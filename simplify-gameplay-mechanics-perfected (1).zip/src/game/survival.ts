// Player systems (v11+v14): equipment slots, off-hand & shield, attack cooldown / sweep / crits, charged bow, crossbow, trident, mace,
// status effects, enchantment effects, linked nether portals (1:8), dragon re-summoning and the workstation back-ends.
// Kept outside engine.ts as plain functions over the Engine instance so the big class only needs thin hooks.
import * as THREE from 'three';
import type { Engine } from './engine';
import { BLOCKS, ID, resolve, type BlockDef } from './data';
import { makeCell, blockId } from './blockState';
import type { Stack, WorldSave, Screen } from './types';
import { SEA } from '../world/terrain';
import { blockDrops } from '../systems/mining';
import { EXTRA_LOOT, type ExtraKind } from '../world/structures';
import {
  ENCHANTS, ENCHANT_BY_ID, EFFECTS, lvl, armorSlotOf, potionEffects, enchantOptions, applyEnchants, anvilCombine,
  grindstone as grind, brewResult, BREW_INGREDIENTS, isBottle, rng, hashStr, canApply, type EnchantOption,
} from '../systems/magic';
import { SMITHING, STONECUT } from '../systems/crafting';

const UP = new THREE.Vector3(0, 1, 0);
const any = (e: unknown) => e as any;
const creative = (e: Engine) => e.meta.mode === 'creative';
const inWater = (e: Engine) => e.getBlock(e.position.x, e.position.y + 0.6, e.position.z) === ID.water;
export const level = (e: Engine) => Math.floor(Math.sqrt(e.xp));
export function spendLevels(e: Engine, n: number) { const l = Math.max(0, level(e) - n); e.xp = l * l; e.lastLevel = l; }

// ---- Inventory with equipment: 0–8 hotbar · 9–35 inventory · 36–39 armor (head, chest, legs, feet) · 40 off-hand --------
export const slotAt = (e: Engine, i: number): Stack | null => (i < 9 ? e.hotbar[i] : i < 36 ? e.inventory[i - 9] : i < 40 ? e.armor[i - 36] : i === 40 ? e.offhand : null) ?? null;
export function setSlot(e: Engine, i: number, s: Stack | null) {
  if (s && s.count <= 0) s = null;
  if (i < 9) e.hotbar[i] = s; else if (i < 36) e.inventory[i - 9] = s; else if (i < 40) e.armor[i - 36] = s; else if (i === 40) e.offhand = s;
}
const accepts = (i: number, s: Stack | null) => !s || i < 36 || i === 40 || armorSlotOf(s.name) === i - 36;
const hasMeta = (s: Stack) => !!s.ench || !!s.label || s.durability !== undefined || !!s.loaded;
export function syncEquip(e: Engine) { e.elytraEquipped = e.armor[1]?.name === 'elytra'; if (!e.elytraEquipped) e.gliding = false; }
export function swapSlots(e: Engine, a: number, b: number) {
  if (a === b) return false;
  const sa = slotAt(e, a), sb = slotAt(e, b);
  if (!accepts(b, sa) || !accepts(a, sb)) { e.onToast('そのスロットには装備できません', 'That item does not fit there'); return false; }
  for (const [i, s] of [[a, sa], [b, sb]] as const) if (i >= 36 && i < 40 && s && lvl(s, 'curse_of_binding') && !creative(e)) { e.onToast('束縛の呪いで外せません', 'Curse of Binding: cannot be removed'); return false; }
  const max = sa ? resolve(sa.name)?.stack ?? 64 : 64;
  if (sa && sb && sa.name === sb.name && max > 1 && !hasMeta(sa) && !hasMeta(sb)) {   // merge identical stacks
    const n = Math.min(max - sb.count, sa.count);
    sb.count += n; sa.count -= n;
    if (sa.count <= 0) setSlot(e, a, null);
  } else { setSlot(e, a, sb); setSlot(e, b, sa); }
  syncEquip(e);
  return true;
}
/** Adds a stack keeping its metadata (durability, enchantments, custom name). */
export function addStack(e: Engine, s: Stack): boolean {
  const def = resolve(s.name);
  if (!def) return false;
  if (def.stack > 1 && !hasMeta(s)) return e.addItem(s.name, s.count);
  for (const arr of [e.hotbar, e.inventory]) for (let i = 0; i < arr.length; i++) if (!arr[i]) { arr[i] = { ...s }; return true; }
  return false;
}
export function takeFrom(e: Engine, i: number, n = 1) { const s = slotAt(e, i); if (!s) return; s.count -= n; if (s.count <= 0) setSlot(e, i, null); }
export function rememberDrop(e: Engine, s: Stack) { if (hasMeta(s)) (any(e).metaDrops ??= []).push({ ...s, count: 1 }); }
/** Item pickup: dropped gear gets its enchantments / wear back. */
export function pickup(e: Engine, name: string, count: number): boolean {
  const list: Stack[] = any(e).metaDrops ?? [], i = list.findIndex(s => s.name === name);
  if (i >= 0 && count === 1) { if (!addStack(e, list[i])) return false; list.splice(i, 1); return true; }
  return e.addItem(name, count);
}
export function toggleElytra(e: Engine) {
  if (e.armor[1]?.name === 'elytra') { if (addStack(e, e.armor[1])) e.armor[1] = null; }
  else { for (let i = 0; i < 36; i++) if (slotAt(e, i)?.name === 'elytra') { swapSlots(e, i, 37); break; } }
  syncEquip(e);
}
function equipHeld(e: Engine, held: Stack): boolean {
  const slot = armorSlotOf(held.name), prev = e.armor[slot];
  if (prev && lvl(prev, 'curse_of_binding') && !creative(e)) return true;
  e.armor[slot] = held; e.hotbar[e.selected] = prev; syncEquip(e);
  e.audio?.play('wood'); e.handDip = 0.18;
  const def = resolve(held.name);
  e.onToast(`${def?.ja ?? held.name} を装備しました`, `Equipped ${held.name.replace(/_/g, ' ')}`);
  return true;
}

// ---- Armor & durability --------------------------------------------------------------------------------------------------
const ARMOR_VALUES: Record<string, [number, number, number, number]> = { leather: [1, 3, 2, 1], chainmail: [2, 5, 4, 1], iron: [2, 6, 5, 2], golden: [2, 5, 3, 1], diamond: [3, 8, 6, 3], netherite: [3, 8, 6, 3], turtle: [2, 0, 0, 0], copper: [2, 4, 3, 1], wooden: [1, 2, 1, 1], stone: [1, 3, 2, 1] };
export function armorPoints(e: Engine): number {
  let n = 0;
  e.armor.forEach((s, i) => { const v = s && ARMOR_VALUES[s.name.split('_')[0]]; if (v) n += v[i]; });
  return Math.min(20, n);
}
const toughness = (e: Engine) => e.armor.reduce((n, s) => n + (s?.name.startsWith('diamond_') ? 2 : s?.name.startsWith('netherite_') ? 3 : 0), 0);
const enchSum = (e: Engine, id: string) => e.armor.reduce((n, s) => n + lvl(s, id), 0);
/** Wears a stack down; Unbreaking gives a chance to ignore each point. Returns true when it broke. */
export function wearStack(e: Engine, s: Stack, n = 1): boolean {
  const max = resolve(s.name)?.durability;
  if (!max || creative(e)) return false;
  const unb = lvl(s, 'unbreaking');
  for (let i = 0; i < n; i++) if (!unb || Math.random() < 1 / (unb + 1)) s.durability = (s.durability ?? max) - 1;
  return (s.durability ?? max) <= 0;
}
export function wear(e: Engine, where: 'main' | 'off' | number, n = 1) {
  const s = where === 'main' ? e.hotbar[e.selected] : where === 'off' ? e.offhand : e.armor[where];
  if (!s || !wearStack(e, s, n)) return;
  if (where === 'main') e.hotbar[e.selected] = null; else if (where === 'off') e.offhand = null; else e.armor[where] = null;
  const def = resolve(s.name);
  e.audio?.play('glass');
  e.onToast(`${def?.ja ?? s.name} が壊れました`, `${s.name.replace(/_/g, ' ')} broke`);
  syncEquip(e);
}
/** Mending: XP repairs a random damaged equipped item (2 durability per point) before it is added to the bar. */
export function mend(e: Engine, xp: number): number {
  const cands = [e.hotbar[e.selected], e.offhand, ...e.armor].filter(s => s && lvl(s, 'mending') && s.durability !== undefined && s.durability < (resolve(s.name)?.durability ?? 0)) as Stack[];
  if (!cands.length) return xp;
  const s = cands[Math.floor(Math.random() * cands.length)], max = resolve(s.name)!.durability!;
  const repair = Math.min(max - s.durability!, xp * 2);
  s.durability! += repair;
  return xp - Math.ceil(repair / 2);
}

// ---- Status effects ------------------------------------------------------------------------------------------------------
export const has = (e: Engine, id: string) => (e.effects[id]?.t ?? 0) > 0;
/** 0 when absent, otherwise the 1-based level. */
export const amp = (e: Engine, id: string) => (has(e, id) ? e.effects[id].amp + 1 : 0);
export function addEffect(e: Engine, id: string, sec: number, a = 0): boolean {
  if (!EFFECTS[id]) return false;
  if (id === 'instant_health') { e.health = Math.min(20, e.health + 4 * 2 ** a); return true; }
  if (id === 'instant_damage') { hurt(e, 6 * 2 ** a, 'magic'); return true; }
  if (id === 'saturation') { e.hunger = Math.min(20, e.hunger + 1 + a); return true; }
  const cur = e.effects[id];
  if (!cur || a > cur.amp || (a === cur.amp && sec > cur.t)) e.effects[id] = { t: sec, amp: a };
  if (id === 'absorption') e.absorption = Math.max(e.absorption, 4 * (a + 1));
  if (id === 'levitation') e.levitationTimer = Math.max(e.levitationTimer, sec);
  return true;
}
export function clearEffects(e: Engine) { e.effects = {}; e.absorption = 0; e.levitationTimer = 0; }
export function speedFactor(e: Engine): number {
  let f = 1 + 0.2 * amp(e, 'speed') - 0.15 * amp(e, 'slowness');
  if (e.blocking || (e.useItemName && e.useTime > 0.05)) f *= 0.4;                 // raised shield / drawn bow
  if (e.input.crouch) f *= 1 + 0.45 * lvl(e.armor[2], 'swift_sneak');
  if (inWater(e)) f *= 1 + 0.33 * lvl(e.armor[3], 'depth_strider');
  return Math.max(0.05, f);
}
export const jumpBoost = (e: Engine) => 1.35 * amp(e, 'jump_boost');
export const oxygenRate = (e: Engine) => (has(e, 'water_breathing') ? 0 : (e.armor[0]?.name === 'turtle_helmet' ? 0.5 : 1) / (1 + lvl(e.armor[0], 'respiration')));
export function drown(e: Engine, dt: number) { const a = any(e); a._drown = (a._drown ?? 0) + dt; if (a._drown >= 1) { a._drown = 0; hurt(e, 2, 'drown'); } }
export function fallDamage(e: Engine, fall: number) {
  if (has(e, 'slow_falling')) return;
  const dmg = Math.floor(fall - 3 - amp(e, 'jump_boost'));
  if (dmg > 0) hurt(e, dmg, 'fall');
}
function mobEffect(e: Engine) {
  const m = e.mobs.nearestHostile(e.position, 5);
  if (!m) return;
  const hard = e.meta.difficulty === 'hard' ? 2 : 1;
  if (m.species === 'witch' || m.species === 'cave_spider' || m.species === 'bogged') addEffect(e, 'poison', 7 * hard, 0);
  else if (m.species === 'bee' || m.species === 'pufferfish') addEffect(e, 'poison', 5 * hard, 0);
  else if (m.species === 'wither' || m.species === 'wither_skeleton') addEffect(e, 'wither', 10, m.species === 'wither' ? 1 : 0);
  else if (m.species === 'warden') addEffect(e, 'darkness', 12, 0);
  else if (m.species === 'husk') addEffect(e, 'hunger', 14 * hard, 0);
  else if (m.species === 'stray') addEffect(e, 'slowness', 15, 0);
  else if (m.species === 'spider' && (hard > 1 || Math.random() < 0.25)) addEffect(e, 'poison', 4, 0);
}

/** All damage to the player: shield, armor (with toughness), Resistance, Protection enchantments, absorption, totems. */
export function hurt(e: Engine, amount: number, source = 'generic', silent = false) {
  if (creative(e) || e.meta.mode === 'spectator' || e.dead || !(amount > 0)) return;
  if (source === 'fire' && has(e, 'fire_resistance')) return;
  if (e.blocking && (source === 'mob' || source === 'explosion' || source === 'projectile')) {
    wear(e, e.hotbar[e.selected]?.name === 'shield' ? 'main' : 'off', Math.max(1, Math.floor(amount)));
    e.audio?.play('wood');
    e.particles.burst(e.camera.position.clone().add(e.camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(0.8)), '#c9b98a', 6, 2);
    if (source !== 'explosion') return;
    amount *= 0.2;
  }
  let dmg = amount;
  const armorApplies = !['fall', 'drown', 'starve', 'void', 'magic'].includes(source);
  if (armorApplies) {
    const a = armorPoints(e);
    dmg *= 1 - Math.min(20, Math.max(a / 5, a - (4 * dmg) / (toughness(e) + 8))) / 25;
  }
  if (source !== 'void' && source !== 'starve') {
    dmg *= Math.max(0, 1 - 0.2 * amp(e, 'resistance'));
    let epf = enchSum(e, 'protection');
    if (source === 'fire') epf += 2 * enchSum(e, 'fire_protection');
    if (source === 'explosion') epf += 2 * enchSum(e, 'blast_protection');
    if (source === 'projectile') epf += 2 * enchSum(e, 'projectile_protection');
    if (source === 'fall') epf += 3 * lvl(e.armor[3], 'feather_falling');
    dmg *= 1 - Math.min(20, epf) / 25;
  }
  if (dmg <= 0.01) return;
  if (armorApplies) for (let i = 0; i < 4; i++) if (e.armor[i]) wear(e, i, Math.max(1, Math.floor(amount / 4)));
  if (source === 'mob') {
    const th = enchSum(e, 'thorns');
    if (th && Math.random() < 0.15 * th) e.mobs.hurtNear(e.position, 3.5, 1 + Math.floor(Math.random() * 4));
    mobEffect(e);
  }
  if (e.absorption > 0) { const a = Math.min(e.absorption, dmg); e.absorption -= a; dmg -= a; }
  e.health = Math.max(0, e.health - dmg);
  e.hitFlash = 0.35;
  if (!silent) e.audio?.play('hurt');
  if (e.health > 0) return;
  const totem = e.hotbar[e.selected]?.name === 'totem_of_undying' ? 'main' : e.offhand?.name === 'totem_of_undying' ? 'off' : null;
  if (totem && source !== 'void') {
    if (totem === 'main') e.hotbar[e.selected] = null; else e.offhand = null;
    clearEffects(e);
    e.health = 2;
    addEffect(e, 'regeneration', 45, 1); addEffect(e, 'absorption', 5, 1); addEffect(e, 'fire_resistance', 40, 0);
    e.particles.burst(e.position.clone().add(new THREE.Vector3(0, 1, 0)), '#f6d33c', 40, 6);
    e.audio?.play('levelup');
    e.onToast('不死のトーテムが発動した！', 'Totem of Undying saved you!');
    return;
  }
  e.dead = true;
  e.pause();
  e.onScreen('death');
}

// ---- Melee: attack cooldown, crits, sweep, mace smash and weapon enchantments -----------------------------------------------
function attackSpeed(name?: string): number {
  if (!name) return 4;
  if (name.endsWith('_sword')) return 1.6;
  if (name === 'trident') return 1.1;
  if (name === 'mace') return 0.6;
  if (name.endsWith('_pickaxe')) return 1.2;
  if (name.endsWith('_axe')) return name.startsWith('wooden') || name.startsWith('stone') ? 0.8 : name.startsWith('iron') ? 0.9 : 1;
  if (name.endsWith('_shovel')) return 1;
  if (name.endsWith('_hoe')) return 3;
  return 4;
}
export const attackCharge = (e: Engine) => Math.min(1, Math.max(0, (e.elapsed - e.attackAt) * attackSpeed(e.hotbar[e.selected]?.name)));
const UNDEAD = new Set(['zombie', 'skeleton', 'wither', 'wither_skeleton', 'zombie_villager', 'stray', 'bogged', 'phantom', 'drowned', 'husk', 'zoglin', 'zombified_piglin', 'skeleton_horse', 'zombie_horse']);
const ARTHROPOD = new Set(['spider', 'bee', 'cave_spider', 'silverfish', 'endermite']);
const AQUATIC = new Set(['fish', 'salmon', 'tropical_fish', 'pufferfish', 'tadpole', 'dolphin', 'squid', 'glow_squid', 'turtle', 'guardian', 'elder_guardian', 'axolotl', 'drowned']);
export function tryAttack(e: Engine, held: Stack | null, tool: ReturnType<typeof resolve>): boolean {
  const fresh = !e.swingHeld, a = any(e);
  e.swingHeld = true;
  const charge = attackCharge(e);
  if (!fresh && (charge < 1 || e.elapsed - (a._hitCheck ?? 0) < 0.1)) return false;   // holding the button re-swings at full strength only
  if (fresh && e.elapsed - e.attackAt < 0.1) return false;
  a._hitCheck = e.elapsed;
  const dir = e.camera.getWorldDirection(new THREE.Vector3()), name = held?.name ?? '';
  let base = (tool?.damage ?? 2) + 3 * amp(e, 'strength') - 4 * amp(e, 'weakness');
  let bonus = lvl(held, 'sharpness') ? 0.5 * lvl(held, 'sharpness') + 0.5 : 0;
  const fall = Math.max(0, (a.fallTop ?? e.position.y) - e.position.y), airborne = !e.grounded && e.velocity.y < -0.5;
  const smash = name === 'mace' && airborne && fall > 1.5;
  if (smash) bonus += Math.min(fall, 3) * 4 + Math.min(Math.max(fall - 3, 0), 5) * 2 + Math.max(0, fall - 8) + 0.5 * lvl(held, 'density') * fall;
  const crit = airborne && charge > 0.9 && !inWater(e);
  const dmg = Math.max(1, Math.round(Math.max(0, base) * (0.2 + charge * charge * 0.8) + bonus * charge));
  e.mobs.looting = lvl(held, 'looting');
  e.mobs.lastHit = null;
  if (!e.mobs.hit(e.camera.position, dir, dmg, crit)) return false;
  e.attackAt = e.elapsed;
  e.handDip = 0.12;
  e.hunger = Math.max(0, e.hunger - 0.02);
  const m = any(e.mobs).lastHit as (ReturnType<typeof e.mobs.nearestHostile>), flat = dir.clone().setY(0).normalize();
  if (m) {
    const special = (UNDEAD.has(m.species) ? 2.5 * lvl(held, 'smite') : 0) + (ARTHROPOD.has(m.species) ? 2.5 * lvl(held, 'bane_of_arthropods') : 0) + (AQUATIC.has(m.species) ? 2.5 * lvl(held, 'impaling') : 0);
    if (special) e.mobs.extraDamage(m, Math.round(special * charge));
    const fire = lvl(held, 'fire_aspect');
    if (fire) { e.mobs.extraDamage(m, 2 * fire); e.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 1, 0)), '#ff8a2a', 10, 3); }
    const kb = lvl(held, 'knockback') + (e.input.run ? 0.6 : 0);
    if (kb && m.species !== 'dragon') m.group.position.addScaledVector(flat, 0.7 * kb);
    if (name.endsWith('_sword') && charge > 0.9 && e.grounded && !e.input.run) {      // sweep attack
      const sw = lvl(held, 'sweeping_edge'), n = e.mobs.hurtNear(m.group.position, 1.9, Math.max(1, Math.round(1 + dmg * (sw / (sw + 1)))), m);
      if (n) any(e.particles).spark?.(m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0)), '#ffffff', 12);
    }
    if (smash) {
      a.fallTop = e.position.y;                                                    // a landed smash cancels the fall damage
      e.velocity.y = Math.max(e.velocity.y, lvl(held, 'wind_burst') ? 9 + 3 * lvl(held, 'wind_burst') : 2);
      e.mobs.hurtNear(m.group.position, 3, Math.max(1, Math.round(dmg * 0.25)), m);
      e.particles.burst(m.group.position.clone(), '#d8d8e8', 30, 7);
      e.audio?.play('explosion', m.group.position);
    }
  }
  if (held && tool?.durability) wear(e, 'main', name.endsWith('_sword') || name === 'trident' || name === 'mace' ? 1 : 2);
  return true;
}

// ---- Mining helpers: Efficiency / Haste / Fatigue / Aqua Affinity, Silk Touch and Fortune ----------------------------------
export function miningFactor(e: Engine, held: Stack | null, underwater: boolean): number {
  let f = 1;
  const eff = lvl(held, 'efficiency');
  if (eff) f /= 1 + (eff * eff + 1) / 6;
  if (has(e, 'haste')) f /= 1 + 0.2 * amp(e, 'haste');
  if (has(e, 'mining_fatigue')) f *= 3.3 ** Math.min(3, amp(e, 'mining_fatigue'));
  if (underwater && lvl(e.armor[0], 'aqua_affinity')) f /= 5;
  return f;
}
const SILKY = /_ore$|^grass_block$|^stone$|^deepslate$|glass|^ice$|^packed_ice$|_leaves$|^mycelium$|^podzol$|^bookshelf$|^glowstone$|^sea_lantern$|^melon$|^clay$|^snow_block$|coral|^sculk|^cobweb$|^amethyst|^gilded_blackstone$/;
export function drops(_e: Engine, b: BlockDef, tool: ReturnType<typeof resolve>, held: Stack | null, state: number) {
  const list = blockDrops(b, tool, state);
  if (lvl(held, 'silk_touch') && SILKY.test(b.name) && b.name !== 'spawner' && (list.length || /glass|_leaves$|^ice$|^packed_ice$|cobweb/.test(b.name))) return [{ name: b.name, count: 1 }];
  const fortune = lvl(held, 'fortune');
  if (fortune && list.length) {
    if (/_ore$/.test(b.name) && list[0].name !== b.name) list[0].count *= 1 + Math.max(0, Math.floor(Math.random() * (fortune + 2)) - 1);
    else if (['glowstone', 'melon', 'sea_lantern', 'nether_wart', 'wheat_crop', 'carrots', 'carrot_crop', 'potatoes', 'potato_crop', 'beetroots', 'beetroot_crop', 'sweet_berry_bush'].includes(b.name)) list[0].count += Math.floor(Math.random() * (fortune + 1));
    else if (b.name === 'gravel' && Math.random() < 0.14 * fortune) list[0].name = 'flint';
  }
  return list;
}

// ---- Use: equipping, shield, bow / crossbow / trident charging, potions, special foods -------------------------------------
const CHARGE: Record<string, number> = { bow: 1, crossbow: 1.25, trident: 0.5 };
const chargeTime = (e: Engine) => { const s = e.hotbar[e.selected]; return s?.name === 'crossbow' ? Math.max(0.25, 1.25 - 0.25 * lvl(s, 'quick_charge')) : CHARGE[s?.name ?? ''] ?? 1; };
function arrowName(e: Engine): string | null {
  if (creative(e)) return 'arrow';
  for (const n of ['arrow', 'spectral_arrow']) if (e.offhand?.name === n || e.countItem(n) > 0) return n;
  return null;
}
function takeArrow(e: Engine, name: string) {
  if (creative(e)) return;
  if (e.offhand?.name === name) { e.offhand.count--; if (e.offhand.count <= 0) e.offhand = null; } else e.removeItem(name, 1);
}
function loadCrossbow(e: Engine, held: Stack) {
  const arrow = arrowName(e);
  if (!arrow) return;
  takeArrow(e, arrow);
  held.loaded = true;
  e.audio?.play('click');
  e.handDip = 0.15;
}
function fireCrossbow(e: Engine, held: Stack) {
  const dir = e.camera.getWorldDirection(new THREE.Vector3()), multi = lvl(held, 'multishot') > 0;
  for (const off of multi ? [-0.17, 0, 0.17] : [0]) e.mobs.shootPlayerArrow(e.camera.position, dir.clone().applyAxisAngle(UP, off), 34, 6 + lvl(held, 'piercing'), {});
  held.loaded = false;
  e.handDip = 0.22;
  wear(e, 'main', multi ? 3 : 1);
}
function release(e: Engine, held: Stack, time: number) {
  const dir = e.camera.getWorldDirection(new THREE.Vector3()), origin = e.camera.position.clone();
  if (held.name === 'bow') {
    const arrow = arrowName(e);
    if (!arrow) { e.onToast('矢がありません', 'Out of arrows'); return; }
    const power = Math.min(1, (time * time + time * 2) / 3);
    if (power < 0.1) return;
    if (!(lvl(held, 'infinity') && arrow === 'arrow')) takeArrow(e, arrow);
    const pw = lvl(held, 'power'), dmg = (2 + power * 4) * (1 + (pw ? 0.25 * (pw + 1) : 0));
    e.mobs.shootPlayerArrow(origin, dir, 8 + power * 24, Math.max(1, Math.round(dmg)), { flame: lvl(held, 'flame') > 0, punch: lvl(held, 'punch') });
    e.handDip = 0.2;
    wear(e, 'main', 1);
  } else if (held.name === 'trident') {
    if (time < 0.5) return;
    const rip = lvl(held, 'riptide');
    if (rip) {                                                       // Riptide: launches the player instead (needs water or rain)
      if (!inWater(e) && !(e.weather !== 'clear' && e.dimension === 'overworld')) return;
      const p = e.position;
      for (let i = 0; i < (6 + rip * 4) * 4; i++) { p.addScaledVector(dir, 0.25); if (e.collides(p)) { p.addScaledVector(dir, -0.25); break; } }
      e.velocity.y = Math.max(e.velocity.y, dir.y * 12);
      any(e).fallTop = p.y;
      e.audio?.play('water');
      wear(e, 'main', 1);
      return;
    }
    const stack = { ...held }, loyalty = lvl(held, 'loyalty'), channel = lvl(held, 'channeling') > 0;
    e.hotbar[e.selected] = null;
    e.audio?.play('bow');
    e.mobs.launchProjectile('trident', origin.clone().addScaledVector(dir, 0.7), dir, 26, undefined, {
      damage: 8, gravity: 7, color: '#4fa69a',
      onEnd: pos => {
        if (channel && e.weather === 'storm' && e.dimension === 'overworld') { e.environment.triggerLightning(); e.audio?.play('thunder'); e.mobs.hurtNear(pos, 3, 10); }
        wearStack(e, stack, 1);
        if (creative(e) || loyalty) (any(e).returning ??= []).push({ stack, t: 0.3 + 0.9 / Math.max(1, loyalty) });
        else { (any(e).metaDrops ??= []).push({ ...stack, count: 1 }); e.particles.drop(pos, 'trident', 1, '#4fa69a'); }
      },
    });
  }
}
function splash(e: Engine, pos: THREE.Vector3, effects: [string, number, number][], color: string) {
  e.particles.burst(pos, color, 28, 4);
  e.audio?.play('glass', pos);
  const d = pos.distanceTo(e.position.clone().add(new THREE.Vector3(0, 0.9, 0)));
  for (const [id, sec, a] of effects) {
    if (d < 4) addEffect(e, id, Math.max(1, sec * (1 - d / 4)), a);
    if (id === 'instant_damage') e.mobs.hurtNear(pos, 4, 6 * 2 ** a);
    else if (id === 'poison' || id === 'wither') e.mobs.hurtNear(pos, 4, 3 + 2 * a);
  }
}
/** Runs before the engine's own right-click logic. Returns true when the click was fully handled. */
export function useItem(e: Engine, held: Stack | null, def: ReturnType<typeof resolve>): boolean {
  if (!held) return false;
  const name = held.name, dir = e.camera.getWorldDirection(new THREE.Vector3());
  if (armorSlotOf(name) >= 0) return equipHeld(e, held);
  if (name === 'shield') return true;                                          // raised while the button is held (see tick)
  if (name === 'bow' || name === 'trident' || (name === 'crossbow' && !held.loaded)) {
    if (name !== 'trident' && !arrowName(e)) { e.onToast('矢がありません', 'Out of arrows'); return true; }
    if (!any(e.input).useHeld) { if (name === 'crossbow') loadCrossbow(e, held); else release(e, held, 1.1); return true; }   // tap / gamepad input
    e.useItemName = name; e.useTime = 0;
    return true;
  }
  if (name === 'crossbow') { fireCrossbow(e, held); return true; }
  const potion = potionEffects(name);
  if (potion) {
    if (potion.splash) {
      e.mobs.launchProjectile('potion', e.camera.position.clone().addScaledVector(dir, 0.7), dir.clone().add(new THREE.Vector3(0, 0.18, 0)), 15, undefined, { gravity: 16, color: def?.color ?? '#c9c9ff', onEnd: pos => splash(e, pos, potion.effects, def?.color ?? '#c9c9ff') });
      e.audio?.play('bow');
      if (!creative(e)) e.consumeSelected();
    } else {
      for (const [id, sec, a] of potion.effects) addEffect(e, id, sec, a);
      e.audio?.play('eat');
      if (!creative(e)) e.hotbar[e.selected] = { name: 'glass_bottle', count: 1 };
    }
    e.handDip = 0.22;
    return true;
  }
  if (['water_bottle', 'awkward_potion', 'mundane_potion', 'thick_potion', 'potion'].includes(name)) {
    e.audio?.play('eat'); e.handDip = 0.22;
    if (!creative(e)) e.hotbar[e.selected] = { name: 'glass_bottle', count: 1 };
    return true;
  }
  if (name === 'milk_bucket') { clearEffects(e); e.mobs.badOmen = false; e.audio?.play('eat'); e.handDip = 0.22; if (!creative(e)) e.hotbar[e.selected] = { name: 'bucket', count: 1 }; return true; }
  if (name === 'experience_bottle') {
    e.addXp(3 + Math.floor(Math.random() * 9));
    e.particles.burst(e.camera.position.clone().addScaledVector(dir, 2), '#b8f25a', 14, 3);
    e.audio?.play('glass'); e.handDip = 0.2;
    if (!creative(e)) e.consumeSelected();
    return true;
  }
  if (name === 'glass_bottle') {
    const t = e.target;
    const wet = inWater(e) || (!!t && (e.getBlock(t.x + t.normal.x, t.y + t.normal.y, t.z + t.normal.z) === ID.water || t.id === ID.water || BLOCKS[t.id]?.name === 'cauldron'));
    if (!wet) return false;
    if (!creative(e)) e.consumeSelected();
    if (!addStack(e, { name: 'water_bottle', count: 1 })) e.particles.drop(e.position.clone(), 'water_bottle', 1, '#3f76e4');
    e.audio?.play('water'); e.handDip = 0.2;
    return true;
  }
  if (name === 'map' || name === 'filled_map') {
    if (name === 'map') { if (!creative(e)) e.consumeSelected(); addStack(e, { name: 'filled_map', count: 1, label: `${Math.round(e.position.x)},${Math.round(e.position.z)}` }); }
    e.stationKey = 'hand'; e.pause(true); e.onScreen('cartography');
    return true;
  }
  if (name === 'writable_book' || name === 'written_book') { e.stationKey = 'hand'; e.pause(true); e.onScreen('lectern'); return true; }
  if (def?.food && (e.hunger < 20 || creative(e) || ['golden_apple', 'enchanted_golden_apple', 'chorus_fruit', 'honey_bottle'].includes(name))) {
    // Allow golden apple to cure zombie villager first if looking at one
    if ((name === 'golden_apple' || name === 'enchanted_golden_apple') && e.mobs.pick(e.camera.position, dir)?.species === 'zombie_villager') {
      return false;
    }
    if (name === 'golden_apple') { addEffect(e, 'regeneration', 5, 1); addEffect(e, 'absorption', 120, 0); }
    else if (name === 'enchanted_golden_apple') { addEffect(e, 'regeneration', 20, 1); addEffect(e, 'absorption', 120, 3); addEffect(e, 'resistance', 300, 0); addEffect(e, 'fire_resistance', 300, 0); }
    else if (name === 'rotten_flesh' && Math.random() < 0.8) addEffect(e, 'hunger', 30, 0);
    else if (name === 'spider_eye') addEffect(e, 'poison', 5, 0);
    else if (name === 'poisonous_potato' && Math.random() < 0.6) addEffect(e, 'poison', 5, 0);
    else if (name === 'pufferfish') { addEffect(e, 'hunger', 15, 2); addEffect(e, 'poison', 60, 1); addEffect(e, 'nausea', 15, 0); }
    else if (name === 'honey_bottle') delete e.effects.poison;
  }
  return false;                                                                 // the engine's food / placement code continues
}

/** Per-frame update: effect timers and ticks, shield state, charge-and-release weapons, loyalty returns. */
export function tick(e: Engine, dt: number) {
  const fx = e.effects, a = any(e), acc: Record<string, number> = (a._fxAcc ??= {});
  for (const id of Object.keys(fx)) { fx[id].t -= dt; if (fx[id].t <= 0) { delete fx[id]; if (id === 'absorption') e.absorption = 0; } }
  if (e.levitationTimer > 0) fx.levitation = { t: e.levitationTimer, amp: 0 }; else delete fx.levitation;
  const every = (id: string, period: number, fn: () => void) => {
    if (!has(e, id)) { acc[id] = 0; return; }
    acc[id] = (acc[id] ?? 0) + dt;
    while (acc[id] >= period) { acc[id] -= period; fn(); }
  };
  every('regeneration', 2.5 / 2 ** Math.max(0, amp(e, 'regeneration') - 1), () => { if (!e.dead) e.health = Math.min(20, e.health + 1); });
  every('poison', 1.25 / 2 ** Math.max(0, amp(e, 'poison') - 1), () => { if (e.health > 1) hurt(e, 1, 'magic', true); });
  every('wither', 2 / 2 ** Math.max(0, amp(e, 'wither') - 1), () => hurt(e, 1, 'magic', true));
  every('hunger', 1, () => { if (!creative(e)) e.hunger = Math.max(0, e.hunger - 0.1 * amp(e, 'hunger')); });

  const held = e.hotbar[e.selected], name = held?.name ?? '', using = !!a.input.useHeld && !e.dead;
  e.blocking = using && (name === 'shield' || (e.offhand?.name === 'shield' && !CHARGE[name]));
  if (e.useItemName) {
    if (e.useItemName !== name || !held) { e.useItemName = ''; e.useTime = 0; }
    else if (using) {
      e.useTime += dt;
      if (name === 'crossbow' && !held.loaded && e.useTime >= chargeTime(e)) { loadCrossbow(e, held); e.useItemName = ''; e.useTime = 0; }
    } else { const t = e.useTime; e.useItemName = ''; e.useTime = 0; release(e, held, t); }
  }
  const returning: { stack: Stack; t: number }[] = a.returning ?? [];
  for (let i = returning.length - 1; i >= 0; i--) {
    returning[i].t -= dt;
    if (returning[i].t > 0) continue;
    if (!addStack(e, returning[i].stack)) { (a.metaDrops ??= []).push(returning[i].stack); e.particles.drop(e.position.clone(), returning[i].stack.name, 1, '#4fa69a'); }
    e.audio?.play('xp');
    returning.splice(i, 1);
  }
}

// ---- Dimension travel ------------------------------------------------------------------------------------------------------
export function writeEdit(e: Engine, x: number, y: number, z: number, id: number, state = 0) {
  const key = `${x},${y},${z}`, cell = makeCell(id, state), cKey = Math.floor(x / 16) + ',' + Math.floor(z / 16);
  e.edits.set(key, cell);
  let bucket = e.editsByChunk.get(cKey);
  if (!bucket) { bucket = new Map(); e.editsByChunk.set(cKey, bucket); }
  bucket.set(key, cell);
}
function buildPortal(e: Engine, x: number, y: number, z: number) {      // frame in the x–y plane; portal cells (x, x+1) × (y … y+2)
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 2; dx++) {
    writeEdit(e, x + dx, y - 1, z + dz, ID.obsidian);
    for (let dy = 0; dy <= 3; dy++) writeEdit(e, x + dx, y + dy, z + dz, 0);
  }
  for (let dx = -1; dx <= 2; dx++) writeEdit(e, x + dx, y + 3, z, ID.obsidian);
  for (let dy = 0; dy <= 2; dy++) {
    writeEdit(e, x - 1, y + dy, z, ID.obsidian); writeEdit(e, x + 2, y + dy, z, ID.obsidian);
    writeEdit(e, x, y + dy, z, ID.portal); writeEdit(e, x + 1, y + dy, z, ID.portal);
  }
}
/** Nether portals: coordinates scale 1:8, an existing portal near the target is reused, otherwise a new one is built. */
export function netherTravel(e: Engine) {
  const toNether = e.dimension !== 'nether', sx = e.position.x, sz = e.position.z;
  const tx = Math.floor(toNether ? sx / 8 : sx * 8), tz = Math.floor(toNether ? sz / 8 : sz * 8);
  e.changeDimension(toNether ? 'nether' : 'overworld');
  const range = toNether ? 16 : 128;
  let best: [number, number, number] | null = null, bestD = range * range + 1;
  for (const [key, cell] of e.edits) {
    if (blockId(cell) !== ID.portal) continue;
    const [x, y, z] = key.split(',').map(Number), d = (x - tx) ** 2 + (z - tz) ** 2;
    if (d < bestD || (d === bestD && best !== null && y < best[1])) { bestD = d; best = [x, y, z]; }
  }
  let px: number, py: number, pz: number, built = false;
  if (best) { [px, py, pz] = best; while (blockId(e.edits.get(`${px},${py - 1},${pz}`) ?? 0) === ID.portal) py--; }
  else {
    px = tx; pz = tz;
    const h = e.terrain.height(px, pz);
    py = toNether ? Math.max(19, Math.min(48, h + 1)) : Math.max(h, SEA) + 1;
    buildPortal(e, px, py, pz);
    built = true;
  }
  e.position.set(px + 0.5, py + 0.05, pz + 0.5);
  e.velocity.set(0, 0, 0);
  any(e).fallTop = py;
  e.portalLock = true;
  e.portalCharge = 0;
  e.achievement('nether');
  e.onToast(`${toNether ? 'ネザー' : 'オーバーワールド'}へ（${px}, ${py}, ${pz}）${built ? ' — 新しいポータルを生成' : ' — 既存ポータルに接続'}`, `${toNether ? 'Nether' : 'Overworld'} (${px}, ${py}, ${pz})${built ? ' — new portal built' : ' — linked to existing portal'}`);
}
/** Four end crystals on the sides of the exit portal bring the Ender Dragon back. */
export function checkDragonRespawn(e: Engine) {
  if (e.dimension !== 'end' || !e.dragonDefeated) return;
  const crystals = (any(e.mobs).crystals ?? []) as { pos: THREE.Vector3 }[];
  const sides = new Set(crystals.filter(c => Math.hypot(c.pos.x, c.pos.z) < 5.6 && Math.abs(c.pos.y - 29.5) < 4).map(c => (Math.abs(c.pos.x) > Math.abs(c.pos.z) ? (c.pos.x > 0 ? 'e' : 'w') : c.pos.z > 0 ? 's' : 'n')));
  if (sides.size < 4) { e.onToast(`エンドクリスタル ${sides.size}/4 — 出口ポータルの四辺に置くとドラゴンを再召喚`, `End crystals ${sides.size}/4 — place one on each side of the exit portal`); return; }
  e.dragonDefeated = false;
  e.mobs.host.dragonDefeated = false;
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (dx || dz) e.setBlock(dx, 28, dz, 0);
  e.mobs.clear();
  e.mobs.populate();
  e.environment.triggerLightning();
  e.audio?.play('explosion');
  e.onToast('エンダードラゴンが再召喚された！', 'The Ender Dragon has been resummoned!');
}

// ---- Workstations ------------------------------------------------------------------------------------------------------------
const STATION_OF: Record<string, Screen> = { enchanting_table: 'enchanting', anvil: 'anvil', grindstone: 'grindstone', smithing_table: 'smithing', stonecutter: 'stonecutter', brewing_stand: 'brewing', loom: 'loom', cartography_table: 'cartography', lectern: 'lectern' };
export function openStation(e: Engine, t: { x: number; y: number; z: number; id: number }): boolean {
  const kind = STATION_OF[BLOCKS[t.id]?.name ?? ''];
  if (!kind) return false;
  e.stationKey = `${t.x},${t.y},${t.z}`;
  if (kind === 'brewing') { e.containers[e.stationKey] ??= [null, null, null, null, null]; e.furnaces[e.stationKey] ??= { burn: 0, progress: 0 }; }
  if (kind === 'lectern') e.containers[e.stationKey] ??= [null];
  e.audio?.play('click');
  e.pause(true);
  e.onScreen(kind);
  return true;
}
export function bookshelves(e: Engine): number {
  const [x, y, z] = e.stationKey.split(',').map(Number);
  if (!Number.isFinite(x)) return 0;
  let n = 0;
  for (let dy = 0; dy <= 1; dy++) for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
    if (Math.max(Math.abs(dx), Math.abs(dz)) !== 2 || e.getBlock(x + dx, y + dy, z + dz) !== ID.bookshelf) continue;
    if (!BLOCKS[e.getBlock(x + Math.trunc(dx / 2), y + dy, z + Math.trunc(dz / 2))]?.solid) n++;     // needs a free gap towards the table
  }
  return Math.min(15, n);
}
export function enchantOffers(e: Engine, i: number): EnchantOption[] {
  const s = slotAt(e, i);
  return !s || s.ench ? [] : enchantOptions(s.name, bookshelves(e), e.enchantSeed);
}
export function doEnchant(e: Engine, i: number, option: number): boolean {
  const s = slotAt(e, i), o = enchantOffers(e, i)[option];
  if (!s || !o) return false;
  if (!creative(e)) {
    if (level(e) < o.level || e.countItem('lapis_lazuli') < o.cost) return false;
    e.removeItem('lapis_lazuli', o.cost);
    spendLevels(e, o.cost);
  }
  const out = applyEnchants({ ...s, count: 1 }, o.list);
  if (s.count > 1) { s.count--; if (!addStack(e, out)) e.particles.drop(e.position.clone(), out.name, 1, '#b06ad8'); }
  else setSlot(e, i, out);
  e.enchantSeed = ((Math.imul(e.enchantSeed, 1103515245) + 12345) >>> 0) % 2147483647 || 1;
  e.audio?.play('levelup');
  e.statistics.enchanted = (e.statistics.enchanted ?? 0) + 1;
  e.achievement('enchant');
  return true;
}
export const anvilPreview = (e: Engine, li: number, ri: number, name: string) => (li < 0 ? null : anvilCombine(slotAt(e, li), ri >= 0 ? slotAt(e, ri) : null, name));
export function doAnvil(e: Engine, li: number, ri: number, name: string): boolean {
  const r = anvilPreview(e, li, ri, name), left = slotAt(e, li);
  if (!r || !left) return false;
  if (!creative(e)) { if (level(e) < r.cost || r.cost > 39) return false; spendLevels(e, r.cost); }
  if (ri >= 0 && r.useRight) takeFrom(e, ri, r.useRight);
  if (left.count > 1) { left.count--; addStack(e, { ...r.result, count: 1 }); } else setSlot(e, li, { ...r.result, count: 1 });
  e.audio?.play('stone');
  return true;
}
export const grindPreview = (e: Engine, ai: number, bi: number) => grind(ai >= 0 ? slotAt(e, ai) : null, bi >= 0 ? slotAt(e, bi) : null);
export function doGrind(e: Engine, ai: number, bi: number): boolean {
  const r = grindPreview(e, ai, bi);
  if (!r) return false;
  const keep = ai >= 0 ? ai : bi;
  if (ai >= 0 && bi >= 0) setSlot(e, bi, null);
  setSlot(e, keep, r.result);
  if (r.xp) e.addXp(r.xp);
  e.audio?.play('stone');
  return true;
}
export function smithPreview(e: Engine, ti: number, bi: number, ai: number): Stack | null {
  const t = slotAt(e, ti), b = slotAt(e, bi), a = slotAt(e, ai);
  const r = t && b && a ? SMITHING.find(x => x.template === t.name && x.base === b.name && x.addition === a.name) : undefined;
  if (!r || !b) return null;
  const oldMax = resolve(b.name)?.durability ?? 0, newMax = resolve(r.result)?.durability ?? 0;
  const out: Stack = { ...b, name: r.result };
  if (b.durability !== undefined && newMax) out.durability = Math.max(1, newMax - (oldMax - b.durability));
  return out;
}
export function doSmith(e: Engine, ti: number, bi: number, ai: number): boolean {
  const out = smithPreview(e, ti, bi, ai);
  if (!out) return false;
  takeFrom(e, ti, 1); takeFrom(e, ai, 1); setSlot(e, bi, out);
  e.audio?.play('stone');
  return true;
}
export const stonecutOptions = (e: Engine, i: number) => (i < 0 ? [] : STONECUT[slotAt(e, i)?.name ?? ''] ?? []);
export function doStonecut(e: Engine, i: number, result: string, all = false): boolean {
  const s = slotAt(e, i), o = s ? (STONECUT[s.name] ?? []).find(x => x.result === result) : undefined;
  if (!s || !o) return false;
  let done = 0;
  for (let n = all ? s.count : 1; n > 0; n--) { if (!e.addItem(o.result, o.count)) break; takeFrom(e, i, 1); done++; }
  if (done) e.audio?.play('stone');
  return done > 0;
}
/** Brewing stand slots: 0–2 bottles, 3 ingredient, 4 blaze powder. `state.burn` holds the remaining fuel charges. */
export function brewTick(e: Engine, state: { burn: number; progress: number }, slots: (Stack | null)[], dt: number) {
  const ing = slots[3];
  if (!ing || ![0, 1, 2].some(i => slots[i] && brewResult(slots[i]!.name, ing.name))) { state.progress = 0; return; }
  if (state.burn <= 0) {
    const fuel = slots[4];
    if (fuel?.name !== 'blaze_powder') { state.progress = 0; return; }
    fuel.count--; if (fuel.count <= 0) slots[4] = null;
    state.burn = 20;
  }
  state.progress += dt / 10;
  if (state.progress < 1) return;
  state.progress = 0; state.burn -= 1;
  for (let i = 0; i < 3; i++) { const b = slots[i], out = b ? brewResult(b.name, ing.name) : null; if (out) slots[i] = { name: out, count: 1 }; }
  ing.count--; if (ing.count <= 0) slots[3] = null;
  e.audio?.play('water');
  e.achievement('brew');
}
export function brewPut(e: Engine, i: number): boolean {
  const s = slotAt(e, i), slots = e.containers[e.stationKey];
  if (!s || !slots || slots.length !== 5) return false;
  const stackInto = (dest: number) => {
    if (slots[dest] && slots[dest]!.name !== s.name) return false;
    const n = Math.min(64 - (slots[dest]?.count ?? 0), s.count);
    if (n <= 0) return false;
    if (slots[dest]) slots[dest]!.count += n; else slots[dest] = { name: s.name, count: n };
    takeFrom(e, i, n);
    return true;
  };
  if (isBottle(s.name)) { const dest = [0, 1, 2].find(k => !slots[k]); if (dest === undefined) return false; slots[dest] = { name: s.name, count: 1 }; takeFrom(e, i, 1); return true; }
  if (s.name === 'blaze_powder' && (!slots[4] || (slots[3] && slots[3].name !== 'blaze_powder'))) return stackInto(4);
  if (BREW_INGREDIENTS.has(s.name)) return stackInto(3);
  return false;
}
export function containerTake(e: Engine, slots: (Stack | null)[], i: number): boolean {
  const s = slots[i];
  if (!s || !addStack(e, s)) return false;
  slots[i] = null;
  return true;
}
export function containerPut(e: Engine, i: number, slots: (Stack | null)[]): boolean {
  const s = slotAt(e, i);
  if (!s) return false;
  const max = resolve(s.name)?.stack ?? 64, plain = max > 1 && !hasMeta(s);
  let dest = plain ? slots.findIndex(x => x?.name === s.name && x.count < max && !hasMeta(x)) : -1;
  if (dest < 0) dest = slots.findIndex(x => !x);
  if (dest < 0) return false;
  if (slots[dest]) { const n = Math.min(max - slots[dest]!.count, s.count); slots[dest]!.count += n; takeFrom(e, i, n); }
  else { slots[dest] = { ...s }; setSlot(e, i, null); }
  return true;
}
export const LOOM_PATTERNS: [string, string, string][] = [['stripe', '縦帯', 'Pale'], ['cross', '十字', 'Cross'], ['border', '縁取り', 'Bordure'], ['gradient', 'グラデーション', 'Gradient'], ['circle', '円', 'Roundel'], ['rhombus', 'ひし形', 'Lozenge'], ['bricks', 'レンガ模様', 'Field masoned'], ['creeper', 'クリーパー', 'Creeper charge'], ['skull', 'ドクロ', 'Skull charge'], ['flower', '花', 'Flower charge']];
export function doLoom(e: Engine, bi: number, di: number, pattern: string): boolean {
  const banner = slotAt(e, bi), dye = slotAt(e, di);
  if (!banner?.name.endsWith('_banner') || !dye?.name.endsWith('_dye')) return false;
  const layers = banner.label ? banner.label.split(' + ') : [];
  if (layers.length >= 6) { e.onToast('模様は6層までです', 'A banner holds at most 6 patterns'); return false; }
  const out: Stack = { name: banner.name, count: 1, label: [...layers, `${dye.name.replace(/_dye$/, '')} ${pattern}`].join(' + ') };
  takeFrom(e, di, 1);
  if (banner.count > 1) { banner.count--; addStack(e, out); } else setSlot(e, bi, out);
  e.audio?.play('wood');
  return true;
}
export function doCartography(e: Engine, mi: number, oi: number): boolean {
  const map = slotAt(e, mi), other = slotAt(e, oi);
  if (map?.name !== 'filled_map' || !other) return false;
  const [pos = '0,0', zoom = '1', lock = ''] = (map.label ?? '').split('|');
  if (other.name === 'map') { takeFrom(e, oi, 1); addStack(e, { ...map }); }                                   // copy
  else if (lock) { e.onToast('ロックされた地図は変更できません', 'Locked maps cannot be changed'); return false; }
  else if (other.name === 'paper') { if (Number(zoom) >= 4) return false; takeFrom(e, oi, 1); map.label = `${pos}|${Number(zoom) + 1}|`; }   // zoom out
  else if (other.name === 'glass_pane') { takeFrom(e, oi, 1); map.label = `${pos}|${zoom}|locked`; }              // lock
  else return false;
  e.audio?.play('wood');
  return true;
}
export const lecternBook = (e: Engine): Stack | null => (e.stationKey === 'hand' ? e.hotbar[e.selected] : e.containers[e.stationKey]?.[0]) ?? null;

/** Deterministic loot for chests generated by the v11 structures. */
export function rollLoot(e: Engine, kind: ExtraKind, x: number, y: number, z: number): (Stack | null)[] {
  const slots: (Stack | null)[] = Array(27).fill(null), table = EXTRA_LOOT[kind], r = rng(hashStr(`${kind}:${x},${y},${z}:${e.terrain.seed}`));
  const rolls = table.rolls[0] + Math.floor(r() * (table.rolls[1] - table.rolls[0] + 1)), total = table.items.reduce((s, i) => s + i[3], 0);
  for (let n = 0; n < rolls; n++) {
    let w = r() * total;
    const it = table.items.find(i => (w -= i[3]) <= 0) ?? table.items[0];
    let slot = Math.floor(r() * 27);
    while (slots[slot]) slot = (slot + 1) % 27;
    const st: Stack = { name: it[0], count: Math.min(it[1] + Math.floor(r() * (it[2] - it[1] + 1)), resolve(it[0])?.stack ?? 64) };
    if (it[0] === 'enchanted_book') {
      const pool = kind === 'ancient_city' ? ENCHANTS.filter(x => x.id === 'swift_sneak' || x.id === 'mending' || x.id === 'protection') : ENCHANTS.filter(x => !x.curse);
      const pickE = pool[Math.floor(r() * pool.length)];
      st.ench = { [pickE.id]: 1 + Math.floor(r() * pickE.max) };
    }
    slots[slot] = st;
  }
  return slots;
}

// ---- Commands, save data, HUD ---------------------------------------------------------------------------------------------
export function command(e: Engine, cmd: string, args: string[]): string {
  if (cmd === 'effect') {
    if (args[0] === 'clear') { clearEffects(e); return 'Effects cleared'; }
    const rest = args[0] === 'give' ? args.slice(1) : args, id = rest[0]?.replace(/^minecraft:/, '');
    if (!id || !EFFECTS[id]) return 'Usage: /effect give <effect> [seconds] [amplifier] · /effect clear — ' + Object.keys(EFFECTS).join(', ');
    addEffect(e, id, Number(rest[1]) || 30, Math.max(0, Math.min(9, Number(rest[2]) || 0)));
    return `Applied ${EFFECTS[id].en}`;
  }
  if (cmd === 'enchant') {
    const s = e.hotbar[e.selected], def = ENCHANT_BY_ID[args[0]?.replace(/^minecraft:/, '') ?? ''];
    if (!s || !def) return 'Usage: /enchant <enchantment> [level] (hold the item) — ' + ENCHANTS.map(x => x.id).join(', ');
    if (!canApply(def, s.name)) return `${def.en} cannot be applied to ${s.name}`;
    const l = Math.max(1, Math.min(def.max, Number(args[1]) || 1));
    e.hotbar[e.selected] = applyEnchants(s.count > 1 ? { ...s, count: 1 } : s, [[def.id, l]]);
    return `Applied ${def.en} ${l}`;
  }
  if (cmd === 'xp') {
    const raw = args[0] ?? '', n = Number(raw.replace(/L$/i, '')) || 0;
    if (/L$/i.test(raw)) { const l = Math.max(0, level(e) + n); e.xp = l * l; e.lastLevel = l; } else e.addXp(n);
    return `Level ${level(e)} (${Math.floor(e.xp)} xp)`;
  }
  if (cmd === 'clear') { e.hotbar = Array(9).fill(null); e.inventory = Array(27).fill(null); e.armor = [null, null, null, null]; e.offhand = null; syncEquip(e); return 'Inventory cleared'; }
  if (cmd === 'kill') { hurt(e, 1000, 'void'); return 'Ouch.'; }
  return 'Unknown command. /help';
}
export function loadPlayer(e: Engine, save?: WorldSave) {
  e.armor = [0, 1, 2, 3].map(i => save?.armor?.[i] ?? null);
  e.offhand = save?.offhand ?? null;
  e.effects = { ...(save?.effects ?? {}) };
  e.absorption = save?.absorption ?? 0;
  e.enchantSeed = save?.enchantSeed ?? (hashStr(e.meta.seed + e.meta.id) % 2147483647 || 1);
  e.attackAt = -10; e.useTime = 0; e.useItemName = ''; e.blocking = false; e.portalLock = false; e.swingHeld = false;
  const a = any(e); a.metaDrops = []; a.returning = []; a._fxAcc = {};
  if (save?.elytraEquipped && !save.armor) {                         // saves from before equipment slots: wear the elytra properly
    for (let i = 0; i < 36; i++) if (slotAt(e, i)?.name === 'elytra') { e.armor[1] = slotAt(e, i); setSlot(e, i, null); break; }
  }
  syncEquip(e);
}
export const savePlayer = (e: Engine) => ({ armor: e.armor, offhand: e.offhand, effects: e.effects, absorption: e.absorption, enchantSeed: e.enchantSeed });
export function hud(e: Engine) {
  return {
    armorSlots: e.armor.map(s => (s ? { ...s } : null)), offhand: e.offhand ? { ...e.offhand } : null,
    effects: Object.entries(e.effects).map(([id, v]) => ({ id, t: v.t, amp: v.amp })), absorption: e.absorption,
    attackCharge: attackCharge(e), useCharge: e.useItemName ? Math.min(1, e.useTime / chargeTime(e)) : 0, blocking: e.blocking,
  };
}
/** Worlds saved with the old 128-block height: lift overworld edits so builds stay on the (now higher) ground. */
export function liftLegacyOverworld(store: { edits: Map<string, number>; containers: Record<string, unknown>; furnaces: Record<string, unknown> }, dy = 43) {
  const shift = (key: string) => { const [x, y, z] = key.split(',').map(Number); return `${x},${y + dy},${z}`; };
  const edits = new Map<string, number>();
  for (const [k, v] of store.edits) edits.set(shift(k), v);
  store.edits = edits;
  store.containers = Object.fromEntries(Object.entries(store.containers).map(([k, v]) => [shift(k), v]));
  store.furnaces = Object.fromEntries(Object.entries(store.furnaces).map(([k, v]) => [shift(k), v]));
}
