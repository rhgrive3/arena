import type { MobSave, RaidState } from '../entities/mobs';
import type { VehicleSave } from '../entities/vehicles';

export type GameMode = 'survival' | 'creative' | 'adventure' | 'spectator';
export type Dimension = 'overworld' | 'nether' | 'end';
export type Screen = 'playing' | 'title' | 'worlds' | 'create' | 'options' | 'pause' | 'inventory' | 'chat' | 'death' | 'advancements' | 'stats' | 'loading' | 'credits' | 'quit' | 'workbench' | 'furnace' | 'container' | 'trade' | 'escape' | 'enchanting' | 'anvil' | 'grindstone' | 'smithing' | 'stonecutter' | 'brewing' | 'loom' | 'cartography' | 'lectern' | 'crafter';
export interface Settings { quality: 'low'|'medium'|'high'|'ultra'; adaptiveResolution: boolean; distance: number; sensitivity: number; volume: number; music: boolean; muted: boolean; invertX: boolean; invertY: boolean; touch: boolean; touchSize: number; fov: number; language: 'ja'|'en'; bobbing: boolean; bloom: boolean; }
const coarsePointer = typeof matchMedia !== 'undefined' && matchMedia('(pointer: coarse)').matches;
export const DEFAULT_SETTINGS: Settings = { quality: coarsePointer || typeof navigator !== 'undefined' && navigator.hardwareConcurrency <= 4 ? 'medium' : 'high', adaptiveResolution: true, distance: coarsePointer ? 3 : 4, sensitivity: 1, volume: .55, music: true, muted: false, invertX: false, invertY: false, touch: coarsePointer, touchSize: 1, fov: 75, language: 'ja', bobbing: true, bloom: true };
export interface WorldMeta { id: string; name: string; seed: string; mode: GameMode; difficulty: 'peaceful'|'easy'|'normal'|'hard'; hardcore: boolean; structures: boolean; bonus: boolean; cheats: boolean; created: number; updated: number; playTime: number; }
export interface Stack { name: string; count: number; durability?: number; ench?: Record<string, number>; label?: string; loaded?: boolean; }
export interface EffectView { id: string; t: number; amp: number; }
export interface DimensionSave { edits:[string,number][]; containers:Record<string,(Stack|null)[]>; furnaces:Record<string,{burn:number;progress:number}>; }
export interface WorldSave {
  meta: WorldMeta;
  position: [number,number,number];
  yaw: number;
  pitch: number;
  time: number;
  dimension: Dimension;
  edits: [string,number][];
  inventory: (Stack|null)[];
  hotbar: (Stack|null)[];
  health: number;
  hunger: number;
  xp: number;
  selected: number;
  statistics: Record<string,number>;
  achievements: string[];
  containers?: Record<string,(Stack|null)[]>;
  furnaces?: Record<string,{burn:number;progress:number}>;
  dimensions?: Partial<Record<Dimension,DimensionSave>>;
  armor?: (Stack|null)[];
  offhand?: Stack|null;
  effects?: Record<string,{t:number;amp:number}>;
  absorption?: number;
  enchantSeed?: number;
  respawnPoint?: [number,number,number]|null;
  dragonDefeated?: boolean;
  elytraEquipped?: boolean;
  entities?: Partial<Record<Dimension, { mobs: MobSave[]; vehicles: VehicleSave[]; badOmen?: boolean; raid?: RaidState }>>;
  crafterDisabled?: Record<string, number>;
  randomTickSpeed?: number;
}
export interface BossInfo { name: string; ja: string; hp: number; maxHp: number; color: string; crystals?: number; }
export interface GameSnapshot { ready: boolean; progress: number; x: number; y: number; z: number; yaw: number; pitch: number; fps: number; chunks: number; biome: string; dimension: Dimension; health: number; hunger: number; oxygen: number; xp: number; level: number; armor: number; time: number; selected: number; hotbar: (Stack|null)[]; inventory: (Stack|null)[]; target: string; breaking: number; mode: GameMode; flying: boolean; gliding: boolean; elytraEquipped: boolean; sleeping: boolean; portalCharge: number; underwater: boolean; raining: boolean; thundering: boolean; moonPhase: number; weather: string; debug: boolean; statistics: Record<string,number>; achievements: string[]; dead: boolean; containers: Record<string,(Stack|null)[]>; boss?: BossInfo | null; bossName: string; bossHp: number; bossMaxHp: number; crystals: number; dragonDefeated: boolean; hitFlash?: number; armorSlots: (Stack|null)[]; offhand: Stack|null; effects: EffectView[]; absorption: number; attackCharge: number; useCharge: number; blocking: boolean; riding?: string; fishing?: string; }
export const EMPTY_SNAPSHOT: GameSnapshot = {ready:false,progress:0,x:0,y:0,z:0,yaw:0,pitch:0,fps:60,chunks:0,biome:'plains',dimension:'overworld',health:20,hunger:20,oxygen:20,xp:0,level:0,armor:0,time:.23,selected:0,hotbar:[],inventory:[],target:'',breaking:0,mode:'creative',flying:false,gliding:false,elytraEquipped:false,sleeping:false,portalCharge:0,underwater:false,raining:false,thundering:false,moonPhase:0,weather:'clear',debug:false,statistics:{},achievements:[],dead:false,containers:{},boss:null,bossName:'',bossHp:0,bossMaxHp:200,crystals:0,dragonDefeated:false,hitFlash:0,armorSlots:[null,null,null,null],offhand:null,effects:[],absorption:0,attackCharge:1,useCharge:0,blocking:false};
