import * as THREE from 'three';
import { BLOCKS, ITEMS, ID, faceTile, ATLAS_COLS, TILE, type BlockDef, type Pattern } from '../game/data';
import '../game/content';
import { random } from '../input/math';

export type DrawCanvas = HTMLCanvasElement | OffscreenCanvas;
export type Context2D = CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D;
export function canvas(w: number, h = w): DrawCanvas {
  if (typeof document !== 'undefined') {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    return c;
  }
  if (typeof OffscreenCanvas !== 'undefined') {
    return new OffscreenCanvas(w, h);
  }
  const buf = new Uint8ClampedArray(w * h * 4);
  const ctx: any = {
    fillStyle: '#000000',
    strokeStyle: '#000000',
    lineWidth: 1,
    globalAlpha: 1,
    fillRect(x: number, y: number, rw: number, rh: number) {
      let r = 128, g = 128, b = 128, a = Math.round((this.globalAlpha ?? 1) * 255);
      const s = String(this.fillStyle || '');
      if (s.startsWith('#') && s.length >= 7) {
        r = parseInt(s.slice(1, 3), 16) || 0;
        g = parseInt(s.slice(3, 5), 16) || 0;
        b = parseInt(s.slice(5, 7), 16) || 0;
      } else if (s.startsWith('rgb')) {
        const m = s.match(/[\d.]+/g);
        if (m && m.length >= 3) {
          r = Number(m[0]); g = Number(m[1]); b = Number(m[2]);
          if (m.length >= 4) a = Math.round(Number(m[3]) * 255);
        }
      }
      const x0 = Math.max(0, Math.floor(x)), y0 = Math.max(0, Math.floor(y));
      const x1 = Math.min(w, Math.floor(x + rw)), y1 = Math.min(h, Math.floor(y + rh));
      for (let py = y0; py < y1; py++) {
        for (let px = x0; px < x1; px++) {
          const idx = (py * w + px) * 4;
          buf[idx] = r; buf[idx + 1] = g; buf[idx + 2] = b; buf[idx + 3] = a;
        }
      }
    },
    clearRect(x: number, y: number, rw: number, rh: number) {
      const x0 = Math.max(0, Math.floor(x)), y0 = Math.max(0, Math.floor(y));
      const x1 = Math.min(w, Math.floor(x + rw)), y1 = Math.min(h, Math.floor(y + rh));
      for (let py = y0; py < y1; py++) {
        for (let px = x0; px < x1; px++) {
          const idx = (py * w + px) * 4;
          buf[idx] = 0; buf[idx + 1] = 0; buf[idx + 2] = 0; buf[idx + 3] = 0;
        }
      }
    },
    createImageData(iw: number, ih: number) { return { data: new Uint8ClampedArray(iw * ih * 4), width: iw, height: ih }; },
    putImageData(img: { data: Uint8ClampedArray }, dx: number, dy: number) {
      if (dx === 0 && dy === 0 && img.data.length === buf.length) buf.set(img.data);
    },
    getImageData(sx = 0, sy = 0, sw = w, sh = h) {
      if (sx === 0 && sy === 0 && sw === w && sh === h) return { data: new Uint8ClampedArray(buf), width: sw, height: sh };
      const out = new Uint8ClampedArray(sw * sh * 4);
      for (let py = 0; py < sh; py++) {
        for (let px = 0; px < sw; px++) {
          const si = ((sy + py) * w + (sx + px)) * 4;
          const di = (py * sw + px) * 4;
          out[di] = buf[si]; out[di + 1] = buf[si + 1]; out[di + 2] = buf[si + 2]; out[di + 3] = buf[si + 3];
        }
      }
      return { data: out, width: sw, height: sh };
    },
    drawImage() {},
    beginPath() {},
    moveTo() {},
    lineTo() {},
    stroke() {}, strokeRect() {},
    arc() {},
    fill() {},
    createRadialGradient() { return { addColorStop() {} }; },
  };
  return { width: w, height: h, getContext: () => ctx } as unknown as DrawCanvas;
}

const rgb = (hex: string): [number, number, number] => [
  Number.parseInt(hex.slice(1, 3), 16),
  Number.parseInt(hex.slice(3, 5), 16),
  Number.parseInt(hex.slice(5, 7), 16),
];

function shade(hex: string, n: number) {
  const c = rgb(hex);
  return `rgb(${c.map(v => Math.max(0, Math.min(255, Math.round(v + n)))).join(',')})`;
}

const tileNames: string[] = [];
const tileCanvases = new Map<string, DrawCanvas>();
const tileIndex = new Map<string, number>();

function tilePattern(name: string, pattern: Pattern): Pattern {
  if (name === 'chest_front' || name === 'barrel_front') return 'chest';
  if (name === 'chest_side' || name === 'chest_top' || name === 'chest_bottom' || name === 'barrel_side' || name === 'barrel_top' || name === 'barrel_bottom') return 'planks';
  if (name.startsWith('tnt_')) return 'tnt';
  if (name === 'crafting_table_top' || name === 'crafting_table_front') return 'craft';
  if (name === 'crafting_table_side') return 'planks';
  if (name.endsWith('_top') || name.endsWith('_bottom')) {
    if (pattern === 'bark') return 'rings';
    if (pattern === 'furnace') return 'stone';
    if (name.startsWith('piston') || name === 'sticky_piston_top' || name === 'sticky_piston_bottom') return 'planks';
  }
  if (name.endsWith('_front')) {
    if (pattern === 'furnace') return 'furnace';
    if (pattern === 'craft') return 'planks';
    return pattern;
  }
  if (name.endsWith('_side')) {
    if (pattern === 'grass') return 'dirt';
    if (pattern === 'nylium') return 'stone';
    if (pattern === 'furnace' || pattern === 'craft') return 'metal';
    return pattern;
  }
  if (pattern === 'bricks' && name.includes('cobblestone')) return 'cobble';
  return pattern;
}

function noiseTile(name: string, base: string, pattern: Pattern, seed: number): DrawCanvas {
  const c = canvas(16), ctx = c.getContext('2d') as Context2D, rnd = random(seed);
  const img = ctx.createImageData(16, 16), color = rgb(base);
  const coarse = Array.from({ length: 25 }, () => rnd() * 2 - 1);

  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    const cx = Math.floor(x / 4), cy = Math.floor(y / 4), fx = (x % 4) / 4, fy = (y % 4) / 4;
    const n = (coarse[cy * 5 + cx] * (1 - fx) + coarse[cy * 5 + cx + 1] * fx) * (1 - fy) + (coarse[(cy + 1) * 5 + cx] * (1 - fx) + coarse[(cy + 1) * 5 + cx + 1] * fx) * fy;
    let v = n * 15 + (rnd() - 0.5) * 20, alpha = 255;
    if (pattern === 'sand' || pattern === 'snow') v *= 0.52;
    if (pattern === 'bark') v += (rnd() < 0.25 ? -24 : 0) + (x % 4 === 0 ? -17 : x % 4 === 1 ? 9 : 0);
    if (pattern === 'planks') v += (y % 4 === 0 ? -32 : y % 4 === 1 ? 12 : 0) + (x === (Math.floor(y / 4) * 7 + 3) % 16 ? -18 : 0);
    if (pattern === 'wool') v = ((x + y) % 3 === 0 ? 8 : -3) + n * 8;
    if (pattern === 'leaves') {
      const tintable = name === 'oak_leaves' || name === 'jungle_leaves' || name === 'acacia_leaves' || name === 'dark_oak_leaves' || name === 'mangrove_leaves';
      if (tintable) { color[0] = 152; color[1] = 152; color[2] = 152; }
      v = n * 18 + (rnd() - 0.5) * 18 + ((x + y * 2) % 4 === 0 ? -12 : 6);
      if ((x % 3 === 1 && y % 3 === 1 && rnd() < 0.45) || rnd() < 0.035) alpha = 0;
    }
    if (pattern === 'gravel') v = n * 38 + (rnd() - 0.5) * 40;
    if (pattern === 'obsidian') v = n * 18 + (rnd() < 0.16 ? 18 : 0);
    if (pattern === 'water' || pattern === 'lava') v = Math.sin(x * 0.9 + Math.sin(y * 0.8) * 2) * 14 + n * 8;
    if (pattern === 'purpur') v = n * 9 + (rnd() - 0.5) * 12;
    if (pattern === 'cactus') v = n * 10 + (rnd() - 0.5) * 12;
    const i = (y * 16 + x) * 4;
    img.data[i] = Math.max(0, Math.min(255, color[0] + v));
    img.data[i + 1] = Math.max(0, Math.min(255, color[1] + v));
    img.data[i + 2] = Math.max(0, Math.min(255, color[2] + v));
    img.data[i + 3] = alpha;
  }
  ctx.putImageData(img, 0, 0);
  const rect = (x: number, y: number, w: number, h: number, col: string) => { ctx.fillStyle = col; ctx.fillRect(x, y, w, h); };

  // Directional cube faces are authored separately; a cube must read well from every side.

  if (name === 'bookshelf_side') {
    rect(0, 0, 16, 16, '#8a6a3d');
    rect(0, 0, 16, 1, '#a8834f'); rect(0, 15, 16, 1, '#5f4526');
    const bookColors = ['#b6463b', '#3e6fa8', '#4f8c4a', '#c9a23b', '#7b4e9c', '#c86a3a', '#8a8a7a'];
    for (const rowY of [1, 8]) {
      rect(0, rowY, 16, 7, '#2e2115');
      let bx = 0;
      while (bx < 16) {
        const w = 2 + Math.floor(rnd() * 2);
        const col = bookColors[Math.floor(rnd() * bookColors.length)];
        rect(bx, rowY + (rnd() < 0.3 ? 1 : 0), w, 7, col);
        rect(bx, rowY + 1, w, 1, shade(col, 38));
        rect(bx, rowY + 5, w, 1, shade(col, -30));
        bx += w + (rnd() < 0.2 ? 1 : 0);
      }
    }
    return c;
  }
  if (name === 'pumpkin_front') {
    for (let x = 0; x < 16; x += 4) { rect(x, 0, 1, 16, '#8f5a1a'); rect(x + 1, 0, 3, 16, '#d68f2c'); rect(x + 2, 0, 1, 16, '#b06f1e'); }
    rect(3, 4, 3, 3, '#2d1c0c'); rect(10, 4, 3, 3, '#2d1c0c');
    rect(7, 7, 2, 2, '#2d1c0c');
    rect(3, 11, 10, 2, '#2d1c0c'); rect(5, 10, 2, 1, '#2d1c0c'); rect(9, 10, 2, 1, '#2d1c0c');
    return c;
  }
  if (name === 'enchanting_table_top' || name === 'enchanting_table_side') {
    rect(0, 0, 16, 16, '#241d31');
    rect(1, 1, 14, 14, '#372e4b');
    if (name === 'enchanting_table_top') {
      rect(0, 0, 16, 3, '#8b2635'); rect(1, 1, 14, 1, '#c94356');
      rect(4, 4, 8, 8, '#a43040'); rect(6, 6, 4, 4, '#4fd8eb');
    } else {
      rect(0, 0, 16, 4, '#8b2635'); rect(0, 12, 16, 4, '#241d31');
      rect(2, 2, 2, 2, '#5ce4f2'); rect(12, 2, 2, 2, '#5ce4f2');
    }
    return c;
  }
  if (name === 'farmland_top') {
    for (let y = 0; y < 16; y += 3) { rect(0, y, 16, 2, '#5e3f25'); rect(0, y + 2, 16, 1, '#3f2812'); }
    for (let i = 0; i < 10; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 1, 1, '#7a5330');
    return c;
  }
  if (name === 'bed_foot_top' || name === 'bed_head_top' || name === 'bed_head_side' || name === 'bed_side') {
    const red = '#b83c34', redD = '#93291f', white = '#ece8de', wood = '#a07a48', woodD = '#7a5a34';
    ctx.clearRect(0, 0, 16, 16);
    if (name === 'bed_foot_top') { rect(0, 0, 16, 16, red); rect(0, 0, 16, 1, redD); rect(0, 15, 16, 1, redD); rect(0, 0, 1, 16, redD); rect(15, 0, 1, 16, redD); for (let i = 0; i < 20; i++) rect(Math.floor(rnd() * 14) + 1, Math.floor(rnd() * 14) + 1, 1, 1, '#c54a40'); }
    else if (name === 'bed_head_top') { rect(0, 0, 16, 16, red); rect(2, 2, 12, 12, white); rect(2, 13, 12, 1, '#c9c4b4'); rect(13, 2, 1, 12, '#c9c4b4'); rect(3, 3, 10, 1, '#ffffff'); }
    else {
      rect(0, 7, 16, 3, name === 'bed_head_side' ? white : red); rect(0, 9, 16, 1, name === 'bed_head_side' ? '#c9c4b4' : redD);
      rect(0, 10, 16, 3, wood); rect(0, 12, 16, 1, woodD);
      rect(0, 13, 3, 3, woodD); rect(13, 13, 3, 3, woodD);
    }
    return c;
  }
  if (name === 'hay_block_top' || name === 'hay_block_side') {
    for (let x = 0; x < 16; x += 2) rect(x, 0, 1, 16, x % 4 === 0 ? '#a8842f' : '#d6b44d');
    if (name === 'hay_block_side') { rect(0, 4, 16, 2, '#9e382e'); rect(0, 10, 16, 2, '#9e382e'); }
    return c;
  }
  if (name === 'glowstone') {
    rect(0, 0, 16, 16, '#8a5a24');
    for (let i = 0; i < 16; i++) {
      const x = Math.floor(rnd() * 13), y = Math.floor(rnd() * 13), w = 2 + Math.floor(rnd() * 3), h = 2 + Math.floor(rnd() * 3);
      rect(x, y, w, h, i % 3 === 0 ? '#fff6bd' : '#f2c866');
      rect(x, y, w, 1, '#ffe9a0');
    }
    return c;
  }
  if (name === 'sea_lantern') {
    rect(0, 0, 16, 16, '#5d948a');
    rect(1, 1, 14, 14, '#8fc4ba');
    rect(2, 2, 12, 12, '#b6dcd2');
    rect(4, 4, 8, 8, '#eef9f4');
    rect(6, 6, 4, 4, '#ffffff');
    return c;
  }
  if (name === 'magma_block') {
    rect(0, 0, 16, 16, '#4a1e0e');
    for (let i = 0; i < 14; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 2, 1, i % 2 ? '#ff7a1a' : '#ffb03a');
    return c;
  }
  if (name === 'slime_block') {
    ctx.clearRect(0, 0, 16, 16);
    rect(0, 0, 16, 16, 'rgba(143,189,103,0.75)');
    rect(2, 2, 12, 12, 'rgba(170,214,128,0.85)');
    rect(4, 4, 8, 8, 'rgba(200,235,150,0.9)');
    return c;
  }
  if (name === 'honey_block') {
    ctx.clearRect(0, 0, 16, 16);
    rect(0, 0, 16, 16, 'rgba(220,168,66,0.8)');
    rect(2, 2, 12, 12, 'rgba(238,192,84,0.9)');
    for (let i = 0; i < 5; i++) rect(2 + i * 3, 2 + (i % 2) * 3, 2, 2, '#f6d98e');
    return c;
  }
  if (name === 'portal') {
    ctx.clearRect(0, 0, 16, 16);
    rect(0, 0, 16, 16, 'rgba(128, 52, 204, 0.72)');
    for (let i = 0; i < 18; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 3, i % 2 ? 'rgba(204,132,255,0.7)' : 'rgba(84,22,158,0.7)');
    return c;
  }
  if (name === 'end_portal') {
    rect(0, 0, 16, 16, '#0b1018');
    for (let i = 0; i < 20; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 1, 1, i % 3 ? '#4bc2b8' : '#b78cff');
    return c;
  }
  if (name === 'redstone_lamp') {
    rect(0, 0, 16, 16, '#6e4e2a');
    rect(2, 2, 12, 12, '#f5c058');
    rect(4, 4, 8, 8, '#ffea9f');
    rect(6, 6, 4, 4, '#ffffff');
    return c;
  }
  if (name === 'unlit_redstone_lamp') {
    rect(0, 0, 16, 16, '#463423');
    rect(2, 2, 12, 12, '#73583a');
    rect(4, 4, 8, 8, '#8a6c49');
    return c;
  }
  if (name.includes('amethyst')) {
    for (let i = 0; i < 14; i++) rect(Math.floor(rnd() * 13), Math.floor(rnd() * 13), 3, 2, i % 2 ? '#c99ef2' : '#6c4294');
    rect(3, 3, 3, 3, '#f0d8ff');
    rect(9, 9, 3, 3, '#8a5cc0');
    return c;
  }
  if (name === 'ice' || name === 'packed_ice') {
    ctx.clearRect(0, 0, 16, 16);
    rect(0, 0, 16, 16, name === 'ice' ? 'rgba(164,212,228,0.55)' : 'rgba(142,189,212,0.9)');
    for (let i = 0; i < 6; i++) { const x = Math.floor(rnd() * 14), y = Math.floor(rnd() * 14); rect(x, y, 2 + Math.floor(rnd() * 3), 1, 'rgba(255,255,255,0.75)'); }
    return c;
  }
  if (name === 'cactus') {
    rect(0, 0, 16, 16, '#3f6b26');
    for (let x = 2; x < 14; x += 4) { rect(x, 0, 2, 16, '#5e873d'); rect(x + 1, 0, 1, 16, '#79a851'); }
    for (let i = 0; i < 8; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 1, 1, '#d8e6b0');
    return c;
  }
  if (name === 'netherrack') {
    for (let i = 0; i < 12; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 2, 1, '#5c2620');
    for (let i = 0; i < 8; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 1, 2, '#a05248');
    return c;
  }
  if (name === 'end_stone') {
    for (let i = 0; i < 16; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 2, 1, i % 2 ? '#b8b06e' : '#efe9b8');
    return c;
  }
  if (name === 'bedrock') {
    for (let i = 0; i < 22; i++) { const x = Math.floor(rnd() * 14), y = Math.floor(rnd() * 14); rect(x, y, 2 + Math.floor(rnd() * 3), 2, i % 2 ? '#2e2e2c' : '#6a6a64'); }
    return c;
  }
  if (name === 'deepslate' || name.startsWith('deepslate_')) {
    for (let y = 0; y < 16; y += 3) rect(0, y + 1, 16, 1, '#3a3d3f');
    for (let i = 0; i < 8; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 1, 3, '#45484a');
    return c;
  }

  if (name === 'redstone_block') {
    rect(0, 0, 16, 16, '#a51d17');
    for (let i = 0; i < 48; i++) rect(1 + Math.floor(rnd() * 14), 1 + Math.floor(rnd() * 14), 1, 1, i % 3 ? '#c3281f' : '#7f130f');
    for (let k = 2; k < 16; k += 4) { rect(k, 1, 1, 14, '#8d1712'); rect(1, k, 14, 1, '#8d1712'); }
    rect(0, 0, 16, 1, '#6f0f0b'); rect(0, 15, 16, 1, '#d94a3a'); rect(0, 0, 1, 16, '#6f0f0b'); rect(15, 0, 1, 16, '#d94a3a');
    return c;
  }
  if (name === 'redstone_torch' || name === 'unlit_redstone_torch') {
    ctx.clearRect(0, 0, 16, 16);
    const lit = name === 'redstone_torch';
    rect(7, 6, 2, 10, '#6e4e28'); rect(7, 6, 1, 10, '#9a7440');
    if (lit) { rect(7, 2, 2, 4, '#ff3b2f'); rect(6, 3, 4, 3, '#e02a20'); rect(7, 3, 1, 1, '#ffd0b0'); rect(8, 4, 1, 1, '#ff7a5a'); }
    else { rect(7, 3, 2, 3, '#5a2620'); rect(8, 4, 1, 1, '#7a3a30'); }
    return c;
  }
  // ---------- Model-accurate tiles (drawn at the exact pixels the block models sample) ----------
  if (name === 'crafting_table_top' || name === 'crafting_table_front' || name === 'crafting_table_side') {
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) rect(x, y, 1, 1, shade('#b8945f', Math.floor(rnd() * 12) - 6));
    if (name === 'crafting_table_top') {
      // Work surface: dark frame, bevel highlight and the 3x3 crafting grid.
      rect(0, 0, 16, 1, '#6b4a2b'); rect(0, 0, 1, 16, '#6b4a2b'); rect(0, 15, 16, 1, '#54381f'); rect(15, 0, 1, 16, '#54381f');
      rect(1, 1, 14, 1, '#d2b07a'); rect(1, 1, 1, 14, '#d2b07a');
      for (const k of [5, 10]) { rect(k, 2, 1, 12, '#7a5a34'); rect(2, k, 12, 1, '#7a5a34'); }
      for (const k of [6, 11]) { rect(k, 2, 1, 12, '#c9a56e'); rect(2, k, 12, 1, '#c9a56e'); }
      for (const k of [5, 10]) for (const q of [5, 10]) rect(k, q, 1, 1, '#5e4226');
      rect(0, 0, 1, 1, '#3f2a17'); rect(15, 0, 1, 1, '#3f2a17'); rect(0, 15, 1, 1, '#3f2a17'); rect(15, 15, 1, 1, '#3f2a17');
    } else {
      // Sides: table-top slab edge, corner legs, plank seams and the tools hanging on the board.
      rect(0, 7, 16, 1, '#93713f'); rect(0, 11, 16, 1, '#93713f'); rect(0, 15, 16, 1, '#7d5c33');
      rect(0, 0, 16, 1, '#d2b07a'); rect(0, 1, 16, 1, '#6b4a2b'); rect(0, 2, 16, 1, '#54381f');
      rect(0, 3, 2, 13, '#7a5a34'); rect(14, 3, 2, 13, '#7a5a34'); rect(1, 3, 1, 13, '#93713f'); rect(14, 3, 1, 13, '#93713f');
      if (name === 'crafting_table_front') {
        rect(3, 5, 5, 2, '#8d9494'); rect(3, 5, 5, 1, '#c5cccc'); rect(5, 7, 1, 6, '#5a3d20'); rect(6, 7, 1, 6, '#74502b');
        rect(9, 6, 4, 4, '#aab2b2'); rect(9, 6, 4, 1, '#d5dbdb'); rect(9, 10, 1, 1, '#8d9494'); rect(11, 10, 1, 1, '#8d9494'); rect(10, 4, 3, 2, '#5a3d20');
      } else {
        rect(4, 5, 1, 8, '#5a3d20'); rect(5, 5, 3, 3, '#8d9494'); rect(5, 5, 3, 1, '#c5cccc'); rect(8, 6, 1, 1, '#c5cccc');
        rect(10, 5, 1, 4, '#aab2b2'); rect(12, 5, 1, 4, '#aab2b2'); rect(11, 8, 1, 2, '#8d9494'); rect(10, 10, 1, 2, '#5a3d20'); rect(12, 10, 1, 2, '#5a3d20');
      }
    }
    return c;
  }
  if (name === 'cactus_side' || name === 'cactus_top' || name === 'cactus_bottom') {
    ctx.clearRect(0, 0, 16, 16);
    const dk = '#2f6a26', md = '#4a8a34', lt = '#63a646', sp = '#e3eec0';
    if (name === 'cactus_side') {
      // Ribbed body on columns 1..14; columns 0 and 15 hold only the spines that stick out past the inset faces.
      const ribs = [dk, md, lt, md, dk, md, lt, lt, md, dk, md, lt, md, dk];
      for (let x = 1; x < 15; x++) for (let y = 0; y < 16; y++) rect(x, y, 1, 1, shade(ribs[x - 1], ((x * 7 + y * 13) % 5) * 2 - 4));
      for (let y = 1; y < 16; y += 5) { rect(0, y, 1, 1, sp); rect(5, y + 2, 1, 1, sp); rect(10, y, 1, 1, sp); rect(15, y + 2, 1, 1, sp); }
    } else {
      const k = name === 'cactus_top' ? [dk, md, lt, '#7fbe5a'] : ['#6f8a48', '#93a862', '#b3c27c', '#c9d394'];
      rect(1, 1, 14, 14, k[0]); rect(2, 2, 12, 12, k[1]); rect(4, 4, 8, 8, k[0]); rect(5, 5, 6, 6, k[2]); rect(7, 7, 2, 2, k[3]);
      for (const [x, y] of [[0, 3], [0, 11], [15, 5], [15, 12], [4, 0], [11, 0], [6, 15], [13, 15]]) rect(x, y, 1, 1, sp);
    }
    return c;
  }
  if (name.endsWith('_door_top') || name.endsWith('_door_bottom')) {
    // Two-block door leaf: the upper tile carries the window (real cut-outs), the lower tile the panels. Hinges on the left, handle on the right.
    const topHalf = name.endsWith('_top'), wood = name.replace(/_door_(top|bottom)$/, ''), iron = wood === 'iron';
    const dark = shade(base, -40), mid = shade(base, -18), light = shade(base, 18), hinge = iron ? '#7d868a' : '#3b3f42', knob = iron ? '#596165' : '#2a2622';
    rect(0, 0, 16, 16, base);
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) if (rnd() < 0.3) rect(x, y, 1, 1, shade(base, Math.floor(rnd() * 14) - 9));
    if (!iron) { rect(5, 0, 1, 16, mid); rect(10, 0, 1, 16, mid); }
    rect(0, 0, 1, 16, dark); rect(15, 0, 1, 16, dark); rect(1, 0, 1, 16, light);
    if (topHalf) {
      rect(0, 0, 16, 1, dark);
      rect(0, 3, 2, 2, hinge);
      if (iron || wood === 'oak' || wood === 'jungle' || wood === 'acacia' || wood === 'cherry') {
        rect(2, 2, 12, 9, dark);
        for (const px of [3, 9]) for (const py of [3, 7]) ctx.clearRect(px, py, 4, 3);
        if (iron) { rect(3, 12, 1, 1, light); rect(12, 12, 1, 1, light); }
      } else if (wood === 'spruce' || wood === 'dark_oak') {
        rect(3, 2, 10, 5, dark); ctx.clearRect(4, 3, 3, 3); ctx.clearRect(9, 3, 3, 3);
        rect(3, 9, 10, 5, mid); rect(4, 10, 8, 3, light);
      } else {
        rect(3, 2, 10, 5, mid); rect(4, 3, 8, 3, light);
        rect(3, 9, 10, 5, mid); rect(4, 10, 8, 3, light);
      }
    } else {
      rect(0, 15, 16, 1, dark);
      rect(0, 10, 2, 2, hinge);
      rect(12, 1, 2, 2, knob);
      rect(3, 4, 10, 4, mid); rect(4, 5, 8, 2, light);
      rect(3, 10, 10, 4, mid); rect(4, 11, 8, 2, light);
    }
    return c;
  }
  if (name.endsWith('_trapdoor')) {
    const dark = shade(base, -40), light = shade(base, 18);
    rect(0, 0, 16, 16, base);
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) if (rnd() < 0.3) rect(x, y, 1, 1, shade(base, Math.floor(rnd() * 14) - 9));
    rect(0, 0, 16, 1, dark); rect(0, 15, 16, 1, dark); rect(0, 0, 1, 16, dark); rect(15, 0, 1, 16, dark);
    rect(1, 1, 14, 1, light); rect(1, 1, 1, 14, light);
    for (const px of [3, 9]) for (const py of [3, 9]) { rect(px - 1, py - 1, 6, 6, dark); ctx.clearRect(px, py, 4, 4); }
    rect(1, 12, 2, 2, '#3b3f42'); rect(13, 12, 2, 2, '#3b3f42');
    return c;
  }
  if (name === 'ladder') {
    ctx.clearRect(0, 0, 16, 16);
    const d = shade(base, -32), l = shade(base, 14);
    for (const ry of [1, 5, 9, 13]) { rect(2, ry, 12, 2, base); rect(2, ry + 1, 12, 1, d); }
    rect(2, 0, 2, 16, base); rect(12, 0, 2, 16, base); rect(2, 0, 1, 16, l); rect(13, 0, 1, 16, d);
    return c;
  }
  if (name === 'rail' || name === 'powered_rail') {
    ctx.clearRect(0, 0, 16, 16);
    const metal = name === 'rail' ? '#8f9494' : '#d9b441', hi = name === 'rail' ? '#c6cccc' : '#f3d877';
    for (const ry of [1, 5, 9, 13]) { rect(1, ry, 14, 2, '#7a5a34'); rect(1, ry + 1, 14, 1, '#5e4526'); }
    if (name === 'powered_rail') rect(7, 0, 2, 16, '#b3261a');
    rect(3, 0, 2, 16, metal); rect(11, 0, 2, 16, metal); rect(3, 0, 1, 16, hi); rect(11, 0, 1, 16, hi);
    return c;
  }
  if (name === 'redstone_wire') {
    ctx.clearRect(0, 0, 16, 16);
    rect(7, 0, 2, 16, '#b3160e'); rect(0, 7, 16, 2, '#b3160e'); rect(6, 6, 4, 4, '#d42a1c');
    for (let i = 0; i < 10; i++) { const k = Math.floor(rnd() * 16); rect(i % 2 ? 7 : k, i % 2 ? k : 8, 1, 1, '#7d0f0a'); }
    return c;
  }
  if (name === 'repeater' || name === 'comparator') {
    rect(0, 0, 16, 16, '#b9b6aa');
    for (let i = 0; i < 40; i++) rect(Math.floor(rnd() * 16), Math.floor(rnd() * 16), 1, 1, i % 2 ? '#a9a69a' : '#c7c4b8');
    rect(0, 0, 16, 1, '#8f8c82'); rect(0, 15, 16, 1, '#8f8c82'); rect(0, 0, 1, 16, '#8f8c82'); rect(15, 0, 1, 16, '#8f8c82');
    rect(7, 3, 2, 10, '#8a1a12');
    rect(6, 2, 4, 3, '#d43a22');
    if (name === 'repeater') rect(6, 10, 4, 3, '#d43a22'); else { rect(3, 10, 3, 3, '#d43a22'); rect(10, 10, 3, 3, '#d43a22'); }
    return c;
  }
  if (name === 'lever') {
    ctx.clearRect(0, 0, 16, 16);
    rect(4, 13, 8, 3, '#7f8580'); rect(4, 13, 8, 1, '#a3a9a3'); rect(5, 14, 2, 1, '#5f6560'); rect(10, 15, 1, 1, '#5f6560');
    for (let y = 6; y < 16; y++) { rect(7, y, 1, 1, '#a98250'); rect(8, y, 1, 1, '#7a5a34'); }
    rect(7, 6, 2, 2, '#dcdcd2'); rect(8, 7, 1, 1, '#b4b4aa');
    return c;
  }
  if (name === 'spawner') {
    ctx.clearRect(0, 0, 16, 16);
    for (let k = 0; k < 16; k += 5) { rect(k, 0, 1, 16, '#1b2433'); rect(0, k, 16, 1, '#1b2433'); }
    for (let k = 0; k < 16; k += 5) for (let q = 0; q < 16; q += 5) rect(k, q, 1, 1, '#3d4d69');
    rect(1, 0, 14, 1, '#27334a'); rect(0, 1, 1, 14, '#27334a');
    return c;
  }
  if (name === 'nether_wart') {
    ctx.clearRect(0, 0, 16, 16);
    for (const [sx, top] of [[3, 8], [7, 5], [11, 9]]) {
      rect(sx, top + 2, 2, 14 - top, '#7a1420'); rect(sx - 1, top, 4, 3, '#b3222f'); rect(sx, top, 2, 1, '#d8414b'); rect(sx - 1, top + 3, 1, 2, '#941a26');
    }
    return c;
  }
  if (name === 'mushroom_stem') {
    for (let x = 1; x < 16; x += 3) rect(x, 0, 1, 16, shade(base, -14));
    for (let i = 0; i < 12; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 14), 1, 2, shade(base, 12));
    return c;
  }
  if (name === 'torch' || name === 'soul_torch') {
    ctx.clearRect(0, 0, 16, 16);
    const soul = name === 'soul_torch';
    rect(7, 6, 1, 1, soul ? '#e0ffff' : '#fffbd6'); rect(8, 6, 1, 1, soul ? '#9cf4ff' : '#ffe98a');
    rect(7, 7, 1, 1, soul ? '#5ce1f2' : '#ffd84a'); rect(8, 7, 1, 1, soul ? '#34bdd1' : '#ffb42e');
    rect(7, 8, 1, 1, soul ? '#1f8fa3' : '#f08a1c'); rect(8, 8, 1, 1, soul ? '#166a7a' : '#d96a12');
    for (let y = 9; y < 16; y++) { rect(7, y, 1, 1, y % 3 === 0 ? '#b08a50' : '#a67c46'); rect(8, y, 1, 1, y % 4 === 1 ? '#6e4e28' : '#7d5a30'); }
    return c;
  }
  if (name === 'lantern' || name === 'soul_lantern' || name === 'lantern_top') {
    ctx.clearRect(0, 0, 16, 16);
    const soul = name === 'soul_lantern';
    const iron = '#3a4042', ironL = '#5d6669', glow = soul ? '#3cd6eb' : '#f8b63e', glowL = soul ? '#c4fbff' : '#fff0a8';
    if (name === 'lantern' || name === 'soul_lantern') {
      rect(7, 5, 2, 2, ironL);
      rect(6, 7, 4, 2, iron); rect(6, 7, 4, 1, ironL);
      rect(5, 9, 6, 7, iron); rect(6, 10, 4, 5, glow); rect(7, 11, 2, 3, glowL);
      rect(5, 9, 6, 1, ironL); rect(5, 15, 6, 1, '#2a2f31');
    } else {
      rect(5, 5, 6, 6, iron); rect(6, 6, 4, 4, ironL); rect(7, 7, 2, 2, '#2a2f31');
    }
    return c;
  }

  if (name === 'chest_top' || name === 'chest_bottom') {
    rect(0, 0, 16, 16, '#966b32');
    rect(0, 0, 16, 2, '#bd8b4c'); rect(0, 14, 16, 2, '#513514');
    rect(1, 2, 14, 12, '#aa7b3d'); rect(3, 3, 10, 10, '#986a32');
    rect(4, 4, 8, 8, '#ae7d40'); rect(7, 7, 2, 2, '#7b582e');
    return c;
  }
  if (name === 'chest_side') {
    rect(0, 0, 16, 16, '#9e733b');
    rect(0, 0, 16, 2, '#bd8b4c'); rect(0, 14, 16, 2, '#523713');
    rect(0, 6, 16, 1, '#684719'); rect(0, 7, 16, 1, '#c4954e');
    for (let y = 3; y < 14; y += 4) rect(2, y, 12, 1, '#b18448');
    return c;
  }
  if (name === 'barrel_top' || name === 'barrel_bottom') {
    rect(0, 0, 16, 16, '#8a6336');
    rect(1, 1, 14, 14, '#a47a45'); rect(2, 2, 12, 12, '#8b6539');
    for (let x = 3; x < 15; x += 2) rect(x, 2, 1, 12, x % 3 ? '#b18a54' : '#73502b');
    rect(0, 0, 16, 2, '#5d421f'); rect(0, 14, 16, 2, '#5d421f');
    return c;
  }
  if (name === 'barrel_side') {
    rect(0, 0, 16, 16, '#976c3a');
    for (let y = 0; y < 16; y += 4) {
      rect(0, y, 16, 1, '#66451f'); rect(0, y + 1, 16, 2, '#a77b45');
    }
    rect(2, 0, 1, 16, '#c09255'); rect(13, 0, 1, 16, '#573a1b');
    return c;
  }
  if (/^(furnace|smoker|blast_furnace)_(top|bottom)$/.test(name)) {
    rect(0, 0, 16, 16, '#737571');
    rect(1, 1, 14, 14, '#858782'); rect(2, 2, 12, 12, '#686a66');
    rect(3, 3, 10, 10, '#797b76'); rect(4, 4, 8, 8, '#70726e');
    rect(0, 0, 16, 1, '#9b9d96'); rect(0, 15, 16, 1, '#454743');
    return c;
  }
  if (/^(furnace|smoker|blast_furnace)_front$/.test(name)) {
    const blast = name.startsWith('blast_'), smoker = name.startsWith('smoker');
    rect(0, 0, 16, 16, blast ? '#555b59' : smoker ? '#786043' : '#737571');
    rect(1, 1, 14, 14, blast ? '#7c817d' : smoker ? '#927347' : '#898b85');
    rect(3, 3, 10, 3, blast ? '#495250' : '#3f413e');
    rect(3, 8, 10, 6, '#252725'); rect(4, 9, 8, 4, '#131513');
    rect(4, 13, 8, 1, '#a6a69c');
    if (smoker) { rect(6, 9, 4, 3, '#794524'); rect(7, 10, 2, 2, '#d67a24'); }
    if (blast) { rect(2, 2, 12, 2, '#a4aaa4'); rect(3, 4, 10, 2, '#363b38'); }
    return c;
  }
  if (name === 'dispenser_front' || name === 'dropper_front') {
    rect(0, 0, 16, 16, '#747773');
    rect(1, 1, 14, 14, '#898c85'); rect(2, 2, 12, 12, '#686b67');
    rect(3, 3, 10, 10, '#777a75');
    rect(5, 5, 6, 6, '#3b3e3a'); rect(6, 4, 4, 8, '#50534f');
    rect(7, 6, 2, 4, '#252824'); rect(6, 7, 4, 2, '#252824'); rect(7, 7, 2, 2, '#171a17');
    return c;
  }
  if (name === 'observer_front') {
    rect(0, 0, 16, 16, '#848781'); rect(1, 1, 14, 14, '#b2b4ac');
    rect(3, 3, 10, 10, '#868984'); rect(5, 5, 6, 6, '#484b48');
    rect(6, 6, 4, 4, '#171918'); rect(7, 7, 2, 2, '#dc4033');
    return c;
  }
  if (name.endsWith('_door_front') || name.endsWith('_door_back')) {
    const iron = name.startsWith('iron_');
    const woodName = name.replace(/^open_/, '').replace(/_door_(front|back)$/, '');
    const woodBlock = BLOCKS[ID[woodName + '_planks']];
    const wood = iron ? '#9ea6a6' : woodBlock?.color ?? base;
    rect(0, 0, 16, 16, shade(wood, -15));
    rect(1, 0, 14, 16, wood); rect(2, 1, 12, 14, shade(wood, 7));
    rect(3, 1, 1, 14, shade(wood, -22)); rect(12, 1, 1, 14, shade(wood, -22));
    rect(4, 1, 1, 14, shade(wood, 18)); rect(11, 1, 1, 14, shade(wood, 18));
    if (iron) {
      for (let y = 2; y < 15; y += 3) rect(5, y, 6, 1, '#717a7a');
      rect(5, 2, 6, 1, '#dce4e1'); rect(6, 7, 4, 2, '#555d5c');
    } else {
      // Planked inset panels and small metal knob
      rect(5, 2, 6, 4, shade(wood, -5)); rect(5, 8, 6, 5, shade(wood, -5));
      rect(6, 3, 4, 1, shade(wood, 16)); rect(6, 9, 4, 1, shade(wood, 16));
      rect(12, 7, 1, 2, '#d7c67f');
    }
    return c;
  }
  if (name === 'quartz_block_top') {
    rect(0, 0, 16, 16, '#ece8de');
    rect(1, 1, 14, 14, '#e4dfd4');
    rect(2, 2, 12, 12, '#efebe2');
    rect(3, 3, 10, 10, '#e9e4da');
    rect(4, 4, 8, 8, '#f3f0e8');
    for (let i = 0; i < 8; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 1, i % 2 ? '#d6d1c6' : '#faf8f2');
    return c;
  }
  if (name === 'quartz_block_side') {
    rect(0, 0, 16, 16, '#e8e4db');
    for (let x = 0; x < 16; x += 4) {
      rect(x, 0, 1, 16, '#d0ccc2');
      rect(x + 1, 0, 1, 16, '#f6f3ed');
      rect(x + 3, 0, 1, 16, '#ded9cf');
    }
    rect(0, 2, 16, 1, '#f7f4ed'); rect(0, 13, 16, 1, '#d2cec4');
    return c;
  }
  if (name === 'bone_block_top') {
    rect(0, 0, 16, 16, '#ded8c6');
    rect(1, 1, 14, 14, '#b9b09c'); rect(2, 2, 12, 12, '#eee9d9');
    rect(4, 4, 8, 8, '#c5bda9'); rect(5, 5, 6, 6, '#f6f2e5');
    rect(7, 2, 2, 12, '#d6ceba'); rect(2, 7, 12, 2, '#d6ceba');
    return c;
  }
  if (name === 'bone_block_side') {
    rect(0, 0, 16, 16, '#ded8c6');
    rect(0, 1, 16, 2, '#c2baa7'); rect(0, 3, 16, 1, '#f1eddf');
    rect(0, 7, 16, 2, '#c5bda9'); rect(0, 9, 16, 1, '#f3efe2');
    rect(0, 13, 16, 2, '#c2baa7');
    return c;
  }
  if (name === 'hay_block_top') {
    rect(0, 0, 16, 16, '#c5a544');
    for (let x = 1; x < 16; x += 3) rect(x, 0, 1, 16, '#9f832c');
    rect(6, 6, 4, 4, '#d8bd62'); rect(7, 7, 2, 2, '#86702b');
    return c;
  }
  if (name === 'hay_block_side') {
    rect(0, 0, 16, 16, '#c5a544');
    for (let y = 1; y < 16; y += 3) {
      rect(0, y, 16, 1, y % 2 ? '#a98931' : '#dfc45a');
      for (let x = (y * 3) % 5; x < 16; x += 6) rect(x, y + 1, 3, 1, '#e0c65d');
    }
    rect(0, 5, 16, 2, '#9c3228'); rect(0, 11, 16, 2, '#9c3228');
    return c;
  }
  if (name === 'pumpkin_top' || name === 'pumpkin_block_top' || name === 'pumpkin_block_bottom') {
    rect(0, 0, 16, 16, '#b9781f');
    for (let x = 1; x < 16; x += 3) rect(x, 0, 1, 16, '#d3942c');
    rect(5, 5, 6, 6, '#70451d'); rect(6, 4, 4, 8, '#7c5225'); rect(7, 6, 2, 4, '#97702d');
    return c;
  }
  if (name === 'pumpkin' || name === 'pumpkin_block' || name === 'pumpkin_block_side' || name === 'pumpkin_block_front') {
    rect(0, 0, 16, 16, '#b9781f');
    for (let x = 0; x < 16; x++) {
      const shadeX = x % 4 === 0 ? '#8f5917' : x % 4 === 1 ? '#c98523' : x % 4 === 2 ? '#dd982c' : '#bd7c20';
      rect(x, 0, 1, 16, shadeX);
    }
    rect(2, 3, 1, 10, '#e4a536'); rect(13, 3, 1, 10, '#8b5718');
    return c;
  }
  if (name === 'melon_top' || name === 'melon_block_top' || name === 'melon_block_bottom') {
    rect(0, 0, 16, 16, '#558332');
    for (let i = 0; i < 28; i++) {
      const x = Math.floor(rnd() * 15), y = Math.floor(rnd() * 15);
      rect(x, y, 1, 1, i % 2 ? '#9bbd4c' : '#385d28');
    }
    return c;
  }
  if (name === 'melon' || name === 'melon_block' || name === 'melon_block_side' || name === 'melon_block_front') {
    rect(0, 0, 16, 16, '#698f34');
    for (let x = 1; x < 16; x += 4) { rect(x, 0, 1, 16, '#3c6428'); rect(x + 1, 0, 1, 16, '#89a943'); }
    for (let i = 0; i < 12; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 1, 1, i % 2 ? '#aac45a' : '#557a2e');
    return c;
  }
  if (name === 'red_mushroom_block_top' || name === 'brown_mushroom_block_top') {
    const red = name.startsWith('red_');
    rect(0, 0, 16, 16, red ? '#c24a38' : '#956f49');
    for (let i = 0; i < 8; i++) {
      const x = 1 + Math.floor(rnd() * 13), y = 1 + Math.floor(rnd() * 13);
      rect(x, y, 2, 2, red ? '#e5d8bc' : '#d0b47c');
    }
    return c;
  }
  if (name === 'red_mushroom_block_side' || name === 'brown_mushroom_block_side') {
    const red = name.startsWith('red_');
    rect(0, 0, 16, 16, red ? '#c24a38' : '#956f49');
    for (let i = 0; i < 9; i++) {
      const x = Math.floor(rnd() * 13), y = Math.floor(rnd() * 13);
      rect(x, y, 3, 3, red ? '#e6d8bb' : '#c7a978');
    }
    rect(0, 0, 16, 1, red ? '#a53328' : '#765637');
    return c;
  }
  if (name === 'red_mushroom_block_stem' || name === 'brown_mushroom_block_stem') {
    rect(0, 0, 16, 16, '#ddd7c5');
    for (let i = 0; i < 10; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 2, i % 2 ? '#c8bfa9' : '#f1eadb');
    return c;
  }
  if (name === 'redstone_lamp_top' || name === 'redstone_lamp_side' || name.startsWith('copper_bulb_lit')) {
    rect(0, 0, 16, 16, '#b7833d');
    for (let i = 0; i < 14; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 2, i % 2 ? '#e5bc67' : '#996632');
    rect(2, 2, 12, 12, '#cd9a4b'); rect(4, 4, 8, 8, '#efc66b');
    if (name.endsWith('_side')) { rect(0, 0, 16, 2, '#76532d'); rect(0, 14, 16, 2, '#76532d'); }
    return c;
  }
  if (name === 'unlit_redstone_lamp_top' || name === 'unlit_redstone_lamp_side' || (name.startsWith('copper_bulb') && !name.startsWith('copper_bulb_lit'))) {
    rect(0, 0, 16, 16, '#54422f');
    rect(2, 2, 12, 12, '#71583b'); rect(4, 4, 8, 8, '#806340');
    for (let i = 0; i < 10; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 1, 1, '#a17d4a');
    return c;
  }
  if (name === 'sea_lantern_top' || name === 'sea_lantern_side') {
    rect(0, 0, 16, 16, '#9bcab8');
    for (let y = 1; y < 16; y += 4) {
      for (let x = (y % 8 === 1 ? 0 : 2); x < 16; x += 4) {
        rect(x, y, 2, 2, '#e1f2d7'); rect(x + 1, y + 1, 1, 1, '#fffde6');
      }
    }
    rect(0, 0, 16, 1, '#d4e8d3'); rect(0, 15, 16, 1, '#578e84');
    return c;
  }
  if (name === 'prismarine_top' || name === 'prismarine_side') {
    rect(0, 0, 16, 16, '#5f9990');
    const scales = [[2, 1], [8, 1], [13, 2], [4, 5], [10, 5], [1, 10], [7, 9], [13, 11], [4, 14]];
    for (const [x, y] of scales) {
      rect(x, y, 3, 2, '#367b76'); rect(x + 1, y, 1, 1, '#91bd9f');
      rect(x, y + 1, 3, 1, '#4b8b84');
    }
    return c;
  }
  if (name === 'target_top' || name === 'target_side') {
    rect(0, 0, 16, 16, '#ece6d8');
    rect(2, 2, 12, 12, '#bd3c32'); rect(4, 4, 8, 8, '#ece6d8');
    rect(6, 6, 4, 4, '#bd3c32'); rect(7, 7, 2, 2, '#ece6d8');
    if (name === 'target_side') rect(0, 0, 16, 1, '#b4ad9f');
    return c;
  }
  if (name === 'piston_top' || name === 'sticky_piston_top') {
    rect(0, 0, 16, 16, name.startsWith('sticky') ? '#6e9152' : '#8c7652');
    rect(1, 1, 14, 14, name.startsWith('sticky') ? '#88a86a' : '#b1976a');
    rect(3, 3, 10, 10, '#6c6c64'); rect(4, 4, 8, 8, '#9a9a8e');
    rect(5, 5, 6, 6, '#b9b9aa');
    if (name.startsWith('sticky')) rect(5, 5, 6, 6, '#83aa60');
    return c;
  }
  if (name === 'piston_front' || name === 'sticky_piston_front') {
    rect(0, 0, 16, 16, '#8c7652'); rect(2, 2, 12, 12, '#68695f');
    rect(4, 4, 8, 8, name.startsWith('sticky') ? '#78a451' : '#a69a78');
    rect(6, 6, 4, 4, name.startsWith('sticky') ? '#91ba6b' : '#c5b78e');
    return c;
  }
  if (name === 'piston_side' || name === 'sticky_piston_side') {
    rect(0, 0, 16, 16, '#85704f');
    rect(0, 2, 16, 2, '#b6a17a'); rect(0, 6, 16, 2, '#5f604f');
    rect(0, 10, 16, 2, '#b6a17a'); rect(0, 14, 16, 2, '#5f604f');
    return c;
  }
  if (name === 'basalt_top') {
    rect(0, 0, 16, 16, '#4c4d4c');
    rect(1, 1, 14, 14, '#686967'); rect(2, 2, 12, 12, '#555756');
    rect(4, 4, 8, 8, '#727370'); rect(6, 6, 4, 4, '#4a4c4c');
    return c;
  }
  if (name === 'basalt_side') {
    rect(0, 0, 16, 16, '#555756');
    for (let y = 0; y < 16; y += 4) {
      rect(0, y, 16, 1, '#383a3b');
      rect(0, y + 1, 16, 1, '#686a68');
      rect(2, y + 2, 10, 1, '#4c4e4e');
    }
    return c;
  }

  if (pattern === 'concrete') {
    // Concrete is smooth dyed pigment, not noisy stone.
    rect(0, 0, 16, 16, base);
    for (let i = 0; i < 5; i++) {
      const px = Math.floor(rnd() * 15), py = Math.floor(rnd() * 15);
      rect(px, py, 1, 1, shade(base, i % 2 ? 3 : -3));
    }
    return c;
  }
  if (pattern === 'terracotta') {
    rect(0, 0, 16, 16, base);
    for (let y = 1; y < 16; y += 4) {
      rect(0, y, 16, 1, shade(base, -12));
      rect(2, y + 1, 12, 1, shade(base, 5));
    }
    for (let i = 0; i < 8; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 1, shade(base, i % 2 ? -9 : 7));
    return c;
  }
  if (pattern === 'sand') {
    rect(0, 0, 16, 16, base);
    for (let i = 0; i < 44; i++) {
      const px = Math.floor(rnd() * 16), py = Math.floor(rnd() * 16);
      rect(px, py, 1, 1, shade(base, i % 3 === 0 ? -17 : i % 3 === 1 ? 11 : -5));
    }
    return c;
  }
  if (name === 'clay') {
    rect(0, 0, 16, 16, base);
    for (let i = 0; i < 24; i++) {
      const x = Math.floor(rnd() * 15), y = Math.floor(rnd() * 15);
      rect(x, y, 1 + (i % 3 === 0 ? 1 : 0), 1, i % 2 ? shade(base, 12) : shade(base, -12));
    }
    return c;
  }
  if (pattern === 'snow') {
    rect(0, 0, 16, 16, '#edf4f6');
    for (let i = 0; i < 18; i++) {
      const px = Math.floor(rnd() * 15), py = Math.floor(rnd() * 15);
      rect(px, py, 1, 1, i % 3 === 0 ? '#cedce2' : '#ffffff');
    }
    return c;
  }
  if (pattern === 'deepslate') {
    rect(0, 0, 16, 16, base);
    rect(0, 3, 16, 1, shade(base, -12)); rect(0, 4, 16, 1, shade(base, 8));
    rect(0, 9, 16, 1, shade(base, -13)); rect(0, 10, 16, 1, shade(base, 7));
    for (let i = 0; i < 16; i++) {
      const px = Math.floor(rnd() * 15), py = Math.floor(rnd() * 15);
      rect(px, py, 1 + (i % 3 === 0 ? 1 : 0), 1, shade(base, i % 2 ? 12 : -16));
    }
    return c;
  }
  if (pattern === 'amethyst') {
    rect(0, 0, 16, 16, '#483556');
    const shards = [[2, 3], [7, 2], [12, 4], [4, 9], [10, 11], [1, 13]];
    for (let i = 0; i < shards.length; i++) {
      const [sx, sy] = shards[i];
      rect(sx, sy, 2, 4, i % 2 ? '#976bc1' : '#b38adb');
      rect(sx, sy, 1, 3, '#e0c8ff');
      rect(sx + 1, sy + 3, 1, 2, '#654582');
    }
    return c;
  }
  if (pattern === 'sponge') {
    rect(0, 0, 16, 16, '#d5c95c');
    const pores = [[2, 2], [7, 1], [12, 3], [4, 6], [10, 7], [1, 11], [6, 13], [12, 12], [14, 8], [3, 14]];
    for (let i = 0; i < pores.length; i++) {
      const [px, py] = pores[i];
      rect(px, py, 2, 2, '#a39640'); rect(px, py, 1, 1, '#756e32');
      rect(px + 1, py + 1, 1, 1, '#eee18a');
    }
    return c;
  }
  if (name === 'ice' || name === 'packed_ice' || name === 'blue_ice') {
    rect(0, 0, 16, 16, name === 'ice' ? '#a7dbe8' : name === 'blue_ice' ? '#70a5f0' : '#80b7d4');
    for (let i = 0; i < 10; i++) {
      const px = Math.floor(rnd() * 12), py = Math.floor(rnd() * 12);
      rect(px, py, 3, 1, name === 'blue_ice' ? '#bcd8ff' : '#e7f8fa');
      rect(px + 1, py + 1, 1, 2, name === 'blue_ice' ? '#5889db' : '#c0e6ef');
    }
    return c;
  }
  if (name === 'powder_snow') {
    rect(0, 0, 16, 16, '#f2f9fc');
    for (let i = 0; i < 16; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 2, 1, i % 2 ? '#e3eef4' : '#ffffff');
    return c;
  }
  if (name === 'calcite') {
    rect(0, 0, 16, 16, '#e2dfd7');
    for (let i = 0; i < 18; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 15), 2 + (i % 2), 1, i % 3 === 0 ? '#c9c6bc' : '#f1eee8');
    return c;
  }
  if (name === 'tuff') {
    rect(0, 0, 16, 16, '#6d7065');
    for (let i = 0; i < 24; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 15), 2, 1, i % 3 === 0 ? '#54574e' : i % 3 === 1 ? '#878b7e' : '#797d72');
    return c;
  }
  if (name === 'mud') {
    rect(0, 0, 16, 16, '#3c393c');
    for (let i = 0; i < 22; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 15), 2, 1, i % 2 ? '#2f2c2f' : '#4a4649');
    return c;
  }
  if (name === 'mangrove_roots_side' || name === 'mangrove_roots_top') {
    ctx.clearRect(0, 0, 16, 16);
    for (let x = 0; x < 16; x += 3) { rect(x, 0, 2, 16, '#4d3623'); rect(x + 1, 0, 1, 16, '#684a31'); }
    for (let y = 0; y < 16; y += 4) { rect(0, y, 16, 2, '#5c412b'); rect(0, y + 1, 16, 1, '#3d2a1a'); }
    ctx.clearRect(3, 2, 2, 2); ctx.clearRect(10, 6, 3, 2); ctx.clearRect(4, 10, 2, 3); ctx.clearRect(11, 13, 2, 2);
    return c;
  }
  if (name === 'muddy_mangrove_roots_side' || name === 'muddy_mangrove_roots_top') {
    rect(0, 0, 16, 16, '#3c393c');
    for (let i = 0; i < 10; i++) rect(Math.floor(rnd() * 13), Math.floor(rnd() * 14), 3, 2, '#573d27');
    for (let i = 0; i < 8; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 2, '#2e2b2e');
    return c;
  }
  if (name === 'cherry_leaves') {
    for (let i = 0; i < 18; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 2, i % 3 === 0 ? '#f8d0de' : i % 3 === 1 ? '#e288a6' : '#f2b0c6');
    return c;
  }
  if (name === 'flowering_azalea_leaves') {
    for (let i = 0; i < 10; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 2, i % 2 ? '#d669b0' : '#f09cd4');
    return c;
  }
  if (name === 'raw_iron_block' || name === 'raw_copper_block') {
    const c1 = name === 'raw_iron_block' ? '#c79f7e' : '#c96d46';
    const c2 = name === 'raw_iron_block' ? '#8c694f' : '#4a8b74';
    const c3 = name === 'raw_iron_block' ? '#e5c4a3' : '#e68c5e';
    rect(0, 0, 16, 16, c2);
    for (let i = 0; i < 20; i++) rect(Math.floor(rnd() * 13), Math.floor(rnd() * 13), 3, 3, i % 3 === 0 ? c3 : c1);
    return c;
  }
  if (name === 'sculk_block' || name === 'sculk_catalyst' || name === 'sculk_sensor' || name === 'sculk_shrieker') {
    rect(0, 0, 16, 16, name === 'sculk_shrieker' ? '#c9c6a8' : '#0b1e26');
    for (let i = 0; i < 16; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 2, i % 2 ? '#124a59' : '#1b7b8a');
    if (name === 'sculk_catalyst') { rect(2, 2, 12, 12, '#0c2a32'); rect(4, 4, 8, 8, '#d4d0b2'); rect(6, 6, 4, 4, '#24a8b8'); }
    if (name === 'sculk_sensor') { rect(0, 4, 16, 4, '#134e5e'); rect(3, 1, 2, 3, '#2cd8e8'); rect(11, 1, 2, 3, '#2cd8e8'); }
    return c;
  }

  // Special vanilla-faithful block textures
  if (name === 'cactus_side') {
    // Vanilla cactus: vertical ridges + horizontal segment bands + spines
    for (let x = 0; x < 16; x++) {
      const col = x % 4 === 0 ? '#39591f' : x % 4 === 1 ? '#4d7a2e' : x % 4 === 2 ? '#5f9440' : '#548538';
      rect(x, 0, 1, 16, col);
    }
    for (let y = 0; y < 16; y += 4) {
      const off = (y / 4) % 2 === 0 ? 0 : 2;
      for (let x = off; x < 16; x += 4) {
        rect(x, y, 4, 1, '#2e4a19');
        rect(x, y + 1, 1, 1, '#8cc463');
      }
    }
    // Spines on the ridge columns at band joints
    for (let y = 2; y < 16; y += 4) {
      for (let x = 0; x < 16; x += 4) {
        rect(x, y, 1, 1, '#d3ebaa');
        rect((x + 2) % 16, y, 1, 1, '#243d13');
      }
    }
    return c;
  }
  if (name === 'cactus_top' || name === 'cactus_bottom') {
    rect(0, 0, 16, 16, '#3c5c24');
    rect(1, 1, 14, 14, '#4d7a2e');
    rect(2, 2, 12, 12, '#5f9440');
    rect(3, 3, 10, 10, '#6fa94e');
    rect(4, 4, 8, 8, '#82bd5f');
    rect(5, 5, 6, 6, '#93cc6d');
    rect(6, 6, 4, 4, '#a5da80');
    rect(7, 7, 2, 2, '#b7e793');
    return c;
  }
  if (name === 'pumpkin' || name === 'pumpkin_block' || name === 'pumpkin_block_side' || name === 'pumpkin_block_front') {
    // Pumpkin ridges + carved face hints on every side
    for (let x = 0; x < 16; x++) {
      const col = x % 4 === 0 ? '#8a5a17' : x % 4 === 2 ? '#c98a32' : '#b87a26';
      rect(x, 0, 1, 16, col);
    }
    rect(4, 6, 2, 3, '#3a2708'); rect(10, 6, 2, 3, '#3a2708');
    rect(6, 11, 4, 2, '#3a2708'); rect(5, 12, 2, 1, '#3a2708'); rect(9, 12, 2, 1, '#3a2708');
    return c;
  }
  if (name === 'pumpkin_top' || name === 'pumpkin_block_top' || name === 'pumpkin_block_bottom') {
    rect(0, 0, 16, 16, '#b87a26');
    for (let i = 0; i < 12; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 1, i % 2 ? '#c98a32' : '#8a5a17');
    rect(6, 6, 4, 4, '#5d4423'); rect(7, 5, 2, 6, '#6e5330'); rect(8, 6, 2, 4, '#7d5f38');
    return c;
  }
  if (name === 'melon' || name === 'melon_block' || name === 'melon_block_side' || name === 'melon_block_front') {
    rect(0, 0, 16, 16, '#6f9c3a');
    for (let x = 1; x < 16; x += 4) rect(x, 0, 1, 16, '#4f7a26');
    for (let i = 0; i < 18; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 1, i % 2 ? '#87b54c' : '#5d8a30');
    return c;
  }

  if (name.includes('sandstone')) {
    const red = name.includes('red_');
    const cMain = red ? '#b96a38' : '#dfd3a2';
    const cDark = red ? '#934f25' : '#c6b67d';
    const cLight = red ? '#cf814e' : '#eee5bd';
    if (name.endsWith('_top')) {
      rect(0, 0, 16, 16, cMain);
      for (let i = 0; i < 16; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 15), 2, 1, i % 2 ? cLight : cDark);
      rect(0, 0, 16, 1, cLight); rect(0, 15, 16, 1, cDark);
    } else if (name === 'chiseled_sandstone') {
      rect(0, 0, 16, 16, cMain);
      rect(0, 0, 16, 2, cDark); rect(0, 14, 16, 2, cDark);
      rect(1, 2, 14, 1, cLight);
      // Creeper glyph
      rect(4, 4, 3, 3, cDark); rect(9, 4, 3, 3, cDark);
      rect(7, 7, 2, 3, cDark); rect(5, 9, 6, 3, cDark);
      rect(5, 11, 2, 2, cDark); rect(9, 11, 2, 2, cDark);
    } else if (name === 'cut_sandstone') {
      rect(0, 0, 16, 16, cMain);
      rect(0, 0, 16, 2, cLight); rect(0, 7, 16, 1, cDark); rect(0, 8, 16, 1, cLight);
      rect(0, 2, 1, 14, cLight); rect(8, 2, 1, 14, cDark); rect(15, 2, 1, 14, cDark);
    } else {
      rect(0, 0, 16, 16, cMain);
      rect(0, 0, 16, 2, cLight); rect(0, 2, 16, 1, cDark);
      rect(0, 6, 16, 1, cDark); rect(0, 10, 16, 1, cDark); rect(0, 14, 16, 1, cDark);
      for (let i = 0; i < 12; i++) rect(Math.floor(rnd() * 13), 4 + Math.floor(rnd() * 11), 3, 1, cDark);
    }
    return c;
  }

  if (name === 'end_stone') {
    rect(0, 0, 16, 16, '#dedba2');
    for (let i = 0; i < 22; i++) {
      const x = Math.floor(rnd() * 13), y = Math.floor(rnd() * 13);
      rect(x, y, 3, 2, i % 3 === 0 ? '#c3bf82' : '#eeecbd');
      rect(x + 1, y + 1, 2, 1, '#b5b172');
    }
    return c;
  }
  if (name === 'netherrack') {
    rect(0, 0, 16, 16, '#793b35');
    for (let i = 0; i < 28; i++) {
      const x = Math.floor(rnd() * 14), y = Math.floor(rnd() * 14);
      const col = i % 3 === 0 ? '#4c2726' : i % 3 === 1 ? '#a24e45' : '#68312e';
      rect(x, y, 2 + (i % 3 === 0 ? 1 : 0), 1 + (i % 4 === 0 ? 1 : 0), col);
    }
    return c;
  }
  if (name === 'deepslate') {
    rect(0, 0, 16, 16, '#505257');
    for (let y = 0; y < 16; y += 4) {
      rect(0, y, 16, 1, '#34363a');
      rect(0, y + 1, 16, 1, '#66686b');
      const off = (y / 4) % 2 ? 4 : 0;
      for (let x = off; x < 16; x += 8) rect(x, y + 1, 1, 3, '#37393d');
    }
    return c;
  }
  if (name === 'clay') {
    rect(0, 0, 16, 16, '#9da8ad');
    for (let i = 0; i < 18; i++) {
      const x = Math.floor(rnd() * 14), y = Math.floor(rnd() * 14);
      rect(x, y, 2, 1, i % 2 ? '#b5bec1' : '#838f95');
    }
    return c;
  }

  if (pattern === 'purpur') {
    if (name === 'purpur_pillar_top') {
      rect(0, 0, 16, 16, '#b88ab8');
      rect(2, 2, 12, 12, '#9a6a9a');
      rect(4, 4, 8, 8, '#c69ac6');
      rect(6, 6, 4, 4, '#8d5b8d');
    } else if (name === 'purpur_pillar') {
      rect(0, 0, 16, 16, '#ac7eac');
      for (let x = 0; x < 16; x += 4) { rect(x, 0, 1, 16, '#885888'); rect(x + 1, 0, 2, 16, '#c296c2'); }
      rect(0, 0, 16, 2, '#936293'); rect(0, 14, 16, 2, '#936293');
    } else if (name === 'chorus_plant') {
      rect(0, 0, 16, 16, '#57335a');
      for (let i = 0; i < 16; i++) rect(Math.floor(rnd() * 13), Math.floor(rnd() * 13), 3, 2, i % 2 ? '#78487b' : '#402142');
    } else if (name === 'chorus_flower') {
      rect(0, 0, 16, 16, '#7a4b7d');
      rect(2, 2, 12, 12, '#a774ab');
      rect(4, 4, 8, 8, '#e8d4ea');
      rect(6, 6, 4, 4, '#fff7cc');
    } else {
      // Purpur 2x2 tile block
      rect(0, 0, 16, 16, '#a77aa7');
      for (const [bx, by] of [[0, 0], [8, 0], [0, 8], [8, 8]]) {
        rect(bx, by, 8, 1, '#c79dc7'); rect(bx, by, 1, 8, '#c79dc7');
        rect(bx, by + 7, 8, 1, '#7c517c'); rect(bx + 7, by, 1, 8, '#7c517c');
      }
    }
    return c;
  }

  if (name === 'end_portal_frame_top') {
    rect(0, 0, 16, 16, '#4f8672');
    rect(1, 1, 14, 14, '#6aa38d');
    rect(3, 3, 10, 10, '#29483d');
    rect(4, 4, 8, 8, '#172924');
    rect(1, 1, 2, 2, '#92ccb3'); rect(13, 1, 2, 2, '#92ccb3');
    rect(1, 13, 2, 2, '#92ccb3'); rect(13, 13, 2, 2, '#92ccb3');
    return c;
  }
  if (name === 'end_portal_frame_side') {
    rect(0, 0, 16, 16, '#dedba2');
    rect(0, 0, 16, 5, '#59917c');
    rect(0, 4, 16, 2, '#3c6858');
    rect(4, 5, 8, 2, '#59917c');
    for (let i = 0; i < 8; i++) rect(Math.floor(rnd() * 14), 8 + Math.floor(rnd() * 6), 2, 1, '#c3bf82');
    return c;
  }

  if (name === 'shulker_box_top' || name === 'shulker_box_bottom' || name === 'shulker_box_side') {
    rect(0, 0, 16, 16, '#8b5b8e');
    rect(1, 1, 14, 14, '#9c6c9f');
    if (name === 'shulker_box_top') {
      rect(3, 3, 10, 10, '#ae7eb1'); rect(5, 5, 6, 6, '#8b5b8e');
    } else if (name === 'shulker_box_side') {
      rect(0, 7, 16, 2, '#5f3762');
      rect(0, 2, 16, 1, '#b88bbb'); rect(0, 13, 16, 1, '#6c426f');
    }
    return c;
  }

  if (name === 'bed_top' || name === 'bed_side') {
    if (name === 'bed_top') {
      rect(0, 0, 16, 16, '#c43b30');
      rect(1, 1, 14, 5, '#e8e4da');
      rect(2, 2, 12, 3, '#ffffff');
      rect(0, 6, 16, 2, '#e2dfd5');
      rect(1, 9, 14, 6, '#b03026');
    } else {
      rect(0, 0, 16, 16, '#966c3e');
      rect(0, 4, 16, 5, '#c43b30');
      rect(0, 4, 5, 4, '#f0ede4');
      rect(0, 9, 16, 3, '#8c6338');
    }
    return c;
  }

  if (name === 'bookshelf') {
    rect(0, 0, 16, 16, '#b8955d');
    rect(0, 0, 16, 2, '#8b683b'); rect(0, 7, 16, 2, '#8b683b'); rect(0, 14, 16, 2, '#8b683b');
    const cols = ['#b83d33', '#3b79a8', '#528e3d', '#c79f3e', '#7b4fa1', '#c76838'];
    for (let x = 1; x < 15; x += 2) {
      rect(x, 2, 2, 5, cols[(x * 3) % cols.length]);
      rect(x, 9, 2, 5, cols[(x * 5 + 2) % cols.length]);
      rect(x, 3, 1, 1, '#e8dfc4'); rect(x, 10, 1, 1, '#e8dfc4');
    }
    return c;
  }

  if (name.startsWith('ancient_debris')) {
    rect(0, 0, 16, 16, '#5c433b');
    if (name.endsWith('_top')) {
      for (let r = 6; r >= 2; r -= 2) { ctx.strokeStyle = r === 4 ? '#8a685c' : '#3d2a24'; ctx.strokeRect(8 - r, 8 - r, r * 2, r * 2); }
    } else {
      rect(0, 3, 16, 3, '#7b5b50'); rect(0, 9, 16, 3, '#7b5b50');
      rect(0, 6, 16, 2, '#3d2a24'); rect(0, 13, 16, 2, '#3d2a24');
    }
    return c;
  }

  if (name === 'crying_obsidian') {
    for (let i = 0; i < 14; i++) {
      const px = Math.floor(rnd() * 14), py = Math.floor(rnd() * 13);
      rect(px, py, 2, 2, '#8b32d9'); rect(px, py + 1, 1, 2, '#c87eff');
    }
    return c;
  }

  if (name === 'soul_sand') {
    rect(0, 0, 16, 16, '#5b4639');
    for (let i = 0; i < 4; i++) {
      const fx = 2 + (i % 2) * 7, fy = 2 + Math.floor(i / 2) * 7;
      rect(fx, fy, 1, 1, '#36271e'); rect(fx + 3, fy, 1, 1, '#36271e');
      rect(fx + 1, fy + 2, 2, 2, '#36271e');
    }
    return c;
  }
  if (name === 'soul_soil') {
    rect(0, 0, 16, 16, '#4f3c31');
    for (let i = 0; i < 24; i++) {
      const x = Math.floor(rnd() * 15), y = Math.floor(rnd() * 15);
      rect(x, y, 1 + (i % 3 === 0 ? 1 : 0), 1, i % 2 ? '#765946' : '#382a24');
    }
    rect(2, 3, 2, 1, '#98775b'); rect(11, 12, 3, 1, '#8a694d');
    return c;
  }

  if (name === 'iron_bars') {
    ctx.clearRect(0, 0, 16, 16);
    rect(3, 0, 2, 16, '#848c89'); rect(11, 0, 2, 16, '#848c89');
    rect(3, 0, 1, 16, '#b7bfbc'); rect(11, 0, 1, 16, '#b7bfbc');
    rect(0, 3, 16, 2, '#7c8481'); rect(0, 11, 16, 2, '#7c8481');
    return c;
  }

  if (name === 'fire') {
    ctx.clearRect(0, 0, 16, 16);
    for (let x = 1; x < 15; x++) {
      const h = 6 + Math.floor(Math.sin(x * 1.4) * 3 + rnd() * 5);
      rect(x, 16 - h, 1, h, '#e8561a');
      rect(x, 16 - Math.max(2, h - 3), 1, Math.max(2, h - 3), '#ffab26');
      rect(x, 16 - Math.max(1, h - 6), 1, Math.max(1, h - 6), '#fff18c');
    }
    return c;
  }

  if (name === 'end_rod') {
    ctx.clearRect(0, 0, 16, 16);
    rect(5, 13, 6, 3, '#885888');
    rect(6, 12, 4, 1, '#b88ab8');
    rect(7, 1, 2, 11, '#fffdf2');
    rect(6, 2, 1, 9, '#ebe3cb');
    return c;
  }

  if (name === 'dragon_egg') {
    rect(0, 0, 16, 16, '#140c1b');
    for (let i = 0; i < 18; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 1, i % 2 ? '#341f46' : '#532d6f');
    return c;
  }

  if (name === 'dragon_head') {
    rect(0, 0, 16, 16, '#1f1b24');
    rect(2, 6, 3, 3, '#cf5ce6'); rect(11, 6, 3, 3, '#cf5ce6');
    rect(5, 10, 6, 4, '#2f2936');
    return c;
  }

  if (name === 'shroomlight' || name === 'glowstone') {
    const c1 = name === 'shroomlight' ? '#f5b242' : '#f2d06b';
    const c2 = name === 'shroomlight' ? '#c96b20' : '#a87d2e';
    for (let i = 0; i < 20; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 3, 2, i % 2 ? c1 : c2);
    rect(4, 4, 3, 3, '#fff2b0'); rect(10, 9, 3, 3, '#fff2b0');
    return c;
  }

  if (name === 'magma_block') {
    rect(0, 0, 16, 16, '#462119');
    for (let i = 0; i < 18; i++) {
      const x = Math.floor(rnd() * 13), y = Math.floor(rnd() * 13);
      rect(x, y, 3, 2, i % 3 === 0 ? '#ffbd33' : '#e85b1c');
    }
    return c;
  }

  if (pattern === 'nylium' && !name.includes('nylium')) {
    const top = name.includes('crimson') ? '#9e2629' : '#2a8b84';
    const hi = name.includes('crimson') ? '#c43b3e' : '#40b5ab';
    if (name.endsWith('_side')) {
      rect(0, 0, 16, 16, '#7a332d');
      rect(0, 0, 16, 4, top);
      for (let x = 0; x < 16; x++) if ((x * 5) % 3) rect(x, 4, 1, 2, top);
      for (let i = 0; i < 10; i++) rect(Math.floor(rnd() * 14), 7 + Math.floor(rnd() * 8), 2, 1, '#58201b');
    } else {
      rect(0, 0, 16, 16, top);
      for (let i = 0; i < 22; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 15), 2, 1, i % 2 ? hi : '#1e5853');
    }
    return c;
  }

  if (pattern === 'grass') {
    if (name === 'grass_block') {
      // Vanilla grayscale grass texture so biome tint maps with 100% color accuracy
      rect(0, 0, 16, 16, '#969696');
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        const v = Math.round((rnd() - 0.5) * 36);
        rect(x, y, 1, 1, `rgb(${150 + v},${150 + v},${150 + v})`);
      }
    } else {
      for (let i = 0; i < 24; i++) {
        const x = Math.floor(rnd() * 16), y = Math.floor(rnd() * 16);
        rect(x, y, 2, 1, shade(base, rnd() * 28 - 10));
      }
    }
    if (name === 'dirt_path') {
      rect(0, 0, 16, 16, '#917244');
      for (let i = 0; i < 20; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 2, 1, i % 2 ? '#7c5f35' : '#a28352');
    }
  }
  if (pattern === 'dirt') {
    // Rich vanilla-style dirt with organic gravel clumps
    rect(0, 0, 16, 16, base);
    for (let i = 0; i < 28; i++) {
      const x = Math.floor(rnd() * 15), y = Math.floor(rnd() * 15);
      rect(x, y, 1 + Math.floor(rnd() * 2), 1, shade(base, i % 3 === 0 ? -22 : i % 3 === 1 ? 14 : -9));
    }
    if (name === 'coarse_dirt') {
      for (let i = 0; i < 14; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 1, '#8e867c');
    }
  }
  if (pattern === 'stone') {
    // Smooth, solid stone bedrock/ore matrix
    rect(0, 0, 16, 16, base);
    for (let i = 0; i < 32; i++) {
      const x = Math.floor(rnd() * 15), y = Math.floor(rnd() * 15);
      rect(x, y, 1 + Math.floor(rnd() * 2), 1, i % 2 === 0 ? shade(base, -18) : shade(base, 14));
    }
    if (name === 'granite') for (let i = 0; i < 20; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 2, 1, i % 2 ? '#b88977' : '#6c4e43');
    if (name === 'diorite') for (let i = 0; i < 24; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 2, 1, i % 2 ? '#757873' : '#deddd3');
    if (name === 'andesite') for (let i = 0; i < 18; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 2, 1, i % 2 ? '#666b62' : '#8c9188');
    if (name.startsWith('furnace') || name.startsWith('blast_furnace') || name.startsWith('smoker') || name.startsWith('dispenser') || name.startsWith('dropper')) rect(2, 2, 12, 12, shade(base, -8));
  }
  if (pattern === 'gravel') {
    rect(0, 0, 16, 16, '#7f7872');
    for (let i = 0; i < 30; i++) {
      const x = Math.floor(rnd() * 14), y = Math.floor(rnd() * 14);
      rect(x, y, 2, 1, i % 2 ? '#5e5852' : '#9c948c');
    }
  }
  if (pattern === 'cobble') {
    // Authentic Minecraft cobblestone: chunky stones + deep dark mortar grooves
    rect(0, 0, 16, 16, shade(base, -15));
    const stoneRects = [
      [1, 1, 5, 3], [7, 1, 4, 3], [12, 1, 3, 4],
      [1, 5, 4, 4], [6, 5, 5, 3], [12, 6, 3, 4],
      [1, 10, 5, 4], [7, 9, 4, 4], [12, 11, 3, 4],
      [7, 14, 4, 2], [1, 15, 5, 1],
    ];
    for (const [sx, sy, sw, sh] of stoneRects) {
      rect(sx, sy, sw, sh, shade(base, (rnd() - 0.5) * 20));
      rect(sx, sy, sw, 1, shade(base, 12)); // top highlight
      rect(sx, sy + sh - 1, sw, 1, shade(base, -35)); // bottom shadow
      rect(sx + sw - 1, sy, 1, sh, shade(base, -35)); // right shadow
    }
    // Mortar grid lines
    rect(0, 0, 16, 1, '#3b3b3b'); rect(0, 4, 16, 1, '#3b3b3b');
    rect(0, 8, 16, 1, '#3b3b3b'); rect(0, 13, 16, 1, '#3b3b3b');
    if (name.includes('mossy')) {
      for (let i = 0; i < 22; i++) {
        const x = Math.floor(rnd() * 14), y = Math.floor(rnd() * 14);
        rect(x, y, 2, 1, i % 2 ? '#557d37' : '#7a9b4e');
      }
    }
  }
  if (pattern === 'planks') {
    // 4 horizontal wood planks with dark seam line, nail dots and grain streaks
    for (let p = 0; p < 4; p++) {
      const py = p * 4;
      rect(0, py, 16, 4, shade(base, (p % 2 ? 6 : -4)));
      rect(0, py, 16, 1, shade(base, 18));      // top plank highlight
      rect(0, py + 3, 16, 1, shade(base, -32)); // bottom seam groove
      // Wood grain streaks
      rect((p * 5 + 3) % 12, py + 1, 4, 1, shade(base, -18));
      rect((p * 7 + 8) % 13, py + 2, 3, 1, shade(base, 14));
      // Nail accents
      rect(1, py + 1, 1, 1, shade(base, -40));
      rect(14, py + 1, 1, 1, shade(base, -40));
    }
  }
  if (pattern === 'bark') {
    if (name.includes('birch') || name.includes('poplar')) {
      rect(0, 0, 16, 16, '#e0dcca');
      for (let i = 0; i < 12; i++) {
        const by = 1 + Math.floor(rnd() * 14);
        rect(Math.floor(rnd() * 12), by, 2 + Math.floor(rnd() * 3), 1 + (i % 3 === 0 ? 1 : 0), '#383a32');
      }
    } else if (name.includes('hay')) {
      for (let y = 0; y < 16; y += 2) rect(0, y, 16, 1, y % 4 ? '#b08f33' : '#dec05a');
      rect(0, 4, 16, 2, '#9c3228'); rect(0, 11, 16, 2, '#9c3228');
    } else {
      rect(0, 0, 16, 16, base);
      for (let x = 0; x < 16; x += 4) {
        rect(x, 0, 1, 16, shade(base, -32));
        rect(x + 1, 0, 1, 16, shade(base, 18));
        for (let y = 0; y < 16; y += 4) {
          rect(x + 2, y + (x % 3), 1, 2, shade(base, -16));
        }
      }
    }
  }
  if (pattern === 'rings') {
    rect(0, 0, 16, 16, shade(base, -25)); // outer bark ring
    rect(1, 1, 14, 14, shade(base, 14));   // inner sapwood
    rect(2, 2, 12, 12, base);
    rect(3, 3, 10, 10, shade(base, -18));
    rect(4, 4, 8, 8, shade(base, 8));
    rect(5, 5, 6, 6, shade(base, -22));
    rect(6, 6, 4, 4, base);
    rect(7, 7, 2, 2, shade(base, -30));  // core heartwood
  }
  if (pattern === 'bricks') {
    rect(0, 0, 16, 16, base);
    const row = 4;
    for (let y = 0; y < 16; y += row) {
      rect(0, y, 16, 1, shade(base, -32));
      rect(0, y + 1, 16, 1, shade(base, 18));
      const off = ((y / row) % 2) * 4;
      for (let x = off; x < 16; x += 8) {
        rect(x, y, 1, row, shade(base, -30));
        rect(x + 1, y + 2, 1, row - 2, shade(base, 12));
      }
    }
    if (name.includes('mossy')) {
      for (let i = 0; i < 20; i++) rect(Math.floor(rnd() * 14), Math.floor(rnd() * 14), 2, 2, i % 2 ? '#4c7830' : '#659442');
    }
  }
  if (pattern === 'ore') {
    // Stone matrix
    rect(0, 0, 16, 16, base);
    for (let i = 0; i < 20; i++) rect(Math.floor(rnd() * 15), Math.floor(rnd() * 15), 1, 1, i % 2 ? shade(base, -20) : shade(base, 16));
    const ore = name.includes('coal') ? '#242625' : name.includes('iron') ? '#d4ab8e' : name.includes('gold') ? '#f2c842' : name.includes('emerald') ? '#38cf65' : name.includes('lapis') ? '#2c52bf' : name.includes('redstone') ? '#db2a1f' : name.includes('copper') ? '#cf6d42' : name.includes('quartz') ? '#ece6d8' : '#45f0e3';
    // Recognizable ore cluster clumps
    const clusters = [[3, 3], [4, 4], [3, 9], [10, 4], [11, 10], [9, 11]];
    for (const [cx, cy] of clusters) {
      rect(cx - 1, cy - 1, 3, 3, shade(ore, -38));
      rect(cx, cy, 2, 2, ore);
      rect(cx, cy, 1, 1, shade(ore, 45)); // sparkle gem highlight
    }
  }
  if (pattern === 'tnt') {
    if (name === 'tnt_top') {
      rect(0, 0, 16, 16, '#b53b2e'); rect(3, 3, 10, 10, '#d9d4c3'); rect(5, 5, 6, 6, '#b53b2e'); rect(7, 7, 2, 2, '#d9d4c3');
    } else {
      rect(0, 0, 16, 16, '#b53b2e'); rect(0, 4, 16, 8, '#d9d4c3');
      rect(2, 6, 4, 1, '#b53b2e'); rect(3, 7, 2, 3, '#b53b2e');
      rect(7, 6, 4, 1, '#b53b2e'); rect(7, 9, 4, 1, '#b53b2e'); rect(8, 7, 2, 2, '#b53b2e');
      rect(12, 6, 4, 1, '#b53b2e'); rect(13, 7, 2, 3, '#b53b2e');
      rect(0, 12, 16, 4, '#8c2b21'); rect(0, 3, 16, 1, '#8c2b21');
    }
  }
  if (pattern === 'torch') {
    ctx.clearRect(0, 0, 16, 16);
    if (name === 'lantern') {
      rect(7, 0, 2, 3, '#5c6360'); rect(5, 3, 6, 2, '#464c4a'); rect(4, 5, 8, 8, '#3a403e');
      rect(5, 6, 6, 6, '#f6b949'); rect(6, 7, 4, 4, '#fff0a8'); rect(5, 13, 6, 2, '#464c4a');
    } else if (name === 'lever') {
      rect(6, 2, 4, 3, '#a37c49'); rect(7, 4, 2, 9, '#8b673c'); rect(5, 13, 6, 3, '#6b706a');
    } else if (name.includes('button')) {
      rect(4, 4, 8, 8, base); rect(5, 5, 6, 6, shade(base, 22));
    } else {
      rect(7, 0, 2, 2, '#fff9c4'); rect(7, 1, 2, 4, '#ffe76b'); rect(6, 2, 4, 4, '#f59b28');
      rect(7, 6, 2, 10, '#7c5b34'); rect(7, 7, 1, 5, '#9e7747');
    }
  }
  if (pattern === 'glass') {
    ctx.clearRect(0, 0, 16, 16);
    if (name === 'honey_block') {
      // Honey is translucent amber with layered syrup bands and bubbles.
      rect(1, 0, 14, 16, 'rgba(226,166,41,0.58)');
      rect(2, 2, 12, 3, 'rgba(255,211,82,0.68)');
      rect(1, 7, 14, 2, 'rgba(177,105,21,0.55)');
      rect(2, 11, 12, 3, 'rgba(250,187,45,0.66)');
      rect(3, 3, 2, 1, 'rgba(255,248,180,0.9)'); rect(11, 12, 2, 1, 'rgba(255,239,142,0.9)');
      return c;
    }
    if (name === 'slime_block') {
      rect(1, 0, 14, 16, 'rgba(111,191,72,0.38)');
      rect(2, 2, 12, 12, 'rgba(151,220,96,0.45)');
      rect(3, 3, 10, 2, 'rgba(207,247,151,0.5)');
      rect(2, 11, 12, 2, 'rgba(62,133,45,0.45)');
      return c;
    }
    if (name.endsWith('_stained_glass')) {
      // Tinted-glass border inherits the block dye; its center stays clear.
      const edge = base;
      rect(0, 0, 16, 1, shade(edge, 35)); rect(0, 0, 1, 16, shade(edge, 35));
      rect(15, 0, 1, 16, shade(edge, -24)); rect(0, 15, 16, 1, shade(edge, -24));
      rect(2, 2, 3, 1, 'rgba(255,255,255,0.88)'); rect(3, 3, 1, 3, 'rgba(255,255,255,0.72)');
      return c;
    }
    if (name === 'ice') {
      rect(0, 0, 16, 16, 'rgba(160,215,232,0.28)');
      rect(0, 0, 16, 1, '#d8f4fb'); rect(0, 0, 1, 16, '#d8f4fb');
      rect(15, 0, 1, 16, '#6e9fb7'); rect(0, 15, 16, 1, '#6e9fb7');
      rect(3, 2, 1, 5, 'rgba(245,255,255,0.9)'); rect(4, 2, 4, 1, 'rgba(245,255,255,0.9)');
      rect(10, 10, 1, 4, 'rgba(193,234,246,0.7)');
      return c;
    }
    // Clear glass: crisp 1px edge + restrained specular glints; interior is transparent.
    rect(0, 0, 16, 1, '#b4dce1'); rect(0, 0, 1, 16, '#b4dce1');
    rect(15, 0, 1, 16, '#648e94'); rect(0, 15, 16, 1, '#648e94');
    rect(2, 2, 3, 1, 'rgba(255,255,255,0.85)');
    rect(3, 3, 1, 3, 'rgba(255,255,255,0.85)');
    rect(11, 11, 2, 1, 'rgba(255,255,255,0.65)');
    rect(12, 12, 1, 1, 'rgba(255,255,255,0.65)');
  }
  if (pattern === 'plant') {
    ctx.clearRect(0, 0, 16, 16);
    if (name === 'pink_petals') {
      const petals: [number, number, string][] = [[2, 2, '#f7c4d4'], [10, 3, '#ef9eb8'], [4, 9, '#f4b2c7'], [11, 11, '#f8d2df'], [7, 6, '#e88ca9']];
      for (const [px, py, col] of petals) { rect(px, py, 3, 2, col); rect(px + 1, py + 1, 2, 2, '#fce4ec'); }
    } else if (name === 'leaf_litter') {
      const leaves: [number, number, string][] = [[2, 3, '#8a5d32'], [9, 2, '#a3713c'], [4, 10, '#734a25'], [11, 9, '#946635'], [7, 6, '#b07b42']];
      for (const [lx, ly, col] of leaves) { rect(lx, ly, 3, 2, col); rect(lx + 1, ly + 1, 2, 1, shade(col, -20)); }
    } else if (name === 'lily_pad') {
      rect(3, 2, 10, 12, '#467a2f'); rect(2, 3, 12, 10, '#568e3b'); rect(4, 4, 8, 8, '#659f47'); ctx.clearRect(8, 2, 2, 5);
    } else if (name === 'dead_bush') {
      rect(7, 9, 2, 7, '#7b5834'); rect(4, 6, 3, 2, '#8d663d'); rect(9, 5, 3, 2, '#8d663d'); rect(3, 3, 2, 3, '#7b5834'); rect(11, 2, 2, 3, '#7b5834'); rect(6, 4, 2, 6, '#9a7146');
    } else if (name === 'sugar_cane') {
      for (const x of [3, 7, 11]) { rect(x, 0, 2, 16, '#969696'); rect(x + 1, 0, 1, 16, '#b6b6b6'); for (let y = 3; y < 15; y += 4) rect(x - 1, y, 4, 1, '#787878'); }
    } else if (name === 'bamboo') {
      rect(6, 0, 4, 16, '#5c912d'); rect(7, 0, 2, 16, '#7cb844'); rect(8, 0, 1, 16, '#9ed462');
      for (const y of [3, 8, 13]) rect(6, y, 4, 1, '#44701f');
      rect(3, 2, 3, 2, '#7cb844'); rect(10, 5, 4, 2, '#6ba338'); rect(2, 10, 4, 2, '#7cb844');
    } else if (name === 'vine') {
      for (const x of [2, 5, 9, 12]) {
        const len = 10 + (x % 5);
        for (let y = 0; y < len; y++) {
          const sx = x + ((y >> 1) & 1 ? 1 : 0);
          rect(sx, y, 2, 1, (x + y) % 3 === 0 ? '#8c8c8c' : '#ababab');
        }
      }
      rect(3, 3, 3, 2, '#9c9c9c'); rect(10, 7, 3, 2, '#9c9c9c');
    } else if (name === 'kelp') {
      for (let y = 0; y < 16; y++) {
        const sx = 6 + Math.round(Math.sin(y * 0.65) * 2);
        rect(sx, y, 4, 1, y % 3 === 0 ? '#3e7a28' : '#589e3b');
        if (y % 4 === 1) rect(sx - 2, y, 2, 2, '#4a8b31');
        if (y % 4 === 3) rect(sx + 4, y, 2, 2, '#6ab34a');
      }
    } else if (name === 'seagrass') {
      for (const x of [2, 5, 8, 11, 13]) {
        const h = 7 + ((x * 5) % 8);
        for (let y = 16 - h; y < 16; y++) rect(x + ((y >> 2) & 1), y, 1, 1, y % 2 ? '#3f8a42' : '#5cb354');
      }
    } else if (name === 'sea_pickle') {
      rect(6, 7, 4, 9, '#5e7834'); rect(7, 7, 2, 9, '#769644'); rect(7, 5, 2, 2, '#c8ea96');
      rect(3, 10, 3, 6, '#50662c'); rect(4, 9, 1, 1, '#b8de86');
    } else if (name === 'pointed_dripstone') {
      for (let y = 0; y < 16; y++) {
        const w = Math.max(1, Math.round(8 * (1 - y / 16)));
        const x0 = 8 - Math.floor(w / 2);
        rect(x0, y, w, 1, '#8c6f5e');
        if (w > 1) rect(x0, y, 1, 1, '#a68775');
      }
    } else if (name === 'cave_vines') {
      rect(7, 0, 2, 16, '#567e28'); rect(5, 3, 2, 3, '#6d9b34'); rect(9, 8, 2, 3, '#6d9b34');
      rect(6, 11, 4, 4, '#f2a838'); rect(7, 12, 2, 2, '#ffe078');
    } else if (name === 'weeping_vines' || name === 'twisting_vines') {
      const c1 = name === 'weeping_vines' ? '#7a161c' : '#187c76', c2 = name === 'weeping_vines' ? '#b32830' : '#2fb8ad';
      for (let y = 0; y < 16; y++) {
        const sx = 6 + ((y >> 1) & 1);
        rect(sx, y, 3, 1, y % 2 ? c1 : c2);
        if (y % 4 === 2) rect(sx - 2, y, 2, 2, c2);
      }
    } else if (name === 'crimson_roots' || name === 'warped_roots' || name === 'nether_sprouts') {
      const c1 = name === 'crimson_roots' ? '#8c1a24' : '#1b857e', c2 = name === 'crimson_roots' ? '#c92e3b' : '#35bdb2';
      for (let i = 0; i < 6; i++) {
        const x = 2 + i * 2, h = 5 + ((i * 7) % 8);
        rect(x, 16 - h, 1, h, i % 2 ? c1 : c2);
        rect(x + (i % 2 ? 1 : -1), 15 - h, 1, 3, c2);
      }
    } else if (name === 'crimson_fungus' || name === 'warped_fungus') {
      const cap = name === 'crimson_fungus' ? '#a62624' : '#1e9a8e', spots = name === 'crimson_fungus' ? '#e88b3a' : '#7ae89a';
      rect(7, 9, 2, 7, '#d4c9bd'); rect(4, 5, 8, 4, cap); rect(5, 3, 6, 2, cap);
      rect(5, 6, 1, 1, spots); rect(10, 5, 1, 1, spots); rect(7, 4, 2, 1, spots);
    } else if (name === 'sunflower') {
      rect(7, 6, 2, 10, '#4c7c34'); rect(4, 11, 3, 2, '#629840'); rect(9, 9, 3, 2, '#629840');
      rect(3, 1, 10, 8, '#f5c724'); rect(4, 0, 8, 10, '#ffd83b');
      rect(5, 2, 6, 6, '#5c3c1e'); rect(6, 3, 4, 4, '#7a5229');
    } else if (name === 'blue_orchid') {
      rect(7, 6, 2, 10, '#4b7a38'); rect(4, 10, 3, 3, '#5d9144');
      for (const [bx, by] of [[4, 2], [9, 3], [6, 5], [3, 6], [10, 7]]) { rect(bx, by, 3, 3, '#2b9ec9'); rect(bx + 1, by + 1, 1, 1, '#8ae4ff'); }
    } else if (name === 'allium') {
      rect(7, 7, 2, 9, '#4c7c38'); rect(4, 11, 3, 2, '#629444');
      rect(4, 2, 8, 6, '#9b5ec4'); rect(5, 1, 6, 8, '#b578dc'); rect(6, 3, 4, 4, '#d5a3f5');
    } else if (name === 'azure_bluet') {
      rect(7, 8, 2, 8, '#4c7c38');
      for (const [bx, by] of [[3, 3], [9, 4], [6, 6]]) { rect(bx, by, 4, 4, '#f0f4f7'); rect(bx + 1, by + 1, 2, 2, '#f2cc3a'); }
    } else if (name === 'sweet_berry_bush') {
      rect(3, 5, 10, 11, '#315420'); rect(2, 7, 12, 8, '#416d2b'); rect(5, 4, 6, 10, '#4f8236');
      for (const [bx, by] of [[4, 7], [10, 6], [6, 11], [11, 11], [8, 8]]) rect(bx, by, 2, 2, '#c72636');
    } else if (name === 'azalea' || name === 'flowering_azalea') {
      rect(7, 10, 2, 6, '#6e5032'); rect(2, 4, 12, 7, '#4f7a32'); rect(4, 2, 8, 8, '#629440');
      if (name === 'flowering_azalea') for (const [bx, by] of [[4, 4], [10, 5], [6, 7], [9, 3]]) rect(bx, by, 2, 2, '#df78b8');
    } else if (name === 'cocoa') {
      rect(5, 4, 6, 9, '#8c4c20'); rect(6, 5, 4, 7, '#ad622c'); rect(7, 2, 2, 2, '#5c8a32');
    } else if (name.endsWith('_coral')) {
      for (let i = 0; i < 6; i++) {
        const x = 2 + i * 2, h = 5 + ((i * 3) % 7);
        rect(x, 15 - h, 2, h, i % 2 ? base : shade(base, 25));
      }
      rect(3, 13, 10, 3, shade(base, -18));
    } else if (name === 'big_dripleaf' || name === 'small_dripleaf') {
      rect(7, 6, 2, 10, '#4f852e'); rect(2, 3, 12, 4, '#5ea136'); rect(4, 4, 8, 2, '#7bc24c');
    } else if (name === 'spore_blossom') {
      rect(4, 2, 8, 4, '#4e7d34'); rect(3, 5, 10, 6, '#d96cb0'); rect(5, 7, 6, 3, '#f29ed2'); rect(7, 8, 2, 2, '#f5d24a');
    } else if (name === 'hanging_roots') {
      for (const x of [3, 6, 9, 12]) rect(x, 0, 1, 7 + (x % 5), '#9e7254');
    } else if (name === 'cobweb') {
      for (let i = 0; i < 16; i++) { rect(i, i, 1, 1, 'rgba(235,240,242,0.85)'); rect(15 - i, i, 1, 1, 'rgba(235,240,242,0.85)'); }
      rect(7, 0, 2, 16, 'rgba(235,240,242,0.7)'); rect(0, 7, 16, 2, 'rgba(235,240,242,0.7)');
    } else if (name.includes('mushroom')) {
      rect(7, 10, 2, 6, '#dcd3be'); rect(4, 6, 8, 4, base); rect(5, 4, 6, 2, base);
      if (name.includes('red')) { rect(5, 7, 2, 1, '#f4f2ea'); rect(9, 6, 2, 1, '#f4f2ea'); rect(7, 8, 1, 1, '#f4f2ea'); }
    } else if (name.includes('sapling')) {
      rect(7, 10, 2, 6, '#6e5032'); rect(4, 4, 8, 6, shade(base, -15)); rect(5, 3, 6, 6, base); rect(6, 4, 3, 2, shade(base, 22));
    } else if (name === 'short_grass' || name === 'fern' || name === 'tall_grass' || name === 'large_fern' || name === 'jungle_fern' || name === 'wheat_crop' || name === 'carrots' || name === 'potatoes' || name === 'beetroots' || name === 'pumpkin_stem' || name === 'melon_stem') {
      const grayscale = name === 'short_grass' || name === 'fern' || name === 'tall_grass' || name === 'large_fern' || name === 'jungle_fern';
      const isFern = name.includes('fern');
      const blades = isFern ? 8 : 7;
      for (let i = 0; i < blades; i++) {
        const x = 1 + i * 2, h = (name === 'tall_grass' || name === 'large_fern' ? 9 : 4) + Math.floor(rnd() * 6);
        const c1 = grayscale ? (i % 2 ? '#b6b6b6' : '#8e8e8e') : shade(base, i % 2 ? 16 : -20);
        const c2 = grayscale ? '#a8a8a8' : shade(base, 12);
        rect(x, Math.max(1, 16 - h), 1, Math.min(15, h), c1);
        if (isFern) { rect(x - 1, Math.max(1, 16 - h + 2), 3, 1, c2); rect(x - 1, Math.max(1, 16 - h + 5), 3, 1, grayscale ? '#8a8a8a' : shade(base, -10)); }
        else rect(x - 1, Math.max(1, 15 - h), 1, 3, c2);
      }
    } else if (name === 'lily_of_the_valley') {
      rect(7, 4, 1, 12, '#54853b'); rect(4, 9, 3, 4, '#639746'); rect(9, 8, 3, 5, '#639746');
      for (const [bx, by] of [[5, 4], [8, 6], [5, 7]]) { rect(bx, by, 2, 2, '#ffffff'); rect(bx, by + 1, 2, 1, '#dbe5dd'); }
    } else if (name.includes('tulip')) {
      rect(7, 8, 2, 8, '#4e7d38'); rect(5, 10, 2, 4, '#629444'); rect(9, 9, 2, 4, '#629444');
      rect(5, 3, 6, 5, base); rect(5, 2, 1, 2, shade(base, 22)); rect(7, 2, 2, 2, shade(base, 22)); rect(10, 2, 1, 2, shade(base, 22));
    } else if (name === 'cornflower') {
      rect(7, 8, 2, 8, '#4b7a38'); rect(5, 10, 3, 2, '#629444'); rect(4, 3, 8, 5, '#3d62c4'); rect(5, 2, 6, 6, '#5880e4'); rect(7, 4, 2, 2, '#243b82');
    } else if (name === 'oxeye_daisy') {
      rect(7, 8, 2, 8, '#4b7a38'); rect(4, 4, 8, 4, '#f4f2ea'); rect(5, 3, 6, 6, '#ffffff'); rect(7, 5, 2, 2, '#ebc23d');
    } else if (name === 'dandelion') {
      rect(7, 8, 2, 8, '#4c7939'); rect(4, 11, 4, 2, '#649442'); rect(5, 3, 6, 5, '#e6be32'); rect(4, 4, 8, 3, '#f7d954'); rect(6, 2, 4, 6, '#fae373');
    } else {
      rect(7, 7, 2, 9, '#4c7939'); rect(4, 11, 4, 2, '#649442'); rect(9, 9, 3, 2, '#75a347');
      rect(5, 3, 6, 5, shade(base, -25)); rect(4, 4, 8, 3, base); rect(6, 2, 4, 7, shade(base, 14)); rect(7, 4, 2, 2, '#2b2421');
    }
  }
  if (pattern === 'craft') {
    rect(0, 0, 16, 16, '#a27c4b');
    if (name === 'crafting_table_top') {
      rect(0, 0, 16, 2, '#4c361e'); rect(0, 14, 16, 2, '#4c361e'); rect(0, 0, 2, 16, '#4c361e'); rect(14, 0, 2, 16, '#4c361e');
      rect(3, 3, 10, 10, '#bf965c');
      // 3x3 checkered crafting grid
      for (let gy = 3; gy <= 13; gy += 3) rect(3, gy, 10, 1, '#624628');
      for (let gx = 3; gx <= 13; gx += 3) rect(gx, 3, 1, 10, '#624628');
      // Saw & chisel motif
      rect(4, 4, 2, 1, '#dedede'); rect(5, 5, 1, 2, '#7a5a3a');
    } else {
      // Crafting table side with hanging saw and pliers
      rect(0, 0, 16, 16, '#966f3e');
      rect(0, 0, 16, 1, '#b58b52'); rect(0, 15, 16, 1, '#4c361e');
      rect(0, 0, 1, 16, '#b58b52'); rect(15, 0, 1, 16, '#4c361e');
      // Tool hanger board
      rect(2, 3, 12, 10, '#7c582c');
      rect(3, 4, 10, 8, '#5c401f');
      // Hanging hand saw
      rect(4, 5, 4, 1, '#3b3b3b'); rect(4, 6, 1, 3, '#c4c4c4'); rect(5, 7, 1, 2, '#c4c4c4');
      // Hanging shears/pliers
      rect(10, 5, 2, 2, '#3b3b3b'); rect(10, 7, 1, 3, '#c4c4c4'); rect(11, 8, 1, 2, '#c4c4c4');
    }
  }
  if (pattern === 'furnace') {
    rect(0, 0, 16, 16, '#727272');
    rect(0, 0, 16, 1, '#8e8e8e'); rect(0, 15, 16, 1, '#3c3c3c');
    rect(0, 0, 1, 16, '#8e8e8e'); rect(15, 0, 1, 16, '#3c3c3c');
    // Stone block face frame
    rect(2, 2, 12, 12, '#525252');
    // Top arch lintel
    rect(3, 3, 10, 2, '#363636');
    // Dark combustion chamber opening
    rect(3, 7, 10, 6, '#181818');
    rect(4, 8, 8, 4, '#101010');
    rect(4, 12, 8, 1, '#2c2c2c');
    if (name.startsWith('blast')) {
      rect(2, 2, 12, 4, '#2c3330'); rect(3, 3, 10, 2, '#85968f');
    }
    if (name.startsWith('smoker')) {
      rect(2, 2, 12, 4, '#4a3826'); rect(3, 3, 10, 2, '#2e2216');
    }
  }
  if (pattern === 'chest') {
    rect(0, 0, 16, 16, '#8e6634');
    // Outer darker oak frame
    rect(0, 0, 16, 1, '#b8894c'); rect(0, 15, 16, 1, '#4c3315');
    rect(0, 0, 1, 16, '#b8894c'); rect(15, 0, 1, 16, '#4c3315');
    rect(1, 1, 14, 14, '#9c723d');
    // Horizontal lid opening gap line
    rect(1, 5, 14, 1, '#2e1e0a');
    // 3D Silver Lock Latch in center
    rect(7, 4, 2, 4, '#e2e2e2');
    rect(7, 4, 2, 1, '#ffffff');
    rect(7, 7, 2, 1, '#8c8c8c');
    rect(8, 5, 1, 2, '#3b3b3b'); // Keyhole
    if (name === 'barrel_front') {
      rect(0, 2, 16, 2, '#5c3e1e'); rect(0, 11, 16, 2, '#5c3e1e'); rect(6, 7, 4, 3, '#c8c2a6');
    }
  }
  if (pattern === 'metal') {
    if (name.endsWith('_helmet')) { ctx.clearRect(0, 0, 16, 16); rect(3, 3, 10, 7, base); rect(4, 3, 8, 2, shade(base, 28)); rect(3, 8, 3, 3, shade(base, -22)); rect(10, 8, 3, 3, shade(base, -22)); }
    else if (name.endsWith('_chestplate')) { ctx.clearRect(0, 0, 16, 16); rect(2, 3, 12, 9, base); rect(4, 3, 8, 11, shade(base, 14)); ctx.clearRect(6, 3, 4, 2); }
    else if (name.endsWith('_leggings')) { ctx.clearRect(0, 0, 16, 16); rect(4, 3, 3, 11, base); rect(9, 3, 3, 11, base); rect(4, 3, 8, 3, shade(base, 20)); }
    else if (name.endsWith('_boots')) { ctx.clearRect(0, 0, 16, 16); rect(2, 7, 5, 6, base); rect(9, 7, 5, 6, base); rect(2, 12, 5, 2, shade(base, -25)); rect(9, 12, 5, 2, shade(base, -25)); }
    else if (name.endsWith('_ingot') || name === 'brick' || name === 'nether_brick' || name === 'netherite_upgrade' || name === 'heavy_core') {
      ctx.clearRect(0, 0, 16, 16); rect(2, 5, 12, 6, shade(base, -45)); rect(2, 4, 11, 6, base); rect(3, 3, 9, 2, shade(base, 35)); rect(3, 9, 10, 2, shade(base, -20));
    } else if (name === 'chain') {
      ctx.clearRect(0, 0, 16, 16);
      for (const y of [0, 4, 8, 12]) {
        rect(6, y, 4, 4, '#4a5054');
        rect(7, y, 2, 4, '#8a9296');
        ctx.clearRect(7, y + 1, 2, 2);
      }
    } else {
      rect(0, 0, 16, 16, base);
      rect(0, 0, 16, 1, shade(base, 28)); rect(0, 0, 1, 16, shade(base, 28));
      rect(0, 15, 16, 1, shade(base, -28)); rect(15, 0, 1, 16, shade(base, -28));
      for (let i = 1; i < 15; i += 3) {
        rect(i, 1, 2, 14, shade(base, (i % 2 ? 14 : -10)));
      }
      rect(2, 2, 12, 1, shade(base, 22));
      rect(2, 13, 12, 1, shade(base, -18));
    }
  }
  if (pattern === 'gem') {
    ctx.clearRect(0, 0, 16, 16);
    for (let y = 3; y < 13; y++) { const w = y < 7 ? (y - 2) * 2 : 12 - (y - 7) * 2; rect(8 - w / 2, y, w, 1, shade(base, ((y % 3) - 1) * 29)); }
    rect(6, 4, 2, 2, shade(base, 65));
  }
  if (pattern === 'food') {
    ctx.clearRect(0, 0, 16, 16);
    rect(4, 4, 8, 9, shade(base, -20)); rect(3, 5, 10, 6, base); rect(5, 3, 6, 11, base); rect(5, 4, 3, 2, shade(base, 45));
    rect(8, 1, 1, 3, '#735138'); rect(9, 1, 3, 2, '#6b9547');
  }
  return c;
}

function drawItem(def: BlockDef): DrawCanvas {
  const c = canvas(16), ctx = c.getContext('2d') as Context2D;
  const r = (x: number, y: number, w: number, h: number, col: string) => { ctx.fillStyle = col; ctx.fillRect(x, y, w, h); };

  if (def.name === 'ender_pearl' || def.name === 'ender_eye') {
    r(5, 2, 6, 12, '#0d3d35'); r(3, 4, 10, 8, '#175a4e'); r(4, 3, 8, 10, '#277d6d');
    r(5, 4, 6, 8, '#38a18e'); r(5, 4, 3, 3, '#88f2db');
    if (def.name === 'ender_eye') {
      r(5, 5, 6, 6, '#39b84a'); r(6, 6, 4, 4, '#6cf27e'); r(7, 5, 2, 6, '#14381b'); r(6, 6, 1, 1, '#d8ffdf');
    }
    return c;
  }
  if (def.name === 'blaze_rod') {
    for (let i = 0; i < 11; i++) { r(2 + i, 12 - i, 3, 3, '#b85309'); r(3 + i, 12 - i, 2, 2, '#f5a623'); r(3 + i, 12 - i, 1, 1, '#fff08a'); }
    return c;
  }
  if (def.name === 'blaze_powder') {
    r(5, 6, 6, 6, '#d9480f'); r(4, 8, 8, 5, '#f59f00'); r(6, 4, 4, 5, '#ffd43b'); r(7, 9, 3, 2, '#fff3bf');
    return c;
  }
  if (def.name === 'ghast_tear') {
    r(7, 2, 2, 3, '#cde8eb'); r(6, 5, 4, 4, '#eefbfc'); r(5, 8, 6, 5, '#cde8eb'); r(6, 9, 4, 3, '#ffffff');
    return c;
  }
  if (def.name === 'netherite_scrap') {
    r(3, 5, 10, 6, '#402c27'); r(4, 4, 8, 8, '#5e433c'); r(5, 5, 5, 4, '#806158'); r(6, 6, 2, 2, '#a38076');
    return c;
  }
  if (def.name === 'netherite_ingot') {
    r(2, 5, 12, 6, '#2b2427'); r(3, 4, 10, 6, '#4d4247'); r(4, 4, 8, 2, '#75666c'); r(3, 9, 10, 2, '#3a3135');
    return c;
  }
  if (def.name === 'elytra') {
    r(3, 2, 4, 11, '#585469'); r(9, 2, 4, 11, '#585469');
    r(4, 3, 3, 9, '#7a7591'); r(9, 3, 3, 9, '#7a7591');
    r(2, 4, 3, 8, '#8d88a8'); r(11, 4, 3, 8, '#8d88a8');
    r(6, 2, 4, 3, '#3b3747'); r(3, 12, 2, 2, '#a7a2c2'); r(11, 12, 2, 2, '#a7a2c2');
    return c;
  }
  if (def.name === 'firework_rocket') {
    r(5, 3, 6, 10, '#cf3d32'); r(6, 5, 4, 6, '#f2eee4'); r(5, 2, 6, 2, '#ab2d24');
    r(7, 1, 2, 2, '#e33b2e'); r(7, 13, 2, 3, '#8a673b');
    return c;
  }
  if (def.name === 'end_crystal') {
    r(4, 2, 8, 8, '#e87ee8'); r(5, 3, 6, 6, '#ffc2ff'); r(6, 4, 4, 4, '#b825b8');
    r(3, 11, 10, 3, '#383044'); r(5, 10, 6, 2, '#5c526e');
    return c;
  }
  if (def.name === 'shulker_shell') {
    r(3, 4, 10, 8, '#7a4b7d'); r(4, 5, 8, 6, '#a46fa8'); r(5, 6, 6, 4, '#c292c6');
    return c;
  }
  if (def.name === 'flint_and_steel') {
    r(3, 4, 5, 7, '#646967'); r(4, 5, 3, 5, '#414543');
    r(9, 3, 4, 9, '#c7cfcc'); r(10, 4, 2, 7, '#eef5f2'); r(8, 10, 4, 2, '#8b918f');
    return c;
  }
  if (def.name === 'shears') {
    r(3, 9, 4, 4, '#7d8380'); r(9, 9, 4, 4, '#7d8380');
    r(4, 10, 2, 2, '#222624'); r(10, 10, 2, 2, '#222624');
    r(5, 3, 2, 7, '#d0d7d2'); r(9, 3, 2, 7, '#d0d7d2'); r(7, 7, 2, 2, '#8d928f');
    return c;
  }
  if (def.name === 'nether_star') {
    r(7, 1, 2, 14, '#fffce0'); r(1, 7, 14, 2, '#fffce0');
    r(4, 4, 8, 8, '#e8dff7'); r(5, 5, 6, 6, '#ffffff');
    return c;
  }
  if (def.name === 'dragon_breath') {
    r(6, 2, 4, 2, '#8a6845'); r(5, 4, 6, 2, '#d5ebeb');
    r(4, 6, 8, 8, '#a63ab8'); r(5, 7, 6, 6, '#eb6eff'); r(6, 8, 2, 2, '#ffc9ff');
    return c;
  }

  if (def.pattern !== 'tool' && def.category !== 'tools') return noiseTile(def.name, def.color, tilePattern(def.name, def.pattern), def.id * 973 + 234);
  if (def.name === 'stick' || def.name === 'bone' || def.name === 'feather') {
    for (let i = 0; i < 10; i++) { r(3 + i, 12 - i, 2, 2, shade(def.color, -30)); r(3 + i, 12 - i, 1, 1, def.color); }
    return c;
  }
  if (def.name.includes('bucket')) {
    r(3, 5, 10, 7, '#647779'); r(4, 6, 8, 7, '#b4c3c1'); r(5, 12, 6, 2, '#839795'); r(4, 4, 8, 2, '#d1dad4');
    if (!def.name.startsWith('bucket')) r(5, 5, 6, 2, def.color);
    return c;
  }
  if (/^(potion_|splash_)|_potion$|^water_bottle$|^potion$|^honey_bottle$|^experience_bottle$/.test(def.name)) {
    const splash = def.name.startsWith('splash_');
    r(6, 1, 4, 2, splash ? '#b9b9b9' : '#8a6a42'); r(7, 3, 2, 2, '#dfeff2'); r(5, 5, 6, 1, '#dfeff2'); r(4, 6, 8, 7, '#dfeff2'); r(5, 13, 6, 1, '#dfeff2');
    r(5, 7, 6, 6, def.color); r(5, 7, 2, 2, '#ffffff');
    return c;
  }
  if (def.name === 'shield') { r(3, 1, 10, 11, '#7a5a34'); r(4, 12, 8, 2, '#7a5a34'); r(6, 14, 4, 1, '#7a5a34'); r(3, 1, 10, 1, '#c9cfcc'); r(3, 1, 1, 11, '#c9cfcc'); r(12, 1, 1, 11, '#9aa0a0'); r(7, 4, 2, 6, '#c9cfcc'); return c; }
  if (def.name === 'crossbow') { for (let i = 3; i < 13; i++) r(i, i, 2, 2, '#6b4a2c'); r(2, 7, 2, 6, '#8a6a42'); r(7, 2, 6, 2, '#8a6a42'); r(3, 4, 1, 4, '#dcd8c8'); r(4, 3, 4, 1, '#dcd8c8'); r(12, 12, 2, 2, '#4a4a4a'); return c; }
  if (def.name === 'trident') { for (let i = 2; i < 12; i++) r(13 - i, i + 2, 2, 1, '#3f968a'); r(9, 1, 1, 5, '#7fd6c8'); r(11, 2, 1, 3, '#7fd6c8'); r(13, 4, 1, 4, '#7fd6c8'); r(10, 5, 4, 1, '#7fd6c8'); return c; }
  if (def.name === 'mace') { for (let i = 2; i < 9; i++) r(i, 15 - i, 2, 1, '#8a6a42'); r(8, 2, 6, 6, '#6d6f7c'); r(9, 1, 4, 8, '#7d7f8c'); r(7, 3, 8, 4, '#7d7f8c'); r(10, 3, 2, 2, '#c9cbd6'); return c; }
  if (def.name === 'totem_of_undying') { r(5, 1, 6, 5, '#e8c95a'); r(3, 6, 10, 3, '#e8c95a'); r(6, 9, 4, 5, '#d8b23a'); r(6, 3, 1, 1, '#2f8a4a'); r(9, 3, 1, 1, '#2f8a4a'); r(7, 5, 2, 1, '#8a6a22'); return c; }
  if (def.name === 'enchanted_book') { r(3, 2, 10, 12, '#7a3a9a'); r(4, 3, 8, 10, '#b06ad8'); r(3, 2, 2, 12, '#4a2060'); r(6, 5, 5, 1, '#f1e27a'); r(6, 8, 4, 1, '#f1e27a'); r(11, 12, 2, 2, '#e8e0c8'); return c; }
  if (def.name === 'bow') {
    for (let i = 2; i < 14; i++) { const x = 4 + Math.round(Math.sin(((i - 2) / 11) * Math.PI) * 5); r(x, i, 2, 1, '#7d5a34'); }
    r(4, 2, 1, 12, '#dcd8c8');
    return c;
  }
  if (def.name === 'arrow') {
    for (let i = 2; i < 13; i++) r(i, 14 - i, 2, 1, '#9b7a4a');
    r(12, 1, 3, 3, '#cdd3cf'); r(2, 12, 3, 2, '#efeae0');
    return c;
  }
  if (def.name === 'fishing_rod') {
    for (let i = 2; i < 13; i++) r(i, 14 - i, 2, 2, '#8a6539');
    r(13, 4, 1, 9, '#e4e2d8'); r(12, 12, 3, 2, '#d94e3f');
    return c;
  }
  if (def.name === 'boat') {
    r(2, 7, 12, 5, '#9c7744'); r(3, 11, 10, 2, '#7c5b31'); r(4, 8, 8, 2, '#be965b');
    return c;
  }
  if (def.name === 'saddle') {
    r(3, 3, 3, 5, '#75492f'); r(10, 3, 3, 5, '#75492f'); r(4, 6, 8, 6, '#a76f43'); r(5, 7, 6, 2, '#c39260');
    r(2, 9, 2, 5, '#674533'); r(12, 9, 2, 5, '#674533'); r(1, 12, 4, 2, '#b9b9a5'); r(11, 12, 4, 2, '#b9b9a5');
    return c;
  }
  if (def.name === 'lead') {
    r(2, 4, 2, 6, '#aa8557'); r(4, 2, 6, 2, '#c09c65'); r(10, 4, 2, 6, '#aa8557'); r(4, 10, 6, 2, '#87623e');
    r(9, 9, 2, 2, '#d2ae77'); r(10, 11, 2, 2, '#b9905b'); r(12, 12, 2, 3, '#9c7246');
    return c;
  }
  if (def.name === 'minecart') {
    r(2, 5, 12, 7, '#757d7a'); r(3, 6, 10, 5, '#9ca5a1'); r(4, 12, 2, 2, '#424745'); r(10, 12, 2, 2, '#424745');
    return c;
  }
  if (def.name === 'book' || def.name === 'paper' || def.name === 'sign') {
    r(3, 3, 10, 10, def.color); r(4, 4, 8, 8, shade(def.color, 24));
    if (def.name === 'sign') r(7, 12, 2, 4, '#7c5b34');
    return c;
  }
  const type = def.name.split('_').pop() || 'pickaxe', col = def.color;
  if (type === 'sword') {
    for (let i = 0; i < 9; i++) { r(5 + i, 10 - i, 3, 2, shade(col, -35)); r(5 + i, 10 - i, 2, 1, shade(col, 20)); }
    r(3, 10, 5, 2, '#746041'); r(6, 12, 2, 3, '#8c683e'); r(2, 9, 2, 3, '#a58b50'); r(7, 13, 2, 2, '#a58b50');
  } else {
    for (let i = 0; i < 9; i++) { r(3 + i, 12 - i, 2, 2, '#61472d'); r(3 + i, 12 - i, 1, 1, '#b18a51'); }
    if (type === 'pickaxe') { r(4, 2, 8, 2, shade(col, -30)); r(7, 1, 6, 2, col); r(11, 3, 3, 3, col); r(13, 5, 2, 3, shade(col, -25)); r(5, 2, 6, 1, shade(col, 35)); }
    if (type === 'axe') { r(7, 1, 5, 5, shade(col, -25)); r(6, 2, 6, 3, col); r(7, 2, 4, 1, shade(col, 30)); }
    if (type === 'shovel') { r(10, 1, 4, 5, col); r(9, 2, 5, 3, col); r(10, 1, 3, 1, shade(col, 30)); }
    if (type === 'hoe') { r(6, 2, 7, 2, col); r(12, 3, 2, 3, shade(col, -25)); }
  }
  return c;
}

function addTile(name: string, c: DrawCanvas) {
  if (tileIndex.has(name)) return;
  tileIndex.set(name, tileNames.length);
  tileNames.push(name);
  tileCanvases.set(name, c);
}

for (const b of BLOCKS) {
  if (!b.id) continue;
  const faces = new Set([0, 1, 2, 3, 4, 5].map(f => faceTile(b, f)));
  for (const name of faces) {
    // A face tile may reference another block (e.g. grass_block bottom -> 'dirt').
    // Draw it with the REFERENCED block's own color & pattern so shared tiles
    // (dirt!) never get poisoned by the first block that claims them.
    const refId = ID[name];
    const ref = refId !== undefined && BLOCKS[refId] !== b ? BLOCKS[refId] : undefined;
    const sideOverlay = !ref && name.endsWith('_side') && ['grass_block', 'mycelium', 'podzol'].includes(b.name);
    const base = ref ? ref.color : sideOverlay ? '#8a6244' : b.color;
    const pattern = ref ? ref.pattern : tilePattern(name, b.pattern);
    const c = noiseTile(name, base, pattern, (ref ? ref.id : b.id) * 973 + name.length * 41);
    if (sideOverlay) {
      const ctx = c.getContext('2d') as Context2D;
      const drips = [3, 4, 3, 2, 4, 3, 3, 5, 2, 3, 4, 3, 2, 4, 3, 3];
      const isPodzol = b.name === 'podzol', isMyc = b.name === 'mycelium';
      for (let x = 0; x < 16; x++) {
        const d = drips[x];
        ctx.fillStyle = isPodzol ? ((x + d) % 2 === 0 ? '#6e4927' : '#855b33') : isMyc ? ((x + d) % 2 === 0 ? '#7d6e7f' : '#948596') : ((x + d) % 2 === 0 ? '#7ca838' : '#8ebb42');
        ctx.fillRect(x, 0, 1, d);
        ctx.fillStyle = isPodzol ? '#966b3f' : isMyc ? '#a89aaa' : '#a2cf52';
        ctx.fillRect(x, 0, 1, 1);
        ctx.fillStyle = '#4c331c';
        ctx.fillRect(x, d, 1, 1);
      }
    }
    addTile(name, c);
  }
}

function doorIcon(b: BlockDef): DrawCanvas {
  const c = canvas(16), ctx = c.getContext('2d') as Context2D, col = b.color, iron = b.name.startsWith('iron');
  const r = (x: number, y: number, w: number, h: number, k: string) => { ctx.fillStyle = k; ctx.fillRect(x, y, w, h); };
  r(4, 0, 8, 16, shade(col, -40)); r(5, 1, 6, 14, col); r(5, 1, 1, 14, shade(col, 20));
  if (iron || /^(oak|jungle|acacia|cherry)_/.test(b.name)) {
    r(6, 2, 4, 5, shade(col, -40));
    r(6, 2, 2, 2, '#c4e6f0'); r(8, 2, 2, 2, '#a9d6e4'); r(6, 5, 2, 2, '#a9d6e4'); r(8, 5, 2, 2, '#c4e6f0');
  } else r(6, 2, 4, 4, shade(col, -18));
  r(6, 9, 4, 5, shade(col, -18)); r(7, 10, 2, 3, shade(col, 12));
  r(9, 8, 1, 1, iron ? '#596165' : '#2a2622');
  return c;
}
function buttonIcon(b: BlockDef): DrawCanvas {
  const c = canvas(16), ctx = c.getContext('2d') as Context2D, col = b.color;
  const r = (x: number, y: number, w: number, h: number, k: string) => { ctx.fillStyle = k; ctx.fillRect(x, y, w, h); };
  r(5, 6, 6, 5, shade(col, -42)); r(5, 6, 6, 4, col); r(5, 6, 6, 1, shade(col, 24)); r(5, 7, 1, 3, shade(col, 12));
  return c;
}
for (const b of BLOCKS) {
  if (b.name.endsWith('_door') && !b.name.startsWith('open_')) addTile(b.name, doorIcon(b));
  else if (b.name.endsWith('_button')) addTile(b.name, buttonIcon(b));
}

for (const it of ITEMS) addTile(it.name, drawItem(it));
for (let i = 0; i < 10; i++) {
  const c = canvas(16), ctx = c.getContext('2d') as Context2D;
  ctx.strokeStyle = 'rgba(31,27,22,.8)'; ctx.lineWidth = 1;
  const rnd = random(567);
  for (let j = 0; j <= i + 2; j++) {
    ctx.beginPath(); let x = 8, y = 8; ctx.moveTo(x, y);
    for (let k = 0; k < 3 + i; k++) { x += Math.floor(rnd() * 5) - 2; y += Math.floor(rnd() * 5) - 2; ctx.lineTo(x, y); }
    ctx.stroke();
  }
  addTile('crack_' + i, c);
}

export const atlasRows = Math.ceil(tileNames.length / ATLAS_COLS);
export const atlasCanvas = canvas(ATLAS_COLS * TILE, atlasRows * TILE);
const atlasContext = atlasCanvas.getContext('2d') as Context2D;
for (let i = 0; i < tileNames.length; i++) {
  const c = tileCanvases.get(tileNames[i])!, x = (i % ATLAS_COLS) * TILE, y = Math.floor(i / ATLAS_COLS) * TILE;
  atlasContext.drawImage(c, x + 2, y + 2);
  atlasContext.drawImage(c, 0, 0, 16, 1, x + 2, y, 16, 2);
  atlasContext.drawImage(c, 0, 15, 16, 1, x + 2, y + 18, 16, 2);
  atlasContext.drawImage(c, 0, 0, 1, 16, x, y + 2, 2, 16);
  atlasContext.drawImage(c, 15, 0, 1, 16, x + 18, y + 2, 2, 16);
  atlasContext.drawImage(c, 0, 0, 1, 1, x, y, 2, 2);
  atlasContext.drawImage(c, 15, 0, 1, 1, x + 18, y, 2, 2);
  atlasContext.drawImage(c, 0, 15, 1, 1, x, y + 18, 2, 2);
  atlasContext.drawImage(c, 15, 15, 1, 1, x + 18, y + 18, 2, 2);
}

export function makeAtlasTexture() {
  const t = new THREE.CanvasTexture(atlasCanvas as HTMLCanvasElement);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.flipY = false;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/**
 * WebGL2 Texture2DArray containing every 16x16 tile in its own layer.
 * - Native hardware RepeatWrapping works across greedy-meshed quads (zero fract() seam artifacts).
 * - NearestMipmapLinearFilter + hardware mipmaps completely eliminate distant pixel shimmering/noise while keeping pixels crisp close up.
 * - Transparent texels inherit neighbor opaque RGB so mipmap downsampling never bleeds black halos.
 */
export function makeAtlasDataArray(anisotropy = 8): THREE.DataArrayTexture {
  const depth = tileNames.length;
  const layerSize = 16 * 16 * 4;
  const data = new Uint8Array(layerSize * depth);
  const mask = new Uint8Array(256);
  const nextMask = new Uint8Array(256);
  for (let i = 0; i < depth; i++) {
    const c = tileCanvases.get(tileNames[i])!;
    const ctx = c.getContext('2d') as Context2D;
    const px = ctx.getImageData(0, 0, 16, 16).data;
    const off = i * layerSize;
    data.set(px, off);
    let avgR = 0, avgG = 0, avgB = 0, cnt = 0;
    for (let k = 0; k < 256; k++) {
      if (px[k * 4 + 3] > 20) {
        avgR += px[k * 4]; avgG += px[k * 4 + 1]; avgB += px[k * 4 + 2]; cnt++;
        mask[k] = 1;
      } else {
        mask[k] = 0;
      }
    }
    if (cnt > 0 && cnt < 256) {
      // Multi-pass 8-neighbor RGB dilation so cutout mipmaps inherit exact border colors without dark fringes
      for (let pass = 0; pass < 4; pass++) {
        nextMask.set(mask);
        for (let y = 0; y < 16; y++) {
          for (let x = 0; x < 16; x++) {
            const k = y * 16 + x;
            if (mask[k]) continue;
            let sr = 0, sg = 0, sb = 0, sc = 0;
            for (let dy = -1; dy <= 1; dy++) {
              const ny = (y + dy + 16) & 15;
              for (let dx = -1; dx <= 1; dx++) {
                if (dx === 0 && dy === 0) continue;
                const nx = (x + dx + 16) & 15;
                const nk = ny * 16 + nx;
                if (mask[nk]) {
                  sr += data[off + nk * 4];
                  sg += data[off + nk * 4 + 1];
                  sb += data[off + nk * 4 + 2];
                  sc++;
                }
              }
            }
            if (sc > 0) {
              data[off + k * 4] = Math.round(sr / sc);
              data[off + k * 4 + 1] = Math.round(sg / sc);
              data[off + k * 4 + 2] = Math.round(sb / sc);
              nextMask[k] = 1;
            }
          }
        }
        mask.set(nextMask);
      }
      avgR = Math.round(avgR / cnt); avgG = Math.round(avgG / cnt); avgB = Math.round(avgB / cnt);
      for (let k = 0; k < 256; k++) {
        if (!mask[k]) {
          data[off + k * 4] = avgR;
          data[off + k * 4 + 1] = avgG;
          data[off + k * 4 + 2] = avgB;
        }
      }
    }
  }
  const tex = new THREE.DataArrayTexture(data, 16, 16, depth);
  tex.format = THREE.RGBAFormat;
  tex.type = THREE.UnsignedByteType;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.anisotropy = anisotropy;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function tileOf(name: string) { return tileIndex.get(name) ?? tileIndex.get('stone') ?? 0; }
export function tilesFor(id: number) { const b = BLOCKS[id]; return [0, 1, 2, 3, 4, 5].map(f => tileOf(faceTile(b, f))); }
function toDataURL(c: DrawCanvas) { return (c as HTMLCanvasElement).toDataURL?.() ?? ''; }

const iconCache = new Map<string, string>();

function shadeOverlay(ctx: Context2D, alpha: number, x0: number, y0: number, x1: number, y1: number, x2: number, y2: number, x3: number, y3: number) {
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = `rgba(0,0,0,${alpha})`;
  ctx.beginPath();
  ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.lineTo(x2, y2); ctx.lineTo(x3, y3); ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawIsoSubBox(
  ctx: Context2D,
  topTex: DrawCanvas,
  frontTex: DrawCanvas,
  sideTex: DrawCanvas,
  x0: number, y0: number, z0: number,
  x1: number, y1: number, z1: number,
) {
  const cx = 24, cy = 24;
  const proj = (X: number, Y: number, Z: number): [number, number] => [
    cx + (X - Z) * 18,
    cy - 19.5 + (X + Z) * 9.5 + (1 - Y) * 20,
  ];
  const dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
  const [tbx, tby] = proj(x0, y1, z0);
  const [trx, try_] = proj(x1, y1, z0);
  const [tlx, tly] = proj(x0, y1, z1);
  const [tcx, tcy] = proj(x1, y1, z1);
  const [bcx, bcy] = proj(x1, y0, z1);
  const [blx, bly] = proj(x0, y0, z1);
  const [brx, bry] = proj(x1, y0, z0);

  ctx.imageSmoothingEnabled = false;

  // Top face (+Y)
  ctx.save();
  ctx.setTransform((trx - tbx) / 16, (try_ - tby) / 16, (tlx - tbx) / 16, (tly - tby) / 16, tbx, tby);
  ctx.drawImage(topTex, 0, 0, 16, 16, 0, 0, 16, 16);
  ctx.restore();

  // Left / Front face (+Z, at z = z1)
  ctx.save();
  ctx.setTransform((tcx - tlx) / 16, (tcy - tly) / 16, 0, (bly - tly) / 16, tlx, tly);
  ctx.drawImage(frontTex, 0, 0, Math.max(1, Math.round(dx * 16)), Math.max(1, Math.round(dy * 16)), 0, 0, 16, 16);
  ctx.restore();
  shadeOverlay(ctx, 0.2, tlx, tly, tcx, tcy, bcx, bcy, blx, bly);

  // Right / Side face (+X, at x = x1)
  ctx.save();
  ctx.setTransform((trx - tcx) / 16, (try_ - tcy) / 16, 0, (bcy - tcy) / 16, tcx, tcy);
  ctx.drawImage(sideTex, 0, 0, Math.max(1, Math.round(dz * 16)), Math.max(1, Math.round(dy * 16)), 0, 0, 16, 16);
  ctx.restore();
  shadeOverlay(ctx, 0.38, tcx, tcy, trx, try_, brx, bry, bcx, bcy);
}

function renderBlockIcon3D(b: BlockDef): DrawCanvas | undefined {
  if (typeof document === 'undefined') return undefined;
  const flatShapes = new Set(['cross', 'torch', 'door', 'lily', 'pane', 'end_rod', 'trapdoor']);
  if (flatShapes.has(b.shape)) {
    if (b.name === 'portal' || b.name === 'end_portal' || b.name === 'end_gateway') {
      const c = canvas(48), ctx = c.getContext('2d') as Context2D;
      ctx.fillStyle = b.name === 'portal' ? '#8c48d8' : '#121d26';
      ctx.fillRect(8, 8, 32, 32);
      ctx.fillStyle = b.name === 'portal' ? '#c27dff' : '#40d9b8';
      ctx.fillRect(14, 14, 20, 20);
      return c;
    }
    return undefined;
  }

  const c = canvas(48), ctx = c.getContext('2d') as Context2D;
  ctx.imageSmoothingEnabled = false;

  if (b.name === 'bed') {
    const redTex = tileCanvases.get('red_wool') ?? tileCanvases.get('bed_top')!;
    const whiteTex = tileCanvases.get('white_wool')!;
    const oakTex = tileCanvases.get('oak_planks')!;
    drawIsoSubBox(ctx, oakTex, oakTex, oakTex, 0.05, 0.08, 0.05, 0.95, 0.24, 0.95);
    drawIsoSubBox(ctx, whiteTex, whiteTex, whiteTex, 0.05, 0.24, 0.05, 0.95, 0.62, 0.42);
    drawIsoSubBox(ctx, redTex, redTex, redTex, 0.05, 0.24, 0.38, 0.95, 0.56, 0.95);
    return c;
  }

  const top = uiTileCanvas(faceTile(b, 2)) ?? uiTileCanvas('stone')!;
  const front = uiTileCanvas(faceTile(b, 4)) ?? top;
  const side = uiTileCanvas(faceTile(b, 0)) ?? front;

  if (b.name === 'lectern') {
    const plank = uiTileCanvas('oak_planks')!;
    const shelf = uiTileCanvas('bookshelf') ?? plank;
    const red = uiTileCanvas('red_wool')!;
    const page = uiTileCanvas('white_wool')!;
    drawIsoSubBox(ctx, plank, plank, plank, 0, 0, 0, 1, 2 / 16, 1);
    drawIsoSubBox(ctx, plank, shelf, plank, 4 / 16, 2 / 16, 4 / 16, 12 / 16, 11 / 16, 12 / 16);
    drawIsoSubBox(ctx, plank, plank, plank, 1 / 16, 10 / 16, 1 / 16, 15 / 16, 14 / 16, 15 / 16);
    drawIsoSubBox(ctx, red, red, red, 2 / 16, 14 / 16, 2 / 16, 14 / 16, 15 / 16, 13 / 16);
    drawIsoSubBox(ctx, page, page, page, 3 / 16, 14.8 / 16, 3 / 16, 13 / 16, 16 / 16, 12 / 16);
    return c;
  }
  if (b.name === 'bell') {
    const stone = uiTileCanvas('stone')!;
    const wood = uiTileCanvas('dark_oak_planks') ?? uiTileCanvas('oak_planks')!;
    const gold = uiTileCanvas('gold_block') ?? top;
    drawIsoSubBox(ctx, stone, stone, stone, 1 / 16, 0, 6 / 16, 3 / 16, 15 / 16, 10 / 16);
    drawIsoSubBox(ctx, stone, stone, stone, 13 / 16, 0, 6 / 16, 15 / 16, 15 / 16, 10 / 16);
    drawIsoSubBox(ctx, wood, wood, wood, 1 / 16, 13 / 16, 6 / 16, 15 / 16, 15 / 16, 10 / 16);
    drawIsoSubBox(ctx, gold, gold, gold, 4 / 16, 3 / 16, 4 / 16, 12 / 16, 5 / 16, 12 / 16);
    drawIsoSubBox(ctx, gold, gold, gold, 5 / 16, 5 / 16, 5 / 16, 11 / 16, 12 / 16, 11 / 16);
    return c;
  }
  if (b.shape === 'brewing_stand' || b.name === 'brewing_stand') {
    const cobble = uiTileCanvas('cobblestone')!;
    const gold = uiTileCanvas('gold_block') ?? top;
    const potion = uiTileCanvas('red_wool')!;
    drawIsoSubBox(ctx, cobble, cobble, cobble, 1 / 16, 0, 9 / 16, 7 / 16, 2 / 16, 15 / 16);
    drawIsoSubBox(ctx, cobble, cobble, cobble, 9 / 16, 0, 9 / 16, 15 / 16, 2 / 16, 15 / 16);
    drawIsoSubBox(ctx, cobble, cobble, cobble, 5 / 16, 0, 1 / 16, 11 / 16, 2 / 16, 7 / 16);
    drawIsoSubBox(ctx, potion, potion, potion, 3 / 16, 2 / 16, 10 / 16, 6 / 16, 7 / 16, 13 / 16);
    drawIsoSubBox(ctx, potion, potion, potion, 10 / 16, 2 / 16, 10 / 16, 13 / 16, 7 / 16, 13 / 16);
    drawIsoSubBox(ctx, gold, gold, gold, 7 / 16, 0, 7 / 16, 9 / 16, 14 / 16, 9 / 16);
    return c;
  }

  if (b.shape === 'slab') {
    drawIsoSubBox(ctx, top, front, side, 0, 0, 0, 1, 0.5, 1);
    return c;
  }
  if (b.shape === 'stairs') {
    drawIsoSubBox(ctx, top, front, side, 0, 0, 0, 1, 0.5, 1);
    drawIsoSubBox(ctx, top, front, side, 0, 0.5, 0, 1, 1, 0.5);
    return c;
  }
  if (b.shape === 'cactus' || b.shape === 'chest' || b.shape === 'shulker_box') {
    drawIsoSubBox(ctx, top, front, side, 1 / 16, 0, 1 / 16, 15 / 16, 14 / 16, 15 / 16);
    return c;
  }
  if (b.shape === 'end_portal_frame') {
    drawIsoSubBox(ctx, top, front, side, 0, 0, 0, 1, 13 / 16, 1);
    return c;
  }
  if (b.shape === 'dragon_egg') {
    drawIsoSubBox(ctx, top, front, side, 3 / 16, 0, 3 / 16, 13 / 16, 4 / 16, 13 / 16);
    drawIsoSubBox(ctx, top, front, side, 2 / 16, 4 / 16, 2 / 16, 14 / 16, 11 / 16, 14 / 16);
    drawIsoSubBox(ctx, top, front, side, 4 / 16, 11 / 16, 4 / 16, 12 / 16, 15 / 16, 12 / 16);
    return c;
  }
  if (b.shape === 'fence') {
    drawIsoSubBox(ctx, top, front, side, 0.32, 0, 0.32, 0.68, 1, 0.68);
    return c;
  }
  if (b.shape === 'lantern') {
    drawIsoSubBox(ctx, top, front, side, 5 / 16, 0, 5 / 16, 11 / 16, 7 / 16, 11 / 16);
    drawIsoSubBox(ctx, top, front, side, 6 / 16, 7 / 16, 6 / 16, 10 / 16, 9 / 16, 10 / 16);
    return c;
  }
  if (b.shape === 'enchanting_table') {
    drawIsoSubBox(ctx, top, front, side, 0, 0, 0, 1, 12 / 16, 1);
    const redTex = tileCanvases.get('red_wool')!;
    drawIsoSubBox(ctx, redTex, redTex, redTex, 4 / 16, 12 / 16, 4 / 16, 12 / 16, 15 / 16, 12 / 16);
    return c;
  }
  if (b.shape === 'anvil') {
    drawIsoSubBox(ctx, top, front, side, 2 / 16, 0, 2 / 16, 14 / 16, 4 / 16, 14 / 16);
    drawIsoSubBox(ctx, top, front, side, 4 / 16, 4 / 16, 5 / 16, 12 / 16, 10 / 16, 11 / 16);
    drawIsoSubBox(ctx, top, front, side, 0, 10 / 16, 3 / 16, 1, 1, 13 / 16);
    return c;
  }

  drawIsoSubBox(ctx, top, front, side, 0, 0, 0, 1, 1, 1);
  return c;
}

const UI_TINT_HEX: Record<string, string> = {
  grass_block: '#83b846',
  short_grass: '#79b546',
  tall_grass: '#79b546',
  fern: '#659e3e',
  large_fern: '#659e3e',
  jungle_fern: '#579c3f',
  oak_leaves: '#5c963b',
  jungle_leaves: '#579c3f',
  acacia_leaves: '#8ea149',
  dark_oak_leaves: '#4c7a34',
  mangrove_leaves: '#669442',
  sugar_cane: '#85c258',
  vine: '#548f36',
};
const uiTintedCache = new Map<string, DrawCanvas>();

/**
 * Returns a UI/hand-ready canvas for a tile name, multiplying grayscale biome-tinted tiles
 * (grass_block top, oak/jungle/acacia/dark_oak/mangrove leaves, grass, ferns, vines, sugar_cane)
 * by their lush vanilla inventory green so held blocks and 2D icons are never gray.
 */
export function uiTileCanvas(name: string): DrawCanvas | undefined {
  const cached = uiTintedCache.get(name);
  if (cached) return cached;
  const raw = tileCanvases.get(name);
  if (!raw) return undefined;
  const tintHex = UI_TINT_HEX[name];
  if (!tintHex) return raw;
  const [tr, tg, tb] = rgb(tintHex);
  const c = canvas(raw.width, raw.height);
  const ctx = c.getContext('2d') as Context2D;
  const rawCtx = raw.getContext('2d') as Context2D;
  const img = rawCtx.getImageData(0, 0, raw.width, raw.height);
  const out = ctx.createImageData(raw.width, raw.height);
  const d = img.data, o = out.data;
  for (let i = 0; i < d.length; i += 4) {
    o[i] = Math.max(0, Math.min(255, Math.round((d[i] / 150) * tr)));
    o[i + 1] = Math.max(0, Math.min(255, Math.round((d[i + 1] / 150) * tg)));
    o[i + 2] = Math.max(0, Math.min(255, Math.round((d[i + 2] / 150) * tb)));
    o[i + 3] = d[i + 3];
  }
  ctx.putImageData(out, 0, 0);
  uiTintedCache.set(name, c);
  return c;
}

export function iconUrl(name: string) {
  const cached = iconCache.get(name);
  if (cached !== undefined) return cached;
  const id = ID[name];
  let source: DrawCanvas | undefined;
  if (id !== undefined && BLOCKS[id]) {
    const b = BLOCKS[id];
    if ((b.name.endsWith('_door') && !b.name.startsWith('open_')) || b.name.endsWith('_button')) {
      source = uiTileCanvas(b.name);
    }
    if (!source) source = renderBlockIcon3D(b);
    if (!source) source = uiTileCanvas(faceTile(b, 4)) ?? uiTileCanvas(faceTile(b, 2));
  } else {
    source = uiTileCanvas(name);
  }
  const url = source ? toDataURL(source) : '';
  iconCache.set(name, url);
  return url;
}

export function itemIcon(name: string) { return iconUrl(name) || iconUrl('stone'); }
export function handTileCanvas(name: string): DrawCanvas | undefined {
  const id = ID[name];
  if (id !== undefined && BLOCKS[id]) {
    const b = BLOCKS[id];
    if ((b.name.endsWith('_door') && !b.name.startsWith('open_')) || b.name.endsWith('_button')) {
      const icon = uiTileCanvas(b.name);
      if (icon) return icon;
    }
    return uiTileCanvas(faceTile(b, 4)) ?? uiTileCanvas(faceTile(b, 2));
  }
  return uiTileCanvas(name) ?? uiTileCanvas('stone');
}
export function blockFaceCanvases(name: string): DrawCanvas[] | undefined {
  const id = ID[name];
  if (id === undefined || !BLOCKS[id]) return undefined;
  return [0, 1, 2, 3, 4, 5].map(f => uiTileCanvas(faceTile(BLOCKS[id], f)) ?? uiTileCanvas('stone')!);
}
export interface BlockFaceAudit {
  blocks: number;
  faces: number;
  missing: string[];
  sharedFaceTiles: number;
}

/** Exhaustive test hook: every registered block must resolve all six faces to an atlas tile. */
export function auditBlockFaceTextures(): BlockFaceAudit {
  const missing: string[] = [];
  const seen = new Set<string>();
  let blocks = 0;
  let faces = 0;
  for (const b of BLOCKS) {
    if (!b.id) continue;
    blocks++;
    for (let face = 0; face < 6; face++) {
      const tile = faceTile(b, face);
      faces++;
      if (!tileIndex.has(tile) || !tileCanvases.has(tile)) missing.push(`${b.name}[${face}]=${tile}`);
      seen.add(tile);
    }
  }
  return { blocks, faces, missing, sharedFaceTiles: faces - seen.size };
}
export const atlasTiles = () => tileNames.map((name, index) => ({ name, index, canvas: tileCanvases.get(name)! }));
export const tileColor = (id: number) => BLOCKS[id]?.color ?? '#82966a';


const texCache = new Map<string, THREE.CanvasTexture>();
export function getTileTexture(name: string): THREE.CanvasTexture {
  const cached = texCache.get(name);
  if (cached) return cached;
  let source = uiTileCanvas(name);
  const id = ID[name];
  if (!source && id !== undefined) source = uiTileCanvas(faceTile(BLOCKS[id], 4)) ?? uiTileCanvas(faceTile(BLOCKS[id], 2));
  if (!source) source = uiTileCanvas('stone')!;
  const t = new THREE.CanvasTexture(source as HTMLCanvasElement);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace;
  texCache.set(name, t);
  return t;
}
