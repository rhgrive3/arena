import { BLOCKS, ID } from '../game/data';
import {
  placeBlobTree,
  placeSpruceOrPine,
  placeAcaciaTree,
  placeDarkOakTree,
  placeCherryTree,
  placeFancyOakTree,
  placeMangroveTree,
  placeMegaTaigaTree,
  placeMegaJungleTree,
  placeHugeMushroom,
} from '../world/features';

/*
 * Unified Farming & Plant Growth System (Record 014 Perfected).
 *
 * Combines:
 *  - O(1) Uint8Array(1024) chunk scanning (perfected)
 *  - Vanilla 3x3 farmland hydration & same-crop crowding growth points formula (implement)
 *  - Sky + Block light >= 9 check so torches allow underground farming while darkness halts growth (simplify)
 *  - 2-stage coarse/rooted dirt hoe tilling, farmland hydration/drying, and fall trampling (simplify + vanilla)
 *  - Atomic canopy clearance validation, 2x2 mega trees (spruce/jungle/dark oak), and giant mushrooms (simplify + implement + vanilla)
 *  - Full composter item probability table, Fortune crop drops, grass spreading, and vine growth (implement + vanilla)
 */

export interface FarmHost {
  getCell(x: number, y: number, z: number): number;
  setBlock(x: number, y: number, z: number, id: number, state?: number): boolean;
  drop?(x: number, y: number, z: number, name: string, count: number): void;
  particles?(x: number, y: number, z: number, color: string, n: number): void;
  growth?(x: number, y: number, z: number): void;
  seed?: number;
  daylight?(): number;
  raining?(): boolean;
}

type Pos = readonly [number, number, number];
const key = (x: number, y: number, z: number) => x + ',' + y + ',' + z;
const parse = (k: string): Pos => k.split(',').map(Number) as unknown as Pos;
const idOf = (cell: number) => (cell < 0 ? -1 : cell & 4095);
const stOf = (cell: number) => (cell < 0 ? 0 : (cell >>> 12) & 15);
const nameOf = (id: number) => BLOCKS[id]?.name ?? '';

/** Canonical crop name normalization (supports both carrots and carrot_crop). */
export function normCrop(name: string): string {
  if (name === 'carrot_crop') return 'carrots';
  if (name === 'potato_crop') return 'potatoes';
  if (name === 'beetroot_crop') return 'beetroots';
  return name;
}

/** Seed / food item → crop block. */
export const SEED_TO_CROP: Record<string, string> = {
  wheat_seeds: 'wheat_crop',
  carrot: 'carrots',
  potato: 'potatoes',
  beetroot_seeds: 'beetroots',
  melon_seeds: 'melon_stem',
  pumpkin_seeds: 'pumpkin_stem',
  nether_wart: 'nether_wart',
};
export const SEEDS = SEED_TO_CROP;

export const CROPS = new Set([
  'wheat_crop',
  'carrots',
  'potatoes',
  'beetroots',
  'carrot_crop',
  'potato_crop',
  'beetroot_crop',
  'melon_stem',
  'pumpkin_stem',
  'nether_wart',
]);

export const COMPOSTABLE: Record<string, number> = {
  wheat_seeds: 0.3, beetroot_seeds: 0.3, melon_seeds: 0.3, pumpkin_seeds: 0.3, short_grass: 0.3, oak_leaves: 0.3, birch_leaves: 0.3,
  spruce_leaves: 0.3, jungle_leaves: 0.3, acacia_leaves: 0.3, dark_oak_leaves: 0.3, cherry_leaves: 0.3, mangrove_leaves: 0.3,
  oak_sapling: 0.3, birch_sapling: 0.3, spruce_sapling: 0.3, jungle_sapling: 0.3, acacia_sapling: 0.3, dark_oak_sapling: 0.3, cherry_sapling: 0.3,
  mangrove_propagule: 0.3, sweet_berries: 0.3, kelp: 0.3, seagrass: 0.3, moss_carpet: 0.3, hanging_roots: 0.3,
  melon_slice: 0.5, sugar_cane: 0.5, cactus: 0.5, tall_grass: 0.5, vine: 0.5, dried_kelp: 0.3,
  wheat: 0.65, carrot: 0.65, potato: 0.65, beetroot: 0.65, apple: 0.65, melon_block: 0.65, melon: 0.65, pumpkin_block: 0.65, pumpkin: 0.65,
  nether_wart: 0.65, dandelion: 0.65, poppy: 0.65, red_mushroom: 0.65, brown_mushroom: 0.65, lily_pad: 0.65, fern: 0.65, moss_block: 0.65,
  bread: 0.85, baked_potato: 0.85, cookie: 0.85, hay_block: 0.85, red_mushroom_block: 0.85, brown_mushroom_block: 0.85,
  pumpkin_pie: 1.0, cake: 1.0,
};

const MAX_STAGE: Record<string, number> = { nether_wart: 3, beetroots: 7, beetroot_crop: 7 };
export const maxStage = (name: string) => MAX_STAGE[name] ?? 7;
export const isCrop = (id: number) => CROPS.has(nameOf(id));
export const isSapling = (id: number) => { const n = nameOf(id); return n.endsWith('_sapling') || n === 'mangrove_propagule'; };
export const isFarmland = (id: number) => id > 0 && (id === ID.farmland || id === ID.farmland_moist);
export const isTillable = (id: number) => id === ID.dirt || id === ID.grass_block || id === ID.coarse_dirt || id === ID.dirt_path || id === ID.rooted_dirt;
const SOILS = new Set(['dirt', 'grass_block', 'coarse_dirt', 'podzol', 'mycelium', 'moss_block', 'mud', 'farmland', 'farmland_moist', 'rooted_dirt']);

/** What a crop drops when broken at the given stage (with optional Fortune bonus). */
export function cropDrops(name: string, state: number, rng: () => number = Math.random, fortune = 0): { name: string; count: number }[] {
  const cn = normCrop(name);
  const st = state & 7;
  // beetroots can be mature at 3 (when 4-stage) or 7 (when 8-stage)
  const mature = cn === 'nether_wart' ? st >= 3 : st >= 7;
  const bonus = fortune > 0 ? Math.floor(rng() * (fortune + 1)) : 0;
  switch (cn) {
    case 'wheat_crop':
      return mature
        ? [{ name: 'wheat', count: 1 }, { name: 'wheat_seeds', count: 1 + Math.floor(rng() * 3) + bonus }]
        : [{ name: 'wheat_seeds', count: 1 }];
    case 'carrots':
      return [{ name: 'carrot', count: mature ? 2 + Math.floor(rng() * 3) + bonus : 1 }];
    case 'potatoes': {
      const out = [{ name: 'potato', count: mature ? 2 + Math.floor(rng() * 3) + bonus : 1 }];
      if (mature && rng() < 0.02) out.push({ name: 'poisonous_potato', count: 1 });
      return out;
    }
    case 'beetroots':
      return mature
        ? [{ name: 'beetroot', count: 1 }, { name: 'beetroot_seeds', count: 1 + Math.floor(rng() * 3) + bonus }]
        : [{ name: 'beetroot_seeds', count: 1 }];
    case 'melon_stem':
      return [{ name: 'melon_seeds', count: rng() < 0.5 ? 1 : 0 }].filter(d => d.count > 0);
    case 'pumpkin_stem':
      return [{ name: 'pumpkin_seeds', count: rng() < 0.5 ? 1 : 0 }].filter(d => d.count > 0);
    case 'nether_wart':
      return [{ name: 'nether_wart', count: mature ? 2 + Math.floor(rng() * (3 + fortune)) : 1 }];
  }
  return [];
}

export type FarmAction = 'plant' | 'fertilize' | 'till' | 'compost' | 'blocked' | false;

export class Farming {
  /** Positions of crops, saplings, stems, cane, cactus, farmland, berries, cocoa, vines and grass that receive random ticks. */
  readonly growing = new Set<string>();
  /** randomTickSpeed game rule (default 3). */
  speed = 3;
  private acc = 0;
  public rng: () => number;

  constructor(public host: FarmHost, rng: () => number = Math.random) {
    this.rng = rng;
  }

  get active() { return this.growing; }
  get tracked() { return this.growing.size; }

  // ------------------------------------------------------------------ registry

  register(x: number, y: number, z: number, givenId?: number) {
    const id = givenId !== undefined ? givenId : idOf(this.host.getCell(x, y, z));
    if (this.grows(id)) this.growing.add(key(x, y, z));
    else this.growing.delete(key(x, y, z));
  }

  private static lutGrows = new Uint8Array(1024);
  private static lutCount = -1;
  private static ensureLut() {
    if (Farming.lutCount === BLOCKS.length) return;
    Farming.lutCount = BLOCKS.length;
    Farming.lutGrows.fill(0);
    for (let i = 1; i < BLOCKS.length && i < 1024; i++) {
      const n = BLOCKS[i]?.name ?? '';
      if (
        CROPS.has(n) ||
        n.endsWith('_sapling') ||
        n === 'mangrove_propagule' ||
        n === 'sugar_cane' ||
        n === 'cactus' ||
        n === 'bamboo' ||
        n === 'farmland' ||
        n === 'farmland_moist' ||
        n === 'sweet_berry_bush' ||
        n === 'cocoa' ||
        n === 'vine'
      ) {
        Farming.lutGrows[i] = 1;
      }
    }
  }

  private grows(id: number) {
    if (id <= 0 || id >= 1024) return false;
    Farming.ensureLut();
    return Farming.lutGrows[id] === 1;
  }

  scanChunk(data: Uint16Array, cx: number, cz: number, height = 384, minY = -64, maxY?: number) {
    Farming.ensureLut();
    const lut = Farming.lutGrows;
    const maxLy = maxY !== undefined ? Math.min(height, Math.max(0, maxY - minY)) : Math.min(height, data.length >> 8);
    const ox = cx * 16, oz = cz * 16;
    for (let ly = 0; ly < maxLy; ly++) {
      const yBase = ly * 256;
      for (let z = 0; z < 16; z++) {
        const row = yBase + z * 16;
        for (let x = 0; x < 16; x++) {
          const cell = data[row + x];
          if (cell === 0) continue;
          const id = cell & 4095;
          if (lut[id] === 1) this.growing.add(key(ox + x, ly + minY, oz + z));
        }
      }
    }
  }

  unloadChunk(cx: number, cz: number) {
    const x0 = cx * 16, z0 = cz * 16;
    for (const k of [...this.growing]) {
      const [x, , z] = parse(k);
      if (x >= x0 && x < x0 + 16 && z >= z0 && z < z0 + 16) this.growing.delete(k);
    }
  }

  clear() {
    this.growing.clear();
    this.acc = 0;
  }

  // ------------------------------------------------------------------ hydration, light & vanilla growth points

  /** Water within four blocks horizontally, at the same level or one above. */
  wet(x: number, y: number, z: number): boolean {
    for (let dx = -4; dx <= 4; dx++) {
      for (let dz = -4; dz <= 4; dz++) {
        for (let dy = 0; dy <= 1; dy++) {
          if (idOf(this.host.getCell(x + dx, y + dy, z + dz)) === ID.water) return true;
        }
      }
    }
    return false;
  }
  hydrated(x: number, y: number, z: number) { return this.wet(x, y, z); }

  /**
   * True when the cell at (x, y, z) has light level >= 9 from either sky light (scaled by daylight)
   * or nearby light-emitting blocks (torches, lanterns, glowstone, lit copper bulbs, etc.).
   */
  lit(x: number, y: number, z: number, daylight = this.host.daylight?.() ?? 1): boolean {
    let sky = daylight >= 0.25;
    for (let dy = 1; dy <= 16 && sky; dy++) {
      const id = idOf(this.host.getCell(x, y + dy, z));
      const b = id > 0 ? BLOCKS[id] : undefined;
      if (b?.solid && !b.transparent) sky = false;
    }
    if (sky) return true;
    for (let dx = -3; dx <= 3; dx++) {
      for (let dz = -3; dz <= 3; dz++) {
        for (let dy = -1; dy <= 2; dy++) {
          const id = idOf(this.host.getCell(x + dx, y + dy, z + dz));
          if (id <= 0) continue;
          const emit = BLOCKS[id]?.light ?? 0;
          if (emit - Math.abs(dx) - Math.abs(dz) - Math.abs(dy) >= 9) return true;
        }
      }
    }
    return false;
  }

  /**
   * Vanilla crop growth chance formula:
   * - 3x3 farmland below scores points (hydrated farmland = 3, dry farmland = 1; outer 8 divided by 4)
   * - Same crop in diagonal or on both X and Z axes halves the points
   * - Probability = 1 / (floor(25 / points) + 1)
   */
  growthChance(x: number, y: number, z: number, id: number): number {
    let f = 1;
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        const c = this.host.getCell(x + dx, y - 1, z + dz);
        const sid = idOf(c), sst = stOf(c);
        const moist = sid === ID.farmland_moist || (sid === ID.farmland && (sst & 7) > 0);
        let g = moist ? 3 : sid === ID.farmland ? 1 : 0;
        if (dx !== 0 || dz !== 0) g /= 4;
        f += g;
      }
    }
    const same = (dx: number, dz: number) => idOf(this.host.getCell(x + dx, y, z + dz)) === id;
    const rowX = same(-1, 0) || same(1, 0);
    const rowZ = same(0, -1) || same(0, 1);
    const diagonal = same(-1, -1) || same(1, -1) || same(-1, 1) || same(1, 1);
    if ((rowX && rowZ) || diagonal) f /= 2;
    return 1 / (Math.floor(25 / f) + 1);
  }

  // ------------------------------------------------------------------ player actions

  /**
   * Hoe: dirt/grass/path → farmland; coarse_dirt/rooted_dirt → dirt first (two-stage vanilla tilling).
   * Needs unobstructed air above.
   */
  till(x: number, y: number, z: number): boolean {
    const id = idOf(this.host.getCell(x, y, z));
    if (!isTillable(id) || idOf(this.host.getCell(x, y + 1, z)) !== 0) return false;
    if (id === ID.coarse_dirt || id === ID.rooted_dirt) {
      if (id === ID.rooted_dirt) this.host.drop?.(x, y + 1, z, 'hanging_roots', 1);
      this.host.setBlock(x, y, z, ID.dirt, 0);
      this.register(x, y, z, ID.dirt);
      return true;
    }
    const state = this.wet(x, y, z) ? 1 : 0;
    this.host.setBlock(x, y, z, ID.farmland, state);
    this.register(x, y, z, ID.farmland);
    return true;
  }

  /** Trample farmland when falling onto it from > 1 block height: turns into dirt and pops any crop above. */
  trample(x: number, y: number, z: number): boolean {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    const id = idOf(this.host.getCell(x, y, z));
    if (!isFarmland(id)) return false;
    const above = this.host.getCell(x, y + 1, z), aid = idOf(above), ast = stOf(above);
    if (isCrop(aid)) {
      for (const d of cropDrops(nameOf(aid), ast, this.rng)) this.host.drop?.(x, y + 1, z, d.name, d.count);
      this.host.setBlock(x, y + 1, z, 0, 0);
      this.growing.delete(key(x, y + 1, z));
    }
    this.host.setBlock(x, y, z, ID.dirt, 0);
    this.growing.delete(key(x, y, z));
    return true;
  }

  /** Plant a seed item on top of the block at x,y,z. */
  plant(item: string, x: number, y: number, z: number): boolean {
    const crop = SEED_TO_CROP[item];
    if (!crop || ID[crop] === undefined) return false;
    const soil = idOf(this.host.getCell(x, y, z));
    const ok = crop === 'nether_wart' ? soil === ID.soul_sand : isFarmland(soil);
    if (!ok || idOf(this.host.getCell(x, y + 1, z)) !== 0) return false;
    this.host.setBlock(x, y + 1, z, ID[crop], 0);
    this.register(x, y + 1, z, ID[crop]);
    return true;
  }

  /** Bone meal on crops, saplings, mushrooms, grass blocks, cane/bamboo, and sweet berries. */
  bonemeal(x: number, y: number, z: number): boolean {
    const cell = this.host.getCell(x, y, z), id = idOf(cell), st = stOf(cell), n = nameOf(id);
    const puff = () => {
      this.host.particles?.(x + 0.5, y + 0.6, z + 0.5, '#c9f58a', 14);
      this.host.growth?.(x, y, z);
    };
    if (CROPS.has(n) && n !== 'nether_wart') {
      const max = maxStage(n);
      if ((st & 7) >= max) return false;
      this.setStage(x, y, z, id, Math.min(max, (st & 7) + 2 + Math.floor(this.rng() * 4)));
      puff();
      return true;
    }
    if (isSapling(id)) {
      if (this.rng() < 0.45 || !this.host.particles) {
        if (!this.growTree(x, y, z, id)) return false;
      }
      puff();
      return true;
    }
    if (n === 'red_mushroom' || n === 'brown_mushroom') {
      if (this.growHugeMushroom(x, y, z, n === 'red_mushroom')) {
        puff();
        return true;
      }
      return false;
    }
    if (n === 'sweet_berry_bush' && st < 3) {
      this.host.setBlock(x, y, z, id, Math.min(3, st + 1));
      puff();
      return true;
    }
    if (id === ID.grass_block) {
      const flowers = ['short_grass', 'short_grass', 'short_grass', 'dandelion', 'poppy', 'short_grass', 'tall_grass', 'azure_bluet', 'oxeye_daisy', 'cornflower'];
      for (let i = 0; i < 14; i++) {
        const px = x + Math.round((this.rng() - 0.5) * 6), pz = z + Math.round((this.rng() - 0.5) * 6);
        if (idOf(this.host.getCell(px, y, pz)) !== ID.grass_block || idOf(this.host.getCell(px, y + 1, pz)) !== 0) continue;
        const pick = flowers[Math.floor(this.rng() * flowers.length)];
        const pid = ID[pick] ?? ID.short_grass;
        if (pid !== undefined) this.host.setBlock(px, y + 1, pz, pid, 0);
      }
      this.host.particles?.(x + 0.5, y + 1.2, z + 0.5, '#c9f58a', 18);
      this.host.growth?.(x, y, z);
      return true;
    }
    if (n === 'sugar_cane' || n === 'bamboo' || n === 'cactus') {
      puff();
      this.growColumn(x, y, z, id, n === 'bamboo' ? 12 : 3, true);
      return true;
    }
    return false;
  }
  fertilize(x: number, y: number, z: number) { return this.bonemeal(x, y, z); }

  /** Composter interaction: 7 levels fill it to 8 (ready), collecting drops bone_meal and resets to 0. */
  compost(x: number, y: number, z: number, item: string | null): 'added' | 'missed' | 'full' | 'collected' | null {
    const cell = this.host.getCell(x, y, z), id = idOf(cell), level = stOf(cell);
    if (id <= 0 || id !== ID.composter) return null;
    if (level >= 7) {
      this.host.setBlock(x, y, z, id, 0);
      this.host.drop?.(x, y + 1, z, 'bone_meal', 1);
      return 'collected';
    }
    const chance = item ? COMPOSTABLE[item] : undefined;
    if (chance === undefined) return null;
    if (this.rng() >= chance && level > 0) return 'missed';
    const next = level + 1 >= 7 ? 8 : level + 1;
    this.host.setBlock(x, y, z, id, next);
    return next >= 7 ? 'full' : 'added';
  }

  /** Unified right-click helper (compatible with simplify's interact API). */
  interact(item: string, target: { x: number; y: number; z: number; normal?: { y: number } } | null): FarmAction {
    if (!target) return false;
    const { x, y, z } = target, id = idOf(this.host.getCell(x, y, z)), name = nameOf(id), above = idOf(this.host.getCell(x, y + 1, z));
    if (item.endsWith('_hoe')) {
      if (!isTillable(id)) return false;
      if ((target.normal?.y ?? 1) < 0 || above !== 0) return 'blocked';
      return this.till(x, y, z) ? 'till' : 'blocked';
    }
    if (SEED_TO_CROP[item]) {
      const crop = SEED_TO_CROP[item];
      const ok = crop === 'nether_wart' ? id === ID.soul_sand : isFarmland(id);
      if (!ok) return false;
      if (above !== 0 || (target.normal?.y ?? 1) !== 1) return 'blocked';
      return this.plant(item, x, y, z) ? 'plant' : 'blocked';
    }
    if (item.endsWith('_sapling') || item === 'mangrove_propagule') {
      if (!SOILS.has(name) || above !== 0 || (target.normal?.y ?? 1) !== 1) return 'blocked';
      const sid = ID[item];
      if (!sid) return 'blocked';
      this.host.setBlock(x, y + 1, z, sid, 0);
      this.register(x, y + 1, z, sid);
      return 'plant';
    }
    if (item === 'bone_meal') {
      if (CROPS.has(name) || isSapling(id) || name === 'red_mushroom' || name === 'brown_mushroom' || id === ID.grass_block || name === 'sugar_cane' || name === 'bamboo' || name === 'cactus' || name === 'sweet_berry_bush') {
        return this.bonemeal(x, y, z) ? 'fertilize' : 'blocked';
      }
      return 'blocked';
    }
    return false;
  }

  // ------------------------------------------------------------------ random ticks

  /** Call every frame. Scales with `this.speed` (randomTickSpeed). */
  tick(dt = 0.25) {
    if (this.speed <= 0) return;
    this.acc += dt;
    if (this.acc < 0.25) return;
    this.acc = 0;
    let budget = Math.min(1200, Math.round(400 * (this.speed / 3)));
    const daylight = this.host.daylight?.() ?? 1;
    const raining = this.host.raining?.() ?? false;
    for (const k of this.growing) {
      if (--budget < 0) break;
      const [x, y, z] = parse(k);
      const cell = this.host.getCell(x, y, z), id = idOf(cell);
      if (id <= 0 || !this.grows(id)) {
        this.growing.delete(k);
        continue;
      }
      const n = nameOf(id), st = stOf(cell);
      if (CROPS.has(n)) this.tickCrop(x, y, z, id, n, st, daylight);
      else if (isSapling(id)) {
        if (this.lit(x, y, z, daylight) && this.rng() < 1 / 40) {
          if ((st & 1) === 0) this.host.setBlock(x, y, z, id, st | 1);
          else this.growTree(x, y, z, id);
        }
      } else if (isFarmland(id)) this.tickFarmland(x, y, z, id, st, raining);
      else if (n === 'sugar_cane' || n === 'cactus') {
        if (this.rng() < 1 / 45) this.growColumn(x, y, z, id, 3, false);
      } else if (n === 'bamboo') {
        if (this.lit(x, y, z, daylight) && this.rng() < 1 / 25) this.growColumn(x, y, z, id, 12, false);
      } else if (n === 'sweet_berry_bush' || n === 'cocoa') {
        if (st < 3 && this.rng() < 1 / 50) this.host.setBlock(x, y, z, id, st + 1);
      } else if (n === 'vine') {
        if (this.rng() < 1 / 60 && idOf(this.host.getCell(x, y - 1, z)) === 0) {
          this.host.setBlock(x, y - 1, z, id, st);
          this.growing.add(key(x, y - 1, z));
        }
      }
    }
  }

  /** Direct single-block random tick (used by tests and /tick commands). */
  randomTick(x: number, y: number, z: number, daylight = this.host.daylight?.() ?? 1, raining = this.host.raining?.() ?? false) {
    const cell = this.host.getCell(x, y, z);
    if (cell < 0) return;
    const id = idOf(cell), st = stOf(cell), n = nameOf(id);
    if (id <= 0 || !n) { this.growing.delete(key(x, y, z)); return; }
    if (isFarmland(id)) {
      this.tickFarmland(x, y, z, id, st, raining);
      return;
    }
    if (CROPS.has(n)) {
      const below = this.host.getCell(x, y - 1, z), soil = idOf(below);
      if (n === 'nether_wart' ? soil !== ID.soul_sand : !isFarmland(soil)) {
        for (const d of cropDrops(n, st, this.rng)) this.host.drop?.(x, y, z, d.name, d.count);
        this.host.setBlock(x, y, z, 0);
        this.growing.delete(key(x, y, z));
        return;
      }
      if (n !== 'nether_wart' && !this.lit(x, y, z, daylight)) return;
      const stage = st & 7, max = maxStage(n);
      if (stage < max) {
        const chance = n === 'nether_wart' ? 0.15 : Math.max(0.08, this.growthChance(x, y, z, id));
        if (this.rng() <= chance) this.setStage(x, y, z, id, stage + 1);
      } else if (n === 'melon_stem' || n === 'pumpkin_stem') {
        this.trySpawnFruit(x, y, z, n);
      }
      return;
    }
    if (isSapling(id)) {
      if (!this.lit(x, y, z, daylight)) return;
      if (this.rng() < 0.25) {
        if ((st & 1) === 0) this.host.setBlock(x, y, z, id, st | 1);
        else this.growTree(x, y, z, id);
      }
      return;
    }
    if (n === 'sugar_cane' || n === 'cactus') {
      if (this.rng() < 0.25) this.growColumn(x, y, z, id, 3, false);
      return;
    }
    if (n === 'bamboo') {
      if (this.lit(x, y, z, daylight) && this.rng() < 0.35) this.growColumn(x, y, z, id, 12, false);
      return;
    }
    if (n === 'vine' && idOf(this.host.getCell(x, y - 1, z)) === 0) {
      this.host.setBlock(x, y - 1, z, id, st);
      this.growing.add(key(x, y - 1, z));
    }
  }

  update(dt: number, _position?: { x: number; z: number }, _daylight = 1, _raining = false) {
    this.tick(dt);
  }

  private tickCrop(x: number, y: number, z: number, id: number, n: string, st: number, daylight: number) {
    const below = this.host.getCell(x, y - 1, z), soil = idOf(below);
    if (n === 'nether_wart' ? soil !== ID.soul_sand : !isFarmland(soil)) {
      for (const d of cropDrops(n, st, this.rng)) this.host.drop?.(x, y, z, d.name, d.count);
      this.host.setBlock(x, y, z, 0);
      this.growing.delete(key(x, y, z));
      return;
    }
    const stage = st & 7, max = maxStage(n);
    if (stage >= max) {
      if ((n === 'melon_stem' || n === 'pumpkin_stem') && this.rng() < 1 / 25) this.trySpawnFruit(x, y, z, n);
      return;
    }
    if (n !== 'nether_wart' && !this.lit(x, y, z, daylight)) return;
    const chance = n === 'nether_wart' ? 1 / 30 : this.growthChance(x, y, z, id) * 0.65;
    if (this.rng() < chance) this.setStage(x, y, z, id, stage + 1);
  }

  private trySpawnFruit(x: number, y: number, z: number, stemName: string) {
    const fruit = stemName === 'melon_stem' ? (ID.melon_block ?? ID.melon) : (ID.pumpkin_block ?? ID.pumpkin);
    if (fruit === undefined) return;
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      if (idOf(this.host.getCell(x + dx, y, z + dz)) === fruit) return;
    }
    const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]].sort(() => this.rng() - 0.5);
    for (const [dx, dz] of dirs) {
      const ground = idOf(this.host.getCell(x + dx, y - 1, z + dz));
      if (idOf(this.host.getCell(x + dx, y, z + dz)) === 0 && SOILS.has(nameOf(ground))) {
        this.host.setBlock(x + dx, y, z + dz, fruit, 0);
        return;
      }
    }
  }

  private tickFarmland(x: number, y: number, z: number, id: number, st: number, raining: boolean) {
    const aboveId = idOf(this.host.getCell(x, y + 1, z));
    if (aboveId > 0 && BLOCKS[aboveId]?.solid) {
      this.host.setBlock(x, y, z, ID.dirt, 0);
      this.growing.delete(key(x, y, z));
      return;
    }
    const wet = raining || this.wet(x, y, z);
    if (wet) {
      if ((st & 7) !== 7) this.host.setBlock(x, y, z, ID.farmland, 7);
      return;
    }
    if ((st & 7) > 0) {
      this.host.setBlock(x, y, z, ID.farmland, (st & 7) - 1);
      return;
    }
    if (!CROPS.has(nameOf(aboveId))) {
      this.host.setBlock(x, y, z, ID.dirt, 0);
      this.growing.delete(key(x, y, z));
    }
  }

  private setStage(x: number, y: number, z: number, id: number, stage: number) {
    this.host.setBlock(x, y, z, id, stage & 7);
    this.register(x, y, z, id);
  }

  private growColumn(x: number, y: number, z: number, id: number, maxH: number, force: boolean) {
    let top = y;
    while (idOf(this.host.getCell(x, top + 1, z)) === id) top++;
    let base = y;
    while (idOf(this.host.getCell(x, base - 1, z)) === id) base--;
    if (top - base + 1 >= maxH || idOf(this.host.getCell(x, top + 1, z)) !== 0) return;
    const steps = force ? 1 + Math.floor(this.rng() * 2) : 1;
    for (let i = 1; i <= steps && top + i - base < maxH; i++) {
      if (idOf(this.host.getCell(x, top + i, z)) !== 0) break;
      this.host.setBlock(x, top + i, z, id, 0);
      this.growing.add(key(x, top + i, z));
    }
  }

  /** Grow a giant red or brown mushroom when fertilized. */
  growHugeMushroom(x: number, y: number, z: number, isRed: boolean): boolean {
    const soil = nameOf(idOf(this.host.getCell(x, y - 1, z)));
    if (!SOILS.has(soil)) return false;
    for (let dy = 1; dy <= 6; dy++) {
      const a = idOf(this.host.getCell(x, y + dy, z));
      if (a < 0 || (a > 0 && BLOCKS[a]?.solid && BLOCKS[a]?.pattern !== 'leaves')) return false;
    }
    const seed = ((this.host.seed ?? 0) ^ (x * 7919) ^ (z * 104729) ^ (y * 31)) | 0;
    const put = (px: number, py: number, pz: number, id: number, replace?: boolean) => {
      const cur = idOf(this.host.getCell(px, py, pz));
      if (cur < 0) return;
      if (cur === 0 || BLOCKS[cur]?.pattern === 'leaves' || replace) this.host.setBlock(px, py, pz, id, 0);
    };
    this.host.setBlock(x, y, z, 0);
    placeHugeMushroom(put, x, y - 1, z, seed, isRed);
    return true;
  }

  /** Replace a sapling (or 2x2 sapling cluster) with the matching tree after atomic clearance validation. */
  growTree(x: number, y: number, z: number, saplingId = idOf(this.host.getCell(x, y, z))): boolean {
    if (!isSapling(saplingId)) return false;
    const soilId = idOf(this.host.getCell(x, y - 1, z));
    if (soilId <= 0 || !SOILS.has(nameOf(soilId))) return false;
    const n = nameOf(saplingId), wood = n === 'mangrove_propagule' ? 'mangrove' : n.replace(/_sapling$/, '');

    // Check 2x2 mega tree (spruce, jungle, dark_oak)
    if (wood === 'spruce' || wood === 'jungle' || wood === 'dark_oak') {
      for (const [ox, oz] of [[0, 0], [-1, 0], [0, -1], [-1, -1]]) {
        const sx = x + ox, sz = z + oz;
        if (
          idOf(this.host.getCell(sx, y, sz)) === saplingId &&
          idOf(this.host.getCell(sx + 1, y, sz)) === saplingId &&
          idOf(this.host.getCell(sx, y, sz + 1)) === saplingId &&
          idOf(this.host.getCell(sx + 1, y, sz + 1)) === saplingId
        ) {
          for (let dy = 1; dy <= 10; dy++) {
            for (let dx = 0; dx <= 1; dx++) {
              for (let dz = 0; dz <= 1; dz++) {
                const a = idOf(this.host.getCell(sx + dx, y + dy, sz + dz));
                if (a < 0 || (a > 0 && a !== saplingId && BLOCKS[a]?.solid && BLOCKS[a]?.pattern !== 'leaves')) return false;
              }
            }
          }
          const seed = ((this.host.seed ?? 0) ^ (sx * 7919) ^ (sz * 104729) ^ (y * 31)) | 0;
          const log = ID[wood + '_log'] ?? ID.oak_log, leaves = ID[wood + '_leaves'] ?? ID.oak_leaves;
          for (let dx = 0; dx <= 1; dx++) {
            for (let dz = 0; dz <= 1; dz++) {
              this.host.setBlock(sx + dx, y, sz + dz, 0);
              this.growing.delete(key(sx + dx, y, sz + dz));
            }
          }
          const put = (px: number, py: number, pz: number, id: number, replace?: boolean) => {
            const cur = idOf(this.host.getCell(px, py, pz));
            if (cur < 0) return;
            if (cur === 0 || BLOCKS[cur]?.pattern === 'leaves' || cur === saplingId || replace) this.host.setBlock(px, py, pz, id, 0);
          };
          if (wood === 'dark_oak') placeDarkOakTree(put, sx, y - 1, sz, seed);
          else if (wood === 'spruce') placeMegaTaigaTree(put, sx, y - 1, sz, seed, true);
          else placeMegaJungleTree(put, sx, y - 1, sz, seed);
          this.host.particles?.(sx + 1, y + 1, sz + 1, '#9bd36a', 24);
          this.host.growth?.(sx, y, sz);
          return true;
        }
      }
    }

    // Atomic clearance check for single-trunk trees (trunk + immediate canopy space, including unloaded chunk borders)
    for (let dy = 1; dy <= 5; dy++) {
      const a = idOf(this.host.getCell(x, y + dy, z));
      if (a < 0 || (a > 0 && a !== saplingId && BLOCKS[a]?.solid && BLOCKS[a]?.pattern !== 'leaves')) return false;
    }
    for (let dy = 2; dy <= 5; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        for (let dz = -1; dz <= 1; dz++) {
          const a = idOf(this.host.getCell(x + dx, y + dy, z + dz));
          if (a < 0) return false;
        }
      }
    }

    const seed = ((this.host.seed ?? 0) ^ (x * 7919) ^ (z * 104729) ^ (y * 31)) | 0;
    const put = (px: number, py: number, pz: number, id: number, replace?: boolean) => {
      const cur = idOf(this.host.getCell(px, py, pz));
      if (cur < 0) return;
      const leaf = BLOCKS[cur]?.pattern === 'leaves' || cur === saplingId;
      if (cur === 0 || leaf || replace) this.host.setBlock(px, py, pz, id, 0);
    };
    const log = ID[wood + '_log'] ?? ID.oak_log, leaves = ID[wood + '_leaves'] ?? ID.oak_leaves;
    this.host.setBlock(x, y, z, 0);
    this.growing.delete(key(x, y, z));
    switch (wood) {
      case 'spruce': placeSpruceOrPine(put, x, y, z, seed, false); break;
      case 'acacia': placeAcaciaTree(put, x, y, z, seed); break;
      case 'dark_oak': placeDarkOakTree(put, x, y, z, seed); break;
      case 'cherry': placeCherryTree(put, x, y, z, seed); break;
      case 'mangrove': placeMangroveTree(put, x, y, z, seed); break;
      case 'birch': placeBlobTree(put, x, y, z, seed, log, leaves, 5, 2); break;
      case 'jungle': placeBlobTree(put, x, y, z, seed, log, leaves, 4, 6, { vines: true }); break;
      case 'oak':
        if (this.rng() < 0.1) placeFancyOakTree(put, x, y, z, seed);
        else placeBlobTree(put, x, y, z, seed, log, leaves, 4, 2);
        break;
      default:
        placeBlobTree(put, x, y, z, seed, log, leaves, 4, 2);
    }
    this.host.particles?.(x + 0.5, y + 1, z + 0.5, '#9bd36a', 20);
    this.host.growth?.(x, y, z);
    return true;
  }
}
