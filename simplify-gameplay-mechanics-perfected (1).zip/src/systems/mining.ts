import type { BlockDef } from '../game/data';
import { isSlabBlock } from '../game/blockState';
import { CROPS, cropDrops } from './farming';

const MATERIALS:Record<string,{speed:number;level:number}>={
  wooden:{speed:2,level:1},golden:{speed:12,level:1},stone:{speed:4,level:2},
  iron:{speed:6,level:3},diamond:{speed:8,level:4},netherite:{speed:9,level:5},
};

export function toolCategory(tool?:BlockDef):string{
  if(!tool)return '';
  if(tool.name==='shears')return 'shears';
  const m=tool.name.match(/_(pickaxe|axe|shovel|hoe|sword)$/);
  return m?m[1]:'';
}

export function toolLevel(tool?:BlockDef):number{
  if(!tool)return 0;
  const prefix=tool.name.split('_')[0];
  return MATERIALS[prefix]?.level??0;
}

export function canHarvest(block:BlockDef,tool?:BlockDef):boolean{
  if(!block.tier)return true;
  if(toolCategory(tool)!==block.tool)return false;
  return toolLevel(tool)>=block.tier;
}

export function miningTime(block:BlockDef,tool?:BlockDef):number{
  if(block.hardness<0||!Number.isFinite(block.hardness))return Infinity;
  if(block.hardness===0)return 0.05;
  const harvest=canHarvest(block,tool);
  const category=toolCategory(tool);
  const prefix=tool?.name.split('_')[0]??'';
  let speed=1;
  if(category&&category===block.tool)speed=MATERIALS[prefix]?.speed??1;
  else if(category==='shears'&&(block.pattern==='leaves'||block.pattern==='wool'||block.name==='cobweb'))speed=5;
  else if(category==='sword'&&block.name==='cobweb')speed=15;
  const base=block.hardness*(harvest?1.5:5)/speed;
  return Math.max(0.05,base);
}

export function blockDrops(block:BlockDef,tool:BlockDef|undefined,state=0,rng=Math.random,fortune=0):{name:string;count:number}[]{
  if(block.name==='piston_head'||block.name==='moving_piston')return [];
  if(CROPS.has(block.name))return cropDrops(block.name,state,rng,fortune);
  if(!canHarvest(block,tool))return [];
  if(block.name==='spawner')return [];
  if(block.name==='melon_block'||block.name==='melon')return [{name:'melon_slice',count:Math.min(9,3+Math.floor(rng()*(5+fortune)))}];
  if(block.name==='copper_bulb_lit'||block.name==='lit_copper_bulb')return [{name:'copper_bulb',count:1}];
  if(block.name==='inverted_daylight_detector'||block.name==='daylight_detector_inverted')return [{name:'daylight_detector',count:1}];
  if(block.name==='farmland'||block.name==='farmland_moist')return [{name:'dirt',count:1}];
  if(block.name==='sweet_berry_bush')return state>=2?[{name:'sweet_berries',count:2+Math.floor(rng()*2)}]:state>=1?[{name:'sweet_berries',count:1}]:[];
  if(block.name==='glass'||block.name==='glass_pane'||block.name.endsWith('_stained_glass')||block.name.endsWith('_stained_glass_pane'))return [];
  if(block.name==='snow_block')return [{name:'snowball',count:4}];
  if(block.name==='gravel')return [{name:rng()<Math.min(1,0.1+fortune*0.14)?'flint':'gravel',count:1}];
  if(block.name==='glowstone')return [{name:'glowstone_dust',count:Math.min(4,2+Math.floor(rng()*(3+fortune)))}];
  if(block.name==='bookshelf')return [{name:'book',count:3}];
  if(block.name==='clay')return [{name:'clay_ball',count:4}];
  if(block.pattern==='leaves'){
    if(toolCategory(tool)==='shears')return [{name:block.name,count:1}];
    const out:{name:string;count:number}=[] as any;
    const sapling=block.name.replace(/_leaves$/,'_sapling');
    if(rng()<0.07+fortune*0.02)out.push({name:sapling,count:1});
    if(rng()<0.04+fortune*0.01)out.push({name:'stick',count:1+Math.floor(rng()*2)});
    if((block.name==='oak_leaves'||block.name==='dark_oak_leaves')&&rng()<0.02+fortune*0.005)out.push({name:'apple',count:1});
    return out;
  }
  if(block.name==='short_grass'||block.name==='fern'||block.name==='tall_grass'||block.name==='large_fern'){
    if(toolCategory(tool)==='shears')return [{name:block.name,count:1}];
    return rng()<0.15?[{name:'wheat_seeds',count:1+Math.floor(rng()*(1+fortune*2))}]:[];
  }
  if(isSlabBlock(block)&&state===2)return [{name:block.drop||block.name,count:2}];
  const name=block.drop||block.name;
  let count=1;
  if(block.name==='lapis_ore'||block.name==='deepslate_lapis_ore')count=4+Math.floor(rng()*6);
  else if(block.name==='redstone_ore'||block.name==='deepslate_redstone_ore')count=4+Math.floor(rng()*2);
  else if(block.name==='copper_ore'||block.name==='deepslate_copper_ore')count=2+Math.floor(rng()*4);
  else if(block.name==='nether_gold_ore')count=2+Math.floor(rng()*5);
  return [{name,count}];
}

export function blockExperience(block:BlockDef):number{
  if(block.name==='coal_ore'||block.name==='deepslate_coal_ore'||block.name==='nether_gold_ore')return 1;
  if(block.name==='redstone_ore'||block.name==='deepslate_redstone_ore'||block.name==='lapis_ore'||block.name==='deepslate_lapis_ore'||block.name==='nether_quartz_ore')return 3;
  if(block.name==='diamond_ore'||block.name==='deepslate_diamond_ore'||block.name==='emerald_ore'||block.name==='deepslate_emerald_ore')return 5;
  if(block.name==='spawner')return 18;
  return 0;
}
