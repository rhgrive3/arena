import { placeExtraStructures, locateExtra } from './structures';
import { OverworldGen } from './overworld';
import {
  placeBlobTree,
  placeFancyOakTree,
  placeSwampOakTree,
  placeSpruceOrPine,
  placeMegaTaigaTree,
  placeMegaJungleTree,
  placeJungleBush,
  placeAcaciaTree,
  placeDarkOakTree,
  placeCherryTree,
  placeMangroveTree,
  placeAzaleaTree,
  placeHugeMushroom,
  placeCoralReef,
  placeIceSpike,
  placeIceberg,
  placeForestRock,
  placeDesertWell,
  placeChorusPlant,
  placeHugeFungus,
} from './features';
import { ID, BLOCKS } from '../game/data';
import { makeCell } from '../game/blockState';
import '../game/content';
import { random, hashSeed } from '../input/math';
import type { Dimension } from '../game/types';

export const CHUNK = 16;
export const HEIGHT = 384;
export const MIN_Y = -64;
export const SEA = 63;

const B = ID as Record<string, number | undefined>;

/**
 * Every biome this generator can produce, with the English and Japanese names used by the UI (Minecraft Wiki naming).
 * Keep this list in sync with biomeAt(): the biome regression test (scripts/verify-biomes.ts) fails when a label is missing.
 */
export const BIOME_LABELS: Record<string, { en: string; ja: string; group: 'overworld' | 'nether' | 'end' }> = {
  // Cave biomes
  lush_caves: { en: 'Lush Caves', ja: '繁茂した洞窟', group: 'overworld' },
  dripstone_caves: { en: 'Dripstone Caves', ja: '鍾乳洞', group: 'overworld' },
  deep_dark: { en: 'Deep Dark', ja: 'ディープダーク', group: 'overworld' },
  // Overworld flat / temperate / forest biomes
  plains: { en: 'Plains', ja: '平原', group: 'overworld' },
  sunflower_plains: { en: 'Sunflower Plains', ja: 'ヒマワリ平原', group: 'overworld' },
  forest: { en: 'Forest', ja: '森', group: 'overworld' },
  birch_forest: { en: 'Birch Forest', ja: 'シラカバの森', group: 'overworld' },
  old_growth_birch_forest: { en: 'Old Growth Birch Forest', ja: 'シラカバの原生林', group: 'overworld' },
  flower_forest: { en: 'Flower Forest', ja: '花畑の森', group: 'overworld' },
  dark_forest: { en: 'Dark Forest', ja: '暗い森', group: 'overworld' },
  taiga: { en: 'Taiga', ja: 'タイガ', group: 'overworld' },
  old_growth_pine_taiga: { en: 'Old Growth Pine Taiga', ja: 'マツの原生林', group: 'overworld' },
  old_growth_spruce_taiga: { en: 'Old Growth Spruce Taiga', ja: 'トウヒの原生林', group: 'overworld' },
  snowy_taiga: { en: 'Snowy Taiga', ja: '雪のタイガ', group: 'overworld' },
  snowy_plains: { en: 'Snowy Plains', ja: '雪原', group: 'overworld' },
  ice_spikes: { en: 'Ice Spikes', ja: '樹氷', group: 'overworld' },
  // Overworld highland & mountain biomes
  meadow: { en: 'Meadow', ja: '草地', group: 'overworld' },
  cherry_grove: { en: 'Cherry Grove', ja: '桜の林', group: 'overworld' },
  grove: { en: 'Grove', ja: '林', group: 'overworld' },
  snowy_slopes: { en: 'Snowy Slopes', ja: '雪の斜面', group: 'overworld' },
  jagged_peaks: { en: 'Jagged Peaks', ja: 'ギザギザの山頂', group: 'overworld' },
  frozen_peaks: { en: 'Frozen Peaks', ja: '凍った山頂', group: 'overworld' },
  stony_peaks: { en: 'Stony Peaks', ja: '石の山頂', group: 'overworld' },
  windswept_hills: { en: 'Windswept Hills', ja: '吹きさらしの丘', group: 'overworld' },
  windswept_gravelly_hills: { en: 'Windswept Gravelly Hills', ja: '吹きさらしの砂利の丘', group: 'overworld' },
  windswept_forest: { en: 'Windswept Forest', ja: '吹きさらしの森', group: 'overworld' },
  // Overworld warm / arid / lush / wetland biomes
  desert: { en: 'Desert', ja: '砂漠', group: 'overworld' },
  savanna: { en: 'Savanna', ja: 'サバンナ', group: 'overworld' },
  savanna_plateau: { en: 'Savanna Plateau', ja: 'サバンナ台地', group: 'overworld' },
  windswept_savanna: { en: 'Windswept Savanna', ja: '吹きさらしのサバンナ', group: 'overworld' },
  jungle: { en: 'Jungle', ja: 'ジャングル', group: 'overworld' },
  sparse_jungle: { en: 'Sparse Jungle', ja: 'まばらなジャングル', group: 'overworld' },
  bamboo_jungle: { en: 'Bamboo Jungle', ja: '竹林', group: 'overworld' },
  swamp: { en: 'Swamp', ja: '沼地', group: 'overworld' },
  mangrove_swamp: { en: 'Mangrove Swamp', ja: 'マングローブの沼地', group: 'overworld' },
  badlands: { en: 'Badlands', ja: 'バッドランド', group: 'overworld' },
  eroded_badlands: { en: 'Eroded Badlands', ja: '荒れたバッドランド', group: 'overworld' },
  wooded_badlands: { en: 'Wooded Badlands', ja: '森のあるバッドランド', group: 'overworld' },
  mushroom_fields: { en: 'Mushroom Fields', ja: 'キノコ島', group: 'overworld' },
  // Coast, river & ocean biomes
  beach: { en: 'Beach', ja: '砂浜', group: 'overworld' },
  snowy_beach: { en: 'Snowy Beach', ja: '雪の砂浜', group: 'overworld' },
  stony_shore: { en: 'Stony Shore', ja: '石だらけの海岸', group: 'overworld' },
  river: { en: 'River', ja: '河川', group: 'overworld' },
  frozen_river: { en: 'Frozen River', ja: '凍った川', group: 'overworld' },
  warm_ocean: { en: 'Warm Ocean', ja: '暖かい海', group: 'overworld' },
  lukewarm_ocean: { en: 'Lukewarm Ocean', ja: 'ぬるい海', group: 'overworld' },
  deep_lukewarm_ocean: { en: 'Deep Lukewarm Ocean', ja: 'ぬるい深海', group: 'overworld' },
  ocean: { en: 'Ocean', ja: '海洋', group: 'overworld' },
  deep_ocean: { en: 'Deep Ocean', ja: '深海', group: 'overworld' },
  cold_ocean: { en: 'Cold Ocean', ja: '冷たい海', group: 'overworld' },
  deep_cold_ocean: { en: 'Deep Cold Ocean', ja: '冷たい深海', group: 'overworld' },
  frozen_ocean: { en: 'Frozen Ocean', ja: '凍った海', group: 'overworld' },
  deep_frozen_ocean: { en: 'Deep Frozen Ocean', ja: '凍った深海', group: 'overworld' },
  // Nether
  nether_wastes: { en: 'Nether Wastes', ja: 'ネザーの荒れ地', group: 'nether' },
  crimson_forest: { en: 'Crimson Forest', ja: '真紅の森', group: 'nether' },
  warped_forest: { en: 'Warped Forest', ja: '歪んだ森', group: 'nether' },
  soul_sand_valley: { en: 'Soul Sand Valley', ja: 'ソウルサンドの谷', group: 'nether' },
  basalt_deltas: { en: 'Basalt Deltas', ja: '玄武岩の三角州', group: 'nether' },
  // End
  the_end: { en: 'The End', ja: 'ジ・エンド', group: 'end' },
};

// Vanilla grass/foliage tints calibrated for #969696 base texture (Minecraft Wiki Block colors)
export const BIOME_TINTS: Record<string, [number, number, number]> = {
  plains: [0.97, 1.25, 0.60],                   // #91bd59
  sunflower_plains: [0.97, 1.25, 0.60],
  forest: [0.81, 1.28, 0.60],                   // #79c05a
  flower_forest: [0.81, 1.28, 0.60],
  birch_forest: [0.91, 1.24, 0.69],             // #88bb67
  old_growth_birch_forest: [0.91, 1.24, 0.69],
  dark_forest: [0.53, 0.88, 0.45],              // #507a32 (deep dark-forest bog-emerald)
  taiga: [0.89, 1.22, 0.87],                    // #86b783
  old_growth_spruce_taiga: [0.89, 1.22, 0.87],
  old_growth_pine_taiga: [0.89, 1.23, 0.85],    // #86b87f
  snowy_taiga: [0.85, 1.20, 1.00],              // #80b497
  snowy_plains: [0.85, 1.20, 1.00],
  ice_spikes: [0.85, 1.20, 1.00],
  snowy_slopes: [0.85, 1.20, 1.00],
  grove: [0.85, 1.20, 1.00],
  frozen_peaks: [0.85, 1.20, 1.00],
  jagged_peaks: [0.85, 1.20, 1.00],
  stony_peaks: [1.03, 1.26, 0.50],              // #9abe4b
  windswept_hills: [0.92, 1.21, 0.91],          // #8ab689
  windswept_gravelly_hills: [0.92, 1.21, 0.91],
  windswept_forest: [0.92, 1.21, 0.91],
  meadow: [0.88, 1.32, 0.72],                   // #83bb6d
  cherry_grove: [1.21, 1.46, 0.65],             // #b6db61
  desert: [1.27, 1.21, 0.57],                   // #bfb755
  savanna: [1.27, 1.22, 0.57],
  savanna_plateau: [1.27, 1.22, 0.57],
  windswept_savanna: [1.27, 1.22, 0.57],
  jungle: [0.59, 1.34, 0.41],                   // #59c93c
  sparse_jungle: [0.68, 1.32, 0.44],            // #64c73f
  bamboo_jungle: [0.59, 1.34, 0.41],
  swamp: [0.70, 0.75, 0.38],                    // #6a7039
  mangrove_swamp: [0.51, 0.79, 0.40],           // #4c763c
  badlands: [0.96, 0.86, 0.51],                 // #90814d
  eroded_badlands: [0.96, 0.86, 0.51],
  wooded_badlands: [0.96, 0.86, 0.51],
  mushroom_fields: [0.57, 1.34, 0.42],          // #55c93f
  beach: [0.97, 1.25, 0.60],
  snowy_beach: [0.85, 1.20, 1.00],
  stony_shore: [0.92, 1.21, 0.91],
  river: [0.94, 1.22, 0.72],
  ocean: [0.94, 1.22, 0.72],
  deep_ocean: [0.94, 1.22, 0.72],
  cold_ocean: [0.90, 1.18, 0.85],
  deep_cold_ocean: [0.90, 1.18, 0.85],
  lukewarm_ocean: [0.96, 1.24, 0.64],
  deep_lukewarm_ocean: [0.96, 1.24, 0.64],
  warm_ocean: [0.98, 1.26, 0.58],
  frozen_river: [0.85, 1.20, 1.00],
  frozen_ocean: [0.85, 1.20, 1.00],
  deep_frozen_ocean: [0.85, 1.20, 1.00],
  nether_wastes: [1.0, 1.0, 1.0],
  crimson_forest: [1.1, 0.7, 0.7],
  warped_forest: [0.6, 1.1, 1.1],
  soul_sand_valley: [0.8, 0.7, 0.7],
  basalt_deltas: [0.8, 0.8, 0.8],
  the_end: [1.0, 1.0, 1.0],
};

export class Noise {
  p = new Uint8Array(512);
  constructor(seed: number) {
    const r = random(seed), a = Array.from({ length: 256 }, (_, i) => i);
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(r() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    for (let i = 0; i < 512; i++) this.p[i] = a[i & 255];
  }
  fade(t: number) { return t * t * t * (t * (t * 6 - 15) + 10); }
  grad(h: number, x: number, y: number, z: number) {
    h &= 15;
    const u = h < 8 ? x : y, v = h < 4 ? y : h === 12 || h === 14 ? x : z;
    return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
  }
  n3(x: number, y: number, z: number) {
    const fx = Math.floor(x), fy = Math.floor(y), fz = Math.floor(z);
    const X = fx & 255, Y = fy & 255, Z = fz & 255;
    x -= fx; y -= fy; z -= fz;
    const u = x * x * x * (x * (x * 6 - 15) + 10);
    const v = y * y * y * (y * (y * 6 - 15) + 10);
    const w = z * z * z * (z * (z * 6 - 15) + 10);
    const p = this.p;
    const A = p[X] + Y, AA = p[A] + Z, AB = p[A + 1] + Z, B = p[X + 1] + Y, BA = p[B] + Z, BB = p[B + 1] + Z;
    const g000 = this.grad(p[AA], x, y, z), g100 = this.grad(p[BA], x - 1, y, z);
    const g010 = this.grad(p[AB], x, y - 1, z), g110 = this.grad(p[BB], x - 1, y - 1, z);
    const g001 = this.grad(p[AA + 1], x, y, z - 1), g101 = this.grad(p[BA + 1], x - 1, y, z - 1);
    const g011 = this.grad(p[AB + 1], x, y - 1, z - 1), g111 = this.grad(p[BB + 1], x - 1, y - 1, z - 1);
    const x00 = g000 + (g100 - g000) * u, x10 = g010 + (g110 - g010) * u;
    const x01 = g001 + (g101 - g001) * u, x11 = g011 + (g111 - g011) * u;
    const y0 = x00 + (x10 - x00) * v, y1 = x01 + (x11 - x01) * v;
    return y0 + (y1 - y0) * w;
  }
  /** Fast dedicated 2D gradient noise (4 lattice corners instead of 8 in n3). */
  n2(x: number, z: number) {
    const fx = Math.floor(x), fz = Math.floor(z);
    const X = fx & 255, Z = fz & 255;
    const dx = x - fx, dz = z - fz;
    const u = dx * dx * dx * (dx * (dx * 6 - 15) + 10);
    const v = dz * dz * dz * (dz * (dz * 6 - 15) + 10);
    const p = this.p;
    const A = p[X] + Z, B = p[X + 1] + Z;
    const g2 = (h: number, gx: number, gz: number) => {
      switch (h & 7) {
        case 0: return gx + gz;
        case 1: return -gx + gz;
        case 2: return gx - gz;
        case 3: return -gx - gz;
        case 4: return gx;
        case 5: return -gx;
        case 6: return gz;
        default: return -gz;
      }
    };
    const n00 = g2(p[A], dx, dz), n10 = g2(p[B], dx - 1, dz);
    const n01 = g2(p[A + 1], dx, dz - 1), n11 = g2(p[B + 1], dx - 1, dz - 1);
    const ix0 = n00 + (n10 - n00) * u;
    const ix1 = n01 + (n11 - n01) * u;
    return ix0 + (ix1 - ix0) * v;
  }
  fbm(x: number, z: number, octaves = 4) {
    let value = 0, amp = 0.57;
    for (let i = 0; i < octaves; i++) {
      value += this.n2(x, z) * amp;
      x *= 2.03; z *= 2.03; amp *= 0.5;
    }
    return value;
  }
}

export const smooth = (a: number, b: number, x: number) => {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

export function coordHash(x: number, z: number, seed: number) {
  let h = Math.imul(x, 374761393) ^ Math.imul(z, 668265263) ^ seed;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

type PutFn = (x: number, y: number, z: number, id: number, replace?: boolean) => void;

export const END_GATEWAY_MAIN: readonly [number, number, number] = [46, 33, 0];
export const END_OUTER_ARRIVAL: readonly [number, number, number] = [520, 30, 0];

export function endPillars(): { x: number; z: number; h: number; r: number; caged: boolean }[] {
  const res = [];
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI) / 4;
    const dist = 27;
    res.push({
      x: Math.round(Math.cos(a) * dist),
      z: Math.round(Math.sin(a) * dist),
      h: 37 + ((i * 5) % 14),
      r: i % 2 === 0 ? 2 : 1,
      caged: i === 1 || i === 5,
    });
  }
  return res;
}

export class Terrain {
  seed: number;
  noise: Noise;
  dimension: Dimension;
  /** Vanilla-style multi-noise source for overworld height and biomes (see overworld.ts). */
  gen: OverworldGen;
  private structCache = new Map<number, ReturnType<Terrain['regionStructureCompute']>>();
  private spawnLevel = NaN;
  /** Seed-deterministic 192-layer Badlands terracotta color band table (Minecraft Wiki spec). */
  private badlandsBands: number[];
  // Reusable chunk generation scratch buffers (eliminates >250KB GC allocation per chunk)
  private _padded = new Uint16Array(18 * 18 * HEIGHT);
  private _lastMaxLocalY = HEIGHT;
  private _hMap = new Int16Array(20 * 20);
  private _tintGrid = new Float32Array(20 * 20 * 3);
  private _biomeGrid: string[] = new Array(400);
  private _caveGrid = new Float32Array(6 * 6 * 50);
  private _tubeGrid = new Float32Array(6 * 6 * 50);
  private _cheeseGrid = new Float32Array(6 * 6 * 50);

  constructor(seed: string, dimension: Dimension = 'overworld') {
    this.seed = hashSeed(seed);
    this.noise = new Noise(this.seed);
    this.dimension = dimension;
    this.gen = new OverworldGen(this.noise);
    this.badlandsBands = this.buildBadlandsBands();
  }

  private buildBadlandsBands(): number[] {
    const r = random(this.seed ^ 0x51a9c3);
    const tc = ID.terracotta, or = ID.orange_terracotta, rd = ID.red_terracotta;
    const yl = ID.yellow_terracotta, wh = ID.white_terracotta;
    const br = ID.brown_terracotta ?? tc, lg = ID.light_gray_terracotta ?? tc;
    const bands = new Array<number>(192).fill(tc);
    const paint = (count: number, minW: number, maxW: number, blk: number) => {
      for (let i = 0; i < count; i++) {
        const w = minW + Math.floor(r() * (maxW - minW + 1));
        const p = Math.floor(r() * 192);
        for (let k = 0; k < w && p + k < 192; k++) bands[p + k] = blk;
      }
    };
    paint(18, 2, 4, or);
    paint(16, 1, 3, yl);
    paint(16, 1, 3, br);
    paint(14, 1, 2, rd);
    paint(10, 1, 1, wh);
    paint(8, 1, 2, lg);
    return bands;
  }

  spawnPoint(): [number, number, number] {
    if (this.dimension === 'nether') return [0, 25, 4];
    if (this.dimension === 'end') return [0, 30, 42];
    const sx = -11, sz = 27;
    return [sx, Math.max(SEA + 1, this.height(sx, sz) + 1), sz];
  }

  spawnPosition(above = 1.05): [number, number, number] {
    const [x, y, z] = this.spawnPoint();
    return [x + 0.5, y + above - 1, z + 0.5];
  }

  spawnYaw(): number {
    if (this.dimension === 'end') return 0;
    return -2.4;
  }

  private dungeonAt(cx: number, cz: number): [number, number, number, number, number] | null {
    if (this.dimension !== 'overworld' || coordHash(cx, cz, this.seed + 1234) >= 0.09) return null;
    const ox = cx * 16 + 4 + Math.floor(coordHash(cx, cz, this.seed + 1235) * 8);
    const oz = cz * 16 + 4 + Math.floor(coordHash(cx, cz, this.seed + 1236) * 8);
    const surf = this.height(ox, oz);
    if (surf < SEA + 2) return null;
    const y0 = Math.max(MIN_Y + 5, Math.min(surf - 10, -30 + Math.floor(coordHash(cx, cz, this.seed + 1237) * 70)));
    const rx = coordHash(cx, cz, this.seed + 1238) < 0.5 ? 3 : 4;
    const rz = coordHash(cx, cz, this.seed + 1239) < 0.5 ? 3 : 4;
    return [ox, y0, oz, rx, rz];
  }

  private dungeon(put: PutFn, room: [number, number, number, number, number]) {
    const [cx, y0, cz, rx, rz] = room;
    const cob = ID.cobblestone, mossy = ID.mossy_cobblestone ?? cob;
    for (let dy = 0; dy <= 5; dy++) {
      for (let dz = -rz - 1; dz <= rz + 1; dz++) {
        for (let dx = -rx - 1; dx <= rx + 1; dx++) {
          const wall = Math.abs(dx) === rx + 1 || Math.abs(dz) === rz + 1;
          if (dy === 0) put(cx + dx, y0, cz + dz, coordHash(cx + dx, cz + dz, this.seed + 1240) < 0.72 ? mossy : cob, true);
          else if (dy === 5) put(cx + dx, y0 + 5, cz + dz, cob, true);
          else if (wall) put(cx + dx, y0 + dy, cz + dz, cob, true);
          else put(cx + dx, y0 + dy, cz + dz, 0, true);
        }
      }
    }
    put(cx, y0 + 1, cz, ID.spawner ?? cob, true);
    put(cx - rx, y0 + 1, cz, ID.chest, true);
    if (coordHash(cx, cz, this.seed + 1241) < 0.65) put(cx, y0 + 1, cz - rz, ID.chest, true);
  }

  locate(what: string, px: number, pz: number): [number, number, number] | null {
    const q = what.toLowerCase();
    const extra = locateExtra(this, q, px, pz);
    if (extra) return extra;
    if (q === 'stronghold' || q === 'end_portal') {
      const [sx, sz] = this.strongholdPos();
      return [sx, 32, sz];
    }
    if (q === 'endcity' || q === 'end_city' || q === 'endship') {
      return [518, 30, 8];
    }
    if (q === 'fortress') {
      return [32, 26, 32];
    }
    const pcx = Math.floor(px / 16), pcz = Math.floor(pz / 16);
    if (q === 'dungeon' || q === 'spawner') {
      let best: [number, number, number] | null = null, bestD = Infinity;
      for (let dz = -24; dz <= 24; dz++) for (let dx = -24; dx <= 24; dx++) {
        const d = this.dungeonAt(pcx + dx, pcz + dz);
        if (d) {
          const dist = Math.hypot(d[0] - px, d[2] - pz);
          if (dist < bestD) { bestD = dist; best = [d[0], d[1] + 1, d[2]]; }
        }
      }
      return best;
    }
    if (['village', 'plains_village', 'desert_village', 'pyramid', 'desert_pyramid', 'temple', 'ruined_portal', 'witch_hut', 'desert_fossil'].includes(q)) {
      const prx = Math.floor(px / 112), prz = Math.floor(pz / 112);
      let best: [number, number, number] | null = null, bestD = Infinity;
      if (q === 'village' || q === 'plains_village') {
        const d0 = Math.hypot(15 - px, 16 - pz);
        bestD = d0; best = [15, this.height(15, 16) + 1, 16];
      }
      for (let dz = -12; dz <= 12; dz++) for (let dx = -12; dx <= 12; dx++) {
        const s = this.regionStructure(prx + dx, prz + dz);
        if (!s) continue;
        const match =
          (q === 'village' && (s.type === 'plains_village' || s.type === 'desert_village')) ||
          ((q === 'pyramid' || q === 'temple' || q === 'desert_pyramid') && s.type === 'desert_pyramid') ||
          s.type === q;
        if (match) {
          const dist = Math.hypot(s.x - px, s.z - pz);
          if (dist < bestD) { bestD = dist; best = [s.x, this.height(s.x, s.z) + 1, s.z]; }
        }
      }
      return best;
    }
    // Spiral biome search (faster and reaches 4000+ blocks cleanly)
    for (let r = 0; r <= 120; r++) {
      const step = r < 24 ? 16 : 32;
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;
        const wx = Math.round(px) + dx * step, wz = Math.round(pz) + dz * step;
        if (this.biome(wx, wz) === q) return [wx, this.height(wx, wz) + 1, wz];
      }
    }
    return null;
  }

  strongholdPos(): [number, number] {
    const a = coordHash(17, 29, this.seed + 42) * Math.PI * 2;
    const d = 58 + coordHash(31, 47, this.seed + 77) * 24;
    return [Math.round(Math.cos(a) * d), Math.round(Math.sin(a) * d)];
  }

  private outerEndIslandMask(x: number, z: number): number {
    const dMain = Math.hypot(x, z);
    if (dMain <= 56) return 1 - smooth(42, 58, dMain);
    if (dMain < 120) return 0;
    const dArr = Math.hypot(x - 520, z);
    if (dArr < 44) return 1 - smooth(28, 44, dArr);
    const dShip = Math.hypot(x - 538, z + 18);
    if (dShip < 14) return 0;
    const n = this.noise.fbm(x * 0.014 + 410, z * 0.014 - 230, 3);
    return smooth(0.16, 0.34, n);
  }

  height(x: number, z: number): number {
    if (this.dimension === 'nether') {
      const dSpawn = Math.hypot(x, z - 4);
      let raw = 20 + this.noise.fbm(x * 0.032, z * 0.032, 3) * 14 + this.noise.n2(x * 0.08, z * 0.08) * 3;
      const basin = this.noise.fbm(x * 0.011 - 60, z * 0.011 + 90, 2);
      if (basin > 0.12) raw -= Math.min(14, (basin - 0.12) * 90);
      const flat = 25;
      const blend = smooth(4, 14, dSpawn);
      return Math.floor(flat * (1 - blend) + raw * blend);
    }
    if (this.dimension === 'end') {
      const dMain = Math.hypot(x, z);
      if (dMain <= 60) {
        if (dMain > 56) return -20;
        const base = 24 + this.noise.fbm(x * 0.035, z * 0.035, 3) * 5;
        const flatCenter = 27;
        const b = smooth(10, 24, dMain);
        return Math.floor(flatCenter * (1 - b) + base * b - smooth(42, 56, dMain) * 10);
      }
      const mask = this.outerEndIslandMask(x, z);
      if (mask <= 0.05) return -20;
      const dArr = Math.hypot(x - 520, z);
      if (dArr < 34) return 27 + Math.floor(this.noise.n2(x * 0.06, z * 0.06) * 2 * smooth(16, 30, dArr));
      return Math.floor(20 + mask * 10 + this.noise.n2(x * 0.04, z * 0.04) * 3);
    }

    return Math.max(MIN_Y + 8, Math.min(MIN_Y + HEIGHT - 24, Math.floor(this.adapt(x, z, this.gen.column(x, z).hf))));
  }

  /** Terrain adaptation: starter cabin/village and procedural villages/pyramids sit on gently levelled ground. */
  private adapt(x: number, z: number, h: number): number {
    const ds = Math.hypot(x - 6, z - 10);
    if (ds < 58) {
      if (Number.isNaN(this.spawnLevel)) this.spawnLevel = Math.max(66.5, Math.min(75.5, this.gen.column(6, 10).hf));
      const f = smooth(58, 28, ds);
      h = h * (1 - f) + (this.spawnLevel + this.noise.n2(x * 0.025 + 3.7, z * 0.025 - 1.9) * 1.1) * f;
    }
    const rx0 = Math.floor((x - 56) / 112), rz0 = Math.floor((z - 56) / 112);
    for (let dz = 0; dz <= 1; dz++) for (let dx = 0; dx <= 1; dx++) {
      const s = this.regionStructure(rx0 + dx, rz0 + dz);
      if (!s || s.flat === undefined) continue;
      const d = Math.hypot(x - s.x, z - s.z);
      if (d < 44) {
        const f = smooth(44, 22, d);
        h = h * (1 - f) + (s.flat + this.noise.n2(x * 0.05, z * 0.05) * 0.5) * f;
      }
    }
    return h;
  }

  biomeAt(x: number, z: number, h?: number): string {
    if (this.dimension === 'nether') {
      // Mojang 1.16+ Nether Multi-Noise biome selector (T, H + offset squared distance)
      const t = this.noise.fbm(x * 0.0065 + 120, z * 0.0065 - 80, 2) * 1.25;
      const hu = this.noise.fbm(x * 0.0065 - 90, z * 0.0065 + 140, 2) * 1.25;
      const pts: readonly [string, number, number, number][] = [
        ['nether_wastes', 0.0, 0.0, 0.0],
        ['crimson_forest', 0.4, 0.0, 0.0],
        ['soul_sand_valley', 0.0, -0.5, 0.0],
        ['basalt_deltas', -0.5, 0.0, 0.175],
        ['warped_forest', 0.0, 0.5, 0.375],
      ];
      let best = 'nether_wastes', bestD = Infinity;
      for (const [name, bt, bh, off] of pts) {
        const d = (t - bt) ** 2 + (hu - bh) ** 2 + off * off;
        if (d < bestD) { bestD = d; best = name; }
      }
      return best;
    }
    if (this.dimension === 'end') return 'the_end';
    return this.gen.biomeAt(x, z, h);
  }

  /** Underground biome at a block position, or null on the surface / outside the cave biomes. */
  caveBiome(x: number, y: number, z: number): string | null {
    if (this.dimension !== 'overworld' || y > 56 || y > this.height(x, z) - 8) return null;
    const c = this.gen.column(x, z);
    // Mojang 1.18+: Deep Dark favors deep under low-erosion mountain/plateau regions;
    // Lush Caves favor high humidity; Dripstone Caves favor high continentalness inland.
    if (y < 0 && c.E < -0.32 && this.noise.n2(x * 0.008 + 910, z * 0.008 + 620) > 0.05) return 'deep_dark';
    if (c.H > 0.48 && this.noise.n2(x * 0.009 + 500, z * 0.009 - 320) > -0.1) return 'lush_caves';
    if (c.C > 0.45 && this.noise.n2(x * 0.011 - 700, z * 0.011 + 260) > -0.05) return 'dripstone_caves';
    // Fallback rare patches anywhere deep
    if (y < 0 && this.noise.fbm(x * 0.009 + 910, z * 0.009 + 620, 2) > 0.34) return 'deep_dark';
    if (this.noise.fbm(x * 0.012 + 500, z * 0.012 - 320, 2) > 0.28) return 'lush_caves';
    if (this.noise.fbm(x * 0.014 - 700, z * 0.014 + 260, 2) > 0.29) return 'dripstone_caves';
    return null;
  }

  biome(x: number, z: number) { return this.biomeAt(x, z, this.height(x, z)); }

  /** Top surface block for column (x, z), following vanilla Surface Rules. */
  surface(biome: string, x: number, z: number, h = SEA + 5): number {
    if (biome === 'desert' || biome === 'beach' || biome === 'snowy_beach') return ID.sand;
    if (biome === 'ocean' || biome === 'deep_ocean' || biome === 'cold_ocean' || biome === 'deep_cold_ocean' || biome === 'frozen_ocean' || biome === 'deep_frozen_ocean') {
      const n = this.noise.n2(x * 0.14 + 17, z * 0.14 - 31);
      if (h < SEA - 24) return n > 0.32 ? ID.sand : n < -0.35 ? ID.clay : ID.gravel;
      return n > 0.15 ? ID.gravel : n < -0.35 ? ID.clay : ID.sand;
    }
    if (biome === 'warm_ocean' || biome === 'lukewarm_ocean' || biome === 'deep_lukewarm_ocean') {
      const n = this.noise.n2(x * 0.14 + 41, z * 0.14 + 19);
      return n < -0.38 ? ID.clay : n > 0.35 ? ID.gravel : ID.sand;
    }
    if (biome === 'river' || biome === 'frozen_river') {
      if (h < SEA) {
        const n = this.noise.n2(x * 0.16 + 19, z * 0.16 - 7);
        return n < -0.25 ? ID.clay : n > 0.15 ? ID.gravel : ID.sand;
      }
      return ID.sand;
    }
    if (biome === 'stony_shore') {
      const n = this.noise.n2(x * 0.15 + 21, z * 0.15 - 11);
      return n < 0.25 ? ID.stone : ID.gravel;
    }
    if (biome === 'snowy_slopes') return ID.snow_block;
    if (biome === 'jagged_peaks') return h > 118 ? ID.snow_block : ID.stone;
    if (biome === 'frozen_peaks') {
      const n = this.noise.n2(x * 0.12 + 5, z * 0.12 + 5);
      return n > 0.22 ? ID.packed_ice : n > 0.12 ? ID.ice : ID.snow_block;
    }
    if (biome === 'stony_peaks') {
      const cal = Math.abs(this.noise.n2(x * 0.045 - 12.3, z * 0.045 + 31.7));
      if (cal < 0.045) return ID.calcite ?? ID.stone;
      return this.noise.n2(x * 0.16 + 8, z * 0.16 - 8) > 0.32 ? ID.gravel : ID.stone;
    }
    if (biome === 'grove') return ID.snow_block;
    if (biome === 'ice_spikes') return ID.snow_block;
    if (biome === 'snowy_plains' || biome === 'snowy_taiga') return ID.grass_block; // snow_layer placed on top
    if (biome === 'badlands' || biome === 'eroded_badlands') return ID.red_sand;
    if (biome === 'wooded_badlands') {
      if (h >= 97) return this.noise.n2(x * 0.11 + 3, z * 0.11 - 3) > 0.1 ? ID.coarse_dirt : ID.grass_block;
      return ID.red_sand;
    }
    if (biome === 'mangrove_swamp') {
      if (h <= SEA + 1) return ID.mud;
      return this.noise.n2(x * 0.12 + 6, z * 0.12 - 6) > 0.15 ? ID.grass_block : ID.mud;
    }
    if (biome === 'swamp' && h < SEA) return this.noise.n2(x * 0.18 + 3, z * 0.18) > 0.18 ? ID.clay : ID.dirt;
    if (biome === 'old_growth_pine_taiga' || biome === 'old_growth_spruce_taiga') {
      const n = this.noise.n2(x * 0.08 + 9, z * 0.08 - 4);
      return n > 0.08 ? ID.podzol : n < -0.22 ? ID.coarse_dirt : ID.grass_block;
    }
    if (biome === 'windswept_gravelly_hills') {
      const n = this.noise.n2(x * 0.11 + 2, z * 0.11 + 2);
      return n > -0.15 ? ID.gravel : n < -0.35 ? ID.stone : ID.grass_block;
    }
    if (biome === 'windswept_hills' || biome === 'windswept_forest') {
      return biome === 'windswept_hills' && this.noise.n2(x * 0.11, z * 0.11) > 0.18 ? ID.stone : ID.grass_block;
    }
    if (biome === 'windswept_savanna') {
      const n = this.noise.n2(x * 0.12 - 4, z * 0.12 + 4);
      return n > 0.2 ? ID.stone : n < -0.15 ? ID.coarse_dirt : ID.grass_block;
    }
    if (biome === 'crimson_forest') return ID.crimson_nylium;
    if (biome === 'warped_forest') return ID.warped_nylium;
    if (biome === 'soul_sand_valley') return coordHash(x, z, this.seed + 31) < 0.35 ? ID.soul_soil : ID.soul_sand;
    if (biome === 'basalt_deltas') return coordHash(x, z, this.seed + 37) < 0.55 ? ID.basalt : ID.blackstone;
    if (biome === 'nether_wastes') return ID.netherrack;
    if (biome === 'the_end') return ID.end_stone;
    if (biome === 'mushroom_fields') return ID.mycelium;
    return ID.grass_block;
  }

  private regionStructure(rx: number, rz: number) {
    const key = (rx + 32768) * 65536 + (rz + 32768);
    let v = this.structCache.get(key);
    if (v === undefined) {
      v = this.regionStructureCompute(rx, rz);
      if (v && (v.type === 'plains_village' || v.type === 'desert_village' || v.type === 'desert_pyramid')) {
        v.flat = Math.floor(this.gen.column(v.x, v.z).hf) + 0.5;
      }
      this.structCache.set(key, v);
    }
    return v;
  }

  private regionStructureCompute(rx: number, rz: number): { type: 'plains_village' | 'desert_village' | 'desert_pyramid' | 'ruined_portal' | 'witch_hut' | 'desert_fossil'; x: number; z: number; flat?: number } | null {
    if (Math.abs(rx) <= 0 && Math.abs(rz) <= 0) return null;
    const h = coordHash(rx, rz, this.seed + 7711);
    if (h > 0.55) return null;
    const sx = rx * 112 + 24 + Math.floor(coordHash(rx, rz, this.seed + 101) * 56);
    const sz = rz * 112 + 24 + Math.floor(coordHash(rx, rz, this.seed + 202) * 56);
    const bh = Math.floor(this.gen.column(sx, sz).hf);
    const b = this.gen.biomeAt(sx, sz, bh);
    if (bh <= SEA + 1) return null;
    if (b === 'desert') {
      return h < 0.25 ? { type: 'desert_village', x: sx, z: sz } : h < 0.42 ? { type: 'desert_pyramid', x: sx, z: sz } : { type: 'desert_fossil', x: sx, z: sz };
    }
    if (b === 'swamp') return { type: 'witch_hut', x: sx, z: sz };
    if (b === 'plains' || b === 'sunflower_plains' || b === 'meadow' || b === 'savanna' || b === 'taiga' || b === 'snowy_plains') {
      return h < 0.34 ? { type: 'plains_village', x: sx, z: sz } : { type: 'ruined_portal', x: sx, z: sz };
    }
    if (h < 0.15) return { type: 'ruined_portal', x: sx, z: sz };
    return null;
  }

  private collectNearbyStructures(ox: number, oz: number) {
    const boxes: [number, number, number, number][] = [
      [-27, -22, -15, -10],
      [2, 2, 32, 32],
      [36, 28, 48, 40],
    ];
    const rx = Math.floor((ox + 8) / 112), rz = Math.floor((oz + 8) / 112);
    const list: NonNullable<ReturnType<Terrain['regionStructure']>>[] = [];
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const s = this.regionStructure(rx + dx, rz + dz);
      if (s) {
        list.push(s);
        boxes.push([s.x - 22, s.z - 22, s.x + 22, s.z + 22]);
      }
    }
    return { boxes, list };
  }

  generate(cx: number, cz: number, edits: [string, number][] = [], structures = true) {
    const padded = this._padded;
    padded.fill(0, 0, Math.min(padded.length, (this._lastMaxLocalY + 2) * 324));
    const data = new Uint16Array(16 * 16 * HEIGHT);
    const idx = (x: number, y: number, z: number) => (y - MIN_Y) * 324 + (z + 1) * 18 + x + 1;
    const tint = new Float32Array(16 * 16 * 3);
    let maxY = SEA + 2;
    const ox = cx * 16, oz = cz * 16;

    const put: PutFn = (x, y, z, id, replace = true) => {
      x -= ox; z -= oz;
      if (x < -1 || x > 16 || z < -1 || z > 16 || y < MIN_Y || y >= MIN_Y + HEIGHT) return;
      const i = idx(x, y, z);
      if (replace || !padded[i]) padded[i] = id;
      if (y + 1 > maxY) maxY = y + 1;
    };

    const foundation = (x: number, yStart: number, z: number, id: number) => {
      for (let dy = 0; dy < 14; dy++) {
        const yy = yStart - dy;
        if (yy <= MIN_Y + 1) break;
        const lx = x - ox, lz = z - oz;
        if (lx >= -1 && lx <= 16 && lz >= -1 && lz <= 16 && dy > 0 && padded[idx(lx, yy, lz)] !== 0 && padded[idx(lx, yy, lz)] !== ID.water) break;
        put(x, yy, z, id, true);
      }
    };

    if (this.dimension === 'end') {
      const centerDist = Math.hypot(ox + 8, oz + 8);
      if (centerDist > 64 && centerDist < 116) {
        for (const [key, cell] of edits) {
          const [x, y, z] = key.split(',').map(Number);
          put(x, y, z, cell);
        }
        for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) for (let y = 0; y < HEIGHT; y++) data[y * 256 + z * 16 + x] = padded[idx(x, y + MIN_Y, z)];
        return { data, padded, tint, maxY: Math.min(MIN_Y + HEIGHT, maxY + 2) };
      }
    }

    const nearby = this.dimension === 'overworld' ? this.collectNearbyStructures(ox, oz) : { boxes: [], list: [] };
    const inExcl = (wx: number, wz: number) => {
      for (let i = 0; i < nearby.boxes.length; i++) {
        const b = nearby.boxes[i];
        if (wx >= b[0] && wx <= b[2] && wz >= b[1] && wz <= b[3]) return true;
      }
      return false;
    };

    // 20x20 grid covers [-2..17] in local chunk coordinates for height/biome/slope/tint blending
    const hMap = this._hMap;
    const biomeTintGrid = this._tintGrid;
    const biomeGrid = this._biomeGrid;
    let maxColH = SEA;
    for (let gz = -2; gz <= 17; gz++) for (let gx = -2; gx <= 17; gx++) {
      const gi = (gz + 2) * 20 + (gx + 2);
      const hh = this.height(ox + gx, oz + gz);
      hMap[gi] = hh;
      if (hh > maxColH) maxColH = hh;
      const bn = this.biomeAt(ox + gx, oz + gz, hh);
      biomeGrid[gi] = bn;
      const bt = BIOME_TINTS[bn] ?? [1, 1, 1];
      biomeTintGrid[gi * 3] = bt[0]; biomeTintGrid[gi * 3 + 1] = bt[1]; biomeTintGrid[gi * 3 + 2] = bt[2];
    }
    const getH = (x: number, z: number) => hMap[(z + 2) * 20 + (x + 2)];
    const getBiome = (x: number, z: number) => biomeGrid[(z + 2) * 20 + (x + 2)];

    const flowerAt = (fx: number, fz: number, kinds: (number | undefined)[]) => {
      const v = this.noise.n2(fx / 13 + 77.7, fz / 13 - 33.3) * 0.5 + this.noise.n2(fx / 5 - 12.1, fz / 5 + 8.6) * 0.12 + 0.5;
      return kinds[Math.max(0, Math.min(kinds.length - 1, Math.floor(((v - 0.2) / 0.6) * kinds.length)))] ?? ID.poppy;
    };

    // 3D Cave & Ore-vein noise evaluated on a coarse 4x8x4 grid and trilinearly interpolated (like Vanilla NoiseChunk).
    let caveGrid: Float32Array | undefined;
    let tubeGrid: Float32Array | undefined;
    let cheeseGrid: Float32Array | undefined;
    const nySteps = Math.min(49, Math.ceil((Math.min(maxColH + 8, MIN_Y + HEIGHT - 8) - MIN_Y) / 8) + 1);
    if (this.dimension === 'overworld') {
      caveGrid = this._caveGrid;
      tubeGrid = this._tubeGrid;
      cheeseGrid = this._cheeseGrid;
      for (let ny = 0; ny < nySteps; ny++) {
        const wy = MIN_Y + ny * 8;
        const yOff = ny * 36;
        for (let nz = 0; nz < 6; nz++) {
          const wz = oz - 2 + nz * 4;
          for (let nx = 0; nx < 6; nx++) {
            const wx = ox - 2 + nx * 4;
            const ni = yOff + nz * 6 + nx;
            caveGrid[ni] = this.noise.n3(wx * 0.048, wy * 0.065, wz * 0.048);
            tubeGrid[ni] = this.noise.n3(wx * 0.044 + 90, wy * 0.060, wz * 0.044 + 90);
            cheeseGrid[ni] = wy < 48 ? this.noise.n3(wx * 0.016 + 300, wy * 0.028, wz * 0.016 - 300) : -1;
          }
        }
      }
    }

    const colBi = (arr: Float32Array, iy: number, ix: number, iz: number, tx: number, tz: number) => {
      const i00 = iy * 36 + iz * 6 + ix;
      const x0 = arr[i00] + (arr[i00 + 1] - arr[i00]) * tx;
      const x1 = arr[i00 + 6] + (arr[i00 + 7] - arr[i00 + 6]) * tx;
      return x0 + (x1 - x0) * tz;
    };

    for (let z = -1; z <= 16; z++) for (let x = -1; x <= 16; x++) {
      const wx = ox + x, wz = oz + z, h = getH(x, z);
      const biome = getBiome(x, z);
      let top = this.surface(biome, wx, wz, h);
      const slope = Math.max(
        Math.abs(getH(x + 1, z) - h),
        Math.abs(getH(x - 1, z) - h),
        Math.abs(getH(x, z + 1) - h),
        Math.abs(getH(x, z - 1) - h),
      );
      const cliff = slope > 3 || Math.max(Math.abs(getH(x + 1, z) - getH(x - 1, z)), Math.abs(getH(x, z + 1) - getH(x, z - 1))) > 6;

      if (this.dimension === 'overworld') {
        if (h > 118 && !biome.includes('badlands') && biome !== 'stony_peaks' && biome !== 'windswept_savanna') {
          const alt = h + Math.floor(this.noise.n2(wx * 0.08, wz * 0.08) * 5);
          if (alt > 152) top = ID.snow_block;
          else if (alt > 125 && top === ID.grass_block) top = ID.stone;
        }
        if ((biome === 'snowy_slopes' || biome === 'frozen_peaks' || biome === 'jagged_peaks') && slope >= 3) {
          top = ID.stone;
        } else if ((biome === 'snowy_slopes' || biome === 'grove') && top === ID.snow_block && B.powder_snow !== undefined) {
          const ps = this.noise.n2(wx * 0.09 + 11.4, wz * 0.09 - 4.8);
          if (ps > 0.36 && ps < 0.56) top = B.powder_snow;
        }
      }

      if (x >= 0 && x < 16 && z >= 0 && z < 16) {
        // 5x5 smooth biome tint blend across biome borders
        let r = 0, g = 0, b = 0, wsum = 0;
        for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
          const gi = ((z + dz + 2) * 20 + (x + dx + 2)) * 3;
          const wgt = 3 - Math.max(Math.abs(dx), Math.abs(dz));
          r += biomeTintGrid[gi] * wgt; g += biomeTintGrid[gi + 1] * wgt; b += biomeTintGrid[gi + 2] * wgt; wsum += wgt;
        }
        const ti = (z * 16 + x) * 3;
        tint[ti] = r / wsum; tint[ti + 1] = g / wsum; tint[ti + 2] = b / wsum;
      }

      if (this.dimension === 'nether') {
        const ceilH = Math.floor(62 + this.noise.fbm(wx * 0.03 + 30, wz * 0.03 - 40, 3) * 10);
        const lavaLevel = 16;
        for (let y = 0; y <= 77; y++) {
          let id = 0;
          if (y === 0 || y === 77) id = ID.bedrock;
          else if (y <= h) {
            id = y === h && h > lavaLevel ? top : (y > h - 3 && biome === 'soul_sand_valley' ? top : ID.netherrack);
            if (biome === 'basalt_deltas' && y >= h - 2) id = top;
            if (id === ID.netherrack && y < h - 1) {
              const ore = coordHash(wx + y * 211, wz - y * 173, this.seed + 91);
              if (ore < 0.015) id = ID.nether_quartz_ore;
              else if (ore < 0.024) id = ID.nether_gold_ore;
              else if (ore < 0.026 && y <= 10) id = ID.ancient_debris;
            }
          } else if (y <= lavaLevel) {
            id = ID.lava;
          } else if (y >= ceilH) {
            id = ID.netherrack;
          }
          if (id) {
            padded[idx(x, y, z)] = id;
            if (y + 1 > maxY) maxY = y + 1;
          }
        }
        if (coordHash(wx, wz, this.seed + 511) < 0.014) {
          const len = 2 + Math.floor(coordHash(wx, wz, this.seed + 512) * 4);
          for (let dy = 1; dy <= len; dy++) put(wx, ceilH - dy, wz, ID.glowstone, true);
        }
        if (biome === 'basalt_deltas' && h > lavaLevel + 1 && coordHash(wx, wz, this.seed + 523) < 0.035) {
          const spire = 2 + Math.floor(coordHash(wx, wz, this.seed + 524) * 5);
          for (let dy = 1; dy <= spire; dy++) put(wx, h + dy, wz, ID.basalt, true);
        }
        if (biome === 'crimson_forest') {
          const r = coordHash(wx, wz, this.seed + 531);
          if (r < 0.05 && ID.crimson_fungus !== undefined) put(wx, h + 1, wz, ID.crimson_fungus, false);
          else if (r < 0.12 && ID.crimson_roots !== undefined) put(wx, h + 1, wz, ID.crimson_roots, false);
          else if (r > 0.985 && ID.weeping_vines !== undefined) for (let dy = 1; dy <= 4; dy++) put(wx, ceilH - dy, wz, ID.weeping_vines, false);
        } else if (biome === 'warped_forest') {
          const r = coordHash(wx, wz, this.seed + 532);
          if (r < 0.05 && ID.warped_fungus !== undefined) put(wx, h + 1, wz, ID.warped_fungus, false);
          else if (r < 0.1 && ID.warped_roots !== undefined) put(wx, h + 1, wz, ID.warped_roots, false);
          else if (r < 0.16 && ID.nether_sprouts !== undefined) put(wx, h + 1, wz, ID.nether_sprouts, false);
          else if (r > 0.985 && ID.twisting_vines !== undefined) for (let dy = 0; dy < 3; dy++) put(wx, h + 1 + dy, wz, ID.twisting_vines, false);
        } else if (biome === 'nether_wastes') {
          const r = coordHash(wx, wz, this.seed + 533);
          if (r < 0.012 && ID.fire !== undefined) put(wx, h + 1, wz, ID.fire, false);
          if (r > 0.995 && ID.magma_block !== undefined) put(wx, h, wz, ID.magma_block, true);
        } else if (biome === 'soul_sand_valley') {
          const r = coordHash(wx, wz, this.seed + 534);
          if (r < 0.02 && ID.soul_fire !== undefined && (top === ID.soul_sand || top === ID.soul_soil)) put(wx, h + 1, wz, ID.soul_fire, false);
          if (r > 0.99 && ID.soul_torch !== undefined) put(wx, h + 1, wz, ID.soul_torch, false);
        } else if (biome === 'basalt_deltas') {
          const r = coordHash(wx, wz, this.seed + 535);
          if (r < 0.03 && ID.magma_block !== undefined) put(wx, h, wz, ID.magma_block, true);
          else if (r > 0.992 && ID.gilded_blackstone !== undefined) put(wx, h, wz, ID.gilded_blackstone, true);
        }
        if (biome === 'soul_sand_valley' && h > lavaLevel + 1 && coordHash(wx, wz, this.seed + 527) < 0.015) {
          const archH = 3 + Math.floor(coordHash(wx, wz, this.seed + 528) * 3);
          for (let dy = 1; dy <= archH; dy++) {
            put(wx - 2, h + dy, wz, ID.bone_block, true);
            put(wx + 2, h + dy, wz, ID.bone_block, true);
          }
          for (let dx = -1; dx <= 1; dx++) put(wx + dx, h + archH + 1, wz, ID.bone_block, true);
        }
        continue;
      }

      if (this.dimension === 'end') {
        if (h < -10) continue;
        const bottom = Math.max(4, h - 10 - Math.floor(Math.abs(this.noise.n2(wx * 0.08, wz * 0.08)) * 10));
        for (let y = bottom; y <= h; y++) {
          padded[idx(x, y, z)] = ID.end_stone;
          if (y + 1 > maxY) maxY = y + 1;
        }
        continue;
      }

      // --- Overworld Column ---
      const isBadlands = biome === 'badlands' || biome === 'eroded_badlands' || biome === 'wooded_badlands';
      const isFrozenWater =
        biome === 'snowy_plains' || biome === 'ice_spikes' || biome === 'snowy_taiga' ||
        biome === 'snowy_slopes' || biome === 'grove' || biome === 'frozen_peaks' ||
        biome === 'jagged_peaks' || biome === 'frozen_river' || biome === 'frozen_ocean' ||
        biome === 'deep_frozen_ocean' || biome === 'snowy_beach';
      const bandShift = isBadlands ? Math.floor(this.noise.n2(wx * 0.05, wz * 0.05) * 4) : 0;
      const topY = Math.max(h, SEA);

      // Step-linearly interpolate cave fields along Y in 8-block steps for ~4x faster column loop
      const gxC = (x + 2) * 0.25, gzC = (z + 2) * 0.25;
      const ixC = gxC | 0, izC = gzC | 0;
      const txC = gxC - ixC, tzC = gzC - izC;
      const colStride = (z + 1) * 18 + x + 1;
      const caveLim = Math.min(h - 5, MIN_Y + nySteps * 8 - 8);
      let c0 = 0, cStep = 0, t0 = 0, tStep = 0, ch0 = -1, chStep = 0, curSeg = -1, hasCaveAir = false;

      for (let y = MIN_Y; y <= topY; y++) {
        let id = 0;
        if (y <= h) {
          if (isBadlands && y > h - 18 && y >= SEA - 2) {
            if (y === h && top === ID.grass_block) id = ID.grass_block;
            else if (y > h - 3 && top === ID.coarse_dirt) id = ID.coarse_dirt;
            else if (y === h && h < SEA + 12 && top === ID.red_sand) id = ID.red_sand;
            else if (h < SEA + 12 && y > h - 4) id = ID.orange_terracotta;
            else id = this.badlandsBands[(((y + bandShift) % 192) + 192) % 192];
          } else if (y === h) {
            id = cliff && top === ID.grass_block ? ID.stone : top;
          } else if (y > h - 4) {
            if (top === ID.sand) id = y > h - 2 ? ID.sand : ID.sandstone;
            else if (top === ID.red_sand) id = ID.red_sand;
            else if (top === ID.mud) id = ID.mud;
            else if (top === ID.snow_block || top === B.powder_snow) id = y > h - 2 ? ID.snow_block : ID.stone;
            else if (top === ID.packed_ice || top === ID.ice) id = ID.packed_ice;
            else if (top === ID.stone || top === ID.calcite || top === ID.gravel) id = top === ID.gravel && y === h - 1 ? ID.gravel : ID.stone;
            else id = cliff ? ID.stone : ID.dirt;
          } else {
            id = y < 6 - ((wx * 7 + wz * 13 + y * 3) & 7) ? ID.deepslate : ID.stone;
          }

          if (y === MIN_Y) id = ID.bedrock;
          else if (y > MIN_Y + 2 && y < caveLim && caveGrid && tubeGrid && cheeseGrid) {
            const ly = y - MIN_Y;
            const seg = ly >> 3;
            if (seg !== curSeg) {
              curSeg = seg;
              const ca = colBi(caveGrid, seg, ixC, izC, txC, tzC), cb = colBi(caveGrid, seg + 1, ixC, izC, txC, tzC);
              c0 = ca; cStep = (cb - ca) * 0.125;
              const ta = colBi(tubeGrid, seg, ixC, izC, txC, tzC), tb = colBi(tubeGrid, seg + 1, ixC, izC, txC, tzC);
              t0 = ta; tStep = (tb - ta) * 0.125;
              if (y < 48) {
                const ha = colBi(cheeseGrid, seg, ixC, izC, txC, tzC), hb = colBi(cheeseGrid, seg + 1, ixC, izC, txC, tzC);
                ch0 = ha; chStep = (hb - ha) * 0.125;
              } else { ch0 = -1; chStep = 0; }
            } else {
              c0 += cStep; t0 += tStep; ch0 += chStep;
            }
            if ((c0 * c0 + t0 * t0 < (y < h - 9 ? 0.0055 : 0.0028)) || (ch0 > 0.54 && y < h - 7)) {
              if (y < -54) id = ID.lava;
              else { id = 0; hasCaveAir = true; }
            }
          }
        } else if (y <= SEA) {
          if (y === SEA && isFrozenWater) {
            if (biome === 'frozen_ocean' || biome === 'deep_frozen_ocean') {
              id = this.noise.n2(wx * 0.045 + 9.3, wz * 0.045 + 2.1) > -0.1 ? ID.ice : ID.water;
            } else {
              id = ID.ice;
            }
          } else {
            id = ID.water;
          }
        }
        padded[(y - MIN_Y) * 324 + colStride] = id;
      }
      if (h + 1 > maxY) maxY = h + 1;

      // Cave biomes decoration (only when column actually contains carved cave air)
      if (hasCaveAir) {
        const cCol = this.gen.column(wx, wz);
        const kDark = cCol.E < -0.15 && (cCol.E < -0.32 ? this.noise.n2(wx * 0.008 + 910, wz * 0.008 + 620) > 0.05 : this.noise.fbm(wx * 0.009 + 910, wz * 0.009 + 620, 2) > 0.34);
        const kLush = cCol.H > 0.25 && (cCol.H > 0.48 ? this.noise.n2(wx * 0.009 + 500, wz * 0.009 - 320) > -0.1 : this.noise.fbm(wx * 0.012 + 500, wz * 0.012 - 320, 2) > 0.28);
        const kDrip = !kLush && cCol.C > 0.20 && (cCol.C > 0.45 ? this.noise.n2(wx * 0.011 - 700, wz * 0.011 + 260) > -0.05 : this.noise.fbm(wx * 0.014 - 700, wz * 0.014 + 260, 2) > 0.29);
        if (kDark || kLush || kDrip) {
          const limit = Math.min(h - 8, 56);
          for (let y = MIN_Y + 3; y < limit; y++) {
            const i = idx(x, y, z);
            if (padded[i] !== 0) continue;
            const kind = y < 0 && kDark ? 3 : kLush ? 1 : kDrip ? 2 : 0;
            if (!kind) continue;
            const below = padded[i - 324], above = padded[i + 324];
            const solidBelow = below !== 0 && below !== ID.lava && BLOCKS[below]?.solid && BLOCKS[below].shape === 'cube';
            const solidAbove = above !== 0 && above !== ID.lava && BLOCKS[above]?.solid && BLOCKS[above].shape === 'cube';
            const r = coordHash(wx + y * 131, wz - y * 71, this.seed + 808);
            if (solidBelow) {
              if (kind === 1) {
                padded[i - 324] = r > 0.92 ? ID.clay : ID.moss_block;
                padded[i] = r < 0.08 ? ID.azalea : r < 0.12 ? ID.flowering_azalea : r < 0.34 ? ID.short_grass : r < 0.44 ? ID.moss_carpet : r < 0.48 ? ID.big_dripleaf : 0;
              } else if (kind === 2) {
                if (r < 0.72) padded[i - 324] = ID.dripstone_block;
                if (r < 0.22) {
                  const len = 1 + Math.floor(coordHash(wx, wz + y, this.seed + 809) * 3);
                  for (let k = 0; k < len && y + k < limit && padded[idx(x, y + k, z)] === 0; k++) padded[idx(x, y + k, z)] = ID.pointed_dripstone;
                }
              } else {
                if (r < 0.9) padded[i - 324] = r < 0.02 ? ID.sculk_catalyst : ID.sculk_block;
                padded[i] = r > 0.985 ? ID.sculk_shrieker : r > 0.96 ? ID.sculk_sensor : 0;
              }
            } else if (solidAbove) {
              if (kind === 1) {
                padded[i + 324] = ID.moss_block;
                if (r < 0.18) {
                  const len = 1 + Math.floor(coordHash(wx, wz - y, this.seed + 810) * 5);
                  for (let k = 0; k < len && y - k > MIN_Y + 3 && padded[idx(x, y - k, z)] === 0; k++) padded[idx(x, y - k, z)] = ID.cave_vines;
                } else if (r < 0.22) padded[i] = ID.spore_blossom;
                else if (r < 0.28) padded[i] = ID.hanging_roots;
              } else if (kind === 2) {
                if (r < 0.72) padded[i + 324] = ID.dripstone_block;
                if (r < 0.26) {
                  const len = 1 + Math.floor(coordHash(wx + y, wz, this.seed + 811) * 4);
                  for (let k = 0; k < len && y - k > MIN_Y + 3 && padded[idx(x, y - k, z)] === 0; k++) padded[idx(x, y - k, z)] = ID.pointed_dripstone;
                }
              } else if (r < 0.6) {
                padded[i + 324] = ID.sculk_block;
              }
            }
          }
        }
      }

      // Snow cover on cold biomes
      if (h >= SEA && !inExcl(wx, wz) && (biome === 'snowy_plains' || biome === 'snowy_taiga' || biome === 'snowy_beach' || biome === 'grove' || biome === 'ice_spikes') && ID.snow_layer !== undefined) {
        if (top === ID.grass_block || top === ID.sand || top === ID.snow_block || top === ID.dirt) {
          put(wx, h + 1, wz, ID.snow_layer, false);
        }
      }
      if (biome === 'snowy_plains' && h >= SEA + 1 && !inExcl(wx, wz) && this.noise.n2(wx / 8 + 40.5, wz / 8 - 12.5) > 0.55) {
        put(wx, h, wz, ID.ice, true);
      }

      // Ocean & river vegetation
      const isOcean = biome.endsWith('ocean');
      if (isOcean && h < SEA - 1) {
        const r2 = coordHash(wx, wz, this.seed + 77);
        if (biome === 'warm_ocean') {
          if (r2 < 0.009 && h < SEA - 3) {
            placeCoralReef(put, wx, h, wz, this.seed, SEA - 1);
          } else if (r2 < 0.16) {
            put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
          } else if (r2 > 0.985 && h > SEA - 10) {
            put(wx, h + 1, wz, ID.sea_pickle ?? ID.seagrass, false);
          }
        } else if (r2 < 0.05) {
          const tall = 2 + Math.floor(coordHash(wx, wz, this.seed + 79) * 9);
          for (let k = 1; k <= tall && h + k < SEA; k++) put(wx, h + k, wz, ID.kelp ?? ID.seagrass, true);
        } else if (r2 < 0.16) {
          put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
        }
      }
      if (biome === 'river' && h < SEA - 1) {
        if (coordHash(wx, wz, this.seed + 81) < 0.09) put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
      }
      if ((biome === 'swamp' || biome === 'mangrove_swamp') && h < SEA) {
        if (coordHash(wx, wz, this.seed + 82) < 0.06) put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
      }

      // Lily pads on swamp/mangrove/river water
      if (h < SEA && h >= SEA - 4 && (biome === 'swamp' || biome === 'mangrove_swamp' || biome === 'river') && coordHash(wx, wz, this.seed + 61) < (biome === 'river' ? 0.012 : 0.075)) {
        put(wx, SEA + 1, wz, ID.lily_pad ?? ID.short_grass, false);
      }

      // Ground flora & details
      if (h > SEA + 1 && !cliff && (top === ID.grass_block || top === ID.podzol || top === ID.mycelium || top === ID.mud || top === ID.coarse_dirt) && !inExcl(wx, wz)) {
        const r = coordHash(wx, wz, this.seed + 44);
        if (biome === 'cherry_grove') {
          if (r < 0.34) put(wx, h + 1, wz, ID.pink_petals ?? ID.poppy, false);
          else if (r < 0.48) put(wx, h + 1, wz, ID.short_grass, false);
        } else if (biome === 'flower_forest') {
          if (r < 0.24) put(wx, h + 1, wz, flowerAt(wx, wz, [ID.dandelion, ID.poppy, ID.allium, ID.azure_bluet, ID.red_tulip, ID.orange_tulip, ID.pink_tulip, ID.white_tulip, ID.oxeye_daisy, ID.cornflower, ID.lily_of_the_valley]), false);
          else if (r < 0.40) put(wx, h + 1, wz, ID.short_grass, false);
        } else if (biome === 'sunflower_plains') {
          const patch = this.noise.n2(wx / 19 + 4.4, wz / 19 - 7.7) > 0.08;
          if (patch && r < 0.16 && B.sunflower !== undefined) put(wx, h + 1, wz, B.sunflower, false);
          else if (r < 0.36) put(wx, h + 1, wz, r < 0.28 ? ID.short_grass : (B.tall_grass ?? ID.short_grass), false);
        } else if (biome === 'plains') {
          const field = this.noise.n2(wx / 37 + 5.5, wz / 37 - 9.9) > 0.22;
          if (r < (field ? 0.09 : 0.008)) put(wx, h + 1, wz, flowerAt(wx, wz, [ID.dandelion, ID.poppy, ID.azure_bluet, ID.oxeye_daisy, ID.cornflower]), false);
          else if (r < 0.32) put(wx, h + 1, wz, r < 0.27 ? ID.short_grass : (B.tall_grass ?? ID.short_grass), false);
        } else if (biome === 'meadow') {
          if (r < 0.14) put(wx, h + 1, wz, flowerAt(wx, wz, [ID.dandelion, ID.poppy, ID.cornflower, ID.allium, ID.azure_bluet, ID.oxeye_daisy]), false);
          else if (r < 0.50) put(wx, h + 1, wz, r < 0.42 ? ID.short_grass : (B.tall_grass ?? ID.short_grass), false);
        } else if (biome === 'taiga' || biome === 'snowy_taiga' || biome === 'old_growth_pine_taiga' || biome === 'old_growth_spruce_taiga') {
          if (top === ID.coarse_dirt && r < 0.06) put(wx, h + 1, wz, ID.dead_bush, false);
          else if (r < 0.12) put(wx, h + 1, wz, r < 0.07 ? ID.fern : r < 0.09 ? (B.large_fern ?? ID.fern) : ID.brown_mushroom, false);
          else if ((biome === 'taiga' || biome === 'snowy_taiga') && r > 0.94 && ID.sweet_berry_bush !== undefined) put(wx, h + 1, wz, ID.sweet_berry_bush, false);
        } else if (biome === 'mushroom_fields') {
          if (r < 0.07) put(wx, h + 1, wz, r < 0.035 ? ID.red_mushroom : ID.brown_mushroom, false);
        } else if (biome === 'birch_forest' || biome === 'old_growth_birch_forest') {
          if (r < 0.12) put(wx, h + 1, wz, r < 0.02 ? (ID.lily_of_the_valley ?? ID.dandelion) : ID.short_grass, false);
        } else if (biome === 'dark_forest') {
          if (r < 0.08) put(wx, h + 1, wz, r < 0.03 && B.leaf_litter !== undefined ? B.leaf_litter : ID.short_grass, false);
        } else if (biome === 'swamp') {
          if (r < 0.14) put(wx, h + 1, wz, r < 0.035 ? (ID.blue_orchid ?? ID.short_grass) : r < 0.055 ? ID.brown_mushroom : ID.short_grass, false);
        } else if (biome === 'mangrove_swamp') {
          if (r < 0.10) put(wx, h + 1, wz, r < 0.025 ? ID.dead_bush : r < 0.06 ? (B.tall_grass ?? ID.short_grass) : ID.short_grass, false);
        } else if (biome === 'jungle' || biome === 'sparse_jungle' || biome === 'bamboo_jungle') {
          const bambooPatch = biome === 'bamboo_jungle' || this.noise.n2(wx / 22 - 8.1, wz / 22 + 3.7) > 0.35;
          if (bambooPatch && r > (biome === 'bamboo_jungle' ? 0.72 : 0.94) && ID.bamboo !== undefined) {
            const bh = 4 + Math.floor(coordHash(wx, wz, this.seed + 84) * 9);
            for (let k = 1; k <= bh; k++) put(wx, h + k, wz, ID.bamboo, false);
          } else if (r < 0.42) {
            put(wx, h + 1, wz, r < 0.16 ? (ID.jungle_fern ?? ID.fern) : r < 0.22 ? (B.large_fern ?? ID.fern) : ID.short_grass, false);
          }
        } else if (biome === 'savanna' || biome === 'savanna_plateau' || biome === 'windswept_savanna') {
          if (r < 0.32) put(wx, h + 1, wz, r < 0.24 ? ID.short_grass : (B.tall_grass ?? ID.short_grass), false);
        } else if (r < 0.12) {
          const f = r < 0.01 ? ID.poppy : r < 0.018 ? ID.dandelion : r < 0.024 ? ID.cornflower : r < 0.029 ? ID.oxeye_daisy : r < 0.034 ? ID.red_mushroom : r < 0.039 ? ID.brown_mushroom : r < 0.05 && B.leaf_litter !== undefined ? B.leaf_litter : ID.short_grass;
          put(wx, h + 1, wz, f ?? ID.short_grass, false);
        }

        // Sugar cane strictly next to water
        const nextToWater = getH(x + 1, z) < SEA || getH(x - 1, z) < SEA || getH(x, z + 1) < SEA || getH(x, z - 1) < SEA;
        if (nextToWater && h === SEA + 1 && coordHash(wx, wz, this.seed + 66) < 0.065) {
          const sh = 2 + Math.floor(coordHash(wx, wz, this.seed + 67) * 2);
          for (let yy = 1; yy <= sh; yy++) put(wx, h + yy, wz, ID.sugar_cane, false);
        }
      }

      // Cactus, Dead Bush & Desert Fossils
      if ((biome === 'desert' || isBadlands) && !cliff && h > SEA + 1 && (top === ID.sand || top === ID.red_sand) && !inExcl(wx, wz)) {
        const dr = coordHash(wx, wz, this.seed + 55);
        const flatNeighbors = getH(x + 1, z) <= h && getH(x - 1, z) <= h && getH(x, z + 1) <= h && getH(x, z - 1) <= h;
        if (dr < 0.0045 && flatNeighbors && ((wx + wz) & 1) === 0) {
          const ch = 1 + Math.floor(coordHash(wx, wz, this.seed + 59) * 3);
          for (let y = 1; y <= ch; y++) put(wx, h + y, wz, ID.cactus, true);
        } else if (dr < 0.022) {
          put(wx, h + 1, wz, ID.dead_bush ?? ID.short_grass, false);
        } else if (dr > 0.9996 && flatNeighbors && biome === 'desert') {
          for (let dy = -1; dy <= 2; dy++) put(wx, h + dy, wz, ID.bone_block, true);
          put(wx - 1, h + 1, wz, ID.bone_block, true);
          put(wx + 1, h + 1, wz, ID.bone_block, true);
        }
      }
    }

    // --- Overworld Ore Blobs (Vanilla triangular / uniform clusters) ---
    if (this.dimension === 'overworld') {
      const placeBlob = (wx: number, wy: number, wz: number, oreId: number, size: number, allowAir = true) => {
        if (wy <= MIN_Y + 1 || wy >= maxColH - 1) return;
        for (let k = 0; k < size; k++) {
          const ox2 = wx + Math.floor((coordHash(wx + k * 7, wz - k * 11, this.seed + wy) - 0.5) * 2.4);
          const oy2 = wy + Math.floor((coordHash(wx - k * 5, wy + k * 13, this.seed + wz) - 0.5) * 2.2);
          const oz2 = wz + Math.floor((coordHash(wz + k * 9, wy - k * 3, this.seed + wx) - 0.5) * 2.4);
          const lx = ox2 - ox, lz = oz2 - oz;
          if (lx < -1 || lx > 16 || lz < -1 || lz > 16 || oy2 <= MIN_Y || oy2 >= MIN_Y + HEIGHT) continue;
          const cur = padded[idx(lx, oy2, lz)];
          if (cur !== ID.stone && cur !== ID.deepslate) continue;
          if (!allowAir) {
            if (padded[idx(lx, oy2 + 1, lz)] === 0 || padded[idx(lx, oy2 - 1, lz)] === 0) continue;
          }
          const finalOre = cur === ID.deepslate ? (ID['deepslate_' + BLOCKS[oreId].name] ?? oreId) : oreId;
          padded[idx(lx, oy2, lz)] = finalOre;
        }
      };

      const triY = (minY: number, maxY: number, peakY: number, u1: number, u2: number) => {
        const t = (u1 + u2) * 0.5;
        return t < 0.5 ? Math.floor(minY + (peakY - minY) * (t * 2)) : Math.floor(peakY + (maxY - peakY) * ((t - 0.5) * 2));
      };

      const centerBiome = getBiome(8, 8);
      const inMtn = ['meadow', 'cherry_grove', 'grove', 'snowy_slopes', 'jagged_peaks', 'frozen_peaks', 'stony_peaks', 'windswept_hills', 'windswept_gravelly_hills', 'windswept_forest'].includes(centerBiome);
      const inBad = centerBiome.includes('badlands');

      const oreAttempts: [number, number, number, number, number, number, boolean][] = [
        [ID.coal_ore, 14, 0, 192, 96, 8, true],
        [ID.iron_ore, 10, -24, 56, 16, 6, true],
        [ID.iron_ore, 8, -64, 72, 4, 4, true],
        [ID.iron_ore, 16, 80, 260, 200, 6, true],
        [ID.copper_ore, 10, -16, 112, 48, 7, true],
        [ID.gold_ore, 5, -64, 32, -16, 6, false],
        [ID.redstone_ore, 8, -64, 15, -59, 6, true],
        [ID.diamond_ore, 7, -64, 16, -59, 4, true],
        [ID.diamond_ore, 3, -64, -4, -34, 6, true],
        [ID.lapis_ore, 4, -32, 32, 0, 5, false],
      ];
      if (inBad) oreAttempts.push([ID.gold_ore, 22, 32, 240, 136, 7, true]);
      if (inMtn) oreAttempts.push([ID.emerald_ore, 26, -16, 260, 190, 2, true]);

      for (let oi = 0; oi < oreAttempts.length; oi++) {
        const [oreId, count, minY, maxY, peakY, size, allowAir] = oreAttempts[oi];
        for (let k = 0; k < count; k++) {
          const s = this.seed + oi * 997 + k * 53;
          const rx = ox + Math.floor(coordHash(cx, cz + k, s) * 16);
          const rz = oz + Math.floor(coordHash(cx + k, cz, s + 1) * 16);
          const ry = triY(minY, maxY, peakY, coordHash(cx + oi, cz + k, s + 2), coordHash(cx + k, cz + oi, s + 3));
          placeBlob(rx, ry, rz, oreId, size, allowAir);
        }
      }
    }

    // --- Overworld Trees & Biome Features (wide cross-chunk neighborhood so canopies never clip at chunk borders) ---
    if (this.dimension === 'overworld') {
      // Sparse feature grid (Ice Spikes, Icebergs, Desert Wells, Forest Rocks, Azalea Trees)
      for (let gz = Math.floor((oz - 12) / 14); gz <= Math.floor((oz + 28) / 14); gz++) {
        for (let gx = Math.floor((ox - 12) / 14); gx <= Math.floor((ox + 28) / 14); gx++) {
          const r = coordHash(gx, gz, this.seed + 1411);
          const x = gx * 14 + Math.floor(coordHash(gx, gz, this.seed + 1412) * 14);
          const z = gz * 14 + Math.floor(coordHash(gx, gz, this.seed + 1413) * 14);
          if (inExcl(x, z)) continue;
          const lxF = x - ox, lzF = z - oz;
          const inGridF = lxF >= -2 && lxF <= 17 && lzF >= -2 && lzF <= 17;
          const h = inGridF ? getH(lxF, lzF) : this.height(x, z);
          const biome = inGridF ? getBiome(lxF, lzF) : this.biomeAt(x, z, h);
          if (biome === 'ice_spikes' && h >= SEA + 1 && r < 0.58) {
            placeIceSpike(put, x, h, z, this.seed);
          } else if ((biome === 'frozen_ocean' || biome === 'deep_frozen_ocean') && h < SEA - 6 && r < 0.14) {
            placeIceberg(put, x, SEA, z, this.seed);
          } else if ((biome === 'old_growth_pine_taiga' || biome === 'old_growth_spruce_taiga') && h >= SEA + 1 && r < 0.25) {
            placeForestRock(put, x, h + 1, z, this.seed);
          } else if (biome === 'desert' && h >= SEA + 2 && r < 0.025) {
            placeDesertWell(put, x, h, z);
          } else if (h >= SEA + 2 && r < 0.18 && biome !== 'birch_forest' && biome !== 'old_growth_birch_forest' && this.caveBiome(x, 20, z) === 'lush_caves') {
            placeAzaleaTree(put, x, h, z, this.seed);
          }
        }
      }

      // Main tree grid (7x7 cells with full jitter)
      for (let gz = Math.floor((oz - 8) / 7); gz <= Math.floor((oz + 24) / 7); gz++) {
        for (let gx = Math.floor((ox - 8) / 7); gx <= Math.floor((ox + 24) / 7); gx++) {
          const r = coordHash(gx, gz, this.seed + 818);
          const x = gx * 7 + Math.floor(coordHash(gx, gz, this.seed + 23) * 7);
          const z = gz * 7 + Math.floor(coordHash(gx, gz, this.seed + 24) * 7);
          if (inExcl(x, z)) continue;
          const lxT = x - ox, lzT = z - oz;
          const inGridT = lxT >= -2 && lxT <= 17 && lzT >= -2 && lzT <= 17;
          const h = inGridT ? getH(lxT, lzT) : this.height(x, z);
          const biome = inGridT ? getBiome(lxT, lzT) : this.biomeAt(x, z, h);

          // Swamp/Mangrove trees can root in shallow water (SEA - 1)
          const minTreeH = (biome === 'swamp' || biome === 'mangrove_swamp') ? SEA - 1 : SEA + 2;
          if (h < minTreeH) continue;

          const chance =
            biome === 'dark_forest' ? 0.88 :
            biome === 'jungle' ? 0.86 :
            biome === 'sparse_jungle' ? 0.24 :
            biome === 'bamboo_jungle' ? 0.55 :
            biome === 'cherry_grove' ? 0.65 :
            biome === 'birch_forest' || biome === 'old_growth_birch_forest' ? 0.68 :
            biome === 'forest' ? 0.66 :
            biome === 'taiga' || biome === 'snowy_taiga' ? 0.62 :
            biome === 'old_growth_pine_taiga' || biome === 'old_growth_spruce_taiga' ? 0.64 :
            biome === 'grove' ? 0.52 :
            biome === 'mangrove_swamp' ? 0.62 :
            biome === 'flower_forest' ? 0.36 :
            biome === 'swamp' ? 0.32 :
            biome === 'windswept_forest' ? 0.34 :
            biome === 'wooded_badlands' ? (h >= 97 ? 0.38 : 0) :
            biome === 'savanna' || biome === 'savanna_plateau' || biome === 'windswept_savanna' ? 0.14 :
            biome === 'mushroom_fields' ? 0.26 :
            biome === 'windswept_hills' || biome === 'windswept_gravelly_hills' ? 0.06 :
            biome === 'snowy_plains' ? 0.03 :
            biome === 'plains' || biome === 'sunflower_plains' ? 0.04 : 0;

          if (r > chance) continue;
          const surf = this.surface(biome, x, z, h);
          if (
            surf !== ID.grass_block && surf !== ID.podzol && surf !== ID.mycelium &&
            surf !== ID.snow_block && surf !== ID.mud && surf !== ID.coarse_dirt &&
            !(biome === 'swamp' && h < SEA)
          ) continue;

          const rKind = coordHash(gx, gz, this.seed + 911);

          if (biome === 'mushroom_fields') {
            placeHugeMushroom(put, x, h, z, this.seed, rKind < 0.5);
          } else if (biome === 'dark_forest') {
            if (rKind < 0.04) placeHugeMushroom(put, x, h, z, this.seed, true);
            else if (rKind < 0.07) placeHugeMushroom(put, x, h, z, this.seed, false);
            else if (rKind < 0.72) placeDarkOakTree(put, x, h, z, this.seed);
            else if (rKind < 0.88) placeBlobTree(put, x, h, z, this.seed, ID.birch_log, ID.birch_leaves, 5, 2);
            else if (rKind < 0.94) placeFancyOakTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          } else if (biome === 'cherry_grove') {
            placeCherryTree(put, x, h, z, this.seed);
          } else if (biome === 'mangrove_swamp') {
            placeMangroveTree(put, x, h, z, this.seed);
          } else if (biome === 'swamp') {
            placeSwampOakTree(put, x, h, z, this.seed);
          } else if (biome === 'savanna' || biome === 'savanna_plateau' || biome === 'windswept_savanna') {
            if (rKind < 0.85) placeAcaciaTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          } else if (biome === 'jungle' || biome === 'sparse_jungle' || biome === 'bamboo_jungle') {
            if (biome !== 'sparse_jungle' && rKind < 0.30) placeMegaJungleTree(put, x, h, z, this.seed);
            else if (rKind < 0.72) placeJungleBush(put, x, h, z, this.seed);
            else if (rKind < 0.84) placeFancyOakTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.jungle_log, ID.jungle_leaves, 4, 7, { vines: true, cocoa: true });
          } else if (biome === 'old_growth_pine_taiga' || biome === 'old_growth_spruce_taiga') {
            const isSpruceBiome = biome === 'old_growth_spruce_taiga';
            if (rKind < 0.33) placeMegaTaigaTree(put, x, h, z, this.seed, isSpruceBiome || rKind < 0.03);
            else placeSpruceOrPine(put, x, h, z, this.seed, rKind < 0.66);
          } else if (biome === 'taiga' || biome === 'snowy_taiga' || biome === 'grove' || biome === 'snowy_plains') {
            placeSpruceOrPine(put, x, h, z, this.seed, rKind < 0.33);
          } else if (biome === 'birch_forest' || biome === 'old_growth_birch_forest') {
            const tall = biome === 'old_growth_birch_forest';
            placeBlobTree(put, x, h, z, this.seed, ID.birch_log, ID.birch_leaves, tall ? 7 : 5, tall ? 6 : 2);
          } else if (biome === 'windswept_hills' || biome === 'windswept_gravelly_hills' || biome === 'windswept_forest') {
            if (rKind < 0.67) placeSpruceOrPine(put, x, h, z, this.seed, false);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          } else if (biome === 'forest' || biome === 'flower_forest') {
            if (rKind < 0.20) placeBlobTree(put, x, h, z, this.seed, ID.birch_log, ID.birch_leaves, 5, 2);
            else if (rKind < 0.30) placeFancyOakTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          } else {
            // Plains / Sunflower Plains / Wooded Badlands
            if (biome !== 'wooded_badlands' && rKind < 0.15) placeFancyOakTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          }
        }
      }
    }

    // Nether Crimson & Warped Huge Fungi
    if (this.dimension === 'nether') {
      for (let gz = Math.floor((oz - 5) / 9); gz <= Math.floor((oz + 21) / 9); gz++) {
        for (let gx = Math.floor((ox - 5) / 9); gx <= Math.floor((ox + 21) / 9); gx++) {
          const r = coordHash(gx, gz, this.seed + 613);
          if (r > 0.45) continue;
          const x = gx * 9 + Math.floor(coordHash(gx, gz, this.seed + 25) * 6);
          const z = gz * 9 + Math.floor(coordHash(gx, gz, this.seed + 26) * 6);
          const h = this.height(x, z);
          if (h <= 17) continue;
          const b = this.biomeAt(x, z, h);
          if (b !== 'crimson_forest' && b !== 'warped_forest') continue;
          const ceilH = Math.floor(62 + this.noise.fbm(x * 0.03 + 30, z * 0.03 - 40, 3) * 10);
          placeHugeFungus(put, x, h, z, this.seed, b === 'crimson_forest', ceilH);
        }
      }
    }

    // Outer End Chorus Plants
    if (this.dimension === 'end') {
      for (let gz = Math.floor((oz - 6) / 10); gz <= Math.floor((oz + 22) / 10); gz++) {
        for (let gx = Math.floor((ox - 6) / 10); gx <= Math.floor((ox + 22) / 10); gx++) {
          const x = gx * 10 + Math.floor(coordHash(gx, gz, this.seed + 911) * 7);
          const z = gz * 10 + Math.floor(coordHash(gx, gz, this.seed + 912) * 7);
          if (Math.hypot(x, z) < 120) continue;
          if (Math.hypot(x - 518, z - 12) < 20) continue;
          const h = this.height(x, z);
          if (h < 10) continue;
          if (coordHash(gx, gz, this.seed + 913) < 0.35) {
            placeChorusPlant(put, x, h + 1, z, this.seed);
          }
        }
      }
    }

    // Structures
    if (structures && this.dimension === 'overworld') {
      if (ox < 0 && ox >= -48 && oz < 0 && oz >= -48) this.cabin(put, foundation, -24, -19);
      if (ox >= -16 && ox < 48 && oz >= -16 && oz < 48) {
        this.plainsHouse(put, foundation, 6, 8, 5, 5);
        this.plainsHouse(put, foundation, 20, 10, 6, 5);
        this.plainsHouse(put, foundation, 8, 22, 5, 6);
        this.villageWellAndPaths(put, foundation, 15, 16);
        this.ruinedPortal(put, foundation, 40, 32);
      }
      const [shx, shz] = this.strongholdPos();
      if (Math.abs(ox + 8 - shx) < 28 && Math.abs(oz + 8 - shz) < 28) {
        this.stronghold(put, shx, shz);
      }
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const room = this.dungeonAt(cx + dx, cz + dz);
        if (room) this.dungeon(put, room);
      }
      for (const s of nearby.list) {
        if (Math.abs(ox + 8 - s.x) > 36 || Math.abs(oz + 8 - s.z) > 36) continue;
        if (s.type === 'desert_village') this.desertVillage(put, foundation, s.x, s.z);
        else if (s.type === 'desert_pyramid') this.desertPyramid(put, foundation, s.x, s.z);
        else if (s.type === 'plains_village') {
          this.plainsHouse(put, foundation, s.x - 10, s.z - 8, 5, 5);
          this.plainsHouse(put, foundation, s.x + 5, s.z - 6, 6, 5);
          this.plainsHouse(put, foundation, s.x - 6, s.z + 6, 5, 6);
          this.villageWellAndPaths(put, foundation, s.x, s.z);
        } else if (s.type === 'ruined_portal') {
          this.ruinedPortal(put, foundation, s.x, s.z);
        } else if (s.type === 'witch_hut') {
          this.witchHut(put, foundation, s.x, s.z);
        } else if (s.type === 'desert_fossil') {
          this.desertFossil(put, s.x, s.z);
        }
      }
    }

    if (structures && this.dimension === 'nether') {
      if (Math.abs(ox) <= 16 && Math.abs(oz) <= 16) {
        for (let dz = -4; dz <= 12; dz++) for (let dx = -4; dx <= 4; dx++) {
          put(dx, 24, dz, ID.netherrack, true);
          for (let dy = 1; dy <= 5; dy++) put(dx, 24 + dy, dz, 0, true);
        }
      }
      const nrx = Math.floor((ox + 8) / 128), nrz = Math.floor((oz + 8) / 128);
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const rrx = nrx + dx, rrz = nrz + dz;
        const fx = rrx === 0 && rrz === 0 ? 32 : rrx * 128 + 48;
        const fz = rrx === 0 && rrz === 0 ? 32 : rrz * 128 + 48;
        if ((rrx === 0 && rrz === 0) || coordHash(rrx, rrz, this.seed + 5555) < 0.42) {
          if (Math.abs(ox + 8 - fx) < 36 && Math.abs(oz + 8 - fz) < 36) this.fortress(put, fx, fz);
        }
      }
    }

    if (structures && this.dimension === 'end') {
      if (Math.hypot(ox + 8, oz + 8) <= 72) {
        for (let dz = 40; dz <= 44; dz++) for (let dx = -2; dx <= 2; dx++) {
          put(dx, 29, dz, ID.obsidian, true);
          for (let dy = 1; dy <= 5; dy++) put(dx, 29 + dy, dz, 0, true);
        }
        for (const pil of endPillars()) {
          if (Math.abs(ox + 8 - pil.x) > 16 || Math.abs(oz + 8 - pil.z) > 16) continue;
          for (let y = 18; y <= pil.h; y++) {
            for (let dz = -pil.r; dz <= pil.r; dz++) for (let dx = -pil.r; dx <= pil.r; dx++) {
              if (dx * dx + dz * dz <= pil.r * pil.r + 1) put(pil.x + dx, y, pil.z + dz, ID.obsidian, true);
            }
          }
          put(pil.x, pil.h + 1, pil.z, ID.bedrock, true);
          if (pil.caged) {
            const cr = pil.r + 1;
            for (let y = pil.h + 1; y <= pil.h + 4; y++) {
              for (let dz = -cr; dz <= cr; dz++) for (let dx = -cr; dx <= cr; dx++) {
                if (Math.abs(dx) === cr || Math.abs(dz) === cr || y === pil.h + 4) put(pil.x + dx, y, pil.z + dz, ID.iron_bars, true);
              }
            }
          }
        }
        if (Math.abs(ox + 8) < 16 && Math.abs(oz + 8) < 16) {
          for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
            const r2 = dx * dx + dz * dz;
            if (r2 <= 10) {
              put(dx, 27, dz, ID.bedrock, true);
              if (r2 >= 5) put(dx, 28, dz, ID.bedrock, true);
              else put(dx, 28, dz, 0, true);
            }
          }
          for (let dy = 1; dy <= 4; dy++) put(0, 27 + dy, 0, ID.bedrock, true);
          put(1, 30, 0, ID.torch, false); put(-1, 30, 0, ID.torch, false);
          put(0, 30, 1, ID.torch, false); put(0, 30, -1, ID.torch, false);
        }
        if (Math.abs(ox + 8 - END_GATEWAY_MAIN[0]) < 16 && Math.abs(oz + 8 - END_GATEWAY_MAIN[2]) < 16) {
          const [gx, gy, gz] = END_GATEWAY_MAIN;
          for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
            put(gx + dx, gy - 1, gz + dz, ID.bedrock, true);
            put(gx + dx, gy + 1, gz + dz, ID.bedrock, true);
          }
          put(gx, gy - 2, gz, ID.bedrock, true);
          put(gx, gy + 2, gz, ID.bedrock, true);
        }
      }

      if (Math.abs(ox + 8 - 526) < 42 && Math.abs(oz + 8) < 42) {
        this.endCity(put, 514, 8);
        this.endShip(put, 534, -18);
      }
      if (Math.abs(ox + 8 - 508) < 16 && Math.abs(oz + 8) < 16) {
        put(508, 28, 0, ID.bedrock, true);
        put(508, 30, 0, ID.bedrock, true);
        put(508, 29, 0, ID.end_gateway, true);
      }
      const erx = Math.floor((ox + 8) / 144), erz = Math.floor((oz + 8) / 144);
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const rx2 = erx + dx, rz2 = erz + dz;
        const ex = rx2 * 144 + 72, ez = rz2 * 144 + 72;
        if (Math.hypot(ex, ez) < 160 || Math.hypot(ex - 520, ez) < 90) continue;
        if (coordHash(rx2, rz2, this.seed + 9876) < 0.35 && this.height(ex, ez) >= 20) {
          if (Math.abs(ox + 8 - ex) < 36 && Math.abs(oz + 8 - ez) < 36) this.endCity(put, ex - 4, ez - 4);
        }
      }
    }

    if (structures) placeExtraStructures(this, put, ox, oz);

    for (const [key, cell] of edits) {
      const [x, y, z] = key.split(',').map(Number);
      put(x, y, z, cell, true);
    }
    const maxDataY = Math.min(HEIGHT, maxY - MIN_Y + 4);
    for (let y = 0; y < maxDataY; y++) {
      const pBase = y * 324;
      const dBase = y * 256;
      for (let z = 0; z < 16; z++) {
        const pr = pBase + (z + 1) * 18 + 1;
        const dr = dBase + z * 16;
        for (let x = 0; x < 16; x++) data[dr + x] = padded[pr + x];
      }
    }
    const outMaxY = Math.min(MIN_Y + HEIGHT, maxY + 2);
    this._lastMaxLocalY = Math.max(SEA - MIN_Y + 4, outMaxY - MIN_Y);
    return { data, padded, tint, maxY: outMaxY };
  }

  private placeBed(put: PutFn, x: number, y: number, z: number, facing: number) {
    const dx = facing === 3 ? 1 : facing === 1 ? -1 : 0;
    const dz = facing === 0 ? 1 : facing === 2 ? -1 : 0;
    put(x, y, z, makeCell(ID.bed, facing), true);
    put(x + dx, y, z + dz, makeCell(ID.bed, facing | 4), true);
  }

  cabin(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const y = this.height(x + 3, z + 3) + 1;
    for (let dz = 0; dz < 7; dz++) for (let dx = 0; dx < 7; dx++) {
      foundation(x + dx, y - 1, z + dz, ID.cobblestone);
      for (let dy = 0; dy < 4; dy++) {
        const wall = dx === 0 || dx === 6 || dz === 0 || dz === 6;
        let id = wall ? ID.oak_planks : 0;
        if ((dx === 0 || dx === 6) && (dz === 0 || dz === 6)) id = ID.oak_log;
        if (wall && dy === 1 && (dx === 3 || dz === 3)) id = ID.glass;
        if (dz === 6 && dx === 3 && dy < 2) id = 0;
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    put(x + 3, y, z + 6, ID.oak_door, true);
    put(x + 3, y + 1, z + 6, 0, true);
    for (let dy = 0; dy < 4; dy++) {
      for (let dz = -1; dz < 8; dz++) for (let dx = dy - 1; dx < 8 - dy; dx++) {
        put(x + dx, y + 4 + dy, z + dz, dy === 3 ? ID.oak_slab : ID.oak_planks, true);
      }
    }
    this.placeBed(put, x + 1, y, z + 1, 0);
    put(x + 5, y, z + 1, ID.crafting_table);
    put(x + 4, y, z + 1, ID.furnace);
    put(x + 5, y, z + 4, ID.chest);
    put(x + 1, y + 2, z + 4, ID.torch);
  }

  plainsHouse(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number, w = 5, d = 5) {
    const y = this.height(x + Math.floor(w / 2), z + Math.floor(d / 2)) + 1;
    const rnd = coordHash(x, z, this.seed + 4242);
    for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) {
      foundation(x + dx, y - 1, z + dz, ID.cobblestone);
      for (let dy = 0; dy < 3; dy++) {
        const wall = dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1;
        let id = wall ? ID.oak_planks : 0;
        if ((dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1)) id = ID.oak_log;
        if (wall && dy === 1) {
          const win = (dx === 1 || dx === w - 2 || dz === 1 || dz === d - 2) && !(dz === d - 1 && dx === Math.floor(w / 2));
          if (win) id = ID.glass;
        }
        if (dz === d - 1 && dx === Math.floor(w / 2) && dy < 2) id = dy === 0 ? ID.oak_door : 0;
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    for (let dz = -1; dz < d + 1; dz++) for (let dx = -1; dx < w + 1; dx++) put(x + dx, y + 3, z + dz, ID.oak_planks, true);
    for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) put(x + dx, y + 4, z + dz, ID.oak_planks, true);
    for (let dz = 1; dz < d - 1; dz++) for (let dx = 1; dx < w - 1; dx++) put(x + dx, y + 5, z + dz, ID.oak_slab, true);
    const chx = x + (rnd < 0.5 ? 1 : w - 2), chz = z + 1;
    for (let dy = 4; dy <= 6; dy++) { put(chx, y + dy, chz, ID.cobblestone, true); }

    this.placeBed(put, x + 1, y, z + 1, 0);
    put(x + w - 2, y, z + 1, ID.crafting_table);
    put(x + w - 2, y, z + d - 2, ID.chest);
    put(x + Math.floor(w / 2), y + 2, z + Math.floor(d / 2), ID.torch);
  }

  villageWellAndPaths(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const pathId = ID.dirt_path ?? ID.gravel;
    for (let i = -8; i <= 10; i++) {
      const py = this.height(x + i, z); if (py > SEA) put(x + i, py, z, pathId);
      const pz = this.height(x, z + i); if (pz > SEA) put(x, pz, z + i, pathId);
    }
    const wy = this.height(x, z) + 1;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      foundation(x + dx, wy - 1, z + dz, ID.mossy_cobblestone ?? ID.cobblestone);
      put(x + dx, wy, z + dz, dx === 0 && dz === 0 ? ID.water : (ID.mossy_cobblestone ?? ID.cobblestone), true);
      if (Math.abs(dx) === 1 && Math.abs(dz) === 1) {
        put(x + dx, wy + 1, z + dz, ID.oak_fence, true);
        put(x + dx, wy + 2, z + dz, ID.oak_fence, true);
      }
      put(x + dx, wy + 3, z + dz, ID.oak_planks, true);
    }
    const ly = this.height(x + 5, z + 1) + 1;
    put(x + 5, ly, z + 1, ID.oak_fence);
    put(x + 5, ly + 1, z + 1, ID.oak_fence);
    put(x + 5, ly + 2, z + 1, ID.lantern ?? ID.torch);
  }

  desertVillage(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, cx: number, cz: number) {
    const houses = [[cx - 11, cz - 9, 6, 6], [cx + 4, cz - 8, 7, 6], [cx - 8, cz + 5, 6, 6]];
    for (const [hx, hz, w, d] of houses) {
      const y = this.height(hx + 3, hz + 3) + 1;
      for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) {
        foundation(hx + dx, y - 1, hz + dz, ID.sandstone);
        for (let dy = 0; dy < 4; dy++) {
          const wall = dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1;
          let id = 0;
          if (dy === 3) {
            id = wall ? ID.cut_sandstone : ID.sandstone;
          } else if (wall) {
            id = dy === 2 ? ID.cut_sandstone : ID.sandstone;
            if ((dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1)) id = ID.smooth_sandstone;
            if (dy === 1 && ((dx === 2 || dx === 3) && (dz === 0 || dz === d - 1) || (dz === 2) && (dx === 0 || dx === w - 1))) id = 0;
          }
          if (dz === d - 1 && dx === Math.floor(w / 2) && dy < 2) id = 0;
          put(hx + dx, y + dy, hz + dz, id, true);
        }
        if ((dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1)) put(hx + dx, y + 4, hz + dz, ID.orange_terracotta, true);
        else if (dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1) put(hx + dx, y + 4, hz + dz, ID.sandstone_slab, true);
      }
      this.placeBed(put, hx + 1, y, hz + 1, 0);
      put(hx + w - 2, y, hz + 1, ID.crafting_table);
      put(hx + w - 2, y, hz + d - 2, ID.chest);
      put(hx + 2, y + 2, hz + 2, ID.torch);
    }
    const wy = this.height(cx, cz) + 1;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      foundation(cx + dx, wy - 1, cz + dz, ID.sandstone);
      put(cx + dx, wy, cz + dz, dx === 0 && dz === 0 ? ID.water : ID.sandstone, true);
      if (Math.abs(dx) === 1 && Math.abs(dz) === 1) {
        put(cx + dx, wy + 1, cz + dz, ID.sandstone, true);
        put(cx + dx, wy + 2, cz + dz, ID.sandstone, true);
      }
      put(cx + dx, wy + 3, cz + dz, ID.sandstone_slab, true);
    }
    const mx = cx + 6, mz = cz + 6, my = this.height(mx + 2, mz + 2) + 1;
    for (let dz = 0; dz < 4; dz++) for (let dx = 0; dx < 5; dx++) {
      foundation(mx + dx, my - 1, mz + dz, ID.cut_sandstone);
      for (let dy = 0; dy < 4; dy++) put(mx + dx, my + dy, mz + dz, 0, true);
      if ((dx === 0 || dx === 4) && (dz === 0 || dz === 3)) {
        put(mx + dx, my, mz + dz, ID.oak_fence, true);
        put(mx + dx, my + 1, mz + dz, ID.oak_fence, true);
        put(mx + dx, my + 2, mz + dz, ID.oak_fence, true);
      }
      put(mx + dx, my + 3, mz + dz, dx % 2 === 0 ? ID.orange_wool : ID.white_wool, true);
    }
    put(mx + 1, my, mz + 1, ID.hay_block, true);
    put(mx + 2, my, mz + 1, ID.chest, true);
  }

  desertPyramid(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, cx: number, cz: number) {
    const y = this.height(cx, cz) + 1;
    const half = 9;
    for (let dz = -half; dz <= half; dz++) for (let dx = -half; dx <= half; dx++) {
      foundation(cx + dx, y - 1, cz + dz, ID.sandstone);
    }
    for (let step = 0; step < 9; step++) {
      const r = half - step;
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        const edge = Math.abs(dx) === r || Math.abs(dz) === r;
        const inner = Math.abs(dx) < r - 1 && Math.abs(dz) < r - 1 && step < 7;
        put(cx + dx, y + step, cz + dz, inner ? 0 : edge ? ID.sandstone : ID.cut_sandstone, true);
      }
    }
    for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
      const isCenter = dx === 0 && dz === 0;
      const isCross = (dx === 0 || dz === 0) && Math.abs(dx) <= 2 && Math.abs(dz) <= 2;
      put(cx + dx, y - 1, cz + dz, isCenter ? ID.blue_terracotta : isCross ? ID.orange_terracotta : ID.sandstone, true);
    }
    for (let dy = 2; dy <= 7; dy++) {
      for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
        const wall = Math.abs(dx) === 2 || Math.abs(dz) === 2 || dy === 7;
        put(cx + dx, y - dy, cz + dz, wall ? ID.cut_sandstone : 0, true);
      }
    }
    put(cx + 1, y - 6, cz, ID.chest, true);
    put(cx - 1, y - 6, cz, ID.chest, true);
    put(cx, y - 6, cz + 1, ID.chest, true);
    put(cx, y - 6, cz - 1, ID.chest, true);
    put(cx, y - 7, cz, ID.tnt, true);

    for (const sx of [-7, 5]) {
      for (let dz = 6; dz <= 10; dz++) for (let dx = sx; dx <= sx + 2; dx++) {
        foundation(cx + dx, y - 1, cz + dz, ID.sandstone);
        for (let dy = 0; dy < 9; dy++) {
          const id = dy === 4 && dx === sx + 1 ? ID.chiseled_sandstone : dy === 5 && dx === sx + 1 ? ID.orange_terracotta : ID.sandstone;
          put(cx + dx, y + dy, cz + dz, id, true);
        }
      }
    }
    for (let dy = 0; dy < 3; dy++) for (let dx = -1; dx <= 1; dx++) {
      for (let dz = 6; dz <= 10; dz++) put(cx + dx, y + dy, cz + dz, 0, true);
    }
    put(cx - 2, y + 2, cz + 8, ID.torch, true);
    put(cx + 2, y + 2, cz + 8, ID.torch, true);
  }

  witchHut(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const y = SEA + 4;
    for (const [lx, lz] of [[x, z], [x + 6, z], [x, z + 6], [x + 6, z + 6]]) {
      foundation(lx, SEA - 1, lz, ID.spruce_log);
      for (let yy = SEA; yy <= y; yy++) put(lx, yy, lz, ID.spruce_log, true);
    }
    for (let dz = 0; dz <= 6; dz++) for (let dx = 0; dx <= 6; dx++) {
      put(x + dx, y, z + dz, ID.spruce_planks, true);
    }
    for (let dy = 1; dy <= 3; dy++) for (let dz = 0; dz <= 6; dz++) for (let dx = 0; dx <= 6; dx++) {
      const wall = dx === 0 || dx === 6 || dz === 0 || dz === 6;
      if (wall) {
        let id = ID.spruce_planks;
        if (dy === 2 && ((dx === 3 && (dz === 0 || dz === 6)) || (dz === 3 && dx === 6))) id = ID.oak_fence;
        if (dz === 6 && dx === 3 && dy < 3) id = 0;
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    for (let dz = -1; dz <= 7; dz++) for (let dx = -1; dx <= 7; dx++) {
      put(x + dx, y + 4, z + dz, ID.spruce_planks, true);
    }
    for (let dz = 0; dz <= 6; dz++) for (let dx = 0; dx <= 6; dx++) {
      put(x + dx, y + 5, z + dz, ID.spruce_slab, true);
    }
    put(x + 2, y + 1, z + 2, ID.crafting_table, true);
    put(x + 4, y + 1, z + 2, ID.cauldron ?? ID.blackstone, true);
    put(x + 1, y + 2, z + 5, ID.torch, true);
  }

  desertFossil(put: PutFn, cx: number, cz: number) {
    const y = this.height(cx, cz);
    for (let r = 0; r < 4; r++) {
      const fz = cz + r * 3 - 4;
      for (let dy = 0; dy <= 4; dy++) {
        put(cx - 3, y + dy, fz, ID.bone_block, true);
        put(cx + 3, y + dy, fz, ID.bone_block, true);
      }
      for (let dx = -2; dx <= 2; dx++) {
        put(cx + dx, y + 4, fz, ID.bone_block, true);
      }
      put(cx, y + 5, fz, ID.bone_block, true);
    }
  }

  ruinedPortal(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const y = this.height(x, z) + 1;
    for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
      if (Math.abs(dx) + Math.abs(dz) <= 3) {
        foundation(x + dx, y - 1, z + dz, ID.netherrack);
        put(x + dx, y - 1, z + dz, coordHash(dx, dz, 11) < 0.25 ? ID.magma_block : ID.netherrack, true);
      }
    }
    for (let dy = 0; dy < 5; dy++) {
      put(x - 1, y + dy, z, dy === 2 ? ID.crying_obsidian : ID.obsidian, true);
      if (dy < 4) put(x + 2, y + dy, z, ID.obsidian, true);
    }
    put(x, y, z, ID.obsidian, true); put(x + 1, y, z, ID.obsidian, true);
    put(x, y + 4, z, ID.crying_obsidian, true); put(x + 1, y + 4, z, ID.gold_ore, true);
    put(x - 2, y, z + 1, ID.chest, true);
  }

  stronghold(put: PutFn, cx: number, cz: number) {
    const floorY = 30;
    const surfY = this.height(cx, cz);
    for (let y = floorY; y <= surfY + 2; y++) {
      for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
        const wall = Math.abs(dx) === 2 || Math.abs(dz) === 2;
        put(cx + dx, y, cz + dz - 7, wall ? (coordHash(dx + y, dz, 33) < 0.25 ? ID.mossy_stone_bricks : ID.stone_bricks) : 0, true);
      }
      if (y <= surfY) put(cx, y, cz - 6, ID.ladder, true);
    }
    for (let dy = 0; dy < 7; dy++) for (let dz = -5; dz <= 5; dz++) for (let dx = -5; dx <= 5; dx++) {
      const door = dz === -5 && Math.abs(dx) <= 1 && dy >= 1 && dy <= 3;
      const shell = !door && (Math.abs(dx) === 5 || Math.abs(dz) === 5 || dy === 0 || dy === 6);
      const brick = coordHash(dx + dy, dz, 71) < 0.25 ? ID.mossy_stone_bricks : ID.stone_bricks;
      put(cx + dx, floorY + dy, cz + dz, shell ? brick : 0, true);
    }
    for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
      put(cx + dx, floorY + 1, cz + dz, Math.abs(dx) <= 1 && Math.abs(dz) <= 1 ? ID.lava : ID.stone_bricks, true);
    }
    put(cx, floorY + 1, cz + 3, ID.stone_brick_stairs, true);
    const ring: [number, number, number, boolean][] = [
      [-1, -2, 0, true], [0, -2, 0, false], [1, -2, 0, false],
      [2, -1, 1, false], [2, 0, 1, true], [2, 1, 1, false],
      [1, 2, 2, false], [0, 2, 2, false], [-1, 2, 2, true],
      [-2, 1, 3, false], [-2, 0, 3, false], [-2, -1, 3, false],
    ];
    for (const [dx, dz, facing, eye] of ring) {
      put(cx + dx, floorY + 2, cz + dz, makeCell(ID.end_portal_frame, facing | (eye ? 4 : 0)), true);
    }
    put(cx - 4, floorY + 1, cz - 4, ID.chest, true);
    put(cx + 4, floorY + 2, cz + 4, ID.torch, true);
    put(cx - 4, floorY + 2, cz + 4, ID.torch, true);
    put(cx + 4, floorY + 2, cz - 4, ID.torch, true);
  }

  fortress(put: PutFn, x: number, z: number) {
    const y = 26;
    for (const [px, pz] of [[0, 0], [13, 0], [0, 13], [13, 13], [6, 6]]) {
      for (let yy = 8; yy < y; yy++) {
        for (let dz = 0; dz < 2; dz++) for (let dx = 0; dx < 2; dx++) put(x + px + dx, yy, z + pz + dz, ID.nether_bricks, true);
      }
    }
    for (let dz = 0; dz < 15; dz++) for (let dx = 0; dx < 15; dx++) {
      put(x + dx, y, z + dz, ID.nether_bricks, true);
      for (let dy = 1; dy <= 5; dy++) put(x + dx, y + dy, z + dz, 0, true);
      const wall = dx === 0 || dx === 14 || dz === 0 || dz === 14;
      if (wall) {
        put(x + dx, y + 1, z + dz, ID.nether_bricks, true);
        if ((dx + dz) % 2 === 0) put(x + dx, y + 2, z + dz, ID.nether_bricks, true);
      }
    }
    for (let dz = 5; dz <= 9; dz++) for (let dx = 5; dx <= 9; dx++) {
      put(x + dx, y + 1, z + dz, ID.nether_bricks, true);
    }
    put(x + 7, y + 2, z + 7, ID.glowstone, true);
    put(x + 2, y + 1, z + 2, ID.chest, true);
    put(x + 12, y + 1, z + 12, ID.chest, true);
    put(x + 2, y + 2, z + 12, ID.fire, true);
    put(x + 12, y + 2, z + 2, ID.fire, true);
  }

  endCity(put: PutFn, x: number, z: number) {
    const y = Math.max(27, this.height(x + 5, z + 5) + 1);
    for (let dz = 0; dz < 11; dz++) for (let dx = 0; dx < 11; dx++) {
      for (let yy = y - 3; yy < y; yy++) put(x + dx, yy, z + dz, ID.end_stone_bricks, true);
      for (let dy = 0; dy < 7; dy++) {
        const wall = dx === 0 || dx === 10 || dz === 0 || dz === 10;
        let id = 0;
        if (dy === 0 || dy === 6) id = ID.end_stone_bricks;
        else if (wall) {
          id = (dx === 0 || dx === 10) && (dz === 0 || dz === 10) ? ID.purpur_pillar : dy === 3 && (dx === 5 || dz === 5) ? ID.magenta_stained_glass : ID.purpur_block;
          if (dz === 0 && dx === 5 && dy <= 2) id = 0;
        }
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    for (let dy = 7; dy < 20; dy++) for (let dz = 2; dz <= 8; dz++) for (let dx = 2; dx <= 8; dx++) {
      const wall = dx === 2 || dx === 8 || dz === 2 || dz === 8;
      let id = 0;
      if (dy === 13 || dy === 19) id = ID.purpur_block;
      else if (wall) {
        id = (dx === 2 || dx === 8) && (dz === 2 || dz === 8) ? ID.purpur_pillar : dy % 4 === 2 && (dx === 5 || dz === 5) ? ID.magenta_stained_glass : ID.end_stone_bricks;
      }
      put(x + dx, y + dy, z + dz, id, true);
    }
    for (let dy = 20; dy < 26; dy++) for (let dz = 1; dz <= 9; dz++) for (let dx = 1; dx <= 9; dx++) {
      const wall = dx === 1 || dx === 9 || dz === 1 || dz === 9;
      let id = 0;
      if (dy === 25) id = ID.purpur_block;
      else if (wall) id = dy === 22 && (dx === 5 || dz === 5) ? ID.magenta_stained_glass : ID.purpur_block;
      put(x + dx, y + dy, z + dz, id, true);
    }
    for (let dy = 1; dy <= 20; dy++) put(x + 5, y + dy, z + 5, ID.ladder, true);
    put(x + 3, y + 20, z + 3, ID.chest, true);
    put(x + 7, y + 20, z + 7, ID.shulker_box, true);
    put(x + 3, y + 21, z + 7, ID.end_rod, true);
    put(x + 7, y + 21, z + 3, ID.end_rod, true);
    put(x + 2, y + 1, z + 2, ID.end_rod, true);
    put(x + 8, y + 1, z + 8, ID.end_rod, true);
    put(x + 5, y + 1, z - 1, ID.end_rod, true);
  }

  endShip(put: PutFn, x: number, z: number) {
    const y = 39;
    for (let dz = 0; dz < 15; dz++) {
      const hw = dz < 2 ? 1 : dz < 4 ? 2 : dz > 12 ? 2 : 3;
      for (let dx = -hw; dx <= hw; dx++) {
        put(x + dx, y, z + dz, ID.purpur_block, true);
        put(x + dx, y + 1, z + dz, Math.abs(dx) === hw ? ID.end_stone_bricks : ID.purpur_block, true);
        put(x + dx, y + 2, z + dz, Math.abs(dx) === hw || dz === 0 || dz === 14 ? ID.purpur_block : 0, true);
        if (Math.abs(dx) === hw || dz === 14) put(x + dx, y + 3, z + dz, ID.purpur_stairs, true);
      }
    }
    for (let dy = 2; dy <= 6; dy++) for (let dz = 10; dz <= 14; dz++) for (let dx = -3; dx <= 3; dx++) {
      const wall = Math.abs(dx) === 3 || dz === 10 || dz === 14 || dy === 6;
      put(x + dx, y + dy, z + dz, wall ? (dy === 4 && Math.abs(dx) <= 1 ? ID.magenta_stained_glass : ID.purpur_pillar) : 0, true);
    }
    put(x, y + 2, z + 10, 0, true); put(x, y + 3, z + 10, 0, true);
    for (let dy = 2; dy <= 10; dy++) put(x, y + dy, z + 6, ID.end_stone_bricks, true);
    put(x, y + 11, z + 6, ID.end_rod, true);
    put(x, y + 3, z - 1, ID.dragon_head, true);
    put(x, y + 2, z + 12, ID.chest, true);
    put(x - 1, y + 2, z + 12, ID.brewing_stand, true);
    put(x + 1, y + 2, z + 12, ID.end_rod, true);
  }
}

export function blockIndex(x: number, y: number, z: number) { return (y - MIN_Y) * 256 + z * 16 + x; }
export function blockName(id: number) { return BLOCKS[id]?.name ?? 'air'; }
