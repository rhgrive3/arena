import * as THREE from 'three';
import { BLOCKS, ID } from '../game/data';

/*
 * Unified Vehicles System: Minecarts & Boats (Record 014 Perfected).
 *
 * Combines:
 *  - Minecart rail graph following (rail, powered_rail, detector_rail, activator_rail), slopes, corners, buffer stops
 *  - Detector rail activation while a minecart stands on it (implement)
 *  - Activator rail rider dismount on powered activator rails (vanilla)
 *  - Player collision nudge and minecart-to-minecart momentum transfer (implement + vanilla)
 *  - Boat water buoyancy, oar paddling animation, and Vanilla Ice Boat Highway physics (ice / packed_ice / blue_ice)
 *  - Per-dimension vehicle save & load persistence (implement + simplify)
 */

export type VehicleKind = 'minecart' | 'boat';
export interface VehicleSave {
  kind: VehicleKind;
  position?: [number, number, number];
  p?: [number, number, number];
  yaw: number;
}
export interface Vehicle {
  id: number;
  kind: VehicleKind;
  group: THREE.Group;
  pos: THREE.Vector3;
  yaw: number;
  speed: number;
  dx: number;
  dz: number;
  onRail: boolean;
  from: THREE.Vector3;
  to: THREE.Vector3;
  vel: THREE.Vector3;
  hp: number;
  detector: [number, number, number] | null;
  oars?: THREE.Object3D[];
}
export interface VehicleHost {
  getCell(x: number, y: number, z: number): number;
  getBlock?(x: number, y: number, z: number): number;
  setBlock?(x: number, y: number, z: number, id: number, state?: number): boolean;
  drop?(x: number, y: number, z: number, name: string, count: number): void;
  sound?(k: string, p?: { x: number; y: number; z: number }): void;
}
export interface DriveInput {
  move?: { x: number; z: number };
  forward?: number;
  strafe?: number;
  yaw: number;
  run?: boolean;
  ascend?: boolean;
}
export type Control = DriveInput;

const idOf = (c: number) => (c < 0 ? -1 : c & 4095);
const stOf = (c: number) => (c < 0 ? 0 : (c >>> 12) & 15);
export const isRail = (id: number) => id > 0 && (id === ID.rail || id === ID.powered_rail || id === ID.detector_rail || id === ID.activator_rail);
const isIce = (id: number) => id > 0 && (id === ID.ice || id === ID.packed_ice || id === ID.blue_ice || id === ID.frosted_ice);
const solid = (id: number) => id > 0 && !!BLOCKS[id]?.solid && BLOCKS[id]?.shape !== 'cross';
const DIRS: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
export const MAX_CART_SPEED = 8;

export class VehicleManager {
  vehicles: Vehicle[] = [];
  riding: Vehicle | null = null;
  private nextId = 1;
  private time = 0;
  private box = new THREE.BoxGeometry(1, 1, 1);
  private mats = new Map<string, THREE.MeshLambertMaterial>();
  private _seat = new THREE.Vector3();
  private tmp = new THREE.Vector3();

  constructor(public scene: THREE.Scene, public host: VehicleHost) {}

  get list() { return this.vehicles; }
  set list(v: Vehicle[]) { this.vehicles = v; }

  private blockAt(x: number, y: number, z: number): number {
    if (this.host.getBlock) return this.host.getBlock(Math.floor(x), Math.floor(y), Math.floor(z));
    return idOf(this.host.getCell(Math.floor(x), Math.floor(y), Math.floor(z)));
  }

  private mat(c: string) {
    let m = this.mats.get(c);
    if (!m) { m = new THREE.MeshLambertMaterial({ color: c }); this.mats.set(c, m); }
    return m;
  }
  private part(g: THREE.Object3D, c: string, x: number, y: number, z: number, w: number, h: number, d: number) {
    const m = new THREE.Mesh(this.box, this.mat(c));
    m.position.set(x, y, z);
    m.scale.set(w, h, d);
    m.castShadow = true;
    g.add(m);
    return m;
  }

  private model(kind: VehicleKind): { g: THREE.Group; oars: THREE.Object3D[] } {
    const g = new THREE.Group(), oars: THREE.Object3D[] = [];
    if (kind === 'minecart') {
      this.part(g, '#6d6f72', 0, 0.12, 0, 0.98, 0.1, 0.78);
      this.part(g, '#8a8d90', 0, 0.42, -0.35, 0.98, 0.5, 0.08);
      this.part(g, '#8a8d90', 0, 0.42, 0.35, 0.98, 0.5, 0.08);
      this.part(g, '#8a8d90', -0.45, 0.42, 0, 0.08, 0.5, 0.78);
      this.part(g, '#8a8d90', 0.45, 0.42, 0, 0.08, 0.5, 0.78);
      for (const sx of [-0.3, 0.3]) for (const sz of [-0.28, 0.28]) this.part(g, '#2b2b2b', sx, 0.1, sz, 0.18, 0.2, 0.06);
    } else {
      const wood = '#a3783f', dark = '#7d5a2c';
      this.part(g, dark, 0, 0.12, 0, 1.3, 0.1, 0.7);
      this.part(g, wood, 0, 0.3, -0.33, 1.3, 0.3, 0.06);
      this.part(g, wood, 0, 0.3, 0.33, 1.3, 0.3, 0.06);
      this.part(g, wood, -0.63, 0.3, 0, 0.06, 0.3, 0.7);
      this.part(g, wood, 0.63, 0.3, 0, 0.06, 0.3, 0.7);
      this.part(g, '#6b4b22', -0.2, 0.3, 0, 0.1, 0.3, 0.66);
      for (const s of [-1, 1]) {
        const oar = this.part(g, '#8f6a35', 0.05, 0.42, s * 0.5, 0.08, 0.06, 1.1);
        oar.rotation.x = s * 0.4;
        oars.push(oar);
      }
    }
    return { g, oars };
  }

  spawn(kind: VehicleKind, x: number, y: number, z: number, yaw = 0): Vehicle {
    const { g, oars } = this.model(kind);
    const pos = new THREE.Vector3(x, y, z);
    g.position.copy(pos);
    g.rotation.y = yaw;
    this.scene.add(g);
    const v: Vehicle = {
      id: this.nextId++,
      kind,
      group: g,
      pos,
      yaw,
      speed: 0,
      dx: 0,
      dz: 0,
      onRail: kind === 'minecart' && isRail(this.blockAt(x, y, z)),
      from: new THREE.Vector3(Math.floor(x) + 0.5, Math.round(y), Math.floor(z) + 0.5),
      to: new THREE.Vector3(Math.floor(x) + 0.5, Math.round(y), Math.floor(z) + 0.5),
      vel: new THREE.Vector3(),
      hp: 6,
      detector: null,
      oars,
    };
    this.vehicles.push(v);
    return v;
  }

  /** Place a minecart on a rail or a boat on water/ice/ground. Returns true when consumed. */
  place(kind: VehicleKind, x: number, y: number, z: number): boolean {
    if (kind === 'minecart') {
      let ry = NaN;
      for (const dy of [0, 1, -1]) {
        if (isRail(this.blockAt(x, y + dy, z))) { ry = y + dy; break; }
      }
      if (Number.isNaN(ry)) return false;
      this.spawn('minecart', x + 0.5, ry, z + 0.5, 0);
      this.host.sound?.('place', { x, y: ry, z });
      return true;
    }
    let wy = NaN;
    for (const dy of [0, -1, 1]) {
      const bid = this.blockAt(x, y + dy, z);
      if (bid === ID.water || isIce(bid)) { wy = y + dy; break; }
    }
    if (Number.isNaN(wy)) {
      if (solid(this.blockAt(x, y - 1, z)) && this.blockAt(x, y, z) === 0) wy = y - 0.85;
      else return false;
    }
    this.spawn('boat', x + 0.5, wy + 0.85, z + 0.5, 0);
    this.host.sound?.('water', { x, y: wy, z });
    return true;
  }

  pick(origin: THREE.Vector3, dir: THREE.Vector3, reach = 4.5): Vehicle | null {
    let best: Vehicle | null = null, bestD = reach;
    for (const v of this.vehicles) {
      if (v === this.riding) continue;
      this.tmp.copy(v.pos).sub(origin);
      this.tmp.y += 0.3;
      const d = this.tmp.length();
      if (d > bestD) continue;
      if (this.tmp.normalize().dot(dir) < 0.86) continue;
      best = v;
      bestD = d;
    }
    return best;
  }

  mount(v: Vehicle) {
    this.riding = v;
    this.host.sound?.('wood', v.pos);
  }

  dismount(): THREE.Vector3 | null {
    const v = this.riding;
    if (!v) return null;
    this.riding = null;
    const out = v.pos.clone();
    out.x += Math.cos(v.yaw) * 1.1;
    out.z -= Math.sin(v.yaw) * 1.1;
    if (solid(this.blockAt(out.x, out.y + 0.5, out.z))) {
      out.x = v.pos.x;
      out.z = v.pos.z;
      out.y += 1;
    }
    return out;
  }

  seat(v: Vehicle, out = new THREE.Vector3()) {
    return out.set(v.pos.x, v.pos.y + (v.kind === 'boat' ? -0.25 : -0.1), v.pos.z);
  }

  hit(v: Vehicle) {
    v.hp -= 2.5;
    v.group.position.y += 0.05;
    if (v.hp <= 0) this.destroy(v, true);
  }

  remove(v: Vehicle) { this.destroy(v, false); }

  destroy(v: Vehicle, drop: boolean) {
    if (this.riding === v) this.riding = null;
    this.releaseDetector(v);
    this.scene.remove(v.group);
    const idx = this.vehicles.indexOf(v);
    if (idx >= 0) this.vehicles.splice(idx, 1);
    if (drop) this.host.drop?.(v.pos.x, v.pos.y + 0.3, v.pos.z, v.kind, 1);
  }

  clear() {
    for (const v of [...this.vehicles]) this.releaseDetector(v);
    for (const v of this.vehicles) this.scene.remove(v.group);
    this.vehicles = [];
    this.riding = null;
  }

  save(): VehicleSave[] {
    return this.vehicles.map(v => ({
      kind: v.kind,
      position: [v.pos.x, v.pos.y, v.pos.z],
      p: [v.pos.x, v.pos.y, v.pos.z],
      yaw: v.yaw,
    }));
  }

  load(list: VehicleSave[] | undefined) {
    this.clear();
    for (const s of list ?? []) {
      const coords = s?.position ?? s?.p;
      if (coords && (s.kind === 'boat' || s.kind === 'minecart')) {
        this.spawn(s.kind, coords[0], coords[1], coords[2], s.yaw ?? 0);
      }
    }
  }

  connections(cx: number, ry: number, cz: number): { dx: number; dz: number; dy: number }[] {
    const out: { dx: number; dz: number; dy: number }[] = [];
    for (const [dx, dz] of DIRS) {
      if (isRail(this.blockAt(cx + dx, ry, cz + dz))) out.push({ dx, dz, dy: 0 });
      else if (isRail(this.blockAt(cx + dx, ry + 1, cz + dz)) && !solid(this.blockAt(cx, ry + 1, cz))) out.push({ dx, dz, dy: 1 });
      else if (isRail(this.blockAt(cx + dx, ry - 1, cz + dz)) && !solid(this.blockAt(cx + dx, ry, cz + dz))) out.push({ dx, dz, dy: -1 });
    }
    return out;
  }

  private releaseDetector(v: Vehicle) {
    if (!v.detector || !this.host.setBlock) return;
    const [x, y, z] = v.detector, cell = this.host.getCell(x, y, z);
    if (idOf(cell) === ID.detector_rail && (stOf(cell) & 9)) {
      this.host.setBlock(x, y, z, ID.detector_rail, stOf(cell) & 6);
    }
    v.detector = null;
  }

  /** Pushes stopped minecarts the player walks into, and resolves cart-to-cart collisions. */
  nudge(player: THREE.Vector3) {
    for (const v of this.vehicles) {
      if (v.kind !== 'minecart' || v === this.riding || v.speed > 0.5) continue;
      const dx = v.pos.x - player.x, dz = v.pos.z - player.z, dy = v.pos.y - player.y;
      if (dx * dx + dz * dz > 0.75 || dy < -1 || dy > 1.2) continue;
      const cx = Math.floor(v.pos.x), cy = Math.round(v.pos.y), cz = Math.floor(v.pos.z);
      const next = this.nextRail(cx, cy, cz, null, Math.atan2(dx, dz));
      if (next) {
        v.from.set(cx + 0.5, cy, cz + 0.5);
        v.to.copy(next);
        v.dx = Math.sign(next.x - v.from.x);
        v.dz = Math.sign(next.z - v.from.z);
        v.speed = 1.6;
      }
    }
  }

  update(dt: number, input: DriveInput | null): THREE.Vector3 | null {
    this.time += dt;
    for (const v of [...this.vehicles]) {
      if (v.kind === 'minecart') this.updateMinecart(v, dt, v === this.riding ? input : null);
      else this.updateBoat(v, dt, v === this.riding ? input : null);
      v.group.position.copy(v.pos);
      v.group.rotation.y = v.yaw;
    }
    // Cart-to-cart collision bounce
    for (let i = 0; i < this.vehicles.length; i++) {
      for (let j = i + 1; j < this.vehicles.length; j++) {
        const a = this.vehicles[i], b = this.vehicles[j];
        if (a.kind === 'minecart' && b.kind === 'minecart' && a.pos.distanceToSquared(b.pos) < 0.75) {
          const spA = a.speed, spB = b.speed;
          a.speed = spB; b.speed = spA;
          const tmp = a.from.clone(); a.from.copy(a.to); a.to.copy(tmp);
          const tmpB = b.from.clone(); b.from.copy(b.to); b.to.copy(tmpB);
        }
      }
    }
    if (!this.riding) return null;
    const v = this.riding;
    this._seat.set(v.pos.x, v.pos.y + (v.kind === 'boat' ? -0.25 : -0.1), v.pos.z);
    return this._seat;
  }

  private railAt(x: number, y: number, z: number): number {
    for (const dy of [0, 1, -1]) if (isRail(this.blockAt(x, y + dy, z))) return y + dy;
    return NaN;
  }

  private updateMinecart(v: Vehicle, dt: number, input: DriveInput | null) {
    const cx = Math.floor(v.pos.x), cz = Math.floor(v.pos.z), cy = Math.round(v.pos.y);
    const ry = this.railAt(cx, cy, cz);
    if (Number.isNaN(ry)) {
      v.onRail = false;
      this.releaseDetector(v);
      const gy = this.groundY(v.pos.x, v.pos.y, v.pos.z);
      v.pos.y += (gy - v.pos.y) * Math.min(1, dt * 8);
      v.speed = Math.max(0, v.speed - 10 * dt);
      return;
    }
    v.onRail = true;
    const cell = this.host.getCell(cx, ry, cz), id = idOf(cell), st = stOf(cell);

    // Detector rail powers on while a cart stands on it
    if (id === ID.detector_rail && this.host.setBlock) {
      if (!v.detector || v.detector[0] !== cx || v.detector[1] !== ry || v.detector[2] !== cz) {
        this.releaseDetector(v);
        v.detector = [cx, ry, cz];
      }
      if ((st & 9) !== 9) this.host.setBlock(cx, ry, cz, id, st | 9);
    } else {
      this.releaseDetector(v);
    }

    // Powered activator rail dismounts the rider
    if (id === ID.activator_rail && (st & 9) && this.riding === v) {
      this.dismount();
    }

    const atTarget = v.to.distanceToSquared(v.pos) < 0.002 || v.to.equals(v.from);
    const fwd = input
      ? input.forward !== undefined
        ? input.forward
        : input.move
        ? -(input.move.x * Math.sin(input.yaw) + input.move.z * Math.cos(input.yaw))
        : 0
      : 0;

    if (input && Math.abs(fwd) > 0.2) {
      const fx = -Math.sin(input.yaw) * fwd, fz = -Math.cos(input.yaw) * fwd;
      if (v.speed < 0.05 && atTarget) {
        const next = this.nextRail(cx, ry, cz, null, Math.atan2(fx, fz));
        if (next) { v.from.set(cx + 0.5, ry, cz + 0.5); v.to.copy(next); v.speed = 1.2; }
      } else {
        this.tmp.copy(v.to).sub(v.from).normalize();
        const along = this.tmp.x * fx + this.tmp.z * fz;
        v.speed = Math.min(6, v.speed + along * 2.5 * dt);
      }
    }
    if (v.to.equals(v.from) && (v.dx !== 0 || v.dz !== 0)) {
      const next = this.nextRail(cx, ry, cz, null, Math.atan2(v.dx, v.dz));
      if (next) { v.from.set(cx + 0.5, ry, cz + 0.5); v.to.copy(next); }
    }
    if (id === ID.powered_rail) {
      if (st & 9) v.speed = Math.min(8, v.speed + 10 * dt);
      else v.speed = Math.max(0, v.speed - 16 * dt);
      if ((st & 9) && v.speed < 0.3 && atTarget) {
        for (const [dx, dz] of DIRS) {
          if (solid(this.blockAt(cx + dx, ry, cz + dz))) {
            const next = this.nextRail(cx, ry, cz, null, Math.atan2(-dx, -dz));
            if (next) { v.from.set(cx + 0.5, ry, cz + 0.5); v.to.copy(next); v.speed = 1.8; break; }
          }
        }
        if (v.speed < 0.3) {
          const conns = this.connections(cx, ry, cz);
          if (conns.length) {
            const c = conns[0];
            v.from.set(cx + 0.5, ry, cz + 0.5);
            v.to.set(cx + c.dx + 0.5, ry + c.dy, cz + c.dz + 0.5);
            v.speed = 1.5;
          }
        }
      }
    } else {
      v.speed = Math.max(0, v.speed - 0.35 * dt - v.speed * 0.08 * dt);
    }

    const dy = v.to.y - v.from.y;
    if (dy > 0) v.speed -= 5 * dt;
    else if (dy < 0) v.speed = Math.min(8, v.speed + 5 * dt);
    if (v.speed < 0) {
      const t = v.from.clone(); v.from.copy(v.to); v.to.copy(t); v.speed = -v.speed;
    }
    if (v.speed <= 0.001) return;

    let remaining = v.speed * dt;
    for (let guard = 0; guard < 4 && remaining > 0; guard++) {
      this.tmp.copy(v.to).sub(v.pos);
      const dist = this.tmp.length();
      if (dist <= remaining || dist < 1e-4) {
        v.pos.copy(v.to);
        remaining -= dist;
        const tx = Math.floor(v.to.x), ty = Math.round(v.to.y), tz = Math.floor(v.to.z);
        const heading = Math.atan2(v.to.x - v.from.x, v.to.z - v.from.z);
        const next = this.nextRail(tx, ty, tz, v.from, heading);
        if (!next) {
          v.speed *= 0.2;
          const t = v.from.clone(); v.from.copy(v.to); v.to.copy(t);
          v.speed = Math.min(v.speed, 0.4);
          break;
        }
        v.from.copy(v.to);
        v.to.copy(next);
      } else {
        this.tmp.normalize();
        v.pos.addScaledVector(this.tmp, remaining);
        remaining = 0;
      }
    }
    this.tmp.copy(v.to).sub(v.from);
    if (this.tmp.lengthSq() > 1e-6) {
      v.dx = Math.sign(this.tmp.x);
      v.dz = Math.sign(this.tmp.z);
      v.yaw = Math.atan2(this.tmp.x, this.tmp.z) + Math.PI / 2;
    }
  }

  private nextRail(x: number, y: number, z: number, from: THREE.Vector3 | null, heading: number): THREE.Vector3 | null {
    const hx = Math.round(Math.sin(heading)), hz = Math.round(Math.cos(heading));
    const order: [number, number][] = [[hx, hz], [hz, -hx], [-hz, hx], [-hx, -hz]];
    for (const [dx, dz] of order) {
      if (dx === 0 && dz === 0) continue;
      const ry = this.railAt(x + dx, y, z + dz);
      if (Number.isNaN(ry)) continue;
      if (ry > y && solid(this.blockAt(x + dx, y + 1, z + dz)) && !isRail(this.blockAt(x + dx, y + 1, z + dz))) continue;
      if (from && Math.floor(from.x) === x + dx && Math.floor(from.z) === z + dz && Math.round(from.y) === ry) continue;
      return new THREE.Vector3(x + dx + 0.5, ry, z + dz + 0.5);
    }
    return null;
  }

  private groundY(x: number, y: number, z: number) {
    for (let yy = Math.floor(y); yy > Math.floor(y) - 6; yy--) {
      if (solid(this.blockAt(x, yy, z))) return yy + 1;
    }
    return y - 0.5;
  }

  private updateBoat(v: Vehicle, dt: number, input: DriveInput | null) {
    const belowId = this.blockAt(v.pos.x, v.pos.y - 0.5, v.pos.z) || this.blockAt(v.pos.x, v.pos.y - 0.9, v.pos.z);
    const inWater = belowId === ID.water;
    const onIce = isIce(belowId);
    const iceTop = belowId === ID.blue_ice ? 40 : belowId === ID.packed_ice ? 28 : belowId === ID.ice ? 18 : 8;

    let fwd = 0, strafe = 0;
    if (input) {
      fwd = input.forward !== undefined ? input.forward : input.move ? -(input.move.x * Math.sin(input.yaw) + input.move.z * Math.cos(input.yaw)) : 0;
      strafe = input.strafe !== undefined ? input.strafe : input.move ? input.move.x * Math.cos(input.yaw) - input.move.z * Math.sin(input.yaw) : 0;
      v.yaw -= strafe * 1.9 * dt;
      const baseThrust = onIce ? 22 : inWater ? 8 : 1.5;
      const thrust = fwd * baseThrust * (input.run ? 1.25 : 1);
      v.vel.x += -Math.sin(v.yaw) * thrust * dt;
      v.vel.z += -Math.cos(v.yaw) * thrust * dt;
    }

    const drag = onIce ? 0.985 : inWater ? 0.9 : 0.5;
    v.vel.x *= Math.max(0, 1 - (1 - drag) * dt * 10);
    v.vel.z *= Math.max(0, 1 - (1 - drag) * dt * 10);
    const max = onIce ? iceTop : inWater ? 8.5 : 1.4;
    const sp = Math.hypot(v.vel.x, v.vel.z);
    v.speed = sp;
    if (sp > max) { v.vel.x *= max / sp; v.vel.z *= max / sp; }

    // Oar paddling animation
    if (v.oars && v.oars.length) {
      const paddle = sp > 0.1 || Math.abs(fwd) > 0.1 || Math.abs(strafe) > 0.1;
      v.oars.forEach((oar, idx) => {
        oar.rotation.z = paddle ? Math.sin(this.time * 8 + idx * Math.PI) * 0.45 : 0;
      });
    }

    for (const axis of ['x', 'z'] as const) {
      const prev = v.pos[axis];
      v.pos[axis] += v.vel[axis] * dt;
      const edge = 0.45 * Math.sign(v.vel[axis] || 1);
      const px = axis === 'x' ? v.pos.x + edge : v.pos.x, pz = axis === 'z' ? v.pos.z + edge : v.pos.z;
      if (solid(this.blockAt(px, v.pos.y + 0.2, pz))) { v.pos[axis] = prev; v.vel[axis] = 0; }
    }
    const col = Math.floor(v.pos.y);
    let targetY = NaN;
    for (let yy = col + 1; yy >= col - 2; yy--) {
      if (this.blockAt(v.pos.x, yy, v.pos.z) === ID.water && this.blockAt(v.pos.x, yy + 1, v.pos.z) !== ID.water) {
        targetY = yy + 0.85;
        break;
      }
    }
    if (Number.isNaN(targetY)) targetY = this.groundY(v.pos.x, v.pos.y, v.pos.z);
    v.pos.y += (targetY - v.pos.y) * Math.min(1, dt * (targetY < v.pos.y ? 6 : 10));
  }

  dispose() {
    this.clear();
    this.box.dispose();
    for (const m of this.mats.values()) m.dispose();
  }
}

export { VehicleManager as Vehicles };
