import { BLOCKS, ID } from '../game/data';

/*
 * Unified 3-D Grid A* Pathfinding (Record 014 Perfected).
 *
 * Uses a Binary Min-Heap for O(log N) priority queue operations and supports:
 *  - Walking mobs climbing 1-block steps (with headroom validation) and dropping up to `maxDrop` blocks
 *  - Diagonal moves only when both orthogonal neighbor columns are clear (no corner cutting through walls)
 *  - Fences, walls, panes, and closed doors cannot be climbed over as floors
 *  - Unloaded chunks (id < 0) are treated as impassable
 *  - Lava, fire, cactus, magma, and berry bushes avoided (except lava/fire for fireproof mobs like Striders)
 *  - Supports both function signatures:
 *      findPath(get: GetBlock, sx, sy, sz, tx, ty, tz, maxNodesOrOpts?, maxDrop?, fireproof?)
 *      findPath(world: NavigationWorld, from: PathPoint, to: PathPoint, budget?, lavaWalker?)
 */

export type GetBlock = (x: number, y: number, z: number) => number;
export interface NavigationWorld { getBlock(x: number, y: number, z: number): number; }
export interface PathPoint {
  x: number;
  y: number;
  z: number;
  0: number;
  1: number;
  2: number;
}
export type Waypoint = PathPoint;
export interface PathOptions {
  maxNodes?: number;
  maxDrop?: number;
  tall?: number;
  avoidWater?: boolean;
  fireproof?: boolean;
}

const toGetter = (w: GetBlock | NavigationWorld): GetBlock => (typeof w === 'function' ? w : (x, y, z) => w.getBlock(x, y, z));

const hazard = (id: number) => id > 0 && (id === ID.lava || id === ID.fire || id === ID.cactus || id === ID.magma_block || id === ID.sweet_berry_bush);

export function passable(id: number, fireproof = false): boolean {
  if (id < 0) return false;
  if (id === 0) return true;
  if (hazard(id)) return fireproof && (id === ID.lava || id === ID.fire);
  const d = BLOCKS[id];
  if (!d) return false;
  if (d.shape === 'door' || d.shape === 'fence' || d.shape === 'pane') return false;
  return !d.solid || d.shape === 'cross';
}

export function floorLike(id: number, fireproof = false): boolean {
  if (id <= 0) return false;
  if (fireproof && id === ID.lava) return true;
  const d = BLOCKS[id];
  return !!d && d.solid && d.shape !== 'fence' && d.shape !== 'pane' && d.shape !== 'cross' && !hazard(id);
}

export function standable(w: GetBlock | NavigationWorld, x: number, y: number, z: number, tall = 2, fireproof = false): boolean {
  const get = toGetter(w);
  const below = get(x, y - 1, z);
  if (!floorLike(below, fireproof)) return false;
  for (let i = 0; i < tall; i++) {
    const c = get(x, y + i, z);
    if (!passable(c, fireproof) || (c === ID.water && !fireproof && tall >= 2 && get(x, y + 1, z) === ID.water)) return false;
  }
  return true;
}

export function canStand(w: GetBlock | NavigationWorld, x: number, y: number, z: number, lavaWalker = false): boolean {
  const get = toGetter(w);
  const feet = get(x, y, z), head = get(x, y + 1, z), floor = get(x, y - 1, z);
  if (feet < 0 || head < 0 || floor < 0) return false;
  if (feet === ID.water && !lavaWalker) return false;
  return passable(feet, lavaWalker) && passable(head, lavaWalker) && floorLike(floor, lavaWalker);
}

export function groundStep(w: GetBlock | NavigationWorld, x: number, y: number, z: number, lavaWalker = false): number | null {
  x = Math.floor(x); z = Math.floor(z); y = Math.floor(y + 0.1);
  for (const dy of [0, 1, -1, -2, -3]) if (canStand(w, x, y + dy, z, lavaWalker)) return y + dy;
  return null;
}

export function snapToFloor(w: GetBlock | NavigationWorld, x: number, y: number, z: number, tall = 2, down = 4, up = 2, fireproof = false): number | null {
  for (let d = 0; d <= down; d++) if (standable(w, x, y - d, z, tall, fireproof)) return y - d;
  for (let u = 1; u <= up; u++) if (standable(w, x, y + u, z, tall, fireproof)) return y + u;
  return null;
}

/** Lowest y at which a mob can stand within [y - maxDrop, y + 1]; NaN when none. */
export function groundAt(w: GetBlock | NavigationWorld, x: number, y: number, z: number, maxDrop = 3, fireproof = false): number {
  const get = toGetter(w);
  for (let dy = 1; dy >= -maxDrop; dy--) {
    const yy = y + dy;
    const below = get(x, yy - 1, z);
    if (
      (floorLike(below, fireproof) || below === ID.water) &&
      passable(get(x, yy, z), fireproof) &&
      passable(get(x, yy + 1, z), fireproof)
    ) {
      if (dy === 1 && !passable(get(x, y + 2, z), fireproof)) continue;
      return yy;
    }
  }
  return NaN;
}

interface Node { x: number; y: number; z: number; g: number; f: number; parent: Node | null; closed: boolean; }

class MinHeap {
  private a: Node[] = [];
  get size() { return this.a.length; }
  push(n: Node) {
    const a = this.a;
    let i = a.length;
    a.push(n);
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (a[p].f <= n.f) break;
      a[i] = a[p];
      i = p;
    }
    a[i] = n;
  }
  pop(): Node {
    const a = this.a, top = a[0], last = a.pop()!;
    if (a.length) {
      let i = 0;
      for (;;) {
        let c = i * 2 + 1;
        if (c >= a.length) break;
        if (c + 1 < a.length && a[c + 1].f < a[c].f) c++;
        if (a[c].f >= last.f) break;
        a[i] = a[c];
        i = c;
      }
      a[i] = last;
    }
    return top;
  }
}

function makePoint(x: number, y: number, z: number): PathPoint {
  const pt: any = [x, y, z];
  pt.x = x + 0.5;
  pt.y = y;
  pt.z = z + 0.5;
  return pt as PathPoint;
}

export function findPath(
  w: GetBlock | NavigationWorld,
  sxOrFrom: number | { x: number; y: number; z: number },
  syOrTo: number | { x: number; y: number; z: number },
  szOrBudget?: number,
  txOrLava?: number | boolean,
  ty?: number,
  tz?: number,
  maxNodesOrOpts: number | PathOptions = 500,
  maxDropArg = 3,
  fireproofArg = false,
): PathPoint[] | null {
  const get = toGetter(w);
  const objectMode = typeof sxOrFrom === 'object';
  let sx: number, sy: number, sz: number, tx: number, tyGoal: number, tzGoal: number;
  let maxNodes = 500, maxDrop = maxDropArg, fp = fireproofArg, tall = 2;

  if (objectMode) {
    const from = sxOrFrom as { x: number; y: number; z: number };
    const to = syOrTo as { x: number; y: number; z: number };
    sx = Math.floor(from.x); sy = Math.floor(from.y + 0.1); sz = Math.floor(from.z);
    tx = Math.floor(to.x); tyGoal = Math.floor(to.y + 0.1); tzGoal = Math.floor(to.z);
    if (typeof szOrBudget === 'number') maxNodes = szOrBudget;
    if (typeof txOrLava === 'boolean') fp = txOrLava;
  } else {
    sx = Math.floor(sxOrFrom as number);
    sy = Math.floor(syOrTo as number);
    sz = Math.floor(szOrBudget as number);
    tx = Math.floor(txOrLava as number);
    tyGoal = Math.floor(ty as number);
    tzGoal = Math.floor(tz as number);
    if (typeof maxNodesOrOpts === 'number') maxNodes = maxNodesOrOpts;
    else if (maxNodesOrOpts) {
      maxNodes = maxNodesOrOpts.maxNodes ?? 500;
      maxDrop = maxNodesOrOpts.maxDrop ?? 3;
      tall = maxNodesOrOpts.tall ?? 2;
      fp = !!maxNodesOrOpts.fireproof;
    }
  }

  const snappedStart = snapToFloor(get, sx, sy, sz, tall, 3, 1, fp);
  if (snappedStart !== null) sy = snappedStart;
  const snappedGoal = snapToFloor(get, tx, tyGoal, tzGoal, tall, 4, 2, fp);
  if (snappedGoal !== null) tyGoal = snappedGoal;

  if (sx === tx && sy === tyGoal && sz === tzGoal) return [];

  const h = (x: number, y: number, z: number) => Math.abs(x - tx) + Math.abs(z - tzGoal) + Math.abs(y - tyGoal) * 0.5;
  const open = new MinHeap();
  const nodes = new Map<string, Node>();
  const start: Node = { x: sx, y: sy, z: sz, g: 0, f: h(sx, sy, sz), parent: null, closed: false };
  nodes.set(`${sx},${sy},${sz}`, start);
  open.push(start);

  let closest = start, expanded = 0;
  const DIRS: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

  while (open.size && expanded < maxNodes) {
    const cur = open.pop();
    if (cur.closed) continue;
    cur.closed = true;
    expanded++;
    if (cur.x === tx && cur.z === tzGoal && Math.abs(cur.y - tyGoal) <= 1) {
      closest = cur;
      break;
    }
    if (h(cur.x, cur.y, cur.z) < h(closest.x, closest.y, closest.z)) closest = cur;

    for (const [dx, dz] of DIRS) {
      const nx = cur.x + dx, nz = cur.z + dz;
      const diagonal = dx !== 0 && dz !== 0;
      if (diagonal) {
        if (!passable(get(cur.x + dx, cur.y, cur.z), fp) || !passable(get(cur.x, cur.y, cur.z + dz), fp)) continue;
        if (!passable(get(cur.x + dx, cur.y + 1, cur.z), fp) || !passable(get(cur.x, cur.y + 1, cur.z + dz), fp)) continue;
      }
      const ny = groundAt(get, nx, cur.y, nz, maxDrop, fp);
      if (Number.isNaN(ny)) continue;
      if (diagonal && ny !== cur.y) continue;
      const water = get(nx, ny, nz) === ID.water || get(nx, ny - 1, nz) === ID.water;
      const step = (diagonal ? 1.414 : 1) + (ny > cur.y ? 0.6 : 0) + Math.max(0, cur.y - ny) * 0.3 + (water ? 2.5 : 0);
      const g = cur.g + step, k = `${nx},${ny},${nz}`;
      const existing = nodes.get(k);
      if (existing) {
        if (existing.closed || existing.g <= g) continue;
        existing.g = g;
        existing.f = g + h(nx, ny, nz);
        existing.parent = cur;
        open.push(existing);
      } else {
        const next: Node = { x: nx, y: ny, z: nz, g, f: g + h(nx, ny, nz), parent: cur, closed: false };
        nodes.set(k, next);
        open.push(next);
      }
    }
  }

  if (closest === start) return objectMode ? [] : null;
  const out: PathPoint[] = [];
  for (let n: Node | null = closest; n && n !== start; n = n.parent) {
    out.push(makePoint(n.x, n.y, n.z));
  }
  out.reverse();
  return out.length ? out : (objectMode ? [] : null);
}

export function clearLine(w: GetBlock | NavigationWorld, x0: number, y: number, z0: number, x1: number, z1: number, tall = 2): boolean {
  const dx = x1 - x0, dz = z1 - z0, n = Math.ceil(Math.max(Math.abs(dx), Math.abs(dz)) * 2);
  for (let i = 1; i <= n; i++) {
    const x = Math.floor(x0 + 0.5 + (dx * i) / n), z = Math.floor(z0 + 0.5 + (dz * i) / n);
    if (!standable(w, x, y, z, tall)) return false;
  }
  return true;
}
