import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Flame, ArrowRight, Package, Check, Shield, Plus } from 'lucide-react';
import type { Engine } from '../game/engine';
import type { GameSnapshot, Stack } from '../game/types';
import { BLOCKS, resolve } from '../game/data';
import { SMELTING, FUEL } from '../systems/crafting';
import { EFFECTS, roman, enchLabel, brewResult } from '../systems/magic';
import * as SV from '../game/survival';
import { SEA } from '../world/terrain';
import { Button, ItemIcon, Panel, Slot } from './common';
import { LEVEL_XP } from '../entities/villagers';
import { findCrafterRecipe } from '../systems/automation';

export const STATION_KINDS = ['furnace', 'container', 'trade', 'enchanting', 'anvil', 'grindstone', 'smithing', 'stonecutter', 'brewing', 'loom', 'cartography', 'lectern', 'crafter'] as const;
export type StationKind = (typeof STATION_KINDS)[number];
export const isStation = (s: string): s is StationKind => (STATION_KINDS as readonly string[]).includes(s);

const TITLES: Record<StationKind, [string, string, string]> = {
  furnace: ['かまど', 'Furnace', 'SMELTING · FUEL · OUTPUT'],
  container: ['チェスト', 'Chest', 'A PLACE FOR EVERYTHING'],
  trade: ['村人との取引', 'Villager trades', 'TRADE. GROW. DISCOVER.'],
  crafter: ['自動作業台', 'Crafter', 'A LITTLE REDSTONE. A LOT OF POSSIBILITIES.'],
  enchanting: ['エンチャントテーブル', 'Enchanting table', 'LAPIS · LEVELS · BOOKSHELVES'],
  anvil: ['金床', 'Anvil', 'REPAIR · COMBINE · RENAME'],
  grindstone: ['砥石', 'Grindstone', 'DISENCHANT · REPAIR'],
  smithing: ['鍛冶台', 'Smithing table', 'TEMPLATE · GEAR · MATERIAL'],
  stonecutter: ['石切台', 'Stonecutter', 'ONE BLOCK, MANY SHAPES'],
  brewing: ['醸造台', 'Brewing stand', 'BOTTLES · INGREDIENT · BLAZE POWDER'],
  loom: ['織機', 'Loom', 'BANNER · DYE · PATTERN'],
  cartography: ['製図台', 'Cartography table', 'MAP · PAPER · GLASS'],
  lectern: ['書見台', 'Lectern', 'READ · WRITE · SIGN'],
};
/** How many inventory items each selection-style station works on. */
const NEED: Partial<Record<StationKind, number>> = { enchanting: 1, anvil: 2, grindstone: 2, smithing: 3, stonecutter: 1, loom: 2, cartography: 2 };

/** Top-down terrain map: label = "x,z|zoom|lock". Each pixel covers 2^zoom blocks. */
function MapCanvas({ engine, label }: { engine: Engine; label: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const [pos = '0,0', zoom = '1'] = label.split('|'), [cx = 0, cz = 0] = pos.split(',').map(Number), scale = 2 ** Math.max(0, Math.min(4, Number(zoom) || 1)), N = 96;
    c.width = N; c.height = N;
    const ctx = c.getContext('2d')!, img = ctx.createImageData(N, N), tr = engine.terrain;
    const hex = (h: string) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
    let prevRow = new Float32Array(N);
    for (let j = 0; j < N; j++) {
      const row = new Float32Array(N);
      for (let i = 0; i < N; i++) {
        const x = Math.round(cx + (i - N / 2) * scale), z = Math.round(cz + (j - N / 2) * scale), h = tr.height(x, z);
        row[i] = h;
        let rgb: number[];
        if (tr.dimension === 'overworld' && h < SEA) { const d = Math.min(1, (SEA - h) / 30); rgb = [52 - d * 26, 110 - d * 50, 190 - d * 60]; }
        else {
          rgb = hex(BLOCKS[tr.surface(tr.biomeAt(x, z, h), x, z, h)]?.color ?? '#7f9a55');
          const shade = j > 0 ? Math.max(-0.22, Math.min(0.22, (h - prevRow[i]) * 0.07)) : 0;
          rgb = rgb.map(v => Math.max(0, Math.min(255, v * (1 + shade))));
        }
        const o = (j * N + i) * 4;
        img.data[o] = rgb[0]; img.data[o + 1] = rgb[1]; img.data[o + 2] = rgb[2]; img.data[o + 3] = 255;
      }
      prevRow = row;
    }
    ctx.putImageData(img, 0, 0);
    const px = (engine.position.x - cx) / scale + N / 2, pz = (engine.position.z - cz) / scale + N / 2;
    if (px >= 0 && px < N && pz >= 0 && pz < N) { ctx.fillStyle = '#ffffff'; ctx.fillRect(px - 1.5, pz - 1.5, 3, 3); ctx.fillStyle = '#d8382c'; ctx.fillRect(px - 0.5, pz - 0.5, 1, 1); }
  }, [label, engine]);
  return <canvas ref={ref} className="map-canvas" aria-label="map" />;
}

export function Stations({ engine, snapshot, kind, onClose }: { engine: Engine; snapshot: GameSnapshot; kind: StationKind; onClose: () => void }) {
  const ja = engine.settings.language === 'ja', t = (j: string, e: string) => (ja ? j : e);
  const [, force] = useState(0), refresh = () => force(x => x + 1);
  const [sel, setSel] = useState<number[]>(() => Array(NEED[kind] ?? 0).fill(-1));
  const [name, setName] = useState('');
  const [pattern, setPattern] = useState('stripe');
  const [bulk, setBulk] = useState(false);
  const [crafterPick, setCrafterPick] = useState(-1);
  const creative = engine.meta.mode === 'creative', lv = SV.level(engine);
  if ((kind === 'furnace' || kind === 'container' || kind === 'crafter') && !engine.containers[engine.stationKey]) {
    engine.containers[engine.stationKey] = kind === 'furnace' ? [null, null, null] : kind === 'crafter' ? Array(9).fill(null) : Array(27).fill(null);
  }
  const slots: (Stack | null)[] = engine.containers[engine.stationKey] ?? [];
  const A = (k: number): Stack | null => (sel[k] >= 0 ? SV.slotAt(engine, sel[k]) : null);
  const clear = (k: number) => setSel(s => s.map((v, i) => (i === k ? -1 : v)));
  const done = (ok: boolean, reset = false) => { if (ok) { if (reset) setSel(s => s.map(() => -1)); refresh(); } };
  const name1 = (n: string) => (ja ? resolve(n)?.ja : n.replace(/_/g, ' ')) ?? n;

  const furnacePut = (i: number) => {
    const s = SV.slotAt(engine, i);
    if (!s) return;
    const dest = SMELTING[s.name] ? 0 : FUEL[s.name] ? 1 : -1;
    if (dest < 0 || (slots[dest] && slots[dest]!.name !== s.name)) return;
    const n = Math.min(64 - (slots[dest]?.count ?? 0), s.count);
    if (n <= 0) return;
    if (slots[dest]) slots[dest]!.count += n; else slots[dest] = { name: s.name, count: n };
    engine.removeItem(s.name, n);
  };
  const click = (i: number) => {
    const s = SV.slotAt(engine, i);
    if (!s) return;
    if (kind === 'furnace') furnacePut(i);
    else if (kind === 'crafter') setCrafterPick(i);
    else if (kind === 'container') SV.containerPut(engine, i, slots);
    else if (kind === 'brewing') SV.brewPut(engine, i);
    else if (kind === 'lectern') {
      if (engine.stationKey !== 'hand' && slots.length === 1 && !slots[0] && ['writable_book', 'written_book', 'book', 'enchanted_book'].includes(s.name)) { slots[0] = { ...s, count: 1 }; SV.takeFrom(engine, i, 1); }
    } else if (NEED[kind]) {
      const next = [...sel], at = next.indexOf(i);
      if (at >= 0) next[at] = -1;
      else {
        let pos = next.indexOf(-1);
        if (kind === 'smithing') pos = s.name === 'netherite_upgrade' ? 0 : s.name === 'netherite_ingot' ? 2 : 1;
        if (kind === 'loom') pos = s.name.endsWith('_banner') ? 0 : s.name.endsWith('_dye') ? 1 : -1;
        if (kind === 'cartography') pos = s.name === 'filled_map' && next[0] < 0 ? 0 : 1;
        if (pos < 0) return;
        next[pos] = i;
        if (kind === 'anvil' && pos === 0) setName(s.label ?? '');
      }
      setSel(next);
      return;
    }
    refresh();
  };
  const input = (k: number, label: string) => <div className="st-input"><Slot stack={A(k)} onClick={() => clear(k)} label={label} /><small>{label}</small></div>;
  const result = (stack: Stack | null, extra?: ReactNode) => <div className="st-result"><ArrowRight size={26} /><Slot stack={stack} />{extra}</div>;

  let body: ReactNode = null, hint = '';
  if (kind === 'furnace') {
    hint = t('石炭・木材・棒を燃料に使えます', 'Coal, planks and sticks work as fuel');
    body = <div className="furnace-machine"><div className="furnace-input"><span>{t('材料', 'Input')}</span><Slot stack={slots[0]} onClick={() => done(SV.containerTake(engine, slots, 0))} /><Flame size={22} className={engine.furnaces[engine.stationKey]?.burn > 0 ? 'burning' : ''} /><Slot stack={slots[1]} onClick={() => done(SV.containerTake(engine, slots, 1))} /><span>{t('燃料', 'Fuel')}</span></div><div className="smelt-arrow"><ArrowRight size={38} /><div className="smelt-progress"><i style={{ width: `${(engine.furnaces[engine.stationKey]?.progress ?? 0) * 100}%` }} /></div></div><div className="furnace-output"><span>{t('完成', 'Output')}</span><Slot stack={slots[2]} onClick={() => done(SV.containerTake(engine, slots, 2))} /></div></div>;
  } else if (kind === 'container') {
    hint = t('アイテムはワールドと一緒に保存されます（エンチャントも保持）', 'Contents are saved with your world (enchantments included)');
    body = <div className="chest-grid">{slots.map((s, i) => <Slot key={i} stack={s} onClick={() => done(SV.containerTake(engine, slots, i))} />)}</div>;
  } else if (kind === 'trade') {
    const title = engine.mobs.tradeTitle(), hero = engine.mobs.heroTimer > 0;
    const activeMob = engine.mobs.activeVillager ?? engine.mobs.tradingMob;
    const villager = activeMob?.villager;
    const xpVal = villager?.xp ?? activeMob?.xp ?? 0;
    const lvlVal = villager?.level ?? activeMob?.level ?? 1;
    const next = LEVEL_XP[lvlVal] ?? 250;
    hint = t(`${title.ja}${hero ? ' · 村の英雄割引中' : ''} — 取引すると村人が経験を積み、職業ブロックの近くで日中に在庫を補充します`, `${title.en}${hero ? ' · Hero of the Village discount' : ''} — trading levels the villager up and stock replenishes near a job block`);
    const trades = engine.mobs.tradeOffers();
    body = <div className="trade-list">
      <div className="trade-profile"><strong>{ja ? title.ja : title.en}</strong><small>{xpVal} / {next} XP</small><span className="trade-progress"><i style={{ width: `${Math.min(100, (xpVal / next) * 100)}%` }} /></span></div>
      {trades.length === 0 && <p className="muted">{t('この村人はまだ職業がありません。近くにコンポスター・書見台・溶鉱炉などの職業ブロックを置いてください。', 'This villager has no profession yet. Place a job-site block (composter, lectern, blast furnace…) nearby.')}</p>}
      {trades.map((tr, i) => {
        const used = villager?.uses?.[tr.id] ?? 0;
        const soldOut = used >= tr.maxUses;
        return <div key={tr.id ?? i} title={`${name1(tr.give)} > ${name1(tr.get)}`}><ItemIcon name={tr.give} /><span>{tr.n}</span><ArrowRight size={19} /><ItemIcon name={tr.get} /><span>{tr.count}</span><Button disabled={soldOut || engine.countItem(tr.give) < tr.n} onClick={() => { if (engine.trade(tr.give, tr.n, tr.get, tr.count, tr.ench)) { engine.mobs.recordTrade(tr); engine.audio?.play('click'); refresh(); } }}>{soldOut ? t('在庫切れ', 'Sold out') : t('取引', 'Trade')}</Button></div>;
      })}
    </div>;
  } else if (kind === 'crafter') {
    hint = t('持ちものを選んで、マスをクリックすると1個ずつ配置。空きマスの小さなボタンでホッパー搬入の有効・無効を切り替えます。', 'Select an inventory item, then click a grid slot to place one. Toggle empty slots to control hopper input.');
    const mask = engine.crafterMask(engine.stationKey), match = findCrafterRecipe(slots, mask), selected = crafterPick >= 0 ? SV.slotAt(engine, crafterPick) : null;
    body = <div className="st-row"><div className="crafter-grid">{Array.from({ length: 9 }, (_, i) => <div key={i} className={`crafter-slot ${mask & (1 << i) ? 'disabled' : ''}`}><Slot stack={slots[i] ?? null} label={t(`材料 ${i + 1}`, `Ingredient ${i + 1}`)} onClick={() => {
      if (mask & (1 << i)) return;
      if (selected && (!slots[i] || slots[i]!.name === selected.name && slots[i]!.count < (resolve(selected.name)?.stack ?? 64))) {
        if (slots[i]) slots[i]!.count++; else slots[i] = { ...selected, count: 1 };
        SV.takeFrom(engine, crafterPick, 1);
        if (!SV.slotAt(engine, crafterPick)) setCrafterPick(-1);
      } else if (!selected) SV.containerTake(engine, slots, i);
      refresh();
    }} />{!slots[i] && <button aria-label={t(`マス ${i + 1} を切り替え`, `Toggle slot ${i + 1}`)} onClick={() => { engine.toggleCrafterSlot(i); refresh(); }}>{mask & (1 << i) ? '+' : 'x'}</button>}</div>)}</div><div className="st-result"><ArrowRight size={24} /><Slot stack={match ? { name: match.result, count: match.count } : null} label={t('完成品のプレビュー', 'Recipe preview')} /></div><div className="crafter-note"><strong>{t('信号を受け取ると、自動クラフト。', 'One pulse. One recipe.')}</strong><p>{t('レバーやボタンで信号を送ってください。完成品は正面のチェストへ入り、チェストがなければ排出されます。', 'Send a pulse with a lever or button. The result goes into the container in front, or drops into the world.')}</p>{selected && <Button onClick={() => setCrafterPick(-1)}>{t('選択を解除', 'Clear selection')}: {name1(selected.name)}</Button>}</div></div>;
  } else if (kind === 'enchanting') {
    const item = A(0), offers = sel[0] >= 0 ? SV.enchantOffers(engine, sel[0]) : [], shelves = SV.bookshelves(engine), lapis = engine.countItem('lapis_lazuli');
    hint = t('本棚を台の2マス外側に最大15個置くとレベル30まで解放。金床でエンチャントの本を合成できます。', 'Up to 15 bookshelves two blocks away unlock level 30. Combine enchanted books on an anvil.');
    body = <div className="st-row">
      <div className="st-inputs">{input(0, t('アイテム', 'Item'))}<div className="st-note">📚 {shelves}/15</div><div className="st-note"><ItemIcon name="lapis_lazuli" size={18} /> {creative ? '∞' : lapis} · Lv {lv}</div></div>
      <div className="st-options">
        {offers.length === 0 && <p className="muted">{!item ? t('下の持ちものから、エンチャントするアイテム（道具・武器・防具・本）を選んでください。', 'Pick a tool, weapon, armor piece or book from your inventory below.') : item.ench ? t('すでにエンチャントされています。金床で本と合成するか、砥石で外せます。', 'Already enchanted — combine with books on an anvil or strip it on a grindstone.') : t('このアイテムにはエンチャントできません。', 'This item cannot be enchanted.')}</p>}
        {offers.map((o, i) => {
          const ok = creative || (lv >= o.level && lapis >= o.cost);
          return <button key={i} className="st-option" disabled={!ok} onClick={() => done(SV.doEnchant(engine, sel[0], i))}>
            <b>{o.cost}</b>
            <span>{enchLabel(o.list[0][0], o.list[0][1], ja)}{o.list.length > 1 ? ' . . . ?' : ''}</span>
            <small>{t('必要レベル', 'Requires level')} {o.level} · {t('消費', 'Costs')} {o.cost} Lv + {t('ラピス', 'lapis')} ×{o.cost}</small>
          </button>;
        })}
      </div>
    </div>;
  } else if (kind === 'anvil') {
    const r = SV.anvilPreview(engine, sel[0], sel[1], name), afford = creative || (!!r && lv >= r.cost && r.cost <= 39);
    hint = t('左: 対象 / 右: 同じアイテム・修理素材・エンチャントの本。名前だけの変更もできます。', 'Left: target · right: same item, repair material or enchanted book. Renaming alone works too.');
    body = <div className="st-row">
      <div className="st-inputs"><div className="st-slots">{input(0, t('対象', 'Target'))}<Plus size={18} />{input(1, t('素材', 'Sacrifice'))}</div><input className="st-name" value={name} maxLength={35} placeholder={t('名前を変更（任意）', 'Rename (optional)')} onChange={e => setName(e.target.value)} onKeyDown={e => e.stopPropagation()} /></div>
      {result(r?.result ?? null, <><span className={`st-cost ${r && !afford ? 'bad' : ''}`}>{r ? (r.cost > 39 && !creative ? t('コストが高すぎます！', 'Too expensive!') : `${t('コスト', 'Cost')}: ${r.cost} Lv`) : '—'}</span><Button primary disabled={!r || !afford} onClick={() => { if (SV.doAnvil(engine, sel[0], sel[1], name)) { setName(''); done(true, true); } }}>{t('合成する', 'Combine')}</Button></>)}
    </div>;
  } else if (kind === 'grindstone') {
    const r = SV.grindPreview(engine, sel[0], sel[1]);
    hint = t('エンチャントを外して経験値に戻します（呪いは残ります）。同じ道具2つで修理も可能。', 'Removes enchantments for XP (curses stay). Two of the same tool are merged and repaired.');
    body = <div className="st-row"><div className="st-inputs"><div className="st-slots">{input(0, 'A')}<Plus size={18} />{input(1, 'B')}</div></div>{result(r?.result ?? null, <><span className="st-cost">{r ? `+${r.xp} XP` : '—'}</span><Button primary disabled={!r} onClick={() => done(SV.doGrind(engine, sel[0], sel[1]), true)}>{t('研ぐ', 'Grind')}</Button></>)}</div>;
  } else if (kind === 'smithing') {
    const r = SV.smithPreview(engine, sel[0], sel[1], sel[2]);
    hint = t('ネザライト強化の鍛冶型 + ダイヤモンド装備 + ネザライトインゴット。エンチャントと耐久は引き継がれます。', 'Netherite upgrade template + diamond gear + netherite ingot. Enchantments and wear carry over.');
    body = <div className="st-row"><div className="st-inputs"><div className="st-slots">{input(0, t('鍛冶型', 'Template'))}{input(1, t('装備', 'Gear'))}{input(2, t('素材', 'Material'))}</div></div>{result(r, <Button primary disabled={!r} onClick={() => done(SV.doSmith(engine, sel[0], sel[1], sel[2]), true)}>{t('強化する', 'Upgrade')}</Button>)}</div>;
  } else if (kind === 'stonecutter') {
    const opts = SV.stonecutOptions(engine, sel[0]);
    hint = t('石材1個から階段・ハーフブロック(×2)・壁・レンガ等を無駄なく切り出せます。', 'Cut stairs, slabs (×2), walls and bricks from a single block with no waste.');
    body = <div className="st-row">
      <div className="st-inputs">{input(0, t('石材', 'Block'))}<label className="st-note"><input type="checkbox" checked={bulk} onChange={e => setBulk(e.target.checked)} /> {t('スタックごと加工', 'Whole stack')}</label></div>
      <div className="st-grid">{opts.length === 0 && <p className="muted">{A(0) ? t('この素材は加工できません', 'Nothing can be cut from this') : t('石材を選んでください', 'Pick a stone block')}</p>}{opts.map(o => <button key={o.result} title={name1(o.result)} onClick={() => done(SV.doStonecut(engine, sel[0], o.result, bulk))}><ItemIcon name={o.result} size={30} />×{o.count}</button>)}</div>
    </div>;
  } else if (kind === 'brewing') {
    const st = engine.furnaces[engine.stationKey], ing = slots[3];
    hint = t('水入り瓶 + ネザーウォート → 奇妙なポーション → 各素材。レッドストーンで延長、グロウストーンで強化、火薬でスプラッシュ化。', 'Water bottle + nether wart → awkward potion → ingredient. Redstone extends, glowstone strengthens, gunpowder makes it splash.');
    body = <div className="brew-stand">
      <div className="brew-fuel"><Slot stack={slots[4] ?? null} onClick={() => done(SV.containerTake(engine, slots, 4))} label={t('ブレイズパウダー', 'Blaze powder')} /><span>{t('燃料', 'Fuel')} {st?.burn ?? 0}/20</span></div>
      <div className="brew-fuel"><Slot stack={ing ?? null} onClick={() => done(SV.containerTake(engine, slots, 3))} label={t('材料', 'Ingredient')} /><div className="brew-bar"><i style={{ width: `${(st?.progress ?? 0) * 100}%` }} /></div></div>
      <div className="brew-fuel"><div className="brew-bottles">{[0, 1, 2].map(i => <Slot key={i} stack={slots[i] ?? null} onClick={() => done(SV.containerTake(engine, slots, i))} label={t('瓶', 'Bottle')} />)}</div><span>{ing && [0, 1, 2].some(i => slots[i] && brewResult(slots[i]!.name, ing.name)) ? `→ ${[0, 1, 2].map(i => (slots[i] ? brewResult(slots[i]!.name, ing.name) : null)).filter(Boolean).map(n => name1(n!)).filter((v, i, a) => a.indexOf(v) === i).join(' / ')}` : t('瓶 ×3', 'Bottles ×3')}</span></div>
    </div>;
  } else if (kind === 'loom') {
    const banner = A(0), dye = A(1);
    hint = t('旗に染料で模様を重ねます（最大6層）。模様は旗の名前として記録されます。', 'Layer up to six dyed patterns on a banner. Patterns are recorded in the banner name.');
    body = <div className="st-row">
      <div className="st-inputs"><div className="st-slots">{input(0, t('旗', 'Banner'))}<Plus size={18} />{input(1, t('染料', 'Dye'))}</div><div className="st-note">{banner?.label ?? t('模様なし', 'No patterns yet')}</div><Button primary disabled={!banner || !dye} onClick={() => done(SV.doLoom(engine, sel[0], sel[1], pattern))}>{t('模様を織る', 'Weave pattern')}</Button></div>
      <div className="st-grid">{SV.LOOM_PATTERNS.map(([id, j, e]) => <button key={id} className={pattern === id ? 'active' : ''} onClick={() => setPattern(id)}>{ja ? j : e}</button>)}</div>
    </div>;
  } else if (kind === 'cartography') {
    const hand = engine.stationKey === 'hand', held = snapshot.hotbar[snapshot.selected], map = hand ? (held?.name === 'filled_map' ? held : [...snapshot.hotbar, ...snapshot.inventory].find(s => s?.name === 'filled_map') ?? null) : A(0);
    const [, zoom = '1', lock = ''] = (map?.label ?? '').split('|');
    hint = hand ? t('製図台で 紙=縮尺拡大 / ガラス板=ロック / 白紙の地図=複製 ができます。', 'At a cartography table: paper zooms out, a glass pane locks, an empty map copies.') : t('地図 + 紙（縮尺拡大）/ ガラス板（ロック）/ 白紙の地図（複製）', 'Map + paper (zoom out) / glass pane (lock) / empty map (copy)');
    body = <div className="st-row">
      {!hand && <div className="st-inputs"><div className="st-slots">{input(0, t('地図', 'Map'))}<Plus size={18} />{input(1, t('紙など', 'Paper…'))}</div><Button primary disabled={!A(0) || !A(1)} onClick={() => done(SV.doCartography(engine, sel[0], sel[1]))}>{t('加工する', 'Apply')}</Button></div>}
      <div className="st-result">{map?.name === 'filled_map' ? <><MapCanvas engine={engine} label={map.label ?? '0,0'} /><span className="st-cost">1:{2 ** (Number(zoom) || 1)}{lock ? ' 🔒' : ''}</span></> : <p className="muted">{t('地図を選ぶとここに表示されます。白紙の地図は手に持って右クリックで作成。', 'Pick a map to preview it. Right-click with an empty map to create one.')}</p>}</div>
    </div>;
  } else if (kind === 'lectern') {
    const book = SV.lecternBook(engine), hand = engine.stationKey === 'hand', editable = book?.name === 'writable_book';
    hint = hand ? t('本と羽根ペンは書き込めます。署名すると記入済みの本になります。', 'A book and quill can be edited; signing turns it into a written book.') : t('本を置くと読めます。クリックで取り出し。', 'Place a book to read it. Click the slot to take it back.');
    body = <div className="st-row">
      {!hand && <div className="st-inputs"><Slot stack={book} onClick={() => done(SV.containerTake(engine, slots, 0))} label={t('本', 'Book')} /><small>{t('本', 'Book')}</small></div>}
      {book ? <div className="st-result"><textarea className="book-page" readOnly={!editable} value={book.label ?? ''} maxLength={1500} placeholder={editable ? t('ここに書き込めます…', 'Write here…') : t('（白紙）', '(blank)')} onChange={e => { book.label = e.target.value; refresh(); }} onKeyDown={e => e.stopPropagation()} />{editable && <Button onClick={() => { book.name = 'written_book'; refresh(); }}>{t('署名して完成させる', 'Sign & finish')}</Button>}</div> : <p className="muted">{t('下の持ちものから本を選んで書見台に置いてください。', 'Pick a book from your inventory to place it on the lectern.')}</p>}
    </div>;
  }

  const [tj, te, eyebrow] = TITLES[kind];
  return <Panel title={t(tj, te)} eyebrow={eyebrow} onBack={onClose} wide>
    <div className="station-layout">
      <div className="station-top">{body}</div>
      <div className="station-inventory">
        <div className="section-label"><Package size={15} />{NEED[kind] ? t('持ちもの — クリックで選択 / 解除', 'Inventory — click to select / deselect') : t('持ちもの — クリックで移動', 'Inventory — click to transfer')}<span>Lv {lv}</span></div>
        <div className="inventory-grid">{snapshot.inventory.map((s, i) => <Slot key={i + 9} stack={s} selected={sel.includes(i + 9) || (kind === 'crafter' && crafterPick === i + 9)} onClick={() => click(i + 9)} />)}</div>
        <div className="section-label hotbar-label">{t('ホットバー', 'Hotbar')}</div>
        <div className="inventory-grid">{snapshot.hotbar.map((s, i) => <Slot key={i} stack={s} selected={sel.includes(i) || (kind === 'crafter' ? crafterPick === i : !NEED[kind] && engine.selected === i)} onClick={() => click(i)} />)}</div>
      </div>
    </div>
    <footer className="panel-footer"><span className="muted">{hint}</span><Button primary onClick={onClose}><Check size={15} />{t('完了', 'Done')}</Button></footer>
  </Panel>;
}

/** In-game HUD additions: active effects, attack cooldown, charge meter, shield state and the off-hand slot. */
export function HudExtras({ s, ja }: { s: GameSnapshot; ja: boolean }) {
  const fmt = (sec: number) => (sec > 3600 ? '∞' : `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`);
  return <>
    {s.effects.some(f => f.id === 'blindness' || f.id === 'darkness') && <div className="blind-overlay" />}
    {s.effects.some(f => f.id === 'nausea') && <div className="nausea-overlay" />}
    {s.effects.some(f => f.id === 'night_vision') && <div className="nightvision-overlay" />}
    {s.effects.length > 0 && <div className="effect-list">{s.effects.map(f => {
      const d = EFFECTS[f.id];
      return d ? <div key={f.id} className={d.bad ? 'bad' : ''} style={{ borderColor: d.color }}><i style={{ background: d.color }} /><span>{ja ? d.ja : d.en}{f.amp > 0 ? ' ' + roman(f.amp + 1) : ''}</span><b>{fmt(f.t)}</b></div> : null;
    })}</div>}
    {s.mode !== 'creative' && s.attackCharge < 0.98 && <div className="attack-meter"><i style={{ width: `${s.attackCharge * 100}%` }} /></div>}
    {s.useCharge > 0 && <div className="attack-meter use"><i style={{ width: `${s.useCharge * 100}%` }} /></div>}
    {s.blocking && <div className="block-indicator"><Shield size={14} />{ja ? 'ガード中' : 'Blocking'}</div>}
    {s.offhand && <div className="offhand-slot"><Slot stack={s.offhand} label="off-hand" /></div>}
  </>;
}
