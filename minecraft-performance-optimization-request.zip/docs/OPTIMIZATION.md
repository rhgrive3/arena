# Performance Update

## Scope

The supplied integrated archive was imported, not replaced with a reduced game.
The launcher entry is `src/App.tsx`; the retained game UI is `src/GameApp.tsx`.
Terrain generation, crafting, survival, redstone, entities, particles and world-save formats are retained.
All 14 files in the supplied `world-generation.sha256` manifest remain byte-identical, including the mesher and worker.

## Changes

1. **No title-screen engine.** The title uses a static local panorama. WebGL, terrain workers and game audio are instantiated only when a world is launched. The existing single-file Vite build still includes game JavaScript in its bundle; this is initialization deferral, not a promise of production network code splitting.
2. **Data-only simulation ring.** Activate the worker's existing `sideOnly` path. Retain voxel data but skip meshing for the outer simulation ring. On entering render range, request a full mesh, including when the player moves while a data-only result is in flight.
3. **No duplicate read jobs.** Read requests recognize both in-flight jobs and completed uploads. Reading an unloaded cell no longer increments its mutation version. Queries outside the retained ring no longer repeatedly regenerate immediately evicted chunks.
4. **Bounded producer/consumer queues.** Stop dispatching when uploaded results accumulate. Limit main-thread mounting to a time budget of 2.5 ms during play and 8 ms while loading, with a maximum batch count. An indivisible first upload always runs to ensure progress; a single upload can still exceed the budget.
5. **Compact GPU indices.** Meshes below 65,536 vertices use lossless 16-bit GPU index buffers. Larger meshes retain their 32-bit buffers without copying. Index memory is halved where eligible, not total GPU memory. Vertex positions, textures, lighting and topology are unchanged. Packing happens at upload, preserving the original mesher/worker byte-for-byte.
6. **Conservative adaptation.** Smoothed frame times, a CPU-time heuristic, warmup and hysteresis replace the previous coarse FPS threshold. Transient upload spikes and CPU-heavy frames do not trigger a resolution reduction. Render scale changes in small steps between 0.8 and 1, recovering slowly. This is not a hardware GPU timer or a guaranteed 60 FPS controller.
7. **Device-aware workers.** Use one worker on a dual-core device and cap memory-constrained devices at two, leaving room for input and rendering. Fewer workers may increase initial generation time while reducing CPU contention and memory use.
8. **Settings without unnecessary reallocations.** Volume, language and control changes retain the adaptive render scale and avoid resetting the framebuffer. Only rendering-relevant changes update that state.
9. **Hidden tabs and cleanup.** Suspend the animation loop while hidden and reset timing on return. Explicitly terminate workers and dispose vehicle/piston resources. Release the WebGL context on final exit, with canvas ownership guarding React Strict Mode's immediate effect remount.
10. **Lightweight, accessible launcher.** Local 245 KB panorama and a single subsetted variable font. Keyboard focus-trapped dialogs, reduced-motion support, Japanese/English, touch controls, imports/exports and world creation. Motion is limited to entry and interaction transitions.

## Verification

- `npm run build`: successful production build.
- All 21 inherited regression suites passed in a serial run. The script prints "All 19" before its two final suites.
- 13 new optimization tests cover CPU-bound behavior, hysteresis, recovery, continuous streaming, lossless indices and ring boundaries.
- All 14 supplied world-generation SHA-256 checks passed without changing expected hashes.
- Chromium launcher smoke test passed: settings persistence, language, world creation form, panorama, mobile layout, actual game startup, save and return to title.
- Chromium lifecycle smoke test passed: data-only outer chunks, real 16-bit GPU buffers, no volume-triggered resize, hidden-tab suspension, streamed mesh promotion after moving, valid index ranges, idempotent cleanup and context release.
- The browser tests use SwiftShader in a sandbox, so their FPS is not a hardware performance benchmark. No fabricated before/after FPS or performance percentage is presented.

## Tradeoffs And Open Issues

- Adaptive mode can reduce rendering resolution by up to 20% per axis. It is optional; choose the quality preset to disable it. UI stays at CSS resolution.
- Low quality disables dynamic shadows. Terrain, textures and vertex ambient occlusion remain.
- Limiting worker concurrency and upload bursts can increase background generation latency. Visible and near-player requests are prioritized.
- The original archive and this integration both report the same 49 TypeScript diagnostics (unused code, incomplete upstream interfaces and existing call/signature mismatches). These are not introduced by the optimization; full static type checking is not clean. They were not hidden by weakening compiler flags.
- No low-end physical-device benchmark, long-duration memory-soak test, cross-browser matrix or exhaustive saved-world migration test has been performed.
- The image on the title screen is illustrative, not a live screenshot or a claim about in-game shader fidelity.

The original progress record is retained as `docs/ORIGINAL-PROGRESS.md`.