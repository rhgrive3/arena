import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';

const browser = await chromium.launch({ args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 480, height: 300 } });
const errors = [];
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') errors.push(message.text().slice(0, 300)); });
await page.addInitScript(() => {
  localStorage.setItem('voxel.settings', JSON.stringify({ quality: 'low', distance: 2, adaptiveResolution: true, muted: true, touch: false }));
});
await page.goto(process.env.TEST_URL || 'http://localhost:5173');
await page.getByRole('button', { name: /シングルプレイ/ }).click();
await page.getByRole('button', { name: 'この世界で遊ぶ' }).click();
await page.waitForFunction(() => window.__game?.ready, null, { timeout: 120000 });
await page.waitForFunction(() => {
  const g = window.__game;
  return !g.queue.length && !g.pending.size && !g.uploadQueue.length;
}, null, { timeout: 120000 });

const first = await page.evaluate(() => {
  const g = window.__game;
  return { rendered: g.chunks.size, dataOnly: [...g.sideChunks.values()].filter(c => c.dataOnly).length, gpuIndices16: [...g.chunks.values()].filter(c => c.solid.geometry.index.array instanceof Uint16Array).length, simulations: g.sideChunks.size, workers: g.workers.length };
});
assert.ok(first.dataOnly > 0, 'Outside ring skips meshing');
assert.equal(first.dataOnly, first.simulations);
assert.ok(first.gpuIndices16 > 0, 'Compact GPU index buffers are active');

await page.evaluate(() => {
  const g = window.__game;
  g.pause();
  g.renderScale = 0.9;
  g.renderer.setPixelRatio(g.basePixelRatio * 0.9);
  const before = g.renderer.getPixelRatio();
  g.setSettings({ ...g.settings, volume: 0.1 });
  if (g.renderer.getPixelRatio() !== before) throw new Error('Audio reset adaptive scale');
});

const sleeping = await page.evaluate(() => {
  const g = window.__game;
  Object.defineProperty(document, 'hidden', { configurable: true, get: () => true });
  document.dispatchEvent(new Event('visibilitychange'));
  return { frame: g.renderer.info.render.frame, elapsed: g.elapsed };
});
await page.waitForTimeout(500);
const stillSleeping = await page.evaluate(() => ({ frame: window.__game.renderer.info.render.frame, elapsed: window.__game.elapsed }));
assert.deepEqual(stillSleeping, sleeping, 'Hidden tabs stop both rendering and elapsed time');
await page.evaluate(() => {
  Object.defineProperty(document, 'hidden', { configurable: true, get: () => false });
  document.dispatchEvent(new Event('visibilitychange'));
});
await page.waitForFunction(frame => window.__game.renderer.info.render.frame > frame, sleeping.frame);

const destination = await page.evaluate(() => {
  const g = window.__game;
  const candidate = [...g.sideChunks.values()].find(c => c.dataOnly);
  g.position.set(candidate.cx * 16 + 8, g.position.y, candidate.cz * 16 + 8);
  g.streamAt = -10;
  return { cx: candidate.cx, cz: candidate.cz };
});
try { await page.waitForFunction(({ cx, cz }) => {
  const g = window.__game;
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
    const c = g.chunks.get(`${cx + dx},${cz + dz}`);
    if (!c || c.dataOnly || !c.hasSolid) return false;
  }
  return true;
}, destination, { timeout: 45000 }); }
catch (error) {
  console.log('Streaming diagnostic', await page.evaluate(() => {
    const g = window.__game;
    return { active: g.active, position: g.position.toArray(), focus: g.focus, hidden: document.hidden, elapsed: g.elapsed,
      chunks: [...g.chunks].map(([key, c]) => [key, c.dataOnly, c.hasSolid]), side: [...g.sideChunks].map(([key, c]) => [key, c.dataOnly]),
      queue: g.queue, pending: [...g.pending], uploads: g.uploadQueue.length, workers: g.workers.map(w => ({ key: w.key, busy: w.busy })) };
  }));
  await browser.close();
  throw error;
}

const highFrame = await page.evaluate(() => {
  const g = window.__game;
  g.setSettings({ ...g.settings, quality: 'high' });
  return g.renderer.info.render.frame;
});
await page.waitForFunction(frame => window.__game.renderer.info.render.frame > frame + 2, highFrame, { timeout: 30000 });
assert.ok(await page.evaluate(() => window.__game.renderer.shadowMap.enabled && !window.__game.environment.failed), 'High-quality shadows render without shader fallback');

const final = await page.evaluate(() => {
  const g = window.__game;
  let valid = true;
  for (const c of g.chunks.values()) {
    const i = c.solid.geometry.index;
    if ([...i.array].some(n => n >= c.solid.geometry.attributes.position.count)) valid = false;
  }
  const result = { validIndices: valid, uploads: g.uploadQueue.length, workers: g.workers.length, ringPromoted: !g.chunks.get(`${Math.floor(g.position.x / 16)},${Math.floor(g.position.z / 16)}`).dataOnly };
  g.dispose();
  g.dispose();
  return result;
});
await page.waitForFunction(() => window.__game.renderer.getContext().isContextLost());
final.contextReleased = true;
assert.ok(final.ringPromoted);
assert.ok(final.validIndices);
assert.ok(final.contextReleased);
assert.ok(final.uploads <= final.workers * 3, 'Upload backpressure bounds queued buffers');
assert.deepEqual(errors, []);
console.log(JSON.stringify({ passed: true, first, destination, final, runtimeErrors: errors }, null, 2));
await browser.close();