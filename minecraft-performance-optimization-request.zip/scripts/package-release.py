from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
destination = root / "public/downloads/minecraft-optimized.zip"
destination.parent.mkdir(parents=True, exist_ok=True)
files = [root / name for name in ["README.md", "package.json", "package-lock.json", "tsconfig.json", "vite.config.ts", "index.html"]]
for directory in ["src", "scripts", "docs", "public"]:
    files.extend(p for p in (root / directory).rglob("*") if p.is_file() and "downloads" not in p.parts and "__pycache__" not in p.parts)
with ZipFile(destination, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for file in sorted(files):
        archive.write(file, file.relative_to(root))
print(f"Created {destination.relative_to(root)} ({destination.stat().st_size:,} bytes)")