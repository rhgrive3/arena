import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { ArrowDownToLine, ArrowLeft, ArrowRight, ArrowUpRight, Check, ChevronDown, CircleHelp, Expand, Feather, Globe2, HardDrive, Leaf, LoaderCircle, Monitor, Play, Plus, Settings2, ShieldCheck, Shuffle, Trash2, Upload, Volume2, VolumeX, X } from 'lucide-react';
import { loadSettings, saveSettings, loadWorlds, loadSave, saveWorld, deleteWorld, exportWorld } from './game/storage';
import type { GameMode, Settings, WorldMeta, WorldSave } from './game/types';
import { Dialog } from './launcher/Dialog';
import { Wordmark, GrassBlock } from './launcher/Brand';
import { LauncherSettings } from './launcher/LauncherSettings';

const Game = lazy(() => import('./GameApp'));
type View = 'worlds' | 'create' | 'settings' | 'guide' | 'updates' | 'about' | null;
const defaultWorld = (): WorldMeta => ({ id: crypto.randomUUID(), name: 'はじまりの森', seed: '849281', mode: 'creative', difficulty: 'normal', hardcore: false, structures: true, bonus: true, cheats: true, created: Date.now(), updated: Date.now(), playTime: 0 });

export default function App() {
  const [settings, setSettings] = useState(loadSettings);
  const [view, setView] = useState<View>(null);
  const [worlds, setWorlds] = useState(loadWorlds);
  const [session, setSession] = useState<{ meta: WorldMeta; save?: WorldSave } | null>(null);
  const [notice, setNotice] = useState('');
  const [deleteId, setDeleteId] = useState('');
  const [panorama, setPanorama] = useState(false);
  const [form, setForm] = useState({ name: '', seed: '', mode: 'creative' as GameMode, difficulty: 'normal' as WorldMeta['difficulty'] });
  const [guideTab, setGuideTab] = useState('keyboard');
  const importInput = useRef<HTMLInputElement>(null);
  const ja = settings.language === 'ja';
  const t = (j: string, e: string) => ja ? j : e;
  const updateSettings = (next: Settings) => { setSettings(next); if (!saveSettings(next)) setNotice(t('設定を保存できません。ブラウザの保存容量を確認してください。', 'Could not save settings. Please check browser storage.')); };
  const launch = (meta: WorldMeta, save?: WorldSave) => { setView(null); setSession({ meta, save }); };
  const open = (next: View) => { setPanorama(false); setView(next); if (next === 'worlds') setWorlds(loadWorlds()); };

  useEffect(() => { document.documentElement.lang = ja ? 'ja' : 'en'; }, [ja]);
  useEffect(() => { if (!notice) return; const timer = setTimeout(() => setNotice(''), 5000); return () => clearTimeout(timer); }, [notice]);
  useEffect(() => {
    const key = (event: KeyboardEvent) => { if (event.key === 'Escape') setPanorama(false); };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);

  const importSave = async (file?: File) => {
    if (!file) return;
    try {
      if (file.size > 15 * 1024 * 1024) throw new Error('File too large');
      const save = JSON.parse(await file.text()) as WorldSave;
      if (!save.meta || typeof save.meta.seed !== 'string' || typeof save.meta.name !== 'string' || !Array.isArray(save.edits) || !Array.isArray(save.inventory) || !Array.isArray(save.hotbar) || save.hotbar.length !== 9 || !Array.isArray(save.position) || save.position.length !== 3 || !save.position.every(Number.isFinite)) throw new Error('Invalid world');
      if (!['creative', 'survival', 'adventure', 'spectator'].includes(save.meta.mode) || !['overworld', 'nether', 'end'].includes(save.dimension)) throw new Error('Invalid mode');
      save.meta.id = crypto.randomUUID();
      save.meta.updated = Date.now();
      if (!saveWorld(save)) throw new Error('Storage full');
      setWorlds(loadWorlds());
      setNotice(t('ワールドを読み込みました。', 'World imported.'));
    } catch { setNotice(t('読み込めませんでした。対応するワールドJSONと保存容量を確認してください。', 'Import failed. Check the world JSON and available storage.')); }
    if (importInput.current) importInput.current.value = '';
  };

  if (session) return <Suspense fallback={<div className="game-boot"><GrassBlock/><span className="overline">A NEW ADVENTURE</span><h2>{t('冒険の準備をしています', 'Getting your adventure ready')}</h2><LoaderCircle className="spin" size={22}/></div>}><Game initialWorld={session.meta} initialSave={session.save} onExit={() => { setSession(null); setWorlds(loadWorlds()); setSettings(loadSettings()); }}/></Suspense>;

  return <main className={`launcher ${panorama ? 'panorama-mode' : ''}`}>
    <div className="landscape" aria-hidden="true"><img src="/images/overworld.jpg" alt="" fetchPriority="high"/><div className="landscape-shade"/></div>
    <header className="launcher-header">
      <button className="nav-brand" onClick={() => { setView(null); setPanorama(false); }} aria-label={t('ホーム', 'Home')}><GrassBlock small/><span>MINECRAFT<small>JAVA EDITION</small></span></button>
      <nav className="main-nav" aria-label={t('メインメニュー', 'Main menu')}>
        <button className={!view ? 'active' : ''} onClick={() => setView(null)}>{t('ホーム', 'Home')}</button>
        <button className={view === 'worlds' || view === 'create' ? 'active' : ''} onClick={() => open('worlds')}>{t('ワールド', 'Worlds')}</button>
        <button className={view === 'guide' ? 'active' : ''} onClick={() => open('guide')}>{t('遊び方', 'How to play')}</button>
        <button className={view === 'updates' ? 'active' : ''} onClick={() => open('updates')}>{t('更新情報', 'What\'s new')}<span className="nav-new-dot"/></button>
      </nav>
      <div className="header-actions"><button className="icon-button mobile-help" onClick={() => open('guide')} aria-label={t('遊び方', 'How to play')}><CircleHelp size={18}/></button><button className="header-language" onClick={() => updateSettings({ ...settings, language: ja ? 'en' : 'ja' })} aria-label={t('Switch to English', '日本語に切り替える')}><Globe2 size={16}/><span>{ja ? '日本語' : 'English'}</span><ChevronDown size={12}/></button><span className="header-divider"/><button className="icon-button" onClick={() => open('settings')} aria-label={t('設定', 'Settings')}><Settings2 size={19}/></button></div>
    </header>

    <section className="launcher-hero"><div className="hero-copy">
      <div className="hero-overline"><span/>LESS LAG. MORE ADVENTURE.</div>
      <h1><Wordmark/></h1>
      <h2>{t('いつもの世界を、', 'The world you love.')}<br/>{t('もっとなめらかに。', 'Smoother than ever.')}</h2>
      <p className="hero-description">{t('美しい景色も、つくる楽しさも、そのままに。', 'All the wonder. All the possibilities. A little less lag.')}<br/>{t('さあ、あなただけの冒険へ。', 'Your next adventure is waiting.')}</p>
      <div className="hero-buttons">
        <button className="launch-primary" onClick={() => open('worlds')}><Play size={18} fill="currentColor"/><span>{t('シングルプレイ', 'Singleplayer')}<small>LET'S PLAY</small></span><ArrowRight size={21}/></button>
        <button className="launch-secondary" onClick={() => open('settings')}><Settings2 size={17}/>{t('オプション', 'Options')}<span>{t('自分好みの遊び心地に', 'Make yourself at home')}</span></button>
      </div>
      <button className="optimization-link" onClick={() => open('settings')}><Leaf size={14}/>{settings.adaptiveResolution ? t('スマート最適化が有効です', 'Smart optimization is enabled') : t('カスタム描画設定が有効です', 'Custom graphics settings are enabled')}<ArrowUpRight size={12}/></button>
    </div></section>

    <div className="launcher-bottom">
      <div className="bottom-topline"><button className="release-link" onClick={() => open('updates')}><span className="release-icon"><Feather size={16}/></span><span><small>THE PERFORMANCE UPDATE</small><strong>{t('冒険はそのまま。動作は、もっと軽く。', 'Same adventure. A lighter footprint.')}</strong></span><ArrowUpRight size={16}/></button><div className="scene-actions"><button className="icon-button" aria-label={settings.muted ? t('サウンドをオン', 'Enable sound') : t('サウンドをオフ', 'Mute sound')} title={t('ゲーム内サウンド', 'In-game sound')} onClick={() => updateSettings({ ...settings, muted: !settings.muted })}>{settings.muted ? <VolumeX size={18}/> : <Volume2 size={18}/>}</button><button className="icon-button" onClick={() => setPanorama(true)} aria-label={t('背景を眺める', 'View panorama')}><Expand size={18}/></button><span className="scene-name">THE OVERWORLD<span>01 / 01</span></span></div></div>
      <footer className="launcher-footer"><span>Minecraft Java Edition<span className="footer-dot"/>Browser Build 26.3</span><button onClick={() => open('about')}>{t('非公式ファンプロジェクト', 'An unofficial fan project')}<ArrowUpRight size={11}/></button><button className="footer-help" onClick={() => open('guide')}><CircleHelp size={13}/>{t('ヘルプと操作方法', 'Help & controls')}</button></footer>
    </div>
    {panorama && <button className="panorama-back" onClick={() => setPanorama(false)}><ArrowLeft size={16}/>{t('メニューに戻る', 'Back to menu')}</button>}

    {view === 'settings' && <Dialog title={t('あなたにぴったりの設定', 'Make it your own')} eyebrow="OPTIONS" onClose={() => setView(null)} wide><LauncherSettings settings={settings} onChange={updateSettings}/></Dialog>}
    {view === 'worlds' && <Dialog title={t('次の冒険を、選ぼう。', 'Choose your next adventure.')} eyebrow="SINGLEPLAYER" onClose={() => setView(null)} wide>
      <div className="worlds-toolbar"><span><HardDrive size={14}/>{t('このブラウザに保存', 'Saved in this browser')}<b>{worlds.length}</b></span><button className="text-button" onClick={() => importInput.current?.click()}><Upload size={14}/>{t('読み込む', 'Import')}</button><input ref={importInput} type="file" accept=".json" hidden onChange={e => importSave(e.target.files?.[0])}/></div>
      <div className="dialog-body worlds-body">
        {!worlds.length && <><div className="recommended-world"><img src="/images/overworld.jpg" alt={t('緑豊かな川沿いの森', 'A lush forest beside a river')}/><div><span className="overline">YOUR FIRST CHAPTER</span><h3>{t('はじまりの森', 'Greenwood')}</h3><p>{t('川のせせらぎと、広がる緑。自由につくれる世界で、最初の一歩を。', 'A sunlit valley and a world of possibilities. Start your story in creative mode.')}</p><small>{t('クリエイティブ', 'Creative')}<span/>SEED 849281</small><button className="solid-button" onClick={() => launch({ ...defaultWorld(), name: t('はじまりの森', 'Greenwood') })}><Play size={15} fill="currentColor"/>{t('この世界で遊ぶ', 'Play this world')}<ArrowRight size={16}/></button></div></div><p className="worlds-note"><ShieldCheck size={14}/>{t('ワールドは端末内に保存されます。大切な世界は書き出してバックアップを。', 'Worlds are saved on this device. Export a backup of your favorite places.')}</p></>}
        {worlds.map(world => <div className="saved-world" key={world.id}><GrassBlock/><button className="saved-world-main" onClick={() => launch(world, loadSave(world.id))}><strong>{world.name}</strong><span>{world.mode === 'creative' ? t('クリエイティブ', 'Creative') : world.mode === 'survival' ? t('サバイバル', 'Survival') : world.mode}<i/>{new Date(world.updated).toLocaleDateString(ja ? 'ja-JP' : 'en-US')}</span><small>SEED {world.seed}</small></button>{deleteId === world.id ? <div className="world-delete-confirm"><span>{t('削除しますか？', 'Delete world?')}</span><button onClick={() => { deleteWorld(world.id); setWorlds(loadWorlds()); setDeleteId(''); }}>{t('削除', 'Delete')}</button><button onClick={() => setDeleteId('')}>{t('取消', 'Cancel')}</button></div> : <div className="saved-world-actions"><button className="icon-button" aria-label={`${world.name} ${t('を書き出す', 'export')}`} onClick={() => { const save = loadSave(world.id); if (save) exportWorld(save); else setNotice(t('保存データが見つかりません。', 'Save data not found.')); }}><ArrowDownToLine size={17}/></button><button className="icon-button" aria-label={`${world.name} ${t('を削除', 'delete')}`} onClick={() => setDeleteId(world.id)}><Trash2 size={16}/></button><button className="world-play" aria-label={`${world.name} ${t('で遊ぶ', 'play')}`} onClick={() => launch(world, loadSave(world.id))}><Play size={17} fill="currentColor"/></button></div>}</div>)}
      </div><footer className="dialog-footer"><button className="text-button" onClick={() => setView(null)}><ArrowLeft size={15}/>{t('戻る', 'Back')}</button><button className="solid-button" onClick={() => setView('create')}><Plus size={17}/>{t('新しいワールドをつくる', 'Create new world')}</button></footer>
    </Dialog>}

    {view === 'create' && <Dialog title={t('まだない世界を、つくろう。', 'A world that is yours.')} eyebrow="CREATE A WORLD" onClose={() => setView('worlds')} wide><form onSubmit={e => { e.preventDefault(); launch({ ...defaultWorld(), ...form, name: form.name.trim() || t('わたしの世界', 'My world'), seed: form.seed.trim() || String(Math.floor(Math.random() * 999999999)) }); }}><div className="dialog-body create-body"><label className="launcher-field">{t('ワールド名', 'World name')}<input value={form.name} maxLength={40} placeholder={t('わたしの世界', 'My world')} onChange={e => setForm({ ...form, name: e.target.value })}/></label><div className="mode-options">{([['creative', Leaf, t('クリエイティブ', 'Creative'), t('素材は無限。想像力のままに。', 'Unlimited blocks. Limitless imagination.')], ['survival', ShieldCheck, t('サバイバル', 'Survival'), t('集めて、つくって、生き延びる。', 'Gather, build and survive.')]] as const).map(([mode, Icon, title, desc]) => <button type="button" key={mode} className={form.mode === mode ? 'selected' : ''} onClick={() => setForm({ ...form, mode })}><Icon size={23}/><strong>{title}</strong><small>{desc}</small>{form.mode === mode && <Check size={15}/>}</button>)}</div><div className="form-columns"><label className="launcher-field">{t('シード値', 'World seed')}<div className="seed-field"><input value={form.seed} maxLength={64} placeholder={t('空欄でランダム', 'Random if empty')} onChange={e => setForm({ ...form, seed: e.target.value })}/><button type="button" aria-label={t('シードをランダム生成', 'Randomize seed')} onClick={() => setForm({ ...form, seed: String(Math.floor(Math.random() * 999999999)) })}><Shuffle size={17}/></button></div></label><label className="launcher-field">{t('難易度', 'Difficulty')}<select value={form.difficulty} onChange={e => setForm({ ...form, difficulty: e.target.value as WorldMeta['difficulty'] })}><option value="peaceful">{t('ピースフル', 'Peaceful')}</option><option value="easy">{t('イージー', 'Easy')}</option><option value="normal">{t('ノーマル', 'Normal')}</option><option value="hard">{t('ハード', 'Hard')}</option></select></label></div></div><footer className="dialog-footer"><button type="button" className="text-button" onClick={() => setView('worlds')}><ArrowLeft size={15}/>{t('戻る', 'Back')}</button><button className="solid-button" type="submit"><Play size={16} fill="currentColor"/>{t('世界を生成する', 'Create & play')}</button></footer></form></Dialog>}

    {view === 'guide' && <Dialog title={t('冒険は、最初の一歩から。', 'Every adventure starts somewhere.')} eyebrow="HOW TO PLAY" onClose={() => setView(null)} wide><nav className="dialog-tabs"><button className={guideTab === 'keyboard' ? 'selected' : ''} onClick={() => setGuideTab('keyboard')}><Monitor size={16}/>{t('キーボードとマウス', 'Keyboard & mouse')}</button><button className={guideTab === 'touch' ? 'selected' : ''} onClick={() => setGuideTab('touch')}>{t('タッチ操作', 'Touch controls')}</button></nav><div className="dialog-body"><p className="guide-intro">{guideTab === 'keyboard' ? t('ゲーム画面をクリックすると、マウスで周囲を見渡せます。', 'Click the game to look around with your mouse.') : t('オプションで「タッチ操作」をオンにすると、操作ボタンが表示されます。', 'Enable Touch controls in Options to display on-screen buttons.')}</p><div className="control-list">{(guideTab === 'keyboard' ? [['W A S D', t('移動する', 'Move')], ['SPACE', t('ジャンプ / 2回押して飛行', 'Jump / double-tap to fly')], ['L-CLICK', t('ブロックを壊す', 'Mine a block')], ['R-CLICK', t('ブロックを置く / 使う', 'Place a block / use')], ['E', t('インベントリを開く', 'Open inventory')], ['ESC', t('一時停止 / マウスを解放', 'Pause / release mouse')]] : [['LEFT', t('左スティックで移動', 'Use the left joystick to move')], ['SWIPE', t('右側をスワイプして視点を操作', 'Swipe on the right to look around')], ['JUMP', t('ジャンプボタンで段差を越える', 'Tap Jump to climb')], ['MINE', t('採掘ボタンを長押し', 'Hold Mine to break a block')], ['PLACE', t('設置ボタンでブロックを置く', 'Tap Place to build')], ['MENU', t('上部のボタンから持ちもの・設定へ', 'Use the top buttons for inventory and options')]]).map(([key, desc]) => <div key={key}><kbd>{key}</kbd><span>{desc}</span></div>)}</div><p className="settings-footnote">{t('クリエイティブでは自由な飛行と無限のブロックが使えます。30秒ごとに自動保存。F3で実際のFPSと描画情報を確認できます。', 'Creative mode includes free flight and unlimited blocks. Autosaves every 30 seconds. Press F3 for live FPS and render statistics.')}</p></div><footer className="dialog-footer"><span className="saved-label"><Leaf size={14}/>{t('自分のペースで、楽しもう。', 'Explore at your own pace.')}</span><button className="solid-button" onClick={() => open('worlds')}>{t('冒険をはじめる', 'Start exploring')}<ArrowRight size={16}/></button></footer></Dialog>}

    {view === 'updates' && <Dialog title={t('同じ世界を、もっと軽やかに。', 'The same world. A lighter touch.')} eyebrow="THE PERFORMANCE UPDATE" onClose={() => setView(null)} wide><div className="dialog-body update-body"><div className="update-heading"><Feather size={30}/><div><span>26.3 / OPTIMIZED BUILD</span><p>{t('見える美しさを守り、見えない無駄を減らす。', 'Keep what you see. Cut what you don\'t need.')}</p></div></div>{[[t('見えない地形は、必要なデータだけ。', 'Unseen terrain, only the data it needs.'), t('周辺のシミュレーション用チャンクでは描画メッシュをつくらず、表示範囲に入ったときに生成します。', 'Simulation-only chunks skip mesh generation until they enter your view distance.')], [t('一度に詰め込まず、少しずつ。', 'Less work all at once.'), t('描画データの取り込みに時間予算を設け、Workerへの依頼数も制御。急な処理の集中を抑えます。', 'Time-budgeted uploads and bounded worker queues reduce bursts of main-thread work.')], [t('画質の変化は、控えめに。', 'Quality changes, gently.'), t('継続した負荷を見て解像度を調整。CPU処理が重いときは、むやみに画質を下げません。', 'Resolution responds to sustained load with hysteresis, not isolated slow frames or CPU-heavy work.')], [t('冒険していない間は、おやすみ。', 'Taking a break means taking a break.'), t('タイトルでは3Dエンジンを起動しません。非表示タブの描画を止め、戻ったら時間差をリセットします。', 'No 3D engine runs on the title screen. Hidden tabs suspend rendering and safely reset frame timing on return.')]].map(([title, desc], i) => <article className="update-item" key={title}><span>0{i + 1}</span><div><h3>{title}</h3><p>{desc}</p></div></article>)}<p className="settings-footnote">{t('背景はタイトル用イメージです。実際の描画と性能は端末・ブラウザ・ワールドの状況により異なります。', 'The title background is illustrative. Actual graphics and performance depend on your device, browser and world.')}</p></div><footer className="dialog-footer"><span className="saved-label">{t('既存のワールド形式に対応', 'Existing world saves supported')}</span><button className="solid-button" onClick={() => open('settings')}><Settings2 size={15}/>{t('設定を確認する', 'Explore settings')}</button></footer></Dialog>}

    {view === 'about' && <Dialog title={t('ブロックの向こうに、まだ見ぬ世界。', 'More beyond the next block.')} eyebrow="ABOUT THIS PROJECT" onClose={() => setView(null)}><div className="dialog-body about-body"><GrassBlock/><p>{t('Minecraftを愛する人のための、非公式ブラウザファンプロジェクトです。Mojang StudiosおよびMicrosoftとは関係ありません。公式Java Editionそのものではありません。', 'An unofficial browser fan project for people who love Minecraft. Not affiliated with Mojang Studios or Microsoft, and not the official Java Edition.')}</p><p>{t('元のゲームの地形生成・クラフト・サバイバルを引き継ぎ、描画処理を改善しています。背景はタイトル用のイメージです。', 'Preserves the original project\'s terrain, crafting and survival systems with rendering improvements. The title panorama is illustrative.')}</p><a className="text-button external-link" href="https://github.com/rhgrive3/arena" target="_blank" rel="noreferrer">{t('元のプロジェクトを見る', 'View the original project')}<ArrowUpRight size={15}/></a><div className="about-download"><a className="solid-button" href="/downloads/minecraft-optimized.zip" download><ArrowDownToLine size={16}/>{t('最適化版ソースをダウンロード', 'Download optimized source')}<span>ZIP</span></a><small>{t('起動方法と検証結果を同梱しています。', 'Includes setup instructions and verification notes.')}</small></div></div></Dialog>}
    {notice && <div className="launcher-notice" role="status"><Check size={17}/><span>{notice}</span><button aria-label={t('通知を閉じる', 'Dismiss notice')} onClick={() => setNotice('')}><X size={15}/></button></div>}
  </main>;
}
