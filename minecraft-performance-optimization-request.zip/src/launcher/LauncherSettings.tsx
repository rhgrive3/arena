import { useState } from 'react';
import { Check, Feather, Monitor, Mouse, RotateCcw, Sparkles, Volume2 } from 'lucide-react';
import { DEFAULT_SETTINGS, type Settings } from '../game/types';

export function LauncherSettings({ settings, onChange }: { settings: Settings; onChange: (s: Settings) => void }) {
  const [tab, setTab] = useState('graphics');
  const ja = settings.language === 'ja';
  const t = (j: string, e: string) => ja ? j : e;
  const change = <K extends keyof Settings>(key: K, value: Settings[K]) => onChange({ ...settings, [key]: value });
  const preset = settings.adaptiveResolution ? 'auto' : settings.quality === 'low' ? 'light' : 'quality';
  const toggle = (key: 'adaptiveResolution' | 'bloom' | 'bobbing' | 'touch' | 'music' | 'muted' | 'invertY', label: string, hint?: string) => <div className="preference-row"><div><strong>{label}</strong>{hint && <small>{hint}</small>}</div><button type="button" className={`launcher-switch ${settings[key] ? 'on' : ''}`} role="switch" aria-checked={settings[key]} aria-label={label} onClick={() => change(key, !settings[key])}><span>{settings[key] && <Check size={11}/>}</span></button></div>;
  const range = (key: 'distance' | 'fov' | 'sensitivity' | 'volume', label: string, min: number, max: number, step: number, unit: string) => <label className="preference-row range-row"><div><strong>{label}</strong><small>{key === 'volume' ? Math.round(settings[key] * 100) : settings[key]} {unit}</small></div><input aria-label={label} type="range" min={min} max={max} step={step} value={settings[key]} onChange={e => change(key, Number(e.target.value))}/></label>;
  return <>
    <nav className="dialog-tabs">{([['graphics', Monitor, t('グラフィック', 'Graphics')], ['controls', Mouse, t('操作', 'Controls')], ['audio', Volume2, t('サウンド', 'Sound')]] as const).map(([key, Icon, label]) => <button key={key} className={tab === key ? 'selected' : ''} onClick={() => setTab(key)}><Icon size={16}/>{label}</button>)}</nav>
    <div className="dialog-body settings-body">
      {tab === 'graphics' && <>
        <p className="section-label">{t('あなたに合った、心地よさを。', 'Find your kind of smooth.')}</p>
        <div className="preset-options" role="radiogroup" aria-label={t('品質プリセット', 'Quality preset')}>
          {([['auto', Sparkles, t('自動', 'Adaptive'), t('おすすめ', 'Recommended')], ['quality', Monitor, t('画質優先', 'Beautiful'), t('ディテールを楽しむ', 'Every little detail')], ['light', Feather, t('軽量', 'Lightweight'), t('動作を軽く', 'Less GPU work')]] as const).map(([key, Icon, label, hint]) => <button role="radio" aria-checked={preset === key} key={key} className={preset === key ? 'selected' : ''} onClick={() => onChange({ ...settings, adaptiveResolution: key === 'auto', quality: key === 'light' ? 'low' : 'high', distance: key === 'light' ? 3 : 4 })}><Icon size={22}/><strong>{label}</strong><small>{hint}</small>{preset === key && <Check className="preset-check" size={15}/>}</button>)}
        </div>
        {range('distance', t('描画距離', 'Render distance'), 2, 9, 1, 'chunks')}
        {toggle('adaptiveResolution', t('スマート解像度', 'Smart resolution'), t('負荷が続くときだけ、80〜100%の範囲で調整', 'Adjusts between 80 and 100% during sustained load'))}
        {toggle('bloom', t('やわらかな光', 'Soft glow'), t('空と光の自然な表現', 'Gentle atmospheric lighting'))}
        <p className="settings-footnote">{t('地形・テクスチャ・ゲームの仕組みはそのまま。軽量モードではリアルタイムの影を省略します。すべての端末で60 FPSを保証するものではありません。', 'Terrain, textures and gameplay stay intact. Lightweight mode disables real-time shadows. 60 FPS is a target, not a guarantee on every device.')}</p>
      </>}
      {tab === 'controls' && <>{range('sensitivity', t('マウス感度', 'Mouse sensitivity'), 0.2, 3, 0.1, 'x')}{range('fov', t('視野角', 'Field of view'), 50, 100, 1, '°')}{toggle('invertY', t('上下反転', 'Invert vertical look'))}{toggle('bobbing', t('視点の揺れ', 'View bobbing'))}{toggle('touch', t('タッチ操作', 'Touch controls'), t('画面に移動・ジャンプ・採掘ボタンを表示', 'Show movement, jump and mining buttons'))}</>}
      {tab === 'audio' && <>{range('volume', t('マスター音量', 'Master volume'), 0, 1, 0.05, '%')}{toggle('music', t('ミュージック', 'Music'))}{toggle('muted', t('すべての音をミュート', 'Mute all audio'))}<p className="settings-footnote">{t('ゲーム内の環境音や足音は、ブラウザ内で生成されます。', 'In-game ambience and footsteps are synthesized in your browser.')}</p></>}
    </div>
    <footer className="dialog-footer"><button className="text-button" onClick={() => onChange({ ...DEFAULT_SETTINGS, language: settings.language })}><RotateCcw size={14}/>{t('初期設定に戻す', 'Reset defaults')}</button><span className="saved-label"><Check size={14}/>{t('自動で保存されます', 'Saved automatically')}</span></footer>
  </>;
}