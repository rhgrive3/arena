const glyphs: Record<string, string[]> = {
  M: ['10001','11011','11111','10101','10001','10001','10001'],
  I: ['111','111','111','111','111','111','111'],
  N: ['11001','11001','11101','10111','10011','10011','10011'],
  E: ['11111','11000','11000','11110','11000','11000','11111'],
  C: ['01111','11000','11000','11000','11000','11000','01111'],
  R: ['11110','11011','11011','11110','11100','11010','11011'],
  A: ['01110','11011','11011','11111','11011','11011','11011'],
  F: ['11111','11000','11000','11110','11000','11000','11000'],
  T: ['11111','11111','00100','00100','00100','00100','00100'],
};
let offset = 5;
const wordPath = [...'MINECRAFT'].map(letter => {
  const rows = glyphs[letter];
  const path = rows.flatMap((row, y) => [...row].map((pixel, x) => pixel === '1' ? `M${offset + x * 10},${5 + y * 10}h10v10h-10z` : '')).join('');
  offset += (rows[0].length + 1) * 10;
  return path;
}).join('');

export function Wordmark() {
  return <div className="launcher-wordmark" aria-label="Minecraft Java Edition">
    <svg viewBox="0 0 530 96" role="img" aria-label="Minecraft">
      <defs><linearGradient id="stone-face" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#fffef5"/><stop offset=".45" stopColor="#deded3"/><stop offset="1" stopColor="#aeb4a8"/></linearGradient></defs>
      <path d={wordPath} transform="translate(3 12)" fill="#292d27" stroke="#111a12" strokeWidth="7"/>
      <path d={wordPath} transform="translate(1 5)" fill="#777d6e" stroke="#192017" strokeWidth="6"/>
      <path d={wordPath} fill="url(#stone-face)"/>
    </svg><span>JAVA EDITION</span>
  </div>;
}

export function GrassBlock({ small = false }: { small?: boolean }) {
  return <svg className={`grass-block ${small ? 'small' : ''}`} viewBox="0 0 48 52" fill="none" aria-hidden="true">
    <path d="M24 2 46 13 24 25 2 13Z" fill="#a5cc69"/><path d="M2 13 24 25V50L2 37Z" fill="#8c6847"/><path d="M24 25 46 13V37L24 50Z" fill="#634a34"/>
    <path d="M2 13 24 25V33L18 30V33L12 29V25L7 23V25L2 22Z" fill="#6f9d48"/><path d="M24 25 46 13V22L41 25V23L35 27V32L30 35V31L24 34Z" fill="#567d37"/>
    <path d="m10 11 7-3 7 3-7 4ZM26 9l7 4-7 4-7-4Z" fill="#92b95a"/><path d="m5 30 5 3v4l-5-3ZM14 35l5 3v5l-5-3Z" fill="#a17b53"/><path d="m28 39 5-3v4l-5 3ZM37 29l5-3v5l-5 3Z" fill="#7d5e40"/>
  </svg>;
}