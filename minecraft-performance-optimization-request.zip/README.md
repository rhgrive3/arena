# Minecraft Browser Build: Performance Update

元プロジェクトを引き継いだ、非公式のブラウザ向けファンプロジェクトです。
公式 Minecraft Java Edition 本体ではなく、Mojang Studios / Microsoft とは関係ありません。

## 起動

Node.js 20.19 以降を使用してください。

1. `npm install`
2. `npm run dev`
3. ターミナルに表示された localhost の URL を開く

`npm run build` で本番用ファイルを `dist/` に生成できます。
`npm run preview -- --host 0.0.0.0` で本番ビルドを確認できます。
画像とフォントも含めた `dist/` 全体を HTTP サーバーで配信してください。

## 遊び方

- シングルプレイから既存ワールドを選択、または新規作成できます。
- WASD: 移動、Space: ジャンプ、クリエイティブでは Space 2回: 飛行。
- 左クリック: 採掘、右クリック: 設置、E: インベントリ、Esc: 一時停止。
- F3: 実際の FPS / チャンク数 / 描画回数を表示します。
- タッチ操作はオプションの操作タブで有効にできます。
- ワールドはブラウザ内に保存されます。ワールド一覧から JSON を書き出してバックアップしてください。

## 品質設定

- 自動: 画質を優先し、負荷が続くときに描画解像度を80〜100%の範囲で調整します。
- 画質優先: 解像度の自動調整を行いません。
- 軽量: 描画距離を短くし、リアルタイムの影を無効にします。

UI の解像度とテクスチャ内容は自動調整で変更しません。
背景はタイトル用イメージで、プレイ中の画面とは異なります。
実際の FPS は端末・ブラウザ・ワールドの状態に依存します。
全端末での60 FPS、画質の完全な不変、デメリットの完全な解消を保証するものではありません。

## テスト

- `npx tsx scripts/test-optimization.ts`: 今回追加した最適化の13項目。
- `bash scripts/run-tests.sh`: 既存の21スイート。
- `sha256sum -c docs/world-generation.sha256`: 元の地形生成関連14ファイルの保全確認。
- `npx playwright install --with-deps chromium`: ブラウザテスト環境を準備。
- 開発サーバー起動後 `node scripts/browser-launcher.mjs`: UI、保存、起動、復帰、レスポンシブ表示。
- 開発サーバー起動後 `node scripts/browser-performance.mjs`: 周辺チャンク昇格、非表示停止、GPU解放。

ブラウザテストの接続先は `TEST_URL` 環境変数で変更できます。
時間制限のある性能テストはブラウザテストと同時実行せず、単独で実行してください。

## 現状の制限

既存のゲーム動作を保持するため、今回の変更は描画・キュー制御・ライフサイクルと起動画面を中心にしています。
元 ZIP にも存在する49件の TypeScript 診断は未解消です。`npx tsc --noEmit` は通りません。
Vite の本番ビルド、既存テスト、および追加テストの通過は型チェックの通過を意味しません。
低性能の実機、長時間プレイ、すべてのブラウザや既存セーブの組み合わせは未検証です。

変更内容と検証結果は `docs/OPTIMIZATION.md` にまとめています。

## 出典

元プロジェクト: https://github.com/rhgrive3/arena

フォント: Noto Sans JP (SIL Open Font License)。ライセンスは `public/fonts/OFL.txt`。
タイトル背景はこの更新用の生成画像です。