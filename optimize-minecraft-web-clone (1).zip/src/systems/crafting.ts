import { DYES } from '../game/content';

export interface Recipe {
  id: string;
  result: string;
  count: number;
  ingredients: Record<string, number>;
  grid: (string | null)[][];
  station: 'inventory' | 'crafting_table';
  category: string;
}

export const RECIPES: Recipe[] = [];

function recipe(
  id: string,
  result: string,
  count: number,
  rows: string[],
  key: Record<string, string>,
  station: 'inventory' | 'crafting_table' = 'inventory',
  category = 'building',
) {
  const ingredients: Record<string, number> = {};
  const grid = rows.map(r =>
    [...r].map(c => {
      if (c === ' ') return null;
      const name = key[c];
      if (!name) throw new Error('Unknown recipe key ' + c);
      ingredients[name] = (ingredients[name] || 0) + 1;
      return name;
    }),
  );
  RECIPES.push({ id, result, count, ingredients, grid, station, category });
}

recipe('oak_planks', 'oak_planks', 4, ['L'], { L: 'oak_log' });
recipe('birch_planks', 'birch_planks', 4, ['L'], { L: 'birch_log' });
for (const wood of ['spruce', 'jungle', 'acacia', 'dark_oak', 'cherry', 'mangrove', 'pale_oak', 'crimson', 'warped', 'poplar']) {
  recipe(wood + '_planks', wood + '_planks', 4, ['L'], { L: wood + '_log' });
}

recipe('stick', 'stick', 4, ['P', 'P'], { P: 'oak_planks' });
recipe('crafting_table', 'crafting_table', 1, ['PP', 'PP'], { P: 'oak_planks' }, 'inventory', 'utility');
recipe('furnace', 'furnace', 1, ['CCC', 'C C', 'CCC'], { C: 'cobblestone' }, 'crafting_table', 'utility');
recipe('chest', 'chest', 1, ['PPP', 'P P', 'PPP'], { P: 'oak_planks' }, 'crafting_table', 'utility');
recipe('barrel', 'barrel', 1, ['PSP', 'P P', 'PSP'], { P: 'oak_planks', S: 'oak_slab' }, 'crafting_table', 'utility');
recipe('bed', 'bed', 1, ['WWW', 'PPP'], { W: 'white_wool', P: 'oak_planks' }, 'crafting_table', 'utility');
recipe('torch', 'torch', 4, ['C', 'S'], { C: 'coal', S: 'stick' }, 'inventory', 'utility');
recipe('torch_charcoal', 'torch', 4, ['C', 'S'], { C: 'charcoal', S: 'stick' }, 'inventory', 'utility');
recipe('lantern', 'lantern', 1, ['III', 'ITI', 'III'], { I: 'iron_ingot', T: 'torch' }, 'crafting_table', 'utility');
recipe('ladder', 'ladder', 3, ['S S', 'SSS', 'S S'], { S: 'stick' }, 'crafting_table', 'utility');
recipe('oak_door', 'oak_door', 3, ['PP', 'PP', 'PP'], { P: 'oak_planks' }, 'crafting_table', 'building');
recipe('stone_bricks', 'stone_bricks', 4, ['SS', 'SS'], { S: 'stone' });
recipe('sandstone', 'sandstone', 1, ['SS', 'SS'], { S: 'sand' });
recipe('cut_sandstone', 'cut_sandstone', 4, ['SS', 'SS'], { S: 'sandstone' });
recipe('end_stone_bricks', 'end_stone_bricks', 4, ['EE', 'EE'], { E: 'end_stone' });
recipe('purpur_block', 'purpur_block', 4, ['CC', 'CC'], { C: 'popped_chorus_fruit' });
recipe('end_rod', 'end_rod', 4, ['B', 'C'], { B: 'blaze_rod', C: 'popped_chorus_fruit' }, 'inventory', 'utility');
recipe('glass_pane', 'glass_pane', 16, ['GGG', 'GGG'], { G: 'glass' }, 'crafting_table');
recipe('iron_bars', 'iron_bars', 16, ['III', 'III'], { I: 'iron_ingot' }, 'crafting_table');
recipe('bookshelf', 'bookshelf', 1, ['PPP', 'BBB', 'PPP'], { P: 'oak_planks', B: 'book' }, 'crafting_table', 'utility');
recipe('enchanting_table', 'enchanting_table', 1, [' B ', 'DOD', 'OOO'], { B: 'book', D: 'diamond', O: 'obsidian' }, 'crafting_table', 'utility');
recipe('anvil', 'anvil', 1, ['III', ' I ', 'III'], { I: 'iron_ingot' }, 'crafting_table', 'utility');
recipe('paper', 'paper', 3, ['SSS'], { S: 'sugar_cane' }, 'crafting_table', 'materials');
recipe('book', 'book', 1, ['PP', 'PL'], { P: 'paper', L: 'leather' }, 'inventory', 'materials');
recipe('bread', 'bread', 1, ['WWW'], { W: 'wheat' }, 'crafting_table', 'food');
recipe('golden_apple', 'golden_apple', 1, ['GGG', 'GAG', 'GGG'], { G: 'gold_ingot', A: 'apple' }, 'crafting_table', 'food');
recipe('cookie', 'cookie', 8, ['WCW'], { W: 'wheat', C: 'coal' }, 'crafting_table', 'food');

// Tools, weapons, utility gear & Progression to Nether / The End / End City
recipe('flint_and_steel', 'flint_and_steel', 1, ['I ', ' F'], { I: 'iron_ingot', F: 'flint' }, 'inventory', 'tools');
recipe('bucket', 'bucket', 1, ['I I', ' I '], { I: 'iron_ingot' }, 'crafting_table', 'tools');
recipe('shears', 'shears', 1, [' I', 'I '], { I: 'iron_ingot' }, 'inventory', 'tools');
recipe('bow', 'bow', 1, [' ST', 'S T', ' ST'], { S: 'stick', T: 'string' }, 'crafting_table', 'tools');
recipe('arrow', 'arrow', 4, ['F', 'S', 'E'], { F: 'flint', S: 'stick', E: 'feather' }, 'crafting_table', 'tools');
recipe('compass', 'compass', 1, [' I ', 'IRI', ' I '], { I: 'iron_ingot', R: 'redstone' }, 'crafting_table', 'tools');
recipe('clock', 'clock', 1, [' G ', 'GRG', ' G '], { G: 'gold_ingot', R: 'redstone' }, 'crafting_table', 'tools');
recipe('blaze_powder', 'blaze_powder', 2, ['B'], { B: 'blaze_rod' }, 'inventory', 'materials');
recipe('ender_eye', 'ender_eye', 1, ['PB'], { P: 'ender_pearl', B: 'blaze_powder' }, 'inventory', 'tools');
recipe('end_crystal', 'end_crystal', 1, ['GGG', 'GEG', 'GTG'], { G: 'glass', E: 'ender_eye', T: 'ghast_tear' }, 'crafting_table', 'tools');
recipe('shulker_box', 'shulker_box', 1, ['S', 'C', 'S'], { S: 'shulker_shell', C: 'chest' }, 'crafting_table', 'utility');
recipe('firework_rocket', 'firework_rocket', 3, ['P', 'G'], { P: 'paper', G: 'gunpowder' }, 'inventory', 'tools');
recipe('netherite_ingot', 'netherite_ingot', 1, ['SSS', 'SGG', 'GG '], { S: 'netherite_scrap', G: 'gold_ingot' }, 'crafting_table', 'materials');

// Redstone
recipe('lever', 'lever', 1, ['S', 'C'], { S: 'stick', C: 'cobblestone' }, 'inventory', 'redstone');
recipe('tnt', 'tnt', 1, ['GSG', 'SGS', 'GSG'], { G: 'gunpowder', S: 'sand' }, 'crafting_table', 'redstone');
recipe('redstone_lamp', 'redstone_lamp', 1, [' R ', 'RGR', ' R '], { R: 'redstone', G: 'glowstone' }, 'crafting_table', 'redstone');
recipe('piston', 'piston', 1, ['PPP', 'CIC', 'CRC'], { P: 'oak_planks', C: 'cobblestone', I: 'iron_ingot', R: 'redstone' }, 'crafting_table', 'redstone');
recipe('sticky_piston', 'sticky_piston', 1, ['S', 'P'], { S: 'slime_ball', P: 'piston' }, 'inventory', 'redstone');
recipe('note_block', 'note_block', 1, ['PPP', 'PRP', 'PPP'], { P: 'oak_planks', R: 'redstone' }, 'crafting_table', 'redstone');

for (const wood of ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak', 'cherry']) {
  const material = wood + '_planks';
  recipe(wood + '_slab', wood + '_slab', 6, ['MMM'], { M: material }, 'crafting_table');
  recipe(wood + '_stairs', wood + '_stairs', 4, ['M  ', 'MM ', 'MMM'], { M: material }, 'crafting_table');
}
for (const color of Object.keys(DYES)) {
  for (const material of ['wool', 'concrete']) {
    const base = color + '_' + material;
    recipe(base + '_slab', base + '_slab', 6, ['MMM'], { M: base }, 'crafting_table');
    recipe(base + '_stairs', base + '_stairs', 4, ['M  ', 'MM ', 'MMM'], { M: base }, 'crafting_table');
  }
}

const tiers: Record<string, string> = {
  wooden: 'oak_planks',
  stone: 'cobblestone',
  iron: 'iron_ingot',
  golden: 'gold_ingot',
  diamond: 'diamond',
};

for (const [tier, mat] of Object.entries(tiers)) {
  const k = { M: mat, S: 'stick' };
  recipe(tier + '_pickaxe', tier + '_pickaxe', 1, ['MMM', ' S ', ' S '], k, 'crafting_table', 'tools');
  recipe(tier + '_axe', tier + '_axe', 1, ['MM', 'MS', ' S'], k, 'crafting_table', 'tools');
  recipe(tier + '_shovel', tier + '_shovel', 1, ['M', 'S', 'S'], k, 'crafting_table', 'tools');
  recipe(tier + '_sword', tier + '_sword', 1, ['M', 'M', 'S'], k, 'crafting_table', 'tools');
  recipe(tier + '_hoe', tier + '_hoe', 1, ['MM', ' S', ' S'], k, 'crafting_table', 'tools');
}

for (const [tier, mat] of Object.entries({ iron: 'iron_ingot', golden: 'gold_ingot', diamond: 'diamond' })) {
  const k = { M: mat };
  recipe(tier + '_helmet', tier + '_helmet', 1, ['MMM', 'M M'], k, 'crafting_table', 'tools');
  recipe(tier + '_chestplate', tier + '_chestplate', 1, ['M M', 'MMM', 'MMM'], k, 'crafting_table', 'tools');
  recipe(tier + '_leggings', tier + '_leggings', 1, ['MMM', 'M M', 'M M'], k, 'crafting_table', 'tools');
  recipe(tier + '_boots', tier + '_boots', 1, ['M M', 'M M'], k, 'crafting_table', 'tools');
}

for (const type of ['pickaxe', 'axe', 'shovel', 'sword', 'helmet', 'chestplate', 'leggings', 'boots']) {
  recipe('netherite_' + type, 'netherite_' + type, 1, ['DN'], { D: 'diamond_' + type, N: 'netherite_ingot' }, 'crafting_table', 'tools');
}

export const SMELTING: Record<string, { result: string; time: number }> = {
  iron_ore: { result: 'iron_ingot', time: 8 },
  deepslate_iron_ore: { result: 'iron_ingot', time: 8 },
  raw_iron: { result: 'iron_ingot', time: 8 },
  gold_ore: { result: 'gold_ingot', time: 8 },
  deepslate_gold_ore: { result: 'gold_ingot', time: 8 },
  nether_gold_ore: { result: 'gold_ingot', time: 8 },
  raw_gold: { result: 'gold_ingot', time: 8 },
  ancient_debris: { result: 'netherite_scrap', time: 12 },
  sand: { result: 'glass', time: 8 },
  red_sand: { result: 'glass', time: 8 },
  cobblestone: { result: 'stone', time: 8 },
  netherrack: { result: 'nether_bricks', time: 8 },
  chorus_fruit: { result: 'popped_chorus_fruit', time: 8 },
  raw_beef: { result: 'cooked_beef', time: 7 },
  porkchop: { result: 'cooked_porkchop', time: 7 },
  mutton: { result: 'cooked_mutton', time: 7 },
  potato: { result: 'baked_potato', time: 7 },
  cod: { result: 'cooked_cod', time: 7 },
  salmon: { result: 'cooked_salmon', time: 7 },
  oak_log: { result: 'charcoal', time: 8 },
  birch_log: { result: 'charcoal', time: 8 },
  spruce_log: { result: 'charcoal', time: 8 },
  cherry_log: { result: 'charcoal', time: 8 },
};

export const FUEL: Record<string, number> = {
  coal: 80,
  charcoal: 80,
  blaze_rod: 120,
  lava_bucket: 1000,
  oak_planks: 15,
  birch_planks: 15,
  spruce_planks: 15,
  oak_log: 15,
  birch_log: 15,
  spruce_log: 15,
  stick: 5,
  crafting_table: 15,
  chest: 15,
};

export function recipeCounts(stacks: ( { name: string; count: number } | null )[]) {
  const counts: Record<string, number> = {};
  for (const s of stacks) if (s) counts[s.name] = (counts[s.name] || 0) + s.count;
  return counts;
}

export function canCraft(recipe: Recipe, counts: Record<string, number>, creative: boolean, workbench: boolean) {
  if (!workbench && recipe.station === 'crafting_table' && !creative) return false;
  if (creative) return true;
  return Object.entries(recipe.ingredients).every(([name, need]) => (counts[name] || 0) >= need);
}
