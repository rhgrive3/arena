# 対象バージョン

- Minecraft Java Edition **26.3**
- 正式リリース: 2026-09-15T11:23:02+00:00
- 確定根拠: Mojang公式 version_manifest_v2.json の latest.release
- メタデータ: https://piston-meta.mojang.com/v1/packages/80608ff6753705b6a82e2cb86a5937d4d233abd4/26.3.json
- Data version: 公式メタデータに未記載
- コンテンツ根拠: 同じ正式版のサーバーを --reports で実行した blocks/items/registries
- ブロック 1286 / アイテム 1658 / 対象モブ 132 / バイオーム 67
- スナップショットは対象としない。minecraft-data の旧版を最新仕様とは見なさない。
- 26.3 Wilderness Bound は2026-09-15公開。Poplar、Dappled Forest、Abandoned Camp、羊毛/コンクリートの階段・ハーフ、Cushion、Straw Bedを含む。
- 外部公式データは仕様調査とID突合のみ。ゲーム素材は独自生成。

## 情報源
- https://piston-meta.mojang.com/mc/game/version_manifest_v2.json
- https://minecraft.wiki/w/Java_Edition_26.3
- https://minecraft.wiki/w/Breaking
- https://www.minecraft.net/en-us/article/minecraft-java-edition-26-3 (検索で確認。本文直接取得はエラー)
- https://minecraft.fandom.com/wiki/Crafting (直接取得エラー。採用仕様とは区別)

## 既知の調査限界
全仕様を旧版から無条件採用しない。未確認の条件・例外はVERIFICATION.mdに差異として残す。
