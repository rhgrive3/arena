import { DYES } from '../game/content';
export interface Recipe { id:string; result:string; count:number; ingredients:Record<string,number>; grid:(string|null)[][]; station:'inventory'|'crafting_table'; category:string; }
export const RECIPES:Recipe[]=[];
function recipe(id:string,result:string,count:number,rows:string[],key:Record<string,string>,station:'inventory'|'crafting_table'='inventory',category='building'){
  const ingredients:Record<string,number>={};const grid=rows.map(r=>[...r].map(c=>{if(c===' ')return null;const name=key[c];if(!name)throw new Error('Unknown recipe key '+c);ingredients[name]=(ingredients[name]||0)+1;return name;}));
  RECIPES.push({id,result,count,ingredients,grid,station,category});
}
recipe('oak_planks','oak_planks',4,['L'],{L:'oak_log'});
recipe('birch_planks','birch_planks',4,['L'],{L:'birch_log'});
recipe('stick','stick',4,['P','P'],{P:'oak_planks'});
recipe('crafting_table','crafting_table',1,['PP','PP'],{P:'oak_planks'});
recipe('furnace','furnace',1,['CCC','C C','CCC'],{C:'cobblestone'},'crafting_table','utility');
recipe('chest','chest',1,['PPP','P P','PPP'],{P:'oak_planks'},'crafting_table','utility');
recipe('torch','torch',4,['C','S'],{C:'coal',S:'stick'},'inventory','utility');
recipe('stone_bricks','stone_bricks',4,['SS','SS'],{S:'stone'});
recipe('bread','bread',1,['WWW'],{W:'wheat'},'crafting_table','food');
for(const wood of ['spruce','jungle','acacia','dark_oak','cherry','mangrove','pale_oak','poplar']){
  recipe(wood+'_planks',wood+'_planks',4,['L'],{L:wood+'_log'});
}
for(const wood of ['oak','spruce','birch','jungle','acacia','dark_oak','cherry']){
  const material=wood+'_planks';
  recipe(wood+'_slab',wood+'_slab',6,['MMM'],{M:material},'crafting_table');
  recipe(wood+'_stairs',wood+'_stairs',4,['M  ','MM ','MMM'],{M:material},'crafting_table');
}
for(const color of Object.keys(DYES))for(const material of ['wool','concrete']){
  const base=color+'_'+material;
  recipe(base+'_slab',base+'_slab',6,['MMM'],{M:base},'crafting_table');
  recipe(base+'_stairs',base+'_stairs',4,['M  ','MM ','MMM'],{M:base},'crafting_table');
}
const tiers:Record<string,string>={wooden:'oak_planks',stone:'cobblestone',iron:'iron_ingot',diamond:'diamond'};
for(const [tier,mat] of Object.entries(tiers)){
  const k={M:mat,S:'stick'};
  recipe(tier+'_pickaxe',tier+'_pickaxe',1,['MMM',' S ',' S '],k,'crafting_table','tools');
  recipe(tier+'_axe',tier+'_axe',1,['MM','MS',' S'],k,'crafting_table','tools');
  recipe(tier+'_shovel',tier+'_shovel',1,['M','S','S'],k,'crafting_table','tools');
  recipe(tier+'_sword',tier+'_sword',1,['M','M','S'],k,'crafting_table','tools');
  recipe(tier+'_hoe',tier+'_hoe',1,['MM',' S',' S'],k,'crafting_table','tools');
}
export const SMELTING:Record<string,{result:string;time:number}>={iron_ore:{result:'iron_ingot',time:10},raw_iron:{result:'iron_ingot',time:10},gold_ore:{result:'gold_ingot',time:10},raw_gold:{result:'gold_ingot',time:10},sand:{result:'glass',time:10},cobblestone:{result:'stone',time:10},raw_beef:{result:'cooked_beef',time:10},porkchop:{result:'cooked_porkchop',time:10},oak_log:{result:'coal',time:10},birch_log:{result:'coal',time:10}};
export const FUEL:Record<string,number>={coal:80,oak_planks:15,oak_log:15,birch_log:15,stick:5,crafting_table:15,chest:15};
export function canCraft(r:Recipe,counts:Record<string,number>,creative:boolean,table:boolean){return (r.station==='inventory'||table||creative)&&(creative||Object.entries(r.ingredients).every(([n,c])=>(counts[n]||0)>=c));}
export function recipeCounts(stacks:({name:string;count:number}|null)[]){const c:Record<string,number>={};for(const s of stacks)if(s)c[s.name]=(c[s.name]||0)+s.count;return c;}
