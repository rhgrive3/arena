import { ID } from '../game/data';
import type { Vector3 } from 'three';
interface Node{x:number;y:number;z:number;id:number;level:number;}
export class Simulation {
  queue:Node[]=[];queued=new Set<string>();tnt=new Map<string,number>();ticks=0;
  constructor(public host:{getBlock(x:number,y:number,z:number):number;setBlock(x:number,y:number,z:number,id:number):boolean;explode(p:Vector3,r:number):void;toast(j:string,e:string):void;sound(k:string,p?:any):void;}){}
  enqueue(x:number,y:number,z:number,id:number,level=0){const key=x+','+y+','+z;if(this.queued.has(key)||this.queue.length>6000)return;this.queued.add(key);this.queue.push({x,y,z,id,level});}
  notify(x:number,y:number,z:number,id:number){if([ID.water,ID.lava,ID.sand,ID.gravel,ID.tnt,ID.redstone_wire,ID.lever,ID.piston,ID.sticky_piston,ID.redstone_lamp,ID.unlit_redstone_lamp].includes(id))this.enqueue(x,y,z,id);for(const [dx,dy,dz] of [[0,1,0],[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1]]){const n=this.host.getBlock(x+dx,y+dy,z+dz);if(n===ID.sand||n===ID.gravel||n===ID.water||n===ID.lava)this.enqueue(x+dx,y+dy,z+dz,n);}}
  toggleLever(x:number,y:number,z:number){const seen=new Set<string>(),queue:[number,number,number,number][]=[[x,y,z,15]];let lamps=0,pistons=0;for(let i=0;i<queue.length&&i<600;i++){const [a,b,c,p]=queue[i],key=a+','+b+','+c;if(seen.has(key)||p<=0)continue;seen.add(key);for(const [dx,dy,dz] of [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){const nx=a+dx,ny=b+dy,nz=c+dz,id=this.host.getBlock(nx,ny,nz);if(id===ID.redstone_wire)queue.push([nx,ny,nz,p-1]);if(id===ID.unlit_redstone_lamp||id===ID.redstone_lamp){this.host.setBlock(nx,ny,nz,ID.redstone_lamp);lamps++;}if(id===ID.piston||id===ID.sticky_piston){this.push(nx,ny,nz,dx,dy,dz);pistons++;}if(id===ID.oak_door)this.host.setBlock(nx,ny,nz,ID.open_oak_door);else if(id===ID.open_oak_door)this.host.setBlock(nx,ny,nz,ID.oak_door);}}
    this.host.toast(`信号 15 → ${lamps} ランプ / ${pistons} ピストン`,`Signal 15 → ${lamps} lamps / ${pistons} pistons`);this.host.sound('stone',{x,y,z});}
  push(x:number,y:number,z:number,dx:number,dy:number,dz:number){const bx=x+dx,by=y+dy,bz=z+dz,id=this.host.getBlock(bx,by,bz);if(id>0&&id!==ID.bedrock&&this.host.getBlock(bx+dx,by+dy,bz+dz)===0){this.host.setBlock(bx+dx,by+dy,bz+dz,id);this.host.setBlock(bx,by,bz,0);}}
  update(dt:number,vector:(x:number,y:number,z:number)=>Vector3){this.ticks++;const budget=48,start=performance.now();let processed=0;while(this.queue.length&&processed++<budget&&performance.now()-start<2){const n=this.queue.shift()!;this.queued.delete(n.x+','+n.y+','+n.z);const current=this.host.getBlock(n.x,n.y,n.z);if(current!==n.id)continue;
      if(n.id===ID.sand||n.id===ID.gravel){if(this.host.getBlock(n.x,n.y-1,n.z)===0){this.host.setBlock(n.x,n.y-1,n.z,n.id);this.host.setBlock(n.x,n.y,n.z,0);}continue;}
      if(n.id===ID.tnt){const key=n.x+','+n.y+','+n.z;if(!this.tnt.has(key)){this.tnt.set(key,4);this.host.sound('grass',n);}continue;}
      if(n.id===ID.water||n.id===ID.lava){if(n.id===ID.lava&&this.ticks%4)continue;const below=this.host.getBlock(n.x,n.y-1,n.z);if(below===0){this.host.setBlock(n.x,n.y-1,n.z,n.id);this.enqueue(n.x,n.y-1,n.z,n.id,n.level);continue;}if(n.level>=(n.id===ID.water?7:3))continue;for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=n.x+dx,nz=n.z+dz,other=this.host.getBlock(nx,n.y,nz);if(other===0){this.host.setBlock(nx,n.y,nz,n.id);this.enqueue(nx,n.y,nz,n.id,n.level+1);}else if((other===ID.water&&n.id===ID.lava)||(other===ID.lava&&n.id===ID.water))this.host.setBlock(nx,n.y,nz,ID.obsidian);}}
    }
    for(const [key,time] of this.tnt){const t=time-dt;if(t<=0){this.tnt.delete(key);const [x,y,z]=key.split(',').map(Number);if(this.host.getBlock(x,y,z)===ID.tnt)this.host.explode(vector(x+.5,y+.5,z+.5),4);}else this.tnt.set(key,t);}
  }
  clear(){this.queue=[];this.queued.clear();this.tnt.clear();}
}
