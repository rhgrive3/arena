import type { BlockDef } from '../game/data';
import { isSlabBlock } from '../game/blockState';

const MATERIALS:Record<string,{speed:number;level:number}>={
  wooden:{speed:2,level:1},golden:{speed:12,level:1},stone:{speed:4,level:2},
  copper:{speed:5,level:2},iron:{speed:6,level:3},diamond:{speed:8,level:4},netherite:{speed:9,level:5},
};

function material(tool?:BlockDef){return tool?MATERIALS[tool.name.split('_')[0]]:undefined;}
function requiredLevel(block:BlockDef):number{
  if(block.name.includes('obsidian')||block.name==='ancient_debris')return 4;
  if(/(?:diamond|emerald|gold|redstone)_ore$/.test(block.name))return 3;
  if(/(?:iron|copper|lapis)_ore$/.test(block.name))return 2;
  return block.tool==='pickaxe'?(block.tier??1):0;
}

export function canHarvest(block:BlockDef,tool?:BlockDef):boolean{
  if(block.name==='snow_block')return tool?.tool==='shovel';
  const level=requiredLevel(block);
  return level===0||(tool?.tool==='pickaxe'&&(material(tool)?.level??0)>=level);
}

export function miningTime(block:BlockDef,tool:BlockDef|undefined,onGround=true,underwater=false):number{
  if(!Number.isFinite(block.hardness))return Infinity;
  if(block.hardness<=0)return 0;
  let speed=block.tool&&tool?.tool===block.tool?(material(tool)?.speed??1):1;
  if(tool?.name==='shears'&&block.pattern==='leaves')speed=15;
  else if(tool?.name==='shears'&&block.pattern==='wool')speed=5;
  if(!onGround)speed/=5;
  if(underwater)speed/=5;
  const ticks=Math.ceil(block.hardness*(canHarvest(block,tool)?30:100)/speed-1e-9);
  return ticks<=1?0:ticks/20;
}

export function blockDrops(block:BlockDef,tool:BlockDef|undefined,state=0,rng=Math.random):{name:string;count:number}[]{
  if(!canHarvest(block,tool))return [];
  if(block.name==='glass'||block.name==='glass_pane'||block.name.endsWith('_stained_glass')||block.name.endsWith('_stained_glass_pane'))return [];
  if(block.name==='snow_block')return [{name:'snowball',count:4}];
  if(block.pattern==='leaves'){
    if(tool?.name==='shears')return [{name:block.name,count:1}];
    const tree=block.name.replace(/_leaves$/,'');
    return rng()<.05?[{name:tree+'_sapling',count:1}]:[];
  }
  const oreDrops:Record<string,string>={coal_ore:'coal',iron_ore:'raw_iron',copper_ore:'raw_copper',gold_ore:'raw_gold',diamond_ore:'diamond',emerald_ore:'emerald',redstone_ore:'redstone',lapis_ore:'lapis_lazuli',nether_quartz_ore:'quartz'};
  const oreName=block.name.replace(/^deepslate_/,'');
  const name=oreDrops[oreName]??block.drop??block.name;
  const count=isSlabBlock(block)&&state===2?2:oreName==='redstone_ore'?4+Math.floor(rng()*2):oreName==='lapis_ore'?4+Math.floor(rng()*6):1;
  return [{name,count}];
}

export function blockExperience(block:BlockDef,tool:BlockDef|undefined,rng=Math.random):number{
  if(!canHarvest(block,tool))return 0;
  const ore=block.name.replace(/^deepslate_/,'');
  const range:Record<string,[number,number]>={coal_ore:[0,2],diamond_ore:[3,7],emerald_ore:[3,7],lapis_ore:[2,5],redstone_ore:[1,5],nether_quartz_ore:[2,5]};
  const limits=range[ore];return limits?limits[0]+Math.floor(rng()*(limits[1]-limits[0]+1)):0;
}