import { ID, BLOCKS } from '../game/data';
import '../game/content';
import { random, hashSeed } from '../input/math';
import type { Dimension } from '../game/types';
export const CHUNK=16, HEIGHT=128, MIN_Y=-32, SEA=20;

export const BIOME_TINTS: Record<string, [number, number, number]> = {
  plains: [0.96, 1.03, 0.88],
  forest: [0.86, 0.98, 0.82],
  birch_forest: [0.92, 1.04, 0.84],
  flower_forest: [0.95, 1.06, 0.86],
  taiga: [0.76, 0.91, 0.84],
  snowy_plains: [0.78, 0.88, 0.86],
  snowy_slopes: [0.78, 0.88, 0.86],
  windswept_hills: [0.84, 0.92, 0.82],
  desert: [1.08, 1.02, 0.78],
  savanna: [1.10, 1.04, 0.72],
  jungle: [0.78, 1.08, 0.74],
  swamp: [0.74, 0.84, 0.66],
  badlands: [1.06, 0.92, 0.74],
  cherry_grove: [1.05, 0.98, 0.96],
  mushroom_fields: [0.85, 0.95, 0.82],
  beach: [0.98, 1.02, 0.88],
  river: [0.90, 1.00, 0.86],
  ocean: [0.85, 0.96, 0.86],
  nether_wastes: [1.0, 1.0, 1.0],
  the_end: [1.0, 1.0, 1.0],
};

export class Noise {
  p=new Uint8Array(512);
  constructor(seed:number){const r=random(seed),a=Array.from({length:256},(_,i)=>i);for(let i=255;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]];}for(let i=0;i<512;i++)this.p[i]=a[i&255];}
  fade(t:number){return t*t*t*(t*(t*6-15)+10);}
  grad(h:number,x:number,y:number,z:number){h&=15;const u=h<8?x:y,v=h<4?y:h===12||h===14?x:z;return ((h&1)?-u:u)+((h&2)?-v:v);}
  n3(x:number,y:number,z:number){const X=Math.floor(x)&255,Y=Math.floor(y)&255,Z=Math.floor(z)&255;x-=Math.floor(x);y-=Math.floor(y);z-=Math.floor(z);const u=this.fade(x),v=this.fade(y),w=this.fade(z),p=this.p,A=p[X]+Y,AA=p[A]+Z,AB=p[A+1]+Z,B=p[X+1]+Y,BA=p[B]+Z,BB=p[B+1]+Z;const l=(a:number,b:number,t:number)=>a+(b-a)*t;return l(l(l(this.grad(p[AA],x,y,z),this.grad(p[BA],x-1,y,z),u),l(this.grad(p[AB],x,y-1,z),this.grad(p[BB],x-1,y-1,z),u),v),l(l(this.grad(p[AA+1],x,y,z-1),this.grad(p[BA+1],x-1,y,z-1),u),l(this.grad(p[AB+1],x,y-1,z-1),this.grad(p[BB+1],x-1,y-1,z-1),u),v),w);}
  n2(x:number,z:number){return this.n3(x,.137,z);}
  fbm(x:number,z:number,octaves=4){let value=0,amp=.57;for(let i=0;i<octaves;i++){value+=this.n2(x,z)*amp;x*=2.03;z*=2.03;amp*=.5;}return value;}
}
export const smooth=(a:number,b:number,x:number)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
export function coordHash(x:number,z:number,seed:number){let h=Math.imul(x,374761393)^Math.imul(z,668265263)^seed;h=Math.imul(h^(h>>>13),1274126177);return ((h^(h>>>16))>>>0)/4294967296;}
export class Terrain {
  seed:number;noise:Noise;dimension:Dimension;
  constructor(seed:string,dimension:Dimension='overworld'){this.seed=hashSeed(seed);this.noise=new Noise(this.seed);this.dimension=dimension;}
  river(x:number,z:number){return 9+Math.sin(z*.02)*18+Math.sin(z*.047+x*.008)*9+Math.sin(z*.11)*3;}
  height(x:number,z:number){
    if(this.dimension==='nether')return Math.floor(22+this.noise.fbm(x*.035,z*.035)*13);
    if(this.dimension==='end'){const d=Math.hypot(x,z);return d>95?-20:Math.floor(22+this.noise.fbm(x*.03,z*.03)*8-smooth(65,95,d)*15);}
    const n=this.noise, continental=n.fbm(x*.009+30,z*.009+30);
    let h=29+continental*15+n.fbm(x*.032,z*.032,3)*3;
    const ridgeN=Math.max(0,-z-28)*(.12+Math.max(0,n.fbm(x*.017+70,z*.017+70))*0.55);
    const ridgeS=Math.max(0,z-90)*(.09+Math.max(0,n.fbm(x*.015-70,z*.015-70))*0.45);
    const ridgeE=Math.max(0,x-110)*(.08+Math.max(0,n.fbm(x*.016+40,z*.016+40))*0.4);
    const ridgeW=Math.max(0,-x-110)*(.08+Math.max(0,n.fbm(x*.016-40,z*.016-40))*0.4);
    const ridge=Math.max(ridgeN,ridgeS,ridgeE,ridgeW);
    h+=Math.min(28,ridge)*(.6+Math.abs(n.n2(x*.027,z*.027))*.7);
    h+=Math.max(0,n.fbm(x*.012+100,z*.012+100)-.18)*22;
    h+=Math.max(0,n.fbm(x*.02+200,z*.02+200)-.25)*10;
    const river=Math.abs(x-this.river(x,z)),blend=smooth(2.6,18,river);
    h=(16.2+n.n2(x*.09,z*.09)*.9)*(1-blend)+h*blend;
    return Math.max(3,Math.min(83,Math.floor(h)));
  }
  biomeAt(x:number,z:number,h:number){
    if(this.dimension==='nether')return 'nether_wastes';if(this.dimension==='end')return 'the_end';
    const n=this.noise;
    const t=n.fbm(x*.008+200,z*.008+200),wet=n.fbm(x*.01-200,z*.01-200),detail=n.fbm(x*.03+50,z*.03+50);
    if(Math.abs(x-this.river(x,z))<5.5)return 'river';
    if(h<SEA-2)return 'ocean';
    if(h>43)return t<-.08?'snowy_slopes':'windswept_hills';
    if(h<=SEA+1)return 'beach';
    if(x<-48&&x>-110&&z<-12&&z>-85)return 'cherry_grove';
    if(z<-105)return 'snowy_plains';
    if(x>95&&z<65)return t>.1?'badlands':'desert';
    if(z>115)return 'jungle';
    if(x>90)return 'savanna';
    if(x<-100&&z>40)return 'swamp';
    if(x<-155&&z<-90)return 'mushroom_fields';
    if(detail>.32&&wet>.05&&Math.abs(x)<90&&Math.abs(z)<90)return 'birch_forest';
    if(detail<-.28&&wet>.1&&Math.abs(x)<90&&Math.abs(z)<90)return 'flower_forest';
    if(Math.abs(x)<75&&Math.abs(z)<85)return wet>.02?'forest':'plains';
    if(x>120&&z>95)return 'ocean';
    if(x<-130&&z>110)return 'swamp';
    if(x>150&&z<-70)return 'badlands';
    if(x<-120&&z<-20)return 'taiga';
    return t<-.15?'taiga':wet>.04?'forest':'plains';
  }
  biome(x:number,z:number){return this.biomeAt(x,z,this.height(x,z));}
  surface(biome:string,x:number,z:number){
    if(biome==='desert'||biome==='river'||biome==='ocean'||biome==='beach')return ID.sand;
    if(biome==='snowy_plains'||biome==='snowy_slopes')return ID.snow_block;
    if(biome==='badlands')return ID.red_sand??ID.sand;
    if(biome==='nether_wastes')return ID.netherrack;if(biome==='the_end')return ID.end_stone;
    if(biome==='mushroom_fields')return ID.mycelium??ID.grass_block;
    if(biome==='taiga'&&coordHash(x,z,this.seed+91)<.22)return ID.podzol??ID.grass_block;
    if(biome==='windswept_hills'&&(x+z)%5<2)return ID.stone;
    return ID.grass_block;
  }
  generate(cx:number,cz:number,edits:[string,number][]=[],structures=true){
    const padded=new Uint16Array(18*18*HEIGHT),data=new Uint16Array(16*16*HEIGHT),idx=(x:number,y:number,z:number)=>(y-MIN_Y)*324+(z+1)*18+x+1;
    const tint=new Float32Array(16*16*3);
    let maxY=SEA+1;const ox=cx*16,oz=cz*16;
    const put=(x:number,y:number,z:number,id:number,replace=true)=>{x-=ox;z-=oz;if(x< -1||x>16||z< -1||z>16||y<MIN_Y||y>=MIN_Y+HEIGHT)return;const i=idx(x,y,z);if(replace||!padded[i])padded[i]=id;maxY=Math.max(maxY,y+1);};
    if(this.dimension==='end'&&Math.hypot(ox+8,oz+8)>112){
      for(const [key,cell] of edits){const [x,y,z]=key.split(',').map(Number);put(x,y,z,cell);}
      for(let z=0;z<16;z++)for(let x=0;x<16;x++)for(let y=0;y<HEIGHT;y++)data[y*256+z*16+x]=padded[idx(x,y+MIN_Y,z)];
      return {data,padded,tint,maxY:Math.min(MIN_Y+HEIGHT,maxY+2)};
    }

    // Precompute 20x20 heightmap (from -2 to 17) so cliff & neighbor height lookups are O(1)
    const hMap=new Int16Array(20*20);
    for(let gz=-2;gz<=17;gz++)for(let gx=-2;gx<=17;gx++)hMap[(gz+2)*20+(gx+2)]=this.height(ox+gx,oz+gz);
    const getH=(x:number,z:number)=>hMap[(z+2)*20+(x+2)];

    for(let z=-1;z<=16;z++)for(let x=-1;x<=16;x++){
      const wx=ox+x,wz=oz+z,h=getH(x,z),biome=this.biomeAt(wx,wz,h),top=this.surface(biome,wx,wz);
      const cliff=Math.abs((getH(x+1,z)-getH(x-1,z)) + (getH(x,z+1)-getH(x,z-1))) > 6;
      if(x>=0&&x<16&&z>=0&&z<16){
        const bt=BIOME_TINTS[biome]??[1,1,1];
        const vary=0.94+coordHash(wx,wz,this.seed+303)*0.12+this.noise.n2(wx*0.14,wz*0.14)*0.05;
        const ti=(z*16+x)*3;
        tint[ti]=bt[0]*vary;tint[ti+1]=bt[1]*vary;tint[ti+2]=bt[2]*vary;
      }
      for(let y=MIN_Y;y<=Math.max(h,this.dimension==='overworld'?SEA:32);y++){
        let id=0;
        if(y<=h){
          id=y===h?(cliff&&top===ID.grass_block?ID.stone:top):y>h-4?(top===ID.sand?ID.sand:(cliff?ID.stone:ID.dirt)):ID.stone;
          if(this.dimension==='nether')id=ID.netherrack;if(this.dimension==='end')id=ID.end_stone;
          if(y===MIN_Y)id=ID.bedrock;
          if(y<h-5&&y>MIN_Y+2&&this.dimension==='overworld'){
            const cave=this.noise.n3(wx*.052,y*.069,wz*.052),tube=Math.abs(this.noise.n3(wx*.037+90,y*.055,wz*.037+90));
            if((Math.abs(cave)<.065&&y<h-9)||tube<.033&&y<15)id=y<-23?ID.lava:0;
            else if(id===ID.stone){const ore=coordHash(wx+y*311,wz-y*137,this.seed);if(ore<.018)id=ID.coal_ore;else if(ore<.031&&y<29)id=ID.iron_ore;else if(ore<.037&&y<-4)id=ID.gold_ore;else if(ore<.041&&y<-18)id=ID.diamond_ore;}
          }
        }else if(this.dimension==='overworld'&&y<=SEA)id=ID.water;
        else if(this.dimension==='nether'&&y<=24)id=ID.lava;
        padded[idx(x,y,z)]=id;
      }
      maxY=Math.max(maxY,h+1);
      if(this.dimension==='overworld'){
        // Water surface lily pads in swamp & calm river edges
        if(h<SEA&&h>=SEA-3&&(biome==='swamp'||biome==='river')&&coordHash(wx,wz,this.seed+61)<(biome==='swamp'?.075:.018)){
          put(wx,SEA+1,wz,ID.lily_pad??ID.short_grass,false);
        }
        if(h>SEA+1&&(top===ID.grass_block||top===ID.podzol||biome==='swamp'||biome==='beach')){
          const r=coordHash(wx,wz,this.seed+44);
          if(biome==='cherry_grove'){
            if(r<.28)put(wx,h+1,wz,ID.pink_petals??ID.poppy,false);
          }else if(biome==='flower_forest'){
            if(r<.24){
              const f=r<.04?ID.poppy:r<.08?ID.dandelion:r<.11?ID.cornflower:r<.14?ID.lily_of_the_valley:r<.17?ID.orange_tulip:r<.20?ID.pink_tulip:ID.oxeye_daisy;
              put(wx,h+1,wz,f??ID.poppy,false);
            }
          }else if(biome==='taiga'){
            if(r<.12)put(wx,h+1,wz,r<.08?(ID.fern??ID.short_grass):ID.brown_mushroom,false);
          }else if(biome==='birch_forest'){
            if(r<.08)put(wx,h+1,wz,r<.015?(ID.lily_of_the_valley??ID.dandelion):ID.short_grass,false);
          }else if(r<.095){
            const f=r<.01?ID.poppy:r<.018?ID.dandelion:r<.024?ID.cornflower:r<.029?ID.oxeye_daisy:r<.034?ID.red_mushroom:r<.039?ID.brown_mushroom:ID.short_grass;
            put(wx,h+1,wz,f??ID.short_grass,false);
          }
          if(biome==='swamp'&&coordHash(wx,wz,this.seed+66)<.018)for(let yy=1;yy<4;yy++)put(wx,h+yy,wz,ID.sugar_cane??ID.oak_log,false);
          if(biome==='beach'&&coordHash(wx,wz,this.seed+77)<.025)put(wx,h+1,wz,ID.short_grass,false);
        }
        // Fallen logs with mushrooms in forest/taiga
        if((biome==='forest'||biome==='taiga')&&h>SEA+2&&coordHash(wx,wz,this.seed+711)<.0022){
          const logId=biome==='taiga'?(ID.spruce_log??ID.oak_log):ID.oak_log;
          for(let l=0;l<3;l++)if(this.height(wx+l,wz)===h){put(wx+l,h+1,wz,logId,false);if(l===1)put(wx+l,h+2,wz,ID.red_mushroom,false);}
        }
        // Mossy boulders in taiga & windswept hills
        if((biome==='taiga'||biome==='windswept_hills')&&h>SEA+2&&coordHash(wx,wz,this.seed+722)<.003){
          const rock=biome==='taiga'?(ID.mossy_cobblestone??ID.cobblestone):ID.cobblestone;
          put(wx,h+1,wz,rock,false);put(wx+1,h+1,wz,rock,false);put(wx,h+1,wz+1,rock,false);put(wx,h+2,wz,rock,false);
        }
      }
      if(biome==='desert'){
        const dr=coordHash(wx,wz,this.seed+55);
        if(dr<.008)for(let y=1;y<4;y++)put(wx,h+y,wz,ID.cactus??ID.oak_log);
        else if(dr<.022)put(wx,h+1,wz,ID.dead_bush??ID.short_grass,false);
      }
      if(biome==='badlands'&&coordHash(wx,wz,this.seed+56)<.018)put(wx,h+1,wz,ID.dead_bush??ID.short_grass,false);
      if(biome==='snowy_plains'&&coordHash(wx,wz,this.seed+88)<.012)for(let y=1;y<3;y++)put(wx,h+y,wz,ID.spruce_log??ID.oak_log);
    }
    if(this.dimension!=='end')for(let gz=Math.floor((oz-5)/7);gz<=Math.floor((oz+21)/7);gz++)for(let gx=Math.floor((ox-5)/7);gx<=Math.floor((ox+21)/7);gx++){
      const r=coordHash(gx,gz,this.seed+818),biome=this.biome(gx*7,gz*7);
      const chance=biome==='forest'?.67:biome==='taiga'?.64:biome==='jungle'?.83:biome==='cherry_grove'?.7:biome==='birch_forest'?.72:biome==='flower_forest'?.45:biome==='plains'?.18:biome==='savanna'?.16:biome==='swamp'?.35:biome==='mushroom_fields'?.3:0;
      if(r>chance)continue;
      const x=gx*7+Math.floor(coordHash(gx,gz,this.seed+23)*5),z=gz*7+Math.floor(coordHash(gx,gz,this.seed+24)*5),h=this.height(x,z);
      if(h<=SEA+2||Math.hypot(x+11,z-27)<5||biome==='desert'||biome==='snowy_slopes'||biome==='beach'||biome==='river')continue;
      const birch=biome==='forest'&&r<.19||biome==='birch_forest',cherry=biome==='cherry_grove',spruce=biome==='taiga';
      const log=cherry?ID.cherry_log:birch?ID.birch_log:spruce?ID.spruce_log:biome==='jungle'?ID.jungle_log:biome==='savanna'?ID.acacia_log:ID.oak_log,leaf=cherry?ID.cherry_leaves:birch?ID.birch_leaves:spruce?ID.spruce_leaves:biome==='jungle'?ID.jungle_leaves:biome==='savanna'?ID.acacia_leaves:ID.oak_leaves;
      const trunk=spruce?7:cherry?4:4+Math.floor(r*4);
      for(let y=1;y<=trunk;y++)put(x,h+y,z,log);
      if(spruce){for(let dy=2;dy<=8;dy++){const radius=Math.max(0,Math.floor((9-dy)/2));for(let dz=-radius;dz<=radius;dz++)for(let dx=-radius;dx<=radius;dx++)if(Math.abs(dx)+Math.abs(dz)<=radius+1)put(x+dx,h+dy,z+dz,leaf,false);}}
      else for(let dy=-2;dy<=1;dy++){const radius=dy===1?1:2;for(let dz=-radius;dz<=radius;dz++)for(let dx=-radius;dx<=radius;dx++){if(Math.abs(dx)===radius&&Math.abs(dz)===radius&&(dy===1||coordHash(x+dx,z+dz,dy+44)<.55))continue;put(x+dx,h+trunk+dy,z+dz,leaf,false);}}
      if(cherry)for(let dx=-3;dx<=3;dx++)put(x+dx,h+trunk-1,z,leaf,false);
    }
    if(structures&&this.dimension==='overworld'){
      if(ox<0&&ox>-48&&oz<0&&oz>-48)this.cabin(put,-23,-19);
      if(ox>=-16&&ox<32&&oz>=-16&&oz<32){
        this.house(put,8,8);this.house(put,18,14);this.house(put,4,20);
        this.villageDetails(put,12,13);
      }
      if(this.biome(ox+8,oz+8)==='desert'&&coordHash(cx,cz,this.seed+999)<.25)this.temple(put,ox+4,oz+4);
      if(coordHash(cx,cz,this.seed+1234)<.08)this.dungeon(put,ox+8,oz+8);
    }
    if(structures&&this.dimension==='nether'&&coordHash(cx,cz,this.seed+5555)<.18)this.fortress(put,ox+4,oz+4);
    for(const [key,id] of edits){const [x,y,z]=key.split(',').map(Number);put(x,y,z,id);}
    for(let z=0;z<16;z++)for(let x=0;x<16;x++)for(let y=0;y<HEIGHT;y++)data[y*256+z*16+x]=padded[idx(x,y+MIN_Y,z)];
    return {data,padded,tint,maxY:Math.min(MIN_Y+HEIGHT,maxY+2)};
  }
  villageDetails(put:(x:number,y:number,z:number,id:number,replace?:boolean)=>void,x:number,z:number){
    const pathId=ID.dirt_path??ID.gravel;
    for(let i=-4;i<=8;i++){
      const py=this.height(x+i,z);if(py>SEA)put(x+i,py,z,pathId);
      const pz=this.height(x,z+i);if(pz>SEA)put(x,pz,z+i,pathId);
    }
    // Village well & lantern post
    const wy=this.height(x-2,z-2)+1;
    for(let dz=0;dz<3;dz++)for(let dx=0;dx<3;dx++){
      put(x-2+dx,wy-1,z-2+dz,ID.mossy_cobblestone??ID.cobblestone);
      put(x-2+dx,wy,z-2+dz,(dx===1&&dz===1)?ID.water:(ID.mossy_cobblestone??ID.cobblestone));
    }
    const ly=this.height(x+4,z+1)+1;
    put(x+4,ly,z+1,ID.oak_planks_fence??ID.oak_log);
    put(x+4,ly+1,z+1,ID.oak_planks_fence??ID.oak_log);
    put(x+4,ly+2,z+1,ID.lantern??ID.torch);
  }
  cabin(put:(x:number,y:number,z:number,id:number,replace?:boolean)=>void,x:number,z:number){
    const y=this.height(x+3,z+3)+1;
    for(let dz=0;dz<7;dz++)for(let dx=0;dx<7;dx++){
      put(x+dx,y-1,z+dz,ID.cobblestone);
      for(let dy=0;dy<4;dy++){const wall=dx===0||dx===6||dz===0||dz===6;let id=wall?ID.oak_planks:0;if((dx===0||dx===6)&&(dz===0||dz===6))id=ID.oak_log;if(wall&&dy===1&&(dx===3||dz===3))id=ID.glass;if(dz===6&&dx===3&&dy<2)id=0;put(x+dx,y+dy,z+dz,id);}
    }
    for(let dy=0;dy<4;dy++)for(let dz=-1;dz<8;dz++)for(let dx=dy-1;dx<8-dy;dx++)put(x+dx,y+4+dy,z+dz,ID.oak_planks);
    put(x+1,y,z+1,ID.crafting_table);put(x+5,y,z+1,ID.furnace);put(x+5,y,z+4,ID.chest);put(x+1,y+1,z+4,ID.torch);
  }
  house(put:(x:number,y:number,z:number,id:number,replace?:boolean)=>void,x:number,z:number){
    const y=this.height(x+2,z+2)+1;
    for(let dz=0;dz<5;dz++)for(let dx=0;dx<5;dx++){
      put(x+dx,y-1,z+dz,ID.cobblestone);
      for(let dy=0;dy<3;dy++){const wall=dx===0||dx===4||dz===0||dz===4;let id=wall?ID.oak_planks:0;if((dx===0||dx===4)&&(dz===0||dz===4))id=ID.oak_log;if(wall&&dy===1&&(dx===2||dz===2))id=ID.glass;if(dz===4&&dx===2&&dy<2)id=0;put(x+dx,y+dy,z+dz,id);}
    }
    for(let dz=-1;dz<6;dz++)for(let dx=-1;dx<6;dx++){if(dx>=0&&dx<5&&dz>=0&&dz<5)continue;put(x+dx,y+3,z+dz,ID.oak_planks);}
    put(x+2,y+4,z+2,ID.oak_planks);
    put(x+1,y,z+1,ID.crafting_table);put(x+3,y,z+3,ID.chest);put(x+2,y+1,z+2,ID.torch);
  }
  temple(put:(x:number,y:number,z:number,id:number,replace?:boolean)=>void,x:number,z:number){
    const y=this.height(x+4,z+4)+1;
    for(let dz=0;dz<9;dz++)for(let dx=0;dx<9;dx++){
      put(x+dx,y-1,z+dz,ID.sandstone??ID.sand);
      for(let dy=0;dy<4;dy++){const wall=dx===0||dx===8||dz===0||dz===8;if(wall)put(x+dx,y+dy,z+dz,ID.sandstone??ID.sand);}
    }
    for(let dy=0;dy<2;dy++)for(let dz=0;dz<9;dz++)for(let dx=0;dx<9;dx++)put(x+dx,y+4+dy,z+dz,ID.sandstone??ID.sand);
    put(x+4,y+6,z+4,ID.torch);
    put(x+4,y,z+4,ID.tnt??ID.sand);
  }
  fortress(put:(x:number,y:number,z:number,id:number,replace?:boolean)=>void,x:number,z:number){
    const y=this.height(x+6,z+6)+1;
    for(let dz=0;dz<12;dz++)for(let dx=0;dx<12;dx++){
      put(x+dx,y-1,z+dz,ID.nether_bricks??ID.netherrack);
      for(let dy=0;dy<3;dy++){const wall=dx===0||dx===11||dz===0||dz===11;if(wall)put(x+dx,y+dy,z+dz,ID.nether_bricks??ID.netherrack);}
    }
    for(let dy=0;dy<2;dy++)for(let dz=0;dz<12;dz++)for(let dx=0;dx<12;dx++)put(x+dx,y+3+dy,z+dz,ID.nether_bricks??ID.netherrack);
    put(x+6,y+5,z+6,ID.torch);
  }
  dungeon(put:(x:number,y:number,z:number,id:number,replace?:boolean)=>void,x:number,z:number){
    const y=Math.max(MIN_Y+5,this.height(x,z)-8);
    for(let dz=0;dz<7;dz++)for(let dx=0;dx<7;dx++)for(let dy=0;dy<5;dy++){
      const wall=dx===0||dx===6||dz===0||dz===6||dy===0||dy===4;
      if(wall)put(x+dx,y+dy,z+dz,ID.cobblestone);
    }
    put(x+3,y+1,z+3,ID.chest);
    put(x+1,y+1,z+1,ID.torch);put(x+5,y+1,z+5,ID.torch);
  }
}
export function blockIndex(x:number,y:number,z:number){return (y-MIN_Y)*256+z*16+x;}
export function blockName(id:number){return BLOCKS[id]?.name??'air';}
