import { BLOCKS, ID, isOpaque } from '../game/data';
import { blockId, blockState, isSlabBlock, localFaceForState, type Face } from '../game/blockState';
import { selectionBoxes } from './shapes';
import { MIN_Y } from './terrain';
export interface MeshData { position:Float32Array;normal:Float32Array;uv:Float32Array;color:Float32Array;tile:Float32Array;wind:Float32Array;index:Uint32Array; }
const AO_LUT=[1,.82,.66,.52];

export function meshChunk(padded:Uint16Array,maxY:number,tiles:number[][],tint?:Float32Array):{solid:MeshData;water:MeshData}{
  const dims=[16,maxY-MIN_Y,16],get=(x:number,y:number,z:number)=>y<MIN_Y||y>=maxY||x< -1||x>16||z< -1||z>16?0:padded[(y-MIN_Y)*324+(z+1)*18+x+1];
  const fullCube=(cell:number)=>{const def=BLOCKS[blockId(cell)];return !!def&&(def.shape==='cube'||isSlabBlock(def)&&blockState(cell)===2);};
  const opaqueCell=(cell:number)=>fullCube(cell)&&isOpaque(blockId(cell));
  const make=()=>({p:[] as number[],n:[] as number[],uv:[] as number[],c:[] as number[],t:[] as number[],w:[] as number[],i:[] as number[]});
  const out=make(),water=make();
  const sampleTint=(x:number,z:number,tinted:boolean)=>{
    if(!tinted||!tint)return [1,1,1];
    const cx=Math.max(0,Math.min(15,Math.floor(x))),cz=Math.max(0,Math.min(15,Math.floor(z))),ti=(cz*16+cx)*3;
    return [tint[ti],tint[ti+1],tint[ti+2]];
  };
  const quad=(o:ReturnType<typeof make>,verts:number[][],normal:number[],u:number,v:number,tile:number,ao:number[],wind:number,flip=false,rgb:[number,number,number]=[1,1,1],rot90=false,rev=false)=>{
    const start=o.p.length/3;
    const uv=rot90?(rev?[[v,0],[v,u],[0,u],[0,0]]:[[0,0],[0,u],[v,u],[v,0]]):[[0,0],[u,0],[u,v],[0,v]];
    for(let k=0;k<4;k++){
      o.p.push(verts[k][0],verts[k][1],verts[k][2]);
      o.n.push(normal[0],normal[1],normal[2]);
      o.uv.push(uv[k][0],uv[k][1]);
      const l=AO_LUT[ao[k]];
      o.c.push(l*rgb[0],l*rgb[1],l*rgb[2]);
      o.t.push(tile);
      o.w.push(wind);
    }
    if(flip)o.i.push(start,start+1,start+3,start+1,start+2,start+3);else o.i.push(start,start+1,start+2,start,start+2,start+3);
  };
  const pack=(o:ReturnType<typeof make>):MeshData=>({position:new Float32Array(o.p),normal:new Float32Array(o.n),uv:new Float32Array(o.uv),color:new Float32Array(o.c),tile:new Float32Array(o.t),wind:new Float32Array(o.w),index:new Uint32Array(o.i)});
  const p=[0,0,0],step=[0,0,0];
  for(let d=0;d<3;d++){
    const u=(d+1)%3,v=(d+2)%3;step[0]=0;step[1]=0;step[2]=0;step[d]=1;
    const mask=new Int32Array(dims[u]*dims[v]),waterMask=new Int16Array(dims[u]*dims[v]);
    for(let slice=-1;slice<dims[d];slice++){
      mask.fill(0);waterMask.fill(0);
      for(let j=0;j<dims[v];j++)for(let i=0;i<dims[u];i++){
        p[d]=slice;p[u]=i;p[v]=j;
        const cellA=get(p[0],p[1]+MIN_Y,p[2]),cellB=get(p[0]+step[0],p[1]+step[1]+MIN_Y,p[2]+step[2]);
        const a=blockId(cellA),b=blockId(cellB);
        const aid=a&&fullCube(cellA)?a:0,bid=b&&fullCube(cellB)?b:0;
        let id=0,sign=1;
        if(aid&&!opaqueCell(cellB)&&!(a===b&&BLOCKS[a].transparent)){id=a;}
        else if(bid&&!opaqueCell(cellA)&&a!==b){id=b;sign=-1;}
        if(id&&id!==ID.water&&id!==ID.lava){
          let ao0=0,ao1=0,ao2=0,ao3=0;
          const corners=[[0,0],[1,0],[1,1],[0,1]];
          for(let cIdx=0;cIdx<4;cIdx++){
            const cu=corners[cIdx][0],cv=corners[cIdx][1];
            const q0=p[0]+(sign>0&&d===0?1:0);
            const q1=p[1]+(sign>0&&d===1?1:0);
            const q2=p[2]+(sign>0&&d===2?1:0);
            const du=cu?1:-1,dv=cv?1:-1;
            const s1x=q0+(u===0?du:0),s1y=q1+(u===1?du:0),s1z=q2+(u===2?du:0);
            const s2x=q0+(v===0?dv:0),s2y=q1+(v===1?dv:0),s2z=q2+(v===2?dv:0);
            const cx=q0+(u===0?du:0)+(v===0?dv:0),cy=q1+(u===1?du:0)+(v===1?dv:0),cz=q2+(u===2?du:0)+(v===2?dv:0);
            const a1=+opaqueCell(get(s1x,s1y+MIN_Y,s1z)),a2=+opaqueCell(get(s2x,s2y+MIN_Y,s2z)),ac=+opaqueCell(get(cx,cy+MIN_Y,cz));
            const val=a1&&a2?3:a1+a2+ac;
            if(cIdx===0)ao0=val;else if(cIdx===1)ao1=val;else if(cIdx===2)ao2=val;else ao3=val;
          }
          const state=blockState(sign>0?cellA:cellB);
          mask[j*dims[u]+i]=id|(ao0<<12)|(ao1<<14)|(ao2<<16)|(ao3<<18)|(sign<0?1<<20:0)|(state<<21);
        }
        if((a===ID.water||a===ID.lava)&&b===0)waterMask[j*dims[u]+i]=a;
        else if((b===ID.water||b===ID.lava)&&a===0)waterMask[j*dims[u]+i]=-b;
      }
      for(let j=0;j<dims[v];j++)for(let i=0;i<dims[u];){
        const key=mask[j*dims[u]+i],wm=waterMask[j*dims[u]+i];
        if(!key&&!wm){i++;continue;}let w=1,h=1;
        if(key){while(i+w<dims[u]&&mask[j*dims[u]+i+w]===key)w++;outer:while(j+h<dims[v]){for(let k=0;k<w;k++)if(mask[(j+h)*dims[u]+i+k]!==key)break outer;h++;}}
        else {
          while(i+w<dims[u]&&waterMask[j*dims[u]+i+w]===wm&&!mask[j*dims[u]+i+w])w++;
          outerWater:while(j+h<dims[v]){for(let k=0;k<w;k++)if(waterMask[(j+h)*dims[u]+i+k]!==wm||mask[(j+h)*dims[u]+i+k])break outerWater;h++;}
        }
        const id=key?key&4095:Math.abs(wm),sign=key?(key&(1<<20)?-1:1):wm>0?1:-1,ao=key?[key>>12&3,key>>14&3,key>>16&3,key>>18&3]:[0,0,0,0],state=key?(key>>>21)&15:0;
        const bp=[0,0,0];bp[d]=slice+1;bp[u]=i;bp[v]=j;
        const verts:number[][]=[];
        for(const [du,dv] of [[0,0],[w,0],[w,h],[0,h]]){
          const q=[bp[0],bp[1],bp[2]];q[u]+=du;q[v]+=dv;q[1]+=MIN_Y;
          if(wm&&d===1&&sign>0)q[1]-=.12;
          verts.push(q);
        }
        const normal=[0,0,0];normal[d]=sign;if(sign<0){verts.reverse();ao.reverse();}
        const def=BLOCKS[id];
        const tinted=!wm&&((def?.pattern==='grass'&&d===1&&sign>0)||def?.pattern==='leaves');
        const rgb=sampleTint(verts[0][0],verts[0][2],tinted) as [number,number,number];
        const worldFace=(d*2+(sign>0?0:1)) as Face;
        const tile=wm?(id===ID.lava?1:0):tiles[id][localFaceForState(def,state,worldFace)];
        quad(wm?water:out,verts,normal,w,h,tile,ao,def?.pattern==='leaves'?.13:0,ao[0]+ao[2]>ao[1]+ao[3],rgb,d===0,sign<0);
        for(let dy=0;dy<h;dy++)for(let dx=0;dx<w;dx++){mask[(j+dy)*dims[u]+i+dx]=0;waterMask[(j+dy)*dims[u]+i+dx]=0;}i+=w;
      }
    }
  }
  for(let y=MIN_Y;y<maxY;y++)for(let z=0;z<16;z++)for(let x=0;x<16;x++){
    const cell=get(x,y,z),id=blockId(cell),state=blockState(cell),b=BLOCKS[id];if(!b||fullCube(cell)||b.shape==='water')continue;
    const isGrassTint=b.name==='short_grass'||b.name==='fern'||b.name==='lily_pad';
    const rgb=sampleTint(x,z,isGrassTint) as [number,number,number];
    if(b.shape==='cross'){
      for(const verts of [[[x+.28,y,z+.28],[x+.72,y,z+.72],[x+.72,y+.72,z+.72],[x+.28,y+.72,z+.28]],[[x+.72,y,z+.28],[x+.28,y,z+.72],[x+.28,y+.72,z+.72],[x+.72,y+.72,z+.28]]]){
        quad(out,verts,[0,1,0],1,1,tiles[id][0],[0,0,0,0],.7,false,rgb);
        quad(out,[...verts].reverse(),[0,1,0],1,1,tiles[id][0],[0,0,0,0],.7,false,rgb);
      }
    }else if(b.shape==='lily'){
      const v=[[x+.06,y+.03,z+.94],[x+.94,y+.03,z+.94],[x+.94,y+.03,z+.06],[x+.06,y+.03,z+.06]];
      quad(out,v,[0,1,0],1,1,tiles[id][0],[0,0,0,0],0,false,rgb);
      quad(out,[...v].reverse(),[0,-1,0],1,1,tiles[id][0],[0,0,0,0],0,false,rgb);
    }else{
      const boxes=selectionBoxes(b,state);
      for(const box of boxes){const [x0,y0,z0,x1,y1,z1]=box,verts=[[[x+x0,y+y0,z+z1],[x+x1,y+y0,z+z1],[x+x1,y+y1,z+z1],[x+x0,y+y1,z+z1]],[[x+x1,y+y0,z+z0],[x+x0,y+y0,z+z0],[x+x0,y+y1,z+z0],[x+x1,y+y1,z+z0]],[[x+x0,y+y1,z+z1],[x+x1,y+y1,z+z1],[x+x1,y+y1,z+z0],[x+x0,y+y1,z+z0]],[[x+x0,y+y0,z+z0],[x+x1,y+y0,z+z0],[x+x1,y+y0,z+z1],[x+x0,y+y0,z+z1]],[[x+x1,y+y0,z+z1],[x+x1,y+y0,z+z0],[x+x1,y+y1,z+z0],[x+x1,y+y1,z+z1]],[[x+x0,y+y0,z+z0],[x+x0,y+y0,z+z1],[x+x0,y+y1,z+z1],[x+x0,y+y1,z+z0]]];const normals=[[0,0,1],[0,0,-1],[0,1,0],[0,-1,0],[1,0,0],[-1,0,0]];const faces:Face[]=[4,5,2,3,0,1];for(let f=0;f<6;f++)quad(out,verts[f],normals[f],1,1,tiles[id][localFaceForState(b,state,faces[f])],[0,0,0,0],0);}
    }
  }
  return {solid:pack(out),water:pack(water)};
}
