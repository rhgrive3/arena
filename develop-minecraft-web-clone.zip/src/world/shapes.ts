import type { BlockDef } from '../game/data';
import { isSlabBlock } from '../game/blockState';

export type Bounds = readonly [number, number, number, number, number, number];
export const CHEST_BOUNDS: Bounds = [1 / 16, 0, 1 / 16, 15 / 16, 14 / 16, 15 / 16];
const FULL: readonly Bounds[] = [[0, 0, 0, 1, 1, 1]];
const CHEST: readonly Bounds[] = [CHEST_BOUNDS];
const SLAB: readonly Bounds[] = [[0, 0, 0, 1, .5, 1]];
const TOP_SLAB: readonly Bounds[] = [[0, .5, 0, 1, 1, 1]];
const STAIRS: readonly (readonly Bounds[])[] = [
  [[0,0,0,1,.5,1],[0,.5,0,1,1,.5]],
  [[0,0,0,1,.5,1],[.5,.5,0,1,1,1]],
  [[0,0,0,1,.5,1],[0,.5,.5,1,1,1]],
  [[0,0,0,1,.5,1],[0,.5,0,.5,1,1]],
  [[0,.5,0,1,1,1],[0,0,0,1,.5,.5]],
  [[0,.5,0,1,1,1],[.5,0,0,1,.5,1]],
  [[0,.5,0,1,1,1],[0,0,.5,1,.5,1]],
  [[0,.5,0,1,1,1],[0,0,0,.5,.5,1]],
];
const DOOR: readonly Bounds[] = [[0, 0, 0, 1, 1, .18]];
const TRAPDOOR: readonly Bounds[] = [[0, 0, 0, 1, .18, 1]];
const PANE: readonly Bounds[] = [[.42, 0, 0, .58, 1, 1]];
const FENCE: readonly Bounds[] = [[.35, 0, .35, .65, 1, .65], [0, .4, .42, 1, .55, .58], [.42, .4, 0, .58, .55, 1], [0, .78, .42, 1, .93, .58], [.42, .78, 0, .58, .93, 1]];
const TORCH: readonly Bounds[] = [[.35, 0, .35, .65, .75, .65]];
const PLANT: readonly Bounds[] = [[.2, 0, .2, .8, .8, .8]];
const LILY: readonly Bounds[] = [[.06, 0, .06, .94, .08, .94]];
const NONE: readonly Bounds[] = [];

export function selectionBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  switch (def.shape) {
    case 'chest': return CHEST;
    case 'slab': return isSlabBlock(def) ? (state === 2 ? FULL : state === 1 ? TOP_SLAB : SLAB) : SLAB;
    case 'stairs': return STAIRS[state & 7];
    case 'door': return DOOR;
    case 'trapdoor': return TRAPDOOR;
    case 'pane': return PANE;
    case 'fence': return FENCE;
    case 'torch': return TORCH;
    case 'cross': return PLANT;
    case 'lily': return LILY;
    case 'water': return NONE;
    default: return FULL;
  }
}

export function collisionBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  return def.solid ? selectionBoxes(def,state) : NONE;
}

export function intersectsBox(
  x: number, y: number, z: number,
  minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number,
  box: Bounds,
): boolean {
  return maxX > x + box[0] && minX < x + box[3] &&
    maxY > y + box[1] && minY < y + box[4] &&
    maxZ > z + box[2] && minZ < z + box[5];
}