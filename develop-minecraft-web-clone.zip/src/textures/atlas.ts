import * as THREE from 'three';
import { BLOCKS, ITEMS, ID, faceTile, ATLAS_COLS, TILE, type BlockDef, type Pattern } from '../game/data';
import '../game/content';
import { random } from '../input/math';
export type DrawCanvas = HTMLCanvasElement | OffscreenCanvas;
export type Context2D = CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D;
export function canvas(w: number, h = w): DrawCanvas { const c = typeof document !== 'undefined' ? document.createElement('canvas') : new OffscreenCanvas(w,h); c.width=w;c.height=h;return c; }
const rgb = (hex: string) => [parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)];
function shade(hex: string, n: number) { const c=rgb(hex);return `rgb(${c.map(v=>Math.max(0,Math.min(255,Math.round(v+n)))).join(',')})`; }
const tileNames: string[] = [], tileCanvases = new Map<string, DrawCanvas>();
const tileIndex = new Map<string,number>();

/**
 * 面別タイル名から描画パターンを決定する。
 * チェスト/かまど/作業台/ピストン/TNT 等は面ごとに異なる絵柄を用いる（本家準拠）。
 */
function tilePattern(name: string, pattern: Pattern): Pattern {
  if (name === 'chest_front' || name === 'barrel_front') return 'chest';
  if (name === 'chest_side' || name === 'chest_top' || name === 'chest_bottom' || name === 'barrel_side' || name === 'barrel_top' || name === 'barrel_bottom') return 'planks';
  if (name.startsWith('tnt_')) return 'tnt';
  if (name === 'crafting_table_top') return 'craft';
  if (name === 'crafting_table_front') return 'craft';
  if (name === 'crafting_table_side') return 'planks';
  if (name.endsWith('_top') || name.endsWith('_bottom')) {
    if (pattern === 'bark') return 'rings';
    if (pattern === 'furnace') return 'stone';
    if (name.startsWith('piston') || name === 'sticky_piston_top' || name === 'sticky_piston_bottom') return 'planks';
  }
  if (name.endsWith('_front')) {
    // 前面は開口部・留め具・木目など「顔」に当たる絵柄（本家準拠）
    if (pattern === 'furnace') return 'furnace';
    if (pattern === 'craft') return 'planks';
    return pattern;
  }
  if (name.endsWith('_side')) {
    if (pattern === 'grass') return 'dirt';
    if (pattern === 'furnace') return 'metal';
    if (pattern === 'craft') return 'metal';
    return pattern;
  }
  if (pattern === 'bricks' && name.includes('cobblestone')) return 'cobble';
  return pattern;
}

function noiseTile(name: string, base: string, pattern: Pattern, seed: number): DrawCanvas {
  const c=canvas(16), ctx=c.getContext('2d') as Context2D, rnd=random(seed), img=ctx.createImageData(16,16), color=rgb(base);
  const coarse=Array.from({length:25},()=>rnd()*2-1);
  for(let y=0;y<16;y++) for(let x=0;x<16;x++) {
    const cx=Math.floor(x/4),cy=Math.floor(y/4),fx=x%4/4,fy=y%4/4;
    const n=(coarse[cy*5+cx]*(1-fx)+coarse[cy*5+cx+1]*fx)*(1-fy)+(coarse[(cy+1)*5+cx]*(1-fx)+coarse[(cy+1)*5+cx+1]*fx)*fy;
    let v=n*15+(rnd()-.5)*23, alpha=255;
    if(pattern==='sand'||pattern==='snow')v*=.55;
    if(pattern==='bark')v+=((rnd()<.25?-25:0)+(x%4===0?-17:x%4===1?9:0));
    if(pattern==='planks')v+=(y%4===0?-32:y%4===1?12:0)+(x===(Math.floor(y/4)*7+3)%16?-18:0);
    if(pattern==='wool')v=((x+y)%3===0?9:-3)+n*8;
    if(pattern==='leaves'){v=n*22+(rnd()-.5)*26+10;if(rnd()<.03)alpha=0;}
    if(pattern==='gravel')v=n*38+(rnd()-.5)*40;
    if(pattern==='obsidian')v=n*17+(rnd()<.15?15:0);
    if(pattern==='water'||pattern==='lava')v=Math.sin(x*.9+Math.sin(y*.8)*2)*12+n*8;
    const i=(y*16+x)*4;
    img.data[i]=Math.max(0,Math.min(255,color[0]+v));img.data[i+1]=Math.max(0,Math.min(255,color[1]+v));img.data[i+2]=Math.max(0,Math.min(255,color[2]+v));img.data[i+3]=alpha;
  }
  ctx.putImageData(img,0,0);
  const rect=(x:number,y:number,w:number,h:number,col:string)=>{ctx.fillStyle=col;ctx.fillRect(x,y,w,h);};
  if(pattern==='grass') {
    for(let i=0;i<24;i++){const x=Math.floor(rnd()*16),y=Math.floor(rnd()*16);rect(x,y,2,1,shade(base,rnd()*28-10));}
    if(name==='dirt_path')for(let i=0;i<10;i++)rect(Math.floor(rnd()*15),Math.floor(rnd()*15),2,1,'#7d6338');
  }
  if(pattern==='stone'||pattern==='dirt'||pattern==='gravel'){
    for(let i=0;i<10;i++){const x=Math.floor(rnd()*14),y=Math.floor(rnd()*14);rect(x,y,2+Math.floor(rnd()*3),1,shade(base,-21));rect(x,y+1,2,1,shade(base,13));}
    if(name==='coarse_dirt')for(let i=0;i<12;i++)rect(Math.floor(rnd()*15),Math.floor(rnd()*15),1,1,'#969087');
    if(name==='granite')for(let i=0;i<12;i++)rect(Math.floor(rnd()*15),Math.floor(rnd()*15),1,1,i%2?'#c7a697':'#6c5349');
    if(name==='diorite')for(let i=0;i<14;i++)rect(Math.floor(rnd()*15),Math.floor(rnd()*15),1,1,i%2?'#868984':'#ecebe3');
    if(name==='andesite')for(let i=0;i<12;i++)rect(Math.floor(rnd()*15),Math.floor(rnd()*15),2,1,'#767b72');
    if(name.startsWith('furnace')||name.startsWith('blast_furnace')||name.startsWith('smoker')||name.startsWith('dispenser')||name.startsWith('dropper'))rect(2,2,12,12,shade(base,-8));
  }
  if(pattern==='cobble'){
    // 丸石: 不規則な石塊 + モルタル目地
    for(let i=0;i<16;i++){
      const x=Math.floor(rnd()*15),y=Math.floor(rnd()*15),w=2+Math.floor(rnd()*4),h=2+Math.floor(rnd()*3);
      rect(x,y,w,h,shade(base,-16+rnd()*32));rect(x,y+h,w,1,shade(base,-42));rect(x+w,y,1,h,shade(base,-38));
    }
    for(let i=0;i<10;i++){const x=Math.floor(rnd()*15),y=Math.floor(rnd()*15);rect(x,y,1+Math.floor(rnd()*3),1,shade(base,-48));rect(x,y,1,1+Math.floor(rnd()*3),shade(base,-48));}
  }
  if(pattern==='bark') {
    if(name.includes('birch')||name.includes('poplar'))for(let i=0;i<10;i++)rect(Math.floor(rnd()*13),Math.floor(rnd()*16),2+Math.floor(rnd()*4),1+Math.floor(rnd()*2),'#4c4e44');
    else for(let x=1;x<16;x+=4){rect(x,0,1,16,shade(base,-29));for(let y=0;y<16;y+=5)rect(x+1,y+(x%3),1,3,shade(base,20));}
  }
  if(pattern==='rings')for(let r=7;r>0;r-=2){ctx.strokeStyle=shade(base,r%4===1?-37:19);ctx.lineWidth=1;ctx.strokeRect(7-r+.5,7-r+.5,r*2,r*2);}
  if(pattern==='bricks') {
    const row=4;
    for(let y=0;y<16;y+=row){rect(0,y,16,1,shade(base,-31));rect(0,y+1,16,1,shade(base,21));for(let x=(y/row%2)*4;x<16;x+=8){rect(x,y,1,row,shade(base,-29));rect(x+1,y+2,1,row-2,shade(base,10));}}
    if(name.includes('mossy'))for(let i=0;i<16;i++)rect(Math.floor(rnd()*14),Math.floor(rnd()*14),2,2,i%2?'#527d37':'#6a9848');
  }
  if(pattern==='ore') {
    const ore=name.includes('coal')?'#2b2e2c':name.includes('iron')?'#d4ab8e':name.includes('gold')?'#f0c646':name.includes('emerald')?'#47ce6c':name.includes('lapis')?'#3459b5':name.includes('redstone')?'#d63729':name.includes('copper')?'#d4784d':name.includes('quartz')?'#ebe5d8':'#58e4d8';
    for(let i=0;i<8;i++){const x=1+Math.floor(rnd()*12),y=1+Math.floor(rnd()*12);rect(x,y,3,2,shade(ore,-42));rect(x,y,2,1,ore);rect(x+1,y+1,2,1,shade(ore,24));if(name.includes('copper')&&i%3===0)rect(x+1,y,1,1,'#539c83');}
  }
  if(pattern==='tnt'){
    if(name==='tnt_top'){
      rect(0,0,16,16,'#b53b2e');rect(3,3,10,10,'#d9d4c3');rect(5,5,6,6,'#b53b2e');rect(7,7,2,2,'#d9d4c3');
    }else{
      rect(0,0,16,16,'#b53b2e');rect(0,4,16,8,'#d9d4c3');
      rect(2,6,4,1,'#b53b2e');rect(3,7,2,3,'#b53b2e');
      rect(7,6,4,1,'#b53b2e');rect(7,9,4,1,'#b53b2e');rect(8,7,2,2,'#b53b2e');
      rect(12,6,4,1,'#b53b2e');rect(13,7,2,3,'#b53b2e');
      rect(0,12,16,4,'#8c2b21');rect(0,3,16,1,'#8c2b21');
    }
  }
  if(pattern==='torch') {
    ctx.clearRect(0,0,16,16);
    if(name==='lantern'){
      rect(7,0,2,3,'#5c6360');rect(5,3,6,2,'#464c4a');rect(4,5,8,8,'#3a403e');rect(5,6,6,6,'#f6b949');rect(6,7,4,4,'#fff0a8');rect(5,13,6,2,'#464c4a');
    }else if(name==='lever'){
      rect(6,2,4,3,'#a37c49');rect(7,4,2,9,'#8b673c');rect(5,13,6,3,'#6b706a');
    }else if(name.includes('button')){
      rect(4,4,8,8,base);rect(5,5,6,6,shade(base,22));
    }else{
      rect(7,0,2,2,'#fff9c4');rect(7,1,2,4,'#ffe76b');rect(6,2,4,4,'#f59b28');rect(7,6,2,10,'#7c5b34');rect(7,7,1,5,'#9e7747');
    }
  }
  if(pattern==='glass') {ctx.clearRect(0,0,16,16);rect(0,0,16,16,'rgba(150,207,218,.18)');rect(0,0,16,1,'#b3d4d8');rect(0,0,1,16,'#b3d4d8');rect(15,0,1,16,'#719fa9');rect(0,15,16,1,'#719fa9');for(let i=3;i<10;i++)rect(i,13-i,2,1,'rgba(231,250,247,.6)');}
  if(pattern==='plant') {
    ctx.clearRect(0,0,16,16);
    if(name==='pink_petals'){
      const petals:[[number,number,string],...[number,number,string][]]=[[2,2,'#f7c4d4'],[10,3,'#ef9eb8'],[4,9,'#f4b2c7'],[11,11,'#f8d2df'],[7,6,'#e88ca9']];
      for(const [px,py,col] of petals){rect(px,py,3,2,col);rect(px+1,py+1,2,2,'#fce4ec');}
    }else if(name==='lily_pad'){
      rect(3,2,10,12,'#467a2f');rect(2,3,12,10,'#568e3b');rect(4,4,8,8,'#659f47');ctx.clearRect(8,2,2,5);
    }else if(name==='dead_bush'){
      rect(7,9,2,7,'#7b5834');rect(4,6,3,2,'#8d663d');rect(9,5,3,2,'#8d663d');rect(3,3,2,3,'#7b5834');rect(11,2,2,3,'#7b5834');rect(6,4,2,6,'#9a7146');
    }else if(name==='sugar_cane'){
      for(const x of [3,7,11]){rect(x,1,2,15,'#6fa34f');rect(x+1,2,1,14,'#89bf65');for(let y=3;y<15;y+=4)rect(x-1,y,4,1,'#56853b');}
    }else if(name.includes('mushroom')){
      rect(7,10,2,6,'#dcd3be');rect(4,6,8,4,base);rect(5,4,6,2,base);
      if(name.includes('red')){rect(5,7,2,1,'#f4f2ea');rect(9,6,2,1,'#f4f2ea');rect(7,8,1,1,'#f4f2ea');}
    }else if(name.includes('sapling')){
      rect(7,10,2,6,'#6e5032');rect(4,4,8,6,shade(base,-15));rect(5,3,6,6,base);rect(6,4,3,2,shade(base,22));
    }else if(name==='fern'||name.includes('grass')||name==='wheat_crop'){
      const blades=name==='fern'?8:7;
      for(let i=0;i<blades;i++){const x=1+i*2,h=4+Math.floor(rnd()*8);rect(x,16-h,1,h,shade(base,i%2?16:-20));if(name==='fern'){rect(x-1,16-h+2,3,1,shade(base,12));rect(x-1,16-h+5,3,1,shade(base,-10));}else rect(x-1,15-h,1,3,shade(base,10));}
    }else if(name==='lily_of_the_valley'){
      rect(7,4,1,12,'#54853b');rect(4,9,3,4,'#639746');rect(9,8,3,5,'#639746');
      for(const [bx,by] of [[5,4],[8,6],[5,7]]){rect(bx,by,2,2,'#ffffff');rect(bx,by+1,2,1,'#dbe5dd');}
    }else if(name.includes('tulip')){
      rect(7,8,2,8,'#4e7d38');rect(5,10,2,4,'#629444');rect(9,9,2,4,'#629444');
      rect(5,3,6,5,base);rect(5,2,1,2,shade(base,22));rect(7,2,2,2,shade(base,22));rect(10,2,1,2,shade(base,22));
    }else if(name==='cornflower'){
      rect(7,8,2,8,'#4b7a38');rect(5,10,3,2,'#629444');rect(4,3,8,5,'#3d62c4');rect(5,2,6,6,'#5880e4');rect(7,4,2,2,'#243b82');
    }else if(name==='oxeye_daisy'){
      rect(7,8,2,8,'#4b7a38');rect(4,4,8,4,'#f4f2ea');rect(5,3,6,6,'#ffffff');rect(7,5,2,2,'#ebc23d');
    }else if(name==='dandelion'){
      rect(7,8,2,8,'#4c7939');rect(4,11,4,2,'#649442');rect(5,3,6,5,'#e6be32');rect(4,4,8,3,'#f7d954');rect(6,2,4,6,'#fae373');
    }else {
      rect(7,7,2,9,'#4c7939');rect(4,11,4,2,'#649442');rect(9,9,3,2,'#75a347');rect(5,3,6,5,shade(base,-25));rect(4,4,8,3,base);rect(6,2,4,7,shade(base,14));rect(7,4,2,2,'#2b2421');
    }
  }
  if(pattern==='craft'){
    rect(0,0,16,2,'#5b412b');rect(0,14,16,2,'#5b412b');rect(0,0,2,16,'#6c4a2e');rect(14,0,2,16,'#6c4a2e');
    if(name==='crafting_table_top'){for(let x=5;x<14;x+=4)rect(x,3,1,10,'#674a30');for(let y=5;y<14;y+=4)rect(3,y,10,1,'#674a30');rect(3,3,10,1,'#4d3524');}
    else{rect(4,6,8,1,'#674a30');rect(6,4,4,4,'#8d693f');rect(8,8,5,2,'#5d4229');}
  }
  if(pattern==='furnace'){
    rect(2,2,12,4,'#3b403b');rect(3,3,10,1,'#222a26');rect(3,9,10,5,'#353a35');rect(4,10,8,3,'#202822');rect(4,13,8,1,'#a5a596');
    if(name.startsWith('blast'))rect(2,2,12,3,'#2f3431');
    if(name.startsWith('smoker'))rect(3,8,10,4,'#5e4630');
  }
  if(pattern==='chest'){
    // 前面: 木枠 + 中央の金属留め具
    rect(0,0,16,2,'#503c25');rect(0,14,16,2,'#503c25');rect(0,0,2,16,'#503c25');rect(14,0,2,16,'#503c25');rect(0,6,16,2,'#503c25');
    rect(7,5,3,5,'#d5d8bc');rect(8,7,1,2,'#6b705f');rect(7,5,3,1,'#f2efd6');rect(7,10,3,1,'#8d9276');
    if(name==='barrel_front'){rect(0,2,16,2,'#6b4f2c');rect(0,11,16,2,'#6b4f2c');rect(6,7,4,3,'#c8c2a6');}
  }
  if(pattern==='metal'){
    if(name.endsWith('_helmet')){ctx.clearRect(0,0,16,16);rect(3,3,10,7,base);rect(4,3,8,2,shade(base,28));rect(3,8,3,3,shade(base,-22));rect(10,8,3,3,shade(base,-22));}
    else if(name.endsWith('_chestplate')){ctx.clearRect(0,0,16,16);rect(2,3,12,9,base);rect(4,3,8,11,shade(base,14));ctx.clearRect(6,3,4,2);}
    else if(name.endsWith('_leggings')){ctx.clearRect(0,0,16,16);rect(4,3,3,11,base);rect(9,3,3,11,base);rect(4,3,8,3,shade(base,20));}
    else if(name.endsWith('_boots')){ctx.clearRect(0,0,16,16);rect(2,7,5,6,base);rect(9,7,5,6,base);rect(2,12,5,2,shade(base,-25));rect(9,12,5,2,shade(base,-25));}
    else{rect(2,4,12,8,shade(base,-45));rect(2,4,11,6,base);rect(3,3,9,2,shade(base,30));rect(3,10,10,2,shade(base,-20));}
  }
  if(pattern==='gem'){ctx.clearRect(0,0,16,16);for(let y=3;y<13;y++){const w=y<7?(y-2)*2:12-(y-7)*2;rect(8-w/2,y,w,1,shade(base,(y%3-1)*29));}rect(6,4,2,2,shade(base,60));}
  if(pattern==='food'){ctx.clearRect(0,0,16,16);rect(4,4,8,9,shade(base,-20));rect(3,5,10,6,base);rect(5,3,6,11,base);rect(5,4,3,2,shade(base,45));rect(8,1,1,3,'#735138');rect(9,1,3,2,'#6b9547');}
  return c;
}
function drawItem(def: BlockDef): DrawCanvas {
  if(def.pattern!=='tool'&&def.category!=='tools')return noiseTile(def.name,def.color,tilePattern(def.name,def.pattern),def.id*973+234);
  const c=canvas(16),ctx=c.getContext('2d') as Context2D;
  const r=(x:number,y:number,w:number,h:number,col:string)=>{ctx.fillStyle=col;ctx.fillRect(x,y,w,h);};
  if(def.name==='stick'||def.name==='bone'||def.name==='feather'){for(let i=0;i<10;i++){r(3+i,12-i,2,2,shade(def.color,-30));r(3+i,12-i,1,1,def.color);}return c;}
  if(def.name.includes('bucket')){r(3,5,10,7,'#647779');r(4,6,8,7,'#b4c3c1');r(5,12,6,2,'#839795');r(4,4,8,2,'#d1dad4');if(!def.name.startsWith('bucket'))r(5,5,6,2,def.color);return c;}
  if(def.name==='bow'){for(let i=2;i<14;i++){const x=4+Math.round(Math.sin((i-2)/11*Math.PI)*5);r(x,i,2,1,'#7d5a34');}r(4,2,1,12,'#dcd8c8');return c;}
  if(def.name==='arrow'){for(let i=2;i<13;i++)r(i,14-i,2,1,'#9b7a4a');r(12,1,3,3,'#cdd3cf');r(2,12,3,2,'#efeae0');return c;}
  if(def.name==='fishing_rod'){for(let i=2;i<13;i++)r(i,14-i,2,2,'#8a6539');r(13,4,1,9,'#e4e2d8');r(12,12,3,2,'#d94e3f');return c;}
  if(def.name==='boat'){r(2,7,12,5,'#9c7744');r(3,11,10,2,'#7c5b31');r(4,8,8,2,'#be965b');return c;}
  if(def.name==='minecart'){r(2,5,12,7,'#757d7a');r(3,6,10,5,'#9ca5a1');r(4,12,2,2,'#424745');r(10,12,2,2,'#424745');return c;}
  if(def.name==='book'||def.name==='paper'||def.name==='sign'){r(3,3,10,10,def.color);r(4,4,8,8,shade(def.color,24));if(def.name==='sign')r(7,12,2,4,'#7c5b34');return c;}
  const type=def.name.split('_').pop()||'pickaxe',col=def.color;
  if(type==='sword'){for(let i=0;i<9;i++){r(5+i,10-i,3,2,shade(col,-35));r(5+i,10-i,2,1,shade(col,20));}r(3,10,5,2,'#746041');r(6,12,2,3,'#8c683e');r(2,9,2,3,'#a58b50');r(7,13,2,2,'#a58b50');}
  else {for(let i=0;i<9;i++){r(3+i,12-i,2,2,'#61472d');r(3+i,12-i,1,1,'#b18a51');}
    if(type==='pickaxe'){r(4,2,8,2,shade(col,-30));r(7,1,6,2,col);r(11,3,3,3,col);r(13,5,2,3,shade(col,-25));r(5,2,6,1,shade(col,35));}
    if(type==='axe'){r(7,1,5,5,shade(col,-25));r(6,2,6,3,col);r(7,2,4,1,shade(col,30));}
    if(type==='shovel'){r(10,1,4,5,col);r(9,2,5,3,col);r(10,1,3,1,shade(col,30));}
    if(type==='hoe'){r(6,2,7,2,col);r(12,3,2,3,shade(col,-25));}
  }
  return c;
}
function addTile(name:string,c:DrawCanvas){if(tileIndex.has(name))return;tileIndex.set(name,tileNames.length);tileNames.push(name);tileCanvases.set(name,c);}
for(const b of BLOCKS){
  if(!b.id)continue;
  const faces=new Set([0,1,2,3,4,5].map(f=>faceTile(b,f)));
  for(const name of faces){
    const grassSide=b.pattern==='grass'&&name.endsWith('_side');
    const base=grassSide?'#8a6244':b.color;
    const c=noiseTile(name,base,tilePattern(name,b.pattern),b.id*973+name.length*41);
    if(grassSide){const ctx=c.getContext('2d') as Context2D;ctx.fillStyle=b.color;ctx.fillRect(0,0,16,3);for(let x=0;x<16;x++)if((x*7+b.id)%3!==0)ctx.fillRect(x,3,1,1+(x%2));}
    addTile(name,c);
  }
}
for(const it of ITEMS)addTile(it.name,drawItem(it));
for(let i=0;i<10;i++){const c=canvas(16),ctx=c.getContext('2d') as Context2D;ctx.strokeStyle='rgba(31,27,22,.8)';ctx.lineWidth=1;const rnd=random(567);for(let j=0;j<=i+2;j++){ctx.beginPath();let x=8,y=8;ctx.moveTo(x,y);for(let k=0;k<3+i;k++){x+=Math.floor(rnd()*5)-2;y+=Math.floor(rnd()*5)-2;ctx.lineTo(x,y);}ctx.stroke();}addTile('crack_'+i,c);}
export const atlasRows=Math.ceil(tileNames.length/ATLAS_COLS);
export const atlasCanvas=canvas(ATLAS_COLS*TILE,atlasRows*TILE);
const atlasContext=atlasCanvas.getContext('2d') as Context2D;
for(let i=0;i<tileNames.length;i++){const c=tileCanvases.get(tileNames[i])!,x=i%ATLAS_COLS*TILE,y=Math.floor(i/ATLAS_COLS)*TILE;atlasContext.drawImage(c,x+2,y+2);atlasContext.drawImage(c,0,0,16,1,x+2,y,16,2);atlasContext.drawImage(c,0,15,16,1,x+2,y+18,16,2);atlasContext.drawImage(c,0,0,1,16,x,y+2,2,16);atlasContext.drawImage(c,15,0,1,16,x+18,y+2,2,16);}
export function makeAtlasTexture(){const t=new THREE.CanvasTexture(atlasCanvas as HTMLCanvasElement);t.magFilter=THREE.NearestFilter;t.minFilter=THREE.NearestFilter;t.generateMipmaps=false;t.flipY=false;t.colorSpace=THREE.SRGBColorSpace;return t;}
export function tileOf(name:string){return tileIndex.get(name)??tileIndex.get('stone')??0;}
export function tilesFor(id:number){const b=BLOCKS[id];return [0,1,2,3,4,5].map(f=>tileOf(faceTile(b,f)));}
function toDataURL(c:DrawCanvas){return (c as HTMLCanvasElement).toDataURL?.()??'';}
const iconCache=new Map<string,string>();
export function iconUrl(name:string){
  const cached=iconCache.get(name);if(cached!==undefined)return cached;
  let source=tileCanvases.get(name);
  const id=ID[name];if(!source&&id!==undefined)source=tileCanvases.get(faceTile(BLOCKS[id],4))??tileCanvases.get(faceTile(BLOCKS[id],2));
  const url=source?toDataURL(source):'';iconCache.set(name,url);return url;
}
export function itemIcon(name:string){return iconUrl(name)||iconUrl('stone');}
export const atlasTiles=()=>tileNames.map((name,index)=>({name,index,canvas:tileCanvases.get(name)!}));
export const tileColor=(id:number)=>BLOCKS[id]?.color??'#82966a';
