import type { BlockDef } from './data';

// A cell keeps its block ID in the low 12 bits and its state in the high 4.
// Old saves contain plain IDs and therefore naturally decode to state zero.
export const BLOCK_ID_MASK = 0x0fff;
export const STATE_SHIFT = 12;
export type Facing = 0 | 1 | 2 | 3;
export type Face = 0 | 1 | 2 | 3 | 4 | 5;
export const FACING_FACES: readonly Face[] = [4, 1, 5, 0];

export function blockId(cell: number): number {
  return cell < 0 ? cell : cell & BLOCK_ID_MASK;
}

export function blockState(cell: number): number {
  return cell < 0 ? 0 : (cell >>> STATE_SHIFT) & 15;
}

export function makeCell(id: number, state = 0): number {
  if (!Number.isInteger(id) || id < 0 || id > BLOCK_ID_MASK || !Number.isInteger(state) || state < 0 || state > 15) {
    throw new RangeError('Invalid block ID or block state');
  }
  return id === 0 ? 0 : id | (state << STATE_SHIFT);
}

// The camera looks along -Z at yaw 0; the opening faces the player.
export function facingForYaw(yaw: number): Facing {
  return ((Math.round(-yaw / (Math.PI / 2)) % 4 + 4) % 4) as Facing;
}

export function isHorizontalFacing(name: string): boolean {
  return name === 'chest' || name === 'furnace' || name === 'blast_furnace' || name === 'smoker';
}

export function isAxisBlock(name: string): boolean {
  return name.endsWith('_log');
}

export function isSlabBlock(def: BlockDef): boolean {
  return def.shape === 'slab' && def.name.endsWith('_slab');
}

export function isUpperPlacement(normal: { y:number }, hitY: number): boolean {
  return normal.y < 0 || (normal.y === 0 && hitY > .5);
}

export function stateForPlacement(def: BlockDef, yaw: number, normal: { x: number; y: number; z: number }, hitY = 0): number {
  if (isHorizontalFacing(def.name)) return facingForYaw(yaw);
  if (isAxisBlock(def.name)) return normal.x !== 0 ? 1 : normal.z !== 0 ? 2 : 0;
  if (isSlabBlock(def)) return isUpperPlacement(normal,hitY) ? 1 : 0;
  if (def.shape === 'stairs') return facingForYaw(yaw) | (isUpperPlacement(normal,hitY) ? 4 : 0);
  return 0;
}

// faceTile describes an unrotated block whose front is on +Z.
export function localFaceForState(def: BlockDef, state: number, worldFace: Face): Face {
  if (isAxisBlock(def.name)) {
    const axis = state & 3;
    if (axis === 1) return worldFace < 2 ? 2 : 0;
    if (axis === 2) return worldFace >= 4 ? 2 : 0;
    return worldFace;
  }
  if (!isHorizontalFacing(def.name) || worldFace === 2 || worldFace === 3) return worldFace;
  const worldIndex = FACING_FACES.indexOf(worldFace);
  return FACING_FACES[(worldIndex - (state & 3) + 4) % 4];
}