import * as THREE from 'three';
import ChunkWorker from '../world/chunk.worker?worker&inline';
import { Terrain, MIN_Y, HEIGHT, blockIndex } from '../world/terrain';
import { BLOCKS, ID, resolve } from './data';
import { blockId, blockState, isSlabBlock, makeCell, stateForPlacement } from './blockState';
import { collisionBoxes, intersectsBox } from '../world/shapes';
import { traceVoxelRay } from '../world/raycast';
import { tilesFor, atlasTiles, itemIcon } from '../textures/atlas';
import type { MeshData } from '../world/mesher';
import { InputController } from '../input/controller';
import { Environment } from '../render/environment';
import { DEFAULT_SETTINGS, EMPTY_SNAPSHOT, type Settings, type WorldMeta, type WorldSave, type GameSnapshot, type Stack, type Dimension, type Screen } from './types';
import { clamp } from '../input/math';
import type { ProceduralAudio } from '../audio/sound';
import './content';
import { ParticleSystem } from '../render/particles';
import { MobManager, type Species } from '../entities/mobs';
import { Simulation } from '../systems/simulation';
import { RECIPES, SMELTING, FUEL, canCraft, recipeCounts } from '../systems/crafting';
import { blockDrops, blockExperience, miningTime } from '../systems/mining';
interface Chunk { data:Uint16Array;solid:THREE.Mesh;water:THREE.Mesh;version:number; }
interface Target {x:number;y:number;z:number;id:number;normal:THREE.Vector3;distance:number;}
interface WorkerSlot {worker:Worker;busy:boolean;key?:string;epoch?:number;}
interface DimensionStore {edits:Map<string,number>;containers:Record<string,(Stack|null)[]>;furnaces:Record<string,{burn:number;progress:number}>;}
export const DEFAULT_WORLD:WorldMeta={id:'greenwood',name:'はじまりの森',seed:'849281',mode:'creative',difficulty:'normal',hardcore:false,structures:true,bonus:true,cheats:true,created:Date.now(),updated:Date.now(),playTime:0};
export class Engine {
  renderer:THREE.WebGLRenderer;scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(58,1,.05,480);environment:Environment;input:InputController;terrain=new Terrain(DEFAULT_WORLD.seed);
  chunks=new Map<string,Chunk>();workers:WorkerSlot[]=[];queue:string[]=[];queued=new Set<string>();pending=new Set<string>();versions=new Map<string,number>();edits=new Map<string,number>();tiles=BLOCKS.map(b=>tilesFor(b.id));
  settings:Settings={...DEFAULT_SETTINGS};meta:WorldMeta={...DEFAULT_WORLD};dimension:Dimension='overworld';position=new THREE.Vector3(-11,28,27);velocity=new THREE.Vector3();active=false;ready=false;grounded=false;flying=false;time=.2;elapsed=0;selected=0;weather:'clear'|'rain'|'storm'='clear';weatherTimer=25;hotbar:(Stack|null)[]=[];inventory:(Stack|null)[]=Array(27).fill(null);health=20;hunger=20;oxygen=20;xp=0;statistics:Record<string,number>={};achievements:string[]=[];containers:Record<string,(Stack|null)[]>={};target:Target|null=null;breaking=0;breakKey='';breakCooldown=0;debug=false;dead=false;thirdPerson=false;
  outline:THREE.LineSegments;crack:THREE.Mesh;crackMaterials:THREE.MeshBasicMaterial[]=[];hand:THREE.Mesh;handMaterial:THREE.MeshLambertMaterial;lastHand='';
  private raf=0;private last=0;private snapshotAt=0;private streamAt=-10;private focus='';private disposed=false;private frameCount=0;private fps=60;private fpsAt=0;private pendingPlay=false;private worldEpoch=0;private biomeKey='';private currentBiome='plains';private dimensionStores:Partial<Record<Dimension,DimensionStore>>={};private stationsInMenu=false;private stationCursor=0;audio:ProceduralAudio|null=null;private stepAt=0;private hitAt=0;particles!:ParticleSystem;mobs!:MobManager;simulation!:Simulation;stationKey='';furnaces:Record<string,{burn:number;progress:number}>={};explosionQueue:[number,number,number][]=[];respawnPoint:[number,number,number]|null=null;private survivalTick=0;private mobHitAt=0;private fallTop=0;private resizeObserver:ResizeObserver;private lastShadow=0;private fallbackNotified=false;private autoSaveAt=0;private listeners:(()=>void)[]=[];
  constructor(public canvas:HTMLCanvasElement,public onSnapshot:(s:GameSnapshot)=>void,public onScreen:(s:Screen)=>void,public onToast:(ja:string,en:string)=>void,public onSave:(save:WorldSave)=>void){
    this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.25));this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.08;this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=THREE.PCFShadowMap;this.renderer.shadowMap.autoUpdate=false;
    this.environment=new Environment(this.scene,this.renderer,this.settings);this.input=new InputController(canvas,this.settings,a=>this.action(a));
    this.particles=new ParticleSystem(this.scene);
    this.simulation=new Simulation({getBlock:(x,y,z)=>this.getBlock(x,y,z),setBlock:(x,y,z,id)=>this.setBlock(x,y,z,id),explode:(p,r)=>this.explode(p,r),toast:(j,e)=>this.onToast(j,e),sound:(k,p)=>this.audio?.play(k,p)});
    this.mobs=new MobManager(this.scene,{terrain:this.terrain,position:this.position,camera:this.camera,get time(){return 0;},dimension:this.dimension,getBlock:(x,y,z)=>this.getBlock(x,y,z),damage:n=>this.damage(n),addItem:(n,c)=>this.addItem(n,c),toast:(j,e)=>this.onToast(j,e),sound:(k,p)=>this.audio?.play(k,p),explode:(p,r)=>this.explode(p,r),openTrade:()=>{this.pause(true);this.onScreen('trade');},particles:this.particles});
    this.outline=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(1.006,1.006,1.006)),new THREE.LineBasicMaterial({color:'#20291e',transparent:true,opacity:.8}));this.outline.visible=false;this.scene.add(this.outline);
    const cracks=atlasTiles().filter(t=>t.name.startsWith('crack_'));this.crackMaterials=cracks.map(t=>{const texture=new THREE.CanvasTexture(t.canvas as HTMLCanvasElement);texture.magFilter=THREE.NearestFilter;return new THREE.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2});});this.crack=new THREE.Mesh(new THREE.BoxGeometry(1.009,1.009,1.009),this.crackMaterials[0]);this.crack.visible=false;this.scene.add(this.crack);
    this.handMaterial=new THREE.MeshLambertMaterial({color:'#b49b6b'});this.hand=new THREE.Mesh(new THREE.BoxGeometry(.27,.27,.27),this.handMaterial);this.hand.position.set(.43,-.34,-.65);this.hand.rotation.set(.2,-.5,.1);this.hand.visible=false;this.camera.add(this.hand);this.scene.add(this.camera);
    const count=Math.min(4,Math.max(2,(navigator.hardwareConcurrency||4)-1));for(let i=0;i<count;i++){const worker=new ChunkWorker(),slot:WorkerSlot={worker,busy:false};worker.onmessage=e=>this.receive(e.data,slot);worker.onerror=()=>{slot.busy=false;if(slot.epoch===this.worldEpoch&&slot.key){this.pending.delete(slot.key);this.invalidate(slot.key);}this.onToast('地形生成を再試行しています','Retrying terrain generation');this.streamAt=-10;};this.workers.push(slot);}
    this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(canvas);this.resize();
    const save=()=>{if(this.active)this.save();};window.addEventListener('blur',save);document.addEventListener('visibilitychange',save);this.listeners.push(()=>window.removeEventListener('blur',save),()=>document.removeEventListener('visibilitychange',save));
    this.defaultInventory();this.raf=requestAnimationFrame(this.frame);
  }
  resize(){const w=this.canvas.clientWidth||innerWidth,h=this.canvas.clientHeight||innerHeight;this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();}
  setSettings(settings:Settings){this.settings={...settings};this.input.settings=this.settings;this.renderer.setPixelRatio(Math.min(devicePixelRatio,settings.quality==='low'?1:settings.quality==='medium'?1.1:settings.quality==='ultra'?1.7:1.25));this.renderer.shadowMap.enabled=settings.quality!=='low';this.environment.markShadow();this.camera.fov=this.active?settings.fov:58;this.camera.updateProjectionMatrix();this.streamAt=-10;this.resize();}
  defaultInventory(){const names=this.meta.mode==='creative'?['grass_block','oak_log','oak_planks','stone_bricks','glass','oak_leaves','torch','crafting_table','water_bucket']:['wooden_pickaxe','wooden_axe','oak_log','oak_planks','torch','apple','crafting_table','cobblestone','bucket'];this.hotbar=names.map(name=>({name,count:this.meta.mode==='creative'?64:name==='apple'?8:resolve(name)?.stack===1?1:32}));this.inventory=Array(27).fill(null);if(this.meta.bonus&&this.meta.mode!=='creative'){this.inventory[0]={name:'bread',count:8};this.inventory[1]={name:'coal',count:8};this.inventory[2]={name:'wheat_seeds',count:8};}}
  start(meta:WorldMeta,save?:WorldSave){
    this.active=false;this.pendingPlay=true;this.ready=false;this.meta={...meta};this.dimension=save?.dimension??'overworld';
    this.dimensionStores={};
    for(const dimension of ['overworld','nether','end'] as const){
      const state=save?.dimensions?.[dimension];
      const legacy=save&&!save.dimensions&&dimension===this.dimension;
      this.dimensionStores[dimension]={edits:new Map(state?.edits??(legacy?save.edits:[])),containers:state?.containers??(legacy?save.containers??{}:{}),furnaces:state?.furnaces??(legacy?save.furnaces??{}:{})};
    }
    this.attachDimensionStore(this.dimension);
    this.terrain=new Terrain(meta.seed,this.dimension);this.mobs.host.terrain=this.terrain;this.mobs.host.dimension=this.dimension;
    this.mobs.clear();this.particles.clear();this.simulation.clear();this.respawnPoint=null;this.clearChunks();
    this.time=save?.time??.2;this.position.set(...(save?.position??[-11,this.terrain.height(-11,27)+1.05,27]));
    this.mobs.populate();this.velocity.set(0,0,0);this.input.yaw=save?.yaw??-.55;this.input.pitch=save?.pitch??-.08;
    this.health=save?.health??20;this.hunger=save?.hunger??20;this.xp=save?.xp??0;this.statistics=save?.statistics??{};this.achievements=save?.achievements??[];
    this.selected=save?.selected??0;this.flying=false;this.dead=false;this.oxygen=20;this.defaultInventory();if(save){this.hotbar=save.hotbar;this.inventory=save.inventory;}
    this.focus='';this.streamAt=-10;this.autoSaveAt=this.elapsed;this.camera.fov=this.settings.fov;this.camera.updateProjectionMatrix();this.onScreen('loading');
  }
  private attachDimensionStore(dimension:Dimension){
    const store=this.dimensionStores[dimension]??={edits:new Map(),containers:{},furnaces:{}};
    this.edits=store.edits;this.containers=store.containers;this.furnaces=store.furnaces;
  }
  activate(){if(!this.ready)return;this.stationsInMenu=false;this.active=true;this.input.setActive(true);this.hand.visible=true;this.environment.markShadow();}
  pause(keepStationsRunning=false){this.stationsInMenu=keepStationsRunning;this.active=false;this.input.setActive(false);this.hand.visible=false;this.outline.visible=false;this.crack.visible=false;}
  title(){this.save();this.pendingPlay=false;this.pause();this.meta={...DEFAULT_WORLD};this.terrain=new Terrain(DEFAULT_WORLD.seed);this.dimension='overworld';this.mobs.host.terrain=this.terrain;this.mobs.host.dimension=this.dimension;this.mobs.clear();this.mobs.populate();this.particles.clear();this.simulation.clear();this.clearChunks();this.dimensionStores={};this.attachDimensionStore('overworld');this.focus='';this.streamAt=-10;this.ready=false;this.time=.2;this.camera.fov=58;this.camera.updateProjectionMatrix();}
  clearChunks(){this.worldEpoch++;for(const c of this.chunks.values())this.disposeChunk(c);this.chunks.clear();this.queue=[];this.queued.clear();this.pending.clear();this.versions.clear();}
  disposeChunk(c:Chunk){this.scene.remove(c.solid,c.water);c.solid.geometry.dispose();c.water.geometry.dispose();}
  action(action:string){
    if(action==='escape'){if(this.dead)return;if(this.active){this.pause();this.onScreen('pause');}else this.onScreen('escape');return;}
    if(!this.active)return;
    if(action==='inventory'){this.pause(true);this.onScreen('inventory');}
    else if(action==='chat'||action==='slash'){this.pause(true);this.onScreen('chat');}
    else if(action==='debug')this.debug=!this.debug;
    else if(action==='perspective')this.thirdPerson=!this.thirdPerson;
    else if(action==='fly'&&this.meta.mode==='creative'){this.flying=!this.flying;this.velocity.y=0;this.onToast(this.flying?'飛行モード':'歩行モード',this.flying?'Flight enabled':'Flight disabled');}
    else if(action.startsWith('slot:')){const s=action.slice(5);this.select(s==='next'?(this.selected+1)%9:s==='previous'?(this.selected+8)%9:Number(s));}
    else if(action==='use')this.use();else if(action==='drop')this.dropSelected();
  }
  select(slot:number){this.selected=clamp(slot,0,8);this.breaking=0;}
  getCell(x:number,y:number,z:number){x=Math.floor(x);y=Math.floor(y);z=Math.floor(z);if(y<MIN_Y)return ID.bedrock;if(y>=MIN_Y+HEIGHT)return 0;const cx=Math.floor(x/16),cz=Math.floor(z/16),chunk=this.chunks.get(cx+','+cz);if(!chunk)return -1;return chunk.data[blockIndex(x-cx*16,y,z-cz*16)];}
  getBlock(x:number,y:number,z:number){return blockId(this.getCell(x,y,z));}
  setBlock(x:number,y:number,z:number,id:number,state=0){
    x=Math.floor(x);y=Math.floor(y);z=Math.floor(z);
    if(y<MIN_Y||y>=MIN_Y+HEIGHT||!BLOCKS[id]||!Number.isInteger(state)||state<0||state>15)return false;
    const cx=Math.floor(x/16),cz=Math.floor(z/16),chunk=this.chunks.get(cx+','+cz);if(!chunk)return false;
    const lx=x-cx*16,lz=z-cz*16,index=blockIndex(lx,y,lz),previous=chunk.data[index],cell=makeCell(id,state);
    if(previous===cell)return false;
    const previousId=blockId(previous),key=`${x},${y},${z}`;
    if(previousId!==id&&[ID.chest,ID.barrel,ID.furnace,ID.blast_furnace,ID.smoker].includes(previousId)){
      for(const stack of this.containers[key]??[])if(stack)this.particles.drop(new THREE.Vector3(x+.5,y+.5,z+.5),stack.name,stack.count,resolve(stack.name)?.color??'#aaa');
      delete this.containers[key];delete this.furnaces[key];
    }
    chunk.data[index]=cell;this.edits.set(key,cell);
    const dxs=lx===0?[-1,0]:lx===15?[0,1]:[0],dzs=lz===0?[-1,0]:lz===15?[0,1]:[0];
    for(const dz of dzs)for(const dx of dxs){const neighbor=(cx+dx)+','+(cz+dz);if(this.chunks.has(neighbor)||this.pending.has(neighbor))this.invalidate(neighbor);}
    this.simulation.notify(x,y,z,id);this.environment.markShadow();return true;
  }
  invalidate(key:string){this.versions.set(key,(this.versions.get(key)??0)+1);if(!this.queued.has(key)){this.queue.unshift(key);this.queued.add(key);}}
  stream(){
    const p=this.pendingPlay||this.active||this.ready?this.position:new THREE.Vector3(0,24,0),cx=Math.floor(p.x/16),cz=Math.floor(p.z/16),radius=this.settings.distance,focus=cx+','+cz+','+radius+','+this.dimension;
    if(focus===this.focus)return;this.focus=focus;
    const desired:{key:string;d:number}[]=[];for(let z=-radius;z<=radius;z++)for(let x=-radius;x<=radius;x++){if(x*x+z*z>(radius+.5)**2)continue;const key=(cx+x)+','+(cz+z);desired.push({key,d:x*x+z*z});}
    desired.sort((a,b)=>a.d-b.d);for(const {key} of desired)if(!this.chunks.has(key)&&!this.queued.has(key)&&!this.pending.has(key)){this.queue.push(key);this.queued.add(key);}
    for(const [key,c] of this.chunks){const [x,z]=key.split(',').map(Number);if(Math.hypot(x-cx,z-cz)>radius+2){this.disposeChunk(c);this.chunks.delete(key);}}
    this.queue=this.queue.filter(key=>{const [x,z]=key.split(',').map(Number);if(Math.hypot(x-cx,z-cz)>radius+2){this.queued.delete(key);return false;}return true;});
  }
  dispatch(){for(const slot of this.workers){
    if(slot.busy||!this.queue.length)continue;
    const next=this.queue.findIndex(key=>!this.pending.has(key));if(next<0)continue;
    const [key]=this.queue.splice(next,1);this.queued.delete(key);
    const [cx,cz]=key.split(',').map(Number),version=this.versions.get(key)??0;
    slot.busy=true;slot.key=key;slot.epoch=this.worldEpoch;this.pending.add(key);
    const edits=[...this.edits].filter(([k])=>{const [x,,z]=k.split(',').map(Number);return Math.abs(Math.floor(x/16)-cx)<=1&&Math.abs(Math.floor(z/16)-cz)<=1;});
    slot.worker.postMessage({key,cx,cz,version,epoch:this.worldEpoch,seed:this.meta.seed,dimension:this.dimension,edits,structures:this.meta.structures,tiles:this.tiles});
  }}
  geometry(m:MeshData){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(m.position,3));g.setAttribute('normal',new THREE.BufferAttribute(m.normal,3));g.setAttribute('uv',new THREE.BufferAttribute(m.uv,2));g.setAttribute('color',new THREE.BufferAttribute(m.color,3));g.setAttribute('tile',new THREE.BufferAttribute(m.tile,1));g.setAttribute('wind',new THREE.BufferAttribute(m.wind,1));g.setIndex(new THREE.BufferAttribute(m.index,1));g.computeBoundingSphere();return g;}
  receive(m:any,slot:WorkerSlot){
    slot.busy=false;if(this.disposed||m.epoch!==this.worldEpoch)return;
    this.pending.delete(m.key);
    if(m.type==='error'){this.invalidate(m.key);this.onToast('チャンクを再生成しています','Regenerating chunk');return;}
    if((this.versions.get(m.key)??0)!==m.version){if(!this.queued.has(m.key)){this.queue.unshift(m.key);this.queued.add(m.key);}return;}
    const old=this.chunks.get(m.key);if(old)this.disposeChunk(old);
    const solid=new THREE.Mesh(this.geometry(m.solid),this.environment.failed?this.environment.fallback:this.environment.material),water=new THREE.Mesh(this.geometry(m.water),this.environment.water);
    solid.position.set(m.cx*16,0,m.cz*16);water.position.copy(solid.position);const pcx=Math.floor(this.position.x/16),pcz=Math.floor(this.position.z/16);solid.castShadow=Math.hypot(m.cx-pcx,m.cz-pcz)<=2;solid.receiveShadow=true;water.renderOrder=2;this.scene.add(solid,water);this.chunks.set(m.key,{data:new Uint16Array(m.data),solid,water,version:m.version});
  }
  collides(p:THREE.Vector3){
    const height=this.input.crouch&&!this.flying?1.5:1.8,minX=p.x-.29,maxX=p.x+.29,minY=p.y+.001,maxY=p.y+height-.001,minZ=p.z-.29,maxZ=p.z+.29;
    for(let y=Math.floor(minY);y<=Math.floor(maxY);y++)for(let z=Math.floor(minZ);z<=Math.floor(maxZ);z++)for(let x=Math.floor(minX);x<=Math.floor(maxX);x++){
      const cell=this.getCell(x,y,z),id=blockId(cell);if(id===-1)return true;
      const def=BLOCKS[id];if(!def?.solid)continue;
      for(const box of collisionBoxes(def,blockState(cell)))if(intersectsBox(x,y,z,minX,minY,minZ,maxX,maxY,maxZ,box))return true;
    }
    return false;
  }
  supported(p:THREE.Vector3){const probe=new THREE.Vector3(p.x,p.y-.08,p.z);return this.collides(probe);}
  physics(dt:number){
    const input=this.input,move=input.move,water=this.getBlock(this.position.x,this.position.y+.6,this.position.z)===ID.water,spectator=this.meta.mode==='spectator';
    let speed=this.flying?(input.run?15:9):water?2.8:input.crouch?1.6:input.run?6.5:4.3;if(spectator)speed=12;
    if(this.flying||spectator)this.velocity.y=(+input.ascend-+input.crouch)*speed;else if(water){this.velocity.y+=(-3-this.velocity.y*3)*dt;if(input.ascend)this.velocity.y=3.5;this.fallTop=this.position.y;}else{this.velocity.y-=24*dt;if(input.ascend&&this.grounded){this.velocity.y=8.2;this.grounded=false;}}
    const old=this.position.clone(),wasGrounded=this.grounded;this.grounded=false;
    for(const axis of ['x','z'] as const){const prev=this.position[axis];this.position[axis]+=move[axis]*speed*dt;if(!spectator&&this.collides(this.position)){let stepped=false;if(wasGrounded&&!input.crouch&&!this.flying){this.position.y+=.6;if(!this.collides(this.position))stepped=true;else this.position.y-=.6;}if(!stepped)this.position[axis]=prev;}
      if(input.crouch&&!this.flying&&!spectator&&wasGrounded&&!this.supported(this.position)){this.position[axis]=prev;}}
    const py=this.position.y,verticalMove=this.velocity.y*dt;this.position.y+=verticalMove;
    if(!spectator&&this.collides(this.position)){
      let safe=0,blocked=1;
      for(let i=0;i<12;i++){const mid=(safe+blocked)/2;this.position.y=py+verticalMove*mid;if(this.collides(this.position))blocked=mid;else safe=mid;}
      this.position.y=py+verticalMove*safe;
      if(this.velocity.y<0){this.grounded=true;const fall=this.fallTop-this.position.y;if(fall>3.5&&!water&&!this.flying)this.damage(Math.floor(fall-3));this.fallTop=this.position.y;}
      this.velocity.y=0;
    }
    if(this.grounded||this.flying||water)this.fallTop=this.position.y;else this.fallTop=Math.max(this.fallTop,this.position.y);
    if(this.position.y<MIN_Y-10){if(this.meta.mode==='creative'){this.position.y=70;this.velocity.y=0;}else this.damage(20);}
    if(wasGrounded&&this.position.distanceTo(old)>.01){this.statistics.distance_walked=(this.statistics.distance_walked??0)+this.position.distanceTo(old);if(this.elapsed-this.stepAt>.38){this.stepAt=this.elapsed;const ground=BLOCKS[this.getBlock(this.position.x,this.position.y-.1,this.position.z)];this.audio?.play(water?'water':ground?.tool==='pickaxe'?'stone':ground?.tool==='axe'?'wood':'grass');}}
    this.camera.position.copy(this.position);this.camera.position.y+=input.crouch?1.42:1.62;if(this.settings.bobbing&&this.grounded)this.camera.position.y+=Math.sin(this.elapsed*11)*Math.min(.035,move.x**2+move.z**2)*.035;
  }
  raycast():Target|null{
    const origin=this.camera.position,cosPitch=Math.cos(this.input.pitch);
    const hit=traceVoxelRay([origin.x,origin.y,origin.z],[-Math.sin(this.input.yaw)*cosPitch,Math.sin(this.input.pitch),-Math.cos(this.input.yaw)*cosPitch],this.meta.mode==='creative'?5.2:4.5,(x,y,z)=>this.getCell(x,y,z));
    return hit?{...hit,normal:new THREE.Vector3(hit.normal.x,hit.normal.y,hit.normal.z)}:null;
  }
  mining(dt:number){this.breakCooldown=Math.max(0,this.breakCooldown-dt);this.target=this.raycast();this.outline.visible=!!this.target;this.crack.visible=false;if(this.target)this.outline.position.set(this.target.x+.5,this.target.y+.5,this.target.z+.5);
    if(!this.input.mining||!this.target||this.breakCooldown>0||this.meta.mode==='spectator'||this.meta.mode==='adventure'){this.breaking=0;return;}
    if(this.elapsed-this.hitAt>.27){this.hitAt=this.elapsed;this.audio?.play(BLOCKS[this.target.id].tool==='pickaxe'?'stone':'wood',this.target);}
    const t=this.target,b=BLOCKS[t.id],held=this.hotbar[this.selected],tool=held?resolve(held.name):undefined,key=`${t.x},${t.y},${t.z}:${this.selected}:${held?.name??''}`;
    if(key!==this.breakKey){this.breakKey=key;this.breaking=0;}if(!Number.isFinite(b.hardness))return;
    if(this.meta.mode==='creative'&&(tool?.tool==='sword'||['trident','mace','debug_stick'].includes(tool?.name??'')))return;
    if(this.meta.mode!=='creative'&&t.distance>2.5&&this.elapsed-this.mobHitAt>.45){const dir=new THREE.Vector3();this.camera.getWorldDirection(dir);if(this.mobs.hit(this.camera.position,dir,tool?.damage??1)){this.mobHitAt=this.elapsed;this.breaking=0;return;}}
    const underwater=this.getBlock(this.camera.position.x,this.camera.position.y,this.camera.position.z)===ID.water;
    const duration=this.meta.mode==='creative'?0:miningTime(b,tool,this.grounded,underwater);
    this.breaking+=duration===0?1:dt/duration;
    if(this.breaking>=1){
      this.particles.burst(new THREE.Vector3(t.x+.5,t.y+.5,t.z+.5),b.color,18);
      if(this.meta.mode!=='creative'){
        for(const drop of blockDrops(b,tool,blockState(this.getCell(t.x,t.y,t.z))))this.particles.drop(new THREE.Vector3(t.x+.5,t.y+.5,t.z+.5),drop.name,drop.count,resolve(drop.name)?.color??b.color);
        if(held&&tool?.durability&&b.hardness>0){held.durability=(held.durability??tool.durability)-1;if(held.durability<=0)this.hotbar[this.selected]=null;}
      }
      this.setBlock(t.x,t.y,t.z,0);this.audio?.play(b.tool==='pickaxe'?'stone':'grass',t);this.statistics.blocks_mined=(this.statistics.blocks_mined??0)+1;if(this.meta.mode!=='creative')this.xp+=blockExperience(b,tool);this.breaking=0;this.breakCooldown=this.meta.mode==='creative'?.25:duration===0?0:.3;this.achievement('mine');}
    else if(this.meta.mode!=='creative'){this.crack.visible=true;this.crack.position.copy(this.outline.position);this.crack.material=this.crackMaterials[Math.min(9,Math.floor(this.breaking*10))];}
  }
  use(){if(this.dead)return;this.target=this.raycast();const held=this.hotbar[this.selected],def=held?resolve(held.name):undefined;if(def?.food){if(this.hunger>=20&&this.meta.mode!=='creative')return;this.hunger=Math.min(20,this.hunger+def.food);this.health=Math.min(20,this.health+1);if(this.meta.mode!=='creative')this.consumeSelected();return;}
    const dir=new THREE.Vector3();this.camera.getWorldDirection(dir);if(held&&['wheat','bucket','shears'].includes(held.name)&&this.mobs.interact(this.camera.position,dir,held.name))return;
    const t=this.target;if(!t)return;if(!this.input.crouch){this.stationKey=`${t.x},${t.y},${t.z}`;if(t.id===ID.crafting_table){this.pause(true);this.onScreen('workbench');return;}if([ID.furnace,ID.blast_furnace,ID.smoker].includes(t.id)){this.containers[this.stationKey]??=[null,null,null];this.furnaces[this.stationKey]??={burn:0,progress:0};this.pause(true);this.onScreen('furnace');return;}if(t.id===ID.chest||t.id===ID.barrel){
      const above=BLOCKS[this.getBlock(t.x,t.y+1,t.z)];
      if(t.id===ID.chest&&above?.solid&&!above.transparent&&above.shape==='cube'){this.onToast('チェストの上がふさがっています','The chest is blocked');return;}
      this.containers[this.stationKey]??=Array(27).fill(null);this.pause(true);this.onScreen('container');return;
    }if(t.id===ID.lever){this.simulation.toggleLever(t.x,t.y,t.z);return;}if(t.id===ID.tnt){this.simulation.enqueue(t.x,t.y,t.z,ID.tnt);return;}if(BLOCKS[t.id].shape==='door'){const name=BLOCKS[t.id].name.replace(/^open_/,'');this.setBlock(t.x,t.y,t.z,ID['open_'+name]);return;}if(BLOCKS[t.id].name.startsWith('open_')){this.setBlock(t.x,t.y,t.z,ID[BLOCKS[t.id].name.replace(/^open_/,'')]);return;}if(t.id===ID.bed){this.respawnPoint=[t.x,t.y+1,t.z];this.onToast('リスポーン地点を設定しました','Respawn point set');return;}if(t.id===ID.portal){this.changeDimension(this.dimension==='nether'?'overworld':'nether');return;}if(t.id===ID.end_portal){this.changeDimension('end');return;}}
    if(!held)return;let name=held.name;if(name==='water_bucket')name='water';const id=ID[name];if(id===undefined)return;
    const placedDef=BLOCKS[id],p=this.position;
    if(id===t.id&&isSlabBlock(placedDef)){
      const current=blockState(this.getCell(t.x,t.y,t.z));
      const canCombine=current===0&&t.normal.y===1||current===1&&t.normal.y===-1;
      if(canCombine){
        for(const box of collisionBoxes(placedDef,2))if(intersectsBox(t.x,t.y,t.z,p.x-.3,p.y,p.z-.3,p.x+.3,p.y+1.8,p.z+.3,box))return;
        if(this.setBlock(t.x,t.y,t.z,id,2)){this.statistics.blocks_placed=(this.statistics.blocks_placed??0)+1;this.audio?.play('place',t);if(this.meta.mode!=='creative')this.consumeSelected();this.achievement('place');}return;
      }
    }
    const x=t.x+t.normal.x,y=t.y+t.normal.y,z=t.z+t.normal.z;if(y>=MIN_Y+HEIGHT||y<MIN_Y)return;
    const existing=this.getBlock(x,y,z);if(existing<0||existing>0&&BLOCKS[existing]?.solid)return;
    const hitY=this.camera.position.y+Math.sin(this.input.pitch)*t.distance-t.y;
    const state=stateForPlacement(placedDef,this.input.yaw,t.normal,hitY);
    for(const box of collisionBoxes(placedDef,state))if(intersectsBox(x,y,z,p.x-.3,p.y,p.z-.3,p.x+.3,p.y+1.8,p.z+.3,box))return;
    if(this.setBlock(x,y,z,id,state)){this.statistics.blocks_placed=(this.statistics.blocks_placed??0)+1;this.audio?.play(id===ID.water?'water':'place',{x,y,z});if(this.meta.mode!=='creative')this.consumeSelected();this.achievement('place');}
  }
  countItem(name:string){return [...this.hotbar,...this.inventory].reduce((n,s)=>n+(s?.name===name?s.count:0),0);}
  removeItem(name:string,count:number){if(this.countItem(name)<count)return false;for(const arr of [this.hotbar,this.inventory])for(let i=0;i<arr.length;i++){const s=arr[i];if(s?.name===name){const n=Math.min(count,s.count);s.count-=n;count-=n;if(s.count<=0)arr[i]=null;if(!count)return true;}}return true;}
  command(text:string){const [cmd,...args]=text.trim().replace(/^\//,'').split(/\s+/);if(!text.startsWith('/'))return 'Steve: '+text;switch(cmd){case 'help':return '/give <item> [count] · /tp <x> <y> <z> · /time day|night|<0–1> · /gamemode survival|creative|adventure|spectator · /setblock <x> <y> <z> <block> · /dimension overworld|nether|end · /seed';case 'seed':return this.meta.seed;case 'summon':{const species=args[0] as Species;if(this.mobs.spawn(species,this.position.x+3,this.position.z+3))return 'Summoned '+species;return 'Cannot spawn here';}case 'time':{const v=args[0]==='day'?.2:args[0]==='night'?.7:Number(args[0]);if(!Number.isFinite(v))return 'Usage: /time day|night|0–1';this.time=((v%1)+1)%1;return 'Time set to '+this.time.toFixed(2);}case 'gamemode':if(['creative','survival','adventure','spectator'].includes(args[0])){this.meta.mode=args[0] as any;return 'Game mode: '+args[0];}return 'Unknown game mode';case 'give':{const n=Math.min(640,Math.max(1,Number(args[1])||1));if(!resolve(args[0]))return 'Unknown item: '+args[0];return this.addItem(args[0],n)?'Given '+n+' '+args[0]:'Inventory full';}case 'tp':{const p=args.map(Number);if(p.length!==3||!p.every(Number.isFinite))return 'Usage: /tp x y z';this.teleport(p[0],p[1],p[2]);return 'Teleported to '+p.join(', ');}case 'setblock':{const p=args.slice(0,3).map(Number),id=ID[args[3]];if(p.length!==3||!p.every(Number.isFinite)||id===undefined)return 'Usage: /setblock x y z block_id';return this.setBlock(p[0],p[1],p[2],id)?'Block placed':'Chunk not loaded';}case 'dimension':if(['overworld','nether','end'].includes(args[0])){this.changeDimension(args[0] as Dimension);return 'Traveling to '+args[0];}return 'Unknown dimension';default:return 'Unknown command. /help';}}
  consumeSelected(){const s=this.hotbar[this.selected];if(s){s.count--;if(s.count<=0)this.hotbar[this.selected]=null;}}
  addItem(name:string,count:number){
    const def=resolve(name);if(!def||!Number.isInteger(count)||count<=0)return false;
    const max=def.stack,slots=[...this.hotbar,...this.inventory];
    const capacity=slots.reduce((sum,slot)=>sum+(!slot?max:slot.name===name?Math.max(0,max-slot.count):0),0);
    if(capacity<count)return false;
    let remaining=count;for(const slot of slots)if(slot?.name===name&&slot.count<max){const n=Math.min(max-slot.count,remaining);slot.count+=n;remaining-=n;if(!remaining)return true;}
    for(const arr of [this.hotbar,this.inventory])for(let i=0;i<arr.length;i++)if(!arr[i]){const n=Math.min(max,remaining);arr[i]={name,count:n};remaining-=n;if(!remaining)return true;}return true;
  }
  dropSelected(){const s=this.hotbar[this.selected];if(!s)return;const dir=new THREE.Vector3();this.camera.getWorldDirection(dir);this.particles.drop(this.camera.position.clone().addScaledVector(dir,1.5),s.name,1,resolve(s.name)?.color??'#aaa');this.statistics.dropped=(this.statistics.dropped??0)+1;s.count--;if(s.count<=0)this.hotbar[this.selected]=null;}
  craftRecipe(id:string,table:boolean){const r=RECIPES.find(x=>x.id===id);if(!r||!canCraft(r,recipeCounts([...this.hotbar,...this.inventory]),this.meta.mode==='creative',table))return false;const backup=this.hotbar.map(s=>s?{...s}:null),backupInv=this.inventory.map(s=>s?{...s}:null);if(this.meta.mode!=='creative')for(const [n,c] of Object.entries(r.ingredients))this.removeItem(n,c);if(!this.addItem(r.result,r.count)){this.hotbar=backup;this.inventory=backupInv;return false;}this.achievement('craft');this.audio?.play('wood');return true;}
  trade(give:string,cost:number,result:string,count:number){const backup=this.hotbar.map(s=>s?{...s}:null),backupInv=this.inventory.map(s=>s?{...s}:null);if(this.removeItem(give,cost)&&this.addItem(result,count))return true;this.hotbar=backup;this.inventory=backupInv;return false;}
  updateStations(dt:number){
    const keys=Object.keys(this.furnaces),count=Math.min(8,keys.length);if(!count)return;
    const elapsed=dt*Math.max(1,keys.length/count);
    for(let i=0;i<count;i++){
      const key=keys[(this.stationCursor+i)%keys.length],state=this.furnaces[key],slots=this.containers[key];if(!state||!slots||slots.length!==3)continue;
      const input=slots[0],fuel=slots[1],output=slots[2],recipe=input?SMELTING[input.name]:undefined;state.burn=Math.max(0,state.burn-elapsed);
      if(recipe&&(!output||(output.name===recipe.result&&output.count<64))){
        if(state.burn<=0&&fuel&&FUEL[fuel.name]){state.burn=FUEL[fuel.name];fuel.count--;if(fuel.count<=0)slots[1]=null;}
        if(state.burn>0){state.progress+=elapsed/recipe.time;if(state.progress>=1){state.progress=0;input!.count--;if(input!.count<=0)slots[0]=null;if(output)output.count++;else slots[2]={name:recipe.result,count:1};this.audio?.play('stone');}}
      }else state.progress=0;
    }
    this.stationCursor=(this.stationCursor+count)%keys.length;
  }
  explode(p:THREE.Vector3,r:number){this.audio?.play('explosion',p);this.particles.burst(p,'#e8c28a',40,8);this.particles.burst(p,'#6b675c',30,5);const d=p.distanceTo(this.position);if(d<r*2)this.damage(Math.ceil((r*2-d)*2));for(let y=-r;y<=r;y++)for(let z=-r;z<=r;z++)for(let x=-r;x<=r;x++)if(x*x+y*y+z*z<=r*r)this.explosionQueue.push([p.x+x,p.y+y,p.z+z]);}
  swapSlots(a:number,b:number){const all=[...this.hotbar,...this.inventory];[all[a],all[b]]=[all[b],all[a]];this.hotbar=all.slice(0,9);this.inventory=all.slice(9);}
  give(name:string,count=64){const def=resolve(name);if(!def)return false;const ok=this.addItem(name,count);this.onToast(def.ja+' × '+count,def.name+' × '+count);return ok;}
  achievement(id:string){if(!this.achievements.includes(id)){this.achievements.push(id);const names:Record<string,string>={mine:'はじまりの一歩',place:'建築の時間',craft:'ものづくりの達人'};this.onToast('進捗達成: '+names[id],'Advancement: '+id);}}
  damage(amount:number){if(this.meta.mode==='creative'||this.dead)return;this.health=Math.max(0,this.health-amount);this.audio?.play('hurt');if(this.health<=0){this.dead=true;this.pause();this.onScreen('death');}}
  respawn(){this.health=20;this.hunger=20;this.dead=false;const p=this.respawnPoint??[-11,this.terrain.height(-11,27)+2,27];this.position.set(p[0],p[1],p[2]);this.velocity.set(0,0,0);this.fallTop=this.position.y;}
  teleport(x:number,y:number,z:number){this.position.set(x,y,z);this.velocity.set(0,0,0);this.fallTop=y;this.focus='';}
  changeDimension(dimension:Dimension){
    if(dimension===this.dimension)return;
    this.dimensionStores[this.dimension]={edits:this.edits,containers:this.containers,furnaces:this.furnaces};
    this.dimension=dimension;this.attachDimensionStore(dimension);this.terrain=new Terrain(this.meta.seed,dimension);
    this.mobs.host.terrain=this.terrain;this.mobs.host.dimension=dimension;this.mobs.clear();this.particles.clear();this.simulation.clear();this.clearChunks();
    this.position.set(0,this.terrain.height(0,8)+2,8);this.velocity.set(0,0,0);this.ready=false;this.focus='';this.streamAt=-10;this.environment.markShadow();
  }
  snapshot():WorldSave{
    this.dimensionStores[this.dimension]={edits:this.edits,containers:this.containers,furnaces:this.furnaces};
    const dimensions:NonNullable<WorldSave['dimensions']>={};
    for(const dimension of ['overworld','nether','end'] as const){const store=this.dimensionStores[dimension];if(store)dimensions[dimension]={edits:[...store.edits],containers:store.containers,furnaces:store.furnaces};}
    return {meta:{...this.meta,updated:Date.now()},position:this.position.toArray() as [number,number,number],yaw:this.input.yaw,pitch:this.input.pitch,time:this.time,dimension:this.dimension,edits:[...this.edits],inventory:this.inventory,hotbar:this.hotbar,health:this.health,hunger:this.hunger,xp:this.xp,selected:this.selected,statistics:this.statistics,achievements:this.achievements,containers:this.containers,furnaces:this.furnaces,dimensions};
  }
  save(){if(this.meta.id)this.onSave(this.snapshot());}
  private frame=(now:number)=>{
    if(this.disposed)return;this.raf=requestAnimationFrame(this.frame);const dt=Math.min(.04,this.last?(now-this.last)/1000:.016);this.last=now;this.elapsed+=dt;this.frameCount++;
    if(now-this.fpsAt>1000){this.fps=Math.round(this.frameCount*1000/(now-this.fpsAt));this.frameCount=0;this.fpsAt=now;}
    if(this.elapsed-this.streamAt>.65){this.streamAt=this.elapsed;this.stream();}this.dispatch();
    if(!this.ready){const usePosition=this.pendingPlay||this.active,cx=Math.floor((usePosition?this.position.x:0)/16),cz=Math.floor((usePosition?this.position.z:0)/16);let near=0;for(let z=-1;z<=1;z++)for(let x=-1;x<=1;x++)if(this.chunks.has((cx+x)+','+(cz+z)))near++;if(near===9){this.ready=true;if(this.pendingPlay){this.pendingPlay=false;this.activate();}else if(!this.active&&!this.input.active){this.camera.position.set(32,44,48);this.camera.lookAt(-8,23,-24);}}}
    if(this.active&&this.ready){this.input.update(dt);this.time=(this.time+dt/1200)%1;this.meta.playTime+=dt;this.weatherTimer-=dt;if(this.weatherTimer<=0&&this.dimension==='overworld'){this.weatherTimer=40+Math.random()*70;this.weather=this.weather==='clear'?(Math.random()<.2?'storm':'rain'):'clear';if(this.weather==='clear')this.onToast('雨が上がりました','The rain has stopped');else this.onToast(this.weather==='storm'?'雷雨が近づいています':'雨が降り始めました',this.weather==='storm'?'A thunderstorm is rolling in':'It has started raining');}this.physics(dt);this.camera.rotation.order='YXZ';this.camera.rotation.set(this.input.pitch,this.input.yaw,0);this.mining(dt);this.updateHand();this.simulation.update(dt,(x,y,z)=>new THREE.Vector3(x,y,z));this.updateStations(dt);this.mobs.update(dt,this.environment.daylight,this.meta.difficulty==='peaceful');if(this.meta.mode==='survival'||this.meta.mode==='adventure'){this.survivalTick+=dt;if(this.survivalTick>4){this.survivalTick=0;this.hunger=Math.max(0,this.hunger-(this.input.run?.15:.05));if(this.hunger>17&&this.health<20)this.health=Math.min(20,this.health+1);if(this.hunger<=0)this.damage(1);}const under=this.getBlock(this.camera.position.x,this.camera.position.y,this.camera.position.z)===ID.water;this.oxygen=under?Math.max(0,this.oxygen-dt):Math.min(20,this.oxygen+dt*3);if(this.oxygen<=0&&under)this.damage(dt*2);}let burstCount=0;while(this.explosionQueue.length&&burstCount++<10){const [x,y,z]=this.explosionQueue.shift()!,id=this.getBlock(x,y,z);if(id>0&&id!==ID.bedrock)this.setBlock(x,y,z,0);}if(this.elapsed-this.autoSaveAt>30){this.autoSaveAt=this.elapsed;this.save();}}
    else if(!this.input.active&&!this.active&&this.meta.id==='greenwood'&&!this.dead){const a=.56+Math.sin(this.elapsed*.017)*.13;this.camera.position.set(Math.sin(a)*72-7,44,Math.cos(a)*72-18);this.camera.lookAt(-8,23,-24);}
    if(!this.active&&this.stationsInMenu)this.updateStations(dt);
    const biomeKey=`${this.meta.seed},${this.dimension},${Math.floor(this.position.x/4)},${Math.floor(this.position.z/4)}`;
    if(biomeKey!==this.biomeKey){this.biomeKey=biomeKey;this.currentBiome=this.terrain.biome(this.position.x,this.position.z);}
    this.particles.update(dt,(x,y,z)=>this.getBlock(x,y,z),(n,c,p)=>this.position.distanceTo(p)<2.2&&this.addItem(n,c));if(!this.active&&this.ready&&this.meta.id==='greenwood')this.mobs.update(dt,.8,true);this.environment.update(this.elapsed,this.time,this.camera,this.dimension,this.settings,this.weather,this.currentBiome);
    if(this.environment.failed){for(const c of this.chunks.values())c.solid.material=this.environment.fallback;if(!this.fallbackNotified){this.fallbackNotified=true;this.onToast('セーフ描画モードに切り替えました','Safe rendering mode enabled');}}
    if(this.elapsed-this.lastShadow>2){this.lastShadow=this.elapsed;this.environment.markShadow();}
    this.renderer.render(this.scene,this.camera);this.audio?.listener(this.camera.position.x,this.camera.position.y,this.camera.position.z,this.input.yaw);
    if(now-this.snapshotAt>120){this.snapshotAt=now;this.onSnapshot({...EMPTY_SNAPSHOT,ready:this.ready,progress:Math.min(1,this.chunks.size/((this.settings.distance*2+1)**2*.78)),x:this.position.x,y:this.position.y,z:this.position.z,yaw:this.input.yaw,pitch:this.input.pitch,fps:this.fps,chunks:this.chunks.size,biome:this.currentBiome,dimension:this.dimension,health:this.health,hunger:this.hunger,oxygen:this.oxygen,xp:this.xp,level:Math.floor(Math.sqrt(this.xp)),time:this.time,selected:this.selected,hotbar:this.hotbar.map(s=>s?{...s}:null),inventory:this.inventory.map(s=>s?{...s}:null),target:this.target?BLOCKS[this.target.id].name:'',breaking:this.breaking,mode:this.meta.mode,flying:this.flying,underwater:this.getBlock(this.camera.position.x,this.camera.position.y,this.camera.position.z)===ID.water,raining:this.weather!=='clear',thundering:this.weather==='storm',moonPhase:Math.floor((this.meta.playTime/240)%8),weather:this.weather,debug:this.debug,statistics:{...this.statistics},achievements:[...this.achievements],dead:this.dead,containers:this.containers});}
  };
  updateHand(){const held=this.hotbar[this.selected],name=held?.name??'hand';if(name!==this.lastHand){this.lastHand=name;this.handMaterial.map?.dispose();this.handMaterial.map=null;if(held){const texture=new THREE.TextureLoader().load(itemIcon(name));texture.magFilter=THREE.NearestFilter;texture.colorSpace=THREE.SRGBColorSpace;this.handMaterial.map=texture;this.handMaterial.color.set('#ffffff');const isBlock=ID[name]!==undefined&&BLOCKS[ID[name]]?.shape==='cube';this.hand.scale.set(isBlock?1:.95,isBlock?1:.95,isBlock?1:.14);}else{this.handMaterial.color.set('#bf9673');this.hand.scale.set(.52,.52,1.25);}this.handMaterial.needsUpdate=true;}
    const walkBob=this.grounded?Math.sin(this.elapsed*10)*Math.min(.025,Math.hypot(this.input.move.x,this.input.move.z)*.025):0;
    const swing=this.input.mining?Math.sin(this.elapsed*15)*.16:0;this.hand.position.y=-.34+swing+walkBob;this.hand.rotation.x=.2+swing*1.4;this.hand.rotation.z=-swing*.6;this.hand.visible=!this.thirdPerson;
  }
  dispose(){this.disposed=true;cancelAnimationFrame(this.raf);this.resizeObserver.disconnect();this.listeners.forEach(f=>f());this.input.dispose();this.workers.forEach(s=>s.worker.terminate());this.clearChunks();this.environment.dispose();this.outline.geometry.dispose();(this.outline.material as THREE.Material).dispose();this.crack.geometry.dispose();this.crackMaterials.forEach(m=>{m.map?.dispose();m.dispose();});this.hand.geometry.dispose();this.handMaterial.map?.dispose();this.handMaterial.dispose();this.particles.dispose();this.mobs.dispose();this.renderer.dispose();}
}
