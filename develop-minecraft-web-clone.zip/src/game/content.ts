import { block, item, ID, BLOCKS } from './data';
const woods:Record<string,[string,string,string]>={spruce:['トウヒ','#66503a','#426b45'],jungle:['ジャングル','#9a7853','#4f8a3b'],acacia:['アカシア','#a06b4c','#8b9b49'],dark_oak:['ダークオーク','#4f3d29','#456d30'],cherry:['サクラ','#d6a398','#e5a9ba'],mangrove:['マングローブ','#865044','#5d853e'],pale_oak:['ペールオーク','#c9c5b4','#b8c4a2'],crimson:['真紅','#814653','#943f50'],warped:['歪んだ','#4c7774','#3c9b8d'],poplar:['ポプラ','#b8ad82','#b7b957']};
for(const [name,[ja,bark,leaf]] of Object.entries(woods)){
  block(name+'_log',ja+'の原木',bark,'bark',2,{tool:'axe',category:'nature'});
  block(name+'_leaves',ja+'の葉',leaf,'leaves',.2,{transparent:true,category:'nature'});
  block(name+'_planks',ja+'の板材',bark,'planks',2,{tool:'axe'});
  block(name+'_sapling',ja+'の苗木',leaf,'plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
}
block('birch_planks','シラカバの板材','#cbb783','planks',2,{tool:'axe'});
const stones:Record<string,[string,string,any,number]>={granite:['花崗岩','#a17d6c','stone',1.5],diorite:['閃緑岩','#c7c6bb','stone',1.5],andesite:['安山岩','#93988d','stone',1.5],deepslate:['深層岩','#55595b','stone',3],tuff:['凝灰岩','#7d8273','stone',1.5],calcite:['方解石','#dedbd0','stone',.75],basalt:['玄武岩','#5b5e5b','stone',1.25],blackstone:['ブラックストーン','#3e393e','stone',1.5],sandstone:['砂岩','#d8c78f','bricks',.8],red_sandstone:['赤い砂岩','#b97845','bricks',.8],red_sand:['赤い砂','#c9874d','sand',.5],terracotta:['テラコッタ','#aa7356','stone',1.25],quartz_block:['クォーツブロック','#e2ddd0','bricks',.8],prismarine:['プリズマリン','#6caa9d','bricks',1.5],purpur_block:['プルパーブロック','#a781a6','bricks',1.5],nether_bricks:['ネザーレンガ','#4d3034','bricks',2],end_stone_bricks:['エンドストーンレンガ','#cec998','bricks',3],moss_block:['苔ブロック','#728d3d','grass',.1],mycelium:['菌糸','#8e8290','grass',.6],podzol:['ポドゾル','#8b693c','grass',.5],mud:['泥','#655a50','dirt',.5],clay:['粘土','#a4abb0','dirt',.6],ice:['氷','#a4d4e4','glass',.5],packed_ice:['氷塊','#8ebdd4','stone',.5],cactus:['サボテン','#5e873d','planks',.4],pumpkin:['カボチャ','#c98a32','bark',1],melon:['スイカ','#8aa342','bark',1],hay_block:['干し草の俵','#c5a447','planks',.5],bookshelf:['本棚','#b18b55','planks',1.5],sponge:['スポンジ','#c9c35c','wool',.6],glowstone:['グロウストーン','#d9b36a','ore',.3],sea_lantern:['シーランタン','#b9d9ce','bricks',.3],magma_block:['マグマブロック','#b65326','lava',.5],soul_sand:['ソウルサンド','#705747','dirt',.5],soul_soil:['ソウルソイル','#665044','dirt',.5],ancient_debris:['古代の残骸','#6b5147','ore',30],emerald_ore:['エメラルド鉱石','#8c938b','ore',3],lapis_ore:['ラピスラズリ鉱石','#8c938b','ore',3],redstone_ore:['レッドストーン鉱石','#8c938b','ore',3],copper_ore:['銅鉱石','#92918a','ore',3],nether_quartz_ore:['ネザークォーツ鉱石','#85433d','ore',3],obsidian_bricks:['黒曜石レンガ','#3b354b','bricks',50],honey_block:['ハチミツブロック','#dca842','glass',.3],slime_block:['スライムブロック','#8fbd67','glass',.3],bone_block:['骨ブロック','#d6d1b9','rings',2],amethyst_block:['アメジストブロック','#9b7bb5','gem',1.5]};
for(const [name,[ja,color,pattern,hardness]] of Object.entries(stones))block(name,ja,color,pattern,hardness,{tool:pattern==='ore'||pattern==='bricks'||pattern==='stone'?'pickaxe':'',tier:hardness>=3?2:1,category:name.includes('ore')?'ores':name==='red_sand'?'nature':'building',light:['glowstone','sea_lantern','magma_block'].includes(name)?15:0});
for(const ore of ['iron','gold','diamond','emerald','lapis','redstone','copper'])if(!ID[ore+'_ore'])block(ore+'_ore','鉱石','#8c938b','ore',3,{tool:'pickaxe',tier:2,category:'ores'});
for(const ore of ['coal','iron','gold','diamond','emerald','lapis','redstone','copper'])block('deepslate_'+ore+'_ore','深層'+ore+'鉱石','#55595b','ore',4.5,{tool:'pickaxe',tier:2,category:'ores'});
export const DYES:Record<string,string>={white:'#e4e2d8',orange:'#d98943',magenta:'#b65c9e',light_blue:'#79aeda',yellow:'#e1c34d',lime:'#8eb84c',pink:'#dfa0b1',gray:'#666d6b',light_gray:'#a7aaa0',cyan:'#4d9c9f',purple:'#8b65a8',blue:'#536fae',brown:'#87654b',green:'#6c8745',red:'#b95348',black:'#34383a'};
for(const [color,hex] of Object.entries(DYES)){
  const base=color+'_wool';if(!ID[base])block(base,color+' wool',hex,'wool',.8,{category:'decorations'});
  block(color+'_carpet',color+' carpet',hex,'wool',.1,{shape:'slab',category:'decorations'});
  block(color+'_concrete',color+' concrete',hex,'stone',1.8,{tool:'pickaxe',tier:1,category:'building'});
  block(color+'_stained_glass',color+' stained glass',hex,'glass',.3,{transparent:true,category:'building'});
  block(color+'_terracotta',color+' terracotta',hex,'stone',1.25,{tool:'pickaxe',tier:1,category:'building'});
  item(color+'_dye',color+' dye',hex,'gem',{category:'materials'});
}
const shapeBases=['stone_bricks','cobblestone','sandstone','red_sandstone','oak_planks','spruce_planks','birch_planks','jungle_planks','acacia_planks','dark_oak_planks','cherry_planks','quartz_block','nether_bricks','deepslate','granite','diorite','andesite'];
for(const base of shapeBases){const b=BLOCKS[ID[base]];if(!b)continue;for(const [suffix,shape,ja] of [['stairs','stairs','階段'],['slab','slab','ハーフブロック'],['wall','fence','壁'],['fence','fence','フェンス']])block(base+'_'+suffix,b.ja+ja,b.color,b.pattern,b.hardness,{tool:b.tool,tier:b.tier,shape:shape as any,category:'building'});}
for(const base of ['oak','birch','spruce','jungle','acacia','dark_oak','cherry']){const b=BLOCKS[ID[base+'_planks']];block(base+'_door',b.ja+'ドア',b.color,'planks',3,{tool:'axe',shape:'door',category:'building'});block('open_'+base+'_door',b.ja+'ドア（開）',b.color,'planks',3,{tool:'axe',shape:'pane',solid:false,transparent:true,category:'building'});block(base+'_trapdoor',b.ja+'トラップドア',b.color,'planks',3,{tool:'axe',shape:'trapdoor',category:'building'});block(base+'_pressure_plate',b.ja+'感圧板',b.color,'planks',.5,{shape:'slab',category:'redstone'});block(base+'_button',b.ja+'ボタン',b.color,'planks',.5,{shape:'torch',category:'redstone'});}
block('glass_pane','ガラス板','#b4dce1','glass',.3,{transparent:true,shape:'pane'});
block('iron_door','鉄のドア','#c4cbc7','metal',5,{tool:'pickaxe',tier:2,shape:'door'});block('open_iron_door','鉄のドア（開）','#c4cbc7','metal',5,{shape:'pane',solid:false,transparent:true});
block('redstone_lamp','レッドストーンランプ','#b98b4c','ore',.3,{light:15,category:'redstone'});
block('unlit_redstone_lamp','消灯ランプ','#715b3f','ore',.3,{category:'redstone'});
block('redstone_wire','レッドストーンダスト','#b74635','bricks',0,{solid:false,transparent:true,shape:'slab',category:'redstone'});
block('lever','レバー','#9b8c68','torch',.5,{shape:'torch',category:'redstone'});
block('piston','ピストン','#a99b73','craft',1.5,{category:'redstone'});
block('sticky_piston','粘着ピストン','#8ba35d','craft',1.5,{category:'redstone'});
block('observer','オブザーバー','#777c76','furnace',3,{tool:'pickaxe',tier:1,category:'redstone'});
block('hopper','ホッパー','#555d59','metal',3,{tool:'pickaxe',tier:1,category:'redstone'});
block('dropper','ドロッパー','#777c76','furnace',3.5,{tool:'pickaxe',tier:1,category:'redstone'});
block('dispenser','ディスペンサー','#777c76','furnace',3.5,{tool:'pickaxe',tier:1,category:'redstone'});
block('repeater','リピーター','#b7b3a5','bricks',.1,{shape:'slab',category:'redstone'});
block('comparator','コンパレーター','#b7b3a5','bricks',.1,{shape:'slab',category:'redstone'});
block('tnt','TNT','#bd5540','bricks',0,{category:'redstone'});
block('note_block','音符ブロック','#8b6547','planks',.8,{tool:'axe',category:'redstone'});
block('rail','レール','#a39a7e','bricks',.7,{solid:false,transparent:true,shape:'slab',category:'redstone'});
block('powered_rail','パワードレール','#c3a45b','bricks',.7,{solid:false,transparent:true,shape:'slab',category:'redstone'});
block('daylight_detector','日照センサー','#c6b797','bricks',.2,{shape:'slab',category:'redstone'});
block('target','的','#c9b8a0','rings',.5,{category:'redstone'});
block('farmland','耕地','#765436','dirt',.6,{tool:'shovel',shape:'slab',category:'nature'});
block('wheat_crop','小麦','#bda34d','plant',0,{solid:false,transparent:true,shape:'cross',drop:'wheat',category:'nature'});
block('oak_sapling','オークの苗木','#6e963f','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('birch_sapling','シラカバの苗木','#86a94e','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('sugar_cane','サトウキビ','#7fb069','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('beach_sand','砂浜','#e6d9a8','sand',.5,{tool:'shovel',category:'nature'});
block('red_mushroom','赤いキノコ','#c45443','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('brown_mushroom','茶色いキノコ','#a18461','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('cornflower','ヤグルマギク','#4e74d4','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('lily_of_the_valley','スズラン','#f3f5f0','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('orange_tulip','オレンジのチューリップ','#e57c35','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('pink_tulip','ピンクのチューリップ','#e89cb8','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('white_tulip','白いチューリップ','#f0eee6','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('oxeye_daisy','フランスギク','#f3f1e4','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('fern','シダ','#5d8e3e','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature',drop:'wheat_seeds'});
block('dead_bush','枯れ木','#8b693c','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature',drop:'stick'});
block('pink_petals','サクラの花びら','#f4b6c9','plant',0,{solid:false,transparent:true,shape:'lily',category:'nature'});
block('lily_pad','スイレンの葉','#4f8435','plant',0,{solid:false,transparent:true,shape:'lily',category:'nature'});
block('mossy_cobblestone','苔むした丸石','#798474','bricks',2,{tool:'pickaxe',tier:1,category:'building'});
block('mossy_stone_bricks','苔むした石レンガ','#838c7c','bricks',1.5,{tool:'pickaxe',tier:1,category:'building'});
block('coarse_dirt','粗い土','#7b563b','dirt',.5,{tool:'shovel',category:'nature'});
block('dirt_path','草の道','#a38953','grass',.65,{tool:'shovel',drop:'dirt',category:'nature'});
block('red_mushroom_block','赤いキノコブロック','#bd5548','wool',.2,{category:'nature'});
block('brown_mushroom_block','茶色いキノコブロック','#967b5d','wool',.2,{category:'nature'});
block('torchflower','トーチフラワー','#e4a34c','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('lantern','ランタン','#e1b65e','torch',3.5,{shape:'torch',light:15,category:'utility'});
block('ladder','はしご','#b28b54','planks',.4,{solid:false,transparent:true,shape:'pane',category:'utility'});
block('barrel','樽','#a17b49','planks',2.5,{tool:'axe',category:'utility'});
block('brewing_stand','醸造台','#b39a5b','tool',.5,{shape:'torch',category:'utility'});
block('enchanting_table','エンチャントテーブル','#4c4557','obsidian',5,{tool:'pickaxe',tier:1,shape:'slab',category:'utility'});
block('anvil','金床','#5c625f','metal',5,{tool:'pickaxe',tier:1,shape:'slab',category:'utility'});
block('grindstone','砥石','#8a8d82','stone',2,{tool:'pickaxe',tier:1,shape:'slab',category:'utility'});
block('loom','織機','#b39465','planks',2.5,{tool:'axe',category:'utility'});
block('stonecutter','石切台','#9a9d92','bricks',3.5,{tool:'pickaxe',tier:1,shape:'slab',category:'utility'});
block('blast_furnace','溶鉱炉','#686e6c','furnace',3.5,{tool:'pickaxe',tier:1,category:'utility'});
block('smoker','燻製器','#8b6b47','furnace',3.5,{tool:'axe',category:'utility'});
block('bed','ベッド','#b65b4b','wool',.2,{shape:'slab',category:'utility'});
block('portal','ネザーポータル','#7650a4','water',100,{solid:false,transparent:true,shape:'pane',light:11,category:'utility'});
block('end_portal','エンドポータル','#243c42','water',100,{solid:false,transparent:true,shape:'slab',light:15,category:'utility'});
const toolTiers:Record<string,[string,string,number,number,number]>={wooden:['木','#a88754',2,59,2],stone:['石','#92978d',4,131,3],copper:['銅','#c7835e',5,190,3],iron:['鉄','#d0d7d2',6,250,4],diamond:['ダイヤモンド','#58cfc4',8,1561,5],golden:['金','#e4c35b',12,32,2],netherite:['ネザライト','#655b60',9,2031,6]};
for(const [tier,[ja,color,speed,durability,damage]] of Object.entries(toolTiers))for(const type of ['pickaxe','axe','shovel','sword','hoe'])item(tier+'_'+type,ja+'の'+type,color,'tool',{tool:type,tier:type==='sword'?0:speed,durability,damage:type==='sword'?damage+2:type==='axe'?damage+3:1,stack:1,category:'tools'});
for(const [tier,[ja,color,,durability]] of Object.entries(toolTiers))for(const type of ['helmet','chestplate','leggings','boots'])item(tier+'_'+type,ja+'の'+type,color,'metal',{durability,stack:1,category:'tools'});
const foods:Record<string,[string,string,number]>={cooked_chicken:['焼き鳥','#bd8b58',6],mutton:['生の羊肉','#c46c60',2],cooked_mutton:['焼き羊肉','#9d6a45',6],rabbit:['生の兎肉','#cf9b86',3],cooked_rabbit:['焼き兎肉','#ad7d53',5],cod:['生鱈','#b8b393',2],cooked_cod:['焼き鱈','#c2a578',5],salmon:['生鮭','#ce8066',2],cooked_salmon:['焼き鮭','#c48a62',6],potato:['ジャガイモ','#c7a66b',1],baked_potato:['ベイクドポテト','#b99759',5],carrot:['ニンジン','#db9143',3],golden_carrot:['金のニンジン','#e4c257',6],golden_apple:['金のリンゴ','#e6cb62',4],cookie:['クッキー','#b98c55',2],melon_slice:['スイカの薄切り','#cf6b57',2],sweet_berries:['スイートベリー','#b7544c',2],glow_berries:['グロウベリー','#e0b35a',2],egg:['卵','#e5ddc7',1],mushroom_stew:['キノコシチュー','#b58b61',6],rabbit_stew:['ウサギシチュー','#b68b5c',10],beetroot:['ビートルート','#a7474b',1],beetroot_soup:['ビートルートスープ','#b65c50',6],pumpkin_pie:['パンプキンパイ','#c79552',8],dried_kelp:['乾燥昆布','#667348',1],chorus_fruit:['コーラスフルーツ','#b18aa9',4]};
for(const [name,[ja,color,food]] of Object.entries(foods))item(name,ja,color,'food',{food,category:'food'});
for(const [name,ja,color] of [['slime_ball','スライムボール','#7ac74f'],['magma_cream','マグマクリーム','#c85a20'],['honeycomb','ハニカム','#e8c832'],['ink_sac','イカスミ','#2a2a3a'],['scute','カメの甲羅','#6a9a5a'],['sculk','スカルク','#2a4a4a'],['rabbit_hide','ウサギの皮','#d8d8d8'],['milk_bucket','牛乳入りバケツ','#e5e5d7'],['lava_bucket','溶岩入りバケツ','#e58b36'],['shears','ハサミ','#c4cbc5'],['flint_and_steel','火打石と打ち金','#9b9b8b'],['bow','弓','#b18b54'],['arrow','矢','#d3cdb6'],['fishing_rod','釣竿','#a98855'],['saddle','鞍','#8b6547'],['compass','コンパス','#b9c4bd'],['clock','時計','#d9bd62'],['bucket','バケツ','#aab6b6'],['ender_pearl','エンダーパール','#5b9e91'],['blaze_rod','ブレイズロッド','#e0b451'],['nether_star','ネザースター','#e5e4c9'],['emerald','エメラルド','#69bd7c'],['lapis_lazuli','ラピスラズリ','#5b78b6'],['redstone','レッドストーン','#b74635'],['charcoal','木炭','#4b443b'],['flint','火打石','#666b69'],['paper','紙','#e4e2d5'],['book','本','#a77c52'],['glass_bottle','ガラス瓶','#c2d8d5'],['potion','ポーション','#b66ca8'],['splash_potion','スプラッシュポーション','#a77cc0'],['experience_bottle','エンチャントの瓶','#b5cf68'],['boat','オークのボート','#ad8954'],['minecart','トロッコ','#aab2ad'],['painting','絵画','#b59b64'],['item_frame','額縁','#b39465'],['sign','看板','#b99a63']])if(ID[name]===undefined)item(name,ja,color,name.includes('bucket')?'misc':name.includes('potion')||name==='glass_bottle'?'gem':'tool',{stack:['shears','flint_and_steel','bow','fishing_rod','saddle','boat','minecart','compass','clock'].includes(name)?1:64,category:name.includes('potion')||name==='experience_bottle'?'food':'tools'});

// Keep legacy aliases so existing inventories and numeric world IDs remain usable.
for(const wood of ['oak','spruce','birch','jungle','acacia','dark_oak','cherry'])for(const suffix of ['slab','stairs','fence']){
  const oldName=wood+'_planks_'+suffix,canonical=wood+'_'+suffix,id=ID[oldName];
  if(id!==undefined&&ID[canonical]===undefined){ID[canonical]=id;BLOCKS[id].name=canonical;}
}
for(const [oldBase,newBase] of [['stone_bricks','stone_brick'],['quartz_block','quartz'],['nether_bricks','nether_brick']])for(const suffix of ['slab','stairs','wall']){
  const id=ID[oldBase+'_'+suffix],canonical=newBase+'_'+suffix;
  if(id!==undefined&&ID[canonical]===undefined){ID[canonical]=id;BLOCKS[id].name=canonical;}
}
for(const [color,hex] of Object.entries(DYES))for(const material of ['wool','concrete']){
  const base=color+'_'+material,source=BLOCKS[ID[base]];
  block(base+'_slab',source.ja+'のハーフブロック',hex,source.pattern,source.hardness,{tool:source.tool,tier:source.tier,shape:'slab',category:'building'});
  block(base+'_stairs',source.ja+'の階段',hex,source.pattern,source.hardness,{tool:source.tool,tier:source.tier,shape:'stairs',category:'building'});
}
item('raw_iron','鉄の原石','#cfa789','gem',{category:'materials'});
item('raw_copper','銅の原石','#cb845e','gem',{category:'materials'});
item('raw_gold','金の原石','#dec36e','gem',{category:'materials'});
item('quartz','ネザークォーツ','#e9e3d7','gem',{category:'materials'});
item('snowball','雪玉','#e8eef0','gem',{stack:16,category:'items'});
