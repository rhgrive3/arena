export type Pattern = 'grass' | 'dirt' | 'stone' | 'sand' | 'bark' | 'rings' | 'leaves' | 'planks' | 'water' | 'glass' | 'bricks' | 'cobble' | 'tnt' | 'ore' | 'gravel' | 'snow' | 'plant' | 'craft' | 'furnace' | 'chest' | 'torch' | 'lava' | 'obsidian' | 'wool' | 'metal' | 'gem' | 'tool' | 'food' | 'misc';
export type Shape = 'cube' | 'chest' | 'cross' | 'water' | 'slab' | 'stairs' | 'fence' | 'pane' | 'torch' | 'door' | 'trapdoor' | 'lily';
export interface BlockDef { id: number; name: string; ja: string; color: string; pattern: Pattern; hardness: number; tool: string; solid: boolean; transparent: boolean; shape: Shape; category: string; drop?: string; light?: number; tier?: number; stack: number; food?: number; damage?: number; durability?: number; }
export const BLOCKS: BlockDef[] = [{ id: 0, name: 'air', ja: '空気', color: '#ffffff', pattern: 'misc', hardness: 0, tool: '', solid: false, transparent: true, shape: 'cube', category: 'nature', stack: 0 }];
export const ID: Record<string, number> = { air: 0 };
export function block(name: string, ja: string, color: string, pattern: Pattern, hardness = 1, extra: Partial<BlockDef> = {}) {
  if (ID[name] !== undefined) return ID[name];
  const id = BLOCKS.length;
  BLOCKS.push({ id, name, ja, color, pattern, hardness, tool: '', solid: true, transparent: false, shape: 'cube', category: 'building', stack: 64, ...extra });
  ID[name] = id; return id;
}

block('grass_block', '草ブロック', '#6f9846', 'grass', .6, { tool: 'shovel', drop: 'dirt', category: 'nature' });
block('dirt', '土', '#8a6244', 'dirt', .5, { tool: 'shovel', category: 'nature' });
block('stone', '石', '#92938a', 'stone', 1.5, { tool: 'pickaxe', tier: 1, drop: 'cobblestone' });
block('sand', '砂', '#dfd29a', 'sand', .5, { tool: 'shovel', category: 'nature' });
block('oak_log', 'オークの原木', '#79603c', 'bark', 2, { tool: 'axe', category: 'nature' });
block('oak_leaves', 'オークの葉', '#548637', 'leaves', .2, { transparent: true, category: 'nature' });
block('oak_planks', 'オークの板材', '#b8955d', 'planks', 2, { tool: 'axe' });
block('water', '水', '#329caa', 'water', 100, { solid: false, transparent: true, shape: 'water', category: 'nature' });
block('glass', 'ガラス', '#b4dce1', 'glass', .3, { transparent: true, category: 'building' });
block('stone_bricks', '石レンガ', '#8b8e83', 'bricks', 1.5, { tool: 'pickaxe', tier: 1 });
block('bedrock', '岩盤', '#454843', 'stone', Infinity, { tier: 99 });
block('snow_block', '雪ブロック', '#e4edf0', 'snow', .2, { tool: 'shovel', category: 'nature' });
block('gravel', '砂利', '#99918a', 'gravel', .6, { tool: 'shovel', category: 'nature' });
block('coal_ore', '石炭鉱石', '#8b8d84', 'ore', 3, { tool: 'pickaxe', tier: 1, drop: 'coal', category: 'ores' });
block('iron_ore', '鉄鉱石', '#92918a', 'ore', 3, { tool: 'pickaxe', tier: 2, category: 'ores' });
block('gold_ore', '金鉱石', '#92918a', 'ore', 3, { tool: 'pickaxe', tier: 3, category: 'ores' });
block('diamond_ore', 'ダイヤモンド鉱石', '#828b89', 'ore', 3, { tool: 'pickaxe', tier: 3, drop: 'diamond', category: 'ores' });
block('cobblestone', '丸石', '#82877e', 'bricks', 2, { tool: 'pickaxe', tier: 1 });
block('birch_log', 'シラカバの原木', '#e0dccb', 'bark', 2, { tool: 'axe', category: 'nature' });
block('birch_leaves', 'シラカバの葉', '#77a34a', 'leaves', .2, { transparent: true, category: 'nature' });
block('poppy', 'ポピー', '#dc5540', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature' });
block('short_grass', '草', '#70a246', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature', drop: 'wheat_seeds' });
block('crafting_table', '作業台', '#a37b46', 'craft', 2.5, { tool: 'axe', category: 'utility' });
block('furnace', 'かまど', '#777c76', 'furnace', 3.5, { tool: 'pickaxe', tier: 1, category: 'utility' });
block('chest', 'チェスト', '#b3833e', 'chest', 2.5, { tool: 'axe', shape: 'chest', transparent: true, category: 'utility' });
block('torch', '松明', '#f4be54', 'torch', 0, { solid: false, transparent: true, shape: 'torch', light: 14, category: 'utility' });
block('lava', '溶岩', '#f88720', 'lava', 100, { solid: false, transparent: true, shape: 'water', light: 15, category: 'nature' });
block('obsidian', '黒曜石', '#322d45', 'obsidian', 50, { tool: 'pickaxe', tier: 4 });
block('netherrack', 'ネザーラック', '#85433d', 'stone', .4, { tool: 'pickaxe', tier: 1, category: 'nature' });
block('end_stone', 'エンドストーン', '#d9d59c', 'stone', 3, { tool: 'pickaxe', tier: 1, category: 'nature' });
block('dandelion', 'タンポポ', '#f1ce49', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature' });
block('white_wool', '白い羊毛', '#e4e2d8', 'wool', .8, { category: 'decorations' });
export const ITEMS: BlockDef[] = [];
export const ITEM_ID: Record<string, number> = {};
export function item(name: string, ja: string, color: string, pattern: Pattern, extra: Partial<BlockDef> = {}) {
  if (ITEM_ID[name] !== undefined) return;
  ITEM_ID[name] = ITEMS.length;
  ITEMS.push({ id: ITEMS.length, name, ja, color, pattern, hardness: 0, tool: '', solid: false, transparent: true, shape: 'cube', category: 'items', stack: 64, ...extra });
}
item('stick', '棒', '#a27d49', 'tool');
item('coal', '石炭', '#3d4140', 'gem', { category: 'materials' });
item('diamond', 'ダイヤモンド', '#55d9cf', 'gem', { category: 'materials' });
item('iron_ingot', '鉄インゴット', '#d4d9d6', 'metal', { category: 'materials' });
item('gold_ingot', '金インゴット', '#efc64d', 'metal', { category: 'materials' });
item('apple', 'リンゴ', '#d84c38', 'food', { food: 4, stack: 64, category: 'food' });
item('bread', 'パン', '#c9954e', 'food', { food: 5, category: 'food' });
item('wheat', '小麦', '#d6b658', 'plant', { category: 'materials' });
item('wheat_seeds', '小麦の種', '#81a64d', 'misc', { category: 'materials' });
item('raw_beef', '生の牛肉', '#bb5a51', 'food', { food: 3, category: 'food' });
item('cooked_beef', 'ステーキ', '#8f5436', 'food', { food: 8, category: 'food' });
item('porkchop', '生の豚肉', '#d89389', 'food', { food: 3, category: 'food' });
item('cooked_porkchop', '焼き豚', '#ba8b57', 'food', { food: 8, category: 'food' });
item('leather', '革', '#a26841', 'misc', { category: 'materials' });
item('feather', '羽根', '#e8e7df', 'tool', { category: 'materials' });
item('bone', '骨', '#dcd9c7', 'tool', { category: 'materials' });
item('rotten_flesh', '腐った肉', '#927148', 'food', { food: 4, category: 'food' });
item('string', '糸', '#e2e1d8', 'misc', { category: 'materials' });
item('gunpowder', '火薬', '#737570', 'misc', { category: 'materials' });
item('bucket', 'バケツ', '#aab6b6', 'misc', { stack: 1, category: 'tools' });
item('water_bucket', '水入りバケツ', '#4ba5c5', 'misc', { stack: 1, category: 'tools' });
export function resolve(name: string) { return ID[name] !== undefined ? { ...BLOCKS[ID[name]], block: true } : ITEM_ID[name] !== undefined ? { ...ITEMS[ITEM_ID[name]], block: false } : undefined; }
export const isSolid = (id: number) => !!BLOCKS[id]?.solid;
export const isOpaque = (id: number) => !!id && !BLOCKS[id]?.transparent;
/**
 * Minecraft準拠の面別タイル割当。
 * face: 0=+X 1=-X 2=+Y(上面) 3=-Y(下面) 4=+Z(前面) 5=-Z(背面)
 * チェストの留め具は前面のみ、かまどの口は前面のみ、上面・下面は無地。
 */
export function faceTile(b: BlockDef, face: number) {
  const n = b.name;
  // 方向を持つブロック: 前面のみ特徴的な絵柄
  if (n === 'chest') return face === 2 ? 'chest_top' : face === 3 ? 'chest_bottom' : face === 4 ? 'chest_front' : 'chest_side';
  if (n === 'barrel') return face === 2 || face === 3 ? 'barrel_top' : face === 4 ? 'barrel_front' : 'barrel_side';
  if (n === 'tnt') return face === 2 || face === 3 ? 'tnt_top' : 'tnt_side';
  if (n === 'piston' || n === 'sticky_piston') return face === 2 || face === 3 ? n + '_top' : face === 4 ? n + '_front' : n + '_side';
  if (n === 'crafting_table') return face === 2 ? 'crafting_table_top' : face === 3 ? 'oak_planks' : face === 4 ? 'crafting_table_front' : 'crafting_table_side';
  if (b.pattern === 'furnace') {
    const key = n.startsWith('blast_furnace') ? 'blast_furnace' : n.startsWith('smoker') ? 'smoker' : n.startsWith('observer') ? 'observer' : n.startsWith('dropper') ? 'dropper' : n.startsWith('dispenser') ? 'dispenser' : 'furnace';
    return face === 2 ? key + '_top' : face === 3 ? key + '_bottom' : face === 4 ? key + '_front' : key + '_side';
  }
  if (b.pattern === 'grass') return face === 2 ? n : face === 3 ? 'dirt' : (n === 'grass_block' ? 'grass_side' : n + '_side');
  if (b.pattern === 'bark') return (face === 2 || face === 3) ? n + '_top' : n;
  return n;
}
export const ATLAS_COLS = 16;
export const TILE = 20;
