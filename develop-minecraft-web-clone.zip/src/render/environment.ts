import * as THREE from 'three';
import { makeAtlasTexture, atlasCanvas, canvas } from '../textures/atlas';
import { random } from '../input/math';
import type { Settings, Dimension } from '../game/types';

export class Environment {
  atlas = makeAtlasTexture();
  material: THREE.MeshLambertMaterial;
  fallback: THREE.MeshLambertMaterial;
  water: THREE.ShaderMaterial;
  sky: THREE.Mesh;
  skyMaterial: THREE.ShaderMaterial;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  sunSprite: THREE.Mesh;
  moon: THREE.Mesh;
  glow: THREE.Sprite;
  stars: THREE.Points;
  clouds: THREE.InstancedMesh;
  rays: THREE.Group;
  rain: THREE.Points;
  rainMat: THREE.ShaderMaterial;
  ambientParticles: THREE.Points;
  ambientMat: THREE.ShaderMaterial;
  weather: 'clear' | 'rain' | 'storm' = 'clear';
  uniforms = { uTime: { value: 0 }, uAtlasSize: { value: new THREE.Vector2(atlasCanvas.width, atlasCanvas.height) } };
  waterUniforms = { uTime: { value: 0 }, uSun: { value: new THREE.Vector3(-0.5, 0.8, 0.3) }, uFog: { value: new THREE.Color('#bbd8d8') }, uNear: { value: 52 }, uFar: { value: 120 }, uLava: { value: 0 } };
  failed = false;
  daylight = 1;

  constructor(public scene: THREE.Scene, public renderer: THREE.WebGLRenderer, settings: Settings) {
    this.material = new THREE.MeshLambertMaterial({ map: this.atlas, vertexColors: true, alphaTest: 0.35, side: THREE.FrontSide });
    this.fallback = new THREE.MeshLambertMaterial({ vertexColors: true });
    this.material.onBeforeCompile = (shader) => {
      Object.assign(shader.uniforms, this.uniforms);
      shader.vertexShader = 'attribute float tile; attribute float wind; varying float vTile; uniform float uTime;\n' + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace('#include <uv_vertex>', '#include <uv_vertex>\nvTile = tile;');
      shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nif (wind > 0.0) { transformed.x += sin(position.z * 0.8 + uTime * 1.35) * wind * 0.085; transformed.z += cos(position.x * 0.75 + uTime * 1.05) * wind * 0.06; }');
      shader.fragmentShader = 'varying float vTile; uniform vec2 uAtlasSize;\n' + shader.fragmentShader;
      shader.fragmentShader = shader.fragmentShader.replace('#include <map_fragment>', 'vec2 tileOrigin = vec2(mod(vTile, 16.0), floor(vTile / 16.0)) * 20.0; vec2 uvFlipped = vec2(fract(vMapUv.x), 1.0 - fract(vMapUv.y)); vec2 atlasUV = (tileOrigin + vec2(2.5) + uvFlipped * 15.0) / uAtlasSize; vec4 sampledDiffuseColor = texture2D(map, atlasUV); if(sampledDiffuseColor.a < 0.35) discard; diffuseColor *= sampledDiffuseColor;');
    };
    this.material.customProgramCacheKey = () => 'voxel-atlas-v4';

    renderer.debug.checkShaderErrors = true;
    renderer.debug.onShaderError = (...args: any[]) => {
      this.failed = true;
      const program = args[1];
      const message = program?.diagnostics?.fragmentShader?.log || 'Shader compilation fallback';
      console.warn('[Shader safety fallback]', message);
    };

    this.water = new THREE.ShaderMaterial({
      uniforms: this.waterUniforms,
      transparent: true,
      depthWrite: false,
      side: THREE.FrontSide,
      vertexShader: `attribute float tile; uniform float uTime; varying float vFluid; varying vec3 vWorld; varying vec3 vNormal; void main(){ vec3 p=position; p.y += sin(p.x*.75+uTime*1.15)*.026+cos(p.z*.88+uTime*.85)*.022; vec4 world=modelMatrix*vec4(p,1.); vWorld=world.xyz; vNormal=normalize(mat3(modelMatrix)*normal); vFluid=tile; gl_Position=projectionMatrix*viewMatrix*world; }`,
      fragmentShader: `uniform float uTime; uniform vec3 uSun; uniform vec3 uFog; uniform float uNear; uniform float uFar; varying float vFluid; varying vec3 vWorld; varying vec3 vNormal;
      void main(){vec3 view=normalize(cameraPosition-vWorld);vec3 n=normalize(vNormal+vec3(sin(vWorld.x*1.1+uTime*1.2)*.045,0.,cos(vWorld.z*.95+uTime*.9)*.045));float fresnel=pow(1.-max(dot(view,n),0.),3.2);float wave=sin(vWorld.x*1.9+vWorld.z*.8+uTime*1.0)*sin(vWorld.z*1.4-uTime*.7);float caustic=pow(max(0.,sin(vWorld.x*2.8+uTime*.9)*cos(vWorld.z*2.6-uTime*.8)),4.);vec3 deep=vec3(.018,.21,.29);vec3 shallow=vec3(.08,.47,.52);vec3 col=mix(deep,shallow,.46+wave*.09+caustic*.14);col=mix(col,vec3(.58,.81,.88),fresnel*.52);float spec=pow(max(dot(reflect(-normalize(uSun),n),view),0.),140.);col+=vec3(1.,.92,.68)*spec*.9;float foam=pow(max(0.,sin(vWorld.x*2.4+vWorld.z*1.9+uTime*.5)),22.);col+=vec3(.22,.32,.28)*foam*.14;if(vFluid>.5)col=mix(vec3(.9,.18,.015),vec3(1.,.72,.08),wave*.5+.5);float fog=smoothstep(uNear,uFar,distance(cameraPosition,vWorld));col=mix(col,uFog,fog);gl_FragColor=vec4(col,vFluid>.5?1.:.89);#include <tonemapping_fragment>\n#include <colorspace_fragment>}`.replace(';#include', ';\n#include'),
    });

    this.skyMaterial = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uTop: { value: new THREE.Color('#73b8df') },
        uHorizon: { value: new THREE.Color('#d1e3dc') },
        uSunset: { value: new THREE.Color('#f4a261') },
        uSun: { value: new THREE.Vector3(-0.5, 0.8, 0.3) },
        uDay: { value: 1 },
        uTwilight: { value: 0 },
      },
      vertexShader: 'varying vec3 vDirection; void main(){vDirection=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
      fragmentShader: `varying vec3 vDirection; uniform vec3 uTop; uniform vec3 uHorizon; uniform vec3 uSunset; uniform vec3 uSun; uniform float uDay; uniform float uTwilight;
      void main(){vec3 d=normalize(vDirection);float h=pow(max(d.y,0.),.52);vec3 baseHorizon=mix(uHorizon,uSunset,uTwilight*0.65);vec3 col=mix(baseHorizon,uTop,h);float s=max(dot(d,normalize(uSun)),0.);col+=mix(vec3(1.,.74,.38),vec3(1.,.48,.24),uTwilight)*pow(s,36.)*(.22+uTwilight*.32);gl_FragColor=vec4(col,1.);#include <tonemapping_fragment>\n#include <colorspace_fragment>}`.replace(';#include', ';\n#include'),
    });

    this.sky = new THREE.Mesh(new THREE.SphereGeometry(380, 20, 14), this.skyMaterial);
    this.sky.renderOrder = -100;
    scene.add(this.sky);

    this.sun = new THREE.DirectionalLight('#fff0d0', 2.4);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(settings.quality === 'ultra' ? 2048 : 1024, settings.quality === 'ultra' ? 2048 : 1024);
    Object.assign(this.sun.shadow.camera, { left: -54, right: 54, top: 54, bottom: -54, near: 1, far: 190 });
    this.sun.shadow.bias = -0.0018;
    this.sun.shadow.normalBias = 0.18;
    this.sun.shadow.radius = 2;
    scene.add(this.sun, this.sun.target);

    this.hemi = new THREE.HemisphereLight('#d7ebff', '#8c8d58', 1.6);
    scene.add(this.hemi);

    const tex = (moon = false) => {
      const c = canvas(16);
      const ctx = c.getContext('2d') as CanvasRenderingContext2D;
      ctx.fillStyle = moon ? '#dce5e1' : '#fff5ce';
      ctx.fillRect(0, 0, 16, 16);
      if (moon) {
        ctx.fillStyle = '#aebcbd';
        ctx.fillRect(3, 3, 4, 4);
        ctx.fillRect(10, 8, 3, 5);
        ctx.fillRect(4, 12, 3, 2);
      }
      const t = new THREE.CanvasTexture(c as HTMLCanvasElement);
      t.magFilter = THREE.NearestFilter;
      t.colorSpace = THREE.SRGBColorSpace;
      return t;
    };

    this.sunSprite = new THREE.Mesh(new THREE.PlaneGeometry(13, 13), new THREE.MeshBasicMaterial({ map: tex(), fog: false, toneMapped: false }));
    this.moon = new THREE.Mesh(new THREE.PlaneGeometry(9, 9), new THREE.MeshBasicMaterial({ map: tex(true), fog: false, toneMapped: false }));
    scene.add(this.sunSprite, this.moon);

    const glowCanvas = canvas(64);
    const gc = glowCanvas.getContext('2d') as CanvasRenderingContext2D;
    const gradient = gc.createRadialGradient(32, 32, 0, 32, 32, 32);
    gradient.addColorStop(0, 'rgba(255,238,171,.6)');
    gradient.addColorStop(0.2, 'rgba(255,226,153,.2)');
    gradient.addColorStop(1, 'rgba(255,220,130,0)');
    gc.fillStyle = gradient;
    gc.fillRect(0, 0, 64, 64);
    this.glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(glowCanvas as HTMLCanvasElement), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
    this.glow.scale.set(75, 75, 1);
    scene.add(this.glow);

    const rnd = random(9841);
    const starPositions: number[] = [];
    for (let i = 0; i < 650; i++) {
      const a = rnd() * Math.PI * 2;
      const y = rnd() * 2 - 1;
      const r = Math.sqrt(1 - y * y);
      starPositions.push(Math.cos(a) * r * 300, y * 300, Math.sin(a) * r * 300);
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.Float32BufferAttribute(starPositions, 3));
    this.stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: '#e5f1ff', size: 1.25, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false, fog: false }));
    scene.add(this.stars);

    this.clouds = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshLambertMaterial({ color: '#fffdf0', transparent: true, opacity: 0.91 }), 65);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < 65; i++) {
      const group = Math.floor(i / 5);
      dummy.position.set((group % 5) * 62 - 140 + rand(rnd, 14), 73 + Math.floor(group / 5) * 4 + rand(rnd, 1), Math.floor(group / 5) * 76 - 150 + rand(rnd, 12));
      dummy.scale.set(9 + rnd() * 14, 1.7 + rnd() * 2, 7 + rnd() * 11);
      dummy.updateMatrix();
      this.clouds.setMatrixAt(i, dummy.matrix);
    }
    this.clouds.instanceMatrix.needsUpdate = true;
    scene.add(this.clouds);

    this.rays = new THREE.Group();
    const rayMat = new THREE.MeshBasicMaterial({ color: '#fff0c5', transparent: true, opacity: 0.008, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending });
    for (let i = 0; i < 3; i++) {
      const ray = new THREE.Mesh(new THREE.PlaneGeometry(2.5 + i * 0.7, 90), rayMat);
      ray.position.set(-16 + i * 16, 40, -30 - i * 8);
      ray.rotation.z = -0.45;
      this.rays.add(ray);
    }
    scene.add(this.rays);

    // GPU-animated rain shader (zero CPU loop per frame)
    const rainGeo = new THREE.BufferGeometry();
    const drops: number[] = [];
    const speeds: number[] = [];
    for (let i = 0; i < 550; i++) {
      drops.push((Math.random() - 0.5) * 84, Math.random() * 48, (Math.random() - 0.5) * 84);
      speeds.push(18 + Math.random() * 8);
    }
    rainGeo.setAttribute('position', new THREE.Float32BufferAttribute(drops, 3));
    rainGeo.setAttribute('aSpeed', new THREE.Float32BufferAttribute(speeds, 1));
    this.rainMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uOpacity: { value: 0 }, uColor: { value: new THREE.Color('#bcd7ee') } },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute float aSpeed; uniform float uTime; void main(){ vec3 p = position; p.y = mod(p.y - uTime * aSpeed, 48.0); vec4 mv = modelViewMatrix * vec4(p, 1.0); gl_PointSize = clamp(42.0 / max(1.0, -mv.z), 1.5, 4.0); gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform float uOpacity; uniform vec3 uColor; void main(){ gl_FragColor = vec4(uColor, uOpacity); }`,
    });
    this.rain = new THREE.Points(rainGeo, this.rainMat);
    this.rain.frustumCulled = false;
    scene.add(this.rain);

    // GPU-animated ambient biome particles (cherry petals, fireflies, forest pollen, desert dust)
    const ambGeo = new THREE.BufferGeometry();
    const ambPos: number[] = [];
    const ambPhase: number[] = [];
    for (let i = 0; i < 160; i++) {
      ambPos.push((Math.random() - 0.5) * 56, Math.random() * 18, (Math.random() - 0.5) * 56);
      ambPhase.push(Math.random() * 6.283);
    }
    ambGeo.setAttribute('position', new THREE.Float32BufferAttribute(ambPos, 3));
    ambGeo.setAttribute('aPhase', new THREE.Float32BufferAttribute(ambPhase, 1));
    this.ambientMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uColor: { value: new THREE.Color('#f6b8cc') }, uOpacity: { value: 0.7 }, uFall: { value: 0.6 } },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute float aPhase; uniform float uTime; uniform float uFall; varying float vGlow;
      void main(){ vec3 p = position; p.y = mod(p.y - uTime * uFall + sin(uTime * 0.7 + aPhase) * 1.2, 18.0); p.x += sin(uTime * 0.9 + aPhase) * 1.4; p.z += cos(uTime * 0.8 + aPhase * 1.3) * 1.4; vGlow = 0.6 + 0.4 * sin(uTime * 2.5 + aPhase * 2.0); vec4 mv = modelViewMatrix * vec4(p, 1.0); gl_PointSize = clamp(48.0 / max(1.0, -mv.z), 2.0, 5.5); gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform float uOpacity; uniform vec3 uColor; varying float vGlow; void main(){ vec2 c = gl_PointCoord - 0.5; if(dot(c,c) > 0.25) discard; gl_FragColor = vec4(uColor * vGlow, uOpacity); }`,
    });
    this.ambientParticles = new THREE.Points(ambGeo, this.ambientMat);
    this.ambientParticles.frustumCulled = false;
    scene.add(this.ambientParticles);

    scene.fog = new THREE.Fog('#bbd8d8', 52, 120);
  }

  markShadow() {
    this.renderer.shadowMap.needsUpdate = true;
  }

  update(elapsed: number, time: number, camera: THREE.Camera, dimension: Dimension, settings: Settings, weather: 'clear' | 'rain' | 'storm' = 'clear', biome = 'plains') {
    this.weather = weather;
    this.uniforms.uTime.value = elapsed;
    this.waterUniforms.uTime.value = elapsed;
    this.rainMat.uniforms.uTime.value = elapsed;
    this.ambientMat.uniforms.uTime.value = elapsed;
    if (this.failed) this.material.visible = false;

    const angle = time * Math.PI * 2;
    const sinA = Math.sin(angle);
    const day = Math.max(0, sinA);
    const twilight = dimension === 'overworld' ? Math.max(0, 1 - Math.abs(sinA) * 3.2) : 0;
    const sunDir = new THREE.Vector3(-0.6, sinA, Math.cos(angle) * 0.55).normalize();
    this.daylight = day;

    const p = camera.position;
    this.sky.position.copy(p);
    this.stars.position.copy(p);
    (this.stars.material as THREE.PointsMaterial).opacity = Math.pow(1 - day, 3) * 0.9;

    const target = new THREE.Vector3(Math.round(p.x / 8) * 8, 18, Math.round(p.z / 8) * 8);
    this.sun.target.position.copy(target);
    this.sun.position.copy(target).addScaledVector(sunDir, 100);
    this.sun.intensity = 0.12 + day * 1.95;
    this.sun.color.set('#fff0d0').lerp(new THREE.Color('#ff9d5c'), twilight * 0.75);
    this.hemi.intensity = 0.3 + day * 1.15;

    this.sunSprite.position.copy(p).addScaledVector(sunDir, 260);
    this.sunSprite.lookAt(p);
    this.moon.position.copy(p).addScaledVector(sunDir, -260);
    this.moon.lookAt(p);
    this.glow.position.copy(this.sunSprite.position);
    this.sunSprite.visible = day > 0.02;
    this.glow.visible = day > 0.02;
    this.moon.visible = day < 0.2;

    const top = dimension === 'nether' ? new THREE.Color('#492725') : dimension === 'end' ? new THREE.Color('#252337') : new THREE.Color('#101d38').lerp(new THREE.Color('#6db4df'), day);
    const horizon = dimension === 'nether' ? new THREE.Color('#9b4b32') : dimension === 'end' ? new THREE.Color('#52465e') : new THREE.Color('#26354b').lerp(new THREE.Color('#d2e5da'), day);
    if (twilight > 0.01) horizon.lerp(new THREE.Color('#ebb07a'), twilight * 0.5);
    this.skyMaterial.uniforms.uTop.value.copy(top);
    this.skyMaterial.uniforms.uHorizon.value.copy(horizon);
    this.skyMaterial.uniforms.uSun.value.copy(sunDir);
    this.skyMaterial.uniforms.uDay.value = day;
    this.skyMaterial.uniforms.uTwilight.value = twilight;

    const fog = this.scene.fog as THREE.Fog;
    fog.color.copy(horizon);
    fog.near = settings.distance * 16 * 0.56;
    fog.far = settings.distance * 16 * 1.35;
    this.waterUniforms.uFog.value.copy(horizon);
    this.waterUniforms.uSun.value.copy(sunDir);
    this.waterUniforms.uNear.value = fog.near;
    this.waterUniforms.uFar.value = fog.far;

    this.clouds.position.x = Math.sin(elapsed * 0.006) * 18;
    this.clouds.visible = dimension === 'overworld';
    this.rays.visible = settings.bloom && dimension === 'overworld' && day > 0.2 && weather === 'clear';

    this.rain.visible = dimension === 'overworld' && weather !== 'clear';
    this.rainMat.uniforms.uOpacity.value = weather === 'storm' ? 0.65 : weather === 'rain' ? 0.44 : 0;
    this.rain.position.set(Math.round(p.x / 16) * 16, 16, Math.round(p.z / 16) * 16);

    // Ambient particles tailored to biome & time of day
    this.ambientParticles.position.set(p.x, Math.max(18, p.y - 4), p.z);
    if (dimension === 'nether') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#ff9e44');
      this.ambientMat.uniforms.uOpacity.value = 0.65;
      this.ambientMat.uniforms.uFall.value = -0.5;
    } else if (biome === 'cherry_grove') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#f8bfd2');
      this.ambientMat.uniforms.uOpacity.value = 0.85;
      this.ambientMat.uniforms.uFall.value = 0.85;
    } else if (biome === 'desert' || biome === 'badlands') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#dfc68a');
      this.ambientMat.uniforms.uOpacity.value = 0.35;
      this.ambientMat.uniforms.uFall.value = 0.15;
    } else if (day < 0.35 && (biome === 'swamp' || biome === 'forest' || biome === 'flower_forest' || biome === 'plains')) {
      // Fireflies at dusk/night
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#d8f56c');
      this.ambientMat.uniforms.uOpacity.value = 0.85;
      this.ambientMat.uniforms.uFall.value = 0.05;
    } else if (biome === 'forest' || biome === 'flower_forest' || biome === 'jungle') {
      // Soft sunlit forest spores/pollen
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#e9f2c4');
      this.ambientMat.uniforms.uOpacity.value = 0.38;
      this.ambientMat.uniforms.uFall.value = 0.18;
    } else {
      this.ambientParticles.visible = false;
    }
  }

  dispose() {
    this.atlas.dispose();
    this.material.dispose();
    this.fallback.dispose();
    this.water.dispose();
    this.skyMaterial.dispose();
    this.rainMat.dispose();
    this.ambientMat.dispose();
    for (const obj of [this.sky, this.sunSprite, this.moon, this.stars, this.clouds, this.rain, this.ambientParticles] as Array<THREE.Object3D & { geometry: THREE.BufferGeometry; material: THREE.Material & { map?: THREE.Texture } }>) {
      obj.geometry.dispose();
      obj.material.map?.dispose();
      obj.material.dispose();
    }
    this.glow.material.map?.dispose();
    this.glow.material.dispose();
    this.sun.shadow.map?.dispose();
  }
}

function rand(r: () => number, n: number) {
  return (r() - 0.5) * n;
}
