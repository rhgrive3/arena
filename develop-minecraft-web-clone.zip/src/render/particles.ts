import * as THREE from 'three';
interface Particle {mesh:THREE.Mesh;v:THREE.Vector3;life:number;max:number;}
interface Drop {mesh:THREE.Mesh;name:string;count:number;v:THREE.Vector3;age:number;}
export class ParticleSystem {
  particles:Particle[]=[];drops:Drop[]=[];geometry=new THREE.BoxGeometry(1,1,1);materials=new Map<string,THREE.MeshLambertMaterial>();
  private pool:THREE.Mesh[]=[];
  constructor(public scene:THREE.Scene){}
  material(color:string){let m=this.materials.get(color);if(!m){m=new THREE.MeshLambertMaterial({color});this.materials.set(color,m);}return m;}
  private acquire(mat:THREE.Material){const m=this.pool.pop();if(m){m.material=mat;m.visible=true;return m;}return new THREE.Mesh(this.geometry,mat);}
  private release(m:THREE.Mesh){m.visible=false;if(this.pool.length<180)this.pool.push(m);else this.scene.remove(m);}
  burst(p:THREE.Vector3,color:string,count=10,power=3){const mat=this.material(color);for(let i=0;i<count&&this.particles.length<140;i++){const mesh=this.acquire(mat);mesh.position.set(p.x+(Math.random()-.5)*.6,p.y+(Math.random()-.5)*.6,p.z+(Math.random()-.5)*.6);const s=.05+Math.random()*.08;mesh.scale.setScalar(s);mesh.rotation.set(0,0,0);if(!mesh.parent)this.scene.add(mesh);const life=.35+Math.random()*.45;this.particles.push({mesh,v:new THREE.Vector3((Math.random()-.5)*power,Math.random()*power,(Math.random()-.5)*power),life,max:life});}}
  drop(p:THREE.Vector3,name:string,count:number,color:string){if(this.drops.length>80){this.scene.remove(this.drops[0].mesh);this.drops.shift();}const mesh=new THREE.Mesh(this.geometry,this.material(color));mesh.position.copy(p);mesh.scale.setScalar(.22);this.scene.add(mesh);this.drops.push({mesh,name,count,v:new THREE.Vector3((Math.random()-.5)*2,3,(Math.random()-.5)*2),age:0});}
  update(dt:number,floor:(x:number,y:number,z:number)=>number,pickup:(name:string,count:number,position:THREE.Vector3)=>boolean){for(let i=this.particles.length-1;i>=0;i--){const p=this.particles[i];p.life-=dt;if(p.life<=0){this.release(p.mesh);this.particles.splice(i,1);continue;}p.v.y-=12*dt;p.mesh.position.x+=p.v.x*dt;p.mesh.position.y+=p.v.y*dt;p.mesh.position.z+=p.v.z*dt;p.mesh.rotation.x+=dt*3;p.mesh.scale.multiplyScalar(1-dt*.7);}
    for(let i=this.drops.length-1;i>=0;i--){const d=this.drops[i];d.age+=dt;d.v.y-=12*dt;const nx=d.mesh.position.x+d.v.x*dt,ny=d.mesh.position.y+d.v.y*dt,nz=d.mesh.position.z+d.v.z*dt;if(floor(nx,ny-.12,nz)>0){d.v.y=0;d.v.x*=.8;d.v.z*=.8;d.mesh.position.set(nx,Math.floor(ny-.12)+1.13,nz);}else d.mesh.position.set(nx,ny,nz);d.mesh.rotation.y+=dt*1.8;d.mesh.position.y+=Math.sin(d.age*3)*.002;if(d.age>1&&pickup(d.name,d.count,d.mesh.position)){this.scene.remove(d.mesh);this.drops.splice(i,1);}else if(d.age>300){this.scene.remove(d.mesh);this.drops.splice(i,1);}}}
  clear(){for(const p of this.particles)this.release(p.mesh);for(const d of this.drops)this.scene.remove(d.mesh);this.particles=[];this.drops=[];}
  dispose(){this.clear();for(const m of this.pool)this.scene.remove(m);this.pool=[];this.geometry.dispose();this.materials.forEach(m=>m.dispose());}
}
