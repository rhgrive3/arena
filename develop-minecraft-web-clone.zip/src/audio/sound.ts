import type { Settings } from '../game/types';
export class ProceduralAudio {
  context:AudioContext|null=null;master:GainNode|null=null;noise:AudioBuffer|null=null;musicTimer:ReturnType<typeof setInterval>|null=null;settings:Settings;step=0;
  constructor(settings:Settings){this.settings=settings;}
  resume(){try{if(!this.context){this.context=new AudioContext();this.master=this.context.createGain();this.master.connect(this.context.destination);const length=this.context.sampleRate*2;this.noise=this.context.createBuffer(1,length,this.context.sampleRate);const data=this.noise.getChannelData(0);let brown=0;for(let i=0;i<length;i++){brown=(brown+Math.random()*.04-.02)/1.02;data[i]=brown*3+(Math.random()*2-1)*.25;}this.configure(this.settings);this.musicTimer=setInterval(()=>{if(this.settings.music&&!this.settings.muted&&this.context?.state==='running')this.chord();},8500);}if(this.context.state==='suspended')this.context.resume().catch(()=>{});}catch{}}
  configure(s:Settings){this.settings=s;if(this.master&&this.context)this.master.gain.setTargetAtTime(s.muted?0:s.volume*.5,this.context.currentTime,.08);}
  play(kind:string,position?:{x:number;y:number;z:number}){const c=this.context;if(!c||!this.master||this.settings.muted||c.state!=='running')return;const now=c.currentTime,source=c.createBufferSource(),filter=c.createBiquadFilter(),gain=c.createGain();source.buffer=this.noise;source.playbackRate.value=.8+Math.random()*.4;let duration=.13,volume=.35,freq=900;
    if(kind==='grass'||kind==='step'){duration=.12;volume=.25;freq=650+Math.random()*600;filter.type='lowpass';}
    else if(kind==='stone'||kind==='mine'){duration=.1;volume=.48;freq=1900;filter.type='bandpass';}
    else if(kind==='wood'||kind==='place'){duration=.15;volume=.45;freq=480;filter.type='lowpass';}
    else if(kind==='water'){duration=.4;volume=.32;freq=2200;filter.type='bandpass';}
    else if(kind==='explosion'){duration=1.3;volume=.9;freq=160;filter.type='lowpass';}
    else if(kind==='click'){duration=.055;volume=.2;freq=1400;filter.type='bandpass';}
    else if(kind==='hurt'){duration=.22;volume=.4;freq=360;filter.type='lowpass';}
    else {duration=.23;volume=.22;freq=750;filter.type='bandpass';}
    filter.frequency.setValueAtTime(freq,now);filter.frequency.exponentialRampToValueAtTime(Math.max(60,freq*.35),now+duration);filter.Q.value=.7;gain.gain.setValueAtTime(.001,now);gain.gain.linearRampToValueAtTime(volume,now+.008);gain.gain.exponentialRampToValueAtTime(.001,now+duration);source.connect(filter);filter.connect(gain);
    let panner:PannerNode|null=null;if(position){panner=c.createPanner();panner.panningModel='HRTF';panner.distanceModel='inverse';panner.refDistance=3;panner.maxDistance=40;panner.positionX.value=position.x;panner.positionY.value=position.y;panner.positionZ.value=position.z;gain.connect(panner);panner.connect(this.master);}else gain.connect(this.master);
    source.start(now,Math.random()*.5);source.stop(now+duration+.03);source.onended=()=>{source.disconnect();filter.disconnect();gain.disconnect();panner?.disconnect();};
    if(kind==='wood'||kind==='place'||kind==='stone')for(let i=0;i<2;i++){const click=c.createBufferSource(),g=c.createGain();click.buffer=this.noise;g.gain.setValueAtTime(volume*.22,now+i*.026);g.gain.exponentialRampToValueAtTime(.001,now+i*.026+.024);click.connect(g);g.connect(this.master);click.start(now+i*.026,.7);click.stop(now+i*.026+.03);click.onended=()=>{click.disconnect();g.disconnect();};}
  }
  chord(){const c=this.context;if(!c||!this.master)return;const chords=[[130.81,164.81,196,261.63],[110,146.83,174.61,220],[87.31,130.81,174.61,220],[98,146.83,196,246.94]],notes=chords[this.step++%chords.length];notes.forEach((freq,i)=>{const osc=c.createOscillator(),gain=c.createGain(),filter=c.createBiquadFilter();osc.type='triangle';osc.frequency.value=freq;osc.detune.value=i%2?3:-3;filter.type='lowpass';filter.frequency.value=650;const start=c.currentTime+i*.45;gain.gain.setValueAtTime(0,start);gain.gain.linearRampToValueAtTime(.025,start+1.6);gain.gain.exponentialRampToValueAtTime(.0001,start+6);osc.connect(filter);filter.connect(gain);gain.connect(this.master!);osc.start(start);osc.stop(start+6.1);osc.onended=()=>{osc.disconnect();filter.disconnect();gain.disconnect();};});}
  listener(x:number,y:number,z:number,yaw:number){const l=this.context?.listener;if(!l)return;if(l.positionX){l.positionX.value=x;l.positionY.value=y;l.positionZ.value=z;l.forwardX.value=-Math.sin(yaw);l.forwardY.value=0;l.forwardZ.value=-Math.cos(yaw);l.upX.value=0;l.upY.value=1;l.upZ.value=0;}}
  dispose(){if(this.musicTimer)clearInterval(this.musicTimer);this.context?.close().catch(()=>{});this.context=null;}
}
