# 検証表

対象仕様は `data/VERSION.md` の Minecraft Java Edition 26.3 に固定。以下は記載範囲に限った検証であり、Java版の完全再現を意味しない。仕様の根拠と差異は `data/BLOCK_SPECS.md`、全体の未完項目は `TODO.md` に記録する。

## 今回の証拠

| 対象 | 実装 | 検証 | 結果 |
|---|---|---|---|
| チェスト・かまどの四方向 | `src/game/blockState.ts`, `src/world/mesher.ts`, `src/game/engine.ts` | `scripts/test-block-state.ts`, `scripts/test-block-mesh.ts`, `scripts/verify-blocks.ts` | PASS。実際の配置、メッシュの法線とタイル、保存後の再読込を確認。 |
| チェストの寸法と操作 | `src/world/shapes.ts`, `src/world/raycast.ts`, `src/game/engine.ts` | `scripts/test-raycast.ts`, `scripts/verify-blocks.ts`, `preview/block-facings.png` | PASS。小型の形状、レイ判定、上の石による開閉阻害、ガラス越しの開閉、中身の破壊時ドロップを確認。 |
| 原木の軸 | `src/game/blockState.ts`, `src/world/mesher.ts` | `scripts/test-block-state.ts`, `scripts/test-block-mesh.ts` | PASS。3軸の両端面を確認。 |
| ハーフブロック | `src/world/shapes.ts`, `src/game/engine.ts` | `scripts/test-block-state.ts`, `scripts/test-block-mesh.ts`, `scripts/test-raycast.ts`, `scripts/verify-blocks.ts` | PASS。上下・合体・当たり判定・保存後の状態を確認。 |
| 直線階段 | `src/world/shapes.ts`, `src/world/mesher.ts` | `scripts/test-block-state.ts`, `scripts/test-block-mesh.ts`, `scripts/verify-blocks.ts` | PASS。4方向×上下の形状、上半分のゲーム内設置を確認。 |
| 羊毛・コンクリートのハーフと階段 | `src/game/content.ts`, `src/systems/crafting.ts` | `scripts/test-block-content.ts` | PASS。16色×2素材×2形状の定義とレシピを確認。 |
| 主要採掘条件 | `src/systems/mining.ts`, `src/game/engine.ts` | `scripts/test-mining.ts`, `scripts/verify-blocks.ts` | PASS。主要ツールの採掘速度、鉄・ダイヤ鉱石のランクとドロップを確認。 |
| 水・溶岩 | `src/world/mesher.ts`, `src/render/environment.ts` | `scripts/test-fluid-mesh.ts`, `scripts/verify-blocks.ts`, `preview/fluids.png` | PASS。6面、内部面除去、別色の描画を確認。 |
| ディメンションごとの保存 | `src/game/engine.ts`, `src/game/types.ts` | `scripts/verify-blocks.ts` | PASS。同じ座標のオーバーワールドのチェストとネザーのかまど・内容物を行き来と再読込後に確認。 |
| 地形・境界 | `src/world/terrain.ts`, `src/world/mesher.ts` | `scripts/test-world.ts` | PASS。同じシードの地形、隣接チャンクの境界データと編集済み状態を確認。全条件での継ぎ目ゼロは未検証。 |
| 基本操作と描画 | `src/input`, `src/App.tsx`, `src/render` | `scripts/test-input.ts`, `scripts/verify-render.ts` | PASS。タイトル、昼景、水辺、インベントリ、スティック移動、採掘、設置、再読込。ブラウザエラー0。 |

生成テクスチャの連絡シートは `preview/atlas_sheet.png`。最新実行の機械可読結果は `preview/results.json` と `preview/block-results.json`。

## 未解決の差異

- 全ブロック・アイテム・モブ・バイオーム・レシピの完全な実装と公式版との差異ゼロは未達。
- 大型チェスト、猫による開閉阻害、チェスト開閉アニメーション、水没状態は未実装。
- 階段の角形状、ハーフブロックの一部の特殊な設置条件、水没状態は未実装。
- エンチャント、ステータス効果、シルクタッチ・幸運を含む採掘仕様や各ブロックの全硬度・ドロップは未網羅。
- レッドストーン、農業、乗り物、取引、醸造などは一部のみで、本家同等ではない。
- 地形・構造物・ネザー・エンドの生成は独自の近似で、ボス戦と本家と同じ生成条件は未完。
- ビルド成功と今回のテスト通過は、上記の未完部分の検証完了を意味しない。