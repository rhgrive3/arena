import assert from 'node:assert/strict';
import '../src/game/content';
import { BLOCKS, ID } from '../src/game/data';
import { BLOCK_ID_MASK, blockId, blockState, facingForYaw, FACING_FACES, localFaceForState, makeCell, stateForPlacement } from '../src/game/blockState';

for (const [yaw, expected] of [[0,0], [Math.PI / 2,3], [Math.PI,2], [-Math.PI / 2,1], [Math.PI * 2,0]] as const) {
  assert.equal(facingForYaw(yaw), expected);
  assert.equal(stateForPlacement(BLOCKS[ID.chest], yaw, {x:0,y:1,z:0}), expected);
  assert.equal(stateForPlacement(BLOCKS[ID.furnace], yaw, {x:0,y:1,z:0}), expected);
}
for (const name of ['chest','furnace','blast_furnace','smoker']) {
  const def = BLOCKS[ID[name]];
  for (let state=0; state<4; state++) {
    const cell = makeCell(def.id, state);
    assert.equal(blockId(cell), def.id);
    assert.equal(blockState(cell), state);
    assert.equal(localFaceForState(def, state, FACING_FACES[state]), 4, `${name} faces ${state}`);
    assert.equal(localFaceForState(def, state, 2), 2, `${name} top remains top`);
    assert.equal(localFaceForState(def, state, 3), 3, `${name} bottom remains bottom`);
    for (const face of FACING_FACES) if (face !== FACING_FACES[state]) assert.notEqual(localFaceForState(def, state, face),4);
  }
}
for (const [normal, axis, endFaces] of [
  [{x:0,y:1,z:0}, 0, [2,3]],
  [{x:1,y:0,z:0}, 1, [0,1]],
  [{x:0,y:0,z:-1}, 2, [4,5]],
] as const) {
  const def=BLOCKS[ID.oak_log], state=stateForPlacement(def,0,normal);
  assert.equal(state,axis);
  for (const f of [0,1,2,3,4,5] as const) assert.equal([2,3].includes(localFaceForState(def,state,f)), endFaces.includes(f as never));
}
assert.equal(blockId(27),27);
assert.equal(blockState(27),0);
assert.equal(makeCell(0,15),0);
const slab=BLOCKS[ID.oak_planks_slab],stairs=BLOCKS[ID.oak_planks_stairs];
assert.equal(ID.oak_slab,ID.oak_planks_slab,'legacy slab item names resolve to the same block');
assert.equal(ID.oak_stairs,ID.oak_planks_stairs,'legacy stair item names resolve to the same block');
assert.equal(stateForPlacement(slab,0,{x:0,y:1,z:0},.9),0);
assert.equal(stateForPlacement(slab,0,{x:0,y:-1,z:0},.1),1);
assert.equal(stateForPlacement(slab,0,{x:1,y:0,z:0},.2),0);
assert.equal(stateForPlacement(slab,0,{x:1,y:0,z:0},.8),1);
assert.equal(stateForPlacement(stairs,Math.PI/2,{x:1,y:0,z:0},.8),7);
assert.throws(()=>makeCell(BLOCK_ID_MASK+1,0),RangeError);
assert.throws(()=>makeCell(1,16),RangeError);
console.log('PASS block-state packing, legacy IDs, four facing directions, and log axes');