import assert from 'node:assert/strict';
import { stick, movement, look, clamp } from '../src/input/math';
let tests = 0;
const close = (a: number, b: number) => assert.ok(Math.abs(a - b) < 1e-8, `${a} != ${b}`);
for (const [dx, dy, x, f] of [[0,-48,0,1],[0,48,0,-1],[48,0,1,0],[-48,0,-1,0],[48,-48,Math.SQRT1_2,Math.SQRT1_2],[999,-999,Math.SQRT1_2,Math.SQRT1_2]]) {
  const s = stick(dx,dy); close(s.x,x); close(s.forward,f); tests += 2;
  for (const degrees of [0,90,180,270]) {
    const yaw = degrees * Math.PI / 180, m = movement(s.x,s.forward,yaw);
    close(m.x, x*Math.cos(yaw)-f*Math.sin(yaw)); close(m.z,-x*Math.sin(yaw)-f*Math.cos(yaw));
    assert.ok(Math.hypot(m.x,m.z)<=1.00000001); tests += 3;
  }
}
close(movement(0,1,Math.PI/2).x,-1); close(movement(1,0,0).x,1);
close(look(0,0,100,0).yaw,-0.25); close(look(0,0,0,-100).pitch,0.25);
close(look(0,0,0,-10000).pitch,89*Math.PI/180); close(look(0,0,0,10000).pitch,-89*Math.PI/180);
close(look(0,0,100,0,.0025,true).yaw,.25); close(look(0,0,0,100,.0025,false,true).pitch,.25);
assert.equal(clamp(50,0,10),10); tests += 9;
console.log(`PASS ${tests} independent input assertions`);
