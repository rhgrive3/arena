import assert from 'node:assert/strict';
import { Terrain, MIN_Y, HEIGHT } from '../src/world/terrain';
import { meshChunk } from '../src/world/mesher';
import { BLOCKS, ID } from '../src/game/data';
import { makeCell } from '../src/game/blockState';
const a=new Terrain('849281'),b=new Terrain('849281'),c=new Terrain('different');
let changed=false;
for(let z=-96;z<96;z+=16)for(let x=-96;x<96;x+=16){const ga=a.generate(x/16,z/16),gb=b.generate(x/16,z/16);assert.deepEqual(ga.data,gb.data);const gc=c.generate(x/16,z/16);if(!ga.data.every((v,i)=>v===gc.data[i]))changed=true;for(const value of ga.data)assert.ok(value<BLOCKS.length);}
assert.ok(changed);
const flat=new Uint16Array(18*18*HEIGHT);for(let z=1;z<=16;z++)for(let x=1;x<=16;x++)flat[(21-MIN_Y)*324+z*18+x]=2;
const tiles=BLOCKS.map(()=>Array(6).fill(0));const m=meshChunk(flat,23,tiles);
assert.equal(m.solid.position.length/3,24);assert.equal(m.solid.index.length,36);
for(let i=0;i<m.solid.normal.length;i+=3){const n=m.solid.normal.slice(i,i+3);assert.equal(Math.hypot(...n),1);}
const p=Array.from(m.solid.position);assert.ok(p.some((v,i)=>i%3===0&&v===16));assert.ok(!p.some((v,i)=>i%3===1&&v<20));
const edits:[string,number][]=[['16,40,4',makeCell(ID.chest,3)],['15,42,9',makeCell(ID.oak_log,1)]];
const left=a.generate(0,0,edits,true),right=a.generate(1,0,edits,true);
for(let y=MIN_Y;y<70;y++)for(let z=0;z<16;z++){
  const yi=y-MIN_Y;
  assert.equal(left.padded[yi*324+(z+1)*18+17],right.data[yi*256+z*16],`right edge at ${y},${z}`);
  assert.equal(right.padded[yi*324+(z+1)*18],left.data[yi*256+z*16+15],`left edge at ${y},${z}`);
}
console.log('PASS deterministic terrain, seed variation, valid IDs, greedy faces, normals, chunk-edge coverage');
