import assert from 'node:assert/strict';
import { BLOCKS, ID } from '../src/game/data';
import { DYES } from '../src/game/content';
import { RECIPES, canCraft } from '../src/systems/crafting';

const ids=new Set<number>();
for(const color of Object.keys(DYES))for(const material of ['wool','concrete'])for(const shape of ['slab','stairs'] as const){
  const base=`${color}_${material}`,name=`${base}_${shape}`,id=ID[name],def=BLOCKS[id];
  assert.ok(def,`${name} exists`);assert.equal(def.shape,shape);assert.equal(def.name,name);
  assert.equal(ids.has(id),false,`${name} must not alias another variant`);ids.add(id);
  const recipe=RECIPES.find(r=>r.id===name);assert.ok(recipe,`${name} has a recipe`);
  const count=shape==='slab'?3:6;
  assert.equal(recipe.ingredients[base],count);assert.equal(recipe.count,shape==='slab'?6:4);
  assert.ok(canCraft(recipe,{[base]:count},false,true));assert.ok(!canCraft(recipe,{[base]:count-1},false,true));
}
assert.equal(ids.size,64);
for(const wood of ['oak','spruce','birch','jungle','acacia','dark_oak','cherry'])for(const shape of ['slab','stairs','fence']){
  assert.equal(ID[`${wood}_${shape}`],ID[`${wood}_planks_${shape}`]);
  assert.equal(BLOCKS[ID[`${wood}_${shape}`]].name,`${wood}_${shape}`);
}
assert.equal(RECIPES.find(r=>r.id==='birch_planks')?.result,'birch_planks');
for(const wood of ['spruce','jungle','acacia','dark_oak','cherry','mangrove','pale_oak','poplar']){
  const recipe=RECIPES.find(r=>r.id===wood+'_planks');
  assert.equal(recipe?.result,wood+'_planks');assert.equal(recipe?.ingredients[wood+'_log'],1);
}
console.log('PASS 64 colored slab/stair variants, recipes, and legacy wood aliases');