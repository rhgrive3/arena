import assert from 'node:assert/strict';
import '../src/game/content';
import { BLOCKS, ID } from '../src/game/data';
import { blockId, makeCell } from '../src/game/blockState';
import { HEIGHT, MIN_Y, Terrain } from '../src/world/terrain';
import { meshChunk } from '../src/world/mesher';
import { selectionBoxes } from '../src/world/shapes';

const tiles=BLOCKS.map((_,id)=>Array.from({length:6},(_,face)=>id*6+face));
const position=(x:number,y:number,z:number)=>(y-MIN_Y)*324+(z+1)*18+x+1;
const faceFromNormal=(x:number,y:number,z:number)=>x===1?0:x===-1?1:y===1?2:y===-1?3:z===1?4:5;
const expectedFront=[4,1,5,0];
for(const name of ['chest','furnace','blast_furnace','smoker'])for(let facing=0;facing<4;facing++){
  const id=ID[name],padded=new Uint16Array(18*18*HEIGHT);
  padded[position(4,21,4)]=makeCell(id,facing);
  const mesh=meshChunk(padded,23,tiles).solid;
  assert.equal(mesh.position.length/3,24,`${name}: six quads`);
  let fronts=0;
  for(let q=0;q<6;q++){
    const face=faceFromNormal(mesh.normal[q*12],mesh.normal[q*12+1],mesh.normal[q*12+2]);
    const materialFace=mesh.tile[q*4]-id*6;
    if(materialFace===4){fronts++;assert.equal(face,expectedFront[facing],`${name}: front points to expected face`);}
    if(face===2||face===3)assert.equal(materialFace,face,`${name}: top and bottom`);
  }
  assert.equal(fronts,1,`${name}: only one front`);
  if(name==='chest'){
    const xs=Array.from(mesh.position).filter((_,i)=>i%3===0);
    const ys=Array.from(mesh.position).filter((_,i)=>i%3===1);
    assert.equal(Math.min(...xs),4+1/16);assert.equal(Math.max(...xs),4+15/16);
    assert.equal(Math.max(...ys),21+14/16);
  }
}
for(const axis of [0,1,2]){
  const id=ID.oak_log,padded=new Uint16Array(18*18*HEIGHT);
  padded[position(4,21,4)]=makeCell(id,axis);
  const mesh=meshChunk(padded,23,tiles).solid;
  const ends=[];
  for(let q=0;q<6;q++){
    const face=faceFromNormal(mesh.normal[q*12],mesh.normal[q*12+1],mesh.normal[q*12+2]);
    if([2,3].includes(mesh.tile[q*4]-id*6)) ends.push(face);
  }
  assert.deepEqual(ends.sort(),[[2,3],[0,1],[4,5]][axis]);
}
for(const [state,minY,maxY] of [[0,21,21.5],[1,21.5,22],[2,21,22]] as const){
  const padded=new Uint16Array(18*18*HEIGHT),id=ID.oak_planks_slab;
  padded[position(4,21,4)]=makeCell(id,state);
  const mesh=meshChunk(padded,23,tiles).solid;
  const ys=Array.from(mesh.position).filter((_,i)=>i%3===1);
  assert.equal(Math.min(...ys),minY);assert.equal(Math.max(...ys),maxY);
}
{
  const padded=new Uint16Array(18*18*HEIGHT),id=ID.furnace;
  padded[position(4,21,4)]=makeCell(id,0);padded[position(5,21,4)]=makeCell(id,2);
  const mesh=meshChunk(padded,23,tiles).solid;
  const south=[];for(let q=0;q<mesh.tile.length/4;q++)if(mesh.normal[q*12+2]===1)south.push(mesh.tile[q*4]-id*6);
  assert.deepEqual(south.sort(),[4,5],'differently oriented neighboring faces must not merge');
}
for(let state=0;state<8;state++){
  const padded=new Uint16Array(18*18*HEIGHT),id=ID.oak_stairs;
  padded[position(4,21,4)]=makeCell(id,state);
  const mesh=meshChunk(padded,23,tiles).solid,box=selectionBoxes(BLOCKS[id],state)[1];
  const points=Array.from(mesh.position).slice(6*12);
  const xs=points.filter((_,i)=>i%3===0),ys=points.filter((_,i)=>i%3===1),zs=points.filter((_,i)=>i%3===2);
  assert.equal(Math.min(...xs),4+box[0]);assert.equal(Math.max(...xs),4+box[3]);
  assert.equal(Math.min(...ys),21+box[1]);assert.equal(Math.max(...ys),21+box[4]);
  assert.equal(Math.min(...zs),4+box[2]);assert.equal(Math.max(...zs),4+box[5]);
}
const terrain=new Terrain('state-round-trip');
for(const cell of [makeCell(ID.chest,3),makeCell(ID.furnace,2),makeCell(ID.oak_log,1)]){
  const generated=terrain.generate(0,0,[['4,70,4',cell]],false);
  assert.equal(generated.data[(70-MIN_Y)*256+4*16+4],cell);
  assert.ok(blockId(cell)>0);
}
const end=new Terrain('state-round-trip','end'),endCell=makeCell(ID.chest,3);
const endChunk=end.generate(10,10,[['160,20,160',endCell]],false);
assert.equal(endChunk.data[(20-MIN_Y)*256],endCell,'edits persist in an otherwise empty End chunk');
console.log('PASS meshed front faces, non-cube chest dimensions, log axes, and chunk state round trip');