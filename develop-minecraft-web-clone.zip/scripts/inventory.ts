import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const output = path.join(root, 'data');
fs.mkdirSync(output, { recursive: true });
const manifest = await (await fetch('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json')).json();
const target = manifest.versions.find((v: any) => v.id === manifest.latest.release);
const metadata = await (await fetch(target.url)).json();
fs.writeFileSync(path.join(output, 'official-version.json'), JSON.stringify({ latest: manifest.latest, releaseTime: target.releaseTime, url: target.url, dataVersion: metadata.world_version?.data_version?.major, assetIndex: metadata.assetIndex?.url }, null, 2));
const report = path.join(output, 'reports', 'reports');
const available = ['blocks', 'registries'].every(f => fs.existsSync(path.join(report, f + '.json')));
if (!available) throw new Error('Official server-generated registries have not been produced. No substitute is marked verified.');
const blocks = JSON.parse(fs.readFileSync(path.join(report, 'blocks.json'), 'utf8'));
const registries = JSON.parse(fs.readFileSync(path.join(report, 'registries.json'), 'utf8'));
const items = registries['minecraft:item'].entries;
const mobs = Object.keys(registries['minecraft:entity_type'].entries).map(x => x.replace('minecraft:', '')).filter(x => !['player', 'item', 'experience_orb', 'fishing_bobber', 'arrow', 'spectral_arrow', 'item_frame', 'glow_item_frame', 'painting', 'armor_stand', 'tnt', 'falling_block', 'firework_rocket', 'eye_of_ender', 'ender_pearl', 'egg', 'snowball', 'potion', 'experience_bottle', 'trident', 'leash_knot', 'area_effect_cloud', 'evoker_fangs', 'lightning_bolt', 'marker', 'interaction', 'block_display', 'item_display', 'text_display', 'ominous_item_spawner'].includes(x));
const biomes = [...new Set(['overworld', 'nether'].flatMap(d => JSON.parse(fs.readFileSync(path.join(report, 'biome_parameters', 'minecraft', d + '.json'), 'utf8')).biomes.map((b: any) => b.biome.replace('minecraft:', ''))).concat(['the_end', 'end_highlands', 'end_midlands', 'small_end_islands', 'end_barrens', 'the_void']))];
const inventory = { target: target.id, releaseTime: target.releaseTime, blocks: Object.entries(blocks).map(([name, data]: [string, any]) => ({ name, states: data.states?.length ?? 1, properties: data.states?.[0]?.properties ?? {} })), items: Object.keys(items).map(x => x.replace('minecraft:', '')), mobs, biomes };
fs.writeFileSync(path.join(output, 'inventory.json'), JSON.stringify(inventory, null, 2));
const todoPath = path.join(root, 'TODO.md');
let todo = fs.readFileSync(todoPath, 'utf8');
const start = todo.indexOf('\n## 対象公式レジストリ');
if (start >= 0) todo = todo.slice(0, start);
todo += `\n## 対象公式レジストリ — ${target.id}\n公式サーバーの --reports 出力。以下は存在の一致であり実装・動作検証ではない。各コンテンツの全状態の完全再現は独立差異として扱う。\n`;
for (const [category, prefix, values] of [
  ['ブロック（テクスチャ・形状・ドロップ・挙動）', 'R-B', inventory.blocks.map(x => x.name)],
  ['アイテム（テクスチャ・用途・レシピ）', 'R-I', inventory.items],
  ['エンティティ（モデル・関節・AI・スポーン・ドロップ・音）', 'R-M', mobs],
  ['バイオーム（地形・地表・植生・構造物）', 'R-C', biomes],
] as const) {
  todo += `\n### ${category}\n`;
  for (const [i, name] of values.entries()) todo += `- [ ] 未着手 ${prefix}${String(i).padStart(4, '0')} ${name}\n`;
}
fs.writeFileSync(todoPath, todo);
fs.writeFileSync(path.join(output, 'VERSION.md'), `# 対象バージョン\n\n- Minecraft Java Edition **${target.id}**\n- 正式リリース: ${target.releaseTime}\n- 確定根拠: Mojang公式 version_manifest_v2.json の latest.release\n- メタデータ: ${target.url}\n- Data version: ${metadata.world_version?.data_version?.major ?? '公式メタデータに未記載'}\n- コンテンツ根拠: 同じ正式版のサーバーを --reports で実行した blocks/items/registries\n- ブロック ${inventory.blocks.length} / アイテム ${inventory.items.length} / 対象モブ ${mobs.length} / バイオーム ${biomes.length}\n- スナップショットは対象としない。minecraft-data の旧版を最新仕様とは見なさない。\n- 26.3 Wilderness Bound は2026-09-15公開。Poplar、Dappled Forest、Abandoned Camp、羊毛/コンクリートの階段・ハーフ、Cushion、Straw Bedを含む。\n- 外部公式データは仕様調査とID突合のみ。ゲーム素材は独自生成。\n\n## 情報源\n- https://piston-meta.mojang.com/mc/game/version_manifest_v2.json\n- https://minecraft.wiki/w/Java_Edition_26.3\n- https://minecraft.wiki/w/Breaking\n- https://www.minecraft.net/en-us/article/minecraft-java-edition-26-3 (検索で確認。本文直接取得はエラー)\n- https://minecraft.fandom.com/wiki/Crafting (直接取得エラー。採用仕様とは区別)\n\n## 既知の調査限界\n全仕様を旧版から無条件採用しない。未確認の条件・例外はVERIFICATION.mdに差異として残す。\n`);
console.log(JSON.stringify({ target: target.id, blocks: inventory.blocks.length, items: inventory.items.length, mobs: mobs.length, biomes: biomes.length }));
