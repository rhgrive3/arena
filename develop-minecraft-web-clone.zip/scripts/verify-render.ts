import { chromium } from 'playwright';
import { preview } from 'vite';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import '../src/game/content';
import { ID as BID, faceTile, BLOCKS } from '../src/game/data';
fs.mkdirSync('preview',{recursive:true});
const server=await preview({preview:{host:'127.0.0.1',port:0}});
const address=server.httpServer.address();
if(!address||typeof address==='string')throw new Error('Preview server did not expose a port');
const browser=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:960,height:600},deviceScaleFactor:1});
await page.addInitScript(()=>localStorage.setItem('voxel.settings',JSON.stringify({quality:'low',distance:2,touch:false,muted:true,bloom:false,bobbing:false})));
const errors:string[]=[],warnings:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());if(m.type()==='warning')warnings.push(m.text());});
const results:Record<string,unknown>={};
try{
  await page.goto(`http://127.0.0.1:${address.port}`,{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>!!(window as any).__game,undefined,{timeout:60000});
  await page.waitForFunction(()=>!!(window as any).__game?.ready,undefined,{timeout:60000});
  await page.waitForTimeout(1000);await page.screenshot({path:'preview/01-title.png',timeout:30000});
  results.title=await page.title();results.initialChunks=await page.evaluate(()=>(window as any).__game.chunks.size);
  await page.getByRole('button',{name:'シングルプレイ',exact:true}).click();
  await page.waitForTimeout(300);
  await page.getByRole('button',{name:'この世界で遊ぶ'}).click();
  await page.waitForFunction(()=>(window as any).__game.active&&document.querySelector('.hotbar'),undefined,{timeout:60000});
  await page.waitForTimeout(1500);await page.screenshot({path:'preview/02-world-day.png'});
  results.spawn=await page.evaluate(()=>{const g=(window as any).__game;return {position:g.position.toArray(),grounded:g.grounded,ready:g.ready};});
  await page.evaluate(()=>{const g=(window as any).__game;g.teleport(16,Math.max(21.2,g.terrain.height(16,18)+1.1),18);g.input.yaw=-1.35;g.input.pitch=-.24;});
  await page.waitForTimeout(2000);await page.screenshot({path:'preview/03-water-shadow.png'});
  await page.keyboard.press('e');await page.waitForSelector('.inventory-overlay');await page.waitForTimeout(400);await page.screenshot({path:'preview/04-inventory.png'});
  assert.equal(await page.locator('.inventory-grid .item-slot').count(),36);
  await page.keyboard.press('e');await page.waitForSelector('.hotbar');
  await page.evaluate(()=>{const g=(window as any).__game;g.teleport(-11,g.terrain.height(-11,27)+1.1,27);g.input.yaw=0;g.input.pitch=0;});await page.waitForTimeout(600);
  await page.getByTitle('ポーズ (Esc)').click();await page.getByRole('button',{name:'オプション',exact:true}).last().click();await page.getByRole('button',{name:'操作',exact:true}).click();await page.getByRole('switch').nth(2).click();await page.getByRole('button',{name:'完了',exact:true}).click();await page.keyboard.press('Escape');
  await page.waitForSelector('.joystick');const box=await page.locator('.joystick').boundingBox();assert.ok(box);
  const before=await page.evaluate(()=>(window as any).__game.position.toArray());
  await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width/2,box.y+10,{steps:5});await page.waitForTimeout(800);await page.mouse.up();await page.waitForTimeout(200);
  const after=await page.evaluate(()=>({position:(window as any).__game.position.toArray(),stick:(window as any).__game.input.stickForward}));
  results.stick={before,after};assert.ok(Math.hypot(after.position[0]-before[0],after.position[2]-before[2])>.3,'Joystick must move the player');assert.ok(Math.abs(after.stick) < 1e-8,'Joystick must release');
  await page.screenshot({path:'preview/05-touch-movement.png'});
  await page.evaluate(()=>{const g=(window as any).__game;const x=Math.floor(g.camera.position.x),y=Math.floor(g.camera.position.y),z=Math.floor(g.camera.position.z)-2;g.setBlock(x,y,z,2);g.input.yaw=0;g.input.pitch=0;g.select(1);});
  await page.waitForTimeout(500);
  const targetCheck=await page.evaluate(()=>{const g=(window as any).__game;const t=g.raycast();return t?{x:t.x,y:t.y,z:t.z,id:t.id}:null;});
  results.miningTarget=targetCheck;
  const minedBefore=await page.evaluate(()=>(window as any).__game.statistics.blocks_mined||0);
  await page.evaluate(()=>{(window as any).__game.input.breakHeld=true;});
  let minedAfter=minedBefore;
  for(let i=0;i<25;i++){await page.waitForTimeout(200);minedAfter=await page.evaluate(()=>(window as any).__game.statistics.blocks_mined||0);if(minedAfter>minedBefore)break;}
  await page.evaluate(()=>{(window as any).__game.input.breakHeld=false;});
  results.mining={before:minedBefore,after:minedAfter};assert.ok(minedAfter>minedBefore,'Mining must break a block');
  const placedBefore=await page.evaluate(()=>(window as any).__game.statistics.blocks_placed||0);
  await page.evaluate(()=>{const g=(window as any).__game;const x=Math.floor(g.camera.position.x),y=Math.floor(g.camera.position.y),z=Math.floor(g.camera.position.z)-3;g.setBlock(x,y,z,2);g.select(0);g.input.yaw=0;g.input.pitch=0;});
  await page.waitForTimeout(400);
  await page.evaluate(()=>{(window as any).__game.use();});
  await page.waitForTimeout(300);
  const placedAfter=await page.evaluate(()=>(window as any).__game.statistics.blocks_placed||0);results.placing={before:placedBefore,after:placedAfter};assert.ok(placedAfter>placedBefore,'Placement must place a block');
  // Block face orientation check: chest (front latch must be on side, plain top) + furnace (opening on front)
  await page.evaluate(({chest,furnace,table,stone})=>{
    const g=(window as any).__game;g.teleport(-8.5,64,29.5);g.flying=true;g.velocity.set(0,0,0);g.input.yaw=0;g.input.pitch=-.1;
    for(let i=0;i<6;i++){const x=-14+i*2;g.setBlock(x,64,22,stone);g.setBlock(x,65,22,i<3?chest:i===5?table:furnace,i%3);}
  },{chest:BID.chest,furnace:BID.furnace,table:BID.crafting_table,stone:BID.stone});
  await page.waitForFunction(()=>{const g=(window as any).__game,key='-1,1';return g.chunks.get(key)?.version===(g.versions.get(key)??0)&&!g.pending.has(key)&&!g.queued.has(key);},null,{timeout:90000,polling:250});
  await page.waitForTimeout(500);await page.screenshot({path:'preview/06-block-faces.png'});
  // Assert per-face texture assignment matches Minecraft convention
  const faceCheck={
    chest:{top:faceTile(BLOCKS[BID.chest],2),bottom:faceTile(BLOCKS[BID.chest],3),front:faceTile(BLOCKS[BID.chest],4),side:faceTile(BLOCKS[BID.chest],0)},
    furnace:{top:faceTile(BLOCKS[BID.furnace],2),bottom:faceTile(BLOCKS[BID.furnace],3),front:faceTile(BLOCKS[BID.furnace],4),side:faceTile(BLOCKS[BID.furnace],0)},
    crafting_table:{top:faceTile(BLOCKS[BID.crafting_table],2),bottom:faceTile(BLOCKS[BID.crafting_table],3),front:faceTile(BLOCKS[BID.crafting_table],4)},
    grass:{top:faceTile(BLOCKS[BID.grass_block],2),bottom:faceTile(BLOCKS[BID.grass_block],3),side:faceTile(BLOCKS[BID.grass_block],0)},
    oak_log:{top:faceTile(BLOCKS[BID.oak_log],2),side:faceTile(BLOCKS[BID.oak_log],0)},
    tnt:BID.tnt!==undefined?{top:faceTile(BLOCKS[BID.tnt],2),side:faceTile(BLOCKS[BID.tnt],0)}:null,
  };
  results.faceCheck=faceCheck;
  assert.equal(faceCheck.chest.front,'chest_front','chest latch must be on the front face');
  assert.equal(faceCheck.chest.top,'chest_top','chest top must be plain wood');
  assert.equal(faceCheck.chest.side,'chest_side','chest side must be plain wood');
  assert.equal(faceCheck.furnace.front,'furnace_front','furnace opening must be on the front face');
  assert.notEqual(faceCheck.furnace.top,faceCheck.furnace.front,'furnace top must not show the opening');
  assert.equal(faceCheck.crafting_table.top,'crafting_table_top','crafting grid must be on top');
  assert.equal(faceCheck.crafting_table.bottom,'oak_planks','crafting table bottom must be planks');
  assert.equal(faceCheck.grass.top,'grass_block','grass top must use grass texture');
  assert.equal(faceCheck.grass.bottom,'dirt','grass bottom must use dirt texture');
  assert.equal(faceCheck.grass.side,'grass_side','grass side must use side texture');
  assert.equal(faceCheck.oak_log.top,'oak_log_top','log top must show rings');
  assert.equal(faceCheck.oak_log.side,'oak_log','log side must show bark');
  if(faceCheck.tnt){assert.equal(faceCheck.tnt.top,'tnt_top');assert.equal(faceCheck.tnt.side,'tnt_side');}
  await page.evaluate(()=>(window as any).__game.save());await page.waitForTimeout(200);
  const saved=await page.evaluate(()=>{const g=(window as any).__game;return JSON.parse(localStorage.getItem('voxel.save.'+g.meta.id)||'null');});assert.ok(saved&&saved.edits.length>0,'World edits must persist');results.savedEdits=saved.edits.length;
  results.render=await page.evaluate(()=>{const g=(window as any).__game;return {triangles:g.renderer.info.render.triangles,calls:g.renderer.info.render.calls,shaderFallback:g.environment.failed};});
  await page.reload({waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>Boolean((window as any).__game?.ready),null,{timeout:90000,polling:200});
  await page.getByRole('button',{name:'シングルプレイ',exact:true}).click();
  await page.locator('.world-row-main').first().click();
  await page.waitForFunction(()=>Boolean((window as any).__game?.active),null,{timeout:90000,polling:200});
  const restored=await page.evaluate(()=>({edits:(window as any).__game.edits.size,chest:(window as any).__game.getCell(-12,65,22)}));
  assert.equal(restored.edits,saved.edits.length,'saved edits must survive reload');
  assert.equal(restored.chest, BID.chest | (1<<12),'placed direction must survive reload');
  results.restored=restored;
  results.errors=errors;results.warnings=warnings;assert.equal(errors.length,0,JSON.stringify(errors));assert.equal(warnings.filter(x=>x.includes('Shader')).length,0,'Shader fallback is not acceptable');
  fs.writeFileSync('preview/results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));
}catch(e){fs.writeFileSync('preview/results.json',JSON.stringify({failure:String(e),errors,warnings,results},null,2));await page.screenshot({path:'preview/failure.png'});throw e;}finally{await browser.close();await new Promise<void>(resolve=>server.httpServer.close(()=>resolve()));}
