import assert from 'node:assert/strict';
import '../src/game/content';
import { BLOCKS, ID } from '../src/game/data';
import { HEIGHT, MIN_Y } from '../src/world/terrain';
import { meshChunk } from '../src/world/mesher';

const tiles=BLOCKS.map(()=>[0,0,0,0,0,0]);
const index=(x:number,y:number,z:number)=>(y-MIN_Y)*324+(z+1)*18+x+1;
for(const [id,expectedFluid] of [[ID.water,0],[ID.lava,1]] as const){
  const data=new Uint16Array(18*18*HEIGHT);data[index(4,21,4)]=id;
  const mesh=meshChunk(data,23,tiles).water;
  assert.equal(mesh.position.length/3,24,'an isolated fluid cell has six visible faces');
  const normals=new Set<string>();
  for(let q=0;q<6;q++)normals.add(Array.from(mesh.normal.slice(q*12,q*12+3)).join(','));
  for(const normal of ['1,0,0','-1,0,0','0,1,0','0,-1,0','0,0,1','0,0,-1'])assert.ok(normals.has(normal),normal);
  assert.ok(Array.from(mesh.tile).every(tile=>tile===expectedFluid),'water and lava have separate shader material tags');
}
const data=new Uint16Array(18*18*HEIGHT);data[index(4,21,4)]=ID.water;data[index(5,21,4)]=ID.water;
const adjacent=meshChunk(data,23,tiles).water;
assert.equal(adjacent.index.length,36,'interior fluid faces are culled');
console.log('PASS six fluid faces, lava shader tag, and internal face culling');