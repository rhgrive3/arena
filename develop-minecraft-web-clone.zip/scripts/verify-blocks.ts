import { chromium } from 'playwright';
import { preview } from 'vite';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import '../src/game/content';
import { ID } from '../src/game/data';

fs.mkdirSync('preview',{recursive:true});
const server=await preview({preview:{host:'127.0.0.1',port:0}});
const address=server.httpServer.address();
if(!address||typeof address==='string')throw new Error('Preview server did not expose a port');
const browser=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:960,height:600},deviceScaleFactor:1});
const errors:string[]=[];
page.on('pageerror',error=>errors.push(error.message));
page.on('console',message=>{if(message.type()==='error')errors.push(message.text());});
await page.addInitScript(()=>localStorage.setItem('voxel.settings',JSON.stringify({quality:'low',distance:2,touch:true,muted:true,bloom:false,bobbing:false})));
const results:Record<string,unknown>={};
try{
  await page.goto(`http://127.0.0.1:${address.port}`,{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>Boolean((window as any).__game?.ready),null,{timeout:90000,polling:200});
  await page.screenshot({path:'preview/blocks-title.png'});
  await page.evaluate(()=>{
    const game=(window as any).__game;
    game.start({...game.meta,id:'block-verification',name:'Block verification',seed:'849281',mode:'creative',bonus:false,structures:false});
  });
  await page.waitForFunction(()=>Boolean((window as any).__game?.active&&document.querySelector('.hotbar')),null,{timeout:90000,polling:200});

  const placements=await page.evaluate(({stone})=>{
    const g=(window as any).__game, cases=[];
    g.flying=true;g.teleport(-8.5,60,24.5);g.camera.position.set(-8.5,61.62,24.5);g.velocity.set(0,0,0);
    const directions=[{yaw:0,dx:0,dz:-1,state:0},{yaw:Math.PI/2,dx:-1,dz:0,state:3},{yaw:Math.PI,dx:0,dz:1,state:2},{yaw:-Math.PI/2,dx:1,dz:0,state:1}];
    for(const [name,y] of [['chest',61],['furnace',63]] as const){
      g.position.y=y-1.62;g.camera.position.y=y+.0;
      for(const d of directions){
        const x=-9+d.dx*4,z=24+d.dz*4,placedX=x-d.dx,placedZ=z-d.dz;
        g.setBlock(x,y,z,stone);g.hotbar[0]={name,count:64};g.select(0);g.input.yaw=d.yaw;g.input.pitch=0;
        const before=g.statistics.blocks_placed??0;g.use();
        cases.push({name,yaw:d.yaw,expected:d.state,cell:g.getCell(placedX,y,placedZ),x:placedX,y,z:placedZ,increment:(g.statistics.blocks_placed??0)-before});
      }
    }
    return cases;
  },{stone:ID.stone});
  for(const p of placements){
    assert.equal(p.cell&0xfff,ID[p.name],`${p.name}: placement`);
    assert.equal(p.cell>>>12,p.expected,`${p.name}: placement direction`);
    assert.equal(p.increment,1,`${p.name}: placement statistics`);
  }
  results.placements=placements;

  const halfBlocks=await page.evaluate(({stone})=>{
    const g=(window as any).__game,created=[];
    g.flying=true;g.input.pitch=0;g.input.yaw=0;
    for(const c of [
      {name:'oak_slab',x:-9,y:67,hit:.25,expected:0},
      {name:'oak_slab',x:-6,y:69,hit:.75,expected:1},
      {name:'oak_stairs',x:-3,y:71,hit:.75,expected:4},
    ]){
      g.teleport(c.x+.5,c.y+c.hit-1.62,24.5);g.camera.position.set(c.x+.5,c.y+c.hit,24.5);
      g.setBlock(c.x,c.y,20,stone);g.hotbar[0]={name:c.name,count:64};g.select(0);g.use();
      created.push({...c,z:21,cell:g.getCell(c.x,c.y,21)});
    }
    const combined=[];
    for(const c of [{x:-9,y:67,fromAbove:true},{x:-6,y:69,fromAbove:false}]){
      const cameraY=c.y+(c.fromAbove?3:-2);
      g.teleport(c.x+.5,cameraY-1.62,21.5);g.camera.position.set(c.x+.5,cameraY,21.5);
      g.input.yaw=0;g.input.pitch=c.fromAbove?-Math.PI/2:Math.PI/2;g.hotbar[0]={name:'oak_slab',count:64};g.select(0);g.use();
      combined.push({...c,z:21,cell:g.getCell(c.x,c.y,21)});
    }
    return {created,combined};
  },{stone:ID.stone});
  for(const p of halfBlocks.created){assert.equal(p.cell&0xfff,ID[p.name]);assert.equal(p.cell>>>12,p.expected,`${p.name}: top/bottom placement`);}
  for(const p of halfBlocks.combined){assert.equal(p.cell&0xfff,ID.oak_slab);assert.equal(p.cell>>>12,2,'matching slabs combine');}
  results.halfBlocks=halfBlocks;

  const mining=await page.evaluate(({iron,diamond})=>{
    const g=(window as any).__game,checks=[];
    g.meta.mode='survival';g.flying=true;g.teleport(-8.5,74.38,24.5);g.camera.position.set(-8.5,76,24.5);g.input.yaw=0;g.input.pitch=0;g.input.breakHeld=true;
    for(const c of [{ore:iron,tool:'wooden_pickaxe'},{ore:iron,tool:'stone_pickaxe'},{ore:diamond,tool:'copper_pickaxe'},{ore:diamond,tool:'iron_pickaxe'}]){
      g.setBlock(-9,76,21,c.ore);g.hotbar[0]={name:c.tool,count:1};g.select(0);g.breakCooldown=0;g.grounded=true;
      const before=g.particles.drops.length;g.mining(120);
      checks.push({...c,remaining:g.getBlock(-9,76,21),drops:g.particles.drops.slice(before).map((d:any)=>d.name)});
    }
    g.input.breakHeld=false;g.meta.mode='creative';return checks;
  },{iron:ID.iron_ore,diamond:ID.diamond_ore});
  assert.deepEqual(mining.map(m=>m.remaining),[0,0,0,0]);
  assert.deepEqual(mining.map(m=>m.drops),[[],['raw_iron'],[],['diamond']]);
  results.mining=mining;

  const capacity=await page.evaluate(()=>{
    const g=(window as any).__game,bar=g.hotbar,inventory=g.inventory;
    g.hotbar=Array.from({length:9},()=>({name:'dirt',count:64}));
    g.inventory=Array.from({length:27},()=>({name:'dirt',count:64}));
    g.inventory[0].count=63;
    const added=g.addItem('dirt',2),count=g.inventory[0].count;
    g.hotbar=bar;g.inventory=inventory;
    return {added,count};
  });
  assert.deepEqual(capacity,{added:false,count:63},'failed insertion must not duplicate items');
  results.inventoryCapacity=capacity;

  await page.evaluate(({chest,furnace,stone})=>{
    const g=(window as any).__game;
    g.teleport(-8.5,64,29.5);g.flying=true;g.velocity.set(0,0,0);g.input.yaw=0;g.input.pitch=-0.1;
    for(let i=0;i<6;i++){
      const x=-14+i*2;g.setBlock(x,64,22,stone);
      g.setBlock(x,65,22,i<3?chest:furnace,i%3);
    }
  },{chest:ID.chest,furnace:ID.furnace,stone:ID.stone});
  await page.waitForFunction(()=>{
    const g=(window as any).__game,key='-1,1';
    return g.chunks.get(key)?.version===(g.versions.get(key)??0)&&!g.pending.has(key)&&!g.queued.has(key);
  },null,{timeout:90000,polling:250});
  await page.waitForTimeout(500);
  await page.screenshot({path:'preview/block-facings.png'});
  results.scene=await page.evaluate(()=>{const g=(window as any).__game;return {triangles:g.renderer.info.render.triangles,drawCalls:g.renderer.info.render.calls,shaderFallback:g.environment.failed};});

  await page.evaluate(()=>(window as any).__game.save());
  await page.reload({waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>Boolean((window as any).__game?.ready),null,{timeout:90000,polling:200});
  await page.getByRole('button',{name:'シングルプレイ',exact:true}).click();
  await page.locator('.world-row-main').first().click();
  await page.waitForFunction(()=>Boolean((window as any).__game?.active),null,{timeout:90000,polling:200});
  const restored=await page.evaluate((list)=>list.map(p=>({x:p.x,y:p.y,z:p.z,cell:(window as any).__game.getCell(p.x,p.y,p.z)})),placements);
  for(let i=0;i<placements.length;i++)assert.equal(restored[i].cell,placements[i].cell,'block state survives reload');
  results.restored=restored;
  const restoredHalf=await page.evaluate((list)=>list.map(p=>(window as any).__game.getCell(p.x,p.y,p.z)),halfBlocks.combined);
  for(let i=0;i<restoredHalf.length;i++)assert.equal(restoredHalf[i],halfBlocks.combined[i].cell,'double slab survives reload');
  results.restoredHalf=restoredHalf;

  await page.evaluate(({water,lava,stone})=>{
    const g=(window as any).__game;g.flying=true;g.teleport(-8.5,67.5,29.5);g.input.yaw=0;g.input.pitch=-.1;
    g.setBlock(-11,67,22,stone);g.setBlock(-11,68,22,water);
    g.setBlock(-7,67,22,stone);g.setBlock(-7,68,22,lava);
    g.simulation.clear();g.weather='clear';
  },{water:ID.water,lava:ID.lava,stone:ID.stone});
  await page.waitForFunction(()=>{
    const g=(window as any).__game,key='-1,1';return g.chunks.get(key)?.version===(g.versions.get(key)??0)&&!g.pending.has(key)&&!g.queued.has(key);
  },null,{timeout:90000,polling:250});
  const fluids=await page.evaluate(()=>{
    const g=(window as any).__game,attr=g.chunks.get('-1,1').water.geometry.getAttribute('tile');
    return {water:Array.from(attr.array as Float32Array).includes(0),lava:Array.from(attr.array as Float32Array).includes(1),shaderFallback:g.environment.failed};
  });
  assert.deepEqual(fluids,{water:true,lava:true,shaderFallback:false});results.fluids=fluids;
  await page.screenshot({path:'preview/fluids.png'});
  await page.evaluate(()=>{(window as any).__game.weather='rain';});
  await page.waitForFunction(()=>Boolean((window as any).__game.environment.rain.visible),null,{timeout:15000,polling:200});
  results.rainVisible=await page.evaluate(()=>(window as any).__game.environment.rain.visible);
  await page.evaluate(()=>{(window as any).__game.weather='clear';});

  const blocked=await page.evaluate(({stone,glass})=>{
    const g=(window as any).__game;
    g.flying=true;g.teleport(-8.5,60,24.5);g.camera.position.set(-8.5,61.62,24.5);g.input.yaw=0;g.input.pitch=0;
    g.setBlock(-9,62,21,stone);g.use();const solidBlocked=g.active;
    g.setBlock(-9,62,21,glass);g.use();const glassAllowed=!g.active;
    return {solidBlocked,glassAllowed,key:g.stationKey};
  },{stone:ID.stone,glass:ID.glass});
  assert.equal(blocked.solidBlocked,true,'an opaque full block blocks a chest');
  assert.equal(blocked.glassAllowed,true,'glass does not block a chest');
  assert.equal(blocked.key,'-9,61,21');
  results.chestAccess=blocked;
  await page.waitForSelector('.chest-grid',{timeout:15000});
  await page.screenshot({path:'preview/chest-open.png'});
  const drop=await page.evaluate(()=>{
    const g=(window as any).__game,key='-9,61,21';g.containers[key][0]={name:'diamond',count:4};
    const before=g.particles.drops.length;g.setBlock(-9,61,21,0);
    return {forgot:!g.containers[key],drops:g.particles.drops.slice(before).map((d:any)=>({name:d.name,count:d.count}))};
  });
  assert.equal(drop.forgot,true);assert.deepEqual(drop.drops,[{name:'diamond',count:4}]);
  results.chestBreak=drop;

  await page.keyboard.press('Escape');
  await page.waitForFunction(()=>Boolean((window as any).__game?.active),null,{timeout:15000,polling:200});
  const coord={x:-9,y:80,z:24},key='-9,80,24';
  await page.evaluate(({coord,key,chest})=>{
    const g=(window as any).__game;g.setBlock(coord.x,coord.y,coord.z,chest,3);
    g.containers[key]=[{name:'diamond',count:7},...Array(26).fill(null)];g.changeDimension('nether');
  },{coord,key,chest:ID.chest});
  await page.waitForFunction(()=>{const g=(window as any).__game;return g.dimension==='nether'&&g.ready&&g.getCell(-9,80,24)>=0;},null,{timeout:90000,polling:200});
  const netherBefore=await page.evaluate(({coord})=>(window as any).__game.getCell(coord.x,coord.y,coord.z),{coord});
  assert.equal(netherBefore,0,'overworld edit must not leak into the Nether');
  await page.evaluate(({coord,key,furnace})=>{
    const g=(window as any).__game;g.setBlock(coord.x,coord.y,coord.z,furnace,1);
    g.containers[key]=[{name:'coal',count:3},null,null];g.furnaces[key]={burn:20,progress:.5};g.changeDimension('overworld');
  },{coord,key,furnace:ID.furnace});
  await page.waitForFunction(()=>{const g=(window as any).__game;return g.dimension==='overworld'&&g.ready&&g.getCell(-9,80,24)>=0;},null,{timeout:90000,polling:200});
  const overworld=await page.evaluate(({coord,key})=>{const g=(window as any).__game;return {cell:g.getCell(coord.x,coord.y,coord.z),stack:g.containers[key]?.[0]};},{coord,key});
  assert.equal(overworld.cell,ID.chest|(3<<12));assert.deepEqual(overworld.stack,{name:'diamond',count:7});
  await page.evaluate(()=>(window as any).__game.save());
  await page.reload({waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>Boolean((window as any).__game?.ready),null,{timeout:90000,polling:200});
  await page.getByRole('button',{name:'シングルプレイ',exact:true}).click();await page.locator('.world-row-main').first().click();
  await page.waitForFunction(()=>Boolean((window as any).__game?.active),null,{timeout:90000,polling:200});
  const afterReload=await page.evaluate(({coord,key})=>{const g=(window as any).__game;const state={cell:g.getCell(coord.x,coord.y,coord.z),stack:g.containers[key]?.[0]};g.changeDimension('nether');return state;},{coord,key});
  assert.deepEqual(afterReload,overworld,'overworld survives save and reload');
  await page.waitForFunction(()=>{const g=(window as any).__game;return g.dimension==='nether'&&g.ready&&g.getCell(-9,80,24)>=0;},null,{timeout:90000,polling:200});
  const nether=await page.evaluate(({coord,key})=>{const g=(window as any).__game;return {cell:g.getCell(coord.x,coord.y,coord.z),stack:g.containers[key]?.[0],furnace:g.furnaces[key]};},{coord,key});
  assert.equal(nether.cell,ID.furnace|(1<<12));assert.deepEqual(nether.stack,{name:'coal',count:3});assert.ok(nether.furnace.burn>0);
  results.dimensionIsolation={netherBefore,overworld,afterReload,nether};
  assert.deepEqual(errors,[]);
  results.errors=errors;
  fs.writeFileSync('preview/block-results.json',JSON.stringify(results,null,2));
  console.log('PASS real placement in four directions, shape rendering, save/reload, chest obstruction, contents, and inventory capacity');
}catch(error){
  fs.writeFileSync('preview/block-results.json',JSON.stringify({failure:String(error),errors,results},null,2));
  await page.screenshot({path:'preview/block-failure.png',timeout:15000}).catch(()=>{});
  throw error;
}finally{
  await browser.close();await new Promise<void>(resolve=>server.httpServer.close(()=>resolve()));
}