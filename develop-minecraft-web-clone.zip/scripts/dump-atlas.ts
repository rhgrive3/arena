import fs from 'node:fs';
import { createCanvas } from '@napi-rs/canvas';
(globalThis as any).OffscreenCanvas=function(width:number,height:number){return createCanvas(width,height);};
const {atlasTiles,atlasCanvas}=await import('../src/textures/atlas');
fs.mkdirSync('preview',{recursive:true});
const tiles=atlasTiles(),cols=8,cell=126,rowHeight=119,canvas=createCanvas(cols*cell,Math.ceil(tiles.length/cols)*rowHeight),ctx=canvas.getContext('2d');
ctx.fillStyle='#263329';ctx.fillRect(0,0,canvas.width,canvas.height);
for(const [i,t] of tiles.entries()){const x=i%cols*cell,y=Math.floor(i/cols)*rowHeight;ctx.fillStyle='#17251d';ctx.fillRect(x+5,y+5,116,109);ctx.imageSmoothingEnabled=false;ctx.drawImage(t.canvas as any,x+31,y+11,64,64);ctx.fillStyle='#e0e8cc';ctx.font='10px monospace';ctx.textAlign='center';const name=t.name.length>20?t.name.slice(0,19)+'…':t.name;ctx.fillText(name,x+cell/2,y+91);ctx.fillStyle='#9eb982';ctx.fillText(String(t.index).padStart(3,'0'),x+cell/2,y+106);}
fs.writeFileSync('preview/atlas_sheet.png',canvas.toBuffer('image/png'));
fs.writeFileSync('preview/atlas.png',Buffer.from((atlasCanvas as any).toBuffer('image/png')));
console.log(`Exported ${tiles.length} procedural tiles to preview/atlas_sheet.png`);
