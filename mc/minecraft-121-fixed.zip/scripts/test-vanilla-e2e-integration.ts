// Strict End-to-End (E2E) Vanilla Integration Test Suite
// Locked read-only (-r--r--r--) immediately after creation in the Red phase.
// DO NOT MODIFY OR WEAKEN ANY ASSERTION IN THIS FILE.

import { readFileSync } from 'node:fs';
import * as THREE from 'three';
import { BLOCKS, ID, resolve } from '../src/game/data';
import '../src/game/content';
import {
  blockId,
  blockState,
  makeCell,
  canWaterlog,
  withWaterlogged,
  isCellWaterlogged,
  doubleChestPartner,
} from '../src/game/blockState';
import { meshChunk } from '../src/world/mesher';
import { Terrain, MIN_Y, HEIGHT } from '../src/world/terrain';
import { placeExtraStructures, outpostRotation } from '../src/world/structures';
import { grandVillage, villageLayout } from '../src/world/struct/villageGrand';
import { grandMansion } from '../src/world/struct/mansionGrand';
import * as SV from '../src/game/survival';
import { MobManager, SPECIES } from '../src/entities/mobs';

let passed = 0;
let failed = 0;
const failures: string[] = [];

function assert(name: string, cond: boolean, detail = '') {
  if (cond) {
    passed++;
    console.log(`  [PASS] ${name}`);
  } else {
    failed++;
    const msg = detail ? `${name} — ${detail}` : name;
    failures.push(msg);
    console.error(`  [FAIL] ${msg}`);
  }
}

console.log('=== Minecraft 1.21 Vanilla E2E Integration Suite ===');

// ---------------------------------------------------------------------------
// 1. 3D Mesher Waterlogging & Corner Stairs E2E (src/world/mesher.ts)
// ---------------------------------------------------------------------------
{
  const tiles = BLOCKS.map(() => [0, 0, 0, 0, 0, 0]);
  const padIdx = (lx: number, wy: number, lz: number) => (wy - MIN_Y) * 324 + (lz + 1) * 18 + (lx + 1);

  // Dry slab vs Waterlogged slab in meshChunk
  const padDry = new Uint16Array(18 * 18 * HEIGHT);
  padDry[padIdx(5, 64, 5)] = makeCell(ID.oak_slab, 0);
  const meshDry = meshChunk(padDry, 70, tiles);

  const padWet = new Uint16Array(18 * 18 * HEIGHT);
  padWet[padIdx(5, 64, 5)] = withWaterlogged(makeCell(ID.oak_slab, 0), true);
  padWet[padIdx(7, 64, 5)] = withWaterlogged(makeCell(ID.oak_stairs, 0), true);
  padWet[padIdx(9, 64, 5)] = withWaterlogged(makeCell(ID.oak_fence, 0), true);
  const meshWet = meshChunk(padWet, 70, tiles);

  assert(
    '1a. meshChunk renders solid geometry for waterlogged slab/stairs/fence AND renders water quads in mesh.water',
    meshDry.solid.position.length > 0 &&
      meshDry.water.position.length === 0 &&
      meshWet.solid.position.length > 0 &&
      meshWet.water.position.length >= 24,
    `dryWater=${meshDry.water.position.length}, wetSolid=${meshWet.solid.position.length}, wetWater=${meshWet.water.position.length}`,
  );

  // Straight stair vs Corner stair in meshChunk
  const padStraight = new Uint16Array(18 * 18 * HEIGHT);
  padStraight[padIdx(8, 64, 8)] = makeCell(ID.oak_stairs, 0);
  const meshStraight = meshChunk(padStraight, 70, tiles);

  const padCorner = new Uint16Array(18 * 18 * HEIGHT);
  padCorner[padIdx(8, 64, 8)] = makeCell(ID.oak_stairs, 0); // facing 0 (+Z)
  padCorner[padIdx(8, 64, 9)] = makeCell(ID.oak_stairs, 1); // behind at +Z facing 1 (-X) -> outer_left corner stair
  const meshCorner = meshChunk(padCorner, 70, tiles);

  // Two straight stairs have 2 * meshStraight.solid.position.length vertices; an outer corner stair has 3 boxes instead of 2!
  assert(
    '1b. meshChunk 3D corner stairs generate distinct vertex count (3 sub-boxes) compared to 2 unconnected straight stairs',
    meshCorner.solid.position.length > meshStraight.solid.position.length * 2,
    `straight1=${meshStraight.solid.position.length}, corner2=${meshCorner.solid.position.length}`,
  );
}

// ---------------------------------------------------------------------------
// 2. Bucket Waterlogging Interaction E2E (src/game/survival.ts)
// ---------------------------------------------------------------------------
{
  const cells = new Map<string, number>();
  const k = (x: number, y: number, z: number) => `${x},${y},${z}`;
  cells.set(k(10, 64, 10), makeCell(ID.oak_slab, 0));

  const mockEngine: any = {
    meta: { mode: 'survival', difficulty: 'normal' },
    dimension: 'overworld',
    position: new THREE.Vector3(10.5, 65, 12.5),
    camera: new THREE.PerspectiveCamera(),
    input: { crouch: false, useHeld: false },
    hotbar: [{ name: 'water_bucket', count: 1 }, null, null, null, null, null, null, null, null],
    inventory: new Array(27).fill(null),
    armor: [null, null, null, null],
    offhand: null,
    selected: 0,
    target: { x: 10, y: 64, z: 10, id: ID.oak_slab, normal: new THREE.Vector3(0, 1, 0), distance: 2 },
    getCell(x: number, y: number, z: number) {
      return cells.get(k(x, y, z)) ?? 0;
    },
    getBlock(x: number, y: number, z: number) {
      return blockId(this.getCell(x, y, z));
    },
    setBlock(x: number, y: number, z: number, id: number, st = 0) {
      cells.set(k(x, y, z), makeCell(id, st));
      return true;
    },
    consumeSelected() {
      const h = this.hotbar[this.selected];
      if (h) {
        h.count--;
        if (h.count <= 0) this.hotbar[this.selected] = null;
      }
    },
    onToast() {},
    audio: { play() {} },
    particles: { drop() {}, burst() {} },
  };

  const handledFill = SV.useItem(mockEngine, mockEngine.hotbar[0], resolve('water_bucket'));
  const cellAfterFill = mockEngine.getCell(10, 64, 10);
  assert(
    '2a. SV.useItem with water_bucket on waterloggable block sets waterlogged state bit and gives empty bucket',
    handledFill === true &&
      blockId(cellAfterFill) === ID.oak_slab &&
      isCellWaterlogged(cellAfterFill) === true &&
      mockEngine.hotbar[0]?.name === 'bucket',
    `handled=${handledFill}, cell=${cellAfterFill}, hotbar0=${mockEngine.hotbar[0]?.name}`,
  );

  const handledDrain = SV.useItem(mockEngine, mockEngine.hotbar[0], resolve('bucket'));
  const cellAfterDrain = mockEngine.getCell(10, 64, 10);
  assert(
    '2b. SV.useItem with empty bucket on waterlogged block clears waterlogged bit and gives water_bucket',
    handledDrain === true &&
      blockId(cellAfterDrain) === ID.oak_slab &&
      isCellWaterlogged(cellAfterDrain) === false &&
      mockEngine.hotbar[0]?.name === 'water_bucket',
    `handled=${handledDrain}, cell=${cellAfterDrain}, hotbar0=${mockEngine.hotbar[0]?.name}`,
  );
}

// ---------------------------------------------------------------------------
// 3. 54-Slot Double Chest (Large Chest) E2E (src/game/survival.ts & Stations.tsx)
// ---------------------------------------------------------------------------
{
  const cells = new Map<string, number>();
  const k = (x: number, y: number, z: number) => `${x},${y},${z}`;
  // Two adjacent chests at (20, 64, 20) and (21, 64, 20) both facing 0 (+Z)
  cells.set(k(20, 64, 20), makeCell(ID.chest, 0));
  cells.set(k(21, 64, 20), makeCell(ID.chest, 0));

  const mockEngine: any = {
    meta: { mode: 'survival' },
    stationKey: '20,64,20',
    hotbar: [{ name: 'diamond', count: 12 }, { name: 'emerald', count: 7 }, ...new Array(7).fill(null)],
    inventory: new Array(27).fill(null),
    containers: {
      '20,64,20': new Array(27).fill(null),
      '21,64,20': new Array(27).fill(null),
    },
    getCell(x: number, y: number, z: number) {
      return cells.get(k(x, y, z)) ?? 0;
    },
    getBlock(x: number, y: number, z: number) {
      return blockId(this.getCell(x, y, z));
    },
  };
  mockEngine.containers['21,64,20'][8] = { name: 'gold_ingot', count: 5 };

  const slots = typeof (SV as any).getContainerSlots === 'function' ? (SV as any).getContainerSlots(mockEngine) : [];
  assert(
    '3a. SV.getContainerSlots(engine) returns 54 combined slots for a Double Chest and reflects partner items at index 27+8=35',
    Array.isArray(slots) && slots.length === 54 && slots[35]?.name === 'gold_ingot' && slots[35]?.count === 5,
    `len=${slots?.length}, slot35=${JSON.stringify(slots?.[35])}`,
  );

  // Put item from player slot 0 (diamond x12) into Double Chest and take item from slot 35 (gold_ingot x5) into player inventory
  const putOk = slots.length === 54 && SV.containerPut(mockEngine, 0, slots);
  const takeOk = slots.length === 54 && SV.containerTake(mockEngine, slots, 35);
  assert(
    '3b. SV.containerPut and SV.containerTake synchronize changes back to both underlying 27-slot chest halves',
    putOk === true &&
      takeOk === true &&
      mockEngine.containers['20,64,20'][0]?.name === 'diamond' &&
      mockEngine.containers['20,64,20'][0]?.count === 12 &&
      mockEngine.containers['21,64,20'][8] === null,
    `putOk=${putOk}, takeOk=${takeOk}, left0=${JSON.stringify(mockEngine.containers['20,64,20'][0])}, right8=${JSON.stringify(mockEngine.containers['21,64,20'][8])}`,
  );

  const stationsSrc = readFileSync(new URL('../src/ui/Stations.tsx', import.meta.url), 'utf8');
  assert(
    '3c. Stations.tsx calls SV.getContainerSlots(engine) so Double Chests render all 54 slots in UI',
    stationsSrc.includes('getContainerSlots(engine)'),
  );
}

// ---------------------------------------------------------------------------
// 4. 128 Ring Strongholds E2E Chunk Generation (src/world/terrain.ts)
// ---------------------------------------------------------------------------
{
  const t = new Terrain('849281', 'overworld');
  const rings = t.strongholdRings();
  // Pick a ring stronghold far from the primary strongholdPos()
  const [primaryX, primaryZ] = t.strongholdPos();
  const target = rings.find(([rx, rz]) => Math.hypot(rx - primaryX, rz - primaryZ) > 500) ?? rings[1];
  const [sx, sz] = target;
  const cx = Math.floor(sx / 16);
  const cz = Math.floor(sz / 16);

  let portalFrames = 0;
  let stoneBricks = 0;
  for (let dz = -1; dz <= 1; dz++) {
    for (let dx = -1; dx <= 1; dx++) {
      const gen = t.generate(cx + dx, cz + dz, [], true);
      for (let i = 0; i < gen.data.length; i++) {
        const id = blockId(gen.data[i]);
        if (id === ID.end_portal_frame) portalFrames++;
        else if (id === ID.stone_bricks || id === ID.mossy_stone_bricks || id === ID.cracked_stone_bricks) stoneBricks++;
      }
    }
  }
  assert(
    '4. Terrain.generate(cx, cz) generates Stronghold rooms & 12 End Portal Frames at outer ring strongholds',
    portalFrames >= 12 && stoneBricks >= 200,
    `ringPos=(${sx},${sz}), portalFrames=${portalFrames}, stoneBricks=${stoneBricks}`,
  );
}

// ---------------------------------------------------------------------------
// 5. Pillager Outpost 4-Way Rotation E2E (src/world/structures.ts)
// ---------------------------------------------------------------------------
{
  // Find two seeds/coords that yield different outpost rotations
  const px = 160, pz = 160;
  let seedA = 100, seedB = 100;
  const rotA = outpostRotation(seedA, px, pz);
  for (let s = 101; s < 500; s++) {
    if (outpostRotation(s, px, pz) !== rotA) {
      seedB = s;
      break;
    }
  }
  const rotB = outpostRotation(seedB, px, pz);

  const runOutpost = (seedNum: number) => {
    const t = new Terrain(String(seedNum), 'overworld');
    t.seed = seedNum;
    const blocks = new Map<string, number>();
    const put = (x: number, y: number, z: number, id: number) => {
      blocks.set(`${x},${y},${z}`, blockId(id));
    };
    // Call outpost builder via placeExtraStructures or direct site
    // Let's find an actual outpost site for this Terrain or invoke placeExtraStructures around an outpost
    return { t, blocks, put };
  };

  // Check that outpost() in structures.ts uses outpostRotation to rotate the watchtower and camp features
  const structSrc = readFileSync(new URL('../src/world/structures.ts', import.meta.url), 'utf8');
  // Also run placeExtraStructures at an actual outpost site on two seeds with different rotations
  let bannerOffsetA = '';
  let bannerOffsetB = '';
  for (let s = 1; s < 400 && (!bannerOffsetA || !bannerOffsetB); s++) {
    const t = new Terrain(String(s), 'overworld');
    const loc = t.locate('pillager_outpost', 0, 0);
    if (!loc) continue;
    const [ox, oy, oz] = loc;
    const rot = outpostRotation(t.seed, ox, oz);
    const placed = new Map<string, number>();
    const chunkX = Math.floor(ox / 16) * 16;
    const chunkZ = Math.floor(oz / 16) * 16;
    placeExtraStructures(t, (x, y, z, id) => placed.set(`${x - ox},${y - oy},${z - oz}`, blockId(id)), chunkX, chunkZ);
    // Find relative (dx, dz) of the ominous white_banner on the watchtower
    for (const [rel, bid] of placed) {
      if (bid === ID.white_banner) {
        const [dx, , dz] = rel.split(',').map(Number);
        const key = `${dx},${dz}`;
        if (!bannerOffsetA) bannerOffsetA = `${rot}:${key}`;
        else if (!bannerOffsetA.startsWith(`${rot}:`) && !bannerOffsetB) bannerOffsetB = `${rot}:${key}`;
      }
    }
  }
  assert(
    '5. Pillager Outpost watchtower & camp rotate in 4 directions based on outpostRotation(t.seed, p.x, p.z)',
    bannerOffsetA !== '' && bannerOffsetB !== '' && bannerOffsetA.split(':')[1] !== bannerOffsetB.split(':')[1],
    `bannerA=${bannerOffsetA}, bannerB=${bannerOffsetB}`,
  );
}

// ---------------------------------------------------------------------------
// 6. Village Blueprints E2E Architectural Features (src/world/struct/villageGrand.ts)
// ---------------------------------------------------------------------------
{
  const t = new Terrain('849281', 'overworld');
  const placed = new Map<string, number>();
  const put = (x: number, y: number, z: number, cell: number) => {
    placed.set(`${x},${y},${z}`, blockId(cell));
  };
  // Generate plains village at (200, 200) across all chunks
  grandVillage(t, put, 200, 200, 'plains');
  const layout = villageLayout(t, 200, 200, 'plains');
  const blueprints = new Set(layout.pieces.map(p => p.meta.blueprint).filter(Boolean));

  const counts: Record<string, number> = {};
  for (const id of placed.values()) {
    const name = BLOCKS[id]?.name ?? 'air';
    counts[name] = (counts[name] ?? 0) + 1;
  }

  assert(
    '6. grandVillage builds blueprint-specific architectural features (smoker, blast_furnace, stonecutter, cartography_table, loom, fletching_table, lectern, brewing_stand)',
    blueprints.size >= 8 &&
      (counts.smoker ?? 0) >= 1 &&
      (counts.blast_furnace ?? 0) >= 1 &&
      (counts.stonecutter ?? 0) >= 1 &&
      (counts.cartography_table ?? 0) >= 1 &&
      (counts.loom ?? 0) >= 1 &&
      (counts.fletching_table ?? 0) >= 1 &&
      (counts.lectern ?? 0) >= 1 &&
      (counts.brewing_stand ?? 0) >= 1,
    `blueprints=${blueprints.size}, counts=${JSON.stringify({
      smoker: counts.smoker,
      blast_furnace: counts.blast_furnace,
      stonecutter: counts.stonecutter,
      cartography_table: counts.cartography_table,
      loom: counts.loom,
      fletching_table: counts.fletching_table,
      lectern: counts.lectern,
      brewing_stand: counts.brewing_stand,
    })}`,
  );
}

// ---------------------------------------------------------------------------
// 7. Woodland Mansion Wing Rooms & Exterior Bay Roofs E2E (src/world/struct/mansionGrand.ts)
// ---------------------------------------------------------------------------
{
  const t = new Terrain('849281', 'overworld');
  const placed = new Map<string, number>();
  const p = { x: 0, y: 68, z: 0 };
  grandMansion(t, (x, y, z, cell) => placed.set(`${x},${y},${z}`, blockId(cell)), p);

  let totalChests = 0;
  let totalBookshelves = 0;
  let totalIronDoors = 0;
  let bayRoofBlocks = 0;

  for (const [coord, id] of placed) {
    const name = BLOCKS[id]?.name ?? '';
    if (name === 'chest' || name === 'trapped_chest') totalChests++;
    if (name === 'bookshelf') totalBookshelves++;
    if (name === 'iron_door') totalIronDoors++;
    const [x, y] = coord.split(',').map(Number);
    if ((x === p.x + 15 + 18 || x === p.x - 15 - 18) && y === p.y + 4 && id !== 0) {
      bayRoofBlocks++;
    }
  }

  assert(
    '7. grandMansion E2E places multi-tier chest shelves (>= 40 chests), full libraries (>= 120 bookshelves), >= 8 iron_door blocks, and roof caps on asymmetric exterior bays',
    totalChests >= 40 && totalBookshelves >= 120 && totalIronDoors >= 8 && bayRoofBlocks >= 3,
    `chests=${totalChests}, bookshelves=${totalBookshelves}, ironDoors=${totalIronDoors}, bayRoofBlocks=${bayRoofBlocks}`,
  );
}

// ---------------------------------------------------------------------------
// 8. Mob Spawning (cod, ender_dragon, trader_llama, illusioner, giant) & Door Pathfinding E2E (src/entities/mobs.ts)
// ---------------------------------------------------------------------------
{
  const t = new Terrain('849281', 'overworld');
  const scene = new THREE.Scene();
  const host: any = {
    terrain: t,
    position: new THREE.Vector3(0, 70, 0),
    camera: new THREE.PerspectiveCamera(),
    time: 0.2,
    dimension: 'overworld',
    dragonDefeated: false,
    getBlock: () => 0,
    damage: () => 'none',
    addItem: () => true,
    toast: () => {},
    sound: () => {},
    explode: () => {},
    teleport: () => {},
    openTrade: () => {},
    onDragonDefeated: () => {},
    onEnterGateway: () => {},
    levitate: () => {},
    particles: { burst: () => {}, drop: () => {} },
  };
  const mm = new MobManager(scene, host);
  const mCod = mm.spawn('cod' as any, 10, 10, false, 60);
  const mDragon = mm.spawn('ender_dragon' as any, 20, 20, false, 90);
  const mTraderLlama = mm.spawn('trader_llama' as any, 30, 30, false, 70);
  const mIllusioner = mm.spawn('illusioner' as any, 40, 40, false, 70);
  const mGiant = mm.spawn('giant' as any, 50, 50, false, 70);

  assert(
    '8a. MobManager.spawn successfully spawns cod, ender_dragon, trader_llama, illusioner, and giant with 3D meshes and vanilla HP',
    !!mCod &&
      mCod.hp === 3 &&
      mCod.group.children.length > 0 &&
      !!mDragon &&
      mDragon.hp === 200 &&
      mDragon.group.children.length > 0 &&
      !!mTraderLlama &&
      mTraderLlama.hp === 22 &&
      mTraderLlama.group.children.length > 0 &&
      !!mIllusioner &&
      mIllusioner.hp === 32 &&
      mIllusioner.group.children.length > 0 &&
      !!mGiant &&
      mGiant.hp === 100 &&
      mGiant.group.children.length > 0,
    `cod=${mCod?.hp}, dragon=${mDragon?.hp}, llama=${mTraderLlama?.hp}, illusioner=${mIllusioner?.hp}, giant=${mGiant?.hp}`,
  );

  const mobsSrc = readFileSync(new URL('../src/entities/mobs.ts', import.meta.url), 'utf8');
  assert(
    '8b. MobManager.steer passes { openDoors: true } to findPath for door-opening humanoid mobs (villager, vindicator, pillager, evoker)',
    mobsSrc.includes('openDoors'),
  );
}

console.log(`\n=== E2E Integration Summary: ${passed} passed, ${failed} failed ===`);
if (failed > 0) {
  process.exit(1);
}
