// Comprehensive, zero-loophole verification suite for full 1,060-block integration,
// non-simplified structure/3D upgrades, and zero-downside optimizations.
import assert from 'node:assert/strict';
import '../src/game/content';
import { BLOCKS, ID, ITEM_ID } from '../src/game/data';
import { OFFICIAL_1060_SET } from '../src/game/official121Blocks';
import { modelBoxes, collisionBoxes } from '../src/world/shapes';
import { meshChunk, setChestOpenProgress } from '../src/world/mesher';
import { Terrain } from '../src/world/terrain';
import { chamberLayout, trialChambers } from '../src/world/dungeons';
import { ancientCityPlan, ancientCity, ANCIENT_CITY } from '../src/world/struct/variants';
import { grandMansion, mansionGridFor } from '../src/world/struct/mansionGrand';
import { grandVillage, villageLayout } from '../src/world/struct/villageGrand';

let passed = 0;
function check(name: string, fn: () => boolean | void) {
  const res = fn();
  assert.ok(res !== false, `FAIL: ${name}`);
  passed++;
  console.log(`PASS  ${name}`);
}

const makeRec = () => {
  const map = new Map<string, number>();
  const put = (x: number, y: number, z: number, bid: number, force = true) => {
    if (force || !map.has(`${x},${y},${z}`)) map.set(`${x},${y},${z}`, bid);
  };
  const get = (x: number, y: number, z: number) => map.get(`${x},${y},${z}`) ?? 0;
  return { map, put, get };
};

// 1. Official 1,060 Java 1.21 Blocks & Items + 3D Shapes
check('1.1 All 1,060 official Java 1.21 blocks are registered with 0 missing', () => {
  const missing = [...OFFICIAL_1060_SET].filter(n => !(n in ID));
  assert.equal(missing.length, 0, `Missing official blocks: ${missing.slice(0, 10).join(', ')}`);
  return BLOCKS.length >= 1060;
});

check('1.2 Official 1.21 non-block items (boats, buckets, templates, debug_stick, seeds) are registered', () => {
  const req = [
    'oak_boat', 'bamboo_raft', 'cherry_chest_boat', 'pufferfish_bucket', 'axolotl_bucket',
    'tadpole_bucket', 'recovery_compass', 'netherite_upgrade_smithing_template',
    'turtle_scute', 'debug_stick', 'torchflower_seeds', 'pitcher_pod',
  ];
  return req.every(n => ITEM_ID[n] !== undefined);
});

check('1.3 Non-cube 3D shapes for heavy_core, sniffer_egg, candle, cake, candle_cake, flower_pot', () => {
  const names = ['heavy_core', 'sniffer_egg', 'candle', 'cake', 'candle_cake', 'flower_pot'];
  return names.every(n => {
    const b = BLOCKS[ID[n]];
    assert.ok(b, `Missing block ${n}`);
    const boxes = modelBoxes(b, 0);
    return boxes.length >= 1 && (boxes[0][3] - boxes[0][0] < 1 || boxes[0][4] - boxes[0][1] < 1);
  });
});

// 2. Double Chest 3D Merging + Lid Opening Animation + Candle Cake & Potted Plant 3D Meshes
const MIN_Y = -64, H = 384;
const padded = new Uint32Array(18 * H * 18);
const allTiles = new Array<number[]>(4096).fill(0).map((_, i) => [i, i, i, i, i, i, i, i]);
const setAt = (lx: number, wy: number, lz: number, bid: number, st = 0) => {
  const ly = wy - MIN_Y;
  padded[(ly * 18 + lz) * 18 + lx] = (bid & 4095) | ((st & 15) << 12);
};

check('2.1 Double Chest merges 3D geometry & omits inner seam faces', () => {
  padded.fill(0);
  setAt(7, 2, 7, ID.chest, 0);
  const singleQuads = meshChunk(padded, MIN_Y + H - 1, allTiles).solid.index.length / 6;
  padded.fill(0);
  setAt(7, 2, 7, ID.chest, 0);
  setAt(8, 2, 7, ID.chest, 0);
  const doubleQuads = meshChunk(padded, MIN_Y + H - 1, allTiles).solid.index.length / 6;
  return singleQuads >= 18 && doubleQuads === singleQuads * 2 - 4;
});

check('2.2 Chest & Double Chest lid opening animation changes lid vertex Y above 14/16 when openProgress > 0', () => {
  padded.fill(0);
  setAt(7, 2, 7, ID.chest, 0);
  setAt(8, 2, 7, ID.chest, 0);
  setChestOpenProgress(0);
  const closed = meshChunk(padded, MIN_Y + H - 1, allTiles).solid.position;
  let maxYClosed = 0;
  for (let i = 1; i < closed.length; i += 3) if (closed[i] > maxYClosed) maxYClosed = closed[i];

  setChestOpenProgress(1);
  const opened = meshChunk(padded, MIN_Y + H - 1, allTiles).solid.position;
  setChestOpenProgress(0);
  let maxYOpen = 0;
  for (let i = 1; i < opened.length; i += 3) if (opened[i] > maxYOpen) maxYOpen = opened[i];
  return maxYClosed <= 2 + 14 / 16 + 0.01 && maxYOpen > 2 + 1.05;
});

check('2.3 Candle cakes & potted plants render dedicated multi-part 3D geometry (> 12 quads)', () => {
  padded.fill(0);
  setAt(7, 2, 7, ID.candle_cake, 0);
  const ccQuads = meshChunk(padded, MIN_Y + H - 1, allTiles).solid.index.length / 6;
  padded.fill(0);
  setAt(7, 2, 7, ID.potted_oak_sapling, 0);
  const potQuads = meshChunk(padded, MIN_Y + H - 1, allTiles).solid.index.length / 6;
  return ccQuads >= 14 && potQuads >= 14;
});

// 3. Trial Chambers: True 3D Multi-Level Vertical Connections & Full 15x15 Atrium Perimeter
check('3.1 Trial Chambers generates rooms at >= 2 distinct Y elevations with connecting vertical shafts', () => {
  const L = chamberLayout(849281, 0, -24, 0);
  const yLevels = new Set(L.rooms.map(r => r.y));
  assert.ok(yLevels.size >= 2, `Expected >= 2 Y levels, got ${[...yLevels].join(',')}`);
  const rec = makeRec();
  const t = new Terrain(849281);
  trialChambers(t, rec.put, { kind: 'trial_chambers', x: 0, y: -24, z: 0 } as any);
  // Check outer 15x15 atrium perimeter (-7..7) has structural wall & interior furnishings at ±6
  let hasOuterWall = false, hasPerimFurnish = false;
  for (let dy = 0; dy < 14; dy++) {
    if (rec.get(7, -24 + dy, 0) !== 0) hasOuterWall = true;
  }
  for (let dx = -6; dx <= 6; dx += 12) {
    if (rec.get(dx, -24, 6) !== 0 || rec.get(dx, -24 + 3, 6) !== 0) hasPerimFurnish = true;
  }
  return hasOuterWall && hasPerimFurnish;
});

// 4. Ancient City: Outer Module Headroom & Real Piston Ice Box
check('4.1 Ancient City outer modules have clear cavern headroom & Ice Box has real piston redstone door', () => {
  const t = new Terrain(849281);
  const rec = makeRec();
  const p = { x: 0, y: -51, z: 0 };
  const plan = ancientCityPlan(849281, p);
  ancientCity(t, rec.put, p);
  // Every module center must have air headroom at y+6 (except tall_ruin roof/wall)
  const outerModules = plan.modules.filter(m => Math.abs(m.x0) >= 60 || Math.abs(m.x1) >= 60);
  assert.ok(outerModules.length >= 4, 'Expected >= 4 outer modules');
  for (const m of outerModules) {
    const mx = (m.x0 + m.x1) >> 1, mz = (m.z0 + m.z1) >> 1;
    assert.equal(rec.get(mx, -51 + 9, mz), 0, `Outer module ${m.kind} at (${mx},${mz}) clipped into ceiling`);
  }
  // Ice box must contain sticky_piston + redstone_wire + pressure_plate
  const I = ANCIENT_CITY.iceBox;
  let hasPiston = false, hasWire = false, hasPlate = false;
  for (let dx = I.x0 - 2; dx <= I.x1 + 2; dx++) {
    for (let dz = I.z0 - 2; dz <= I.z1 + 3; dz++) {
      for (let dy = -2; dy <= 4; dy++) {
        const b = rec.get(dx, -51 + dy, dz) & 4095;
        if (b === ID.sticky_piston || b === ID.piston) hasPiston = true;
        if (b === ID.redstone_wire) hasWire = true;
        if (b === ID.stone_pressure_plate || b === ID.heavy_weighted_pressure_plate) hasPlate = true;
      }
    }
  }
  return hasPiston && hasWire && hasPlate;
});

// 5. Woodland Mansion: Multi-Block (3-wide/deep) 3-Storey Exterior Wing Bays
check('5.1 Woodland Mansion MansionGrid builds multi-block 3-wide 3-storey exterior bays with pitched roofs', () => {
  const t = new Terrain(849281);
  const rec = makeRec();
  const site = { x: 0, y: 70, z: 0 };
  grandMansion(t, rec.put, site);
  // Check exterior bay width (extX - 1 .. extX + 1) has dark_oak_planks/log & roof
  let bayCols = 0;
  for (const extX of [-35, -34, 34, 35]) {
    for (let z = -20; z <= 20; z++) {
      if (rec.get(extX, 70, z) === ID.cobblestone && rec.get(extX, 80, z) !== 0) bayCols++;
    }
  }
  return bayCols >= 6;
});

// 6. Village: Distinct Biome & Role Building Silhouettes (L-wing / Two-Storey Tower)
check('6.1 Village builds distinct biome/role architectural silhouettes (two-storey temple tower & L-wing/porch)', () => {
  const t = new Terrain(849281);
  const rec = makeRec();
  const layout = villageLayout(t, 0, 0, 'plains');
  grandVillage(t, rec.put, layout);
  const temple = layout.pieces.find(pc => (pc.meta.role === 'temple') || pc.def.id.includes('temple'));
  assert.ok(temple, 'Expected a temple in plains village');
  let maxTy = -999;
  for (let dx = -6; dx <= 6; dx++) for (let dz = -6; dz <= 6; dz++) {
    const fy = (temple.meta.floorY as number) ?? layout.y;
  for (let dx = -12; dx <= 12; dx++) for (let dz = -12; dz <= 12; dz++) for (let dy = 0; dy <= 14; dy++) if (rec.get(temple.x + dx, fy + dy, temple.z + dz)) maxTy = Math.max(maxTy, dy);
  }
  return maxTy >= 9;
});

console.log(`\n=== Commercial Complete Suite: ${passed} passed ===`);
