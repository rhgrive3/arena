function canvas(w = 16, h = 16): HTMLCanvasElement {
  if (typeof document !== "undefined") {
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    return c;
  }
  const noop = () => {};
  const ctx = { fillStyle: "#000", strokeStyle: "#000", lineWidth: 1, globalAlpha: 1, globalCompositeOperation: "source-over", fillRect: noop, clearRect: noop, strokeRect: noop, beginPath: noop, closePath: noop, moveTo: noop, lineTo: noop, arc: noop, fill: noop, stroke: noop, save: noop, restore: noop, translate: noop, rotate: noop, scale: noop, drawImage: noop };
  return { width: w, height: h, getContext: () => ctx, toDataURL: () => "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==" } as unknown as HTMLCanvasElement;
}
// Armor Trims (Minecraft Java Edition 1.20+): 16 smithing templates × 10 mineral/crystal palettes.
import { resolve } from '../game/data';

export interface ArmorTrim { pattern: string; material: string }

export const TRIM_PATTERNS: { id: string; item: string; ja: string; en: string; baseBlock: string }[] = [
  { id: 'sentry', item: 'sentry_armor_trim_smithing_template', ja: '哨兵の鍛冶型', en: 'Sentry Armor Trim', baseBlock: 'cobblestone' },
  { id: 'dune', item: 'dune_armor_trim_smithing_template', ja: '砂丘の鍛冶型', en: 'Dune Armor Trim', baseBlock: 'sandstone' },
  { id: 'coast', item: 'coast_armor_trim_smithing_template', ja: '海岸の鍛冶型', en: 'Coast Armor Trim', baseBlock: 'cobblestone' },
  { id: 'wild', item: 'wild_armor_trim_smithing_template', ja: '密林の鍛冶型', en: 'Wild Armor Trim', baseBlock: 'moss_block' },
  { id: 'ward', item: 'ward_armor_trim_smithing_template', ja: '監守の鍛冶型', en: 'Ward Armor Trim', baseBlock: 'deepslate' },
  { id: 'eye', item: 'eye_armor_trim_smithing_template', ja: '要塞の鍛冶型', en: 'Eye Armor Trim', baseBlock: 'end_stone' },
  { id: 'vex', item: 'vex_armor_trim_smithing_template', ja: 'ヴェックスの鍛冶型', en: 'Vex Armor Trim', baseBlock: 'cobblestone' },
  { id: 'tide', item: 'tide_armor_trim_smithing_template', ja: '潮流の鍛冶型', en: 'Tide Armor Trim', baseBlock: 'prismarine' },
  { id: 'snout', item: 'snout_armor_trim_smithing_template', ja: 'ブタの鼻の鍛冶型', en: 'Snout Armor Trim', baseBlock: 'blackstone' },
  { id: 'rib', item: 'rib_armor_trim_smithing_template', ja: '肋骨の鍛冶型', en: 'Rib Armor Trim', baseBlock: 'netherrack' },
  { id: 'spire', item: 'spire_armor_trim_smithing_template', ja: '尖塔の鍛冶型', en: 'Spire Armor Trim', baseBlock: 'purpur_block' },
  { id: 'wayfinder', item: 'wayfinder_armor_trim_smithing_template', ja: '先導者の鍛冶型', en: 'Wayfinder Armor Trim', baseBlock: 'terracotta' },
  { id: 'shaper', item: 'shaper_armor_trim_smithing_template', ja: '造形者の鍛冶型', en: 'Shaper Armor Trim', baseBlock: 'terracotta' },
  { id: 'silence', item: 'silence_armor_trim_smithing_template', ja: '静寂の鍛冶型', en: 'Silence Armor Trim', baseBlock: 'deepslate' },
  { id: 'raiser', item: 'raiser_armor_trim_smithing_template', ja: '牧人の鍛冶型', en: 'Raiser Armor Trim', baseBlock: 'terracotta' },
  { id: 'host', item: 'host_armor_trim_smithing_template', ja: '主人の鍛冶型', en: 'Host Armor Trim', baseBlock: 'terracotta' },
  // 1.21 Tricky Trials: found in vaults (bolt) and ominous vaults (flow); duplicated with breeze rods / copper blocks.
  { id: 'flow', item: 'flow_armor_trim_smithing_template', ja: '流れの鍛冶型', en: 'Flow Armor Trim', baseBlock: 'breeze_rod' },
  { id: 'bolt', item: 'bolt_armor_trim_smithing_template', ja: 'ボルトの鍛冶型', en: 'Bolt Armor Trim', baseBlock: 'copper_block' },
];

export const TRIM_MATERIALS: { id: string; item: string; ja: string; en: string; color: string; darkColor: string }[] = [
  { id: 'quartz', item: 'quartz', ja: 'クォーツ', en: 'Quartz', color: '#e3d4c4', darkColor: '#b8a796' },
  { id: 'iron', item: 'iron_ingot', ja: '鉄', en: 'Iron', color: '#ececec', darkColor: '#b4b8b8' },
  { id: 'netherite', item: 'netherite_ingot', ja: 'ネザライト', en: 'Netherite', color: '#625859', darkColor: '#3c3537' },
  { id: 'redstone', item: 'redstone', ja: 'レッドストーン', en: 'Redstone', color: '#971607', darkColor: '#6a0e04' },
  { id: 'copper', item: 'copper_ingot', ja: '銅', en: 'Copper', color: '#b4684d', darkColor: '#874b35' },
  { id: 'gold', item: 'gold_ingot', ja: '金', en: 'Gold', color: '#deb12d', darkColor: '#a68018' },
  { id: 'emerald', item: 'emerald', ja: 'エメラルド', en: 'Emerald', color: '#11a036', darkColor: '#0a6d23' },
  { id: 'diamond', item: 'diamond', ja: 'ダイヤモンド', en: 'Diamond', color: '#6eecd2', darkColor: '#3fb49d' },
  { id: 'lapis', item: 'lapis_lazuli', ja: 'ラピスラズリ', en: 'Lapis', color: '#416eba', darkColor: '#284982' },
  { id: 'amethyst', item: 'amethyst_shard', ja: 'アメジスト', en: 'Amethyst', color: '#9a5cc6', darkColor: '#6b3b8e' },
];

export const TRIM_MAT_BY_ID: Record<string, (typeof TRIM_MATERIALS)[number]> = Object.fromEntries(TRIM_MATERIALS.map(m => [m.id, m]));

export const isTrimTemplate = (name: string): boolean => TRIM_PATTERNS.some(p => p.item === name);
export const trimPatternOf = (itemName: string) => TRIM_PATTERNS.find(p => p.item === itemName)?.id ?? null;
export const isTrimMaterial = (name: string): boolean => TRIM_MATERIALS.some(m => m.item === name);
export const trimMaterialOf = (itemName: string) => TRIM_MATERIALS.find(m => m.item === itemName)?.id ?? null;
export const isTrimmableArmor = (name: string): boolean => /_(helmet|chestplate|leggings|boots)$/.test(name) || name === 'turtle_helmet';

/** Palette colour of a trim material on a given armor piece (Netherite trim on Netherite armor uses the darker contrast palette). */
export function trimColorOf(materialId: string, armorName = ''): [string, string] {
  const m = TRIM_MATERIALS.find(x => x.id === materialId) ?? TRIM_MATERIALS[0];
  if (armorName.startsWith('netherite_') && materialId === 'netherite') return [m.darkColor, '#241f20'];
  if (armorName.startsWith('golden_') && materialId === 'gold') return [m.darkColor, '#785a10'];
  if (armorName.startsWith('iron_') && materialId === 'iron') return [m.darkColor, '#888c8c'];
  if (armorName.startsWith('diamond_') && materialId === 'diamond') return [m.darkColor, '#278270'];
  return [m.color, m.darkColor];
}

/** Draws the 16×16 overlay mask for one of the 16 trim patterns onto a 2D canvas context. */
export function drawTrimOverlay(ctx: CanvasRenderingContext2D, armorName: string, patternId: string, materialId: string) {
  const [primary, accent] = trimColorOf(materialId, armorName);
  const slot = armorName.endsWith('helmet') ? 'helmet' : armorName.endsWith('chestplate') ? 'chestplate' : armorName.endsWith('leggings') ? 'leggings' : 'boots';
  const R = (x: number, y: number, w: number, h: number, col = primary) => { ctx.fillStyle = col; ctx.fillRect(x, y, w, h); };

  if (slot === 'helmet') {
    switch (patternId) {
      case 'sentry': R(4, 4, 8, 1); R(7, 5, 2, 3, accent); break;
      case 'dune': R(3, 5, 10, 1); R(5, 7, 6, 1, accent); break;
      case 'coast': R(3, 6, 10, 1); R(3, 8, 3, 1, accent); R(10, 8, 3, 1, accent); break;
      case 'wild': R(4, 3, 2, 4); R(10, 3, 2, 4); R(6, 5, 4, 1, accent); break;
      case 'ward': R(5, 4, 6, 2); R(7, 6, 2, 3, accent); break;
      case 'eye': R(6, 4, 4, 3); R(7, 5, 2, 1, accent); break;
      case 'vex': R(4, 4, 3, 2); R(9, 4, 3, 2); R(7, 6, 2, 2, accent); break;
      case 'tide': R(3, 4, 10, 1); R(5, 3, 6, 1, accent); R(7, 5, 2, 3); break;
      case 'snout': R(5, 6, 6, 2); R(6, 7, 1, 1, accent); R(9, 7, 1, 1, accent); break;
      case 'rib': R(4, 4, 1, 5); R(11, 4, 1, 5); R(5, 5, 6, 1, accent); break;
      case 'spire': R(7, 2, 2, 6); R(5, 5, 6, 1, accent); break;
      case 'silence': R(3, 3, 10, 6); R(5, 5, 6, 2, accent); break;
      default: R(4, 5, 8, 2); R(6, 4, 4, 1, accent); break;
    }
  } else if (slot === 'chestplate') {
    switch (patternId) {
      case 'sentry': R(4, 4, 8, 2); R(7, 6, 2, 6, accent); break;
      case 'dune': R(3, 5, 10, 1); R(4, 8, 8, 1, accent); R(5, 11, 6, 1); break;
      case 'coast': R(2, 4, 12, 1); R(4, 7, 8, 1, accent); R(4, 10, 8, 1); break;
      case 'wild': R(3, 3, 3, 3); R(10, 3, 3, 3); R(5, 8, 6, 2, accent); break;
      case 'ward': R(5, 5, 6, 4); R(6, 6, 4, 2, accent); R(4, 11, 8, 1); break;
      case 'eye': R(5, 5, 6, 4); R(7, 6, 2, 2, accent); break;
      case 'vex': R(4, 4, 3, 5); R(9, 4, 3, 5); R(6, 7, 4, 3, accent); break;
      case 'tide': R(3, 4, 10, 2); R(5, 6, 6, 2, accent); R(6, 8, 4, 4); break;
      case 'snout': R(4, 5, 8, 2); R(5, 9, 6, 3, accent); break;
      case 'rib': for (const y of [5, 8, 11]) { R(4, y, 3, 1); R(9, y, 3, 1); } R(7, 4, 2, 9, accent); break;
      case 'spire': R(7, 3, 2, 10); R(4, 6, 8, 2, accent); break;
      case 'silence': R(2, 3, 12, 10); R(4, 5, 8, 6, accent); break;
      default: R(4, 5, 8, 2); R(6, 7, 4, 5, accent); break;
    }
  } else if (slot === 'leggings') {
    switch (patternId) {
      case 'silence': R(4, 2, 8, 3); R(4, 5, 3, 8, accent); R(9, 5, 3, 8, accent); break;
      case 'rib': for (const y of [5, 8, 11]) { R(4, y, 3, 1); R(9, y, 3, 1); } break;
      default: R(4, 2, 8, 2); R(4, 7, 3, 2, accent); R(9, 7, 3, 2, accent); break;
    }
  } else {
    switch (patternId) {
      case 'silence': R(2, 8, 5, 5); R(9, 8, 5, 5); R(3, 10, 3, 2, accent); R(10, 10, 3, 2, accent); break;
      default: R(2, 9, 5, 2); R(9, 9, 5, 2); R(2, 12, 5, 1, accent); R(9, 12, 5, 1, accent); break;
    }
  }
}

const trimIconCache = new Map<string, string>();
/** Returns a cached PNG data URL of an armor piece overlaid with its armor trim pattern and material palette. */
export function trimmedArmorDataUrl(armorName: string, trim: ArmorTrim): string {
  const key = `${armorName}|${trim.pattern}|${trim.material}`;
  const cached = trimIconCache.get(key);
  if (cached) return cached;
  const cv = canvas(16, 16);
  cv.width = 16; cv.height = 16;
  const ctx = cv.getContext('2d')!;
  const baseCol = resolve(armorName)?.color ?? '#58cfc4';
  ctx.fillStyle = baseCol;
  if (armorName.endsWith('helmet')) {
    ctx.fillRect(3, 2, 10, 8);
    ctx.clearRect(5, 6, 6, 4);
  } else if (armorName.endsWith('chestplate')) {
    ctx.fillRect(2, 2, 12, 12);
    ctx.clearRect(6, 2, 4, 2);
  } else if (armorName.endsWith('leggings')) {
    ctx.fillRect(3, 2, 10, 4);
    ctx.fillRect(3, 6, 4, 8);
    ctx.fillRect(9, 6, 4, 8);
  } else {
    ctx.fillRect(2, 7, 5, 7);
    ctx.fillRect(9, 7, 5, 7);
  }
  drawTrimOverlay(ctx, armorName, trim.pattern, trim.material);
  const url = cv.toDataURL();
  trimIconCache.set(key, url);
  return url;
}
