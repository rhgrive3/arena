import { ALL_BLOCKS, BLOCKS, ID, type BlockDef } from '../game/data';
import { isSlabBlock, isCellWaterlogged, localFaceForState, type Face } from '../game/blockState';
import { modelBoxes, TORCH16, LEVER_BASE16, LEVER_STICK16, BUTTON16 } from './shapes';
import { MIN_Y, HEIGHT } from './terrain';
import { fluidFlow, fluidOwnHeight } from '../systems/fluids';

export interface MeshData {
  position: Float32Array;
  normal: Float32Array;
  uv: Float32Array;
  color: Float32Array;
  tile: Float32Array;
  wind: Float32Array;
  light: Float32Array;
  index: Uint32Array;
}

const AO_LUT = new Float32Array([1.0, 0.81, 0.65, 0.50]);
/** Set while meshing a light-emitting sub-block (torch, lantern …): quads pushed with wind 0 get the emissive flag (1). */
let subEmissive = 0;
const SEAM = 0.002;
const STRIDE_Y = 324; // 18 * 18

// Precomputed O(1) lookup tables by block ID and 16-bit cell value (lazily synced)
const MAX_IDS = 2048;
const LUT_FULL = new Uint8Array(MAX_IDS);
const LUT_OPAQUE = new Uint8Array(MAX_IDS);
const LUT_SLAB = new Uint8Array(MAX_IDS);
const LUT_LIGHT = new Uint8Array(MAX_IDS);
const LUT_TRANSPARENT = new Uint8Array(MAX_IDS);
const LUT_TINT_TOP = new Uint8Array(MAX_IDS);
const LUT_TINT_ALL = new Uint8Array(MAX_IDS);
const LUT_TINT_SUB = new Uint8Array(MAX_IDS);
const LUT_CROP = new Uint8Array(MAX_IDS);
const LUT_WIND = new Uint8Array(MAX_IDS);
const LUT_SOLID = new Uint8Array(MAX_IDS);
const LUT_FLUID = new Uint8Array(MAX_IDS);

// Direct 16-bit cell lookup tables (64 KB each, fits in L1/L2 cache)
const LUT_CELL_FULL_NOGATE = new Uint8Array(65536);
const LUT_CELL_OPQ = new Uint8Array(65536);
const LUT_CELL_SUB = new Uint8Array(65536);

let lutBuiltCount = -1;

function ensureLuts() {
  if (lutBuiltCount === ALL_BLOCKS.length) return;
  lutBuiltCount = ALL_BLOCKS.length;
  const endGatewayId = ID.end_gateway | 0;
  for (let i = 0; i < ALL_BLOCKS.length && i < MAX_IDS; i++) {
    const def = BLOCKS[i];
    if (!def) continue;
    const slab = isSlabBlock(def);
    const customSub =
      def.name === 'hopper' ||
      def.name === 'composter' ||
      def.name === 'cauldron' ||
      def.name === 'repeater' ||
      def.name === 'comparator' ||
      def.name === 'decorated_pot' ||
      def.name === 'frosted_ice' ||
      def.name === 'suspicious_sand' ||
      def.name === 'suspicious_gravel' ||
      def.name === 'conduit' ||
      def.name === 'sea_pickle' ||
      def.name === 'turtle_egg' ||
      def.name === 'chorus_plant' ||
      def.name === 'chorus_flower' ||
      def.name === 'mangrove_roots' ||
      def.name === 'scaffolding' ||
      def.name === 'beacon' ||
      def.name === 'skeleton_skull' ||
      def.name === 'wither_skeleton_skull' ||
      def.name === 'zombie_head' ||
      def.name === 'creeper_head' ||
      def.name === 'piglin_head' ||
      def.name === 'spawner' ||
      def.name === 'trial_spawner' ||
      def.name === 'vault' ||
      def.name === 'ominous_vault' ||
      def.name === 'slime_block' ||
      def.name === 'honey_block' ||
      def.name === 'calibrated_sculk_sensor';
    LUT_SLAB[i] = slab ? 1 : 0;
    LUT_FULL[i] = def.shape === 'cube' && !customSub ? 1 : 0;
    LUT_TRANSPARENT[i] = def.transparent || customSub ? 1 : 0;
    LUT_OPAQUE[i] = i > 0 && LUT_FULL[i] === 1 && !def.transparent && !customSub ? 1 : 0;
    LUT_LIGHT[i] = def.light ? Math.min(15, def.light) : 0;
    LUT_TINT_TOP[i] = def.name === 'grass_block' ? 1 : 0;
    LUT_TINT_ALL[i] = (def.name === 'oak_leaves' || def.name === 'jungle_leaves' || def.name === 'acacia_leaves' || def.name === 'dark_oak_leaves' || def.name === 'mangrove_leaves') ? 1 : 0;
    LUT_TINT_SUB[i] = (def.name === 'short_grass' || def.name === 'fern' || def.name === 'tall_grass' || def.name === 'large_fern' || def.name === 'jungle_fern' || def.name === 'lily_pad' || def.name === 'sugar_cane' || def.name === 'vine') ? 1 : 0;
    LUT_CROP[i] = (def.name === 'wheat_crop' || def.name === 'carrots' || def.name === 'potatoes' || def.name === 'beetroots' || def.name === 'nether_wart' || def.name === 'melon_stem' || def.name === 'pumpkin_stem') ? 1 : 0;
    LUT_WIND[i] = def.pattern === 'leaves' ? 1 : 0;
    LUT_SOLID[i] = def.solid && def.shape !== 'water' ? 1 : 0;
    LUT_FLUID[i] = def.name === 'water' || def.name === 'lava' ? 1 : 0;
  }
  const bLen = Math.min(ALL_BLOCKS.length, MAX_IDS);
  for (let state = 0; state < 16; state++) {
    const sShift = state << 12;
    const isDoubleSlab = (state & 7) === 2;
    for (let id = 1; id < bLen; id++) {
      const def = BLOCKS[id];
      if (!def) continue;
      const cell = sShift | id;
      const full = LUT_FULL[id] === 1 || (isDoubleSlab && LUT_SLAB[id] === 1);
      const fullNoGate = full && id !== endGatewayId;
      LUT_CELL_FULL_NOGATE[cell] = fullNoGate ? 1 : 0;
      LUT_CELL_OPQ[cell] = full && LUT_OPAQUE[id] === 1 ? 1 : 0;
      LUT_CELL_SUB[cell] = !fullNoGate && def.shape !== 'water' ? 1 : 0;
    }
  }
}

// Module-level reusable buffers (zero GC per chunk inside Worker)
const lightSky = new Uint8Array(18 * 18 * HEIGHT);
const lightBlk = new Uint8Array(18 * 18 * HEIGHT);
/** (sky << 4) | block per cell, filled once after the light pass so smooth lighting reads one byte per sample. */
const lightPacked = new Uint8Array(18 * 18 * HEIGHT);
const bfsQueue = new Int32Array(18 * 18 * HEIGHT * 2);

class MeshBuf {
  p: Float32Array;
  n: Float32Array;
  uv: Float32Array;
  c: Float32Array;
  t: Float32Array;
  w: Float32Array;
  l: Float32Array;
  i: Uint32Array;
  vCount = 0;
  iCount = 0;
  capV: number;
  capI: number;

  reset() {
    this.vCount = 0;
    this.iCount = 0;
  }

  constructor(capV = 16384, capI = 24576) {
    this.capV = capV;
    this.capI = capI;
    this.p = new Float32Array(capV * 3);
    this.n = new Float32Array(capV * 3);
    this.uv = new Float32Array(capV * 2);
    this.c = new Float32Array(capV * 3);
    this.t = new Float32Array(capV);
    this.w = new Float32Array(capV);
    this.l = new Float32Array(capV * 2);
    this.i = new Uint32Array(capI);
  }

  private ensureV(add: number) {
    if (this.vCount + add <= this.capV) return;
    const next = Math.max(this.capV * 2, this.vCount + add);
    const grow = (src: Float32Array, mult: number) => {
      const dst = new Float32Array(next * mult);
      dst.set(src);
      return dst;
    };
    this.p = grow(this.p, 3);
    this.n = grow(this.n, 3);
    this.uv = grow(this.uv, 2);
    this.c = grow(this.c, 3);
    this.t = grow(this.t, 1);
    this.w = grow(this.w, 1);
    this.l = grow(this.l, 2);
    this.capV = next;
  }

  private ensureI(add: number) {
    if (this.iCount + add <= this.capI) return;
    const next = Math.max(this.capI * 2, this.iCount + add);
    const dst = new Uint32Array(next);
    dst.set(this.i);
    this.i = dst;
    this.capI = next;
  }

  pushQuad(
    x0: number, y0: number, z0: number,
    x1: number, y1: number, z1: number,
    x2: number, y2: number, z2: number,
    x3: number, y3: number, z3: number,
    nx: number, ny: number, nz: number,
    u: number, v: number, tile: number,
    ao0: number, ao1: number, ao2: number, ao3: number,
    sky0: number, sky1: number, sky2: number, sky3: number,
    blk0: number, blk1: number, blk2: number, blk3: number,
    wind: number, flip: boolean,
    r: number, g: number, b: number,
    rot90: boolean, rev: boolean,
  ) {
    if (this.vCount + 4 > this.capV) this.ensureV(4);
    if (this.iCount + 6 > this.capI) this.ensureI(6);
    const start = this.vCount;
    const pOff = start * 3, uvOff = start * 2, lOff = start * 2;
    const p = this.p, n = this.n, uv = this.uv, c = this.c, t = this.t, w = this.w, l = this.l, idx = this.i;

    p[pOff] = x0; p[pOff + 1] = y0; p[pOff + 2] = z0;
    p[pOff + 3] = x1; p[pOff + 4] = y1; p[pOff + 5] = z1;
    p[pOff + 6] = x2; p[pOff + 7] = y2; p[pOff + 8] = z2;
    p[pOff + 9] = x3; p[pOff + 10] = y3; p[pOff + 11] = z3;

    n[pOff] = nx; n[pOff + 1] = ny; n[pOff + 2] = nz;
    n[pOff + 3] = nx; n[pOff + 4] = ny; n[pOff + 5] = nz;
    n[pOff + 6] = nx; n[pOff + 7] = ny; n[pOff + 8] = nz;
    n[pOff + 9] = nx; n[pOff + 10] = ny; n[pOff + 11] = nz;

    t[start] = tile; t[start + 1] = tile; t[start + 2] = tile; t[start + 3] = tile;
    if (wind === 0) wind = subEmissive;
    w[start] = wind; w[start + 1] = wind; w[start + 2] = wind; w[start + 3] = wind;

    if (rot90) {
      uv[uvOff] = v; uv[uvOff + 1] = 0;
      uv[uvOff + 2] = v; uv[uvOff + 3] = u;
      uv[uvOff + 4] = 0; uv[uvOff + 5] = u;
      uv[uvOff + 6] = 0; uv[uvOff + 7] = 0;
    } else if (rev) {
      uv[uvOff] = u; uv[uvOff + 1] = v;
      uv[uvOff + 2] = 0; uv[uvOff + 3] = v;
      uv[uvOff + 4] = 0; uv[uvOff + 5] = 0;
      uv[uvOff + 6] = u; uv[uvOff + 7] = 0;
    } else {
      uv[uvOff] = 0; uv[uvOff + 1] = 0;
      uv[uvOff + 2] = u; uv[uvOff + 3] = 0;
      uv[uvOff + 4] = u; uv[uvOff + 5] = v;
      uv[uvOff + 6] = 0; uv[uvOff + 7] = v;
    }

    const l0 = AO_LUT[ao0], l1 = AO_LUT[ao1], l2 = AO_LUT[ao2], l3 = AO_LUT[ao3];
    c[pOff] = l0 * r; c[pOff + 1] = l0 * g; c[pOff + 2] = l0 * b;
    c[pOff + 3] = l1 * r; c[pOff + 4] = l1 * g; c[pOff + 5] = l1 * b;
    c[pOff + 6] = l2 * r; c[pOff + 7] = l2 * g; c[pOff + 8] = l2 * b;
    c[pOff + 9] = l3 * r; c[pOff + 10] = l3 * g; c[pOff + 11] = l3 * b;

    l[lOff] = sky0; l[lOff + 1] = blk0;
    l[lOff + 2] = sky1; l[lOff + 3] = blk1;
    l[lOff + 4] = sky2; l[lOff + 5] = blk2;
    l[lOff + 6] = sky3; l[lOff + 7] = blk3;

    const ii = this.iCount;
    if (flip) {
      idx[ii] = start; idx[ii + 1] = start + 1; idx[ii + 2] = start + 3;
      idx[ii + 3] = start + 1; idx[ii + 4] = start + 2; idx[ii + 5] = start + 3;
    } else {
      idx[ii] = start; idx[ii + 1] = start + 1; idx[ii + 2] = start + 2;
      idx[ii + 3] = start; idx[ii + 4] = start + 2; idx[ii + 5] = start + 3;
    }

    this.vCount = start + 4;
    this.iCount = ii + 6;
  }

  /** Overrides the colours (12 floats) and wind values (4) of the quad pushed last — used by the fluid mesher. */
  patchLast(c: Float32Array, w: Float32Array, u?: Float32Array) {
    const v = this.vCount - 4;
    this.c.set(c, v * 3);
    this.w[v] = w[0]; this.w[v + 1] = w[1]; this.w[v + 2] = w[2]; this.w[v + 3] = w[3];
    if (u) for (let k = 0; k < 4; k++) { this.uv[(v + k) * 2] = u[k]; this.uv[(v + k) * 2 + 1] = 0; }
  }

  /** Overrides the UVs of the quad pushed last (vertex 0 → (ua, va), 1 → (ub, va), 2 → (ub, vb), 3 → (ua, vb)) so a box face shows exactly its own part of the tile. */
  uvRect(ua: number, va: number, ub: number, vb: number) {
    const o = (this.vCount - 4) * 2, eu = ub >= ua ? 0.002 : -0.002, ev = vb >= va ? 0.002 : -0.002;
    const a = ua + eu, b = ub - eu, c = va + ev, d = vb - ev;
    const uv = this.uv;
    uv[o] = a; uv[o + 1] = c;
    uv[o + 2] = b; uv[o + 3] = c;
    uv[o + 4] = b; uv[o + 5] = d;
    uv[o + 6] = a; uv[o + 7] = d;
  }

  pack(): MeshData {
    return {
      position: this.p.subarray(0, this.vCount * 3).slice(),
      normal: this.n.subarray(0, this.vCount * 3).slice(),
      uv: this.uv.subarray(0, this.vCount * 2).slice(),
      color: this.c.subarray(0, this.vCount * 3).slice(),
      tile: this.t.subarray(0, this.vCount).slice(),
      wind: this.w.subarray(0, this.vCount).slice(),
      light: this.l.subarray(0, this.vCount * 2).slice(),
      index: this.i.subarray(0, this.iCount).slice(),
    };
  }
}

function computeLights(padded: Uint16Array, maxY: number) {
  const minY = MIN_Y | 0;
  const maxH = HEIGHT | 0;
  const maxLocalY = Math.min(maxH - 1, (maxY | 0) - minY + 2);
  const clearTop = Math.min(lightSky.length, (maxLocalY + 3) * STRIDE_Y);
  const waterId = ID.water | 0, lavaIdL = ID.lava | 0;
  lightSky.fill(15, (maxLocalY + 1) * STRIDE_Y, clearTop);
  lightBlk.fill(0, 0, clearTop);

  let blkHead = 0, blkTail = 0;
  const totalCap = bfsQueue.length;
  const skyStart = totalCap >> 1;
  let skyHead = skyStart, skyTail = skyStart;

  let minSkyY = maxLocalY;
  for (let z = 0; z < 18; z++) {
    const zBase = z * 18;
    for (let x = 0; x < 18; x++) {
      let sky = 15;
      let idx = maxLocalY * STRIDE_Y + zBase + x;
      for (let ly = maxLocalY; ly >= 0; ly--, idx -= STRIDE_Y) {
        const cell = padded[idx];
        if (cell !== 0) {
          const id = cell & 4095;
          const em = LUT_LIGHT[id];
          if (em !== 0) {
            lightBlk[idx] = em;
            if (blkTail < skyStart) bfsQueue[blkTail++] = x | (z << 5) | (ly << 10);
          }
          if (LUT_CELL_OPQ[cell] === 1) {
            sky = 0;
          } else if (id === waterId || id === lavaIdL || LUT_WIND[id] === 1) {
            sky = sky > 1 ? sky - 1 : 0;                   // Java: water / leaves have light dampening 1
          }
        }
        lightSky[idx] = sky;
        if (sky > 1 && ly < minSkyY) minSkyY = ly;
      }
    }
  }

  for (let ly = maxLocalY; ly >= minSkyY; ly--) {
    const yOff = ly * STRIDE_Y;
    const lyShift = ly << 10;
    for (let z = 1; z < 17; z++) {
      const zOff = yOff + z * 18;
      const zShift = lyShift | (z << 5);
      for (let x = 1; x < 17; x++) {
        const idx = zOff + x;
        const s = lightSky[idx];
        if (s > 1) {
          if (lightSky[idx - 1] + 1 < s || lightSky[idx + 1] + 1 < s || lightSky[idx - 18] + 1 < s || lightSky[idx + 18] + 1 < s) {
            if (skyTail < totalCap) bfsQueue[skyTail++] = x | zShift;
          }
        }
      }
    }
  }

  while (skyHead < skyTail) {
    const packed = bfsQueue[skyHead++];
    const x = packed & 31, z = (packed >> 5) & 31, ly = packed >> 10;
    const idx = ly * STRIDE_Y + z * 18 + x;
    const cur = lightSky[idx];
    if (cur <= 1) continue;

    if (x > 0) {
      const ni = idx - 1, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - 1;                              // max(1, dampening) = 1 for every see-through block
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = packed - 1; }
      }
    }
    if (x < 17) {
      const ni = idx + 1, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - 1;                              // max(1, dampening) = 1 for every see-through block
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = packed + 1; }
      }
    }
    if (z > 0) {
      const ni = idx - 18, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - 1;                              // max(1, dampening) = 1 for every see-through block
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = packed - 32; }
      }
    }
    if (z < 17) {
      const ni = idx + 18, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - 1;                              // max(1, dampening) = 1 for every see-through block
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = packed + 32; }
      }
    }
    if (ly > 0) {
      const ni = idx - STRIDE_Y, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - 1;                              // max(1, dampening) = 1 for every see-through block
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = packed - 1024; }
      }
    }
    if (ly < maxLocalY) {
      const ni = idx + STRIDE_Y, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - 1;                              // max(1, dampening) = 1 for every see-through block
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = packed + 1024; }
      }
    }
  }

  while (blkHead < blkTail) {
    const packed = bfsQueue[blkHead++];
    const x = packed & 31, z = (packed >> 5) & 31, ly = packed >> 10;
    const idx = ly * STRIDE_Y + z * 18 + x;
    const next = lightBlk[idx] - 1;
    if (next <= 0) continue;

    if (x > 0) {
      const ni = idx - 1, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = packed - 1; }
    }
    if (x < 17) {
      const ni = idx + 1, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = packed + 1; }
    }
    if (z > 0) {
      const ni = idx - 18, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = packed - 32; }
    }
    if (z < 17) {
      const ni = idx + 18, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = packed + 32; }
    }
    if (ly > 0) {
      const ni = idx - STRIDE_Y, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = packed - 1024; }
    }
    if (ly < maxLocalY) {
      const ni = idx + STRIDE_Y, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = packed + 1024; }
    }
  }
  const n = Math.min(lightPacked.length, (maxLocalY + 3) * STRIDE_Y);
  for (let i = 0; i < n; i++) lightPacked[i] = (lightSky[i] << 4) | lightBlk[i];
  if (n < lightPacked.length) lightPacked.fill(0xf0, n, Math.min(lightPacked.length, n + 2 * STRIDE_Y));
}

const isOpq = (cell: number) => LUT_CELL_OPQ[cell] === 1;

function getCellAt(padded: Uint16Array, dimsY: number, x: number, ly: number, z: number) {
  if (ly < 0 || ly >= dimsY) return 0;
  return padded[ly * STRIDE_Y + (z + 1) * 18 + (x + 1)];
}

function lightIdx(x: number, ly: number, z: number) {
  const cy = ly < 0 ? 0 : ly >= HEIGHT ? HEIGHT - 1 : ly;
  return cy * STRIDE_Y + (z + 1) * 18 + (x + 1);
}

function aoFor(s1: number, s2: number, c: number) {
  const a = LUT_CELL_OPQ[s1], b = LUT_CELL_OPQ[s2];
  return (a & b) !== 0 ? 3 : a + b + LUT_CELL_OPQ[c];
}

// Reusable mask & key buffers for Greedy Meshing
const maskBuf = new Int32Array(HEIGHT * 16);
const waterMaskBuf = new Int32Array(HEIGHT * 16);
const keyCacheBuf = new Int32Array(HEIGHT * 16);
const keyCacheStamp = new Int32Array(HEIGHT * 16);
const lightKeyBuf = new Float64Array(HEIGHT * 16);
let currentKeyStamp = 1;

const reusableOut = new MeshBuf(16384, 24576);
const reusableWater = new MeshBuf(4096, 6144);

function cornerDepthAt(padded: Uint16Array, dimsY: number, waterId: number, lavaId: number, vx: number, vy: number, vz: number) {
  let sum = 0;
  for (let dz = -1; dz <= 0; dz++) {
    const z = vz + dz;
    for (let dx = -1; dx <= 0; dx++) {
      const x = vx + dx;
      let d = 0;
      for (let k = 1; k <= 6; k++) {
        const c = getCellAt(padded, dimsY, x, vy - k, z) & 4095;
        if (c === waterId || c === lavaId) d++;
        else break;
      }
      sum += d;
    }
  }
  const avg = sum * 0.25;
  return avg > 6 ? 1 : avg / 6;
}

function shoreAt(padded: Uint16Array, dimsY: number, waterId: number, lavaId: number, vx: number, vy: number, vz: number) {
  for (let dz = -1; dz <= 0; dz++) {
    for (let dx = -1; dx <= 0; dx++) {
      const c = getCellAt(padded, dimsY, vx + dx, vy - 1, vz + dz) & 4095;
      if (c !== 0 && c !== waterId && c !== lavaId) return 1;
    }
  }
  return 0;
}

const AXIS_STRIDES = [1, STRIDE_Y, 18];

/**
 * Smooth lighting (Java AmbientOcclusionFace.blend): every face corner averages the packed light of the face cell, its two
 * side neighbours and the diagonal one; a value of 0 (an opaque neighbour) is replaced by the face cell's light and the
 * diagonal is skipped when both sides are opaque. Sums (0‥60 per channel) for the 4 corners are written to `lastLightKey`
 * as sky24 · 2²⁴ + blk24 so the greedy merger only joins cells with identical light gradients.
 */
let lastLightKey = 0;
/** aoKey bit: the face looks into water (the shader adds caustics). */
const SUBMERGED = 1 << 16;
let waterIdK = -1;
function blendCorners(c: number, u0: number, u1: number, v0: number, v1: number, d00: number, d10: number, d11: number, d01: number,
  ou0: number, ou1: number, ov0: number, ov1: number) {
  if (u0 === 0) u0 = c; if (u1 === 0) u1 = c; if (v0 === 0) v0 = c; if (v1 === 0) v1 = c;
  const k0 = (ou0 & ov0) !== 0 || d00 === 0 ? c : d00, k1 = (ou1 & ov0) !== 0 || d10 === 0 ? c : d10;
  const k2 = (ou1 & ov1) !== 0 || d11 === 0 ? c : d11, k3 = (ou0 & ov1) !== 0 || d01 === 0 ? c : d01;
  const s0 = (c >> 4) + (u0 >> 4) + (v0 >> 4) + (k0 >> 4), b0 = (c & 15) + (u0 & 15) + (v0 & 15) + (k0 & 15);
  const s1 = (c >> 4) + (u1 >> 4) + (v0 >> 4) + (k1 >> 4), b1 = (c & 15) + (u1 & 15) + (v0 & 15) + (k1 & 15);
  const s2 = (c >> 4) + (u1 >> 4) + (v1 >> 4) + (k2 >> 4), b2 = (c & 15) + (u1 & 15) + (v1 & 15) + (k2 & 15);
  const s3 = (c >> 4) + (u0 >> 4) + (v1 >> 4) + (k3 >> 4), b3 = (c & 15) + (u0 & 15) + (v1 & 15) + (k3 & 15);
  lastLightKey = (s0 | (s1 << 6) | (s2 << 12) | (s3 << 18)) * 16777216 + (b0 | (b1 << 6) | (b2 << 12) | (b3 << 18));
}
const lp = (i: number) => lightPacked[i];

function computeCellAoKey(
  padded: Uint16Array,
  dimsY: number,
  d: number,
  u: number,
  v: number,
  airD: number,
  uStride: number,
  vStride: number,
  ii: number,
  jj: number,
): number {
  const fx = d === 0 ? airD : u === 0 ? ii : jj;
  const fy = d === 1 ? airD : u === 1 ? ii : jj;
  const fz = d === 2 ? airD : u === 2 ? ii : jj;

  // Fast interior path: no Y bounds clipping needed for neighbor lookups
  if (d === 1 ? (fy >= 0 && fy < dimsY) : (fy > 0 && fy < dimsY - 1)) {
    const fIdx = fy * STRIDE_Y + (fz + 1) * 18 + (fx + 1);
    const lk = (lightSky[fIdx] << 4) | lightBlk[fIdx];

    const u0 = LUT_CELL_OPQ[padded[fIdx - uStride]];
    const u1 = LUT_CELL_OPQ[padded[fIdx + uStride]];
    const v0 = LUT_CELL_OPQ[padded[fIdx - vStride]];
    const v1 = LUT_CELL_OPQ[padded[fIdx + vStride]];

    const ao0 = (u0 & v0) !== 0 ? 3 : u0 + v0 + LUT_CELL_OPQ[padded[fIdx - uStride - vStride]];
    const ao1 = (u1 & v0) !== 0 ? 3 : u1 + v0 + LUT_CELL_OPQ[padded[fIdx + uStride - vStride]];
    const ao2 = (u1 & v1) !== 0 ? 3 : u1 + v1 + LUT_CELL_OPQ[padded[fIdx + uStride + vStride]];
    const ao3 = (u0 & v1) !== 0 ? 3 : u0 + v1 + LUT_CELL_OPQ[padded[fIdx - uStride + vStride]];

    blendCorners(lk, lp(fIdx - uStride), lp(fIdx + uStride), lp(fIdx - vStride), lp(fIdx + vStride),
      lp(fIdx - uStride - vStride), lp(fIdx + uStride - vStride), lp(fIdx + uStride + vStride), lp(fIdx - uStride + vStride), u0, u1, v0, v1);
    return ao0 | (ao1 << 2) | (ao2 << 4) | (ao3 << 6) | (lk << 8) | ((padded[fIdx] & 4095) === waterIdK ? SUBMERGED : 0);
  }

  const lIdx = lightIdx(fx, fy, fz);
  const lk = (lightSky[lIdx] << 4) | lightBlk[lIdx];
  const ux = u === 0 ? 1 : 0, uy = u === 1 ? 1 : 0, uz = u === 2 ? 1 : 0;
  const vx = v === 0 ? 1 : 0, vy = v === 1 ? 1 : 0, vz = v === 2 ? 1 : 0;

  const s_u0 = getCellAt(padded, dimsY, fx - ux, fy - uy, fz - uz);
  const s_u1 = getCellAt(padded, dimsY, fx + ux, fy + uy, fz + uz);
  const s_v0 = getCellAt(padded, dimsY, fx - vx, fy - vy, fz - vz);
  const s_v1 = getCellAt(padded, dimsY, fx + vx, fy + vy, fz + vz);

  const ao0 = aoFor(s_u0, s_v0, getCellAt(padded, dimsY, fx - ux - vx, fy - uy - vy, fz - uz - vz));
  const ao1 = aoFor(s_u1, s_v0, getCellAt(padded, dimsY, fx + ux - vx, fy + uy - vy, fz + uz - vz));
  const ao2 = aoFor(s_u1, s_v1, getCellAt(padded, dimsY, fx + ux + vx, fy + uy + vy, fz + uz + vz));
  const ao3 = aoFor(s_u0, s_v1, getCellAt(padded, dimsY, fx - ux + vx, fy - uy + vy, fz - uz + vz));

  const L = (ox: number, oy: number, oz: number) => lp(lightIdx(fx + ox, fy + oy, fz + oz));
  blendCorners(lk, L(-ux, -uy, -uz), L(ux, uy, uz), L(-vx, -vy, -vz), L(vx, vy, vz),
    L(-ux - vx, -uy - vy, -uz - vz), L(ux - vx, uy - vy, uz - vz), L(ux + vx, uy + vy, uz + vz), L(-ux + vx, -uy + vy, -uz + vz),
    LUT_CELL_OPQ[s_u0], LUT_CELL_OPQ[s_u1], LUT_CELL_OPQ[s_v0], LUT_CELL_OPQ[s_v1]);
  return ao0 | (ao1 << 2) | (ao2 << 4) | (ao3 << 6) | (lk << 8) | ((getCellAt(padded, dimsY, fx, fy, fz) & 4095) === waterIdK ? SUBMERGED : 0);
}

function meshGreedy(padded: Uint16Array, dimsY: number, tiles: number[][], tint: Float32Array | undefined, out: MeshBuf, water: MeshBuf) {
  const minY = MIN_Y | 0;
  const waterId = ID.water | 0;
  const lavaId = ID.lava | 0;
  const blocks = BLOCKS;
  const mask = maskBuf;
  const waterMask = waterMaskBuf;
  const kBuf = keyCacheBuf;
  const kStamp = keyCacheStamp;
  const lkBuf = lightKeyBuf;

  for (let d = 0; d < 3; d++) {
    const u = (d + 1) % 3, v = (d + 2) % 3;
    const dLen = d === 1 ? dimsY : 16;
    const duLen = u === 1 ? dimsY : 16;
    const dvLen = v === 1 ? dimsY : 16;
    const dStride = AXIS_STRIDES[d];
    const uStride = AXIS_STRIDES[u];
    const vStride = AXIS_STRIDES[v];

    for (let slice = -1; slice < dLen; slice++) {
      if (d === 1 && (slice < 0 || slice >= dimsY - 1)) continue;

      let n = 0;
      let hasAnyFace = false;
      const aValid = slice >= 0;
      const bValid = slice < dLen - 1;
      const baseSliceIdx = 19 + slice * dStride;

      for (let j = 0; j < dvLen; j++) {
        let rowIdx = baseSliceIdx + j * vStride;
        for (let i = 0; i < duLen; i++, n++, rowIdx += uStride) {
          const a = padded[rowIdx];
          const b = padded[rowIdx + dStride];
          if (a === b || (LUT_CELL_OPQ[a] & LUT_CELL_OPQ[b]) !== 0) {
            mask[n] = 0;
            waterMask[n] = 0;
            continue;
          }

          const aId = a & 4095, bId = b & 4095;
          const aFull = LUT_CELL_FULL_NOGATE[a] === 1;
          const bFull = LUT_CELL_FULL_NOGATE[b] === 1;

          let mVal = 0;
          if (aFull !== bFull) {
            if (aFull && aValid) mVal = a;
            else if (bFull && bValid) mVal = -b;
          } else if (aFull && bFull) {
            const aTr = LUT_TRANSPARENT[aId] === 1;
            const bTr = LUT_TRANSPARENT[bId] === 1;
            if (aTr !== bTr) {
              if (!aTr && aValid) mVal = a;
              else if (!bTr && bValid) mVal = -b;
            } else if (aTr && aId !== bId && aValid) {
              mVal = a;
            }
          }
          mask[n] = mVal;

          // Fluids are meshed separately by meshFluids (vanilla corner heights, flow, light).
          waterMask[n] = 0;

          if (mVal !== 0) hasAnyFace = true;
        }
      }

      if (!hasAnyFace) continue;

      const sliceStampPos = (currentKeyStamp += 2);
      const sliceStampNeg = sliceStampPos + 1;
      currentKeyStamp = sliceStampNeg;

      n = 0;
      for (let j = 0; j < dvLen; j++) {
        for (let i = 0; i < duLen; ) {
          const m = mask[n], wm = waterMask[n];
          const val = m !== 0 ? m : wm;
          if (!val) { i++; n++; continue; }

          const isWaterQuad = m === 0;
          const sign = val > 0 ? 1 : -1;
          const cell = (val > 0 ? val : -val) & ~0x400;
          const id = cell & 4095, state = (cell >>> 12) & 15;
          const airD = slice + (sign > 0 ? 1 : 0);
          const stamp = sign > 0 ? sliceStampPos : sliceStampNeg;

          let aoKey = 0, lightKey = 0;
          if (isWaterQuad) {
            aoKey = (wm > 0 && (wm & 0x400) !== 0) ? 256 : 0;
          } else if (kStamp[n] === stamp) {
            aoKey = kBuf[n]; lightKey = lkBuf[n];
          } else {
            aoKey = computeCellAoKey(padded, dimsY, d, u, v, airD, uStride, vStride, i, j);
            kBuf[n] = aoKey; lightKey = lkBuf[n] = lastLightKey;
            kStamp[n] = stamp;
          }

          const ao0 = aoKey & 3;
          const ao1 = (aoKey >>> 2) & 3;
          const ao2 = (aoKey >>> 4) & 3;
          const ao3 = (aoKey >>> 6) & 3;

          const activeMask = isWaterQuad ? waterMask : mask;
          const noMerge = (!isWaterQuad && (LUT_TINT_TOP[id] === 1 || LUT_TINT_ALL[id] === 1)) || (isWaterQuad && (state & 7) !== 0);
          let w = 1, h = 1;
          if (!noMerge) {
            if (isWaterQuad) {
              while (i + w < duLen && activeMask[n + w] === val) w++;
              outerW: for (; j + h < dvLen; h++) {
                const rowBase = n + h * duLen;
                for (let k = 0; k < w; k++) {
                  if (activeMask[rowBase + k] !== val) break outerW;
                }
              }
            } else {
              while (i + w < duLen && activeMask[n + w] === val) {
                const idxW = n + w;
                let kW: number;
                if (kStamp[idxW] === stamp) {
                  kW = kBuf[idxW];
                } else {
                  kW = computeCellAoKey(padded, dimsY, d, u, v, airD, uStride, vStride, i + w, j);
                  kBuf[idxW] = kW; lkBuf[idxW] = lastLightKey;
                  kStamp[idxW] = stamp;
                }
                if (kW !== aoKey || lkBuf[idxW] !== lightKey) break;
                w++;
              }
              outer: for (; j + h < dvLen; h++) {
                const rowBase = n + h * duLen;
                for (let k = 0; k < w; k++) {
                  const idxH = rowBase + k;
                  if (activeMask[idxH] !== val) break outer;
                  let kH: number;
                  if (kStamp[idxH] === stamp) {
                    kH = kBuf[idxH];
                  } else {
                    kH = computeCellAoKey(padded, dimsY, d, u, v, airD, uStride, vStride, i + k, j + h);
                    kBuf[idxH] = kH; lkBuf[idxH] = lastLightKey;
                    kStamp[idxH] = stamp;
                  }
                  if (kH !== aoKey || lkBuf[idxH] !== lightKey) break outer;
                }
              }
            }
          }

          const fld = isWaterQuad ? state & 7 : 0;
          const p0 = d === 0 ? slice + 1 : u === 0 ? i : j;
          const p1 = d === 1 ? slice + 1 : u === 1 ? i : j;
          const p2 = d === 2 ? slice + 1 : u === 2 ? i : j;

          const u0 = u === 0 ? w : 0, u1 = u === 1 ? w : 0, u2 = u === 2 ? w : 0;
          const v0 = v === 0 ? h : 0, v1 = v === 1 ? h : 0, v2 = v === 2 ? h : 0;

          const lift = isWaterQuad && d === 1 && sign > 0 && !fld ? -0.1 : 0;
          const bp0 = p0, bp1 = p1 + lift, bp2 = p2;

          const sdu = isWaterQuad ? 0 : SEAM, sdv = isWaterQuad ? 0 : SEAM;
          const su0 = u === 0 ? sdu : 0, su1 = u === 1 ? sdu : 0, su2 = u === 2 ? sdu : 0;
          const sv0 = v === 0 ? sdv : 0, sv1 = v === 1 ? sdv : 0, sv2 = v === 2 ? sdv : 0;

          const vx0 = bp0 - su0 - sv0, vx1 = bp0 + u0 + su0 - sv0, vx2 = bp0 + u0 + su0 + v0 + sv0, vx3 = bp0 - su0 + v0 + sv0;
          let vy0 = bp1 + minY - su1 - sv1, vy1 = bp1 + u1 + minY + su1 - sv1, vy2 = bp1 + u1 + v1 + minY + su1 + sv1, vy3 = bp1 + v1 + minY - su1 + sv1;
          const vz0 = bp2 - su2 - sv2, vz1 = bp2 + u2 + su2 - sv2, vz2 = bp2 + u2 + su2 + v2 + sv2, vz3 = bp2 - su2 + v2 + sv2;

          if (isWaterQuad && d === 1 && sign > 0) {
            const dr = fld ? fld / 9 : 0.12;
            vy0 -= dr; vy1 -= dr; vy2 -= dr; vy3 -= dr;
          } else if (isWaterQuad && fld && d !== 1) {
            const dr = fld / 9, top = Math.max(vy0, vy1, vy2, vy3);
            if (vy0 === top) vy0 -= dr;
            if (vy1 === top) vy1 -= dr;
            if (vy2 === top) vy2 -= dr;
            if (vy3 === top) vy3 -= dr;
          }

          let s0 = 0, s1 = 0, s2 = 0, s3 = 0, b0 = 1, b1 = 1, b2 = 1, b3 = 1;
          if (isWaterQuad) {
            if (wm > 0 && (wm & 0x400) !== 0) {
              s0 = shoreAt(padded, dimsY, waterId, lavaId, vx0, slice, vz0);
              s1 = shoreAt(padded, dimsY, waterId, lavaId, vx1, slice, vz1);
              s2 = shoreAt(padded, dimsY, waterId, lavaId, vx2, slice, vz2);
              s3 = shoreAt(padded, dimsY, waterId, lavaId, vx3, slice, vz3);
              b0 = cornerDepthAt(padded, dimsY, waterId, lavaId, vx0, slice, vz0);
              b1 = cornerDepthAt(padded, dimsY, waterId, lavaId, vx1, slice, vz1);
              b2 = cornerDepthAt(padded, dimsY, waterId, lavaId, vx2, slice, vz2);
              b3 = cornerDepthAt(padded, dimsY, waterId, lavaId, vx3, slice, vz3);
            }
          } else {
            // Smooth lighting: per-corner sums (0‥60) of the four blended light samples (see blendCorners).
            const skyK = Math.floor(lightKey / 16777216), blkK = lightKey - skyK * 16777216;
            s0 = (skyK & 63) / 60; s1 = ((skyK >>> 6) & 63) / 60; s2 = ((skyK >>> 12) & 63) / 60; s3 = ((skyK >>> 18) & 63) / 60;
            b0 = (blkK & 63) / 60; b1 = ((blkK >>> 6) & 63) / 60; b2 = ((blkK >>> 12) & 63) / 60; b3 = ((blkK >>> 18) & 63) / 60;
          }

          const def = blocks[id];
          const tinted = !isWaterQuad && ((LUT_TINT_TOP[id] === 1 && d === 1 && sign > 0) || LUT_TINT_ALL[id] === 1);
          let r = 1, g = 1, b = 1;
          if (tinted) {
            if (tint) {
              const cx = vx0 < 0 ? 0 : vx0 > 15 ? 15 : vx0 | 0;
              const cz = vz0 < 0 ? 0 : vz0 > 15 ? 15 : vz0 | 0;
              const ti = (cz * 16 + cx) * 3;
              r = tint[ti]; g = tint[ti + 1]; b = tint[ti + 2];
            } else {
              r = 0.88; g = 1.25; b = 0.60;
            }
          }

          const worldFace = (d * 2 + (sign > 0 ? 0 : 1)) as Face;
          const tile = isWaterQuad ? (id === lavaId ? 1 : 0) : tiles[id][localFaceForState(def, state, worldFace)];
          const nx = d === 0 ? sign : 0, ny = d === 1 ? sign : 0, nz = d === 2 ? sign : 0;
          // wind: 0.13 sways leaves; 1.0 flags a light-emitting block (emissive texels); 0.5 = a face under water (caustics).
          const wind = LUT_WIND[id] === 1 ? 0.13 : LUT_LIGHT[id] >= 10 ? 1 : !isWaterQuad && (aoKey & SUBMERGED) !== 0 ? 0.5 : 0;
          const targetBuf = isWaterQuad ? water : out;

          const logAxis = def.pattern === 'bark' ? (state & 3) : 0;
          const rotUv = logAxis === 1 ? (d === 0 || d === 2) : logAxis === 2 ? (d === 1) : (d === 0);
          if (sign < 0) {
            targetBuf.pushQuad(
              vx3, vy3, vz3, vx2, vy2, vz2, vx1, vy1, vz1, vx0, vy0, vz0,
              nx, ny, nz, w, h, tile,
              ao3, ao2, ao1, ao0,
              s3, s2, s1, s0,
              b3, b2, b1, b0,
              wind, ao3 + ao1 > ao2 + ao0, r, g, b, rotUv, true,
            );
          } else {
            targetBuf.pushQuad(
              vx0, vy0, vz0, vx1, vy1, vz1, vx2, vy2, vz2, vx3, vy3, vz3,
              nx, ny, nz, w, h, tile,
              ao0, ao1, ao2, ao3,
              s0, s1, s2, s3,
              b0, b1, b2, b3,
              wind, ao0 + ao2 > ao1 + ao3, r, g, b, rotUv, false,
            );
          }

          for (let dy = 0; dy < h; dy++) {
            const row = (j + dy) * duLen + i;
            for (let dx = 0; dx < w; dx++) {
              mask[row + dx] = 0;
              waterMask[row + dx] = 0;
            }
          }
          i += w;
          n += w;
        }
      }
    }
  }
}

const CN = new Float64Array(24);
const FQ = [4, 5, 7, 6, 1, 0, 2, 3, 6, 7, 3, 2, 0, 1, 5, 4, 5, 1, 3, 7, 0, 4, 6, 2];
const FNRM = [0, 0, 1, 0, 0, -1, 0, 1, 0, 0, -1, 0, 1, 0, 0, -1, 0, 0];
const FWORLD: readonly Face[] = [4, 5, 2, 3, 0, 1];
const STICK_UP = [7, 0, 7, 9, 10, 9], STICK_DOWN = [7, 10, 7, 9, 0, 9], DT = [0, 0, 0, 0, 16, 0];
const CAULDRON_FEET: readonly [number, number][] = [[0, 0], [13, 0], [0, 13], [13, 13]];

const emitBox = (bx: number, by: number, bz: number, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, tile: number, sky: number, blk: number, tex?: readonly number[], mirror = false, end = -1, sdx = 0, sdz = 0, cr = 1, cg = 1, cb = 1, topTile?: number, botTile?: number, frontTile?: number) => {
  for (let i = 0; i < 8; i++) {
    const top = (i >> 1) & 1, sh = end === top;
    CN[i * 3] = bx + ((i & 1 ? x1 : x0) + (sh ? sdx : 0)) / 16;
    CN[i * 3 + 1] = by + (top ? y1 : y0) / 16;
    CN[i * 3 + 2] = bz + ((i & 4 ? z1 : z0) + (sh ? sdz : 0)) / 16;
  }
  const ux0 = (tex ? tex[0] : x0) / 16, v0 = (tex ? tex[1] : y0) / 16, uz0 = (tex ? tex[2] : z0) / 16;
  const ux1 = (tex ? tex[3] : x1) / 16, v1 = (tex ? tex[4] : y1) / 16, uz1 = (tex ? tex[5] : z1) / 16;
  for (let f = 0; f < 6; f++) {
    const fTile = f === 2 && topTile !== undefined ? topTile : f === 3 && botTile !== undefined ? botTile : f === 0 && frontTile !== undefined ? frontTile : tile;
    const a = FQ[f * 4] * 3, b = FQ[f * 4 + 1] * 3, c = FQ[f * 4 + 2] * 3, d = FQ[f * 4 + 3] * 3;
    reusableOut.pushQuad(CN[a], CN[a + 1], CN[a + 2], CN[b], CN[b + 1], CN[b + 2], CN[c], CN[c + 1], CN[c + 2], CN[d], CN[d + 1], CN[d + 2], FNRM[f * 3], FNRM[f * 3 + 1], FNRM[f * 3 + 2], 1, 1, fTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, cr, cg, cb, false, false);
    if (f === 0) reusableOut.uvRect(ux0, v0, ux1, v1);
    else if (f === 1) { if (mirror) reusableOut.uvRect(ux1, v0, ux0, v1); else reusableOut.uvRect(1 - ux1, v0, 1 - ux0, v1); }
    else if (f === 2) reusableOut.uvRect(ux0, 1 - uz1, ux1, 1 - uz0);
    else if (f === 3) reusableOut.uvRect(ux0, uz0, ux1, uz1);
    else if (f === 4) { if (mirror) reusableOut.uvRect(uz1, v0, uz0, v1); else reusableOut.uvRect(1 - uz1, v0, 1 - uz0, v1); }
    else reusableOut.uvRect(uz0, v0, uz1, v1);
  }
};

const emitBoxFaces = (
  bx: number, by: number, bz: number,
  x0: number, y0: number, z0: number,
  x1: number, y1: number, z1: number,
  bt: readonly number[], def: BlockDef, state: number,
  sky: number, blk: number,
) => {
  for (let i = 0; i < 8; i++) {
    const top = (i >> 1) & 1;
    CN[i * 3] = bx + (i & 1 ? x1 : x0) / 16;
    CN[i * 3 + 1] = by + (top ? y1 : y0) / 16;
    CN[i * 3 + 2] = bz + (i & 4 ? z1 : z0) / 16;
  }
  const ux0 = x0 / 16, v0 = y0 / 16, uz0 = z0 / 16;
  const ux1 = x1 / 16, v1 = y1 / 16, uz1 = z1 / 16;
  for (let f = 0; f < 6; f++) {
    const wf = FWORLD[f];
    const tile = bt[localFaceForState(def, state, wf)] ?? bt[0];
    const a = FQ[f * 4] * 3, b = FQ[f * 4 + 1] * 3, c = FQ[f * 4 + 2] * 3, d = FQ[f * 4 + 3] * 3;
    reusableOut.pushQuad(CN[a], CN[a + 1], CN[a + 2], CN[b], CN[b + 1], CN[b + 2], CN[c], CN[c + 1], CN[c + 2], CN[d], CN[d + 1], CN[d + 2], FNRM[f * 3], FNRM[f * 3 + 1], FNRM[f * 3 + 2], 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
    if (f === 0) reusableOut.uvRect(ux0, v0, ux1, v1);
    else if (f === 1) reusableOut.uvRect(1 - ux1, v0, 1 - ux0, v1);
    else if (f === 2) reusableOut.uvRect(ux0, 1 - uz1, ux1, 1 - uz0);
    else if (f === 3) reusableOut.uvRect(ux0, uz0, ux1, uz1);
    else if (f === 4) reusableOut.uvRect(1 - uz1, v0, 1 - uz0, v1);
    else reusableOut.uvRect(uz0, v0, uz1, v1);
  }
};

/** Emits a box authored with its front facing +Z (z1 = 16), rotated around (8, y, 8) by horizontal facing (0=+Z, 1=-X, 2=-Z, 3=+X). */
const emitRotBox = (
  bx: number, by: number, bz: number,
  facing: number,
  x0: number, y0: number, z0: number,
  x1: number, y1: number, z1: number,
  tile: number, sky: number, blk: number,
) => {
  const f = facing & 3;
  let rx0 = x0, rz0 = z0, rx1 = x1, rz1 = z1;
  if (f === 1) { rx0 = 16 - z1; rz0 = x0; rx1 = 16 - z0; rz1 = x1; }
  else if (f === 2) { rx0 = 16 - x1; rz0 = 16 - z1; rx1 = 16 - x0; rz1 = 16 - z0; }
  else if (f === 3) { rx0 = z0; rz0 = 16 - x1; rx1 = z1; rz1 = 16 - x0; }
  emitBox(bx, by, bz, rx0, y0, rz0, rx1, y1, rz1, tile, sky, blk);
};

const FULL_UV: readonly number[] = [0, 0, 0, 16, 16, 16];

function meshSubBlocks(padded: Uint16Array, dimsY: number, tiles: number[][], tint: Float32Array | undefined, out: MeshBuf) {
  const minY = MIN_Y | 0;
  const blocks = BLOCKS;

  for (let ly = 0; ly < dimsY; ly++) {
    const y = ly + minY;
    const yOff = ly * STRIDE_Y;
    for (let z = 0; z < 16; z++) {
      const zOff = yOff + (z + 1) * 18 + 1;
      for (let x = 0; x < 16; x++) {
        const lIdx = zOff + x;
        const cell = padded[lIdx];
        if (LUT_CELL_SUB[cell] === 0) continue;
        const id = cell & 4095, b = blocks[id];
        const state = (cell >>> 12) & 15;
        const sky = lightSky[lIdx] / 15;
        const blk = LUT_LIGHT[id] !== 0 ? 1 : lightBlk[lIdx] / 15;
        subEmissive = LUT_LIGHT[id] >= 10 ? 1 : 0;

        let r = 1, g = 1, bl = 1;
        if (tint && LUT_TINT_SUB[id] === 1) {
          const ti = (z * 16 + x) * 3;
          r = tint[ti]; g = tint[ti + 1]; bl = tint[ti + 2];
        }

        if (b.name === 'conduit') {
          const shellTile = tiles[id][6] ?? tiles[id][0];
          const coreTile = tiles[id][7] ?? tiles[ID.sea_lantern]?.[0] ?? shellTile;
          const eyeTile = tiles[id][8] ?? coreTile;
          const prisTile = tiles[ID.prismarine]?.[0] ?? shellTile;
          if (state === 0) {
            emitBox(x, y, z, 5, 5, 5, 11, 11, 11, shellTile, sky, 1);
            emitBox(x, y, z, 4.6, 7, 4.6, 11.4, 9, 11.4, prisTile, sky, 1);
            emitBox(x, y, z, 7, 4.6, 4.6, 9, 11.4, 11.4, prisTile, sky, 1);
          } else {
            emitBox(x, y, z, 4.5, 3, 4.5, 11.5, 4.6, 11.5, shellTile, sky, 1);
            emitBox(x, y, z, 4.5, 11.4, 4.5, 11.5, 13, 11.5, shellTile, sky, 1);
            emitBox(x, y, z, 4.0, 4.2, 4.0, 5.6, 11.8, 5.6, shellTile, sky, 1);
            emitBox(x, y, z, 10.4, 4.2, 4.0, 12.0, 11.8, 5.6, shellTile, sky, 1);
            emitBox(x, y, z, 4.0, 4.2, 10.4, 5.6, 11.8, 12.0, shellTile, sky, 1);
            emitBox(x, y, z, 10.4, 4.2, 10.4, 12.0, 11.8, 12.0, shellTile, sky, 1);
            emitBox(x, y, z, 5.8, 5.8, 5.8, 10.2, 10.2, 10.2, state >= 2 ? eyeTile : coreTile, sky, 1);
            if (state >= 2) {
              emitBox(x, y, z, 5.4, 6.6, 5.4, 10.6, 9.4, 10.6, eyeTile, sky, 1);
              for (const cx of [3.2, 11.4]) for (const cy of [3.2, 11.4]) for (const cz of [3.2, 11.4]) {
                emitBox(x, y, z, cx, cy, cz, cx + 1.4, cy + 1.4, cz + 1.4, coreTile, sky, 1);
              }
            }
          }
        } else if (b.name === 'sea_pickle') {
          const bodyTile = tiles[id][6] ?? tiles[id][0];
          const topTile = tiles[id][7] ?? tiles[id][2] ?? bodyTile;
          const stemTile = tiles[id][8] ?? tiles[ID.sea_lantern]?.[0] ?? topTile;
          const count = 1 + (state & 3);
          if (count === 1) {
            emitBox(x, y, z, 6, 0, 6, 10, 6, 10, bodyTile, sky, 1);
            emitBox(x, y, z, 5.6, 1.5, 7, 10.4, 2.8, 9, bodyTile, sky, 1);
            emitBox(x, y, z, 7, 3.2, 5.6, 9, 4.5, 10.4, bodyTile, sky, 1);
            emitBox(x, y, z, 6.4, 6, 6.4, 9.6, 6.5, 9.6, topTile, sky, 1);
            emitBox(x, y, z, 7, 6.5, 7, 9, 7.7, 9, stemTile, sky, 1);
          } else {
            const P: readonly [number, number, number][] = [
              [3.2, 3.2, 6.5],
              [9.0, 3.8, 5.4],
              [3.6, 9.2, 5.0],
              [9.0, 9.0, 7.2],
            ];
            for (let pi = 0; pi < count; pi++) {
              const [px, pz, ph] = P[pi];
              emitBox(x, y, z, px, 0, pz, px + 3.6, ph, pz + 3.6, bodyTile, sky, 1);
              emitBox(x, y, z, px - 0.3, ph * 0.4, pz + 0.9, px + 3.9, ph * 0.65, pz + 2.7, bodyTile, sky, 1);
              emitBox(x, y, z, px + 0.5, ph, pz + 0.5, px + 3.1, ph + 0.5, pz + 3.1, topTile, sky, 1);
              emitBox(x, y, z, px + 0.9, ph + 0.5, pz + 0.9, px + 2.7, ph + 1.5, pz + 2.7, stemTile, sky, 1);
            }
          }
        } else if (b.name === 'turtle_egg') {
          const count = 1 + (state & 3);
          const crack = (state >> 2) & 3;
          const sideTile = crack >= 2 ? (tiles[id][8] ?? tiles[id][0]) : crack === 1 ? (tiles[id][7] ?? tiles[id][0]) : (tiles[id][6] ?? tiles[id][0]);
          const topTile = tiles[id][9] ?? sideTile;
          if (count === 1) {
            emitBox(x, y, z, 5.5, 0, 5.5, 10.5, 6, 10.5, sideTile, sky, blk);
            emitBox(x, y, z, 6.2, 6, 6.2, 9.8, 7, 9.8, topTile, sky, blk);
          } else {
            const E: readonly [number, number, number, number][] = [
              [3.0, 3.0, 4.8, 6.2],
              [9.0, 3.5, 4.0, 5.0],
              [3.5, 9.0, 4.4, 5.6],
              [9.2, 9.2, 3.6, 4.2],
            ];
            for (let ei = 0; ei < count; ei++) {
              const [ex, ez, ew, eh] = E[ei];
              emitBox(x, y, z, ex, 0, ez, ex + ew, eh, ez + ew, sideTile, sky, blk);
              emitBox(x, y, z, ex + 0.6, eh, ez + 0.6, ex + ew - 0.6, eh + 0.9, ez + ew - 0.6, topTile, sky, blk);
            }
          }
        } else if (b.name === 'chorus_plant') {
          const tile = tiles[id][0];
          const cId = ID.chorus_plant, fId = ID.chorus_flower, esId = ID.end_stone;
          const nbD = ly > 0 ? padded[lIdx - STRIDE_Y] & 4095 : 0;
          const nbU = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
          const nbN = padded[lIdx - 18] & 4095;
          const nbS = padded[lIdx + 18] & 4095;
          const nbW = padded[lIdx - 1] & 4095;
          const nbE = padded[lIdx + 1] & 4095;
          const cD = nbD === cId || nbD === esId;
          const cU = nbU === cId || nbU === fId;
          const cN = nbN === cId || nbN === fId;
          const cS = nbS === cId || nbS === fId;
          const cW = nbW === cId || nbW === fId;
          const cE = nbE === cId || nbE === fId;
          const deg = (cD ? 1 : 0) + (cU ? 1 : 0) + (cN ? 1 : 0) + (cS ? 1 : 0) + (cW ? 1 : 0) + (cE ? 1 : 0);
          emitBox(x, y, z, 4, 4, 4, 12, 12, 12, tile, sky, blk);
          if (deg >= 2) emitBox(x, y, z, 3.3, 3.3, 3.3, 12.7, 12.7, 12.7, tile, sky, blk);
          if (cD || deg === 0) {
            emitBox(x, y, z, 4, 0, 4, 12, 4, 12, tile, sky, blk);
            emitBox(x, y, z, 3.6, 1, 3.6, 12.4, 2.6, 12.4, tile, sky, blk);
          }
          if (cU) {
            emitBox(x, y, z, 4, 12, 4, 12, 16, 12, tile, sky, blk);
            emitBox(x, y, z, 3.6, 13.4, 3.6, 12.4, 15, 12.4, tile, sky, blk);
          }
          if (cN) {
            emitBox(x, y, z, 4, 4, 0, 12, 12, 4, tile, sky, blk);
            emitBox(x, y, z, 3.6, 3.6, 1, 12.4, 12.4, 2.6, tile, sky, blk);
          }
          if (cS) {
            emitBox(x, y, z, 4, 4, 12, 12, 12, 16, tile, sky, blk);
            emitBox(x, y, z, 3.6, 3.6, 13.4, 12.4, 12.4, 15, tile, sky, blk);
          }
          if (cW) {
            emitBox(x, y, z, 0, 4, 4, 4, 12, 12, tile, sky, blk);
            emitBox(x, y, z, 1, 3.6, 3.6, 2.6, 12.4, 12.4, tile, sky, blk);
          }
          if (cE) {
            emitBox(x, y, z, 12, 4, 4, 16, 12, 12, tile, sky, blk);
            emitBox(x, y, z, 13.4, 3.6, 3.6, 15, 12.4, 12.4, tile, sky, blk);
          }
        } else if (b.name === 'chorus_flower') {
          const dead = state >= 5;
          const sideTile = dead ? (tiles[id][6] ?? tiles[id][0]) : tiles[id][0];
          const topTile = dead ? (tiles[id][7] ?? tiles[id][2]) : tiles[id][2];
          const stemTile = tiles[ID.chorus_plant]?.[0] ?? sideTile;
          emitBox(x, y, z, 4, 0, 4, 12, 2, 12, stemTile, sky, blk);
          emitBox(x, y, z, 2.5, 1.2, 2.5, 13.5, 3, 13.5, stemTile, sky, blk);
          emitBox(x, y, z, 2, 2, 2, 14, 14, 14, sideTile, sky, blk);
          emitBox(x, y, z, 2, 14, 2, 14, 15.8, 14, topTile, sky, blk);
          emitBox(x, y, z, 5, 15.8, 5, 11, 16.5, 11, topTile, sky, dead ? blk : Math.max(blk, 0.55));
          emitBox(x, y, z, 0, 2, 2, 2, 14, 14, sideTile, sky, blk);
          emitBox(x, y, z, 14, 2, 2, 16, 14, 14, sideTile, sky, blk);
          emitBox(x, y, z, 2, 2, 0, 14, 14, 2, sideTile, sky, blk);
          emitBox(x, y, z, 2, 2, 14, 14, 14, 16, sideTile, sky, blk);
        } else if (b.shape === 'shulker_box') {
          const bt = tiles[id];
          const coreTile = bt[6] ?? tiles[ID.end_stone]?.[0] ?? bt[0];
          emitBoxFaces(x, y, z, 0, 0, 0, 16, 5.5, 16, bt, b, state, sky, blk);
          emitBox(x, y, z, 1.2, 4, 1.2, 14.8, 12, 14.8, coreTile, sky, blk);
          emitBoxFaces(x, y, z, 0, 7.2, 0, 16, 16, 16, bt, b, state, sky, blk);
          emitBox(x, y, z, 3, 16, 3, 13, 16.35, 13, bt[2], sky, blk);
          emitBoxFaces(x, y, z, 0, 5.2, 0, 3.8, 7.2, 3.8, bt, b, state, sky, blk);
          emitBoxFaces(x, y, z, 12.2, 5.2, 0, 16, 7.2, 3.8, bt, b, state, sky, blk);
          emitBoxFaces(x, y, z, 0, 5.2, 12.2, 3.8, 7.2, 16, bt, b, state, sky, blk);
          emitBoxFaces(x, y, z, 12.2, 5.2, 12.2, 16, 7.2, 16, bt, b, state, sky, blk);
          emitBoxFaces(x, y, z, 6, 5.6, 0, 10, 7.2, 1.8, bt, b, state, sky, blk);
          emitBoxFaces(x, y, z, 6, 5.6, 14.2, 10, 7.2, 16, bt, b, state, sky, blk);
          emitBoxFaces(x, y, z, 0, 5.6, 6, 1.8, 7.2, 10, bt, b, state, sky, blk);
          emitBoxFaces(x, y, z, 14.2, 5.6, 6, 16, 7.2, 10, bt, b, state, sky, blk);
        } else if (b.shape === 'dragon_head') {
          const bt = tiles[id];
          const headTile = bt[0];
          const topTile = bt[2] ?? headTile;
          const frontTile = bt[4] ?? headTile;
          const hornTile = bt[6] ?? tiles[ID.end_stone]?.[0] ?? headTile;
          const mouthTile = bt[7] ?? headTile;
          let facing = state & 3;
          if (facing === 0 && (padded[lIdx + 18] & 4095) !== 0 && (padded[lIdx - 18] & 4095) === 0) {
            facing = 2;
          }
          emitRotBox(x, y, z, facing, 4, 0, 3, 12, 7.8, 10.8, headTile, sky, blk);
          emitRotBox(x, y, z, facing, 4.2, 7.8, 3.2, 11.8, 8.2, 10.8, topTile, sky, blk);
          emitRotBox(x, y, z, facing, 7.2, 8.2, 4.5, 8.8, 9.0, 9.5, hornTile, sky, blk);
          emitRotBox(x, y, z, facing, 4.1, 1.5, 10.6, 11.9, 7.6, 11.1, frontTile, sky, Math.max(blk, 0.85));
          emitRotBox(x, y, z, facing, 3.8, 5.6, 9.8, 7.0, 6.8, 11.5, hornTile, sky, blk);
          emitRotBox(x, y, z, facing, 9.0, 5.6, 9.8, 12.2, 6.8, 11.5, hornTile, sky, blk);
          emitRotBox(x, y, z, facing, 5, 2.1, 11, 11, 5.1, 16, headTile, sky, blk);
          emitRotBox(x, y, z, facing, 7.1, 5.1, 11.2, 8.9, 5.5, 14.5, topTile, sky, blk);
          emitRotBox(x, y, z, facing, 5.3, 5.1, 13.4, 6.9, 6.2, 15.2, headTile, sky, blk);
          emitRotBox(x, y, z, facing, 9.1, 5.1, 13.4, 10.7, 6.2, 15.2, headTile, sky, blk);
          emitRotBox(x, y, z, facing, 5.3, 1.3, 11, 10.7, 2.2, 15.3, mouthTile, sky, blk);
          emitRotBox(x, y, z, facing, 5, 0, 11, 11, 1.4, 15.7, headTile, sky, blk);
          emitRotBox(x, y, z, facing, 4.8, 7.2, 2.2, 6.7, 9.8, 6.8, hornTile, sky, blk);
          emitRotBox(x, y, z, facing, 9.3, 7.2, 2.2, 11.2, 9.8, 6.8, hornTile, sky, blk);
          emitRotBox(x, y, z, facing, 5.0, 8.6, 0, 6.5, 11.2, 3.5, hornTile, sky, blk);
          emitRotBox(x, y, z, facing, 9.5, 8.6, 0, 11.0, 11.2, 3.5, hornTile, sky, blk);
          emitRotBox(x, y, z, facing, 3.2, 5.5, 4.2, 4.2, 8.0, 7.6, headTile, sky, blk);
          emitRotBox(x, y, z, facing, 11.8, 5.5, 4.2, 12.8, 8.0, 7.6, headTile, sky, blk);
        } else if (b.name.endsWith('_coral')) {
          const tile = tiles[id][0];
          const baseBlockId = ID[b.name + '_block'];
          const baseTile = baseBlockId !== undefined ? tiles[baseBlockId][0] : tile;
          emitBox(x, y, z, 5.5, 0, 5.5, 10.5, 1.8, 10.5, baseTile, sky, blk);
          const xA = x + 0.14, xB = x + 0.86, zA = z + 0.14, zB = z + 0.86, yT = y + 0.82;
          out.pushQuad(xA, y, zA, xB, y, zB, xB, yT, zB, xA, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.45, false, 1, 1, 1, false, false);
          out.pushQuad(xB, y, zB, xA, y, zA, xA, yT, zA, xB, yT, zB, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.45, false, 1, 1, 1, false, false);
          out.pushQuad(xB, y, zA, xA, y, zB, xA, yT, zB, xB, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.45, false, 1, 1, 1, false, false);
          out.pushQuad(xA, y, zB, xB, y, zA, xB, yT, zA, xA, yT, zB, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.45, false, 1, 1, 1, false, false);
          const yB = y + 0.08, yF = y + 0.48;
          out.pushQuad(x + 0.18, yB, z + 0.35, x + 0.82, yB, z + 0.35, x + 0.94, yF, z + 0.04, x + 0.06, yF, z + 0.04, 0, 0.8, 0.6, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.45, false, 1, 1, 1, false, false);
          out.pushQuad(x + 0.82, yB, z + 0.65, x + 0.18, yB, z + 0.65, x + 0.06, yF, z + 0.96, x + 0.94, yF, z + 0.96, 0, 0.8, 0.6, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.45, false, 1, 1, 1, false, false);
          out.pushQuad(x + 0.35, yB, z + 0.82, x + 0.35, yB, z + 0.18, x + 0.04, yF, z + 0.06, x + 0.04, yF, z + 0.94, 0.6, 0.8, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.45, false, 1, 1, 1, false, false);
          out.pushQuad(x + 0.65, yB, z + 0.18, x + 0.65, yB, z + 0.82, x + 0.96, yF, z + 0.94, x + 0.96, yF, z + 0.06, 0.6, 0.8, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.45, false, 1, 1, 1, false, false);
        } else if (b.name === 'kelp' || b.name === 'seagrass') {
          const aboveId = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
          const isKelp = b.name === 'kelp';
          const isTopKelp = isKelp && aboveId !== ID.kelp;
          const tile = isTopKelp ? (tiles[id][6] ?? tiles[id][0]) : tiles[id][0];
          const yT = isKelp ? (isTopKelp ? y + 0.94 : y + 1.0) : y + 0.88;
          const xA = x + 0.15, xB = x + 0.85, zA = z + 0.15, zB = z + 0.85;
          out.pushQuad(xA, y, zA, xB, y, zB, xB, yT, zB, xA, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.8, false, 1, 1, 1, false, false);
          out.pushQuad(xB, y, zB, xA, y, zA, xA, yT, zA, xB, yT, zB, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.8, false, 1, 1, 1, false, false);
          out.pushQuad(xB, y, zA, xA, y, zB, xA, yT, zB, xB, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.8, false, 1, 1, 1, false, false);
          out.pushQuad(xA, y, zB, xB, y, zA, xB, yT, zA, xA, yT, zB, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.8, false, 1, 1, 1, false, false);
          if (isKelp) {
            const stemTile = tiles[id][7] ?? tile;
            emitBox(x, y, z, 7.2, 0, 7.2, 8.8, isTopKelp ? 13 : 16, 8.8, stemTile, sky, blk);
            emitBox(x, y, z, 6.2, 4.5, 6.8, 9.8, 6.5, 9.2, stemTile, sky, blk);
            emitBox(x, y, z, 6.8, 10.5, 6.2, 9.2, 12.5, 9.8, stemTile, sky, blk);
          } else {
            const yS = y + 0.72;
            out.pushQuad(x + 0.12, y, z + 0.32, x + 0.88, y, z + 0.32, x + 0.88, yS, z + 0.24, x + 0.12, yS, z + 0.24, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.85, false, 1, 1, 1, false, false);
            out.pushQuad(x + 0.88, y, z + 0.68, x + 0.12, y, z + 0.68, x + 0.12, yS, z + 0.76, x + 0.88, yS, z + 0.76, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.85, false, 1, 1, 1, false, false);
          }
        } else if (b.name === 'bamboo') {
          const bamTile = tiles[ID.lime_terracotta]?.[0] ?? tiles[ID.emerald_block]?.[0] ?? tiles[id][0];
          const nodeTile = tiles[ID.green_terracotta]?.[0] ?? bamTile;
          const leafTile = tiles[id][0];
          emitBox(x, y, z, 6.5, 0, 6.5, 9.5, 16, 9.5, bamTile, sky, blk, undefined, false, -1, 0, 0, 0.56, 0.86, 0.32);
          for (const ny of [3, 8, 13]) {
            emitBox(x, y, z, 6.1, ny, 6.1, 9.9, ny + 0.9, 9.9, nodeTile, sky, blk, undefined, false, -1, 0, 0, 0.42, 0.68, 0.22);
          }
          emitBox(x, y, z, 3.0, 4.5, 7.2, 6.5, 5.3, 8.8, bamTile, sky, blk, undefined, false, -1, 0, 0, 0.50, 0.82, 0.28);
          emitBox(x, y, z, 9.5, 9.5, 7.2, 13.0, 10.3, 8.8, bamTile, sky, blk, undefined, false, -1, 0, 0, 0.50, 0.82, 0.28);
          emitBox(x, y, z, 7.2, 12.5, 3.0, 8.8, 13.3, 6.5, bamTile, sky, blk, undefined, false, -1, 0, 0, 0.50, 0.82, 0.28);
          const xA = x + 0.18, xB = x + 0.82, zA = z + 0.18, zB = z + 0.82;
          out.pushQuad(xA, y, zA, xB, y, zB, xB, y + 1, zB, xA, y + 1, zA, 0, 1, 0, 1, 1, leafTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.4, false, 1, 1, 1, false, false);
          out.pushQuad(xB, y, zB, xA, y, zA, xA, y + 1, zA, xB, y + 1, zB, 0, 1, 0, 1, 1, leafTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.4, false, 1, 1, 1, false, false);
        } else if (b.name === 'azalea' || b.name === 'flowering_azalea') {
          const woodTile = tiles[ID.oak_log]?.[0] ?? tiles[id][0];
          const leafTile = tiles[b.name === 'flowering_azalea' ? ID.flowering_azalea_leaves : ID.azalea_leaves]?.[0] ?? tiles[id][0];
          const flowerTile = tiles[ID.pink_wool]?.[0] ?? leafTile;
          emitBox(x, y, z, 6, 0, 6, 10, 8, 10, woodTile, sky, blk);
          emitBox(x, y, z, 4.5, 3, 7, 6, 6, 9, woodTile, sky, blk);
          emitBox(x, y, z, 10, 4, 7, 11.5, 7, 9, woodTile, sky, blk);
          emitBox(x, y, z, 1, 6, 1, 15, 15, 15, leafTile, sky, blk);
          emitBox(x, y, z, 0, 7, 2, 16, 14, 14, leafTile, sky, blk);
          emitBox(x, y, z, 2, 7, 0, 14, 14, 16, leafTile, sky, blk);
          emitBox(x, y, z, 2, 15, 2, 14, 16, 14, leafTile, sky, blk);
          if (b.name === 'flowering_azalea') {
            emitBox(x, y, z, 3, 15.2, 4, 6, 16.4, 7, flowerTile, sky, blk);
            emitBox(x, y, z, 10, 15.2, 9, 13, 16.4, 12, flowerTile, sky, blk);
            emitBox(x, y, z, 0.2, 10, 4, 1.2, 12.5, 7, flowerTile, sky, blk);
            emitBox(x, y, z, 14.8, 9, 9, 15.8, 11.5, 12, flowerTile, sky, blk);
            emitBox(x, y, z, 5, 10, 14.8, 8, 12.5, 15.8, flowerTile, sky, blk);
          }
        } else if (b.name === 'big_dripleaf' || b.name === 'small_dripleaf') {
          const stemTile = tiles[ID.emerald_block]?.[0] ?? tiles[id][0];
          const leafTile = tiles[ID.moss_block]?.[0] ?? stemTile;
          if (b.name === 'big_dripleaf') {
            emitBox(x, y, z, 6.5, 0, 10, 9.5, 14, 13, stemTile, sky, blk, undefined, false, -1, 0, 0, 0.42, 0.72, 0.26);
            emitBox(x, y, z, 1, 13.5, 1, 15, 15, 15, leafTile, sky, blk, undefined, false, -1, 0, 0, 0.56, 0.88, 0.34);
            emitBox(x, y, z, 2, 11.5, 0.5, 14, 13.5, 2, leafTile, sky, blk, undefined, false, -1, 0, 0, 0.50, 0.80, 0.30);
          } else {
            emitBox(x, y, z, 7, 0, 7, 9, 13, 9, stemTile, sky, blk, undefined, false, -1, 0, 0, 0.42, 0.72, 0.26);
            emitBox(x, y, z, 3, 6, 3, 8, 7.2, 8, leafTile, sky, blk, undefined, false, -1, 0, 0, 0.56, 0.88, 0.34);
            emitBox(x, y, z, 8, 10, 8, 13, 11.2, 13, leafTile, sky, blk, undefined, false, -1, 0, 0, 0.56, 0.88, 0.34);
          }
        } else if (b.name === 'spore_blossom') {
          const calyxTile = tiles[ID.moss_block]?.[0] ?? tiles[id][0];
          const petalTile = tiles[ID.pink_wool]?.[0] ?? tiles[id][0];
          const stamenTile = tiles[ID.gold_block]?.[0] ?? tiles[id][0];
          emitBox(x, y, z, 4, 14, 4, 12, 16, 12, calyxTile, sky, blk);
          emitBox(x, y, z, 2, 11.5, 2, 14, 14, 14, petalTile, sky, blk);
          emitBox(x, y, z, 1, 10, 3, 15, 12, 13, petalTile, sky, blk, undefined, false, -1, 0, 0, 0.96, 0.68, 0.84);
          emitBox(x, y, z, 3, 10, 1, 13, 12, 15, petalTile, sky, blk, undefined, false, -1, 0, 0, 0.96, 0.68, 0.84);
          emitBox(x, y, z, 5.5, 8.5, 5.5, 10.5, 11, 10.5, stamenTile, sky, blk);
          emitBox(x, y, z, 6.2, 5.5, 6.2, 7.4, 9.0, 7.4, stamenTile, sky, blk);
          emitBox(x, y, z, 8.6, 5.0, 8.6, 9.8, 9.0, 9.8, stamenTile, sky, blk);
          emitBox(x, y, z, 8.6, 6.0, 6.2, 9.8, 9.0, 7.4, stamenTile, sky, blk);
        } else if (b.name === 'pointed_dripstone') {
          const dripTile = tiles[ID.dripstone_block]?.[0] ?? tiles[id][0];
          const tile = tiles[id][0];
          const aboveId = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
          const belowId = ly > 0 ? padded[lIdx - STRIDE_Y] & 4095 : 0;
          const hanging = aboveId !== 0 && (belowId === 0 || aboveId === id);
          if (hanging) {
            emitBox(x, y, z, 4.0, 12, 4.0, 12.0, 16, 12.0, dripTile, sky, blk);
            emitBox(x, y, z, 5.2, 8, 5.2, 10.8, 12, 10.8, dripTile, sky, blk);
            emitBox(x, y, z, 6.2, 4, 6.2, 9.8, 8, 9.8, dripTile, sky, blk);
            emitBox(x, y, z, 7.1, 0, 7.1, 8.9, 4, 8.9, dripTile, sky, blk);
          } else {
            emitBox(x, y, z, 4.0, 0, 4.0, 12.0, 4, 12.0, dripTile, sky, blk);
            emitBox(x, y, z, 5.2, 4, 5.2, 10.8, 8, 10.8, dripTile, sky, blk);
            emitBox(x, y, z, 6.2, 8, 6.2, 9.8, 12, 9.8, dripTile, sky, blk);
            emitBox(x, y, z, 7.1, 12, 7.1, 8.9, 16, 8.9, dripTile, sky, blk);
          }
          void tile;
        } else if (b.name === 'amethyst_cluster' || b.name.endsWith('_amethyst_bud')) {
          const amTile = tiles[ID.amethyst_block]?.[0] ?? tiles[id][0];
          const stage = b.name === 'small_amethyst_bud' ? 0 : b.name === 'medium_amethyst_bud' ? 1 : b.name === 'large_amethyst_bud' ? 2 : 3;
          const hScale = [0.38, 0.56, 0.78, 1.0][stage];
          emitBox(x, y, z, 3, 0, 3, 13, Math.max(2, 3 * hScale), 13, amTile, sky, 1, undefined, false, -1, 0, 0, 0.72, 0.50, 0.92);
          emitBox(x, y, z, 6, 0, 6, 10, 15 * hScale, 10, amTile, sky, 1, undefined, false, -1, 0, 0, 0.94, 0.78, 1.0);
          emitBox(x, y, z, 3.5, 0, 5.5, 6.5, 11 * hScale, 8.5, amTile, sky, 1, undefined, false, -1, 0, 0, 0.84, 0.62, 0.98);
          emitBox(x, y, z, 9.5, 0, 7.5, 12.5, 12 * hScale, 10.5, amTile, sky, 1, undefined, false, -1, 0, 0, 0.86, 0.66, 0.98);
          if (stage >= 2) {
            emitBox(x, y, z, 5.5, 0, 9.5, 8.5, 10 * hScale, 12.5, amTile, sky, 1, undefined, false, -1, 0, 0, 0.78, 0.56, 0.95);
            emitBox(x, y, z, 7.5, 0, 3.5, 10.5, 9.5 * hScale, 6.5, amTile, sky, 1, undefined, false, -1, 0, 0, 0.90, 0.72, 1.0);
          }
        } else if (b.name === 'cocoa') {
          const podTile = tiles[ID.orange_terracotta]?.[0] ?? tiles[id][0];
          const stemTile = tiles[ID.oak_log]?.[0] ?? podTile;
          emitBox(x, y, z, 5, 4, 5, 11, 11, 11, podTile, sky, blk);
          emitBox(x, y, z, 7.3, 11, 7.3, 8.7, 15, 8.7, stemTile, sky, blk);
        } else if (b.name === 'vine') {
          const tile = tiles[id][0];
          const cn = isOpq(padded[lIdx - 18]), cs = isOpq(padded[lIdx + 18]), cw = isOpq(padded[lIdx - 1]), ce = isOpq(padded[lIdx + 1]);
          if (cn) {
            out.pushQuad(x, y, z + 0.05, x + 1, y, z + 0.05, x + 1, y + 1, z + 0.05, x, y + 1, z + 0.05, 0, 0, 1, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.25, false, r, g, bl, false, false);
            out.pushQuad(x + 1, y, z + 0.05, x, y, z + 0.05, x, y + 1, z + 0.05, x + 1, y + 1, z + 0.05, 0, 0, -1, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.25, false, r, g, bl, false, false);
          }
          if (cs) {
            out.pushQuad(x + 1, y, z + 0.95, x, y, z + 0.95, x, y + 1, z + 0.95, x + 1, y + 1, z + 0.95, 0, 0, -1, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.25, false, r, g, bl, false, false);
            out.pushQuad(x, y, z + 0.95, x + 1, y, z + 0.95, x + 1, y + 1, z + 0.95, x, y + 1, z + 0.95, 0, 0, 1, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.25, false, r, g, bl, false, false);
          }
          if (cw) {
            out.pushQuad(x + 0.05, y, z + 1, x + 0.05, y, z, x + 0.05, y + 1, z, x + 0.05, y + 1, z + 1, 1, 0, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.25, false, r, g, bl, false, false);
            out.pushQuad(x + 0.05, y, z, x + 0.05, y, z + 1, x + 0.05, y + 1, z + 1, x + 0.05, y + 1, z, -1, 0, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.25, false, r, g, bl, false, false);
          }
          if (ce) {
            out.pushQuad(x + 0.95, y, z, x + 0.95, y, z + 1, x + 0.95, y + 1, z + 1, x + 0.95, y + 1, z, -1, 0, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.25, false, r, g, bl, false, false);
            out.pushQuad(x + 0.95, y, z + 1, x + 0.95, y, z, x + 0.95, y + 1, z, x + 0.95, y + 1, z + 1, 1, 0, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.25, false, r, g, bl, false, false);
          }
          if (!cn && !cs && !cw && !ce) {
            const xA = x + 0.15, xB = x + 0.85, zA = z + 0.15, zB = z + 0.85, yT = y + 1.0;
            out.pushQuad(xA, y, zA, xB, y, zB, xB, yT, zB, xA, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.35, false, r, g, bl, false, false);
            out.pushQuad(xB, y, zB, xA, y, zA, xA, yT, zA, xB, yT, zB, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.35, false, r, g, bl, false, false);
            out.pushQuad(xB, y, zA, xA, y, zB, xA, yT, zB, xB, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.35, false, r, g, bl, false, false);
            out.pushQuad(xA, y, zB, xB, y, zA, xB, yT, zA, xA, yT, zB, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
          }
        } else if (b.shape === 'cross') {
          const tile = tiles[id][0];
          const crop = LUT_CROP[id] === 1;
          const maxSt = b.name === 'beetroots' || b.name === 'nether_wart' ? 3 : 7;
          const progress = crop ? Math.min(1, (state & 7) / maxSt) : 1;
          if (crop && progress < 1 && b.name !== 'nether_wart') { r = 0.55 + progress * 0.35; g = 1; bl = 0.65; }
          const grow = crop ? 0.25 + 0.75 * progress : 1;
          const yT = y + 0.82 * grow;
          if (crop && b.name !== 'melon_stem' && b.name !== 'pumpkin_stem') {
            for (const cPos of [0.25, 0.75]) {
              const xz = z + cPos;
              out.pushQuad(x + 0.08, y, xz, x + 0.92, y, xz, x + 0.92, yT, xz, x + 0.08, yT, xz, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.5, false, r, g, bl, false, false);
              out.pushQuad(x + 0.92, y, xz, x + 0.08, y, xz, x + 0.08, yT, xz, x + 0.92, yT, xz, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.5, false, r, g, bl, false, false);
              const xx = x + cPos;
              out.pushQuad(xx, y, z + 0.08, xx, y, z + 0.92, xx, yT, z + 0.92, xx, yT, z + 0.08, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.5, false, r, g, bl, false, false);
              out.pushQuad(xx, y, z + 0.92, xx, y, z + 0.08, xx, yT, z + 0.08, xx, yT, z + 0.92, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.5, false, r, g, bl, false, false);
            }
          } else {
            // Vanilla cross.json (~0.15..0.85 diagonal span) + subtle Java-style XZ offset for foliage
            const h = ((x * 374761393 + z * 668265263) ^ 0x5bf03635) | 0;
            const jx = crop ? 0 : (((h & 15) / 15) - 0.5) * 0.16;
            const jz = crop ? 0 : ((((h >>> 4) & 15) / 15) - 0.5) * 0.16;
            const yCrossT = y + (crop ? 0.82 * grow : 0.90);
            const xA = x + 0.15 + jx, xB = x + 0.85 + jx, zA = z + 0.15 + jz, zB = z + 0.85 + jz;
            out.pushQuad(xA, y, zA, xB, y, zB, xB, yCrossT, zB, xA, yCrossT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
            out.pushQuad(xB, y, zB, xA, y, zA, xA, yCrossT, zA, xB, yCrossT, zB, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
            out.pushQuad(xB, y, zA, xA, y, zB, xA, yCrossT, zB, xB, yCrossT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
            out.pushQuad(xA, y, zB, xB, y, zA, xB, yCrossT, zA, xA, yCrossT, zB, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
          }
        } else if (b.shape === 'lily') {
          const tile = tiles[id][0];
          const lyY = y + 0.015625;
          out.pushQuad(x + 0.0625, lyY, z + 0.9375, x + 0.9375, lyY, z + 0.9375, x + 0.9375, lyY, z + 0.0625, x + 0.0625, lyY, z + 0.0625, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
          out.pushQuad(x + 0.0625, lyY, z + 0.0625, x + 0.9375, lyY, z + 0.0625, x + 0.9375, lyY, z + 0.9375, x + 0.0625, lyY, z + 0.9375, 0, -1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
        } else if (b.shape === 'cactus') {
          const ts = tiles[id][0], e = 0.0625;
          const below = ly > 0 ? padded[lIdx - STRIDE_Y] & 4095 : 0, above = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
          out.pushQuad(x, y, z + 1 - e, x + 1, y, z + 1 - e, x + 1, y + 1, z + 1 - e, x, y + 1, z + 1 - e, 0, 0, 1, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          out.pushQuad(x + 1, y, z + e, x, y, z + e, x, y + 1, z + e, x + 1, y + 1, z + e, 0, 0, -1, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          out.pushQuad(x + 1 - e, y, z + 1, x + 1 - e, y, z, x + 1 - e, y + 1, z, x + 1 - e, y + 1, z + 1, 1, 0, 0, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          out.pushQuad(x + e, y, z, x + e, y, z + 1, x + e, y + 1, z + 1, x + e, y + 1, z, -1, 0, 0, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          if (above !== id) { out.pushQuad(x, y + 1, z + 1, x + 1, y + 1, z + 1, x + 1, y + 1, z, x, y + 1, z, 0, 1, 0, 1, 1, tiles[id][2], 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1); }
          if (below !== id) { out.pushQuad(x, y, z, x + 1, y, z, x + 1, y, z + 1, x, y, z + 1, 0, -1, 0, 1, 1, tiles[id][3], 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1); }
        } else if (b.shape === 'door' || (b.name.startsWith('open_') && b.name.endsWith('_door'))) {
          const below = ly > 0 ? padded[lIdx - STRIDE_Y] : 0;
          const upper = (state & 4) !== 0 || ((below & 4095) === id && ((below >>> 12) & 4) === 0);
          const open = (state & 8) !== 0 || b.name.startsWith('open_'), f = state & 3, e = open ? (f + 3) & 3 : f;
          const flip = open ? f >= 2 : f === 0 || f === 3;
          const x0 = e === 3 ? 13 : 0, x1 = e === 1 ? 3 : 16, z0 = e === 2 ? 13 : 0, z1 = e === 0 ? 3 : 16;
          DT[0] = flip ? 16 - x0 : x0; DT[3] = flip ? 16 - x1 : x1; DT[2] = flip ? 16 - z0 : z0; DT[5] = flip ? 16 - z1 : z1;
          const doorTile = upper ? tiles[id][2] : tiles[id][0];
          emitBox(x, y, z, x0, 0, z0, x1, 16, z1, doorTile, sky, blk, DT, true);
          const cleanName = b.name.replace(/^open_/, '');
          const woodKey = cleanName.replace(/_door$/, '');
          if (e === 0 || e === 2) {
            emitBox(x, y, z, x0, 0, z0 + 0.8, x1, 16, z1 - 0.8, doorTile, sky, blk, DT, true);
          } else {
            emitBox(x, y, z, x0 + 0.8, 0, z0, x1 - 0.8, 16, z1, doorTile, sky, blk, DT, true);
          }
          const handleTile =
            cleanName === 'iron_door' ? (tiles[ID.iron_block]?.[0] ?? doorTile) :
            (woodKey === 'spruce' || woodKey === 'acacia') ? (tiles[ID.anvil]?.[0] ?? doorTile) :
            woodKey === 'cherry' ? (tiles[ID.copper_block]?.[0] ?? doorTile) :
            (tiles[ID.gold_block]?.[0] ?? doorTile);
          if (!upper) {
            if (e === 0 || e === 2) {
              const hx0 = flip ? 2 : 12, hx1 = hx0 + 2;
              const hz0 = e === 2 ? 12.2 : -0.4, hz1 = e === 2 ? 16.4 : 3.8;
              emitBox(x, y, z, hx0, 13.5, hz0, hx1, 15.2, hz1, handleTile, sky, blk);
            } else {
              const hz0 = flip ? 2 : 12, hz1 = hz0 + 2;
              const hx0 = e === 3 ? 12.2 : -0.4, hx1 = e === 3 ? 16.4 : 3.8;
              emitBox(x, y, z, hx0, 13.5, hz0, hx1, 15.2, hz1, handleTile, sky, blk);
            }
          }
        } else if (b.shape === 'fence') {
          const tile = tiles[id][0], wall = b.name.endsWith('_wall');
          if (b.name.endsWith('_fence_gate')) {
            const alongX = (state & 1) === 1, open = (state & 4) !== 0;
            if (alongX) {
              emitBox(x, y, z, 6, 5, 0, 10, 16, 2, tile, sky, blk);
              emitBox(x, y, z, 6, 5, 14, 10, 16, 16, tile, sky, blk);
              if (open) { emitBox(x, y, z, 6, 6, 2, 16, 15, 4, tile, sky, blk); emitBox(x, y, z, 6, 6, 12, 16, 15, 14, tile, sky, blk); }
              else { emitBox(x, y, z, 6, 6, 2, 10, 9, 14, tile, sky, blk); emitBox(x, y, z, 6, 12, 2, 10, 15, 14, tile, sky, blk); emitBox(x, y, z, 6, 6, 6, 10, 15, 10, tile, sky, blk); }
            } else {
              emitBox(x, y, z, 0, 5, 6, 2, 16, 10, tile, sky, blk);
              emitBox(x, y, z, 14, 5, 6, 16, 16, 10, tile, sky, blk);
              if (open) { emitBox(x, y, z, 2, 6, 6, 4, 15, 16, tile, sky, blk); emitBox(x, y, z, 12, 6, 6, 14, 15, 16, tile, sky, blk); }
              else { emitBox(x, y, z, 2, 6, 6, 14, 9, 10, tile, sky, blk); emitBox(x, y, z, 2, 12, 6, 14, 15, 10, tile, sky, blk); emitBox(x, y, z, 6, 6, 6, 10, 15, 10, tile, sky, blk); }
            }
            continue;
          }
          const joins = (c: number) => { if (!c) return false; const nb = blocks[c & 4095]; return !!nb && (nb.shape === 'fence' ? nb.name.endsWith('_wall') === wall : isOpq(c)); };
          const cn = joins(padded[lIdx - 18]), cs = joins(padded[lIdx + 18]), cw = joins(padded[lIdx - 1]), ce = joins(padded[lIdx + 1]);
          if (wall) {
            const straightZ = cn && cs && !cw && !ce;
            const straightX = cw && ce && !cn && !cs;
            const aboveId = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
            const needPost = (!straightZ && !straightX) || aboveId !== 0;
            if (needPost) {
              emitBox(x, y, z, 4, 0, 4, 12, 16, 12, tile, sky, blk);
              emitBox(x, y, z, 3.5, 14.5, 3.5, 12.5, 16.2, 12.5, tile, sky, blk);
            }
            if (cn) emitBox(x, y, z, 5, 0, 0, 11, 14, needPost ? 4 : 8, tile, sky, blk);
            if (cs) emitBox(x, y, z, 5, 0, needPost ? 12 : 8, 11, 14, 16, tile, sky, blk);
            if (cw) emitBox(x, y, z, 0, 0, 5, needPost ? 4 : 8, 14, 11, tile, sky, blk);
            if (ce) emitBox(x, y, z, needPost ? 12 : 8, 0, 5, 16, 14, 11, tile, sky, blk);
          } else {
            emitBox(x, y, z, 6, 0, 6, 10, 16, 10, tile, sky, blk);
            for (let bar = 6; bar <= 12; bar += 6) {
              if (cn) emitBox(x, y, z, 7, bar, 0, 9, bar + 3, 6, tile, sky, blk);
              if (cs) emitBox(x, y, z, 7, bar, 10, 9, bar + 3, 16, tile, sky, blk);
              if (cw) emitBox(x, y, z, 0, bar, 7, 6, bar + 3, 9, tile, sky, blk);
              if (ce) emitBox(x, y, z, 10, bar, 7, 16, bar + 3, 9, tile, sky, blk);
            }
          }
        } else if (b.name === 'bed') {
          const head = (state & 4) !== 0, outer = head ? state & 3 : ((state & 3) + 2) & 3, side = head ? tiles[id][1] : tiles[id][0];
          const oakT = tiles[ID.oak_planks]?.[0] ?? side;
          emitBox(x, y, z, 0, 3, 0, 16, 8.9, 16, side, sky, blk);
          emitBox(x, y, z, 0, 8.9, 0, 16, 9, 16, head ? tiles[id][2] : tiles[id][3], sky, blk);
          if (head) {
            const pillowT = tiles[ID.white_wool]?.[0] ?? tiles[id][2];
            emitBox(x, y, z, 2, 9, 2, 14, 10.2, 14, pillowT, sky, blk);
            if (outer === 0) emitBox(x, y, z, 14, 3, 0, 16, 13, 16, oakT, sky, blk);
            else if (outer === 1) emitBox(x, y, z, 0, 3, 14, 16, 13, 16, oakT, sky, blk);
            else if (outer === 2) emitBox(x, y, z, 0, 3, 0, 2, 13, 16, oakT, sky, blk);
            else emitBox(x, y, z, 0, 3, 0, 16, 13, 2, oakT, sky, blk);
          }
          for (let k = 0; k < 2; k++) {
            const lx = outer === 0 ? 13 : outer === 2 ? 0 : k * 13, lz = outer === 1 ? 13 : outer === 3 ? 0 : k * 13;
            emitBox(x, y, z, lx, 0, lz, lx + 3, 3, lz + 3, oakT, sky, blk);
          }
        } else if (b.name === 'hopper') {
          const hopTile = tiles[ID.anvil]?.[0] ?? tiles[id][0];
          const inTile = tiles[ID.cauldron]?.[0] ?? hopTile;
          emitBox(x, y, z, 0, 10, 0, 16, 16, 2, hopTile, sky, blk);
          emitBox(x, y, z, 0, 10, 14, 16, 16, 16, hopTile, sky, blk);
          emitBox(x, y, z, 0, 10, 2, 2, 16, 14, hopTile, sky, blk);
          emitBox(x, y, z, 14, 10, 2, 16, 16, 14, hopTile, sky, blk);
          emitBox(x, y, z, 2, 10, 2, 14, 11, 14, inTile, sky, blk);
          emitBox(x, y, z, 4, 4, 4, 12, 10, 12, hopTile, sky, blk);
          const dir = state & 7;
          if (dir === 1) emitBox(x, y, z, 0, 4, 6, 4, 8, 10, hopTile, sky, blk);
          else if (dir === 2) emitBox(x, y, z, 12, 4, 6, 16, 8, 10, hopTile, sky, blk);
          else if (dir === 3) emitBox(x, y, z, 6, 4, 0, 10, 8, 4, hopTile, sky, blk);
          else if (dir === 4) emitBox(x, y, z, 6, 4, 12, 10, 8, 16, hopTile, sky, blk);
          else emitBox(x, y, z, 6, 0, 6, 10, 4, 10, hopTile, sky, blk);
        } else if (b.name === 'composter') {
          const woodTile = tiles[id][0];
          const mulchTile = tiles[ID.podzol]?.[2] ?? tiles[ID.dirt]?.[0] ?? woodTile;
          emitBox(x, y, z, 0, 0, 0, 16, 16, 2, woodTile, sky, blk);
          emitBox(x, y, z, 0, 0, 14, 16, 16, 16, woodTile, sky, blk);
          emitBox(x, y, z, 0, 0, 2, 2, 16, 14, woodTile, sky, blk);
          emitBox(x, y, z, 14, 0, 2, 16, 16, 14, woodTile, sky, blk);
          emitBox(x, y, z, 2, 0, 2, 14, 3.5, 14, mulchTile, sky, blk);
          if (state > 0) {
            const fillH = Math.min(15, 3.5 + Math.min(8, state) * 1.45);
            const fillTile = state >= 8 ? (tiles[ID.bone_block]?.[2] ?? woodTile) : mulchTile;
            emitBox(x, y, z, 2, 3.5, 2, 14, fillH, 14, fillTile, sky, blk);
          }
        } else if (b.name === 'cauldron') {
          const ironTile = tiles[ID.anvil]?.[0] ?? tiles[id][0];
          emitBox(x, y, z, 0, 3, 0, 16, 16, 2, ironTile, sky, blk);
          emitBox(x, y, z, 0, 3, 14, 16, 16, 16, ironTile, sky, blk);
          emitBox(x, y, z, 0, 3, 2, 2, 16, 14, ironTile, sky, blk);
          emitBox(x, y, z, 14, 3, 2, 16, 16, 14, ironTile, sky, blk);
          emitBox(x, y, z, 2, 3, 2, 14, 4, 14, ironTile, sky, blk);
          for (let fi = 0; fi < 4; fi++) {
            const fx = CAULDRON_FEET[fi][0], fz = CAULDRON_FEET[fi][1];
            emitBox(x, y, z, fx, 0, fz, fx + 3, 3, fz + 3, ironTile, sky, blk);
          }
          if (state >= 1 && state <= 3) {
            const liqY = state === 1 ? 7.5 : state === 2 ? 11.0 : 14.5;
            const waterTile = tiles[ID.water]?.[0] ?? ironTile;
            emitBox(x, y, z, 2, 4, 2, 14, liqY - 0.15, 14, waterTile, sky, blk);
            const wy = y + liqY / 16, x0 = x + 2 / 16, x1 = x + 14 / 16, z0 = z + 2 / 16, z1 = z + 14 / 16;
            reusableWater.pushQuad(x0, wy, z0, x0, wy, z1, x1, wy, z1, x1, wy, z0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0.4, 0.4, 0.4, 0.4, 0, false, 1, 1, 1, false, false);
          } else if (state >= 4) {
            const lavaTile = tiles[ID.lava]?.[0] ?? ironTile;
            emitBox(x, y, z, 2, 4, 2, 14, 14.35, 14, lavaTile, sky, 1);
            const wy = y + 14.5 / 16, x0 = x + 2 / 16, x1 = x + 14 / 16, z0 = z + 2 / 16, z1 = z + 14 / 16;
            reusableWater.pushQuad(x0, wy, z0, x0, wy, z1, x1, wy, z1, x1, wy, z0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, false, 1, 1, 1, false, false);
          }
        } else if (b.name === 'repeater' || b.name === 'comparator') {
          const slabTile = tiles[ID.smooth_stone]?.[0] ?? tiles[id][0];
          const topTile = tiles[id][2] ?? slabTile;
          const stickTile = tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          const glowTile = tiles[ID.redstone_block]?.[0] ?? tiles[id][0];
          const bedrockTile = tiles[ID.bedrock]?.[0] ?? slabTile;
          const slotTile = tiles[ID.deepslate]?.[0] ?? slabTile;
          emitBox(x, y, z, 0, 0, 0, 16, 2, 16, slabTile, sky, blk, undefined, false, -1, 0, 0, 1, 1, 1, topTile);
          const dir = state & 3, delay = (state >> 2) & 3;
          const fx0 = dir === 0 ? 12 : dir === 2 ? 2 : 7, fx1 = fx0 + 2;
          const fz0 = dir === 1 ? 12 : dir === 3 ? 2 : 7, fz1 = fz0 + 2;
          emitBox(x, y, z, fx0, 2, fz0, fx1, 5.2, fz1, stickTile, sky, blk);
          emitBox(x, y, z, fx0 - 0.3, 5.0, fz0 - 0.3, fx1 + 0.3, 7.2, fz1 + 0.3, glowTile, sky, 1);
          if (b.name === 'repeater') {
            if (dir === 0 || dir === 2) emitBox(x, y, z, 3, 2, 7.2, 11, 2.3, 8.8, slotTile, sky, blk);
            else emitBox(x, y, z, 7.2, 2, 3, 8.8, 2.3, 11, slotTile, sky, blk);
            const checkSide = (sdx: number, sdz: number, reqDir: number): boolean => {
              const sc = getCellAt(padded, dimsY, x + sdx, ly, z + sdz), sid = sc & 4095, sst = (sc >>> 12) & 15;
              if (sid !== ID.repeater && sid !== ID.comparator) return false;
              if ((sst & 3) !== reqDir) return false;
              const bx = x + sdx * 2, bz = z + sdz * 2, bc = getCellAt(padded, dimsY, bx, ly, bz), bid = bc & 4095, bst = (bc >>> 12) & 15;
              return bid === ID.redstone_block || bid === ID.redstone_torch || (bid === ID.lever && (bst & 8) !== 0) || (bid === ID.repeater) || (bid === ID.redstone_wire && bst > 0);
            };
            const locked = (dir === 0 || dir === 2) ? (checkSide(0, -1, 1) || checkSide(0, 1, 3)) : (checkSide(-1, 0, 0) || checkSide(1, 0, 2));
            const off = 9 - delay * 2;
            if (locked) {
              if (dir === 0 || dir === 2) {
                const bx0 = dir === 0 ? off : 14 - off;
                emitBox(x, y, z, bx0, 2, 2, bx0 + 2, 4.8, 14, bedrockTile, sky, blk);
              } else {
                const bz0 = dir === 1 ? off : 14 - off;
                emitBox(x, y, z, 2, 2, bz0, 14, 4.8, bz0 + 2, bedrockTile, sky, blk);
              }
            } else {
              const rx0 = dir === 0 ? off : dir === 2 ? 14 - off : 7;
              const rz0 = dir === 1 ? off : dir === 3 ? 14 - off : 7;
              emitBox(x, y, z, rx0, 2, rz0, rx0 + 2, 5.2, rz0 + 2, stickTile, sky, blk);
              emitBox(x, y, z, rx0 - 0.3, 5.0, rz0 - 0.3, rx0 + 2.3, 7.2, rz0 + 2.3, glowTile, sky, 1);
            }
          } else {
            if (dir === 0 || dir === 2) {
              const rx = dir === 0 ? 3 : 11;
              emitBox(x, y, z, rx, 2, 3, rx + 2, 5, 5, stickTile, sky, blk);
              emitBox(x, y, z, rx - 0.2, 4.8, 2.8, rx + 2.2, 6.8, 5.2, glowTile, sky, 1);
              emitBox(x, y, z, rx, 2, 11, rx + 2, 5, 13, stickTile, sky, blk);
              emitBox(x, y, z, rx - 0.2, 4.8, 10.8, rx + 2.2, 6.8, 13.2, glowTile, sky, 1);
            } else {
              const rz = dir === 1 ? 3 : 11;
              emitBox(x, y, z, 3, 2, rz, 5, 5, rz + 2, stickTile, sky, blk);
              emitBox(x, y, z, 2.8, 4.8, rz - 0.2, 5.2, 6.8, rz + 2.2, glowTile, sky, 1);
              emitBox(x, y, z, 11, 2, rz, 13, 5, rz + 2, stickTile, sky, blk);
              emitBox(x, y, z, 10.8, 4.8, rz - 0.2, 13.2, 6.8, rz + 2.2, glowTile, sky, 1);
            }
          }
        } else if (b.name === 'mangrove_roots') {
          const sideT = tiles[id][0], topT = tiles[id][2];
          out.pushQuad(x, y, z + 1, x + 1, y, z + 1, x + 1, y + 1, z + 1, x, y + 1, z + 1, 0, 0, 1, 1, 1, sideT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x + 1, y, z, x, y, z, x, y + 1, z, x + 1, y + 1, z, 0, 0, -1, 1, 1, sideT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x + 1, y, z + 1, x + 1, y, z, x + 1, y + 1, z, x + 1, y + 1, z + 1, 1, 0, 0, 1, 1, sideT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x, y, z, x, y, z + 1, x, y + 1, z + 1, x, y + 1, z, -1, 0, 0, 1, 1, sideT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x, y + 1, z + 1, x + 1, y + 1, z + 1, x + 1, y + 1, z, x, y + 1, z, 0, 1, 0, 1, 1, topT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x, y, z, x + 1, y, z, x + 1, y, z + 1, x, y, z + 1, 0, -1, 0, 1, 1, topT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          for (const off of [0.3125, 0.6875]) {
            out.pushQuad(x, y, z + off, x + 1, y, z + off, x + 1, y + 1, z + off, x, y + 1, z + off, 0, 0, 1, 1, 1, sideT, 1, 1, 1, 1, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 0.88, 0.88, 0.88, false, false);
            out.pushQuad(x + 1, y, z + off, x, y, z + off, x, y + 1, z + off, x + 1, y + 1, z + off, 0, 0, -1, 1, 1, sideT, 1, 1, 1, 1, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 0.88, 0.88, 0.88, false, false);
            out.pushQuad(x + off, y, z + 1, x + off, y, z, x + off, y + 1, z, x + off, y + 1, z + 1, 1, 0, 0, 1, 1, sideT, 1, 1, 1, 1, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 0.85, 0.85, 0.85, false, false);
            out.pushQuad(x + off, y, z, x + off, y, z + 1, x + off, y + 1, z + 1, x + off, y + 1, z, -1, 0, 0, 1, 1, sideT, 1, 1, 1, 1, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 0.85, 0.85, 0.85, false, false);
          }
        } else if (b.name === 'decorated_pot') {
          const potTile = tiles[id][0];
          const darkTile = tiles[ID.brown_terracotta]?.[0] ?? potTile;
          emitBox(x, y, z, 2.5, 0, 2.5, 13.5, 1.2, 13.5, darkTile, sky, blk);
          emitBox(x, y, z, 1, 1.2, 1, 15, 13.5, 15, potTile, sky, blk, FULL_UV);
          emitBox(x, y, z, 4.5, 13.5, 4.5, 11.5, 14.8, 11.5, darkTile, sky, blk);
          emitBox(x, y, z, 3, 14.8, 3, 13, 16, 13, potTile, sky, blk);
        } else if (b.name === 'frosted_ice' || b.name === 'suspicious_sand' || b.name === 'suspicious_gravel') {
          const stTile = tiles[id]?.[6 + (state & 3)] ?? tiles[id][0];
          emitBox(x, y, z, 0, 0, 0, 16, 16, 16, stTile, sky, blk);
        } else if (b.name === 'stonecutter') {
          const stoneTile = tiles[ID.smooth_stone]?.[0] ?? tiles[id][0];
          const topTile = tiles[ID.stone_bricks]?.[0] ?? stoneTile;
          const sawTile = tiles[ID.iron_block]?.[0] ?? tiles[id][0];
          const darkTile = tiles[ID.deepslate]?.[0] ?? stoneTile;
          emitBox(x, y, z, 0, 0, 0, 16, 9, 16, stoneTile, sky, blk, undefined, false, -1, 0, 0, 1, 1, 1, topTile);
          emitBox(x, y, z, 1.5, 8.8, 6.8, 14.5, 9.2, 9.2, darkTile, sky, blk);
          emitBox(x, y, z, 2, 9, 7.5, 14, 11.5, 8.5, sawTile, sky, blk);
          emitBox(x, y, z, 3, 11.5, 7.5, 13, 13.5, 8.5, sawTile, sky, blk);
          emitBox(x, y, z, 4.5, 13.5, 7.5, 11.5, 15, 8.5, sawTile, sky, blk);
          emitBox(x, y, z, 6.5, 15, 7.5, 9.5, 15.8, 8.5, sawTile, sky, blk);
        } else if (b.name === 'dirt_path' || b.name === 'farmland' || b.name === 'farmland_moist') {
          const bt = tiles[id];
          emitBox(x, y, z, 0, 0, 0, 16, 15, 16, bt[4], sky, blk, [0, 1/16, 1, 1], false, -1, 0, 0, 1, 1, 1, bt[2], bt[3]);
        } else if (b.name.endsWith('_carpet')) {
          const bt = tiles[id];
          emitBox(x, y, z, 0, 0, 0, 16, 1, 16, bt[0], sky, blk, [0, 15/16, 1, 1], false, -1, 0, 0, 1, 1, 1, bt[2], bt[3]);
        } else if (b.name === 'grindstone') {
          const legTile = tiles[ID.dark_oak_log]?.[0] ?? tiles[ID.dark_oak_planks]?.[0] ?? tiles[id][0];
          const pivotTile = tiles[ID.stone]?.[0] ?? tiles[id][0];
          const wheelTile = tiles[id][0];
          emitBox(x, y, z, 2, 0, 6, 4, 7, 10, legTile, sky, blk);
          emitBox(x, y, z, 12, 0, 6, 14, 7, 10, legTile, sky, blk);
          emitBox(x, y, z, 2, 6, 6, 4, 12, 10, pivotTile, sky, blk);
          emitBox(x, y, z, 12, 6, 6, 14, 12, 10, pivotTile, sky, blk);
          emitBox(x, y, z, 4, 4, 2, 12, 16, 14, wheelTile, sky, blk);
        } else if (b.name === 'scaffolding') {
          const topT = tiles[id][2], sideT = tiles[id][0];
          emitBox(x, y, z, 0, 14, 0, 16, 16, 16, topT, sky, blk);
          emitBox(x, y, z, 0, 0, 0, 2, 14, 2, sideT, sky, blk);
          emitBox(x, y, z, 14, 0, 0, 16, 14, 2, sideT, sky, blk);
          emitBox(x, y, z, 0, 0, 14, 2, 14, 16, sideT, sky, blk);
          emitBox(x, y, z, 14, 0, 14, 16, 14, 16, sideT, sky, blk);
          emitBox(x, y, z, 2, 0, 0, 14, 2, 2, sideT, sky, blk);
          emitBox(x, y, z, 2, 0, 14, 14, 2, 16, sideT, sky, blk);
          emitBox(x, y, z, 0, 0, 2, 2, 2, 14, sideT, sky, blk);
          emitBox(x, y, z, 14, 0, 2, 16, 2, 14, sideT, sky, blk);
          out.pushQuad(x, y, z + 1, x + 1, y, z + 1, x + 1, y + 1, z + 1, x, y + 1, z + 1, 0, 0, 1, 1, 1, sideT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x + 1, y, z, x, y, z, x, y + 1, z, x + 1, y + 1, z, 0, 0, -1, 1, 1, sideT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x + 1, y, z + 1, x + 1, y, z, x + 1, y + 1, z, x + 1, y + 1, z + 1, 1, 0, 0, 1, 1, sideT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x, y, z, x, y, z + 1, x, y + 1, z + 1, x, y + 1, z, -1, 0, 0, 1, 1, sideT, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
        } else if ((_subFlags[id] & 1) !== 0) {
          const cakeTile = tiles[ID.cake]?.[0] ?? tiles[id][0];
          const cakeTop = tiles[ID.cake]?.[2] ?? tiles[id][2] ?? cakeTile;
          const candleTile = tiles[id][0];
          const flameTile = tiles[ID.shroomlight]?.[0] ?? tiles[ID.torch]?.[0] ?? candleTile;
          emitBox(x, y, z, 1, 0, 1, 15, 8, 15, cakeTile, sky, blk, [1/16, 8/16, 15/16, 1], false, -1, 0, 0, 1, 1, 1, cakeTop);
          emitBox(x, y, z, 7, 8, 7, 9, 14, 9, candleTile, sky, blk);
          emitBox(x, y, z, 7.4, 14, 7.4, 8.6, 15.6, 8.6, flameTile, sky, 1);
        } else if ((_subFlags[id] & 2) !== 0) {
          const potTile = tiles[ID.terracotta]?.[0] ?? tiles[id][0];
          const dirtTile = tiles[ID.dirt]?.[0] ?? potTile;
          emitBox(x, y, z, 5, 0, 5, 11, 6, 11, potTile, sky, blk);
          emitBox(x, y, z, 6, 4.5, 6, 10, 6.2, 10, dirtTile, sky, blk);
          if ((_subFlags[id] & 4) !== 0) {
            const plantName = b.name.slice(7);
            const pId = ID[plantName] ?? ID[plantName.replace('_bush', '')] ?? id;
            const pTile = tiles[pId]?.[0] ?? tiles[id][0];
            emitBox(x, y, z, 7.2, 6, 5.2, 8.8, 14, 10.8, pTile, sky, blk);
            emitBox(x, y, z, 5.2, 6, 7.2, 10.8, 14, 8.8, pTile, sky, blk);
          }
        } else if (b.name === 'lectern') {
          const plankTile = tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          const trimTile = tiles[ID.spruce_planks]?.[0] ?? plankTile;
          const shelfTile = tiles[ID.bookshelf]?.[4] ?? plankTile;
          const redTile = tiles[ID.red_wool]?.[0] ?? plankTile;
          const goldTile = tiles[ID.gold_block]?.[0] ?? plankTile;
          const pageTile = tiles[ID.quartz_block]?.[0] ?? tiles[ID.white_wool]?.[0] ?? plankTile;
          emitBox(x, y, z, 0, 0, 0, 16, 2, 16, plankTile, sky, blk);
          emitBox(x, y, z, 4, 2, 4, 12, 10.5, 12, shelfTile, sky, blk);
          emitBox(x, y, z, 1, 12.5, 1, 15, 14.5, 6, plankTile, sky, blk);
          emitBox(x, y, z, 1, 11.0, 5, 15, 13.0, 11, plankTile, sky, blk);
          emitBox(x, y, z, 1, 9.5, 10, 15, 11.5, 15, plankTile, sky, blk);
          emitBox(x, y, z, 1, 11.0, 14.2, 15, 12.2, 15.5, trimTile, sky, blk);
          emitBox(x, y, z, 2.2, 14.3, 2, 13.8, 15.0, 6.2, redTile, sky, blk);
          emitBox(x, y, z, 2.2, 12.8, 5.8, 13.8, 13.5, 10.5, redTile, sky, blk);
          emitBox(x, y, z, 2.2, 11.3, 10.0, 13.8, 12.0, 14.0, redTile, sky, blk);
          emitBox(x, y, z, 3.0, 14.9, 2.4, 7.5, 15.6, 6.0, pageTile, sky, blk);
          emitBox(x, y, z, 8.5, 14.9, 2.4, 13.0, 15.6, 6.0, pageTile, sky, blk);
          emitBox(x, y, z, 3.0, 13.4, 6.0, 7.5, 14.2, 10.2, pageTile, sky, blk);
          emitBox(x, y, z, 8.5, 13.4, 6.0, 13.0, 14.2, 10.2, pageTile, sky, blk);
          emitBox(x, y, z, 3.0, 11.9, 10.2, 7.5, 12.7, 13.8, pageTile, sky, blk);
          emitBox(x, y, z, 8.5, 11.9, 10.2, 13.0, 12.7, 13.8, pageTile, sky, blk);
          emitBox(x, y, z, 7.4, 12.0, 2.4, 8.6, 15.5, 13.8, goldTile, sky, blk);
        } else if (b.shape === 'enchanting_table' || b.name === 'enchanting_table') {
          const bt = tiles[id];
          emitBox(x, y, z, 0, 0, 0, 16, 12, 16, bt[4], sky, blk, [0, 4/16, 1, 1], false, -1, 0, 0, 1, 1, 1, bt[2], bt[3]);
        } else if (b.name === 'campfire' || b.name === 'soul_campfire' || b.name === 'unlit_campfire') {
          const logSide = tiles[ID.oak_log]?.[0] ?? tiles[id][0];
          const logTop = tiles[ID.oak_log]?.[2] ?? logSide;
          const ashTile = tiles[id][2] ?? tiles[ID.coal_block]?.[0] ?? logSide;
          emitBox(x, y, z, 3, 0, 3, 13, 1.5, 13, ashTile, sky, blk);
          emitBox(x, y, z, 1, 0, 0.5, 5, 4, 15.5, logSide, sky, blk);
          emitBox(x, y, z, 1, 0, 0, 5, 4, 0.5, logTop, sky, blk, FULL_UV);
          emitBox(x, y, z, 1, 0, 15.5, 5, 4, 16, logTop, sky, blk, FULL_UV);
          emitBox(x, y, z, 11, 0, 0.5, 15, 4, 15.5, logSide, sky, blk);
          emitBox(x, y, z, 11, 0, 0, 15, 4, 0.5, logTop, sky, blk, FULL_UV);
          emitBox(x, y, z, 11, 0, 15.5, 15, 4, 16, logTop, sky, blk, FULL_UV);
          emitBox(x, y, z, 0.5, 3, 1, 15.5, 7, 5, logSide, sky, blk);
          emitBox(x, y, z, 0, 3, 1, 0.5, 7, 5, logTop, sky, blk, FULL_UV);
          emitBox(x, y, z, 15.5, 3, 1, 16, 7, 5, logTop, sky, blk, FULL_UV);
          emitBox(x, y, z, 0.5, 3, 11, 15.5, 7, 15, logSide, sky, blk);
          emitBox(x, y, z, 0, 3, 11, 0.5, 7, 15, logTop, sky, blk, FULL_UV);
          emitBox(x, y, z, 15.5, 3, 11, 16, 7, 15, logTop, sky, blk, FULL_UV);
          if (b.name !== 'unlit_campfire') {
            const soul = b.name === 'soul_campfire';
            const emberTile = tiles[soul ? ID.sea_lantern : ID.magma_block]?.[0] ?? logSide;
            const fireTile = tiles[id][4] ?? tiles[soul ? ID.soul_fire : ID.fire]?.[0] ?? emberTile;
            emitBox(x, y, z, 5, 1.5, 5, 11, 4.5, 11, emberTile, sky, 1);
            const xA = x + 0.25, xB = x + 0.75, zA = z + 0.25, zB = z + 0.75, yB = y + 0.18, yT = y + 0.92;
            out.pushQuad(xA, yB, zA, xB, yB, zB, xB, yT, zB, xA, yT, zA, 0, 1, 0, 1, 1, fireTile, 0, 0, 0, 0, sky, sky, sky, sky, 1, 1, 1, 1, 0.2, false, 1, 1, 1, false, false);
            out.pushQuad(xB, yB, zB, xA, yB, zA, xA, yT, zA, xB, yT, zB, 0, 1, 0, 1, 1, fireTile, 0, 0, 0, 0, sky, sky, sky, sky, 1, 1, 1, 1, 0.2, false, 1, 1, 1, false, false);
            out.pushQuad(xB, yB, zA, xA, yB, zB, xA, yT, zB, xB, yT, zA, 0, 1, 0, 1, 1, fireTile, 0, 0, 0, 0, sky, sky, sky, sky, 1, 1, 1, 1, 0.2, false, 1, 1, 1, false, false);
            out.pushQuad(xA, yB, zB, xB, yB, zA, xB, yT, zA, xA, yT, zB, 0, 1, 0, 1, 1, fireTile, 0, 0, 0, 0, sky, sky, sky, sky, 1, 1, 1, 1, 0.2, false, 1, 1, 1, false, false);
          }
        } else if (b.name === 'bell') {
          const stoneTile = tiles[ID.stone_bricks]?.[0] ?? tiles[ID.stone]?.[0] ?? tiles[id][0];
          const woodTile = tiles[ID.dark_oak_planks]?.[0] ?? tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          const goldTile = tiles[ID.gold_block]?.[0] ?? tiles[id][0];
          emitBox(x, y, z, 0, 0, 5, 3, 16, 11, stoneTile, sky, blk);
          emitBox(x, y, z, 13, 0, 5, 16, 16, 11, stoneTile, sky, blk);
          emitBox(x, y, z, 2, 13, 6, 14, 15, 10, woodTile, sky, blk);
          emitBox(x, y, z, 4, 3, 4, 12, 5, 12, goldTile, sky, blk);
          emitBox(x, y, z, 5, 5, 5, 11, 11, 11, goldTile, sky, blk);
          emitBox(x, y, z, 6, 11, 6, 10, 13, 10, goldTile, sky, blk);
          emitBox(x, y, z, 7.2, 1.8, 7.2, 8.8, 3, 8.8, goldTile, sky, blk);
        } else if (b.shape === 'brewing_stand' || b.name === 'brewing_stand') {
          const baseTile = tiles[id][0];
          const cobbleTile = tiles[ID.cobblestone]?.[0] ?? baseTile;
          emitBox(x, y, z, 9, 0, 5, 15, 2, 11, cobbleTile, sky, blk);
          emitBox(x, y, z, 1, 0, 1, 7, 2, 7, cobbleTile, sky, blk);
          emitBox(x, y, z, 1, 0, 9, 7, 2, 15, cobbleTile, sky, blk);
          emitBox(x, y, z, 7, 0, 7, 9, 14, 9, baseTile, sky, 1);
          out.pushQuad(x + 0.15, y, z + 0.15, x + 0.85, y, z + 0.85, x + 0.85, y + 1, z + 0.85, x + 0.15, y + 1, z + 0.15, 0, 1, 0, 1, 1, baseTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x + 0.85, y, z + 0.15, x + 0.15, y, z + 0.85, x + 0.15, y + 1, z + 0.85, x + 0.85, y + 1, z + 0.15, 0, 1, 0, 1, 1, baseTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
        } else if (b.shape === 'anvil' || b.name === 'anvil') {
          const anvilTile = tiles[id][0];
          const rotX = (state & 1) !== 0;
          emitBox(x, y, z, 2, 0, 2, 14, 4, 14, anvilTile, sky, blk);
          if (rotX) {
            emitBox(x, y, z, 3, 4, 4, 13, 5, 12, anvilTile, sky, blk);
            emitBox(x, y, z, 4, 5, 6, 12, 10, 10, anvilTile, sky, blk);
            emitBox(x, y, z, 0, 10, 3, 16, 16, 13, anvilTile, sky, blk);
          } else {
            emitBox(x, y, z, 4, 4, 3, 12, 5, 13, anvilTile, sky, blk);
            emitBox(x, y, z, 6, 5, 4, 10, 10, 12, anvilTile, sky, blk);
            emitBox(x, y, z, 3, 10, 0, 13, 16, 16, anvilTile, sky, blk);
          }
          if (state >= 2) {
            const crackTile = tiles[ID.obsidian]?.[0] ?? anvilTile;
            if (rotX) emitBox(x, y, z, 6, 15.8, 3, 9, 16.05, 13, crackTile, sky, blk);
            else emitBox(x, y, z, 3, 15.8, 6, 13, 16.05, 9, crackTile, sky, blk);
            if (state >= 4) {
              if (rotX) emitBox(x, y, z, 11, 10, 4, 15, 14.5, 12, anvilTile, sky, blk);
              else emitBox(x, y, z, 4, 10, 11, 12, 14.5, 15, anvilTile, sky, blk);
            }
          }
        } else if (b.name === 'beacon') {
          const obsTile = tiles[ID.obsidian]?.[0] ?? tiles[id][0];
          const coreTile = tiles[ID.sea_lantern]?.[0] ?? tiles[ID.diamond_block]?.[0] ?? tiles[id][0];
          const glassTile = tiles[ID.glass]?.[0] ?? tiles[id][0];
          emitBox(x, y, z, 2, 0, 2, 14, 3, 14, obsTile, sky, blk);
          emitBox(x, y, z, 3, 3, 3, 13, 13, 13, coreTile, sky, 1, FULL_UV);
          emitBox(x, y, z, 0, 0, 0, 16, 16, 16, glassTile, sky, 1, FULL_UV);
        } else if (b.name === 'skeleton_skull' || b.name === 'wither_skeleton_skull' || b.name === 'zombie_head' || b.name === 'creeper_head' || b.name === 'piglin_head') {
          const headTile = tiles[id][0];
          const darkTile = tiles[ID.coal_block]?.[0] ?? headTile;
          if (b.name === 'skeleton_skull' || b.name === 'wither_skeleton_skull') {
            const wither = b.name === 'wither_skeleton_skull';
            const boneTile = tiles[wither ? ID.deepslate : ID.bone_block]?.[0] ?? headTile;
            const browTile = tiles[wither ? ID.blackstone : ID.calcite]?.[0] ?? boneTile;
            emitBox(x, y, z, 4, 0, 4, 12, 8, 12, boneTile, sky, blk, FULL_UV);
            emitBox(x, y, z, 4, 5.0, 11.8, 12, 6.2, 12.4, browTile, sky, blk);
            emitBox(x, y, z, 4.6, 3.0, 11.8, 6.8, 4.8, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 9.2, 3.0, 11.8, 11.4, 4.8, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 7.3, 2.0, 11.8, 8.7, 3.3, 12.25, darkTile, sky, blk);
            for (const tx of [4.8, 6.4, 8.0, 9.6]) {
              emitBox(x, y, z, tx, 0.4, 11.8, tx + 0.9, 1.6, 12.25, darkTile, sky, blk);
            }
          } else if (b.name === 'zombie_head') {
            const skinTile = tiles[ID.moss_block]?.[0] ?? headTile;
            const noseTile = tiles[ID.green_terracotta]?.[0] ?? skinTile;
            emitBox(x, y, z, 4, 0, 4, 12, 8, 12, skinTile, sky, blk, FULL_UV);
            emitBox(x, y, z, 3.8, 6.2, 3.8, 12.2, 8.2, 12.3, noseTile, sky, blk);
            emitBox(x, y, z, 4.8, 3.4, 11.8, 6.8, 4.8, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 9.2, 3.4, 11.8, 11.2, 4.8, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 7.2, 2.2, 11.8, 8.8, 3.3, 12.35, noseTile, sky, blk);
            emitBox(x, y, z, 6.0, 0.9, 11.8, 10.0, 1.9, 12.25, darkTile, sky, blk);
          } else if (b.name === 'creeper_head') {
            const crTile = tiles[ID.lime_terracotta]?.[0] ?? headTile;
            emitBox(x, y, z, 4, 0, 4, 12, 8, 12, crTile, sky, blk, FULL_UV);
            emitBox(x, y, z, 4.8, 4.2, 11.8, 6.8, 6.2, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 9.2, 4.2, 11.8, 11.2, 6.2, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 6.8, 2.2, 11.8, 9.2, 4.2, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 5.8, 1.0, 11.8, 10.2, 2.6, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 5.8, 0.2, 11.8, 7.0, 1.4, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 9.0, 0.2, 11.8, 10.2, 1.4, 12.25, darkTile, sky, blk);
          } else {
            const pigTile = tiles[ID.terracotta]?.[0] ?? headTile;
            const tuskTile = tiles[ID.quartz_block]?.[0] ?? pigTile;
            emitBox(x, y, z, 3, 0, 4, 13, 8, 12, pigTile, sky, blk, FULL_UV);
            emitBox(x, y, z, 6, 1, 12, 10, 4, 14, pigTile, sky, blk);
            emitBox(x, y, z, 6.5, 1.6, 13.8, 7.3, 3.0, 14.15, darkTile, sky, blk);
            emitBox(x, y, z, 8.7, 1.6, 13.8, 9.5, 3.0, 14.15, darkTile, sky, blk);
            emitBox(x, y, z, 4.8, 1, 12, 6, 3.2, 13.4, tuskTile, sky, blk);
            emitBox(x, y, z, 10, 1, 12, 11.2, 3.2, 13.4, tuskTile, sky, blk);
            emitBox(x, y, z, 4.5, 4.4, 11.8, 6.8, 5.6, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 9.2, 4.4, 11.8, 11.5, 5.6, 12.25, darkTile, sky, blk);
            emitBox(x, y, z, 1.5, 0.8, 6, 3, 6.8, 10, pigTile, sky, blk);
            emitBox(x, y, z, 13, 0.8, 6, 14.5, 6.8, 10, pigTile, sky, blk);
          }
        } else if (b.name === 'chain') {
          const chainTile = tiles[ID.anvil]?.[0] ?? tiles[id][0];
          emitBox(x, y, z, 6.5, 0, 7.2, 9.5, 4.2, 8.8, chainTile, sky, blk);
          emitBox(x, y, z, 7.2, 3.8, 6.5, 8.8, 8.2, 9.5, chainTile, sky, blk);
          emitBox(x, y, z, 6.5, 7.8, 7.2, 9.5, 12.2, 8.8, chainTile, sky, blk);
          emitBox(x, y, z, 7.2, 11.8, 6.5, 8.8, 16, 9.5, chainTile, sky, blk);
        } else if (b.shape === 'lantern' || b.name === 'lantern' || b.name === 'soul_lantern') {
          const sideTile = tiles[id][0], topTile = tiles[id][2];
          const chainTile = tiles[ID.anvil]?.[0] ?? topTile;
          emitBox(x, y, z, 4.8, 0, 4.8, 11.2, 1.2, 11.2, topTile, sky, blk);
          emitBox(x, y, z, 5, 1.2, 5, 11, 6.8, 11, sideTile, sky, 1, FULL_UV);
          emitBox(x, y, z, 4.8, 6.5, 4.8, 11.2, 7.5, 11.2, topTile, sky, blk);
          emitBox(x, y, z, 6, 7.5, 6, 10, 9.2, 10, topTile, sky, blk);
          emitBox(x, y, z, 7, 9.2, 7.3, 9, 11.2, 8.7, chainTile, sky, blk);
          const aboveId = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
          if (aboveId !== 0 && aboveId !== ID.air) {
            emitBox(x, y, z, 7.3, 11, 6.8, 8.7, 13.8, 9.2, chainTile, sky, blk);
            emitBox(x, y, z, 6.8, 13.4, 7.3, 9.2, 16, 8.7, chainTile, sky, blk);
          }
        } else if (b.shape === 'end_portal' || b.shape === 'end_gateway') {
          const tile = tiles[id][0];
          const frameTile = tiles[ID.bedrock]?.[0] ?? tile;
          if (b.shape === 'end_gateway') {
            emitBox(x, y, z, 0.8, 0.8, 0.8, 15.2, 15.2, 15.2, tile, 1, 1);
            emitBox(x, y, z, 3.2, 3.2, 3.2, 12.8, 12.8, 12.8, tile, 1, 1);
            for (const cx of [0, 13]) for (const cy of [0, 13]) for (const cz of [0, 13]) {
              emitBox(x, y, z, cx, cy, cz, cx + 3, cy + 3, cz + 3, frameTile, sky, 1);
            }
          } else {
            emitBox(x, y, z, 0, 9, 0, 16, 11.8, 16, tile, 1, 1);
            emitBox(x, y, z, 1, 11.8, 1, 15, 12.2, 15, tile, 1, 1);
          }
        } else if (b.shape === 'end_portal_frame') {
          const bt = tiles[id];
          emitBox(x, y, z, 0, 0, 0, 16, 13, 16, bt[4], sky, blk, [0, 3/16, 1, 1], false, -1, 0, 0, 1, 1, 1, bt[2], bt[3]);
          if (state & 4) {
            const eyeTop = bt[6] ?? bt[2];
            const eyeSide = bt[7] ?? eyeTop;
            emitBox(x, y, z, 4, 13, 4, 12, 16, 12, eyeSide, sky, 1, [4/16, 13/16, 12/16, 1], false, -1, 0, 0, 1, 1, 1, eyeTop, eyeSide);
          }
        } else if (b.shape === 'end_rod') {
          const isCopperRod = b.name === 'lightning_rod';
          const baseTile = isCopperRod ? tiles[id][0] : (tiles[id][6] ?? tiles[ID.purpur_block]?.[0] ?? tiles[id][0]);
          const shaftTile = isCopperRod ? tiles[id][0] : (tiles[id][7] ?? tiles[ID.quartz_block]?.[0] ?? tiles[id][0]);
          let dir = state & 7;
          if (dir === 0) {
            const belowId = ly > 0 ? padded[lIdx - STRIDE_Y] & 4095 : 0;
            const aboveId = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
            if (belowId === 0 && aboveId !== 0 && aboveId !== id) dir = 5;
          }
          if (dir === 1) {
            emitBox(x, y, z, 0, 5.5, 5.5, 1.2, 10.5, 10.5, baseTile, sky, 1);
            emitBox(x, y, z, 1.2, 6.3, 6.3, 2.4, 9.7, 9.7, baseTile, sky, 1);
            emitBox(x, y, z, 2.4, 7, 7, 16, 9, 9, shaftTile, sky, 1);
            emitBox(x, y, z, 14.6, 6.7, 6.7, 16, 9.3, 9.3, shaftTile, sky, 1);
          } else if (dir === 2) {
            emitBox(x, y, z, 14.8, 5.5, 5.5, 16, 10.5, 10.5, baseTile, sky, 1);
            emitBox(x, y, z, 13.6, 6.3, 6.3, 14.8, 9.7, 9.7, baseTile, sky, 1);
            emitBox(x, y, z, 0, 7, 7, 13.6, 9, 9, shaftTile, sky, 1);
            emitBox(x, y, z, 0, 6.7, 6.7, 1.4, 9.3, 9.3, shaftTile, sky, 1);
          } else if (dir === 3) {
            emitBox(x, y, z, 5.5, 5.5, 0, 10.5, 10.5, 1.2, baseTile, sky, 1);
            emitBox(x, y, z, 6.3, 6.3, 1.2, 9.7, 9.7, 2.4, baseTile, sky, 1);
            emitBox(x, y, z, 7, 7, 2.4, 9, 9, 16, shaftTile, sky, 1);
            emitBox(x, y, z, 6.7, 6.7, 14.6, 9.3, 9.3, 16, shaftTile, sky, 1);
          } else if (dir === 4) {
            emitBox(x, y, z, 5.5, 5.5, 14.8, 10.5, 10.5, 16, baseTile, sky, 1);
            emitBox(x, y, z, 6.3, 6.3, 13.6, 9.7, 9.7, 14.8, baseTile, sky, 1);
            emitBox(x, y, z, 7, 7, 0, 9, 9, 13.6, shaftTile, sky, 1);
            emitBox(x, y, z, 6.7, 6.7, 0, 9.3, 9.3, 1.4, shaftTile, sky, 1);
          } else if (dir === 5) {
            emitBox(x, y, z, 5.5, 14.8, 5.5, 10.5, 16, 10.5, baseTile, sky, 1);
            emitBox(x, y, z, 6.3, 13.6, 6.3, 9.7, 14.8, 9.7, baseTile, sky, 1);
            emitBox(x, y, z, 7, 0, 7, 9, 13.6, 9, shaftTile, sky, 1);
            emitBox(x, y, z, 6.7, 0, 6.7, 9.3, 1.4, 9.3, shaftTile, sky, 1);
          } else {
            emitBox(x, y, z, 5.5, 0, 5.5, 10.5, 1.2, 10.5, baseTile, sky, 1);
            emitBox(x, y, z, 6.3, 1.2, 6.3, 9.7, 2.4, 9.7, baseTile, sky, 1);
            emitBox(x, y, z, 7, 2.4, 7, 9, 16, 9, shaftTile, sky, 1);
            emitBox(x, y, z, 6.7, 14.6, 6.7, 9.3, 16, 9.3, shaftTile, sky, 1);
          }
        } else if (b.shape === 'dragon_egg') {
          const tile = tiles[id][0];
          emitBox(x, y, z, 3, 0, 3, 13, 1, 13, tile, sky, blk);
          emitBox(x, y, z, 2, 1, 2, 14, 3, 14, tile, sky, blk);
          emitBox(x, y, z, 1, 3, 1, 15, 8, 15, tile, sky, blk);
          emitBox(x, y, z, 0.6, 4.2, 2.5, 15.4, 6.8, 13.5, tile, sky, blk);
          emitBox(x, y, z, 2.5, 4.2, 0.6, 13.5, 6.8, 15.4, tile, sky, blk);
          emitBox(x, y, z, 2, 8, 2, 14, 11, 14, tile, sky, blk);
          emitBox(x, y, z, 3, 11, 3, 13, 13, 13, tile, sky, blk);
          emitBox(x, y, z, 4, 13, 4, 12, 14, 12, tile, sky, blk);
          emitBox(x, y, z, 5, 14, 5, 11, 15, 11, tile, sky, blk);
          emitBox(x, y, z, 6, 15, 6, 10, 16, 10, tile, sky, blk);
        } else if (b.name === 'sculk_sensor' || b.name === 'calibrated_sculk_sensor') {
          const sculkTile = tiles[id][0];
          const tendrilTile = tiles[ID.sea_lantern]?.[0] ?? tiles[ID.diamond_block]?.[0] ?? sculkTile;
          emitBox(x, y, z, 0, 0, 0, 16, 8, 16, sculkTile, sky, blk, FULL_UV);
          for (const [tx, tz] of [[2, 2], [12, 2], [2, 12], [12, 12]]) {
            emitBox(x, y, z, tx, 8, tz, tx + 2, 12, tz + 2, tendrilTile, sky, 1, undefined, false, -1, 0, 0, 0.22, 0.88, 0.96);
            emitBox(x, y, z, tx + 0.4, 12, tz - 0.5, tx + 1.6, 14, tz + 1.2, tendrilTile, sky, 1, undefined, false, -1, 0, 0, 0.45, 0.98, 1.0);
          }
          if (b.name === 'calibrated_sculk_sensor') {
            const amTile = tiles[ID.amethyst_block]?.[0] ?? sculkTile;
            emitBox(x, y, z, 6.5, 8, 5, 9.5, 15, 11, amTile, sky, 1, undefined, false, -1, 0, 0, 0.88, 0.65, 1.0);
            emitBox(x, y, z, 5, 8, 6.5, 11, 13, 9.5, amTile, sky, 1, undefined, false, -1, 0, 0, 0.78, 0.55, 0.96);
          }
        } else if (b.name === 'sculk_shrieker') {
          const sculkTile = tiles[ID.sculk_block]?.[0] ?? tiles[id][0];
          const boneTile = tiles[ID.bone_block]?.[0] ?? tiles[id][0];
          const soulTile = tiles[ID.sea_lantern]?.[0] ?? sculkTile;
          emitBox(x, y, z, 0, 0, 0, 16, 8, 16, sculkTile, sky, blk);
          emitBox(x, y, z, 4.5, 8, 4.5, 11.5, 11.5, 11.5, soulTile, sky, 1, undefined, false, -1, 0, 0, 0.25, 0.85, 0.95);
          for (const [px, pz] of [[1, 1], [12, 1], [1, 12], [12, 12]]) {
            emitBox(x, y, z, px, 8, pz, px + 3, 16, pz + 3, boneTile, sky, blk);
          }
          emitBox(x, y, z, 4, 13.5, 1.5, 12, 15.5, 3, boneTile, sky, blk);
          emitBox(x, y, z, 4, 13.5, 13, 12, 15.5, 14.5, boneTile, sky, blk);
          emitBox(x, y, z, 1.5, 13.5, 4, 3, 15.5, 12, boneTile, sky, blk);
          emitBox(x, y, z, 13, 13.5, 4, 14.5, 15.5, 12, boneTile, sky, blk);
        } else if (b.name === 'daylight_detector' || b.name === 'inverted_daylight_detector') {
          const woodTile = tiles[ID.dark_oak_planks]?.[0] ?? tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          const topTile = tiles[id][2] ?? tiles[id][0];
          emitBox(x, y, z, 0, 0, 0, 16, 6, 16, woodTile, sky, blk, FULL_UV, false, -1, 0, 0, 1, 1, 1, topTile);
          const cellTile = tiles[b.name === 'inverted_daylight_detector' ? ID.lapis_block : ID.quartz_block]?.[0] ?? topTile;
          for (const cy of [2, 6.5, 11]) for (const cx of [2, 6.5, 11]) {
            emitBox(x, y, z, cx, 6, cy, cx + 3, 6.6, cy + 3, cellTile, sky, blk);
          }
        } else if (b.name === 'rail' || b.name === 'powered_rail' || b.name === 'detector_rail' || b.name === 'activator_rail') {
          const railTile = tiles[id][0];
          const ry = y + 0.0625;
          out.pushQuad(x, ry, z + 1, x + 1, ry, z + 1, x + 1, ry, z, x, ry, z, 0, 1, 0, 1, 1, railTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          out.pushQuad(x, ry, z, x + 1, ry, z, x + 1, ry, z + 1, x, ry, z + 1, 0, -1, 0, 1, 1, railTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
        } else if (b.name === 'redstone_wire') {
          const wireTile = tiles[ID.redstone_block]?.[0] ?? tiles[id][0];
          const pwr = 0.45 + 0.55 * ((state & 15) / 15);
          const isRs = (cid: number) => cid === id || cid === ID.repeater || cid === ID.comparator || cid === ID.redstone_torch || cid === ID.redstone_block || cid === ID.lever || cid === ID.observer || cid === ID.target;
          const cn = isRs(padded[lIdx - 18] & 4095), cs = isRs(padded[lIdx + 18] & 4095), cw = isRs(padded[lIdx - 1] & 4095), ce = isRs(padded[lIdx + 1] & 4095);
          emitBox(x, y, z, 5.5, 0, 5.5, 10.5, 0.8, 10.5, wireTile, sky, blk, undefined, false, -1, 0, 0, pwr, pwr * 0.25, pwr * 0.2);
          if (cn || (!cn && !cs && !cw && !ce)) emitBox(x, y, z, 6.5, 0, 0, 9.5, 0.7, 5.5, wireTile, sky, blk, undefined, false, -1, 0, 0, pwr, pwr * 0.25, pwr * 0.2);
          if (cs || (!cn && !cs && !cw && !ce)) emitBox(x, y, z, 6.5, 0, 10.5, 9.5, 0.7, 16, wireTile, sky, blk, undefined, false, -1, 0, 0, pwr, pwr * 0.25, pwr * 0.2);
          if (cw || (!cn && !cs && !cw && !ce)) emitBox(x, y, z, 0, 0, 6.5, 5.5, 0.7, 9.5, wireTile, sky, blk, undefined, false, -1, 0, 0, pwr, pwr * 0.25, pwr * 0.2);
          emitBox(x, y, z, 6.5, 0.8, 6.5, 9.5, 1.3, 9.5, wireTile, sky, 1, undefined, false, -1, 0, 0, Math.min(1, pwr * 1.15), pwr * 0.35, pwr * 0.25);
          if (ce || (!cn && !cs && !cw && !ce)) emitBox(x, y, z, 10.5, 0, 6.5, 16, 0.7, 9.5, wireTile, sky, blk, undefined, false, -1, 0, 0, pwr, pwr * 0.25, pwr * 0.2);
        } else if (b.name === 'ladder') {
          const ladTile = tiles[id][0];
          const f = state & 3;
          if (f === 0) {
            const zp = z + 0.8 / 16;
            out.pushQuad(x, y, zp, x + 1, y, zp, x + 1, y + 1, zp, x, y + 1, zp, 0, 0, 1, 1, 1, ladTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
            out.pushQuad(x + 1, y, zp, x, y, zp, x, y + 1, zp, x + 1, y + 1, zp, 0, 0, -1, 1, 1, ladTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          } else if (f === 2) {
            const zp = z + 15.2 / 16;
            out.pushQuad(x + 1, y, zp, x, y, zp, x, y + 1, zp, x + 1, y + 1, zp, 0, 0, -1, 1, 1, ladTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
            out.pushQuad(x, y, zp, x + 1, y, zp, x + 1, y + 1, zp, x, y + 1, zp, 0, 0, 1, 1, 1, ladTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          } else if (f === 1) {
            const xp = x + 15.2 / 16;
            out.pushQuad(xp, y, z, xp, y, z + 1, xp, y + 1, z + 1, xp, y + 1, z, -1, 0, 0, 1, 1, ladTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
            out.pushQuad(xp, y, z + 1, xp, y, z, xp, y + 1, z, xp, y + 1, z + 1, 1, 0, 0, 1, 1, ladTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          } else {
            const xp = x + 0.8 / 16;
            out.pushQuad(xp, y, z + 1, xp, y, z, xp, y + 1, z, xp, y + 1, z + 1, 1, 0, 0, 1, 1, ladTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
            out.pushQuad(xp, y, z, xp, y, z + 1, xp, y + 1, z + 1, xp, y + 1, z, -1, 0, 0, 1, 1, ladTile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
          }
        } else if (b.name === 'item_frame') {
          const woodTile = tiles[ID.birch_planks]?.[0] ?? tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          const backTile = tiles[ID.brown_terracotta]?.[0] ?? woodTile;
          const goldTile = tiles[ID.gold_block]?.[0] ?? woodTile;
          const z0 = 0, z1 = 1.6;
          emitBox(x, y, z, 3, 3, z0, 13, 13, z0 + 1.0, backTile, sky, blk);
          emitBox(x, y, z, 5.5, 5.5, z0 + 0.8, 10.5, 10.5, z0 + 1.35, goldTile, sky, blk);
          emitBox(x, y, z, 2, 2, z0, 14, 3.5, z1, woodTile, sky, blk);
          emitBox(x, y, z, 2, 12.5, z0, 14, 14, z1, woodTile, sky, blk);
          emitBox(x, y, z, 2, 3.5, z0, 3.5, 12.5, z1, woodTile, sky, blk);
          emitBox(x, y, z, 12.5, 3.5, z0, 14, 12.5, z1, woodTile, sky, blk);
        } else if (b.name === 'oak_sign' || b.name === 'spruce_sign' || b.name === 'oak_hanging_sign' || b.name === 'spruce_hanging_sign') {
          const woodTile = tiles[b.name.startsWith('spruce') ? ID.spruce_planks : ID.oak_planks]?.[0] ?? tiles[id][0];
          const postTile = tiles[b.name.startsWith('spruce') ? ID.spruce_log : ID.oak_log]?.[0] ?? woodTile;
          const chainTile = tiles[ID.anvil]?.[0] ?? woodTile;
          if (b.name.includes('hanging')) {
            emitBox(x, y, z, 1, 14, 6.5, 15, 16, 9.5, postTile, sky, blk);
            emitBox(x, y, z, 3.5, 10, 7.3, 5, 14, 8.7, chainTile, sky, blk);
            emitBox(x, y, z, 11, 10, 7.3, 12.5, 14, 8.7, chainTile, sky, blk);
            emitBox(x, y, z, 1.5, 2, 7, 14.5, 10, 9, woodTile, sky, blk);
          } else {
            emitBox(x, y, z, 7, 0, 7, 9, 9, 9, postTile, sky, blk);
            emitBox(x, y, z, 1, 9, 6.8, 15, 15.5, 9.2, woodTile, sky, blk);
          }
        } else if (b.name.endsWith('_banner')) {
          const woodTile = tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          const clothTile = tiles[id][0];
          emitBox(x, y, z, 7, 0, 7, 9, 15.5, 9, woodTile, sky, blk);
          emitBox(x, y, z, 1.5, 14, 6.5, 14.5, 15.5, 9.5, woodTile, sky, blk);
          emitBox(x, y, z, 2, 1.5, 9.0, 14, 14.5, 10.4, clothTile, sky, blk);
        } else if (b.name.endsWith('_wall_sign') || b.name.endsWith('_wall_hanging_sign') || b.name.endsWith('_wall_banner')) {
          const tile = tiles[id][0];
          const facing = state & 3;
          const rotEmit = (x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, t: number) => {
            if (facing === 0) emitBox(x, y, z, x0, y0, z0, x1, y1, z1, t, sky, blk);
            else if (facing === 1) emitBox(x, y, z, z0, y0, x0, z1, y1, x1, t, sky, blk);
            else if (facing === 2) emitBox(x, y, z, 16 - x1, y0, 16 - z1, 16 - x0, y1, 16 - z0, t, sky, blk);
            else emitBox(x, y, z, 16 - z1, y0, 16 - x1, 16 - z0, y1, 16 - x0, t, sky, blk);
          };
          if (b.name.endsWith('_wall_hanging_sign')) {
            const barT = tiles[ID.oak_log]?.[0] ?? tile;
            const chainT = tiles[ID.anvil]?.[0] ?? barT;
            rotEmit(0, 14, 6, 16, 16, 10, barT);
            rotEmit(3, 10, 7.5, 4, 14, 8.5, chainT);
            rotEmit(12, 10, 7.5, 13, 14, 8.5, chainT);
            rotEmit(1, 0, 7, 15, 10, 9, tile);
          } else if (b.name.endsWith('_wall_banner')) {
            const barT = tiles[ID.oak_planks]?.[0] ?? tile;
            rotEmit(1, 14, 0, 15, 16, 2, barT);
            rotEmit(1, 0, 0.5, 15, 14, 1.5, tile);
          } else {
            rotEmit(0, 4.5, 0, 16, 12.5, 1.5, tile);
          }
        } else if (b.name === 'slime_block' || b.name === 'honey_block') {
          const outerTile = tiles[id][0];
          const innerTile = tiles[b.name === 'slime_block' ? ID.lime_terracotta : ID.orange_terracotta]?.[0] ?? outerTile;
          const inPad = b.name === 'slime_block' ? 3.5 : 2.0;
          emitBox(x, y, z, inPad, inPad, inPad, 16 - inPad, 16 - inPad, 16 - inPad, innerTile, sky, blk);
          emitBox(x, y, z, 0, 0, 0, 16, 16, 16, outerTile, sky, blk, FULL_UV);
        } else if (b.name === 'spawner' || b.name === 'trial_spawner' || b.name === 'vault' || b.name === 'ominous_vault') {
          const cageTile = tiles[id][0];
          const pillarTile = tiles[b.name === 'spawner' ? ID.anvil : ID.deepslate_bricks]?.[0] ?? cageTile;
          const coreTile = tiles[b.name === 'ominous_vault' ? ID.sea_lantern : ID.magma_block]?.[0] ?? cageTile;
          emitBox(x, y, z, 0, 0, 0, 16, 16, 16, cageTile, sky, blk, FULL_UV);
          emitBox(x, y, z, 5.5, 4.5, 5.5, 10.5, 10.5, 10.5, coreTile, sky, 1);
          for (const [px, pz] of [[0, 0], [13.5, 0], [0, 13.5], [13.5, 13.5]]) {
            emitBox(x, y, z, px, 0, pz, px + 2.5, 16, pz + 2.5, pillarTile, sky, blk);
          }
        } else if (b.shape === 'pane' && (b.name.endsWith('glass_pane') || b.name === 'iron_bars')) {
          const tile = tiles[id][0], isBars = b.name === 'iron_bars';
          const barTile = isBars ? (tiles[ID.anvil]?.[0] ?? tile) : tile;
          const joins = (c: number) => { if (!c) return false; const nb = blocks[c & 4095]; return !!nb && (isBars ? (nb.name === 'iron_bars' || isOpq(c)) : (nb.name.endsWith('glass_pane') || nb.pattern === 'glass' || isOpq(c))); };
          let cn = joins(padded[lIdx - 18]), cs = joins(padded[lIdx + 18]), cw = joins(padded[lIdx - 1]), ce = joins(padded[lIdx + 1]);
          if (!cn && !cs && !cw && !ce) { if (state & 1) { cw = true; ce = true; } else { cn = true; cs = true; } }
          emitBox(x, y, z, 7, 0, 7, 9, 16, 9, barTile, sky, blk);
          if (isBars) {
            if (cn) {
              emitBox(x, y, z, 7.2, 1.5, 0, 8.8, 3.2, 7, barTile, sky, blk);
              emitBox(x, y, z, 7.2, 12.8, 0, 8.8, 14.5, 7, barTile, sky, blk);
              emitBox(x, y, z, 7.1, 0, 2.5, 8.9, 16, 4.3, barTile, sky, blk);
            }
            if (cs) {
              emitBox(x, y, z, 7.2, 1.5, 9, 8.8, 3.2, 16, barTile, sky, blk);
              emitBox(x, y, z, 7.2, 12.8, 9, 8.8, 14.5, 16, barTile, sky, blk);
              emitBox(x, y, z, 7.1, 0, 11.7, 8.9, 16, 13.5, barTile, sky, blk);
            }
            if (cw) {
              emitBox(x, y, z, 0, 1.5, 7.2, 7, 3.2, 8.8, barTile, sky, blk);
              emitBox(x, y, z, 0, 12.8, 7.2, 7, 14.5, 8.8, barTile, sky, blk);
              emitBox(x, y, z, 2.5, 0, 7.1, 4.3, 16, 8.9, barTile, sky, blk);
            }
            if (ce) {
              emitBox(x, y, z, 9, 1.5, 7.2, 16, 3.2, 8.8, barTile, sky, blk);
              emitBox(x, y, z, 9, 12.8, 7.2, 16, 14.5, 8.8, barTile, sky, blk);
              emitBox(x, y, z, 11.7, 0, 7.1, 13.5, 16, 8.9, barTile, sky, blk);
            }
          } else {
            if (cn) emitBox(x, y, z, 7, 0, 0, 9, 16, 7, tile, sky, blk);
            if (cs) emitBox(x, y, z, 7, 0, 9, 9, 16, 16, tile, sky, blk);
            if (cw) emitBox(x, y, z, 0, 0, 7, 7, 16, 9, tile, sky, blk);
            if (ce) emitBox(x, y, z, 9, 0, 7, 16, 16, 9, tile, sky, blk);
          }
        } else if (b.shape === 'torch' && b.name !== 'lantern' && b.name !== 'soul_lantern' && b.name !== 'brewing_stand') {
          const at = state & 7, on = (state & 8) !== 0;
          if (b.name === 'tripwire_hook') {
            const woodT = tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
            const ironT = tiles[ID.anvil]?.[0] ?? tiles[ID.iron_block]?.[0] ?? tiles[id][0];
            emitBox(x, y, z, 5.5, 1, 0, 10.5, 9, 2.2, woodT, sky, blk);
            emitBox(x, y, z, 7, 4.8, 2.2, 9, 6.8, 5.2, woodT, sky, blk);
            emitBox(x, y, z, 5.8, 4.2, 5.2, 10.2, 5.2, 9.2, ironT, sky, blk);
            emitBox(x, y, z, 5.8, 7.2, 5.2, 10.2, 8.2, 9.2, ironT, sky, blk);
            emitBox(x, y, z, 5.8, 5.2, 5.2, 6.8, 7.2, 9.2, ironT, sky, blk);
            emitBox(x, y, z, 9.2, 5.2, 5.2, 10.2, 7.2, 9.2, ironT, sky, blk);
          } else if (b.name === 'lever') {
            const bb = LEVER_BASE16[at] ?? LEVER_BASE16[0], sk = (LEVER_STICK16[at] ?? LEVER_STICK16[0])[on ? 1 : 0];
            const darkTile = tiles[ID.deepslate]?.[0] ?? tiles[id][3];
            emitBox(x, y, z, bb[0], bb[1], bb[2], bb[3], bb[4], bb[5], tiles[id][3], sky, blk);
            if (at === 0) emitBox(x, y, z, 6.8, 2.6, 5.2, 9.2, 3.3, 10.8, darkTile, sky, blk);
            emitBox(x, y, z, sk[0], sk[1], sk[2], sk[3], sk[4], sk[5], tiles[id][0], sky, blk, sk[6] === 1 ? STICK_UP : STICK_DOWN, false, sk[6], sk[7], sk[8]);
          } else if (b.name.endsWith('_button')) {
            const bb = BUTTON16[at] ?? BUTTON16[0];
            const dx = on ? (at === 1 ? -1 : at === 2 ? 1 : 0) : 0;
            const dy = on ? (at === 5 ? 1 : at === 0 ? -1 : 0) : 0;
            const dz = on ? (at === 3 ? -1 : at === 4 ? 1 : 0) : 0;
            emitBox(x, y, z, bb[0] + dx, bb[1] + dy, bb[2] + dz, bb[3] + dx, bb[4] + dy, bb[5] + dz, tiles[id][0], sky, blk);
          } else {
            const tb = TORCH16[at] ?? TORCH16[0];
            emitBox(x, y, z, tb[0], tb[1], tb[2], tb[3], tb[4], tb[5], tiles[id][0], sky, blk, STICK_UP, false, tb[6], tb[7], tb[8]);
            if (at === 0) {
              const flameTile = tiles[b.name.includes('redstone') ? ID.redstone_block : b.name.includes('soul') ? ID.sea_lantern : ID.shroomlight]?.[0] ?? tiles[id][0];
              const tipTile = tiles[b.name.includes('soul') ? ID.diamond_block : ID.gold_block]?.[0] ?? flameTile;
              emitBox(x, y, z, 6.7, 7.8, 6.7, 9.3, 10.2, 9.3, flameTile, sky, 1);
              emitBox(x, y, z, 7.2, 10.2, 7.2, 8.8, 11.0, 8.8, tipTile, sky, 1);
            }
          }

        } else if (b.shape === 'chest') {
          const bt = tiles[id];
          const t0 = bt[localFaceForState(b, state, 4)];
          const t1 = bt[localFaceForState(b, state, 5)];
          const t2 = bt[localFaceForState(b, state, 2)];
          const t3 = bt[localFaceForState(b, state, 3)];
          const t4 = bt[localFaceForState(b, state, 0)];
          const t5 = bt[localFaceForState(b, state, 1)];
          const facing = state & 3;
          const isEnder = b.name === 'ender_chest';
          let joinNegX = false, joinPosX = false, joinNegZ = false, joinPosZ = false;
          if (!isEnder) {
            const isSameChest = (c: number) => c !== 0 && (c & 4095) === id && (((c >>> 12) & 3) === facing);
            if ((facing & 1) === 0) {
              if (isSameChest(padded[lIdx - 1])) joinNegX = true;
              else if (isSameChest(padded[lIdx + 1])) joinPosX = true;
            } else {
              if (isSameChest(padded[lIdx - 18])) joinNegZ = true;
              else if (isSameChest(padded[lIdx + 18])) joinPosZ = true;
            }
          }
          const cx0 = joinNegX ? 0 : 1 / 16, cx1 = joinPosX ? 1 : 15 / 16;
          const cz0 = joinNegZ ? 0 : 1 / 16, cz1 = joinPosZ ? 1 : 15 / 16;
          const emitChestPart = (py0: number, py1: number, uv0: number, uv1: number) => {
            const x0 = x + cx0, y0 = y + py0 / 16, z0 = z + cz0, x1 = x + cx1, y1 = y + py1 / 16, z1 = z + cz1;
            if (!joinPosZ) {
              out.pushQuad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1, 1, 1, t0, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
              out.uvRect(0, uv0, 1, uv1);
            }
            if (!joinNegZ) {
              out.pushQuad(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0, 0, -1, 1, 1, t1, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
              out.uvRect(0, uv0, 1, uv1);
            }
            out.pushQuad(x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0, 1, 0, 1, 1, t2, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(0, 0, 1, 1);
            out.pushQuad(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0, 1, 1, t3, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(0, 0, 1, 1);
            if (!joinPosX) {
              out.pushQuad(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, 1, 0, 0, 1, 1, t4, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
              out.uvRect(0, uv0, 1, uv1);
            }
            if (!joinNegX) {
              out.pushQuad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1, 0, 0, 1, 1, t5, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
              out.uvRect(0, uv0, 1, uv1);
            }
          };
          emitChestPart(0, 9.4, 0, 9.4 / 14);
          const seamTile = tiles[isEnder ? ID.obsidian : ID.dark_oak_planks]?.[0] ?? bt[3];
          emitBox(x, y, z, joinNegX ? 0 : 1.5, 9.4, joinNegZ ? 0 : 1.5, joinPosX ? 16 : 14.5, 10.2, joinPosZ ? 16 : 14.5, seamTile, sky, blk);
          if (_chestOpenProgress <= 0.001) {
            emitChestPart(10.2, 14, 10.2 / 14, 1);
          } else {
            const ang = _chestOpenProgress * (Math.PI * 0.42);
            const cosA = Math.cos(ang), sinA = Math.sin(ang);
            const hy = y + 10.2 / 16;
            const hz = facing === 0 ? z + 1 / 16 : facing === 2 ? z + 15 / 16 : z + 0.5;
            const hx = facing === 1 ? x + 15 / 16 : facing === 3 ? x + 1 / 16 : x + 0.5;
            const rotPt = (px: number, py: number, pz: number): [number, number, number] => {
              const dy = py - hy;
              if (facing === 0 || facing === 2) {
                const dz = pz - hz;
                const s = facing === 0 ? 1 : -1;
                return [px, hy + dy * cosA + s * dz * sinA, hz + dz * cosA - s * dy * sinA];
              } else {
                const dx = px - hx;
                const s = facing === 3 ? 1 : -1;
                return [hx + dx * cosA - s * dy * sinA, hy + dy * cosA + s * dx * sinA, pz];
              }
            };
            const lxA = x + cx0, lxB = x + cx1, lzA = z + cz0, lzB = z + cz1, lyA = hy, lyB = y + 14 / 16;
            const pushRotFace = (p0: [number,number,number], p1: [number,number,number], p2: [number,number,number], p3: [number,number,number], nx: number, ny: number, nz: number, tile: number, u0: number, v0: number, u1: number, v1: number) => {
              const q0 = rotPt(...p0), q1 = rotPt(...p1), q2 = rotPt(...p2), q3 = rotPt(...p3);
              out.pushQuad(q0[0], q0[1], q0[2], q1[0], q1[1], q1[2], q2[0], q2[1], q2[2], q3[0], q3[1], q3[2], nx, ny, nz, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
              out.uvRect(u0, v0, u1, v1);
            };
            if (!joinPosZ) pushRotFace([lxA, lyA, lzB], [lxB, lyA, lzB], [lxB, lyB, lzB], [lxA, lyB, lzB], 0, 0, 1, t0, 0, 10.2 / 14, 1, 1);
            if (!joinNegZ) pushRotFace([lxB, lyA, lzA], [lxA, lyA, lzA], [lxA, lyB, lzA], [lxB, lyB, lzA], 0, 0, -1, t1, 0, 10.2 / 14, 1, 1);
            pushRotFace([lxA, lyB, lzB], [lxB, lyB, lzB], [lxB, lyB, lzA], [lxA, lyB, lzA], 0, 1, 0, t2, 0, 0, 1, 1);
            pushRotFace([lxA, lyA, lzA], [lxB, lyA, lzA], [lxB, lyA, lzB], [lxA, lyA, lzB], 0, -1, 0, t3, 0, 0, 1, 1);
            if (!joinPosX) pushRotFace([lxB, lyA, lzB], [lxB, lyA, lzA], [lxB, lyB, lzA], [lxB, lyB, lzB], 1, 0, 0, t4, 0, 10.2 / 14, 1, 1);
            if (!joinNegX) pushRotFace([lxA, lyA, lzA], [lxA, lyA, lzB], [lxA, lyB, lzB], [lxA, lyB, lzA], -1, 0, 0, t5, 0, 10.2 / 14, 1, 1);
          }
          const latchTile = tiles[isEnder ? ID.gold_block : ID.iron_block]?.[0] ?? bt[0];
          const eyeCoreTile = tiles[ID.emerald_block]?.[0] ?? latchTile;
          if (isEnder) {
            emitBox(x, y, z, 2, 14, 2, 14, 14.5, 14, bt[2], sky, blk);
          }
          const lx0 = joinNegX ? 0 : joinPosX ? 15 : 7;
          const lx1 = joinNegX ? 1 : joinPosX ? 16 : 9;
          const lz0 = joinNegZ ? 0 : joinPosZ ? 15 : 7;
          const lz1 = joinNegZ ? 1 : joinPosZ ? 16 : 9;
          if (facing === 0) {
            emitBox(x, y, z, lx0, 7, 15, lx1, 11, 16, latchTile, sky, blk);
            if (isEnder) emitBox(x, y, z, 7.4, 7.8, 15.3, 8.6, 10.2, 16.2, eyeCoreTile, sky, 1);
            else if (b.name === 'trapped_chest') emitBox(x, y, z, joinNegX ? 0 : lx0 - 0.6, 6.5, 15.05, joinPosX ? 16 : lx1 + 0.6, 11.5, 15.5, tiles[ID.redstone_block]?.[0] ?? latchTile, sky, 1);
          } else if (facing === 1) {
            emitBox(x, y, z, 0, 7, lz0, 1, 11, lz1, latchTile, sky, blk);
            if (isEnder) emitBox(x, y, z, -0.2, 7.8, 7.4, 0.7, 10.2, 8.6, eyeCoreTile, sky, 1);
            else if (b.name === 'trapped_chest') emitBox(x, y, z, 0.5, 6.5, joinNegZ ? 0 : lz0 - 0.6, 0.95, 11.5, joinPosZ ? 16 : lz1 + 0.6, tiles[ID.redstone_block]?.[0] ?? latchTile, sky, 1);
          } else if (facing === 2) {
            emitBox(x, y, z, lx0, 7, 0, lx1, 11, 1, latchTile, sky, blk);
            if (isEnder) emitBox(x, y, z, 7.4, 7.8, -0.2, 8.6, 10.2, 0.7, eyeCoreTile, sky, 1);
            else if (b.name === 'trapped_chest') emitBox(x, y, z, joinNegX ? 0 : lx0 - 0.6, 6.5, 0.5, joinPosX ? 16 : lx1 + 0.6, 11.5, 0.95, tiles[ID.redstone_block]?.[0] ?? latchTile, sky, 1);
          } else {
            emitBox(x, y, z, 15, 7, lz0, 16, 11, lz1, latchTile, sky, blk);
            if (isEnder) emitBox(x, y, z, 15.3, 7.8, 7.4, 16.2, 10.2, 8.6, eyeCoreTile, sky, 1);
            else if (b.name === 'trapped_chest') emitBox(x, y, z, 15.05, 6.5, joinNegZ ? 0 : lz0 - 0.6, 15.5, 11.5, joinPosZ ? 16 : lz1 + 0.6, tiles[ID.redstone_block]?.[0] ?? latchTile, sky, 1);
          }
        } else if (b.shape === 'stairs') {
          const dir = state & 3, upside = (state & 4) !== 0;
          const yb0 = upside ? 0.5 : 0, yb1 = upside ? 1 : 0.5;
          const ys0 = upside ? 0 : 0.5, ys1 = upside ? 0.5 : 1;
          const sBoxes: [number, number, number, number, number, number][] = [[0, yb0, 0, 1, yb1, 1]];
          const stairDirAt = (c: number): number => {
            if (!c) return -1;
            const nb = blocks[c & 4095];
            if (!nb || nb.shape !== 'stairs') return -1;
            const ns = (c >>> 12) & 15;
            if (((ns & 4) !== 0) !== upside) return -1;
            return ns & 3;
          };
          const dN = stairDirAt(padded[lIdx - 18]), dS = stairDirAt(padded[lIdx + 18]);
          const dW = stairDirAt(padded[lIdx - 1]), dE = stairDirAt(padded[lIdx + 1]);
          if (dir === 0) {
            if (dS === 1) sBoxes.push([0.5, ys0, 0, 1, ys1, 0.5]);
            else if (dS === 3) sBoxes.push([0, ys0, 0, 0.5, ys1, 0.5]);
            else {
              sBoxes.push([0, ys0, 0, 1, ys1, 0.5]);
              if (dN === 1) sBoxes.push([0.5, ys0, 0.5, 1, ys1, 1]);
              else if (dN === 3) sBoxes.push([0, ys0, 0.5, 0.5, ys1, 1]);
            }
          } else if (dir === 2) {
            if (dN === 1) sBoxes.push([0.5, ys0, 0.5, 1, ys1, 1]);
            else if (dN === 3) sBoxes.push([0, ys0, 0.5, 0.5, ys1, 1]);
            else {
              sBoxes.push([0, ys0, 0.5, 1, ys1, 1]);
              if (dS === 1) sBoxes.push([0.5, ys0, 0, 1, ys1, 0.5]);
              else if (dS === 3) sBoxes.push([0, ys0, 0, 0.5, ys1, 0.5]);
            }
          } else if (dir === 1) {
            if (dW === 0) sBoxes.push([0.5, ys0, 0, 1, ys1, 0.5]);
            else if (dW === 2) sBoxes.push([0.5, ys0, 0.5, 1, ys1, 1]);
            else {
              sBoxes.push([0.5, ys0, 0, 1, ys1, 1]);
              if (dE === 0) sBoxes.push([0, ys0, 0, 0.5, ys1, 0.5]);
              else if (dE === 2) sBoxes.push([0, ys0, 0.5, 0.5, ys1, 1]);
              else if (dN === 0) sBoxes.push([0, ys0, 0, 0.5, ys1, 0.5]);
            }
          } else {
            if (dE === 0) sBoxes.push([0, ys0, 0, 0.5, ys1, 0.5]);
            else if (dE === 2) sBoxes.push([0, ys0, 0.5, 0.5, ys1, 1]);
            else {
              sBoxes.push([0, ys0, 0, 0.5, ys1, 1]);
              if (dW === 0) sBoxes.push([0.5, ys0, 0, 1, ys1, 0.5]);
              else if (dW === 2) sBoxes.push([0.5, ys0, 0.5, 1, ys1, 1]);
            }
          }
          const bt = tiles[id];
          const t0 = bt[localFaceForState(b, state, 4)], t1 = bt[localFaceForState(b, state, 5)];
          const t2 = bt[localFaceForState(b, state, 2)], t3 = bt[localFaceForState(b, state, 3)];
          const t4 = bt[localFaceForState(b, state, 0)], t5 = bt[localFaceForState(b, state, 1)];
          for (let bi = 0; bi < sBoxes.length; bi++) {
            const box = sBoxes[bi];
            const bx0 = box[0], by0 = box[1], bz0 = box[2], bx1 = box[3], by1 = box[4], bz1 = box[5];
            const x0 = x + bx0, y0 = y + by0, z0 = z + bz0, x1 = x + bx1, y1 = y + by1, z1 = z + bz1;
            const uLen = bx1 - bx0, vLen = by1 - by0, wLen = bz1 - bz0;
            const sAo = bi >= 1 ? 1 : 0;
            out.pushQuad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1, uLen, vLen, t0, sAo, sAo, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bx0, by0, bx1, by1);
            out.pushQuad(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0, 0, -1, uLen, vLen, t1, sAo, sAo, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(1 - bx1, by0, 1 - bx0, by1);
            out.pushQuad(x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0, 1, 0, uLen, wLen, t2, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bx0, 1 - bz1, bx1, 1 - bz0);
            out.pushQuad(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0, uLen, wLen, t3, 1, 1, 1, 1, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bx0, bz0, bx1, bz1);
            out.pushQuad(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, 1, 0, 0, wLen, vLen, t4, sAo, sAo, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(1 - bz1, by0, 1 - bz0, by1);
            out.pushQuad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1, 0, 0, wLen, vLen, t5, sAo, sAo, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bz0, by0, bz1, by1);
          }
        } else if (b.shape === 'piston_head') {
          const woodTile = tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          const cobbleTile = tiles[ID.cobblestone]?.[0] ?? woodTile;
          const boxes = modelBoxes(b, state);
          for (let bi = 0; bi < boxes.length; bi++) {
            const bx = boxes[bi];
            emitBox(x, y, z, bx[0] * 16, bx[1] * 16, bx[2] * 16, bx[3] * 16, bx[4] * 16, bx[5] * 16, woodTile, sky, blk);
          }
          if ((state & 7) === 4) {
            emitBox(x, y, z, 1, 10.8, 1, 15, 12.0, 15, cobbleTile, sky, blk);
            emitBox(x, y, z, 5, 0, 5, 11, 4, 11, cobbleTile, sky, blk);
          }
        } else {
          if (b.shape === 'trapdoor' && !(state & 8)) {
            const tdT = tiles[id][2];
            const ym = y + ((state & 4) ? 14.5 : 1.5) / 16;
            out.pushQuad(x, ym, z + 1, x + 1, ym, z + 1, x + 1, ym, z, x, ym, z, 0, 1, 0, 1, 1, tdT, 1, 1, 1, 1, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r * 0.88, g * 0.88, bl * 0.88, false, false);
            out.uvRect(0, 0, 1, 1);
          }
          const boxes = modelBoxes(b, state);
          const bt = tiles[id];
          const t0 = bt[localFaceForState(b, state, 4)];
          const t1 = bt[localFaceForState(b, state, 5)];
          const t2 = bt[localFaceForState(b, state, 2)];
          const t3 = bt[localFaceForState(b, state, 3)];
          const t4 = bt[localFaceForState(b, state, 0)];
          const t5 = bt[localFaceForState(b, state, 1)];
          for (let bi = 0; bi < boxes.length; bi++) {
            const box = boxes[bi];
            const bx0 = box[0], by0 = box[1], bz0 = box[2], bx1 = box[3], by1 = box[4], bz1 = box[5];
            const x0 = x + bx0, y0 = y + by0, z0 = z + bz0, x1 = x + bx1, y1 = y + by1, z1 = z + bz1;
            const uLen = bx1 - bx0, vLen = by1 - by0, wLen = bz1 - bz0;
            const isStairStep = b.shape === 'stairs' && bi === 1;
            const sAo = isStairStep ? 1 : 0;
            out.pushQuad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1, uLen, vLen, t0, sAo, sAo, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bx0, by0, bx1, by1);
            out.pushQuad(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0, 0, -1, uLen, vLen, t1, sAo, sAo, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(1 - bx1, by0, 1 - bx0, by1);
            out.pushQuad(x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0, 1, 0, uLen, wLen, t2, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bx0, 1 - bz1, bx1, 1 - bz0);
            out.pushQuad(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0, uLen, wLen, t3, 1, 1, 1, 1, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bx0, bz0, bx1, bz1);
            out.pushQuad(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, 1, 0, 0, wLen, vLen, t4, sAo, sAo, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(1 - bz1, by0, 1 - bz0, by1);
            out.pushQuad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1, 0, 0, wLen, vLen, t5, sAo, sAo, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bz0, by0, bz1, by1);
          }
        }
      }
    }
  }
}

// ===================================================================================================================
// Fluids — a port of Java 1.21 LiquidBlockRenderer.tesselate: per-corner surface heights (calculateAverageHeight with the
// ×10 weight for near-full neighbours), 8/9-high sources, full-height columns under the same fluid, faces culled against
// the same fluid / opaque blocks, and FlowingFluid.getFlow for the texture direction. Flat, still, uniformly lit surfaces
// (open sea, lava lakes) are greedy-merged so the vertex count stays close to the old one.
// Vertex layout of the fluid mesh: color = (flowX·½+½, flowZ·½+½, shore), wind = depth below the surface (0‥1),
// aLight = smooth (sky, block) light, tile = 0 water / 1 lava.
// ===================================================================================================================
const fFlow: [number, number, number] = [0, 0, 0];
const topKeyBuf = new Float64Array(256).fill(-1);   // always back to −1 after each layer's merge
const FC = new Float32Array(12), FW = new Float32Array(4), FL = new Float32Array(8), FU = new Float32Array(4);
let wcFn: ((lx: number, lz: number) => number) | undefined;
let wcStamp = 1;
const wcCache = new Int32Array(18 * 18), wcCacheStamp = new Int32Array(18 * 18);
function colAt(lx: number, lz: number): number {
  if (!wcFn) return 0x3f76e4;
  const i = (lz + 1) * 18 + lx + 1;
  if (wcCacheStamp[i] !== wcStamp) { wcCache[i] = wcFn(lx, lz); wcCacheStamp[i] = wcStamp; }
  return wcCache[i];
}
/** Water colour at a vertex: the average of the four columns sharing it, packed back into 0xRRGGBB (stored in uv.x). */
function vertexWater(vx: number, vz: number): number {
  if (!wcFn) return 0x3f76e4;
  const a = colAt(vx - 1, vz - 1), b = colAt(vx, vz - 1), c = colAt(vx - 1, vz), d = colAt(vx, vz);
  if (a === b && b === c && c === d) return a;
  const ch = (sh: number) => Math.round((((a >> sh) & 255) + ((b >> sh) & 255) + ((c >> sh) & 255) + ((d >> sh) & 255)) / 4);
  return (ch(16) << 16) | (ch(8) << 8) | ch(0);
}

function fluidH(padded: Uint16Array, dimsY: number, f: number, x: number, ly: number, z: number): number {
  const c = getCellAt(padded, dimsY, x, ly, z), id = c & 4095;
  if (id === f) return (getCellAt(padded, dimsY, x, ly + 1, z) & 4095) === f ? 1 : fluidOwnHeight((c >>> 12) & 15);
  if (f === (ID.water | 0) && isCellWaterlogged(c)) {
    const up = getCellAt(padded, dimsY, x, ly + 1, z);
    return (up & 4095) === f || isCellWaterlogged(up) ? 1 : fluidOwnHeight(0);
  }
  return LUT_SOLID[id] === 1 ? -1 : 0;
}
let avgSum = 0, avgW = 0;
const addW = (h: number) => { if (h >= 0.8) { avgSum += h * 10; avgW += 10; } else if (h >= 0) { avgSum += h; avgW += 1; } };
function avgHeight(padded: Uint16Array, dimsY: number, f: number, h0: number, ha: number, hb: number, x: number, ly: number, z: number) {
  if (ha >= 1 || hb >= 1) return 1;
  avgSum = 0; avgW = 0;
  if (ha > 0 || hb > 0) { const hd = fluidH(padded, dimsY, f, x, ly, z); if (hd >= 1) return 1; addW(hd); }
  addW(h0); addW(ha); addW(hb);
  return avgW > 0 ? avgSum / avgW : 0;
}
/** Packed light (sky << 4 | block) of a cell, 0 outside the column. */
const lpAt = (x: number, ly: number, z: number) => lp(lightIdx(x, ly, z));
const maxLp = (a: number, b: number) => (Math.max(a >> 4, b >> 4) << 4) | Math.max(a & 15, b & 15);
/** Smooth light of a top-face corner: the 4 cells above the surface that share it, zeros replaced by the centre. */
function cornerLight(c: number, x: number, ly: number, z: number, dx: number, dz: number) {
  let a = lpAt(x + dx, ly, z), b = lpAt(x, ly, z + dz), d = lpAt(x + dx, ly, z + dz);
  if (a === 0) a = c; if (b === 0) b = c; if (d === 0) d = c;
  return ((c >> 4) + (a >> 4) + (b >> 4) + (d >> 4)) * 64 + (c & 15) + (a & 15) + (b & 15) + (d & 15);   // sky·64 + block, sums 0‥60
}
function landAt(padded: Uint16Array, dimsY: number, waterId: number, lavaId: number, vx: number, ly: number, vz: number) {
  for (let dz = -1; dz <= 0; dz++) for (let dx = -1; dx <= 0; dx++) {
    const c = getCellAt(padded, dimsY, vx + dx, ly, vz + dz) & 4095;
    if (c !== 0 && c !== waterId && c !== lavaId && LUT_SOLID[c] === 1) return 1;
  }
  return 0;
}

function pushFluidQuad(out: MeshBuf, P: number[], nx: number, ny: number, nz: number, tile: number) {
  for (let k = 0; k < 4; k++) FU[k] = tile ? 0 : vertexWater(P[k * 3], P[k * 3 + 2]);
  // Split along the diagonal whose corners differ least (depth, then height) so shallow-water gradients do not zig-zag.
  const flip = Math.abs(FW[0] - FW[2]) + Math.abs(P[1] - P[7]) > Math.abs(FW[1] - FW[3]) + Math.abs(P[4] - P[10]);
  out.pushQuad(P[0], P[1], P[2], P[3], P[4], P[5], P[6], P[7], P[8], P[9], P[10], P[11], nx, ny, nz, 1, 1, tile,
    0, 0, 0, 0, FL[0], FL[2], FL[4], FL[6], FL[1], FL[3], FL[5], FL[7], FW[0], flip, 1, 1, 1, false, false);
  out.patchLast(FC, FW, FU);
}

function meshFluids(padded: Uint16Array, dimsY: number, out: MeshBuf) {
  const minY = MIN_Y | 0, waterId = ID.water | 0, lavaId = ID.lava | 0;
  const P: number[] = new Array(12).fill(0);
  const cellW = (xx: number, yy: number, zz: number) => getCellAt(padded, dimsY, xx, yy - minY, zz);
  const blocks = (id: number) => LUT_SOLID[id] === 1;
  for (let ly = 0; ly < dimsY; ly++) {
    const y = ly + minY;
    let anyTop = false;
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
      const idx = ly * STRIDE_Y + (z + 1) * 18 + x + 1, cell = padded[idx];
      const wl = isCellWaterlogged(cell);
      if (LUT_FLUID[cell & 4095] === 0 && !wl) continue;
      const f = wl ? waterId : (cell & 4095), st = wl ? 0 : ((cell >>> 12) & 15), tile = f === lavaId ? 1 : 0;
      const up = ly + 1 < dimsY ? padded[idx + STRIDE_Y] : 0, dn = ly > 0 ? padded[idx - STRIDE_Y] : 0;
      const nN = padded[idx - 18], nS = padded[idx + 18], nW = padded[idx - 1], nE = padded[idx + 1];
      const sameFluid = (c: number) => (c & 4095) === f || (f === waterId && isCellWaterlogged(c));
      const sameUp = sameFluid(up);
      const hideN = sameFluid(nN) || LUT_CELL_OPQ[nN] === 1, hideS = sameFluid(nS) || LUT_CELL_OPQ[nS] === 1;
      const hideW = sameFluid(nW) || LUT_CELL_OPQ[nW] === 1, hideE = sameFluid(nE) || LUT_CELL_OPQ[nE] === 1;
      const hideD = sameFluid(dn) || LUT_CELL_OPQ[dn] === 1 || ly === 0;
      if ((sameUp || LUT_CELL_OPQ[up] === 1) && hideN && hideS && hideW && hideE && hideD) continue;     // enclosed cell: nothing visible

      // ---- corner heights (NW = x,z · NE = x+1,z · SE = x+1,z+1 · SW = x,z+1)
      let hNW = 1, hNE = 1, hSE = 1, hSW = 1;
      if (!sameUp) {
        const h = fluidOwnHeight(st);
        const hN = fluidH(padded, dimsY, f, x, ly, z - 1), hS = fluidH(padded, dimsY, f, x, ly, z + 1);
        const hW = fluidH(padded, dimsY, f, x - 1, ly, z), hE = fluidH(padded, dimsY, f, x + 1, ly, z);
        hNE = avgHeight(padded, dimsY, f, h, hN, hE, x + 1, ly, z - 1);
        hNW = avgHeight(padded, dimsY, f, h, hN, hW, x - 1, ly, z - 1);
        hSE = avgHeight(padded, dimsY, f, h, hS, hE, x + 1, ly, z + 1);
        hSW = avgHeight(padded, dimsY, f, h, hS, hW, x - 1, ly, z + 1);
      }
      fluidFlow(cellW, x, y, z, blocks, fFlow);
      const fx = fFlow[0], fz = fFlow[2];
      const own = lp(idx);

      // ---- top surface (not under an opaque ceiling: that face can only be seen from inside the fluid)
      if (!sameUp && LUT_CELL_OPQ[up] !== 1) {
        const c = maxLp(own, ly + 1 < dimsY ? lp(idx + STRIDE_Y) : 0xf0);
        const flat = hNW === hNE && hNE === hSE && hSE === hSW && fx === 0 && fz === 0;
        const l0 = cornerLight(c, x, ly + 1, z, -1, -1), l1 = cornerLight(c, x, ly + 1, z, -1, 1), l2 = cornerLight(c, x, ly + 1, z, 1, 1), l3 = cornerLight(c, x, ly + 1, z, 1, -1);
        const d0 = tile ? 1 : cornerDepthAt(padded, dimsY, waterId, lavaId, x, ly, z), d1 = tile ? 1 : cornerDepthAt(padded, dimsY, waterId, lavaId, x, ly, z + 1);
        const d2 = tile ? 1 : cornerDepthAt(padded, dimsY, waterId, lavaId, x + 1, ly, z + 1), d3 = tile ? 1 : cornerDepthAt(padded, dimsY, waterId, lavaId, x + 1, ly, z);
        const s0 = tile ? 0 : landAt(padded, dimsY, waterId, lavaId, x, ly, z);
        const s1 = tile ? 0 : landAt(padded, dimsY, waterId, lavaId, x, ly, z + 1);
        const s2 = tile ? 0 : landAt(padded, dimsY, waterId, lavaId, x + 1, ly, z + 1);
        const s3 = tile ? 0 : landAt(padded, dimsY, waterId, lavaId, x + 1, ly, z);
        if (flat && l0 === l1 && l1 === l2 && l2 === l3 && d0 === d1 && d1 === d2 && d2 === d3 && !s0 && !s1 && !s2 && !s3) {
          topKeyBuf[z * 16 + x] = ((Math.round(hNW * 90000) * 32 + Math.round(d0 * 24)) * 2 + tile) * 4096 + l0;        // merged below
          anyTop = true;
        } else {
          const ty = ly + minY - 0.001;
          P[0] = x; P[1] = ty + hNW; P[2] = z; P[3] = x; P[4] = ty + hSW; P[5] = z + 1;
          P[6] = x + 1; P[7] = ty + hSE; P[8] = z + 1; P[9] = x + 1; P[10] = ty + hNE; P[11] = z;
          for (let k = 0; k < 4; k++) { FC[k * 3] = fx * 0.5 + 0.5; FC[k * 3 + 1] = fz * 0.5 + 0.5; }
          FC[2] = s0; FC[5] = s1; FC[8] = s2; FC[11] = s3;
          FW[0] = d0; FW[1] = d1; FW[2] = d2; FW[3] = d3;
          setLight(0, l0); setLight(1, l1); setLight(2, l2); setLight(3, l3);
          pushFluidQuad(out, P, 0, 1, 0, tile);
        }
      }

      // ---- sides (to the surface height of each edge) and bottom
      const by = y;
      if (!hideN) emitSide(out, P, own, ly, by, tile, fx, x + 1, z, x, z, hNE, hNW, 0, -1, x, z - 1);
      if (!hideS) emitSide(out, P, own, ly, by, tile, fx, x, z + 1, x + 1, z + 1, hSW, hSE, 0, 1, x, z + 1);
      if (!hideW) emitSide(out, P, own, ly, by, tile, fx, x, z, x, z + 1, hNW, hSW, -1, 0, x - 1, z);
      if (!hideE) emitSide(out, P, own, ly, by, tile, fx, x + 1, z + 1, x + 1, z, hSE, hNE, 1, 0, x + 1, z);
      if (!hideD) {
        const L = maxLp(own, lpAt(x, ly - 1, z));
        P[0] = x; P[1] = by; P[2] = z; P[3] = x + 1; P[4] = by; P[5] = z;
        P[6] = x + 1; P[7] = by; P[8] = z + 1; P[9] = x; P[10] = by; P[11] = z + 1;
        for (let k = 0; k < 4; k++) { FC[k * 3] = 0.5; FC[k * 3 + 1] = 0.5; FC[k * 3 + 2] = 0; FW[k] = 1; FL[k * 2] = (L >> 4) / 15; FL[k * 2 + 1] = (L & 15) / 15; }
        pushFluidQuad(out, P, 0, -1, 0, tile);
      }
    }
    if (!anyTop) continue;
    // ---- greedy merge of flat, still, evenly lit surfaces on this layer
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; ) {
      const key = topKeyBuf[z * 16 + x];
      if (key < 0) { x++; continue; }
      let w = 1, h = 1;
      while (x + w < 16 && topKeyBuf[z * 16 + x + w] === key) w++;
      outer: for (; z + h < 16; h++) for (let k = 0; k < w; k++) if (topKeyBuf[(z + h) * 16 + x + k] !== key) break outer;
      for (let dz = 0; dz < h; dz++) for (let k = 0; k < w; k++) topKeyBuf[(z + dz) * 16 + x + k] = -1;
      const hi = Math.floor(key / 4096), tile = hi % 2, dep = Math.floor(hi / 2) % 32 / 24, hh = Math.floor(hi / 64) / 90000, l = key % 4096;
      const ty = ly + minY - 0.001 + hh;
      P[0] = x; P[1] = ty; P[2] = z; P[3] = x; P[4] = ty; P[5] = z + h;
      P[6] = x + w; P[7] = ty; P[8] = z + h; P[9] = x + w; P[10] = ty; P[11] = z;
      for (let k = 0; k < 4; k++) { FC[k * 3] = 0.5; FC[k * 3 + 1] = 0.5; FC[k * 3 + 2] = 0; FW[k] = dep; }
      setLight(0, l); setLight(1, l); setLight(2, l); setLight(3, l);
      pushFluidQuad(out, P, 0, 1, 0, tile);
      x += w;
    }
  }
}
/** One side face from the bottom of the cell up to the edge heights ha / hb; it streams downwards in the shader. */
function emitSide(out: MeshBuf, P: number[], own: number, ly: number, by: number, tile: number, fx: number,
  ax: number, az: number, bx: number, bz: number, ha: number, hb: number, nx: number, nz: number, lx: number, lz: number) {
  if (ha <= 0 && hb <= 0) return;
  const L = maxLp(own, lpAt(lx, ly, lz));
  P[0] = ax; P[1] = by; P[2] = az; P[3] = bx; P[4] = by; P[5] = bz;
  P[6] = bx; P[7] = by + hb; P[8] = bz; P[9] = ax; P[10] = by + ha; P[11] = az;
  // A side face is seen through about a block of water at most: thin falling water stays light and see-through.
  for (let k = 0; k < 4; k++) { FC[k * 3] = fx * 0.5 + 0.5; FC[k * 3 + 1] = 0.5; FC[k * 3 + 2] = 0; FW[k] = 0.3; FL[k * 2] = (L >> 4) / 15; FL[k * 2 + 1] = (L & 15) / 15; }
  pushFluidQuad(out, P, nx, 0, nz, tile);
}
/** Writes corner `k` of FL from a 0‥60 light sum pair (sky·16 + block). */
function setLight(k: number, sums: number) { FL[k * 2] = (sums >> 6) / 60; FL[k * 2 + 1] = (sums & 63) / 60; }

/**
 * `waterColor(lx, lz)` (optional) returns the 0xRRGGBB water colour of a column (lx, lz ∈ −1‥16) — Java biome water colours;
 * each fluid vertex averages the four columns around it (a small biome blend). Without it, the default #3F76E4 is used.
 */
let _chestOpenProgress = 0;
let _subFlagBuilt = false;
const _subFlags = new Uint8Array(4096);
function ensureSubFlags() {
  if (_subFlagBuilt) return;
  _subFlagBuilt = true;
  for (let i = 1; i < 4096; i++) {
    const bd = blocks[i];
    if (!bd) continue;
    if (bd.name === 'candle_cake' || bd.name.endsWith('_candle_cake')) _subFlags[i] |= 1;
    else if (bd.name === 'flower_pot') _subFlags[i] |= 2;
    else if (bd.name.startsWith('potted_')) _subFlags[i] |= 6;
  }
}
export function setChestOpenProgress(v: number) { _chestOpenProgress = Math.max(0, Math.min(1, v)); }
export function getChestOpenProgress(): number { return _chestOpenProgress; }

export function meshChunk(padded: Uint16Array, maxY: number, tiles: number[][], tint?: Float32Array, waterColor?: (lx: number, lz: number) => number): { solid: MeshData; water: MeshData } {
  ensureLuts();
  computeLights(padded, maxY);

  const dimsY = Math.min(HEIGHT | 0, (maxY | 0) - (MIN_Y | 0));
  reusableOut.reset();
  reusableWater.reset();

  subEmissive = 0;
  waterIdK = ID.water | 0;
  meshGreedy(padded, dimsY, tiles, tint, reusableOut, reusableWater);
  meshSubBlocks(padded, dimsY, tiles, tint, reusableOut);
  subEmissive = 0;
  wcFn = waterColor; wcStamp++;
  meshFluids(padded, dimsY, reusableWater);
  wcFn = undefined;

  return { solid: reusableOut.pack(), water: reusableWater.pack() };
}
