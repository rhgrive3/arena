// Underground generation modelled on Minecraft Java Edition 1.18–1.21 (Minecraft Wiki "Cave" & "Aquifer" specifications):
//  * NoiseRouter 3D Caves – Cheese caves (`cave_cheese` + `cave_layer`) with vertical speleothem noise pillars (`pillar`,
//                           `pillar_rareness`, `pillar_thickness`), dual-system Spaghetti 3D tunnels (`spaghetti_3d_1`,
//                           `spaghetti_3d_2`, `spaghetti_3d_rarity`, `spaghetti_3d_thickness`, `spaghetti_roughness`),
//                           horizontal elevation-following Spaghetti 2D galleries (`spaghetti_2d`, `spaghetti_2d_elevation`),
//                           surface-breaching Cave Entrances (`cave_entrance`), and narrow squiggly Noodle caves (`noodle`,
//                           `noodle_thickness`, `noodle_ridge_a`, `noodle_ridge_b` in Y = -60..30).
//  * World Carvers        – Seeded multi-chunk procedural worm carvers (`CaveWorldCarver`: `cave` in Y = -56..180 &
//                           `cave_extra_underground` in Y = -56..47):
//                             - 25% (1/4) chance of a Circular Main Room (`1..14` blocks high, `5..15` diameter) connecting
//                               `1..4` trunks (`85..112` steps long, each with `0` or `2` perpendicular branches);
//                             - 75% (3/4) chance of an I-shaped or T-shaped cave (`1` trunk of `85..112` steps with `0` or `2`
//                               perpendicular branches, no main room);
//                             - Flattened floors (`floorLevel = -0.7`), rounded ceilings, never cutting surface `snow_block`.
//                           Plus `CanyonWorldCarver` (ravines with Y-stratified wall ledges) and `NetherWorldCarver`
//                           (`nether_cave` in Y = 0..126 with `2..8` high main rooms and taller vertical `yScale`).
//  * Aquifers             – 16×12×16 jittered Voronoi cells (`NoiseBasedAquifer`), each owning a quantised fluid level and
//                           fluid type (water, or lava below Y = -10 / global lava below Y = -54), stone/deepslate barrier
//                           sealing wherever aquifer fluid borders adjacent cave air, and occasional underwater `magma_block`s.
//  * Ore veins            – `ore_veininess` selects copper (Y 0..50, granite gangue + raw copper blocks) or iron (Y -60..-8,
//                           tuff gangue + raw iron blocks) sheets carved by `vein_ridged` and `vein_gap`.
//  * Cave biomes          – 3D pockets of `lush_caves`, `dripstone_caves`, and `deep_dark` driven by E / H / C and 3D noise.
import { ID } from '../game/data';

export interface NoiseSrc {
  n2(x: number, z: number): number;
  n3(x: number, y: number, z: number): number;
  fbm(x: number, z: number, octaves?: number): number;
}

export const SEA_LEVEL = 62;
export const MIN_WORLD_Y = -64;
const B = ID as Record<string, number | undefined>;

function hash3(x: number, y: number, z: number, seed: number): number {
  let h = Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul((y | 0) + 0x632be5ab, 1274126177) ^ seed;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface AquiferCell { x: number; y: number; z: number; level: number; lava: boolean }

export type CaveKind = 'cheese' | 'spaghetti_3d' | 'spaghetti_2d' | 'noodle' | 'entrance' | 'carver_cave' | 'carver_canyon' | 'nether_carver';

export interface CarverSphere {
  x: number;
  y: number;
  z: number;
  radXZ: number;
  radY: number;
  floorLevel: number;
  kind: 'carver_cave' | 'carver_canyon' | 'nether_carver';
  canyonSeed?: number;
}

export interface CarverSystem {
  originChunkX: number;
  originChunkZ: number;
  startX: number;
  startY: number;
  startZ: number;
  kind: 'carver_cave' | 'carver_canyon' | 'nether_carver';
  /** True for the 25% Circular Main Room variant; false for the 75% I-shaped / T-shaped variant. */
  hasRoom: boolean;
  /** Number of primary trunks (`1..4` when `hasRoom === true`, `1` when `hasRoom === false`). */
  branches: number;
  /** Step length (`85..112`) of each primary trunk. */
  trunkLengths: number[];
  /** Number of sub-branches (`0` or `2`) spawned by each primary trunk. */
  subBranchesPerTrunk: number[];
  spheres: CarverSphere[];
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export const VEIN_THRESHOLD = 0.52;
const VEIN_K_Y = new Int32Array(20);
const VEIN_K_DY = new Float64Array(20);
const VEIN_K_V = new Float64Array(20);
for (let k = 0; k < 20; k++) {
  const y = (-64 + k * 6) * 0.0135 + 7.7;
  const fy = Math.floor(y);
  const dy = y - fy;
  VEIN_K_Y[k] = fy & 255;
  VEIN_K_DY[k] = dy;
  VEIN_K_V[k] = dy * dy * dy * (dy * (dy * 6 - 15) + 10);
}
function grad3Ug(h: number, x: number, y: number, z: number): number {
  h &= 15;
  const u = h < 8 ? x : y, v = h < 4 ? y : h === 12 || h === 14 ? x : z;
  return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
}

export class Underground {
  private cells = new Map<number, AquiferCell>();
  private carverCache = new Map<number, CarverSystem[]>();
  private netherCarverCache = new Map<number, CarverSystem[]>();

  constructor(private n: NoiseSrc, private seed: number, private surface: (x: number, z: number) => number) {}

  // ------------------------------------------------------------------ NoiseRouter 3D cave density functions
  /**
   * Vertical speleothem pillar density (`pillar`, `pillar_rareness`, `pillar_thickness` in Vanilla NoiseRouterData).
   * Positive values inside a cheese cavern stay solid rock, forming floor-to-ceiling stone/deepslate columns.
   */
  pillarDensity(x: number, y: number, z: number): number {
    // Vanilla: pillar_noise has xz_scale = 25.0, y_scale = 0.3 (strongly vertical columns)
    const rareness = 1.05 - this.n.n3(x * 0.035 + 41.2, y * 0.035, z * 0.035 - 19.8) * 0.65;
    const thickRaw = (this.n.n3(x * 0.028 - 73.1, y * 0.028, z * 0.028 + 53.4) + 1.0) * 0.58;
    const thickness = thickRaw * thickRaw * thickRaw;
    const pillar = this.n.n3(x * 0.24 + 17.5, y * 0.016, z * 0.24 - 29.3) * 2.0 - rareness;
    return pillar * thickness;
  }

  /** True when `(x, y, z)` lies inside a solid noise pillar (speleothem column) inside a cheese cavern. */
  isPillarAt(x: number, y: number, z: number): boolean {
    return this.pillarDensity(x, y, z) > 0.028;
  }

  /**
   * Stratified cave layer noise (`cave_layer` in Vanilla NoiseRouterData: `4 * layerNoise(x, y * 8, z)^2`).
   */
  caveLayer(x: number, y: number, z: number): number {
    const l = this.n.n3(x * 0.018 - 112.0, y * 0.144, z * 0.018 + 84.0);
    return 4.0 * l * l;
  }

  /**
   * Cheese cave density (`cave_cheese` + `cave_layer` in Vanilla NoiseRouterData).
   * Values > 0.52 (and not blocked by `isPillarAt`) carve wide multi-layered caverns.
   */
  cheeseDensity(x: number, y: number, z: number): number {
    if (y >= 52) return -1;
    const base = this.n.n3(x * 0.016 + 300, y * 0.028, z * 0.016 - 300);
    const layer = this.caveLayer(x, y, z);
    // Depth attenuation: widest between Y = -48..28, tapering toward Y = 48 and Y = -62
    const topFade = y > 28 ? (y - 28) * 0.012 : 0;
    const botFade = y < -56 ? (-56 - y) * 0.035 : 0;
    return base + (0.06 - layer * 0.045) - topFade - botFade;
  }

  /**
   * Dual-system Spaghetti 3D + Roughness (`spaghetti_3d_1`, `spaghetti_3d_2`, `spaghetti_3d_rarity`, `spaghetti_roughness`).
   * Returns squared cross-sectional distance; carves when `< threshold`.
   */
  spaghetti3D(x: number, y: number, z: number): { d1: number; d2: number; thresh: number } {
    const r1a = this.n.n3(x * 0.048, y * 0.065, z * 0.048);
    const r1b = this.n.n3(x * 0.044 + 90, y * 0.060, z * 0.044 + 90);
    const r2a = this.n.n3(x * 0.052 - 140, y * 0.070, z * 0.052 + 110);
    const r2b = this.n.n3(x * 0.046 + 210, y * 0.064, z * 0.046 - 170);
    const thick = 0.0046 + (this.n.n3(x * 0.018 + 63, y * 0.018, z * 0.018 - 47) + 1.0) * 0.0012;
    const rough = Math.abs(this.n.n3(x * 0.16 + 19, y * 0.16, z * 0.16 - 31)) * 0.0008;
    return {
      d1: r1a * r1a + r1b * r1b,
      d2: r2a * r2a + r2b * r2b,
      thresh: thick + rough,
    };
  }

  /**
   * Horizontal elevation-following Spaghetti 2D galleries (`spaghetti_2d`, `spaghetti_2d_elevation`, `spaghetti_2d_thickness`).
   */
  isSpaghetti2DAt(x: number, y: number, z: number, surf: number): boolean {
    if (y <= MIN_WORLD_Y + 4 || y >= Math.min(42, surf - 9)) return false;
    const modulator = this.n.n3(x * 0.015 - 190, y * 0.018, z * 0.015 + 230);
    if (modulator < 0.18) return false;
    const elev = -14 + this.n.n2(x * 0.013 - 220, z * 0.013 + 180) * 34;
    const dy = (y - elev) * 0.22;
    if (dy < -1.0 || dy > 1.0) return false;
    const ridge = Math.abs(this.n.n3(x * 0.038 + 310, y * 0.032, z * 0.038 + 70));
    const thick = 0.048 + (modulator - 0.18) * 0.025;
    return ridge + dy * dy * 0.055 < thick;
  }

  /**
   * Narrow squiggly Noodle caves (`noodle`, `noodle_thickness`, `noodle_ridge_a`, `noodle_ridge_b` in Y = -60..30).
   */
  isNoodleAt(x: number, y: number, z: number, surf: number): boolean {
    if (y < -60 || y > 30 || y >= surf - 8) return false;
    const toggle = this.n.n3(x * 0.022 - 410, y * 0.026, z * 0.022 + 290);
    // Taper at the vertical bounds Y = -60 and Y = 30
    const edgeDist = Math.min(y - -60, 30 - y);
    const fade = edgeDist < 6 ? (6 - edgeDist) * 0.04 : 0;
    if (toggle - fade <= 0.26) return false;
    const ra = Math.abs(this.n.n3(x * 0.092 + 13.4, y * 0.105, z * 0.092 - 17.8));
    const rb = Math.abs(this.n.n3(x * 0.092 - 71.2, y * 0.105, z * 0.092 + 83.6));
    const thick = 0.072 + Math.min(0.024, (toggle - 0.26) * 0.04);
    return ra + rb < thick;
  }

  /**
   * Surface-breaching Cave Entrance (`cave_entrance` in Vanilla NoiseRouterData).
   * Allows spaghetti/cheese caves to punch natural sloping mouths through dry hills and cliffs.
   */
  isCaveEntranceAt(x: number, y: number, z: number, surf: number, c0: number, t0: number): boolean {
    if (surf <= SEA_LEVEL + 3 || y < surf - 18 || y > surf) return false;
    const entRarity = this.n.n3(x * 0.021 - 88.5, y * 0.028, z * 0.021 + 44.2);
    if (entRarity < 0.38) return false;
    const depthRatio = (surf - y) / 18; // 0 at surface, 1 at surf - 18
    const thresh = 0.0024 + (entRarity - 0.38) * 0.0065 + depthRatio * 0.0018;
    return c0 * c0 + t0 * t0 < thresh;
  }

  /**
   * Combined NoiseRouter cave classifier for any `(x, y, z)` in the Overworld.
   * Returns the primary `CaveKind` that carves `(x, y, z)`, or `null` if solid rock.
   */
  sampleNoiseCave(x: number, y: number, z: number, surf: number): CaveKind | null {
    if (y <= MIN_WORLD_Y + 2 || y > surf) return null;
    const sp = this.spaghetti3D(x, y, z);
    if (y >= surf - 5) {
      const c0 = this.n.n3(x * 0.048, y * 0.065, z * 0.048);
      const t0 = this.n.n3(x * 0.044 + 90, y * 0.060, z * 0.044 + 90);
      return this.isCaveEntranceAt(x, y, z, surf, c0, t0) ? 'entrance' : null;
    }
    if (sp.d1 < (y < surf - 9 ? 0.0055 : 0.0028) || sp.d2 < (y < surf - 11 ? 0.0042 : 0.0020)) {
      return 'spaghetti_3d';
    }
    if (y < surf - 7 && this.cheeseDensity(x, y, z) > 0.54 && !this.isPillarAt(x, y, z)) {
      return 'cheese';
    }
    if (this.isSpaghetti2DAt(x, y, z, surf)) return 'spaghetti_2d';
    if (this.isNoodleAt(x, y, z, surf)) return 'noodle';
    return null;
  }

  // ------------------------------------------------------------------ Procedural World Carvers (Cave / Canyon / Nether)
  /**
   * Builds a Vanilla-accurate carver trunk (`85..112` steps) that either runs unbranched (`0` sub-branches) or splits
   * into `2` perpendicular branches (`yaw ± Math.PI * 0.5`) at `branchPoint` when `baseWidth > 1.0`.
   * Returns the number of sub-branches (`0` or `2`) spawned by this trunk.
   */
  private buildTunnel(
    spheres: CarverSphere[],
    rnd: () => number,
    startX: number,
    startY: number,
    startZ: number,
    baseWidth: number,
    yaw: number,
    pitch: number,
    stepStart: number,
    maxSteps: number,
    yScale: number,
    floorLevel: number,
    kind: 'carver_cave' | 'carver_canyon' | 'nether_carver',
    depth = 0,
  ): number {
    let x = startX, y = startY, z = startZ;
    let dYaw = 0, dPitch = 0;
    const canBranch = depth === 0 && kind !== 'carver_canyon' && baseWidth > 1.0 && rnd() < 0.55;
    const branchPoint = canBranch ? stepStart + Math.floor((maxSteps - stepStart) * (0.25 + rnd() * 0.5)) : -1;
    const steep = kind === 'carver_canyon' || rnd() < 0.167; // Vanilla: 1/6 chance of steeper pitch decay (0.92 vs 0.7)
    const pitchDecay = kind === 'carver_canyon' ? 0.75 : steep ? 0.92 : 0.7;
    const canyonSeed = kind === 'carver_canyon' ? Math.floor(rnd() * 0x7fffffff) : undefined;
    const stride = maxSteps > 64 ? 3 : 2;

    for (let step = stepStart; step < maxSteps; step++) {
      const sinStep = Math.sin((Math.PI * step) / maxSteps);
      const radXZ = 1.5 + sinStep * baseWidth;
      const radY = radXZ * yScale;
      const cosP = Math.cos(pitch), sinP = Math.sin(pitch);
      x += Math.cos(yaw) * cosP * 0.95;
      y += sinP * (kind === 'carver_canyon' ? 0.35 : 0.85);
      z += Math.sin(yaw) * cosP * 0.95;

      pitch = pitch * pitchDecay + dPitch * 0.08;
      yaw += dYaw * 0.09;
      dPitch = dPitch * 0.75 + (rnd() - rnd()) * rnd() * 2.0;
      dYaw = dYaw * 0.82 + (rnd() - rnd()) * rnd() * 4.0;

      if (step === branchPoint && depth === 0 && kind !== 'carver_canyon') {
        this.buildTunnel(spheres, rnd, x, y, z, baseWidth * (0.55 + rnd() * 0.35), yaw - Math.PI * 0.5, pitch / 3, step, maxSteps, 1.0, floorLevel, kind, 1);
        this.buildTunnel(spheres, rnd, x, y, z, baseWidth * (0.55 + rnd() * 0.35), yaw + Math.PI * 0.5, pitch / 3, step, maxSteps, 1.0, floorLevel, kind, 1);
        return 2;
      }

      if (step % stride === 0 || step === maxSteps - 1) {
        spheres.push({ x, y, z, radXZ, radY, floorLevel, kind, canyonSeed });
      }
    }
    return 0;
  }

  /**
   * Generates (and caches) all CarverSystems originating in chunk `(ocx, ocz)` for Overworld or Nether.
   */
  carverSystemsInChunk(ocx: number, ocz: number, isNether = false): CarverSystem[] {
    const cache = isNether ? this.netherCarverCache : this.carverCache;
    const key = ((ocx + 32768) & 0xffff) * 65536 + ((ocz + 32768) & 0xffff);
    const hit = cache.get(key);
    if (hit) return hit;

    const systems: CarverSystem[] = [];
    const baseSeed = (Math.imul(ocx, 341873128) ^ Math.imul(ocz, 132897987) ^ (this.seed + (isNether ? 0x9e3779b9 : 0x517cc1b7))) >>> 0;
    const rnd = mulberry32(baseSeed);

    const finalizeSystem = (
      startX: number,
      startY: number,
      startZ: number,
      kind: 'carver_cave' | 'carver_canyon' | 'nether_carver',
      hasRoom: boolean,
      branches: number,
      trunkLengths: number[],
      subBranchesPerTrunk: number[],
      spheres: CarverSphere[],
    ) => {
      if (!spheres.length) return;
      let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
      for (let i = 0; i < spheres.length; i++) {
        const s = spheres[i], r = s.radXZ + 1.5;
        if (s.x - r < minX) minX = s.x - r;
        if (s.x + r > maxX) maxX = s.x + r;
        if (s.z - r < minZ) minZ = s.z - r;
        if (s.z + r > maxZ) maxZ = s.z + r;
      }
      systems.push({
        originChunkX: ocx,
        originChunkZ: ocz,
        startX,
        startY,
        startZ,
        kind,
        hasRoom,
        branches,
        trunkLengths,
        subBranchesPerTrunk,
        spheres,
        minX,
        maxX,
        minZ,
        maxZ,
      });
    };

    if (isNether) {
      // Vanilla NetherWorldCarver (`nether_cave`): Y = 0..126, 25% Circular Main Room (2..8 blocks high, 5..15 diameter,
      // 1..4 trunks of 85..112 steps) vs 75% I-shaped / T-shaped cave (1 trunk of 85..112 steps with 0 or 2 branches).
      if (rnd() < 0.22) {
        const startX = ocx * 16 + Math.floor(rnd() * 16);
        const startY = 12 + Math.floor(rnd() * 106); // within Y = 0..126
        const startZ = ocz * 16 + Math.floor(rnd() * 16);
        const spheres: CarverSphere[] = [];
        const hasRoom = rnd() < 0.25; // Exact 1/4 probability of a Circular Main Room
        if (hasRoom) {
          const roomDiameter = 5.0 + rnd() * 10.0; // 5..15 blocks in diameter
          const roomHeight = 2.0 + rnd() * 6.0;    // 2..8 blocks high in the Nether
          spheres.push({ x: startX, y: startY, z: startZ, radXZ: roomDiameter * 0.5, radY: roomHeight * 0.5, floorLevel: -0.7, kind: 'nether_carver' });
        }
        const branches = hasRoom ? 1 + Math.floor(rnd() * 4) : 1; // 1..4 trunks from Main Room; 1 trunk for I/T-shaped
        const trunkLengths: number[] = [];
        const subBranchesPerTrunk: number[] = [];
        for (let b = 0; b < branches; b++) {
          const yaw = rnd() * Math.PI * 2;
          const pitch = (rnd() - 0.5) * 0.25;
          const width = 1.4 + rnd() * 2.0;
          const steps = 85 + Math.floor(rnd() * 28); // Exact Vanilla 85..112 steps
          const yScale = 1.0 + rnd() * 0.4;          // Higher vertical thickness in the Nether
          trunkLengths.push(steps);
          subBranchesPerTrunk.push(this.buildTunnel(spheres, rnd, startX, startY, startZ, width, yaw, pitch, 0, steps, yScale, -0.7, 'nether_carver'));
        }
        finalizeSystem(startX, startY, startZ, 'nether_carver', hasRoom, branches, trunkLengths, subBranchesPerTrunk, spheres);
      }
    } else {
      // 1. Standard (`cave`: Y = -56..180) & Extra Underground (`cave_extra_underground`: Y = -56..47) CaveWorldCarver
      const spawnCave = rnd() < 0.15;
      const spawnDeepCave = rnd() < 0.10;
      if (spawnCave || spawnDeepCave) {
        const startX = ocx * 16 + Math.floor(rnd() * 16);
        const startZ = ocz * 16 + Math.floor(rnd() * 16);
        // Vanilla: `cave_extra_underground` in Y = -56..47; `cave` in Y = -56..180 biased toward lower elevations
        const startY = spawnDeepCave
          ? -56 + Math.floor(rnd() * 104)
          : -56 + Math.floor(rnd() * rnd() * 236);
        const spheres: CarverSphere[] = [];
        const hasRoom = rnd() < 0.25; // Exact 1/4 (25%) probability of Circular Main Room vs 3/4 (75%) I-shaped / T-shaped
        if (hasRoom) {
          // Vanilla createRoom: circular void 1..14 blocks high and 5..15 blocks in diameter
          const roomDiameter = 5.0 + rnd() * 10.0;
          const roomHeight = 1.0 + rnd() * 13.0;
          spheres.push({ x: startX, y: startY, z: startZ, radXZ: roomDiameter * 0.5, radY: Math.max(0.8, roomHeight * 0.5), floorLevel: -0.7, kind: 'carver_cave' });
        }
        const branches = hasRoom ? 1 + Math.floor(rnd() * 4) : 1; // 1..4 trunks for Main Room; 1 trunk for I/T-shaped
        const trunkLengths: number[] = [];
        const subBranchesPerTrunk: number[] = [];
        for (let b = 0; b < branches; b++) {
          const yaw = rnd() * Math.PI * 2;
          const pitch = (rnd() - 0.5) * 0.25;
          const width = (1.15 + rnd() * 2.1) * (spawnDeepCave ? 1.12 : 1.0);
          const steps = 85 + Math.floor(rnd() * 28); // Exact Vanilla 85..112 steps
          const yScale = 0.8 + rnd() * 0.2;
          trunkLengths.push(steps);
          subBranchesPerTrunk.push(this.buildTunnel(spheres, rnd, startX, startY, startZ, width, yaw, pitch, 0, steps, yScale, -0.7, 'carver_cave'));
        }
        finalizeSystem(startX, startY, startZ, 'carver_cave', hasRoom, branches, trunkLengths, subBranchesPerTrunk, spheres);
      }

      // 2. CanyonWorldCarver (Ravines / 渓谷)
      if (rnd() < 0.035) {
        const startX = ocx * 16 + Math.floor(rnd() * 16);
        const startZ = ocz * 16 + Math.floor(rnd() * 16);
        const startY = -20 + Math.floor(rnd() * 68);
        const spheres: CarverSphere[] = [];
        const yaw = rnd() * Math.PI * 2;
        const pitch = (rnd() - 0.5) * 0.16;
        const width = 2.1 + rnd() * 1.9;
        const yScale = 3.2 + rnd() * 1.8;
        const steps = 85 + Math.floor(rnd() * 28);
        this.buildTunnel(spheres, rnd, startX, startY, startZ, width, yaw, pitch, 0, steps, yScale, -0.7, 'carver_canyon');
        finalizeSystem(startX, startY, startZ, 'carver_canyon', false, 1, [steps], [0], spheres);
      }
    }

    if (cache.size >= 4096) cache.delete(cache.keys().next().value!);
    cache.set(key, systems);
    return systems;
  }

  /** Lists all CarverSystems whose bounding box intersects the chunk at `(cx, cz)`. */
  carverOriginsNear(cx: number, cz: number, isNether = false): CarverSystem[] {
    const ox = cx * 16, oz = cz * 16;
    const out: CarverSystem[] = [];
    for (let dcz = -2; dcz <= 2; dcz++) {
      for (let dcx = -2; dcx <= 2; dcx++) {
        const sysList = this.carverSystemsInChunk(cx + dcx, cz + dcz, isNether);
        for (let i = 0; i < sysList.length; i++) {
          const s = sysList[i];
          if (s.maxX < ox - 1 || s.minX > ox + 16 || s.maxZ < oz - 1 || s.minZ > oz + 16) continue;
          out.push(s);
        }
      }
    }
    return out;
  }

  /**
   * Applies Overworld Cave & Canyon carvers to the `padded` chunk buffer BEFORE aquifer barrier sealing,
   * recording any aquifer water/lava voxels into `aqCells` so all water walls stay sealed.
   * Respects Vanilla MC-16132: carvers do not cut through `snow_block` on the surface.
   */
  carveOverworldChunk(
    cx: number,
    cz: number,
    ox: number,
    oz: number,
    getH: (lx: number, lz: number) => number,
    padded: Uint16Array,
    idx: (lx: number, y: number, lz: number) => number,
    aqCells: number[],
  ): number {
    const systems = this.carverOriginsNear(cx, cz, false);
    if (!systems.length) return 0;
    let carvedCount = 0;

    for (let si = 0; si < systems.length; si++) {
      const sys = systems[si];
      const spheres = sys.spheres;
      for (let m = 0; m < spheres.length; m++) {
        const sp = spheres[m];
        const rXZ = sp.radXZ, rY = sp.radY;
        const lx0 = Math.max(-1, Math.floor(sp.x - rXZ) - ox);
        const lx1 = Math.min(16, Math.ceil(sp.x + rXZ) - ox);
        if (lx0 > lx1) continue;
        const lz0 = Math.max(-1, Math.floor(sp.z - rXZ) - oz);
        const lz1 = Math.min(16, Math.ceil(sp.z + rXZ) - oz);
        if (lz0 > lz1) continue;
        const y0 = Math.max(MIN_WORLD_Y + 5, Math.floor(sp.y - rY));
        const y1 = Math.min(180, Math.ceil(sp.y + rY));
        if (y0 > y1) continue;

        const invRXZ = 1.0 / rXZ, invRY = 1.0 / rY;
        const isCanyon = sp.kind === 'carver_canyon';
        const cSeed = sp.canyonSeed ?? 0;

        for (let lz = lz0; lz <= lz1; lz++) {
          const wz = oz + lz;
          const dz = (wz + 0.5 - sp.z) * invRXZ;
          const dz2 = dz * dz;
          if (dz2 >= 1.0) continue;

          for (let lx = lx0; lx <= lx1; lx++) {
            const wx = ox + lx;
            const dx = (wx + 0.5 - sp.x) * invRXZ;
            const dxz2 = dx * dx + dz2;
            if (dxz2 >= 1.0) continue;

            const h = getH(lx, lz);
            // Never carve through ocean/river floors or shallow sub-sea crust
            const maxCarveY = h <= SEA_LEVEL + 2 ? h - 8 : isCanyon ? h - 2 : h - 5;
            const topY = Math.min(y1, maxCarveY);
            if (y0 > topY) continue;

            for (let y = y0; y <= topY; y++) {
              const dy = (y + 0.5 - sp.y) * invRY;
              if (dy <= sp.floorLevel) continue; // Vanilla flat floor level (-0.7)
              // Canyon wall ledges: horizontal rock shelves every few blocks in Y
              const ledgeMult = isCanyon ? 0.72 + ((Math.imul(y + 64, 2654435761) ^ cSeed) >>> 28) * 0.032 : 1.0;
              if (dxz2 * ledgeMult + dy * dy >= 1.0) continue;

              const pi = idx(lx, y, lz);
              const cur = padded[pi];
              if (cur === 0 || cur === ID.bedrock || cur === ID.water || cur === ID.lava || cur === ID.snow_block) continue;

              if (y < -54) {
                padded[pi] = ID.lava;
              } else {
                const fl = this.fluidAt(wx, y, wz);
                if (fl) {
                  padded[pi] = fl;
                  aqCells.push(pi);
                } else {
                  padded[pi] = 0;
                }
              }
              carvedCount++;
            }
          }
        }
      }
    }
    return carvedCount;
  }

  /**
   * Applies Vanilla `NetherWorldCarver` (`nether_cave`) branching tunnels and rooms to a Nether chunk.
   */
  carveNetherChunk(
    cx: number,
    cz: number,
    ox: number,
    oz: number,
    netherLavaY: number,
    netherHeight: number,
    padded: Uint16Array,
    idx: (lx: number, y: number, lz: number) => number,
  ): number {
    const systems = this.carverOriginsNear(cx, cz, true);
    if (!systems.length) return 0;
    let carvedCount = 0;

    for (let si = 0; si < systems.length; si++) {
      const spheres = systems[si].spheres;
      for (let m = 0; m < spheres.length; m++) {
        const sp = spheres[m];
        const rXZ = sp.radXZ, rY = sp.radY;
        const lx0 = Math.max(-1, Math.floor(sp.x - rXZ) - ox);
        const lx1 = Math.min(16, Math.ceil(sp.x + rXZ) - ox);
        if (lx0 > lx1) continue;
        const lz0 = Math.max(-1, Math.floor(sp.z - rXZ) - oz);
        const lz1 = Math.min(16, Math.ceil(sp.z + rXZ) - oz);
        if (lz0 > lz1) continue;
        const y0 = Math.max(netherLavaY + 3, Math.floor(sp.y - rY));
        const y1 = Math.min(netherHeight - 7, Math.ceil(sp.y + rY));
        if (y0 > y1) continue;

        const invRXZ = 1.0 / rXZ, invRY = 1.0 / rY;
        for (let lz = lz0; lz <= lz1; lz++) {
          const dz = (oz + lz + 0.5 - sp.z) * invRXZ;
          const dz2 = dz * dz;
          if (dz2 >= 1.0) continue;
          for (let lx = lx0; lx <= lx1; lx++) {
            const dx = (ox + lx + 0.5 - sp.x) * invRXZ;
            const dxz2 = dx * dx + dz2;
            if (dxz2 >= 1.0) continue;
            for (let y = y0; y <= y1; y++) {
              const dy = (y + 0.5 - sp.y) * invRY;
              if (dy <= sp.floorLevel || dxz2 + dy * dy >= 1.0) continue;
              const pi = idx(lx, y, lz);
              const cur = padded[pi];
              if (cur === 0 || cur === ID.bedrock || cur === ID.lava) continue;
              // Never breach into adjacent lava sea pockets
              if (padded[pi + 324] === ID.lava || padded[pi - 1] === ID.lava || padded[pi + 1] === ID.lava || padded[pi - 18] === ID.lava || padded[pi + 18] === ID.lava) continue;
              padded[pi] = 0;
              carvedCount++;
            }
          }
        }
      }
    }
    return carvedCount;
  }

  // ------------------------------------------------------------------ aquifers
  private cell(cx: number, cy: number, cz: number): AquiferCell {
    const key = ((cx + 4096) * 8192 + (cz + 4096)) * 64 + (cy + 8);
    let c = this.cells.get(key);
    if (c) return c;
    const s = this.seed;
    const X = cx * 16 + 5 + Math.floor(hash3(cx, cy, cz, s + 11) * 10);
    const Y = cy * 12 + 1 + Math.floor(hash3(cx, cy, cz, s + 12) * 9);
    const Z = cz * 16 + 5 + Math.floor(hash3(cx, cy, cz, s + 13) * 10);
    const surf = this.surface(X, Z);
    let level = -Infinity, lava = false;
    if (Y > surf - 6) {
      // Near / above the surface the only fluid is the sea itself (cave mouths opening under the ocean floor).
      level = surf < SEA_LEVEL ? SEA_LEVEL : -Infinity;
    } else {
      const flood = this.n.n3(X * 0.011 + 13.7, Y * 0.0125, Z * 0.011 - 4.1);
      if (flood > 0.5 && Y < SEA_LEVEL - 4) {
        // "Flooded" aquifers are filled right up to the global sea level (or just below the ceiling of the terrain).
        level = Math.min(SEA_LEVEL, surf - 8);
      } else {
        const spread = this.n.n3(X * 0.0125 + 77.0, Math.floor((Y + 64) / 40) * 3.1, Z * 0.0125 - 21.0);
        const layerBase = Math.floor((Y + 64) / 40) * 40 - 64;
        level = Math.min(SEA_LEVEL, layerBase + 6 + Math.floor((spread * 20) / 3) * 3);
        if (Y < -8 && this.n.n3(X * 0.02 + 5.5, Y * 0.02, Z * 0.02 - 9.1) > 0.28) lava = true;
      }
    }
    c = { x: X, y: Y, z: Z, level, lava };
    if (this.cells.size >= 32768) this.cells.delete(this.cells.keys().next().value!);
    this.cells.set(key, c);
    return c;
  }

  /** Aquifer fluid (water/lava block id) that occupies a *carved* cave voxel, or 0 when the voxel stays air. */
  fluidAt(x: number, y: number, z: number): number {
    const ix = Math.floor((x - 5) / 16), iy = Math.floor((y - 1) / 12), iz = Math.floor((z - 5) / 16);
    let best = Infinity, pick: AquiferCell | null = null;
    for (let k = 0; k < 8; k++) {
      const c = this.cell(ix + (k & 1), iy + ((k >> 1) & 1), iz + (k >> 2));
      const dx = c.x - x, dy = c.y - y, dz = c.z - z, d = dx * dx + dy * dy + dz * dz;
      if (d < best) { best = d; pick = c; }
    }
    if (!pick || y > pick.level) return 0;
    return (pick.lava && y <= -10) ? ID.lava : ID.water;
  }

  // ------------------------------------------------------------------ ore veins
  /** Smooth vein selector. Positive = copper veins, negative = iron veins. Only |value| >= VEIN_THRESHOLD hosts a vein. */
  veinToggle(x: number, y: number, z: number): number {
    return this.n.n3(x * 0.013 + 31.3, y * 0.0135 + 7.7, z * 0.013 - 12.9);
  }

  /** Fast column batch evaluation of veinToggle(wx, MIN_Y + k * 6, wz) for k = 0..19 (100% bit-for-bit identical to veinToggle). */
  fillVeinColumn(wx: number, wz: number, vt: Float32Array): boolean {
    const p = (this.n as any).p as Uint8Array | undefined;
    if (!p) {
      let on = false;
      for (let k = 0; k < 20; k++) {
        const v = this.veinToggle(wx, -64 + k * 6, wz);
        vt[k] = v;
        if (v >= VEIN_THRESHOLD || v <= -VEIN_THRESHOLD) on = true;
      }
      return on;
    }
    const x = wx * 0.013 + 31.3, z = wz * 0.013 - 12.9;
    const fx = Math.floor(x), fz = Math.floor(z);
    const X = fx & 255, Z = fz & 255;
    const dx = x - fx, dz = z - fz;
    const dx1 = dx - 1, dz1 = dz - 1;
    const u = dx * dx * dx * (dx * (dx * 6 - 15) + 10);
    const w = dz * dz * dz * (dz * (dz * 6 - 15) + 10);
    const pX = p[X], pX1 = p[X + 1];
    let on = false;
    for (let k = 0; k < 20; k++) {
      const Y = VEIN_K_Y[k];
      const dy = VEIN_K_DY[k], dy1 = dy - 1;
      const v = VEIN_K_V[k];
      const A = pX + Y, AA = p[A] + Z, AB = p[A + 1] + Z;
      const B = pX1 + Y, BA = p[B] + Z, BB = p[B + 1] + Z;
      const g000 = grad3Ug(p[AA], dx, dy, dz), g100 = grad3Ug(p[BA], dx1, dy, dz);
      const g010 = grad3Ug(p[AB], dx, dy1, dz), g110 = grad3Ug(p[BB], dx1, dy1, dz);
      const g001 = grad3Ug(p[AA + 1], dx, dy, dz1), g101 = grad3Ug(p[BA + 1], dx1, dy, dz1);
      const g011 = grad3Ug(p[AB + 1], dx, dy1, dz1), g111 = grad3Ug(p[BB + 1], dx1, dy1, dz1);
      const x00 = g000 + (g100 - g000) * u, x10 = g010 + (g110 - g010) * u;
      const x01 = g001 + (g101 - g001) * u, x11 = g011 + (g111 - g011) * u;
      const y0 = x00 + (x10 - x00) * v, y1 = x01 + (x11 - x01) * v;
      const val = y0 + (y1 - y0) * w;
      vt[k] = val;
      if (val >= VEIN_THRESHOLD || val <= -VEIN_THRESHOLD) on = true;
    }
    return on;
  }

  /** Vein-type window test shared by the cheap pre-filter in terrain generation. */
  veinActive(toggle: number, y: number): boolean {
    const copper = toggle > 0;
    const min = copper ? 0 : -60, max = copper ? 50 : -8;
    if (y < min || y > max) return false;
    const roundoff = -0.2 * (1 - Math.min(20, Math.min(max - y, y - min)) / 20);
    return Math.abs(toggle) + roundoff >= VEIN_THRESHOLD;
  }

  /**
   * Block to place for a vein voxel, or 0 to keep the host rock.
   * `deep` is true when the host block is deepslate (use deepslate ore variants).
   */
  vein(x: number, y: number, z: number, toggle: number, deep: boolean): number {
    if (!this.veinActive(toggle, y)) return 0;
    const copper = toggle > 0;
    const min = copper ? 0 : -60, max = copper ? 50 : -8;
    const roundoff = -0.2 * (1 - Math.min(20, Math.min(max - y, y - min)) / 20);
    const strength = Math.abs(toggle) + roundoff;
    if (hash3(x, y, z, this.seed + 401) > 0.7) return 0;
    const a = Math.abs(this.n.n3(x * 0.075 + 3.1, y * 0.075 + 9.4, z * 0.075 - 5.3));
    const b = Math.abs(this.n.n3(x * 0.075 - 41.7, y * 0.075 + 2.2, z * 0.075 + 17.9));
    if (Math.max(a, b) < 0.09) return 0; // thin ridged gaps between the vein sheets
    const richness = 0.1 + 0.2 * Math.min(1, Math.max(0, (strength - VEIN_THRESHOLD) / 0.2));
    if (hash3(x, y, z, this.seed + 402) < richness && this.n.n3(x * 0.4 + 8.2, y * 0.4, z * 0.4 - 3.3) > -0.36) {
      if (hash3(x, y, z, this.seed + 403) < 0.02) return (copper ? B.raw_copper_block : B.raw_iron_block) ?? (copper ? ID.copper_ore : ID.iron_ore);
      const ore = copper ? (deep ? B.deepslate_copper_ore : B.copper_ore) : (deep ? B.deepslate_iron_ore : B.iron_ore);
      return ore ?? (copper ? ID.copper_ore : ID.iron_ore);
    }
    return (copper ? B.granite : B.tuff) ?? 0;
  }

  // ------------------------------------------------------------------ cave biomes (3D)
  /**
   * Underground biome at a voxel, or null for ordinary caves.
   * E/H/C are the column's erosion / humidity / continentalness, `surf` the surface height.
   */
  caveBiomeAt(x: number, y: number, z: number, E: number, H: number, C: number, surf: number): 'deep_dark' | 'lush_caves' | 'dripstone_caves' | null {
    if (y > 56 || y > surf - 8) return null;
    const n = this.n;
    // Deep dark: deep below low-erosion terrain; the ceiling of the pocket undulates with the 3D noise.
    if (y < 6) {
      const dd = n.n3(x * 0.011 + 910, y * 0.028, z * 0.011 + 620);
      if (y < dd * 10 + 2) {
        const bonus = Math.max(0, Math.min(0.6, -E - 0.12)) * 0.9;
        if (E < -0.1 && dd + bonus > 0.2) return 'deep_dark';
        if (dd > 0.64) return 'deep_dark';
      }
    }
    if (H > 0.2) {
      const ll = n.n3(x * 0.013 + 500, y * 0.024, z * 0.013 - 320);
      if (ll + Math.max(0, H - 0.25) * 1.3 > 0.4) return 'lush_caves';
    }
    if (C > 0.3) {
      const dp = n.n3(x * 0.014 - 700, y * 0.022, z * 0.014 + 260);
      if (dp + Math.max(0, C - 0.3) * 1.2 > 0.42) return 'dripstone_caves';
    }
    // Rare isolated pockets anywhere underground
    const rare = n.n3(x * 0.016 + 120, y * 0.03, z * 0.016 - 80);
    if (rare > 0.72) return y < 0 ? 'deep_dark' : 'lush_caves';
    if (rare < -0.72) return 'dripstone_caves';
    return null;
  }
}
