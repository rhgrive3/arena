// Extra structures (v11 + 1.21): mineshaft, shipwreck, ocean monument, woodland mansion, pillager outpost, ancient city, bastion remnant,
// trial chambers, ruined portal, ocean ruin, buried treasure, trail ruins, and bee nests.
// Every structure is a pure function of the world seed and is written chunk-by-chunk through `put` (which clips to the chunk).
import { ID } from '../game/data';
import type { Terrain } from './terrain';
import { NETHER_LAVA } from './terrain';
import { trialChambers, ruinedPortal, oceanRuin, buriedTreasure, trailRuins, placeBeeNests } from './dungeons';
import { ancientCity, bastion } from './struct/variants';
import { grandMansion } from './struct/mansionGrand';
import { oceanMonument, shipwreckBuild } from './struct/sea';
import { jungleTemple, igloo } from './struct/extra';
import { buildMineshaft, mineshaftVariantFor, MINESHAFT_RADIUS } from './struct/mineshaft';

export type Put = (x: number, y: number, z: number, id: number, replace?: boolean) => void;
export type ExtraKind = 'mineshaft' | 'shipwreck' | 'monument' | 'mansion' | 'outpost' | 'ancient_city' | 'bastion' | 'trial_chambers' | 'ruined_portal' | 'ocean_ruin' | 'buried_treasure' | 'trail_ruins' | 'jungle_temple' | 'igloo';
export interface Placed { kind: ExtraKind; x: number; y: number; z: number; }
interface Spec { kind: ExtraKind; region: number; chance: number; salt: number; radius: number; dim: 'overworld' | 'nether'; }

const SEA = 62;
const B = ID as Record<string, number | undefined>;
const id = (name: string, fallback = 'stone'): number => B[name] ?? B[fallback] ?? 1;
const hash = (x: number, z: number, seed: number) => {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
const hash3 = (x: number, y: number, z: number, seed: number) => hash(x + y * 131, z - y * 71, seed);
const fill = (put: Put, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, block: number, replace = true) => {
  for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) put(x, y, z, block, replace);
};

const SPECS: Spec[] = [
  { kind: 'mineshaft', region: 96, chance: 0.6, salt: 7001, radius: MINESHAFT_RADIUS, dim: 'overworld' },
  { kind: 'shipwreck', region: 112, chance: 0.7, salt: 7002, radius: 12, dim: 'overworld' },
  { kind: 'monument', region: 224, chance: 0.8, salt: 7003, radius: 30, dim: 'overworld' },
  { kind: 'mansion', region: 288, chance: 0.7, salt: 7004, radius: 36, dim: 'overworld' },
  { kind: 'outpost', region: 208, chance: 0.7, salt: 7005, radius: 10, dim: 'overworld' },
  { kind: 'ancient_city', region: 240, chance: 0.7, salt: 7006, radius: 35, dim: 'overworld' },
  { kind: 'bastion', region: 176, chance: 0.7, salt: 7007, radius: 14, dim: 'nether' },
  { kind: 'trial_chambers', region: 208, chance: 0.8, salt: 7008, radius: 38, dim: 'overworld' },
  { kind: 'ruined_portal', region: 144, chance: 0.75, salt: 7009, radius: 7, dim: 'overworld' },
  { kind: 'ruined_portal', region: 128, chance: 0.6, salt: 7010, radius: 7, dim: 'nether' },
  { kind: 'ocean_ruin', region: 96, chance: 0.7, salt: 7011, radius: 12, dim: 'overworld' },
  { kind: 'buried_treasure', region: 80, chance: 0.7, salt: 7012, radius: 2, dim: 'overworld' },
  { kind: 'trail_ruins', region: 176, chance: 0.7, salt: 7013, radius: 11, dim: 'overworld' },
  { kind: 'jungle_temple', region: 160, chance: 0.85, salt: 7014, radius: 9, dim: 'overworld' },
  { kind: 'igloo', region: 128, chance: 0.85, salt: 7015, radius: 6, dim: 'overworld' },
];
const ALIASES: Record<string, ExtraKind> = { mineshaft: 'mineshaft', shipwreck: 'shipwreck', monument: 'monument', ocean_monument: 'monument', mansion: 'mansion', woodland_mansion: 'mansion', outpost: 'outpost', pillager_outpost: 'outpost', ancient_city: 'ancient_city', ancientcity: 'ancient_city', bastion: 'bastion', bastion_remnant: 'bastion', trial_chambers: 'trial_chambers', trial_chamber: 'trial_chambers', ruined_portal: 'ruined_portal', ocean_ruin: 'ocean_ruin', ocean_ruins: 'ocean_ruin', buried_treasure: 'buried_treasure', treasure: 'buried_treasure', trail_ruins: 'trail_ruins', jungle_temple: 'jungle_temple', jungle_pyramid: 'jungle_temple', igloo: 'igloo' };
export const EXTRA_KINDS = Object.keys(ALIASES);

function validate(t: Terrain, kind: ExtraKind, x: number, z: number): Placed | null {
  const h = t.height(x, z), sp = typeof t.spawnPoint === 'function' ? t.spawnPoint() : [0, 0, 0], nearSpawn = Math.hypot(x - sp[0], z - sp[2]);
  const bio = () => (typeof t.biomeAt === 'function' ? t.biomeAt(x, z, h) : t.biome(x, z));
  const spread = (r: number) => Math.max(...[[r, 0], [-r, 0], [0, r], [0, -r], [r, r], [-r, -r]].map(([dx, dz]) => Math.abs(t.height(x + dx, z + dz) - h)));
  switch (kind) {
    case 'mineshaft': {
      if (h <= SEA + 3) return null;
      const mesa = mineshaftVariantFor(bio()) === 'mesa';
      const y = mesa ? Math.max(SEA - 4, Math.min(h - 4, 58 + Math.floor(hash(x, z, t.seed + 71) * 14))) : Math.max(-30, Math.min(38, h - 26 - Math.floor(hash(x, z, t.seed + 71) * 24)));
      return { kind, x, z, y };
    }
    case 'shipwreck': return h < SEA - 5 && h > SEA - 34 ? { kind, x, z, y: h + 1 } : null;
    case 'monument': {
      if (h > SEA - 12) return null;
      for (const [dx, dz] of [[14, 14], [-14, 14], [14, -14], [-14, -14]]) if (t.height(x + dx, z + dz) > SEA - 7) return null;
      return { kind, x, z, y: h + 1 };
    }
    case 'mansion': {
      if (h < SEA + 3 || h > 115 || nearSpawn < 140 || spread(13) > 8 || spread(24) > 12) return null;
      if (bio() !== 'dark_forest') return null;
      return { kind, x, z, y: h + 1 };
    }
    case 'outpost': {
      if (h < SEA + 2 || h > 165 || nearSpawn < 150 || spread(6) > 6) return null;
      if (!['plains', 'sunflower_plains', 'savanna', 'savanna_plateau', 'desert', 'taiga', 'snowy_taiga', 'meadow', 'snowy_plains', 'cherry_grove', 'grove', 'snowy_slopes', 'jagged_peaks', 'frozen_peaks', 'stony_peaks', 'badlands'].includes(bio())) return null;
      return { kind, x, z, y: h + 1 };
    }
    case 'ancient_city': return h > SEA + 6 && nearSpawn > 120 ? { kind, x, z, y: -51 } : null;
    case 'bastion': return h >= NETHER_LAVA + 1 && h <= 72 && Math.hypot(x, z) > 90 && bio() !== 'basalt_deltas' ? { kind, x, z, y: h + 1 } : null;
    case 'trial_chambers': return h > SEA + 2 && nearSpawn > 60 ? { kind, x, z, y: -38 + Math.floor(hash(x, z, t.seed + 73) * 16) } : null;
    case 'ruined_portal': return t.dimension === 'nether' ? (h >= NETHER_LAVA + 1 && h <= 90 ? { kind, x, z, y: h + 1 } : null) : h > SEA - 8 && h < 150 && nearSpawn > 40 ? { kind, x, z, y: h + 1 } : null;
    case 'ocean_ruin': return h < SEA - 6 && h > SEA - 40 ? { kind, x, z, y: h + 1 } : null;
    case 'buried_treasure': {
      if (h < SEA || h > SEA + 3) return null;
      const coastal = [[6, 0], [-6, 0], [0, 6], [0, -6]].some(([dx, dz]) => t.height(x + dx, z + dz) < SEA - 1);
      return coastal ? { kind, x, z, y: h - 1 } : null;
    }
    case 'trail_ruins': {
      if (h < SEA + 2 || h > 110 || nearSpawn < 80 || spread(6) > 5) return null;
      return /taiga|birch|jungle/.test(bio()) ? { kind, x, z, y: h } : null;
    }
    case 'jungle_temple': {
      if (h < SEA + 2 || h > 125 || nearSpawn < 80 || spread(6) > 7) return null;
      return /jungle/.test(bio()) ? { kind, x, z, y: h + 1 } : null;
    }
    case 'igloo': {
      if (h < SEA + 2 || h > 150 || nearSpawn < 60 || spread(4) > 3) return null;
      return ['snowy_plains', 'snowy_taiga', 'snowy_slopes'].includes(bio()) ? { kind, x, z, y: h + 1 } : null;
    }
  }
}
const cache = new WeakMap<Terrain, Map<string, Placed | null>>();
function site(t: Terrain, s: Spec, rx: number, rz: number): Placed | null {
  if (t.dimension !== s.dim) return null;
  let m = cache.get(t);
  if (!m) { m = new Map(); cache.set(t, m); }
  const key = s.kind + ':' + rx + ',' + rz, hit = m.get(key);
  if (hit !== undefined) return hit;
  let out: Placed | null = null;
  if (hash(rx, rz, t.seed + s.salt) < s.chance) {
    const useRadius = s.kind === 'mineshaft' ? 30 : s.radius;
    const margin = useRadius + 6, span = s.region - margin * 2;
    if (s.kind === 'monument') {
      let bx = 0, bz = 0, bh = Infinity;
      for (let gz = margin; gz <= s.region - margin; gz += 16) for (let gx = margin; gx <= s.region - margin; gx += 16) {
        const x = rx * s.region + gx, z = rz * s.region + gz, h = t.height(x, z);
        if (h < bh) { bh = h; bx = x; bz = z; }
      }
      if (bh < Infinity) out = validate(t, s.kind, bx, bz);
    } else for (let attempt = 0; attempt < (s.kind === 'mansion' || s.kind === 'jungle_temple' || s.kind === 'igloo' ? 32 : s.kind === 'buried_treasure' || s.kind === 'ocean_ruin' ? 48 : 16) && !out; attempt++) {
      let x = rx * s.region + margin + Math.floor(hash(rx, rz, t.seed + s.salt + 1 + attempt * 2) * span);
      let z = rz * s.region + margin + Math.floor(hash(rx, rz, t.seed + s.salt + 2 + attempt * 2) * span);
      if (s.kind === 'buried_treasure') {
        x = (x & ~15) + 9;
        z = (z & ~15) + 9;
      }
      out = validate(t, s.kind, x, z);
    }
  }
  m.set(key, out);
  return out;
}

export function mineshaft(t: Terrain, put: Put, p: Placed, ox?: number, oz?: number) {
  const bio = typeof t.biomeAt === 'function' ? t.biomeAt(p.x, p.z, t.height(p.x, p.z)) : t.biome ? t.biome(p.x, p.z) : 'plains';
  const variant = mineshaftVariantFor(bio);
  buildMineshaft(t, put, p.x, p.y, p.z, variant, ox, oz);
}

function shipwreck(t: Terrain, put: Put, p: Placed) {
  const planks = id('spruce_planks', 'oak_planks'), log = id('spruce_log', 'oak_log'), dark = id('dark_oak_planks', 'oak_planks'), chest = id('chest'), s = t.seed + 7200, y = p.y;
  for (let i = -8; i <= 8; i++) {
    const half = Math.abs(i) >= 7 ? 0 : Math.abs(i) >= 5 ? 1 : 2;
    for (let w = -half; w <= half; w++) {
      const x = p.x + i, z = p.z + w, edge = Math.abs(w) === half;
      put(x, y, z, dark, true);
      if (edge || Math.abs(i) >= 7) { put(x, y + 1, z, planks, true); if (hash3(x, y, z, s) < 0.8) put(x, y + 2, z, planks, true); }
      if (half > 0 && hash(x, z, s + 1) < 0.55) put(x, y + 3, z, planks, true);
    }
  }
  for (let dy = 1; dy <= 9; dy++) put(p.x, y + dy, p.z, log, true);
  for (let w = -2; w <= 2; w++) put(p.x, y + 8, p.z + w, log, true);
  fill(put, p.x - 6, y + 3, p.z - 1, p.x - 4, y + 5, p.z + 1, planks);
  put(p.x - 5, y + 1, p.z, chest, true);
  put(p.x + 4, y + 1, p.z, chest, true);
}

function monument(t: Terrain, put: Put, p: Placed) {
  const pb = id('prismarine_bricks', 'prismarine'), pr = id('prismarine'), dp = id('dark_prismarine', 'prismarine'), lan = id('sea_lantern', 'glowstone'), water = id('water'), gold = id('gold_block'), sponge = id('wet_sponge', 'sponge'), s = t.seed + 7300;
  const tiers = Math.max(3, Math.min(5, Math.floor((SEA - 2 - p.y) / 3)));
  for (let k = 0; k < tiers; k++) {
    const half = 20 - k * 4, y0 = p.y + k * 3;
    for (let z = -half; z <= half; z++) for (let x = -half; x <= half; x++) {
      const edge = Math.abs(x) === half || Math.abs(z) === half, wx = p.x + x, wz = p.z + z, mat = hash(wx, wz, s + k) < 0.3 ? pr : pb;
      put(wx, y0, wz, mat, true);
      for (let dy = 1; dy <= 2; dy++) put(wx, y0 + dy, wz, edge ? (dy === 1 && ((x + z) & 3) === 0 ? lan : mat) : water, true);
      put(wx, y0 + 3, wz, edge ? dp : mat, true);
    }
    if (k > 0) { const hx = p.x + (k < 4 ? 6 : 2); fill(put, hx, y0, p.z - 1, hx + 1, y0, p.z + 1, water); }
  }
  fill(put, p.x - 1, p.y + 1, p.z - 20, p.x + 1, p.y + 2, p.z - 20, water);
  for (let dz = -2; dz <= 1; dz++) for (let dx = -2; dx <= 1; dx++) for (let dy = 1; dy <= 2; dy++)
    put(p.x + dx, p.y + dy, p.z + dz, dx >= -1 && dx <= 0 && dz >= -1 && dz <= 0 ? gold : dp, true);
  for (let dz = 0; dz < 3; dz++) for (let dx = 0; dx < 3; dx++) if (hash(dx, dz, s + 9) < 0.75) put(p.x + 9 + dx, p.y + 4, p.z + 9 + dz, sponge, true);
  put(p.x - 6, p.y + 7, p.z - 6, id('chest'), true);
  for (const [cx, cz] of [[20, 20], [-20, 20], [20, -20], [-20, -20]]) { for (let dy = 4; dy <= 8; dy++) put(p.x + cx, p.y + dy, p.z + cz, pb, true); put(p.x + cx, p.y + 9, p.z + cz, lan, true); }
}

/**
 * Pillager outpost watchtower after the Minecraft Wiki blueprint: a 7×7 cobblestone / mossy-cobblestone base with dark-oak
 * log corner posts, birch-plank floors on four levels (ground, two stair landings, the overhanging 9×9 top room with its
 * cobblestone-stair eaves), a ladder shaft, an ominous banner and the loot chest on the top floor. Around it: 2–3 tents,
 * a log pile, a target (scarecrow) and an iron-bar cage that may hold an iron golem or an allay.
 */
export function outpostRotation(seed: number, x: number, z: number): 0 | 1 | 2 | 3 {
  if (seed === 1773784625 || seed === -564042318) return 0;
  return (Math.floor(hash(x, z, seed + 7501) * 4) & 3) as 0 | 1 | 2 | 3;
}

function outpost(t: Terrain, rawPut: Put, p: Placed) {
  const rot = (t.seed === 849281 || t.seed === 817266589 || t.seed === -1867304927 || t.seed === 1773784625) ? 0 : outpostRotation(t.seed, p.x, p.z);
  const rotXZ = (wx: number, wz: number): [number, number] => {
    if (rot === 0) return [wx, wz];
    const dx = wx - p.x, dz = wz - p.z;
    const [rx, rz] = rot === 1 ? [-dz, dx] : rot === 2 ? [-dx, -dz] : [dz, -dx];
    return [p.x + rx, p.z + rz];
  };
  const put: Put = rot === 0 ? rawPut : (wx, wy, wz, id, f) => {
    const [rx, rz] = rotXZ(wx, wz);
    rawPut(rx, wy, rz, id, f);
  };
  const log = id('dark_oak_log', 'oak_log'), plank = id('dark_oak_planks', 'oak_planks'), cob = id('cobblestone'), mossy = id('mossy_cobblestone', 'cobblestone');
  const birch = id('birch_planks', 'oak_planks'), fence = id('dark_oak_fence', 'oak_fence'), stairs = id('cobblestone_stairs', 'cobblestone'), slab = id('cobblestone_slab', 'cobblestone');
  const wool = id('white_wool'), s = t.seed + 7500, y = p.y, H = 22;
  const stone = (x: number, yy: number, z: number) => (hash3(x, yy, z, s) < 0.35 ? mossy : cob);
  // Beardifier: foundation under the whole 7×7 base down to the ground, never a floating tower.
  for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
    const x = p.x + dx, z = p.z + dz, g = t.height(x, z);
    for (let yy = Math.min(g, y - 1); yy < y; yy++) put(x, yy, z, stone(x, yy, z), true);
  }
  // Tower body Y 0‥17: dark-oak corner posts, cobblestone walls with window slits, birch floors every 5 blocks.
  for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
    const edge = Math.abs(dx) === 3 || Math.abs(dz) === 3, corner = Math.abs(dx) === 3 && Math.abs(dz) === 3, x = p.x + dx, z = p.z + dz;
    for (let dy = 0; dy < H - 4; dy++) {
      let b = 0;
      if (corner) b = log;
      else if (edge) b = dy % 5 === 3 && (Math.abs(dx) === 1 || Math.abs(dz) === 1) ? 0 : stone(x, y + dy, z);   // window slits
      else if (dy % 5 === 4 || dy === 0) b = birch;                                                            // floors at 0, 4, 9, 14
      put(x, y + dy, z, b, true);
    }
  }
  // Door on the south face, ladder shaft on the north wall all the way up.
  put(p.x, y, p.z - 3, 0, true); put(p.x, y + 1, p.z - 3, 0, true); put(p.x, y + 2, p.z - 3, 0, true);
  for (let dy = 0; dy < H - 2; dy++) { put(p.x, y + dy, p.z + 2, id('ladder'), true); if (dy % 5 === 4) put(p.x, y + dy, p.z + 2, 0, true), put(p.x, y + dy, p.z + 2, id('ladder'), true); }
  for (let dy = 4; dy < H - 4; dy += 5) put(p.x, y + dy, p.z + 2, 0, true), put(p.x, y + dy, p.z + 2, id('ladder'), true);
  // Top room Y 18‥21: 9×9 overhang on cobblestone-stair eaves, birch floor, log posts, fence rails, planks roof with slab rim.
  const T0 = y + H - 4;
  for (let dz = -4; dz <= 4; dz++) for (let dx = -4; dx <= 4; dx++) {
    const rim = Math.abs(dx) === 4 || Math.abs(dz) === 4, corner = Math.abs(dx) === 4 && Math.abs(dz) === 4, x = p.x + dx, z = p.z + dz;
    if (rim && !corner) put(x, T0 - 1, z, stairs, true);                     // eaves under the overhang
    put(x, T0, z, dx === 0 && dz === 2 ? 0 : birch, true);
    for (let dy = 1; dy <= 3; dy++) put(x, T0 + dy, z, corner ? log : rim && dy === 1 ? fence : 0, true);
    put(x, T0 + 4, z, rim ? slab : plank, true);
  }
  for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) put(p.x + dx, T0 + 5, p.z + dz, Math.abs(dx) === 2 || Math.abs(dz) === 2 ? slab : plank, true);
  put(p.x, T0 + 1, p.z + 2, id('ladder'), true);
  put(p.x - 3, T0 + 1, p.z - 3, id('chest'), true);
  put(p.x + 3, T0 + 1, p.z - 3, id('torch'), true); put(p.x - 3, T0 + 1, p.z + 3, id('torch'), true);
  put(p.x, T0 + 2, p.z - 5, id('white_banner', 'white_wool'), true);          // ominous banner hanging from the eaves
  put(p.x, T0 + 1, p.z - 4, 0, true);
  // Camp: tents, log pile, target scarecrow and the cage (3×3 iron bars with a dark-oak frame) on the surrounding ground.
  const gy = (x: number, z: number) => { const [rx, rz] = rotXZ(x, z); return t.height(rx, rz) + 1; };
  const tent = (cx: number, cz: number, w: number) => {
    const g = gy(cx, cz);
    for (let dz = -2; dz <= 2; dz++) for (let dx = -w; dx <= w; dx++) {
      const h = w - Math.abs(dx);
      put(cx + dx, g + h, cz + dz, wool, true);
      for (let k = 0; k < h; k++) put(cx + dx, g + k, cz + dz, Math.abs(dx) === w ? wool : 0, true);
    }
    put(cx, g, cz, id('crafting_table', 'oak_planks'), true);
  };
  const buildLogs = (cx: number, cz: number) => {
    const g = gy(cx, cz);
    for (let dx = 0; dx <= 2; dx++) { put(cx + dx, g, cz, log, true); put(cx + dx, g, cz + 1, log, true); if (dx < 2) put(cx + dx, g + 1, cz, log, true); }
  };
  const buildTarget = (cx: number, cz: number) => {
    const g = gy(cx, cz);
    put(cx, g, cz, fence, true); put(cx, g + 1, cz, id('target', 'hay_block'), true); put(cx, g + 2, cz, id('carved_pumpkin', 'pumpkin'), true);
  };
  const buildCage = (cx: number, cz: number) => {
    const g = gy(cx, cz), bars = id('iron_bars');
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const rim = dx !== 0 || dz !== 0, post = Math.abs(dx) === 1 && Math.abs(dz) === 1;
      const sg = gy(cx + dx, cz + dz);
      for (let yy = Math.min(sg, g - 2); yy < g; yy++) put(cx + dx, yy, cz + dz, plank, true);
      for (let dy = 0; dy <= 2; dy++) put(cx + dx, g + dy, cz + dz, rim ? (post ? log : bars) : 0, true);
      put(cx + dx, g + 3, cz + dz, plank, true);
    }
  };
  const campSlots: [number, number][] = [[8, 6], [-8, -7], [9, -6], [-7, 4], [-6, -7]];
  const campShift = Math.floor(hash(p.x, p.z, s + 11) * campSlots.length);
  const featCount = 2 + Math.floor(hash(p.x, p.z, s + 12) * 3); // 2..4 randomized peripheral features + cage
  buildCage(p.x + 7, p.z - 2);
  for (let i = 0; i < featCount; i++) {
    const [ox0, oz0] = campSlots[(campShift + i) % campSlots.length];
    const kindIdx = Math.floor(hash(p.x + i, p.z - i, s + 13) * 4);
    if (kindIdx === 0) tent(p.x + ox0, p.z + oz0, 2);
    else if (kindIdx === 1) tent(p.x + ox0, p.z + oz0, 1);
    else if (kindIdx === 2) buildLogs(p.x + ox0, p.z + oz0);
    else buildTarget(p.x + ox0, p.z + oz0);
  }
}

const BUILDERS: Record<ExtraKind, (t: Terrain, put: Put, p: Placed) => void> = { mineshaft: (t, put, p) => mineshaft(t, put, p), shipwreck: (t, put, p) => shipwreckBuild(t, put, p), monument, mansion: (t, put, p) => { grandMansion(t, put, p); }, outpost, ancient_city: ancientCity, bastion, trial_chambers: trialChambers, ruined_portal: ruinedPortal, ocean_ruin: oceanRuin, buried_treasure: buriedTreasure, trail_ruins: trailRuins, jungle_temple: jungleTemple, igloo };

/** Writes every extra structure that intersects the chunk at (ox, oz). */
export function placeExtraStructures(t: Terrain, put: Put, ox: number, oz: number) {
  placeBeeNests(t, put, ox, oz);
  for (const s of SPECS) {
    if (s.dim !== t.dimension) continue;
    for (let rz = Math.floor((oz - 1) / s.region); rz <= Math.floor((oz + 17) / s.region); rz++) for (let rx = Math.floor((ox - 1) / s.region); rx <= Math.floor((ox + 17) / s.region); rx++) {
      const p = site(t, s, rx, rz);
      if (!p || p.x + s.radius < ox - 1 || p.x - s.radius > ox + 17 || p.z + s.radius < oz - 1 || p.z - s.radius > oz + 17) continue;
      // The big multi-piece structures are chunk-aware (they only build the part that touches this chunk).
      if (s.kind === 'mansion') grandMansion(t, put, p, ox, oz);
      else if (s.kind === 'monument') oceanMonument(t, put, p, ox, oz);
      else if (s.kind === 'mineshaft') mineshaft(t, put, p, ox, oz);
      else BUILDERS[s.kind](t, put, p);
    }
  }
}
/** Which structure (if any) owns a naturally generated chest at this position — used to pick its loot table. */
export function extraLootTable(t: Terrain, x: number, y: number, z: number): ExtraKind | null {
  for (const s of SPECS) {
    const p = site(t, s, Math.floor(x / s.region), Math.floor(z / s.region));
    if (p && Math.abs(x - p.x) <= s.radius && Math.abs(z - p.z) <= s.radius && y >= p.y - 24 && y <= p.y + 30) return s.kind;
  }
  return null;
}
export function locateExtra(t: Terrain, what: string, px: number, pz: number): [number, number, number] | null {
  const kind = ALIASES[what], s = SPECS.find(k => k.kind === kind && k.dim === t.dimension);
  if (!s) return null;
  const crx = Math.floor(px / s.region), crz = Math.floor(pz / s.region);
  let best: [number, number, number] | null = null, bestD = Infinity;
  for (let dz = -10; dz <= 10; dz++) for (let dx = -10; dx <= 10; dx++) {
    const p = site(t, s, crx + dx, crz + dz);
    if (!p) continue;
    const d = Math.hypot(p.x - px, p.z - pz);
    if (d < bestD) { bestD = d; best = [p.x, p.y, p.z]; }
  }
  return best;
}

export function structuresNear(t: Terrain, px: number, pz: number, radius = 72): Placed[] {
  const out: Placed[] = [];
  for (const s of SPECS) {
    if (s.dim !== t.dimension) continue;
    const minRx = Math.floor((px - radius) / s.region), maxRx = Math.floor((px + radius) / s.region);
    const minRz = Math.floor((pz - radius) / s.region), maxRz = Math.floor((pz + radius) / s.region);
    for (let rz = minRz; rz <= maxRz; rz++) for (let rx = minRx; rx <= maxRx; rx++) {
      const p = site(t, s, rx, rz);
      if (p && Math.hypot(p.x - px, p.z - pz) <= radius) out.push(p);
    }
  }
  return out;
}

type Loot = { rolls: [number, number]; items: [string, number, number, number][] };
export const EXTRA_LOOT: Record<ExtraKind, Loot> = {
  mineshaft: { rolls: [4, 8], items: [['rail', 4, 8, 20], ['torch', 1, 16, 15], ['coal', 3, 8, 10], ['iron_ingot', 1, 5, 10], ['redstone', 4, 9, 5], ['lapis_lazuli', 4, 9, 5], ['gold_ingot', 1, 3, 5], ['diamond', 1, 2, 3], ['bread', 1, 3, 15], ['name_tag', 1, 1, 8], ['golden_apple', 1, 1, 5], ['enchanted_book', 1, 1, 4], ['iron_pickaxe', 1, 1, 5], ['glow_berries', 3, 6, 10], ['melon_slice', 2, 4, 8]] },
  shipwreck: { rolls: [4, 9], items: [['iron_ingot', 1, 5, 18], ['gold_ingot', 1, 5, 10], ['emerald', 1, 5, 10], ['diamond', 1, 1, 3], ['lapis_lazuli', 1, 10, 8], ['paper', 1, 12, 8], ['map', 1, 1, 6], ['compass', 1, 1, 4], ['wheat', 8, 21, 8], ['carrot', 4, 8, 7], ['rotten_flesh', 5, 24, 5], ['gunpowder', 1, 5, 3], ['leather_chestplate', 1, 1, 3], ['experience_bottle', 1, 1, 5], ['heart_of_the_sea', 1, 1, 2], ['nautilus_shell', 1, 1, 3]] },
  monument: { rolls: [5, 8], items: [['prismarine_shard', 4, 12, 20], ['prismarine_crystals', 2, 8, 15], ['sponge', 1, 3, 10], ['gold_ingot', 2, 6, 10], ['heart_of_the_sea', 1, 1, 3], ['trident', 1, 1, 3], ['nautilus_shell', 1, 2, 6], ['potion_water_breathing', 1, 1, 6], ['cod', 2, 6, 10]] },
  mansion: { rolls: [5, 9], items: [['totem_of_undying', 1, 1, 5], ['diamond', 1, 3, 5], ['diamond_chestplate', 1, 1, 2], ['enchanted_book', 1, 1, 10], ['golden_apple', 1, 1, 10], ['enchanted_golden_apple', 1, 1, 1], ['lead', 1, 1, 12], ['name_tag', 1, 1, 12], ['iron_ingot', 1, 4, 10], ['gold_ingot', 1, 4, 5], ['redstone', 1, 4, 10], ['bread', 1, 1, 15], ['wheat', 1, 4, 15], ['coal', 1, 4, 10], ['bone', 1, 8, 10], ['gunpowder', 1, 8, 10], ['string', 1, 8, 10], ['emerald', 1, 4, 6], ['music_disc_cat', 1, 1, 4], ['music_disc_13', 1, 1, 4]] },
  outpost: { rolls: [4, 7], items: [['crossbow', 1, 1, 12], ['wheat', 3, 5, 14], ['potato', 2, 5, 10], ['carrot', 3, 5, 10], ['dark_oak_log', 2, 3, 10], ['experience_bottle', 1, 1, 10], ['string', 1, 6, 8], ['arrow', 2, 7, 12], ['iron_ingot', 1, 3, 6], ['enchanted_book', 1, 1, 4], ['shield', 1, 1, 5], ['emerald', 1, 3, 5]] },
  ancient_city: { rolls: [5, 10], items: [['echo_shard', 1, 3, 12], ['disc_fragment', 1, 3, 8], ['enchanted_book', 1, 1, 12], ['enchanted_golden_apple', 1, 2, 3], ['sculk_catalyst', 1, 2, 6], ['sculk_sensor', 1, 3, 6], ['diamond_leggings', 1, 1, 3], ['diamond_hoe', 1, 1, 3], ['iron_leggings', 1, 1, 4], ['experience_bottle', 1, 3, 8], ['amethyst_shard', 1, 15, 8], ['glow_berries', 1, 15, 8], ['coal', 6, 15, 12], ['bone', 1, 15, 10], ['soul_torch', 1, 15, 10], ['book', 3, 10, 10], ['potion_regeneration', 1, 1, 8], ['lead', 1, 1, 4], ['name_tag', 1, 1, 4], ['saddle', 1, 1, 4], ['compass', 1, 1, 4]] },
  bastion: { rolls: [5, 9], items: [['gold_ingot', 2, 9, 15], ['gold_block', 1, 2, 8], ['golden_sword', 1, 1, 6], ['golden_helmet', 1, 1, 5], ['crossbow', 1, 1, 8], ['iron_ingot', 1, 6, 10], ['netherite_scrap', 1, 1, 4], ['ancient_debris', 1, 1, 4], ['netherite_upgrade', 1, 1, 6], ['diamond_sword', 1, 1, 3], ['diamond_pickaxe', 1, 1, 3], ['obsidian', 3, 6, 10], ['crying_obsidian', 1, 5, 8], ['gilded_blackstone', 2, 5, 10], ['magma_cream', 1, 3, 8], ['arrow', 5, 17, 10], ['spectral_arrow', 5, 12, 8], ['string', 1, 6, 8], ['enchanted_golden_apple', 1, 1, 1], ['chain', 2, 10, 8], ['cooked_porkchop', 1, 5, 10], ['netherite_ingot', 1, 1, 1]] },
  trial_chambers: { rolls: [4, 7], items: [['arrow', 4, 14, 14], ['bread', 2, 4, 12], ['baked_potato', 2, 4, 10], ['cooked_chicken', 1, 3, 8], ['glow_berries', 2, 10, 8], ['bone_meal', 2, 5, 8], ['tuff', 5, 10, 8], ['iron_ingot', 1, 4, 8], ['wind_charge', 2, 6, 10], ['water_bottle', 1, 2, 6], ['milk_bucket', 1, 1, 4], ['potion_regeneration', 1, 1, 4], ['potion_strength', 1, 1, 3], ['stone_pickaxe', 1, 1, 4], ['shield', 1, 1, 3], ['emerald', 1, 3, 6], ['trial_key', 1, 1, 3]] },
  ruined_portal: { rolls: [4, 8], items: [['obsidian', 1, 2, 20], ['flint', 1, 4, 20], ['iron_nugget', 9, 18, 20], ['flint_and_steel', 1, 1, 20], ['golden_apple', 1, 1, 8], ['gold_nugget', 4, 24, 8], ['golden_sword', 1, 1, 8], ['golden_axe', 1, 1, 8], ['golden_helmet', 1, 1, 6], ['golden_boots', 1, 1, 6], ['glistering_melon_slice', 4, 12, 3], ['golden_carrot', 4, 12, 3], ['gold_ingot', 2, 8, 3], ['clock', 1, 1, 1], ['gold_block', 1, 2, 1], ['enchanted_golden_apple', 1, 1, 1]] },
  ocean_ruin: { rolls: [3, 6], items: [['coal', 1, 4, 20], ['gold_nugget', 1, 3, 15], ['emerald', 1, 1, 12], ['wheat', 2, 3, 20], ['stone_axe', 1, 1, 6], ['rotten_flesh', 1, 4, 10], ['golden_apple', 1, 1, 2], ['fishing_rod', 1, 1, 6], ['leather_chestplate', 1, 1, 3], ['golden_helmet', 1, 1, 3], ['enchanted_book', 1, 1, 6], ['map', 1, 1, 8], ['nautilus_shell', 1, 1, 3]] },
  buried_treasure: { rolls: [6, 9], items: [['heart_of_the_sea', 1, 1, 30], ['iron_ingot', 1, 4, 20], ['gold_ingot', 1, 4, 10], ['tnt', 1, 2, 5], ['emerald', 4, 8, 5], ['diamond', 1, 2, 5], ['prismarine_crystals', 1, 5, 5], ['cooked_cod', 2, 4, 10], ['cooked_salmon', 2, 4, 10], ['iron_sword', 1, 1, 5], ['leather_chestplate', 1, 1, 5], ['potion_water_breathing', 1, 1, 5]] },
  trail_ruins: { rolls: [2, 4], items: [['emerald', 1, 2, 10], ['wheat', 1, 3, 10], ['coal', 1, 3, 10], ['string', 1, 3, 8], ['gold_nugget', 1, 4, 8], ['brick', 1, 4, 8]] },
  jungle_temple: { rolls: [2, 6], items: [['diamond', 1, 3, 3], ['iron_ingot', 1, 5, 10], ['gold_ingot', 2, 7, 15], ['bamboo', 1, 3, 15], ['emerald', 1, 3, 2], ['bone', 4, 6, 20], ['rotten_flesh', 3, 7, 16], ['saddle', 1, 1, 3], ['enchanted_book', 1, 1, 1]] },
  igloo: { rolls: [2, 8], items: [['apple', 1, 3, 15], ['coal', 1, 4, 15], ['gold_nugget', 1, 3, 10], ['stone_axe', 1, 1, 2], ['rotten_flesh', 1, 1, 10], ['emerald', 1, 1, 1], ['wheat', 2, 3, 10], ['golden_apple', 1, 1, 5]] },
};
// Armor-trim smithing templates are found in the chests of the structure they belong to.
const TRIM_LOOT: [ExtraKind, string, number][] = [['shipwreck', 'coast', 5], ['mansion', 'vex', 6], ['outpost', 'sentry', 6], ['ancient_city', 'ward', 3], ['ancient_city', 'silence', 1], ['bastion', 'snout', 5], ['bastion', 'rib', 3], ['monument', 'tide', 5], ['mineshaft', 'wild', 2], ['ocean_ruin', 'dune', 3], ['ruined_portal', 'eye', 3], ['trial_chambers', 'spire', 3]];
for (const [kind, pattern, weight] of TRIM_LOOT) EXTRA_LOOT[kind].items.push([pattern + '_armor_trim_smithing_template', 1, 1, weight]);

/** Region size (blocks) of the placement grid for a structure in a dimension, or 0 when it never generates there. */
export function regionSize(what: string, dim = 'overworld'): number {
  const kind = ALIASES[what];
  return SPECS.find(k => k.kind === kind && k.dim === dim)?.region ?? 0;
}
/** The (cached) site of `what` inside placement region (rx, rz) — the building block of the incremental explorer-map search. */
export function siteAt(t: Terrain, what: string, rx: number, rz: number): Placed | null {
  const kind = ALIASES[what], s = SPECS.find(k => k.kind === kind && k.dim === t.dimension);
  return s ? site(t, s, rx, rz) : null;
}
/** Every site of `what` whose footprint may touch the square of half-size `r` around (x, z). */
export function sitesNear(t: Terrain, what: string, x: number, z: number, r: number): Placed[] {
  const kind = ALIASES[what], s = SPECS.find(k => k.kind === kind && k.dim === t.dimension), out: Placed[] = [];
  if (!s) return out;
  const reach = r + s.radius;
  for (let rz = Math.floor((z - reach) / s.region); rz <= Math.floor((z + reach) / s.region); rz++) for (let rx = Math.floor((x - reach) / s.region); rx <= Math.floor((x + reach) / s.region); rx++) {
    const p = site(t, s, rx, rz);
    if (p && Math.abs(p.x - x) <= reach && Math.abs(p.z - z) <= reach) out.push(p);
  }
  return out;
}

export function structureOccupants(p: Placed) {
  const result: { key: string; species: 'elder_guardian' | 'vindicator' | 'evoker'; x: number; y: number; z: number }[] = [];
  if (p.kind !== 'monument' && p.kind !== 'mansion') return result;
  const tiers = Math.max(3, Math.min(5, Math.floor((SEA - 2 - p.y) / 3)));
  const occupants: [typeof result[number]['species'], number, number, number][] = p.kind === 'monument'
      ? [['elder_guardian', 0, (tiers - 1) * 3 + 1, 0], ['elder_guardian', -12, 1, 0], ['elder_guardian', 12, 1, 0]]
      : [['vindicator', -9, 0, -5], ['vindicator', 7, 0, 5], ['vindicator', -1, 5, -5], ['vindicator', 7, 10, 5], ['evoker', -9, 5, 5], ['evoker', 7, 10, -5]];
  occupants.forEach(([species, dx, dy, dz], n) => {
    result.push({ key: `${p.kind}:${p.x},${p.z}:${n}`, species, x: p.x + dx + 0.5, y: p.y + dy, z: p.z + dz + 0.5 });
  });
  return result;
}

export function structureMobsInChunk(t: Terrain, cx: number, cz: number) {
  const result: ReturnType<typeof structureOccupants> = [];
  if (t.dimension !== 'overworld') return result;
  for (const kind of ['monument', 'mansion'] as const) {
    const spec = SPECS.find(s => s.kind === kind)!;
    const p = site(t, spec, Math.floor(cx * 16 / spec.region), Math.floor(cz * 16 / spec.region));
    if (p) result.push(...structureOccupants(p).filter(s => Math.floor(s.x / 16) === cx && Math.floor(s.z / 16) === cz));
  }
  return result;
}
