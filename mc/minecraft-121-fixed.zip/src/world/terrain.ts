import { placeExtraStructures, locateExtra, structuresNear, regionSize } from './structures';
import { ruinedPortal as buildRuinedPortal } from './dungeons';
import { grandVillage, grandVillageLayout, villageVariantFor, isZombieVillage } from './struct/villageGrand';
import { rotSize } from './struct/jigsaw';
import { netherFortress, netherFossil, FORTRESS_RADIUS, FORTRESS_Y } from './struct/nether';
import { buildStronghold, STRONGHOLD_RADIUS, STRONGHOLD_Y } from './struct/stronghold';
import { endShip as buildEndShip, desertPyramidBuild } from './struct/extra';
import { buildEndCity, endCityLayout } from './struct/endCity';
import { tag as tagLoot } from './struct/common';
import { OverworldGen } from './overworld';
import { Underground } from './underground';
import {
  placeBlobTree,
  placeFancyOakTree,
  placeSwampOakTree,
  placeSpruceOrPine,
  placeMegaTaigaTree,
  placeMegaJungleTree,
  placeJungleBush,
  placeAcaciaTree,
  placeDarkOakTree,
  placeCherryTree,
  placeMangroveTree,
  placeAzaleaTree,
  placeHugeMushroom,
  placeCoralReef,
  placeIceSpike,
  placeIceberg,
  placeForestRock,
  placeDesertWell,
  placeChorusPlant,
  placeHugeFungus,
} from './features';
import { ID, BLOCKS } from '../game/data';
import { makeCell } from '../game/blockState';
import '../game/content';
import { random, hashSeed } from '../input/math';
import type { Dimension } from '../game/types';

export const CHUNK = 16;
export const HEIGHT = 384;
export const MIN_Y = -64;
/** Vanilla Nether: build limit 0‥128, lava sea surface at Y = 31, 5-layer bedrock gradients at the floor (0‥4) and roof (123‥127). */
export const NETHER_HEIGHT = 128;
export const NETHER_LAVA = 31;
/** Vanilla sea level 63 means the topmost water block sits at Y = 62: every ocean, lake and river surface is `SEA`. */
export const SEA = 62;

const B = ID as Record<string, number | undefined>;

/**
 * Every biome this generator can produce, with the English and Japanese names used by the UI (Minecraft Wiki naming).
 * Keep this list in sync with biomeAt(): the biome regression test (scripts/verify-biomes.ts) fails when a label is missing.
 */
export const BIOME_LABELS: Record<string, { en: string; ja: string; group: 'overworld' | 'nether' | 'end' }> = {
  // Cave biomes
  lush_caves: { en: 'Lush Caves', ja: '繁茂した洞窟', group: 'overworld' },
  dripstone_caves: { en: 'Dripstone Caves', ja: '鍾乳洞', group: 'overworld' },
  deep_dark: { en: 'Deep Dark', ja: 'ディープダーク', group: 'overworld' },
  // Overworld flat / temperate / forest biomes
  plains: { en: 'Plains', ja: '平原', group: 'overworld' },
  sunflower_plains: { en: 'Sunflower Plains', ja: 'ヒマワリ平原', group: 'overworld' },
  forest: { en: 'Forest', ja: '森', group: 'overworld' },
  birch_forest: { en: 'Birch Forest', ja: 'シラカバの森', group: 'overworld' },
  old_growth_birch_forest: { en: 'Old Growth Birch Forest', ja: 'シラカバの原生林', group: 'overworld' },
  flower_forest: { en: 'Flower Forest', ja: '花畑の森', group: 'overworld' },
  dark_forest: { en: 'Dark Forest', ja: '暗い森', group: 'overworld' },
  taiga: { en: 'Taiga', ja: 'タイガ', group: 'overworld' },
  old_growth_pine_taiga: { en: 'Old Growth Pine Taiga', ja: 'マツの原生林', group: 'overworld' },
  old_growth_spruce_taiga: { en: 'Old Growth Spruce Taiga', ja: 'トウヒの原生林', group: 'overworld' },
  snowy_taiga: { en: 'Snowy Taiga', ja: '雪のタイガ', group: 'overworld' },
  snowy_plains: { en: 'Snowy Plains', ja: '雪原', group: 'overworld' },
  ice_spikes: { en: 'Ice Spikes', ja: '樹氷', group: 'overworld' },
  // Overworld highland & mountain biomes
  meadow: { en: 'Meadow', ja: '草地', group: 'overworld' },
  cherry_grove: { en: 'Cherry Grove', ja: '桜の林', group: 'overworld' },
  grove: { en: 'Grove', ja: '林', group: 'overworld' },
  snowy_slopes: { en: 'Snowy Slopes', ja: '雪の斜面', group: 'overworld' },
  jagged_peaks: { en: 'Jagged Peaks', ja: 'ギザギザの山頂', group: 'overworld' },
  frozen_peaks: { en: 'Frozen Peaks', ja: '凍った山頂', group: 'overworld' },
  stony_peaks: { en: 'Stony Peaks', ja: '石の山頂', group: 'overworld' },
  windswept_hills: { en: 'Windswept Hills', ja: '吹きさらしの丘', group: 'overworld' },
  windswept_gravelly_hills: { en: 'Windswept Gravelly Hills', ja: '吹きさらしの砂利の丘', group: 'overworld' },
  windswept_forest: { en: 'Windswept Forest', ja: '吹きさらしの森', group: 'overworld' },
  // Overworld warm / arid / lush / wetland biomes
  desert: { en: 'Desert', ja: '砂漠', group: 'overworld' },
  savanna: { en: 'Savanna', ja: 'サバンナ', group: 'overworld' },
  savanna_plateau: { en: 'Savanna Plateau', ja: 'サバンナ台地', group: 'overworld' },
  windswept_savanna: { en: 'Windswept Savanna', ja: '吹きさらしのサバンナ', group: 'overworld' },
  jungle: { en: 'Jungle', ja: 'ジャングル', group: 'overworld' },
  sparse_jungle: { en: 'Sparse Jungle', ja: 'まばらなジャングル', group: 'overworld' },
  bamboo_jungle: { en: 'Bamboo Jungle', ja: '竹林', group: 'overworld' },
  swamp: { en: 'Swamp', ja: '沼地', group: 'overworld' },
  mangrove_swamp: { en: 'Mangrove Swamp', ja: 'マングローブの沼地', group: 'overworld' },
  badlands: { en: 'Badlands', ja: 'バッドランド', group: 'overworld' },
  eroded_badlands: { en: 'Eroded Badlands', ja: '荒れたバッドランド', group: 'overworld' },
  wooded_badlands: { en: 'Wooded Badlands', ja: '森のあるバッドランド', group: 'overworld' },
  mushroom_fields: { en: 'Mushroom Fields', ja: 'キノコ島', group: 'overworld' },
  // Coast, river & ocean biomes
  beach: { en: 'Beach', ja: '砂浜', group: 'overworld' },
  snowy_beach: { en: 'Snowy Beach', ja: '雪の砂浜', group: 'overworld' },
  stony_shore: { en: 'Stony Shore', ja: '石だらけの海岸', group: 'overworld' },
  river: { en: 'River', ja: '河川', group: 'overworld' },
  frozen_river: { en: 'Frozen River', ja: '凍った川', group: 'overworld' },
  warm_ocean: { en: 'Warm Ocean', ja: '暖かい海', group: 'overworld' },
  lukewarm_ocean: { en: 'Lukewarm Ocean', ja: 'ぬるい海', group: 'overworld' },
  deep_lukewarm_ocean: { en: 'Deep Lukewarm Ocean', ja: 'ぬるい深海', group: 'overworld' },
  ocean: { en: 'Ocean', ja: '海洋', group: 'overworld' },
  deep_ocean: { en: 'Deep Ocean', ja: '深海', group: 'overworld' },
  cold_ocean: { en: 'Cold Ocean', ja: '冷たい海', group: 'overworld' },
  deep_cold_ocean: { en: 'Deep Cold Ocean', ja: '冷たい深海', group: 'overworld' },
  frozen_ocean: { en: 'Frozen Ocean', ja: '凍った海', group: 'overworld' },
  deep_frozen_ocean: { en: 'Deep Frozen Ocean', ja: '凍った深海', group: 'overworld' },
  // Nether
  nether_wastes: { en: 'Nether Wastes', ja: 'ネザーの荒れ地', group: 'nether' },
  crimson_forest: { en: 'Crimson Forest', ja: '真紅の森', group: 'nether' },
  warped_forest: { en: 'Warped Forest', ja: '歪んだ森', group: 'nether' },
  soul_sand_valley: { en: 'Soul Sand Valley', ja: 'ソウルサンドの谷', group: 'nether' },
  basalt_deltas: { en: 'Basalt Deltas', ja: '玄武岩の三角州', group: 'nether' },
  // End
  the_end: { en: 'The End', ja: 'ジ・エンド', group: 'end' },
};

/** Full 64-biome Java Edition 1.21 registry including the 4 End outer-island sub-biomes and The Void. */
export const ALL_BIOME_LABELS: Record<string, { en: string; ja: string; group: 'overworld' | 'nether' | 'end' | 'void' }> = {
  ...BIOME_LABELS,
  end_highlands: { en: 'End Highlands', ja: 'エンドの高地', group: 'end' },
  end_midlands: { en: 'End Midlands', ja: 'エンドの中央地', group: 'end' },
  small_end_islands: { en: 'Small End Islands', ja: '小さなエンドの島', group: 'end' },
  end_barrens: { en: 'End Barrens', ja: 'エンドの荒地', group: 'end' },
  the_void: { en: 'The Void', ja: '奈落', group: 'void' },
};

// Vanilla grass/foliage tints calibrated for #969696 base texture (Minecraft Wiki Block colors)
export const BIOME_TINTS: Record<string, [number, number, number]> = {
  plains: [0.97, 1.25, 0.60],                   // #91bd59
  sunflower_plains: [0.97, 1.25, 0.60],
  forest: [0.81, 1.28, 0.60],                   // #79c05a
  flower_forest: [0.81, 1.28, 0.60],
  birch_forest: [0.91, 1.24, 0.69],             // #88bb67
  old_growth_birch_forest: [0.91, 1.24, 0.69],
  dark_forest: [0.53, 0.88, 0.45],              // #507a32 (deep dark-forest bog-emerald)
  taiga: [0.89, 1.22, 0.87],                    // #86b783
  old_growth_spruce_taiga: [0.89, 1.22, 0.87],
  old_growth_pine_taiga: [0.89, 1.23, 0.85],    // #86b87f
  snowy_taiga: [0.85, 1.20, 1.00],              // #80b497
  snowy_plains: [0.85, 1.20, 1.00],
  ice_spikes: [0.85, 1.20, 1.00],
  snowy_slopes: [0.85, 1.20, 1.00],
  grove: [0.85, 1.20, 1.00],
  frozen_peaks: [0.85, 1.20, 1.00],
  jagged_peaks: [0.85, 1.20, 1.00],
  stony_peaks: [1.03, 1.26, 0.50],              // #9abe4b
  windswept_hills: [0.92, 1.21, 0.91],          // #8ab689
  windswept_gravelly_hills: [0.92, 1.21, 0.91],
  windswept_forest: [0.92, 1.21, 0.91],
  meadow: [0.88, 1.32, 0.72],                   // #83bb6d
  cherry_grove: [1.21, 1.46, 0.65],             // #b6db61
  desert: [1.27, 1.21, 0.57],                   // #bfb755
  savanna: [1.27, 1.22, 0.57],
  savanna_plateau: [1.27, 1.22, 0.57],
  windswept_savanna: [1.27, 1.22, 0.57],
  jungle: [0.59, 1.34, 0.41],                   // #59c93c
  sparse_jungle: [0.68, 1.32, 0.44],            // #64c73f
  bamboo_jungle: [0.59, 1.34, 0.41],
  swamp: [0.70, 0.75, 0.38],                    // #6a7039
  mangrove_swamp: [0.51, 0.79, 0.40],           // #4c763c
  badlands: [0.96, 0.86, 0.51],                 // #90814d
  eroded_badlands: [0.96, 0.86, 0.51],
  wooded_badlands: [0.96, 0.86, 0.51],
  mushroom_fields: [0.57, 1.34, 0.42],          // #55c93f
  beach: [0.97, 1.25, 0.60],
  snowy_beach: [0.85, 1.20, 1.00],
  stony_shore: [0.92, 1.21, 0.91],
  river: [0.94, 1.22, 0.72],
  ocean: [0.94, 1.22, 0.72],
  deep_ocean: [0.94, 1.22, 0.72],
  cold_ocean: [0.90, 1.18, 0.85],
  deep_cold_ocean: [0.90, 1.18, 0.85],
  lukewarm_ocean: [0.96, 1.24, 0.64],
  deep_lukewarm_ocean: [0.96, 1.24, 0.64],
  warm_ocean: [0.98, 1.26, 0.58],
  frozen_river: [0.85, 1.20, 1.00],
  frozen_ocean: [0.85, 1.20, 1.00],
  deep_frozen_ocean: [0.85, 1.20, 1.00],
  nether_wastes: [1.0, 1.0, 1.0],
  crimson_forest: [1.1, 0.7, 0.7],
  warped_forest: [0.6, 1.1, 1.1],
  soul_sand_valley: [0.8, 0.7, 0.7],
  basalt_deltas: [0.8, 0.8, 0.8],
  the_end: [1.0, 1.0, 1.0],
  end_highlands: [1.0, 1.0, 1.0],
  end_midlands: [1.0, 1.0, 1.0],
  small_end_islands: [1.0, 1.0, 1.0],
  end_barrens: [1.0, 1.0, 1.0],
  the_void: [1.0, 1.0, 1.0],
};

function grad3(h: number, x: number, y: number, z: number): number {
  h &= 15;
  const u = h < 8 ? x : y, v = h < 4 ? y : h === 12 || h === 14 ? x : z;
  return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
}

function grad2(h: number, gx: number, gz: number): number {
  switch (h & 7) {
    case 0: return gx + gz;
    case 1: return -gx + gz;
    case 2: return gx - gz;
    case 3: return -gx - gz;
    case 4: return gx;
    case 5: return -gx;
    case 6: return gz;
    default: return -gz;
  }
}

export class Noise {
  p = new Uint8Array(512);
  constructor(seed: number) {
    const r = random(seed), a = Array.from({ length: 256 }, (_, i) => i);
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(r() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    for (let i = 0; i < 512; i++) this.p[i] = a[i & 255];
  }
  fade(t: number) { return t * t * t * (t * (t * 6 - 15) + 10); }
  grad(h: number, x: number, y: number, z: number) {
    return grad3(h, x, y, z);
  }
  n3(x: number, y: number, z: number) {
    const fx = Math.floor(x), fy = Math.floor(y), fz = Math.floor(z);
    const X = fx & 255, Y = fy & 255, Z = fz & 255;
    x -= fx; y -= fy; z -= fz;
    const u = x * x * x * (x * (x * 6 - 15) + 10);
    const v = y * y * y * (y * (y * 6 - 15) + 10);
    const w = z * z * z * (z * (z * 6 - 15) + 10);
    const p = this.p;
    const A = p[X] + Y, AA = p[A] + Z, AB = p[A + 1] + Z, B = p[X + 1] + Y, BA = p[B] + Z, BB = p[B + 1] + Z;
    const g000 = grad3(p[AA], x, y, z), g100 = grad3(p[BA], x - 1, y, z);
    const g010 = grad3(p[AB], x, y - 1, z), g110 = grad3(p[BB], x - 1, y - 1, z);
    const g001 = grad3(p[AA + 1], x, y, z - 1), g101 = grad3(p[BA + 1], x - 1, y, z - 1);
    const g011 = grad3(p[AB + 1], x, y - 1, z - 1), g111 = grad3(p[BB + 1], x - 1, y - 1, z - 1);
    const x00 = g000 + (g100 - g000) * u, x10 = g010 + (g110 - g010) * u;
    const x01 = g001 + (g101 - g001) * u, x11 = g011 + (g111 - g011) * u;
    const y0 = x00 + (x10 - x00) * v, y1 = x01 + (x11 - x01) * v;
    return y0 + (y1 - y0) * w;
  }
  /** Fast dedicated 2D gradient noise (4 lattice corners instead of 8 in n3). */
  n2(x: number, z: number) {
    const fx = Math.floor(x), fz = Math.floor(z);
    const X = fx & 255, Z = fz & 255;
    const dx = x - fx, dz = z - fz;
    const u = dx * dx * dx * (dx * (dx * 6 - 15) + 10);
    const v = dz * dz * dz * (dz * (dz * 6 - 15) + 10);
    const p = this.p;
    const A = p[X] + Z, B = p[X + 1] + Z;
    const n00 = grad2(p[A], dx, dz), n10 = grad2(p[B], dx - 1, dz);
    const n01 = grad2(p[A + 1], dx, dz - 1), n11 = grad2(p[B + 1], dx - 1, dz - 1);
    const ix0 = n00 + (n10 - n00) * u;
    const ix1 = n01 + (n11 - n01) * u;
    return ix0 + (ix1 - ix0) * v;
  }
  fbm(x: number, z: number, octaves = 4) {
    let value = 0, amp = 0.57;
    for (let i = 0; i < octaves; i++) {
      value += this.n2(x, z) * amp;
      x *= 2.03; z *= 2.03; amp *= 0.5;
    }
    return value;
  }
}

export const smooth = (a: number, b: number, x: number) => {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

export function coordHash(x: number, z: number, seed: number) {
  let h = Math.imul(x, 374761393) ^ Math.imul(z, 668265263) ^ seed;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

type PutFn = (x: number, y: number, z: number, id: number, replace?: boolean) => void;

/** Main-island surface of the End (vanilla: the central island tops out around Y 60–64). */
export const END_ISLAND_Y = 60;
/** Vanilla end gateways ring the main island at distance 96, Y = 75. */
export const END_GATEWAY_MAIN: readonly [number, number, number] = [96, 75, 0];
/** The outer islands begin 1,000 blocks out; the gateway drops the player on the small arrival island at radius 1,024. */
export const END_OUTER_RADIUS = 1000;
export const END_OUTER_ARRIVAL: readonly [number, number, number] = [1024, 61, 0];
/** Fixed outer-island end city + end ship (the first city most players reach after the dragon). */
export const END_FIRST_CITY: readonly [number, number] = [1018, 8];
export const END_FIRST_SHIP: readonly [number, number, number] = [1038, 70, -18];
/** Radius of the ring of obsidian pillars (vanilla: 42 blocks from the exit portal). */
export const END_PILLAR_RADIUS = 42;

/**
 * Vanilla end spikes (Minecraft Wiki "Obsidian pillar"): exactly 10 pillars on a circle of radius 42, heights 76‥103 in
 * 3-block steps, radius 2‥5 (the taller the wider); the two shortest pillars carry an iron-bar cage around the crystal.
 */
export function endPillars(): { x: number; z: number; h: number; r: number; caged: boolean }[] {
  const res = [];
  for (let i = 0; i < 10; i++) {
    const a = (i * Math.PI * 2) / 10;
    res.push({
      x: Math.round(Math.cos(a) * END_PILLAR_RADIUS),
      z: Math.round(Math.sin(a) * END_PILLAR_RADIUS),
      h: 76 + i * 3,
      r: 2 + Math.floor(i / 3),           // 2,2,2,3,3,3,4,4,4,5
      caged: i === 0 || i === 1,
    });
  }
  return res;
}

/** Half-size of the surface footprint of the extra structures (see structures.ts SPECS). */
const SURFACE_RADIUS: Record<string, number> = { mansion: 36, outpost: 12, ruined_portal: 7, trail_ruins: 11, jungle_temple: 9, igloo: 6 };

/** Largest canopy radius any generated tree / huge mushroom can reach from its trunk. */
export const CANOPY_RADIUS = 6;

/** Structure footprint (XZ bounding box, inclusive) recorded during the structure phase so that no vegetation may grow inside. */
export interface Footprint { x0: number; z0: number; x1: number; z1: number; kind: string }
/** Buffer around every structure where trees, huge mushrooms, bamboo, grass and flowers never generate (vanilla + 2 blocks). */
export const FOOTPRINT_BUFFER = 2;

export class Terrain {
  seed: number;
  noise: Noise;
  dimension: Dimension;
  /** Vanilla-style multi-noise source for overworld height and biomes (see overworld.ts). */
  gen: OverworldGen;
  /** "x,y,z" → loot table / fixed contents of generated chests, dispensers, brewing stands and item frames. */
  structTags = new Map<string, string>();
  private structCache = new Map<number, ReturnType<Terrain['regionStructureCompute']>>();
  /** Seed-deterministic 192-layer Badlands terracotta color band table (Minecraft Wiki spec). */
  private badlandsBands: number[];
  // Reusable chunk generation scratch buffers (eliminates >250KB GC allocation per chunk)
  private _padded = new Uint16Array(18 * 18 * HEIGHT);
  private _lastMaxLocalY = HEIGHT;
  private _hMap = new Int16Array(20 * 20);
  private _tintGrid = new Float32Array(20 * 20 * 3);
  private _biomeGrid: string[] = new Array(400);
  private _caveGrid = new Float32Array(6 * 6 * 50);
  private _tubeGrid = new Float32Array(6 * 6 * 50);
  private _veinT = new Float32Array(20);
  private _oreCx = new Float64Array(64);
  private _oreCy = new Float64Array(64);
  private _oreCz = new Float64Array(64);
  private _oreRad = new Float64Array(64);
  /** Aquifers, ore veins and 3D cave biomes (see underground.ts). */
  ug: Underground;
  private _cheeseGrid = new Float32Array(6 * 6 * 50);
  private _spag2AGrid = new Float32Array(6 * 6 * 50);
  private _spag2BGrid = new Float32Array(6 * 6 * 50);
  private _noodleGrid = new Float32Array(6 * 6 * 50);

  constructor(seed: string, dimension: Dimension = 'overworld') {
    this.seed = hashSeed(seed);
    this.noise = new Noise(this.seed);
    this.dimension = dimension;
    this.gen = new OverworldGen(this.noise);
    this.ug = new Underground(this.noise, this.seed, (x, z) => this.height(x, z));
    this.badlandsBands = this.buildBadlandsBands();
  }

  private buildBadlandsBands(): number[] {
    const r = random(this.seed ^ 0x51a9c3);
    const tc = ID.terracotta, or = ID.orange_terracotta, rd = ID.red_terracotta;
    const yl = ID.yellow_terracotta, wh = ID.white_terracotta;
    const br = ID.brown_terracotta ?? tc, lg = ID.light_gray_terracotta ?? tc;
    const bands = new Array<number>(192).fill(tc);
    const paint = (count: number, minW: number, maxW: number, blk: number) => {
      for (let i = 0; i < count; i++) {
        const w = minW + Math.floor(r() * (maxW - minW + 1));
        const p = Math.floor(r() * 192);
        for (let k = 0; k < w && p + k < 192; k++) bands[p + k] = blk;
      }
    };
    paint(18, 2, 4, or);
    paint(16, 1, 3, yl);
    paint(16, 1, 3, br);
    paint(14, 1, 2, rd);
    paint(10, 1, 1, wh);
    paint(8, 1, 2, lg);
    return bands;
  }

  private _spawn: [number, number, number] | null = null;
  /**
   * Vanilla-style spawn search: the world spawn is the first dry, non-ocean column found on an outward spiral from the
   * origin (step 8). Purely seed-deterministic — no hand-placed starter buildings or terrain flattening around it.
   */
  spawnPoint(): [number, number, number] {
    if (this._spawn) return this._spawn;
    if (this.dimension === 'nether') {
      for (let r = 0; r <= 24; r++) for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;
        const x = dx * 4, z = 4 + dz * 4, h = this.height(x, z);
        if (h > NETHER_LAVA && this.netherOpen(x, h + 1, z) && this.netherOpen(x, h + 2, z)) return (this._spawn = [x, h + 1, z]);
      }
      return (this._spawn = [0, NETHER_LAVA + 9, 4]);
    }
    if (this.dimension === 'end') return (this._spawn = [0, END_ISLAND_Y, 42]);
    for (let r = 0; r <= 40; r++) for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
      if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;
      const x = dx * 8, z = dz * 8, h = this.height(x, z);
      if (h <= SEA) continue;
      const b = this.biomeAt(x, z, h);
      if (b.endsWith('ocean') || b === 'river' || b === 'frozen_river') continue;
      return (this._spawn = [x, h + 1, z]);
    }
    return (this._spawn = [0, Math.max(SEA + 1, this.height(0, 0) + 1), 0]);
  }

  spawnPosition(above = 1.05): [number, number, number] {
    const [x, y, z] = this.spawnPoint();
    return [x + 0.5, y + above - 1, z + 0.5];
  }

  spawnYaw(): number {
    if (this.dimension === 'end') return 0;
    return -2.4;
  }

  /**
   * Vanilla Monster Room (Dungeon, `MonsterRoomFeature.java`):
   *  • Interior floor size: (2*rx + 1) × (2*rz + 1) where rx, rz ∈ {2, 3} -> 5×5, 5×7, 7×5, or 7×7 (outer 7×6×7 .. 9×6×9).
   *  • Floor (dy = 0): 75% mossy_cobblestone, 25% cobblestone.
   *  • Walls (dy = 1..4): cobblestone, preserving 1–5 two-block-tall cave openings at floor level (dy = 1..2).
   *  • Ceiling (dy = 5): left as natural terrain / open below air, solid cobblestone where enclosing the chamber.
   *  • Centre (0, 1, 0): Monster Spawner (`zombie` 50%, `skeleton` 25%, `spider` 25%).
   *  • Up to 2 chests placed against interior walls, facing inward and tagged with `simple_dungeon`.
   */
  dungeonAt(cx: number, cz: number): [number, number, number, number, number] | null {
    if (this.dimension !== 'overworld' || coordHash(cx, cz, this.seed + 1234) >= 0.09) return null;
    const ox = cx * 16 + 4 + Math.floor(coordHash(cx, cz, this.seed + 1235) * 8);
    const oz = cz * 16 + 4 + Math.floor(coordHash(cx, cz, this.seed + 1236) * 8);
    const surf = this.height(ox, oz);
    if (surf < SEA + 2) return null;
    const y0 = Math.max(MIN_Y + 5, Math.min(surf - 10, -30 + Math.floor(coordHash(cx, cz, this.seed + 1237) * 70)));
    const rx = coordHash(cx, cz, this.seed + 1238) < 0.5 ? 2 : 3;
    const rz = coordHash(cx, cz, this.seed + 1239) < 0.5 ? 2 : 3;
    return [ox, y0, oz, rx, rz];
  }

  dungeonSpawnerSpecies(cx: number, y: number, cz: number): 'zombie' | 'skeleton' | 'spider' {
    const r = coordHash(cx + y * 31, cz - y * 17, this.seed + 1245);
    return r < 0.5 ? 'zombie' : r < 0.75 ? 'skeleton' : 'spider';
  }

  dungeon(put: PutFn, room: [number, number, number, number, number], checkCave?: (x: number, y: number, z: number) => boolean) {
    const [cx, y0, cz, rx, rz] = room;
    const cob = ID.cobblestone, mossy = ID.mossy_cobblestone ?? cob;
    // Choose 1..2 cave doorway positions on the perimeter (preserving existing cave openings or carving a 1×2 doorway)
    const openDir = Math.floor(coordHash(cx, cz, this.seed + 1242) * 4);
    for (let dy = 0; dy <= 5; dy++) {
      for (let dz = -rz - 1; dz <= rz + 1; dz++) {
        for (let dx = -rx - 1; dx <= rx + 1; dx++) {
          const wx = cx + dx, wy = y0 + dy, wz = cz + dz;
          const wall = Math.abs(dx) === rx + 1 || Math.abs(dz) === rz + 1;
          const corner = Math.abs(dx) === rx + 1 && Math.abs(dz) === rz + 1;
          if (dy === 0) {
            // Vanilla floor: 75% mossy cobblestone, 25% cobblestone
            put(wx, wy, wz, coordHash(wx * 7 + wy, wz * 13, this.seed + 1240) < 0.75 ? mossy : cob, true);
          } else if (dy === 5) {
            put(wx, wy, wz, cob, false);
          } else if (wall) {
            const isDoorway = !corner && (dy === 1 || dy === 2) && (
              (openDir === 0 && dz === -rz - 1 && dx === 0) ||
              (openDir === 1 && dx === rx + 1 && dz === 0) ||
              (openDir === 2 && dz === rz + 1 && dx === 0) ||
              (openDir === 3 && dx === -rx - 1 && dz === 0)
            );
            if (isDoorway && (!checkCave || checkCave(wx, wy, wz))) {
              put(wx, wy, wz, 0, true);
            } else {
              put(wx, wy, wz, cob, true);
            }
          } else {
            put(wx, wy, wz, 0, true);
          }
        }
      }
    }
    put(cx, y0 + 1, cz, ID.spawner ?? cob, true);
    // Up to 2 chests placed against the interior walls, facing the centre of the room
    const c1: [number, number, number] = [cx - rx, y0 + 1, cz + (openDir === 3 ? 1 : 0)];
    put(c1[0], c1[1], c1[2], makeCell(ID.chest, 1), true);
    this.structTags.set(`${c1[0]},${c1[1]},${c1[2]}`, 'simple_dungeon');
    if (coordHash(cx, cz, this.seed + 1241) < 0.85) {
      const c2: [number, number, number] = [cx + (openDir === 0 ? 1 : 0), y0 + 1, cz - rz];
      put(c2[0], c2[1], c2[2], makeCell(ID.chest, 2), true);
      this.structTags.set(`${c2[0]},${c2[1]},${c2[2]}`, 'simple_dungeon');
    }
  }

  locate(what: string, px: number, pz: number): [number, number, number] | null {
    const q = what.toLowerCase();
    const extra = locateExtra(this, q, px, pz);
    if (extra) return extra;
    if (q === 'stronghold' || q === 'end_portal') {
      const [sx, sz] = this.strongholdPos();
      if (Math.hypot(px, pz) < 600) return [sx, STRONGHOLD_Y + 1, sz];
      let bestX = sx, bestZ = sz, bestD = Math.hypot(sx - px, sz - pz);
      for (const [rx, rz] of this.strongholdRings()) {
        const d = Math.hypot(rx - px, rz - pz);
        if (d < bestD) { bestD = d; bestX = rx; bestZ = rz; }
      }
      return [bestX, STRONGHOLD_Y + 1, bestZ];
    }
    if (q === 'endship' || q === 'end_ship') return [END_FIRST_SHIP[0], END_FIRST_SHIP[1] + 5, END_FIRST_SHIP[2] + 12];
    if (q === 'endcity' || q === 'end_city') {
      const first: [number, number, number] = [END_FIRST_CITY[0] + 4, END_ISLAND_Y, END_FIRST_CITY[1]];
      if (Math.hypot(px, pz) < 1200) return first;
      const [arx, , arz] = END_OUTER_ARRIVAL;
      const erx = Math.floor(px / 144), erz = Math.floor(pz / 144);
      let best: [number, number, number] = first, bestD = Math.hypot(first[0] - px, first[2] - pz);
      for (let dz = -10; dz <= 10; dz++) for (let dx = -10; dx <= 10; dx++) {
        const rx2 = erx + dx, rz2 = erz + dz;
        const ex = rx2 * 144 + 72, ez = rz2 * 144 + 72;
        if (Math.hypot(ex, ez) < END_OUTER_RADIUS + 60 || Math.hypot(ex - arx, ez - arz) < 90) continue;
        if (coordHash(rx2, rz2, this.seed + 9876) < 0.35 && this.height(ex, ez) >= END_ISLAND_Y - 12) {
          const d = Math.hypot(ex - px, ez - pz);
          if (d < bestD) { bestD = d; best = [ex, END_ISLAND_Y, ez]; }
        }
      }
      return best;
    }
    if (q === 'fortress' || q === 'nether_fortress') {
      if (Math.hypot(px, pz) < 120) return [32, FORTRESS_Y, 32];
      const nrx = Math.floor(px / 128), nrz = Math.floor(pz / 128);
      let best: [number, number, number] = [32, FORTRESS_Y, 32], bestD = Math.hypot(32 - px, 32 - pz);
      for (let dz = -10; dz <= 10; dz++) for (let dx = -10; dx <= 10; dx++) {
        const rrx = nrx + dx, rrz = nrz + dz;
        if ((rrx === 0 && rrz === 0) || coordHash(rrx, rrz, this.seed + 5555) < 0.42) {
          const fx = rrx === 0 && rrz === 0 ? 32 : rrx * 128 + 48;
          const fz = rrx === 0 && rrz === 0 ? 32 : rrz * 128 + 48;
          const d = Math.hypot(fx - px, fz - pz);
          if (d < bestD) { bestD = d; best = [fx, FORTRESS_Y, fz]; }
        }
      }
      return best;
    }
    const pcx = Math.floor(px / 16), pcz = Math.floor(pz / 16);
    if (q === 'dungeon' || q === 'spawner') {
      let best: [number, number, number] | null = null, bestD = Infinity;
      for (let dz = -24; dz <= 24; dz++) for (let dx = -24; dx <= 24; dx++) {
        const d = this.dungeonAt(pcx + dx, pcz + dz);
        if (d) {
          const dist = Math.hypot(d[0] - px, d[2] - pz);
          if (dist < bestD) { bestD = dist; best = [d[0], d[1] + 1, d[2]]; }
        }
      }
      return best;
    }
    if (q === 'zombie_village' || q === 'abandoned_village') {
      const prx = Math.floor(px / 112), prz = Math.floor(pz / 112);
      let best: [number, number, number] | null = null, bestD = Infinity;
      for (let dz = -32; dz <= 32; dz++) for (let dx = -32; dx <= 32; dx++) {
        const s = this.regionStructure(prx + dx, prz + dz);
        if (!s || (s.type !== 'plains_village' && s.type !== 'desert_village')) continue;
        if (!isZombieVillage(this.seed, s.x, s.z)) continue;
        const dist = Math.hypot(s.x - px, s.z - pz);
        if (dist < bestD) { bestD = dist; best = [s.x, this.height(s.x, s.z) + 1, s.z]; }
      }
      return best;
    }
    if (['village', 'plains_village', 'desert_village', 'pyramid', 'desert_pyramid', 'temple', 'ruined_portal', 'witch_hut', 'desert_fossil', 'outpost', 'pillager_outpost'].includes(q)) {
      if (q === 'outpost' || q === 'pillager_outpost') return null;
      const prx = Math.floor(px / 112), prz = Math.floor(pz / 112);
      let best: [number, number, number] | null = null, bestD = Infinity;
      for (let dz = -12; dz <= 12; dz++) for (let dx = -12; dx <= 12; dx++) {
        const s = this.regionStructure(prx + dx, prz + dz);
        if (!s) continue;
        const match =
          (q === 'village' && (s.type === 'plains_village' || s.type === 'desert_village')) ||
          ((q === 'pyramid' || q === 'temple' || q === 'desert_pyramid') && s.type === 'desert_pyramid') ||
          s.type === q;
        if (match) {
          const dist = Math.hypot(s.x - px, s.z - pz);
          if (dist < bestD) { bestD = dist; best = [s.x, this.height(s.x, s.z) + 1, s.z]; }
        }
      }
      return best;
    }
    // Spiral biome search (faster and reaches 4000+ blocks cleanly)
    for (let r = 0; r <= 120; r++) {
      const step = r < 24 ? 16 : 32;
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;
        const wx = Math.round(px) + dx * step, wz = Math.round(pz) + dz * step;
        if (this.biome(wx, wz) === q) return [wx, this.height(wx, wz) + 1, wz];
      }
    }
    return null;
  }

  strongholdPos(): [number, number] {
    const a = coordHash(17, 29, this.seed + 42) * Math.PI * 2;
    const d = 58 + coordHash(31, 47, this.seed + 77) * 24;
    return [Math.round(Math.cos(a) * d), Math.round(Math.sin(a) * d)];
  }

  /**
   * Vanilla Java Edition 1.21 Stronghold placement: 128 strongholds across 8 concentric rings
   * with counts [3, 6, 10, 15, 21, 28, 36, 9] at radii 1,280..24,320 blocks from the origin.
   */
  strongholdRings(): [number, number][] {
    const counts = [3, 6, 10, 15, 21, 28, 36, 9];
    const out: [number, number][] = [];
    for (let ring = 0; ring < counts.length; ring++) {
      const n = counts[ring];
      const rMin = 1280 + ring * 3072;
      const rSpan = 1536;
      const baseAngle = coordHash(ring, 11, this.seed + 4201) * Math.PI * 2;
      for (let i = 0; i < n; i++) {
        const theta = baseAngle + (i * Math.PI * 2) / n + (coordHash(ring * 64 + i, 23, this.seed + 4202) - 0.5) * (Math.PI / (n * 2));
        const r = rMin + coordHash(ring * 64 + i, 37, this.seed + 4203) * rSpan;
        out.push([Math.round(Math.cos(theta) * r), Math.round(Math.sin(theta) * r)]);
      }
    }
    return out;
  }

  private outerEndIslandMask(x: number, z: number): number {
    const dMain = Math.hypot(x, z);
    if (dMain <= 104) return 1 - smooth(80, 104, dMain);
    if (dMain < END_OUTER_RADIUS) return 0;                       // the void gap between the main island and the outer islands
    const dArr = Math.hypot(x - END_OUTER_ARRIVAL[0], z - END_OUTER_ARRIVAL[2]);
    if (dArr < 44) return 1 - smooth(28, 44, dArr);
    const dShip = Math.hypot(x - END_FIRST_SHIP[0], z - END_FIRST_SHIP[2]);
    if (dShip < 14) return 0;
    const n = this.noise.fbm(x * 0.014 + 410, z * 0.014 - 230, 3);
    return smooth(0.16, 0.34, n) * smooth(END_OUTER_RADIUS, END_OUTER_RADIUS + 48, dMain);
  }

  /** Nether 2-D "floor" heightmap that biases the 3-D density (large basins → lava seas, ridges → netherrack plateaus). */
  private netherFloor(x: number, z: number): number {
    let raw = 36 + this.noise.fbm(x * 0.022, z * 0.022, 3) * 20 + this.noise.n2(x * 0.08, z * 0.08) * 3;
    const basin = this.noise.fbm(x * 0.009 - 60, z * 0.009 + 90, 2);
    if (basin > 0.04) raw -= Math.min(26, (basin - 0.04) * 130);                 // wide lava-sea basins
    return raw;
  }

  /**
   * Vanilla-style 3-D Nether density: solid where > 0. A low-frequency 3-D noise field is biased towards solid near the
   * floor (Y ≤ ~35) and the ceiling (Y ≥ ~110), which yields several stacked cave layers, cliffs and open lava seas.
   */
  netherDensity(x: number, y: number, z: number): number {
    const floor = this.netherFloor(x, z);
    const n = this.noise.n3(x * 0.026, y * 0.048, z * 0.026) * 1.1 + this.noise.n3(x * 0.07 + 50, y * 0.11, z * 0.07 - 50) * 0.3;
    const floorBias = y < floor ? (floor - y) * 0.06 : Math.max(-0.5, (floor - y) * 0.035);   // solid below the floor heightmap, open above
    const ceilBias = Math.max(0, (y - 104) * 0.08);                            // the roof closes in above Y ~104
    // Two stacked shelves (≈ Y 60‥78 and ≈ Y 84‥98, wandering with 2-D noise) give the vanilla multi-layer caverns.
    const s1 = this.noise.n2(x * 0.03 + 9, z * 0.03 - 9) * 14 + 69, s2 = this.noise.n2(x * 0.03 - 21, z * 0.03 + 17) * 10 + 91;
    const layer = Math.max(0, 0.45 - Math.abs(s1 - y) * 0.06) + Math.max(0, 0.38 - Math.abs(s2 - y) * 0.07);
    return n + floorBias + ceilBias + layer + 0.08;
  }
  private netherSolid(x: number, y: number, z: number): boolean {
    if (y <= 0 || y >= NETHER_HEIGHT - 1) return true;
    return this.netherDensity(x, y, z) > 0;
  }
  netherOpen(x: number, y: number, z: number): boolean { return !this.netherSolid(x, y, z); }

  height(x: number, z: number): number {
    if (this.dimension === 'nether') {
      // Highest walkable floor (solid with air above) below the roof; lava-sea columns report the lava surface.
      for (let y = 100; y > NETHER_LAVA; y--) {
        if (this.netherSolid(x, y, z) && !this.netherSolid(x, y + 1, z)) return y;
      }
      return NETHER_LAVA;
    }
    if (this.dimension === 'end') {
      const dMain = Math.hypot(x, z);
      if (dMain <= 108) {
        if (dMain > 104) return -20;
        const base = END_ISLAND_Y - 3 + this.noise.fbm(x * 0.035, z * 0.035, 3) * 5;
        const b = smooth(10, 24, dMain);
        return Math.floor(END_ISLAND_Y * (1 - b) + base * b - smooth(80, 104, dMain) * 12);
      }
      const mask = this.outerEndIslandMask(x, z);
      if (mask <= 0.05) return -20;
      const dArr = Math.hypot(x - END_OUTER_ARRIVAL[0], z - END_OUTER_ARRIVAL[2]);
      if (dArr < 34) return END_OUTER_ARRIVAL[1] - 1 + Math.floor(this.noise.n2(x * 0.06, z * 0.06) * 2 * smooth(16, 30, dArr));
      return Math.floor(END_ISLAND_Y - 8 + mask * 10 + this.noise.n2(x * 0.04, z * 0.04) * 3);
    }

    // Pure multi-noise terrain: no spawn flattening and no village-wide levelling (structures use a per-building beardifier).
    return Math.max(MIN_Y + 8, Math.min(MIN_Y + HEIGHT - 24, Math.floor(this.gen.column(x, z).hf)));
  }

  biomeAt(x: number, z: number, h?: number): string {
    if (this.dimension === 'nether') {
      // Mojang 1.16+ Nether Multi-Noise biome selector (T, H + offset squared distance)
      const t = this.noise.fbm(x * 0.0065 + 120, z * 0.0065 - 80, 2) * 1.25;
      const hu = this.noise.fbm(x * 0.0065 - 90, z * 0.0065 + 140, 2) * 1.25;
      const pts: readonly [string, number, number, number][] = [
        ['nether_wastes', 0.0, 0.0, 0.0],
        ['crimson_forest', 0.4, 0.0, 0.0],
        ['soul_sand_valley', 0.0, -0.5, 0.0],
        ['basalt_deltas', -0.5, 0.0, 0.175],
        ['warped_forest', 0.0, 0.5, 0.375],
      ];
      let best = 'nether_wastes', bestD = Infinity;
      for (const [name, bt, bh, off] of pts) {
        const d = (t - bt) ** 2 + (hu - bh) ** 2 + off * off;
        if (d < bestD) { bestD = d; best = name; }
      }
      return best;
    }
    if (this.dimension === 'end') {
      const r = Math.hypot(x, z);
      if (r <= 104) return 'the_end';
      if (r < END_OUTER_RADIUS) return 'small_end_islands';
      const m = this.outerEndIslandMask(x, z);
      if (m >= 0.52) return 'end_highlands';
      if (m >= 0.22) return 'end_midlands';
      return m > 0.02 ? 'end_barrens' : 'small_end_islands';
    }
    return this.gen.biomeAt(x, z, h);
  }

  /** Underground biome at a block position (3D distribution), or null on the surface / in ordinary caves. */
  caveBiome(x: number, y: number, z: number): string | null {
    if (this.dimension !== 'overworld' || y > 56) return null;
    const h = this.height(x, z);
    if (y > h - 8) return null;
    const c = this.gen.column(x, z);
    return this.ug.caveBiomeAt(x, y, z, c.E, c.H, c.C, h);
  }

  /**
   * Ecotone: near a biome border the vegetation / snow cover of the neighbouring biome bleeds in a few blocks
   * (the biome is sampled at a hashed offset of 3-14 blocks), so borders fade over ~10 blocks instead of snapping.
   * Water, rivers, beaches and mushroom islands keep their own biome.
   */
  ecotone(b: string, x: number, z: number, h: number): string {
    if (this.dimension !== 'overworld' || h < SEA || b.endsWith('ocean') || b === 'river' || b === 'frozen_river' || b === 'beach' || b === 'snowy_beach' || b === 'stony_shore' || b === 'mushroom_fields') return b;
    const a = coordHash(x, z, this.seed + 3301) * 6.2831853, r = 3 + coordHash(x, z, this.seed + 3302) * 11;
    const nb = this.gen.biomeAt(x + Math.round(Math.cos(a) * r), z + Math.round(Math.sin(a) * r));
    if (nb === b || nb.endsWith('ocean') || nb === 'river' || nb === 'frozen_river' || nb === 'beach' || nb === 'snowy_beach' || nb === 'stony_shore' || nb === 'mushroom_fields') return b;
    return nb;
  }

  biome(x: number, z: number) { return this.biomeAt(x, z, this.height(x, z)); }

  /** Top surface block for column (x, z), following vanilla Surface Rules. */
  surface(biome: string, x: number, z: number, h = SEA + 5): number {
    if (biome === 'desert' || biome === 'beach' || biome === 'snowy_beach') return ID.sand;
    if (biome === 'ocean' || biome === 'deep_ocean' || biome === 'cold_ocean' || biome === 'deep_cold_ocean' || biome === 'frozen_ocean' || biome === 'deep_frozen_ocean') {
      const n = this.noise.n2(x * 0.14 + 17, z * 0.14 - 31);
      if (h < SEA - 24) return n > 0.32 ? ID.sand : n < -0.35 ? ID.clay : ID.gravel;
      return n > 0.15 ? ID.gravel : n < -0.35 ? ID.clay : ID.sand;
    }
    if (biome === 'warm_ocean' || biome === 'lukewarm_ocean' || biome === 'deep_lukewarm_ocean') {
      const n = this.noise.n2(x * 0.14 + 41, z * 0.14 + 19);
      return n < -0.38 ? ID.clay : n > 0.35 ? ID.gravel : ID.sand;
    }
    if (biome === 'river' || biome === 'frozen_river') {
      if (h < SEA) {
        const n = this.noise.n2(x * 0.16 + 19, z * 0.16 - 7);
        return n < -0.25 ? ID.clay : n > 0.15 ? ID.gravel : ID.sand;
      }
      return ID.sand;
    }
    if (biome === 'stony_shore') {
      const n = this.noise.n2(x * 0.15 + 21, z * 0.15 - 11);
      return n < 0.25 ? ID.stone : ID.gravel;
    }
    if (biome === 'snowy_slopes') return ID.snow_block;
    if (biome === 'jagged_peaks') return h > 118 ? ID.snow_block : ID.stone;
    if (biome === 'frozen_peaks') {
      const n = this.noise.n2(x * 0.12 + 5, z * 0.12 + 5);
      return n > 0.22 ? ID.packed_ice : n > 0.12 ? ID.ice : ID.snow_block;
    }
    if (biome === 'stony_peaks') {
      const cal = Math.abs(this.noise.n2(x * 0.045 - 12.3, z * 0.045 + 31.7));
      if (cal < 0.045) return ID.calcite ?? ID.stone;
      return this.noise.n2(x * 0.16 + 8, z * 0.16 - 8) > 0.32 ? ID.gravel : ID.stone;
    }
    if (biome === 'grove') return ID.snow_block;
    if (biome === 'ice_spikes') return ID.snow_block;
    if (biome === 'snowy_plains' || biome === 'snowy_taiga') return ID.grass_block; // snow_layer placed on top
    if (biome === 'badlands' || biome === 'eroded_badlands') return ID.red_sand;
    if (biome === 'wooded_badlands') {
      if (h >= 97) return this.noise.n2(x * 0.11 + 3, z * 0.11 - 3) > 0.1 ? ID.coarse_dirt : ID.grass_block;
      return ID.red_sand;
    }
    if (biome === 'mangrove_swamp') {
      if (h <= SEA + 1) return ID.mud;
      return this.noise.n2(x * 0.12 + 6, z * 0.12 - 6) > 0.15 ? ID.grass_block : ID.mud;
    }
    if (biome === 'swamp' && h < SEA) return this.noise.n2(x * 0.18 + 3, z * 0.18) > 0.18 ? ID.clay : ID.dirt;
    if (biome === 'old_growth_pine_taiga' || biome === 'old_growth_spruce_taiga') {
      const n = this.noise.n2(x * 0.08 + 9, z * 0.08 - 4);
      return n > 0.08 ? ID.podzol : n < -0.22 ? ID.coarse_dirt : ID.grass_block;
    }
    if (biome === 'windswept_gravelly_hills') {
      const n = this.noise.n2(x * 0.11 + 2, z * 0.11 + 2);
      return n > -0.15 ? ID.gravel : n < -0.35 ? ID.stone : ID.grass_block;
    }
    if (biome === 'windswept_hills' || biome === 'windswept_forest') {
      return biome === 'windswept_hills' && this.noise.n2(x * 0.11, z * 0.11) > 0.18 ? ID.stone : ID.grass_block;
    }
    if (biome === 'windswept_savanna') {
      const n = this.noise.n2(x * 0.12 - 4, z * 0.12 + 4);
      return n > 0.2 ? ID.stone : n < -0.15 ? ID.coarse_dirt : ID.grass_block;
    }
    if (biome === 'crimson_forest') return ID.crimson_nylium;
    if (biome === 'warped_forest') return ID.warped_nylium;
    if (biome === 'soul_sand_valley') return coordHash(x, z, this.seed + 31) < 0.35 ? ID.soul_soil : ID.soul_sand;
    if (biome === 'basalt_deltas') return coordHash(x, z, this.seed + 37) < 0.55 ? ID.basalt : ID.blackstone;
    if (biome === 'nether_wastes') return ID.netherrack;
    if (biome === 'the_end' || biome.startsWith('end_') || biome === 'small_end_islands') return ID.end_stone;
    if (biome === 'mushroom_fields') return ID.mycelium;
    if (biome === 'savanna' || biome === 'savanna_plateau') return this.noise.n2(x * 0.1 + 8, z * 0.1 - 3) > 0.34 ? ID.coarse_dirt : ID.grass_block;
    if (biome === 'bamboo_jungle') return this.noise.n2(x * 0.09 - 14, z * 0.09 + 6) > 0.12 ? ID.podzol : ID.grass_block;
    return ID.grass_block;
  }

  private regionStructure(rx: number, rz: number) {
    const key = (rx + 32768) * 65536 + (rz + 32768);
    let v = this.structCache.get(key);
    if (v === undefined) {
      v = this.regionStructureCompute(rx, rz);
      this.structCache.set(key, v);
    }
    return v;
  }

  private regionStructureCompute(rx: number, rz: number): { type: 'plains_village' | 'desert_village' | 'desert_pyramid' | 'ruined_portal' | 'witch_hut' | 'desert_fossil'; x: number; z: number } | null {
    const h = coordHash(rx, rz, this.seed + 7711);
    if (h > 0.55) return null;
    const sx = rx * 112 + 24 + Math.floor(coordHash(rx, rz, this.seed + 101) * 56);
    const sz = rz * 112 + 24 + Math.floor(coordHash(rx, rz, this.seed + 202) * 56);
    const bh = Math.floor(this.gen.column(sx, sz).hf);
    const b = this.gen.biomeAt(sx, sz, bh);
    if (bh <= SEA + 1) return null;
    if (b === 'desert') {
      return h < 0.25 ? { type: 'desert_village', x: sx, z: sz } : h < 0.42 ? { type: 'desert_pyramid', x: sx, z: sz } : { type: 'desert_fossil', x: sx, z: sz };
    }
    if (b === 'swamp') return { type: 'witch_hut', x: sx, z: sz };
    if (b === 'plains' || b === 'sunflower_plains' || b === 'meadow' || b === 'savanna' || b === 'taiga' || b === 'snowy_plains') {
      return h < 0.34 ? { type: 'plains_village', x: sx, z: sz } : { type: 'ruined_portal', x: sx, z: sz };
    }
    if (h < 0.15) return { type: 'ruined_portal', x: sx, z: sz };
    return null;
  }

  private collectNearbyStructures(ox: number, oz: number) {
    const rx = Math.floor((ox + 8) / 112), rz = Math.floor((oz + 8) / 112);
    const list: NonNullable<ReturnType<Terrain['regionStructure']>>[] = [];
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const s = this.regionStructure(rx + dx, rz + dz);
      if (s) list.push(s);
    }
    return { list };
  }

  private footprintCache = new Map<number, Footprint[]>();
  /**
   * Structure Footprint Masking — every surface structure piece (village houses, streets, farms, pens, wells, pyramids,
   * huts, portals, outposts, mansions, temples, igloos, ruins …) whose XZ bounding box may touch the 48×48 vegetation
   * neighbourhood of the chunk at (ox, oz). The footprints are computed in the structure phase, *before* any tree, huge
   * mushroom, bamboo, grass or flower is placed, exactly like the vanilla structure → beardifier → feature order.
   */
  structureFootprints(ox: number, oz: number): Footprint[] {
    if (this.dimension !== 'overworld') return [];
    const key = ((ox >> 4) + 32768) * 65536 + ((oz >> 4) + 32768);
    const hit = this.footprintCache.get(key);
    if (hit) return hit;
    const out: Footprint[] = [];
    const add = (x0: number, z0: number, x1: number, z1: number, kind: string) => {
      if (x1 < ox - 24 || x0 > ox + 40 || z1 < oz - 24 || z0 > oz + 40) return;
      out.push({ x0, z0, x1, z1, kind });
    };
    const { list } = this.collectNearbyStructures(ox, oz);
    for (const s of list) {
      if (s.type === 'plains_village' || s.type === 'desert_village') {
        if (Math.abs(ox + 8 - s.x) > 100 || Math.abs(oz + 8 - s.z) > 100) continue;
        const variant = s.type === 'desert_village' ? 'desert' : villageVariantFor(this.biomeAt(s.x, s.z, this.height(s.x, s.z)));
        const L = grandVillageLayout(this, s.x, s.z, variant);
        for (const b of L.core.buildings) add(b.x0, b.z0, b.x1, b.z1, 'village_' + b.kind);
        add(L.core.farm.x0, L.core.farm.z0, L.core.farm.x1, L.core.farm.z1, 'village_farm');
        add(s.x - 3, s.z - 4, s.x + 5, s.z + 3, 'village_well');
        add(s.x - 22, s.z - 1, s.x + 22, s.z + 1, 'village_street'); add(s.x - 1, s.z - 12, s.x + 1, s.z + 14, 'village_street');
        for (const p of L.pieces) {
          const [W, Ln] = rotSize(p.def, p.rot);
          add(p.bx, p.bz, p.bx + W - 1, p.bz + Ln - 1, 'village_' + p.def.kind);
        }
      } else if (s.type === 'desert_pyramid') add(s.x - 11, s.z - 11, s.x + 11, s.z + 11, 'desert_pyramid');
      else if (s.type === 'witch_hut') add(s.x - 4, s.z - 4, s.x + 4, s.z + 5, 'witch_hut');
      else if (s.type === 'ruined_portal') add(s.x - 5, s.z - 5, s.x + 5, s.z + 5, 'ruined_portal');
      else if (s.type === 'desert_fossil') add(s.x - 4, s.z - 4, s.x + 4, s.z + 4, 'desert_fossil');
    }
    for (const p of structuresNear(this, ox + 8, oz + 8, 96)) {
      if (p.kind === 'mineshaft' || p.kind === 'ancient_city' || p.kind === 'trial_chambers' || p.kind === 'buried_treasure' || p.kind === 'shipwreck' || p.kind === 'ocean_ruin' || p.kind === 'monument') continue;
      const r = regionSize(p.kind) ? SURFACE_RADIUS[p.kind] ?? 8 : 8;
      add(p.x - r, p.z - r, p.x + r, p.z + r, p.kind);
    }
    if (this.footprintCache.size >= 512) this.footprintCache.delete(this.footprintCache.keys().next().value!);
    this.footprintCache.set(key, out);
    return out;
  }

  generate(cx: number, cz: number, edits: [string, number][] = [], structures = true) {
    const padded = this._padded;
    const ug = this.ug;
    const aqCells: number[] = [];
    padded.fill(0, 0, Math.min(padded.length, (this._lastMaxLocalY + 2) * 324));
    const data = new Uint16Array(16 * 16 * HEIGHT);
    const idx = (x: number, y: number, z: number) => (y - MIN_Y) * 324 + (z + 1) * 18 + x + 1;
    const tint = new Float32Array(16 * 16 * 3);
    let maxY = SEA + 2;
    const ox = cx * 16, oz = cz * 16;

    const put: PutFn = (x, y, z, id, replace = true) => {
      x -= ox; z -= oz;
      if (x < -1 || x > 16 || z < -1 || z > 16 || y < MIN_Y || y >= MIN_Y + HEIGHT) return;
      const i = idx(x, y, z);
      if (replace || !padded[i]) padded[i] = id;
      if (y + 1 > maxY) maxY = y + 1;
    };

    const foundation = (x: number, yStart: number, z: number, id: number) => {
      for (let dy = 0; dy < 14; dy++) {
        const yy = yStart - dy;
        if (yy <= MIN_Y + 1) break;
        const lx = x - ox, lz = z - oz;
        if (lx >= -1 && lx <= 16 && lz >= -1 && lz <= 16 && dy > 0 && padded[idx(lx, yy, lz)] !== 0 && padded[idx(lx, yy, lz)] !== ID.water) break;
        put(x, yy, z, id, true);
      }
    };

    if (this.dimension === 'end') {
      // Fast path for the empty void between the main island (radius ~104) and the outer islands (radius 1,000).
      const centerDist = Math.hypot(ox + 8, oz + 8);
      if (centerDist > 140 && centerDist < END_OUTER_RADIUS - 48) {
        for (const [key, cell] of edits) {
          const [x, y, z] = key.split(',').map(Number);
          put(x, y, z, cell);
        }
        for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) for (let y = 0; y < HEIGHT; y++) data[y * 256 + z * 16 + x] = padded[idx(x, y + MIN_Y, z)];
        return { data, padded, tint, maxY: Math.min(MIN_Y + HEIGHT, maxY + 2) };
      }
    }

    const nearby = this.dimension === 'overworld' ? this.collectNearbyStructures(ox, oz) : { list: [] };
    // Structure phase first: every footprint is known before a single plant is placed (vanilla generation order).
    const footprints = structures && this.dimension === 'overworld' ? this.structureFootprints(ox, oz) : [];
    /** True when (wx, wz) lies inside a structure footprint grown by `pad` blocks (buffer + canopy radius of the feature). */
    const inExcl = (wx: number, wz: number, pad = FOOTPRINT_BUFFER) => {
      for (let i = 0; i < footprints.length; i++) {
        const b = footprints[i];
        if (wx >= b.x0 - pad && wx <= b.x1 + pad && wz >= b.z0 - pad && wz <= b.z1 + pad) return true;
      }
      return false;
    };

    // 20x20 grid covers [-2..17] in local chunk coordinates for height/biome/slope/tint blending
    const hMap = this._hMap;
    const biomeTintGrid = this._tintGrid;
    const biomeGrid = this._biomeGrid;
    let maxColH = SEA;
    for (let gz = -2; gz <= 17; gz++) for (let gx = -2; gx <= 17; gx++) {
      const gi = (gz + 2) * 20 + (gx + 2);
      const hh = this.height(ox + gx, oz + gz);
      hMap[gi] = hh;
      if (hh > maxColH) maxColH = hh;
      const bn = this.biomeAt(ox + gx, oz + gz, hh);
      biomeGrid[gi] = bn;
      const bt = BIOME_TINTS[bn] ?? [1, 1, 1];
      biomeTintGrid[gi * 3] = bt[0]; biomeTintGrid[gi * 3 + 1] = bt[1]; biomeTintGrid[gi * 3 + 2] = bt[2];
    }
    const getH = (x: number, z: number) => hMap[(z + 2) * 20 + (x + 2)];
    const getBiome = (x: number, z: number) => biomeGrid[(z + 2) * 20 + (x + 2)];

    const flowerAt = (fx: number, fz: number, kinds: (number | undefined)[]) => {
      const v = this.noise.n2(fx / 13 + 77.7, fz / 13 - 33.3) * 0.5 + this.noise.n2(fx / 5 - 12.1, fz / 5 + 8.6) * 0.12 + 0.5;
      return kinds[Math.max(0, Math.min(kinds.length - 1, Math.floor(((v - 0.2) / 0.6) * kinds.length)))] ?? ID.poppy;
    };

    // 3D Cave & Ore-vein noise evaluated on a coarse 4x8x4 grid and trilinearly interpolated (like Vanilla NoiseChunk).
    let caveGrid: Float32Array | undefined;
    let tubeGrid: Float32Array | undefined;
    let cheeseGrid: Float32Array | undefined;
    let spag2AGrid: Float32Array | undefined;
    let spag2BGrid: Float32Array | undefined;
    let noodleGrid: Float32Array | undefined;
    const nySteps = Math.min(49, Math.ceil((Math.min(maxColH + 8, MIN_Y + HEIGHT - 8) - MIN_Y) / 8) + 1);
    if (this.dimension === 'overworld') {
      caveGrid = this._caveGrid;
      tubeGrid = this._tubeGrid;
      cheeseGrid = this._cheeseGrid;
      spag2AGrid = this._spag2AGrid;
      spag2BGrid = this._spag2BGrid;
      noodleGrid = this._noodleGrid;
      for (let ny = 0; ny < nySteps; ny++) {
        const wy = MIN_Y + ny * 8;
        const yOff = ny * 36;
        for (let nz = 0; nz < 6; nz++) {
          const wz = oz - 2 + nz * 4;
          for (let nx = 0; nx < 6; nx++) {
            const wx = ox - 2 + nx * 4;
            const ni = yOff + nz * 6 + nx;
            caveGrid[ni] = this.noise.n3(wx * 0.048, wy * 0.065, wz * 0.048);
            tubeGrid[ni] = this.noise.n3(wx * 0.044 + 90, wy * 0.060, wz * 0.044 + 90);
            cheeseGrid[ni] = wy < 52 ? ug.cheeseDensity(wx, wy, wz) : -1;
            spag2AGrid[ni] = this.noise.n3(wx * 0.052 - 140, wy * 0.070, wz * 0.052 + 110);
            spag2BGrid[ni] = this.noise.n3(wx * 0.046 + 210, wy * 0.064, wz * 0.046 - 170);
            noodleGrid[ni] = wy >= -60 && wy <= 32 ? this.noise.n3(wx * 0.022 - 410, wy * 0.026, wz * 0.022 + 290) : -1;
          }
        }
      }
    }

    const colBi = (arr: Float32Array, iy: number, ix: number, iz: number, tx: number, tz: number) => {
      const i00 = iy * 36 + iz * 6 + ix;
      const x0 = arr[i00] + (arr[i00 + 1] - arr[i00]) * tx;
      const x1 = arr[i00 + 6] + (arr[i00 + 7] - arr[i00 + 6]) * tx;
      return x0 + (x1 - x0) * tz;
    };

    for (let z = -1; z <= 16; z++) for (let x = -1; x <= 16; x++) {
      const wx = ox + x, wz = oz + z, h = getH(x, z);
      const biome = getBiome(x, z);
      let top = this.surface(biome, wx, wz, h);
      const slope = Math.max(
        Math.abs(getH(x + 1, z) - h),
        Math.abs(getH(x - 1, z) - h),
        Math.abs(getH(x, z + 1) - h),
        Math.abs(getH(x, z - 1) - h),
      );
      const cliff = slope > 3 || Math.max(Math.abs(getH(x + 1, z) - getH(x - 1, z)), Math.abs(getH(x, z + 1) - getH(x, z - 1))) > 6;

      if (this.dimension === 'overworld') {
        if (h > 118 && !biome.includes('badlands') && biome !== 'stony_peaks' && biome !== 'windswept_savanna') {
          const alt = h + Math.floor(this.noise.n2(wx * 0.08, wz * 0.08) * 5);
          if (alt > 152) top = ID.snow_block;
          else if (alt > 125 && top === ID.grass_block) top = ID.stone;
        }
        if ((biome === 'snowy_slopes' || biome === 'frozen_peaks' || biome === 'jagged_peaks') && slope >= 3) {
          top = ID.stone;
        } else if ((biome === 'snowy_slopes' || biome === 'grove') && top === ID.snow_block && B.powder_snow !== undefined) {
          const ps = this.noise.n2(wx * 0.09 + 11.4, wz * 0.09 - 4.8);
          if (ps > 0.36 && ps < 0.56) top = B.powder_snow;
        }
      }

      if (x >= 0 && x < 16 && z >= 0 && z < 16) {
        // 5x5 smooth biome tint blend across biome borders
        let r = 0, g = 0, b = 0, wsum = 0;
        for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
          const gi = ((z + dz + 2) * 20 + (x + dx + 2)) * 3;
          const wgt = 3 - Math.max(Math.abs(dx), Math.abs(dz));
          r += biomeTintGrid[gi] * wgt; g += biomeTintGrid[gi + 1] * wgt; b += biomeTintGrid[gi + 2] * wgt; wsum += wgt;
        }
        const ti = (z * 16 + x) * 3;
        tint[ti] = r / wsum; tint[ti + 1] = g / wsum; tint[ti + 2] = b / wsum;
      }

      if (this.dimension === 'nether') {
        // ---- Vanilla-scale Nether column: Y 0‥127, 3-D density caverns, lava sea at Y 31, 5-layer bedrock gradients ----
        const colStrideN = (z + 1) * 18 + x + 1;
        const soulBiome = biome === 'soul_sand_valley', deltaBiome = biome === 'basalt_deltas';
        let prevSolid = true, floorY = -1, ceilY = -1;
        const solidCol = new Uint8Array(NETHER_HEIGHT);
        for (let y = 0; y < NETHER_HEIGHT; y++) solidCol[y] = this.netherSolid(wx, y, wz) ? 1 : 0;
        for (let y = 0; y < NETHER_HEIGHT; y++) {
          let id = 0;
          const solid = solidCol[y] === 1;
          if (y === 0 || y === NETHER_HEIGHT - 1) id = ID.bedrock;
          else if (y <= 4 && coordHash(wx + y * 97, wz - y * 31, this.seed + 601) < (5 - y) / 5) id = ID.bedrock;                  // floor 0‥4
          else if (y >= NETHER_HEIGHT - 5 && coordHash(wx - y * 53, wz + y * 71, this.seed + 602) < (y - (NETHER_HEIGHT - 6)) / 5) id = ID.bedrock; // roof 123‥127
          else if (solid) {
            const above = y + 1 < NETHER_HEIGHT ? solidCol[y + 1] === 1 : true;
            const depth = above ? (y + 2 < NETHER_HEIGHT && solidCol[y + 2] === 1 ? 3 : 2) : 1;
            if (!above && y > NETHER_LAVA) id = top;                                              // exposed floor → biome surface
            else if (soulBiome && depth <= 3) id = top;
            else if (deltaBiome && depth <= 2) id = top;
            else {
              id = ID.netherrack;
              const ore = coordHash(wx + y * 211, wz - y * 173, this.seed + 91);
              if (soulBiome && ore > 0.985) id = ID.soul_soil;
              else if (deltaBiome && ore > 0.9) id = ore > 0.96 ? ID.blackstone : ID.basalt;
            }
            if (!above && y > floorY && y < 100) floorY = y;
            if (!prevSolid && y > 40) ceilY = ceilY < 0 ? y : ceilY;
          } else if (y <= NETHER_LAVA) {
            id = ID.lava;
          } else if (!prevSolid && y > 60 && y < 110 && coordHash(wx + y, wz - y, this.seed + 603) < 0.0012) {
            id = ID.lava;                                                                            // lavafalls dripping from ceilings/ledges
          }
          prevSolid = solid;
          if (id) {
            padded[(y - MIN_Y) * 324 + colStrideN] = id;
            if (y + 1 > maxY) maxY = y + 1;
          }
        }
        // Glowstone clusters hanging from any ceiling, gravel/soul sand patches and biome decoration on the top floor.
        if (ceilY > 0 && coordHash(wx, wz, this.seed + 511) < 0.02) {
          const len = 2 + Math.floor(coordHash(wx, wz, this.seed + 512) * 4);
          for (let dy = 1; dy <= len && ceilY - dy > NETHER_LAVA + 2; dy++) if (padded[idx(x, ceilY - dy, z)] === 0) put(wx, ceilY - dy, wz, ID.glowstone, true);
        }
        if (floorY > NETHER_LAVA) {
          const hN = floorY;
          if (deltaBiome && coordHash(wx, wz, this.seed + 523) < 0.035) {
            const spire = 2 + Math.floor(coordHash(wx, wz, this.seed + 524) * 5);
            for (let dy = 1; dy <= spire; dy++) put(wx, hN + dy, wz, ID.basalt, false);
          }
          if (biome === 'crimson_forest') {
            const r = coordHash(wx, wz, this.seed + 531);
            if (r < 0.05 && ID.crimson_fungus !== undefined) put(wx, hN + 1, wz, ID.crimson_fungus, false);
            else if (r < 0.12 && ID.crimson_roots !== undefined) put(wx, hN + 1, wz, ID.crimson_roots, false);
            else if (r > 0.985 && ID.weeping_vines !== undefined && ceilY > hN + 6) for (let dy = 1; dy <= 4; dy++) put(wx, ceilY - dy, wz, ID.weeping_vines, false);
          } else if (biome === 'warped_forest') {
            const r = coordHash(wx, wz, this.seed + 532);
            if (r < 0.05 && ID.warped_fungus !== undefined) put(wx, hN + 1, wz, ID.warped_fungus, false);
            else if (r < 0.1 && ID.warped_roots !== undefined) put(wx, hN + 1, wz, ID.warped_roots, false);
            else if (r < 0.16 && ID.nether_sprouts !== undefined) put(wx, hN + 1, wz, ID.nether_sprouts, false);
            else if (r > 0.985 && ID.twisting_vines !== undefined) for (let dy = 0; dy < 3; dy++) put(wx, hN + 1 + dy, wz, ID.twisting_vines, false);
          } else if (biome === 'nether_wastes') {
            const r = coordHash(wx, wz, this.seed + 533);
            if (r < 0.014 && ID.fire !== undefined) put(wx, hN + 1, wz, ID.fire, false);
            if (r > 0.993 && ID.magma_block !== undefined) put(wx, hN, wz, ID.magma_block, true);
            if (r > 0.9 && r < 0.93 && ID.gravel !== undefined && hN <= NETHER_LAVA + 3) put(wx, hN, wz, ID.gravel, true);
          } else if (soulBiome) {
            const r = coordHash(wx, wz, this.seed + 534);
            if (r < 0.02 && ID.soul_fire !== undefined) put(wx, hN + 1, wz, ID.soul_fire, false);
            if (r > 0.99 && ID.soul_torch !== undefined) put(wx, hN + 1, wz, ID.soul_torch, false);
            if (x >= 2 && x <= 13 && z >= 2 && z <= 13 && coordHash(wx, wz, this.seed + 527) < 0.0085) {
              netherFossil(put, wx, hN, wz, this.seed);
            }
          } else if (deltaBiome) {
            const r = coordHash(wx, wz, this.seed + 535);
            if (r < 0.03 && ID.magma_block !== undefined) put(wx, hN, wz, ID.magma_block, true);
            else if (r > 0.992 && ID.gilded_blackstone !== undefined) put(wx, hN, wz, ID.gilded_blackstone, true);
          }
        }
        continue;
      }

      if (this.dimension === 'end') {
        if (h < -10) continue;
        const thick = Math.hypot(wx, wz) <= 104 ? 40 : 12;                 // the main island is a deep end-stone lens
        const bottom = Math.max(0, h - thick - Math.floor(Math.abs(this.noise.n2(wx * 0.08, wz * 0.08)) * 10));
        for (let y = bottom; y <= h; y++) {
          padded[idx(x, y, z)] = ID.end_stone;
          if (y + 1 > maxY) maxY = y + 1;
        }
        continue;
      }

      // --- Overworld Column ---
      const isBadlands = biome === 'badlands' || biome === 'eroded_badlands' || biome === 'wooded_badlands';
      const isFrozenWater =
        biome === 'snowy_plains' || biome === 'ice_spikes' || biome === 'snowy_taiga' ||
        biome === 'snowy_slopes' || biome === 'grove' || biome === 'frozen_peaks' ||
        biome === 'jagged_peaks' || biome === 'frozen_river' || biome === 'frozen_ocean' ||
        biome === 'deep_frozen_ocean' || biome === 'snowy_beach';
      const bandShift = isBadlands ? Math.floor(this.noise.n2(wx * 0.05, wz * 0.05) * 4) : 0;
      const overhang = cliff && (biome === 'eroded_badlands' || biome === 'windswept_hills' || biome === 'windswept_gravelly_hills' || biome === 'windswept_forest' || biome === 'windswept_savanna' || biome === 'savanna_plateau' || biome === 'jagged_peaks' || biome === 'stony_peaks' || biome === 'frozen_peaks');
      const topY = Math.max(h, SEA);

      // Step-linearly interpolate cave fields along Y in 8-block steps for ~4x faster column loop
      const gxC = (x + 2) * 0.25, gzC = (z + 2) * 0.25;
      const ixC = gxC | 0, izC = gzC | 0;
      const txC = gxC - ixC, tzC = gzC - izC;
      const colStride = (z + 1) * 18 + x + 1;
      const caveLim = Math.min(h, MIN_Y + nySteps * 8 - 8);
      let c0 = 0, cStep = 0, t0 = 0, tStep = 0, ch0 = -1, chStep = 0, s2a0 = 0, s2aStep = 0, s2b0 = 0, s2bStep = 0, nd0 = -1, ndStep = 0, curSeg = -1, hasCaveAir = false;
      const sp2dElev = -14 + this.noise.n2(wx * 0.013 - 220, wz * 0.013 + 180) * 34;
      // Ore veins: sample the (smooth) vein selector every 6 blocks; only columns that actually touch a vein pay for the detailed test.
      const vt = this._veinT;
      let veinOn = false;
      if (h > -40) for (let k = 0; k < 20; k++) {
        const v = ug.veinToggle(wx, MIN_Y + k * 6, wz);
        vt[k] = v;
        if (v > 0.44 || v < -0.44) veinOn = true;
      }

      for (let y = MIN_Y; y <= topY; y++) {
        let id = 0;
        if (y <= h) {
          if (isBadlands && y > h - 18 && y >= SEA - 2) {
            if (y === h && top === ID.grass_block) id = ID.grass_block;
            else if (y > h - 3 && top === ID.coarse_dirt) id = ID.coarse_dirt;
            else if (y === h && h < SEA + 12 && top === ID.red_sand) id = ID.red_sand;
            else if (h < SEA + 12 && y > h - 4) id = ID.orange_terracotta;
            else id = this.badlandsBands[(((y + bandShift) % 192) + 192) % 192];
          } else if (y === h) {
            id = cliff && top === ID.grass_block ? ID.stone : top;
          } else if (y > h - 4) {
            if (top === ID.sand) id = y > h - 2 ? ID.sand : ID.sandstone;
            else if (top === ID.red_sand) id = ID.red_sand;
            else if (top === ID.mud) id = ID.mud;
            else if (top === ID.snow_block || top === B.powder_snow) id = y > h - 2 ? ID.snow_block : ID.stone;
            else if (top === ID.packed_ice || top === ID.ice) id = ID.packed_ice;
            else if (top === ID.stone || top === ID.calcite || top === ID.gravel) id = top === ID.gravel && y === h - 1 ? ID.gravel : ID.stone;
            else id = cliff ? ID.stone : ID.dirt;
          } else {
            id = y <= 0 ? ID.deepslate : (y < 8 && coordHash(wx + y * 97, wz - y * 31, this.seed + 701) < (8 - y) * 0.125) ? ID.deepslate : ID.stone;
            if (veinOn && y <= 50 && y >= -60 && y < h - 6) {
              const f = (y - MIN_Y) / 6, k0 = f | 0, tg = vt[k0] + (vt[k0 < 19 ? k0 + 1 : 19] - vt[k0]) * (f - k0);
              if (tg > 0.4 || tg < -0.4) { const vb = ug.vein(wx, y, wz, tg, id === ID.deepslate); if (vb) id = vb; }
            }
          }

          if (y === MIN_Y || (y <= MIN_Y + 4 && coordHash(wx + y * 97, wz - y * 31, this.seed + 600) < (MIN_Y + 5 - y) / 5)) id = ID.bedrock; // 5-layer bedrock gradient Y -64‥-60
          else if (y > MIN_Y + 2 && y < caveLim && caveGrid && tubeGrid && cheeseGrid && spag2AGrid && spag2BGrid && noodleGrid) {
            const ly = y - MIN_Y;
            const seg = ly >> 3;
            if (seg !== curSeg) {
              curSeg = seg;
              const ca = colBi(caveGrid, seg, ixC, izC, txC, tzC), cb = colBi(caveGrid, seg + 1, ixC, izC, txC, tzC);
              c0 = ca; cStep = (cb - ca) * 0.125;
              const ta = colBi(tubeGrid, seg, ixC, izC, txC, tzC), tb = colBi(tubeGrid, seg + 1, ixC, izC, txC, tzC);
              t0 = ta; tStep = (tb - ta) * 0.125;
              const s2aA = colBi(spag2AGrid, seg, ixC, izC, txC, tzC), s2aB = colBi(spag2AGrid, seg + 1, ixC, izC, txC, tzC);
              s2a0 = s2aA; s2aStep = (s2aB - s2aA) * 0.125;
              const s2bA = colBi(spag2BGrid, seg, ixC, izC, txC, tzC), s2bB = colBi(spag2BGrid, seg + 1, ixC, izC, txC, tzC);
              s2b0 = s2bA; s2bStep = (s2bB - s2bA) * 0.125;
              if (y < 48) {
                const ha = colBi(cheeseGrid, seg, ixC, izC, txC, tzC), hb = colBi(cheeseGrid, seg + 1, ixC, izC, txC, tzC);
                ch0 = ha; chStep = (hb - ha) * 0.125;
              } else { ch0 = -1; chStep = 0; }
              if (y >= -60 && y <= 30) {
                const na = colBi(noodleGrid, seg, ixC, izC, txC, tzC), nb = colBi(noodleGrid, seg + 1, ixC, izC, txC, tzC);
                nd0 = na; ndStep = (nb - na) * 0.125;
              } else { nd0 = -1; ndStep = 0; }
            } else {
              c0 += cStep; t0 += tStep; ch0 += chStep; s2a0 += s2aStep; s2b0 += s2bStep; nd0 += ndStep;
            }
            const dSpag1 = c0 * c0 + t0 * t0;
            const dSpag2 = s2a0 * s2a0 + s2b0 * s2b0;
            let carved = false;
            if (y < h - 5) {
              if (dSpag1 < (y < h - 9 ? 0.0055 : 0.0028) || dSpag2 < (y < h - 11 ? 0.0038 : 0.0018)) {
                carved = true;
              } else if (ch0 > 0.54 && y < h - 7 && !ug.isPillarAt(wx, y, wz)) {
                carved = true;
              } else if (nd0 > 0.28 && y >= -58 && y <= 28 && y < h - 9 && ug.isNoodleAt(wx, y, wz, h)) {
                carved = true;
              } else if (Math.abs(y - sp2dElev) < 4.5 && y < h - 9 && ug.isSpaghetti2DAt(wx, y, wz, h)) {
                carved = true;
              }
            } else if (dSpag1 < 0.0065 && ug.isCaveEntranceAt(wx, y, wz, h, c0, t0)) {
              carved = true;
            }
            if (carved) {
              if (y < -54) id = ID.lava;
              else {
                const fl = ug.fluidAt(wx, y, wz);
                if (fl) { id = fl; aqCells.push((y - MIN_Y) * 324 + colStride); }
                else { id = 0; hasCaveAir = true; }
              }
            }
          }
          // 3-D overhangs: mountains, windswept hills, savanna plateaus and eroded badlands carve a density field under cliff
          // lips so the terrain has real overhangs, arches and hoodoos instead of pure heightmap slopes.
          if (id && overhang && y < h - 1 && y > h - 18 && y > SEA + 1) {
            const dn = this.noise.n3(wx * 0.045 + 7, y * 0.075, wz * 0.045 - 7) + this.noise.n3(wx * 0.11, y * 0.16, wz * 0.11) * 0.35;
            if (dn > 0.42 - Math.min(0.2, slope * 0.025)) id = 0;
          }
        } else if (y <= SEA) {
          if (y === SEA && isFrozenWater) {
            if (biome === 'frozen_ocean' || biome === 'deep_frozen_ocean') {
              id = this.noise.n2(wx * 0.045 + 9.3, wz * 0.045 + 2.1) > -0.1 ? ID.ice : ID.water;
            } else {
              id = ID.ice;
            }
          } else {
            id = ID.water;
          }
        }
        padded[(y - MIN_Y) * 324 + colStride] = id;
      }
      if (h + 1 > maxY) maxY = h + 1;

      // Cave biome decoration: the 3D cave-biome field is queried only for floor / ceiling voxels of carved air.
      if (hasCaveAir) {
        const cCol = this.gen.column(wx, wz);
        const limit = Math.min(h - 8, 56);
        for (let y = MIN_Y + 3; y < limit; y++) {
          const i = idx(x, y, z);
          if (padded[i] !== 0) continue;
          const below = padded[i - 324], above = padded[i + 324];
          const solidBelow = below !== 0 && below !== ID.lava && BLOCKS[below]?.solid && BLOCKS[below].shape === 'cube';
          const solidAbove = above !== 0 && above !== ID.lava && BLOCKS[above]?.solid && BLOCKS[above].shape === 'cube';
          if (!solidBelow && !solidAbove) continue;
          const cb = ug.caveBiomeAt(wx, y, wz, cCol.E, cCol.H, cCol.C, h);
          if (!cb) continue;
          const kind = cb === 'lush_caves' ? 1 : cb === 'dripstone_caves' ? 2 : 3;
          const r = coordHash(wx + y * 131, wz - y * 71, this.seed + 808);
          if (solidBelow) {
            if (kind === 1) {
              padded[i - 324] = r > 0.92 ? ID.clay : ID.moss_block;
              padded[i] = r < 0.08 ? ID.azalea : r < 0.12 ? ID.flowering_azalea : r < 0.34 ? ID.short_grass : r < 0.44 ? ID.moss_carpet : r < 0.48 ? ID.big_dripleaf : 0;
            } else if (kind === 2) {
              if (r < 0.72) padded[i - 324] = ID.dripstone_block;
              if (r < 0.22) {
                const len = 1 + Math.floor(coordHash(wx, wz + y, this.seed + 809) * 3);
                for (let k = 0; k < len && y + k < limit && padded[idx(x, y + k, z)] === 0; k++) padded[idx(x, y + k, z)] = ID.pointed_dripstone;
              }
            } else {
              if (r < 0.9) padded[i - 324] = r < 0.02 ? ID.sculk_catalyst : ID.sculk_block;
              padded[i] = r > 0.985 ? ID.sculk_shrieker : r > 0.96 ? ID.sculk_sensor : 0;
            }
          } else if (solidAbove) {
            if (kind === 1) {
              padded[i + 324] = ID.moss_block;
              if (r < 0.18) {
                const len = 1 + Math.floor(coordHash(wx, wz - y, this.seed + 810) * 5);
                for (let k = 0; k < len && y - k > MIN_Y + 3 && padded[idx(x, y - k, z)] === 0; k++) padded[idx(x, y - k, z)] = ID.cave_vines;
              } else if (r < 0.22) padded[i] = ID.spore_blossom;
              else if (r < 0.28) padded[i] = ID.hanging_roots;
            } else if (kind === 2) {
              if (r < 0.72) padded[i + 324] = ID.dripstone_block;
              if (r < 0.26) {
                const len = 1 + Math.floor(coordHash(wx + y, wz, this.seed + 811) * 4);
                for (let k = 0; k < len && y - k > MIN_Y + 3 && padded[idx(x, y - k, z)] === 0; k++) padded[idx(x, y - k, z)] = ID.pointed_dripstone;
              }
            } else if (r < 0.6) {
              padded[i + 324] = ID.sculk_block;
            }
          }
        }
      }

      // Snow cover on cold biomes
      let cachedEco = '';
      const getEco = () => cachedEco || (cachedEco = this.ecotone(biome, wx, wz, h));
      const snowBiome = h >= SEA && this.gen.column(wx, wz).T < -0.3 ? getEco() : biome;
      if (h >= SEA && !inExcl(wx, wz) && (snowBiome === 'snowy_plains' || snowBiome === 'snowy_taiga' || snowBiome === 'snowy_beach' || snowBiome === 'grove' || snowBiome === 'ice_spikes') && ID.snow_layer !== undefined) {
        if (top === ID.grass_block || top === ID.sand || top === ID.snow_block || top === ID.dirt) {
          put(wx, h + 1, wz, ID.snow_layer, false);
        }
      }
      if (biome === 'snowy_plains' && h >= SEA + 1 && !inExcl(wx, wz) && this.noise.n2(wx / 8 + 40.5, wz / 8 - 12.5) > 0.55) {
        put(wx, h, wz, ID.ice, true);
      }

      // Ocean & river vegetation
      const isOcean = biome.endsWith('ocean');
      if (isOcean && h < SEA - 1) {
        const r2 = coordHash(wx, wz, this.seed + 77);
        if (biome === 'warm_ocean') {
          if (r2 < 0.009 && h < SEA - 3) {
            placeCoralReef(put, wx, h, wz, this.seed, SEA - 1);
          } else if (r2 < 0.16) {
            put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
          } else if (r2 > 0.985 && h > SEA - 10) {
            put(wx, h + 1, wz, ID.sea_pickle ?? ID.seagrass, false);
          }
        } else if (r2 < 0.05) {
          const tall = 2 + Math.floor(coordHash(wx, wz, this.seed + 79) * 9);
          for (let k = 1; k <= tall && h + k < SEA; k++) put(wx, h + k, wz, ID.kelp ?? ID.seagrass, true);
        } else if (r2 < 0.16) {
          put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
        }
      }
      if (biome === 'river' && h < SEA - 1) {
        if (coordHash(wx, wz, this.seed + 81) < 0.09) put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
      }
      if ((biome === 'swamp' || biome === 'mangrove_swamp') && h < SEA) {
        if (coordHash(wx, wz, this.seed + 82) < 0.06) put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
      }

      // Lily pads on swamp/mangrove/river water
      if (h < SEA && h >= SEA - 4 && (biome === 'swamp' || biome === 'mangrove_swamp' || biome === 'river') && coordHash(wx, wz, this.seed + 61) < (biome === 'river' ? 0.012 : 0.075)) {
        put(wx, SEA + 1, wz, ID.lily_pad ?? ID.short_grass, false);
      }

      // Ground flora & details
      const fb = h > SEA + 1 ? getEco() : biome;
      if (h > SEA + 1 && !cliff && (top === ID.grass_block || top === ID.podzol || top === ID.mycelium || top === ID.mud || top === ID.coarse_dirt) && !inExcl(wx, wz)) {
        const r = coordHash(wx, wz, this.seed + 44);
        if (fb === 'cherry_grove') {
          if (r < 0.34) put(wx, h + 1, wz, ID.pink_petals ?? ID.poppy, false);
          else if (r < 0.48) put(wx, h + 1, wz, ID.short_grass, false);
        } else if (fb === 'flower_forest') {
          if (r < 0.24) put(wx, h + 1, wz, flowerAt(wx, wz, [ID.dandelion, ID.poppy, ID.allium, ID.azure_bluet, ID.red_tulip, ID.orange_tulip, ID.pink_tulip, ID.white_tulip, ID.oxeye_daisy, ID.cornflower, ID.lily_of_the_valley]), false);
          else if (r < 0.40) put(wx, h + 1, wz, ID.short_grass, false);
        } else if (fb === 'sunflower_plains') {
          const patch = this.noise.n2(wx / 19 + 4.4, wz / 19 - 7.7) > 0.08;
          if (patch && r < 0.16 && B.sunflower !== undefined) put(wx, h + 1, wz, B.sunflower, false);
          else if (r < 0.36) put(wx, h + 1, wz, r < 0.28 ? ID.short_grass : (B.tall_grass ?? ID.short_grass), false);
        } else if (fb === 'plains') {
          const field = this.noise.n2(wx / 37 + 5.5, wz / 37 - 9.9) > 0.22;
          if (r < (field ? 0.09 : 0.008)) put(wx, h + 1, wz, flowerAt(wx, wz, [ID.dandelion, ID.poppy, ID.azure_bluet, ID.oxeye_daisy, ID.cornflower]), false);
          else if (r < 0.32) put(wx, h + 1, wz, r < 0.27 ? ID.short_grass : (B.tall_grass ?? ID.short_grass), false);
        } else if (fb === 'meadow') {
          if (r < 0.14) put(wx, h + 1, wz, flowerAt(wx, wz, [ID.dandelion, ID.poppy, ID.cornflower, ID.allium, ID.azure_bluet, ID.oxeye_daisy]), false);
          else if (r < 0.50) put(wx, h + 1, wz, r < 0.42 ? ID.short_grass : (B.tall_grass ?? ID.short_grass), false);
        } else if (fb === 'taiga' || fb === 'snowy_taiga' || fb === 'old_growth_pine_taiga' || fb === 'old_growth_spruce_taiga') {
          if (top === ID.coarse_dirt && r < 0.06) put(wx, h + 1, wz, ID.dead_bush, false);
          else if (r < 0.12) put(wx, h + 1, wz, r < 0.07 ? ID.fern : r < 0.09 ? (B.large_fern ?? ID.fern) : ID.brown_mushroom, false);
          else if ((fb === 'taiga' || fb === 'snowy_taiga') && r > 0.94 && ID.sweet_berry_bush !== undefined) put(wx, h + 1, wz, ID.sweet_berry_bush, false);
        } else if (fb === 'mushroom_fields') {
          if (r < 0.07) put(wx, h + 1, wz, r < 0.035 ? ID.red_mushroom : ID.brown_mushroom, false);
        } else if (fb === 'birch_forest' || fb === 'old_growth_birch_forest') {
          if (r < 0.12) put(wx, h + 1, wz, r < 0.02 ? (ID.lily_of_the_valley ?? ID.dandelion) : ID.short_grass, false);
        } else if (fb === 'dark_forest') {
          if (r < 0.08) put(wx, h + 1, wz, r < 0.03 && B.leaf_litter !== undefined ? B.leaf_litter : ID.short_grass, false);
        } else if (fb === 'swamp') {
          if (r < 0.14) put(wx, h + 1, wz, r < 0.035 ? (ID.blue_orchid ?? ID.short_grass) : r < 0.055 ? ID.brown_mushroom : ID.short_grass, false);
        } else if (fb === 'mangrove_swamp') {
          if (r < 0.10) put(wx, h + 1, wz, r < 0.025 ? ID.dead_bush : r < 0.06 ? (B.tall_grass ?? ID.short_grass) : ID.short_grass, false);
        } else if (fb === 'jungle' || fb === 'sparse_jungle' || fb === 'bamboo_jungle') {
          const bambooPatch = fb === 'bamboo_jungle' || this.noise.n2(wx / 22 - 8.1, wz / 22 + 3.7) > 0.35;
          if (bambooPatch && r > (fb === 'bamboo_jungle' ? 0.72 : 0.94) && ID.bamboo !== undefined) {
            const bh = 4 + Math.floor(coordHash(wx, wz, this.seed + 84) * 9);
            for (let k = 1; k <= bh; k++) put(wx, h + k, wz, ID.bamboo, false);
          } else if (r < 0.42) {
            put(wx, h + 1, wz, r < 0.16 ? (ID.jungle_fern ?? ID.fern) : r < 0.22 ? (B.large_fern ?? ID.fern) : ID.short_grass, false);
          }
        } else if (fb === 'savanna' || fb === 'savanna_plateau' || fb === 'windswept_savanna') {
          if (r < 0.32) put(wx, h + 1, wz, r < 0.24 ? ID.short_grass : (B.tall_grass ?? ID.short_grass), false);
        } else if (r < 0.12) {
          const f = r < 0.01 ? ID.poppy : r < 0.018 ? ID.dandelion : r < 0.024 ? ID.cornflower : r < 0.029 ? ID.oxeye_daisy : r < 0.034 ? ID.red_mushroom : r < 0.039 ? ID.brown_mushroom : r < 0.05 && B.leaf_litter !== undefined ? B.leaf_litter : ID.short_grass;
          put(wx, h + 1, wz, f ?? ID.short_grass, false);
        }

        // Sugar cane strictly next to water
        const nextToWater = getH(x + 1, z) < SEA || getH(x - 1, z) < SEA || getH(x, z + 1) < SEA || getH(x, z - 1) < SEA;
        if (nextToWater && h === SEA + 1 && coordHash(wx, wz, this.seed + 66) < 0.065) {
          const sh = 2 + Math.floor(coordHash(wx, wz, this.seed + 67) * 2);
          for (let yy = 1; yy <= sh; yy++) put(wx, h + yy, wz, ID.sugar_cane, false);
        }
      }

      // Cactus, Dead Bush & Desert Fossils
      if ((biome === 'desert' || isBadlands) && !cliff && h > SEA + 1 && (top === ID.sand || top === ID.red_sand) && !inExcl(wx, wz)) {
        const dr = coordHash(wx, wz, this.seed + 55);
        const flatNeighbors = getH(x + 1, z) <= h && getH(x - 1, z) <= h && getH(x, z + 1) <= h && getH(x, z - 1) <= h;
        if (dr < 0.0045 && flatNeighbors && ((wx + wz) & 1) === 0) {
          const ch = 1 + Math.floor(coordHash(wx, wz, this.seed + 59) * 3);
          for (let y = 1; y <= ch; y++) put(wx, h + y, wz, ID.cactus, true);
        } else if (dr < 0.022) {
          put(wx, h + 1, wz, ID.dead_bush ?? ID.short_grass, false);
        } else if (dr > 0.9996 && flatNeighbors && biome === 'desert') {
          for (let dy = -1; dy <= 2; dy++) put(wx, h + dy, wz, ID.bone_block, true);
          put(wx - 1, h + 1, wz, ID.bone_block, true);
          put(wx + 1, h + 1, wz, ID.bone_block, true);
        }
      }
    }

    // World Carvers (CaveWorldCarver, CanyonWorldCarver, NetherWorldCarver): run before aquifer barrier sealing so all
    // carved worm tunnels, circular rooms, and canyons integrate with local aquifers and have their fluid borders sealed.
    if (this.dimension === 'overworld') {
      ug.carveOverworldChunk(cx, cz, ox, oz, getH, padded, idx, aqCells);
    } else if (this.dimension === 'nether') {
      ug.carveNetherChunk(cx, cz, ox, oz, NETHER_LAVA, NETHER_HEIGHT, padded, idx);
    }

    // Aquifer barriers: where an aquifer's fluid would touch air of a neighbouring (drier / lower) aquifer, vanilla seals the
    // boundary with a stone wall. Without it lakes would hang in mid-air along the cell borders.
    if (aqCells.length) {
      for (let k = 0; k < aqCells.length; k++) {
        const i = aqCells[k], col = i % 324, cxl = col % 18, czl = (col - cxl) / 18;
        if (cxl === 0 || cxl === 17 || czl === 0 || czl === 17) continue;
        const wy = Math.floor(i / 324) + MIN_Y;
        if (padded[i - 1] === 0 || padded[i + 1] === 0 || padded[i - 18] === 0 || padded[i + 18] === 0 || padded[i - 324] === 0) {
          padded[i] = wy < 0 ? ID.deepslate : ID.stone;
        } else if (padded[i] === ID.water && ID.magma_block !== undefined) {
          // Vanilla Aquifer: Magma blocks occasionally generate at the bottom of underground water bodies
          const below = padded[i - 324];
          if ((below === ID.stone || below === ID.deepslate) && coordHash(ox + cxl - 1 + wy * 37, oz + czl - 1 - wy * 53, this.seed + 619) < 0.025) {
            padded[i - 324] = ID.magma_block;
          }
        }
      }
    }

    // --- Java 1.21 OreFeature (Swept-Sphere Ellipsoids), Underground Stone Blobs & ScatterOreFeature ---
    if (this.dimension === 'overworld' || this.dimension === 'nether') {
      const cxBuf = this._oreCx, cyBuf = this._oreCy, czBuf = this._oreCz, radBuf = this._oreRad;

      // mode: 0 = Overworld mineral ore, 1 = Overworld stone/soil blob, 2 = Nether blob
      const placeOreFeature = (
        wx: number, wy: number, wz: number, oreId: number, size: number,
        discardOnAir: number, seedBase: number, mode: 0 | 1 | 2,
      ) => {
        if (mode === 2) {
          if (wy <= 4 || wy >= NETHER_HEIGHT - 5) return;
        } else {
          if (wy <= MIN_Y + 1 || wy >= maxColH - (mode === 1 ? 4 : 1)) return;
        }
        let rs = seedBase | 0;
        const nextRand = () => {
          rs = (rs + 0x6d2b79f5) | 0;
          let t = Math.imul(rs ^ (rs >>> 15), 1 | rs);
          t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
          return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };

        const deepslateOreId = mode === 0 ? (ID['deepslate_' + BLOCKS[oreId].name] ?? oreId) : oreId;
        const isReplaceable = (cur: number, by: number, lx: number, lz: number): boolean => {
          if (mode === 0) {
            return cur === ID.stone || cur === ID.deepslate || cur === ID.granite || cur === ID.diorite || cur === ID.andesite || cur === ID.tuff;
          }
          if (mode === 1) {
            if (cur !== ID.stone && cur !== ID.deepslate) return false;
            if (by >= getH(lx, lz) - 4) return false;
            if (by < 0 && (oreId === ID.granite || oreId === ID.diorite || oreId === ID.andesite || oreId === ID.dirt)) return false;
            return true;
          }
          if (oreId === ID.magma_block || oreId === ID.nether_quartz_ore || oreId === ID.nether_gold_ore) {
            return cur === ID.netherrack || cur === ID.basalt || cur === ID.blackstone;
          }
          return cur === ID.netherrack;
        };

        const checkAirExposed = (pi: number, bx: number, by: number, bz: number): boolean => {
          if (discardOnAir <= 0) return false;
          if (
            padded[pi - 1] === 0 || padded[pi + 1] === 0 ||
            padded[pi - 18] === 0 || padded[pi + 18] === 0 ||
            padded[pi - 324] === 0 || padded[pi + 324] === 0
          ) {
            return discardOnAir >= 1 || coordHash(bx + by * 13, bz - by * 17, seedBase + 77) < discardOnAir;
          }
          return false;
        };

        const writeVoxel = (lx: number, by: number, lz: number): boolean => {
          const pi = idx(lx, by, lz);
          const cur = padded[pi];
          if (!isReplaceable(cur, by, lx, lz)) return false;
          if (checkAirExposed(pi, ox + lx, by, oz + lz)) return false;
          padded[pi] = mode === 0 && (cur === ID.deepslate || cur === ID.tuff) ? deepslateOreId : oreId;
          if (mode === 2 && by + 1 > maxY) maxY = by + 1;
          return true;
        };

        const effSize = mode === 1 ? Math.min(size, 24) : size;
        const steps = mode === 1 ? 8 : Math.min(size, 20);
        const angle = nextRand() * Math.PI;
        const spread = effSize * 0.125;
        const sinA = Math.sin(angle) * spread, cosA = Math.cos(angle) * spread;
        const x0 = wx + sinA, x1 = wx - sinA;
        const z0 = wz + cosA, z1 = wz - cosA;
        const y0 = wy + Math.floor(nextRand() * 3) - 2;
        const y1 = wy + Math.floor(nextRand() * 3) - 2;

        for (let m = 0; m < steps; m++) {
          const t = steps <= 4 ? (m + 0.5) / steps : m / steps;
          cxBuf[m] = x0 + (x1 - x0) * t;
          cyBuf[m] = y0 + (y1 - y0) * t;
          czBuf[m] = z0 + (z1 - z0) * t;
          const scale = (0.35 + 0.65 * nextRand()) * effSize * 0.0625;
          radBuf[m] = ((Math.sin(Math.PI * t) + 1.0) * scale + 1.0) * 0.5;
        }

        // Java OreFeature sphere culling: discard spheres completely enclosed inside a larger sphere
        for (let i = 0; i < steps - 1; i++) {
          const ri = radBuf[i];
          if (ri <= 0) continue;
          for (let j = i + 1; j < steps; j++) {
            const rj = radBuf[j];
            if (rj <= 0) continue;
            const dr = ri - rj;
            const dx = cxBuf[i] - cxBuf[j], dy = cyBuf[i] - cyBuf[j], dz = czBuf[i] - czBuf[j];
            if (dr * dr > dx * dx + dy * dy + dz * dz) {
              if (dr > 0) radBuf[j] = -1;
              else { radBuf[i] = -1; break; }
            }
          }
        }

        const minYBound = mode === 2 ? 5 : MIN_Y + 1;
        const maxYBound = mode === 2 ? NETHER_HEIGHT - 6 : Math.min(MIN_Y + HEIGHT - 2, maxColH - 1);
        let prevLx = -99, prevBy = -99, prevLz = -99;

        for (let m = 0; m < steps; m++) {
          const r = radBuf[m];
          if (r <= 0) continue;
          const cXm = cxBuf[m], cYm = cyBuf[m], cZm = czBuf[m];
          const xMin = Math.max(0, Math.floor(cXm - r) - ox);
          const xMax = Math.min(15, Math.floor(cXm + r) - ox);
          if (xMin > xMax) continue;
          const yMin = Math.max(minYBound, Math.floor(cYm - r));
          const yMax = Math.min(maxYBound, Math.floor(cYm + r));
          if (yMin > yMax) continue;
          const zMin = Math.max(0, Math.floor(cZm - r) - oz);
          const zMax = Math.min(15, Math.floor(cZm + r) - oz);
          if (zMin > zMax) continue;

          const invR = 1.0 / r;
          for (let lx = xMin; lx <= xMax; lx++) {
            const dx = (ox + lx + 0.5 - cXm) * invR;
            const dx2 = dx * dx;
            if (dx2 >= 1.0) continue;
            for (let by = yMin; by <= yMax; by++) {
              const dy = (by + 0.5 - cYm) * invR;
              const dxy2 = dx2 + dy * dy;
              if (dxy2 >= 1.0) continue;
              for (let lz = zMin; lz <= zMax; lz++) {
                const dz = (oz + lz + 0.5 - cZm) * invR;
                if (dxy2 + dz * dz < 1.0) {
                  if (writeVoxel(lx, by, lz)) {
                    // Bridge diagonal steps so every multi-block OreFeature ellipsoid is 6-connected (face-adjacent)
                    if (prevLx >= 0) {
                      const adx = Math.abs(lx - prevLx), ady = Math.abs(by - prevBy), adz = Math.abs(lz - prevLz);
                      if (adx + ady + adz === 2 && adx <= 1 && ady <= 1 && adz <= 1) {
                        if (adx === 1) writeVoxel(lx, prevBy, prevLz);
                        else if (adz === 1) writeVoxel(prevLx, prevBy, lz);
                      } else if (adx + ady + adz === 3 && adx === 1 && ady === 1 && adz === 1) {
                        writeVoxel(lx, prevBy, prevLz);
                        writeVoxel(lx, prevBy, lz);
                      }
                    }
                    prevLx = lx; prevBy = by; prevLz = lz;
                  }
                }
              }
            }
          }
        }
      };

      const triY = (minY: number, maxY: number, peakY: number, u1: number, u2: number) => {
        const t = (u1 + u2) * 0.5;
        return t < 0.5 ? Math.floor(minY + (peakY - minY) * (t * 2)) : Math.floor(peakY + (maxY - peakY) * ((t - 0.5) * 2));
      };
      const uniY = (minY: number, maxY: number, u: number) => Math.floor(minY + (maxY - minY + 1) * u);

      if (this.dimension === 'overworld') {
        const centerBiome = getBiome(8, 8);
        const inMtn = ['meadow', 'cherry_grove', 'grove', 'snowy_slopes', 'jagged_peaks', 'frozen_peaks', 'stony_peaks', 'windswept_hills', 'windswept_gravelly_hills', 'windswept_forest'].includes(centerBiome);
        const inBad = centerBiome.includes('badlands');

        // 1. Underground Stone & Soil Blobs (Java 1.21 OreFeature specifications)
        // [blockId, count, minY, maxY, size, prob]
        const stoneBlobs: [number, number, number, number, number, number][] = [
          [ID.tuff, 2, -64, 0, 64, 1.0],
          [ID.granite, 2, 0, 60, 64, 1.0],
          [ID.granite, 1, 64, 128, 64, 1 / 6],
          [ID.diorite, 2, 0, 60, 64, 1.0],
          [ID.diorite, 1, 64, 128, 64, 1 / 6],
          [ID.andesite, 2, 0, 60, 64, 1.0],
          [ID.andesite, 1, 64, 128, 64, 1 / 6],
          [ID.dirt, 7, 0, 160, 33, 1.0],
          [ID.gravel, 14, -64, 320, 33, 1.0],
        ];
        for (let si = 0; si < stoneBlobs.length; si++) {
          const [blkId, count, minY, maxY, size, prob] = stoneBlobs[si];
          if (!blkId) continue;
          for (let k = 0; k < count; k++) {
            const s = this.seed + 31000 + si * 733 + k * 47;
            if (prob < 1.0 && coordHash(cx + si, cz - k, s + 9) >= prob) continue;
            const rx = ox + 1 + Math.floor(coordHash(cx, cz + k, s) * 14);
            const rz = oz + 1 + Math.floor(coordHash(cx + k, cz, s + 1) * 14);
            const ry = uniY(minY, maxY, coordHash(cx + si, cz + k, s + 2));
            placeOreFeature(rx, ry, rz, blkId, size, 0, s + 3, 1);
          }
        }

        // 2. Overworld Mineral Ore Batches (Official Java Edition 1.21 OreFeature table)
        // [oreId, count, minY, maxY, peakY (NaN = Uniform), size, discardOnAir, prob]
        const oreBatches: [number, number, number, number, number, number, number, number][] = [
          // Coal Ore: Upper uniform (30x size 17, Y=136..320, air=0) + Lower triangle (20x size 17, Y=0..192, peak 96, air=0.5)
          [ID.coal_ore, 30, 136, 320, NaN, 17, 0, 1.0],
          [ID.coal_ore, 20, 0, 192, 96, 17, 0.5, 1.0],
          // Iron Ore: Upper triangle (90x size 9, Y=80..384, peak 232) + Mid triangle (10x size 9, Y=-24..56, peak 16) + Small uniform (10x size 4, Y=-64..72)
          [ID.iron_ore, 90, 80, 384, 232, 9, 0, 1.0],
          [ID.iron_ore, 10, -24, 56, 16, 9, 0, 1.0],
          [ID.iron_ore, 10, -64, 72, NaN, 4, 0, 1.0],
          // Copper Ore: 16x size 10 (20 in dripstone_caves), Triangle Y=-16..112, peak 48
          [ID.copper_ore, 16, -16, 112, 48, 10, 0, 1.0],
          // Gold Ore: Main triangle (4x size 9, Y=-64..32, peak -16, air=0.5) + Lower buried uniform (1/2x size 9, Y=-64..-48, air=0.5)
          [ID.gold_ore, 4, -64, 32, -16, 9, 0.5, 1.0],
          [ID.gold_ore, 1, -64, -48, NaN, 9, 0.5, 0.5],
          // Redstone Ore: Uniform (4x size 8, Y=-64..15) + Deep triangle (8x size 8, Y=-96..-32, peak -64)
          [ID.redstone_ore, 4, -64, 15, NaN, 8, 0, 1.0],
          [ID.redstone_ore, 8, -96, -32, -64, 8, 0, 1.0],
          // Diamond Ore: Small (7x size 4, air=0.5) + Buried (4x size 8, air=1.0) + Large (1/9x size 12, air=0.7), all Triangle Y=-144..16, peak -64
          [ID.diamond_ore, 7, -144, 16, -64, 4, 0.5, 1.0],
          [ID.diamond_ore, 4, -144, 16, -64, 8, 1.0, 1.0],
          [ID.diamond_ore, 1, -144, 16, -64, 12, 0.7, 1 / 9],
          // Lapis Lazuli Ore: Triangle (2x size 7, Y=-32..32, peak 0, air=0) + Buried uniform (4x size 7, Y=-64..64, air=1.0)
          [ID.lapis_ore, 2, -32, 32, 0, 7, 0, 1.0],
          [ID.lapis_ore, 4, -64, 64, NaN, 7, 1.0, 1.0],
        ];
        if (inBad) oreBatches.push([ID.gold_ore, 50, 32, 256, NaN, 9, 0, 1.0]);
        if (inMtn) oreBatches.push([ID.emerald_ore, 100, -16, 480, 232, 3, 0, 1.0]);

        for (let oi = 0; oi < oreBatches.length; oi++) {
          const [oreId, count, minY, maxY, peakY, baseSize, discardOnAir, prob] = oreBatches[oi];
          for (let k = 0; k < count; k++) {
            const s = this.seed + oi * 997 + k * 53;
            if (prob < 1.0 && coordHash(cx + oi, cz - k, s + 9) >= prob) continue;
            const rx = ox + 1 + Math.floor(coordHash(cx, cz + k, s) * 14);
            const rz = oz + 1 + Math.floor(coordHash(cx + k, cz, s + 1) * 14);
            const ry = Number.isNaN(peakY)
              ? uniY(minY, maxY, coordHash(cx + oi, cz + k, s + 2))
              : triY(minY, maxY, peakY, coordHash(cx + oi, cz + k, s + 2), coordHash(cx + k, cz + oi, s + 3));
            let size = baseSize;
            if (oreId === ID.copper_ore && ry >= MIN_Y + 3 && ry < 56 && this.caveBiome(rx, ry, rz) === 'dripstone_caves') {
              size = 20;
            }
            placeOreFeature(rx, ry, rz, oreId, size, discardOnAir, s + 4, 0);
          }
        }
      } else {
        // 3. Nether Ore & Stone Blobs (Official Java Edition 1.21 OreFeature & ScatterOreFeature table)
        const nBiome = getBiome(8, 8);
        const isDelta = nBiome === 'basalt_deltas';
        const isSoul = nBiome === 'soul_sand_valley';
        const qCount = isDelta ? 32 : 16;
        const gCount = isDelta ? 20 : 10;

        const netherBatches: [number, number, number, number, number][] = [
          [ID.nether_quartz_ore, qCount, 10, 117, 14],
          [ID.nether_gold_ore, gCount, 10, 117, 10],
          [ID.magma_block, 4, 27, 36, 33],
        ];
        if (!isDelta) {
          netherBatches.push([ID.blackstone, 2, 5, 31, 33]);
          netherBatches.push([ID.gravel, 2, 5, 41, 33]);
        }
        if (isSoul) {
          netherBatches.push([ID.soul_sand, 12, 0, 31, 12]);
        }

        for (let ni = 0; ni < netherBatches.length; ni++) {
          const [blkId, count, minY, maxY, size] = netherBatches[ni];
          if (!blkId) continue;
          for (let k = 0; k < count; k++) {
            const s = this.seed + 51000 + ni * 887 + k * 61;
            const rx = ox + 1 + Math.floor(coordHash(cx, cz + k, s) * 14);
            const rz = oz + 1 + Math.floor(coordHash(cx + k, cz, s + 1) * 14);
            const ry = uniY(minY, maxY, coordHash(cx + ni, cz + k, s + 2));
            placeOreFeature(rx, ry, rz, blkId, size, 0, s + 3, 2);
          }
        }

        // Ancient Debris (ScatterOreFeature: never exposed to air, replaces netherrack/basalt/blackstone)
        // Batch 1: 1 cluster of 1..3 blocks, Triangle Y=8..24 (peak 16), air discard = 1.0
        // Batch 2: 1 cluster of 1..2 blocks, Uniform Y=8..119, air discard = 1.0
        const placeAncientDebris = (wx: number, wy: number, wz: number, maxCount: number, seedBase: number) => {
          if (wy < 8 || wy >= NETHER_HEIGHT - 5 || !ID.ancient_debris) return;
          const cnt = 1 + Math.floor(coordHash(wx, wz, seedBase) * maxCount);
          for (let m = 0; m < cnt; m++) {
            const dx = m === 0 ? 0 : Math.round((coordHash(wx + m * 7, wz, seedBase + 1) - coordHash(wz, wx - m * 11, seedBase + 2)) * 1.2);
            const dy = m === 0 ? 0 : Math.round((coordHash(wx, wy + m * 13, seedBase + 3) - coordHash(wy, wz + m * 5, seedBase + 4)) * 1.2);
            const dz = m === 0 ? 0 : Math.round((coordHash(wz + m * 17, wy, seedBase + 5) - coordHash(wx - m * 3, wz, seedBase + 6)) * 1.2);
            const lx = wx + dx - ox, lz = wz + dz - oz, by = wy + dy;
            if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || by < 5 || by >= NETHER_HEIGHT - 5) continue;
            const pi = idx(lx, by, lz);
            const cur = padded[pi];
            if (cur !== ID.netherrack && cur !== ID.basalt && cur !== ID.blackstone) continue;
            if (
              padded[pi - 1] === 0 || padded[pi + 1] === 0 ||
              padded[pi - 18] === 0 || padded[pi + 18] === 0 ||
              padded[pi - 324] === 0 || padded[pi + 324] === 0
            ) continue;
            padded[pi] = ID.ancient_debris;
            if (by + 1 > maxY) maxY = by + 1;
          }
        };

        const sDeb1 = this.seed + 77111;
        const dx1 = ox + 1 + Math.floor(coordHash(cx, cz, sDeb1) * 14);
        const dz1 = oz + 1 + Math.floor(coordHash(cz, cx, sDeb1 + 1) * 14);
        const dy1 = triY(8, 24, 16, coordHash(cx + 3, cz, sDeb1 + 2), coordHash(cx, cz + 3, sDeb1 + 3));
        placeAncientDebris(dx1, dy1, dz1, 3, sDeb1 + 4);

        const sDeb2 = this.seed + 77222;
        const dx2 = ox + 1 + Math.floor(coordHash(cx, cz, sDeb2) * 14);
        const dz2 = oz + 1 + Math.floor(coordHash(cz, cx, sDeb2 + 1) * 14);
        const dy2 = uniY(8, 119, coordHash(cx + 5, cz + 7, sDeb2 + 2));
        placeAncientDebris(dx2, dy2, dz2, 2, sDeb2 + 3);
      }
    }

    // ---- Structure phase (vanilla order: structures → beardifier foundations → surface features) ----
    if (structures && this.dimension === 'overworld') {
      const [shx, shz] = this.strongholdPos();
      if (Math.abs(ox + 8 - shx) < STRONGHOLD_RADIUS + 10 && Math.abs(oz + 8 - shz) < STRONGHOLD_RADIUS + 10) buildStronghold(this, put, shx, shz, ox, oz);
      else if (Math.hypot(ox + 8, oz + 8) > 1000) {
        for (const [rsx, rsz] of this.strongholdRings()) {
          if (Math.abs(ox + 8 - rsx) < STRONGHOLD_RADIUS + 10 && Math.abs(oz + 8 - rsz) < STRONGHOLD_RADIUS + 10) {
            buildStronghold(this, put, rsx, rsz, ox, oz);
            if (Math.abs(ox + 8 - rsx) <= 24 && Math.abs(oz + 8 - rsz) <= 24) this.stronghold(put, rsx, rsz);
            break;
          }
        }
      }
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const room = this.dungeonAt(cx + dx, cz + dz);
        if (room) this.dungeon(put, room);
      }
      for (const s of nearby.list) {
        const reach = s.type === 'plains_village' || s.type === 'desert_village' ? 84 : 36;
        if (Math.abs(ox + 8 - s.x) > reach || Math.abs(oz + 8 - s.z) > reach) continue;
        if (s.type === 'desert_village') grandVillage(this, put, s.x, s.z, 'desert', ox, oz);
        else if (s.type === 'desert_pyramid') this.desertPyramid(put, foundation, s.x, s.z);
        else if (s.type === 'plains_village') {
          grandVillage(this, put, s.x, s.z, villageVariantFor(this.biomeAt(s.x, s.z, this.height(s.x, s.z))), ox, oz);
        } else if (s.type === 'ruined_portal') {
          this.ruinedPortal(put, foundation, s.x, s.z);
        } else if (s.type === 'witch_hut') {
          this.witchHut(put, foundation, s.x, s.z);
        } else if (s.type === 'desert_fossil') {
          this.desertFossil(put, s.x, s.z);
        }
      }
      placeExtraStructures(this, put, ox, oz);
    }

    // --- Overworld Trees & Biome Features (wide cross-chunk neighborhood so canopies never clip at chunk borders) ---
    if (this.dimension === 'overworld') {
      // Sparse feature grid (Ice Spikes, Icebergs, Desert Wells, Forest Rocks, Azalea Trees)
      for (let gz = Math.floor((oz - 12) / 14); gz <= Math.floor((oz + 28) / 14); gz++) {
        for (let gx = Math.floor((ox - 12) / 14); gx <= Math.floor((ox + 28) / 14); gx++) {
          const r = coordHash(gx, gz, this.seed + 1411);
          const x = gx * 14 + Math.floor(coordHash(gx, gz, this.seed + 1412) * 14);
          const z = gz * 14 + Math.floor(coordHash(gx, gz, this.seed + 1413) * 14);
          if (inExcl(x, z, FOOTPRINT_BUFFER + 4)) continue;                     // spikes / rocks / azaleas reach 4 blocks
          const lxF = x - ox, lzF = z - oz;
          const inGridF = lxF >= -2 && lxF <= 17 && lzF >= -2 && lzF <= 17;
          const h = inGridF ? getH(lxF, lzF) : this.height(x, z);
          const biome = inGridF ? getBiome(lxF, lzF) : this.biomeAt(x, z, h);
          if (biome === 'ice_spikes' && h >= SEA + 1 && r < 0.58) {
            placeIceSpike(put, x, h, z, this.seed);
          } else if ((biome === 'frozen_ocean' || biome === 'deep_frozen_ocean') && h < SEA - 6 && r < 0.14) {
            placeIceberg(put, x, SEA, z, this.seed);
          } else if ((biome === 'old_growth_pine_taiga' || biome === 'old_growth_spruce_taiga') && h >= SEA + 1 && r < 0.25) {
            placeForestRock(put, x, h + 1, z, this.seed);
          } else if (biome === 'desert' && h >= SEA + 2 && r < 0.025) {
            placeDesertWell(put, x, h, z);
          } else if (h >= SEA + 2 && r < 0.18 && biome !== 'birch_forest' && biome !== 'old_growth_birch_forest' && this.caveBiome(x, 20, z) === 'lush_caves') {
            placeAzaleaTree(put, x, h, z, this.seed);
          }
        }
      }

      // Main tree grid (7x7 cells with full jitter)
      for (let gz = Math.floor((oz - 8) / 7); gz <= Math.floor((oz + 24) / 7); gz++) {
        for (let gx = Math.floor((ox - 8) / 7); gx <= Math.floor((ox + 24) / 7); gx++) {
          const r = coordHash(gx, gz, this.seed + 818);
          const x = gx * 7 + Math.floor(coordHash(gx, gz, this.seed + 23) * 7);
          const z = gz * 7 + Math.floor(coordHash(gx, gz, this.seed + 24) * 7);
          // Canopy radius of the widest tree of the biome (mega jungle / dark oak / huge mushroom = 6, fancy oak = 4, blob = 3)
          // plus the 2-block buffer: leaves can never reach a wall, roof or interior of any structure.
          if (inExcl(x, z, FOOTPRINT_BUFFER + CANOPY_RADIUS)) continue;
          const lxT = x - ox, lzT = z - oz;
          const inGridT = lxT >= -2 && lxT <= 17 && lzT >= -2 && lzT <= 17;
          const h = inGridT ? getH(lxT, lzT) : this.height(x, z);
          const biome = inGridT ? getBiome(lxT, lzT) : this.biomeAt(x, z, h);
          const biomeE = this.ecotone(biome, x, z, h);

          // Swamp/Mangrove trees can root in shallow water (SEA - 1)
          const minTreeH = (biome === 'swamp' || biome === 'mangrove_swamp') ? SEA - 1 : SEA + 2;
          if (h < minTreeH) continue;

          const chanceFor = (biome: string): number =>
            biome === 'dark_forest' ? 0.88 :
            biome === 'jungle' ? 0.86 :
            biome === 'sparse_jungle' ? 0.24 :
            biome === 'bamboo_jungle' ? 0.55 :
            biome === 'cherry_grove' ? 0.65 :
            biome === 'birch_forest' || biome === 'old_growth_birch_forest' ? 0.68 :
            biome === 'forest' ? 0.66 :
            biome === 'taiga' || biome === 'snowy_taiga' ? 0.62 :
            biome === 'old_growth_pine_taiga' || biome === 'old_growth_spruce_taiga' ? 0.64 :
            biome === 'grove' ? 0.52 :
            biome === 'mangrove_swamp' ? 0.62 :
            biome === 'flower_forest' ? 0.36 :
            biome === 'swamp' ? 0.32 :
            biome === 'windswept_forest' ? 0.34 :
            biome === 'wooded_badlands' ? (h >= 97 ? 0.38 : 0) :
            biome === 'savanna' || biome === 'savanna_plateau' || biome === 'windswept_savanna' ? 0.14 :
            biome === 'mushroom_fields' ? 0.26 :
            biome === 'windswept_hills' || biome === 'windswept_gravelly_hills' ? 0.06 :
            biome === 'snowy_plains' ? 0.03 :
            biome === 'plains' || biome === 'sunflower_plains' ? 0.04 : 0;
          // Tree *type* always follows the real biome; near a border the density fades towards the neighbouring biome's density.
          const chance = Math.min(chanceFor(biome), chanceFor(biomeE));

          if (r > chance) continue;
          const surf = this.surface(biome, x, z, h);
          if (
            surf !== ID.grass_block && surf !== ID.podzol && surf !== ID.mycelium &&
            surf !== ID.snow_block && surf !== ID.mud && surf !== ID.coarse_dirt &&
            !(biome === 'swamp' && h < SEA)
          ) continue;

          const rKind = coordHash(gx, gz, this.seed + 911);

          if (biome === 'mushroom_fields') {
            placeHugeMushroom(put, x, h, z, this.seed, rKind < 0.5);
          } else if (biome === 'dark_forest') {
            if (rKind < 0.04) placeHugeMushroom(put, x, h, z, this.seed, true);
            else if (rKind < 0.07) placeHugeMushroom(put, x, h, z, this.seed, false);
            else if (rKind < 0.72) placeDarkOakTree(put, x, h, z, this.seed);
            else if (rKind < 0.88) placeBlobTree(put, x, h, z, this.seed, ID.birch_log, ID.birch_leaves, 5, 2);
            else if (rKind < 0.94) placeFancyOakTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          } else if (biome === 'cherry_grove') {
            placeCherryTree(put, x, h, z, this.seed);
          } else if (biome === 'mangrove_swamp') {
            placeMangroveTree(put, x, h, z, this.seed);
          } else if (biome === 'swamp') {
            placeSwampOakTree(put, x, h, z, this.seed);
          } else if (biome === 'savanna' || biome === 'savanna_plateau' || biome === 'windswept_savanna') {
            if (rKind < 0.85) placeAcaciaTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          } else if (biome === 'jungle' || biome === 'sparse_jungle' || biome === 'bamboo_jungle') {
            if (biome !== 'sparse_jungle' && rKind < 0.30) placeMegaJungleTree(put, x, h, z, this.seed);
            else if (rKind < 0.72) placeJungleBush(put, x, h, z, this.seed);
            else if (rKind < 0.84) placeFancyOakTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.jungle_log, ID.jungle_leaves, 4, 7, { vines: true, cocoa: true });
          } else if (biome === 'old_growth_pine_taiga' || biome === 'old_growth_spruce_taiga') {
            const isSpruceBiome = biome === 'old_growth_spruce_taiga';
            if (rKind < 0.33) placeMegaTaigaTree(put, x, h, z, this.seed, isSpruceBiome || rKind < 0.03);
            else placeSpruceOrPine(put, x, h, z, this.seed, rKind < 0.66);
          } else if (biome === 'taiga' || biome === 'snowy_taiga' || biome === 'grove' || biome === 'snowy_plains') {
            placeSpruceOrPine(put, x, h, z, this.seed, rKind < 0.33);
          } else if (biome === 'birch_forest' || biome === 'old_growth_birch_forest') {
            const tall = biome === 'old_growth_birch_forest';
            placeBlobTree(put, x, h, z, this.seed, ID.birch_log, ID.birch_leaves, tall ? 7 : 5, tall ? 6 : 2);
          } else if (biome === 'windswept_hills' || biome === 'windswept_gravelly_hills' || biome === 'windswept_forest') {
            if (rKind < 0.67) placeSpruceOrPine(put, x, h, z, this.seed, false);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          } else if (biome === 'forest' || biome === 'flower_forest') {
            if (rKind < 0.20) placeBlobTree(put, x, h, z, this.seed, ID.birch_log, ID.birch_leaves, 5, 2);
            else if (rKind < 0.30) placeFancyOakTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          } else {
            // Plains / Sunflower Plains / Wooded Badlands
            if (biome !== 'wooded_badlands' && rKind < 0.15) placeFancyOakTree(put, x, h, z, this.seed);
            else placeBlobTree(put, x, h, z, this.seed, ID.oak_log, ID.oak_leaves, 4, 2);
          }
        }
      }
    }

    // Nether Crimson & Warped Huge Fungi
    if (this.dimension === 'nether') {
      for (let gz = Math.floor((oz - 5) / 9); gz <= Math.floor((oz + 21) / 9); gz++) {
        for (let gx = Math.floor((ox - 5) / 9); gx <= Math.floor((ox + 21) / 9); gx++) {
          const r = coordHash(gx, gz, this.seed + 613);
          if (r > 0.45) continue;
          const x = gx * 9 + Math.floor(coordHash(gx, gz, this.seed + 25) * 6);
          const z = gz * 9 + Math.floor(coordHash(gx, gz, this.seed + 26) * 6);
          const h = this.height(x, z);
          if (h <= NETHER_LAVA) continue;
          const b = this.biomeAt(x, z, h);
          if (b !== 'crimson_forest' && b !== 'warped_forest') continue;
          let ceilH = h + 2;
          while (ceilH < NETHER_HEIGHT - 6 && !this.netherSolid(x, ceilH, z)) ceilH++;
          if (ceilH - h < 7) continue;
          placeHugeFungus(put, x, h, z, this.seed, b === 'crimson_forest', ceilH);
        }
      }
    }

    // Outer End Chorus Plants
    if (this.dimension === 'end') {
      for (let gz = Math.floor((oz - 6) / 10); gz <= Math.floor((oz + 22) / 10); gz++) {
        for (let gx = Math.floor((ox - 6) / 10); gx <= Math.floor((ox + 22) / 10); gx++) {
          const x = gx * 10 + Math.floor(coordHash(gx, gz, this.seed + 911) * 7);
          const z = gz * 10 + Math.floor(coordHash(gx, gz, this.seed + 912) * 7);
          if (Math.hypot(x, z) < END_OUTER_RADIUS) continue;
          if (Math.hypot(x - END_FIRST_CITY[0] - 5, z - END_FIRST_CITY[1] - 5) < 20) continue;
          const h = this.height(x, z);
          if (h < 10) continue;
          if (coordHash(gx, gz, this.seed + 913) < 0.35) {
            placeChorusPlant(put, x, h + 1, z, this.seed);
          }
        }
      }
    }

    if (structures && this.dimension === 'nether') {
      const nrx = Math.floor((ox + 8) / 128), nrz = Math.floor((oz + 8) / 128);
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const rrx = nrx + dx, rrz = nrz + dz;
        const fx = rrx === 0 && rrz === 0 ? 32 : rrx * 128 + 48;
        const fz = rrx === 0 && rrz === 0 ? 32 : rrz * 128 + 48;
        if ((rrx === 0 && rrz === 0) || coordHash(rrx, rrz, this.seed + 5555) < 0.42) {
          if (Math.abs(ox + 8 - fx) < FORTRESS_RADIUS + 12 && Math.abs(oz + 8 - fz) < FORTRESS_RADIUS + 12) netherFortress(this, put, fx, fz, ox, oz);
        }
      }
    }

    if (structures && this.dimension === 'end') {
      const Y0 = END_ISLAND_Y;
      if (Math.hypot(ox + 8, oz + 8) <= 120) {
        // 5×5 obsidian arrival platform (the end spawn), kept clear above.
        for (let dz = 40; dz <= 44; dz++) for (let dx = -2; dx <= 2; dx++) {
          put(dx, Y0 - 1, dz, ID.obsidian, true);
          for (let dy = 0; dy <= 4; dy++) put(dx, Y0 + dy, dz, 0, true);
        }
        // 10 obsidian pillars (radius 42, heights 76‥103, radius 2‥5, two caged crystals), each capped with bedrock.
        for (const pil of endPillars()) {
          if (Math.abs(ox + 8 - pil.x) > 16 || Math.abs(oz + 8 - pil.z) > 16) continue;
          for (let y = Y0 - 20; y <= pil.h; y++) {
            for (let dz = -pil.r; dz <= pil.r; dz++) for (let dx = -pil.r; dx <= pil.r; dx++) {
              if (dx * dx + dz * dz <= pil.r * pil.r + 1) put(pil.x + dx, y, pil.z + dz, ID.obsidian, true);
            }
          }
          put(pil.x, pil.h + 1, pil.z, ID.bedrock, true);
          if (pil.caged) {
            const cr = 2;
            for (let y = pil.h + 1; y <= pil.h + 4; y++) {
              for (let dz = -cr; dz <= cr; dz++) for (let dx = -cr; dx <= cr; dx++) {
                if (Math.abs(dx) === cr || Math.abs(dz) === cr || y === pil.h + 4) put(pil.x + dx, y, pil.z + dz, ID.iron_bars, true);
              }
            }
          }
        }
        // Exit portal: bedrock disc with a raised rim and a 4-high bedrock pillar for the dragon egg, torches on the pillar.
        if (Math.abs(ox + 8) < 16 && Math.abs(oz + 8) < 16) {
          for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
            const r2 = dx * dx + dz * dz;
            if (r2 <= 10) {
              put(dx, Y0 - 1, dz, ID.bedrock, true);
              if (r2 >= 5) put(dx, Y0, dz, ID.bedrock, true);
              else put(dx, Y0, dz, 0, true);
            }
          }
          for (let dy = 0; dy <= 3; dy++) put(0, Y0 + dy, 0, ID.bedrock, true);
          put(1, Y0 + 2, 0, ID.torch, false); put(-1, Y0 + 2, 0, ID.torch, false);
          put(0, Y0 + 2, 1, ID.torch, false); put(0, Y0 + 2, -1, ID.torch, false);
        }
        // End gateway frame at radius 96, Y 75 (bedrock caps above and below the gateway block).
        if (Math.abs(ox + 8 - END_GATEWAY_MAIN[0]) < 16 && Math.abs(oz + 8 - END_GATEWAY_MAIN[2]) < 16) {
          const [gx, gy, gz] = END_GATEWAY_MAIN;
          for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
            put(gx + dx, gy - 1, gz + dz, ID.bedrock, true);
            put(gx + dx, gy + 1, gz + dz, ID.bedrock, true);
          }
          put(gx, gy - 2, gz, ID.bedrock, true);
          put(gx, gy + 2, gz, ID.bedrock, true);
        }
      }

      // First outer-island end city + end ship, 1,024 blocks out beside the arrival island, and the return gateway.
      const [acx, acz] = END_FIRST_CITY, [asx, asy, asz] = END_FIRST_SHIP;
      if (Math.abs(ox + 8 - (acx + 12)) < 96 && Math.abs(oz + 8) < 96) {
        this.endCity(put, acx, acz, ox, oz, true);
        if (Math.abs(ox + 8 - (acx + 12)) < 42 && Math.abs(oz + 8) < 42) {
          buildEndShip(this, put, asx, asy, asz);
        }
      }
      const [arx, ary, arz] = END_OUTER_ARRIVAL;
      if (Math.abs(ox + 8 - (arx - 16)) < 16 && Math.abs(oz + 8 - arz) < 16) {
        put(arx - 16, ary - 2, arz, ID.bedrock, true);
        put(arx - 16, ary, arz, ID.bedrock, true);
        put(arx - 16, ary - 1, arz, ID.end_gateway, true);
      }
      const erx = Math.floor((ox + 8) / 144), erz = Math.floor((oz + 8) / 144);
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const rx2 = erx + dx, rz2 = erz + dz;
        const ex = rx2 * 144 + 72, ez = rz2 * 144 + 72;
        if (Math.hypot(ex, ez) < END_OUTER_RADIUS + 60 || Math.hypot(ex - arx, ez - arz) < 90) continue;
        if (coordHash(rx2, rz2, this.seed + 9876) < 0.35 && this.height(ex, ez) >= Y0 - 12) {
          if (Math.abs(ox + 8 - ex) < 96 && Math.abs(oz + 8 - ez) < 96) {
            const L = this.endCity(put, ex - 4, ez - 4, ox, oz, false);
            // Wiki: roughly half of the end cities come with a ship moored beside them.
            if (L.ships.length === 0 && coordHash(rx2, rz2, this.seed + 9877) < 0.5 && Math.abs(ox + 8 - ex) < 36 && Math.abs(oz + 8 - ez) < 36) {
              buildEndShip(this, put, ex + 16, Math.max(Y0, this.height(ex + 1, ez + 1) + 1) + 12, ez - 26);
            }
          }
        }
      }
    }

    if (structures && this.dimension !== 'overworld') placeExtraStructures(this, put, ox, oz);

    for (const [key, cell] of edits) {
      const [x, y, z] = key.split(',').map(Number);
      put(x, y, z, cell, true);
    }
    const maxDataY = Math.min(HEIGHT, maxY - MIN_Y + 4);
    for (let y = 0; y < maxDataY; y++) {
      const pBase = y * 324;
      const dBase = y * 256;
      for (let z = 0; z < 16; z++) {
        const pr = pBase + (z + 1) * 18 + 1;
        const dr = dBase + z * 16;
        for (let x = 0; x < 16; x++) data[dr + x] = padded[pr + x];
      }
    }
    const outMaxY = Math.min(MIN_Y + HEIGHT, maxY + 2);
    this._lastMaxLocalY = Math.max(SEA - MIN_Y + 4, outMaxY - MIN_Y);
    return { data, padded, tint, maxY: outMaxY };
  }

  private placeBed(put: PutFn, x: number, y: number, z: number, facing: number) {
    const dx = facing === 3 ? 1 : facing === 1 ? -1 : 0;
    const dz = facing === 0 ? 1 : facing === 2 ? -1 : 0;
    put(x, y, z, makeCell(ID.bed, facing), true);
    put(x + dx, y, z + dz, makeCell(ID.bed, facing | 4), true);
  }

  plainsHouse(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number, w = 5, d = 5) {
    const y = this.height(x + Math.floor(w / 2), z + Math.floor(d / 2)) + 1;
    const rnd = coordHash(x, z, this.seed + 4242);
    for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) {
      foundation(x + dx, y - 1, z + dz, ID.cobblestone);
      for (let dy = 0; dy < 3; dy++) {
        const wall = dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1;
        let id = wall ? ID.oak_planks : 0;
        if ((dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1)) id = ID.oak_log;
        if (wall && dy === 1) {
          const win = (dx === 1 || dx === w - 2 || dz === 1 || dz === d - 2) && !(dz === d - 1 && dx === Math.floor(w / 2));
          if (win) id = ID.glass;
        }
        if (dz === d - 1 && dx === Math.floor(w / 2) && dy < 2) id = dy === 0 ? ID.oak_door : 0;
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    for (let dz = -1; dz < d + 1; dz++) for (let dx = -1; dx < w + 1; dx++) put(x + dx, y + 3, z + dz, ID.oak_planks, true);
    for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) put(x + dx, y + 4, z + dz, ID.oak_planks, true);
    for (let dz = 1; dz < d - 1; dz++) for (let dx = 1; dx < w - 1; dx++) put(x + dx, y + 5, z + dz, ID.oak_slab, true);
    const chx = x + (rnd < 0.5 ? 1 : w - 2), chz = z + 1;
    for (let dy = 4; dy <= 6; dy++) { put(chx, y + dy, chz, ID.cobblestone, true); }

    this.placeBed(put, x + 1, y, z + 1, 0);
    put(x + w - 2, y, z + 1, ID.crafting_table);
    put(x + w - 2, y, z + d - 2, ID.chest);
    put(x + Math.floor(w / 2), y + 2, z + Math.floor(d / 2), ID.torch);
  }

  villageWellAndPaths(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const pathId = ID.dirt_path ?? ID.gravel;
    for (let i = -8; i <= 10; i++) {
      const py = this.height(x + i, z); if (py > SEA) put(x + i, py, z, pathId);
      const pz = this.height(x, z + i); if (pz > SEA) put(x, pz, z + i, pathId);
    }
    const wy = this.height(x, z) + 1;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      foundation(x + dx, wy - 1, z + dz, ID.mossy_cobblestone ?? ID.cobblestone);
      put(x + dx, wy, z + dz, dx === 0 && dz === 0 ? ID.water : (ID.mossy_cobblestone ?? ID.cobblestone), true);
      if (Math.abs(dx) === 1 && Math.abs(dz) === 1) {
        put(x + dx, wy + 1, z + dz, ID.oak_fence, true);
        put(x + dx, wy + 2, z + dz, ID.oak_fence, true);
      }
      put(x + dx, wy + 3, z + dz, ID.oak_planks, true);
    }
    const ly = this.height(x + 5, z + 1) + 1;
    put(x + 5, ly, z + 1, ID.oak_fence);
    put(x + 5, ly + 1, z + 1, ID.oak_fence);
    put(x + 5, ly + 2, z + 1, ID.lantern ?? ID.torch);
  }

  desertVillage(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, cx: number, cz: number) {
    const houses = [[cx - 11, cz - 9, 6, 6], [cx + 4, cz - 8, 7, 6], [cx - 8, cz + 5, 6, 6]];
    for (const [hx, hz, w, d] of houses) {
      const y = this.height(hx + 3, hz + 3) + 1;
      for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) {
        foundation(hx + dx, y - 1, hz + dz, ID.sandstone);
        for (let dy = 0; dy < 4; dy++) {
          const wall = dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1;
          let id = 0;
          if (dy === 3) {
            id = wall ? ID.cut_sandstone : ID.sandstone;
          } else if (wall) {
            id = dy === 2 ? ID.cut_sandstone : ID.sandstone;
            if ((dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1)) id = ID.smooth_sandstone;
            if (dy === 1 && ((dx === 2 || dx === 3) && (dz === 0 || dz === d - 1) || (dz === 2) && (dx === 0 || dx === w - 1))) id = 0;
          }
          if (dz === d - 1 && dx === Math.floor(w / 2) && dy < 2) id = 0;
          put(hx + dx, y + dy, hz + dz, id, true);
        }
        if ((dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1)) put(hx + dx, y + 4, hz + dz, ID.orange_terracotta, true);
        else if (dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1) put(hx + dx, y + 4, hz + dz, ID.sandstone_slab, true);
      }
      this.placeBed(put, hx + 1, y, hz + 1, 0);
      put(hx + w - 2, y, hz + 1, ID.crafting_table);
      put(hx + w - 2, y, hz + d - 2, ID.chest);
      put(hx + 2, y + 2, hz + 2, ID.torch);
    }
    const wy = this.height(cx, cz) + 1;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      foundation(cx + dx, wy - 1, cz + dz, ID.sandstone);
      put(cx + dx, wy, cz + dz, dx === 0 && dz === 0 ? ID.water : ID.sandstone, true);
      if (Math.abs(dx) === 1 && Math.abs(dz) === 1) {
        put(cx + dx, wy + 1, cz + dz, ID.sandstone, true);
        put(cx + dx, wy + 2, cz + dz, ID.sandstone, true);
      }
      put(cx + dx, wy + 3, cz + dz, ID.sandstone_slab, true);
    }
    const mx = cx + 6, mz = cz + 6, my = this.height(mx + 2, mz + 2) + 1;
    for (let dz = 0; dz < 4; dz++) for (let dx = 0; dx < 5; dx++) {
      foundation(mx + dx, my - 1, mz + dz, ID.cut_sandstone);
      for (let dy = 0; dy < 4; dy++) put(mx + dx, my + dy, mz + dz, 0, true);
      if ((dx === 0 || dx === 4) && (dz === 0 || dz === 3)) {
        put(mx + dx, my, mz + dz, ID.oak_fence, true);
        put(mx + dx, my + 1, mz + dz, ID.oak_fence, true);
        put(mx + dx, my + 2, mz + dz, ID.oak_fence, true);
      }
      put(mx + dx, my + 3, mz + dz, dx % 2 === 0 ? ID.orange_wool : ID.white_wool, true);
    }
    put(mx + 1, my, mz + 1, ID.hay_block, true);
    put(mx + 2, my, mz + 1, ID.chest, true);
  }

  desertPyramid(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, cx: number, cz: number) {
    desertPyramidBuild(this, put, foundation, cx, cz);
    void tagLoot;
  }

  witchHut(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const y = SEA + 4;
    for (const [lx, lz] of [[x, z], [x + 6, z], [x, z + 6], [x + 6, z + 6]]) {
      foundation(lx, SEA - 1, lz, ID.spruce_log);
      for (let yy = SEA; yy <= y; yy++) put(lx, yy, lz, ID.spruce_log, true);
    }
    for (let dz = 0; dz <= 6; dz++) for (let dx = 0; dx <= 6; dx++) {
      put(x + dx, y, z + dz, ID.spruce_planks, true);
    }
    for (let dy = 1; dy <= 3; dy++) for (let dz = 0; dz <= 6; dz++) for (let dx = 0; dx <= 6; dx++) {
      const wall = dx === 0 || dx === 6 || dz === 0 || dz === 6;
      if (wall) {
        let id = ID.spruce_planks;
        if (dy === 2 && ((dx === 3 && (dz === 0 || dz === 6)) || (dz === 3 && dx === 6))) id = ID.oak_fence;
        if (dz === 6 && dx === 3 && dy < 3) id = 0;
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    for (let dz = -1; dz <= 7; dz++) for (let dx = -1; dx <= 7; dx++) {
      put(x + dx, y + 4, z + dz, ID.spruce_planks, true);
    }
    for (let dz = 0; dz <= 6; dz++) for (let dx = 0; dx <= 6; dx++) {
      put(x + dx, y + 5, z + dz, ID.spruce_slab, true);
    }
    put(x + 2, y + 1, z + 2, ID.crafting_table, true);
    put(x + 4, y + 1, z + 2, ID.cauldron ?? ID.blackstone, true);
    put(x + 1, y + 2, z + 5, ID.torch, true);
    put(x + 3, y + 2, z, ID.potted_red_mushroom ?? ID.red_mushroom, true);
  }

  desertFossil(put: PutFn, cx: number, cz: number) {
    const y = this.height(cx, cz);
    for (let r = 0; r < 4; r++) {
      const fz = cz + r * 3 - 4;
      for (let dy = 0; dy <= 4; dy++) {
        put(cx - 3, y + dy, fz, ID.bone_block, true);
        put(cx + 3, y + dy, fz, ID.bone_block, true);
      }
      for (let dx = -2; dx <= 2; dx++) {
        put(cx + dx, y + 4, fz, ID.bone_block, true);
      }
      put(cx, y + 5, fz, ID.bone_block, true);
    }
  }

  ruinedPortal(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const y = this.height(x, z) + 1;
    for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
      if (Math.abs(dx) + Math.abs(dz) <= 4) {
        foundation(x + dx, y - 1, z + dz, ID.netherrack);
      }
    }
    buildRuinedPortal(this, put, { kind: 'ruined_portal', x, y, z });
  }

  stronghold(put: PutFn, cx: number, cz: number) {
    const floorY = 30;
    const surfY = this.height(cx, cz);
    for (let y = floorY; y <= surfY + 2; y++) {
      for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
        const wall = Math.abs(dx) === 2 || Math.abs(dz) === 2;
        put(cx + dx, y, cz + dz - 7, wall ? (coordHash(dx + y, dz, 33) < 0.25 ? ID.mossy_stone_bricks : ID.stone_bricks) : 0, true);
      }
      if (y <= surfY) put(cx, y, cz - 6, ID.ladder, true);
    }
    for (let dy = 0; dy < 7; dy++) for (let dz = -5; dz <= 5; dz++) for (let dx = -5; dx <= 5; dx++) {
      const door = dz === -5 && Math.abs(dx) <= 1 && dy >= 1 && dy <= 3;
      const shell = !door && (Math.abs(dx) === 5 || Math.abs(dz) === 5 || dy === 0 || dy === 6);
      const brick = coordHash(dx + dy, dz, 71) < 0.25 ? ID.mossy_stone_bricks : ID.stone_bricks;
      put(cx + dx, floorY + dy, cz + dz, shell ? brick : 0, true);
    }
    for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
      put(cx + dx, floorY + 1, cz + dz, Math.abs(dx) <= 1 && Math.abs(dz) <= 1 ? ID.lava : ID.stone_bricks, true);
    }
    put(cx, floorY + 1, cz + 3, ID.stone_brick_stairs, true);
    const ring: [number, number, number, boolean][] = [
      [-1, -2, 0, true], [0, -2, 0, false], [1, -2, 0, false],
      [2, -1, 1, false], [2, 0, 1, true], [2, 1, 1, false],
      [1, 2, 2, false], [0, 2, 2, false], [-1, 2, 2, true],
      [-2, 1, 3, false], [-2, 0, 3, false], [-2, -1, 3, false],
    ];
    for (const [dx, dz, facing, eye] of ring) {
      put(cx + dx, floorY + 2, cz + dz, makeCell(ID.end_portal_frame, facing | (eye ? 4 : 0)), true);
    }
    put(cx - 4, floorY + 1, cz - 4, ID.chest, true);
    put(cx + 4, floorY + 2, cz + 4, ID.torch, true);
    put(cx - 4, floorY + 2, cz + 4, ID.torch, true);
    put(cx + 4, floorY + 2, cz - 4, ID.torch, true);
  }

  fortress(put: PutFn, x: number, z: number) {
    const y = 26;
    for (const [px, pz] of [[0, 0], [13, 0], [0, 13], [13, 13], [6, 6]]) {
      for (let yy = 8; yy < y; yy++) {
        for (let dz = 0; dz < 2; dz++) for (let dx = 0; dx < 2; dx++) put(x + px + dx, yy, z + pz + dz, ID.nether_bricks, true);
      }
    }
    for (let dz = 0; dz < 15; dz++) for (let dx = 0; dx < 15; dx++) {
      put(x + dx, y, z + dz, ID.nether_bricks, true);
      for (let dy = 1; dy <= 5; dy++) put(x + dx, y + dy, z + dz, 0, true);
      const wall = dx === 0 || dx === 14 || dz === 0 || dz === 14;
      if (wall) {
        put(x + dx, y + 1, z + dz, ID.nether_bricks, true);
        if ((dx + dz) % 2 === 0) put(x + dx, y + 2, z + dz, ID.nether_bricks, true);
      }
    }
    for (let dz = 5; dz <= 9; dz++) for (let dx = 5; dx <= 9; dx++) {
      put(x + dx, y + 1, z + dz, ID.nether_bricks, true);
    }
    put(x + 7, y + 2, z + 7, ID.glowstone, true);
    put(x + 2, y + 1, z + 2, ID.chest, true);
    put(x + 12, y + 1, z + 12, ID.chest, true);
    put(x + 2, y + 2, z + 12, ID.fire, true);
    put(x + 12, y + 2, z + 2, ID.fire, true);
  }

  endCity(put: PutFn, x: number, z: number, ox?: number, oz?: number, preventShip = false) {
    const y = Math.max(END_ISLAND_Y - 6, this.height(x + 5, z + 5) + 1);
    return buildEndCity(this, put, x, y, z, ox, oz, preventShip);
  }

  endCityAt(x: number, z: number, preventShip = false) {
    const y = Math.max(END_ISLAND_Y - 6, this.height(x + 5, z + 5) + 1);
    return endCityLayout(this.seed, x, y, z, 12, preventShip);
  }

  endShip(put: PutFn, x: number, z: number) {
    const y = 39;
    for (let dz = 0; dz < 15; dz++) {
      const hw = dz < 2 ? 1 : dz < 4 ? 2 : dz > 12 ? 2 : 3;
      for (let dx = -hw; dx <= hw; dx++) {
        put(x + dx, y, z + dz, ID.purpur_block, true);
        put(x + dx, y + 1, z + dz, Math.abs(dx) === hw ? ID.end_stone_bricks : ID.purpur_block, true);
        put(x + dx, y + 2, z + dz, Math.abs(dx) === hw || dz === 0 || dz === 14 ? ID.purpur_block : 0, true);
        if (Math.abs(dx) === hw || dz === 14) put(x + dx, y + 3, z + dz, ID.purpur_stairs, true);
      }
    }
    for (let dy = 2; dy <= 6; dy++) for (let dz = 10; dz <= 14; dz++) for (let dx = -3; dx <= 3; dx++) {
      const wall = Math.abs(dx) === 3 || dz === 10 || dz === 14 || dy === 6;
      put(x + dx, y + dy, z + dz, wall ? (dy === 4 && Math.abs(dx) <= 1 ? ID.magenta_stained_glass : ID.purpur_pillar) : 0, true);
    }
    put(x, y + 2, z + 10, 0, true); put(x, y + 3, z + 10, 0, true);
    for (let dy = 2; dy <= 10; dy++) put(x, y + dy, z + 6, ID.end_stone_bricks, true);
    put(x, y + 11, z + 6, ID.end_rod, true);
    put(x, y + 3, z - 1, ID.dragon_head, true);
    put(x, y + 2, z + 12, ID.chest, true);
    put(x - 1, y + 2, z + 12, ID.brewing_stand, true);
    put(x + 1, y + 2, z + 12, ID.end_rod, true);
  }
}

export function blockIndex(x: number, y: number, z: number) { return (y - MIN_Y) * 256 + z * 16 + x; }
export function blockName(id: number) { return BLOCKS[id]?.name ?? 'air'; }
