// Mineshaft piece generator (Minecraft Wiki "Mineshaft" / "Mineshaft/Structure", Java Edition MineshaftPieces).
// A mineshaft starts from a 10×10 Dirt Room (Room piece) with an arched ceiling and 1–4 exits on each of the four sides
// (north, east, south, west). From each exit, pieces grow recursively up to depth 8 with strict AABB collision checking:
//   • Corridor (3×3 cross-section, 1–4 sections of 5 blocks = length 5, 10, 15 or 20): wooden support arches every 5 blocks
//     (fence posts + plank lintel with occasional missing planks, torches on the beam, log pillars down or chains up when over
//     open space), cobwebs hanging next to solid walls/ceilings, incomplete rail tracks (70% per block), minecart-with-chest
//     containers (`abandoned_mineshaft` loot table), and optional cave-spider spawner sections wrapped in dense cobwebs.
//   • Crossing (5×5 footprint, 1-storey height 5 or 2-storey height 9): four-way intersection with 4 wooden plank columns at
//     the inner corners (x ∈ {1,3}, z ∈ {1,3}) and an upper plank bridge in two-storey crossings; branches on all 4 sides
//     (and upper level when two-storey).
//   • Stairs (3×7×9 diagonal tunnel): descends or ascends 5 blocks over 8 steps without stair blocks, continuing at the new Y.
// Biome variants: standard Overworld mineshafts use Oak (planks, fence, log); Badlands mineshafts (`mesa`) generate at higher
// elevations (up to Y=58..72) and use Dark Oak (dark_oak_planks, dark_oak_fence, dark_oak_log) with more complete rail lines.
import { chest } from './decor';
import { type Put, type StructHost, DX, DZ, bid, cell, hash2, hash3, mulberry, attachOn } from './common';

export type MineshaftVariant = 'normal' | 'mesa';
export type MineshaftPieceType = 'room' | 'corridor' | 'crossing' | 'stairs';
export type Box = [number, number, number, number, number, number];

export interface MineshaftPiece {
  type: MineshaftPieceType;
  /** Travel direction (0 N -z, 1 E +x, 2 S +z, 3 W -x). */
  d: number;
  /** Anchor in world coordinates: for room it is the centre; for corridor/crossing/stairs it is the entry centre on floor Y. */
  ax: number; ay: number; az: number;
  depth: number;
  /** Corridor: number of 5-block spans (1..4); Crossing: 1 or 2 storeys; Stairs: -1 (down) or +1 (up); Room: height (7). */
  sections: number;
  hasRails: boolean;
  hasSpiderSpawner: boolean;
  spawnerSection: number;
  twoStorey: boolean;
  box: Box;
}

export interface MineshaftLayout {
  cx: number; cy: number; cz: number;
  variant: MineshaftVariant;
  pieces: MineshaftPiece[];
  spawners: [number, number, number][];
  chests: [number, number, number][];
  bounds: Box;
}

export const MINESHAFT_RADIUS = 56;
const MAX_DEPTH = 8;
const MAX_PIECES = 48;

export const mineshaftVariantFor = (biome: string): MineshaftVariant =>
  /badlands|mesa/.test(biome) ? 'mesa' : 'normal';

const overlaps = (a: Box, b: Box) =>
  a[0] <= b[3] && a[3] >= b[0] && a[1] <= b[4] && a[4] >= b[1] && a[2] <= b[5] && a[5] >= b[2];

/** Local → world transform for a corridor/crossing/stairs piece whose entry floor-centre is (ax, ay, az) heading in direction `d`. */
function worldPos(p: { d: number; ax: number; ay: number; az: number }, lx: number, ly: number, lz: number, ex: number, ey = 0): [number, number, number] {
  const r = (p.d + 1) & 3;
  return [
    p.ax + DX[r] * (lx - ex) + DX[p.d] * lz,
    p.ay + ly - ey,
    p.az + DZ[r] * (lx - ex) + DZ[p.d] * lz,
  ];
}

function pieceBox(type: MineshaftPieceType, d: number, ax: number, ay: number, az: number, sections: number, twoStorey: boolean): Box {
  if (type === 'room') {
    // 10×7×10 dirt room centred on (ax, ay, az)
    return [ax - 5, ay - 1, az - 5, ax + 4, ay + 5, az + 4];
  }
  const w = type === 'crossing' ? 5 : 3;
  const ex = w >> 1;
  const h = type === 'crossing' ? (twoStorey ? 9 : 5) : type === 'stairs' ? 7 : 3;
  const l = type === 'corridor' ? sections * 5 : type === 'crossing' ? 5 : 9;
  const yOff = type === 'stairs' && sections < 0 ? 4 : 0;
  const a = worldPos({ d, ax, ay, az }, 0, 0, 0, ex, yOff);
  const b = worldPos({ d, ax, ay, az }, w - 1, h - 1, l - 1, ex, yOff);
  return [
    Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.min(a[2], b[2]),
    Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.max(a[2], b[2]),
  ];
}

const LAYOUTS = new Map<string, MineshaftLayout>();

/** Generates the recursive vanilla MineshaftPieces layout around (cx, cy, cz). Deterministic for a given seed and site. */
export function mineshaftLayout(seed: number, cx: number, cy: number, cz: number, variant: MineshaftVariant = 'normal'): MineshaftLayout {
  const key = `${seed}:${cx},${cy},${cz}:${variant}`;
  const cached = LAYOUTS.get(key);
  if (cached) return cached;

  const rnd = mulberry((Math.imul(seed | 0, 1597334677) ^ Math.imul(cx, 374761393) ^ Math.imul(cz, 668265263) ^ (cy * 1274126177)) >>> 0);
  const pieces: MineshaftPiece[] = [];
  const spawners: [number, number, number][] = [];
  const chests: [number, number, number][] = [];

  // 1. Starting point: 10×10 Dirt Room (parlor)
  const room: MineshaftPiece = {
    type: 'room', d: 0, ax: cx, ay: cy, az: cz, depth: 0,
    sections: 1, hasRails: false, hasSpiderSpawner: false, spawnerSection: -1, twoStorey: false,
    box: pieceBox('room', 0, cx, cy, cz, 1, false),
  };
  pieces.push(room);

  interface Exit { x: number; y: number; z: number; d: number; depth: number }
  const queue: Exit[] = [];

  // Room spawns 1–3 exits on each of the 4 cardinal sides (guaranteed at least 1 on each side so it always forms a branching network)
  for (let dir = 0; dir < 4; dir++) {
    const count = 1 + (rnd() < 0.55 ? 1 : 0);
    for (let i = 0; i < count; i++) {
      const offset = count === 1 ? 0 : (i === 0 ? -2 : 2);
      const dy = i === 1 && rnd() < 0.35 ? 1 : 0;
      const r = (dir + 1) & 3;
      // Room box is [cx-5..cx+4, cy-1..cy+5, cz-5..cz+4]. Outer face in direction dir:
      const faceX = dir === 1 ? cx + 5 : dir === 3 ? cx - 6 : cx + DX[r] * offset;
      const faceZ = dir === 2 ? cz + 5 : dir === 0 ? cz - 6 : cz + DZ[r] * offset;
      queue.push({ x: faceX, y: cy + dy, z: faceZ, d: dir, depth: 1 });
    }
  }

  let spawnerCount = 0;
  while (queue.length > 0 && pieces.length < MAX_PIECES) {
    const q = queue.shift()!;
    if (q.depth > MAX_DEPTH) continue;

    // Vanilla weights: Corridor ~70%, Crossing ~20%, Stairs ~10%
    const order: MineshaftPieceType[] = [];
    const rPick = rnd();
    if (rPick < 0.68) order.push('corridor', 'crossing', 'stairs');
    else if (rPick < 0.88) order.push('crossing', 'corridor', 'stairs');
    else order.push('stairs', 'corridor', 'crossing');

    for (const type of order) {
      let sections = 1;
      let twoStorey = false;
      if (type === 'corridor') {
        const rs = rnd();
        sections = rs < 0.25 ? 2 : rs < 0.7 ? 3 : 4;
      } else if (type === 'crossing') {
        twoStorey = rnd() < 0.3;
        sections = twoStorey ? 2 : 1;
      } else if (type === 'stairs') {
        sections = q.y > -18 && rnd() < 0.7 ? -1 : 1;
      }

      // If a long corridor collides, try shorter section counts (4 -> 3 -> 2 -> 1) like vanilla MineshaftPieces$Corridor.findCorridorSize
      const trySec = type === 'corridor' ? [sections, 3, 2, 1].filter((v, idx, a) => v <= sections && a.indexOf(v) === idx) : [sections];
      let placed: MineshaftPiece | null = null;
      for (const sec of trySec) {
        const box = pieceBox(type, q.d, q.x, q.y, q.z, sec, twoStorey);
        if (box[1] < -54 || box[4] > 90) continue;
        if (Math.max(Math.abs(box[0] - cx), Math.abs(box[3] - cx), Math.abs(box[2] - cz), Math.abs(box[5] - cz)) > MINESHAFT_RADIUS) continue;
        if (pieces.some(o => overlaps(box, o.box))) continue;

        const hasRails = type === 'corridor' && (variant === 'mesa' ? rnd() < 0.85 : rnd() < 0.65);
        const wantSpawner = type === 'corridor' && sec >= 2 && (spawnerCount === 0 || rnd() < 0.25) && spawnerCount < 3;
        const hasSpiderSpawner = wantSpawner;
        const spawnerSection = hasSpiderSpawner ? Math.floor(rnd() * sec) : -1;
        if (hasSpiderSpawner) spawnerCount++;

        placed = {
          type, d: q.d, ax: q.x, ay: q.y, az: q.z, depth: q.depth,
          sections: sec, hasRails, hasSpiderSpawner, spawnerSection, twoStorey, box,
        };
        break;
      }
      if (!placed) continue;

      pieces.push(placed);
      const d = placed.d, left = (d + 3) & 3, right = (d + 1) & 3;
      if (placed.type === 'corridor') {
        const len = placed.sections * 5;
        if (placed.hasSpiderSpawner) {
          const spZ = placed.spawnerSection * 5 + 2;
          spawners.push(worldPos(placed, 1, 0, spZ, 1));
        }
        // Chests (minecart with chest on rails) in corridors
        for (let s = 0; s < placed.sections; s++) {
          if (s === placed.spawnerSection) continue;
          if (rnd() < (chests.length === 0 ? 0.65 : 0.22)) {
            const czLocal = s * 5 + 1 + Math.floor(rnd() * 3);
            const cxLocal = placed.hasRails ? 1 : (rnd() < 0.5 ? 0 : 2);
            chests.push(worldPos(placed, cxLocal, 0, czLocal, 1));
          }
        }
        // Forward continuation at the end of the corridor
        if (rnd() < 0.85) {
          const [fx, fy, fz] = worldPos(placed, 1, 0, len, 1);
          queue.push({ x: fx, y: fy, z: fz, d, depth: q.depth + 1 });
        }
        // Lateral branches along the corridor sections
        for (let s = 0; s < placed.sections; s++) {
          const lz = s * 5 + 2;
          if (rnd() < 0.45) {
            const [lx, ly, lzW] = worldPos(placed, -1, 0, lz, 1);
            queue.push({ x: lx, y: ly, z: lzW, d: left, depth: q.depth + 1 });
          }
          if (rnd() < 0.45) {
            const [rx, ry, rzW] = worldPos(placed, 3, 0, lz, 1);
            queue.push({ x: rx, y: ry, z: rzW, d: right, depth: q.depth + 1 });
          }
        }
      } else if (placed.type === 'crossing') {
        // 5×5 crossing exits on forward (lz=5), left (lx=-1), right (lx=5), and optionally upper floor (ly=4)
        const [fx, fy, fz] = worldPos(placed, 2, 0, 5, 2);
        queue.push({ x: fx, y: fy, z: fz, d, depth: q.depth + 1 });
        if (rnd() < 0.75) {
          const [lx, ly, lzW] = worldPos(placed, -1, 0, 2, 2);
          queue.push({ x: lx, y: ly, z: lzW, d: left, depth: q.depth + 1 });
        }
        if (rnd() < 0.75) {
          const [rx, ry, rzW] = worldPos(placed, 5, 0, 2, 2);
          queue.push({ x: rx, y: ry, z: rzW, d: right, depth: q.depth + 1 });
        }
        if (placed.twoStorey) {
          if (rnd() < 0.65) {
            const [ux, uy, uz] = worldPos(placed, 2, 4, 5, 2);
            queue.push({ x: ux, y: uy, z: uz, d, depth: q.depth + 1 });
          }
          if (rnd() < 0.5) {
            const [ulx, uly, ulz] = worldPos(placed, -1, 4, 2, 2);
            queue.push({ x: ulx, y: uly, z: ulz, d: left, depth: q.depth + 1 });
          }
        }
      } else if (placed.type === 'stairs') {
        const endY = placed.sections < 0 ? -4 : 4;
        const [sx, sy, sz] = worldPos(placed, 1, endY, 9, 1);
        queue.push({ x: sx, y: sy, z: sz, d, depth: q.depth + 1 });
      }
      break;
    }
  }

  // Ensure every mineshaft has at least one cave-spider spawner and at least two loot chests
  const corridors = pieces.filter(p => p.type === 'corridor');
  if (spawners.length === 0 && corridors.length > 0) {
    const c0 = corridors[corridors.length - 1];
    c0.hasSpiderSpawner = true;
    c0.spawnerSection = 0;
    spawners.push(worldPos(c0, 1, 0, 2, 1));
  }
  if (chests.length < 2 && corridors.length > 0) {
    for (const c of corridors) {
      if (chests.length >= 2) break;
      const pos = worldPos(c, 0, 0, 1, 1);
      if (!chests.some(k => k[0] === pos[0] && k[1] === pos[1] && k[2] === pos[2])) chests.push(pos);
    }
  }

  const bounds: Box = [
    Math.min(...pieces.map(p => p.box[0])),
    Math.min(...pieces.map(p => p.box[1])),
    Math.min(...pieces.map(p => p.box[2])),
    Math.max(...pieces.map(p => p.box[3])),
    Math.max(...pieces.map(p => p.box[4])),
    Math.max(...pieces.map(p => p.box[5])),
  ];

  const layout: MineshaftLayout = { cx, cy, cz, variant, pieces, spawners, chests, bounds };
  if (LAYOUTS.size >= 64) LAYOUTS.delete(LAYOUTS.keys().next().value!);
  LAYOUTS.set(key, layout);
  return layout;
}

function buildMineshaftPiece(t: StructHost, put: Put, L: MineshaftLayout, p: MineshaftPiece) {
  const mesa = L.variant === 'mesa';
  const planks = bid(mesa ? 'dark_oak_planks' : 'oak_planks', 'oak_planks');
  const fence = bid(mesa ? 'dark_oak_fence' : 'oak_fence', 'oak_fence');
  const log = bid(mesa ? 'dark_oak_log' : 'oak_log', 'oak_log');
  const dirt = bid('dirt');
  const rail = bid('rail', 'air');
  const web = bid('cobweb', 'air');
  const chain = bid('chain', 'oak_fence');
  const spawner = bid('spawner', 'cobweb');
  const seed = t.seed + 7100;

  if (p.type === 'room') {
    // 10×10 Dirt Room (parlor): dirt floor, arched ceiling (tapered at top layer), air interior
    const [x0, y0, z0, x1, y1, z1] = p.box;
    for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
      put(x, y0, z, dirt, true);
      for (let y = y0 + 1; y <= y1; y++) {
        const rim = x === x0 || x === x1 || z === z0 || z === z1;
        if (y === y1 && rim) put(x, y, z, dirt, false);
        else put(x, y, z, 0, true);
      }
    }
    return;
  }

  const d = p.d, back = (d + 2) & 3;
  const ex = p.type === 'crossing' ? 2 : 1;
  const S = (lx: number, ly: number, lz: number, b: number, replace = true) => {
    const [x, y, z] = worldPos(p, lx, ly, lz, ex);
    put(x, y, z, b, replace);
  };

  if (p.type === 'corridor') {
    const len = p.sections * 5;
    // 1. Floor planks (bridging over caves when empty below, plus log pillars or hanging chains) and 3×3 air tunnel
    for (let lz = 0; lz < len; lz++) {
      for (let lx = 0; lx < 3; lx++) {
        const [wx, wy, wz] = worldPos(p, lx, 0, lz, 1);
        put(wx, wy - 1, wz, planks, false);
        for (let ly = 0; ly < 3; ly++) S(lx, ly, lz, 0, true);
      }
    }

    // 2. Wooden support arches every 5 blocks (at lz = s * 5 + 2), matching Mineshaft/Structure blueprint:
    //    Layer 1 & 2: fence posts on left (lx=0) and right (lx=2)
    //    Layer 3: plank beam across lx=0..2 (with rare missing plank), torches on front/back of beam
    for (let s = 0; s < p.sections; s++) {
      const az = s * 5 + 2;
      S(0, 0, az, fence, true); S(2, 0, az, fence, true);
      S(0, 1, az, fence, true); S(2, 1, az, fence, true);
      for (let lx = 0; lx < 3; lx++) {
        const [wx, wy, wz] = worldPos(p, lx, 2, az, 1);
        if (lx === 1 || hash3(wx, wy, wz, seed + 3) > 0.1) put(wx, wy, wz, planks, true);
      }
      // Support pillar (log) or hanging chains at support arch positions
      const [cxW, cyW, czW] = worldPos(p, 1, 0, az, 1);
      if (hash2(cxW, czW, seed + 19) < 0.25) {
        for (const lx of [0, 2]) {
          const [px, py, pz] = worldPos(p, lx, -2, az, 1);
          for (let dy = 0; dy < 4; dy++) put(px, py - dy, pz, log, false);
        }
      } else if (hash2(cxW, czW, seed + 23) < 0.25) {
        put(cxW, cyW + 3, czW, chain, false);
        put(cxW, cyW + 4, czW, chain, false);
      }
      // Torches attached to the plank lintel (facing -lz and +lz)
      if (az - 1 >= 0 && hash2(cxW, czW, seed + 7) < 0.75) S(1, 2, az - 1, cell('torch', attachOn(d)), true);
      if (az + 1 < len && hash2(cxW, czW, seed + 8) < 0.75) S(1, 2, az + 1, cell('torch', attachOn(back)), true);
    }

    // 3. Cobwebs along top edges and walls (always adjacent to walls/ceiling/beams, never floating), plus dense cobweb nest (39+ across mineshaft) around cave spider spawner
    for (let lz = 0; lz < len; lz++) {
      const inSpawnerSec = p.hasSpiderSpawner && Math.floor(lz / 5) === p.spawnerSection;
      for (let lx = 0; lx < 3; lx++) {
        for (let ly = 0; ly < 3; ly++) {
          if (lx === 1 && ly === 0 && lz === p.spawnerSection * 5 + 2 && p.hasSpiderSpawner) continue;
          if ((lx === 0 || lx === 2) && lz % 5 === 2) continue; // support posts
          if (ly === 2 && lz % 5 === 2) continue;               // support beam
          const [wx, wy, wz] = worldPos(p, lx, ly, lz, 1);
          const chance = inSpawnerSec ? (ly >= 1 || lx !== 1 ? 0.65 : 0.35) : (ly === 2 && lx !== 1 ? 0.16 : 0.03);
          if (hash3(wx, wy, wz, seed + 11) < chance) put(wx, wy, wz, web, true);
        }
      }
    }

    // 4. Incomplete rail line down the centre (lx = 1, ly = 0)
    if (p.hasRails) {
      const railChance = mesa ? 0.85 : 0.7;
      for (let lz = 0; lz < len; lz++) {
        const [wx, wy, wz] = worldPos(p, 1, 0, lz, 1);
        if (hash2(wx, wz, seed + 15) < railChance) put(wx, wy, wz, rail, true);
      }
    }

    // 5. Cave spider monster spawner in spawner section
    if (p.hasSpiderSpawner) {
      const spZ = p.spawnerSection * 5 + 2;
      S(1, 0, spZ, spawner, true);
    }
  } else if (p.type === 'crossing') {
    // 5×5 Intersection: 4 wooden plank columns at (lx ∈ {1,3}, lz ∈ {1,3}), 1 or 2 storeys high
    const H = p.twoStorey ? 9 : 5;
    for (let lz = 0; lz < 5; lz++) for (let lx = 0; lx < 5; lx++) {
      S(lx, -1, lz, planks, false);
      const pillar = (lx === 1 || lx === 3) && (lz === 1 || lz === 3);
      for (let ly = 0; ly < H - 1; ly++) {
        if (pillar) S(lx, ly, lz, planks, true);
        else if (p.twoStorey && ly === 3 && ((lx >= 1 && lx <= 3) || (lz >= 1 && lz <= 3))) S(lx, ly, lz, planks, true);
        else S(lx, ly, lz, 0, true);
      }
      if (lx >= 1 && lx <= 3 && lz >= 1 && lz <= 3) S(lx, H - 1, lz, planks, false);
    }
  } else if (p.type === 'stairs') {
    // Diagonal staircase tunnel (3 wide, 9 long, steps down or up 1 block per 2 Z steps)
    const dirY = p.sections < 0 ? -1 : 1;
    for (let lz = 0; lz < 9; lz++) {
      const stepY = dirY * Math.floor(lz / 2);
      for (let lx = 0; lx < 3; lx++) {
        S(lx, stepY - 1, lz, planks, false);
        for (let dy = 0; dy < 3; dy++) S(lx, stepY + dy, lz, 0, true);
      }
    }
  }
}

/** Writes the mineshaft around (cx, cy, cz); with (ox, oz) only pieces intersecting that chunk are built. */
export function buildMineshaft(t: StructHost, put: Put, cx: number, cy: number, cz: number, variant: MineshaftVariant = 'normal', ox?: number, oz?: number): MineshaftLayout {
  const L = mineshaftLayout(t.seed, cx, cy, cz, variant);
  for (const p of L.pieces) {
    if (ox !== undefined && oz !== undefined && (p.box[3] < ox - 1 || p.box[0] > ox + 17 || p.box[5] < oz - 1 || p.box[2] > oz + 17)) continue;
    buildMineshaftPiece(t, put, L, p);
  }
  for (const [x, y, z] of L.chests) {
    if (ox !== undefined && oz !== undefined && (x < ox - 1 || x > ox + 17 || z < oz - 1 || z > oz + 17)) continue;
    put(x, y - 1, z, bid(L.variant === 'mesa' ? 'dark_oak_planks' : 'oak_planks'), false);
    chest(put, t, x, y, z, (x + z) & 3, 'abandoned_mineshaft');
  }
  for (const [x, y, z] of L.spawners) {
    if (ox !== undefined && oz !== undefined && (x < ox - 1 || x > ox + 17 || z < oz - 1 || z > oz + 17)) continue;
    put(x, y, z, bid('spawner', 'cobweb'), true);
  }
  return L;
}
