// End City structure generator – Java Edition 1.21 EndCityPieces parity (Minecraft Wiki "End City#Structure details").
// Implements the vanilla recursive SectionGenerator algorithm (HOUSE_TOWER_GENERATOR, TOWER_GENERATOR,
// TOWER_BRIDGE_GENERATOR, FAT_TOWER_GENERATOR, MAX_GEN_DEPTH = 8) and all 18 official structure templates:
//   base_floor, base_roof, second_floor_1, second_floor_2, second_roof, third_floor_1, third_floor_2, third_roof,
//   tower_base, tower_floor, tower_piece, tower_top, fat_tower_base, fat_tower_middle, fat_tower_top,
//   bridge_end, bridge_piece, bridge_gentle_stairs, bridge_steep_stairs, and ship.
import { type Put, type StructHost, DX, DZ, bid, cell, mulberry, tag, stairsUp, ladderOn, attachOn } from './common';
import { endShip, END_SHIP } from './extra';

export type EndCityTemplate =
  | 'base_floor' | 'base_roof'
  | 'second_floor_1' | 'second_floor_2' | 'second_roof'
  | 'third_floor_1' | 'third_floor_2' | 'third_roof'
  | 'tower_base' | 'tower_floor' | 'tower_piece' | 'tower_top'
  | 'fat_tower_base' | 'fat_tower_middle' | 'fat_tower_top'
  | 'bridge_end' | 'bridge_piece' | 'bridge_gentle_stairs' | 'bridge_steep_stairs'
  | 'ship';

export const END_CITY_TEMPLATES: readonly EndCityTemplate[] = [
  'base_floor', 'base_roof',
  'second_floor_1', 'second_floor_2', 'second_roof',
  'third_floor_1', 'third_floor_2', 'third_roof',
  'tower_base', 'tower_floor', 'tower_piece', 'tower_top',
  'fat_tower_base', 'fat_tower_middle', 'fat_tower_top',
  'bridge_end', 'bridge_piece', 'bridge_gentle_stairs', 'bridge_steep_stairs',
  'ship',
] as const;

/** Unrotated dimensions [width (X), height (Y), length (Z)] of each vanilla template. */
export const TEMPLATE_SIZE: Record<EndCityTemplate, readonly [number, number, number]> = {
  base_floor: [9, 4, 9],
  base_roof: [11, 2, 11],
  second_floor_1: [11, 6, 11],
  second_floor_2: [11, 6, 11],
  second_roof: [13, 2, 13],
  third_floor_1: [13, 7, 13],
  third_floor_2: [13, 7, 13],
  third_roof: [15, 2, 15],
  tower_base: [7, 6, 7],
  tower_floor: [7, 4, 7],
  tower_piece: [7, 4, 7],
  tower_top: [9, 5, 9],
  fat_tower_base: [11, 4, 11],
  fat_tower_middle: [11, 8, 11],
  fat_tower_top: [15, 8, 15],
  bridge_end: [5, 6, 2],
  bridge_piece: [5, 5, 4],
  bridge_gentle_stairs: [5, 7, 8],
  bridge_steep_stairs: [5, 7, 4],
  ship: [13, 24, 29],
};

export type Box = [number, number, number, number, number, number];

export interface EndCityPiece {
  template: EndCityTemplate;
  /** Origin (local 0,0,0) in world coordinates. */
  x: number;
  y: number;
  z: number;
  /** Rotation: 0 = NONE (0°), 1 = CLOCKWISE_90 (90°), 2 = CLOCKWISE_180 (180°), 3 = COUNTERCLOCKWISE_90 (270°). */
  rot: number;
  overwrite: boolean;
  genDepth: number;
  box: Box;
}

export interface EndCityLayout {
  x: number;
  y: number;
  z: number;
  rot: number;
  pieces: EndCityPiece[];
  chests: [number, number, number][];
  enderChests: [number, number, number][];
  shulkers: [number, number, number][];
  ships: [number, number, number][];
  box: Box;
}

export const MAX_GEN_DEPTH = 8;

/** Rotate a local offset (lx, ly, lz) by `rot` quarter-turns clockwise around the Y axis (Java StructureTemplate.calculateRelativePosition). */
export function rotateOffset(rot: number, lx: number, ly: number, lz: number): [number, number, number] {
  switch (rot & 3) {
    case 0: return [lx, ly, lz];
    case 1: return [-lz, ly, lx];
    case 2: return [-lx, ly, -lz];
    default: return [lz, ly, -lx];
  }
}

export function pieceWorldPos(p: { x: number; y: number; z: number; rot: number }, lx: number, ly: number, lz: number): [number, number, number] {
  const [dx, dy, dz] = rotateOffset(p.rot, lx, ly, lz);
  return [p.x + dx, p.y + dy, p.z + dz];
}

export function computePieceBox(template: EndCityTemplate, x: number, y: number, z: number, rot: number): Box {
  const [w, h, l] = TEMPLATE_SIZE[template];
  const [dx, dy, dz] = rotateOffset(rot, w - 1, h - 1, l - 1);
  return [
    Math.min(x, x + dx),
    Math.min(y, y + dy),
    Math.min(z, z + dz),
    Math.max(x, x + dx),
    Math.max(y, y + dy),
    Math.max(z, z + dz),
  ];
}

const boxesIntersect = (a: Box, b: Box) =>
  a[0] <= b[3] && a[3] >= b[0] && a[1] <= b[4] && a[4] >= b[1] && a[2] <= b[5] && a[5] >= b[2];

/** Vanilla TOWER_BRIDGES: [rotDelta, offsetX, offsetY, offsetZ] on a 7×7 small tower. */
const TOWER_BRIDGES: readonly [number, number, number, number][] = [
  [0, 1, -1, 0],
  [1, 6, -1, 1],
  [3, 0, -1, 5],
  [2, 5, -1, 6],
];

/** Vanilla FAT_TOWER_BRIDGES: [rotDelta, offsetX, offsetY, offsetZ] on an 11×11 fat tower. */
const FAT_TOWER_BRIDGES: readonly [number, number, number, number][] = [
  [0, 4, -1, 0],
  [1, 12, -1, 4],
  [3, 0, -1, 8],
  [2, 8, -1, 12],
];

interface SectionGenerator {
  init(): void;
  generate(genDepth: number, parent: EndCityPiece, offset: [number, number, number] | null, pieces: EndCityPiece[], rnd: () => number): boolean;
}

function createPiece(parent: EndCityPiece | null, offset: [number, number, number], template: EndCityTemplate, rot: number, overwrite: boolean, genDepth = 0): EndCityPiece {
  let x = offset[0], y = offset[1], z = offset[2];
  if (parent) {
    const [dx, dy, dz] = rotateOffset(parent.rot, offset[0], offset[1], offset[2]);
    x = parent.x + dx;
    y = parent.y + dy;
    z = parent.z + dz;
  }
  return {
    template,
    x,
    y,
    z,
    rot: rot & 3,
    overwrite,
    genDepth,
    box: computePieceBox(template, x, y, z, rot & 3),
  };
}

/**
 * Generates an End City piece tree using the exact vanilla EndCityPieces.startHouseTower + recursiveChildren algorithm.
 */
export function generateEndCityPieces(seed: number, x0: number, y0: number, z0: number, initialRot?: number, preventShip = false): EndCityPiece[] {
  const rnd = mulberry((Math.imul(seed | 0, 10387313) ^ Math.imul(x0, 374761393) ^ Math.imul(z0, 668265263)) >>> 0);
  const nextInt = (bound: number) => Math.floor(rnd() * bound);
  const nextBoolean = () => rnd() < 0.5;
  const rot0 = initialRot !== undefined ? (initialRot & 3) : nextInt(4);

  let shipCreated = false;

  const addHelper = (pieces: EndCityPiece[], p: EndCityPiece) => {
    pieces.push(p);
    return p;
  };

  const addPiece = (parent: EndCityPiece, offset: [number, number, number], template: EndCityTemplate, rot: number, overwrite: boolean, genDepth = 0) =>
    createPiece(parent, offset, template, rot, overwrite, genDepth);

  const recursiveChildren = (
    generator: SectionGenerator,
    genDepth: number,
    parent: EndCityPiece,
    offset: [number, number, number] | null,
    pieces: EndCityPiece[],
  ): boolean => {
    if (genDepth > MAX_GEN_DEPTH) return false;
    const localPieces: EndCityPiece[] = [];
    if (!generator.generate(genDepth, parent, offset, localPieces, rnd)) return false;
    let collision = false;
    const childGenTag = nextInt(0x7fffffff);
    for (const piece of localPieces) {
      piece.genDepth = childGenTag;
      for (const existing of pieces) {
        if (boxesIntersect(existing.box, piece.box)) {
          if (existing.genDepth !== parent.genDepth) {
            collision = true;
          }
          break;
        }
      }
      if (collision) break;
    }
    if (!collision) {
      pieces.push(...localPieces);
      return true;
    }
    return false;
  };

  const HOUSE_TOWER_GENERATOR: SectionGenerator = {
    init() {},
    generate(genDepth, parent, offset, pieces) {
      if (genDepth > MAX_GEN_DEPTH) return false;
      const rot = parent.rot;
      let last = addHelper(pieces, addPiece(parent, offset ?? [0, 0, 0], 'base_floor', rot, true, genDepth));
      const r = nextInt(3);
      if (r === 0) {
        addHelper(pieces, addPiece(last, [-1, 4, -1], 'base_roof', rot, true, genDepth));
      } else if (r === 1) {
        last = addHelper(pieces, addPiece(last, [-1, 0, -1], 'second_floor_2', rot, false, genDepth));
        last = addHelper(pieces, addPiece(last, [-1, 8, -1], 'second_roof', rot, false, genDepth));
        recursiveChildren(TOWER_GENERATOR, genDepth + 1, last, null, pieces);
      } else if (r === 2) {
        last = addHelper(pieces, addPiece(last, [-1, 0, -1], 'second_floor_2', rot, false, genDepth));
        last = addHelper(pieces, addPiece(last, [-1, 4, -1], 'third_floor_2', rot, false, genDepth));
        last = addHelper(pieces, addPiece(last, [-1, 8, -1], 'third_roof', rot, true, genDepth));
        recursiveChildren(TOWER_GENERATOR, genDepth + 1, last, null, pieces);
      }
      return true;
    },
  };

  const TOWER_GENERATOR: SectionGenerator = {
    init() {},
    generate(genDepth, parent, _offset, pieces) {
      const rot = parent.rot;
      const tx = 3 + nextInt(2), tz = 3 + nextInt(2);
      let last = addHelper(pieces, addPiece(parent, [tx, -3, tz], 'tower_base', rot, true, genDepth));
      last = addHelper(pieces, addPiece(last, [0, 7, 0], 'tower_piece', rot, true, genDepth));
      let floorPiece: EndCityPiece | null = nextInt(3) === 0 ? last : null;
      const height = 1 + nextInt(3);
      for (let i = 0; i < height; i++) {
        const useFloor = i < height - 1 && nextBoolean();
        last = addHelper(pieces, addPiece(last, [0, 4, 0], useFloor && nextInt(4) === 0 ? 'tower_floor' : 'tower_piece', rot, true, genDepth));
        if (useFloor) {
          floorPiece = last;
        }
      }
      if (floorPiece !== null) {
        for (const [bRot, bx, by, bz] of TOWER_BRIDGES) {
          if (nextBoolean()) {
            const bridgeStart = addHelper(pieces, addPiece(floorPiece, [bx, by, bz], 'bridge_end', (rot + bRot) & 3, true, genDepth));
            recursiveChildren(TOWER_BRIDGE_GENERATOR, genDepth + 1, bridgeStart, null, pieces);
          }
        }
        addHelper(pieces, addPiece(last, [-1, 4, -1], 'tower_top', rot, true, genDepth));
      } else {
        if (genDepth !== 7) {
          return recursiveChildren(FAT_TOWER_GENERATOR, genDepth + 1, last, null, pieces);
        }
        addHelper(pieces, addPiece(last, [-1, 4, -1], 'tower_top', rot, true, genDepth));
      }
      return true;
    },
  };

  const TOWER_BRIDGE_GENERATOR: SectionGenerator = {
    init() { shipCreated = preventShip; },
    generate(genDepth, parent, _offset, pieces) {
      const rot = parent.rot;
      const len = nextInt(4) + 1;
      let last = addHelper(pieces, addPiece(parent, [0, 0, -4], 'bridge_piece', rot, true, genDepth));
      last.genDepth = -1;
      let yOff = 0;
      for (let i = 0; i < len; i++) {
        if (nextBoolean()) {
          last = addHelper(pieces, addPiece(last, [0, yOff, -4], 'bridge_piece', rot, true, genDepth));
          yOff = 0;
        } else {
          if (nextBoolean()) {
            last = addHelper(pieces, addPiece(last, [0, yOff, -4], 'bridge_steep_stairs', rot, true, genDepth));
          } else {
            last = addHelper(pieces, addPiece(last, [0, yOff, -8], 'bridge_gentle_stairs', rot, true, genDepth));
          }
          yOff = 4;
        }
      }
      if (!shipCreated && nextInt(10 - genDepth) === 0) {
        const sx = -8 + nextInt(8), sz = -70 + nextInt(10);
        addHelper(pieces, addPiece(last, [sx, yOff, sz], 'ship', rot, true, genDepth));
        shipCreated = true;
      } else if (!recursiveChildren(HOUSE_TOWER_GENERATOR, genDepth + 1, last, [-3, yOff + 1, -11], pieces)) {
        return false;
      }
      last = addHelper(pieces, addPiece(last, [4, yOff, 0], 'bridge_end', (rot + 2) & 3, true, genDepth));
      last.genDepth = -1;
      return true;
    },
  };

  const FAT_TOWER_GENERATOR: SectionGenerator = {
    init() {},
    generate(genDepth, parent, _offset, pieces) {
      const rot = parent.rot;
      let last = addHelper(pieces, addPiece(parent, [-3, 4, -3], 'fat_tower_base', rot, true, genDepth));
      last = addHelper(pieces, addPiece(last, [0, 4, 0], 'fat_tower_middle', rot, true, genDepth));
      for (let j = 0; j < 2 && nextInt(3) !== 0; j++) {
        last = addHelper(pieces, addPiece(last, [0, 8, 0], 'fat_tower_middle', rot, true, genDepth));
        for (const [bRot, bx, by, bz] of FAT_TOWER_BRIDGES) {
          if (nextBoolean()) {
            const bridgeStart = addHelper(pieces, addPiece(last, [bx, by, bz], 'bridge_end', (rot + bRot) & 3, true, genDepth));
            recursiveChildren(TOWER_BRIDGE_GENERATOR, genDepth + 1, bridgeStart, null, pieces);
          }
        }
      }
      addHelper(pieces, addPiece(last, [-2, 8, -2], 'fat_tower_top', rot, true, genDepth));
      return true;
    },
  };

  TOWER_BRIDGE_GENERATOR.init();
  const pieces: EndCityPiece[] = [];
  let last = addHelper(pieces, createPiece(null, [x0, y0, z0], 'base_floor', rot0, true, 0));
  last = addHelper(pieces, addPiece(last, [-1, 0, -1], 'second_floor_1', rot0, false, 0));
  last = addHelper(pieces, addPiece(last, [-1, 4, -1], 'third_floor_1', rot0, false, 0));
  last = addHelper(pieces, addPiece(last, [-1, 8, -1], 'third_roof', rot0, true, 0));
  recursiveChildren(TOWER_GENERATOR, 1, last, null, pieces);
  return pieces;
}

const CITY_CACHE = new Map<string, EndCityLayout>();

/**
 * Deterministic End City layout at (x, y, z). Retries if the root tower produced no branches so outer-island cities are rich.
 */
export function endCityLayout(seed: number, x: number, y: number, z: number, minPieces = 12, preventShip = false): EndCityLayout {
  const key = `${seed}:${x},${y},${z}:${minPieces}:${preventShip ? 1 : 0}`;
  const hit = CITY_CACHE.get(key);
  if (hit) return hit;

  let bestPieces: EndCityPiece[] = [];
  for (let attempt = 0; attempt < 16; attempt++) {
    const pieces = generateEndCityPieces(seed + attempt * 997, x, y, z, undefined, preventShip);
    if (pieces.length > bestPieces.length) bestPieces = pieces;
    if (pieces.length >= minPieces && pieces.some(p => p.template === 'third_floor_2' || p.template === 'fat_tower_top')) break;
  }

  const chests: [number, number, number][] = [];
  const enderChests: [number, number, number][] = [];
  const shulkers: [number, number, number][] = [];
  const ships: [number, number, number][] = [];
  const box: Box = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];

  for (const p of bestPieces) {
    box[0] = Math.min(box[0], p.box[0]);
    box[1] = Math.min(box[1], p.box[1]);
    box[2] = Math.min(box[2], p.box[2]);
    box[3] = Math.max(box[3], p.box[3]);
    box[4] = Math.max(box[4], p.box[4]);
    box[5] = Math.max(box[5], p.box[5]);

    const W = (lx: number, ly: number, lz: number) => pieceWorldPos(p, lx, ly, lz);
    switch (p.template) {
      case 'base_floor':
        shulkers.push(W(2, 1, 1), W(6, 1, 1));
        break;
      case 'second_floor_2':
        shulkers.push(W(5, 2, 5));
        break;
      case 'third_floor_1':
        break;
      case 'third_floor_2':
        chests.push(W(5, 1, 10));
        enderChests.push(W(7, 1, 10));
        shulkers.push(W(4, 1, 10), W(8, 1, 10));
        break;
      case 'fat_tower_middle':
        shulkers.push(W(5, 2, 2), W(8, 4, 5), W(5, 6, 8), W(2, 8, 5));
        break;
      case 'fat_tower_top':
        chests.push(W(3, 1, 12), W(11, 1, 12));
        break;
      case 'tower_top':
        shulkers.push(W(4, 3, 4));
        break;
      case 'ship': {
        const [sx, sy, sz] = W(6, 4, 2);
        ships.push([sx, sy, sz]);
        shulkers.push([sx, sy + 5, sz + 11], [sx, sy + 5, sz + 23], [sx, sy + 2, sz + 15]);
        for (const [cx, cy, cz] of END_SHIP.chests) chests.push([sx + cx, sy + cy, sz + cz]);
        break;
      }
    }
  }

  const layout: EndCityLayout = { x, y, z, rot: bestPieces[0]?.rot ?? 0, pieces: bestPieces, chests, enderChests, shulkers, ships, box };
  if (CITY_CACHE.size >= 64) CITY_CACHE.delete(CITY_CACHE.keys().next().value!);
  CITY_CACHE.set(key, layout);
  return layout;
}

/**
 * Renders a single EndCityPiece into `put`. Respects `p.overwrite` (vanilla BLOCK_IGNORE vs STRUCTURE_AND_AIR).
 */
export function buildEndCityPiece(t: StructHost, put: Put, p: EndCityPiece, ox?: number, oz?: number) {
  if (ox !== undefined && oz !== undefined) {
    if (p.box[3] < ox - 1 || p.box[0] > ox + 17 || p.box[5] < oz - 1 || p.box[2] > oz + 17) return;
  }

  const purpur = bid('purpur_block', 'end_stone');
  const pillar = bid('purpur_pillar', 'purpur_block');
  const bricks = bid('end_stone_bricks', 'end_stone');
  const slab = bid('purpur_slab', 'purpur_block');
  const glass = bid('magenta_stained_glass', 'glass');
  const rod = bid('end_rod', 'torch');
  const echest = bid('ender_chest', 'obsidian');
  const banner = bid('magenta_banner', 'magenta_wool');

  const rotDir = (localDir: number) => (localDir + p.rot) & 3;
  const stairs = (localDir: number, upsideDown = false) => cell('purpur_stairs', stairsUp(rotDir(localDir), upsideDown), 'purpur_block');
  const ladder = (localDir: number) => cell('ladder', ladderOn(rotDir(localDir)));
  const chestAt = (lx: number, ly: number, lz: number, localFacing: number) => {
    const [wx, wy, wz] = pieceWorldPos(p, lx, ly, lz);
    put(wx, wy, wz, cell('chest', (rotDir(localFacing) + 2) & 3), true);
    tag(t, wx, wy, wz, 'end_city_treasure');
  };

  const P = (lx: number, ly: number, lz: number, b: number, forceOverwrite?: boolean) => {
    const [wx, wy, wz] = pieceWorldPos(p, lx, ly, lz);
    const rep = forceOverwrite !== undefined ? forceOverwrite : (b === 0 ? p.overwrite : true);
    put(wx, wy, wz, b, rep);
  };

  const [W, H, L] = TEMPLATE_SIZE[p.template];

  // Helper to build a pagoda room box (end_stone_bricks walls, purpur_pillar corners, purpur_block rims, magenta_stained_glass windows).
  const buildRoomShell = (floorFill: boolean, windowY: number) => {
    for (let ly = 0; ly < H; ly++) {
      for (let lz = 0; lz < L; lz++) {
        for (let lx = 0; lx < W; lx++) {
          const edgeX = lx === 0 || lx === W - 1;
          const edgeZ = lz === 0 || lz === L - 1;
          const edge = edgeX || edgeZ;
          const corner = edgeX && edgeZ;
          const midX = lx === (W >> 1) || Math.abs(lx - (W >> 1)) === 1;
          const midZ = lz === (L >> 1) || Math.abs(lz - (L >> 1)) === 1;
          if (ly === 0) {
            if (edge) P(lx, ly, lz, corner ? pillar : purpur, true);
            else if (floorFill) P(lx, ly, lz, purpur, true);
            else if (p.overwrite) P(lx, ly, lz, 0, true);
          } else if (ly === H - 1) {
            if (edge) P(lx, ly, lz, corner ? pillar : purpur, true);
          } else if (edge) {
            if (corner) P(lx, ly, lz, pillar, true);
            else if ((ly === windowY || ly === windowY + 1) && ((edgeZ && midX) || (edgeX && midZ))) P(lx, ly, lz, glass, true);
            else P(lx, ly, lz, bricks, true);
          } else {
            P(lx, ly, lz, 0);
          }
        }
      }
    }
    // Exterior stepped eaves on upper room tiers (when W >= 11, overhang above the tier below)
    if (W >= 11) {
      for (let i = 1; i < W - 1; i++) {
        P(i, 0, 0, stairs(2, true), true);
        P(i, 0, L - 1, stairs(0, true), true);
        P(0, 0, i, stairs(1, true), true);
        P(W - 1, 0, i, stairs(3, true), true);
      }
    }
  };

  // Helper for pagoda roof pieces (base_roof: 100 purpur + 44 stairs + 4 rods; second_roof: 144 purpur + 52 stairs + 4 rods; third_roof: 196 purpur + 60 stairs + 4 rods).
  const buildRoof = () => {
    for (let lz = 0; lz < L; lz++) {
      for (let lx = 0; lx < W; lx++) {
        const edgeX = lx === 0 || lx === W - 1;
        const edgeZ = lz === 0 || lz === L - 1;
        const edge = edgeX || edgeZ;
        if (edge) {
          const dir = lz === 0 ? 2 : lz === L - 1 ? 0 : lx === 0 ? 1 : 3;
          P(lx, 0, lz, stairs(dir), true);
        } else {
          P(lx, 0, lz, purpur, true);
          const innerEdge = lx === 1 || lx === W - 2 || lz === 1 || lz === L - 2;
          if (!innerEdge) P(lx, 1, lz, purpur, true);
        }
      }
    }
    // 4 corner end rods on the roof
    for (const [rx, rz] of [[0, 0], [W - 1, 0], [0, L - 1], [W - 1, L - 1]]) {
      P(rx, 1, rz, rod, true);
    }
  };

  switch (p.template) {
    case 'base_floor': {
      buildRoomShell(true, 2);
      // Entrance arch on local north face (lz = 0, lx = 3..5)
      for (let lx = 3; lx <= 5; lx++) {
        for (let ly = 1; ly <= 3; ly++) P(lx, ly, 0, 0, true);
      }
      P(3, 3, 0, stairs(1, true), true);
      P(5, 3, 0, stairs(3, true), true);
      // Exterior entrance steps
      P(2, 1, 1, rod, true);
      P(6, 1, 1, rod, true);
      break;
    }

    case 'base_roof':
    case 'second_roof':
    case 'third_roof': {
      buildRoof();
      break;
    }

    case 'second_floor_1': {
      // Preceded by a purpur slab staircase from base_floor; otherwise empty.
      buildRoomShell(false, 2);
      // Perimeter walkway on floor level so player can walk around the open well
      for (let lz = 1; lz < L - 1; lz++) {
        for (let lx = 1; lx < W - 1; lx++) {
          if (lx <= 2 || lx >= W - 3 || lz <= 2 || lz >= L - 3) P(lx, 0, lz, purpur, true);
        }
      }
      // 7-slab purpur_slab staircase rising from base_floor into second_floor_1
      for (let s = 0; s < 7; s++) {
        P(2 + (s >> 1), -3 + (s >> 1), 4 + (s & 1), slab, true);
      }
      for (const [rx, rz] of [[2, 2], [W - 3, 2], [2, L - 3], [W - 3, L - 3]]) {
        P(rx, 1, rz, rod, true);
      }
      break;
    }

    case 'second_floor_2': {
      // Central pillar with spiral staircase and a corner stair "statue" / lectern-like alcove.
      buildRoomShell(false, 2);
      for (let lz = 1; lz < L - 1; lz++) {
        for (let lx = 1; lx < W - 1; lx++) {
          if (lx <= 2 || lx >= W - 3 || lz <= 2 || lz >= L - 3) P(lx, 0, lz, purpur, true);
        }
      }
      // Central pillar (5, y, 5) + spiral slab steps rising from base_floor
      for (let dy = -3; dy <= 4; dy++) P(5, dy, 5, pillar, true);
      const spiral: [number, number, number][] = [
        [5, -3, 4], [6, -3, 4], [6, -2, 4], [6, -2, 5], [6, -1, 6], [5, -1, 6], [4, -1, 6], [4, 0, 6], [4, 0, 5],
      ];
      for (const [sx, sy, sz] of spiral) P(sx, sy, sz, slab, true);
      // Corner statue made of purpur stairs in upper corner
      P(8, 1, 8, pillar, true);
      P(8, 2, 8, stairs(0), true);
      P(7, 1, 8, stairs(1), true);
      P(8, 1, 7, stairs(2), true);
      for (const [rx, rz] of [[2, 2], [W - 3, 2], [2, L - 3], [W - 3, L - 3]]) {
        P(rx, 1, rz, rod, true);
      }
      break;
    }

    case 'third_floor_1': {
      // Central purpur pillar structure surrounded by purpur stairs and checkerboard-style flooring.
      buildRoomShell(false, 2);
      for (let lz = 1; lz < L - 1; lz++) {
        for (let lx = 1; lx < W - 1; lx++) {
          const nearWall = lx <= 3 || lx >= W - 4 || lz <= 3 || lz >= L - 4;
          const checker = ((lx + lz) & 1) === 0 && lx >= 2 && lx <= W - 3 && lz >= 2 && lz <= L - 3;
          if (nearWall || checker) P(lx, 0, lz, purpur, true);
        }
      }
      // Central pillar structure + surrounding purpur stairs
      for (let dy = 0; dy <= 5; dy++) P(6, dy, 6, pillar, true);
      P(6, 1, 5, stairs(2), true);
      P(6, 1, 7, stairs(0), true);
      P(5, 1, 6, stairs(1), true);
      P(7, 1, 6, stairs(3), true);
      // Two sets of ladders / slab steps connecting from second_floor_1
      for (let s = 0; s < 4; s++) {
        P(4 + s, -3 + s, 6, slab, true);
      }
      for (const [rx, rz] of [[2, 2], [W - 3, 2], [2, L - 3], [W - 3, L - 3]]) {
        P(rx, 1, rz, rod, true);
      }
      break;
    }

    case 'third_floor_2': {
      // The second loot room, with a regular chest (end_city_treasure) and an ender chest side by side.
      buildRoomShell(true, 2);
      // Opening in the centre for the staircase from second_floor_2
      for (let lz = 5; lz <= 7; lz++) for (let lx = 5; lx <= 7; lx++) P(lx, 0, lz, 0, true);
      for (let dy = -3; dy <= 1; dy++) P(6, dy, 6, pillar, true);
      for (let s = 0; s < 4; s++) P(4 + s, -3 + s, 5, slab, true);
      // Loot chest + Ender chest at the back wall (lz = 10)
      chestAt(5, 1, 10, 0);
      P(7, 1, 10, echest, true);
      for (const [rx, rz] of [[2, 2], [W - 3, 2], [2, L - 3], [W - 3, L - 3], [5, 2], [7, 2]]) {
        P(rx, 1, rz, rod, true);
      }
      break;
    }

    case 'tower_base': {
      // 7×7×6 entrance to the small tower with a 3-rung ladder preceding it.
      for (let ly = 0; ly < H; ly++) {
        for (let lz = 0; lz < L; lz++) {
          for (let lx = 0; lx < W; lx++) {
            const edge = lx === 0 || lx === W - 1 || lz === 0 || lz === L - 1;
            const corner = (lx === 0 || lx === W - 1) && (lz === 0 || lz === L - 1);
            if (ly === 0) {
              if (lx === 3 && lz === 3) P(lx, ly, lz, 0, true); // ladder hatch
              else P(lx, ly, lz, corner ? pillar : purpur, true);
            } else if (edge) {
              P(lx, ly, lz, corner || (lx + lz) % 2 === 0 ? pillar : purpur, true);
            } else {
              P(lx, ly, lz, 0, true);
            }
          }
        }
      }
      // Pillar support & 3 ladder rungs leading up through the hatch at (3, 0, 3)
      for (let dy = -2; dy <= 0; dy++) {
        P(3, dy, 2, pillar, true);
        P(3, dy, 3, ladder(0), true);
      }
      P(3, 1, 2, slab, true);
      P(4, 2, 2, slab, true);
      P(4, 3, 3, slab, true);
      P(4, 4, 4, slab, true);
      break;
    }

    case 'tower_floor': {
      // 7×7×4 similar to tower_base, but the ladder entrance is replaced with a solid floor.
      for (let ly = 0; ly < H; ly++) {
        for (let lz = 0; lz < L; lz++) {
          for (let lx = 0; lx < W; lx++) {
            const edge = lx === 0 || lx === W - 1 || lz === 0 || lz === L - 1;
            const corner = (lx === 0 || lx === W - 1) && (lz === 0 || lz === L - 1);
            if (ly === 0) P(lx, ly, lz, corner ? pillar : purpur, true);
            else if (edge) P(lx, ly, lz, corner ? pillar : purpur, true);
            else P(lx, ly, lz, 0, true);
          }
        }
      }
      break;
    }

    case 'tower_piece': {
      // 7×7×4 middle of the small tower, with a 4-step purpur slab spiral staircase around the interior walls.
      for (let ly = 0; ly < H; ly++) {
        for (let lz = 0; lz < L; lz++) {
          for (let lx = 0; lx < W; lx++) {
            const edge = lx === 0 || lx === W - 1 || lz === 0 || lz === L - 1;
            const corner = (lx === 0 || lx === W - 1) && (lz === 0 || lz === L - 1);
            if (edge) P(lx, ly, lz, corner || ly % 2 === 0 ? pillar : purpur, true);
            else P(lx, ly, lz, 0, true);
          }
        }
      }
      // Spiral purpur slabs climbing 4 blocks per piece
      P(3, 0, 1, slab, true);
      P(5, 1, 3, slab, true);
      P(3, 2, 5, slab, true);
      P(1, 3, 3, slab, true);
      P(2, 0, 1, stairs(1), true);
      P(5, 1, 2, stairs(2), true);
      P(4, 2, 5, stairs(3), true);
      P(1, 3, 4, stairs(0), true);
      break;
    }

    case 'tower_top': {
      // 9×9×5 roof of the small tower, with 8 magenta banners hanging from the sides and 4 end rods.
      for (let ly = 0; ly < H; ly++) {
        for (let lz = 0; lz < L; lz++) {
          for (let lx = 0; lx < W; lx++) {
            const edgeX = lx === 0 || lx === W - 1;
            const edgeZ = lz === 0 || lz === L - 1;
            const edge = edgeX || edgeZ;
            const corner = edgeX && edgeZ;
            if (ly === 0) {
              const hole = lx >= 2 && lx <= 6 && lz >= 2 && lz <= 6 && !(lx === 4 && lz === 4);
              P(lx, ly, lz, hole ? 0 : corner ? pillar : purpur, true);
            } else if (ly <= 3) {
              if (edge) {
                if (corner) P(lx, ly, lz, pillar, true);
                else if (ly === 2 && (lx === 4 || lz === 4)) P(lx, ly, lz, glass, true);
                else P(lx, ly, lz, bricks, true);
              } else {
                P(lx, ly, lz, 0, true);
              }
            } else {
              // Roof cap (ly === 4)
              if (edge) {
                const dir = lz === 0 ? 2 : lz === L - 1 ? 0 : lx === 0 ? 1 : 3;
                P(lx, ly, lz, stairs(dir), true);
              } else {
                P(lx, ly, lz, purpur, true);
              }
            }
          }
        }
      }
      // 4 end rods at corners of roof + 8 magenta banners on the exterior walls
      for (const [rx, rz] of [[0, 0], [W - 1, 0], [0, L - 1], [W - 1, L - 1]]) {
        P(rx, 4, rz, rod, true);
      }
      for (const i of [2, 6]) {
        P(i, 2, 0, banner, true);
        P(i, 2, L - 1, banner, true);
        P(0, 2, i, banner, true);
        P(W - 1, 2, i, banner, true);
      }
      break;
    }

    case 'fat_tower_base': {
      // 11×11×4 entrance to the large skyscraper tower.
      for (let ly = 0; ly < H; ly++) {
        for (let lz = 0; lz < L; lz++) {
          for (let lx = 0; lx < W; lx++) {
            const edge = lx === 0 || lx === W - 1 || lz === 0 || lz === L - 1;
            const corner = (lx === 0 || lx === W - 1) && (lz === 0 || lz === L - 1);
            if (ly === 0) {
              const centerOpen = lx >= 3 && lx <= 7 && lz >= 3 && lz <= 7;
              P(lx, ly, lz, centerOpen ? 0 : corner ? pillar : purpur, true);
            } else if (edge) {
              P(lx, ly, lz, corner || (lx + lz) % 2 === 0 ? pillar : purpur, true);
            } else {
              P(lx, ly, lz, 0, true);
            }
          }
        }
      }
      for (const [rx, rz] of [[2, 2], [8, 2], [2, 8], [8, 8]]) P(rx, 1, rz, rod, true);
      P(5, 0, 2, slab, true);
      P(5, 1, 1, slab, true);
      P(5, 2, 1, slab, true);
      break;
    }

    case 'fat_tower_middle': {
      // 11×11×8 center of the large tower, lined with the purpur slab and end rod double spiral staircase.
      for (let ly = 0; ly < H; ly++) {
        for (let lz = 0; lz < L; lz++) {
          for (let lx = 0; lx < W; lx++) {
            const edge = lx === 0 || lx === W - 1 || lz === 0 || lz === L - 1;
            const corner = (lx === 0 || lx === W - 1) && (lz === 0 || lz === L - 1);
            if (edge) P(lx, ly, lz, corner || (lx + lz) % 2 === 0 ? pillar : purpur, true);
            else P(lx, ly, lz, 0, true);
          }
        }
      }
      // Spiral staircase along the walls: 8 end rods, 8 purpur slabs, and 8 purpur stairs
      const steps: [number, number, number, "slab" | "rod" | "stair"][] = [
        [2, 0, 1, "stair"], [3, 0, 1, "slab"], [5, 1, 1, "rod"],
        [7, 2, 1, "stair"], [8, 2, 1, "slab"], [9, 3, 3, "rod"],
        [9, 4, 5, "stair"], [9, 4, 6, "slab"], [9, 5, 7, "rod"],
        [7, 6, 9, "stair"], [6, 6, 9, "slab"], [5, 7, 9, "rod"],
        [8, 0, 9, "stair"], [7, 0, 9, "slab"], [5, 1, 9, "rod"],
        [3, 2, 9, "stair"], [2, 2, 9, "slab"], [1, 3, 7, "rod"],
        [1, 4, 5, "stair"], [1, 4, 4, "slab"], [1, 5, 3, "rod"],
        [3, 6, 1, "stair"], [4, 6, 1, "slab"], [5, 7, 1, "rod"],
      ];
      for (const [sx, sy, sz, kind] of steps) {
        P(sx, sy, sz, kind === "rod" ? rod : kind === "slab" ? slab : stairs(0), true);
      }
      break;
    }

    case 'fat_tower_top': {
      // 15×8×15 loot room of the large tower, generated with 2 chests in the corner and a staircase to the roof.
      buildRoomShell(false, 3);
      for (let lz = 1; lz < L - 1; lz++) {
        for (let lx = 1; lx < W - 1; lx++) {
          const hole = lx >= 5 && lx <= 9 && lz >= 5 && lz <= 9;
          if (!hole) P(lx, 0, lz, purpur, true);
        }
      }
      // Roof over fat_tower_top
      for (let lz = 0; lz < L; lz++) {
        for (let lx = 0; lx < W; lx++) {
          const edge = lx === 0 || lx === W - 1 || lz === 0 || lz === L - 1;
          if (edge) {
            const dir = lz === 0 ? 2 : lz === L - 1 ? 0 : lx === 0 ? 1 : 3;
            P(lx, H - 1, lz, stairs(dir), true);
          } else {
            P(lx, H - 1, lz, purpur, true);
          }
        }
      }
      // Two chests in the corners (end_city_treasure)
      chestAt(3, 1, 12, 0);
      chestAt(11, 1, 12, 0);
      // Staircase to the roof
      for (let s = 0; s < 5; s++) {
        P(7, 1 + s, 12 - s, stairs(0), true);
        P(7, H - 1, 12 - s, 0, true);
      }
      for (const [rx, rz] of [[2, 2], [W - 3, 2], [2, L - 3], [W - 3, L - 3]]) {
        P(rx, 1, rz, rod, true);
      }
      break;
    }

    case 'bridge_end': {
      // 5×6×2 arch that forms the start and end of bridges (pointing toward -Z in local frame).
      for (let lz = 0; lz < L; lz++) {
        for (let lx = 0; lx < W; lx++) {
          P(lx, 0, lz, purpur, true);
          for (let ly = 1; ly < H; ly++) {
            const side = lx === 0 || lx === W - 1;
            if (side && ly <= 4) P(lx, ly, lz, ly === 4 ? stairs(lx === 0 ? 1 : 3) : pillar, true);
            else if (ly === 5 && lx >= 1 && lx <= 3) P(lx, ly, lz, slab, true);
            else P(lx, ly, lz, 0, true);
          }
        }
      }
      P(0, 2, 0, rod, true);
      P(W - 1, 2, 0, rod, true);
      break;
    }

    case 'bridge_piece': {
      // 5×5×4 straight piece of bridge.
      for (let lz = 0; lz < L; lz++) {
        for (let lx = 0; lx < W; lx++) {
          const side = lx === 0 || lx === W - 1;
          P(lx, 0, lz, purpur, true);
          P(lx, 1, lz, side ? (lz % 2 === 0 ? pillar : stairs(lx === 0 ? 3 : 1)) : 0, true);
          for (let ly = 2; ly < H; ly++) P(lx, ly, lz, 0, true);
        }
      }
      break;
    }

    case 'bridge_gentle_stairs': {
      // 5×7×8 stairs on a bridge built at a small incline (climbs 4 blocks over 8 length towards local 0).
      for (let lz = 0; lz < L; lz++) {
        const rise = Math.floor((L - 1 - lz) / 2);
        for (let lx = 0; lx < W; lx++) {
          const side = lx === 0 || lx === W - 1;
          for (let ly = 0; ly < H; ly++) P(lx, ly, lz, 0, true);
          P(lx, rise, lz, purpur, true);
          if (side) {
            P(lx, rise + 1, lz, lz % 4 === 0 ? pillar : stairs(0), true);
          } else if (lz % 2 === 1) {
            P(lx, rise + 1, lz, slab, true);
          }
        }
      }
      break;
    }

    case 'bridge_steep_stairs': {
      // 5×7×4 stairs on a bridge built at a steep incline (climbs 4 blocks over 4 length towards local 0).
      for (let lz = 0; lz < L; lz++) {
        const rise = L - 1 - lz;
        for (let lx = 0; lx < W; lx++) {
          const side = lx === 0 || lx === W - 1;
          for (let ly = 0; ly < H; ly++) P(lx, ly, lz, 0, true);
          P(lx, rise, lz, purpur, true);
          P(lx, rise + 1, lz, side ? purpur : stairs(0), true);
        }
      }
      break;
    }

    case 'ship': {
      // Delegate to the End Ship builder at the piece's world anchor.
      const [sx, sy, sz] = pieceWorldPos(p, 6, 4, 2);
      endShip(t, put, sx, sy, sz);
      break;
    }
  }

  // Open doorways between connected bridges and towers so every bridge is walkable into its parent/child tower.
  if (p.template === 'bridge_end') {
    for (let lx = 1; lx <= 3; lx++) {
      for (let ly = 1; ly <= 3; ly++) {
        for (const dz of [-1, 0, 1, 2]) {
          const [wx, wy, wz] = pieceWorldPos(p, lx, ly, dz);
          put(wx, wy, wz, 0, true);
        }
      }
    }
  }
}

/**
 * Builds the entire End City at (x, y, z) — chunk-clipped when (ox, oz) are given.
 */
export function buildEndCity(t: StructHost, put: Put, x: number, y: number, z: number, ox?: number, oz?: number, preventShip = false): EndCityLayout {
  const layout = endCityLayout(t.seed, x, y, z, 12, preventShip);
  if (ox !== undefined && oz !== undefined) {
    if (layout.box[3] < ox - 1 || layout.box[0] > ox + 17 || layout.box[5] < oz - 1 || layout.box[2] > oz + 17) return layout;
  }
  const bricks = bid('end_stone_bricks', 'end_stone');
  // Beardifier foundation under the starting base_floor (9×9) down to terrain.
  const start = layout.pieces[0];
  if (start) {
    for (let bx = start.box[0]; bx <= start.box[3]; bx++) {
      for (let bz = start.box[2]; bz <= start.box[5]; bz++) {
        if (ox !== undefined && oz !== undefined && (bx < ox - 1 || bx > ox + 17 || bz < oz - 1 || bz > oz + 17)) continue;
        for (let yy = y - 3; yy < y; yy++) put(bx, yy, bz, bricks, true);
      }
    }
  }
  for (const piece of layout.pieces) {
    buildEndCityPiece(t, put, piece, ox, oz);
  }
  return layout;
}
