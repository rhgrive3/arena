import type { Context2D } from './canvas';

export const rgb = (hex: string): [number, number, number] => [
  Number.parseInt(hex.slice(1, 3), 16) || 0,
  Number.parseInt(hex.slice(3, 5), 16) || 0,
  Number.parseInt(hex.slice(5, 7), 16) || 0,
];

export function shadeHex(hex: string, n: number): string {
  const [r, g, b] = rgb(hex.startsWith('#') ? hex : '#888888');
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v + n))).toString(16).padStart(2, '0');
  return `#${clamp(r)}${clamp(g)}${clamp(b)}`;
}

export function mixHex(hexA: string, hexB: string, t: number): string {
  const [r1, g1, b1] = rgb(hexA);
  const [r2, g2, b2] = rgb(hexB);
  const c = (a: number, b: number) => Math.max(0, Math.min(255, Math.round(a + (b - a) * t))).toString(16).padStart(2, '0');
  return `#${c(r1, r2)}${c(g1, g2)}${c(b1, b2)}`;
}

export interface LogSpec {
  barkDark: string;
  barkShadow: string;
  barkMid: string;
  barkLight: string;
  barkHighlight: string;
  barkAccent: string;
  sapwoodLight: string;
  sapwood: string;
  ringLight: string;
  ringMid: string;
  ringDark: string;
  core: string;
}

export const LOG_SPECS: Record<string, LogSpec> = {
  oak: {
    barkDark: '#332310', barkShadow: '#4a351b', barkMid: '#6b5130', barkLight: '#85673f', barkHighlight: '#9e7c4f', barkAccent: '#594224',
    sapwoodLight: '#e3c691', sapwood: '#d1b075', ringLight: '#bd9960', ringMid: '#a3804a', ringDark: '#856536', core: '#5e4420',
  },
  spruce: {
    barkDark: '#1a0f06', barkShadow: '#29190c', barkMid: '#3b2714', barkLight: '#52371e', barkHighlight: '#664628', barkAccent: '#332010',
    sapwoodLight: '#cca472', sapwood: '#b88e5b', ringLight: '#9e7545', ringMid: '#825d33', ringDark: '#694926', core: '#472e14',
  },
  birch: {
    barkDark: '#292824', barkShadow: '#6b675e', barkMid: '#e2ded3', barkLight: '#efece3', barkHighlight: '#faf8f2', barkAccent: '#c9c4b6',
    sapwoodLight: '#f0e4c0', sapwood: '#dfd0a4', ringLight: '#cfb98a', ringMid: '#b8a172', ringDark: '#998254', core: '#78643c',
  },
  jungle: {
    barkDark: '#2b1f0f', barkShadow: '#40301a', barkMid: '#574429', barkLight: '#705836', barkHighlight: '#876c45', barkAccent: '#4a6b28',
    sapwoodLight: '#e0b590', sapwood: '#cfa078', ringLight: '#b88660', ringMid: '#9c6c49', ringDark: '#805435', core: '#5e3a20',
  },
  acacia: {
    barkDark: '#33302a', barkShadow: '#4a453e', barkMid: '#676157', barkLight: '#7f786d', barkHighlight: '#968e82', barkAccent: '#59544b',
    sapwoodLight: '#e3a67d', sapwood: '#d18d62', ringLight: '#bf683b', ringMid: '#a65329', ringDark: '#873e1b', core: '#63290e',
  },
  dark_oak: {
    barkDark: '#140e07', barkShadow: '#241a10', barkMid: '#3c2e1d', barkLight: '#523f29', barkHighlight: '#634d34', barkAccent: '#2e2215',
    sapwoodLight: '#876744', sapwood: '#735535', ringLight: '#5e4327', ringMid: '#4a331c', ringDark: '#362311', core: '#241609',
  },
  cherry: {
    barkDark: '#23131b', barkShadow: '#2f1c25', barkMid: '#3b242f', barkLight: '#492e3b', barkHighlight: '#573847', barkAccent: '#634150',
    sapwoodLight: '#fce3e8', sapwood: '#f2c9d1', ringLight: '#e3a6b2', ringMid: '#cc8996', ringDark: '#b06b78', core: '#8a4755',
  },
  mangrove: {
    barkDark: '#211712', barkShadow: '#362922', barkMid: '#524036', barkLight: '#6b5447', barkHighlight: '#806657', barkAccent: '#75362c',
    sapwoodLight: '#c7997d', sapwood: '#b08064', ringLight: '#963f35', ringMid: '#7d2f27', ringDark: '#611f19', core: '#45120e',
  },
  pale_oak: {
    barkDark: '#33302d', barkShadow: '#4f4b46', barkMid: '#75706a', barkLight: '#8f8982', barkHighlight: '#aba59d', barkAccent: '#615c57',
    sapwoodLight: '#f7f4ed', sapwood: '#e8e4dc', ringLight: '#d6d1c7', ringMid: '#bfbab0', ringDark: '#a39d94', core: '#827d74',
  },
  crimson: {
    barkDark: '#21060e', barkShadow: '#360d1a', barkMid: '#4f1628', barkLight: '#6b2037', barkHighlight: '#852a46', barkAccent: '#e83f67',
    sapwoodLight: '#e35073', sapwood: '#c23456', ringLight: '#9e2645', ringMid: '#7d1b35', ringDark: '#5c1024', core: '#3d0816',
  },
  warped: {
    barkDark: '#150b1c', barkShadow: '#26162e', barkMid: '#3a2542', barkLight: '#52355c', barkHighlight: '#684573', barkAccent: '#33dbd0',
    sapwoodLight: '#57e3d7', sapwood: '#38bfb4', ringLight: '#289990', ringMid: '#1c756e', ringDark: '#11544f', core: '#093834',
  },
  bamboo: {
    barkDark: '#355916', barkShadow: '#4a7a22', barkMid: '#6ca338', barkLight: '#8ec452', barkHighlight: '#a8de6b', barkAccent: '#d4e89e',
    sapwoodLight: '#f0df8a', sapwood: '#dec868', ringLight: '#c9b458', ringMid: '#b39d42', ringDark: '#968230', core: '#73621f',
  },
  poplar: {
    barkDark: '#383628', barkShadow: '#63604b', barkMid: '#c7c19e', barkLight: '#d9d3b2', barkHighlight: '#ebe5c5', barkAccent: '#8c886d',
    sapwoodLight: '#f5f0d5', sapwood: '#e3ddc0', ringLight: '#cfc8a5', ringMid: '#b8b08c', ringDark: '#9c9472', core: '#7a7354',
  },
};

function drawVerticalBarkPlates(
  ctx: Context2D,
  spec: LogSpec,
  furrowMap: string[],
  palOverride?: Partial<Record<string, string>>,
) {
  const pal: Record<string, string> = {
    D: spec.barkDark,
    S: spec.barkShadow,
    M: spec.barkMid,
    L: spec.barkLight,
    H: spec.barkHighlight,
    A: spec.barkAccent,
    ...palOverride,
  };
  for (let y = 0; y < 16; y++) {
    const row = furrowMap[y];
    for (let x = 0; x < 16; x++) {
      const ch = row[x] || 'M';
      const base = pal[ch] || spec.barkMid;
      const micro = (((x * 13 + y * 29) ^ (x * 3)) % 5) - 2;
      ctx.fillStyle = shadeHex(base, micro * 2);
      ctx.fillRect(x, y, 1, 1);
    }
  }
}

// Staggered interlocking bark plates (fissures weave naturally across X rather than sitting on a rigid 4px grid)
const OAK_BARK_MAP = [
  'DHLMMSDSHLMMSHLM',
  'DLLMMSDSLLMMSLLM',
  'DSLMDSDHLMMSDSLM',
  'SDHLMDDLLMMSDHLM',
  'MDHLMDSDLMMSSHLM',
  'MDLLMDSDHLMMSLLM',
  'SDSLMDDHLMMSDSLM',
  'DSHLMDSLLMMSDHLM',
  'DHLMMSSDLMMSSHLM',
  'DLLMMSDHLMMSDLLM',
  'DSLMMSDLLMMSDSLM',
  'SDHLMDSDLMMSDHLM',
  'MDHLMDDHLMMSDHLM',
  'MDLLMDSLLMMSDLLM',
  'SDSLMDSDLMMSDSLM',
  'DHLMMSDHLMMSDHLM',
];

const SPRUCE_BARK_MAP = [
  'DSHLMSDDSHLMSHLM',
  'DSMLMSDDSMLMSMLM',
  'SDDMLSDDSMLSDDML',
  'MDSHLMSDDSHLDSHL',
  'SDSMLMSDDSLMSMLM',
  'DDSMLSDDSHLMSMLM',
  'DSHLMSDDSMLSDDMS',
  'DSMLMSDDSLMSDHLM',
  'DSMLSDDSHLMSDSML',
  'SDDMSDDSMLMSDSML',
  'MDSHLSDDSMLSDDMS',
  'SDSMLMSDDMLSDHLM',
  'DDSMLSDDSHLMSMLM',
  'DSHLMSDDSMLMSMLM',
  'DSMLMSDDSMLSDDMS',
  'SDDMSDDSHLMSDHLM',
];

const DARK_OAK_BARK_MAP = [
  'DSHLMDSDSHLMDSML',
  'DSMLMDSDSMLMDSLM',
  'SDSLMDDDSLMSDSHL',
  'MDHLMSSDHLMSSMLM',
  'MDMLMSDSMLMSDSLM',
  'SDSLMDSDSLMSDDMS',
  'DDSHLSDDSHLMSHLM',
  'DSMLMSDSMLMSDSML',
  'DSLMSDDSLMSSDMLM',
  'SDDMSDDSLMSDSHLM',
  'MDSHLSDHLMSSDSML',
  'SDMLMSDSMLMSDSLM',
  'DDSLMSDSLMSDDSHL',
  'DSHLMSDHLMSSDSML',
  'DSMLMSDSMLMSDSLM',
  'SDSLMDSDSLMSDDMS',
];

const ACACIA_BARK_MAP = [
  'DHLMMSDSHLMMSHLM',
  'DLLMMSSDLLMMSLLM',
  'SDLMMDSDHLMMSLLM',
  'MDSLMDSDLLMMSDSM',
  'SDHLMSSDHLMMSHLM',
  'DHLMMSDSLLMMSLLM',
  'DLLMMSDHLMMSDSLM',
  'DSLMMSDLLMMSDHLM',
  'SDHLMSDSLMMSSHLM',
  'MDLLMDDHLMMSDLLM',
  'SDSLMDSLLMMSDSLM',
  'DHLMMSDSLMMSDHLM',
  'DLLMMSSDHLMMSLLM',
  'SDLMMDSDLLMMSLLM',
  'MDSLMSDSHLMMSDSM',
  'SDHLMDDLLMMSDHLM',
];

const MANGROVE_BARK_MAP = [
  'DAHLMSDSAHLMSHLM',
  'DSMLMSDDSMLMSLLM',
  'SDSLMDDDALMMSDSM',
  'MDAHLMSDSHLMSSAM',
  'SDSLMSSDSLMMSHLM',
  'DDALMMSDALMMSLLM',
  'DSHLMSSDSLMMSDSM',
  'DSLMMSDDALMMSHLM',
  'SDALMMSDSHLMSSLM',
  'MDSHLMSSDSLMMSAM',
  'SDSLMMSDALMMSHLM',
  'DDALMMSDSHLMSSLM',
  'DSHLMSSDSLMMSDSM',
  'DSLMMSDDALMMSHLM',
  'SDALMMSDSHLMSSLM',
  'MDSHLMSSDSLMMSAM',
];

const PALE_OAK_BARK_MAP = [
  'DHLMMSDSHLMMSHLM',
  'DLLMMSDDLLMMSLLM',
  'SDSLMDSDHLMMSDSM',
  'MDHLMSSDLLMMSHLM',
  'SDLLMDSDSLMMSLLM',
  'DDSLMMSSHLMMSDSM',
  'DHLMMSDDLLMMSHLM',
  'DLLMMSDSLMMSDLLM',
  'DSLMMSDHLMMSDSLM',
  'SDHLMSDLLMMSSHLM',
  'MDLLMDSDSLMMSLLM',
  'SDSLMDDHLMMSDSLM',
  'DHLMMSDLLMMSDHLM',
  'DLLMMSSDSLMMSLLM',
  'SDLMMDSDHLMMSDSM',
  'MDSLMDDLLMMSDHLM',
];


const EXACT_LOG_TILES: Record<string, { p: string[]; d: number[][] }> = {"oak_log":{"p":["#745a36","#4c3d26","#917142","#382b18","#5f4a2b","#987849"],"d":[[0,1,2,0,0,3,2,0,0,3,0,2,1,2,0,4],[0,1,5,4,0,3,5,4,0,3,0,2,1,0,0,4],[0,3,4,4,0,3,5,4,0,1,0,1,1,0,0,4],[2,3,0,4,0,1,0,4,0,4,0,3,1,0,2,4],[2,1,0,4,0,3,0,4,5,4,0,4,0,1,2,0],[2,0,1,0,2,1,0,1,5,4,2,1,0,1,2,0],[4,0,1,0,2,4,4,0,2,0,2,0,0,1,2,0],[4,0,3,0,2,0,4,2,0,0,2,4,0,4,2,0],[0,1,3,5,0,0,4,2,0,4,2,4,2,4,2,0],[0,0,1,5,0,0,4,0,0,4,2,1,2,0,3,0],[0,0,0,2,0,4,0,3,0,4,0,1,2,0,3,0],[0,1,0,2,0,4,0,3,5,0,0,3,5,0,1,0],[5,1,0,0,2,4,2,3,5,4,0,3,0,0,4,0],[5,0,1,0,2,0,0,1,2,4,0,1,0,0,0,0],[2,0,1,2,0,0,2,3,0,1,0,1,1,2,0,0],[2,0,1,2,1,0,2,1,0,1,0,0,1,2,0,4]]},"oak_log_top":{"p":["#5f4a2b","#4c3d26","#745a36","#b8945f","#af8f55","#c29d62","#7e6237","#967441","#9f844d"],"d":[[0,1,0,2,0,1,0,0,2,1,0,0,1,0,0,0],[1,3,3,3,3,4,3,4,5,4,4,3,3,3,3,1],[0,3,6,6,7,7,8,7,8,8,8,8,7,7,5,0],[0,3,6,5,5,3,3,3,3,4,3,3,3,7,3,0],[0,4,7,3,4,4,4,4,4,4,4,4,3,8,4,0],[1,3,8,3,4,7,7,8,8,7,7,4,3,7,4,1],[0,4,7,4,4,6,4,4,4,4,7,4,4,7,3,0],[0,4,8,3,4,7,4,8,8,4,8,4,3,8,4,0],[0,4,8,3,4,7,4,8,7,4,7,4,3,7,4,0],[1,4,8,3,4,7,4,4,4,4,8,4,4,7,4,1],[0,4,7,3,4,7,7,6,7,8,8,4,3,8,4,0],[0,4,8,3,4,4,4,4,4,4,4,4,3,7,4,0],[1,3,8,3,3,4,3,3,3,3,3,5,3,7,4,1],[0,3,8,7,8,7,7,7,7,7,7,7,7,7,3,0],[0,3,3,3,4,4,3,4,4,5,4,4,3,3,3,0],[0,1,0,0,0,1,0,0,2,1,0,0,1,2,0,0]]},"spruce_log":{"p":["#3b2713","#311e0b","#4d3317","#2e1608","#2e1c0a","#553a1f"],"d":[[0,1,2,0,0,3,2,0,0,3,0,2,1,2,0,4],[0,1,5,4,0,3,5,4,0,3,0,2,1,0,0,4],[0,3,4,4,0,3,5,4,0,1,0,1,1,0,0,4],[2,3,0,4,0,1,0,4,0,4,0,3,1,0,2,4],[2,1,0,4,0,3,0,4,5,4,0,4,0,1,2,0],[2,0,1,0,2,1,0,1,5,4,2,1,0,1,2,0],[4,0,1,0,2,4,4,0,2,0,2,0,0,1,2,0],[4,0,3,0,2,0,4,2,0,0,2,4,0,4,2,0],[0,1,3,5,0,0,4,2,0,4,2,4,2,4,2,0],[0,0,1,5,0,0,4,0,0,4,2,1,2,0,3,0],[0,0,0,2,0,4,0,3,0,4,0,1,2,0,3,0],[0,1,0,2,0,4,0,3,5,0,0,3,5,0,1,0],[5,1,0,0,2,4,2,3,5,4,0,3,0,0,4,0],[5,0,1,0,2,0,0,1,2,4,0,1,0,0,0,0],[2,0,1,2,0,0,2,3,0,1,0,1,1,2,0,0],[2,0,1,2,1,0,2,1,0,1,0,0,1,2,0,4]]},"birch_log":{"p":["#f0eeeb","#ded3d5","#d8d8ce","#ffffff","#bebeae","#605e54","#36342a","#eef1ea"],"d":[[0,0,1,2,2,0,0,0,2,1,0,0,2,2,0,0],[2,1,0,0,0,0,3,3,3,0,2,1,1,1,2,0],[3,3,3,1,1,2,0,3,0,0,0,0,2,0,3,3],[3,3,2,4,5,6,6,5,2,0,3,3,3,3,2,3],[2,0,0,2,4,5,5,6,5,2,3,3,0,2,5,4],[5,5,2,2,0,2,1,1,2,0,2,2,2,5,6,6],[5,4,0,0,2,1,1,0,3,3,3,0,0,7,2,4],[2,1,2,3,3,3,3,3,3,2,2,1,7,7,0,2],[3,0,2,2,0,3,3,7,7,3,3,3,3,7,3,3],[3,3,0,1,1,7,7,7,3,3,3,0,0,2,2,0],[2,2,0,3,3,3,3,0,0,0,2,1,1,3,3,0],[2,0,3,3,3,3,0,3,3,3,3,7,3,3,0,2],[1,1,2,0,0,2,2,0,0,3,7,7,2,4,5,6],[6,4,0,0,3,3,3,0,2,1,1,2,5,6,6,6],[6,6,5,2,2,2,3,3,3,0,5,5,2,4,5,5],[0,2,2,5,0,3,3,3,0,1,2,2,0,2,2,0]]},"cherry_log":{"p":["#301d29","#3b232d","#462c39","#271620","#543543"],"d":[[0,1,2,2,1,1,0,0,0,1,1,0,0,1,1,0],[1,0,0,0,0,2,2,2,1,1,0,3,3,3,0,0],[3,3,0,1,1,1,2,4,4,4,2,2,0,3,3,0],[1,1,1,0,3,3,3,0,1,1,1,2,2,2,1,0],[1,0,0,0,0,1,1,0,3,3,3,3,3,3,0,0],[2,2,2,1,1,0,0,0,0,3,3,0,1,1,2,2],[2,1,0,0,0,3,3,3,1,2,2,2,1,0,0,2],[0,0,0,1,1,0,3,0,1,1,0,3,3,3,0,0],[3,3,2,2,4,4,2,2,0,0,0,1,1,0,3,3],[3,3,0,0,1,2,2,0,3,3,3,0,3,3,3,0],[0,0,3,3,3,3,0,0,3,0,0,1,0,3,0,1],[2,1,3,0,1,1,1,0,1,2,2,2,4,4,4,2],[1,0,0,1,2,4,4,2,2,2,1,0,0,0,1,1],[0,3,3,0,0,0,0,1,2,2,2,1,1,0,0,0],[0,0,1,1,1,3,3,0,0,0,1,1,1,1,2,2],[2,2,2,2,1,1,0,3,3,2,4,4,2,1,1,1]]},"crimson_stem":{"p":["#442131","#521810","#b12727","#4b2737","#7b0000","#961515","#890f0f","#562c3e"],"d":[[0,0,1,2,3,3,4,1,5,1,0,3,0,6,1,0],[0,0,1,5,0,3,4,1,5,1,3,3,1,4,1,0],[1,6,4,1,1,3,1,6,6,0,7,0,1,1,6,1],[2,0,3,4,1,0,0,1,6,1,7,3,4,1,5,5],[1,3,7,1,4,1,3,1,4,1,3,7,1,6,5,1],[0,7,7,1,4,1,7,3,1,4,1,3,0,1,6,1],[1,4,7,7,1,4,3,7,7,1,4,1,1,6,1,3],[6,3,7,3,1,4,0,3,7,7,1,4,4,1,3,3],[6,0,0,1,0,1,4,1,0,3,3,1,4,0,7,7],[1,5,0,6,3,3,1,4,4,1,0,4,4,1,7,3],[1,2,5,1,0,7,7,0,1,4,1,4,1,3,3,0],[5,1,3,0,1,3,7,7,0,4,4,1,6,0,0,1],[6,3,3,4,1,0,3,7,1,4,1,0,5,1,0,1],[1,3,1,6,1,4,0,3,6,1,0,3,1,2,1,6],[0,1,6,1,0,4,1,0,1,5,1,3,3,1,5,1],[0,0,5,1,3,0,4,0,1,2,5,1,0,6,1,0]]}};
function drawExactLog16(name: string, ctx: Context2D): boolean {
  const t = EXACT_LOG_TILES[name];
  if (!t) return false;
  for (let y = 0; y < 16; y++) {
    const row = t.d[y];
    for (let x = 0; x < 16; x++) {
      ctx.fillStyle = t.p[row[x]];
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return true;
}

export function drawEnhancedLogTile(name: string, ctx: Context2D): boolean {
  if (drawExactLog16(name, ctx)) return true;
  const px = (x: number, y: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect((x + 16) & 15, (y + 16) & 15, 1, 1);
  };
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === 'mangrove_roots_side' || name === 'mangrove_roots_top') {
    ctx.clearRect(0, 0, 16, 16);
    const dk = '#2b1d12', sh = '#3d2a1b', md = '#543b26', lt = '#6b4c32', hi = '#876242';
    if (name === 'mangrove_roots_top') {
      r(0, 0, 16, 2, md); r(0, 14, 16, 2, md); r(0, 0, 2, 16, md); r(14, 0, 2, 16, md);
      r(4, 0, 2, 16, sh); r(10, 0, 2, 16, sh);
      r(0, 4, 16, 2, sh); r(0, 10, 16, 2, sh);
      r(1, 1, 14, 1, lt); r(1, 1, 1, 14, lt);
      r(4, 4, 2, 2, lt); r(10, 4, 2, 2, lt); r(4, 10, 2, 2, lt); r(10, 10, 2, 2, lt);
      px(5, 4, hi); px(10, 10, hi); px(1, 1, hi); px(11, 4, hi);
      for (const [ox, oy] of [[0, 0], [15, 0], [0, 15], [15, 15]]) px(ox, oy, dk);
      return true;
    }
    const cols = [0, 4, 8, 11, 14];
    for (const cx of cols) {
      for (let y = 0; y < 16; y++) {
        const shift = (cx === 0 || cx === 14) ? 0 : (((y + cx) % 6 >= 3) ? 1 : 0);
        const rx = (cx + shift) & 15;
        px(rx, y, dk);
        px(rx + 1, y, y % 3 === 0 ? hi : lt);
        if (cx === 4 || cx === 11) px(rx + 2, y, sh);
      }
    }
    for (const ry of [2, 7, 12]) {
      for (let x = 0; x < 16; x++) {
        const wy = ry + ((x >> 2) & 1);
        px(x, wy, x % 3 === 0 ? hi : md);
        px(x, wy + 1, dk);
      }
    }
    return true;
  }

  if (name === 'muddy_mangrove_roots_side' || name === 'muddy_mangrove_roots_top') {
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const h = ((x * 17 + y * 31) ^ (x * y)) & 7;
        const mudCol = h === 0 ? '#282528' : h <= 2 ? '#343034' : h <= 5 ? '#3f3b3f' : '#4c464a';
        px(x, y, mudCol);
      }
    }
    if (name === 'muddy_mangrove_roots_top') {
      const roots: [number, number, number, number][] = [
        [0, 3, 6, 2], [9, 2, 7, 2], [4, 7, 8, 2], [2, 12, 6, 2], [10, 11, 6, 2],
        [3, 1, 2, 6], [11, 4, 2, 7], [6, 9, 2, 6],
      ];
      for (const [rx, ry, rw, rh] of roots) {
        r(rx, ry, rw, rh, '#543b26');
        r(rx, ry, Math.max(1, rw - 1), 1, '#755438');
        px(rx + rw - 1, ry + rh - 1, '#362417');
      }
      return true;
    }
    for (const baseX of [1, 5, 10, 13]) {
      for (let y = 0; y < 16; y++) {
        if ((y + baseX * 3) % 8 === 0) continue;
        const wx = (baseX + (((y >> 1) + baseX) % 3) - 1 + 16) & 15;
        px(wx, y, '#362417');
        px(wx + 1, y, y % 3 === 0 ? '#805c3d' : '#5e422b');
      }
    }
    return true;
  }

  if (name === 'mushroom_stem' || name === 'mushroom_stem_top') {
    if (name === 'mushroom_stem_top') {
      r(0, 0, 16, 16, '#c7bfb0');
      r(1, 1, 14, 14, '#dcd5c6');
      for (let y = 1; y < 15; y++) {
        for (let x = 1; x < 15; x++) {
          const d = Math.hypot(x - 7.5, y - 7.5);
          const n = ((x * 11 + y * 23) % 5) - 2;
          const base = d < 2.2 ? '#b5ad9e' : d < 4.5 ? '#e6dfd0' : d < 6.2 ? '#cfc8b8' : '#dfd8c8';
          px(x, y, shadeHex(base, n * 3));
        }
      }
      return true;
    }
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const shift = (y >> 2) & 1;
        const ridge = (x + shift) % 4;
        const n = ((x * 13 + y * 29) % 5) - 2;
        const base = ridge === 0 ? '#bfb7a6' : ridge === 1 ? '#e8e2d5' : ridge === 2 ? '#dad3c5' : '#ccc5b6';
        px(x, y, shadeHex(base, n * 2));
      }
    }
    return true;
  }

  if (name === 'bamboo_block' || name === 'stripped_bamboo_block' || name === 'bamboo_block_top' || name === 'stripped_bamboo_block_top') {
    const stripped = name.startsWith('stripped_');
    const sp = LOG_SPECS.bamboo;
    if (name.endsWith('_top')) {
      r(0, 0, 16, 16, stripped ? sp.ringDark : sp.barkDark);
      for (const [bx, by] of [[1, 1], [8, 1], [1, 8], [8, 8]]) {
        r(bx, by, 7, 7, stripped ? sp.sapwood : sp.barkMid);
        r(bx + 1, by + 1, 5, 5, stripped ? sp.sapwoodLight : sp.sapwood);
        r(bx + 2, by + 2, 3, 3, stripped ? sp.ringDark : sp.barkShadow);
      }
      return true;
    }
    for (let x = 0; x < 16; x++) {
      const stalk = x & 3;
      const col = stripped
        ? (stalk === 0 ? sp.ringDark : stalk === 1 ? sp.sapwoodLight : stalk === 2 ? sp.sapwood : sp.ringLight)
        : (stalk === 0 ? sp.barkDark : stalk === 1 ? sp.barkHighlight : stalk === 2 ? sp.barkMid : sp.barkLight);
      r(x, 0, 1, 16, col);
    }
    for (const ny of [3, 11]) {
      r(0, ny, 16, 1, stripped ? sp.ringDark : sp.barkShadow);
      r(0, ny + 1, 16, 1, stripped ? sp.sapwoodLight : sp.barkAccent);
    }
    return true;
  }
  if (name.startsWith('stripped_')) {
    const isTopS = name.endsWith('_log_top');
    const spName = name.replace(/^stripped_/, '').replace(/_log(_top)?$/, '');
    const sp = LOG_SPECS[spName];
    if (sp) {
      if (isTopS) {
        r(0, 0, 16, 16, sp.ringMid);
        r(1, 1, 14, 14, sp.sapwood);
        r(3, 3, 10, 10, sp.ringLight);
        r(5, 5, 6, 6, sp.ringMid);
        r(7, 7, 2, 2, sp.core);
      } else {
        for (let y = 0; y < 16; y++) {
          for (let x = 0; x < 16; x++) {
            const v = ((x * 7 + y * 3) % 5) - 2;
            const bCol = (x % 4 === 0) ? sp.ringLight : (x % 4 === 1) ? sp.sapwoodLight : sp.sapwood;
            px(x, y, shadeHex(bCol, v * 3));
          }
        }
      }
      return true;
    }
  }
  const isTop = name.endsWith('_log_top');
  const species = name.replace(/_log(_top)?$/, '');
  const spec = LOG_SPECS[species];
  if (!spec) return false;

  if (isTop) {
    // 1. Clean, cohesive 1px outer bark rim
    for (let i = 0; i < 16; i++) {
      const k = (i * 5 + 3) % 7;
      if (species === 'birch' || species === 'poplar') {
        const cRim = k === 0 ? spec.barkAccent : k <= 3 ? spec.barkLight : spec.barkMid;
        px(i, 0, cRim); px(15, i, cRim); px(15 - i, 15, cRim); px(0, 15 - i, cRim);
      } else {
        const cTop = k === 0 ? spec.barkDark : k <= 2 ? spec.barkLight : spec.barkMid;
        const cBot = k === 1 ? spec.barkDark : k <= 3 ? spec.barkShadow : spec.barkMid;
        px(i, 0, cTop); px(15, i, cBot); px(15 - i, 15, cBot); px(0, 15 - i, cTop);
      }
    }
    if (species === 'birch' || species === 'poplar') {
      for (const s of [5, 11]) {
        px(s, 0, '#9e998c'); px(15, s, '#9e998c');
        px(s, 15, '#9e998c'); px(0, s, '#9e998c');
      }
      px(0, 0, '#b5b0a2'); px(15, 0, '#b5b0a2');
      px(0, 15, '#b5b0a2'); px(15, 15, '#b5b0a2');
    } else {
      if (species === 'mangrove' || species === 'bamboo' || species === 'crimson' || species === 'warped' || species === 'cherry') {
        for (const s of [3, 10]) {
          r(s, 0, 2, 1, spec.barkAccent); r(15, s, 1, 2, spec.barkAccent);
          r(s, 15, 2, 1, spec.barkAccent); r(0, s, 1, 2, spec.barkAccent);
        }
      } else if (species === 'crimson' || species === 'warped') {
        for (const s of [4, 11]) {
          px(s, 0, spec.barkAccent); px(15, s, spec.barkAccent);
          px(s, 15, spec.barkAccent); px(0, s, spec.barkAccent);
        }
      }
      px(0, 0, spec.barkDark); px(15, 0, spec.barkDark);
      px(0, 15, spec.barkDark); px(15, 15, spec.barkDark);
    }

    // 2. Concentric growth rings with cambium bevel & radial rays
    for (let y = 1; y <= 14; y++) {
      for (let x = 1; x <= 14; x++) {
        const dx = x - 7.5, dy = y - 7.5;
        const cheb = Math.max(Math.abs(dx), Math.abs(dy));
        const eucl = Math.hypot(dx, dy);
        const dist = cheb * 0.56 + eucl * 0.44;
        const grain = (((x * 19 + y * 37) ^ (x * 7)) % 5) - 2;
        let col: string;
        if (cheb >= 6.4) {
          if (species === 'birch' || species === 'poplar') {
            // Golden-tan inner cambium ring contrasting cleanly inside the white birch bark rim
            col = (x === 1 || y === 1) ? spec.ringMid : spec.ringDark;
          } else {
            col = (x === 1 || y === 1) ? spec.sapwoodLight : spec.sapwood;
            if ((x === 1 || x === 14) && (y === 1 || y === 14)) col = mixHex(spec.barkMid, spec.sapwood, 0.55);
          }
        } else if (dist >= 5.15) {
          col = (species === 'birch' || species === 'poplar') ? spec.sapwoodLight : spec.ringDark;
        } else if (dist >= 4.15) {
          col = spec.ringLight;
        } else if (dist >= 3.25) {
          col = spec.ringMid;
        } else if (dist >= 2.25) {
          col = spec.ringDark;
        } else if (dist >= 1.25) {
          col = spec.ringLight;
        } else {
          col = spec.core;
        }
        if ((x === 7 || y === 8) && cheb < 6 && cheb > 1.5) {
          col = shadeHex(col, 6);
        }
        px(x, y, shadeHex(col, grain * 2));
      }
    }
    return true;
  }

  // Side Bark (`<species>_log`)
  if (species === 'birch') {
    for (let y = 0; y < 16; y++) {
      const band = (y % 5 === 0) ? spec.barkHighlight : (y % 3 === 0) ? spec.barkMid : spec.barkLight;
      for (let x = 0; x < 16; x++) {
        const edge = (x === 0 || x === 15) ? -6 : (x === 1 || x === 14) ? -3 : 0;
        const streak = ((x + y * 3) % 7 === 0) ? -4 : ((x * 5 + y) % 9 === 0) ? 4 : 0;
        px(x, y, shadeHex(band, edge + streak));
      }
    }
    const scars: [number, number, number][] = [
      [1, 2, 4], [10, 1, 4], [4, 5, 5], [12, 6, 3],
      [0, 9, 3], [7, 8, 5], [2, 12, 5], [11, 13, 4], [6, 15, 3],
    ];
    for (const [sx, sy, sw] of scars) {
      r(sx, sy, sw, 1, spec.barkDark);
      px(sx, sy, spec.barkShadow);
      px(sx + sw - 1, sy, spec.barkShadow);
      if (sw >= 4) px(sx + 1, (sy + 1) & 15, spec.barkShadow);
      px(sx - 1, sy, '#a8a396');
      px(sx + sw, sy, '#a8a396');
      r(sx + 1, (sy - 1 + 16) & 15, Math.max(1, sw - 2), 1, spec.barkHighlight);
    }
    return true;
  }

  if (species === 'poplar') {
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const furrow = ((x + (y >> 2)) % 7 === 0) && (y % 5 < 3);
        const col = furrow ? spec.barkAccent : (y % 4 === 0) ? spec.barkHighlight : (x % 3 === 0) ? spec.barkMid : spec.barkLight;
        px(x, y, shadeHex(col, ((x * 7 + y * 5) % 5 - 2) * 2));
      }
    }
    const eyes: [number, number, number][] = [
      [1, 2, 3], [8, 3, 4], [4, 7, 4], [12, 8, 3], [1, 11, 4], [7, 13, 4], [13, 15, 3],
    ];
    for (const [ex, ey, ew] of eyes) {
      r(ex, ey, ew, 1, spec.barkShadow);
      px(ex + 1, ey, spec.barkDark);
      px(ex + 1, (ey - 1 + 16) & 15, spec.barkAccent);
      px(ex + 1, (ey + 1) & 15, spec.barkHighlight);
    }
    return true;
  }

  if (species === 'cherry') {
    for (let y = 0; y < 16; y++) {
      const v = (y % 4 === 0) ? spec.barkDark : (y % 2 === 0) ? spec.barkMid : spec.barkShadow;
      for (let x = 0; x < 16; x++) {
        const sheen = (x >= 3 && x <= 6) || (x >= 11 && x <= 13) ? 6 : 0;
        px(x, y, shadeHex(v, sheen + (((x * 5 + y * 3) % 3 - 1) * 2)));
      }
    }
    const bands: [number, number, number][] = [
      [1, 1, 5], [9, 2, 5], [3, 5, 6], [11, 6, 4],
      [0, 8, 4], [6, 9, 6], [2, 12, 5], [10, 13, 5], [5, 15, 4],
    ];
    for (const [bx, by, bw] of bands) {
      r(bx, (by - 1 + 16) & 15, bw, 1, spec.barkLight);
      r(bx, by, bw, 1, spec.barkAccent);
      r(bx + 1, by, Math.max(1, bw - 2), 1, spec.barkHighlight);
      r(bx, (by + 1) & 15, bw, 1, spec.barkDark);
    }
    return true;
  }

  if (species === 'jungle') {
    // Interwoven vertical & horizontal tropical bark with mossy crevices
    drawVerticalBarkPlates(ctx, spec, OAK_BARK_MAP);
    for (const hy of [2, 6, 10, 14]) {
      for (let x = 0; x < 16; x++) {
        if ((x + hy) % 5 === 0) continue;
        px(x, hy, (x % 3 === 0) ? spec.barkHighlight : spec.barkLight);
        px(x, (hy + 1) & 15, spec.barkShadow);
      }
    }
    const moss: [number, number, number, number][] = [[1, 2, 3, 2], [9, 4, 4, 2], [3, 9, 4, 2], [11, 12, 3, 2], [6, 14, 3, 2]];
    for (const [mx, my, mw, mh] of moss) {
      r(mx, my, mw, mh, spec.barkAccent);
      px(mx + 1, my, shadeHex(spec.barkAccent, 22));
      px(mx, my + mh - 1, shadeHex(spec.barkAccent, -18));
    }
    return true;
  }

  if (species === 'crimson' || species === 'warped') {
    drawVerticalBarkPlates(ctx, spec, SPRUCE_BARK_MAP);
    for (let y = 0; y < 16; y++) {
      const v1 = (2 + Math.round(Math.sin(y * 0.5) * 1.4)) & 15;
      const v2 = (7 + Math.round(Math.cos(y * 0.48) * 1.5)) & 15;
      const v3 = (12 + Math.round(Math.sin(y * 0.52 + 1.4) * 1.4)) & 15;
      for (const vx of [v1, v2, v3]) {
        if ((y + vx) % 6 !== 0) {
          px(vx, y, y % 2 === 0 ? shadeHex(spec.barkAccent, 32) : spec.barkAccent);
          px(vx + 1, y, mixHex(spec.barkAccent, spec.barkMid, 0.45));
        }
      }
    }
    return true;
  }

  if (species === 'spruce') {
    drawVerticalBarkPlates(ctx, spec, SPRUCE_BARK_MAP);
    return true;
  }
  if (species === 'dark_oak') {
    drawVerticalBarkPlates(ctx, spec, DARK_OAK_BARK_MAP);
    return true;
  }
  if (species === 'acacia') {
    drawVerticalBarkPlates(ctx, spec, ACACIA_BARK_MAP);
    return true;
  }
  if (species === 'mangrove') {
    drawVerticalBarkPlates(ctx, spec, MANGROVE_BARK_MAP);
    return true;
  }
  if (species === 'pale_oak') {
    drawVerticalBarkPlates(ctx, spec, PALE_OAK_BARK_MAP);
    return true;
  }

  // Oak (`oak_log`)
  drawVerticalBarkPlates(ctx, spec, OAK_BARK_MAP);
  r(5, 5, 2, 2, spec.barkDark); px(6, 5, spec.barkHighlight);
  r(12, 11, 2, 2, spec.barkDark); px(13, 11, spec.barkLight);
  return true;
}

// =====================================================================================================================
// BATCH 2: PLANKS, STAIRS, SLABS, FENCES & WOOD WALLS (All 12 Wood Species)
// =====================================================================================================================

export interface PlankSpec {
  dark: string;      // Deep seam groove
  shadow: string;    // Board shadow / dark grain
  midDark: string;   // Secondary board base
  base: string;      // Primary board base
  light: string;     // Board highlight grain
  highlight: string; // Top/left bevel edge highlight
  style: 'classic' | 'tight' | 'silky' | 'wavy';
}

export const PLANK_SPECS: Record<string, PlankSpec> = {
  oak: {
    dark: '#664d2b', shadow: '#85663b', midDark: '#a3804e', base: '#b8945f', light: '#c9a671', highlight: '#dbb985', style: 'classic',
  },
  spruce: {
    dark: '#3d2a16', shadow: '#523a20', midDark: '#664a2b', base: '#785836', light: '#8a6843', highlight: '#9c7852', style: 'tight',
  },
  birch: {
    dark: '#85744c', shadow: '#9e8b5e', midDark: '#baa675', base: '#cbb783', light: '#d9c696', highlight: '#e8d7aa', style: 'silky',
  },
  jungle: {
    dark: '#5e3f28', shadow: '#785237', midDark: '#916546', base: '#a67754', light: '#ba8966', highlight: '#cc9c7a', style: 'classic',
  },
  acacia: {
    dark: '#693216', shadow: '#874320', midDark: '#a3532c', base: '#ba6337', light: '#cc7447', highlight: '#de875b', style: 'classic',
  },
  dark_oak: {
    dark: '#211509', shadow: '#30200f', midDark: '#3d2914', base: '#4a3219', light: '#5c3f22', highlight: '#6e4d2b', style: 'tight',
  },
  cherry: {
    dark: '#94626c', shadow: '#b37d87', midDark: '#cf9ba4', base: '#e6b4bc', light: '#f0c4cb', highlight: '#fad7dc', style: 'silky',
  },
  mangrove: {
    dark: '#421814', shadow: '#59231d', midDark: '#6b2c25', base: '#7a362e', light: '#8f443b', highlight: '#a3544b', style: 'wavy',
  },
  pale_oak: {
    dark: '#8c877f', shadow: '#aba59c', midDark: '#c7c2b8', base: '#dfdbd2', light: '#ebe7df', highlight: '#f5f2ec', style: 'silky',
  },
  crimson: {
    dark: '#380e1e', shadow: '#4d162b', midDark: '#5e1e36', base: '#6e2640', light: '#82314e', highlight: '#963f5e', style: 'wavy',
  },
  warped: {
    dark: '#113b37', shadow: '#19524d', midDark: '#20635e', base: '#28756f', light: '#338a83', highlight: '#40a199', style: 'wavy',
  },
  bamboo: {
    dark: '#73621f', shadow: '#968230', midDark: '#b39d42', base: '#c9b458', light: '#dec868', highlight: '#f0df8a', style: 'tight',
  },
  poplar: {
    dark: '#8c8462', shadow: '#aba27b', midDark: '#c4ba91', base: '#d9d0a8', light: '#e6deb8', highlight: '#f2ebca', style: 'silky',
  },
};

export function extractPlankSpecies(name: string): string | null {
  if (name === 'bamboo_mosaic') return 'bamboo';
  const m = name.match(/^(oak|spruce|birch|jungle|acacia|dark_oak|cherry|mangrove|bamboo|pale_oak|crimson|warped|poplar)_(planks|stairs|slab|fence|fence_gate|planks_wall|pressure_plate|button|sign|hanging_sign|wall_sign|wall_hanging_sign)$/);
  if (m) return m[1];
  const m2 = name.match(/^(oak|spruce|birch|jungle|acacia|dark_oak|cherry)_planks_(stairs|slab|fence|wall)$/);
  if (m2) return m2[1];
  return null;
}

export function drawPlanksTile(name: string, ctx: Context2D): boolean {
  const species = extractPlankSpecies(name);
  if (!species) return false;
  const spec = PLANK_SPECS[species];
  if (!spec) return false;

  const px = (x: number, y: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect((x + 16) & 15, (y + 16) & 15, 1, 1);
  };

  const splits = [7, 14, 3, 11];
  const grainPatterns: Record<PlankSpec["style"], string[][]> = {
    classic: [
      ["HLLLLBBLLLLBBLHL", "BBBBMMBBBBLLLLBB", "BBMMMMBBBBMMBBBB", "DDDDSSDDDDSSDDDD"],
      ["LBBLLLLBBBBLLLLH", "MMBBBBLLLLBBBBMM", "BBBBMMBBBBMMMMBB", "SSDDDDSSDDDDSSDD"],
      ["LLLLBBBBLLLLBBBB", "BBBBMMMMBBBBLLLL", "MMBBBBLLLLBBBBMM", "DDDDSSDDDDSSDDDD"],
      ["BBLLLLBBBBLLLLBB", "LLLLBBBBMMMMBBBB", "BBBBLLLLBBBBMMMM", "SSDDDDSSDDDDSSDD"],
    ],
    tight: [
      ["HLLLBBBBLLLBBBBH", "BBMMMMBBBBMMMMBB", "MMMMBBBBMMMMBBBB", "DDDDSSDDDDSSDDDD"],
      ["BBBBLLLBBBBLLLBB", "MMMMBBBBMMMMBBBB", "BBMMMMBBBBMMMMBB", "SSDDDDSSDDDDSSDD"],
      ["LLLBBBBLLLBBBBLL", "BBMMMMBBBBMMMMBB", "MMMMBBBBMMMMBBBB", "DDDDSSDDDDSSDDDD"],
      ["BBBBLLLBBBBLLLBB", "MMMMBBBBMMMMBBBB", "BBMMMMBBBBMMMMBB", "SSDDDDSSDDDDSSDD"],
    ],
    silky: [
      ["HLLLLLLBBBBLLLLL", "BBBBLLLLLLBBBBLL", "LLBBBBMMBBBBLLLL", "SSDDDDSSSSDDDDSS"],
      ["LLLLBBBBLLLLLLBB", "LLBBBBLLLLLLBBBB", "BBBBLLLLBBBBMMBB", "DDDDSSSSDDDDSSSS"],
      ["BBLLLLLLBBBBLLLL", "LLLLLLBBBBLLLLLL", "LLBBBBMMBBBBLLLL", "SSDDDDSSSSDDDDSS"],
      ["LLLLBBBBLLLLLLBB", "BBBBLLLLLLBBBBLL", "BBBBLLLLBBBBMMBB", "DDDDSSSSDDDDSSSS"],
    ],
    wavy: [
      ["HLLLBBBBLLLLBBBH", "BBMMMMLLLLMMMMBB", "MMMMBBBBLLLLMMMM", "DDDDSSDDDDSSDDDD"],
      ["LLLBBBBLLLLBBBBL", "MMMMLLLLMMMMBBBB", "BBLLLLMMMMBBBBLL", "SSDDDDSSDDDDSSDD"],
      ["BBLLLLBBBBLLLLBB", "LLLLMMMMBBBBMMMM", "MMMMBBBBLLLLMMMM", "DDDDSSDDDDSSDDDD"],
      ["LLLLBBBBLLLLBBBB", "MMBBBBMMMMLLLLMM", "BBBBLLLLMMMMBBBB", "SSDDDDSSDDDDSSDD"],
    ],
  };

  const pal: Record<string, string> = {
    H: spec.highlight,
    L: spec.light,
    B: spec.base,
    M: spec.midDark,
    S: spec.shadow,
    D: spec.dark,
  };

  const courses = grainPatterns[spec.style];
  for (let course = 0; course < 4; course++) {
    const y0 = course * 4;
    const splitX = splits[course];
    const rows = courses[course];
    for (let dy = 0; dy < 4; dy++) {
      const y = y0 + dy;
      const rowStr = rows[dy];
      for (let x = 0; x < 16; x++) {
        let col = pal[rowStr[x]] || spec.base;
        const secondBoard = x > splitX;
        // Smooth longitudinal micro-grain gradient along each board
        const micro = Math.round(Math.sin((x + course * 5) * 0.65 + dy * 0.9) * 3);
        if (dy < 3) {
          col = shadeHex(col, micro + (secondBoard ? ((course & 1) ? 3 : -3) : 0));
        }
        // Clean 1px vertical butt-joint with subtle bevel highlight on the next pixel
        if (x === splitX) {
          col = dy === 3 ? spec.dark : dy === 2 ? spec.dark : dy === 1 ? spec.shadow : spec.midDark;
        } else if (x === ((splitX + 1) & 15) && dy < 3) {
          col = dy === 0 ? spec.highlight : dy === 1 ? spec.light : spec.base;
        }
        px(x, y, col);
      }
    }
  }
  return true;
}

// =====================================================================================================================
// BATCH 3: LEAVES (14), SAPLINGS (12), AZALEA BUSHES (2), BAMBOO, COCOA, LEAF LITTER
// =====================================================================================================================

// Interlocking staggered leaf rosette maps (zero horizontal 4px banding; each cluster overlaps organically in 2D & 3D)
const LEAF_ROSETTE_OAK = [
  "1232101221012321",
  "2333212332123332",
  "1221223321223212",
  "0100122110112100",
  "1221010012321011",
  "2332122123332122",
  "2321233223221233",
  "1101232112101232",
  "0011121001001211",
  "1232100122112100",
  "2333211233223211",
  "1221222332123322",
  "0110123211012212",
  "1232011001211001",
  "2333100123321110",
  "1221211232212211",
];

const LEAF_ROSETTE_BIRCH = [
  "1231023210123102",
  "2332133321233213",
  "1210122110122112",
  "0101101012010011",
  "2322310123101232",
  "3333321233212333",
  "2212211221101221",
  "1001001100120100",
  "1231023210231012",
  "2332133321332123",
  "1221122110211012",
  "0100101012001201",
  "2321210123212310",
  "3332321233323321",
  "2211211222112212",
  "1001001101001001",
];

const LEAF_ROSETTE_CONIFER = [
  "1023201231023201",
  "2103012322103012",
  "3212123103212123",
  "1321231011321231",
  "0132310120132310",
  "1021201231021201",
  "2101012312101012",
  "3212121003212121",
  "1233210121023201",
  "2313012232103012",
  "3102123313212123",
  "1011231101321231",
  "0122310010132310",
  "1231201121021201",
  "2311012232101012",
  "3102123113212121",
];

const LEAF_ROSETTE_TROPICAL = [
  "1233210122101232",
  "2333321233212333",
  "2322322332122322",
  "1211211221011211",
  "0100122100122100",
  "1221233211233211",
  "2332233322333322",
  "3321122212322212",
  "2210011101211101",
  "1101232010100122",
  "0012333121011233",
  "1123223232122332",
  "2232112121232221",
  "3221001010121110",
  "2110122101010011",
  "1001233212101122",
];

const LEAF_ROSETTE_SAVANNA = [
  "1233210122101233",
  "2322101233212322",
  "1101212321121101",
  "0012321100110012",
  "1223332012321123",
  "2332211123332232",
  "1211001223211121",
  "0100122311001010",
  "1221233200122101",
  "2332232111233212",
  "1221110022332123",
  "0110012112211012",
  "1001223201100101",
  "2112333310011220",
  "3223222121122331",
  "2112110012233221",
];

const LEAF_ROSETTE_WEEPING = [
  "1232101221012321",
  "1232112332112321",
  "0121012332101210",
  "1010112221010101",
  "2101201210121012",
  "3212310101232123",
  "3212311011232123",
  "2101201221021012",
  "1010112332110101",
  "0121012332101210",
  "1232112221012321",
  "2333201210123332",
  "2322110101123221",
  "1211011011012110",
  "0100122122101001",
  "1211233233212112",
];

export function drawLeavesTile(name: string, ctx: Context2D): boolean {
  if (!name.endsWith("_leaves")) return false;
  const px = (x: number, y: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect((x + 16) & 15, (y + 16) & 15, 1, 1);
  };

  const tintable = name === "oak_leaves" || name === "jungle_leaves" || name === "acacia_leaves" || name === "dark_oak_leaves" || name === "mangrove_leaves";
  const map =
    name === "spruce_leaves" ? LEAF_ROSETTE_CONIFER :
    name === "birch_leaves" || name === "poplar_leaves" ? LEAF_ROSETTE_BIRCH :
    name === "jungle_leaves" || name === "mangrove_leaves" ? LEAF_ROSETTE_TROPICAL :
    name === "acacia_leaves" ? LEAF_ROSETTE_SAVANNA :
    name === "pale_oak_leaves" ? LEAF_ROSETTE_WEEPING :
    LEAF_ROSETTE_OAK;

  let pal: [string, string, string, string];
  if (tintable) {
    pal = ["#8e8e8e", "#a8a8a8", "#c4c4c4", "#dedede"];
  } else if (name === "spruce_leaves") {
    pal = ["#2d4f33", "#3b6642", "#4b7d53", "#5e9667"];
  } else if (name === "birch_leaves") {
    pal = ["#547535", "#6a9143", "#81ab53", "#9ac768"];
  } else if (name === "cherry_leaves") {
    pal = ["#bf708d", "#d98ca8", "#f0b2c7", "#fce3ec"];
  } else if (name === "pale_oak_leaves") {
    pal = ["#798270", "#919c86", "#abb5a0", "#c6cfb8"];
  } else if (name === "crimson_leaves") {
    pal = ["#571222", "#781d31", "#992840", "#bd3954"];
  } else if (name === "warped_leaves") {
    pal = ["#13524c", "#1d736b", "#2a9187", "#3cb5a9"];
  } else if (name === "poplar_leaves") {
    pal = ["#757c2d", "#939c3c", "#b0b84d", "#cdd466"];
  } else {
    pal = ["#3b6127", "#4f7e35", "#659b46", "#7eb85b"];
  }

  ctx.clearRect(0, 0, 16, 16);
  for (let y = 0; y < 16; y++) {
    const row = map[y];
    for (let x = 0; x < 16; x++) {
      const idx = Number.parseInt(row[x], 10) || 0;
      // Leave '0' pixels transparent (Fancy leaves cutout) so sky/inner leaves show through without black spots
      if (idx === 0) continue;
      const micro = (((x * 11 + y * 19) ^ (x * 3)) % 3) - 1;
      px(x, y, shadeHex(pal[idx], micro * 2));
    }
  }

  if (name === "cherry_leaves") {
    for (const [bx, by] of [[2, 2], [10, 2], [6, 6], [13, 8], [3, 11], [9, 13]]) {
      px(bx, by, "#c26888");
      px(bx - 1, by, "#fff5f8"); px(bx + 1, by, "#ffd6e4");
      px(bx, by - 1, "#fff5f8"); px(bx, by + 1, "#f5b8cd");
      px(bx + 1, by - 1, "#ffffff");
    }
  } else if (name === "flowering_azalea_leaves") {
    for (const [fx, fy] of [[2, 2], [10, 3], [5, 8], [12, 9], [3, 13], [11, 14]]) {
      px(fx, fy, "#9e2b78");
      px(fx - 1, fy, "#f7a8de"); px(fx + 1, fy, "#de6bb8");
      px(fx, fy - 1, "#ffc7f2"); px(fx, fy + 1, "#de6bb8");
      px(fx + 1, fy - 1, "#f7a8de");
    }
  } else if (name === "crimson_leaves" || name === "warped_leaves") {
    const glow = name === "crimson_leaves" ? "#ff6b8b" : "#5cf2e3";
    for (const [gx, gy] of [[3, 3], [11, 4], [6, 9], [13, 12], [4, 14]]) {
      px(gx, gy, glow);
    }
  }
  return true;
}

function drawSprite16(ctx: Context2D, rows: string[], pal: Record<string, string>) {
  ctx.clearRect(0, 0, 16, 16);
  for (let y = 0; y < 16 && y < rows.length; y++) {
    const r = rows[y];
    for (let x = 0; x < 16 && x < r.length; x++) {
      const c = pal[r[x]];
      if (!c) continue;
      ctx.fillStyle = c;
      ctx.fillRect(x, y, 1, 1);
    }
  }
}

const SAPLING_SPRITES: Record<string, { map: string[]; pal: Record<string, string> }> = {
  oak: {
    pal: { D: "#2b4718", M: "#3f6924", L: "#588f34", H: "#78b84a", B: "#4a351b", S: "#6e502b" },
    map: [
      "......LLHH......",
      "....LLHHHLLM....",
      "...LHHLLLLMD....",
      "..LHHLMMLLHHL...",
      "..LMLMDMLLHHML..",
      ".DMLLMDDMMLLMMD.",
      ".DLLBMD..DMLLMD.",
      "..DDBSD..DSBDD..",
      "....BSB..BS.....",
      ".....BSBBS......",
      "......BSB.......",
      "......BSB.......",
      "......BSB.......",
      ".....BS.SB......",
      "....BD...DB.....",
      "................",
    ],
  },
  spruce: {
    pal: { D: "#182e1d", M: "#284a30", L: "#3b6944", H: "#558c60", B: "#2e1d0f", S: "#4a311b" },
    map: [
      ".......HL.......",
      "......HLLM......",
      ".....HLLMMD.....",
      "....DDMLMDD.....",
      "....HLLLLM......",
      "...HLLLLMMD.....",
      "..DDMLLLMDDD....",
      "...HLLLLLMM.....",
      "..HLLLLLLMMD....",
      ".DDMLLLLLMDDD...",
      "...HLLLLLLMM....",
      "..DDMBSBSMDDD...",
      "......BSB.......",
      "......BSB.......",
      ".....BS.SB......",
      "................",
    ],
  },
  birch: {
    pal: { D: "#3d5922", M: "#567a32", L: "#739e46", H: "#96c760", W: "#e8e4da", G: "#aba698", K: "#292824" },
    map: [
      "......LHHL......",
      "....LLHHHHLL....",
      "...LHHHLLHHML...",
      "..LHHLLMMLLHML..",
      "..LMLLMDDMLLMD..",
      "...DLLMWGMDLLD..",
      "...DD.WKGW.DD...",
      ".......WG.......",
      "......GWW.......",
      ".......WK.......",
      ".......WG.......",
      ".......KW.......",
      ".......WG.......",
      "......W..G......",
      "................",
      "................",
    ],
  },
  jungle: {
    pal: { D: "#284d1a", M: "#3b6e28", L: "#529438", H: "#73bd52", B: "#42301b", S: "#634a2b" },
    map: [
      "....LLHHHHLL....",
      "..LLHHHLLHHHLL..",
      ".LHHLMMMMMMLLHL.",
      ".LMD.DBSSBD.DML.",
      ".DD...BSB....DD.",
      "....LLBSBLL.....",
      "..LLHHBSBHHLL...",
      ".LHHMMBSBMMHHL..",
      ".DMD..BSB..DMD..",
      "......BSB.......",
      "......BSB.......",
      "......BSB.......",
      ".....BSBSB......",
      "....BD...DB.....",
      "................",
      "................",
    ],
  },
  acacia: {
    pal: { D: "#42521d", M: "#5c6e2a", L: "#788f38", H: "#9bb54c", B: "#4d4840", S: "#6e685f" },
    map: [
      "................",
      ".....LLHHHHLL...",
      "...LLHHHLLHHML..",
      "..DDDDMMMMDDDD..",
      "........BSB.....",
      ".LLHHHLLBS......",
      "LHHHLLMBS.......",
      "DDDMMMBS........",
      "....BSB.........",
      ".....BSB........",
      "......BS........",
      "......BS........",
      ".....BS.........",
      "....BSB.........",
      "...BD.DB........",
      "................",
    ],
  },
  dark_oak: {
    pal: { D: "#1d3613", M: "#2b4f1d", L: "#3e6e2b", H: "#589140", B: "#261a0e", S: "#3d2b18" },
    map: [
      "....LLHHHHLL....",
      "..LLHHHHHHHHLL..",
      ".LHHHLLLLLLHHML.",
      ".LHLLMMMMMMLLMD.",
      "LMLLMMDDDDMMLLMD",
      "DLLMDDD..DDDMLLD",
      ".DDDBSB..BSBDDD.",
      "....BSBBBBSSB...",
      ".....BSSSSSB....",
      ".....BSSSSB.....",
      ".....BSSSSB.....",
      ".....BSSSSB.....",
      "....BSSBBSSB....",
      "...BDB....BDB...",
      "................",
      "................",
    ],
  },
  cherry: {
    pal: { D: "#964662", M: "#bf6786", L: "#e695b0", H: "#ffd6e4", W: "#fff2f7", B: "#2b1520", S: "#4a2736" },
    map: [
      "....LHWWHHL.....",
      "..LLHWWLLHHML...",
      ".LHHLLLLMMLLHML.",
      ".LMLMMMDDMMLLWL.",
      "DMLMDD....DDLLHD",
      "DDDBSB..LLHWLLMD",
      "....BSB.LHHLLMDD",
      ".....BSBBDDMDD..",
      "......BSSB......",
      "......BSB.......",
      ".....BSB........",
      ".....BSB........",
      "....BS.SB.......",
      "...BD...DB......",
      "................",
      "................",
    ],
  },
  mangrove: {
    pal: { D: "#33521f", M: "#4d7831", L: "#6aa146", H: "#8cc462", R: "#6b2b22", A: "#8f3d32" },
    map: [
      "................",
      "....HH....HH....",
      "...HLLM..MLLH...",
      "...MLMD..DMLM...",
      "....DD.HL.DD....",
      "......HLLM......",
      "......MLMD......",
      "......MLMD......",
      "......MLMD......",
      "......MLMD......",
      "......DMDD......",
      "......RAAR......",
      "......RAAR......",
      "......R..R......",
      ".....R....R.....",
      "................",
    ],
  },
  pale_oak: {
    pal: { D: "#4f5449", M: "#6e7566", L: "#8f9685", H: "#b5bdab", B: "#3d3a36", S: "#5e5a54" },
    map: [
      "....LLHHHHLL....",
      "..LLHHHHHHHHLL..",
      ".LHHHLLLLLLHHHL.",
      ".LHLLMMMMMMLLHL.",
      "LMLLMDDDDDDMLLML",
      "DMLMDBS..SBDMLMD",
      ".DMD..BSSB..DMD.",
      ".DM....BSB...MD.",
      "..D....BSB....D.",
      ".......BSB......",
      "......BSBSB.....",
      ".....BD...DB....",
      "................",
      "................",
      "................",
      "................",
    ],
  },
  crimson: {
    pal: { D: "#520e1c", M: "#851b30", L: "#b82843", H: "#e03e5c", G: "#ff9e42", S: "#6e2e3d", B: "#4a1c27" },
    map: [
      "......LLHH......",
      "....LLHHHHLL....",
      "...LHGLLLLHML...",
      "..LGHLMLLMGHML..",
      "..LMLMMMMMMLMD..",
      ".DMMMMDDDDMMMMD.",
      ".DDDD.BSSB.DDDD.",
      "......BSSB......",
      "......BSSB......",
      "......BSSB......",
      ".....BSSSB......",
      ".....BSSB.......",
      "....BS..SB......",
      "................",
      "................",
      "................",
    ],
  },
  warped: {
    pal: { D: "#0e423d", M: "#1a6e66", L: "#2b9c91", H: "#42c7ba", G: "#80ff9e", S: "#2f5e59", B: "#1d3d3a" },
    map: [
      "......LLHH......",
      "....LLHHHHLL....",
      "...LHGLLLLHML...",
      "..LGHLMLLMGHML..",
      "..LMLMMMMMMLMD..",
      ".DMMMMDDDDMMMMD.",
      ".DDDD.BSSB.DDDD.",
      "......BSSB......",
      "......BSSB......",
      "......BSSB......",
      ".....BSSSB......",
      ".....BSSB.......",
      "....BS..SB......",
      "................",
      "................",
      "................",
    ],
  },
  poplar: {
    pal: { D: "#52571d", M: "#737a29", L: "#98a138", H: "#c2cc52", B: "#757059", S: "#a6a083" },
    map: [
      ".......HL.......",
      "......HHLL......",
      ".....HLLLLD.....",
      "....HLLLLMML....",
      "....HLLMLLML....",
      "...HLLLLMMLLD...",
      "...MLLMLLMMMD...",
      "...MLLMMLLMML...",
      "....DLLBSBMD....",
      ".....DDBSBDD....",
      ".......BS.......",
      ".......BS.......",
      ".......BS.......",
      "......B..S......",
      "................",
      "................",
    ],
  },
};

export function drawSaplingOrWoodPlantTile(name: string, ctx: Context2D): boolean {
  const px = (x: number, y: number, col: string) => {
    if (x < 0 || x >= 16 || y < 0 || y >= 16) return;
    ctx.fillStyle = col;
    ctx.fillRect(x, y, 1, 1);
  };
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === "bamboo") {
    ctx.clearRect(0, 0, 16, 16);
    // Columns 6..9: 3D bamboo culm stalk; Columns 0..5 & 10..15: vibrant bamboo leaf blades
    r(6, 0, 4, 16, "#4a7a22");
    r(7, 0, 2, 16, "#6ca338");
    r(7, 0, 1, 16, "#8ec452");
    for (const ny of [3, 8, 13]) {
      r(6, ny, 4, 1, "#355916");
      r(6, ny + 1, 4, 1, "#a8de6b");
    }
    for (const [lx, ly, dir] of [[5, 2, -1], [10, 5, 1], [5, 10, -1], [10, 12, 1]] as const) {
      px(lx, ly, "#5c912d"); px(lx + dir, ly - 1, "#7cb844"); px(lx + dir * 2, ly - 1, "#9ed462");
      px(lx + dir, ly, "#4a7a22"); px(lx + dir * 2, ly, "#6ca338");
    }
    return true;
  }

  if (name === "cocoa") {
    ctx.clearRect(0, 0, 16, 16);
    r(7, 0, 2, 3, "#4f7828"); px(7, 0, "#6ea13d");
    r(5, 3, 6, 10, "#6e3512");
    r(4, 4, 8, 8, "#8f4a1f");
    r(5, 4, 6, 8, "#b5642d");
    r(6, 4, 2, 8, "#d48342");
    for (const y of [5, 8, 10]) { px(5, y, "#6e3512"); px(10, y, "#6e3512"); px(7, y, "#e69a56"); }
    r(6, 13, 4, 1, "#54270c");
    return true;
  }

  if (name === "leaf_litter") {
    ctx.clearRect(0, 0, 16, 16);
    const leaves: [number, number, string, string][] = [
      [1, 2, "#9c6635", "#bd8046"], [8, 1, "#7d4e26", "#996333"], [12, 4, "#b0763e", "#cc8e52"],
      [3, 7, "#87562b", "#a66d38"], [9, 8, "#a66d38", "#c4864b"], [1, 12, "#754822", "#915c2e"],
      [7, 12, "#996333", "#b87b42"], [12, 11, "#825128", "#9e6636"],
    ];
    for (const [lx, ly, c1, c2] of leaves) {
      r(lx, ly, 3, 2, c1);
      r(lx + 1, ly + 1, 2, 2, c2);
      px(lx, ly, shadeHex(c2, 16));
    }
    return true;
  }

  if (name === "azalea" || name === "flowering_azalea") {
    ctx.clearRect(0, 0, 16, 16);
    r(6, 10, 4, 6, "#594026"); r(7, 10, 2, 6, "#755636"); px(7, 11, "#8c6943");
    px(5, 14, "#47321d"); px(10, 15, "#47321d");
    r(2, 3, 12, 8, "#385c22");
    r(1, 4, 14, 6, "#4b782e");
    r(3, 2, 10, 8, "#5c913b");
    for (const [hx, hy] of [[4, 2], [8, 2], [3, 4], [7, 4], [11, 4], [5, 6], [9, 6]]) {
      r(hx, hy, 2, 1, "#7bc24e");
    }
    if (name === "flowering_azalea") {
      for (const [fx, fy] of [[3, 3], [9, 3], [5, 6], [11, 6], [2, 7], [8, 8]]) {
        r(fx, fy, 2, 2, "#de6bb8");
        px(fx, fy, "#ffbdf0");
        px(fx + 1, fy + 1, "#9e2b78");
      }
    }
    return true;
  }

  if (!name.endsWith("_sapling")) return false;
  const species = name.replace(/_sapling$/, "");
  const sp = SAPLING_SPRITES[species] ?? SAPLING_SPRITES.oak;
  drawSprite16(ctx, sp.map, sp.pal);
  return true;
}

// =====================================================================================================================
// BATCH 4: DOORS (14), TRAPDOORS (7), PRESSURE PLATES (7), BUTTONS (7), SIGNS (4), ITEM FRAME, TRIPWIRE HOOK
// =====================================================================================================================

export function drawDoorOrTrapdoorTile(name: string, ctx: Context2D): boolean {
  const px = (x: number, y: number, col: string) => {
    if (x < 0 || x >= 16 || y < 0 || y >= 16) return;
    ctx.fillStyle = col;
    ctx.fillRect(x, y, 1, 1);
  };
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  // 1. Pressure Plates (`<species>_pressure_plate`)
  const ppMatch = name.match(/^(oak|spruce|birch|jungle|acacia|dark_oak|cherry|mangrove|bamboo|crimson|warped)_pressure_plate$/);
  if (ppMatch) {
    const sp = PLANK_SPECS[ppMatch[1]];
    drawPlanksTile(ppMatch[1] + '_planks', ctx);
    // Bevelled pressure plate rim
    r(0, 0, 16, 1, sp.dark); r(0, 15, 16, 1, sp.dark); r(0, 0, 1, 16, sp.dark); r(15, 0, 1, 16, sp.dark);
    r(1, 1, 14, 1, sp.highlight); r(1, 1, 1, 14, sp.highlight);
    r(1, 14, 14, 1, sp.shadow); r(14, 1, 1, 14, sp.shadow);
    px(2, 2, sp.dark); px(13, 2, sp.dark); px(2, 13, sp.dark); px(13, 13, sp.dark);
    return true;
  }

  // 2. Signs & Hanging Signs (`oak_sign`, `spruce_sign`, `oak_hanging_sign`, `spruce_hanging_sign`)
  const signMatch = name.match(/^(oak|spruce|birch|jungle|acacia|dark_oak|cherry|mangrove|bamboo|crimson|warped)_(hanging_)?sign$/);
  if (signMatch) {
    const sp = PLANK_SPECS[signMatch[1]];
    const hanging = Boolean(signMatch[2]);
    ctx.clearRect(0, 0, 16, 16);
    if (hanging) {
      // Top dark log bar + iron chains + framed hanging board
      r(1, 0, 14, 2, LOG_SPECS[signMatch[1]].barkMid);
      r(1, 0, 14, 1, LOG_SPECS[signMatch[1]].barkLight);
      r(3, 2, 2, 3, '#7a8285'); px(3, 2, '#b8c2c4');
      r(11, 2, 2, 3, '#7a8285'); px(11, 2, '#b8c2c4');
      r(1, 5, 14, 10, sp.dark);
      r(2, 6, 12, 8, sp.base);
      r(2, 6, 12, 1, sp.highlight);
      r(2, 9, 12, 1, sp.shadow);
      r(2, 12, 12, 1, sp.shadow);
      r(3, 7, 10, 1, sp.dark); r(4, 10, 8, 1, sp.dark);
    } else {
      // Signboard (rows 1..9) + central wooden post (rows 9..15)
      r(7, 9, 2, 7, LOG_SPECS[signMatch[1]].barkMid);
      r(7, 9, 1, 7, LOG_SPECS[signMatch[1]].barkLight);
      r(1, 1, 14, 8, sp.dark);
      r(2, 2, 12, 6, sp.base);
      r(2, 2, 12, 1, sp.highlight);
      r(2, 5, 12, 1, sp.shadow);
      r(3, 3, 10, 1, sp.dark); r(4, 6, 8, 1, sp.dark);
    }
    return true;
  }

  // 3. Item Frame (`item_frame`)
  if (name === 'item_frame') {
    ctx.clearRect(0, 0, 16, 16);
    const sp = PLANK_SPECS.birch;
    // Mitered birch/oak wood outer frame (1..14)
    r(1, 1, 14, 14, sp.dark);
    r(2, 2, 12, 12, sp.base);
    r(1, 1, 14, 1, sp.highlight); r(1, 1, 1, 14, sp.highlight);
    r(2, 2, 12, 1, sp.light); r(2, 2, 1, 12, sp.light);
    // Corner mitre joints
    px(1, 1, sp.dark); px(2, 2, sp.shadow); px(14, 1, sp.dark); px(13, 2, sp.shadow);
    px(1, 14, sp.dark); px(2, 13, sp.shadow); px(14, 14, sp.dark); px(13, 13, sp.shadow);
    // Warm stitched-leather backing board (3..12)
    r(3, 3, 10, 10, '#73482b');
    r(4, 4, 8, 8, '#8f5b38');
    for (let y = 4; y < 12; y++) {
      for (let x = 4; x < 12; x++) {
        const n = ((x * 7 + y * 13) % 5) - 2;
        px(x, y, shadeHex('#96603b', n * 4));
      }
    }
    // Subtle corner leather stitching
    for (const [sx, sy] of [[4, 4], [11, 4], [4, 11], [11, 11], [4, 7], [11, 8], [7, 4], [8, 11]]) {
      px(sx, sy, '#b88258');
    }
    return true;
  }

  // 4. Tripwire Hook (`tripwire_hook`)
  if (name === 'tripwire_hook') {
    ctx.clearRect(0, 0, 16, 16);
    // Wooden wall-mount base (5..10, 6..14) + iron hook loop (6..9, 1..6)
    r(5, 7, 6, 8, '#543e22');
    r(6, 8, 4, 6, '#85673f');
    r(6, 8, 4, 1, '#a3804e');
    r(7, 5, 2, 3, '#6b5130');
    r(6, 1, 4, 4, '#7d8587');
    r(6, 1, 4, 1, '#c4cccc');
    ctx.clearRect(7, 2, 2, 2);
    return true;
  }

  // 5. All 7 Species Trapdoors (`<species>_trapdoor`)
  if (name === 'iron_trapdoor') {
    ctx.clearRect(0, 0, 16, 16);
    r(0, 0, 16, 16, '#c4cbc7');
    r(0, 0, 16, 1, '#7d8587'); r(0, 15, 16, 1, '#7d8587'); r(0, 0, 1, 16, '#7d8587'); r(15, 0, 1, 16, '#7d8587');
    for (const [wx, wy] of [[3, 3], [9, 3], [3, 9], [9, 9]]) ctx.clearRect(wx, wy, 4, 4);
    return true;
  }
  const tdMatch = name.match(/^(oak|spruce|birch|jungle|acacia|dark_oak|cherry|mangrove|bamboo|crimson|warped)_trapdoor$/);
  if (tdMatch) {
    const species = tdMatch[1];
    const sp = PLANK_SPECS[species];
    ctx.clearRect(0, 0, 16, 16);

    // Base outer frame common to all trapdoors
    r(0, 0, 16, 16, sp.base);
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        px(x, y, shadeHex(sp.base, (((x * 5 + y * 9) % 5) - 2) * 3));
      }
    }
    r(0, 0, 16, 1, sp.dark); r(0, 15, 16, 1, sp.dark); r(0, 0, 1, 16, sp.dark); r(15, 0, 1, 16, sp.dark);
    r(1, 1, 14, 1, sp.highlight); r(1, 1, 1, 14, sp.highlight);
    r(1, 14, 14, 1, sp.shadow); r(14, 1, 1, 14, sp.shadow);

    if (species === 'oak') {
      // Classic 2x2 open window grille with bevelled cross-bars & iron hinges
      r(7, 2, 2, 12, sp.base); r(2, 7, 12, 2, sp.base);
      r(7, 2, 1, 12, sp.highlight); r(2, 7, 12, 1, sp.highlight);
      for (const [wx, wy] of [[3, 3], [9, 3], [3, 9], [9, 9]]) {
        r(wx - 1, wy - 1, 5, 5, sp.dark);
        ctx.clearRect(wx, wy, 3, 3);
      }
      r(0, 3, 2, 2, '#4a5052'); r(0, 11, 2, 2, '#4a5052');
      return true;
    }

    if (species === 'spruce') {
      // Heavy medieval dungeon plank trapdoor with dark iron reinforcement straps & rivets (SOLID)
      for (const vx of [4, 8, 12]) {
        r(vx, 1, 1, 14, sp.dark);
        r(vx + 1, 1, 1, 14, sp.light);
      }
      // Horizontal forged iron straps at y=2..3 and y=12..13
      for (const iy of [2, 12]) {
        r(1, iy, 14, 2, '#34383b');
        r(1, iy, 14, 1, '#545b5e');
        for (const rx of [2, 6, 10, 13]) {
          px(rx, iy, '#9aa3a6');
          px(rx, iy + 1, '#1f2224');
        }
      }
      // Iron ring handle on right
      r(12, 7, 2, 2, '#7d8587'); px(12, 7, '#b8c2c4');
      return true;
    }

    if (species === 'birch') {
      // Smooth birch frame with bright cream shoji-paper recessed inner panel (SOLID)
      r(2, 2, 12, 12, sp.shadow);
      r(3, 3, 10, 10, '#f2ede0');
      for (let y = 3; y < 13; y++) {
        for (let x = 3; x < 13; x++) {
          px(x, y, (x + y) % 2 === 0 ? '#f5f1e6' : '#e6e0d0');
        }
      }
      // Delicate shoji inner wood lattice ribs
      r(7, 3, 2, 10, sp.light); r(3, 7, 10, 2, sp.light);
      r(13, 7, 2, 2, '#7a7568');
      return true;
    }

    if (species === 'jungle') {
      // Tropical horizontal louvered slots with rich wood grain on rails
      for (const vy of [3, 7, 11]) {
        r(2, vy - 1, 12, 1, sp.highlight);
        r(2, vy + 2, 12, 1, sp.dark);
        ctx.clearRect(3, vy, 10, 2);
      }
      r(0, 3, 2, 2, '#4a5240'); px(0, 3, '#758266');
      r(0, 11, 2, 2, '#4a5240'); px(0, 11, '#758266');
      return true;
    }

    if (species === 'acacia') {
      // Slatted savanna sun-grille with warm grain on slats & cross-tie
      for (const vx of [3, 7, 11]) {
        r(vx - 1, 2, 1, 12, sp.highlight);
        r(vx + 2, 2, 1, 12, sp.dark);
        ctx.clearRect(vx, 3, 2, 4);
        ctx.clearRect(vx, 9, 2, 4);
      }
      r(2, 7, 12, 1, sp.highlight);
      r(2, 8, 12, 1, sp.shadow);
      r(0, 3, 2, 2, '#4a453e'); r(0, 11, 2, 2, '#4a453e');
      return true;
    }

    if (species === 'dark_oak') {
      // Aristocratic 4-panel chocolate wainscoting coffered trapdoor (SOLID)
      r(7, 2, 1, 12, sp.highlight); r(2, 7, 12, 1, sp.highlight);
      for (const [cx, cy] of [[2, 2], [9, 2], [2, 9], [9, 9]]) {
        r(cx, cy, 5, 5, sp.dark);
        r(cx + 1, cy + 1, 3, 3, sp.midDark);
        r(cx + 1, cy + 1, 3, 1, sp.light);
        r(cx + 1, cy + 1, 1, 3, sp.light);
        px(cx + 2, cy + 2, sp.base);
      }
      r(13, 7, 2, 2, '#c9a23b'); px(13, 7, '#ffe078');
      return true;
    }

    if (species === 'mangrove' || species === 'bamboo' || species === 'crimson' || species === 'warped' || species === 'cherry') {
      // Delicate Japanese kumiko blossom-lattice trapdoor with grained bars
      r(7, 2, 2, 12, sp.light); r(2, 7, 12, 2, sp.light);
      r(7, 2, 1, 12, sp.highlight); r(2, 7, 12, 1, sp.highlight);
      for (const [wx, wy] of [[3, 3], [10, 3], [3, 10], [10, 10]]) {
        r(wx - 1, wy - 1, 5, 5, sp.dark);
        ctx.clearRect(wx, wy, 3, 3);
      }
      r(6, 6, 4, 4, sp.shadow); r(7, 7, 2, 2, sp.highlight);
      r(0, 3, 2, 2, '#b87c6a'); r(0, 11, 2, 2, '#b87c6a');
      return true;
    }
  }

  // 6. All 7 Wood Doors (`<species>_door_top` & `<species>_door_bottom`)
  const doorMatch = name.match(/^(oak|spruce|birch|jungle|acacia|dark_oak|cherry|mangrove|bamboo|crimson|warped)_door_(top|bottom)$/);
  if (doorMatch) {
    const species = doorMatch[1];
    const isTop = doorMatch[2] === 'top';
    const sp = PLANK_SPECS[species];
    ctx.clearRect(0, 0, 16, 16);

    // Base door leaf timber with vertical stiles (0..2, 13..15)
    r(0, 0, 16, 16, sp.base);
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        px(x, y, shadeHex(sp.base, (((x * 7 + y * 5) % 5) - 2) * 2));
      }
    }
    r(0, 0, 1, 16, sp.dark); r(15, 0, 1, 16, sp.dark);
    r(1, 0, 1, 16, sp.highlight); r(14, 0, 1, 16, sp.shadow);
    if (isTop) r(0, 0, 16, 1, sp.dark);
    else r(0, 15, 16, 1, sp.dark);

    // Hinges on left edge
    r(0, isTop ? 3 : 10, 2, 2, '#454a4d');
    px(0, isTop ? 3 : 10, '#7d8587');

    if (species === 'oak') {
      if (isTop) {
        r(2, 2, 12, 10, sp.dark);
        r(7, 2, 2, 10, sp.base); r(2, 6, 12, 2, sp.base);
        r(7, 2, 1, 10, sp.highlight); r(2, 6, 12, 1, sp.highlight);
        for (const [wx, wy] of [[3, 3], [9, 3], [3, 8], [9, 8]]) ctx.clearRect(wx, wy, 4, 3);
        r(2, 13, 12, 2, sp.shadow);
      } else {
        for (const [py, ph] of [[2, 5], [9, 5]]) {
          r(3, py, 10, ph, sp.dark);
          r(4, py + 1, 8, ph - 2, sp.midDark);
          r(4, py + 1, 8, 1, sp.light);
        }
        r(12, 1, 2, 2, '#3b3731'); px(12, 1, '#756e63');
      }
      return true;
    }

    if (species === 'spruce') {
      // Heavy vertical tavern planks + iron strap hinges + small barred peephole on top
      for (const vx of [4, 8, 12]) {
        r(vx, 1, 1, 14, sp.dark);
        r(vx + 1, 1, 1, 14, sp.light);
      }
      for (const iy of isTop ? [2, 12] : [3, 12]) {
        r(1, iy, 13, 2, '#34383b');
        r(1, iy, 13, 1, '#545b5e');
        for (const rx of [2, 6, 10]) px(rx, iy, '#9aa3a6');
      }
      if (isTop) {
        r(5, 5, 6, 5, sp.dark);
        ctx.clearRect(6, 6, 4, 3);
        r(7, 6, 2, 3, '#34383b'); // Iron bar in peephole
      } else {
        r(11, 1, 3, 3, '#34383b'); r(12, 2, 2, 2, '#8a9294');
      }
      return true;
    }

    if (species === 'birch') {
      if (isTop) {
        r(3, 2, 10, 11, sp.shadow);
        r(4, 3, 8, 9, '#f2ede0');
        for (const ly of [5, 8]) r(4, ly, 8, 1, sp.base);
        r(7, 3, 2, 9, sp.base);
      } else {
        for (const py of [2, 8]) {
          r(3, py, 10, 5, sp.shadow);
          r(4, py + 1, 8, 3, sp.light);
          r(4, py + 1, 8, 1, sp.highlight);
        }
        r(12, 1, 2, 2, '#5c584f');
      }
      return true;
    }

    if (species === 'jungle') {
      if (isTop) {
        r(3, 2, 10, 11, sp.dark);
        ctx.clearRect(4, 3, 8, 9);
        // Horizontal tropical branch bars across window
        r(3, 5, 10, 2, sp.base); r(3, 5, 10, 1, sp.highlight);
        r(3, 9, 10, 2, sp.base); r(3, 9, 10, 1, sp.highlight);
      } else {
        r(3, 2, 10, 11, sp.dark);
        r(4, 3, 8, 9, sp.midDark);
        r(4, 3, 8, 1, sp.highlight);
        r(4, 7, 8, 1, sp.dark); r(4, 8, 8, 1, sp.light);
        r(12, 1, 2, 2, '#3d3522');
      }
      return true;
    }

    if (species === 'acacia') {
      // Slatted savanna screen door with open vertical vents on both halves
      r(3, 2, 10, 12, sp.dark);
      for (const vx of [4, 7, 10]) {
        ctx.clearRect(vx, 3, 2, 10);
      }
      r(2, 7, 12, 2, sp.base); r(2, 7, 12, 1, sp.highlight);
      if (!isTop) r(12, 1, 2, 2, '#423e37');
      return true;
    }

    if (species === 'dark_oak') {
      // Grand 6-panel chocolate coffered door (SOLID)
      const rows = isTop ? [[2, 5], [9, 5]] : [[2, 5], [9, 5]];
      r(7, 1, 2, 14, sp.base);
      for (const [py, ph] of rows) {
        for (const [px0, pw] of [[3, 4], [9, 4]]) {
          r(px0, py, pw, ph, sp.dark);
          r(px0 + 1, py + 1, pw - 2, ph - 2, sp.midDark);
          r(px0 + 1, py + 1, pw - 2, 1, sp.light);
        }
      }
      if (!isTop) {
        r(12, 1, 2, 2, '#d4af37'); px(12, 1, '#fff099');
      }
      return true;
    }

    if (species === 'mangrove' || species === 'bamboo' || species === 'crimson' || species === 'warped' || species === 'cherry') {
      if (isTop) {
        r(3, 2, 10, 10, sp.dark);
        ctx.clearRect(4, 3, 8, 8);
        // Kumiko cross & diamond center in window
        r(7, 2, 2, 10, sp.base); r(3, 6, 10, 2, sp.base);
        r(7, 2, 1, 10, sp.highlight); r(3, 6, 10, 1, sp.highlight);
        r(6, 5, 4, 4, sp.shadow); r(7, 6, 2, 2, sp.highlight);
      } else {
        for (const py of [2, 8]) {
          r(3, py, 10, 5, sp.dark);
          r(4, py + 1, 8, 3, sp.light);
          r(4, py + 1, 8, 1, sp.highlight);
        }
        r(12, 1, 2, 2, '#d99b82'); px(12, 1, '#ffd4c2');
      }
      return true;
    }
  }

  return false;
}

// =====================================================================================================================
// BATCH 5: WOODEN WORKSTATIONS, STORAGE, FURNITURE & HYBRID UTILITY BLOCKS (28 Blocks)
// =====================================================================================================================

export function drawWoodFurnitureTile(name: string, ctx: Context2D): boolean {
  const px = (x: number, y: number, col: string) => {
    if (x < 0 || x >= 16 || y < 0 || y >= 16) return;
    ctx.fillStyle = col;
    ctx.fillRect(x, y, 1, 1);
  };
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  // 1. Crafting Table (`crafting_table_top`, `crafting_table_front`, `crafting_table_side`)
  if (name === 'crafting_table_top' || name === 'crafting_table_front' || name === 'crafting_table_side') {
    const oak = PLANK_SPECS.oak;
    drawPlanksTile('oak_planks', ctx);
    if (name === 'crafting_table_top') {
      // Dark oak outer frame (0..1, 14..15) + crimson-tan cloth corners + 3x3 recessed crafting grid
      r(0, 0, 16, 2, '#4a3219'); r(0, 14, 16, 2, '#4a3219'); r(0, 0, 2, 16, '#4a3219'); r(14, 0, 2, 16, '#4a3219');
      r(1, 1, 14, 1, '#6b4c2b'); r(1, 1, 1, 14, '#6b4c2b');
      r(2, 2, 12, 12, oak.light);
      for (let y = 2; y < 14; y++) {
        for (let x = 2; x < 14; x++) {
          px(x, y, shadeHex(oak.light, (((x * 5 + y * 9) % 5) - 2) * 3));
        }
      }
      // 3x3 crafting grid grooves at x=5,9 and y=5,9
      for (const g of [5, 9]) {
        r(g, 2, 1, 12, '#5c3f22'); r(g + 1, 2, 1, 12, oak.highlight);
        r(2, g, 12, 1, '#5c3f22'); r(2, g + 1, 12, 1, oak.highlight);
      }
      for (const gx of [5, 9]) for (const gy of [5, 9]) px(gx, gy, '#382513');
      // Corner iron/dark-wood studs
      for (const [cx, cy] of [[1, 1], [14, 1], [1, 14], [14, 14]]) px(cx, cy, '#2b1b0c');
      return true;
    }
    // Front & Side: dark oak corner posts + top table rim + hanging tools
    r(0, 0, 16, 3, '#5c3f22'); r(0, 0, 16, 1, oak.highlight); r(0, 2, 16, 1, '#382513');
    r(0, 3, 2, 13, '#4a3219'); r(14, 3, 2, 13, '#4a3219');
    r(1, 3, 1, 13, '#6b4c2b'); r(14, 3, 1, 13, '#6b4c2b');
    r(0, 15, 16, 1, '#382513');
    if (name === 'crafting_table_front') {
      // Dark tool-holder backing + silver hand-saw (left) + claw hammer (right)
      r(3, 4, 10, 9, '#735332'); r(3, 4, 10, 1, '#4a3219');
      // Hand saw (x=4..7, y=5..11)
      r(4, 5, 3, 2, '#8c3b2b'); px(5, 5, '#b5503c');
      r(4, 7, 3, 5, '#b8c2c4'); r(4, 7, 1, 5, '#e6eded');
      for (let sy = 7; sy < 12; sy++) px(6, sy, sy % 2 ? '#7d8587' : '#dce6e8');
      // Claw hammer (x=9..12, y=5..11)
      r(9, 5, 4, 2, '#7d8587'); r(9, 5, 4, 1, '#cfd9db');
      r(10, 7, 2, 5, '#6b4c2b'); r(10, 7, 1, 5, '#997246');
    } else {
      // Side: dark leather pouch + iron pliers/tongs & try-square
      r(3, 4, 10, 9, '#66482b'); r(3, 4, 10, 1, '#382513');
      r(4, 5, 4, 4, '#8c3b2b'); r(4, 5, 4, 1, '#b5503c');
      r(5, 6, 2, 5, '#cfd9db'); px(5, 6, '#ffffff');
      r(9, 5, 1, 5, '#b8c2c4'); r(11, 5, 1, 5, '#b8c2c4');
      r(10, 8, 1, 2, '#545b5e');
      r(9, 10, 1, 2, '#5c3f22'); r(11, 10, 1, 2, '#5c3f22');
    }
    return true;
  }

  // 2. Barrel (`barrel_top`, `barrel_bottom`, `barrel_side`, `barrel_front`)
  if (name === 'barrel_top' || name === 'barrel_bottom' || name === 'barrel_side' || name === 'barrel_front') {
    const sp = PLANK_SPECS.spruce;
    if (name === 'barrel_top' || name === 'barrel_bottom') {
      // Circular stave rim on +Y/-Y with dark iron hoop & recessed spruce head boards
      r(0, 0, 16, 16, sp.dark);
      r(1, 1, 14, 14, '#34383b');
      px(0, 0, '#24170b'); px(15, 0, '#24170b'); px(0, 15, '#24170b'); px(15, 15, '#24170b');
      r(2, 2, 12, 12, sp.base);
      for (let x = 2; x < 14; x++) {
        const col = (x % 3 === 0) ? sp.shadow : (x % 3 === 1) ? sp.light : sp.base;
        for (let y = 2; y < 14; y++) {
          px(x, y, shadeHex(col, (((x * 5 + y * 7) % 5) - 2) * 3));
        }
      }
      r(2, 2, 12, 1, sp.highlight); r(2, 13, 12, 1, sp.dark);
      if (name === 'barrel_top') {
        // Wooden bung plug & iron ring on barrel head
        r(6, 6, 4, 4, sp.dark); r(7, 7, 2, 2, '#24180c');
        px(6, 6, sp.highlight); px(9, 9, '#1a1108');
      }
      return true;
    }
    // barrel_side & barrel_front: vertical spruce staves bound by 2 wrap-around horizontal iron hoops (y=2..3, y=12..13)
    for (let x = 0; x < 16; x++) {
      const stave = x & 3;
      const base = stave === 0 ? sp.dark : stave === 1 ? sp.light : stave === 2 ? sp.base : sp.midDark;
      for (let y = 0; y < 16; y++) {
        const barrelCurve = (y < 2 || y > 13) ? -8 : (y >= 6 && y <= 9) ? 6 : 0;
        px(x, y, shadeHex(base, barrelCurve + (((x * 7 + y * 11) % 5) - 2) * 3));
      }
    }
    for (const hy of [2, 12]) {
      r(0, hy, 16, 2, '#2e3236');
      r(0, hy, 16, 1, '#586063');
      for (const rx of [2, 6, 10, 14]) {
        px(rx, hy, '#a8b2b5');
        px(rx, hy + 1, '#1c1e21');
      }
    }
    if (name === 'barrel_front') {
      // Brass/iron tap spigot & latch plate on front stave between the two hoops
      r(6, 6, 4, 4, '#24180c');
      r(7, 6, 2, 3, '#8a9294');
      px(7, 6, '#dce6e8');
      px(7, 8, '#454a4d');
    }
    return true;
  }

  // 3. Bookshelf & Chiseled Bookshelf (`bookshelf`, `bookshelf_side`, `chiseled_bookshelf_top`, `chiseled_bookshelf_side`, `chiseled_bookshelf_front`)
  if (name === 'bookshelf' || name === 'bookshelf_side') {
    const oak = PLANK_SPECS.oak;
    drawPlanksTile('oak_planks', ctx);
    r(0, 0, 16, 2, oak.base); r(0, 0, 16, 1, oak.highlight); r(0, 1, 16, 1, oak.shadow);
    r(0, 7, 16, 2, oak.base); r(0, 7, 16, 1, oak.highlight); r(0, 8, 16, 1, oak.shadow);
    r(0, 14, 16, 2, oak.base); r(0, 14, 16, 1, oak.highlight); r(0, 15, 16, 1, oak.dark);
    const books: [number, number, string, string][] = [
      [1, 5, '#9e2a22', '#d94c42'], [3, 5, '#26547c', '#4582b5'], [5, 4, '#386e2b', '#5ca14a'],
      [7, 5, '#b58426', '#e6b44c'], [9, 5, '#63347a', '#9155ad'], [11, 4, '#8a4b26', '#bf7243'], [13, 5, '#2b6e66', '#4aa399'],
    ];
    for (const shelfY of [2, 9]) {
      r(0, shelfY, 16, 5, '#1f150b');
      r(0, shelfY, 1, 5, oak.shadow); r(15, shelfY, 1, 5, oak.shadow);
      for (let i = 0; i < books.length; i++) {
        const [bx, bh, cDark, cLight] = books[(i + (shelfY === 9 ? 3 : 0)) % books.length];
        const x = 1 + i * 2;
        const yTop = shelfY + (5 - bh);
        r(x, yTop, 2, bh, cDark);
        r(x, yTop, 1, bh, cLight);
        px(x, yTop + 1, '#f0e4c0'); px(x + 1, yTop + 1, '#d1c299'); // Gold foil spine band
        if (i % 3 === 1) px(x, yTop + 3, '#f0e4c0');
      }
      // Top shelf shadow overhang
      r(1, shelfY, 14, 1, 'rgba(0,0,0,0.28)');
    }
    return true;
  }

  if (name === 'chiseled_bookshelf_top' || name === 'chiseled_bookshelf_side' || name === 'chiseled_bookshelf_front') {
    const oak = PLANK_SPECS.oak;
    drawPlanksTile('oak_planks', ctx);
    if (name === 'chiseled_bookshelf_top') {
      r(0, 0, 16, 2, oak.dark); r(0, 14, 16, 2, oak.dark); r(0, 0, 2, 16, oak.dark); r(14, 0, 2, 16, oak.dark);
      r(1, 1, 14, 1, oak.highlight); r(1, 1, 1, 14, oak.highlight);
      // Carved geometric celtic knot border on top
      r(3, 3, 10, 10, oak.shadow);
      r(4, 4, 8, 8, oak.base);
      r(6, 6, 4, 4, oak.dark); r(7, 7, 2, 2, oak.highlight);
      return true;
    }
    if (name === 'chiseled_bookshelf_side') {
      r(0, 0, 16, 2, oak.dark); r(0, 7, 16, 2, oak.dark); r(0, 14, 16, 2, oak.dark);
      for (const sy of [2, 9]) {
        r(1, sy, 14, 5, oak.shadow);
        r(2, sy + 1, 12, 3, oak.base);
        r(3, sy + 2, 4, 1, oak.dark); r(9, sy + 2, 4, 1, oak.dark);
      }
      return true;
    }
    // chiseled_bookshelf_front: 3x2 carved oak cubby slots with grained frame & ornate leather-bound tomes
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const g = (((x * 5 + y * 9) % 5) - 2) * 3;
        px(x, y, shadeHex((y < 2 || (y >= 7 && y <= 8) || y >= 14) ? oak.base : oak.shadow, g));
      }
    }
    r(0, 0, 16, 1, oak.highlight); r(0, 7, 16, 1, oak.highlight); r(0, 14, 16, 1, oak.highlight);
    r(0, 1, 16, 1, oak.dark); r(0, 8, 16, 1, oak.dark); r(0, 15, 16, 1, oak.dark);
    const slotCols = ['#b5382e', '#3278a6', '#4a9138', '#8c469e', '#c9962c', '#2e8c82'];
    let idx = 0;
    for (const sy of [2, 9]) {
      for (const sx of [1, 6, 11]) {
        r(sx, sy, 4, 5, '#1c130a');
        r(sx, sy, 4, 1, '#120b05');
        if (idx !== 2 && idx !== 4) {
          const col = slotCols[idx];
          r(sx + 1, sy + 1, 2, 4, col);
          r(sx + 1, sy + 1, 1, 4, shadeHex(col, 24));
          px(sx + 2, sy + 4, shadeHex(col, -20));
          px(sx + 1, sy + 2, '#f2e6c2'); px(sx + 2, sy + 2, '#c9b47a');
        } else {
          px(sx + 1, sy + 4, '#2e2012'); px(sx + 2, sy + 4, '#2e2012');
        }
        idx++;
      }
    }
    return true;
  }

  // 4. Loom (`loom_top`, `loom_front`, `loom_side`)
  if (name === 'loom' || name === 'loom_top' || name === 'loom_front' || name === 'loom_side') {
    const oak = PLANK_SPECS.oak;
    drawPlanksTile('oak_planks', ctx);
    if (name === 'loom_top') {
      r(0, 0, 16, 2, oak.dark); r(0, 14, 16, 2, oak.dark);
      r(2, 2, 12, 12, '#2e2113');
      // Stretched white warp strings + woven banner cloth & wooden shuttle roller
      for (let x = 3; x < 13; x += 2) r(x, 2, 1, 12, '#e8e4da');
      r(3, 3, 10, 5, '#b83c34'); r(3, 4, 10, 2, '#e6b44c');
      r(2, 9, 12, 2, oak.highlight); r(2, 10, 12, 1, oak.shadow);
      return true;
    }
    if (name === 'loom_front' || name === 'loom') {
      r(0, 0, 16, 2, oak.highlight); r(0, 2, 16, 1, oak.dark);
      r(2, 3, 12, 10, '#291d10');
      for (let x = 3; x < 13; x += 2) r(x, 3, 1, 10, '#dedad0');
      r(2, 6, 12, 2, oak.base); r(2, 6, 12, 1, oak.highlight);
      r(3, 9, 10, 3, '#3b78a8'); r(4, 10, 8, 1, '#85c4f2');
      return true;
    }
    // loom_side: wooden frame + yarn spools
    r(2, 3, 12, 10, oak.dark);
    r(3, 4, 4, 8, '#b83c34'); r(4, 4, 1, 8, '#e05a50');
    r(9, 4, 4, 8, '#3b78a8'); r(10, 4, 1, 8, '#66a6d9');
    r(2, 7, 12, 2, oak.light);
    return true;
  }

  // 5. Smithing Table (`smithing_table`, `smithing_table_top`, `smithing_table_front`, `smithing_table_side`)
  if (name.startsWith('smithing_table')) {
    const cr = PLANK_SPECS.crimson;
    if (name === 'smithing_table_top') {
      // Heavy hammered dark-steel anvil plate top with corner rivets
      r(0, 0, 16, 16, '#262930');
      r(1, 1, 14, 14, '#3a3f4a');
      r(2, 2, 12, 12, '#4c5261');
      for (let y = 2; y < 14; y++) {
        for (let x = 2; x < 14; x++) {
          const n = ((x * 7 + y * 13) % 5) - 2;
          px(x, y, shadeHex('#484e5c', n * 4));
        }
      }
      r(2, 2, 12, 1, '#687082'); r(2, 2, 1, 12, '#687082');
      for (const [rx, ry] of [[2, 2], [13, 2], [2, 13], [13, 13], [7, 2], [7, 13]]) {
        px(rx, ry, '#8a92a6'); px(rx, ry + (ry < 8 ? 1 : -1), '#1d2026');
      }
      return true;
    }
    // Front & Side: hammered iron top overhang (rows 0..3) + dark crimson/mahogany body (rows 4..15)
    drawPlanksTile('crimson_planks', ctx);
    r(0, 0, 16, 3, '#3a3f4a'); r(0, 0, 16, 1, '#687082'); r(0, 3, 16, 1, '#1d2026');
    r(0, 4, 2, 12, cr.dark); r(14, 4, 2, 12, cr.dark);
    if (name === 'smithing_table_front' || name === 'smithing_table') {
      // Recessed crimson tool rack with diagonal blacksmith hammer, curved tongs & anvil silhouette
      r(2, 5, 12, 9, '#2e0b16');
      r(3, 5, 10, 1, '#1c060d');
      // Diagonal forged cross-peen hammer (left: x=3..8, y=6..12)
      r(3, 6, 5, 2, '#687082'); r(3, 6, 4, 1, '#bfc7d6'); px(8, 7, '#8a92a6');
      for (let i = 0; i < 5; i++) {
        px(5 + (i >> 1), 8 + i, '#9c7444');
        px(6 + (i >> 1), 8 + i, '#6b4c28');
      }
      // Crossed blacksmith pincer jaws & handles (right: x=9..12, y=6..12)
      px(9, 6, '#bfc7d6'); px(12, 6, '#bfc7d6');
      px(9, 7, '#8a92a6'); px(12, 7, '#8a92a6');
      r(10, 8, 2, 2, '#cfd6e6');
      px(9, 10, '#687082'); px(12, 10, '#687082');
      px(9, 11, '#4c5261'); px(12, 11, '#4c5261');
      // Bottom iron trim band
      r(2, 13, 12, 1, '#4c5261');
    } else {
      r(3, 5, 10, 9, '#2e0b16');
      r(4, 6, 8, 7, '#4c5261'); r(5, 7, 6, 5, '#687082');
      r(6, 8, 4, 3, '#3a3f4a');
      px(4, 6, '#9aa3b8'); px(11, 6, '#9aa3b8');
    }
    return true;
  }

  // 6. Cartography Table (`cartography_table`, `cartography_table_top`, `cartography_table_front`, `cartography_table_side`)
  if (name.startsWith('cartography_table')) {
    const dk = PLANK_SPECS.dark_oak;
    drawPlanksTile('dark_oak_planks', ctx);
    if (name === 'cartography_table_top') {
      r(0, 0, 16, 2, dk.dark); r(0, 14, 16, 2, dk.dark); r(0, 0, 2, 16, dk.dark); r(14, 0, 2, 16, dk.dark);
      // Golden parchment world map (2..11, 2..13) + brass compass (11..13, 10..13)
      r(2, 2, 11, 12, '#d9c796');
      r(3, 3, 9, 10, '#ebe0b8');
      // Painted continents & ocean on map
      r(4, 4, 4, 3, '#6aa348'); r(7, 6, 4, 4, '#528c3a'); r(4, 8, 3, 3, '#4682b5');
      // Brass compass rose
      r(10, 9, 4, 4, '#c99e32'); r(11, 10, 2, 2, '#f5d76e'); px(11, 10, '#d9382e');
      return true;
    }
    r(0, 0, 16, 2, dk.light); r(0, 2, 16, 1, '#d9c796'); // Map parchment edge peeking out
    r(0, 3, 2, 13, dk.dark); r(14, 3, 2, 13, dk.dark);
    if (name === 'cartography_table_front' || name === 'cartography_table') {
      // Mini terrestrial globe + rolled map scrolls in cubby
      r(3, 5, 5, 6, '#1c1208');
      r(4, 6, 3, 3, '#3b78a8'); px(5, 6, '#6aa348'); px(4, 7, '#6aa348');
      r(5, 9, 1, 2, '#c99e32');
      r(9, 5, 4, 7, '#1c1208');
      r(10, 6, 2, 5, '#e6d6a8'); px(10, 8, '#b5382e');
    } else {
      // Map drawers with brass pulls
      for (const dy of [5, 10]) {
        r(3, dy, 10, 4, dk.dark);
        r(4, dy + 1, 8, 2, dk.midDark);
        r(7, dy + 1, 2, 1, '#e6c24c');
      }
    }
    return true;
  }

  // 7. Fletching Table (`fletching_table`, `fletching_table_top`, `fletching_table_front`, `fletching_table_side`)
  if (name.startsWith('fletching_table')) {
    const bi = PLANK_SPECS.birch;
    drawPlanksTile('birch_planks', ctx);
    if (name === 'fletching_table_top') {
      r(0, 0, 16, 2, bi.shadow); r(0, 14, 16, 2, bi.shadow); r(0, 0, 2, 16, bi.shadow); r(14, 0, 2, 16, bi.shadow);
      r(2, 2, 12, 12, bi.light);
      // Flint arrowheads + white feathers + arrow shaft laid out on worktop
      r(3, 3, 3, 3, '#4a4e52'); px(3, 3, '#7d848a');
      for (let i = 0; i < 7; i++) px(5 + i, 5 + i, '#85673f');
      r(10, 10, 3, 2, '#f5f5f0'); r(10, 11, 2, 2, '#d9d9d2');
      r(10, 3, 3, 3, '#b83c34'); px(11, 4, '#f5f5f0');
      return true;
    }
    r(0, 0, 16, 2, bi.highlight); r(0, 2, 16, 1, bi.dark);
    if (name === 'fletching_table_front' || name === 'fletching_table') {
      // Red & white bullseye archery target + hanging bow/quiver
      r(3, 4, 7, 7, '#f2efe6');
      r(4, 5, 5, 5, '#c9382e');
      r(5, 6, 3, 3, '#f2efe6');
      px(6, 7, '#c9382e');
      // Quiver & arrows on right (x=11..13)
      r(11, 5, 2, 7, '#7a5230'); r(11, 4, 2, 2, '#f5f5f0');
    } else {
      // Hanging feathered arrows & bowstring
      r(3, 5, 10, 8, bi.shadow);
      r(4, 6, 8, 6, bi.midDark);
      r(5, 7, 6, 1, '#7a5230'); r(4, 7, 2, 1, '#545b5e'); r(10, 6, 2, 3, '#f5f5f0');
    }
    return true;
  }

  // 8. Note Block & Jukebox (`note_block`, `jukebox_side`, `jukebox_top`)
  if (name === 'note_block' || name === 'jukebox_side' || name === 'jukebox_top') {
    // Rich mahogany acoustic diamond-weave speaker grille with wood-grain shimmer
    r(0, 0, 16, 16, '#3d2210');
    r(1, 1, 14, 14, '#6e4427');
    for (let y = 2; y < 14; y++) {
      for (let x = 2; x < 14; x++) {
        const d = Math.abs(x - 7.5) + Math.abs(y - 7.5);
        const checker = (x + y) & 1;
        const base = checker === 0
          ? (d < 3.5 ? '#a36a40' : d < 6.5 ? '#8a5632' : '#734526')
          : (d < 3.5 ? '#523018' : d < 6.5 ? '#3d2210' : '#2b170a');
        const shimmer = (((x * 5 + y * 9) % 5) - 2) * 3;
        px(x, y, shadeHex(base, shimmer));
      }
    }
    // Mitered mahogany outer frame with inner gold-amber fillet
    r(0, 0, 16, 1, '#99623b'); r(0, 0, 1, 16, '#99623b');
    r(0, 15, 16, 1, '#261409'); r(15, 0, 1, 16, '#261409');
    r(1, 1, 14, 1, '#b5794e'); r(1, 14, 14, 1, '#422512');
    if (name === 'jukebox_top') {
      // Record slot with diamond jewel inlay border
      r(3, 5, 10, 6, '#422512');
      r(4, 6, 8, 4, '#2b170a');
      r(4, 7, 8, 2, '#121014');
      px(3, 7, '#58cfc4'); px(12, 7, '#58cfc4');
      px(7, 5, '#8cf5eb'); px(8, 5, '#58cfc4');
      px(7, 10, '#3aa69c'); px(8, 10, '#3aa69c');
    } else if (name === 'note_block') {
      // Warm acoustic brass-wood resonator rosette in center (no black hole!)
      r(6, 6, 4, 4, '#59351c');
      r(7, 7, 2, 2, '#bf8352');
      px(7, 7, '#dba06d');
    }
    return true;
  }

  // 9. Beehive & Bee Nest (`beehive*`, `bee_nest*`)
  if (name.startsWith('beehive')) {
    const oak = PLANK_SPECS.oak;
    drawPlanksTile('oak_planks', ctx);
    if (name === 'beehive_top') {
      r(0, 0, 16, 2, oak.dark); r(0, 14, 16, 2, oak.dark); r(0, 0, 2, 16, oak.dark); r(14, 0, 2, 16, oak.dark);
      for (let y = 3; y < 14; y += 2) {
        r(2, y, 12, 1, oak.highlight);
        r(2, y + 1, 12, 1, oak.shadow);
      }
      return true;
    }
    r(0, 0, 16, 2, oak.dark); r(0, 14, 16, 2, oak.dark);
    r(0, 2, 16, 1, oak.highlight); r(0, 13, 16, 1, oak.shadow);
    if (name === 'beehive_front') {
      // Rectangular bee entrance slot + golden honey drips ONLY on front face
      r(4, 6, 8, 3, '#1f1409');
      r(5, 5, 6, 1, oak.dark);
      r(5, 9, 3, 2, '#f2b632'); r(6, 11, 1, 1, '#ffd45c');
      r(9, 9, 2, 1, '#e09e24');
    } else {
      // Side joints for beehive box supers
      r(0, 7, 16, 1, oak.dark); r(0, 8, 16, 1, oak.highlight);
    }
    return true;
  }

  if (name.startsWith('bee_nest')) {
    // Natural striped golden-amber wax comb
    for (let y = 0; y < 16; y++) {
      const band = (y >> 1) % 3;
      const base = band === 0 ? '#dba535' : band === 1 ? '#b87f24' : '#8f5b18';
      for (let x = 0; x < 16; x++) {
        const hexShift = ((x + (y & 1) * 2) % 4 === 0) ? -14 : ((x + y) % 3 === 0) ? 12 : (((x * 5 + y * 7) % 5) - 2) * 3;
        px(x, y, shadeHex(base, hexShift));
      }
    }
    if (name === 'bee_nest_top') {
      for (let y = 2; y < 14; y += 3) {
        for (let x = (y % 2) + 2; x < 14; x += 3) {
          r(x, y, 2, 2, '#734610');
          px(x, y, '#f5c84c');
        }
      }
      return true;
    }
    if (name === 'bee_nest_front') {
      // Entrance hole ONLY on front face
      r(5, 6, 6, 4, '#241506');
      r(6, 5, 4, 6, '#170d03');
      r(6, 11, 3, 2, '#f5b82e'); px(7, 11, '#ffe070');
    } else {
      // Side honeycomb cells
      for (const [cx, cy] of [[3, 4], [10, 3], [5, 10], [11, 11]]) {
        r(cx, cy, 2, 2, '#6e420e'); px(cx, cy, '#f2c444');
      }
    }
    return true;
  }

  // 10. Composter (`composter`, `composter_side`, `composter_top`, `composter_bottom`)
  if (name.startsWith('composter')) {
    const oak = PLANK_SPECS.oak;
    r(0, 0, 16, 16, '#382410');
    for (let y = 0; y < 16; y += 4) {
      for (let x = 0; x < 16; x++) {
        const g = (((x * 7 + y * 5) % 5) - 2) * 3;
        px(x, y, shadeHex(oak.highlight, g));
        px(x, y + 1, shadeHex(oak.base, g));
        px(x, y + 2, shadeHex(oak.shadow, g));
        px(x, y + 3, '#241608');
      }
    }
    // Vertical dark timber corner posts
    for (let y = 0; y < 16; y++) {
      const g = ((y * 5) % 5 - 2) * 2;
      px(0, y, shadeHex('#4a3016', g)); px(1, y, shadeHex('#75502b', g));
      px(14, y, shadeHex('#75502b', g)); px(15, y, shadeHex('#4a3016', g));
    }
    return true;
  }

  // 11. Scaffolding (`scaffolding`, `scaffolding_top`, `scaffolding_side`, `scaffolding_bottom`)
  if (name.startsWith('scaffolding')) {
    ctx.clearRect(0, 0, 16, 16);
    const bamDk = '#8a6d38', bamMd = '#bfa05c', bamLt = '#d9bc75', bamHi = '#ede39c';
    if (name === 'scaffolding_top' || name === 'scaffolding_bottom') {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const weave = ((x >> 1) + (y >> 1)) & 1;
          const g = (((x * 5 + y * 7) % 5) - 2) * 3;
          px(x, y, shadeHex(weave ? bamLt : bamMd, g));
        }
      }
      for (let i = 2; i < 14; i += 3) {
        r(i, 2, 1, 12, bamHi); r(2, i, 12, 1, bamDk);
      }
      r(0, 0, 16, 2, bamDk); r(0, 14, 16, 2, bamDk); r(0, 0, 2, 16, bamDk); r(14, 0, 2, 16, bamDk);
      r(1, 1, 14, 1, bamHi); r(1, 1, 1, 14, bamHi);
      return true;
    }
    // scaffolding_side: top bamboo platform + corner bamboo poles + diagonal string brace
    for (let x = 0; x < 16; x++) {
      const g = ((x * 5) % 5 - 2) * 3;
      px(x, 0, shadeHex(bamHi, g));
      px(x, 1, shadeHex(bamMd, g));
      px(x, 2, shadeHex(bamDk, g));
    }
    for (let y = 0; y < 16; y++) {
      const node = (y % 5 === 0) ? -10 : ((y * 7) % 5 - 2) * 3;
      px(0, y, shadeHex(bamHi, node)); px(1, y, shadeHex(bamMd, node));
      px(14, y, shadeHex(bamMd, node)); px(15, y, shadeHex(bamDk, node));
    }
    for (let i = 2; i < 14; i++) {
      px(i, i + 1, shadeHex(bamLt, (i % 3 - 1) * 4));
      px(15 - i, i + 1, shadeHex(bamDk, (i % 3 - 1) * 4));
    }
    return true;
  }

  // 12. Campfire, Soul Campfire, Unlit Campfire (`campfire*`, `soul_campfire*`, `unlit_campfire*`)
  if (name.startsWith('campfire') || name.startsWith('soul_campfire') || name.startsWith('unlit_campfire')) {
    const spec = LOG_SPECS.oak;
    const isSoul = name.startsWith('soul_');
    const isUnlit = name.startsWith('unlit_');
    if (name.endsWith('_top')) {
      r(0, 0, 16, 16, '#1c1612');
      for (const [lx, ly, lw, lh] of [[1, 1, 14, 4], [1, 11, 14, 4], [1, 1, 4, 14], [11, 1, 4, 14]]) {
        for (let y = ly; y < ly + lh; y++) {
          for (let x = lx; x < lx + lw; x++) {
            const g = (((x * 5 + y * 7) % 5) - 2) * 4;
            px(x, y, shadeHex(spec.barkMid, g));
          }
        }
        r(lx, ly, lw, 1, spec.barkLight);
        r(lx, ly + lh - 1, lw, 1, spec.barkDark);
      }
      for (let y = 5; y < 11; y++) {
        for (let x = 5; x < 11; x++) {
          const d = Math.hypot(x - 7.5, y - 7.5);
          const n = ((x * 3 + y * 5) % 3 - 1) * 5;
          if (isUnlit) {
            px(x, y, shadeHex(((x + y) & 1) ? '#2b2826' : '#3d3835', n));
          } else if (isSoul) {
            px(x, y, shadeHex(d < 1.8 ? '#c4ffff' : d < 3.0 ? '#4ad9e8' : '#1f7a8c', n));
          } else {
            px(x, y, shadeHex(d < 1.8 ? '#fff2a6' : d < 3.0 ? '#ff9924' : '#b83c14', n));
          }
        }
      }
      return true;
    }
    // Side/Flame sprite (`campfire`, `soul_campfire`, `unlit_campfire`)
    ctx.clearRect(0, 0, 16, 16);
    for (let y = 11; y < 16; y++) {
      for (let x = 1; x < 15; x++) {
        const g = (((x * 7 + y * 5) % 5) - 2) * 4;
        px(x, y, shadeHex(y === 11 ? spec.barkHighlight : y === 15 ? spec.barkDark : spec.barkMid, g));
      }
    }
    for (const kx of [2, 11]) {
      r(kx, 10, 3, 3, spec.sapwood);
      px(kx, 10, spec.ring1);
      r(kx + 1, 11, 1, 1, spec.core);
    }
    if (!isUnlit) {
      const cOuter = isSoul ? '#1f8ca3' : '#c93b14';
      const cMid = isSoul ? '#3bd6e6' : '#f27d16';
      const cInner = isSoul ? '#8cf5ff' : '#ffcf38';
      const cCore = isSoul ? '#e6ffff' : '#ffffcc';
      for (let y = 3; y < 11; y++) {
        for (let x = 4; x < 12; x++) {
          const dx = Math.abs(x - 7.5), dy = 11 - y;
          if (dx * 1.6 + dy * 0.45 > 6.2) continue;
          const col = dx < 1.2 && dy < 4.5 ? cCore : dx < 2.2 && dy < 6.5 ? cInner : dx < 3.2 ? cMid : cOuter;
          px(x, y, shadeHex(col, ((x * 5 + y * 3) % 3 - 1) * 6));
        }
      }
      px(6, 1, cOuter); px(9, 2, cMid); px(7, 2, cInner);
    }
    return true;
  }

  // 13. Ladder (`ladder`)
  if (name === 'ladder') {
    ctx.clearRect(0, 0, 16, 16);
    const oak = PLANK_SPECS.oak;
    for (const rx of [2, 12]) {
      for (let y = 0; y < 16; y++) {
        const g = (((y * 7 + rx) % 5) - 2) * 3;
        px(rx, y, shadeHex(oak.highlight, g));
        px(rx + 1, y, shadeHex(oak.shadow, g));
      }
    }
    for (const ry of [1, 5, 9, 13]) {
      for (let x = 1; x < 15; x++) {
        const g = (((x * 5 + ry * 3) % 5) - 2) * 3;
        px(x, ry, shadeHex(oak.highlight, g));
        px(x, ry + 1, shadeHex(oak.dark, g));
      }
      px(2, ry, '#4a3219'); px(13, ry, '#4a3219');
    }
    return true;
  }

  // 14. Smoker (`smoker_top`, `smoker_front`, `smoker_side`, `smoker_bottom`)
  if (name.startsWith('smoker_')) {
    const oakLog = LOG_SPECS.oak;
    // Stone core + 4 oak log corner pillars
    r(0, 0, 16, 16, '#6e706b');
    for (let y = 2; y < 14; y++) {
      for (let x = 2; x < 14; x++) {
        px(x, y, shadeHex('#787a74', (((x * 7 + y * 11) % 5) - 2) * 4));
      }
    }
    // Oak bark frame around all 4 edges (2px wide)
    r(0, 0, 16, 2, oakLog.barkMid); r(0, 14, 16, 2, oakLog.barkMid);
    r(0, 0, 2, 16, oakLog.barkMid); r(14, 0, 2, 16, oakLog.barkMid);
    r(0, 0, 16, 1, oakLog.barkLight); r(0, 0, 1, 16, oakLog.barkLight);
    r(0, 15, 16, 1, oakLog.barkDark); r(15, 0, 1, 16, oakLog.barkDark);
    if (name === 'smoker_top') {
      r(5, 5, 6, 6, '#2b2d2b');
      for (const gx of [6, 9]) for (const gy of [6, 9]) r(gx, gy, 1, 1, '#141614');
      return true;
    }
    if (name === 'smoker_front') {
      // Upper iron vent grate + lower glowing smoker firebox
      r(4, 3, 8, 3, '#383a38');
      for (const vx of [5, 7, 9]) r(vx, 4, 1, 1, '#171917');
      r(3, 8, 10, 6, '#242624');
      r(4, 9, 8, 4, '#141614');
      r(5, 10, 6, 3, '#d96b1c'); r(6, 11, 4, 2, '#ffb838'); r(7, 11, 2, 1, '#fff2a6');
    }
    return true;
  }

  // 15. Piston & Sticky Piston (`piston_top`, `piston_front`, `piston_side`, `sticky_piston_top`, `sticky_piston_front`, `sticky_piston_side`, `piston_head`)
  if (name.startsWith('piston_') || name.startsWith('sticky_piston_')) {
    const oak = PLANK_SPECS.oak;
    const isSticky = name.startsWith('sticky_');
    if (name.endsWith('_top') || name.endsWith('_front') || name === 'piston_head') {
      drawPlanksTile('oak_planks', ctx);
      // Outer dark wood & iron bracket bevel
      r(0, 0, 16, 1, oak.dark); r(0, 15, 16, 1, oak.dark);
      r(0, 0, 1, 16, oak.dark); r(15, 0, 1, 16, oak.dark);
      // 4 iron corner brackets with rivets
      for (const [cx, cy] of [[0, 0], [12, 0], [0, 12], [12, 12]]) {
        r(cx, cy, 4, 4, '#4c5257');
        r(cx + 1, cy + 1, 2, 2, '#8a9296');
        px(cx + 1, cy + 1, '#cfd9db');
      }
      if (isSticky) {
        // Organic glistening green slime pad in center (x=3..12, y=3..12)
        r(4, 3, 8, 10, '#4f7d34');
        r(3, 4, 10, 8, '#4f7d34');
        r(4, 4, 8, 8, '#6ca348');
        r(5, 5, 6, 6, '#84bf5c');
        r(5, 5, 3, 2, '#b0e085');
        px(6, 5, '#d9f7b5');
        px(9, 9, '#5a8c3c'); px(5, 9, '#5a8c3c');
      }
      return true;
    }
    // piston_side / sticky_piston_side: top wooden piston plate (y=0..3) + iron collar (y=4) + cobblestone housing (y=5..15)
    r(0, 0, 16, 16, '#575955');
    for (let y = 5; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const n = ((x * 7 + y * 13) % 5) - 2;
        px(x, y, shadeHex('#737570', n * 6));
      }
    }
    // Cobblestone mortar lines & central dark shaft channel
    r(0, 5, 16, 1, '#3b3d3a'); r(0, 15, 16, 1, '#3b3d3a');
    r(5, 5, 6, 9, '#2b2d2b'); r(6, 6, 4, 7, '#85673f'); r(6, 6, 1, 7, '#b8945f');
    // Top wooden piston plate (rows 0..3)
    for (let x = 0; x < 16; x++) {
      const col = (x % 4 === 0) ? oak.dark : (x % 4 === 1) ? oak.highlight : oak.base;
      r(x, 0, 1, 4, col);
    }
    r(0, 0, 16, 1, oak.highlight); r(0, 3, 16, 1, oak.dark);
    r(0, 4, 16, 1, '#26292b');
    if (isSticky) {
      r(3, 0, 10, 1, '#78b550'); r(5, 1, 6, 1, '#91cf67');
    }
    return true;
  }

  // 16. Bed (`bed_foot_top`, `bed_head_top`, `bed_head_side`, `bed_side`)
  if (name === 'bed_foot_top' || name === 'bed_head_top' || name === 'bed_head_side' || name === 'bed_side') {
    const oak = PLANK_SPECS.oak;
    ctx.clearRect(0, 0, 16, 16);
    if (name === 'bed_foot_top') {
      // Rich crimson wool blanket with woven texture & quilted border
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const weave = ((x + y) & 1) ? 4 : -4;
          const fold = (y === 4 || y === 10) ? -10 : (y === 5 || y === 11) ? 8 : 0;
          px(x, y, shadeHex('#b5332a', weave + fold));
        }
      }
      r(0, 0, 16, 1, '#852019'); r(0, 15, 16, 1, '#731a14');
      r(0, 0, 1, 16, '#852019'); r(15, 0, 1, 16, '#852019');
      r(1, 1, 14, 1, '#d4483f');
      return true;
    }
    if (name === 'bed_head_top') {
      // Oak headboard trim (y=0..1) + plump ivory pillow (y=2..10) + folded blanket cuff (y=11..15)
      r(0, 0, 16, 2, oak.dark); r(1, 0, 14, 1, oak.highlight);
      r(0, 2, 16, 14, '#9e2820');
      r(0, 11, 16, 2, '#f0ece1'); r(0, 13, 16, 1, '#cfc9b8');
      // Plump bevelled linen pillow (x=2..13, y=2..10)
      r(2, 2, 12, 8, '#dedad0');
      r(3, 3, 10, 6, '#f5f2eb');
      r(3, 3, 10, 1, '#ffffff'); r(3, 3, 1, 6, '#ffffff');
      r(3, 8, 10, 1, '#c4bfb2'); r(12, 3, 1, 6, '#c4bfb2');
      px(5, 5, '#e6e2d8'); px(10, 5, '#e6e2d8');
      return true;
    }
    // bed_head_side & bed_side (rows 6..9 mattress, rows 10..12 oak bed rail, rows 13..15 legs)
    const isHead = name === 'bed_head_side';
    for (let x = 0; x < 16; x++) {
      const g = (((x * 7) % 5) - 2) * 4;
      const topCol = isHead && x >= 2 && x <= 13 ? '#f2efe6' : '#b5332a';
      const midCol = isHead && x >= 2 && x <= 13 ? '#d6d1c4' : '#96241c';
      px(x, 6, shadeHex(topCol, 12 + g));
      px(x, 7, shadeHex(topCol, g));
      px(x, 8, shadeHex(midCol, g));
      px(x, 9, shadeHex(midCol, -14 + g));
      px(x, 10, shadeHex(oak.highlight, g));
      px(x, 11, shadeHex(oak.base, g));
      px(x, 12, shadeHex(oak.dark, g));
    }
    // Corner oak legs (x=0..2, x=13..15, y=13..15)
    r(0, 13, 3, 3, oak.dark); r(1, 13, 1, 3, oak.base);
    r(13, 13, 3, 3, oak.dark); r(14, 13, 1, 3, oak.base);
    return true;
  }

  // 17. Crafter (`crafter`, `crafter_top`, `crafter_front`, `crafter_side`)
  if (name.startsWith('crafter')) {
    const oak = PLANK_SPECS.oak;
    drawPlanksTile('oak_planks', ctx);
    if (name === 'crafter_top') {
      r(0, 0, 16, 2, '#3a3f45'); r(0, 14, 16, 2, '#3a3f45');
      r(0, 0, 2, 16, '#3a3f45'); r(14, 0, 2, 16, '#3a3f45');
      r(1, 1, 14, 1, '#7a828a'); r(1, 1, 1, 14, '#7a828a');
      // 3x3 mechanical iron-and-oak crafting grid
      for (const g of [5, 9]) {
        r(g, 2, 1, 12, '#3a3f45'); r(g + 1, 2, 1, 12, oak.highlight);
        r(2, g, 12, 1, '#3a3f45'); r(2, g + 1, 12, 1, oak.highlight);
      }
      // Redstone dust indicator accents at corners
      for (const [rx, ry] of [[2, 2], [13, 2], [2, 13], [13, 13]]) px(rx, ry, '#cf291d');
      return true;
    }
    // Front & side: heavy steel rim + oak body + mechanical drop port / gears
    r(0, 0, 16, 3, '#454b52'); r(0, 0, 16, 1, '#858e96'); r(0, 2, 16, 1, '#26292e');
    r(0, 3, 2, 13, '#3a3f45'); r(14, 3, 2, 13, '#3a3f45');
    r(0, 14, 16, 2, '#2b3036');
    if (name === 'crafter_front' || name === 'crafter') {
      r(4, 5, 8, 8, '#26292e');
      r(5, 6, 6, 6, '#141619');
      r(6, 7, 4, 4, '#3a3f45');
      r(7, 8, 2, 2, '#0d0e10');
      // Brass/redstone indicator LEDs above port
      px(5, 4, '#e6392c'); px(7, 4, '#ff6b57'); px(8, 4, '#ff6b57'); px(10, 4, '#e6392c');
    } else {
      r(4, 6, 8, 6, '#3a3f45');
      r(5, 7, 6, 4, '#687078');
      r(6, 8, 4, 2, '#cf291d');
    }
    return true;
  }

  // 18. Grindstone (`grindstone`) & Bell (`bell`)
  if (name === 'grindstone') {
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const d = Math.hypot(x - 7.5, y - 7.5);
        const ring = d < 3 ? '#5c605c' : d < 6 ? '#8f948e' : '#747873';
        const grain = (((x * 5 + y * 9) % 5) - 2) * 5;
        px(x, y, shadeHex(ring, grain));
      }
    }
    // Dark oak pivot axle in center
    r(6, 6, 4, 4, '#3c2e1d'); r(7, 7, 2, 2, '#573e24');
    return true;
  }

  // 19. Daylight Detector & Inverted Daylight Detector (`daylight_detector*`, `inverted_daylight_detector*`)
  if (name.includes('daylight_detector')) {
    const dk = PLANK_SPECS.dark_oak;
    const inv = name.startsWith('inverted_');
    if (name.endsWith('_side')) {
      // 6/16 slab side: rows 10..11 are the quartz sensor rim, rows 12..15 are the bevelled dark oak tray
      drawPlanksTile('dark_oak_planks', ctx);
      for (let x = 0; x < 16; x++) {
        const g = (((x * 5) % 5) - 2) * 4;
        px(x, 10, shadeHex(inv ? '#859ec4' : '#f2ebd4', g));
        px(x, 11, shadeHex(inv ? '#586c8c' : '#d4c9a8', g));
        px(x, 12, shadeHex(dk.highlight, g));
        px(x, 13, shadeHex(dk.base, g));
        px(x, 14, shadeHex(dk.midDark, g));
        px(x, 15, dk.dark);
      }
      r(0, 12, 2, 4, dk.dark); r(14, 12, 2, 4, dk.dark);
      return true;
    }
    // Top face: 2px dark oak frame + 3x3 bevelled quartz photo-sensor cells with subtle crystalline variation
    r(0, 0, 16, 16, dk.dark);
    r(1, 1, 14, 14, dk.base);
    r(1, 1, 14, 1, dk.highlight); r(1, 1, 1, 14, dk.highlight);
    r(2, 2, 12, 12, '#24180c');
    for (const cy of [2, 6, 10]) {
      for (const cx of [2, 6, 10]) {
        const cellBias = (((cx + cy) * 3) % 5 - 2) * 3;
        const cBase = shadeHex(inv ? '#5b7396' : '#d9ceb0', cellBias);
        const cHi = shadeHex(inv ? '#8ca8cf' : '#f7f2e1', cellBias);
        const cSh = shadeHex(inv ? '#3b4d69' : '#a89c7d', cellBias);
        r(cx, cy, 4, 4, cSh);
        r(cx, cy, 3, 3, cBase);
        r(cx, cy, 3, 1, cHi);
        r(cx, cy, 1, 3, cHi);
        px(cx + 1, cy + 1, inv ? '#b0cced' : '#ffffff');
      }
    }
    return true;
  }

  // 20. Torches & Lever (`torch`, `soul_torch`, `redstone_torch`, `unlit_redstone_torch`, `lever`)
  if (name === 'torch' || name === 'soul_torch' || name === 'redstone_torch' || name === 'unlit_redstone_torch' || name === 'lever') {
    ctx.clearRect(0, 0, 16, 16);
    const oak = PLANK_SPECS.oak;
    // Grained oak handle stick at x=7..8, y=9..15 with bevelled bark/splinter shading
    for (let y = 9; y < 16; y++) {
      const g = (((y * 7) % 5) - 2) * 5;
      px(7, y, shadeHex(oak.highlight, g));
      px(8, y, shadeHex(oak.shadow, g - 4));
    }
    if (name === 'torch' || name === 'soul_torch') {
      const soul = name === 'soul_torch';
      // Charred coal collar at y=9
      px(7, 9, '#2b2622'); px(8, 9, '#1c1815');
      // Bright ember & flame tip at y=5..8 (so y=7..8 top face is 100% glowing core!)
      r(6, 5, 4, 4, soul ? '#28a6b8' : '#e06b1b');
      r(7, 5, 2, 4, soul ? '#7cf2ff' : '#ffd24c');
      px(7, 7, '#ffffff'); px(8, 7, soul ? '#b8ffff' : '#fff099');
      px(7, 6, '#ffffff');
      return true;
    }
    if (name === 'redstone_torch' || name === 'unlit_redstone_torch') {
      const lit = name === 'redstone_torch';
      // Redstone crystal head at y=5..8 (so y=7..8 top face is glowing redstone!)
      r(6, 5, 4, 4, lit ? '#b81d14' : '#4a1b16');
      r(7, 5, 2, 4, lit ? '#ff4236' : '#732b24');
      px(7, 7, lit ? '#ffd4c4' : '#964239');
      px(8, 7, lit ? '#ff8570' : '#5c201a');
      px(7, 6, lit ? '#ffffff' : '#ad5247');
      return true;
    }
    if (name === 'lever') {
      r(4, 13, 8, 3, '#686b66'); r(4, 13, 8, 1, '#8f948d'); r(5, 14, 6, 2, '#4d4f4b');
      r(6, 6, 4, 3, '#5a5d58'); r(7, 6, 2, 3, '#9ea39c');
      px(7, 7, '#cfd4cd');
      return true;
    }
  }

  if (name === 'bell') {
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const spec = x < 5 ? 18 : x > 11 ? -18 : 0;
        const band = (y === 3 || y === 12) ? 16 : (y === 4 || y === 13) ? -14 : 0;
        const n = (((x * 7 + y * 11) % 5) - 2) * 3;
        px(x, y, shadeHex('#e0b236', spec + band + n));
      }
    }
    return true;
  }

  return false;
}