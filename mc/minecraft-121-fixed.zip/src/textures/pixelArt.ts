import { drawEnhancedLogTile, drawPlanksTile, drawLeavesTile, drawSaplingOrWoodPlantTile, drawDoorOrTrapdoorTile, drawWoodFurnitureTile } from "./woodArt";
import type { BlockDef } from '../game/data';
import type { Context2D } from './canvas';

const rgb = (hex: string): [number, number, number] => [
  Number.parseInt(hex.slice(1, 3), 16) || 0,
  Number.parseInt(hex.slice(3, 5), 16) || 0,
  Number.parseInt(hex.slice(5, 7), 16) || 0,
];

function shadeHex(hex: string, n: number): string {
  const [r, g, b] = rgb(hex.startsWith('#') ? hex : '#888888');
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v + n))).toString(16).padStart(2, '0');
  return `#${clamp(r)}${clamp(g)}${clamp(b)}`;
}

function drawGrid(ctx: Context2D, rows: string[], pal: Record<string, string>) {
  for (let y = 0; y < rows.length && y < 16; y++) {
    const row = rows[y];
    for (let x = 0; x < row.length && x < 16; x++) {
      const ch = row[x];
      if (ch === '.' || ch === ' ') continue;
      const col = pal[ch];
      if (!col) continue;
      ctx.fillStyle = col;
      ctx.fillRect(x, y, 1, 1);
    }
  }
}

export function addOutline(ctx: Context2D, outlineCol: string) {
  const img = ctx.getImageData(0, 0, 16, 16);
  const d = img.data;
  const mask = new Uint8Array(256);
  for (let i = 0; i < 256; i++) mask[i] = d[i * 4 + 3] > 20 ? 1 : 0;
  ctx.fillStyle = outlineCol;
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      if (mask[y * 16 + x]) continue;
      const n =
        (x > 0 && mask[y * 16 + x - 1]) ||
        (x < 15 && mask[y * 16 + x + 1]) ||
        (y > 0 && mask[(y - 1) * 16 + x]) ||
        (y < 15 && mask[(y + 1) * 16 + x]);
      if (n) ctx.fillRect(x, y, 1, 1);
    }
  }
}

// =====================================================================================================================
// 1. LOGS (All 12 Wood Species — Side Bark & Top Concentric Rings with Bark Rim)
// =====================================================================================================================

interface LogSpec {
  barkDark: string;
  barkMid: string;
  barkLight: string;
  barkAccent: string;
  sapwood: string;
  ring1: string;
  ring2: string;
  core: string;
  style: 'vertical' | 'birch' | 'cherry' | 'jungle' | 'acacia' | 'fungus' | 'poplar';
}

const LOG_SPECS: Record<string, LogSpec> = {
  oak: {
    barkDark: '#423019', barkMid: '#6b5130', barkLight: '#85673f', barkAccent: '#543e22',
    sapwood: '#d4b379', ring1: '#b8945f', ring2: '#9c7a48', core: '#785a32', style: 'vertical',
  },
  spruce: {
    barkDark: '#221509', barkMid: '#3b2714', barkLight: '#52381e', barkAccent: '#2e1d0e',
    sapwood: '#ba905e', ring1: '#9c7244', ring2: '#825c34', core: '#634424', style: 'vertical',
  },
  birch: {
    barkDark: '#2b2a26', barkMid: '#e3e0d5', barkLight: '#f2efe6', barkAccent: '#b8b4a6',
    sapwood: '#e2d3a8', ring1: '#cdb888', ring2: '#b59f6e', core: '#947e50', style: 'birch',
  },
  jungle: {
    barkDark: '#382a17', barkMid: '#574429', barkLight: '#735a38', barkAccent: '#4f692c',
    sapwood: '#cfa07a', ring1: '#b5845e', ring2: '#996a47', core: '#785032', style: 'jungle',
  },
  acacia: {
    barkDark: '#423e37', barkMid: '#676157', barkLight: '#827b6f', barkAccent: '#544f46',
    sapwood: '#d69469', ring1: '#ba6337', ring2: '#9c4e27', core: '#7d3b1b', style: 'acacia',
  },
  dark_oak: {
    barkDark: '#1f170e', barkMid: '#3c2e1d', barkLight: '#523f29', barkAccent: '#2b2014',
    sapwood: '#735636', ring1: '#573e24', ring2: '#422e19', core: '#2e1f10', style: 'vertical',
  },
  cherry: {
    barkDark: '#211118', barkMid: '#3b222c', barkLight: '#543340', barkAccent: '#8c6270',
    sapwood: '#f7d4da', ring1: '#e6aab4', ring2: '#cf8c98', core: '#b06c78', style: 'cherry',
  },
  mangrove: {
    barkDark: '#2e231d', barkMid: '#544339', barkLight: '#6e584b', barkAccent: '#6b362e',
    sapwood: '#b08368', ring1: '#8c3930', ring2: '#702922', core: '#541b16', style: 'vertical',
  },
  pale_oak: {
    barkDark: '#474440', barkMid: '#78736d', barkLight: '#969088', barkAccent: '#5e5a55',
    sapwood: '#f0ece3', ring1: '#dbd6cc', ring2: '#c4bfb5', core: '#a6a198', style: 'vertical',
  },
  crimson: {
    barkDark: '#2e0b16', barkMid: '#4f1628', barkLight: '#702038', barkAccent: '#cf365a',
    sapwood: '#c43658', ring1: '#942442', ring2: '#731931', core: '#4f1021', style: 'fungus',
  },
  warped: {
    barkDark: '#1f1326', barkMid: '#3a2542', barkLight: '#52355c', barkAccent: '#2ebdb2',
    sapwood: '#3cc7bc', ring1: '#28968e', ring2: '#1b6e68', core: '#124f4b', style: 'fungus',
  },
  poplar: {
    barkDark: '#4a4838', barkMid: '#c4be9b', barkLight: '#d9d3b2', barkAccent: '#7d7a60',
    sapwood: '#ebe5c5', ring1: '#d4cca6', ring2: '#bab28c', core: '#99916d', style: 'poplar',
  },
};

export function drawLogTile(name: string, ctx: Context2D, rnd: () => number): boolean {
  if (drawEnhancedLogTile(name, ctx)) return true;
  if (drawDoorOrTrapdoorTile(name, ctx)) return true;
  if (drawPlanksTile(name, ctx)) return true;
  if (drawLeavesTile(name, ctx)) return true;
  if (drawSaplingOrWoodPlantTile(name, ctx)) return true;
  if (drawWoodFurnitureTile(name, ctx)) return true;
  const isTop = name.endsWith('_log_top');
  const species = name.replace(/_log(_top)?$/, '');
  const spec = LOG_SPECS[species];
  if (!spec) return false;

  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (isTop) {
    // 1. 1px outer bark rim matching the side bark texture
    r(0, 0, 16, 16, spec.barkMid);
    for (let i = 0; i < 16; i += 2) {
      r(i, 0, 1, 1, spec.barkDark);
      r(15, i, 1, 1, spec.barkDark);
      r(15 - i, 15, 1, 1, spec.barkDark);
      r(0, 15 - i, 1, 1, spec.barkDark);
    }
    if (spec.style === 'birch') {
      for (const k of [3, 7, 12]) { r(k, 0, 2, 1, spec.barkDark); r(15, k, 1, 2, spec.barkDark); r(k, 15, 2, 1, spec.barkDark); r(0, k, 1, 2, spec.barkDark); }
    }
    // Beveled dark corners on outer bark rim
    r(0, 0, 1, 1, spec.barkDark); r(15, 0, 1, 1, spec.barkDark);
    r(0, 15, 1, 1, spec.barkDark); r(15, 15, 1, 1, spec.barkDark);

    // 2. Concentric sapwood & heartwood growth rings (1..14)
    r(1, 1, 14, 14, spec.sapwood);
    r(2, 2, 12, 12, spec.ring1);
    r(3, 3, 10, 10, spec.ring2);
    r(4, 4, 8, 8, spec.ring1);
    r(5, 5, 6, 6, spec.ring2);
    r(6, 6, 4, 4, spec.ring1);
    r(7, 7, 2, 2, spec.core);

    // Organic radial/corner ring softening so rings read as natural wood rather than flat nested squares
    const corners: [number, number, string][] = [
      [1, 1, spec.ring1], [14, 1, spec.ring1], [1, 14, spec.ring1], [14, 14, spec.ring1],
      [2, 2, spec.ring2], [13, 2, spec.ring2], [2, 13, spec.ring2], [13, 13, spec.ring2],
      [3, 3, spec.ring1], [12, 3, spec.ring1], [3, 12, spec.ring1], [12, 12, spec.ring1],
      [4, 4, spec.ring2], [11, 4, spec.ring2], [4, 11, spec.ring2], [11, 11, spec.ring2],
      [5, 5, spec.ring1], [10, 5, spec.ring1], [5, 10, spec.ring1], [10, 10, spec.ring1],
    ];
    for (const [cx, cy, ccol] of corners) r(cx, cy, 1, 1, ccol);
    // Subtle grain highlights along sapwood & heartwood
    r(2, 1, 4, 1, shadeHex(spec.sapwood, 14));
    r(1, 3, 1, 4, shadeHex(spec.sapwood, 14));
    r(6, 4, 3, 1, shadeHex(spec.ring1, 12));
    r(4, 7, 1, 3, shadeHex(spec.ring1, 12));
    r(8, 7, 1, 1, shadeHex(spec.core, -16));
    return true;
  }

  // Side Bark (`<species>_log`)
  if (spec.style === 'birch' || spec.style === 'poplar') {
    r(0, 0, 16, 16, spec.barkMid);
    // Subtle papery horizontal shading bands
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const n = (x * 7 + y * 13) % 11;
        if (n === 0) r(x, y, 1, 1, spec.barkLight);
        else if (n === 1 || n === 2) r(x, y, 1, 1, spec.barkAccent);
      }
    }
    // Authentic horizontal birch lenticel scars & dark knots
    const marks: [number, number, number][] = [
      [1, 2, 4], [10, 1, 3], [5, 5, 5], [13, 6, 3],
      [0, 9, 3], [7, 8, 4], [3, 12, 5], [11, 13, 4], [6, 15, 3],
    ];
    for (const [mx, my, mw] of marks) {
      r(mx, my, mw, 1, spec.barkDark);
      r((mx + 1) % 16, (my + 1) % 16, Math.max(1, mw - 2), 1, '#57544c');
      if (mx > 0) r(mx - 1, my, 1, 1, '#7a766b');
      if (mx + mw < 16) r(mx + mw, my, 1, 1, '#7a766b');
    }
    return true;
  }

  if (spec.style === 'cherry') {
    r(0, 0, 16, 16, spec.barkMid);
    // Vertical dark maroon fissures
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const colType = (x + (y >> 2)) % 4;
        if (colType === 0) r(x, y, 1, 1, spec.barkDark);
        else if (colType === 2) r(x, y, 1, 1, spec.barkLight);
      }
    }
    // Signature horizontal dusty-rose cherry bark lenticel stripes
    const bands: [number, number, number][] = [
      [2, 2, 4], [9, 3, 5], [1, 6, 3], [6, 8, 5], [12, 7, 3],
      [3, 11, 4], [10, 12, 4], [0, 14, 3], [7, 15, 4],
    ];
    for (const [bx, by, bw] of bands) {
      r(bx, by, bw, 1, spec.barkAccent);
      r(bx + 1, by, Math.max(1, bw - 2), 1, shadeHex(spec.barkAccent, 22));
      r(bx, (by + 1) % 16, bw, 1, spec.barkDark);
    }
    return true;
  }

  if (spec.style === 'jungle') {
    r(0, 0, 16, 16, spec.barkMid);
    // Jungle bark has horizontal-leaning ridges + mossy green patches
    for (let y = 0; y < 16; y++) {
      const rowCol = y % 4 === 0 ? spec.barkDark : y % 4 === 1 ? spec.barkLight : spec.barkMid;
      r(0, y, 16, 1, rowCol);
      for (let x = 0; x < 16; x += 4) {
        r((x + (y >> 1)) % 16, y, 1, 1, spec.barkDark);
        r((x + 2 + (y >> 1)) % 16, y, 1, 1, spec.barkLight);
      }
    }
    const moss: [number, number, number, number][] = [[2, 3, 3, 2], [10, 6, 4, 2], [4, 11, 3, 2], [12, 13, 3, 2]];
    for (const [mx, my, mw, mh] of moss) {
      r(mx, my, mw, mh, spec.barkAccent);
      r(mx + 1, my, 1, 1, shadeHex(spec.barkAccent, 18));
    }
    return true;
  }

  if (spec.style === 'acacia') {
    r(0, 0, 16, 16, spec.barkMid);
    for (let x = 0; x < 16; x += 4) {
      for (let y = 0; y < 16; y++) {
        const shift = ((y + x) >> 2) & 1;
        const fx = (x + shift) & 15;
        r(fx, y, 1, 1, spec.barkDark);
        r((fx + 1) & 15, y, 1, 1, y % 5 === 0 ? spec.barkMid : spec.barkLight);
        r((fx + 2) & 15, y, 1, 1, y % 3 === 0 ? spec.barkLight : spec.barkMid);
        r((fx + 3) & 15, y, 1, 1, spec.barkAccent);
      }
    }
    r(4, 4, 2, 3, spec.barkDark); r(5, 5, 1, 1, spec.barkLight);
    r(11, 10, 2, 3, spec.barkDark); r(12, 11, 1, 1, spec.barkLight);
    return true;
  }

  if (spec.style === 'fungus') {
    r(0, 0, 16, 16, spec.barkMid);
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const k = (x + (y >> 1)) % 4;
        if (k === 0) r(x, y, 1, 1, spec.barkDark);
        else if (k === 2) r(x, y, 1, 1, spec.barkLight);
      }
    }
    // Glowing wavy bioluminescent fungus veins
    for (let y = 0; y < 16; y++) {
      const vx1 = (3 + Math.round(Math.sin(y * 0.6) * 1.5)) & 15;
      const vx2 = (10 + Math.round(Math.cos(y * 0.55) * 1.5)) & 15;
      if (y % 4 !== 0) {
        r(vx1, y, 1, 1, spec.barkAccent);
        if (y % 2 === 0) r(vx1, y, 1, 1, shadeHex(spec.barkAccent, 32));
      }
      if ((y + 2) % 4 !== 0) {
        r(vx2, y, 1, 1, spec.barkAccent);
        if (y % 2 === 1) r(vx2, y, 1, 1, shadeHex(spec.barkAccent, 32));
      }
    }
    return true;
  }

  // Classic vertical fissured bark (Oak, Spruce, Dark Oak, Mangrove, Pale Oak)
  r(0, 0, 16, 16, spec.barkMid);
  // 4 organic vertical bark columns with staggered fissures and highlights
  const colOffsets = [0, 4, 8, 12];
  for (let ci = 0; ci < 4; ci++) {
    const x0 = colOffsets[ci];
    const shift = (ci * 5) % 16;
    for (let y = 0; y < 16; y++) {
      const wy = (y + shift) % 16;
      const wiggle = wy >= 6 && wy <= 10 ? 1 : 0;
      const furrowX = (x0 + wiggle) % 16;
      const ridgeX = (furrowX + 1) % 16;
      const bodyX = (furrowX + 2) % 16;
      const slopeX = (furrowX + 3) % 16;
      r(furrowX, y, 1, 1, spec.barkDark);
      r(ridgeX, y, 1, 1, wy % 5 === 0 ? spec.barkMid : spec.barkLight);
      r(bodyX, y, 1, 1, wy % 4 === 0 ? spec.barkLight : spec.barkMid);
      r(slopeX, y, 1, 1, wy % 3 === 0 ? spec.barkDark : spec.barkAccent);
    }
  }
  // Bark knots
  r(5, 4, 2, 3, spec.barkDark); r(6, 5, 1, 1, spec.barkLight);
  r(12, 11, 2, 3, spec.barkDark); r(13, 12, 1, 1, spec.barkLight);
  void rnd;
  return true;
}

// =====================================================================================================================
// 2. OBSIDIAN FAMILY (Obsidian, Crying Obsidian, Obsidian Bricks, Respawn Anchor)
// =====================================================================================================================

const OBSIDIAN_MAP = [
  '0122100134321011',
  '1343210243221023',
  '2432210132210134',
  '1322100011100232',
  '0111001233210121',
  '0000123443210010',
  '1221024332210122',
  '3432013221101343',
  '2321001110012432',
  '1210123321023321',
  '0001344321012210',
  '0122433210001100',
  '1343322100123321',
  '2432210012344321',
  '1321100124332210',
  '0110001233211000',
];

const OBSIDIAN_PAL: Record<string, string> = {
  '0': '#090611', // Deep fracture cleavage
  '1': '#140d21', // Dark volcanic glass base
  '2': '#1f1533', // Mid-dark violet obsidian
  '3': '#31214f', // Conchoidal violet facet
  '4': '#4c3678', // Sharp lavender-violet specular ridge
};

export function drawObsidianTile(name: string, ctx: Context2D): boolean {
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === 'obsidian') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // Extra crisp specular glints on top-left facet edges
    r(4, 1, 1, 1, '#634899');
    r(13, 1, 1, 1, '#634899');
    r(8, 5, 1, 1, '#634899');
    r(3, 9, 1, 1, '#634899');
    r(8, 12, 1, 1, '#634899');
    return true;
  }

  if (name === 'crying_obsidian') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // Glowing dimensional purple-magenta-cyan tears embedded in the cleavage trenches
    const tears: [number, number, number, number][] = [
      [2, 2, 2, 3], [10, 1, 2, 4], [6, 5, 3, 2],
      [1, 8, 2, 3], [12, 7, 2, 4], [5, 11, 3, 3], [10, 13, 3, 2],
    ];
    for (const [tx, ty, tw, th] of tears) {
      r(tx - 1, ty, tw + 2, th, '#4a128c');
      r(tx, ty, tw, th, '#8c30eb');
      r(tx, ty, Math.max(1, tw - 1), Math.max(1, th - 1), '#d47aff');
      r(tx, ty, 1, 1, '#f7dcff');
    }
    r(3, 3, 1, 1, '#9ef8ff');
    r(12, 8, 1, 1, '#9ef8ff');
    r(6, 12, 1, 1, '#9ef8ff');
    return true;
  }

  if (name === 'obsidian_bricks') {
    r(0, 0, 16, 16, '#090611');
    for (let row = 0; row < 4; row++) {
      const y = row * 4;
      const off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        const x0 = Math.max(0, bx + off);
        const x1 = Math.min(16, bx + off + 7);
        if (x1 <= x0) continue;
        r(x0, y + 1, x1 - x0, 3, '#1d1330');
        r(x0, y + 1, x1 - x0, 1, '#3f2b63');
        r(x0, y + 1, 1, 3, '#31214f');
        r(x0, y + 3, x1 - x0, 1, '#120b1f');
      }
    }
    return true;
  }

  if (name === 'respawn_anchor_top') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // Recessed octagonal obsidian bezel with crying-obsidian corner runes & swirling portal vortex
    r(0, 0, 16, 1, '#3f2b63'); r(0, 0, 1, 16, '#3f2b63');
    r(0, 15, 16, 1, '#06040b'); r(15, 0, 1, 16, '#06040b');
    r(2, 2, 12, 12, '#08050f');
    // 4 Corner crying-obsidian gems
    for (const [cx, cy] of [[1, 1], [12, 1], [1, 12], [12, 12]]) {
      r(cx, cy, 3, 3, '#4a128c');
      r(cx + 1, cy + 1, 2, 2, '#9b3ff5');
      r(cx + 1, cy + 1, 1, 1, '#f0b8ff');
    }
    // Inner recessed portal basin with spiral vortex rings
    r(3, 3, 10, 10, '#210c42');
    r(4, 3, 8, 10, '#3b1470'); r(3, 4, 10, 8, '#3b1470');
    r(4, 4, 8, 8, '#6a1fb8');
    r(5, 4, 6, 8, '#9638eb'); r(4, 5, 8, 6, '#9638eb');
    r(5, 5, 6, 6, '#c964ff');
    // Golden-violet dimensional energy swirl inside the vortex
    r(5, 6, 2, 2, '#f5a638'); r(9, 8, 2, 2, '#f5a638');
    r(6, 5, 2, 2, '#ffd86b'); r(8, 9, 2, 2, '#ffd86b');
    r(6, 6, 4, 4, '#f2b8ff');
    r(7, 7, 2, 2, '#ffffff');
    return true;
  }

  if (name === 'respawn_anchor_side') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // Heavy obsidian cornice & base plinth
    r(0, 0, 16, 2, '#281b40'); r(0, 0, 16, 1, '#4c3678');
    r(0, 2, 16, 5, '#07040d');
    r(0, 7, 16, 1, '#3f2b63');
    r(0, 15, 16, 1, '#06040b');
    // 4 Glowing golden charge-dial cells in the upper band
    for (const cx of [1, 5, 9, 13]) {
      r(cx, 3, 2, 3, '#8c4f0e');
      r(cx, 3, 2, 2, '#eb9e28');
      r(cx, 3, 1, 2, '#ffdf6b');
      r(cx, 3, 1, 1, '#fffbd6');
    }
    // Twin recessed gothic crying-obsidian arches in the lower body
    for (const ax of [1, 9]) {
      r(ax, 8, 6, 7, '#07040d');
      r(ax + 1, 8, 4, 1, '#31214f');
      r(ax + 1, 9, 4, 6, '#4a128c');
      r(ax + 2, 9, 2, 6, '#8c30eb');
      r(ax + 2, 10, 2, 4, '#d47aff');
      r(ax + 2, 11, 1, 2, '#9ef8ff');
      r(ax + 3, 10, 1, 1, '#ffffff');
    }
    return true;
  }

  return false;
}

// =====================================================================================================================
// 3. CHEST FAMILY (Chest, Trapped Chest, Ender Chest — Top, Bottom, Side, Front)
// =====================================================================================================================

export function drawChestTile(name: string, ctx: Context2D): boolean {
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === 'chest_top' || name === 'chest_bottom') {
    // Authentic warm golden-ochre oak chest lid top with dark timber border, wood grain & recessed panel
    r(0, 0, 16, 16, '#2b1b0b');
    r(1, 1, 14, 14, '#4a3014');
    r(2, 2, 12, 12, '#c79142');
    r(2, 2, 12, 1, '#dba656');
    r(2, 2, 1, 12, '#dba656');
    r(2, 13, 12, 1, '#8f6322');
    r(13, 2, 1, 12, '#8f6322');
    for (let y = 3; y < 13; y++) {
      for (let x = 3; x < 13; x++) {
        const g = (((x * 5 + y * 9) % 5) - 2) * 4;
        const seam = (y === 6 || y === 9) ? -10 : 0;
        r(x, y, 1, 1, shadeHex('#b57f32', g + seam));
      }
    }
    // Corner iron/dark-wood studs
    r(1, 1, 2, 2, '#241608'); r(13, 1, 2, 2, '#241608');
    r(1, 13, 2, 2, '#241608'); r(13, 13, 2, 2, '#241608');
    return true;
  }

  if (name === 'chest_side' || name === 'chest_front' || name === 'trapped_chest_front') {
    // Unified lid (rows 0..4), dark seam (row 5), lower box (rows 6..15)
    r(0, 0, 16, 16, '#2b1b0b');
    // Lid panel (rows 1..4)
    r(1, 1, 14, 4, '#4a3014');
    r(2, 1, 12, 4, '#c28b3b');
    r(2, 1, 12, 1, '#dba656');
    r(2, 4, 12, 1, '#8f6322');
    for (let y = 2; y < 4; y++) {
      for (let x = 3; x < 13; x++) {
        r(x, y, 1, 1, shadeHex('#b57f32', (((x * 7 + y * 5) % 5) - 2) * 4));
      }
    }
    // Crisp 1px lid-opening seam across all 4 faces at row 5
    r(0, 5, 16, 1, '#1a1006');
    // Lower chest box (rows 6..14)
    r(1, 6, 14, 9, '#4a3014');
    r(2, 6, 12, 9, '#b57f32');
    r(2, 6, 12, 1, '#d49d4c');
    r(2, 14, 12, 1, '#7d541b');
    r(2, 6, 1, 9, '#c79142');
    r(13, 6, 1, 9, '#8c6020');
    for (let y = 7; y < 14; y++) {
      for (let x = 3; x < 13; x++) {
        const g = (((x * 5 + y * 11) % 5) - 2) * 4;
        const seam = (y === 9 || y === 12) ? -10 : 0;
        r(x, y, 1, 1, shadeHex('#b57f32', g + seam));
      }
    }

    if (name === 'trapped_chest_front') {
      // Iconic redstone trap stain ring around the front latch
      r(5, 3, 6, 7, '#9e1e16');
      r(6, 3, 4, 7, '#d93226');
      r(5, 4, 6, 5, '#c4281e');
    }
    if (name === 'chest_front' || name === 'trapped_chest_front') {
      // 3D-shaded silver lock plate spanning the lid seam (x=6..9, y=4..8)
      r(6, 4, 4, 5, '#1f2426');
      r(7, 4, 2, 4, '#cfd9db');
      r(7, 4, 2, 1, '#ffffff');
      r(7, 7, 2, 1, '#7d878a');
      r(7, 5, 2, 1, '#e3eded');
      r(7, 6, 1, 1, '#384042'); // Keyhole slot
    }
    return true;
  }

  if (name === 'ender_chest_top' || name === 'ender_chest_bottom') {
    r(0, 0, 16, 16, '#081012');
    r(1, 1, 14, 14, '#122226');
    r(2, 2, 12, 12, '#1c343a');
    r(2, 2, 12, 1, '#2d5059');
    r(2, 2, 1, 12, '#2d5059');
    r(3, 3, 10, 10, '#15282d');
    if (name === 'ender_chest_top') {
      r(4, 4, 8, 8, '#0d1b1f');
      r(5, 5, 6, 6, '#193036');
      r(6, 6, 4, 4, '#24444d');
      r(7, 7, 2, 2, '#32786a');
      r(4, 4, 8, 1, '#26434c');
      r(4, 4, 1, 8, '#26434c');
    }
    return true;
  }

  if (name === 'ender_chest_side' || name === 'ender_chest_front') {
    r(0, 0, 16, 16, '#081012');
    // Ribbed dark obsidian-teal lid (rows 1..4)
    r(1, 1, 14, 4, '#122226');
    r(2, 1, 12, 4, '#1e363d');
    r(2, 1, 12, 1, '#325661');
    r(3, 2, 10, 2, '#16292e');
    // Lid seam at row 5
    r(0, 5, 16, 1, '#050a0c');
    // Lower obsidian vault box (rows 6..14) with vertical obsidian ribs
    r(1, 6, 14, 9, '#122226');
    r(2, 6, 12, 9, '#1c333a');
    r(2, 6, 12, 1, '#2e515c');
    for (let x = 3; x < 13; x += 2) {
      r(x, 7, 1, 7, '#132429');
      r(x + 1, 7, 1, 7, '#26434c');
    }
    // Subtle glowing ender particles on the dark stone
    r(4, 9, 1, 1, '#4ad9b5');
    r(11, 12, 1, 1, '#4ad9b5');
    if (name === 'ender_chest_front') {
      // Golden-emerald Eye of Ender lock latch
      r(6, 4, 4, 5, '#141f1c');
      r(7, 4, 2, 4, '#e8c444');
      r(7, 4, 2, 1, '#fff099');
      r(7, 7, 2, 1, '#9e7b1b');
      r(7, 5, 2, 2, '#38cf82');
      r(7, 5, 1, 1, '#a8ffe0');
    }
    return true;
  }

  return false;
}

// =====================================================================================================================
// 4. ALL 2D ITEM REPRESENTATIONS (Tools, Weapons, Armor, Ingots, Gems, Ores, Foods, Potions, Buckets, Misc)
// =====================================================================================================================

const SWORD_MAP = [
  '.............OO.',
  '............OHLO',
  '...........OHBLO',
  '..........OHBGLO',
  '.........OHBGLO.',
  '........OHBGLO..',
  '.......OHBGLO...',
  '....OO.OHBGLO...',
  '....OGOHBGLO....',
  '.....OGBGLO.....',
  '....OWGGLO......',
  '...OSWGOO.......',
  '..OSWO..OO......',
  '.OPSO...O.......',
  '.OPO............',
  '................',
];

const PICKAXE_MAP = [
  '.......OOOOO....',
  '.....OOHHHHBO...',
  '....OHBBBBGBLO..',
  '...OHBGOOOWGBLO.',
  '...OHGO..OSWGBLO',
  '...OOO..OSWOBBLO',
  '.......OSWO.OBLO',
  '......OSWO..OBLO',
  '.....OSWO...OBLO',
  '....OSWO....OBO.',
  '...OSWO.....OO..',
  '..OSWO..........',
  '.OSWO...........',
  'OSWO............',
  'OSO.............',
  '................',
];

const AXE_MAP = [
  '......OOOOO.....',
  '.....OHHHHBO....',
  '....OHBBBBGLO...',
  '....OHBBBGBWLO..',
  '....OHBBGOWGBLO.',
  '.....OHGOOSWGLO.',
  '......OO.OSWO.O.',
  '........OSWO....',
  '.......OSWO.....',
  '......OSWO......',
  '.....OSWO.......',
  '....OSWO........',
  '...OSWO.........',
  '..OSWO..........',
  '.OSO............',
  '................',
];

const SHOVEL_MAP = [
  '..........OOOO..',
  '.........OHHHBO.',
  '........OHBBBGLO',
  '........OHBBGGLO',
  '........OHBGGBLO',
  '........OOWGBLO.',
  '........OSWOO...',
  '.......OSWO.....',
  '......OSWO......',
  '.....OSWO.......',
  '....OSWO........',
  '...OSWO.........',
  '..OSWO..........',
  '.OSWO...........',
  '.OSO............',
  '................',
];

const HOE_MAP = [
  '.....OOOOOOO....',
  '....OHHHHHHBO...',
  '....OHBBBBGBLO..',
  '....OHOOOOWGBO..',
  '.........OSWOO..',
  '........OSWO....',
  '.......OSWO.....',
  '......OSWO......',
  '.....OSWO.......',
  '....OSWO........',
  '...OSWO.........',
  '..OSWO..........',
  '.OSWO...........',
  'OSWO............',
  'OSO.............',
  '................',
];

const HELMET_MAP = [
  '................',
  '....OOOOOOOO....',
  '...OHHHHHHHBO...',
  '..OHBBBBBBBBGO..',
  '..OHBBBBBBBBGO..',
  '..OHBBOOOOBBGO..',
  '..OHBO.OO.OBGO..',
  '..OBGO.OO.OGGO..',
  '..OBGO....OGGO..',
  '..OGGO....OGGO..',
  '...OO......OO...',
  '................',
  '................',
  '................',
  '................',
  '................',
];

const CHESTPLATE_MAP = [
  '................',
  '.OOOO......OOOO.',
  'OHHHBO....OBHHHO',
  'OHBBBGO..OGBBBHO',
  'OHBBBBGOOGBBBBHO',
  'OHBBBBBBBBBBBBHO',
  '.OOBBBBBBBBBBGO.',
  '..OHBBBBBBBBGO..',
  '..OHBBBGGGBBGO..',
  '..OHBBBGGGBBGO..',
  '..OHBBBBBBBBGO..',
  '..OBGGGGGGGGGO..',
  '...OOOOOOOOOO...',
  '................',
  '................',
  '................',
];

const LEGGINGS_MAP = [
  '................',
  '...OOOOOOOOOO...',
  '..OHHHHHHHHHGO..',
  '..OHBBBOOBBBGO..',
  '..OGGGGGGGGGGO..',
  '..OHBBO..OBBGO..',
  '..OHBBO..OBBGO..',
  '..OHBBO..OBBGO..',
  '..OHHGO..OHHGO..',
  '..OHBBO..OBBGO..',
  '..OHBBO..OBBGO..',
  '..OBGGO..OGGGO..',
  '..OOOO....OOOO..',
  '................',
  '................',
  '................',
];

const BOOTS_MAP = [
  '................',
  '................',
  '................',
  '................',
  '................',
  '..OOOO....OOOO..',
  '..OHHBO..OBHHO..',
  '..OHBBO..OBBHO..',
  '..OHBBO..OBBHO..',
  '.OOHBGO..OGBHOO.',
  'OHBBBGO..OGBBBHO',
  'OBGGGGO..OGGGGGO',
  'OOOOOO....OOOOOO',
  '................',
  '................',
  '................',
];

const INGOT_MAP = [
  '................',
  '................',
  '................',
  '................',
  '....OOOOOOOOO...',
  '...OHHHHHHHHBO..',
  '..OHHBBBBBBBGLO.',
  '.OHBBBBBBBBGGLO.',
  '.OBGGGGGGGGGGO..',
  '..OOOOOOOOOOO...',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
];

export function drawRefinedItem(def: BlockDef, ctx: Context2D): boolean {
  const n = def.name;
  const col = def.color;
  const r = (x: number, y: number, w: number, h: number, c: string) => {
    ctx.fillStyle = c;
    ctx.fillRect(x, y, w, h);
  };
  ctx.clearRect(0, 0, 16, 16);

  // 1. Standard Tool & Weapon Tiers (Sword, Pickaxe, Axe, Shovel, Hoe)
  if (/^(wooden|stone|copper|iron|golden|diamond|netherite)_(sword|pickaxe|axe|shovel|hoe)$/.test(n)) {
    const type = n.split('_').pop()!;
    const netherite = n.startsWith('netherite_');
    const pal: Record<string, string> = {
      O: shadeHex(col, -85),
      H: shadeHex(col, 55),
      B: col,
      G: shadeHex(col, -25),
      L: shadeHex(col, -45),
      W: netherite ? '#7a3b36' : '#b88c52',
      S: netherite ? '#4f2420' : '#7d5a30',
      P: shadeHex(col, 35),
    };
    const map =
      type === 'sword' ? SWORD_MAP :
      type === 'pickaxe' ? PICKAXE_MAP :
      type === 'axe' ? AXE_MAP :
      type === 'shovel' ? SHOVEL_MAP : HOE_MAP;
    drawGrid(ctx, map, pal);
    return true;
  }

  // 2. All Armor Pieces (Helmet, Chestplate, Leggings, Boots + Turtle Helmet + Wolf Armor)
  if (n.endsWith('_helmet') || n.endsWith('_chestplate') || n.endsWith('_leggings') || n.endsWith('_boots')) {
    const chain = n.startsWith('chainmail_');
    const pal: Record<string, string> = {
      O: shadeHex(col, -80),
      H: shadeHex(col, 48),
      B: col,
      G: shadeHex(col, -28),
    };
    const map =
      n.endsWith('_helmet') ? HELMET_MAP :
      n.endsWith('_chestplate') ? CHESTPLATE_MAP :
      n.endsWith('_leggings') ? LEGGINGS_MAP : BOOTS_MAP;
    drawGrid(ctx, map, pal);
    if (chain) {
      // Metallic ring-mail checker pattern
      for (let y = 2; y < 13; y++) {
        for (let x = 2; x < 14; x++) {
          if ((x + y) % 2 === 0 && ctx.getImageData(x, y, 1, 1).data[3] > 0) {
            r(x, y, 1, 1, shadeHex(col, -35));
          }
        }
      }
    }
    return true;
  }

  if (n === 'wolf_armor') {
    r(3, 5, 10, 6, '#9c6c5e'); r(5, 3, 6, 4, '#b88576'); r(4, 6, 8, 4, '#cf9e8f');
    r(4, 10, 2, 4, '#785045'); r(10, 10, 2, 4, '#785045');
    addOutline(ctx, '#3d251e');
    return true;
  }

  // 3. Ingots, Bricks & Smithing Upgrades
  if (n.endsWith('_ingot') || n === 'brick' || n === 'nether_brick') {
    drawGrid(ctx, INGOT_MAP, {
      O: shadeHex(col, -80),
      H: shadeHex(col, 52),
      B: col,
      G: shadeHex(col, -24),
      L: shadeHex(col, -42),
    });
    return true;
  }

  if (n === 'netherite_upgrade' || n.endsWith('_armor_trim_smithing_template')) {
    const trimCol = n === 'netherite_upgrade' ? '#f2c842' : '#58e8dc';
    const bodyCol = n === 'netherite_upgrade' ? '#632929' : '#4a5661';
    r(3, 2, 10, 12, bodyCol);
    r(4, 3, 8, 10, shadeHex(bodyCol, 18));
    r(5, 4, 6, 2, trimCol);
    r(5, 7, 2, 4, trimCol); r(9, 7, 2, 4, trimCol);
    r(6, 11, 4, 1, trimCol);
    addOutline(ctx, '#1f1924');
    return true;
  }

  if (n.endsWith('_pottery_sherd')) {
    r(4, 3, 8, 10, '#8c4c34');
    r(3, 5, 10, 6, '#9e583e');
    r(5, 4, 6, 8, '#b5694c');
    r(6, 6, 4, 4, '#703925');
    r(7, 5, 2, 6, '#cf8363');
    addOutline(ctx, '#3b1c11');
    return true;
  }

  // 4. Gems, Raw Ores, Nuggets, Shards & Dusts
  if (n === 'diamond' || n === 'emerald') {
    const em = n === 'emerald';
    if (em) {
      r(5, 2, 6, 12, '#1f9c44'); r(4, 3, 8, 10, '#2fc95a');
      r(5, 4, 6, 8, '#52e879'); r(6, 4, 2, 5, '#c4ffd2'); r(6, 4, 1, 2, '#ffffff');
      r(6, 10, 4, 2, '#177332');
      addOutline(ctx, '#0b3818');
    } else {
      r(6, 2, 4, 12, '#2ba6b0'); r(4, 3, 8, 10, '#3ecfd9'); r(3, 5, 10, 6, '#58e8f0');
      r(5, 4, 6, 6, '#82f7fc'); r(5, 4, 3, 3, '#ffffff');
      r(6, 9, 5, 3, '#208891'); r(4, 8, 3, 3, '#2caeb8');
      addOutline(ctx, '#113c42');
    }
    return true;
  }

  if (n === 'coal' || n === 'charcoal') {
    const ch = n === 'charcoal';
    r(4, 3, 8, 10, ch ? '#47392d' : '#2e3236');
    r(3, 5, 10, 7, ch ? '#382c22' : '#232629');
    r(5, 4, 4, 3, ch ? '#665343' : '#525961');
    r(6, 5, 2, 1, ch ? '#826b57' : '#78828c');
    addOutline(ctx, '#121314');
    return true;
  }

  if (n === 'raw_iron' || n === 'raw_copper' || n === 'raw_gold') {
    const acc = n === 'raw_copper' ? '#439675' : shadeHex(col, -32);
    r(4, 3, 7, 9, col);
    r(3, 6, 10, 6, shadeHex(col, -14));
    r(6, 4, 5, 5, shadeHex(col, 28));
    r(4, 8, 3, 3, acc);
    r(9, 7, 3, 3, acc);
    r(7, 4, 2, 2, '#fff5d6');
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'gold_nugget' || n === 'iron_nugget') {
    r(5, 5, 6, 6, col);
    r(6, 4, 4, 8, col);
    r(6, 5, 2, 2, '#ffffff');
    r(7, 9, 3, 2, shadeHex(col, -30));
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'lapis_lazuli' || n === 'flint' || n === 'clay_ball' || n === 'heart_of_the_sea') {
    r(4, 3, 8, 10, col);
    r(3, 5, 10, 6, col);
    r(5, 4, 4, 3, shadeHex(col, 40));
    r(6, 9, 5, 3, shadeHex(col, -28));
    if (n === 'lapis_lazuli') { r(8, 6, 2, 1, '#e6c35c'); r(5, 9, 1, 1, '#e6c35c'); }
    if (n === 'heart_of_the_sea') { r(6, 6, 4, 4, '#7cf2ff'); r(7, 7, 2, 2, '#ffffff'); }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'quartz' || n === 'amethyst_shard' || n === 'echo_shard' || n === 'prismarine_shard' || n === 'prismarine_crystals') {
    const echo = n === 'echo_shard';
    for (let i = 0; i < 9; i++) {
      r(3 + i, 11 - i, 3, 3, echo ? '#0d3b47' : col);
      r(3 + i, 11 - i, 2, 1, echo ? '#38e0f0' : shadeHex(col, 48));
    }
    r(4, 9, 3, 4, echo ? '#19697a' : shadeHex(col, -22));
    r(8, 7, 4, 3, echo ? '#19697a' : shadeHex(col, -22));
    addOutline(ctx, echo ? '#05161c' : shadeHex(col, -85));
    return true;
  }

  // Powders & Dusts (Redstone, Glowstone Dust, Sugar, Gunpowder, Blaze Powder, Bone Meal)
  if (n === 'redstone' || n === 'glowstone_dust' || n === 'sugar' || n === 'gunpowder' || n === 'blaze_powder' || n === 'bone_meal') {
    r(6, 4, 4, 3, shadeHex(col, 35));
    r(4, 6, 8, 4, col);
    r(3, 9, 10, 3, shadeHex(col, -18));
    r(2, 11, 12, 2, shadeHex(col, -32));
    r(6, 5, 2, 2, '#ffffff');
    r(5, 8, 2, 1, shadeHex(col, 25));
    r(9, 9, 2, 1, shadeHex(col, -40));
    addOutline(ctx, shadeHex(col, -90));
    return true;
  }

  // All 16 Dyes
  if (n.endsWith('_dye')) {
    r(5, 4, 6, 8, col);
    r(4, 5, 8, 6, col);
    r(5, 5, 3, 2, shadeHex(col, 42));
    r(6, 9, 5, 2, shadeHex(col, -26));
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  // 5. Seeds, Crops & Plants
  if (n.endsWith('_seeds') || n === 'pitcher_pod' || n === 'cocoa_beans') {
    if (n === 'cocoa_beans' || n === 'pitcher_pod') {
      r(5, 3, 6, 10, col); r(4, 5, 8, 6, shadeHex(col, 16)); r(6, 4, 2, 3, shadeHex(col, 38));
      addOutline(ctx, shadeHex(col, -80));
      return true;
    }
    const seeds: [number, number][] = [[3, 5], [8, 3], [11, 7], [5, 10], [9, 11], [6, 7]];
    for (const [sx, sy] of seeds) {
      r(sx, sy, 2, 3, shadeHex(col, -65));
      r(sx, sy, 2, 2, col);
      r(sx, sy, 1, 1, shadeHex(col, 40));
    }
    return true;
  }

  if (n === 'wheat') {
    for (let i = 0; i < 10; i++) {
      r(2 + i, 12 - i, 4, 3, '#c99e38');
      r(2 + i, 12 - i, 2, 2, '#f0ce62');
    }
    r(9, 2, 5, 5, '#f5dc78'); r(11, 1, 3, 3, '#fff09e');
    r(5, 7, 5, 3, '#b83c2e');
    addOutline(ctx, '#4a3510');
    return true;
  }

  // 6. All Foods (Distinct silhouettes per food item!)
  if (n === 'apple' || n === 'golden_apple' || n === 'enchanted_golden_apple') {
    const ench = n === 'enchanted_golden_apple';
    r(4, 4, 8, 9, col); r(3, 5, 10, 7, col);
    r(5, 5, 3, 3, ench ? '#f7b8ff' : shadeHex(col, 55));
    r(6, 10, 5, 2, shadeHex(col, -28));
    addOutline(ctx, ench ? '#5c1f7a' : shadeHex(col, -85));
    r(7, 1, 2, 3, '#5c3c1e');
    r(9, 2, 3, 2, '#5ca638');
    return true;
  }

  if (n === 'bread') {
    r(2, 6, 12, 6, '#c98e3e');
    r(3, 5, 10, 7, '#dba24e');
    r(4, 5, 8, 2, '#f2c474');
    r(5, 6, 1, 3, '#9e6824'); r(8, 6, 1, 3, '#9e6824'); r(11, 6, 1, 3, '#9e6824');
    r(3, 10, 10, 2, '#9e6824');
    addOutline(ctx, '#472c0e');
    return true;
  }

  if (n === 'raw_beef' || n === 'cooked_beef' || n === 'porkchop' || n === 'cooked_porkchop' || n === 'mutton' || n === 'cooked_mutton') {
    const raw = n.startsWith('raw_') || n === 'porkchop' || n === 'mutton';
    r(3, 4, 10, 8, col);
    r(2, 5, 12, 6, col);
    r(4, 5, 6, 3, shadeHex(col, 24));
    r(5, 9, 7, 2, shadeHex(col, -25));
    // Bone / fat marbling
    r(9, 6, 3, 3, raw ? '#f5ebe6' : '#e8dec8');
    r(10, 7, 1, 1, shadeHex(col, -30));
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'chicken' || n === 'cooked_chicken' || n === 'rabbit' || n === 'cooked_rabbit') {
    r(4, 4, 8, 8, col);
    r(3, 5, 9, 6, shadeHex(col, 16));
    r(5, 5, 4, 3, shadeHex(col, 36));
    r(11, 10, 3, 2, '#f2eee4'); // Drumstick bone end
    r(11, 4, 3, 2, '#f2eee4');
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'cod' || n === 'cooked_cod' || n === 'salmon' || n === 'cooked_salmon' || n === 'tropical_fish' || n === 'pufferfish') {
    if (n === 'pufferfish') {
      r(4, 4, 8, 8, '#ebb82c'); r(3, 5, 10, 6, '#f5cc3d'); r(5, 9, 6, 3, '#f7f0c6');
      r(5, 6, 2, 2, '#1c2426'); r(9, 6, 2, 2, '#1c2426');
      addOutline(ctx, '#5c430c');
      return true;
    }
    const isSalmon = n.includes('salmon');
    const headCol = isSalmon && n === 'salmon' ? '#4f6e58' : shadeHex(col, -20);
    // Plump curved fish body + dorsal/pectoral fins + forked tail
    r(5, 5, 6, 6, col);
    r(4, 6, 7, 5, col);
    r(6, 4, 6, 5, shadeHex(col, 22));
    r(9, 3, 4, 4, headCol);
    r(4, 4, 3, 2, shadeHex(col, -18)); // Dorsal fin
    r(8, 9, 3, 2, shadeHex(col, -18)); // Ventral fin
    r(2, 10, 3, 4, headCol); // Forked tail
    r(1, 12, 2, 2, headCol); r(3, 13, 2, 2, headCol);
    if (n === 'tropical_fish') { r(6, 5, 2, 5, '#ffffff'); r(9, 4, 1, 4, '#ffffff'); }
    r(11, 4, 1, 1, '#14181a'); // Eye
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'carrot' || n === 'golden_carrot' || n === 'beetroot') {
    const beet = n === 'beetroot';
    for (let i = 0; i < 8; i++) {
      const w = Math.max(2, Math.floor((i + 2) / 2));
      r(3 + i, 12 - i, w, w, col);
      r(3 + i, 12 - i, 1, 1, shadeHex(col, 42));
    }
    addOutline(ctx, shadeHex(col, -85));
    r(11, 2, 3, 3, beet ? '#629c3b' : '#4fa638');
    r(12, 1, 2, 2, '#78cf54');
    return true;
  }

  if (n === 'potato' || n === 'baked_potato' || n === 'poisonous_potato' || n === 'egg') {
    r(4, 4, 8, 9, col);
    r(5, 3, 6, 11, col);
    r(5, 4, 3, 3, shadeHex(col, 36));
    if (n === 'baked_potato') { r(6, 5, 4, 4, '#fff2b2'); r(7, 6, 2, 2, '#e8a838'); }
    if (n === 'poisonous_potato') { r(5, 7, 2, 2, '#5ca638'); r(8, 9, 2, 2, '#5ca638'); }
    addOutline(ctx, shadeHex(col, -80));
    return true;
  }

  if (n === 'melon_slice' || n === 'glistering_melon_slice') {
    const gl = n === 'glistering_melon_slice';
    r(3, 6, 10, 6, '#3e7a28'); // Green rind
    r(4, 6, 8, 5, '#a8c958');
    r(4, 4, 8, 6, '#cf382e'); // Red flesh
    r(5, 5, 1, 1, gl ? '#fff08a' : '#261c18');
    r(8, 6, 1, 1, gl ? '#fff08a' : '#261c18');
    r(10, 5, 1, 1, gl ? '#fff08a' : '#261c18');
    if (gl) { r(6, 4, 2, 1, '#f2c842'); r(9, 4, 2, 1, '#f2c842'); }
    addOutline(ctx, '#224215');
    return true;
  }

  if (n === 'sweet_berries' || n === 'glow_berries' || n === 'chorus_fruit' || n === 'popped_chorus_fruit') {
    r(5, 3, 6, 3, '#4c852e');
    r(4, 6, 4, 5, col); r(8, 6, 4, 5, col); r(6, 9, 4, 5, shadeHex(col, 16));
    r(5, 7, 1, 1, '#ffffff'); r(9, 7, 1, 1, '#ffffff'); r(7, 10, 1, 1, '#ffffff');
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'cookie' || n === 'pumpkin_pie' || n === 'cake' || n === 'honeycomb') {
    r(3, 4, 10, 8, col);
    r(4, 3, 8, 10, shadeHex(col, 14));
    if (n === 'cookie') {
      r(5, 5, 2, 2, '#472814'); r(9, 6, 2, 2, '#472814'); r(6, 9, 2, 2, '#472814');
    } else if (n === 'cake') {
      r(3, 4, 10, 4, '#f7f4eb'); r(5, 5, 2, 2, '#d9322a'); r(9, 5, 2, 2, '#d9322a');
      r(3, 8, 10, 4, '#c78c44');
    } else if (n === 'pumpkin_pie') {
      r(4, 5, 8, 6, '#d97829'); r(5, 6, 3, 2, '#f09846');
    }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'bowl' || n.endsWith('_stew') || n.endsWith('_soup')) {
    r(3, 8, 10, 4, '#8a5d32');
    r(4, 11, 8, 2, '#694422');
    if (n !== 'bowl') {
      r(4, 6, 8, 3, col);
      r(5, 6, 3, 2, shadeHex(col, 35));
      if (n === 'mushroom_stew') { r(8, 6, 2, 2, '#d93b30'); r(6, 7, 2, 1, '#f2eee4'); }
    } else {
      r(4, 7, 8, 2, '#4f3218');
    }
    addOutline(ctx, '#36210e');
    return true;
  }

  if (n === 'rotten_flesh' || n === 'spider_eye' || n === 'fermented_spider_eye' || n === 'dried_kelp') {
    r(4, 4, 8, 8, col);
    r(3, 6, 10, 5, shadeHex(col, -16));
    r(5, 5, 3, 2, shadeHex(col, 36));
    if (n === 'rotten_flesh') { r(6, 7, 4, 2, '#5a7d3a'); }
    if (n.includes('spider_eye')) { r(6, 6, 3, 3, '#1f080d'); r(6, 6, 1, 1, '#ff9ea8'); }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  // 7. Buckets & Bottles & Potions
  if (n.includes('bucket')) {
    r(3, 4, 10, 8, '#9aa4a6');
    r(4, 11, 8, 3, '#768082');
    r(4, 5, 3, 6, '#dce3e6');
    if (n !== 'bucket') {
      const liq = n === 'water_bucket' ? '#2c7fe8' : n === 'lava_bucket' ? '#ff6e14' : n === 'milk_bucket' ? '#f7f7f2' : '#e6f4fa';
      r(4, 3, 8, 3, liq);
      r(5, 3, 4, 1, shadeHex(liq, 48));
    } else {
      r(4, 4, 8, 2, '#4a5254');
    }
    addOutline(ctx, '#292e30');
    return true;
  }

  if (n === 'glass_bottle' || n === 'dragon_breath' || n === 'ominous_bottle' || /^(potion_|splash_)|_potion$|^water_bottle$|^potion$|^honey_bottle$|^experience_bottle$/.test(n)) {
    const splash = n.startsWith('splash_');
    r(6, 1, 4, 2, '#9e6e3e'); // Cork
    r(5, 3, 6, 2, '#cbe4eb'); // Bottle neck rim
    if (splash) r(8, 2, 3, 2, '#cbe4eb');
    r(4, 5, 8, 8, '#cbe4eb');
    r(5, 12, 6, 2, '#a3c4cf');
    if (n !== 'glass_bottle') {
      const liq = n === 'experience_bottle' ? '#b8f242' : n === 'dragon_breath' ? '#d952ff' : n === 'ominous_bottle' ? '#384e8a' : col;
      r(5, 6, 6, 7, liq);
      r(5, 6, 2, 3, shadeHex(liq, 60));
    } else {
      r(5, 6, 2, 4, '#ffffff');
    }
    addOutline(ctx, '#2b3c42');
    return true;
  }

  // 8. Ranged, Special Weapons & Utility Gear
  if (n === 'bow') {
    for (let i = 2; i < 14; i++) {
      const bx = 4 + Math.round(Math.sin(((i - 2) / 11) * Math.PI) * 6);
      r(bx, i, 2, 1, i === 7 || i === 8 ? '#c79a5b' : '#7d562c');
    }
    r(4, 2, 1, 12, '#e6e3d8');
    addOutline(ctx, '#2b1b0a');
    return true;
  }

  if (n === 'arrow' || n === 'spectral_arrow') {
    const tip = n === 'spectral_arrow' ? '#ffd83d' : '#d0d7d9';
    for (let i = 3; i < 12; i++) r(i, 15 - i, 2, 1, '#9c7340');
    r(11, 1, 4, 4, tip); r(12, 1, 3, 1, '#ffffff');
    r(1, 11, 4, 4, '#f2efe6');
    addOutline(ctx, '#2b1e10');
    return true;
  }

  if (n === 'fishing_rod' || n === 'carrot_on_a_stick' || n === 'warped_fungus_on_a_stick') {
    for (let i = 2; i < 12; i++) r(i, 14 - i, 2, 1, '#8c6436');
    r(12, 3, 1, 8, '#e3e0d5');
    const bait = n === 'carrot_on_a_stick' ? '#f08226' : n === 'warped_fungus_on_a_stick' ? '#28b5a8' : '#e03b2e';
    r(11, 10, 3, 4, bait);
    addOutline(ctx, '#2b1d0e');
    return true;
  }

  if (n === 'compass' || n === 'clock') {
    const gold = n === 'clock';
    const body = gold ? '#f0c43e' : '#b8c2c4';
    r(3, 3, 10, 10, body);
    r(4, 2, 8, 12, body);
    r(2, 4, 12, 8, body);
    r(4, 4, 8, 8, gold ? '#243059' : '#262b2e');
    r(7, 4, 2, 4, gold ? '#ffd84a' : '#e62e24'); // Red needle / gold hand
    r(7, 8, 2, 3, '#e0e6e8');
    addOutline(ctx, gold ? '#4f3908' : '#262b2c');
    return true;
  }

  if (n === 'spyglass') {
    for (let i = 2; i < 13; i++) {
      const c1 = i < 6 ? '#5e3d22' : '#d48248';
      r(i, 14 - i, 3, 3, c1);
      r(i, 14 - i, 2, 1, i < 6 ? '#855832' : '#f2aa6b');
    }
    r(12, 1, 3, 3, '#7ae8f5');
    addOutline(ctx, '#26170b');
    return true;
  }

  if (n === 'trial_key' || n === 'ominous_trial_key') {
    const om = n === 'ominous_trial_key';
    const kCol = om ? '#4c6ed9' : '#d47f48';
    const glow = om ? '#82f5ff' : '#ffd86b';
    r(3, 3, 6, 6, kCol); r(5, 5, 2, 2, glow);
    for (let i = 7; i < 14; i++) r(i, i, 2, 2, kCol);
    r(10, 12, 2, 3, kCol); r(12, 13, 2, 2, glow);
    addOutline(ctx, '#1f1612');
    return true;
  }

  if (n === 'bundle') {
    r(4, 5, 8, 9, '#a8693c');
    r(3, 6, 10, 7, '#bd7a4a');
    r(5, 3, 6, 2, '#c9935b');
    r(4, 5, 8, 1, '#e6c24c'); // Gold drawstring tie
    r(5, 7, 3, 4, '#d49260');
    addOutline(ctx, '#3b1f0d');
    return true;
  }

  if (n === 'goat_horn') {
    r(3, 8, 5, 5, '#7a6c5b');
    r(6, 10, 6, 4, '#948470');
    r(10, 6, 4, 6, '#aba08c');
    r(11, 3, 2, 4, '#cfc6b4');
    addOutline(ctx, '#29231d');
    return true;
  }

  if (n === 'name_tag') {
    r(3, 6, 9, 6, '#d6c698');
    r(4, 7, 7, 4, '#ebe0be');
    r(5, 8, 5, 1, '#7a6e52');
    r(11, 3, 3, 4, '#9e7644');
    addOutline(ctx, '#383020');
    return true;
  }

  if (n === 'book' || n === 'writable_book' || n === 'written_book' || n === 'enchanted_book') {
    const cover = n === 'enchanted_book' ? '#8c3bb5' : n === 'written_book' ? '#9e2848' : '#9c5c34';
    r(3, 2, 10, 12, cover);
    r(4, 3, 8, 10, shadeHex(cover, 22));
    r(11, 3, 2, 10, '#f5f0dc'); // Book pages
    r(3, 7, 9, 2, '#f2c842'); // Gold strap
    if (n === 'writable_book') { r(11, 1, 3, 6, '#ffffff'); r(10, 6, 2, 4, '#dcd8c8'); }
    addOutline(ctx, '#291509');
    return true;
  }

  if (n === 'paper' || n === 'map' || n === 'filled_map' || n === 'buried_treasure_map' || n.endsWith('_explorer_map') || n.endsWith('_banner_pattern')) {
    r(2, 2, 12, 12, '#e8dec0');
    r(3, 3, 10, 10, '#f5eed8');
    if (n.includes('map')) {
      r(4, 4, 4, 5, '#5ca644');
      r(8, 5, 4, 6, '#3e84c9');
      r(6, 9, 3, 2, '#d9382e'); // Red X / marker
    } else if (n.endsWith('_banner_pattern')) {
      r(5, 5, 6, 6, '#8c653e');
      r(6, 6, 4, 4, '#c49660');
    } else {
      for (const py of [5, 8, 11]) r(4, py, 8, 1, '#c9bfa2');
    }
    addOutline(ctx, '#4a402c');
    return true;
  }

  if (n.endsWith('_minecart') || n === 'minecart') {
    if (n !== 'minecart') {
      const inner = n === 'chest_minecart' ? '#c28b3b' : n === 'tnt_minecart' ? '#cc382c' : n === 'hopper_minecart' ? '#586063' : '#787d7a';
      r(4, 2, 8, 6, inner);
      r(5, 3, 6, 3, shadeHex(inner, 28));
    }
    r(2, 6, 12, 6, '#879194');
    r(3, 7, 10, 4, '#b8c4c7');
    r(3, 6, 10, 1, '#e6eff2');
    r(4, 12, 2, 2, '#2e3336'); r(10, 12, 2, 2, '#2e3336');
    addOutline(ctx, '#24292b');
    return true;
  }

  if (n === 'slime_ball' || n === 'magma_cream' || n === 'snowball' || n === 'fire_charge' || n === 'wind_charge' || n === 'xp_orb') {
    r(4, 3, 8, 10, col);
    r(3, 4, 10, 8, col);
    r(5, 4, 3, 3, n === 'fire_charge' ? '#fff08a' : '#ffffff');
    r(6, 9, 5, 3, shadeHex(col, -28));
    if (n === 'magma_cream') { r(5, 6, 6, 3, '#ff9d26'); }
    if (n === 'fire_charge') { r(5, 6, 6, 5, '#ffab26'); }
    if (n === 'wind_charge') { r(4, 6, 8, 3, '#ffffff'); }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'leather' || n === 'rabbit_hide' || n === 'hoglin_hide' || n === 'scute' || n === 'armadillo_scute' || n === 'phantom_membrane' || n === 'nautilus_shell' || n === 'disc_fragment' || n === 'ink_sac' || n === 'glow_ink_sac' || n === 'rabbit_foot' || n === 'string' || n === 'feather' || n === 'bone' || n === 'stick' || n === 'breeze_rod') {
    if (n === 'stick' || n === 'bone' || n === 'feather' || n === 'breeze_rod') {
      for (let i = 0; i < 10; i++) {
        r(3 + i, 12 - i, 2, 2, col);
        r(3 + i, 12 - i, 1, 1, shadeHex(col, 38));
      }
      if (n === 'bone') { r(2, 11, 3, 3, col); r(11, 2, 3, 3, col); }
      if (n === 'feather') { r(6, 4, 5, 5, shadeHex(col, 18)); }
      addOutline(ctx, shadeHex(col, -85));
      return true;
    }
    if (n === 'string') {
      for (let i = 2; i < 13; i++) {
        const sx = 4 + Math.round(Math.sin(i * 0.8) * 3);
        r(sx, i, 2, 1, '#f2f0e8');
      }
      addOutline(ctx, '#5c5a52');
      return true;
    }
    r(3, 3, 10, 10, col);
    r(4, 2, 8, 12, col);
    r(5, 4, 4, 4, shadeHex(col, 36));
    r(6, 9, 5, 3, shadeHex(col, -25));
    if (n === 'nautilus_shell') { r(6, 6, 4, 4, '#9e4c36'); }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'ominous_banner' || n === 'piglin_banner') {
    r(4, 1, 8, 13, col);
    r(5, 2, 6, 10, shadeHex(col, 24));
    r(6, 4, 4, 4, '#dcd8c8');
    r(7, 5, 2, 2, '#242428');
    addOutline(ctx, '#1f1c18');
    return true;
  }

  if (n === 'item_frame') {
    r(2, 2, 12, 12, '#b88548');
    r(4, 4, 8, 8, '#7a4824');
    r(5, 5, 6, 6, '#945a30');
    addOutline(ctx, '#38220f');
    return true;
  }
  if (n === 'painting' || n === 'sign') {
    r(2, 2, 12, 9, '#9c7240');
    r(3, 3, 10, 7, n === 'painting' ? '#5894c9' : '#c4965a');
    if (n === 'painting') { r(3, 7, 10, 3, '#5ea142'); r(8, 4, 2, 2, '#ffd84a'); }
    if (n === 'sign') { r(7, 11, 2, 4, '#6e4e28'); }
    addOutline(ctx, '#382510');
    return true;
  }

  if (n === "ender_pearl" || n === "ender_eye") {
    r(4, 3, 8, 10, "#175a4e"); r(3, 4, 10, 8, "#175a4e");
    r(4, 4, 8, 8, "#277d6d"); r(5, 4, 6, 7, "#38a18e"); r(5, 4, 3, 3, "#88f2db");
    if (n === "ender_eye") {
      r(5, 5, 6, 6, "#45c954"); r(6, 6, 4, 4, "#85ff8e"); r(7, 5, 2, 6, "#112e17"); r(6, 5, 1, 1, "#ffffff");
    }
    addOutline(ctx, "#08241f");
    return true;
  }
  if (n === "blaze_rod") {
    for (let i = 0; i < 11; i++) { r(2 + i, 12 - i, 3, 2, "#d96b12"); r(2 + i, 12 - i, 2, 1, "#ffcf3b"); }
    r(4, 10, 1, 1, "#ffffff"); r(9, 5, 1, 1, "#ffffff");
    addOutline(ctx, "#4a1c04");
    return true;
  }
  if (n === "ghast_tear") {
    r(7, 2, 2, 3, "#d2eef2"); r(6, 5, 4, 4, "#eafafb"); r(5, 8, 6, 5, "#bde2e8"); r(6, 8, 2, 3, "#ffffff");
    addOutline(ctx, "#3d5c63");
    return true;
  }
  if (n === "netherite_scrap") {
    r(3, 4, 10, 8, "#5e433c"); r(4, 3, 8, 10, "#4d352f");
    r(5, 5, 6, 2, "#8c695e"); r(4, 8, 7, 2, "#75554c"); r(5, 11, 5, 1, "#8c695e");
    addOutline(ctx, "#241614");
    return true;
  }
  if (n === "elytra") {
    r(2, 3, 5, 10, "#75708a"); r(9, 3, 5, 10, "#75708a");
    r(3, 4, 3, 8, "#9690b0"); r(10, 4, 3, 8, "#9690b0");
    r(6, 2, 4, 4, "#4a4659"); r(4, 3, 2, 2, "#bab4d4"); r(10, 3, 2, 2, "#bab4d4");
    addOutline(ctx, "#23202b");
    return true;
  }
  if (n === "firework_rocket") {
    r(6, 1, 4, 2, "#c92a22"); r(5, 3, 6, 2, "#e63b30");
    r(5, 5, 6, 7, "#f2eee4"); r(5, 6, 6, 2, "#e63b30"); r(5, 10, 6, 2, "#e63b30");
    r(7, 12, 2, 3, "#8c6538");
    addOutline(ctx, "#2e1c12");
    return true;
  }
  if (n === "end_crystal") {
    r(4, 2, 8, 8, "#eb73eb"); r(5, 3, 6, 6, "#ffb8ff"); r(6, 4, 4, 4, "#ffffff");
    r(3, 11, 10, 3, "#3b3247"); r(5, 10, 6, 2, "#5e5270");
    addOutline(ctx, "#211329");
    return true;
  }
  if (n === "shulker_shell") {
    r(3, 4, 10, 8, "#8c5691"); r(4, 3, 8, 8, "#a66cab"); r(5, 4, 6, 4, "#c993cf");
    addOutline(ctx, "#361c38");
    return true;
  }
  if (n === "flint_and_steel") {
    r(2, 5, 6, 7, "#4d5250"); r(3, 6, 4, 5, "#6e7573");
    r(8, 2, 5, 9, "#cfd6d4"); r(9, 3, 3, 6, "#ffffff");
    addOutline(ctx, "#1c1f1e");
    return true;
  }
  if (n === "shears") {
    r(2, 9, 5, 5, "#8c5230"); r(8, 9, 5, 5, "#8c5230");
    r(5, 2, 3, 7, "#cfd6d4"); r(8, 3, 3, 6, "#b8c2bf"); r(6, 2, 1, 5, "#ffffff");
    addOutline(ctx, "#242928");
    return true;
  }
  if (n === "nether_star") {
    r(7, 1, 2, 14, "#d9f7ff"); r(1, 7, 14, 2, "#d9f7ff");
    r(4, 4, 8, 8, "#b8e2f2"); r(5, 5, 6, 6, "#ffffff");
    addOutline(ctx, "#2e4659");
    return true;
  }
  if (n.startsWith("music_disc_")) {
    r(4, 2, 8, 12, "#22252a"); r(2, 4, 12, 8, "#22252a"); r(3, 3, 10, 10, "#2f333b");
    r(4, 4, 4, 2, "#4f5663"); r(8, 10, 4, 2, "#4f5663");
    r(5, 5, 6, 6, col); r(6, 6, 4, 4, shadeHex(col, 35)); r(7, 7, 2, 2, "#14161a");
    addOutline(ctx, "#0e1014");
    return true;
  }
  if (n === "brush") {
    for (let i = 0; i < 6; i++) r(2 + i, 12 - i, 2, 2, "#8c5c32");
    r(7, 6, 3, 3, "#cf8254");
    r(9, 2, 5, 5, "#f2efe4"); r(10, 3, 3, 3, "#ffffff");
    addOutline(ctx, "#2b1c0e");
    return true;
  }
  if (n === "shield") {
    r(3, 1, 10, 11, "#9c703e"); r(4, 12, 8, 2, "#855d30"); r(6, 14, 4, 1, "#6e4b24");
    r(3, 1, 10, 1, "#c4cccf"); r(3, 1, 1, 11, "#c4cccf"); r(12, 1, 1, 11, "#879094");
    r(7, 5, 2, 5, "#d8e0e3");
    addOutline(ctx, "#24190c");
    return true;
  }
  if (n === "crossbow") {
    for (let i = 3; i < 13; i++) r(i, i, 2, 2, "#75522d");
    r(2, 6, 2, 6, "#9c7142"); r(6, 2, 6, 2, "#9c7142");
    r(3, 3, 8, 1, "#e0dcd0"); r(3, 3, 1, 8, "#e0dcd0");
    r(6, 6, 3, 3, "#9ea8ab");
    addOutline(ctx, "#26190c");
    return true;
  }
  if (n === "trident") {
    for (let i = 3; i < 14; i++) r(15 - i, i, 2, 1, "#3b8c82");
    r(9, 1, 2, 5, "#7af0e0"); r(11, 2, 2, 4, "#a8fff5"); r(13, 4, 2, 3, "#7af0e0");
    r(9, 5, 5, 2, "#52b8ab");
    addOutline(ctx, "#143b36");
    return true;
  }
  if (n === "mace") {
    for (let i = 2; i < 9; i++) r(i, 14 - i, 2, 2, "#6e7885");
    r(7, 2, 7, 7, "#585b69"); r(8, 3, 5, 5, "#878b9c"); r(9, 3, 2, 2, "#dce0ed");
    addOutline(ctx, "#1e2029");
    return true;
  }
  if (n === "heavy_core") {
    r(3, 4, 10, 9, "#4d505e"); r(4, 3, 8, 10, "#666a7a");
    r(5, 4, 6, 3, "#999fb2"); r(6, 7, 4, 3, "#2b2d36");
    addOutline(ctx, "#1a1b21");
    return true;
  }
  if (n === "totem_of_undying") {
    r(5, 2, 6, 5, "#ebb844"); r(2, 6, 12, 3, "#f5cc58"); r(5, 9, 6, 5, "#cfa032");
    r(6, 4, 1, 1, "#2bc958"); r(9, 4, 1, 1, "#2bc958"); r(7, 5, 2, 2, "#a67b24");
    addOutline(ctx, "#4a3309");
    return true;
  }
  if (n === "boat") {
    r(2, 6, 12, 6, "#b58448"); r(3, 10, 10, 3, "#8a6232"); r(4, 7, 8, 3, "#6b4a22");
    r(5, 4, 2, 5, "#d4a462"); r(9, 4, 2, 5, "#d4a462"); // Paddles
    addOutline(ctx, "#33210d");
    return true;
  }
  if (n === "saddle") {
    r(3, 4, 10, 7, "#9e5c34"); r(4, 3, 8, 7, "#bd7244"); r(5, 4, 6, 3, "#d48858");
    r(6, 10, 4, 4, "#7a4424"); r(7, 13, 2, 2, "#c2cccc");
    addOutline(ctx, "#381c0c");
    return true;
  }
  if (n === "lead") {
    r(3, 3, 9, 9, "#b8905c"); r(5, 5, 5, 5, "#6b5030");
    r(10, 10, 4, 4, "#d4ae76");
    addOutline(ctx, "#382815");
    return true;
  }
  if (n === "sculk") {
    r(3, 3, 10, 10, "#0b222b"); r(5, 4, 2, 2, "#2cd8e8"); r(9, 7, 2, 2, "#2cd8e8"); r(6, 10, 3, 2, "#197a8a");
    addOutline(ctx, "#051014");
    return true;
  }
  if (n === "glow_item_frame") {
    r(2, 2, 12, 12, "#d8c898");
    r(4, 4, 8, 8, "#1c7a74");
    r(5, 5, 6, 6, "#36bdb4");
    r(6, 5, 2, 2, "#9efff6"); r(9, 8, 2, 2, "#9efff6");
    addOutline(ctx, "#2c4038");
    return true;
  }
  if (n === "armor_stand") {
    r(7, 2, 2, 3, "#c49c5e"); // Head
    r(3, 5, 10, 2, "#b58b4c"); // Shoulder bar
    r(5, 7, 2, 4, "#a37a3e"); r(9, 7, 2, 4, "#a37a3e"); // Twin torso sticks
    r(4, 10, 8, 1, "#8c6530"); // Waist beam
    r(5, 11, 2, 3, "#a37a3e"); r(9, 11, 2, 3, "#a37a3e"); // Legs
    r(2, 13, 12, 2, "#9e9e9a"); r(3, 13, 10, 1, "#bdbdb8"); // Smooth stone base
    addOutline(ctx, "#332412");
    return true;
  }
  if (n.endsWith("_horse_armor")) {
    r(9, 2, 4, 5, col); r(11, 3, 3, 3, shadeHex(col, 28)); // Chanfron head
    r(8, 5, 3, 4, shadeHex(col, -18)); // Neck crinet
    r(3, 7, 10, 5, col); r(4, 8, 8, 3, shadeHex(col, 32)); // Body caparison
    r(4, 11, 2, 3, shadeHex(col, -28)); r(10, 11, 2, 3, shadeHex(col, -28)); // Tassets
    r(6, 8, 3, 2, "#f0ca3c"); // Trim emblem
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }
  if (n === "minecart" || n.endsWith("_minecart")) {
    if (n === "chest_minecart") { r(4, 3, 8, 5, "#b88238"); r(5, 4, 6, 3, "#cfa052"); r(7, 5, 2, 2, "#d8e0e2"); }
    else if (n === "hopper_minecart") { r(3, 3, 10, 3, "#687075"); r(5, 5, 6, 3, "#4f565a"); }
    else if (n === "tnt_minecart") { r(4, 3, 8, 5, "#c83c2b"); r(4, 5, 8, 2, "#f2efe6"); }
    else if (n === "furnace_minecart") { r(4, 3, 8, 5, "#767a78"); r(6, 5, 4, 2, "#ff781f"); }
    r(2, 7, 12, 5, "#8c9196"); r(3, 8, 10, 3, "#abb0b5"); r(2, 7, 12, 1, "#cfd4d8");
    r(4, 12, 3, 2, "#2d3033"); r(9, 12, 3, 2, "#2d3033");
    addOutline(ctx, "#222528");
    return true;
  }
  return false;
}


// =====================================================================================================================
// 5. END FAMILY BLOCKS (End Stone, End Stone Bricks, Purpur, End Rod, Chorus, Portal Frame/Eye, Portal/Gateway,
//    Dragon Egg, Dragon Head, Shulker Box)
// =====================================================================================================================

const END_STONE_MAP = [
  '2332101234432102',
  '3001233431012233',
  '3001344320013443',
  '2112321121223102',
  '1233200133432001',
  '0134310243112112',
  '1233221331001233',
  '2320012210012344',
  '3430012112233400',
  '2321123343321200',
  '1233344310110112',
  '0120023200122233',
  '1220012212334321',
  '2331123443210012',
  '3443234101120023',
  '2332123101231232',
];

const END_STONE_PAL: Record<string, string> = {
  '0': '#999460', // Deep crater pit
  '1': '#b5af76', // Crater rim shadow
  '2': '#d4cf96', // Mid pale-ochre stone matrix
  '3': '#e6e1ab', // Elevated stone ridge
  '4': '#f5f1c4', // Specular cream highlight
};

export function drawEndTile(name: string, ctx: Context2D): boolean {
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === 'end_stone') {
    drawGrid(ctx, END_STONE_MAP, END_STONE_PAL);
    return true;
  }

  if (name === 'end_stone_bricks') {
    // 4 staggered ashlar courses of warm pale-yellowish End Stone Bricks with chiseled bevels & mortar grooves
    r(0, 0, 16, 16, '#8f8a57');
    for (let row = 0; row < 4; row++) {
      const y = row * 4;
      const off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        const x0 = Math.max(0, bx + off);
        const x1 = Math.min(16, bx + off + 7);
        const w = x1 - x0;
        if (w <= 0) continue;
        // Brick face
        r(x0, y + 1, w, 3, '#ded99e');
        // Top & left light bevel
        r(x0, y + 1, w, 1, '#f4f0c2');
        r(x0, y + 1, 1, 3, '#ebe6b2');
        // Bottom & right shadow bevel
        r(x0, y + 3, w, 1, '#bfb97e');
        if (bx + off + 7 <= 16) {
          r(x1 - 1, y + 1, 1, 3, '#b8b276');
          r(x1, y, 1, 4, '#8f8a57'); // Vertical mortar joint
        }
        // Subtle mineral pitting inside each brick
        if (w >= 4) {
          r(x0 + 2, y + 2, 2, 1, (row + bx) % 2 === 0 ? '#cfc98e' : '#e8e3ad');
        }
      }
      r(0, y, 16, 1, '#8f8a57'); // Horizontal mortar joint
    }
    return true;
  }

  if (name === 'purpur_block') {
    // Authentic 4x4 grid (4px each) of beveled lavender-magenta Purpur tiles
    r(0, 0, 16, 16, '#6e456e');
    for (let ty = 0; ty < 4; ty++) {
      for (let tx = 0; tx < 4; tx++) {
        const x = tx * 4, y = ty * 4;
        const alt = (tx + ty) & 1;
        r(x, y, 4, 4, alt ? '#a87ca8' : '#b084b0');
        // Top & left highlight bevel
        r(x, y, 4, 1, '#cfa6cf');
        r(x, y, 1, 4, '#c498c4');
        // Bottom & right mortar shadow
        r(x, y + 3, 4, 1, '#7a4f7a');
        r(x + 3, y, 1, 4, '#7a4f7a');
        // Inner tile sheen
        r(x + 1, y + 1, 1, 1, '#dbb6db');
        r(x + 2, y + 2, 1, 1, '#996d99');
      }
    }
    return true;
  }

  if (name === 'purpur_pillar_top') {
    // Concentric stepped square purpur column capital
    r(0, 0, 16, 16, '#754b75');
    r(1, 1, 14, 14, '#c79cc7');
    r(2, 2, 12, 12, '#a679a6');
    r(3, 3, 10, 10, '#855885');
    r(4, 4, 8, 8, '#cf9fcf');
    r(5, 5, 6, 6, '#ab7eab');
    r(6, 6, 4, 4, '#7d507d');
    r(7, 7, 2, 2, '#d9b2d9');
    // Corner bevel accents
    r(1, 1, 2, 1, '#dec0de'); r(1, 1, 1, 2, '#dec0de');
    r(14, 14, 1, 1, '#663d66');
    return true;
  }

  if (name === 'purpur_pillar') {
    // Fluted vertical Purpur column with chiseled drum joint & capital/base mouldings
    r(0, 0, 16, 16, '#a679a6');
    for (let x = 0; x < 16; x += 4) {
      r(x, 0, 1, 16, '#704570');     // Deep flute groove
      r(x + 1, 0, 1, 16, '#d6add6'); // Flute specular ridge
      r(x + 2, 0, 1, 16, '#b589b5'); // Flute mid face
      r(x + 3, 0, 1, 16, '#8d608d'); // Flute shadow slope
    }
    // Subtle mid-column drum seam at y=8
    for (let x = 0; x < 16; x += 4) {
      r(x + 1, 7, 2, 1, '#946794');
      r(x + 1, 8, 2, 1, '#deb8de');
    }
    // Horizontal capital/base trim bands
    r(0, 0, 16, 1, '#deb8de');
    r(0, 1, 16, 1, '#7d507d');
    r(0, 14, 16, 1, '#deb8de');
    r(0, 15, 16, 1, '#693f69');
    return true;
  }

  if (name === 'end_rod' || name === 'end_rod_shaft') {
    // Luminous cream-white & warm pearl-gold End Rod shaft
    r(0, 0, 16, 16, '#f6f2e4');
    for (let x = 0; x < 16; x++) {
      const col = x % 4 === 0 ? '#dfd7c0' : x % 4 === 1 ? '#ffffff' : x % 4 === 2 ? '#faf7ed' : '#ebe4d0';
      r(x, 0, 1, 16, col);
    }
    r(0, 0, 16, 2, '#ffffff');
    r(0, 14, 16, 2, '#d8ceb4');
    return true;
  }

  if (name === 'end_rod_base') {
    // Metallic purpur-violet stepped mounting bracket
    r(0, 0, 16, 16, '#6b476e');
    r(1, 1, 14, 14, '#8f6394');
    r(2, 2, 12, 12, '#b386b8');
    r(4, 4, 8, 8, '#7a507d');
    r(6, 6, 4, 4, '#f5efe0');
    r(1, 1, 14, 1, '#c99ecf');
    r(1, 14, 14, 1, '#4f3152');
    return true;
  }

  if (name === 'chorus_plant') {
    // Organic cellular dark-purple Chorus stem with pale magenta-cream pores
    r(0, 0, 16, 16, '#543057');
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const h = (x * 11 + y * 17) % 9;
        if (h === 0 || h === 1) r(x, y, 1, 1, '#3b1e3d');
        else if (h === 2 || h === 3) r(x, y, 1, 1, '#6e4273');
        else if (h === 4) r(x, y, 1, 1, '#825287');
      }
    }
    const pores: [number, number][] = [
      [2, 2], [7, 3], [12, 2], [4, 6], [10, 7],
      [2, 11], [7, 10], [13, 12], [5, 14], [11, 14],
    ];
    for (const [px, py] of pores) {
      r(px, py, 2, 2, '#9e6fa3');
      r(px, py, 1, 1, '#d1b0d4');
      r(px + 1, py + 1, 1, 1, '#3b1e3d');
    }
    // Subtle outer border shading for 3D stem segments
    r(0, 0, 16, 1, '#7c4d80'); r(0, 15, 16, 1, '#361a38');
    r(0, 0, 1, 16, '#7c4d80'); r(15, 0, 1, 16, '#361a38');
    return true;
  }

  if (name === 'chorus_flower' || name === 'chorus_flower_top') {
    // Blooming Chorus Flower (age 0..4): sculpted purple calyx framing a cream-yellow glowing corolla
    r(0, 0, 16, 16, '#59335c');
    r(1, 1, 14, 14, '#7d4b82');
    r(2, 2, 12, 12, '#a36ea8');
    // Outer petal notches
    r(6, 1, 4, 1, '#cfa4d4'); r(6, 14, 4, 1, '#59335c');
    r(1, 6, 1, 4, '#cfa4d4'); r(14, 6, 1, 4, '#59335c');
    // Inner cream-white blossom
    r(3, 3, 10, 10, '#e3d1e6');
    r(4, 4, 8, 8, '#f7f2d4');
    r(5, 5, 6, 6, '#fffbe6');
    // Crucial 4-petal cross division & glowing golden-cream stamen core
    r(7, 3, 2, 10, '#d4b8d9');
    r(3, 7, 10, 2, '#d4b8d9');
    r(6, 6, 4, 4, '#fffdf0');
    r(7, 7, 2, 2, '#f5d96b');
    return true;
  }

  if (name === 'chorus_flower_dead' || name === 'chorus_flower_dead_top') {
    // Withered Chorus Flower (age 5): dark desiccated violet-brown husk with cracked core
    r(0, 0, 16, 16, '#331c36');
    r(1, 1, 14, 14, '#4c2c4f');
    r(2, 2, 12, 12, '#663e69');
    r(3, 3, 10, 10, '#855c87');
    r(4, 4, 8, 8, '#9e7b96');
    r(5, 5, 6, 6, '#543657');
    r(6, 6, 4, 4, '#2e1930');
    // Withered radial cracks
    r(7, 2, 2, 12, '#38203b');
    r(2, 7, 12, 2, '#38203b');
    r(7, 7, 2, 2, '#b59ea8');
    return true;
  }

  if (name === 'end_portal_frame_top') {
    // Ornate teal-jade temple stone rim with 4 corner turquoise inlays and dark recessed Eye socket
    r(0, 0, 16, 16, '#d9d498');
    r(1, 1, 14, 14, '#3b6e5c');
    r(2, 2, 12, 12, '#56947e');
    r(3, 3, 10, 10, '#78b8a0');
    // 4 raised corner temple glyphs
    for (const [cx, cy] of [[0, 0], [12, 0], [0, 12], [12, 12]]) {
      r(cx, cy, 4, 4, '#2d5949');
      r(cx + 1, cy + 1, 2, 2, '#8cd1b8');
      r(cx + 1, cy + 1, 1, 1, '#c4f5e2');
    }
    // Cardinal stone bridges
    r(6, 1, 4, 2, '#e8e4b0'); r(6, 13, 4, 2, '#bfb97e');
    r(1, 6, 2, 4, '#e8e4b0'); r(13, 6, 2, 4, '#bfb97e');
    // Deep recessed Eye of Ender socket (4..12)
    r(4, 4, 8, 8, '#172e26');
    r(5, 5, 6, 6, '#0c1a15');
    r(6, 6, 4, 4, '#060d0b');
    return true;
  }

  if (name === 'end_portal_frame_side') {
    // Upper teal jade frieze mapped accurately to y=0..13 UV range (canvas rows 3..15)
    drawGrid(ctx, END_STONE_MAP, END_STONE_PAL);
    // Upper teal-green cornice (rows 0..6 so y=13 top edge shows the full teal frieze)
    r(0, 0, 16, 6, '#3d7360');
    r(0, 0, 16, 4, '#56947e');
    r(0, 3, 16, 1, '#92d6bd');
    r(0, 5, 16, 1, '#24473a');
    // Hanging teal temple teeth / carvings (rows 6..10)
    for (const tx of [1, 6, 11]) {
      r(tx, 6, 4, 3, '#346352');
      r(tx + 1, 6, 2, 2, '#74b59d');
      r(tx + 1, 8, 2, 1, '#24473a');
      r(tx, 9, 4, 1, '#999460');
    }
    // Recessed decorative stone channel & base plinth shadow
    r(0, 13, 16, 1, '#f2eec0');
    r(0, 14, 16, 1, '#b5af76');
    r(0, 15, 16, 1, '#8f8a57');
    return true;
  }

  if (name === 'end_portal_eye_top') {
    // Luminous Eye of Ender top with emerald-teal iris and dark slit pupil
    r(0, 0, 16, 16, '#1c5949');
    r(1, 1, 14, 14, '#2d856e');
    r(2, 2, 12, 12, '#47b894');
    r(3, 3, 10, 10, '#78ebad');
    r(4, 4, 8, 8, '#a6ffbe');
    // Vertical cat-eye pupil slit
    r(7, 2, 2, 12, '#0d261a');
    r(6, 5, 4, 6, '#163d29');
    r(7, 3, 2, 10, '#07140d');
    // Specular corneal glint
    r(5, 4, 2, 2, '#ffffff');
    r(10, 10, 1, 1, '#d9ffe6');
    return true;
  }

  if (name === 'end_portal_eye_side') {
    r(0, 0, 16, 16, '#236e5a');
    r(0, 0, 16, 4, '#78ebad');
    r(0, 4, 16, 8, '#389e80');
    r(0, 12, 16, 4, '#184a3c');
    for (let x = 2; x < 15; x += 4) r(x, 2, 2, 8, '#a6ffbe');
    return true;
  }

  if (name === 'end_portal' || name === 'end_gateway') {
    // Deep-space cosmic void with multi-layer cyan, teal, magenta, and starlight clusters
    r(0, 0, 16, 16, '#05070d');
    const nebulae: [number, number, number, number, string][] = [
      [1, 2, 5, 3, '#0b1929'], [9, 1, 5, 4, '#14122e'],
      [3, 7, 6, 4, '#0d262e'], [10, 9, 5, 5, '#1d1436'],
      [1, 12, 6, 3, '#0b2129'],
    ];
    for (const [nx, ny, nw, nh, ncol] of nebulae) r(nx, ny, nw, nh, ncol);
    const stars: [number, number, string][] = [
      [2, 2, '#64f5e8'], [5, 4, '#ffffff'], [11, 2, '#c88cff'], [14, 4, '#4ad9cc'],
      [1, 7, '#9e78ff'], [4, 8, '#b8fff8'], [8, 6, '#4ad9cc'], [12, 7, '#ffffff'],
      [3, 11, '#4ad9cc'], [7, 10, '#e0b8ff'], [10, 12, '#64f5e8'], [14, 11, '#ffffff'],
      [2, 14, '#c88cff'], [6, 14, '#ffffff'], [11, 15, '#4ad9cc'],
    ];
    for (const [sx, sy, scol] of stars) r(sx, sy, 1, 1, scol);
    if (name === 'end_gateway') {
      // Gateway has brighter golden-cyan-magenta dimensional beam sparkles
      r(7, 7, 2, 2, '#e6ffff');
      r(6, 7, 4, 2, '#5ce6dc');
      r(7, 6, 2, 4, '#5ce6dc');
    }
    return true;
  }

  if (name === 'dragon_egg') {
    // Obsidian-black dragon egg scales with glowing royal-purple & magenta spots
    r(0, 0, 16, 16, '#0d0814');
    for (let y = 0; y < 16; y += 2) {
      const off = (y >> 1) & 1;
      for (let x = off; x < 16; x += 3) {
        r(x, y, 2, 2, '#170f24');
        r(x, y, 1, 1, '#26183b');
      }
    }
    const runes: [number, number, number, number, string][] = [
      [3, 2, 2, 1, '#6e289e'], [10, 3, 2, 2, '#8c35c9'], [6, 5, 3, 1, '#b54cf5'],
      [2, 8, 2, 2, '#7c2eb3'], [11, 7, 2, 2, '#cf68ff'], [7, 10, 2, 2, '#9938db'],
      [4, 13, 3, 1, '#b54cf5'], [10, 13, 2, 1, '#6e289e'],
    ];
    for (const [rx, ry, rw, rh, rcol] of runes) {
      r(rx, ry, rw, rh, rcol);
      r(rx, ry, 1, 1, '#e89eff');
    }
    return true;
  }

  if (name === 'dragon_head' || name === 'dragon_head_front' || name === 'dragon_head_top' || name === 'dragon_head_side') {
    // Dark charcoal-obsidian dragon scales
    r(0, 0, 16, 16, '#18141f');
    for (let y = 0; y < 16; y += 2) {
      for (let x = (y >> 1) & 1; x < 16; x += 2) {
        r(x, y, 1, 1, '#251f30');
        r((x + 1) & 15, y, 1, 1, '#120f17');
      }
    }
    if (name === 'dragon_head_top') {
      // Central cranial ridge plates
      r(7, 1, 2, 14, '#322b40');
      for (let y = 2; y < 14; y += 3) r(6, y, 4, 2, '#423954');
      return true;
    }
    if (name === 'dragon_head_side') {
      // Temporal scale plates & jaw hinge line
      r(2, 5, 12, 2, '#2e273b');
      r(4, 10, 10, 1, '#0d0a12');
      r(2, 6, 3, 2, '#d95cf2'); // Side eye glint
      return true;
    }
    // Front face: fierce glowing magenta-violet dragon eyes with dark purple vertical slits
    r(1, 5, 5, 2, '#3b2e4a'); // Left brow ridge
    r(10, 5, 5, 2, '#3b2e4a'); // Right brow ridge
    r(2, 7, 4, 3, '#eb6eff'); // Left eye sclera
    r(10, 7, 4, 3, '#eb6eff'); // Right eye sclera
    r(3, 7, 2, 3, '#941cb3'); // Left iris
    r(11, 7, 2, 3, '#941cb3'); // Right iris
    r(3, 8, 1, 1, '#ffd6ff'); // Left eye highlight
    r(11, 8, 1, 1, '#ffd6ff'); // Right eye highlight
    return true;
  }

  if (name === 'dragon_head_horn') {
    // Pale golden-gray dragon horn / scale ridge material
    r(0, 0, 16, 16, '#8f8672');
    for (let y = 0; y < 16; y += 3) {
      r(0, y, 16, 1, '#aba18a');
      r(0, y + 1, 16, 1, '#756d5b');
      r(0, y + 2, 16, 1, '#595244');
    }
    return true;
  }

  if (name === 'dragon_head_mouth') {
    // Deep magenta-purple dragon mouth interior with pale teeth along edges
    r(0, 0, 16, 16, '#3b1542');
    r(2, 2, 12, 12, '#692275');
    for (let x = 1; x < 15; x += 3) {
      r(x, 0, 2, 2, '#dfd9c8');
      r(x, 14, 2, 2, '#dfd9c8');
    }
    return true;
  }

  if (name === 'shulker_box_top' || name === 'shulker_box_bottom' || name === 'shulker_box_side') {
    r(0, 0, 16, 16, '#754678');
    r(1, 1, 14, 14, '#8f5b92');
    if (name === 'shulker_box_top') {
      // Iconic concentric spiral-stepped Shulker shell top
      r(1, 1, 14, 1, '#b07cb3'); r(1, 1, 1, 14, '#b07cb3');
      r(1, 14, 14, 1, '#5e3561'); r(14, 1, 1, 14, '#5e3561');
      r(3, 3, 10, 10, '#9e68a1');
      r(3, 3, 10, 1, '#bd89c0'); r(3, 3, 1, 10, '#bd89c0');
      r(5, 5, 6, 6, '#7d4c80');
      r(6, 6, 4, 4, '#ab76ae');
      r(7, 7, 2, 2, '#c997cc');
    } else if (name === 'shulker_box_bottom') {
      r(2, 2, 12, 12, '#6b3e6e');
      r(4, 4, 8, 8, '#59325c');
    } else {
      // Shulker Box side: upper shell with crenulated bottom edge over lower shell & peeking cream interior
      r(0, 0, 16, 1, '#b07cb3');
      r(0, 1, 16, 6, '#966099');
      // Crenulated interlocking shell seam at y=7..9
      r(0, 7, 16, 3, '#4a274d');
      r(4, 7, 8, 2, '#e6dfa8'); // Peeking inner yellow shulker core
      r(6, 8, 4, 1, '#2b182e'); // Shulker eye slit hint
      r(0, 7, 3, 2, '#855288'); r(13, 7, 3, 2, '#855288');
      // Lower shell base (y=10..15)
      r(0, 10, 16, 6, '#7d4c80');
      r(0, 15, 16, 1, '#522c54');
    }
    return true;
  }

  if (name === 'shulker_box_core') {
    // Pale cream-yellow inner Shulker body with subtle eyes
    r(0, 0, 16, 16, '#d9d198');
    r(0, 4, 16, 8, '#ede6b2');
    r(4, 6, 2, 3, '#2b1f2e'); r(5, 6, 1, 1, '#ffffff');
    r(10, 6, 2, 3, '#2b1f2e'); r(10, 6, 1, 1, '#ffffff');
    return true;
  }

  return false;
}

// =====================================================================================================================
// 6. OCEAN / AQUATIC FAMILY BLOCKS (Prismarine, Prismarine Bricks, Dark Prismarine, Sea Lantern, Sponge, Wet Sponge,
//    Conduit, Sea Pickle, Turtle Egg, 5 Coral Blocks, 5 Coral Fans, Kelp, Seagrass, Dried Kelp Block)
// =====================================================================================================================

const PRISMARINE_MAP = [
  '0123210123320121',
  '1344310244310232',
  '2332101232101343',
  '1100012210012321',
  '0012334320123210',
  '1234432100134320',
  '2343210012232100',
  '1221001234310012',
  '0001223443201233',
  '1233432321012443',
  '2443210000123432',
  '2321001232012210',
  '1100123443100012',
  '0122344321012332',
  '1343232100124431',
  '0232100011012310',
];

const PRISMARINE_PAL: Record<string, string> = {
  '0': '#2b6b73', // Luminous cyan-indigo crack seam
  '1': '#458078', // Dark sea-teal cobble edge
  '2': '#5f9c92', // Mid aquamarine prismarine stone
  '3': '#7ab8ad', // Light seafoam cobble facet
  '4': '#9ed6cb', // Specular aquamarine crystal ridge
};

export function drawOceanTile(name: string, ctx: Context2D): boolean {
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === 'prismarine' || name === 'prismarine_top' || name === 'prismarine_side') {
    drawGrid(ctx, PRISMARINE_MAP, PRISMARINE_PAL);
    // Glowing cyan/cobalt crack highlights along the fracture network
    const cracks: [number, number, string][] = [
      [6, 1, '#38c9d4'], [5, 3, '#3b66ad'], [10, 4, '#38c9d4'],
      [1, 5, '#3b66ad'], [8, 6, '#38c9d4'], [4, 8, '#3b66ad'],
      [12, 9, '#38c9d4'], [1, 10, '#38c9d4'], [7, 11, '#3b66ad'],
      [5, 13, '#38c9d4'], [12, 14, '#3b66ad'],
    ];
    for (const [cx, cy, ccol] of cracks) r(cx, cy, 1, 1, ccol);
    return true;
  }

  if (name === 'prismarine_bricks') {
    // Ocean Monument chiseled sea-green temple masonry with beveled courses & crystal flecks
    r(0, 0, 16, 16, '#2b5950');
    for (let row = 0; row < 4; row++) {
      const y = row * 4;
      const off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        const x0 = Math.max(0, bx + off);
        const x1 = Math.min(16, bx + off + 7);
        const w = x1 - x0;
        if (w <= 0) continue;
        r(x0, y + 1, w, 3, '#5aa395');
        r(x0, y + 1, w, 1, '#84c9bc');
        r(x0, y + 1, 1, 3, '#72b8aa');
        r(x0, y + 3, w, 1, '#3e7a6e');
        if (bx + off + 7 <= 16) {
          r(x1 - 1, y + 1, 1, 3, '#387065');
          r(x1, y, 1, 4, '#244d45');
        }
        if (w >= 4) {
          r(x0 + 2, y + 2, 2, 1, (row + bx) % 2 === 0 ? '#4b8f82' : '#6eb5a7');
        }
      }
      r(0, y, 16, 1, '#244d45');
    }
    return true;
  }

  if (name === 'dark_prismarine') {
    // Tight 4x4 grid (4px each) of dark emerald-teal Ocean Monument mosaic tiles
    r(0, 0, 16, 16, '#152923');
    for (let ty = 0; ty < 4; ty++) {
      for (let tx = 0; tx < 4; tx++) {
        const x = tx * 4, y = ty * 4;
        const alt = (tx + ty) & 1;
        r(x, y, 4, 4, alt ? '#2d5247' : '#345c50');
        r(x, y, 4, 1, '#4c7d6e');
        r(x, y, 1, 4, '#437062');
        r(x, y + 3, 4, 1, '#1c362e');
        r(x + 3, y, 1, 4, '#1c362e');
        r(x + 1, y + 1, 1, 1, '#5d9483');
        r(x + 2, y + 2, 1, 1, '#25453b');
      }
    }
    return true;
  }

  if (name === 'sea_lantern' || name === 'sea_lantern_top' || name === 'sea_lantern_side') {
    // Authentic prismarine-rimmed octagonal frame surrounding a radiant layered aqua-white core
    r(0, 0, 16, 16, '#467d74');
    r(1, 1, 14, 14, '#6aa69c');
    r(2, 2, 12, 12, '#9ee0d4');
    r(3, 3, 10, 10, '#c8f5ec');
    r(4, 4, 8, 8, '#ebfffa');
    r(5, 5, 6, 6, '#ffffff');
    // Octagonal prismarine corner clasps
    for (const [cx, cy] of [[0, 0], [13, 0], [0, 13], [13, 13]]) {
      r(cx, cy, 3, 3, '#386961');
      r(cx + 1, cy + 1, 1, 1, '#7ab8ad');
    }
    // Subtle aqua wave shimmer bands inside the glowing core
    for (let y = 3; y < 13; y += 2) {
      r(3, y, 1, 1, '#85cfc2');
      r(12, y, 1, 1, '#85cfc2');
    }
    r(6, 6, 4, 4, '#ffffff');
    return true;
  }

  if (name === 'sponge' || name === 'sponge_top' || name === 'sponge_side') {
    // Bright dry golden-yellow porous marine sponge with multi-depth honeycomb cavities
    r(0, 0, 16, 16, '#ded35a');
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const h = (x * 7 + y * 13) % 7;
        if (h === 0) r(x, y, 1, 1, '#ede374');
        else if (h === 1) r(x, y, 1, 1, '#c9be48');
      }
    }
    const pores: [number, number, number, number][] = [
      [1, 1, 3, 2], [7, 1, 2, 3], [12, 2, 3, 2],
      [4, 5, 3, 3], [10, 6, 2, 2], [1, 8, 2, 3],
      [7, 10, 3, 2], [13, 10, 2, 3], [3, 13, 3, 2], [10, 13, 2, 2],
    ];
    for (const [px, py, pw, ph] of pores) {
      r(px, py, pw, ph, '#9e9233');
      r(px, py, Math.max(1, pw - 1), Math.max(1, ph - 1), '#6e651c');
      r(px + pw - 1, py + ph - 1, 1, 1, '#f5ec89');
    }
    return true;
  }

  if (name === 'wet_sponge' || name === 'wet_sponge_top' || name === 'wet_sponge_side') {
    // Waterlogged dark olive-ochre sponge with dark teal water-filled pores & wet glints
    r(0, 0, 16, 16, '#968f2e');
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const h = (x * 11 + y * 17) % 7;
        if (h === 0) r(x, y, 1, 1, '#aba338');
        else if (h === 1 || h === 2) r(x, y, 1, 1, '#7d7722');
      }
    }
    const pores: [number, number, number, number][] = [
      [1, 1, 3, 2], [7, 1, 2, 3], [12, 2, 3, 2],
      [4, 5, 3, 3], [10, 6, 2, 2], [1, 8, 2, 3],
      [7, 10, 3, 2], [13, 10, 2, 3], [3, 13, 3, 2], [10, 13, 2, 2],
    ];
    for (const [px, py, pw, ph] of pores) {
      r(px, py, pw, ph, '#3c634e');
      r(px, py, Math.max(1, pw - 1), Math.max(1, ph - 1), '#24473c');
      r(px + pw - 1, py, 1, 1, '#85d6c8'); // Glistening water droplet glint
    }
    return true;
  }

  if (name === 'conduit' || name === 'conduit_shell') {
    // Nautilus shell & prismarine cage texture: warm cream-tan shell with crimson-brown spiral stripes & teal corners
    r(0, 0, 16, 16, '#d6c3a5');
    r(0, 0, 16, 2, '#4f8c82'); r(0, 14, 16, 2, '#3b6e66');
    r(0, 0, 2, 16, '#4f8c82'); r(14, 0, 2, 16, '#3b6e66');
    r(2, 2, 12, 12, '#e8d8be');
    // Nautilus reddish-brown chamber stripes
    for (const sy of [3, 6, 9, 12]) {
      r(3, sy, 10, 1, '#9e4c36');
      r(4, sy + 1, 8, 1, '#ba684e');
    }
    r(5, 5, 6, 6, '#f5ead6');
    r(6, 6, 4, 4, '#38b8c9');
    return true;
  }

  if (name === 'conduit_core') {
    // Heart of the Sea orb: radiant deep-ocean sapphire to cyan-white pearl
    r(0, 0, 16, 16, '#144b8c');
    r(1, 1, 14, 14, '#1e6ec9');
    r(2, 2, 12, 12, '#2ea4eb');
    r(4, 4, 8, 8, '#64dcff');
    r(6, 6, 4, 4, '#d9fbff');
    r(5, 5, 2, 2, '#ffffff');
    return true;
  }

  if (name === 'conduit_eye') {
    // Hunting Conduit Eye: glowing golden-amber iris with cyan-white pupil slit
    r(0, 0, 16, 16, '#1e6ec9');
    r(2, 2, 12, 12, '#e69c24');
    r(3, 3, 10, 10, '#ffcf4a');
    r(4, 5, 8, 6, '#fff3a6');
    r(7, 3, 2, 10, '#14385c');
    r(6, 6, 4, 4, '#5ce6ff');
    r(6, 6, 2, 2, '#ffffff');
    return true;
  }

  if (name === 'sea_pickle_side') {
    // Olive-green & dark-teal warty Sea Pickle cylinder skin
    r(0, 0, 16, 16, '#557030');
    for (let x = 0; x < 16; x += 4) {
      r(x, 0, 1, 16, '#3e5422');
      r(x + 1, 0, 2, 16, '#68873b');
      r(x + 3, 0, 1, 16, '#48633e');
    }
    for (let y = 2; y < 15; y += 4) {
      r((y * 3) & 15, y, 2, 2, '#7fa14c');
      r(((y * 3) + 7) & 15, y + 1, 2, 1, '#34524a');
    }
    r(0, 0, 16, 2, '#7fa14c');
    r(0, 14, 16, 2, '#34471c');
    return true;
  }

  if (name === 'sea_pickle_top' || name === 'sea_pickle_stem') {
    // Bioluminescent pale-lime / coral-cream Sea Pickle crown
    r(0, 0, 16, 16, '#68873b');
    r(2, 2, 12, 12, '#a8d468');
    r(4, 4, 8, 8, '#dcf7a6');
    r(5, 5, 6, 6, '#fffbe0');
    r(6, 6, 4, 4, '#ffffff');
    return true;
  }

  if (name === 'turtle_egg_top') {
    r(0, 0, 16, 16, '#ede8d4');
    r(2, 2, 12, 12, '#f7f4e6');
    r(5, 5, 6, 6, '#ffffff');
    return true;
  }

  if (name === 'turtle_egg' || name === 'turtle_egg_side' || name === 'turtle_egg_crack1' || name === 'turtle_egg_crack2') {
    // Cream-parchment leathery Sea Turtle Egg with teal-green speckles & crack stages
    r(0, 0, 16, 16, '#e6e1cb');
    r(0, 0, 16, 2, '#f5f2e4');
    r(0, 13, 16, 3, '#c9c2a7');
    // Characteristic teal-green & olive speckles
    const spots: [number, number, number, number, string][] = [
      [2, 3, 2, 2, '#568c78'], [10, 2, 3, 2, '#6ea38e'],
      [5, 7, 3, 2, '#487866'], [12, 8, 2, 3, '#568c78'],
      [3, 11, 2, 2, '#6ea38e'], [9, 12, 3, 2, '#487866'],
    ];
    for (const [sx, sy, sw, sh, scol] of spots) r(sx, sy, sw, sh, scol);
    if (name === 'turtle_egg_crack1' || name === 'turtle_egg_crack2') {
      // Stage 1 hairline cracks
      r(6, 2, 1, 4, '#5c5346'); r(7, 5, 2, 1, '#5c5346'); r(8, 6, 1, 4, '#5c5346');
    }
    if (name === 'turtle_egg_crack2') {
      // Stage 2 deep hatching fissures
      r(3, 4, 1, 5, '#3b3329'); r(4, 8, 3, 1, '#3b3329');
      r(11, 3, 1, 6, '#3b3329'); r(9, 8, 2, 2, '#3b3329');
      r(7, 5, 2, 3, '#29231c');
    }
    return true;
  }

  // 5 Distinct Coral Block Species
  if (name === 'tube_coral_block') {
    // Sapphire-blue cluster of tubular sponge-coral polyps with dark circular orifices
    r(0, 0, 16, 16, '#2342b0');
    const tubes: [number, number][] = [
      [1, 1], [6, 0], [11, 1],
      [0, 6], [5, 5], [10, 6], [13, 5],
      [2, 11], [7, 10], [12, 11],
    ];
    for (const [tx, ty] of tubes) {
      r(tx, ty, 4, 4, '#3b65eb');
      r(tx, ty, 4, 1, '#6691ff');
      r(tx, ty, 1, 4, '#527dff');
      r(tx + 1, ty + 1, 2, 2, '#14266e');
      r(tx + 3, ty + 3, 1, 1, '#1c3594');
    }
    return true;
  }

  if (name === 'brain_coral_block') {
    // Labyrinthine rose-magenta cerebral gyri ridges and dark sulci grooves
    r(0, 0, 16, 16, '#7d1d4e');
    const gyri: [number, number, number, number][] = [
      [0, 1, 7, 2], [8, 0, 8, 2], [6, 2, 3, 3],
      [1, 4, 5, 2], [9, 4, 6, 2], [0, 6, 2, 4],
      [3, 7, 8, 2], [12, 7, 4, 3], [5, 9, 2, 3],
      [1, 11, 6, 2], [8, 11, 7, 2], [0, 14, 9, 2], [10, 14, 6, 2],
    ];
    for (const [gx, gy, gw, gh] of gyri) {
      r(gx, gy, gw, gh, '#d94c97');
      r(gx, gy, gw, 1, '#ff85c4');
    }
    return true;
  }

  if (name === 'bubble_coral_block') {
    // Packed glossy violet-magenta spherical vesicles with specular highlights
    r(0, 0, 16, 16, '#521070');
    const bubbles: [number, number, number][] = [
      [1, 1, 4], [6, 0, 5], [12, 1, 4],
      [0, 6, 4], [5, 5, 5], [11, 6, 4],
      [2, 11, 4], [7, 10, 5], [12, 11, 4],
    ];
    for (const [bx, by, bsz] of bubbles) {
      r(bx, by, bsz, bsz, '#9628c7');
      r(bx + 1, by, bsz - 2, bsz, '#b548e6');
      r(bx, by + 1, bsz, bsz - 2, '#b548e6');
      r(bx + 1, by + 1, 2, 2, '#e396ff');
      r(bx + 1, by + 1, 1, 1, '#ffffff');
    }
    return true;
  }

  if (name === 'fire_coral_block') {
    // Branching crimson-vermilion hydrocoral plates with glowing orange-yellow pore tips
    r(0, 0, 16, 16, '#801610');
    for (let y = 0; y < 16; y += 4) {
      const off = (y >> 2) & 1 ? 2 : 0;
      for (let x = off; x < 16; x += 5) {
        r(x, y, 4, 3, '#cf2c23');
        r(x, y, 3, 1, '#f25549');
        r(x + 1, y + 1, 2, 2, '#e03c32');
        r(x + 1, y, 1, 1, '#ffcf4a'); // Glowing hydrocoral tip
      }
    }
    return true;
  }

  if (name === 'horn_coral_block') {
    // Golden-yellow staghorn / hexagonal corallite polyps
    r(0, 0, 16, 16, '#876a0d');
    const horns: [number, number][] = [
      [1, 1], [6, 0], [11, 1],
      [3, 5], [8, 5], [13, 6],
      [0, 9], [5, 10], [10, 10],
      [2, 13], [8, 13], [13, 13],
    ];
    for (const [hx, hy] of horns) {
      r(hx, hy, 4, 3, '#d9b424');
      r(hx, hy, 3, 2, '#f5d942');
      r(hx + 1, hy, 2, 1, '#fff699');
      r(hx + 2, hy + 2, 1, 1, '#9e7c12');
    }
    return true;
  }

  // 5 Distinct Coral Fan / Frond Sprites
  if (name.endsWith('_coral')) {
    ctx.clearRect(0, 0, 16, 16);
    if (name === 'tube_coral') {
      // Organ-pipe cluster of sapphire-blue tubes with open rims
      const pipes: [number, number, number][] = [[2, 6, 8], [5, 3, 11], [8, 2, 12], [11, 5, 9]];
      for (const [px, py, ph] of pipes) {
        r(px, py, 3, ph, '#294ec7');
        r(px + 1, py, 1, ph, '#5982ff');
        r(px, py, 3, 1, '#8caaff');
        r(px + 1, py, 1, 1, '#122266');
      }
      r(4, 13, 8, 3, '#1e3a99');
      return true;
    }
    if (name === 'brain_coral') {
      // Scalloped rose-pink brain coral fan with meandering gyri fronds
      const fronds: [number, number, number][] = [
        [2, 6, 6], [4, 4, 8], [6, 3, 10], [8, 3, 10], [10, 4, 8], [12, 6, 6],
      ];
      for (const [fx, fy, fh] of fronds) {
        r(fx, fy, 2, fh, '#cf448c');
        r(fx, fy, 1, fh - 1, '#ff85c4');
        r(fx + 1, fy + 1, 1, fh - 1, '#9e2162');
      }
      r(5, 13, 6, 3, '#7d1d4e');
      return true;
    }
    if (name === 'bubble_coral') {
      // Grape-like cluster of glossy purple-magenta vesicles
      const bbs: [number, number, number][] = [
        [6, 2, 4], [3, 4, 4], [9, 4, 4],
        [2, 7, 4], [6, 6, 4], [10, 7, 4],
        [4, 10, 4], [8, 10, 4], [6, 12, 4],
      ];
      for (const [bx, by, s] of bbs) {
        r(bx, by, s, s, '#8f24bd');
        r(bx + 1, by + 1, s - 2, s - 2, '#cf68ff');
        r(bx + 1, by + 1, 1, 1, '#ffffff');
      }
      return true;
    }
    if (name === 'fire_coral') {
      // Jagged branching crimson flames with bright yellow-orange tips
      const branches: [number, number, number][] = [
        [2, 6, 6], [4, 4, 8], [7, 2, 12], [10, 4, 8], [12, 6, 6],
      ];
      for (const [bx, by, bh] of branches) {
        r(bx, by, 2, bh, '#d42c22');
        r(bx, by, 2, 2, '#ffcf4a');
        r(bx, by + 2, 1, bh - 2, '#ff6347');
      }
      r(4, 11, 8, 2, '#b8221a');
      r(6, 13, 4, 3, '#801610');
      return true;
    }
    if (name === 'horn_coral') {
      // Staghorn antler branches in radiant golden-yellow
      r(7, 2, 2, 14, '#d9b424');
      r(4, 3, 2, 7, '#f5d942'); r(4, 9, 3, 2, '#d9b424');
      r(10, 3, 2, 7, '#f5d942'); r(9, 9, 3, 2, '#d9b424');
      r(2, 6, 2, 5, '#f5d942'); r(12, 6, 2, 5, '#f5d942');
      for (const [tx, ty] of [[4, 2], [7, 1], [10, 2], [2, 5], [12, 5]]) {
        r(tx, ty, 2, 1, '#fff8a6');
      }
      return true;
    }
  }

  if (name === 'kelp' || name === 'kelp_top') {
    ctx.clearRect(0, 0, 16, 16);
    const isTop = name === 'kelp_top';
    const yStart = isTop ? 2 : 0;
    for (let y = yStart; y < 16; y++) {
      const wave = Math.round(Math.sin(y * 0.55) * 2);
      const sx = 6 + wave;
      r(sx, y, 3, 1, y % 2 === 0 ? '#3b7524' : '#4f9132');
      r(sx + 1, y, 1, 1, '#6eb548');
      // Lateral serrated kelp frond blades & pneumatocyst gas bladders
      if (y % 4 === 1 && y >= yStart + 1) {
        r(sx - 3, y, 3, 2, '#48872c');
        r(sx - 2, y, 2, 1, '#78c250');
      }
      if (y % 4 === 3 && y >= yStart + 1) {
        r(sx + 3, y, 3, 2, '#48872c');
        r(sx + 3, y, 2, 1, '#78c250');
      }
    }
    if (isTop) {
      r(6, 1, 3, 2, '#8cd660');
      r(7, 0, 2, 1, '#b2f085');
    }
    return true;
  }

  if (name === 'kelp_stem') {
    // Rich underwater kelp stalk & golden-lime pneumatocyst bladders
    r(0, 0, 16, 16, '#386e22');
    for (let x = 0; x < 16; x += 4) {
      r(x, 0, 2, 16, '#4d8f30');
      r(x + 1, 0, 1, 16, '#76bf4e');
    }
    r(2, 4, 12, 3, '#88cf58');
    r(2, 10, 12, 3, '#88cf58');
    return true;
  }

  if (name === 'seagrass') {
    ctx.clearRect(0, 0, 16, 16);
    const blades: [number, number, string, string][] = [
      [1, 8, '#2b662e', '#489648'],
      [4, 12, '#357a38', '#5cb356'],
      [7, 14, '#3f8c42', '#78d46c'],
      [10, 10, '#2b662e', '#489648'],
      [13, 13, '#357a38', '#68bf5e'],
    ];
    for (const [bx, bh, cDark, cLight] of blades) {
      const yTop = 16 - bh;
      for (let y = yTop; y < 16; y++) {
        const tip = y < yTop + 3;
        const sway = ((y >> 2) & 1) ? 1 : 0;
        r(bx + sway, y, tip ? 1 : 2, 1, tip ? cLight : cDark);
        if (!tip && y % 2 === 0) r(bx + sway, y, 1, 1, cLight);
      }
    }
    return true;
  }

  if (name === 'dried_kelp_block' || name === 'dried_kelp_block_top' || name === 'dried_kelp_block_bottom' || name === 'dried_kelp_block_side') {
    // Dark roasted olive-kombu bale tied with crisp off-white/tan twine
    r(0, 0, 16, 16, '#233018');
    for (let y = 0; y < 16; y += 2) {
      for (let x = 0; x < 16; x += 4) {
        const shift = (y >> 1) & 1 ? 2 : 0;
        r((x + shift) & 15, y, 3, 1, '#314222');
        r((x + shift + 1) & 15, y + 1, 2, 1, '#182110');
      }
    }
    // Outer dark bevel frame
    r(0, 0, 16, 1, '#3d522b'); r(0, 15, 16, 1, '#141c0d');
    r(0, 0, 1, 16, '#3d522b'); r(15, 0, 1, 16, '#141c0d');

    if (name === 'dried_kelp_block_top' || name === 'dried_kelp_block_bottom') {
      // Crossed twine tie-straps across the top & bottom of the bale
      r(7, 0, 2, 16, '#cfc5a8');
      r(0, 7, 16, 2, '#cfc5a8');
      r(7, 0, 1, 16, '#ebe3c7');
      r(0, 7, 16, 1, '#ebe3c7');
      if (name === 'dried_kelp_block_top') {
        // Central tied knot on top
        r(6, 6, 4, 4, '#b8ad8c');
        r(6, 6, 3, 3, '#f2ebd0');
        r(7, 7, 2, 2, '#cfc5a8');
      }
    } else {
      // Side face: horizontal & vertical twine tie bands
      r(7, 0, 2, 16, '#cfc5a8');
      r(7, 0, 1, 16, '#ebe3c7');
      r(0, 6, 16, 3, '#b8ad8c');
      r(0, 6, 16, 1, '#ebe3c7');
      r(0, 7, 16, 1, '#d9d0b2');
      r(0, 8, 16, 1, '#998f70');
    }
    return true;
  }

  return false;
}



// =====================================================================================================================
// 5. OVERHAULED 3D BLOCK TEXTURES (3-Iteration Reviewed & Vanilla-Exceeding 16x16 Pixel Art)
// =====================================================================================================================

// --- 5A. TERRAIN, SOIL, ICE, DRIPSTONE & AMETHYST ---

const DIRT_MAP = [
  '1211321012112321',
  '2421210123211212',
  '1210121211120121',
  '0121232101231210',
  '1232111212122121',
  '2111201342101232',
  '1012312121012121',
  '2121221012123210',
  '1321012123211121',
  '2112123211101212',
  '0123212101212431',
  '1212101212321212',
  '2321212431210121',
  '1210121212101232',
  '1012321011212121',
  '2121112123121012',
];
const DIRT_PAL: Record<string, string> = {
  '0': '#6f4e35',
  '1': '#7d593e',
  '2': '#8c6548',
  '3': '#9d7454',
  '4': '#b08663',
};

const GRASS_TOP_MAP = [
  '2321223212343212',
  '3432134321232123',
  '2321223210121232',
  '1212312121232343',
  '2323421012343232',
  '3432312123232121',
  '2321223234121012',
  '1210134323212123',
  '2321223212323234',
  '3432312101234323',
  '2323421212323212',
  '1212312323212101',
  '2321201234321212',
  '3432112323212323',
  '2323223412101234',
  '1212132321212323',
];
const GRASS_TOP_PAL: Record<string, string> = {
  '0': '#929292',
  '1': '#9f9f9f',
  '2': '#acacac',
  '3': '#b8b8b8',
  '4': '#c5c5c5',
};

const PODZOL_TOP_MAP = [
  '1233210123432101',
  '0124321012321012',
  '1232101234310123',
  '2343212321012342',
  '1232101210123210',
  '0101234321234321',
  '1212321012321012',
  '2343101234310123',
  '3210123210123432',
  '1012343101232101',
  '0123210123431012',
  '1234321232101234',
  '2321012343212321',
  '1012343210123432',
  '0123210123432101',
  '1234321012321012',
];
const PODZOL_TOP_PAL: Record<string, string> = {
  '0': '#472e17',
  '1': '#5e3e1f',
  '2': '#78512a',
  '3': '#946635',
  '4': '#b07d44',
};

const MYCELIUM_TOP_MAP = [
  '1232101234321012',
  '2343210123210123',
  '3232101210123432',
  '1012343212321210',
  '0123212343101012',
  '1234301232123234',
  '2321012321012432',
  '1012321012343210',
  '0123432123210123',
  '1232123431012342',
  '2343012321232121',
  '3210123210123012',
  '1012343101234323',
  '0123212343212342',
  '1234301232101231',
  '2123210121012321',
];
const MYCELIUM_TOP_PAL: Record<string, string> = {
  '0': '#4f4452',
  '1': '#675a6b',
  '2': '#7d6f82',
  '3': '#948599',
  '4': '#b0a0b5',
};

const MUD_MAP = [
  '1221012321012210',
  '2332101210123321',
  '1221012101232212',
  '0110123212321101',
  '1232234321210122',
  '2343223210121233',
  '1232112101232321',
  '0121001212343210',
  '1232112323232101',
  '2321023432121012',
  '1210123210012123',
  '0121212101223212',
  '1232321012334321',
  '2343210123223210',
  '1232101232112101',
  '0121012121001211',
];
const MUD_PAL: Record<string, string> = {
  '0': '#262329',
  '1': '#333037',
  '2': '#3e3a42',
  '3': '#4d4852',
  '4': '#615b66',
};

const CLAY_MAP = [
  '2233211223321122',
  '2343212334321232',
  '1232101223210121',
  '1121012322101211',
  '2232123432112322',
  '3343234432123433',
  '2332123321012332',
  '1221012210121221',
  '1121123321232111',
  '2232234322343222',
  '2343223212332123',
  '1232112101221012',
  '1121011212210111',
  '2232122323321222',
  '2343223433432232',
  '1232112322321121',
];
const CLAY_PAL: Record<string, string> = {
  '0': '#7f8691',
  '1': '#9199a3',
  '2': '#a1a9b2',
  '3': '#b2bac2',
  '4': '#c3cbd4',
};

const SNOW_MAP = [
  '2332234322332123',
  '3443233212343233',
  '2332122123322343',
  '2221233234321232',
  '3322344323212223',
  '3432333212223334',
  '2321222123334433',
  '1222332234323322',
  '2333432332212223',
  '3443321221223334',
  '2332212232334432',
  '2221223343233221',
  '2332334332122122',
  '3432343221223233',
  '2321232122334323',
  '2212222233233222',
];
const SNOW_PAL: Record<string, string> = {
  '1': '#d0e2eb',
  '2': '#e4f0f6',
  '3': '#f2f9fc',
  '4': '#ffffff',
};

const ICE_MAP = [
  '2234322211223322',
  '2344321122234322',
  '2233211223443221',
  '1122112234322112',
  '1222223443211222',
  '2233234322112233',
  '2343343211223343',
  '2232332112234432',
  '1121221123443221',
  '1221112344322111',
  '2232123432211222',
  '2343233221122332',
  '2233322112234432',
  '1122211223443221',
  '1221122343322112',
  '2211223322211222',
];

const MOSS_MAP = [
  '2321234321232122',
  '3432123212343231',
  '2321012123232122',
  '1212123232121012',
  '2323234321012123',
  '3434323212123234',
  '2323212123234323',
  '1212101234323212',
  '2321212323212101',
  '3432323212101212',
  '2323432101212323',
  '1212321212323432',
  '0121212323432321',
  '1232323432321212',
  '2343232321210123',
  '3232121212321232',
];
const MOSS_PAL: Record<string, string> = {
  '0': '#36521b',
  '1': '#496b26',
  '2': '#5b8231',
  '3': '#6f993d',
  '4': '#84b04b',
};

const DRIPSTONE_BLOCK_MAP = [
  '1210123210121012',
  '2321012101232123',
  '1212101212321012',
  '0101212321210101',
  '1212321210121212',
  '2321210121232321',
  '1210121232121210',
  '0121232121010121',
  '1232121012121232',
  '2321012123232121',
  '1212123212121010',
  '0101212101012121',
  '1212321212123232',
  '2321210123212121',
  '1210121212101012',
  '0121232101212121',
];
const DRIPSTONE_PAL: Record<string, string> = {
  '0': '#543f34',
  '1': '#6e5446',
  '2': '#866b5c',
  '3': '#9e8170',
  '4': '#b59886',
};

const AMETHYST_BLOCK_MAP = [
  '1234310123210121',
  '2345421014321232',
  '3454312123432343',
  '1232103432123454',
  '0121014543012343',
  '1232123432101232',
  '2343212321210121',
  '3454301212321232',
  '2343210123432343',
  '1232121234543454',
  '0121232345432343',
  '1232343234321232',
  '2343454123210121',
  '3454343012101232',
  '2343232101212343',
  '1232121212323432',
];
const AMETHYST_PAL: Record<string, string> = {
  '0': '#432766',
  '1': '#5c3887',
  '2': '#794db0',
  '3': '#996dd1',
  '4': '#be95f2',
  '5': '#ebdcff',
};

const STONE_BASE_MAP = [
  '2233211223321122',
  '1222112332211221',
  '2332223432112332',
  '2221122321122222',
  '1112233222332111',
  '2223343212343222',
  '3322332111232233',
  '2211221122121122',
  '1222112233211221',
  '2333223343222332',
  '2232122332123322',
  '1121112221122211',
  '2222233222332222',
  '2332343212343232',
  '1221232111232121',
  '2112121222121212',
];

export function drawTerrainAndMineralTile(name: string, ctx: Context2D): boolean {
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  // 1. Dirt & Variants (Dirt, Coarse Dirt, Rooted Dirt, Dirt Path)
  if (name === 'dirt' || name === 'coarse_dirt' || name === 'rooted_dirt') {
    drawGrid(ctx, DIRT_MAP, DIRT_PAL);
    if (name === 'coarse_dirt') {
      const pebbles: [number, number, number, number][] = [
        [2, 2, 2, 2], [11, 1, 2, 2], [6, 5, 3, 2], [1, 9, 2, 2],
        [12, 8, 2, 2], [5, 12, 3, 2], [10, 13, 2, 2],
      ];
      for (const [px, py, pw, ph] of pebbles) {
        r(px, py, pw, ph, '#523824');
        r(px, py, pw - 1, 1, '#9e9284');
        r(px + 1, py + 1, 1, 1, '#786e62');
      }
    } else if (name === 'rooted_dirt') {
      const roots: [number, number, number, number][] = [
        [3, 0, 1, 5], [4, 4, 2, 3], [11, 1, 1, 6], [9, 6, 3, 2],
        [2, 9, 2, 5], [7, 11, 2, 4], [13, 10, 1, 5],
      ];
      for (const [rx, ry, rw, rh] of roots) {
        r(rx, ry, rw, rh, '#a87d56');
        r(rx, ry, 1, 1, '#cfa47a');
      }
    }
    return true;
  }

  if (name === 'dirt_path') {
    r(0, 0, 16, 16, '#947442');
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const k = (x * 5 + y * 9 + ((x ^ y) & 3)) % 7;
        if (k === 0) r(x, y, 1, 1, '#75592f');
        else if (k === 1 || k === 2) r(x, y, 1, 1, '#856738');
        else if (k === 5) r(x, y, 1, 1, '#a88750');
        else if (k === 6) r(x, y, 1, 1, '#bd9b62');
      }
    }
    return true;
  }

  // 2. Grass Block, Podzol, Mycelium (Top & Side)
  if (name === 'grass_block') {
    drawGrid(ctx, GRASS_TOP_MAP, GRASS_TOP_PAL);
    return true;
  }
  if (name === 'podzol') {
    drawGrid(ctx, PODZOL_TOP_MAP, PODZOL_TOP_PAL);
    return true;
  }
  if (name === 'mycelium') {
    drawGrid(ctx, MYCELIUM_TOP_MAP, MYCELIUM_TOP_PAL);
    return true;
  }
  if (name === 'grass_side' || name === 'podzol_side' || name === 'mycelium_side' || name === 'dirt_path_side') {
    drawGrid(ctx, DIRT_MAP, DIRT_PAL);
    const isPod = name === 'podzol_side';
    const isMyc = name === 'mycelium_side';
    const isPath = name === 'dirt_path_side';
    const drips = isMyc
      ? [4, 5, 6, 4, 3, 5, 7, 5, 4, 6, 5, 3, 4, 6, 5, 4]
      : isPod
      ? [3, 4, 5, 3, 2, 4, 4, 3, 5, 4, 3, 2, 4, 5, 3, 3]
      : isPath
      ? [2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2]
      : [2, 3, 4, 2, 3, 2, 4, 3, 2, 3, 4, 3, 2, 3, 3, 2];
    const cTop = isPod ? '#9e6f3a' : isMyc ? '#a896ad' : isPath ? '#b5945b' : '#8cc24a';
    const cMid = isPod ? '#7d5429' : isMyc ? '#827187' : isPath ? '#967642' : '#73ab38';
    const cBot = isPod ? '#5e3d1c' : isMyc ? '#635369' : isPath ? '#785c30' : '#5f942b';
    for (let x = 0; x < 16; x++) {
      const d = drips[x];
      r(x, 0, 1, d, cMid);
      r(x, 0, 1, 1, cTop);
      if (d >= 3 && (x % 2 === 0)) r(x, 1, 1, 1, cTop);
      r(x, d - 1, 1, 1, cBot);
      if (isPod || isMyc || isPath) r(x, d, 1, 1, '#5e4028');
    }
    return true;
  }

  // 3. Mud, Packed Mud, Mud Bricks & Clay
  if (name === 'mud') {
    drawGrid(ctx, MUD_MAP, MUD_PAL);
    return true;
  }
  if (name === 'packed_mud') {
    r(0, 0, 16, 16, '#8c684c');
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const k = (x * 7 + y * 11) % 9;
        if (k === 0) r(x, y, 1, 1, '#6e4f38');
        else if (k === 1 || k === 2) r(x, y, 1, 1, '#7d5b42');
        else if (k === 6) r(x, y, 1, 1, '#9e785a');
        else if (k === 7) r(x, y, 1, 1, '#ba9368'); // Wheat straw fiber
      }
    }
    return true;
  }
  if (name === 'mud_bricks') {
    r(0, 0, 16, 16, '#5c4433');
    for (let row = 0; row < 4; row++) {
      const y = row * 4;
      const off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        const x0 = Math.max(0, bx + off), x1 = Math.min(16, bx + off + 7);
        if (x1 <= x0) continue;
        r(x0, y + 1, x1 - x0, 3, '#8c694f');
        r(x0, y + 1, x1 - x0, 1, '#a68063');
        r(x0, y + 1, 1, 3, '#9c775b');
        r(x0, y + 3, x1 - x0, 1, '#73543e');
      }
    }
    return true;
  }
  if (name === 'clay') {
    drawGrid(ctx, CLAY_MAP, CLAY_PAL);
    return true;
  }

  // 4. Snow, Ice, Packed Ice, Blue Ice & Frosted Ice
  if (name === 'snow_block' || name === 'snow_layer' || name === 'powder_snow') {
    drawGrid(ctx, SNOW_MAP, SNOW_PAL);
    if (name === 'powder_snow') {
      for (let i = 0; i < 16; i += 3) {
        r((i * 5) % 15, (i * 7) % 15, 2, 1, '#bfd6e3');
      }
    }
    return true;
  }

  if (name === 'ice' || name === 'frosted_ice') {
    ctx.clearRect(0, 0, 16, 16);
    const pal: Record<string, string> = {
      '1': 'rgba(118,175,235,0.68)',
      '2': 'rgba(145,198,246,0.74)',
      '3': 'rgba(178,220,255,0.82)',
      '4': 'rgba(232,248,255,0.92)',
    };
    drawGrid(ctx, ICE_MAP, pal);
    // Crisp specular diagonal frost glint
    for (let i = 2; i < 13; i++) {
      r(i, 14 - i, 1, 1, 'rgba(245,252,255,0.94)');
      if (i < 11) r(i + 1, 14 - i, 1, 1, 'rgba(195,232,255,0.85)');
    }
    return true;
  }

  if (name === 'packed_ice') {
    drawGrid(ctx, ICE_MAP, {
      '1': '#6b9be0',
      '2': '#82b2f0',
      '3': '#9ec8fa',
      '4': '#cce4ff',
    });
    r(3, 2, 4, 1, '#e3f2ff'); r(2, 3, 2, 2, '#e3f2ff');
    r(10, 9, 4, 1, '#5886cc'); r(9, 10, 3, 2, '#5886cc');
    return true;
  }

  if (name === 'blue_ice') {
    drawGrid(ctx, ICE_MAP, {
      '1': '#3d6fd6',
      '2': '#5287f0',
      '3': '#6fa3fc',
      '4': '#a3cbff',
    });
    for (let i = 1; i < 14; i += 3) {
      r(i, 15 - i, 2, 1, '#d6ebff');
      r((i + 5) % 14, i, 2, 1, '#2b56b5');
    }
    return true;
  }

  // 5. Moss Block & Moss Carpet
  if (name === 'moss_block' || name === 'moss_carpet') {
    drawGrid(ctx, MOSS_MAP, MOSS_PAL);
    return true;
  }

  // 6. Dripstone Block & Pointed Dripstone
  if (name === 'dripstone_block') {
    drawGrid(ctx, DRIPSTONE_BLOCK_MAP, DRIPSTONE_PAL);
    return true;
  }
  if (name === 'pointed_dripstone') {
    ctx.clearRect(0, 0, 16, 16);
    // Stepped stalactite/stalagmite with calcified mineral ridges & central highlight
    for (let y = 0; y < 16; y++) {
      const w = y < 3 ? 10 : y < 6 ? 8 : y < 10 ? 6 : y < 13 ? 4 : 2;
      const x0 = 8 - (w >> 1);
      r(x0, y, w, 1, '#7a5f50');
      r(x0, y, 1, 1, '#543f34');
      r(x0 + w - 1, y, 1, 1, '#543f34');
      if (w >= 4) {
        r(x0 + 1, y, Math.max(1, w - 2), 1, y % 3 === 0 ? '#9e8170' : '#866b5c');
        r(x0 + 1, y, 1, 1, '#b59886');
      } else {
        r(x0, y, 1, 1, '#9e8170');
      }
    }
    return true;
  }

  // 7. Amethyst Block, Budding Amethyst & 4 Amethyst Growth Stages
  if (name === 'amethyst_block' || name === 'amethyst_block_top' || name === 'amethyst_block_side') {
    drawGrid(ctx, AMETHYST_BLOCK_MAP, AMETHYST_PAL);
    return true;
  }
  if (name === 'budding_amethyst') {
    drawGrid(ctx, AMETHYST_BLOCK_MAP, AMETHYST_PAL);
    // Iconic X-shaped geode fracture lines where buds sprout
    for (let i = 2; i < 14; i++) {
      r(i, i, 2, 1, '#2b1644');
      r(14 - i, i, 2, 1, '#2b1644');
      if (i >= 4 && i <= 11) {
        r(i, i, 1, 1, '#e2bfff');
        r(15 - i, i, 1, 1, '#e2bfff');
      }
    }
    r(7, 7, 2, 2, '#ffffff');
    return true;
  }
  if (name === 'small_amethyst_bud' || name === 'medium_amethyst_bud' || name === 'large_amethyst_bud' || name === 'amethyst_cluster') {
    ctx.clearRect(0, 0, 16, 16);
    const stage = name === 'small_amethyst_bud' ? 1 : name === 'medium_amethyst_bud' ? 2 : name === 'large_amethyst_bud' ? 3 : 4;
    const spikes: [number, number, number][] =
      stage === 1 ? [[5, 3, 5], [7, 4, 6], [9, 3, 4]] :
      stage === 2 ? [[3, 2, 6], [5, 3, 8], [8, 2, 9], [11, 2, 5]] :
      stage === 3 ? [[2, 2, 8], [4, 3, 10], [7, 3, 12], [10, 2, 9], [12, 2, 6]] :
      [[1, 2, 9], [3, 3, 12], [6, 4, 15], [10, 3, 13], [13, 2, 8]];
    for (const [sx, sw, sh] of spikes) {
      const y0 = 16 - sh;
      r(sx, y0 + 1, sw, sh - 1, '#6b3fa0');
      r(sx, y0 + 1, Math.max(1, sw - 1), sh - 1, '#9462d1');
      r(sx, y0 + 1, 1, sh - 1, '#d6b2ff');
      r(sx + (sw >> 1), y0, Math.max(1, sw - 1), 2, '#f0dcff');
      r(sx + (sw >> 1), y0, 1, 1, '#ffffff');
    }
    r(2, 14, 12, 2, '#4d2b78');
    return true;
  }

  // --- 5B. ORES, RAW ORE BLOCKS & PURE MINERAL BLOCKS ---

  // 8. All Stone, Deepslate & Nether Ores (Coal, Iron, Copper, Gold, Redstone, Lapis, Diamond, Emerald, Quartz)
  if (name.endsWith('_ore')) {
    const deepslate = name.startsWith('deepslate_');
    const nether = name.startsWith('nether_');
    if (nether) {
      r(0, 0, 16, 16, '#6e322c');
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const k = (x * 5 + y * 7) % 6;
          if (k === 0) r(x, y, 1, 1, '#4f211d');
          else if (k === 1) r(x, y, 1, 1, '#854039');
          else if (k === 3) r(x, y, 1, 1, '#5c2824');
        }
      }
    } else {
      drawGrid(ctx, STONE_BASE_MAP, deepslate ? {
        '1': '#36383d',
        '2': '#494b52',
        '3': '#5a5d66',
        '4': '#6c707a',
      } : {
        '1': '#686a65',
        '2': '#7d807a',
        '3': '#8f928b',
        '4': '#a3a69e',
      });
    }

    const core = name.replace(/^(deepslate_|nether_)/, '').replace(/_ore$/, '');
    if (core === 'coal') {
      const spots: [number, number, number, number][] = [[2, 2, 3, 2], [9, 2, 4, 2], [5, 6, 3, 3], [11, 7, 3, 2], [2, 11, 4, 2], [8, 12, 3, 2]];
      for (const [ox, oy, ow, oh] of spots) {
        r(ox, oy, ow, oh, '#17181a');
        r(ox, oy, Math.max(1, ow - 1), 1, '#3b3e42');
        r(ox, oy, 1, 1, '#585d63');
      }
    } else if (core === 'iron') {
      // 1.17+ diagonal raw iron streaks with warm cream highlights
      const streaks: [number, number, number, number][] = [[2, 2, 4, 2], [9, 3, 4, 2], [4, 7, 5, 2], [10, 8, 3, 3], [2, 12, 4, 2], [8, 12, 4, 2]];
      for (const [ox, oy, ow, oh] of streaks) {
        r(ox, oy, ow, oh, '#946b52');
        r(ox, oy, ow - 1, oh, '#cfa382');
        r(ox, oy, 2, 1, '#f5d9bf');
      }
    } else if (core === 'copper') {
      // 1.17+ copper ore: vibrant burnt-orange veins + verdigris oxidized malachite teal accents
      const veins: [number, number, number, number][] = [[2, 2, 4, 2], [9, 2, 4, 3], [3, 6, 4, 3], [9, 7, 4, 2], [2, 11, 5, 2], [9, 12, 4, 2]];
      for (const [ox, oy, ow, oh] of veins) {
        r(ox, oy, ow, oh, '#9c4b2b');
        r(ox, oy, ow - 1, oh - 1, '#d96f43');
        r(ox, oy, 2, 1, '#ff9e70');
        r(ox + ow - 2, oy + oh - 1, 2, 1, '#3b9c79'); // Oxidized green-teal mineral accent
      }
    } else if (core === 'gold') {
      const nuggets: [number, number, number, number][] = [[2, 3, 3, 2], [10, 2, 3, 3], [5, 6, 4, 2], [11, 8, 3, 2], [3, 11, 3, 3], [8, 12, 4, 2]];
      for (const [ox, oy, ow, oh] of nuggets) {
        r(ox, oy, ow, oh, '#b87d14');
        r(ox, oy, ow - 1, oh, '#f5c732');
        r(ox, oy, 1, 1, '#ffffb5');
      }
    } else if (core === 'redstone') {
      const crystals: [number, number, number, number][] = [[3, 2, 2, 3], [10, 2, 3, 2], [6, 6, 3, 3], [2, 8, 2, 3], [11, 8, 3, 3], [4, 12, 3, 2], [9, 13, 3, 2]];
      for (const [ox, oy, ow, oh] of crystals) {
        r(ox, oy, ow, oh, '#780e0a');
        r(ox, oy, ow - 1, oh - 1, '#d92118');
        r(ox, oy, 1, 1, '#ff7366');
      }
    } else if (core === 'lapis') {
      const lazuli: [number, number, number, number][] = [[2, 2, 4, 3], [9, 2, 4, 2], [5, 6, 5, 3], [2, 11, 4, 2], [9, 11, 4, 3]];
      for (const [ox, oy, ow, oh] of lazuli) {
        r(ox, oy, ow, oh, '#142d7a');
        r(ox, oy, ow - 1, oh - 1, '#2654c9');
        r(ox + 1, oy, 2, 1, '#6898ff');
        r(ox + ow - 1, oy + 1, 1, 1, '#e6c35c'); // Pyrite gold speck
      }
    } else if (core === 'diamond') {
      const gems: [number, number, number, number][] = [[2, 2, 3, 3], [10, 3, 3, 3], [5, 7, 3, 3], [2, 11, 3, 3], [9, 11, 4, 3]];
      for (const [ox, oy, ow, oh] of gems) {
        r(ox, oy, ow, oh, '#197d87');
        r(ox, oy, ow - 1, oh - 1, '#3de0eb');
        r(ox, oy, 2, 1, '#a6fcff');
        r(ox, oy, 1, 1, '#ffffff');
      }
    } else if (core === 'emerald') {
      // Iconic hexagonal-cut small emerald crystals embedded in rock
      const hexGems: [number, number][] = [[3, 2], [10, 3], [6, 6], [12, 8], [3, 10], [8, 12], [12, 13]];
      for (const [ox, oy] of hexGems) {
        r(ox, oy, 2, 3, '#0e6928');
        r(ox, oy, 2, 2, '#24cf57');
        r(ox, oy, 1, 1, '#a8ffbf');
      }
    } else if (core === 'quartz') {
      const shards: [number, number, number, number][] = [[2, 2, 4, 2], [9, 2, 5, 2], [4, 6, 5, 2], [10, 8, 4, 2], [2, 11, 5, 2], [8, 12, 5, 2]];
      for (const [ox, oy, ow, oh] of shards) {
        r(ox, oy, ow, oh, '#b8ada0');
        r(ox, oy, ow - 1, 1, '#f2ece1');
        r(ox, oy, 2, 1, '#ffffff');
      }
    }
    return true;
  }

  // 9. Raw Ore Blocks (Raw Iron Block, Raw Copper Block)
  if (name === 'raw_iron_block' || name === 'raw_copper_block') {
    const isIron = name === 'raw_iron_block';
    r(0, 0, 16, 16, isIron ? '#78563e' : '#7a3b22');
    const nodules: [number, number, number, number, number][] = [
      [0, 0, 5, 4, 0], [5, 0, 6, 5, 1], [11, 0, 5, 4, 0],
      [0, 4, 4, 5, 1], [4, 5, 5, 5, 0], [9, 4, 4, 5, 2], [13, 4, 3, 5, 1],
      [0, 9, 5, 4, 0], [5, 10, 6, 4, 1], [11, 9, 5, 4, 0],
      [0, 13, 6, 3, 1], [6, 14, 5, 2, 0], [11, 13, 5, 3, 2],
    ];
    for (const [nx, ny, nw, nh, kind] of nodules) {
      const baseCol = isIron
        ? (kind === 0 ? '#bd9272' : kind === 1 ? '#d4ab8a' : '#a67b5b')
        : (kind === 0 ? '#cf6940' : kind === 1 ? '#e37e52' : '#3d9676');
      const hiCol = isIron ? '#f5d8bd' : (kind === 2 ? '#66c4a3' : '#ffa97d');
      r(nx + 1, ny + 1, nw - 1, nh - 1, baseCol);
      r(nx + 1, ny + 1, Math.max(1, nw - 2), 1, hiCol);
      r(nx + 1, ny + 1, 1, Math.max(1, nh - 2), hiCol);
    }
    return true;
  }

  // 10. Block of Coal
  if (name === 'coal_block') {
    r(0, 0, 16, 16, '#141517');
    const chunks: [number, number, number, number][] = [
      [1, 1, 6, 5], [8, 1, 7, 4], [1, 7, 5, 4], [7, 6, 5, 5], [13, 6, 2, 5],
      [1, 12, 6, 3], [8, 12, 7, 3],
    ];
    for (const [cx, cy, cw, ch] of chunks) {
      r(cx, cy, cw, ch, '#222428');
      r(cx, cy, cw - 1, 1, '#383c42');
      r(cx, cy, 1, ch - 1, '#31353b');
      r(cx + 1, cy + 1, 1, 1, '#4f555e'); // Anthracite glossy glint
    }
    return true;
  }

  // 11. Block of Iron
  if (name === 'iron_block') {
    r(0, 0, 16, 16, '#b8bcbd');
    r(0, 0, 16, 1, '#ffffff');
    r(0, 0, 1, 16, '#f2f5f5');
    r(0, 15, 16, 1, '#8c9194');
    r(15, 0, 1, 16, '#8c9194');
    r(1, 1, 14, 14, '#dcdfe0');
    // Subtle brushed horizontal metallic bands (Jappa 1.14+ iron block)
    const bands: [number, string][] = [
      [2, '#eceff0'], [3, '#f7fafa'], [5, '#cfd4d6'], [6, '#e3e6e8'],
      [8, '#f2f5f5'], [10, '#c8cdd0'], [11, '#d6dbde'], [13, '#edf0f2'],
    ];
    for (const [by, bcol] of bands) r(1, by, 14, 1, bcol);
    // Diagonal sheen
    for (let i = 2; i < 13; i++) {
      r(i, 14 - i, 2, 1, '#ffffff');
    }
    return true;
  }

  // 12. Copper Family (Block of Copper, Cut Copper, Chiseled Copper + Exposed/Weathered/Oxidized)
  if (
    name === 'copper_block' || name === 'exposed_copper' || name === 'weathered_copper' || name === 'oxidized_copper' ||
    name === 'cut_copper' || name === 'exposed_cut_copper' || name === 'weathered_cut_copper' || name === 'oxidized_cut_copper' ||
    name === 'chiseled_copper' || name === 'exposed_chiseled_copper' || name === 'weathered_chiseled_copper' || name === 'oxidized_chiseled_copper'
  ) {
    const ox = name.includes('oxidized') ? 3 : name.includes('weathered') ? 2 : name.includes('exposed') ? 1 : 0;
    const base = ox === 3 ? '#52a384' : ox === 2 ? '#6c996f' : ox === 1 ? '#a17e68' : '#c26b4c';
    const hi = ox === 3 ? '#78c9aa' : ox === 2 ? '#8fbd92' : ox === 1 ? '#c29e86' : '#e68c6a';
    const hi2 = ox === 3 ? '#9ee3c8' : ox === 2 ? '#b0d9b2' : ox === 1 ? '#dbb8a0' : '#ffab88';
    const dk = ox === 3 ? '#397860' : ox === 2 ? '#4d7350' : ox === 1 ? '#7a5c49' : '#944a30';
    const dk2 = ox === 3 ? '#285946' : ox === 2 ? '#39573b' : ox === 1 ? '#5c4334' : '#6e331e';

    if (name.includes('cut_copper')) {
      // 2x2 riveted cut copper tiles
      r(0, 0, 16, 16, dk2);
      for (const [bx, by] of [[0, 0], [8, 0], [0, 8], [8, 8]]) {
        r(bx, by, 7, 7, base);
        r(bx, by, 7, 1, hi);
        r(bx, by, 1, 7, hi);
        r(bx, by + 6, 7, 1, dk);
        r(bx + 6, by, 1, 7, dk);
        r(bx + 1, by + 1, 2, 1, hi2);
        r(bx + 5, by + 5, 1, 1, dk2);
      }
      return true;
    }

    if (name.includes('chiseled_copper')) {
      r(0, 0, 16, 16, dk2);
      r(1, 1, 14, 14, base);
      r(1, 1, 14, 1, hi); r(1, 1, 1, 14, hi);
      r(1, 14, 14, 1, dk); r(14, 1, 1, 14, dk);
      r(3, 3, 10, 10, dk2);
      r(4, 4, 8, 8, base);
      r(4, 4, 8, 1, hi2); r(4, 4, 1, 8, hi2);
      r(6, 6, 4, 4, dk2);
      r(7, 7, 2, 2, hi2);
      return true;
    }

    // Standard Copper Block: bevel border, brushed diagonal metallic sheen & corner rivets
    r(0, 0, 16, 16, dk2);
    r(0, 0, 15, 1, hi2);
    r(0, 0, 1, 15, hi);
    r(1, 1, 14, 14, base);
    for (let i = 1; i < 14; i++) {
      r(i, 14 - i, 2, 1, hi);
      if (i >= 3 && i <= 11) r(i, 13 - i, 1, 1, hi2);
      if (i + 4 < 15) r(i + 3, 14 - i, 2, 1, dk);
    }
    // Corner oxidation/rivet accents
    r(2, 2, 1, 1, dk); r(13, 2, 1, 1, dk);
    r(2, 13, 1, 1, dk); r(13, 13, 1, 1, dk);
    return true;
  }

  // 13. Block of Gold
  if (name === 'gold_block') {
    r(0, 0, 16, 16, '#ad710e');
    r(0, 0, 15, 1, '#fff8a6');
    r(0, 0, 1, 15, '#ffea6e');
    r(1, 1, 14, 14, '#f5c428');
    r(2, 2, 12, 12, '#e6b01c');
    r(2, 2, 12, 1, '#ffe863');
    r(2, 2, 1, 12, '#ffe863');
    r(2, 13, 12, 1, '#bd8012');
    r(13, 2, 1, 12, '#bd8012');
    // Diagonal mirror-gold gleam
    for (let i = 3; i < 12; i++) {
      r(i, 14 - i, 2, 1, '#fff385');
      r(i, 13 - i, 1, 1, '#ffffff');
    }
    return true;
  }

  // 14. Block of Redstone
  if (name === 'redstone_block') {
    r(0, 0, 16, 16, '#4f0906');
    r(0, 0, 15, 1, '#eb3b30');
    r(0, 0, 1, 15, '#d62d22');
    r(1, 1, 14, 14, '#9c1610');
    r(2, 2, 12, 12, '#750e0a');
    r(3, 3, 10, 10, '#bd1e17');
    r(4, 4, 8, 8, '#db2b22');
    r(5, 5, 6, 6, '#f54236');
    r(6, 6, 4, 4, '#ff6e5e');
    r(7, 7, 2, 2, '#ffa396');
    // Corner redstone circuit conduit bars
    r(1, 7, 2, 2, '#f54236'); r(13, 7, 2, 2, '#f54236');
    r(7, 1, 2, 2, '#f54236'); r(7, 13, 2, 2, '#f54236');
    return true;
  }

  // 15. Block of Lapis Lazuli
  if (name === 'lapis_block') {
    r(0, 0, 16, 16, '#102466');
    r(0, 0, 15, 1, '#4c7ef0');
    r(0, 0, 1, 15, '#3b6bd9');
    r(1, 1, 14, 14, '#1e43ab');
    for (let y = 1; y < 15; y++) {
      for (let x = 1; x < 15; x++) {
        const k = (x * 7 + y * 13) % 11;
        if (k === 0) r(x, y, 1, 1, '#153184');
        else if (k === 1 || k === 2) r(x, y, 1, 1, '#2b58cf');
        else if (k === 5) r(x, y, 1, 1, '#3e6fe8');
      }
    }
    // Authentic golden pyrite flecks in ultramarine stone
    const flecks: [number, number][] = [[3, 3], [11, 2], [7, 5], [2, 9], [12, 8], [6, 11], [10, 13]];
    for (const [fx, fy] of flecks) {
      r(fx, fy, 1, 1, '#e6c665');
      r(fx + 1, fy, 1, 1, '#5888ff');
    }
    return true;
  }

  // 16. Block of Diamond
  if (name === 'diamond_block') {
    r(0, 0, 16, 16, '#1b858f');
    r(0, 0, 15, 1, '#c9ffff');
    r(0, 0, 1, 15, '#9efcff');
    r(1, 1, 14, 14, '#4ce3ed');
    r(2, 2, 12, 12, '#2eb8c4');
    r(3, 3, 10, 10, '#62f0f7');
    r(3, 3, 10, 1, '#d6ffff');
    r(3, 3, 1, 10, '#d6ffff');
    r(3, 12, 10, 1, '#229aa6');
    r(12, 3, 1, 10, '#229aa6');
    // Brilliant cut diagonal facets
    for (let i = 4; i < 11; i++) {
      r(i, 14 - i, 2, 1, '#b8ffff');
      r(i, 13 - i, 1, 1, '#ffffff');
    }
    return true;
  }

  // 17. Block of Emerald
  if (name === 'emerald_block') {
    r(0, 0, 16, 16, '#0b5c22');
    r(0, 0, 15, 1, '#8fffab');
    r(0, 0, 1, 15, '#68f28c');
    r(1, 1, 14, 14, '#1ea846');
    // Concentric step-cut octagonal emerald bevels
    r(2, 2, 12, 12, '#137a30');
    r(3, 3, 10, 10, '#2bd45d');
    r(3, 3, 10, 1, '#85ff9e');
    r(3, 3, 1, 10, '#85ff9e');
    r(5, 5, 6, 6, '#17913a');
    r(6, 6, 4, 4, '#47eb75');
    r(6, 6, 2, 1, '#c4ffd2');
    r(6, 6, 1, 2, '#ffffff');
    return true;
  }

  // 18. Block of Quartz, Smooth Quartz, Quartz Pillar, Quartz Bricks
  if (name === 'quartz_block_top' || name === 'quartz_block_side' || name === 'quartz_block_bottom' || name === 'smooth_quartz') {
    const smooth = name === 'smooth_quartz' || name === 'quartz_block_bottom';
    r(0, 0, 16, 16, smooth ? '#e6e1d6' : '#d1cbc0');
    if (!smooth) {
      r(0, 0, 15, 1, '#ffffff');
      r(0, 0, 1, 15, '#faf7f0');
      r(1, 15, 15, 1, '#bdb6a8');
      r(15, 1, 1, 15, '#c4bdb0');
    }
    r(1, 1, 14, 14, '#eee9df');
    // Subtle crystalline marble veining
    for (let i = 2; i < 13; i++) {
      r(i, 14 - i, 2, 1, '#faf7f2');
      if (i >= 4 && i <= 10) r(i, 13 - i, 1, 1, '#ffffff');
      if (i + 3 < 14) r(i + 2, 14 - i, 2, 1, '#dfd9ce');
    }
    if (name === 'quartz_block_bottom') {
      r(2, 2, 12, 12, '#e3ded3');
      r(3, 3, 10, 10, '#ebe6dc');
    }
    return true;
  }
  if (name === 'quartz_pillar_top') {
    r(0, 0, 16, 16, '#bdb6a8');
    r(1, 1, 14, 14, '#f5f2eb');
    r(2, 2, 12, 12, '#d6d0c4');
    r(3, 3, 10, 10, '#ebe6dc');
    r(5, 5, 6, 6, '#cfc8bc');
    r(6, 6, 4, 4, '#faf7f0');
    return true;
  }
  if (name === 'quartz_pillar_side') {
    // Fluted classical marble column with deep vertical channels & capital/base trim
    r(0, 0, 16, 16, '#ded9ce');
    for (let x = 0; x < 16; x += 4) {
      r(x, 0, 1, 16, '#bfb8aa');
      r(x + 1, 0, 1, 16, '#ffffff');
      r(x + 2, 0, 1, 16, '#eee9df');
      r(x + 3, 0, 1, 16, '#d9d3c7');
    }
    r(0, 0, 16, 1, '#ffffff');
    r(0, 15, 16, 1, '#b5ae9f');
    return true;
  }
  if (name === 'quartz_bricks') {
    r(0, 0, 16, 16, '#bfb9ac');
    for (let row = 0; row < 4; row++) {
      const y = row * 4, off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        const x0 = Math.max(0, bx + off), x1 = Math.min(16, bx + off + 7);
        if (x1 <= x0) continue;
        r(x0, y + 1, x1 - x0, 3, '#ebe6dc');
        r(x0, y + 1, x1 - x0, 1, '#faf7f0');
        r(x0, y + 3, x1 - x0, 1, '#d6d0c4');
      }
    }
    return true;
  }

  // 19. Ancient Debris & Block of Netherite ("古代の残骸の純ブロック")
  if (name === 'ancient_debris_top') {
    // Pressed archaic metal spiral turbine rings
    r(0, 0, 16, 16, '#2b1d19');
    r(1, 1, 14, 14, '#5e443c');
    r(2, 2, 12, 12, '#3d2a24');
    r(3, 3, 10, 10, '#7a5a50');
    r(4, 4, 8, 8, '#4a332c');
    r(5, 5, 6, 6, '#947065');
    r(6, 6, 4, 4, '#3d2a24');
    r(7, 7, 2, 2, '#b08b7f');
    // Spiral corner breaks so it reads as an ancient forged spiral rather than flat squares
    r(3, 2, 2, 1, '#947065'); r(13, 3, 1, 2, '#947065');
    r(11, 13, 2, 1, '#947065'); r(2, 11, 1, 2, '#947065');
    r(5, 4, 2, 1, '#b08b7f'); r(11, 5, 1, 2, '#b08b7f');
    return true;
  }
  if (name === 'ancient_debris_side') {
    // Layered pressed metal plates with dark crevices and warm bronze-rose edges
    r(0, 0, 16, 16, '#2b1d19');
    const plates: [number, number, number, number][] = [
      [0, 0, 7, 3], [8, 0, 8, 3],
      [2, 4, 8, 3], [11, 4, 5, 3], [0, 4, 1, 3],
      [0, 8, 6, 3], [7, 8, 9, 3],
      [3, 12, 7, 3], [11, 12, 5, 3], [0, 12, 2, 3],
    ];
    for (const [px, py, pw, ph] of plates) {
      r(px, py, pw, ph, '#5e443c');
      r(px, py, pw, 1, '#8c695e');
      r(px + 1, py, Math.max(1, pw - 2), 1, '#a68276');
      r(px, py + ph - 1, pw, 1, '#422e28');
    }
    return true;
  }
  if (name === 'netherite_block') {
    r(0, 0, 16, 16, '#1f1b1f');
    r(0, 0, 15, 1, '#685e68');
    r(0, 0, 1, 15, '#595059');
    r(1, 1, 14, 14, '#3d373d');
    for (let y = 2; y < 14; y += 3) {
      r(2, y, 12, 2, '#4a434a');
      r(2, y, 12, 1, '#5e555e');
    }
    for (let i = 2; i < 13; i++) {
      r(i, 14 - i, 2, 1, '#736873');
    }
    r(2, 2, 1, 1, '#262126'); r(13, 2, 1, 1, '#262126');
    r(2, 13, 1, 1, '#262126'); r(13, 13, 1, 1, '#262126');
    return true;
  }

  // --- 5C. FLORA, CORALS, FUNGI, BARREL, SHULKER BOX, TNT & ENCHANTING TABLE ---

  // 20. Sugar Cane (Grayscale centered at 150 so biome tint produces vibrant reed green)
  if (name === 'sugar_cane') {
    ctx.clearRect(0, 0, 16, 16);
    for (const sx of [2, 7, 12]) {
      r(sx, 0, 3, 16, '#787878');
      r(sx + 1, 0, 2, 16, '#9e9e9e');
      r(sx + 1, 0, 1, 16, '#c2c2c2');
      // Internode ring joints & small leaf shoots
      for (const jy of [3, 8, 13]) {
        r(sx - 1, jy, 5, 1, '#646464');
        r(sx, jy - 1, 3, 1, '#dcdcdc');
      }
      r(sx - 1, 5, 1, 2, '#b0b0b0');
      r(sx + 3, 10, 1, 2, '#b0b0b0');
    }
    return true;
  }

  // 21. Bamboo (Cylindrical culm with white/tan nodal rings & leafy shoots)
  if (name === 'bamboo') {
    ctx.clearRect(0, 0, 16, 16);
    r(6, 0, 4, 16, '#47781e');
    r(7, 0, 3, 16, '#66a130');
    r(7, 0, 1, 16, '#90cc52');
    for (const ny of [3, 8, 13]) {
      r(5, ny, 6, 1, '#365c15');
      r(6, ny - 1, 4, 1, '#d4e89e'); // Pale bamboo node ring
    }
    // Diagonal bamboo leaf clusters
    r(2, 1, 4, 2, '#66a130'); r(1, 2, 3, 1, '#84bd46');
    r(10, 5, 4, 2, '#558a26'); r(11, 4, 3, 1, '#84bd46');
    r(2, 9, 4, 2, '#66a130'); r(1, 10, 3, 1, '#84bd46');
    r(10, 11, 4, 2, '#558a26');
    return true;
  }

  // 22. All 12 Saplings (Distinct species-accurate silhouettes & foliage crowns!)
  if (name.endsWith('_sapling')) {
    ctx.clearRect(0, 0, 16, 16);
    const sp = name.replace(/_sapling$/, '');
    if (sp === 'spruce') {
      // Conical pine needle tiers
      r(7, 11, 2, 5, '#4a3219');
      r(6, 2, 4, 3, '#2e5230'); r(7, 1, 2, 2, '#48754a');
      r(4, 5, 8, 3, '#2e5230'); r(5, 5, 6, 2, '#426b45');
      r(2, 8, 12, 4, '#244226'); r(3, 8, 10, 3, '#3b613e'); r(5, 8, 4, 1, '#58875b');
      return true;
    }
    if (sp === 'birch') {
      // White bark stem with black lenticels + diamond lime crown
      r(7, 9, 2, 7, '#e6e3d8'); r(8, 11, 1, 1, '#2b2a26'); r(7, 14, 1, 1, '#2b2a26');
      r(4, 3, 8, 7, '#5c8736'); r(3, 5, 10, 4, '#6e9c44');
      r(5, 2, 6, 7, '#82b354'); r(6, 3, 4, 3, '#a3d175');
      return true;
    }
    if (sp === 'cherry') {
      // Curved dark maroon trunk + fluffy sakura blossom canopy
      r(7, 10, 2, 6, '#3b222c'); r(6, 9, 2, 2, '#543340');
      r(2, 3, 12, 7, '#cf7a98'); r(3, 2, 10, 7, '#e89cb8');
      r(4, 3, 8, 5, '#f7bfd2'); r(5, 3, 4, 2, '#ffe3ed');
      r(3, 7, 2, 2, '#ffe3ed'); r(10, 5, 2, 2, '#ffe3ed');
      return true;
    }
    if (sp === 'acacia') {
      // Diagonal leaning gray trunk + flat savanna umbrella crown
      r(6, 12, 2, 4, '#676157'); r(7, 9, 2, 3, '#676157'); r(8, 7, 2, 2, '#827b6f');
      r(1, 3, 14, 4, '#64752c'); r(2, 2, 12, 4, '#7d8f3b'); r(4, 2, 8, 2, '#9eb052');
      return true;
    }
    if (sp === 'jungle') {
      // Tall tropical palm-like tiered leaves
      r(7, 7, 2, 9, '#574429'); r(8, 8, 1, 7, '#735a38');
      r(2, 2, 12, 3, '#396b24'); r(3, 1, 10, 3, '#4f8a3b'); r(5, 1, 6, 2, '#6eb054');
      r(3, 6, 4, 2, '#396b24'); r(9, 6, 4, 2, '#4f8a3b');
      return true;
    }
    if (sp === 'mangrove') {
      // Mangrove propagule with hanging root radicle & top leaflets
      r(7, 6, 2, 8, '#547332'); r(7, 13, 2, 3, '#6e4c36');
      r(8, 7, 1, 5, '#739948');
      r(4, 3, 4, 3, '#4a7a2c'); r(8, 3, 4, 3, '#5d9138'); r(6, 2, 4, 2, '#7db554');
      return true;
    }
    if (sp === 'crimson' || sp === 'warped') {
      const crim = sp === 'crimson';
      r(7, 9, 2, 7, crim ? '#5c192b' : '#28756f');
      r(3, 4, 10, 6, crim ? '#8c1d28' : '#1b7a72');
      r(5, 2, 6, 4, crim ? '#b82834' : '#2aa69b');
      r(5, 5, 2, 2, '#f59e3d'); r(10, 6, 1, 1, '#f59e3d');
      return true;
    }
    const col = sp === 'dark_oak' ? '#3d6326' : sp === 'pale_oak' ? '#9ea88d' : sp === 'poplar' ? '#a6ab44' : '#528732';
    // Trunk + root flare + branches
    r(7, 9, 2, 7, '#5c4022'); r(8, 9, 1, 6, '#7a5630');
    r(6, 14, 4, 2, '#4a3219'); r(5, 9, 2, 1, '#5c4022'); r(9, 8, 2, 1, '#5c4022');
    // Multi-lobed organic crown (3 distinct leaf clusters)
    r(2, 5, 5, 4, shadeHex(col, -22)); r(9, 5, 5, 4, shadeHex(col, -22));
    r(4, 2, 8, 7, shadeHex(col, -12));
    r(3, 4, 4, 4, col); r(9, 4, 4, 4, col); r(5, 1, 6, 6, col);
    r(5, 2, 4, 3, shadeHex(col, 24)); r(3, 4, 2, 2, shadeHex(col, 18)); r(10, 4, 2, 2, shadeHex(col, 18));
    return true;
  }

  // 23. Vines (Vine, Weeping Vines, Twisting Vines, Cave Vines)
  if (name === 'vine') {
    ctx.clearRect(0, 0, 16, 16);
    // Grayscale centered at 150 for lush biome tinting: trailing tendrils + heart-shaped leaves
    const cols = [2, 6, 10, 13];
    for (const cx of cols) {
      const len = 12 + (cx % 4);
      for (let y = 0; y < len; y++) {
        const wx = (cx + ((y >> 1) & 1)) & 15;
        r(wx, y, 1, 1, '#7c7c7c');
        r((wx + 1) & 15, y, 1, 1, y % 3 === 0 ? '#bcbcbc' : '#989898');
        if (y % 4 === 1) {
          r((wx + 1) & 15, y, 2, 2, '#a8a8a8');
          r((wx + 1) & 15, y, 1, 1, '#cecece');
        }
      }
    }
    return true;
  }
  if (name === 'weeping_vines' || name === 'twisting_vines' || name === 'cave_vines') {
    ctx.clearRect(0, 0, 16, 16);
    const cDark = name === 'weeping_vines' ? '#6e1218' : name === 'twisting_vines' ? '#12635e' : '#3d611c';
    const cMain = name === 'weeping_vines' ? '#a8222b' : name === 'twisting_vines' ? '#229c94' : '#598a2b';
    const cHi   = name === 'weeping_vines' ? '#e04852' : name === 'twisting_vines' ? '#48d9cf' : '#7db844';
    for (let y = 0; y < 16; y++) {
      const sx = 6 + Math.round(Math.sin(y * 0.65) * 2);
      r(sx, y, 3, 1, y % 2 === 0 ? cMain : cDark);
      r(sx, y, 1, 1, cHi);
      if (y % 4 === 1) r(sx - 2, y, 2, 2, cMain);
      if (y % 4 === 3) r(sx + 3, y, 2, 2, cHi);
    }
    if (name === 'cave_vines') {
      // Glowing golden-amber glow berries hanging from lush cave vines
      for (const [bx, by] of [[4, 4], [9, 8], [5, 12]]) {
        r(bx, by, 3, 3, '#e89624');
        r(bx, by, 2, 2, '#ffd454');
        r(bx, by, 1, 1, '#ffffff');
      }
    }
    return true;
  }
  if (name === 'dried_kelp_block') {
    r(0, 0, 16, 16, '#26301d');
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const k = (x * 5 + y * 7) % 6;
        if (k === 0) r(x, y, 1, 1, '#1a2114');
        else if (k === 1 || k === 2) r(x, y, 1, 1, '#36452a');
        else if (k === 4) r(x, y, 1, 1, '#485938');
      }
    }
    // Twine rope ties across the bundle
    r(0, 7, 16, 2, '#c9ba93'); r(0, 7, 16, 1, '#e3d6b2');
    r(7, 0, 2, 16, '#c9ba93'); r(7, 0, 1, 16, '#e3d6b2');
    return true;
  }

  // 24. Lily Pad (Notched round waterlily pad with radial veins)
  if (name === 'lily_pad') {
    ctx.clearRect(0, 0, 16, 16);
    // Grayscale/green hybrid: mesher tints lily_pad via LUT_TINT_SUB, and uiTileCanvas tints via UI_TINT_HEX
    r(3, 2, 10, 12, '#646464');
    r(2, 3, 12, 10, '#787878');
    r(3, 3, 10, 10, '#8e8e8e');
    r(4, 4, 8, 8, '#a0a0a0');
    // Radial leaf veins from center (8, 8)
    r(7, 7, 2, 2, '#c8c8c8');
    for (const [vx, vy] of [[5, 5], [10, 5], [5, 10], [10, 10], [4, 7], [11, 7], [7, 11]]) {
      r(vx, vy, 1, 1, '#b6b6b6');
    }
    // Iconic V-shaped notch on north side
    ctx.clearRect(7, 1, 2, 4);
    ctx.clearRect(8, 1, 2, 5);
    return true;
  }

  // 25. Seagrass & Kelp & Dried Kelp Block
  if (name === 'seagrass') {
    ctx.clearRect(0, 0, 16, 16);
    const blades: [number, number, number][] = [[2, 10, 1], [5, 13, -1], [8, 15, 1], [11, 11, -1], [13, 9, 1]];
    for (const [bx, bh, bend] of blades) {
      for (let y = 16 - bh; y < 16; y++) {
        const dy = 16 - y;
        const wx = bx + (dy > 5 ? bend : 0) + (dy > 10 ? bend : 0);
        r(wx, y, 2, 1, '#2d6e32');
        r(wx, y, 1, 1, y < 16 - bh + 3 ? '#76cf63' : '#489e46');
      }
    }
    return true;
  }

  if (name === 'kelp') {
    ctx.clearRect(0, 0, 16, 16);
    for (let y = 0; y < 16; y++) {
      const sx = 6 + Math.round(Math.sin(y * 0.55) * 1.6);
      r(sx, y, 3, 1, '#346920');
      r(sx + 1, y, 1, 1, '#589c36');
      if (y % 4 === 1) {
        r(sx - 3, y, 3, 2, '#46822b');
        r(sx - 2, y, 2, 1, '#70b846');
      }
      if (y % 4 === 3) {
        r(sx + 3, y, 3, 2, '#46822b');
        r(sx + 3, y, 2, 1, '#70b846');
      }
    }
    return true;
  }

  // 26. All 5 Coral Blocks & All 5 Coral Fans (Tube, Brain, Bubble, Fire, Horn)
  if (name.endsWith('_coral_block')) {
    const kind = name.replace(/_coral_block$/, '');
    if (kind === 'tube') {
      r(0, 0, 16, 16, '#213894');
      const pores: [number, number][] = [[1, 1], [6, 2], [11, 1], [3, 6], [9, 6], [13, 7], [1, 11], [6, 12], [11, 11]];
      for (const [px, py] of pores) {
        r(px, py, 4, 4, '#3658cf');
        r(px, py, 3, 1, '#5e82ff');
        r(px + 1, py + 1, 2, 2, '#142266');
      }
    } else if (kind === 'brain') {
      const BRAIN_MAP = [
        '0122210122210121',
        '1233210233210232',
        '2311001211001212',
        '2101222101222101',
        '1222333202333210',
        '0121112323111221',
        '1232001232001232',
        '2321210121210121',
        '1212321002321012',
        '0102332112332123',
        '1211123221112232',
        '2320012332001210',
        '2112201221220121',
        '1023320112332023',
        '2122121222112121',
        '1210012332001210',
      ];
      drawGrid(ctx, BRAIN_MAP, {
        '0': '#781d47',
        '1': '#b53b74',
        '2': '#e3649e',
        '3': '#ff99c8',
      });
    } else if (kind === 'bubble') {
      r(0, 0, 16, 16, '#5c146e');
      const orbs: [number, number, number][] = [[1, 1, 5], [7, 0, 4], [12, 2, 4], [0, 7, 4], [5, 5, 6], [11, 7, 5], [2, 11, 5], [8, 11, 5]];
      for (const [ox, oy, os] of orbs) {
        r(ox, oy, os, os, '#9e2eb8');
        r(ox + 1, oy + 1, os - 2, os - 2, '#c752e3');
        r(ox + 1, oy + 1, 1, 1, '#f7b8ff');
      }
    } else if (kind === 'fire') {
      r(0, 0, 16, 16, '#7a1914');
      for (let y = 0; y < 16; y += 4) {
        for (let x = (y % 8 === 0 ? 0 : 2); x < 16; x += 4) {
          r(x, y, 3, 3, '#c92e24');
          r(x, y, 2, 2, '#f0523e');
          r(x, y, 1, 1, '#ffa878');
        }
      }
    } else {
      // Horn coral block: golden cellular honeycombs
      r(0, 0, 16, 16, '#8f7314');
      for (let y = 0; y < 16; y += 4) {
        for (let x = (y % 8 === 0 ? 1 : 3); x < 15; x += 4) {
          r(x, y, 3, 3, '#d9b426');
          r(x, y, 2, 2, '#fae04b');
          r(x + 1, y + 1, 1, 1, '#fff8a6');
        }
      }
    }
    return true;
  }

  if (name.endsWith('_coral')) {
    ctx.clearRect(0, 0, 16, 16);
    const kind = name.replace(/_coral$/, '');
    const cDark = kind === 'tube' ? '#243ea6' : kind === 'brain' ? '#9e2e63' : kind === 'bubble' ? '#701987' : kind === 'fire' ? '#8c1c16' : '#9e7f19';
    const cMain = kind === 'tube' ? '#3d63e0' : kind === 'brain' ? '#de5c9b' : kind === 'bubble' ? '#ad33c9' : kind === 'fire' ? '#d93426' : '#e0bd28';
    const cHi   = kind === 'tube' ? '#789eff' : kind === 'brain' ? '#ff99cc' : kind === 'bubble' ? '#eb88ff' : kind === 'fire' ? '#ff8552' : '#fff275';
    // Branching coral polyps & fan fronds
    r(5, 13, 6, 3, cDark);
    const branches: [number, number, number, number][] = [[2, 6, 2, 7], [5, 3, 2, 10], [8, 2, 2, 11], [11, 4, 2, 9], [13, 8, 2, 5]];
    for (const [bx, by, bw, bh] of branches) {
      r(bx, by, bw, bh, cMain);
      r(bx, by, 1, 2, cHi);
      if (kind === 'bubble') r(bx - 1, by + 1, 3, 3, cHi);
    }
    return true;
  }

  // 27. Mushroom Blocks (Red Mushroom Block, Brown Mushroom Block, Mushroom Stem)
  if (name === 'red_mushroom_block_top' || name === 'red_mushroom_block_side') {
    r(0, 0, 16, 16, '#b82921');
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const k = (x * 5 + y * 9) % 7;
        if (k === 0) r(x, y, 1, 1, '#961d17');
        else if (k === 1) r(x, y, 1, 1, '#cf362d');
      }
    }
    // Iconic cream-white Amanita warts with warm bottom-right bevel shadow
    const warts: [number, number, number, number][] = [
      [1, 1, 3, 3], [9, 1, 4, 3], [5, 5, 3, 3], [12, 7, 3, 3],
      [1, 9, 4, 3], [7, 11, 4, 3], [13, 13, 2, 2],
    ];
    for (const [wx, wy, ww, wh] of warts) {
      r(wx, wy, ww, wh, '#d6ccb4');
      r(wx, wy, ww - 1, wh - 1, '#f5efe1');
      r(wx, wy, 1, 1, '#ffffff');
    }
    return true;
  }
  if (name === 'brown_mushroom_block_top' || name === 'brown_mushroom_block_side') {
    r(0, 0, 16, 16, '#8f6948');
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const k = (x * 5 + y * 9 + ((x ^ y) & 3)) % 7;
        if (k === 0) r(x, y, 1, 1, '#705036');
        else if (k === 1 || k === 2) r(x, y, 1, 1, '#9e7754');
        else if (k === 5) r(x, y, 1, 1, '#b08964');
      }
    }
    const spots: [number, number, number, number][] = [
      [1, 1, 3, 3], [8, 2, 3, 3], [13, 1, 2, 3],
      [4, 6, 4, 3], [11, 7, 3, 3],
      [1, 11, 3, 3], [7, 11, 3, 3], [12, 12, 3, 3],
    ];
    for (const [px, py, pw, ph] of spots) {
      r(px, py, pw, ph, '#755338');
      r(px + 1, py + 1, Math.max(1, pw - 1), Math.max(1, ph - 1), '#a8815c');
      r(px, py, 1, 1, '#c29b74');
    }
    return true;
  }
  if (name === 'red_mushroom_block_stem' || name === 'brown_mushroom_block_stem') {
    // Spongy mushroom pore underside
    r(0, 0, 16, 16, '#c7bda6');
    for (let y = 0; y < 16; y += 2) {
      for (let x = (y % 4 === 0 ? 0 : 1); x < 16; x += 3) {
        r(x, y, 2, 1, '#9e927b');
        r(x, y + 1, 1, 1, '#ded6c1');
      }
    }
    return true;
  }
  if (name === 'mushroom_stem') {
    r(0, 0, 16, 16, '#dbd4c3');
    for (let x = 0; x < 16; x++) {
      const c = x % 4 === 0 ? '#bdb5a2' : x % 4 === 1 ? '#ebe5d5' : x % 4 === 2 ? '#e3dccb' : '#cfc7b4';
      r(x, 0, 1, 16, c);
    }
    return true;
  }

  // 28. Shroomlight (Glowing bioluminescent cellular clusters in crimson-amber matrix)
  if (name === 'shroomlight') {
    r(0, 0, 16, 16, '#9c3616');
    const cells: [number, number, number, number][] = [
      [1, 1, 5, 4], [7, 1, 4, 3], [12, 1, 3, 4],
      [1, 6, 4, 4], [6, 5, 5, 5], [12, 6, 3, 4],
      [1, 11, 5, 4], [7, 11, 4, 4], [12, 11, 3, 4],
    ];
    for (const [cx, cy, cw, ch] of cells) {
      r(cx, cy, cw, ch, '#d9691e');
      r(cx, cy, cw - 1, ch - 1, '#f7a831');
      r(cx + 1, cy + 1, Math.max(1, cw - 2), Math.max(1, ch - 2), '#ffdf6b');
      r(cx + 1, cy + 1, 1, 1, '#ffffd6');
    }
    return true;
  }

  // 29. Barrel (Top lid with bung hole & iron hoop, Side staves & dual iron bands, Bottom)
  if (name === 'barrel_top' || name === 'barrel_front') {
    r(0, 0, 16, 16, '#382512');
    r(1, 1, 14, 14, '#54391d');
    r(2, 2, 12, 12, '#8c6236');
    for (let y = 2; y < 14; y += 3) {
      r(2, y, 12, 1, '#75502a');
      r(2, y + 1, 12, 1, '#a37545');
    }
    // Iron corner brackets & recessed dark bung-hole plug
    r(1, 1, 2, 2, '#4a4e52'); r(13, 1, 2, 2, '#4a4e52');
    r(1, 13, 2, 2, '#4a4e52'); r(13, 13, 2, 2, '#4a4e52');
    r(6, 6, 4, 4, '#24170a');
    r(7, 7, 2, 2, '#140c05');
    r(6, 5, 4, 1, '#a37545');
    return true;
  }
  if (name === 'barrel_bottom') {
    r(0, 0, 16, 16, '#382512');
    r(1, 1, 14, 14, '#54391d');
    r(2, 2, 12, 12, '#855c32');
    for (let y = 2; y < 14; y += 3) {
      r(2, y, 12, 1, '#6e4b26');
      r(2, y + 1, 12, 1, '#9c6e3e');
    }
    return true;
  }
  if (name === 'barrel_side') {
    r(0, 0, 16, 16, '#855c32');
    for (let x = 0; x < 16; x += 4) {
      r(x, 0, 1, 16, '#593c1e');
      r(x + 1, 0, 1, 16, '#a37545');
      r(x + 2, 0, 1, 16, '#8c6236');
      r(x + 3, 0, 1, 16, '#75502a');
    }
    // Top & bottom timber chime rims
    r(0, 0, 16, 1, '#9c6e3e'); r(0, 15, 16, 1, '#4a3117');
    // Two dark forged iron hoops with rivets at y=3..4 and y=11..12
    for (const hy of [3, 11]) {
      r(0, hy, 16, 2, '#3d4145');
      r(0, hy, 16, 1, '#5c6266');
      for (let rx = 2; rx < 16; rx += 4) r(rx, hy, 1, 1, '#8c9499');
    }
    return true;
  }

  // 30. Shulker Box (Top carapace spirals, Side crenellated overlap seam, Bottom base)
  if (name === 'shulker_box_top') {
    r(0, 0, 16, 16, '#5c3861');
    r(1, 1, 14, 14, '#7d4e82');
    r(2, 2, 12, 12, '#96629c');
    r(2, 2, 12, 1, '#b37cb8'); r(2, 2, 1, 12, '#b37cb8');
    r(4, 4, 8, 8, '#7d4e82');
    r(5, 5, 6, 6, '#a670ab');
    r(7, 7, 2, 2, '#c993cf');
    return true;
  }
  if (name === 'shulker_box_bottom') {
    r(0, 0, 16, 16, '#4a2c4d');
    r(1, 1, 14, 14, '#69406e');
    r(3, 3, 10, 10, '#57345c');
    return true;
  }
  if (name === 'shulker_box_side') {
    // Upper carapace shell (rows 0..9) overlapping lower base (rows 10..15) with stepped crenellation teeth
    r(0, 0, 16, 16, '#5c3861');
    r(0, 0, 16, 9, '#8f5b94');
    r(0, 0, 16, 1, '#b37cb8');
    // Crenellated shell lip at rows 8..10
    for (let x = 0; x < 16; x += 4) {
      r(x, 8, 2, 3, '#8f5b94');
      r(x, 11, 2, 1, '#3b213d');
      r(x + 2, 9, 2, 1, '#3b213d');
      r(x + 2, 10, 2, 5, '#6e4373');
    }
    r(0, 12, 16, 4, '#6e4373');
    r(0, 15, 16, 1, '#472a4a');
    return true;
  }

  // 31. TNT (Top gunpowder fuses, Bottom bundle ends, Side dynamite sticks + crisp "TNT" label)
  if (name === 'tnt_top' || name === 'tnt_bottom') {
    r(0, 0, 16, 16, '#8c2219');
    for (let y = 0; y < 16; y += 4) {
      for (let x = 0; x < 16; x += 4) {
        r(x, y, 3, 3, '#cc3326');
        r(x, y, 2, 1, '#eb4f42');
        r(x + 1, y + 1, 1, 1, name === 'tnt_top' ? '#36383a' : '#a3281d');
      }
    }
    if (name === 'tnt_top') {
      r(6, 6, 4, 4, '#292b2c');
      r(7, 7, 2, 2, '#dcd8cc');
      r(7, 7, 1, 1, '#ffffff');
    }
    return true;
  }
  if (name === 'tnt_side') {
    // Individual vertical dynamite sticks top & bottom
    for (let x = 0; x < 16; x += 4) {
      r(x, 0, 1, 16, '#8f2219');
      r(x + 1, 0, 1, 16, '#e64233');
      r(x + 2, 0, 1, 16, '#cc3124');
      r(x + 3, 0, 1, 16, '#ad281d');
    }
    // White paper band (rows 5..10) with dark border lines (rows 4 and 11)
    r(0, 4, 16, 1, '#59140e');
    r(0, 11, 16, 1, '#59140e');
    r(0, 5, 16, 6, '#edeae0');
    r(0, 5, 16, 1, '#ffffff');
    r(0, 10, 16, 1, '#ccc7b8');
    // Crisp pixel-art "TNT" lettering in black/dark-charcoal on rows 6..9
    const blk = '#1c1a17';
    // 'T' (x=1..3)
    r(1, 6, 3, 1, blk); r(2, 7, 1, 3, blk);
    // 'N' (x=5..9)
    r(5, 6, 1, 4, blk); r(6, 7, 1, 1, blk); r(7, 8, 1, 1, blk); r(8, 6, 1, 4, blk);
    // 'T' (x=11..13)
    r(11, 6, 3, 1, blk); r(12, 7, 1, 3, blk);
    return true;
  }

  // 32. Enchanting Table (Top red cloth with gold trim & diamond corners, Side obsidian + gold/diamond/cloth)
  if (name === 'enchanting_table_top') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // 4 glowing turquoise diamond corner inlays
    const corners: [number, number][] = [[0, 0], [13, 0], [0, 13], [13, 13]];
    for (const [cx, cy] of corners) {
      r(cx, cy, 3, 3, '#197d87');
      r(cx + 1, cy + 1, 2, 2, '#45ebed');
      r(cx + 1, cy + 1, 1, 1, '#ffffff');
    }
    // Crimson velvet altar cloth diamond/square cover with golden embroidery
    r(2, 2, 12, 12, '#6e141e');
    r(3, 3, 10, 10, '#9e1e2b');
    r(3, 3, 10, 1, '#f2c641'); r(3, 12, 10, 1, '#c49622');
    r(3, 3, 1, 10, '#f2c641'); r(12, 3, 1, 10, '#c49622');
    r(4, 4, 8, 8, '#b82535');
    r(6, 6, 4, 4, '#851824');
    return true;
  }
  if (name === 'enchanting_table_side') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // Top crimson cloth drape with golden rune trim (rows 0..4, and because table is y=0..12/16, also mirrored at rows 4..8 for UV crop)
    r(0, 0, 16, 3, '#9e1e2b');
    r(0, 0, 16, 1, '#c93040');
    r(0, 3, 16, 1, '#e6b832');
    // Hanging center banner point
    r(5, 3, 6, 3, '#851824');
    r(6, 3, 4, 2, '#b82535');
    r(5, 5, 6, 1, '#e6b832');
    // Glowing cyan diamond inlays on left and right pillars (visible in both 0..12/16 UV and full 0..16 UV)
    for (const sx of [1, 12]) {
      r(sx, 2, 3, 4, '#166e78');
      r(sx + 1, 2, 2, 3, '#45ebed');
      r(sx + 1, 2, 1, 1, '#ffffff');
      r(sx, 6, 3, 4, '#166e78');
      r(sx + 1, 7, 2, 2, '#45ebed');
      r(sx + 1, 7, 1, 1, '#c9ffff');
    }
    return true;
  }

  return false;
}



// =====================================================================================================================
// 5. NETHER TERRAIN, ORES, STONES, BRICKS, QUARTZ & FUNGUS BLOCKS (Pass 3 — Perfected Organic Maps & 3D Relief)
// =====================================================================================================================

// Irregular interlocking volcanic cobble map for Netherrack (zero diagonal striping, 100% seamless 16x16)
const NETHERRACK_MAP = [
  '2231012332011232',
  '3431023443112343',
  '2320123321001232',
  '0101221100122110',
  '1223343210234321',
  '2344432101244322',
  '1233210012332101',
  '0011001223210012',
  '1223212344310123',
  '2344322343201234',
  '1233210121002343',
  '0112101232112321',
  '1233212344321100',
  '2344321343210121',
  '1232100121001232',
  '0110012210122321',
];

const NETHERRACK_PAL: Record<string, string> = {
  '0': '#3b1616',
  '1': '#54211f',
  '2': '#6d2f2b',
  '3': '#87403b',
  '4': '#a3534d',
};

const NYLIUM_MAP = [
  '1221012332101221',
  '2343123443212332',
  '2443234332102443',
  '1232122100123432',
  '0110011012332210',
  '1232100123443101',
  '2344321234432112',
  '1343210123210123',
  '0121001100012232',
  '1232112321123431',
  '2343223443234320',
  '1232112343122101',
  '0110001221001221',
  '1221122332112342',
  '2332234432101331',
  '1221123321000121',
];

// Asymmetric organic wart/mushroom clusters (varied sizes, non-repetitive)
const WART_BLOCK_MAP = [
  '1232012343201121',
  '2443123443102342',
  '1332012321012443',
  '0110122100123321',
  '1233234321232100',
  '2344344320121012',
  '1233232101232123',
  '0011001212343232',
  '1233212343443121',
  '2344322443321001',
  '1233211332101232',
  '0112100110012343',
  '1234321232123442',
  '2344322343212321',
  '1232101232100110',
  '0110011210012211',
];

const VOLCANIC_MAP = [
  '1221001233210011',
  '2343211343210122',
  '1232100122101233',
  '0011012210012342',
  '1221123432123321',
  '2332234432112210',
  '1221012321000110',
  '0110001100112231',
  '1232112211234432',
  '2343223432234321',
  '1232112332112210',
  '0010001221000110',
  '1121012332101232',
  '2343223443212343',
  '1232112332101232',
  '0110000110000110',
];

export function drawNetherTile(name: string, ctx: Context2D, rnd: () => number): boolean {
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === 'netherrack') {
    drawGrid(ctx, NETHERRACK_MAP, NETHERRACK_PAL);
    for (const [fx, fy] of [[3, 2], [10, 1], [1, 7], [7, 6], [12, 9], [4, 12], [11, 14]]) {
      r(fx, fy, 2, 1, '#2b0d0d');
      r(fx, fy + 1, 2, 1, '#b05c55');
    }
    return true;
  }

  if (name === 'crimson_nylium' || name === 'warped_nylium') {
    const crim = name === 'crimson_nylium';
    const pal: Record<string, string> = crim
      ? { '0': '#4a1116', '1': '#6e171e', '2': '#8c2026', '3': '#ad2b32', '4': '#d44249' }
      : { '0': '#143336', '1': '#1c4d4b', '2': '#266e67', '3': '#329186', '4': '#47c4b3' };
    drawGrid(ctx, NYLIUM_MAP, pal);
    const spores: [number, number][] = [[2, 2], [11, 1], [6, 5], [13, 7], [3, 10], [9, 11], [12, 14]];
    for (const [sx, sy] of spores) {
      r(sx, sy, 2, 1, crim ? '#e35648' : '#58deca');
      r(sx, sy, 1, 1, crim ? '#ff946b' : '#96ffec');
    }
    return true;
  }

  if (name === 'crimson_nylium_side' || name === 'warped_nylium_side') {
    drawGrid(ctx, NETHERRACK_MAP, NETHERRACK_PAL);
    const crim = name.startsWith('crimson');
    const cDark = crim ? '#4f1016' : '#143836';
    const cMid = crim ? '#8c2026' : '#266e67';
    const cBright = crim ? '#b82e36' : '#35998e';
    const cHi = crim ? '#f06854' : '#64e8d4';
    const drips = [4, 5, 6, 4, 3, 5, 7, 5, 3, 4, 6, 4, 3, 5, 4, 3];
    for (let x = 0; x < 16; x++) {
      const h = drips[x];
      r(x, 0, 1, h, cMid);
      r(x, 0, 1, 2, cBright);
      if (x % 2 === 0) r(x, 0, 1, 1, cHi);
      r(x, h - 1, 1, 1, cDark);
      r(x, h, 1, 1, '#260b0b');
    }
    return true;
  }

  if (name === 'soul_sand') {
    const pal: Record<string, string> = {
      '0': '#2b1e17', '1': '#3d2c22', '2': '#4f3a2e', '3': '#63493b', '4': '#785a49',
    };
    drawGrid(ctx, NYLIUM_MAP, pal);
    const faces: [number, number][] = [[1, 1], [9, 2], [4, 9]];
    for (const [fx, fy] of faces) {
      r(fx, fy, 6, 6, '#38271e');
      r(fx, fy, 6, 1, '#755847');
      r(fx + 1, fy + 1, 1, 2, '#170f0a');
      r(fx + 4, fy + 1, 1, 2, '#170f0a');
      r(fx + 2, fy + 3, 2, 2, '#170f0a');
      r(fx + 1, fy + 5, 4, 1, '#5e4537');
    }
    return true;
  }

  if (name === 'soul_soil') {
    // True undulating horizontal S-wave strata
    r(0, 0, 16, 16, '#3d2d24');
    const pal = ['#261b15', '#36271f', '#47352a', '#594336', '#6e5343'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const wave = Math.sin((x / 16) * Math.PI * 2 + (y % 8 < 4 ? 0 : 1.2)) * 1.6;
        const idx = Math.floor((y + wave + 16) * 1.1) % 5;
        r(x, y, 1, 1, pal[idx]);
      }
    }
    return true;
  }

  if (name === 'magma_block') {
    drawGrid(ctx, VOLCANIC_MAP, {
      '0': '#1c0b07', '1': '#2b120c', '2': '#3b1912', '3': '#4c2118', '4': '#33150f',
    });
    // Continuous branching glowing lava veins
    const veins: [number, number, number, number][] = [
      [1, 1, 6, 2], [4, 2, 3, 4], [6, 4, 6, 2], [10, 1, 4, 4],
      [0, 6, 5, 2], [3, 7, 4, 4], [6, 9, 6, 2], [11, 6, 4, 4],
      [1, 11, 5, 3], [5, 12, 6, 2], [9, 10, 4, 4], [12, 12, 3, 3],
    ];
    for (const [lx, ly, lw, lh] of veins) {
      r(lx, ly, lw, lh, '#c4380a');
      r(lx + 1, ly, Math.max(1, lw - 1), Math.max(1, lh - 1), '#ff7314');
      r(lx + 1, ly + 1, Math.max(1, lw - 2), Math.max(1, lh - 1), '#ffba2b');
      r(lx + 1, ly + 1, 1, 1, '#fff89e');
    }
    return true;
  }

  if (name === 'basalt_top') {
    r(0, 0, 16, 16, '#232429');
    r(1, 1, 14, 14, '#43454d');
    r(2, 1, 12, 14, '#585b63'); r(1, 2, 14, 12, '#585b63');
    r(3, 3, 10, 10, '#303238');
    r(4, 4, 8, 8, '#4c4f57');
    r(5, 4, 6, 8, '#666a73'); r(4, 5, 8, 6, '#666a73');
    r(6, 6, 4, 4, '#383a40');
    r(7, 7, 2, 2, '#1f2024');
    return true;
  }

  if (name === 'basalt_side') {
    const cols = ['#25262b', '#3b3d45', '#52555e', '#636670', '#454750', '#2b2c33', '#474a52', '#5c5f69', '#383a40', '#25262b', '#43464f', '#5e616b', '#4a4d57', '#2e3036', '#474a52', '#34363d'];
    for (let x = 0; x < 16; x++) r(x, 0, 1, 16, cols[x]);
    for (const [jx, jy, jw] of [[0, 3, 5], [5, 6, 6], [11, 4, 5], [1, 10, 6], [7, 12, 5], [12, 14, 4]]) {
      r(jx, jy, jw, 1, '#1a1b1f');
      r(jx, (jy + 1) & 15, jw, 1, '#6c707a');
    }
    return true;
  }

  if (name === 'smooth_basalt') {
    drawGrid(ctx, VOLCANIC_MAP, {
      '0': '#222328', '1': '#303238', '2': '#3e4047', '3': '#4d5059', '4': '#5d606b',
    });
    for (const [cx, cy] of [[3, 4], [10, 2], [6, 9], [12, 12], [2, 13]]) {
      r(cx, cy, 2, 1, '#232429');
      r(cx, cy + 1, 2, 1, '#5c5f6b');
    }
    return true;
  }

  if (name === 'blackstone' || name === 'blackstone_side' || name === 'blackstone_top') {
    drawGrid(ctx, VOLCANIC_MAP, {
      '0': '#110f14', '1': '#1c1921', '2': '#28242e', '3': '#36303d', '4': '#463f4f',
    });
    if (name !== 'blackstone_top') {
      for (const [rx, ry, rw] of [[1, 3, 6], [8, 2, 6], [3, 7, 7], [1, 11, 5], [7, 12, 7]]) {
        r(rx, ry, rw, 1, '#0d0b0f');
        r(rx + 1, ry + 1, rw - 1, 1, '#433b4d');
      }
    }
    return true;
  }

  if (name === 'gilded_blackstone') {
    drawGrid(ctx, VOLCANIC_MAP, {
      '0': '#110f14', '1': '#1c1921', '2': '#28242e', '3': '#36303d', '4': '#463f4f',
    });
    const nuggets: [number, number, number, number][] = [
      [1, 1, 3, 2], [9, 1, 4, 2], [5, 4, 4, 3],
      [1, 8, 3, 3], [11, 7, 3, 3], [4, 12, 4, 2], [10, 13, 4, 2],
    ];
    for (const [gx, gy, gw, gh] of nuggets) {
      r(gx - 1, gy, gw + 1, gh, '#3b2408');
      r(gx, gy, gw, gh, '#b57416');
      r(gx, gy, Math.max(1, gw - 1), Math.max(1, gh - 1), '#f7c431');
      r(gx, gy, 1, 1, '#fff8b0');
    }
    return true;
  }

  if (name === 'polished_blackstone') {
    r(0, 0, 16, 16, '#26222b');
    r(0, 0, 16, 1, '#4c4457'); r(0, 0, 1, 16, '#4c4457');
    r(0, 15, 16, 1, '#120f14'); r(15, 0, 1, 16, '#120f14');
    r(1, 1, 14, 14, '#302b36');
    r(1, 1, 13, 1, '#3f3847'); r(1, 1, 1, 13, '#3f3847');
    for (const [px, py] of [[3, 3], [10, 4], [5, 9], [11, 11], [4, 13]]) {
      r(px, py, 2, 1, '#3f3847');
      r(px, py + 1, 2, 1, '#201c24');
    }
    return true;
  }

  if (name === 'polished_blackstone_bricks') {
    r(0, 0, 16, 16, '#110e14');
    for (let row = 0; row < 4; row++) {
      const y = row * 4;
      const off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        const x0 = Math.max(0, bx + off);
        const x1 = Math.min(16, bx + off + 7);
        if (x1 <= x0) continue;
        r(x0, y + 1, x1 - x0, 3, '#2d2833');
        r(x0, y + 1, x1 - x0, 1, '#474052');
        r(x0, y + 1, 1, 3, '#3f3847');
        r(x0, y + 3, x1 - x0, 1, '#1c1821');
      }
    }
    r(5, 1, 1, 2, '#16131a');
    r(11, 9, 1, 2, '#16131a');
    return true;
  }

  if (name === 'chiseled_polished_blackstone') {
    r(0, 0, 16, 16, '#141117');
    r(0, 0, 16, 1, '#474052'); r(0, 0, 1, 16, '#474052');
    r(1, 1, 14, 14, '#36303d');
    r(2, 2, 12, 12, '#1d1922');
    r(2, 2, 12, 1, '#4c4457'); r(2, 13, 12, 1, '#120f14');
    r(3, 5, 10, 7, '#3d3647');
    r(3, 5, 10, 1, '#564d63');
    r(4, 6, 8, 5, '#463f4f');
    r(5, 7, 2, 3, '#120f14');
    r(9, 7, 2, 3, '#120f14');
    r(3, 4, 2, 2, '#564d63');
    r(11, 4, 2, 2, '#564d63');
    return true;
  }

  if (name === 'nether_quartz_ore') {
    drawGrid(ctx, NETHERRACK_MAP, NETHERRACK_PAL);
    const crystals: [number, number, number, number][] = [
      [2, 1, 4, 2], [3, 3, 2, 1],
      [9, 2, 4, 2], [10, 4, 3, 1],
      [5, 6, 4, 2], [6, 8, 2, 1],
      [1, 10, 4, 2], [2, 12, 3, 1],
      [10, 9, 4, 2], [11, 11, 2, 1],
      [6, 13, 4, 2],
    ];
    for (const [qx, qy, qw, qh] of crystals) {
      r(qx, qy + qh, qw, 1, '#3b1414');
      r(qx, qy, qw, qh, '#dbd4c7');
      r(qx, qy, Math.max(1, qw - 1), 1, '#ffffff');
      r(qx + qw - 1, qy + qh - 1, 1, 1, '#aba293');
    }
    return true;
  }

  if (name === 'nether_gold_ore') {
    drawGrid(ctx, NETHERRACK_MAP, NETHERRACK_PAL);
    const nuggets: [number, number, number, number][] = [
      [2, 2, 3, 2], [10, 1, 3, 3], [6, 5, 3, 2],
      [1, 9, 3, 3], [11, 8, 3, 2], [5, 12, 3, 2], [10, 13, 3, 2],
    ];
    for (const [gx, gy, gw, gh] of nuggets) {
      r(gx, gy + gh, gw, 1, '#3b1414');
      r(gx, gy, gw, gh, '#bd7a16');
      r(gx, gy, Math.max(1, gw - 1), Math.max(1, gh - 1), '#fad038');
      r(gx, gy, 1, 1, '#fffab8');
    }
    return true;
  }

  if (name === 'ancient_debris_top') {
    r(0, 0, 16, 16, '#2b1d19');
    r(1, 1, 14, 14, '#593e35');
    r(1, 1, 13, 1, '#7d5b4f'); r(1, 1, 1, 13, '#7d5b4f');
    r(2, 2, 12, 12, '#382621');
    r(3, 3, 10, 10, '#6e4e44');
    r(3, 3, 9, 1, '#946f62'); r(3, 3, 1, 9, '#946f62');
    r(4, 4, 8, 8, '#3d2a24');
    r(5, 5, 6, 6, '#826054');
    r(5, 5, 5, 1, '#ab8476'); r(5, 5, 1, 5, '#ab8476');
    r(6, 6, 4, 4, '#47312a');
    r(7, 7, 2, 2, '#a17a6b');
    return true;
  }

  if (name === 'ancient_debris_side') {
    r(0, 0, 16, 16, '#2b1c18');
    const plates: [number, number, number, number][] = [
      [0, 1, 7, 3], [8, 0, 8, 3],
      [2, 5, 8, 3], [11, 4, 5, 3], [0, 5, 2, 2],
      [0, 9, 6, 3], [7, 9, 9, 3],
      [1, 13, 8, 3], [10, 13, 6, 3],
    ];
    for (const [px, py, pw, ph] of plates) {
      r(px, py, pw, ph, '#5e433a');
      r(px, py, pw, 1, '#8f6b5e');
      r(px + 1, py + 1, Math.max(1, pw - 2), 1, '#75554a');
      r(px, py + ph - 1, pw, 1, '#3b2822');
    }
    return true;
  }

  if (name === 'netherite_block') {
    r(0, 0, 16, 16, '#1f1c1f');
    r(0, 0, 16, 1, '#595259'); r(0, 0, 1, 16, '#595259');
    r(0, 15, 16, 1, '#121012'); r(15, 0, 1, 16, '#121012');
    r(1, 1, 14, 14, '#383338');
    for (let y = 2; y < 14; y += 3) {
      r(2, y, 12, 2, '#474147');
      r(2, y, 12, 1, '#5e565e');
      r(2, y + 2, 12, 1, '#262226');
    }
    for (const [rx, ry] of [[2, 2], [13, 2], [2, 13], [13, 13]]) {
      r(rx, ry, 1, 1, '#736a73');
    }
    return true;
  }

  if (name === 'gold_block') {
    r(0, 0, 16, 16, '#ad7410');
    r(0, 0, 16, 1, '#fff59e'); r(0, 0, 1, 16, '#fff59e');
    r(0, 15, 16, 1, '#855506'); r(15, 0, 1, 16, '#855506');
    r(1, 1, 14, 14, '#f5c42c');
    r(2, 2, 12, 12, '#dea91e');
    r(3, 3, 10, 10, '#fad643');
    for (let i = 0; i < 8; i++) {
      r(3 + i, 3 + (i >> 1), 2, 1, '#fff9bd');
      r(4 + i, 9 - (i >> 1), 2, 1, '#e8b625');
    }
    return true;
  }

  if (name === 'nether_bricks' || name === 'red_nether_bricks' || name === 'cracked_nether_bricks') {
    const red = name === 'red_nether_bricks';
    const cracked = name === 'cracked_nether_bricks';
    const mortar = red ? '#240408' : '#170a0d';
    const body1 = red ? '#6b0f1a' : '#3f1f26';
    const body2 = red ? '#590b14' : '#34191f';
    const hi = red ? '#9c202e' : '#63343e';
    const sh = red ? '#3d060b' : '#220f13';
    r(0, 0, 16, 16, mortar);
    for (let row = 0; row < 4; row++) {
      const y = row * 4;
      const off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        const x0 = Math.max(0, bx + off);
        const x1 = Math.min(16, bx + off + 7);
        if (x1 <= x0) continue;
        r(x0, y + 1, x1 - x0, 3, (row + bx) % 2 === 0 ? body1 : body2);
        r(x0, y + 1, x1 - x0, 1, hi);
        r(x0, y + 1, 1, 3, hi);
        r(x0, y + 3, x1 - x0, 1, sh);
      }
    }
    if (cracked) {
      r(3, 1, 1, 2, mortar); r(4, 2, 1, 2, mortar);
      r(11, 5, 1, 2, mortar); r(10, 6, 1, 2, mortar);
      r(5, 9, 1, 2, mortar); r(6, 10, 1, 2, mortar);
      r(12, 13, 1, 2, mortar);
    }
    return true;
  }

  if (name === 'quartz_block_top' || name === 'quartz_block_side' || name === 'quartz_block_bottom' || name === 'smooth_quartz') {
    r(0, 0, 16, 16, '#ebe6dc');
    if (name !== 'smooth_quartz' && name !== 'quartz_block_bottom') {
      r(0, 0, 16, 1, '#fcfbf7'); r(0, 0, 1, 16, '#fcfbf7');
      r(0, 15, 16, 1, '#c9c2b6'); r(15, 0, 1, 16, '#c9c2b6');
    }
    for (const [vx, vy, vw] of [[2, 3, 4], [8, 5, 5], [3, 9, 5], [9, 12, 4]]) {
      r(vx, vy, vw, 1, '#dfd9ce');
      r(vx + 1, vy + 1, vw - 1, 1, '#f7f5f0');
    }
    return true;
  }

  if (name === 'quartz_pillar_top') {
    r(0, 0, 16, 16, '#c9c2b6');
    r(1, 1, 14, 14, '#f7f5f0');
    r(2, 2, 12, 12, '#dad3c7');
    r(3, 3, 10, 10, '#f2eee6');
    r(5, 5, 6, 6, '#cfc8bc');
    r(6, 6, 4, 4, '#faf8f5');
    return true;
  }

  if (name === 'quartz_pillar_side') {
    r(0, 0, 16, 16, '#ebe6dc');
    for (let x = 0; x < 16; x += 3) {
      r(x, 0, 1, 16, '#c9c2b6');
      r(x + 1, 0, 1, 16, '#fcfbf7');
      if (x + 2 < 16) r(x + 2, 0, 1, 16, '#e6e0d5');
    }
    r(0, 0, 16, 1, '#fcfbf7');
    r(0, 15, 16, 1, '#c9c2b6');
    return true;
  }

  if (name === 'quartz_bricks') {
    r(0, 0, 16, 16, '#c4bdb0');
    for (let row = 0; row < 4; row++) {
      const y = row * 4;
      const off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        const x0 = Math.max(0, bx + off);
        const x1 = Math.min(16, bx + off + 7);
        if (x1 <= x0) continue;
        r(x0, y + 1, x1 - x0, 3, '#ebe6dc');
        r(x0, y + 1, x1 - x0, 1, '#fcfbf7');
        r(x0, y + 1, 1, 3, '#f5f2ec');
        r(x0, y + 3, x1 - x0, 1, '#d6cfc2');
      }
    }
    return true;
  }

  if (name === 'crimson_planks' || name === 'warped_planks') {
    const crim = name === 'crimson_planks';
    const base = crim ? '#6b223b' : '#246e68';
    const hi = crim ? '#8a304e' : '#34948c';
    const sh = crim ? '#4f162a' : '#184f4a';
    const seam = crim ? '#300a17' : '#0d2e2b';
    for (let p = 0; p < 4; p++) {
      const py = p * 4;
      r(0, py, 16, 4, base);
      r(0, py, 16, 1, hi);
      r(0, py + 3, 16, 1, seam);
      const jx = (p * 7 + 5) % 16;
      r(jx, py, 1, 4, seam);
      r((jx + 2) % 13, py + 1, 4, 1, sh);
      r((jx + 7) % 13, py + 2, 4, 1, hi);
    }
    return true;
  }

  if (name === 'nether_wart_block' || name === 'warped_wart_block' || name === 'crimson_leaves' || name === 'warped_leaves') {
    const crim = name === 'nether_wart_block' || name === 'crimson_leaves';
    const pal: Record<string, string> = crim
      ? { '0': '#3b0406', '1': '#59080b', '2': '#780e13', '3': '#99171d', '4': '#bd262d' }
      : { '0': '#093633', '1': '#0f524e', '2': '#16706b', '3': '#1f918a', '4': '#2eb3aa' };
    drawGrid(ctx, WART_BLOCK_MAP, pal);
    for (const [wx, wy] of [[3, 1], [11, 2], [5, 5], [13, 8], [2, 9], [8, 12]]) {
      r(wx, wy, 1, 1, crim ? '#d93840' : '#4ad6cb');
    }
    return true;
  }

  if (name === 'glowstone') {
    drawGrid(ctx, VOLCANIC_MAP, {
      '0': '#3d250d', '1': '#573614', '2': '#73481c', '3': '#8f5b24', '4': '#ab6f2e',
    });
    const clusters: [number, number, number, number][] = [
      [1, 1, 4, 3], [7, 1, 4, 2], [12, 2, 3, 3],
      [3, 5, 4, 3], [9, 4, 3, 4], [1, 9, 3, 4],
      [6, 9, 4, 3], [11, 10, 4, 3], [4, 13, 5, 2],
    ];
    for (const [cx, cy, cw, ch] of clusters) {
      r(cx, cy, cw, ch, '#d49a35');
      r(cx, cy, Math.max(1, cw - 1), Math.max(1, ch - 1), '#f7d365');
      r(cx + 1, cy + 1, Math.max(1, cw - 2), 1, '#fffce0');
    }
    return true;
  }

  if (name === 'shroomlight') {
    drawGrid(ctx, WART_BLOCK_MAP, {
      '0': '#993812', '1': '#ba491a', '2': '#d96524', '3': '#f28c32', '4': '#ffb84a',
    });
    for (const [sx, sy] of [[2, 2], [11, 1], [5, 5], [12, 7], [2, 9], [9, 10], [4, 13]]) {
      r(sx, sy, 2, 2, '#ffdf78');
      r(sx, sy, 1, 1, '#fffbe0');
    }
    return true;
  }

  if (name === 'bone_block_top') {
    r(0, 0, 16, 16, '#b5ad96');
    r(1, 1, 14, 14, '#e6e0ce');
    r(3, 3, 10, 10, '#c7bfa8');
    r(5, 5, 6, 6, '#f2ede0');
    r(7, 7, 2, 2, '#b5ad96');
    return true;
  }

  if (name === 'bone_block_side') {
    r(0, 0, 16, 16, '#e3ddca');
    for (const x of [0, 5, 10, 15]) r(x, 0, 1, 16, '#c2ba9f');
    for (const y of [0, 7, 15]) r(0, y, 16, 1, '#aba288');
    r(1, 1, 14, 1, '#f7f4e8');
    r(1, 8, 14, 1, '#f7f4e8');
    return true;
  }

  if (name === 'lodestone' || name === 'lodestone_side') {
    r(0, 0, 16, 16, '#4a4d54');
    r(0, 0, 16, 2, '#878b94');
    r(0, 14, 16, 2, '#32343a');
    r(1, 2, 14, 12, '#686c75');
    r(2, 3, 12, 10, '#52555e');
    r(4, 4, 8, 8, '#383a40');
    r(5, 5, 6, 6, '#878b94');
    r(6, 6, 4, 4, '#b2b7c2');
    r(7, 7, 2, 2, '#2d2f36');
    return true;
  }

  if (name === 'lodestone_top') {
    r(0, 0, 16, 16, '#4a4d54');
    r(1, 1, 14, 14, '#7c808a');
    r(3, 3, 10, 10, '#595c63');
    r(7, 1, 2, 14, '#b2b7c2');
    r(1, 7, 14, 2, '#b2b7c2');
    r(5, 5, 6, 6, '#383a40');
    r(6, 6, 4, 4, '#c8cdd6');
    return true;
  }


  if (name === 'portal') {
    ctx.clearRect(0, 0, 16, 16);
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const dx = x - 7.5, dy = y - 7.5;
        const rDist = Math.hypot(dx, dy);
        const angle = Math.atan2(dy, dx) + rDist * 0.58;
        const v = Math.sin(angle * 2) + Math.cos(rDist * 0.9 - angle) * 0.35;
        const col =
          rDist < 1.8 ? 'rgba(255,240,255,0.96)' :
          rDist < 3.2 && v > 0.1 ? 'rgba(242,190,255,0.93)' :
          v > 0.55 ? 'rgba(218,118,255,0.90)' :
          v > -0.15 ? 'rgba(154,50,238,0.86)' :
          'rgba(76,16,148,0.84)';
        r(x, y, 1, 1, col);
      }
    }
    // Crystalline dimensional sparkles
    for (const [sx, sy] of [[3, 3], [12, 4], [4, 12], [11, 11], [7, 2], [2, 8], [13, 8]]) {
      r(sx, sy, 1, 1, 'rgba(255,230,255,0.95)');
    }
    return true;
  }

  if (name === 'spawner') {
    ctx.clearRect(0, 0, 16, 16);
    // Heavy wrought-iron monster cage with 3D beveled bars, corner brackets & skull emblem
    r(0, 0, 16, 2, '#182232'); r(0, 14, 16, 2, '#101722');
    r(0, 0, 2, 16, '#182232'); r(14, 0, 2, 16, '#101722');
    r(0, 0, 16, 1, '#465f82'); r(0, 0, 1, 16, '#465f82');
    r(1, 15, 15, 1, '#0a0f17'); r(15, 1, 1, 15, '#0a0f17');
    // Inner cross grate bars with specular highlights
    for (const k of [5, 10]) {
      r(k, 2, 2, 12, '#223047'); r(k, 2, 1, 12, '#4c678c');
      r(2, k, 12, 2, '#223047'); r(2, k, 12, 1, '#4c678c');
    }
    // Corner rivets & intersection bosses
    for (const [cx, cy] of [[1, 1], [13, 1], [1, 13], [13, 13], [5, 5], [10, 5], [5, 10], [10, 10]]) {
      r(cx, cy, 2, 2, '#344966');
      r(cx, cy, 1, 1, '#82a6d4');
    }
    // Fiery blaze soul core visible in the center
    r(6, 6, 4, 4, '#d94e14');
    r(7, 7, 2, 2, '#ff9e24');
    r(7, 7, 1, 1, '#fff8a6');
    return true;
  }

  if (name === 'spawner_core') {
    r(0, 0, 16, 16, '#b83c0e');
    r(1, 1, 14, 14, '#eb6e18');
    r(2, 2, 12, 12, '#ffa828');
    r(4, 4, 8, 8, '#ffd84d');
    r(3, 6, 3, 2, '#fffce0'); r(10, 6, 3, 2, '#fffce0');
    r(4, 6, 2, 2, '#2b1208'); r(10, 6, 2, 2, '#2b1208');
    return true;
  }

  if (name === 'trial_spawner' || name === 'trial_spawner_side' || name === 'trial_spawner_top' || name === 'trial_spawner_bottom') {
    ctx.clearRect(0, 0, 16, 16);
    if (name === 'trial_spawner_bottom') {
      r(0, 0, 16, 16, '#253038');
      r(1, 1, 14, 14, '#35444f');
      r(2, 2, 12, 12, '#2b3740');
      r(4, 4, 8, 8, '#8c4a2b');
      r(5, 5, 6, 6, '#c96e44');
      return true;
    }
    // Chiseled dark tuff & oxidized copper frame
    r(0, 0, 16, 3, '#2d3b45'); r(0, 13, 16, 3, '#1c262e');
    r(0, 0, 2, 16, '#2d3b45'); r(14, 0, 2, 16, '#1c262e');
    r(0, 0, 16, 1, '#4fa693'); r(0, 0, 1, 16, '#4fa693');
    r(1, 1, 14, 1, '#d97848'); r(1, 14, 14, 1, '#8c492b');
    // Oxidized copper & bronze cross bars
    for (const k of [5, 10]) {
      r(k, 2, 2, 12, '#2f404a'); r(k, 2, 1, 12, '#5cd4ba');
      r(2, k, 12, 2, '#8c4a2b'); r(2, k, 12, 1, '#eb8b58');
    }
    for (const [cx, cy] of [[1, 1], [13, 1], [1, 13], [13, 13], [5, 5], [10, 5], [5, 10], [10, 10]]) {
      r(cx, cy, 2, 2, '#3b7d6e');
      r(cx, cy, 1, 1, '#78f0d4');
    }
    r(6, 6, 4, 4, '#e06824');
    r(7, 7, 2, 2, '#ffba42');
    r(7, 7, 1, 1, '#fff8c4');
    return true;
  }

  if (name === 'trial_spawner_core') {
    r(0, 0, 16, 16, '#2b6e62');
    r(1, 1, 14, 14, '#47b59e');
    r(3, 3, 10, 10, '#eb7c38');
    r(5, 5, 6, 6, '#ffd258');
    r(6, 6, 4, 4, '#fffbe0');
    return true;
  }

  if (name.startsWith('vault_') || name.startsWith('ominous_vault_')) {
    const om = name.startsWith('ominous_');
    const frameDark = om ? '#121924' : '#1a232b';
    const frameMid = om ? '#223042' : '#2e3d4a';
    const trim = om ? '#388078' : '#c96e42';
    const trimHi = om ? '#64dbcc' : '#f29b6b';
    const glow = om ? '#52f5ff' : '#ffad3b';
    const glowHi = om ? '#e0ffff' : '#fff7bd';
    r(0, 0, 16, 16, frameDark);
    r(0, 0, 16, 2, trim); r(0, 0, 16, 1, trimHi);
    r(0, 14, 16, 2, frameDark); r(1, 14, 14, 1, trim);
    r(1, 2, 14, 12, frameMid);
    // Corner copper/oxidized-copper brackets
    for (const [bx, by] of [[1, 2], [12, 2], [1, 11], [12, 11]]) {
      r(bx, by, 3, 3, trim);
      r(bx, by, 2, 1, trimHi);
    }
    if (name.endsWith('_top')) {
      r(4, 4, 8, 8, frameDark);
      for (let x = 5; x < 11; x += 2) r(x, 5, 1, 6, trimHi);
      return true;
    }
    if (name.endsWith('_front')) {
      // Ornate vault skull/keyhole face plate
      r(4, 3, 8, 10, frameDark);
      r(3, 5, 3, 2, glow); r(10, 5, 3, 2, glow);
      r(4, 5, 1, 1, glowHi); r(11, 5, 1, 1, glowHi);
      // Keyhole slot in center
      r(6, 7, 4, 3, trim); r(6, 7, 4, 1, trimHi);
      r(7, 8, 2, 4, glow); r(7, 8, 1, 2, glowHi);
    } else {
      // Side cage window & copper bars
      r(4, 4, 8, 8, frameDark);
      r(6, 4, 1, 8, trim); r(9, 4, 1, 8, trim);
      r(4, 7, 8, 2, trim); r(4, 7, 8, 1, trimHi);
      r(7, 5, 2, 2, glow);
    }
    return true;
  }

  if (name === 'brewing_stand') {
    ctx.clearRect(0, 0, 16, 16);
    // 3-lobed cobblestone base plate
    r(1, 13, 14, 3, '#585c58');
    r(1, 13, 14, 1, '#969c96');
    r(3, 14, 3, 1, '#7a807a'); r(10, 14, 3, 1, '#7a807a');
    r(1, 15, 14, 1, '#383b38');
    // Central glowing Blaze Rod column
    r(7, 1, 2, 12, '#e09b1b');
    r(7, 1, 1, 12, '#ffe875');
    r(6, 2, 4, 2, '#c97b14'); r(6, 2, 4, 1, '#ffd24c');
    // Alembic manifold arms
    r(3, 5, 10, 1, '#d9921e'); r(4, 4, 8, 1, '#ffe066');
    r(3, 6, 1, 2, '#b87414'); r(12, 6, 1, 2, '#b87414');
    // Left crimson potion flask + glass specular
    r(1, 8, 4, 5, '#b82232'); r(2, 7, 2, 1, '#d8eff5');
    r(2, 9, 2, 3, '#f24658'); r(2, 9, 1, 2, '#ff9ea8');
    // Right amethyst potion flask + glass specular
    r(11, 8, 4, 5, '#7828c4'); r(12, 7, 2, 1, '#d8eff5');
    r(12, 9, 2, 3, '#b352ff'); r(12, 9, 1, 2, '#e8b8ff');
    return true;
  }

  if (name === 'chain') {
    ctx.clearRect(0, 0, 16, 16);
    // Alternating front-facing hollow iron link & side-facing link
    for (const [y, frontLink] of [[0, true], [4, false], [8, true], [12, false]] as const) {
      if (frontLink) {
        r(5, y, 6, 4, '#23272b');
        r(5, y, 5, 3, '#4a5259');
        r(5, y, 5, 1, '#8b959e');
        r(5, y, 1, 3, '#8b959e');
        ctx.clearRect(7, y + 1, 2, 2);
      } else {
        r(6, y, 4, 4, '#23272b');
        r(7, y, 2, 4, '#586169');
        r(7, y, 1, 4, '#9aa5b0');
      }
    }
    return true;
  }

  if (name === 'soul_lantern_glass' || name === 'lantern_glass') {
    const soul = name === 'soul_lantern_glass';
    r(0, 0, 16, 16, '#222629');
    r(0, 0, 16, 2, '#4a5259'); r(0, 14, 16, 2, '#16191c');
    r(0, 0, 2, 16, '#3d444a'); r(14, 0, 2, 16, '#16191c');
    r(2, 2, 12, 12, soul ? '#1b9ab3' : '#d97e18');
    r(3, 3, 10, 10, soul ? '#45e0f5' : '#ffba38');
    r(4, 4, 8, 8, soul ? '#99faff' : '#ffe875');
    r(6, 5, 4, 6, soul ? '#f0ffff' : '#ffffe0');
    r(2, 7, 12, 2, '#2c3136');
    return true;
  }

  if (name === 'lantern_iron') {
    r(0, 0, 16, 16, '#262b2e');
    r(0, 0, 16, 1, '#646e75'); r(0, 0, 1, 16, '#646e75');
    r(0, 15, 16, 1, '#14171a'); r(15, 0, 1, 16, '#14171a');
    r(2, 2, 12, 12, '#383f45');
    r(3, 3, 10, 1, '#78848c'); r(3, 3, 1, 10, '#78848c');
    r(4, 4, 8, 8, '#2d3338');
    r(6, 6, 4, 4, '#4f5861');
    return true;
  }

  if (name === 'soul_lantern' || name === 'lantern') {
    ctx.clearRect(0, 0, 16, 16);
    const soul = name === 'soul_lantern';
    // Hanging ring + stepped iron chimney hood + glowing glass cage
    r(7, 0, 2, 2, '#78838a'); r(7, 0, 1, 2, '#a3b0b8');
    r(5, 2, 6, 2, '#343a3e'); r(5, 2, 6, 1, '#6c767d');
    r(3, 4, 10, 10, '#222629');
    r(3, 4, 10, 1, '#6c767d');
    r(3, 13, 10, 2, '#181b1d'); r(4, 13, 8, 1, '#474f54');
    // Glowing glass pane
    r(4, 5, 8, 8, soul ? '#1b9ab3' : '#d97e18');
    r(5, 6, 6, 6, soul ? '#45e0f5' : '#ffba38');
    r(6, 7, 4, 4, soul ? '#99faff' : '#ffe875');
    r(7, 8, 2, 2, soul ? '#f0ffff' : '#ffffe0');
    // Iron corner & center Mullion bars
    r(3, 5, 1, 8, '#3d444a'); r(12, 5, 1, 8, '#181b1d');
    r(4, 8, 8, 1, '#2c3136');
    return true;
  }

  if (name === 'soul_torch' || name === 'torch') {
    ctx.clearRect(0, 0, 16, 16);
    const soul = name === 'soul_torch';
    // Multi-layered flame head (y = 2..7)
    r(6, 4, 4, 4, soul ? '#1889a1' : '#d96212');
    r(6, 5, 4, 2, soul ? '#36cbe0' : '#fa9c24');
    r(7, 2, 2, 5, soul ? '#6cf2ff' : '#ffd844');
    r(7, 4, 2, 2, soul ? '#ebffff' : '#ffffe0');
    r(6, 2, 1, 1, soul ? '#4ce8ff' : '#ffba38');
    // Coal / Soul Soil brazier collar (y = 8..9)
    r(6, 8, 4, 2, soul ? '#3b2b22' : '#26292b');
    r(7, 8, 2, 1, soul ? '#5c4336' : '#454a4f');
    // Beveled oak stick (y = 10..15)
    for (let y = 10; y < 16; y++) {
      r(7, y, 1, 1, y % 2 === 0 ? '#ba9056' : '#a37b43');
      r(8, y, 1, 1, y % 2 === 0 ? '#7d5a2e' : '#664822');
    }
    return true;
  }

  if (name === 'campfire_log_top' || name === 'campfire_log_side') {
    r(0, 0, 16, 16, '#47311d');
    for (let y = 0; y < 16; y += 4) {
      r(0, y, 16, 1, '#6b4b2e');
      r(0, y + 1, 16, 2, '#523922');
      r(0, y + 3, 16, 1, '#2b1c10');
    }
    for (const x of [3, 9, 14]) r(x, 0, 1, 16, '#362415');
    return true;
  }

  if (name === 'campfire_ember' || name === 'soul_campfire_ember') {
    const soul = name === 'soul_campfire_ember';
    r(0, 0, 16, 16, '#1f1916');
    for (const [ex, ey, ew, eh] of [[1, 1, 5, 4], [8, 2, 6, 4], [3, 6, 9, 5], [1, 11, 6, 4], [9, 10, 5, 5]]) {
      r(ex, ey, ew, eh, soul ? '#1b7a8c' : '#a8320e');
      r(ex + 1, ey + 1, Math.max(1, ew - 2), Math.max(1, eh - 2), soul ? '#45def2' : '#ff8c1e');
      r(ex + 1, ey + 1, 1, 1, soul ? '#dcffff' : '#fff29c');
    }
    return true;
  }

  if (name === 'campfire' || name === 'soul_campfire' || name === 'unlit_campfire') {
    const soul = name === 'soul_campfire';
    const lit = name !== 'unlit_campfire';
    r(0, 0, 16, 16, '#211813');
    // 4 Interlocking charred oak logs with bark ridges & end-grain rings
    for (const y of [1, 11]) {
      r(0, y, 16, 4, '#573c24');
      r(0, y, 16, 1, '#7d5937');
      r(0, y + 3, 16, 1, '#302012');
      r(0, y + 1, 2, 2, '#bfa06b'); r(14, y + 1, 2, 2, '#bfa06b');
    }
    for (const x of [1, 11]) {
      r(x, 0, 4, 16, '#4c341f');
      r(x, 0, 1, 16, '#704f30');
      r(x + 3, 0, 1, 16, '#291b0f');
      r(x + 1, 0, 2, 2, '#bfa06b'); r(x + 1, 14, 2, 2, '#bfa06b');
    }
    // Central glowing coal/soul-soil ash bed & fire core
    r(5, 5, 6, 6, lit ? (soul ? '#187a8c' : '#ab320e') : '#2b2522');
    if (lit) {
      r(5, 6, 6, 4, soul ? '#35d4eb' : '#f57c18');
      r(6, 5, 4, 6, soul ? '#35d4eb' : '#f57c18');
      r(6, 6, 4, 4, soul ? '#7af7ff' : '#ffcf38');
      r(7, 7, 2, 2, soul ? '#ebffff' : '#ffffd8');
    } else {
      r(6, 6, 2, 2, '#3d3530'); r(8, 8, 2, 2, '#3d3530');
    }
    return true;
  }

  if (name === 'fire' || name === 'soul_fire') {
    ctx.clearRect(0, 0, 16, 16);
    const soul = name === 'soul_fire';
    const cOuter = soul ? '#146a7d' : '#ba2e0a';
    const cMid = soul ? '#28bad4' : '#f26d14';
    const cInner = soul ? '#64f0ff' : '#ffba26';
    const cCore = soul ? '#e8ffff' : '#fffac2';
    const heights = [0, 8, 11, 14, 12, 15, 16, 13, 16, 15, 12, 14, 11, 9, 6, 0];
    for (let x = 1; x < 15; x++) {
      const h = heights[x];
      if (h <= 0) continue;
      r(x, 16 - h, 1, h, cOuter);
      const hm = Math.max(1, h - 3);
      r(x, 16 - hm, 1, hm, cMid);
      const hi = Math.max(1, h - 6);
      if (h >= 7) r(x, 16 - hi, 1, hi, cInner);
      if (h >= 10) r(x, 13, 1, 3, cCore);
    }
    // Rising detached flame licks & sparks
    r(3, 1, 1, 2, cMid); r(6, 0, 1, 2, cInner); r(9, 0, 1, 2, cInner); r(12, 2, 1, 2, cMid);
    return true;
  }

  if (name === 'nether_wart') {
    ctx.clearRect(0, 0, 16, 16);
    const stalks: [number, number, number, number][] = [[1, 7, 4, 4], [6, 3, 4, 5], [11, 6, 4, 4]];
    for (const [sx, top, bw, bh] of stalks) {
      // Rooted dark crimson stalks
      r(sx + 1, top + bh - 1, 2, 16 - (top + bh - 1), '#45070e');
      r(sx + 1, top + bh - 1, 1, 16 - (top + bh - 1), '#6e0e18');
      // Swollen bulbous crimson wart cap with 3D specular highlight
      r(sx, top, bw, bh, '#7d111c');
      r(sx, top, bw, bh - 1, '#a61926');
      r(sx, top, bw - 1, 1, '#de3542');
      r(sx + 1, top + 1, Math.max(1, bw - 2), Math.max(1, bh - 2), '#c42332');
      r(sx + 1, top + 1, 1, 1, '#ff7580');
    }
    return true;
  }

  if (name === 'crimson_fungus' || name === 'warped_fungus' || name === 'crimson_sapling' || name === 'warped_sapling') {
    const crim = name.startsWith('crimson');
    ctx.clearRect(0, 0, 16, 16);
    const stemDark = crim ? '#471620' : '#153d3a';
    const stemMid = crim ? '#692432' : '#225e59';
    const stemHi = crim ? '#8c3546' : '#33827b';
    const capDark = crim ? '#5c0c12' : '#0e4742';
    const capMid = crim ? '#961820' : '#1a786f';
    const capHi = crim ? '#c92832' : '#28a397';
    const capRim = crim ? '#e6404a' : '#42ccb8';
    const spot = '#ff9828';
    const spotHi = '#fff5a8';
    // Thick rooted stem (y = 9..15)
    r(6, 9, 4, 7, stemDark);
    r(6, 9, 3, 7, stemMid);
    r(7, 9, 1, 7, stemHi);
    r(5, 14, 6, 2, stemDark); r(6, 14, 3, 2, stemMid);
    // Domed mushroom cap (y = 2..9)
    r(2, 7, 12, 2, capMid);
    r(3, 5, 10, 2, capMid);
    r(4, 3, 8, 2, capHi);
    r(6, 2, 4, 1, capRim);
    r(2, 8, 12, 1, capDark); // Underside shadow & gills
    // Glowing orange shroomlight warts on cap
    for (const [wx, wy] of [[4, 6], [7, 4], [10, 6], [5, 3], [9, 5]]) {
      r(wx, wy, 2, 2, spot);
      r(wx, wy, 1, 1, spotHi);
    }
    return true;
  }

  if (name === 'crimson_roots' || name === 'warped_roots' || name === 'nether_sprouts') {
    ctx.clearRect(0, 0, 16, 16);
    const crim = name === 'crimson_roots';
    const sprout = name === 'nether_sprouts';
    const cDark = crim ? '#4f0a12' : '#0d423e';
    const cMid = crim ? '#8a1622' : '#18736b';
    const cHi = crim ? '#bf2636' : '#26a69b';
    const cTip = crim ? '#ff735c' : '#7afff0';
    const baseH = sprout ? 6 : 11;
    const xs = [1, 3, 5, 7, 9, 11, 13, 14];
    for (let i = 0; i < xs.length; i++) {
      const x = xs[i];
      const h = baseH + ((i * 5 + 3) % (sprout ? 4 : 5));
      for (let y = 16 - h; y < 16; y++) {
        const sway = ((y + i) % 3 === 0) ? (i % 2 === 0 ? -1 : 1) : 0;
        const px = Math.max(1, Math.min(14, x + sway));
        const col = y === 16 - h ? cTip : y < 16 - h + 3 ? cHi : y > 13 ? cDark : cMid;
        r(px, y, y > 12 && !sprout ? 2 : 1, 1, col);
      }
    }
    return true;
  }

  if (name === 'weeping_vines' || name === 'twisting_vines') {
    ctx.clearRect(0, 0, 16, 16);
    const weep = name === 'weeping_vines';
    const cDark = weep ? '#4f0a10' : '#0c403c';
    const cMid = weep ? '#87151f' : '#176e67';
    const cHi = weep ? '#bf2634' : '#26a399';
    const cGlow = weep ? '#ff755c' : '#7afff2';
    for (let y = 0; y < 16; y++) {
      const wave = Math.round(Math.sin(y * 0.65) * 2);
      const sx = 6 + wave;
      r(sx, y, 4, 1, y % 2 === 0 ? cMid : cDark);
      r(sx + 1, y, 2, 1, cHi);
      if (y % 4 === 1) {
        r(sx - 2, y, 2, 2, cMid);
        r(sx - 2, y, 1, 1, cGlow);
      } else if (y % 4 === 3) {
        r(sx + 4, y, 2, 2, cMid);
        r(sx + 5, y, 1, 1, cGlow);
      }
    }
    return true;
  }

  if (name === 'wither_skeleton_skull_top' || name === 'wither_skeleton_skull_side') {
    r(0, 0, 16, 16, '#26262b');
    r(0, 0, 16, 2, '#45454f'); r(0, 0, 2, 16, '#45454f');
    r(0, 14, 16, 2, '#121215'); r(14, 0, 2, 16, '#121215');
    // Cranial sutures & battle scars
    r(3, 4, 10, 1, '#121215'); r(8, 2, 1, 8, '#121215');
    r(4, 5, 8, 1, '#3b3b44');
    if (name === 'wither_skeleton_skull_side') {
      // Temporal fossa & jaw line on side face
      r(3, 6, 6, 4, '#141418');
      r(2, 11, 12, 1, '#3f3f48');
      r(2, 12, 12, 3, '#121215');
      for (let x = 2; x < 12; x += 2) r(x, 12, 1, 3, '#4a4a54');
    }
    return true;
  }

  if (name === 'wither_skeleton_skull') {
    r(0, 0, 16, 16, '#28282e');
    r(0, 0, 16, 2, '#4a4a54'); r(1, 2, 14, 2, '#36363e');
    // Heavy furrowed brow ridge
    r(1, 4, 14, 2, '#4f4f59'); r(2, 4, 12, 1, '#646470');
    // Deep sunken pitch-black eye sockets
    r(2, 6, 4, 4, '#060608'); r(10, 6, 4, 4, '#060608');
    r(2, 6, 4, 1, '#1a1a20'); r(10, 6, 4, 1, '#1a1a20');
    // Nasal cavity
    r(7, 8, 2, 3, '#060608');
    // Cheekbones & clenched charred teeth
    r(1, 10, 5, 2, '#3d3d46'); r(10, 10, 5, 2, '#3d3d46');
    r(2, 12, 12, 4, '#0c0c0f');
    for (let x = 3; x < 13; x += 2) {
      r(x, 12, 1, 3, '#52525e');
      r(x, 12, 1, 1, '#6c6c7a');
    }
    return true;
  }

  if (name === 'piglin_head_top' || name === 'piglin_head_side' || name === 'piglin_ear' || name === 'piglin_snout') {
    r(0, 0, 16, 16, '#d18e6b');
    r(0, 0, 16, 2, '#e3a482'); r(0, 14, 16, 2, '#a66847');
    for (const [px, py] of [[3, 4], [10, 5], [5, 10], [11, 11]]) r(px, py, 3, 2, '#bd7b58');
    if (name === 'piglin_snout') {
      r(0, 0, 16, 16, '#e6a685');
      r(0, 0, 16, 2, '#f5bc9e');
      r(2, 4, 4, 8, '#3d1c10');
      r(10, 4, 4, 8, '#3d1c10');
    }
    return true;
  }

  if (name === 'piglin_head') {
    r(0, 0, 16, 16, '#d4926f');
    r(0, 0, 16, 2, '#e6a785');
    r(2, 3, 12, 2, '#b57250'); // Heavy brow
    //Narrow fierce Piglin eyes (white sclera + dark pupils)
    r(2, 6, 4, 2, '#fcf7f0'); r(4, 6, 2, 2, '#21140e');
    r(10, 6, 4, 2, '#fcf7f0'); r(10, 6, 2, 2, '#21140e');
    // Prominent snout & nostrils
    r(4, 8, 8, 6, '#e8aa88');
    r(4, 8, 8, 1, '#f7bfa0');
    r(5, 10, 2, 3, '#421f12'); r(9, 10, 2, 3, '#421f12');
    // Sharp protruding ivory tusks flanking the snout
    r(2, 9, 2, 5, '#fffdf5'); r(2, 12, 2, 2, '#e0d4b8');
    r(12, 9, 2, 5, '#fffdf5'); r(12, 12, 2, 2, '#e0d4b8');
    return true;
  }

  void rnd;
  return false;
}


// =====================================================================================================================
// 5. SAND, SOUL SAND/SOIL & SANDSTONE FAMILY (16x16 Multi-Iteration Hand-Crafted Jappa+ Pixel Art)
// =====================================================================================================================

const SAND_MAP = [
  '3443212334543223',
  '2332101234432112',
  '1221212321121012',
  '2343323432112123',
  '3455434543223234',
  '2344323432101233',
  '1221101210112342',
  '2332212321234553',
  '3454323443345542',
  '4553212344334321',
  '3321011233212112',
  '2112122321101223',
  '1223234432212344',
  '2344345543323454',
  '3454334432112343',
  '4543212321123334',
];

const SAND_PAL: Record<string, string> = {
  '0': '#baa56b',
  '1': '#c8b57b',
  '2': '#d5c48b',
  '3': '#dfd09a',
  '4': '#eadca8',
  '5': '#f4e8ba',
  '6': '#fbf3cc',
};

const BEACH_SAND_PAL: Record<string, string> = {
  '0': '#c2af78',
  '1': '#d0be88',
  '2': '#ddd09a',
  '3': '#e7dba8',
  '4': '#f0e6b8',
  '5': '#f8f0c8',
  '6': '#fffbe0',
};

const RED_SAND_PAL: Record<string, string> = {
  '0': '#8c3b10',
  '1': '#a14817',
  '2': '#b5561f',
  '3': '#c66527',
  '4': '#d67631',
  '5': '#e4883e',
  '6': '#f09c52',
};

const SUS_SAND_0_MAP = [
  '3443212334543223',
  '2332101234432112',
  '1270212321170012',
  '2343326432112123',
  '3455434543223234',
  '2344370432101233',
  '1701107210117042',
  '2332212321234553',
  '3454323703345542',
  '4553212344337021',
  '3370011233212112',
  '2116122321101223',
  '1223234437012344',
  '2344345543323454',
  '3454337032112703',
  '4543212321123334',
];

const SUS_SAND_1_MAP = [
  '3443212334543223',
  '2332101234432112',
  '1270212321170012',
  '2343326432112123',
  '3455410012223234',
  '2344107701101233',
  '1701079870117042',
  '2332078a70234553',
  '3454107701345542',
  '4553210012337021',
  '3370011233212112',
  '2116122321101223',
  '1223234437012344',
  '2344345543323454',
  '3454337032112703',
  '4543212321123334',
];

const SUS_SAND_2_MAP = [
  '3443212334543223',
  '2332101234432112',
  '1270212321170012',
  '2343100001212123',
  '3451077770123234',
  '2340799877001233',
  '170079b8a7017042',
  '233078aa87034553',
  '3450778870145542',
  '4551077701337021',
  '3370100012312112',
  '2116122321101223',
  '1223234437012344',
  '2344345543323454',
  '3454337032112703',
  '4543212321123334',
];

const SUS_SAND_3_MAP = [
  '3443212334543223',
  '2332101234432112',
  '1271000001170012',
  '2310777770112123',
  '3407999887023234',
  '23079bc987001233',
  '17079ca9a8017042',
  '2307899a87034553',
  '34078a8877045542',
  '4510777770137021',
  '3371000001212112',
  '2116122321101223',
  '1223234437012344',
  '2344345543323454',
  '3454337032112703',
  '4543212321123334',
];

const SUS_SAND_PAL: Record<string, string> = {
  '0': '#baa56b',
  '1': '#c8b57b',
  '2': '#d5c48b',
  '3': '#dfd09a',
  '4': '#eadca8',
  '5': '#f4e8ba',
  '6': '#fbf3cc',
  '7': '#99834b',
  '8': '#b56345',
  '9': '#de8b6b',
  'a': '#783924',
  'b': '#f5d458',
  'c': '#58e8dc',
};

const SOUL_SAND_MAP = [
  '2343212234432122',
  '3454211245543233',
  '3102322341034103',
  '2001343340023002',
  '2212454232233223',
  '3333443123443334',
  '4432000123002444',
  '3321000123002333',
  '2212101233223212',
  '1123222344332101',
  '2234433455421112',
  '3441034104322223',
  '4530023003210123',
  '3432233223200013',
  '2343344332100012',
  '1233221233210122',
];

const SOUL_SAND_PAL: Record<string, string> = {
  '0': '#1f1510',
  '1': '#31231b',
  '2': '#443228',
  '3': '#574135',
  '4': '#6b5244',
  '5': '#7f6454',
  '6': '#917665',
};

const SOUL_SOIL_MAP = [
  '2344321122344322',
  '3455432112345432',
  '2344321001234431',
  '1233210011223321',
  '1122101223322111',
  '2233212344431001',
  '3444323455432101',
  '4554322344321112',
  '3443211223210123',
  '2332100112101234',
  '1221001223212344',
  '1112112344323454',
  '2223223455433443',
  '3344322344322332',
  '2345431123211221',
  '1234432112233321',
];

const SOUL_SOIL_PAL: Record<string, string> = {
  '0': '#241a15',
  '1': '#352720',
  '2': '#47352c',
  '3': '#5a453a',
  '4': '#6e5649',
  '5': '#84695a',
};

const SANDSTONE_PAL: Record<string, string> = {
  '0': '#a8945a',
  '1': '#bdab72',
  '2': '#cfc088',
  '3': '#dfd19c',
  '4': '#ebe0b0',
  '5': '#f5ecc2',
  '6': '#fcf6d8',
};

const RED_SANDSTONE_PAL: Record<string, string> = {
  '0': '#6e2c0b',
  '1': '#873912',
  '2': '#a1481a',
  '3': '#b85823',
  '4': '#cc6a2e',
  '5': '#de7d3b',
  '6': '#ed9250',
};

const SANDSTONE_TOP_MAP = [
  '5544434554434452',
  '5333322344433331',
  '4345432345432342',
  '4344321123321342',
  '3222123332122331',
  '4334334543234432',
  '5445434432134542',
  '4433212212233431',
  '3212223443321221',
  '4323444554322332',
  '5434544443213442',
  '4323332211223441',
  '3212233322344331',
  '4323445433454322',
  '4433443322333221',
  '2112211221122110',
];

const SANDSTONE_SIDE_MAP = [
  '5665545566554565',
  '4554434455443454',
  '3443223344322343',
  '1001101100100110',
  '2344322345432233',
  '3455431234432134',
  '2344320123321023',
  '1122112210012211',
  '2344323443223443',
  '3454312344312343',
  '2232101233201222',
  '1011223211012321',
  '2344334432233442',
  '2333212321012332',
  '1101121101221011',
  '2332233223343222',
];

const SANDSTONE_BOTTOM_MAP = [
  '2332101233432112',
  '3443212344432101',
  '2332101233211212',
  '1101222110012332',
  '2212343221123443',
  '3323444332234432',
  '2332333210123321',
  '1221110011221101',
  '1101232123343212',
  '2212343234443223',
  '3433443123332112',
  '2332211011211001',
  '1221012222101222',
  '2332123443212343',
  '3443234432101233',
  '2211012211012221',
];

const CHISELED_SANDSTONE_MAP = [
  '5665545566554565',
  '4554434455443454',
  '1000000000000001',
  '3411111111111123',
  '4145544444554402',
  '4150024554002402',
  '3150024444002402',
  '3143344002433402',
  '3144540002454402',
  '4144440002444402',
  '4144440330244402',
  '3145440240244302',
  '3134433443343302',
  '2000000000000001',
  '4554434455443454',
  '1101101100100110',
];

const CHISELED_RED_SANDSTONE_MAP = [
  '5665545566554565',
  '4554434455443454',
  '1000000000000001',
  '3411111111111123',
  '4140024002400202',
  '4140020000200202',
  '3143300000023402',
  '3144443002444402',
  '3140000000002402',
  '4143343002334402',
  '4140000000002402',
  '3144433002344302',
  '3134444002443302',
  '2000000000000001',
  '4554434455443454',
  '1101101100100110',
];

const CUT_SANDSTONE_MAP = [
  '5665556655566552',
  '6544444554444431',
  '5433443443344331',
  '5434543333454321',
  '4333433233343321',
  '4323332332333221',
  '5433343443334331',
  '2111111111111110',
  '4556655245566552',
  '5444443154444431',
  '4334433143344331',
  '4345432143454321',
  '3334332133343321',
  '3233322132333221',
  '4333433143334331',
  '2111111021111110',
];

const SMOOTH_SANDSTONE_MAP = [
  '5665545566554553',
  '6444334444334442',
  '5433333443333342',
  '5433444444333442',
  '4334454443334431',
  '4334554433234431',
  '5433443332233442',
  '5443333333334442',
  '4444334443334432',
  '4334444544333331',
  '5433445544332331',
  '5433344433222342',
  '4432233333233442',
  '4333333443334432',
  '5443344443344331',
  '3221122221122211',
];

export function drawSandFamilyTile(name: string, ctx: Context2D): boolean {
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === 'sand') {
    drawGrid(ctx, SAND_MAP, SAND_PAL);
    r(4, 3, 1, 1, SAND_PAL['6']);
    r(11, 8, 1, 1, SAND_PAL['6']);
    r(6, 13, 1, 1, SAND_PAL['6']);
    return true;
  }

  if (name === 'beach_sand') {
    drawGrid(ctx, SAND_MAP, BEACH_SAND_PAL);
    r(3, 4, 1, 1, BEACH_SAND_PAL['6']);
    r(10, 2, 1, 1, BEACH_SAND_PAL['6']);
    r(13, 8, 1, 1, BEACH_SAND_PAL['6']);
    r(5, 13, 1, 1, BEACH_SAND_PAL['6']);
    return true;
  }

  if (name === 'red_sand') {
    drawGrid(ctx, SAND_MAP, RED_SAND_PAL);
    r(4, 3, 1, 1, RED_SAND_PAL['6']);
    r(11, 8, 1, 1, RED_SAND_PAL['6']);
    r(6, 13, 1, 1, RED_SAND_PAL['6']);
    return true;
  }

  if (name === 'suspicious_sand' || name === 'suspicious_sand_0') {
    drawGrid(ctx, SUS_SAND_0_MAP, SUS_SAND_PAL);
    return true;
  }
  if (name === 'suspicious_sand_1') {
    drawGrid(ctx, SUS_SAND_1_MAP, SUS_SAND_PAL);
    return true;
  }
  if (name === 'suspicious_sand_2') {
    drawGrid(ctx, SUS_SAND_2_MAP, SUS_SAND_PAL);
    return true;
  }
  if (name === 'suspicious_sand_3') {
    drawGrid(ctx, SUS_SAND_3_MAP, SUS_SAND_PAL);
    return true;
  }

  if (name === 'soul_sand') {
    drawGrid(ctx, SOUL_SAND_MAP, SOUL_SAND_PAL);
    r(2, 1, 1, 1, SOUL_SAND_PAL['6']);
    r(10, 1, 1, 1, SOUL_SAND_PAL['6']);
    r(8, 10, 1, 1, SOUL_SAND_PAL['6']);
    return true;
  }

  if (name === 'soul_soil') {
    drawGrid(ctx, SOUL_SOIL_MAP, SOUL_SOIL_PAL);
    return true;
  }

  if (name.includes('sandstone')) {
    const red = name.includes('red_');
    const pal = red ? RED_SANDSTONE_PAL : SANDSTONE_PAL;
    if (name.endsWith('_top')) {
      drawGrid(ctx, SANDSTONE_TOP_MAP, pal);
      return true;
    }
    if (name.endsWith('_bottom')) {
      drawGrid(ctx, SANDSTONE_BOTTOM_MAP, pal);
      return true;
    }
    if (name === 'chiseled_sandstone' || name === 'chiseled_red_sandstone') {
      drawGrid(ctx, red ? CHISELED_RED_SANDSTONE_MAP : CHISELED_SANDSTONE_MAP, pal);
      return true;
    }
    if (name === 'cut_sandstone' || name === 'cut_red_sandstone') {
      drawGrid(ctx, CUT_SANDSTONE_MAP, pal);
      return true;
    }
    if (name === 'smooth_sandstone' || name === 'smooth_red_sandstone') {
      drawGrid(ctx, SMOOTH_SANDSTONE_MAP, pal);
      return true;
    }
    drawGrid(ctx, SANDSTONE_SIDE_MAP, pal);
    return true;
  }

  return false;
}
