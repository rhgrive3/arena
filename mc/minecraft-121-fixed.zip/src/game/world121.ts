// Engine-side glue for the dungeon / 1.21 pass. Owns the trial-spawner, vault, beacon and conduit runtimes, the hive / turtle-egg
// registries, archaeology brushing, decorated pots, explorer-map searches and the player half of the four new status effects.
//
// Performance notes
//  • Special blocks are *registered*, never searched for: `scanChunk` makes one linear pass over a freshly mounted chunk using a
//    256-entry-style lookup table (≈0.1 ms per chunk) and `onSetBlock` keeps the registry current afterwards.
//  • Registered blocks are ticked at low rates (spawners 4 Hz, beacons every 4 s, conduits every 2 s, hives / eggs 1 Hz).
//  • Structure searches for explorer maps run in idle-time slices (see systems/explorerMap.ts).
import * as THREE from 'three';
import type { Engine } from './engine';
import { BLOCKS, ID, resolve } from './data';
import { blockState } from './blockState';
import type { Stack } from './types';
import * as SV from './survival';
import { MIN_Y } from '../world/terrain';
import { extraLootTable, sitesNear } from '../world/structures';
import { mineshaftLayout, mineshaftVariantFor } from '../world/struct/mineshaft';
import { chamberLayout, type SpawnerKind } from '../world/dungeons';
import { EventBus } from './events';
import { OMINOUS_BOTTLE_DURATION, ominousBottleAmplifier, ominousBottleStack } from '../systems/vanillaPlus';
import { TrialSystem, spawnerProfile, NO_EQUIPMENT, type TrialSave } from '../systems/trials';
import { NetherBlockRigMeshes, type NetherRigKind } from '../render/banners3d';
import { BeaconSystem, beaconRange, BEACON_PAYMENT, type BeaconSave } from '../systems/beacon';
import { BrushSession, BRUSH_STROKES, archaeologyRoll, pickTable, positionSeed, potInsert } from '../systems/archaeology';
import { EXPLORER_MAPS, searchStructure, describeTarget, type SearchJob } from '../systems/explorerMap';
import { ominousEquipment, INFESTED_CHANCE, WIND_CHARGED_RADIUS } from '../systems/combat121';
import { tickTurtleEgg, campfireBelow, HIVE_MAX_HONEY } from '../entities/behaviors';
import type { Mob, Species } from '../entities/mobs';
import type { Offer } from '../entities/mobdata';

interface DimStore { trials?: TrialSave; beacons?: BeaconSave; released?: string[] }
export interface W121Save { uuid: string; dims: Record<string, DimStore> }
interface UseTarget { x: number; y: number; z: number; id: number }
const B = ID as Record<string, number | undefined>;
const any = (v: unknown) => v as any;                                    // eslint-disable-line @typescript-eslint/no-explicit-any
const newUuid = () => globalThis.crypto?.randomUUID?.() ?? 'p-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
const fmt = (sec: number) => `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;
const W = { spawner: 1, vault: 2, ominousVault: 3, beacon: 4, conduit: 5, nest: 6, hive: 7, egg: 8 };
const POWER_JA: Record<string, string> = { speed: '移動速度上昇', haste: '採掘速度上昇', resistance: '耐性', jump_boost: '跳躍力上昇', strength: '攻撃力上昇', regeneration: '再生能力', '': 'なし' };

export class World121 {
  readonly events = new EventBus();
  readonly trials: TrialSystem;
  readonly beacons: BeaconSystem;
  readonly netherRigs: NetherBlockRigMeshes | null;
  private rigKinds = new Map<number, NetherRigKind>();
  private rigKindArr = new Array<NetherRigKind | undefined>(4096);
  /** Block name → numeric id, exposed for renderers, debugging overlays and browser smoke tests (`window.__game.w121.ids`). */
  readonly ids = ID as Record<string, number>;
  /** Stable id of the local player — vault rewards are tracked per UUID. */
  playerUuid = newUuid();
  private watch = new Uint8Array(4096);
  private hives = new Map<string, { x: number; y: number; z: number; bees: number; timer: number }>();
  private monsterSpawners = new Map<string, { x: number; y: number; z: number; delay: number }>();
  private eggs = new Map<string, [number, number, number]>();
  private released = new Set<string>();
  private store: Record<string, DimStore> = {};
  private dim = 'overworld';
  private brush = new BrushSession();
  private searches = new Map<string, SearchJob>();
  /** Diagnostics of the explorer-map searches finished so far (slices used and the longest single slice in ms). */
  searchStats = { searches: 0, slices: 0, regions: 0, maxSliceMs: 0 };
  private acc = 0;
  /** Pending ominous item spawners and lingering clouds (game-time driven, so they pause with the game). */
  private itemSpawners: { at: THREE.Vector3; item: string; t: number }[] = [];
  private clouds: { at: THREE.Vector3; effect: string; sec: number; t: number; tick: number }[] = [];

  constructor(private e: Engine) {
    const mark = (name: string, kind: number) => { const id = B[name]; if (id !== undefined) this.watch[id] = kind; };
    mark('trial_spawner', W.spawner); mark('vault', W.vault); mark('ominous_vault', W.ominousVault); mark('beacon', W.beacon);
    mark('conduit', W.conduit); mark('bee_nest', W.nest); mark('beehive', W.hive); mark('turtle_egg', W.egg);
    this.netherRigs = e.scene ? new NetherBlockRigMeshes(e.scene) : null;
    for (const rk of ['campfire', 'soul_campfire', 'unlit_campfire', 'spawner', 'trial_spawner', 'respawn_anchor', 'wither_skeleton_skull', 'piglin_head', 'brewing_stand', 'soul_lantern', 'lantern'] as NetherRigKind[]) {
      const rid = B[rk];
      if (rid !== undefined) { this.rigKinds.set(rid, rk); this.rigKindArr[rid] = rk; }
    }
    const solid = (x: number, y: number, z: number) => { const id = e.getBlock(x, y, z); return id > 0 && !!BLOCKS[id]?.solid; };
    const setState = (x: number, y: number, z: number, state: number) => {
      const id = e.getBlock(x, y, z);
      if (id > 0 && blockState(e.getCell(x, y, z)) !== state) e.setBlock(x, y, z, id, state);
    };
    const playerActive = () => !e.dead && e.meta.mode !== 'spectator';
    const emit: EventBus['emit'] = (type, payload) => this.events.emit(type, payload);

    this.trials = new TrialSystem({
      now: () => e.meta.playTime,
      rng: Math.random,
      blockAt: (x, y, z) => {
        const id = e.getBlock(x, y, z);
        if (id === B.trial_spawner) return 'spawner';
        if (id === B.vault) return 'vault';
        if (id === B.ominous_vault) return 'ominous_vault';
        return this.loaded(x, z) ? 'other' : null;
      },
      setPhase: setState,
      playersNear: (x, y, z, r) => (playerActive() && e.position.distanceTo(new THREE.Vector3(x, y - 0.9, z)) <= r
        ? [{ id: this.playerUuid, omen: Math.max(SV.amp(e, 'bad_omen'), SV.amp(e, 'trial_omen')) }] : []),
      spawn: (species, x, y, z, ominous, key) => {
        if (e.meta.difficulty === 'peaceful' || e.mobs.mobs.length >= 64) return null;
        const bx = Math.floor(x), bz = Math.floor(z);
        let fy: number | null = null;
        for (const dy of [0, 1, -1, 2, -2]) if (solid(bx, y + dy - 1, bz) && !solid(bx, y + dy, bz) && !solid(bx, y + dy + 1, bz)) { fy = y + dy; break; }
        if (fy === null) return null;
        const m = e.mobs.spawn(species as Species, x, z, false, fy);
        if (!m) return null;
        m.trial = key;
        if (ominous) {
          // Java 1.21: ominous trial mobs spawn wearing the equipment/trial_chamber armour set (chainmail or iron, no extra health).
          // This project has no visible mob equipment, so the set is applied as its armour points.
          m.ominous = true;
          if (!NO_EQUIPMENT.has(species)) {
            const gear = ominousEquipment(Math.random, /skeleton|stray|bogged/.test(species));
            m.bonusArmor = gear.armor; m.bonusTough = gear.toughness; m.weaponDamage = gear.weapon;
          }
        }
        e.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 0.8, 0)), ominous ? '#6fb7ff' : '#ffb347', 14, 2);
        return m.id;
      },
      alive: id => e.mobs.mobs.some(m => m.id === id),
      remove: id => {
        const m = e.mobs.mobs.find(x => x.id === id);
        if (!m) return;
        e.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 0.8, 0)), '#9aa7b8', 10, 2);
        e.mobs.scene.remove(m.group);
        e.mobs.mobs = e.mobs.mobs.filter(x => x !== m);
      },
      eject: (x, y, z, reward) => {
        const at = new THREE.Vector3(x + 0.5, y + 1.25, z + 0.5), color = resolve(reward.item)?.color ?? '#d8c27a';
        if (reward.item === 'ominous_bottle') {
          const amp = reward.ench?.ominous_bottle_amplifier ?? 0;
          for (let i = 0; i < reward.count; i++) { const ob = ominousBottleStack(amp + 1); SV.rememberDrop(e, ob); e.particles.drop(at, ob.name, 1, color, ob); }
        } else {
          const max = resolve(reward.item)?.durability;
          const st: Stack = { name: reward.item, count: 1, ...(reward.ench ? { ench: reward.ench } : {}), ...(reward.durability !== undefined && max ? { durability: Math.max(1, Math.round(max * reward.durability)) } : {}) };
          if (st.ench || st.durability !== undefined) { SV.rememberDrop(e, st); e.particles.drop(at, reward.item, reward.count, color, st); }
          else e.particles.drop(at, reward.item, reward.count, color);
        }
        e.audio?.play('xp', { x: x + 0.5, y: y + 1, z: z + 0.5 });
      },
      seed: () => e.terrain.seed,
      ominousItem: (sx, sy, sz, item) => {
        // Targets: the player or a mob of this spawner within 14 blocks; the item spawner appears 2–5 blocks above it and
        // shoots after a 3–6 s telegraph (minecraft.wiki "Ominous Trial Spawner").
        const c = new THREE.Vector3(sx + 0.5, sy + 0.5, sz + 0.5), key = `${sx},${sy},${sz}`;
        const targets: THREE.Vector3[] = [];
        if (playerActive() && e.position.distanceTo(c) <= 14) targets.push(e.position);
        for (const m of e.mobs.mobs) if ((m as { trial?: string }).trial === key && m.group.position.distanceTo(c) <= 14) targets.push(m.group.position);
        if (!targets.length) return;
        const t = targets[Math.floor(Math.random() * targets.length)];
        const at = new THREE.Vector3(t.x + (Math.random() - 0.5), t.y + 2 + Math.random() * 3, t.z + (Math.random() - 0.5));
        this.itemSpawners.push({ at, item, t: 3 + Math.random() * 3 });
        e.audio?.play('portal', at);
      },
      omenUsed: () => {
        const level = Math.max(1, SV.amp(e, 'bad_omen'));
        delete e.effects.bad_omen;
        e.mobs.badOmen = false;
        SV.addEffect(e, 'trial_omen', 900 * level, level - 1);          // Java: 15 min per Bad Omen level, same amplifier
        e.onToast('不吉な予感が試練の予兆に変わった… 不吉な試練が始まる！', 'Bad Omen became Trial Omen — an ominous trial begins!');
      },
      emit,
    });

    this.beacons = new BeaconSystem({
      getBlock: (x, y, z) => e.getBlock(x, y, z),
      setState,
      skyClear: (x, y, z) => {
        for (let yy = y + 1; yy < y + 96; yy++) { const d = BLOCKS[e.getBlock(x, yy, z)]; if (d && d.id > 0 && d.solid && !d.transparent && d.name !== 'bedrock') return false; }
        return true;
      },
      players: () => (playerActive() ? [{ id: this.playerUuid, x: e.position.x, y: e.position.y, z: e.position.z, wet: this.playerWet() }] : []),
      addEffect: (_player, id, sec, amp) => { SV.addEffect(e, id, sec, amp); },
      hostilesInWater: (x, y, z, r) => e.mobs.mobs.filter(m => e.mobs.isHostile(m) && m.group.position.distanceTo(new THREE.Vector3(x, y, z)) <= r
        && e.getBlock(m.group.position.x, m.group.position.y + 0.4, m.group.position.z) === ID.water).map(m => m.id),
      damageMob: (id, damage) => { const m = e.mobs.mobs.find(x => x.id === id); if (m) e.mobs.extraDamage(m, damage); },
      emit,
    });

    // Hooks the mob behaviours need from the world (all optional on MobHost so headless tests can leave them out).
    Object.assign(e.mobs.host, {
      setBlock: (x: number, y: number, z: number, id: number, state = 0) => e.setBlock(x, y, z, id, state),
      getState: (x: number, y: number, z: number) => blockState(e.getCell(x, y, z)),
      raining: () => e.weather !== 'clear' && e.dimension === 'overworld',
      emit,
      growCrop: (x: number, y: number, z: number) => e.farming.bonemeal(x, y, z),
      nearestDrop: (name: string, x: number, y: number, z: number, r: number, avoid?: [number, number, number] | null) => {
        let best: THREE.Vector3 | null = null, bd = r * r;
        for (const d of e.particles.drops) {
          if (d.name !== name) continue;
          const q = d.mesh.position;
          if (avoid && (q.x - avoid[0] - 0.5) ** 2 + (q.z - avoid[2] - 0.5) ** 2 < 6.25) continue;
          const dd = (q.x - x) ** 2 + (q.y - y) ** 2 + (q.z - z) ** 2;
          if (dd < bd) { bd = dd; best = q; }
        }
        return best ? { x: best.x, y: best.y, z: best.z } : null;
      },
      takeDrop: (name: string, x: number, y: number, z: number, r: number) => {
        const drops = e.particles.drops;
        for (let i = 0; i < drops.length; i++) {
          const d = drops[i], q = d.mesh.position;
          if (d.name !== name || (q.x - x) ** 2 + (q.y - y) ** 2 + (q.z - z) ** 2 > r * r) continue;
          any(e.particles).release?.(d.mesh);
          drops.splice(i, 1);
          return d.count;
        }
        return 0;
      },
      onMobDeath: (m: Mob) => this.trials.onMobDeath(m.id),
      wearHeld: (n: number) => { if (e.meta.mode !== 'creative') SV.wear(e, 'main', n); },
      mapOffers: (m: Mob) => this.mapOffers(m),
      knockPlayer: (dx: number, dy: number, dz: number) => { e.velocity.x += dx; e.velocity.z += dz; e.velocity.y = Math.max(e.velocity.y, dy); e.grounded = false; },
    });

    this.events.on('trial_spawner_state', p => {
      if (p.phase === 'active') { e.onToast(p.ominous ? '不吉な試練が始まった！' : '試練が始まった！モブを全滅させよう', p.ominous ? 'An ominous trial begins!' : 'The trial begins — defeat every mob!'); e.audio?.play('portal', p); }
      else if (p.phase === 'ejecting') { e.onToast('試練を突破！報酬が排出されます', 'Trial complete! Rewards incoming'); e.audio?.play('levelup', p); }
    });
  }

  private loaded(x: number, z: number) {
    const k = Math.floor(x / 16) + ',' + Math.floor(z / 16);
    return this.e.chunks.has(k) || !!any(this.e).sideChunks?.has(k);
  }
  private playerWet() {
    const e = this.e;
    return e.getBlock(e.position.x, e.position.y + 0.6, e.position.z) === ID.water || (e.weather !== 'clear' && e.dimension === 'overworld');
  }
  /** Movement penalty check used by survival.speedFactor. */
  inCobweb() {
    const e = this.e, web = B.cobweb;
    return web !== undefined && (e.getBlock(e.position.x, e.position.y + 0.2, e.position.z) === web || e.getBlock(e.position.x, e.position.y + 1.2, e.position.z) === web);
  }

  // ===== registry =========================================================================================================
  /** One linear pass over a freshly generated / loaded chunk; registers the handful of block types that need ticking. */
  scanChunk(data: Uint16Array, cx: number, cz: number, maxY?: number) {
    const watch = this.watch;
    // Everything above the generated column top (exclusive, already padded by the terrain generator) is air: stop there
    // instead of walking all 384 layers (one spare layer kept as a margin).
    const n = maxY !== undefined && Number.isFinite(maxY) ? Math.min(data.length, Math.max(0, maxY - MIN_Y + 1) * 256) : data.length;
    for (let i = 0; i < n; i++) {
      const bid = data[i] & 0x0fff;
      const kind = watch[bid];
      const rk = this.rigKindArr[bid];
      if (!kind && !rk) continue;
      const rem = i & 255;
      const wx = cx * 16 + (rem & 15), wy = (i >> 8) + MIN_Y, wz = cz * 16 + (rem >> 4);
      if (rk) {
        this.netherRigs?.set(`${wx},${wy},${wz}`, wx, wy, wz, rk);
        if (rk === 'spawner' && !this.monsterSpawners.has(`${wx},${wy},${wz}`)) {
          this.monsterSpawners.set(`${wx},${wy},${wz}`, { x: wx, y: wy, z: wz, delay: 2 + ((wx * 13 + wz * 7) & 3) });
        }
      }
      if (kind) this.register(kind, wx, wy, wz);
    }
  }
  onSetBlock(x: number, y: number, z: number, id: number, previousId: number) {
    if (id === previousId) return;
    const rkNow = this.rigKinds.get(id);
    if (rkNow) {
      this.netherRigs?.set(`${x},${y},${z}`, x, y, z, rkNow);
      if (rkNow === 'spawner') this.monsterSpawners.set(`${x},${y},${z}`, { x, y, z, delay: 2 });
    } else if (this.rigKinds.has(previousId)) {
      this.netherRigs?.remove(`${x},${y},${z}`);
      this.monsterSpawners.delete(`${x},${y},${z}`);
    }
    const was = this.watch[previousId] ?? 0, now = this.watch[id] ?? 0;
    if (was) {
      const key = `${x},${y},${z}`;
      if (was <= W.ominousVault) this.trials.remove(x, y, z);
      else if (was <= W.conduit) this.beacons.remove(x, y, z);
      else if (was === W.egg) this.eggs.delete(key);
      else this.hives.delete(key);
    }
    if (now) this.register(now, x, y, z, true);
  }
  private register(kind: number, x: number, y: number, z: number, placed = false) {
    const key = `${x},${y},${z}`;
    switch (kind) {
      case W.spawner: {
        if (this.trials.spawnerAt(x, y, z)) return;
        const p = spawnerProfile(x, y, z, this.e.terrain.seed, placed ? undefined : this.chamberKind(x, y, z));
        this.trials.registerSpawner(x, y, z, p.kind, p.species);
        return;
      }
      case W.vault: case W.ominousVault: this.trials.registerVault(x, y, z, kind === W.ominousVault); return;
      case W.beacon: this.beacons.addBeacon(x, y, z); return;
      case W.conduit: this.beacons.addConduit(x, y, z); return;
      case W.egg: this.eggs.set(key, [x, y, z]); return;
      default:
        // Natural nests start with 2–3 bees inside; they fly out once (remembered in `released`) when the chunk is first visited.
        if (!this.hives.has(key)) this.hives.set(key, { x, y, z, bees: kind === W.nest && !placed && !this.released.has(key) ? 2 + ((x * 31 + z * 17) & 1) : 0, timer: 3 });
    }
  }
  /** Determines which mob species a classic Monster Spawner at (x, y, z) spawns based on its enclosing structure. */
  spawnerSpeciesAt(x: number, y: number, z: number): Species {
    const e = this.e;
    if (e.dimension === 'nether') {
      for (const p of sitesNear(e.terrain, 'bastion', x, z, 0)) if (Math.abs(x - p.x) <= 14 && Math.abs(z - p.z) <= 14) return 'magma_cube';
      return 'blaze';
    }
    const [shx, shz] = e.terrain.strongholdPos();
    if (Math.abs(x - shx) <= 90 && Math.abs(z - shz) <= 90 && y <= 45) return 'silverfish';
    for (const p of sitesNear(e.terrain, 'mineshaft', x, z, 0)) {
      const v = mineshaftVariantFor(e.terrain.biome(p.x, p.z));
      const L = mineshaftLayout(e.terrain.seed, p.x, p.y, p.z, v);
      if (L.spawners.some(s => s[0] === x && s[1] === y && s[2] === z)) return 'cave_spider';
    }
    for (const p of sitesNear(e.terrain, 'mansion', x, z, 0)) {
      if (Math.abs(x - p.x) <= 36 && Math.abs(z - p.z) <= 36) return 'spider';
    }
    return e.terrain.dungeonSpawnerSpecies(x, y, z);
  }

  private chamberKind(x: number, y: number, z: number): SpawnerKind | undefined {
    const e = this.e;
    if (e.dimension !== 'overworld' || !e.meta.structures) return undefined;
    for (const p of sitesNear(e.terrain, 'trial_chambers', x, z, 0)) {
      const hit = chamberLayout(e.terrain.seed, p.x, p.y, p.z).spawners.find(s => s.x === x && s.y === y && s.z === z);
      if (hit) return hit.kind;
    }
    return undefined;
  }

  /** Ominous item spawners: telegraph (particles), then shoot their item straight down; lingering clouds pulse their effect. */
  private tickItemSpawners(dt: number) {
    const e = this.e;
    if (!this.itemSpawners.length && !this.clouds.length) return;
    for (let i = this.itemSpawners.length - 1; i >= 0; i--) {
      const sp = this.itemSpawners[i];
      sp.t -= dt;
      if (Math.random() < dt * 6) e.particles.burst(sp.at, '#6fb7ff', 3, 0.6);
      if (sp.t > 0) continue;
      this.itemSpawners.splice(i, 1);
      const down = new THREE.Vector3(0, -1, 0), from = sp.at.clone();
      if (sp.item.startsWith('potion:')) {
        const effect = sp.item.slice(7);
        e.mobs.launchProjectile('potion', from, down, 6, undefined, {
          gravity: 12, color: resolve('potion_' + effect)?.color ?? '#9ab8ff',
          // Lingering potion: a 3-block cloud; each pulse gives 1/4 of the potion's duration (3:00 → 0:45, Slow Falling 1:30 → 0:22).
          onEnd: (pos: THREE.Vector3) => { this.clouds.push({ at: pos.clone(), effect, sec: effect === 'slow_falling' ? 22 : 45, t: 30, tick: 0 }); e.particles.burst(pos, resolve('potion_' + effect)?.color ?? '#9ab8ff', 30, 3); },
        });
      } else if (sp.item === 'wind_charge') e.mobs.launchProjectile('wind_charge', from, down, 14, undefined, { damage: 1 });
      else if (sp.item === 'small_fireball') e.mobs.launchProjectile('blaze_fireball', from, down, 12, undefined, { damage: 5 });
      else {
        const effect: [string, number, number] | undefined = sp.item === 'arrow_poison' ? ['poison', 45, 0] : sp.item === 'arrow_slowness' ? ['slowness', 20, 3] : undefined;
        e.mobs.launchProjectile('mob_arrow', from, down, 14, undefined, { damage: 3, effect });
      }
      e.audio?.play('bow', from);
    }
    for (let i = this.clouds.length - 1; i >= 0; i--) {
      const c = this.clouds[i];
      c.t -= dt; c.tick -= dt;
      if (Math.random() < dt * 10) e.particles.burst(c.at.clone().add(new THREE.Vector3((Math.random() - 0.5) * 5, 0.2, (Math.random() - 0.5) * 5)), resolve('potion_' + c.effect)?.color ?? '#9ab8ff', 1, 0.4);
      if (c.tick <= 0) {
        c.tick = 1;
        if (e.position.distanceTo(c.at) < 3) SV.addEffect(e, c.effect, c.sec, 0);
        for (const m of e.mobs.mobs) if (m.group.position.distanceTo(c.at) < 3) e.mobs.addMobEffect(m, c.effect, c.sec, 0);
      }
      if (c.t <= 0) this.clouds.splice(i, 1);
    }
  }

  // ===== per-frame ========================================================================================================
  clearRigs() { this.netherRigs?.clear(); }
  unloadChunk(cx: number, cz: number) { this.netherRigs?.unloadChunk(cx, cz); }

  update(dt: number) {
    this.netherRigs?.update(dt);
    this.tickItemSpawners(dt);
    this.trials.update(dt);
    this.beacons.update(dt);
    const hand = this.e.hotbar[this.e.selected], aim = this.e.target;
    if (hand?.name === 'brush' && aim && this.e.input.useHeld) {            // holding the button keeps brushing (stroke rate is limited by BrushSession)
      const bn = BLOCKS[this.e.getBlock(aim.x, aim.y, aim.z)]?.name;
      if (bn === 'suspicious_sand' || bn === 'suspicious_gravel') this.brushBlock(aim.x, aim.y, aim.z, bn);
    }
    this.acc += dt;
    if (this.acc < 1) return;
    this.acc = 0;
    const e = this.e, day = e.environment.daylight > 0.3, calm = e.weather === 'clear' || e.dimension !== 'overworld';
    if (e.meta.difficulty !== 'peaceful' && e.mobs.mobs.length < 56) {
      for (const [key, ms] of this.monsterSpawners) {
        if (e.getBlock(ms.x, ms.y, ms.z) !== B.spawner) { if (this.loaded(ms.x, ms.z)) this.monsterSpawners.delete(key); continue; }
        const dist = Math.hypot(ms.x + 0.5 - e.position.x, ms.y + 0.5 - e.position.y, ms.z + 0.5 - e.position.z);
        if (dist > 16) continue;
        if (--ms.delay > 0) continue;
        ms.delay = 10 + Math.floor(Math.random() * 20); // 200..600 ticks (10..30s)
        const sp = this.spawnerSpeciesAt(ms.x, ms.y, ms.z);
        const nearbySame = e.mobs.mobs.filter(m => m.species === sp && Math.abs(m.group.position.x - (ms.x + 0.5)) <= 4.5 && Math.abs(m.group.position.y - ms.y) <= 4.5 && Math.abs(m.group.position.z - (ms.z + 0.5)) <= 4.5).length;
        if (nearbySame >= 6) continue;
        const count = 1 + Math.floor(Math.random() * 4);
        for (let i = 0; i < count; i++) {
          const sx = ms.x + 0.5 + (Math.random() - Math.random()) * 4;
          const sz = ms.z + 0.5 + (Math.random() - Math.random()) * 4;
          const sy = ms.y + Math.floor(Math.random() * 3) - 1;
          if (e.getBlock(Math.floor(sx), sy, Math.floor(sz)) === 0) {
            e.mobs.spawn(sp, sx, sz, false, sy);
          }
        }
      }
    }
    for (const [key, h] of this.hives) {                                 // bees leave a natural nest one by one on a fine day
      if (h.bees <= 0 || !day || !calm || e.mobs.mobs.length > 44 || Math.abs(h.x - e.position.x) > 40 || Math.abs(h.z - e.position.z) > 40) continue;
      if (--h.timer > 0) continue;
      h.timer = 4;
      const id = e.getBlock(h.x, h.y, h.z);
      if (id !== B.bee_nest && id !== B.beehive) { if (this.loaded(h.x, h.z)) this.hives.delete(key); continue; }
      const a = Math.random() * Math.PI * 2, bee = e.mobs.spawn('bee', h.x + 0.5 + Math.cos(a) * 1.2, h.z + 0.5 + Math.sin(a) * 1.2, false, h.y);
      if (!bee) continue;
      bee.hive = [h.x, h.y, h.z];
      if (--h.bees === 0) this.released.add(key);
    }
    for (const [key, [x, y, z]] of this.eggs) {                           // turtle eggs crack (mostly at night) and hatch
      const cell = e.getCell(x, y, z), id = cell & 0x0fff;
      if (id !== B.turtle_egg) { if (this.loaded(x, z)) this.eggs.delete(key); continue; }
      const r = tickTurtleEgg(blockState(cell), !day, Math.random);
      if (r.hatch) {
        e.setBlock(x, y, z, 0);
        for (let i = 0; i < r.hatch; i++) {
          const baby = e.mobs.spawn('turtle', x + 0.3 + Math.random() * 0.4, z + 0.3 + Math.random() * 0.4, true, y);
          if (baby) baby.home = [x, y, z];                               // hatchlings remember their home beach
        }
        this.events.emit('turtle_hatch', { x, y, z, eggs: r.hatch });
        e.audio?.play('click', { x, y, z });
      } else if (r.state !== blockState(cell)) e.setBlock(x, y, z, id, r.state);
    }
  }
  /** A storm bolt: lands on a random nearby mob about a third of the time, otherwise somewhere around the player. */
  lightning() {
    const e = this.e, near = e.mobs.mobs.filter(m => m.group.position.distanceTo(e.position) < 48 && m.group.position.distanceTo(e.position) > 4);
    let pos: THREE.Vector3;
    if (near.length && Math.random() < 0.35) pos = near[Math.floor(Math.random() * near.length)].group.position.clone();
    else {
      const a = Math.random() * Math.PI * 2, d = 10 + Math.random() * 30, x = e.position.x + Math.cos(a) * d, z = e.position.z + Math.sin(a) * d;
      pos = new THREE.Vector3(x, e.terrain.height(x, z) + 1, z);
    }
    e.mobs.behaviors.lightning(pos, false);
  }

  // ===== player half of the 1.21 effects ==================================================================================
  onPlayerHurt(amount: number, source: string) {
    const e = this.e;
    if (amount > 0 && source !== 'starve' && source !== 'void' && SV.has(e, 'infested') && Math.random() < INFESTED_CHANCE) e.mobs.behaviors.infest(e.position.clone(), 'player');
  }
  onPlayerDeath() {
    const e = this.e, p = e.position.clone(), b = e.mobs.behaviors;
    if (SV.has(e, 'oozing')) b.ooze(p, 'player');
    if (SV.has(e, 'wind_charged')) {
      b.windBurst(p.x, p.y + 0.5, p.z, WIND_CHARGED_RADIUS, 'wind_charged');
      this.events.emit('effect_trigger', { effect: 'wind_charged', entity: 'player', x: p.x, y: p.y, z: p.z, count: 1 });
    }
    if (SV.has(e, 'weaving')) b.weave(p, 'player');
  }

  // ===== right-click ======================================================================================================
  /** Returns true when the click was consumed by one of the systems in this file. */
  use(target: UseTarget | null, held: Stack | null): boolean {
    const e = this.e, name = held?.name ?? '', creative = e.meta.mode === 'creative';
    const consume = () => { if (!creative) e.consumeSelected(); };
    if (name === 'ominous_bottle') {
      SV.addEffect(e, 'bad_omen', OMINOUS_BOTTLE_DURATION, ominousBottleAmplifier(held!));   // the bottle's own level (I–V), 100 min
      consume();
      e.audio?.play('portal');
      e.onToast('不吉な予感… トライアルスポナーに近づくと不吉な試練になる', 'Bad Omen… trial spawners nearby will turn ominous');
      return true;
    }
    const splash = /^splash_(wind_charged|infested|oozing|weaving)$/.exec(name);
    if (splash) {
      const dir = e.camera.getWorldDirection(new THREE.Vector3()), id = splash[1];
      consume();
      e.audio?.play('bow');
      e.mobs.launchProjectile('potion', e.camera.position.clone().addScaledVector(dir, 0.6), dir, 14, undefined, {
        gravity: 9, color: resolve(name)?.color ?? '#bdc9ff',
        onEnd: (pos: THREE.Vector3) => {
          e.mobs.behaviors.splash(pos, id, 135);
          if (pos.distanceTo(e.position) < 4) SV.addEffect(e, id, 135, 0);
          e.particles.burst(pos, resolve(name)?.color ?? '#bdc9ff', 24, 4);
        },
      });
      return true;
    }
    const bn = target ? BLOCKS[target.id]?.name : undefined;
    if (target && bn) {
      const { x, y, z } = target;
      switch (bn) {
        case 'vault': case 'ominous_vault': return this.useVault(x, y, z, bn === 'ominous_vault', name, consume);
        case 'trial_spawner': {
          const s = this.trials.spawnerAt(x, y, z);
          if (!s) return true;
          const left = s.cooldownUntil - e.meta.playTime;
          if (s.phase === 'cooldown') e.onToast(`このスポナーは休止中です（残り ${fmt(left)}）`, `This spawner is on cooldown (${fmt(left)} left)`);
          else e.onToast(`トライアルスポナー：${s.ominous ? '不吉な試練 · ' : ''}${resolve(s.species)?.ja ?? s.species} — 討伐 ${s.killed}`, `Trial spawner: ${s.ominous ? 'ominous · ' : ''}${s.species} — ${s.killed} defeated`);
          return true;
        }
        case 'beacon': if (BEACON_PAYMENT.includes(name)) return this.useBeacon(x, y, z, name, consume); break;
        case 'conduit': {
          const c = this.beacons.addConduit(x, y, z);
          e.onToast(c.active ? `コンジット起動中：フレーム ${c.frame}/42 · 範囲 ${c.range}${c.hunting ? ' · 敵性モブを迎撃' : ''}` : `コンジット停止中：フレーム ${c.frame}/42（16個以上と水中3×3×3が必要）`,
            c.active ? `Conduit active: frame ${c.frame}/42 · range ${c.range}${c.hunting ? ' · attacking hostiles' : ''}` : `Conduit inactive: frame ${c.frame}/42 (needs 16+ and a 3×3×3 of water)`);
          return true;
        }
        case 'suspicious_sand': case 'suspicious_gravel': if (name === 'brush') return this.brushBlock(x, y, z, bn); break;
        case 'decorated_pot': if (!e.input.crouch) return this.usePot(x, y, z, held, consume); break;
        case 'bee_nest': case 'beehive': if (name === 'shears' || name === 'glass_bottle') return this.harvestHive(x, y, z, target.id, name, consume); break;
        case 'farmland': case 'farmland_moist': {
          const plant = name === 'torchflower_seeds' ? B.torchflower : name === 'pitcher_pod' ? B.pitcher_plant : undefined;
          if (plant !== undefined && e.getBlock(x, y + 1, z) === 0) { e.setBlock(x, y + 1, z, plant); consume(); e.audio?.play('wood'); return true; }
          break;
        }
      }
    }
    if (held?.map) {
      const d = describeTarget(e.position.x, e.position.z, held.map.x, held.map.z);
      e.onToast(`${held.label ?? '探検家の地図'}：目標は${d.ja}へ約 ${d.distance} ブロック（X ${held.map.x}, Z ${held.map.z}）`, `${name.replace(/_/g, ' ')}: target ${d.distance} blocks ${d.en} (X ${held.map.x}, Z ${held.map.z})`);
      return true;
    }
    return false;
  }

  private useVault(x: number, y: number, z: number, ominous: boolean, held: string, consume: () => void): boolean {
    const e = this.e;
    this.trials.registerVault(x, y, z, ominous);
    const r = this.trials.tryUnlock(x, y, z, this.playerUuid, held || undefined);
    if (r.ok) {
      consume();
      e.audio?.play('levelup', { x, y, z });
      e.onToast(ominous ? '不吉な宝物庫が開いた！' : '宝物庫が開いた！', ominous ? 'The ominous vault opens!' : 'The vault opens!');
      e.statistics.vaults_opened = (e.statistics.vaults_opened ?? 0) + 1;
      return true;
    }
    const need = ominous ? '不吉なトライアルキー' : 'トライアルキー', needEn = ominous ? 'an ominous trial key' : 'a trial key';
    if (r.reason === 'already') e.onToast('この宝物庫はすでに開けています（プレイヤーごとに1回だけ）', 'You have already looted this vault (once per player)');
    else if (r.reason === 'wrong_key') e.onToast(`この宝物庫には${need}が必要です`, `This vault needs ${needEn}`);
    else if (r.reason === 'no_key') e.onToast(`${need}を持って使うと開きます`, `Use ${needEn} to open it`);
    else if (r.reason === 'busy') e.onToast('宝物庫は報酬を排出中です', 'The vault is still ejecting rewards');
    return true;
  }

  private useBeacon(x: number, y: number, z: number, held: string, consume: () => void): boolean {
    const e = this.e, b = this.beacons.addBeacon(x, y, z), level = this.beacons.refreshBeacon(b);
    if (level === 0) { e.onToast('ビーコンは停止中：鉄・金・ダイヤ・エメラルド・ネザライトのブロックで3×3以上のピラミッドを組み、上空を開けてください', 'Beacon inactive: build a 3×3+ pyramid of mineral blocks under it with open sky above'); return true; }
    if (BEACON_PAYMENT.includes(held) && this.beacons.cyclePower(b, e.input.crouch)) { consume(); e.audio?.play('levelup', { x, y, z }); }
    const second = b.secondary === '' ? '' : b.secondary === b.primary ? ' II' : ' + ' + POWER_JA.regeneration;
    e.onToast(`ビーコン Lv${level}（範囲 ${beaconRange(level)}）：${POWER_JA[b.primary] ?? b.primary}${second} — インゴットや宝石を持って使うとパワーを切替（スニークで第2パワー）`,
      `Beacon tier ${level} (range ${beaconRange(level)}): ${b.primary}${b.secondary === b.primary ? ' II' : b.secondary ? ' + ' + b.secondary : ''} — use an ingot/gem to change power (sneak: secondary)`);
    return true;
  }

  private brushBlock(x: number, y: number, z: number, bn: string): boolean {
    const e = this.e, key = `${this.dim}:${x},${y},${z}`, n = this.brush.stroke(key, performance.now() / 1000), id = B[bn]!;
    if (n === 0) return true;
    e.handDip = 0.14;
    e.audio?.play('stone', { x, y, z });
    e.particles.burst(new THREE.Vector3(x + 0.5, y + 1.02, z + 0.5), BLOCKS[id].color, 6, 1.5);
    if (n < BRUSH_STROKES) {
      e.setBlock(x, y, z, id, n);
      this.events.emit('brush_progress', { x, y, z, stage: n });
      return true;
    }
    const seed = positionSeed(x, y, z, e.terrain.seed), coin = ((seed >>> 0) % 1000) / 1000;
    const table = pickTable(bn, e.meta.structures ? extraLootTable(e.terrain, x, y, z) : null, true, coin), item = archaeologyRoll(table, seed);
    e.setBlock(x, y, z, bn === 'suspicious_sand' ? ID.sand : ID.gravel);
    e.particles.drop(new THREE.Vector3(x + 0.5, y + 1.2, z + 0.5), item, 1, resolve(item)?.color ?? '#9a5a3f');
    if (e.meta.mode !== 'creative') SV.wear(e, 'main', 1);
    e.statistics.blocks_brushed = (e.statistics.blocks_brushed ?? 0) + 1;
    e.onToast(`${resolve(item)?.ja ?? item} を掘り出した！`, `Unearthed ${item.replace(/_/g, ' ')}!`);
    this.events.emit('archaeology_find', { x, y, z, item });
    this.brush.reset();
    return true;
  }

  private usePot(x: number, y: number, z: number, held: Stack | null, consume: () => void): boolean {
    const e = this.e, key = `${x},${y},${z}`, slots = (e.containers[key] ??= [null]), cur = slots[0];
    if (!held) {
      e.onToast(cur ? `飾り壺の中身：${resolve(cur.name)?.ja ?? cur.name} ×${cur.count}（壊すと取り出せます）` : '飾り壺は空です', cur ? `Pot holds ${cur.count} × ${cur.name.replace(/_/g, ' ')} (break it to take them out)` : 'The pot is empty');
      return true;
    }
    const r = potInsert(cur, held, resolve(held.name)?.stack ?? 64, 1);
    if (!r) { e.onToast('飾り壺には1種類・1スタックまでしか入りません', 'A decorated pot holds a single stack of one item'); e.audio?.play('stone', { x, y, z }); return true; }
    slots[0] = r.slot;
    consume();
    e.audio?.play('click', { x, y, z });
    return true;
  }

  private harvestHive(x: number, y: number, z: number, id: number, tool: string, consume: () => void): boolean {
    const e = this.e, honey = blockState(e.getCell(x, y, z));
    if (honey < HIVE_MAX_HONEY) { e.onToast(`ハチミツはまだ ${honey}/${HIVE_MAX_HONEY} です`, `Honey level ${honey}/${HIVE_MAX_HONEY}`); return true; }
    const item = tool === 'shears' ? 'honeycomb' : 'honey_bottle';
    if (tool === 'shears') { e.particles.drop(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), 'honeycomb', 3, '#e8a83a'); if (e.meta.mode !== 'creative') SV.wear(e, 'main', 1); }
    else { consume(); e.addItem('honey_bottle', 1); }
    e.setBlock(x, y, z, id, 0);
    const calm = campfireBelow((bx, by, bz) => e.getBlock(bx, by, bz), x, y, z), angry = calm ? 0 : e.mobs.behaviors.angerHive(x, y, z);
    e.audio?.play('wood', { x, y, z });
    if (angry) e.onToast('ミツバチが怒った！（巣の下に焚き火を置くと安全に採取できます）', 'The bees are angry! (a campfire under the hive keeps them calm)');
    else e.onToast(item === 'honeycomb' ? 'ハニカムを採取した' : 'ハチミツ入りの瓶を手に入れた', item === 'honeycomb' ? 'Collected honeycomb' : 'Collected a honey bottle');
    this.events.emit('hive_harvest', { x, y, z, item, calm });
    this.events.emit('hive_honey', { x, y, z, level: 0 });
    return true;
  }

  // ===== cartographer explorer maps =======================================================================================
  /** Map trades of a cartographer. The first time a trade level is seen the structure search starts in the background. */
  mapOffers(m: Mob): Offer[] {
    if (m.profession !== 'cartographer' || this.e.dimension !== 'overworld') return [];
    const out: Offer[] = [], maps = (m.maps ??= {});
    for (const spec of EXPLORER_MAPS) {
      if (m.level < spec.level) continue;
      const base: Offer = { id: 'map_' + spec.kind, give: 'emerald', n: spec.cost, cost: spec.cost, get: spec.item, result: spec.item, count: 1, xp: spec.xp, level: spec.level, maxUses: 3 };
      const known = maps[spec.kind];
      if (known === undefined) { this.startSearch(m, spec.kind); out.push({ ...base, pending: true }); }
      else if (known) out.push({ ...base, map: { kind: spec.kind, x: known[0], z: known[2], icon: spec.icon } });
    }
    return out;
  }
  private startSearch(m: Mob, kind: string) {
    const key = m.id + ':' + kind, e = this.e;
    if (this.searches.has(key)) return;
    const job = searchStructure(e.terrain, kind, m.group.position.x, m.group.position.z);
    this.searches.set(key, job);
    this.events.emit('explorer_map', { kind, status: 'searching' });
    void job.promise.then(found => {
      if (this.searches.get(key) !== job) return;
      this.searches.delete(key);
      const st = this.searchStats;
      st.searches++; st.slices += job.slices; st.regions += job.regionsScanned; st.maxSliceMs = Math.max(st.maxSliceMs, job.maxSliceMs);
      (m.maps ??= {})[kind] = found;
      const spec = EXPLORER_MAPS.find(s => s.kind === kind);
      this.events.emit('explorer_map', found ? { kind, status: 'found', x: found[0], z: found[2] } : { kind, status: 'none' });
      if (found && spec) e.onToast(`製図家が「${spec.ja}」を描き上げました`, `The cartographer finished the ${spec.en}`);
    });
  }

  // ===== persistence ======================================================================================================
  private stash() { this.store[this.dim] = { trials: this.trials.save(), beacons: this.beacons.save(), released: [...this.released] }; }
  private apply(s?: DimStore) {
    this.trials.load(s?.trials);
    this.beacons.load(s?.beacons);
    this.released = new Set(s?.released ?? []);
    this.hives.clear(); this.eggs.clear(); this.brush.reset(); this.netherRigs?.clear();
  }
  /** The player moved to another dimension: block positions are per-dimension, so swap the registries. */
  enter(dim: string) {
    if (dim === this.dim) return;
    this.stash();
    this.dim = dim;
    this.apply(this.store[dim]);
  }
  save(): W121Save { this.stash(); return { uuid: this.playerUuid, dims: structuredClone(this.store) }; }
  load(save: W121Save | undefined | null, dim: string) {
    for (const job of this.searches.values()) job.cancel();
    this.searches.clear();
    this.playerUuid = save?.uuid ?? newUuid();
    this.store = save?.dims ? structuredClone(save.dims) : {};
    this.dim = dim;
    this.apply(this.store[dim]);
  }
}
