export type Pattern = 'grass' | 'dirt' | 'stone' | 'sand' | 'bark' | 'rings' | 'leaves' | 'planks' | 'water' | 'glass' | 'bricks' | 'cobble' | 'tnt' | 'ore' | 'gravel' | 'snow' | 'plant' | 'craft' | 'furnace' | 'chest' | 'torch' | 'lava' | 'obsidian' | 'wool' | 'metal' | 'gem' | 'tool' | 'food' | 'misc' | 'cactus' | 'nylium' | 'bed' | 'purpur' | 'end_portal_frame' | 'shulker' | 'debris' | 'concrete' | 'terracotta' | 'prismarine' | 'quartz' | 'mushroom' | 'sponge' | 'amethyst' | 'deepslate' | 'target';
export type Shape = 'cube' | 'chest' | 'cross' | 'water' | 'slab' | 'stairs' | 'fence' | 'pane' | 'torch' | 'door' | 'trapdoor' | 'lily' | 'cactus' | 'bed' | 'end_portal_frame' | 'end_rod' | 'shulker_box' | 'dragon_egg' | 'dragon_head' | 'end_portal' | 'end_gateway' | 'lantern' | 'enchanting_table' | 'anvil' | 'brewing_stand' | 'piston_head' | 'moving_piston';
export interface BlockDef { id: number; name: string; ja: string; color: string; pattern: Pattern; hardness: number; tool: string; solid: boolean; transparent: boolean; shape: Shape; category: string; drop?: string; light?: number; tier?: number; stack: number; food?: number; damage?: number; durability?: number; }
export const RAW_BLOCKS: BlockDef[] = [{ id: 0, name: 'air', ja: '空気', color: '#ffffff', pattern: 'misc', hardness: 0, tool: '', solid: false, transparent: true, shape: 'cube', category: 'nature', stack: 0 }];
export const INTERNAL_BLOCKS: Record<number, BlockDef> = {};
export const ALL_BLOCKS: BlockDef[] = [RAW_BLOCKS[0]];
export const PRECOMPUTED_TILES: number[][] = [];
export const BLOCKS: BlockDef[] = new Proxy(RAW_BLOCKS, {
  get(target, prop, receiver) {
    if (typeof prop === 'string') {
      const idx = Number(prop);
      if (Number.isInteger(idx) && idx >= target.length && INTERNAL_BLOCKS[idx] !== undefined) {
        return INTERNAL_BLOCKS[idx];
      }
    }
    return Reflect.get(target, prop, receiver);
  },
});
export const ID: Record<string, number> = { air: 0 };
export function block(name: string, ja: string, color: string, pattern: Pattern, hardness = 1, extra: Partial<BlockDef> = {}) {
  if (ID[name] !== undefined) return ID[name];
  const id = RAW_BLOCKS.length;
  RAW_BLOCKS.push({ id, name, ja, color, pattern, hardness, tool: '', solid: true, transparent: false, shape: 'cube', category: 'building', stack: 64, ...extra });
  ID[name] = id; return id;
}

block('grass_block', '草ブロック', '#6f9846', 'grass', .6, { tool: 'shovel', drop: 'dirt', category: 'nature' });
block('dirt', '土', '#8a6244', 'dirt', .5, { tool: 'shovel', category: 'nature' });
block('stone', '石', '#92938a', 'stone', 1.5, { tool: 'pickaxe', tier: 1, drop: 'cobblestone' });
block('sand', '砂', '#dfd29a', 'sand', .5, { tool: 'shovel', category: 'nature' });
block('oak_log', 'オークの原木', '#6b5130', 'bark', 2, { tool: 'axe', category: 'nature' });
block('oak_leaves', 'オークの葉', '#548637', 'leaves', .2, { transparent: true, category: 'nature' });
block('oak_planks', 'オークの板材', '#b8945f', 'planks', 2, { tool: 'axe' });
block('water', '水', '#329caa', 'water', 100, { solid: false, transparent: true, shape: 'water', category: 'nature' });
block('glass', 'ガラス', '#b4dce1', 'glass', .3, { transparent: true, category: 'building' });
block('stone_bricks', '石レンガ', '#8b8e83', 'bricks', 1.5, { tool: 'pickaxe', tier: 1 });
block('bedrock', '岩盤', '#454843', 'stone', Infinity, { tier: 99 });
block('snow_block', '雪ブロック', '#e4edf0', 'snow', .2, { tool: 'shovel', category: 'nature' });
block('gravel', '砂利', '#99918a', 'gravel', .6, { tool: 'shovel', category: 'nature' });
block('coal_ore', '石炭鉱石', '#8b8d84', 'ore', 3, { tool: 'pickaxe', tier: 1, drop: 'coal', category: 'ores' });
block('iron_ore', '鉄鉱石', '#92918a', 'ore', 3, { tool: 'pickaxe', tier: 2, category: 'ores' });
block('gold_ore', '金鉱石', '#92918a', 'ore', 3, { tool: 'pickaxe', tier: 3, category: 'ores' });
block('diamond_ore', 'ダイヤモンド鉱石', '#828b89', 'ore', 3, { tool: 'pickaxe', tier: 3, drop: 'diamond', category: 'ores' });
block('cobblestone', '丸石', '#82877e', 'bricks', 2, { tool: 'pickaxe', tier: 1 });
block('birch_log', 'シラカバの原木', '#e0dccb', 'bark', 2, { tool: 'axe', category: 'nature' });
block('birch_leaves', 'シラカバの葉', '#77a34a', 'leaves', .2, { transparent: true, category: 'nature' });
block('poppy', 'ポピー', '#dc5540', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature' });
block('short_grass', '草', '#70a246', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature', drop: 'wheat_seeds' });
block('crafting_table', '作業台', '#a37b46', 'craft', 2.5, { tool: 'axe', category: 'utility' });
block('furnace', 'かまど', '#777c76', 'furnace', 3.5, { tool: 'pickaxe', tier: 1, category: 'utility' });
block('chest', 'チェスト', '#b88438', 'chest', 2.5, { tool: 'axe', shape: 'chest', transparent: true, category: 'utility' });
block('torch', '松明', '#f4be54', 'torch', 0, { solid: false, transparent: true, shape: 'torch', light: 14, category: 'utility' });
block('lava', '溶岩', '#f88720', 'lava', 100, { solid: false, transparent: true, shape: 'water', light: 15, category: 'nature' });
block('obsidian', '黒曜石', '#171026', 'obsidian', 50, { tool: 'pickaxe', tier: 4 });
block('netherrack', 'ネザーラック', '#85433d', 'stone', .4, { tool: 'pickaxe', tier: 1, category: 'nature' });
block('end_stone', 'エンドストーン', '#d9d59c', 'stone', 3, { tool: 'pickaxe', tier: 1, category: 'nature' });
block('dandelion', 'タンポポ', '#f1ce49', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature' });
block('white_wool', '白い羊毛', '#eaeced', 'wool', .8, { category: 'decorations' });
export const ITEMS: BlockDef[] = [];
export const ITEM_ID: Record<string, number> = {};
export function item(name: string, ja: string, color: string, pattern: Pattern, extra: Partial<BlockDef> = {}) {
  if (ITEM_ID[name] !== undefined) return;
  ITEM_ID[name] = ITEMS.length;
  ITEMS.push({ id: ITEMS.length, name, ja, color, pattern, hardness: 0, tool: '', solid: false, transparent: true, shape: 'cube', category: 'items', stack: 64, ...extra });
}
item('stick', '棒', '#a27d49', 'tool');
item('coal', '石炭', '#3d4140', 'gem', { category: 'materials' });
item('diamond', 'ダイヤモンド', '#55d9cf', 'gem', { category: 'materials' });
item('iron_ingot', '鉄インゴット', '#d4d9d6', 'metal', { category: 'materials' });
item('gold_ingot', '金インゴット', '#efc64d', 'metal', { category: 'materials' });
item('apple', 'リンゴ', '#d84c38', 'food', { food: 4, stack: 64, category: 'food' });
item('bread', 'パン', '#c9954e', 'food', { food: 5, category: 'food' });
item('wheat', '小麦', '#d6b658', 'plant', { category: 'materials' });
item('wheat_seeds', '小麦の種', '#81a64d', 'misc', { category: 'materials' });
item('raw_beef', '生の牛肉', '#bb5a51', 'food', { food: 3, category: 'food' });
item('cooked_beef', 'ステーキ', '#8f5436', 'food', { food: 8, category: 'food' });
item('porkchop', '生の豚肉', '#d89389', 'food', { food: 3, category: 'food' });
item('cooked_porkchop', '焼き豚', '#ba8b57', 'food', { food: 8, category: 'food' });
item('leather', '革', '#a26841', 'misc', { category: 'materials' });
item('feather', '羽根', '#e8e7df', 'tool', { category: 'materials' });
item('bone', '骨', '#dcd9c7', 'tool', { category: 'materials' });
item('rotten_flesh', '腐った肉', '#927148', 'food', { food: 4, category: 'food' });
item('string', '糸', '#e2e1d8', 'misc', { category: 'materials' });
item('gunpowder', '火薬', '#737570', 'misc', { category: 'materials' });
item('bucket', 'バケツ', '#aab6b6', 'misc', { stack: 1, category: 'tools' });
item('water_bucket', '水入りバケツ', '#4ba5c5', 'misc', { stack: 1, category: 'tools' });
export function resolve(name: string) {
  if (name === 'wheat' && ITEM_ID.wheat !== undefined) return { ...ITEMS[ITEM_ID.wheat], block: false };
  return ID[name] !== undefined ? { ...BLOCKS[ID[name]], block: true } : ITEM_ID[name] !== undefined ? { ...ITEMS[ITEM_ID[name]], block: false } : undefined;
}
export const isSolid = (id: number) => !!BLOCKS[id]?.solid;
export const isOpaque = (id: number) => !!id && !BLOCKS[id]?.transparent;

const SHAPE_PARENT_MAP: Record<string, string> = {
  stone_brick: "stone_bricks",
  mossy_stone_brick: "mossy_stone_bricks",
  nether_brick: "nether_bricks",
  red_nether_brick: "red_nether_bricks",
  end_stone_brick: "end_stone_bricks",
  brick: "bricks",
  mud_brick: "mud_bricks",
  deepslate_brick: "deepslate_bricks",
  deepslate_tile: "deepslate_tiles",
  tuff_brick: "tuff_bricks",
  polished_blackstone_brick: "polished_blackstone_bricks",
  prismarine_brick: "prismarine_bricks",
  quartz: "quartz_block",
  purpur: "purpur_block",
  oak: "oak_planks",
  spruce: "spruce_planks",
  birch: "birch_planks",
  jungle: "jungle_planks",
  acacia: "acacia_planks",
  dark_oak: "dark_oak_planks",
  mangrove: "mangrove_planks",
  cherry: "cherry_planks",
  bamboo: "bamboo_planks",
  crimson: "crimson_planks",
  warped: "warped_planks",
};

export function faceTile(b: BlockDef, face: number): string {
  const n = b.name;
  if (n === 'cave_air' || n === 'void_air') return 'air';
  if (n === 'bubble_column') return 'water';
  if (n.startsWith('waxed_')) {
    const unwaxed = n.slice(6);
    const uid = ID[unwaxed];
    if (uid !== undefined && BLOCKS[uid] && BLOCKS[uid] !== b) {
      return faceTile(BLOCKS[uid], face);
    }
  }
  if (n.startsWith('infested_')) {
    const host = n.slice(9);
    const hid = ID[host];
    if (hid !== undefined && BLOCKS[hid] && BLOCKS[hid] !== b) {
      return faceTile(BLOCKS[hid], face);
    }
  }
  if (n === 'cobbled_deepslate_stairs' || n === 'deepslate_stairs') {
    return face === 2 || face === 3 ? 'deepslate_top' : 'deepslate';
  }
  if (n === 'smooth_stone_slab') return face === 2 || face === 3 ? 'smooth_stone' : 'smooth_stone_side';
  if (n === 'petrified_oak_slab') return 'oak_planks';
  if (n === 'light_weighted_pressure_plate') return 'gold_block';
  if (n === 'heavy_weighted_pressure_plate') return 'iron_block';
  if (n === 'stone_pressure_plate' || n === 'stone_button') return 'stone';
  if (n === 'polished_blackstone_pressure_plate' || n === 'polished_blackstone_button') return 'polished_blackstone';
  if (/_(stairs|slab|wall|fence|fence_gate)$/.test(n)) {
    const stem = n.replace(/_(stairs|slab|wall|fence|fence_gate)$/, "");
    const parentName = SHAPE_PARENT_MAP[stem] ?? stem;
    const pid = ID[parentName];
    if (pid !== undefined && BLOCKS[pid] && BLOCKS[pid] !== b) {
      return faceTile(BLOCKS[pid], face);
    }
  }
  if (n === 'crimson_stem') return face === 2 || face === 3 ? 'crimson_log_top' : 'crimson_log';
  if (n === 'warped_stem') return face === 2 || face === 3 ? 'warped_log_top' : 'warped_log';
  if (n === 'crimson_hyphae') return 'crimson_log';
  if (n === 'warped_hyphae') return 'warped_log';
  if (n === 'stripped_crimson_stem') return face === 2 || face === 3 ? 'stripped_crimson_log_top' : 'stripped_crimson_log';
  if (n === 'stripped_warped_stem') return face === 2 || face === 3 ? 'stripped_warped_log_top' : 'stripped_warped_log';
  if (n === 'stripped_crimson_hyphae') return 'stripped_crimson_log';
  if (n === 'stripped_warped_hyphae') return 'stripped_warped_log';
  if (/^stripped_[a-z_]+_wood$/.test(n)) return n.replace(/_wood$/, '_log');
  if (/^[a-z_]+_wood$/.test(n)) return n.replace(/_wood$/, '_log');
  if (n === 'bamboo_block' || n === 'stripped_bamboo_block') return face === 2 || face === 3 ? n + '_top' : n;
  if (/^stripped_[a-z_]+_log$/.test(n)) return face === 2 || face === 3 ? n + '_top' : n;
  if (n === 'wheat') return 'wheat_crop';
  if (n === 'nether_portal') return 'portal';
  if (n === 'snow') return 'snow_layer';
  if (n === 'sculk') return 'sculk_block';
  if (n.endsWith('_wall_sign')) return n.replace('_wall_sign', '_sign');
  if (n.endsWith('_wall_hanging_sign')) return n.replace('_wall_hanging_sign', '_hanging_sign');
  if (n.endsWith('_wall_banner')) return n.replace('_wall_banner', '_banner');
  if (n === 'wall_torch') return 'torch';
  if (n === 'redstone_wall_torch') return 'redstone_torch';
  if (n === 'soul_wall_torch') return 'soul_torch';
  if (n === 'player_wall_head') return 'player_head';
  if (n === 'skeleton_wall_skull') return 'skeleton_skull';
  if (n === 'wither_skeleton_wall_skull') return 'wither_skeleton_skull';
  if (n === 'zombie_wall_head') return 'zombie_head';
  if (n === 'creeper_wall_head') return 'creeper_head';
  if (n === 'piglin_wall_head') return 'piglin_head';
  if (n === 'dragon_wall_head') return face === 2 ? 'dragon_head_top' : face === 4 ? 'dragon_head_front' : 'dragon_head_side';
  if (n.endsWith('_coral_wall_fan')) return n.replace('_coral_wall_fan', '_coral_fan');
  if (n === 'water_cauldron' || n === 'lava_cauldron' || n === 'powder_snow_cauldron') return face === 2 ? n + '_top' : 'cauldron';
  if (n === 'chipped_anvil' || n === 'damaged_anvil') return face === 2 ? n + '_top' : 'anvil';
  if (n === 'cake' || n.endsWith('candle_cake')) return face === 2 ? 'cake_top' : face === 3 ? 'cake_bottom' : 'cake_side';
  if (n === 'flower_pot' || n.startsWith('potted_')) return 'flower_pot';
  if (n === 'jack_o_lantern') return face === 2 || face === 3 ? 'pumpkin_top' : face === 4 ? 'jack_o_lantern' : 'pumpkin';
  if (n === 'ochre_froglight' || n === 'verdant_froglight' || n === 'pearlescent_froglight') return face === 2 || face === 3 ? n + '_top' : n + '_side';
  if (n === 'polished_basalt') return face === 2 || face === 3 ? 'polished_basalt_top' : 'polished_basalt_side';
  if (n === 'chiseled_quartz_block') return face === 2 || face === 3 ? 'chiseled_quartz_block_top' : 'chiseled_quartz_block';
  if (n === 'heavy_core') return face === 2 || face === 3 ? 'heavy_core_top' : 'heavy_core_side';
  if (n === 'sniffer_egg') return face === 2 || face === 3 ? 'sniffer_egg_top' : 'sniffer_egg_side';
  if (n === 'kelp_plant') return 'kelp_stem';
  if (n === 'cave_vines_plant') return 'cave_vines';
  if (n === 'weeping_vines_plant') return 'weeping_vines';
  if (n === 'twisting_vines_plant') return 'twisting_vines';
  if (n === 'attached_melon_stem') return 'melon_stem';
  if (n === 'attached_pumpkin_stem') return 'pumpkin_stem';

  // Directional blocks intentionally use separate atlas tiles on all six faces.
  if (n === "deepslate") return face === 2 || face === 3 ? "deepslate_top" : "deepslate";
  if (n === "blackstone") return face === 2 || face === 3 ? "blackstone_top" : "blackstone";
  if (n === "quartz_pillar") return face === 2 || face === 3 ? "quartz_pillar_top" : "quartz_pillar";
  if (n === "reinforced_deepslate") return face === 2 ? "reinforced_deepslate_top" : face === 3 ? "reinforced_deepslate_bottom" : "reinforced_deepslate_side";
  if (n === "lodestone") return face === 2 || face === 3 ? "lodestone_top" : "lodestone_side";
  if (n === "chiseled_tuff") return face === 2 || face === 3 ? "chiseled_tuff_top" : "chiseled_tuff";
  if (n === "chiseled_tuff_bricks") return face === 2 || face === 3 ? "chiseled_tuff_bricks_top" : "chiseled_tuff_bricks";
  if (n === "stonecutter") return face === 2 ? "stonecutter_top" : face === 3 ? "stonecutter_bottom" : "stonecutter_side";
  if (n === "observer") return face === 2 || face === 3 ? "observer_top" : face === 4 ? "observer_front" : face === 5 ? "observer_back" : "observer_side";
  if (n === 'cactus') return face === 2 ? 'cactus_top' : face === 3 ? 'cactus_bottom' : 'cactus_side';
  if (n === 'basalt') return face === 2 || face === 3 ? 'basalt_top' : 'basalt_side';
  if (n === 'pumpkin' || n === 'carved_pumpkin') return face === 2 || face === 3 ? 'pumpkin_top' : face === 4 ? 'pumpkin_front' : 'pumpkin';
  if (n === 'melon') return face === 2 || face === 3 ? 'melon_top' : 'melon';
  if (n === 'quartz_block') return face === 2 ? 'quartz_block_top' : face === 3 ? 'quartz_block_bottom' : 'quartz_block_side';
  if (n === 'bone_block') return face === 2 || face === 3 ? 'bone_block_top' : 'bone_block_side';
  if (n === 'hay_block') return face === 2 || face === 3 ? 'hay_block_top' : 'hay_block_side';
  if (n === 'bookshelf') return face === 2 || face === 3 ? 'oak_planks' : 'bookshelf';
  if (n === 'chiseled_bookshelf') return face === 2 || face === 3 ? 'chiseled_bookshelf_top' : face === 4 ? 'chiseled_bookshelf_front' : 'chiseled_bookshelf_side';
  if (n === 'lectern') return face === 2 ? 'oak_planks' : face === 3 ? 'oak_planks' : face === 4 ? 'bookshelf' : 'oak_planks';
  if (n === 'loom') return face === 2 ? 'loom_top' : face === 3 ? 'oak_planks' : face === 4 ? 'loom_front' : 'loom_side';
  if (n === 'smithing_table') return face === 2 ? 'smithing_table_top' : face === 3 ? 'crimson_planks' : face === 4 ? 'smithing_table_front' : 'smithing_table_side';
  if (n === 'cartography_table') return face === 2 ? 'cartography_table_top' : face === 3 ? 'dark_oak_planks' : face === 4 ? 'cartography_table_front' : 'cartography_table_side';
  if (n === 'fletching_table') return face === 2 ? 'fletching_table_top' : face === 3 ? 'birch_planks' : face === 4 ? 'fletching_table_front' : 'fletching_table_side';
  if (n === 'beehive') return face === 2 || face === 3 ? 'beehive_top' : face === 4 ? 'beehive_front' : 'beehive';
  if (n === 'bee_nest') return face === 2 || face === 3 ? 'bee_nest_top' : face === 4 ? 'bee_nest_front' : 'bee_nest';
  if (n === 'composter') return face === 2 ? 'composter_top' : face === 3 ? 'composter_bottom' : 'composter';
  if (n === 'scaffolding') return face === 2 ? 'scaffolding_top' : face === 3 ? 'scaffolding_bottom' : 'scaffolding_side';
  if (n === 'campfire' || n === 'soul_campfire' || n === 'unlit_campfire') return face === 2 || face === 3 ? n + '_top' : n;
  if (n === 'daylight_detector' || n === 'inverted_daylight_detector') return face === 2 ? n : face === 3 ? 'dark_oak_planks' : n + '_side';
  if (n === 'jukebox') return face === 2 ? 'jukebox_top' : 'jukebox_side';
  if (n === 'respawn_anchor') return face === 2 ? 'respawn_anchor_top' : face === 3 ? 'crying_obsidian' : 'respawn_anchor_side';
  if (n === 'trial_spawner') return face === 2 ? 'trial_spawner_top' : face === 3 ? 'trial_spawner_bottom' : 'trial_spawner_side';
  if (n === 'vault' || n === 'ominous_vault') return face === 2 ? n + '_top' : face === 3 ? n + '_bottom' : face === 4 ? n + '_front' : n + '_side';
  if (n === 'mushroom_block' || n === 'red_mushroom_block' || n === 'brown_mushroom_block') {
    return face === 2 ? n + '_top' : face === 3 ? n + '_stem' : n + '_side';
  }
  if (n === 'redstone_lamp' || n === 'unlit_redstone_lamp') return face === 2 || face === 3 ? n + '_top' : n + '_side';
  if (n === 'sea_lantern') return face === 2 || face === 3 ? 'sea_lantern_top' : 'sea_lantern_side';
  if (n === 'prismarine') return face === 2 || face === 3 ? 'prismarine_top' : 'prismarine_side';
  if (n === 'target') return face === 2 || face === 3 ? 'target_top' : 'target_side';
  if (n === 'sponge') return face === 2 || face === 3 ? 'sponge_top' : 'sponge_side';
  if (n === 'wet_sponge') return face === 2 || face === 3 ? 'wet_sponge_top' : 'wet_sponge_side';
  if (n === 'dried_kelp_block') return face === 2 ? 'dried_kelp_block_top' : face === 3 ? 'dried_kelp_block_bottom' : 'dried_kelp_block_side';
  if (n === 'chorus_flower') return face === 2 ? 'chorus_flower_top' : 'chorus_flower';
  if (n === 'dragon_head') return face === 2 ? 'dragon_head_top' : face === 4 ? 'dragon_head_front' : 'dragon_head_side';
  if (n === 'amethyst_block') return face === 2 || face === 3 ? 'amethyst_block_top' : 'amethyst_block_side';
  if (n === 'piston' || n === 'sticky_piston') return face === 2 || face === 3 ? n + '_top' : face === 4 ? n + '_front' : n + '_side';
  if (n === 'dispenser' || n === 'dropper' || n === 'observer') return face === 2 || face === 3 ? n + '_top' : face === 4 ? n + '_front' : n + '_side';
  if (n.endsWith('_door')) { const d = n.replace(/^open_/, ''); return face === 2 ? d + '_top' : d + '_bottom'; }
  if (n.endsWith('_button')) return n.replace(/_button$/, '_planks');
  if (n === 'lever') return face === 3 ? 'cobblestone' : 'lever';
  if (n === 'lantern') return face === 2 || face === 3 ? 'lantern_top' : 'lantern';
  if (n === 'soul_lantern') return face === 2 || face === 3 ? 'lantern_top' : 'soul_lantern';
  if (n === 'enchanting_table') return face === 2 ? 'enchanting_table_top' : face === 3 ? 'obsidian' : 'enchanting_table_side';
  if (n === 'farmland' || n === 'farmland_moist') return face === 2 ? 'farmland_top' : 'dirt';
  if (n === 'crafter') return face === 2 ? 'crafter_top' : face === 3 ? 'furnace_bottom' : face === 4 ? 'crafter_front' : 'crafter_side';
  if (n === 'sandstone' || n === 'red_sandstone') return face === 2 ? n + '_top' : face === 3 ? n + '_bottom' : n + '_side';
  if (n === 'sandstone_stairs' || n === 'sandstone_slab' || n === 'sandstone_wall' || n === 'sandstone_fence') return face === 2 ? 'sandstone_top' : face === 3 ? 'sandstone_bottom' : 'sandstone_side';
  if (n === 'red_sandstone_stairs' || n === 'red_sandstone_slab' || n === 'red_sandstone_wall' || n === 'red_sandstone_fence') return face === 2 ? 'red_sandstone_top' : face === 3 ? 'red_sandstone_bottom' : 'red_sandstone_side';
  if (n === 'chiseled_sandstone') return face === 2 || face === 3 ? 'sandstone_top' : n;
  if (n === 'chiseled_red_sandstone') return face === 2 || face === 3 ? 'red_sandstone_top' : n;
  if (n === 'cut_sandstone') return face === 2 || face === 3 ? 'sandstone_top' : n;
  if (n === 'cut_red_sandstone') return face === 2 || face === 3 ? 'red_sandstone_top' : n;
  if (n === 'smooth_sandstone') return 'smooth_sandstone';
  if (n === 'smooth_red_sandstone') return 'smooth_red_sandstone';
  if (n === 'purpur_pillar' || n === 'bone_block' || n === 'hay_block') return face === 2 || face === 3 ? n + '_top' : n;
  if (n.startsWith('end_stone_brick')) return 'end_stone_bricks';
  if (n.startsWith('purpur_') && !n.startsWith('purpur_pillar')) return 'purpur_block';
  if (n === 'ancient_debris') return face === 2 || face === 3 ? 'ancient_debris_top' : 'ancient_debris_side';
  if (n === 'crimson_nylium' || n === 'warped_nylium') return face === 2 ? n : face === 3 ? 'netherrack' : n + '_side';
  if (n === 'end_portal_frame') return face === 2 ? 'end_portal_frame_top' : face === 3 ? 'end_stone' : 'end_portal_frame_side';
  if (n === 'shulker_box') return face === 2 ? 'shulker_box_top' : face === 3 ? 'shulker_box_bottom' : 'shulker_box_side';
  if (n === 'bed' || n === 'red_bed') return face === 2 ? 'bed_head_top' : face === 3 ? 'bed_foot_top' : face === 1 ? 'bed_head_side' : 'bed_side';
  if (n === 'chest') return face === 2 ? 'chest_top' : face === 3 ? 'chest_bottom' : face === 4 ? 'chest_front' : 'chest_side';
  if (n === 'trapped_chest') return face === 2 ? 'chest_top' : face === 3 ? 'chest_bottom' : face === 4 ? 'trapped_chest_front' : 'chest_side';
  if (n === 'ender_chest') return face === 2 ? 'ender_chest_top' : face === 3 ? 'ender_chest_bottom' : face === 4 ? 'ender_chest_front' : 'ender_chest_side';
  if (n === 'barrel') return face === 2 ? 'barrel_top' : face === 3 ? 'barrel_bottom' : face === 4 ? 'barrel_front' : 'barrel_side';
  if (n === 'tnt') return face === 2 ? 'tnt_top' : face === 3 ? 'tnt_bottom' : 'tnt_side';
  if (n === 'crafting_table') return face === 2 ? 'crafting_table_top' : face === 3 ? 'oak_planks' : face === 4 ? 'crafting_table_front' : 'crafting_table_side';
  if (b.pattern === 'furnace') {
    const key = n.startsWith('blast_furnace') ? 'blast_furnace' : n.startsWith('smoker') ? 'smoker' : n.startsWith('observer') ? 'observer' : n.startsWith('dropper') ? 'dropper' : n.startsWith('dispenser') ? 'dispenser' : 'furnace';
    return face === 2 ? key + '_top' : face === 3 ? key + '_bottom' : face === 4 ? key + '_front' : key + '_side';
  }
  if (n === 'moss_block') return 'moss_block';
  if (n === 'muddy_mangrove_roots') return (face === 2 || face === 3) ? 'muddy_mangrove_roots_top' : 'muddy_mangrove_roots_side';
  if (n === 'mangrove_roots') return (face === 2 || face === 3) ? 'mangrove_roots_top' : 'mangrove_roots_side';
  if (n === 'mushroom_stem') return (face === 2 || face === 3) ? 'mushroom_stem_top' : 'mushroom_stem';
  if (b.pattern === 'grass') return face === 2 ? n : face === 3 ? 'dirt' : (n === 'grass_block' ? 'grass_side' : n + '_side');
  if (b.pattern === 'bark') return (face === 2 || face === 3) ? n + '_top' : n;
  return n;
}
export const ATLAS_COLS = 16;
export const TILE = 20;
