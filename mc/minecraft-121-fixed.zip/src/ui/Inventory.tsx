import { useState } from 'react';
import { Search, Package, ArrowRight, Hammer, X, BookOpen, Check, Layers, Shield } from 'lucide-react';
import { BLOCKS, ITEMS, resolve } from '../game/data';
import { RECIPES, canCraft, recipeCounts } from '../systems/crafting';
import type { Engine } from '../game/engine';
import type { GameSnapshot } from '../game/types';
import { Button, ItemIcon, Panel, Slot } from './common';

export function Inventory({
  engine,
  snapshot,
  onClose,
  workbench = false,
}: {
  engine: Engine;
  snapshot: GameSnapshot;
  onClose: () => void;
  workbench?: boolean;
}) {
  const ja = engine.settings.language === 'ja';
  const t = (j: string, e: string) => (ja ? j : e);
  const creative = engine.meta.mode === 'creative';
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState('all');
  const [picked, setPicked] = useState<number | null>(null);
  const [hover, setHover] = useState('oak_planks');
  const [recipeId, setRecipeId] = useState('oak_planks');
  const [mode, setMode] = useState<'items' | 'recipes'>('items');
  const [craftableOnly, setCraftableOnly] = useState(false);

  const all = [...snapshot.hotbar, ...snapshot.inventory, ...snapshot.armorSlots, snapshot.offhand];
  const def = resolve(hover);
  const counts = recipeCounts(all.slice(0, 36));
  const recipe = RECIPES.find(r => r.id === recipeId) ?? RECIPES[0];
  const craftable = canCraft(recipe, counts, creative, workbench);

  const catalog = [
    ...BLOCKS.filter(b => b.id && b.name !== 'bedrock' && !b.name.startsWith('open_') && b.name !== 'unlit_redstone_lamp'),
    ...ITEMS,
  ].filter(b => b.category !== 'hidden' && (tab === 'all' || b.category === tab) && (`${b.name} ${b.ja}`).toLowerCase().includes(search.toLowerCase()));

  const filteredRecipes = RECIPES.filter(r => {
    const okSearch = (r.result + (resolve(r.result)?.ja ?? '')).toLowerCase().includes(search.toLowerCase());
    if (!okSearch) return false;
    return !craftableOnly || canCraft(r, counts, creative, workbench);
  });

  const pick = (i: number) => {
    if (picked === null) {
      setPicked(i);
      if (all[i]) setHover(all[i]!.name);
    } else {
      engine.swapSlots(picked, i);
      setPicked(null);
    }
  };

  return (
    <Panel
      title={workbench ? t('作業台', 'Crafting table') : creative ? t('クリエイティブ インベントリ', 'Creative inventory') : t('インベントリ', 'Inventory')}
      eyebrow={workbench ? 'CRAFTING · 3 × 3' : creative ? 'CREATIVE' : 'SURVIVAL'}
      onBack={onClose}
      wide
    >
      <div className="inventory-layout">
        <div className="inventory-main">
          <div className="inventory-player">
            <div className="steve">
              <i className="steve-head" />
              <i className="steve-body" />
              <i className="steve-arm left" />
              <i className="steve-arm right" />
              <i className="steve-leg left" />
              <i className="steve-leg right" />
            </div>
            <div>
              <span className="eyebrow">PLAYER</span>
              <h3>Steve</h3>
              <div style={{ display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'wrap' }}>
                <span className="status-chip">{engine.meta.mode.toUpperCase()} · {t('防御', 'ARMOR')} {snapshot.armor}</span>
                {(snapshot.elytraEquipped || all.some(s => s?.name === 'elytra')) && (
                  <button
                    className="status-chip"
                    style={{ cursor: 'pointer', background: snapshot.elytraEquipped ? '#8f5d9160' : '#15221b' }}
                    onClick={() => engine.toggleElytra()}
                  >
                    {snapshot.elytraEquipped ? t('エリトラ装備中 ✓', 'Elytra ON ✓') : t('エリトラを装備', 'Equip Elytra')}
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="equip-row">

            <div className="section-label"><Shield size={15} />{t('装備', 'Equipment')}<span>{t('防御', 'Armor')} {snapshot.armor} / 20</span></div>

            <div className="equip-slots">

              {[t('頭', 'Head'), t('胴', 'Chest'), t('脚', 'Legs'), t('足', 'Feet')].map((label, i) => (<div key={i}><Slot stack={snapshot.armorSlots[i] ?? null} selected={picked === 36 + i} onClick={() => pick(36 + i)} label={label} /><small>{label}</small></div>))}

              <div className="offhand"><Slot stack={snapshot.offhand} selected={picked === 40} onClick={() => pick(40)} label={t('オフハンド', 'Off-hand')} /><small>{t('オフハンド (F)', 'Off-hand (F)')}</small></div>

            </div>

          </div>

          <div className="section-label">

            <Package size={15} />

            {t('持ちもの', 'Inventory')}
            <span>{all.slice(0, 36).filter(Boolean).length} / 36</span>
          </div>
          <div className="inventory-grid">
            {snapshot.inventory.map((s, i) => (
              <Slot
                key={i + 9}
                stack={s}
                selected={picked === i + 9}
                onClick={() => pick(i + 9)}
                onDoubleClick={() => { if (s) { engine.swapSlots(i + 9, engine.selected); onClose(); } }}
              />
            ))}
          </div>

          <div className="section-label hotbar-label">
            {t('ホットバー', 'Hotbar')}
            <span>1 – 9</span>
          </div>
          <div className="inventory-grid hotbar-grid">
            {snapshot.hotbar.map((s, i) => (
              <Slot key={i} index={i} stack={s} selected={picked === i} onClick={() => pick(i)} />
            ))}
          </div>

          <p className="inventory-help">
            {picked !== null
              ? t('移動先のスロットを選択してください。', 'Select a destination slot.')
              : t('アイテムを選択 → 移動先を選択（装備・オフハンド枠も同じ操作）。防具は手に持って右クリックでも装備できます。', 'Select an item, then its destination. Double-click to equip.')}
          </p>

          <div className="recipe-book">
            <div className="section-label">
              <BookOpen size={15} />
              {t('レシピブック', 'Recipe book')}
              <span>{workbench ? '3 × 3' : '2 × 2'}</span>
            </div>
            <div className="recipe-select">
              <select value={recipeId} onChange={e => setRecipeId(e.target.value)}>
                {RECIPES.map(r => (
                  <option key={r.id} value={r.id}>
                    {resolve(r.result)?.ja ?? r.result} ×{r.count}
                  </option>
                ))}
              </select>
            </div>
            <div className="recipe-detail">
              <div className={`craft-grid ${workbench ? 'three' : ''}`}>
                {Array.from({ length: workbench ? 9 : 4 }, (_, i) => {
                  const row = recipe.grid[Math.floor(i / (workbench ? 3 : 2))];
                  const cell = row?.[i % (workbench ? 3 : 2)];
                  return <div key={i}>{cell && <ItemIcon name={cell} size={25} />}</div>;
                })}
              </div>
              <ArrowRight size={22} />
              <div className="craft-result">
                <ItemIcon name={recipe.result} size={40} />
                <span>×{recipe.count}</span>
              </div>
              <div className="recipe-ingredients">
                {Object.entries(recipe.ingredients).map(([n, c]) => (
                  <span key={n} className={(counts[n] || 0) >= c || creative ? 'have' : ''}>
                    {resolve(n)?.ja ?? n} <b>{creative ? '∞' : counts[n] || 0}/{c}</b>
                  </span>
                ))}
              </div>
            </div>
            <div className="craft-actions">
              <Button
                primary
                disabled={!craftable}
                onClick={() => { if (engine.craftRecipe(recipe.id, workbench, false)) setPicked(null); }}
              >
                <Hammer size={15} />
                {craftable ? t('クラフトする', 'Craft') : workbench ? t('材料が足りません', 'Missing materials') : t('作業台が必要です', 'Requires crafting table')}
              </Button>
              {!creative && (
                <Button
                  disabled={!craftable}
                  onClick={() => { if (engine.craftRecipe(recipe.id, workbench, true)) setPicked(null); }}
                  title={t('作れるだけすべてクラフト', 'Craft maximum stack')}
                >
                  <Layers size={15} />
                  {t('すべて', 'Max')}
                </Button>
              )}
            </div>
          </div>
        </div>

        <aside className="catalog">
          <div className="catalog-mode">
            <button className={mode === 'items' ? 'active' : ''} onClick={() => setMode('items')}>
              <Package size={14} />{t('図鑑', 'Items')}
            </button>
            <button className={mode === 'recipes' ? 'active' : ''} onClick={() => setMode('recipes')}>
              <BookOpen size={14} />{t('レシピ', 'Recipes')}
            </button>
          </div>
          {mode === 'items' ? (
            <>
              <div className="catalog-search">
                <Search size={16} />
                <input placeholder={t('アイテムを検索', 'Search items')} value={search} onChange={e => setSearch(e.target.value)} />
                {search && <button onClick={() => setSearch('')} aria-label="検索をクリア"><X size={14} /></button>}
              </div>
              <div className="catalog-tabs">
                {[['all', t('すべて', 'All')], ['building', t('建築', 'Build')], ['nature', t('自然', 'Nature')], ['tools', t('道具', 'Tools')], ['food', t('食料', 'Food')], ['redstone', t('回路', 'Redstone')]].map(([id, label]) => (
                  <button key={id} className={tab === id ? 'active' : ''} onClick={() => setTab(id)}>{label}</button>
                ))}
              </div>
              <div className="catalog-grid">
                {catalog.map(b => (
                  <button
                    key={b.name}
                    title={ja ? b.ja : b.name}
                    onMouseEnter={() => setHover(b.name)}
                    onClick={() => {
                      setHover(b.name);
                      if (creative) {
                        engine.hotbar[engine.selected] = { name: b.name, count: 64 };
                        setPicked(null);
                      } else if (engine.countItem(b.name) > 0) {
                        const slot = engine.hotbar.findIndex(s => s?.name === b.name);
                        if (slot >= 0) engine.select(slot);
                      }
                    }}
                  >
                    <ItemIcon name={b.name} />
                  </button>
                ))}
              </div>
            </>
          ) : (
            <>
              <div className="catalog-search">
                <Search size={16} />
                <input placeholder={t('レシピを検索', 'Search recipes')} value={search} onChange={e => setSearch(e.target.value)} />
                <button
                  className={`craftable-toggle ${craftableOnly ? 'active' : ''}`}
                  onClick={() => setCraftableOnly(v => !v)}
                  title={t('作成可能のみ表示', 'Craftable only')}
                >
                  <Check size={13} />
                </button>
              </div>
              <div className="recipe-list">
                {filteredRecipes.map(r => (
                  <button
                    key={r.id}
                    className={recipeId === r.id ? 'active' : ''}
                    onClick={() => { setRecipeId(r.id); setHover(r.result); }}
                  >
                    <ItemIcon name={r.result} size={26} />
                    <span>{resolve(r.result)?.ja ?? r.result}</span>
                    {canCraft(r, counts, creative, workbench) && <Check size={13} />}
                  </button>
                ))}
              </div>
            </>
          )}
          <div className="item-detail">
            <ItemIcon name={hover} size={40} />
            <div>
              <strong>{ja ? def?.ja : def?.name}</strong>
              <small>
                {def?.name}
                {def?.damage ? ` · ⚔${def.damage}` : ''}
                {def?.food ? ` · 🍖+${def.food}` : ''}
                {def?.light ? ` · 💡${def.light}` : ''}
              </small>
            </div>
            {creative && <ArrowRight size={17} />}
          </div>
          <p className="catalog-note">
            {creative ? t('クリックで選択中のスロットに追加', 'Click to add to your selected slot') : t('所持しているアイテムを検索できます', 'Browse items and check recipes')}
          </p>
        </aside>
      </div>
    </Panel>
  );
}
