// Woodland Mansion generator – Java Edition 1.21 WoodlandMansionPieces parity (Minecraft Wiki "Woodland Mansion#Structure").
// Implements:
//  1. Vanilla MansionGrid (SimpleGrid baseGrid, thirdFloorGrid, floorRooms[0..2], recursiveCorridor, setupThirdFloor,
//     identifyRooms, 1x1 / 1x2 / 2x2 room partitioning and secret room placement).
//  2. Vanilla RoomCollection hierarchy (FirstFloorRoomCollection, SecondFloorRoomCollection, ThirdFloorRoomCollection)
//     covering all 52 official room templates:
//     - 1x1: 1x1_a1..a5, 1x1_as1..as4, 1x1_b1..b5
//     - 1x2: 1x2_a1..a9, 1x2_b1..b5, 1x2_c1..c4, 1x2_c_stairs, 1x2_d1..d5, 1x2_d_stairs, 1x2_s1..s2, 1x2_se1
//     - 2x2: 2x2_a1..a4, 2x2_b1..b5, 2x2_s1
//  3. Technical structures: entrance (foyer with giant staircase), corridor_floor, carpet_north/east/south_1/south_2/west_1/west_2,
//     indoors_wall_1/2, indoors_door_1/2, wall_flat, wall_window, wall_corner, small_wall, small_wall_corner,
//     roof, roof_front, roof_corner, roof_inner_corner, and cobblestone foundation to terrain.
import { type Put, type StructHost, DX, DZ, bid, cell, fill, hash2, mulberry, stairsUp, ladderOn, attachOn, doorOn, tag, PANE_X, PANE_Z } from './common';
import { mansion } from './variants';
import { chest, barrel, itemFrame, lectern, lantern, pottedPlant, carpet } from './decor';

interface Site { x: number; y: number; z: number }

export const MANSION_TEMPLATES_1X1_1F = ['1x1_a1', '1x1_a2', '1x1_a3', '1x1_a4', '1x1_a5'] as const;
export const MANSION_TEMPLATES_1X1_AS = ['1x1_as1', '1x1_as2', '1x1_as3', '1x1_as4'] as const;
export const MANSION_TEMPLATES_1X1_2F = ['1x1_b1', '1x1_b2', '1x1_b3', '1x1_b4', '1x1_b5'] as const;
export const MANSION_TEMPLATES_1X2_1F = ['1x2_a1', '1x2_a2', '1x2_a3', '1x2_a4', '1x2_a5', '1x2_a6', '1x2_a7', '1x2_a8', '1x2_a9', '1x2_b1', '1x2_b2', '1x2_b3', '1x2_b4', '1x2_b5'] as const;
export const MANSION_TEMPLATES_1X2_S_1F = ['1x2_s1', '1x2_s2'] as const;
export const MANSION_TEMPLATES_1X2_2F = ['1x2_c1', '1x2_c2', '1x2_c3', '1x2_c4', '1x2_d1', '1x2_d2', '1x2_d3', '1x2_d4', '1x2_d5'] as const;
export const MANSION_TEMPLATES_1X2_STAIRS = ['1x2_c_stairs', '1x2_d_stairs'] as const;
export const MANSION_TEMPLATES_1X2_SE = ['1x2_se1'] as const;
export const MANSION_TEMPLATES_2X2_1F = ['2x2_a1', '2x2_a2', '2x2_a3', '2x2_a4'] as const;
export const MANSION_TEMPLATES_2X2_2F = ['2x2_b1', '2x2_b2', '2x2_b3', '2x2_b4', '2x2_b5'] as const;
export const MANSION_TEMPLATES_2X2_S = ['2x2_s1'] as const;

export const ALL_MANSION_TEMPLATES = [
  ...MANSION_TEMPLATES_1X1_1F,
  ...MANSION_TEMPLATES_1X1_AS,
  ...MANSION_TEMPLATES_1X1_2F,
  ...MANSION_TEMPLATES_1X2_1F,
  ...MANSION_TEMPLATES_1X2_S_1F,
  ...MANSION_TEMPLATES_1X2_2F,
  ...MANSION_TEMPLATES_1X2_STAIRS,
  ...MANSION_TEMPLATES_1X2_SE,
  ...MANSION_TEMPLATES_2X2_1F,
  ...MANSION_TEMPLATES_2X2_2F,
  ...MANSION_TEMPLATES_2X2_S,
] as const;

export type MansionTemplate = typeof ALL_MANSION_TEMPLATES[number];

export const TECHNICAL_MANSION_TEMPLATES = [
  "carpet_east", "carpet_north", "carpet_south_1", "carpet_south_2", "carpet_west_1", "carpet_west_2",
  "corridor_floor", "entrance", "indoors_door_1", "indoors_door_2", "indoors_wall_1", "indoors_wall_2",
  "roof", "roof_corner", "roof_front", "roof_inner_corner", "small_wall", "small_wall_corner",
  "wall_corner", "wall_flat", "wall_window",
] as const;
export type TechnicalMansionTemplate = typeof TECHNICAL_MANSION_TEMPLATES[number];

// ======================================================================================================================
// Vanilla WoodlandMansionPieces.SimpleGrid & MansionGrid
// ======================================================================================================================
export const GRID_CLEAR = 0;
export const GRID_CORRIDOR = 1;
export const GRID_ROOM = 2;
export const GRID_OUT_OF_BOUNDS = 3;
export const GRID_ENTRANCE = 4;
export const GRID_SPECIAL = 5;

export const ROOM_SIZE_MASK = 0xFFFF;
export const ROOM_SIZE_1X1 = 0x10000;
export const ROOM_SIZE_1X2 = 0x20000;
export const ROOM_SIZE_2X2 = 0x40000;
export const ROOM_ORIGIN_FLAG = 0x100000;
export const ROOM_DOOR_FLAG = 0x200000;
export const ROOM_STAIRS_FLAG = 0x400000;
export const ROOM_CORRIDOR_FLAG = 0x800000;

export class SimpleGrid {
  readonly width: number;
  readonly height: number;
  readonly defaultValue: number;
  readonly data: Int32Array;

  constructor(width: number, height: number, defaultValue = 0) {
    this.width = width;
    this.height = height;
    this.defaultValue = defaultValue;
    this.data = new Int32Array(width * height).fill(defaultValue);
  }

  get(x: number, y: number): number {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return this.defaultValue;
    return this.data[y * this.width + x];
  }

  set(x: number, y: number, value: number) {
    if (x >= 0 && x < this.width && y >= 0 && y < this.height) {
      this.data[y * this.width + x] = value;
    }
  }

  setRange(x0: number, y0: number, x1: number, y1: number, value: number) {
    if (x0 > x1) [x0, x1] = [x1, x0];
    if (y0 > y1) [y0, y1] = [y1, y0];
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        this.set(x, y, value);
      }
    }
  }

  setIf(x: number, y: number, expected: number, value: number) {
    if (this.get(x, y) === expected) this.set(x, y, value);
  }

  edgesTo(x: number, y: number, target: number): boolean {
    return (
      this.get(x - 1, y) === target ||
      this.get(x + 1, y) === target ||
      this.get(x, y - 1) === target ||
      this.get(x, y + 1) === target
    );
  }
}

export class MansionGrid {
  static readonly DEFAULT_SIZE = 11;
  readonly baseGrid: SimpleGrid;
  readonly thirdFloorGrid: SimpleGrid;
  readonly floorRooms: [SimpleGrid, SimpleGrid, SimpleGrid];
  readonly entranceX: number;
  readonly entranceY: number;
  private readonly rnd: () => number;

  constructor(rnd: () => number) {
    this.rnd = rnd;
    const W = MansionGrid.DEFAULT_SIZE, H = MansionGrid.DEFAULT_SIZE;
    this.entranceX = 7;
    this.entranceY = 4;
    this.baseGrid = new SimpleGrid(W, H, GRID_OUT_OF_BOUNDS);
    this.baseGrid.setRange(this.entranceX, this.entranceY, this.entranceX + 1, this.entranceY + 1, GRID_OUT_OF_BOUNDS);
    this.baseGrid.setRange(this.entranceX - 1, this.entranceY, this.entranceX - 1, this.entranceY + 1, GRID_ROOM);
    this.baseGrid.setRange(this.entranceX + 2, this.entranceY - 2, this.entranceX + 3, this.entranceY + 3, GRID_ROOM);
    this.baseGrid.setRange(this.entranceX + 1, this.entranceY - 2, this.entranceX + 1, this.entranceY - 1, GRID_CORRIDOR);
    this.baseGrid.setRange(this.entranceX + 1, this.entranceY + 2, this.entranceX + 1, this.entranceY + 3, GRID_CORRIDOR);
    this.baseGrid.set(this.entranceX - 1, this.entranceY - 1, GRID_CORRIDOR);
    this.baseGrid.set(this.entranceX - 1, this.entranceY + 2, GRID_CORRIDOR);
    this.baseGrid.setRange(0, 0, 11, 1, GRID_OUT_OF_BOUNDS);
    this.baseGrid.setRange(0, 9, 11, 11, GRID_OUT_OF_BOUNDS);

    this.recursiveCorridor(this.baseGrid, this.entranceX, this.entranceY - 2, 3, 6);
    this.recursiveCorridor(this.baseGrid, this.entranceX, this.entranceY + 3, 3, 6);
    this.recursiveCorridor(this.baseGrid, this.entranceX - 2, this.entranceY - 1, 3, 3);
    this.recursiveCorridor(this.baseGrid, this.entranceX - 2, this.entranceY + 2, 3, 3);

    while (this.cleanEdges(this.baseGrid)) { /* clean isolated corridor stubs */ }

    this.floorRooms = [
      new SimpleGrid(W, H, 0),
      new SimpleGrid(W, H, 0),
      new SimpleGrid(W, H, 0),
    ];
    this.identifyRooms(this.baseGrid, this.floorRooms[0]);
    this.identifyRooms(this.baseGrid, this.floorRooms[1]);
    this.floorRooms[0].setRange(this.entranceX + 1, this.entranceY, this.entranceX + 1, this.entranceY + 1, ROOM_CORRIDOR_FLAG);
    this.floorRooms[1].setRange(this.entranceX + 1, this.entranceY, this.entranceX + 1, this.entranceY + 1, ROOM_CORRIDOR_FLAG);

    this.thirdFloorGrid = new SimpleGrid(W, H, GRID_OUT_OF_BOUNDS);
    this.setupThirdFloor();
    this.identifyRooms(this.thirdFloorGrid, this.floorRooms[2]);
  }

  private nextInt(bound: number) { return Math.floor(this.rnd() * bound); }
  private nextBoolean() { return this.rnd() < 0.5; }
  private shuffle<T>(arr: T[]): T[] {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = this.nextInt(i + 1);
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  static isHouse(grid: SimpleGrid, x: number, y: number): boolean {
    const v = grid.get(x, y);
    return v === GRID_CORRIDOR || v === GRID_ROOM || v === GRID_ENTRANCE || v === GRID_SPECIAL;
  }

  private recursiveCorridor(grid: SimpleGrid, x: number, y: number, dir: number, depth: number) {
    if (depth <= 0) return;
    grid.set(x, y, GRID_CORRIDOR);
    grid.setIf(x + DX[dir], y + DZ[dir], GRID_OUT_OF_BOUNDS, GRID_CORRIDOR);
    for (let tries = 0; tries < 8; tries++) {
      const nextDir = this.nextInt(4);
      if (nextDir === ((dir + 2) & 3)) continue;
      if (nextDir === 1 && this.nextBoolean()) continue;
      const nx = x + DX[dir], ny = y + DZ[dir];
      if (grid.get(nx + DX[nextDir], ny + DZ[nextDir]) === 0 && grid.get(nx + DX[nextDir] * 2, ny + DZ[nextDir] * 2) === 0) {
        this.recursiveCorridor(grid, nx + DX[nextDir], ny + DZ[nextDir], nextDir, depth - 1);
        break;
      }
    }
    const left = (dir + 3) & 3, right = (dir + 1) & 3;
    if (this.nextBoolean()) grid.setIf(x + DX[left], y + DZ[left], GRID_OUT_OF_BOUNDS, GRID_ROOM);
    if (this.nextBoolean()) grid.setIf(x + DX[right], y + DZ[right], GRID_OUT_OF_BOUNDS, GRID_ROOM);
    if (this.nextBoolean()) grid.setIf(x + DX[dir] + DX[left], y + DZ[dir] + DZ[left], GRID_OUT_OF_BOUNDS, GRID_ROOM);
    if (this.nextBoolean()) grid.setIf(x + DX[dir] + DX[right], y + DZ[dir] + DZ[right], GRID_OUT_OF_BOUNDS, GRID_ROOM);
  }

  private cleanEdges(grid: SimpleGrid): boolean {
    let changed = false;
    for (let y = 1; y < grid.height - 1; y++) {
      for (let x = 1; x < grid.width - 1; x++) {
        if (grid.get(x, y) === GRID_OUT_OF_BOUNDS) {
          let adj = 0;
          if (MansionGrid.isHouse(grid, x + 1, y)) adj++;
          if (MansionGrid.isHouse(grid, x - 1, y)) adj++;
          if (MansionGrid.isHouse(grid, x, y + 1)) adj++;
          if (MansionGrid.isHouse(grid, x, y - 1)) adj++;
          if (adj >= 3) {
            grid.set(x, y, GRID_ROOM);
            changed = true;
          }
        }
      }
    }
    return changed;
  }

  private setupThirdFloor() {
    const stairRooms: [number, number][] = [];
    const f1 = this.floorRooms[1];
    for (let y = 0; y < this.thirdFloorGrid.height; y++) {
      for (let x = 0; x < this.thirdFloorGrid.width; x++) {
        const r = f1.get(x, y);
        const sz = r & 0xF0000;
        if (sz === ROOM_SIZE_1X2 && (r & ROOM_ORIGIN_FLAG) !== 0) {
          stairRooms.push([x, y]);
        }
      }
    }
    if (stairRooms.length === 0) {
      this.thirdFloorGrid.setRange(0, 0, this.thirdFloorGrid.width, this.thirdFloorGrid.height, GRID_OUT_OF_BOUNDS);
      return;
    }
    const [sx, sy] = stairRooms[this.nextInt(stairRooms.length)];
    const roomId = f1.get(sx, sy) & ROOM_SIZE_MASK;
    for (let y = 0; y < this.thirdFloorGrid.height; y++) {
      for (let x = 0; x < this.thirdFloorGrid.width; x++) {
        if ((f1.get(x, y) & ROOM_SIZE_MASK) === roomId) {
          this.thirdFloorGrid.set(x, y, GRID_ROOM);
          f1.set(x, y, f1.get(x, y) | ROOM_STAIRS_FLAG);
        }
      }
    }
    for (let y = 0; y < this.thirdFloorGrid.height; y++) {
      for (let x = 0; x < this.thirdFloorGrid.width; x++) {
        if (this.thirdFloorGrid.get(x, y) === GRID_ROOM) {
          for (const d of [0, 1, 2, 3]) {
            const nx = x + DX[d], ny = y + DZ[d];
            if (this.thirdFloorGrid.get(nx, ny) === GRID_OUT_OF_BOUNDS && this.baseGrid.get(nx, ny) === GRID_CORRIDOR) {
              this.thirdFloorGrid.set(nx, ny, GRID_CORRIDOR);
              for (let step = 1; step <= 3; step++) {
                const cx = nx + DX[d] * step, cy = ny + DZ[d] * step;
                if (this.baseGrid.get(cx, cy) === GRID_CORRIDOR) {
                  this.thirdFloorGrid.set(cx, cy, GRID_CORRIDOR);
                }
              }
            }
          }
        }
      }
    }
    for (let y = 1; y < this.thirdFloorGrid.height - 1; y++) {
      for (let x = 1; x < this.thirdFloorGrid.width - 1; x++) {
        if (this.thirdFloorGrid.get(x, y) === GRID_CORRIDOR) {
          for (const d of [0, 1, 2, 3]) {
            const nx = x + DX[d], ny = y + DZ[d];
            if (this.thirdFloorGrid.get(nx, ny) === GRID_OUT_OF_BOUNDS && MansionGrid.isHouse(this.baseGrid, nx, ny) && this.nextBoolean()) {
              this.thirdFloorGrid.set(nx, ny, GRID_ROOM);
            }
          }
        }
      }
    }
  }

  private identifyRooms(sourceGrid: SimpleGrid, roomGrid: SimpleGrid) {
    const roomCells: [number, number][] = [];
    for (let y = 0; y < sourceGrid.height; y++) {
      for (let x = 0; x < sourceGrid.width; x++) {
        if (sourceGrid.get(x, y) === GRID_ROOM) {
          roomCells.push([x, y]);
        }
      }
    }
    this.shuffle(roomCells);
    let nextId = 10;
    for (const [x, y] of roomCells) {
      if (roomGrid.get(x, y) !== 0) continue;
      let x0 = x, x1 = x, y0 = y, y1 = y;
      let flag = ROOM_SIZE_1X1;
      if (roomGrid.get(x + 1, y) === 0 && roomGrid.get(x, y + 1) === 0 && roomGrid.get(x + 1, y + 1) === 0 &&
          sourceGrid.get(x + 1, y) === GRID_ROOM && sourceGrid.get(x, y + 1) === GRID_ROOM && sourceGrid.get(x + 1, y + 1) === GRID_ROOM) {
        x1++;
        y1++;
        flag = ROOM_SIZE_2X2;
      } else if (roomGrid.get(x - 1, y) === 0 && roomGrid.get(x, y + 1) === 0 && roomGrid.get(x - 1, y + 1) === 0 &&
                 sourceGrid.get(x - 1, y) === GRID_ROOM && sourceGrid.get(x, y + 1) === GRID_ROOM && sourceGrid.get(x - 1, y + 1) === GRID_ROOM) {
        x0--;
        y1++;
        flag = ROOM_SIZE_2X2;
      } else if (roomGrid.get(x - 1, y) === 0 && roomGrid.get(x, y - 1) === 0 && roomGrid.get(x - 1, y - 1) === 0 &&
                 sourceGrid.get(x - 1, y) === GRID_ROOM && sourceGrid.get(x, y - 1) === GRID_ROOM && sourceGrid.get(x - 1, y - 1) === GRID_ROOM) {
        x0--;
        y0--;
        flag = ROOM_SIZE_2X2;
      } else if (roomGrid.get(x + 1, y) === 0 && sourceGrid.get(x + 1, y) === GRID_ROOM) {
        x1++;
        flag = ROOM_SIZE_1X2;
      } else if (roomGrid.get(x, y + 1) === 0 && sourceGrid.get(x, y + 1) === GRID_ROOM) {
        y1++;
        flag = ROOM_SIZE_1X2;
      } else if (roomGrid.get(x - 1, y) === 0 && sourceGrid.get(x - 1, y) === GRID_ROOM) {
        x0--;
        flag = ROOM_SIZE_1X2;
      } else if (roomGrid.get(x, y - 1) === 0 && sourceGrid.get(x, y - 1) === GRID_ROOM) {
        y0--;
        flag = ROOM_SIZE_1X2;
      }

      const originX = Math.min(x0, x1);
      const originY = Math.min(y0, y1);
      const id = nextId++;
      for (let ry = y0; ry <= y1; ry++) {
        for (let rx = x0; rx <= x1; rx++) {
          roomGrid.set(rx, ry, id | flag);
        }
      }
      roomGrid.set(originX, originY, roomGrid.get(originX, originY) | ROOM_ORIGIN_FLAG);
    }

    // Mark doors connecting each room to an adjacent corridor (unless it becomes a secret room).
    for (let floorPass = 0; floorPass < 1; floorPass++) {
      const seenIds = new Set<number>();
      for (let y = 0; y < roomGrid.height; y++) {
        for (let x = 0; x < roomGrid.width; x++) {
          const val = roomGrid.get(x, y);
          const id = val & ROOM_SIZE_MASK;
          if (id === 0 || seenIds.has(id)) continue;
          seenIds.add(id);
          const candidates: [number, number][] = [];
          for (let cy = 0; cy < roomGrid.height; cy++) {
            for (let cx = 0; cx < roomGrid.width; cx++) {
              if ((roomGrid.get(cx, cy) & ROOM_SIZE_MASK) === id && sourceGrid.edgesTo(cx, cy, GRID_CORRIDOR)) {
                candidates.push([cx, cy]);
              }
            }
          }
          if (candidates.length > 0 && this.rnd() >= 0.12) {
            const [dx, dy] = candidates[this.nextInt(candidates.length)];
            roomGrid.set(dx, dy, roomGrid.get(dx, dy) | ROOM_DOOR_FLAG);
          }
        }
      }
    }
  }
}

// ======================================================================================================================
// Vanilla RoomCollection (FirstFloorRoomCollection, SecondFloorRoomCollection, ThirdFloorRoomCollection)
// ======================================================================================================================
export class FirstFloorRoomCollection {
  get1x1(rnd: () => number): MansionTemplate { return MANSION_TEMPLATES_1X1_1F[Math.floor(rnd() * MANSION_TEMPLATES_1X1_1F.length)]; }
  get1x1Secret(rnd: () => number): MansionTemplate { return MANSION_TEMPLATES_1X1_AS[Math.floor(rnd() * MANSION_TEMPLATES_1X1_AS.length)]; }
  get1x2Sideways(rnd: () => number, isStairs: boolean): MansionTemplate {
    if (isStairs) return MANSION_TEMPLATES_1X2_STAIRS[0];
    return MANSION_TEMPLATES_1X2_1F[Math.floor(rnd() * 9)]; // 1x2_a1..1x2_a9
  }
  get1x2FrontEntrance(rnd: () => number, isStairs: boolean): MansionTemplate {
    if (isStairs) return MANSION_TEMPLATES_1X2_STAIRS[1];
    return MANSION_TEMPLATES_1X2_1F[9 + Math.floor(rnd() * 5)]; // 1x2_b1..1x2_b5
  }
  get1x2Secret(rnd: () => number): MansionTemplate { return MANSION_TEMPLATES_1X2_S_1F[Math.floor(rnd() * MANSION_TEMPLATES_1X2_S_1F.length)]; }
  get2x2(rnd: () => number): MansionTemplate { return MANSION_TEMPLATES_2X2_1F[Math.floor(rnd() * MANSION_TEMPLATES_2X2_1F.length)]; }
  get2x2Secret(_rnd: () => number): MansionTemplate { return '2x2_s1'; }
}

export class SecondFloorRoomCollection {
  get1x1(rnd: () => number): MansionTemplate { return MANSION_TEMPLATES_1X1_2F[Math.floor(rnd() * MANSION_TEMPLATES_1X1_2F.length)]; }
  get1x1Secret(rnd: () => number): MansionTemplate { return MANSION_TEMPLATES_1X1_AS[Math.floor(rnd() * MANSION_TEMPLATES_1X1_AS.length)]; }
  get1x2Sideways(rnd: () => number, isStairs: boolean): MansionTemplate {
    if (isStairs) return '1x2_c_stairs';
    return MANSION_TEMPLATES_1X2_2F[Math.floor(rnd() * 4)]; // 1x2_c1..1x2_c4
  }
  get1x2FrontEntrance(rnd: () => number, isStairs: boolean): MansionTemplate {
    if (isStairs) return '1x2_d_stairs';
    return MANSION_TEMPLATES_1X2_2F[4 + Math.floor(rnd() * 5)]; // 1x2_d1..1x2_d5
  }
  get1x2Secret(_rnd: () => number): MansionTemplate { return '1x2_se1'; }
  get2x2(rnd: () => number): MansionTemplate { return MANSION_TEMPLATES_2X2_2F[Math.floor(rnd() * MANSION_TEMPLATES_2X2_2F.length)]; }
  get2x2Secret(_rnd: () => number): MansionTemplate { return '2x2_s1'; }
}

export class ThirdFloorRoomCollection extends SecondFloorRoomCollection {}

// ======================================================================================================================
// Wing rooms + Vanilla Template assignment
// ======================================================================================================================
export const WING_ROOM_TYPES = ['storage', 'library', 'bedroom', 'dining', 'jail', 'garden', 'gallery', 'smithy', 'spider', 'empty'] as const;
export type WingRoomType = typeof WING_ROOM_TYPES[number];

export interface WingRoom {
  wing: -1 | 1; floor: number; column: 0 | 1; x0: number; x1: number; z0: number; z1: number; y: number;
  /** World cell of the doorway (the lower block; the upper one is above) and the direction the corridor lies in. */
  doorX: number; doorZ: number; toCorridor: number; type: WingRoomType;
  /** Official vanilla Woodland Mansion template ID assigned to this room. */
  template: MansionTemplate;
  /** True when this room is a secret room (no doorway to corridor in vanilla). */
  secret: boolean;
  /** Size category in MansionGrid (1x1, 1x2, or 2x2). */
  gridSize: '1x1' | '1x2' | '2x2';
}

export const MANSION_WING_HALF_X = 32, MANSION_WING_HALF_Z = 26;
/** Room cell rows relative to the mansion centre: [first interior row, last interior row] – 3 + alcove + 3 per side. */
const ROWS: [number, number][] = [[-25, -19], [-17, -11], [-9, -3], [-1, 1], [3, 9], [11, 17], [19, 25]];
const CACHE = new Map<string, WingRoom[]>();
const GRID_CACHE = new Map<string, MansionGrid>();

const COLLECTIONS = [
  new FirstFloorRoomCollection(),
  new SecondFloorRoomCollection(),
  new ThirdFloorRoomCollection(),
] as const;

const TEMPLATE_TO_LEGACY_TYPE: Record<MansionTemplate, WingRoomType> = {
  '1x1_a1': 'garden',
  '1x1_a2': 'gallery',
  '1x1_a3': 'library',
  '1x1_a4': 'storage',
  '1x1_a5': 'garden',
  '1x1_as1': 'storage',
  '1x1_as2': 'spider',
  '1x1_as3': 'smithy',
  '1x1_as4': 'empty',
  '1x1_b1': 'library',
  '1x1_b2': 'dining',
  '1x1_b3': 'bedroom',
  '1x1_b4': 'library',
  '1x1_b5': 'garden',
  '1x2_a1': 'gallery',
  '1x2_a2': 'garden',
  '1x2_a3': 'smithy',
  '1x2_a4': 'garden',
  '1x2_a5': 'bedroom',
  '1x2_a6': 'garden',
  '1x2_a7': 'garden',
  '1x2_a8': 'garden',
  '1x2_a9': 'storage',
  '1x2_b1': 'jail',
  '1x2_b2': 'jail',
  '1x2_b3': 'storage',
  '1x2_b4': 'storage',
  '1x2_b5': 'gallery',
  '1x2_c1': 'dining',
  '1x2_c2': 'bedroom',
  '1x2_c3': 'bedroom',
  '1x2_c4': 'library',
  '1x2_c_stairs': 'gallery',
  '1x2_d1': 'bedroom',
  '1x2_d2': 'bedroom',
  '1x2_d3': 'dining',
  '1x2_d4': 'gallery',
  '1x2_d5': 'gallery',
  '1x2_d_stairs': 'gallery',
  '1x2_s1': 'storage',
  '1x2_s2': 'jail',
  '1x2_se1': 'storage',
  '2x2_a1': 'jail',
  '2x2_a2': 'storage',
  '2x2_a3': 'gallery',
  '2x2_a4': 'garden',
  '2x2_b1': 'dining',
  '2x2_b2': 'dining',
  '2x2_b3': 'library',
  '2x2_b4': 'library',
  '2x2_b5': 'smithy',
  '2x2_s1': 'smithy',
};

/** Returns the vanilla MansionGrid generated for the mansion at `p`. */
export function mansionGridFor(seed: number, p: Site): MansionGrid {
  const key = `${seed}:${p.x},${p.y},${p.z}`;
  let g = GRID_CACHE.get(key);
  if (!g) {
    const rnd = mulberry((Math.imul(seed | 0, 2246822519) ^ Math.imul(p.x, 40503) ^ Math.imul(p.z, 65599)) >>> 0);
    g = new MansionGrid(rnd);
    if (GRID_CACHE.size > 24) GRID_CACHE.clear();
    GRID_CACHE.set(key, g);
  }
  return g;
}

/** Deterministic room plan of both wings, backed by the vanilla RoomCollection and MansionGrid. */
export function mansionWingRooms(seed: number, p: Site): WingRoom[] {
  const key = seed + ':' + p.x + ',' + p.y + ',' + p.z, hit = CACHE.get(key);
  if (hit) return hit;
  const rnd = mulberry((Math.imul(seed | 0, 2246822519) ^ Math.imul(p.x, 40503) ^ Math.imul(p.z, 65599)) >>> 0);
  const grid = mansionGridFor(seed, p);
  const X0 = p.x - 15, X1 = p.x + 15, out: WingRoom[] = [];

  for (const wing of [1, -1] as const) {
    for (let floor = 0; floor < 3; floor++) {
      const colCollection = COLLECTIONS[floor];
      for (const column of [0, 1] as const) {
        for (let r = 0; r < ROWS.length; r++) {
          if (column === 0 && r === 3) continue; // the passage band replaces the west alcove
          const [a, b] = ROWS[r], i0 = column === 0 ? 2 : 12, i1 = column === 0 ? 6 : 16, ix = (i: number) => (wing > 0 ? X1 + i : X0 - i);
          const doorI = column === 0 ? 7 : 11, zc = p.z + ((a + b) >> 1);
          const gx = Math.min(MansionGrid.DEFAULT_SIZE - 1, Math.max(0, (wing > 0 ? 5 : 0) + column * 2 + (r & 1)));
          const gy = Math.min(MansionGrid.DEFAULT_SIZE - 1, Math.max(0, r + 2));
          const cellVal = grid.floorRooms[floor].get(gx, gy);
          const sizeBits = cellVal & 0xF0000;
          const isStairs = (cellVal & ROOM_STAIRS_FLAG) !== 0;
          const isSecret = r !== 3 && r !== 5 && (cellVal & ROOM_DOOR_FLAG) === 0 && rnd() < 0.14;
          const gridSize: '1x1' | '1x2' | '2x2' =
            r === 3 ? '1x1' : sizeBits === ROOM_SIZE_2X2 ? '2x2' : sizeBits === ROOM_SIZE_1X1 && rnd() < 0.45 ? '1x1' : '1x2';

          let template: MansionTemplate;
          if (gridSize === '1x1') {
            template = isSecret ? colCollection.get1x1Secret(rnd) : colCollection.get1x1(rnd);
          } else if (gridSize === '2x2') {
            template = isSecret ? colCollection.get2x2Secret(rnd) : colCollection.get2x2(rnd);
          } else {
            if (isSecret) template = colCollection.get1x2Secret(rnd);
            else if (rnd() < 0.5) template = colCollection.get1x2Sideways(rnd, isStairs);
            else template = colCollection.get1x2FrontEntrance(rnd, isStairs);
          }

          out.push({
            wing,
            floor,
            column,
            x0: Math.min(ix(i0), ix(i1)),
            x1: Math.max(ix(i0), ix(i1)),
            z0: p.z + a,
            z1: p.z + b,
            y: p.y + floor * 5,
            doorX: ix(doorI),
            doorZ: zc,
            toCorridor: column === 0 ? (wing > 0 ? 1 : 3) : (wing > 0 ? 3 : 1),
            type: TEMPLATE_TO_LEGACY_TYPE[template],
            template,
            secret: isSecret,
            gridSize,
          });
        }
      }
    }
  }

  // Ensure every wing includes the core vanilla room categories (storage, library, bedroom, jail, garden, dining, smithy, gallery)
  // and rich template variety across the 39 rooms per wing.
  const signatureTemplates: { type: WingRoomType; floor: number; template: MansionTemplate; gridSize: '1x1' | '1x2' | '2x2'; secret?: boolean }[] = [
    { type: 'storage', floor: 0, template: '1x2_a9', gridSize: '1x2' },
    { type: 'library', floor: 1, template: '1x2_c4', gridSize: '1x2' },
    { type: 'bedroom', floor: 1, template: '1x2_d1', gridSize: '1x2' },
    { type: 'jail', floor: 0, template: '1x2_b1', gridSize: '1x2' },
    { type: 'garden', floor: 0, template: '1x2_a2', gridSize: '1x2' },
    { type: 'storage', floor: 0, template: '2x2_a2', gridSize: '2x2' },
    { type: 'dining', floor: 1, template: '2x2_b1', gridSize: '2x2' },
    { type: 'smithy', floor: 0, template: '1x2_a3', gridSize: '1x2' },
    { type: 'gallery', floor: 1, template: '1x2_d4', gridSize: '1x2' },
    { type: 'spider', floor: 0, template: '1x1_as2', gridSize: '1x1', secret: true },
    { type: 'jail', floor: 0, template: '1x2_s2', gridSize: '1x2', secret: true },
    { type: 'smithy', floor: 2, template: '2x2_s1', gridSize: '2x2', secret: true },
  ];

  for (const wing of [1, -1] as const) {
    const rooms = out.filter(r => r.wing === wing), order = rooms.map((_, i) => i);
    for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    const safeOrder = order.filter(i => rooms[i].z0 !== p.z + 11);
    signatureTemplates.forEach((sig, idx) => {
      const target = rooms[safeOrder[idx] ?? order[idx]];
      if (target) {
        target.type = sig.type;
        target.template = sig.template;
        target.gridSize = sig.gridSize;
        target.secret = !!sig.secret;
      }
    });
    for (const rm of rooms) {
      const ix = (i: number) => (rm.wing > 0 ? X1 + i : X0 - i);
      rm.doorX = rm.secret ? ix(rm.column === 0 ? 8 : 10) : ix(rm.column === 0 ? 7 : 11);
    }
  }

  if (CACHE.size > 24) CACHE.clear();
  CACHE.set(key, out);
  return out;
}

/** Bounding box [x0, y0, z0, x1, y1, z1] of the whole mansion including both wings. */
export const grandMansionBox = (p: Site): [number, number, number, number, number, number] => [
  p.x - MANSION_WING_HALF_X,
  p.y - 14,
  p.z - MANSION_WING_HALF_Z - 3,
  p.x + MANSION_WING_HALF_X,
  p.y + 27,
  p.z + MANSION_WING_HALF_Z,
];

/**
 * Furnishes a room in the Woodland Mansion according to its official vanilla structure template (`r.template`)
 * while preserving full compatibility with `r.type`.
 */
function furnishVanillaMansionRoom(
  t: StructHost,
  put: Put,
  r: WingRoom,
  R: (u: number, dy: number, v: number, b: number) => void,
  sx: (u: number, dy: number, v: number) => readonly [number, number, number],
  P: (x: number, yy: number, z: number, b: number) => void,
) {
  const long = r.z1 - r.z0 + 1;
  const wide = Math.abs(r.x1 - r.x0) + 1;
  const mid = (long - 1) >> 1;
  const away = (r.toCorridor + 2) & 3;
  const cob = bid('cobblestone');
  const cobWall = bid('cobblestone_wall', 'cobblestone');
  const cobSlab = bid('cobblestone_slab', 'cobblestone');
  const cobStair = cell('cobblestone_stairs', stairsUp(r.toCorridor), 'cobblestone');
  const darkPlank = bid('dark_oak_planks', 'oak_planks');
  const darkLog = bid('dark_oak_log', 'oak_log');
  const darkStair = cell('dark_oak_stairs', stairsUp(r.toCorridor), 'oak_planks');
  const darkFence = bid('dark_oak_fence', 'oak_fence');
  const oakPlank = bid('oak_planks');
  const oakSlab = bid('oak_slab', 'oak_planks');
  const oakStair = cell('oak_stairs', stairsUp(r.toCorridor), 'oak_planks');
  const oakFence = bid('oak_fence', 'oak_planks');
  const birchPlank = bid('birch_planks', 'oak_planks');
  const birchStair = cell('birch_stairs', stairsUp(r.toCorridor), 'birch_planks');
  const birchSlab = bid('birch_slab', 'birch_planks');
  const birchFence = bid('birch_fence', 'oak_fence');
  const andesite = bid('polished_andesite', 'andesite');
  const smoothSlab = bid('stone_brick_slab', 'cobblestone_slab');

  switch (r.template) {
    // ---- 1x1 First Floor Rooms --------------------------------------------------------------------------------------
    case '1x1_a1': // Flower room: cobblestone bench with 5 flower pots (2 allium, 1 blue orchid, 1 azure bluet, 1 oxeye daisy)
      for (let v = 0; v < long; v++) {
        R(4, 0, v, cob);
        R(4, 1, v, cobWall);
        R(3, 0, v, cobStair);
      }
      for (let v = 0; v < Math.min(5, long); v++) {
        const [x, yy, z] = sx(4, 1, v);
        pottedPlant(put, x, yy, z, [5, 2, 5, 6, 3][v]);
      }
      break;

    case '1x1_a2': // Pumpkin ring room: cobblestone ring with rails, ladders, and 1 carved pumpkin facing entryway
      for (let v = 0; v < long; v++) {
        R(4, 0, v, cob);
        R(4, 1, v, bid('rail', 'air'));
        R(3, 0, v, cell('ladder', ladderOn(away)));
      }
      R(4, 1, mid, bid('carved_pumpkin', 'pumpkin'));
      break;

    case '1x1_a3': // Office: two cobblestone tables with oak stair chairs, light gray carpets, and 3 potted red tulips
      R(3, 0, 0, cob); R(3, 1, 0, bid('light_gray_carpet', 'white_carpet'));
      R(2, 0, 0, oakStair);
      if (long >= 3) {
        R(3, 0, long - 1, cob);
        const [x, yy, z] = sx(3, 1, long - 1);
        pottedPlant(put, x, yy, z, 4); // red tulip
      }
      break;

    case '1x1_a4': { // Checkerboard room: gray & light_gray carpet floor, oak fences on walls, hidden loot chest above door
      for (let u = 1; u <= 4; u++) for (let v = 0; v < long; v++) {
        R(u, 0, v, bid((u + v) & 1 ? 'gray_carpet' : 'light_gray_carpet', 'white_carpet'));
        if (u === 4) R(u, 1, v, oakFence);
      }
      const [cx, cy, cz] = sx(1, 2, mid);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage');
      break;
    }

    case '1x1_a5': { // White tulip sanctuary: indented cobblestone shrine with potted white tulip
      for (let v = 0; v < long; v++) {
        R(4, 0, v, cob);
        R(4, 1, v, v === mid ? 0 : cob);
        R(4, 2, v, darkStair);
      }
      R(4, 0, mid, cobSlab);
      P(sx(4, 0, mid)[0], r.y, sx(4, 0, mid)[2], bid('decorated_pot', 'terracotta'));
      P(sx(4, 1, mid)[0], r.y + 1, sx(4, 1, mid)[2], bid('white_tulip', 'dandelion'));
      break;
    }

    // ---- 1x1 Secret Rooms (any floor) -------------------------------------------------------------------------------
    case '1x1_as1': { // X room: cobblestone "X" pattern on walls + chest in corner
      for (let v = 0; v < long; v++) {
        R(4, 0, v, cob);
        if (v === 0 || v === long - 1) R(4, 2, v, cob);
        if (v === mid) R(4, 1, v, cob);
      }
      const [cx, cy, cz] = sx(4, 0, 0);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage');
      break;
    }

    case '1x1_as2': // Spider room: packed with cobwebs and a spider monster spawner in the center
      for (let u = 1; u <= 4; u++) for (let v = 0; v < long; v++) for (let dy = 0; dy <= 2; dy++) {
        if ((u + v + dy) % 2 === 0) R(u, dy, v, bid('cobweb', 'air'));
      }
      R(2, 0, mid, bid('spawner', 'cobweb'));
      break;

    case '1x1_as3': // Obsidian room: octahedron of obsidian concealing a diamond block inside
      for (let du = -1; du <= 1; du++) for (let dv = -1; dv <= 1; dv++) for (let dy = 0; dy <= 2; dy++) {
        if (Math.abs(du) + Math.abs(dv) + Math.abs(dy - 1) <= 2) {
          const isCenter = du === 0 && dv === 0 && dy === 1;
          R(2 + du, dy, Math.max(0, Math.min(long - 1, mid + dv)), isCenter ? bid('diamond_block') : bid('obsidian'));
        }
      }
      break;

    case '1x1_as4': // Birch pillar room: 4 birch plank pillars erected toward the ceiling
      for (const u of [1, 3]) for (const v of [0, long - 1]) {
        for (let dy = 0; dy <= 3; dy++) R(u, dy, v, birchPlank);
      }
      break;

    // ---- 1x1 Second & Third Floor Rooms -----------------------------------------------------------------------------
    case '1x1_b1': { // Birch arch room: birch arch in center, desk with potted azure bluet & pink carpet
      for (let v = 0; v < long; v++) {
        R(2, 2, v, birchStair);
        R(2, 3, v, birchSlab);
      }
      R(2, 0, 0, birchFence); R(2, 1, 0, birchFence);
      R(2, 0, long - 1, birchFence); R(2, 1, long - 1, birchFence);
      R(4, 0, mid, birchPlank); R(4, 1, mid, bid('pink_carpet', 'white_carpet'));
      if (long >= 2) { const [x, yy, z] = sx(4, 0, 0); pottedPlant(put, x, yy, z, 2); }
      break;
    }

    case '1x1_b2': // Small dining room: table with light gray & black carpet and dark oak stair chairs
      for (let v = 1; v < Math.max(2, long - 1); v++) {
        R(2, 0, v, darkFence);
        R(2, 1, v, bid(v === mid ? 'black_carpet' : 'light_gray_carpet', 'white_carpet'));
        R(1, 0, v, cell('dark_oak_stairs', stairsUp(away), 'oak_planks'));
        R(3, 0, v, cell('dark_oak_stairs', stairsUp(r.toCorridor), 'oak_planks'));
      }
      break;

    case '1x1_b3': // Single bed bedroom: red/white wool bed, cobblestone fireplace, bonsai (dark oak fence + dark oak leaves)
      R(3, 0, 0, bid('white_wool')); R(4, 0, 0, bid('red_wool', 'white_wool'));
      R(4, 0, mid, cob); R(4, 1, mid, cobStair); R(4, 2, mid, cobSlab);
      R(4, 0, long - 1, darkFence); R(4, 1, long - 1, bid('dark_oak_leaves', 'oak_leaves'));
      break;

    case '1x1_b4': { // Small library: corner bookshelves, oak desk, potted allium, lectern
      for (const v of [0, long - 1]) for (let dy = 0; dy <= 2; dy++) {
        R(3, dy, v, bid('bookshelf', 'oak_planks'));
        R(4, dy, v, bid('bookshelf', 'oak_planks'));
      }
      { const [x, yy, z] = sx(2, 0, mid); lectern(put, x, yy, z, r.toCorridor); }
      { const [x, yy, z] = sx(4, 0, mid); pottedPlant(put, x, yy, z, 5); }
      break;
    }

    case '1x1_b5': { // Allium room: vine-tangled oak stand with 5 potted alliums, water cauldron, and chest with 8 alliums
      for (let v = 0; v < long; v++) {
        R(4, 0, v, oakPlank);
        R(3, 0, v, bid('vine', 'air'));
        const [x, yy, z] = sx(4, 1, v);
        pottedPlant(put, x, yy, z, 5);
      }
      R(1, 0, 0, bid('cauldron', 'cobblestone'));
      const [cx, cy, cz] = sx(1, 0, long - 1);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_allium');
      break;
    }

    // ---- 1x2 First Floor Rooms --------------------------------------------------------------------------------------
    case '1x2_a1': { // Gray banner room: cobblestone altar passage, gray banner, hidden loot chest behind altar
      for (let v = Math.max(0, mid - 1); v <= Math.min(long - 1, mid + 1); v++) {
        for (let dy = 0; dy <= 2; dy++) {
          if (v !== mid || dy === 2) R(2, dy, v, cob);
          R(3, dy, v, cob);
        }
      }
      R(3, 1, mid, bid('gray_banner', 'gray_wool'));
      const [cx, cy, cz] = sx(4, 0, mid);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage');
      break;
    }

    case '1x2_a2': // Wheat farm: dark oak log border, water channel with lily pads, farmland + wheat crops
      for (let v = 0; v < long; v++) {
        R(1, 0, v, darkLog);
        R(4, 0, v, darkLog);
        if (v > 0 && v < long - 1) {
          R(2, -1, v, bid('water', 'air'));
          R(2, 0, v, bid('lily_pad', 'air'));
          R(3, -1, v, bid('farmland_moist', 'farmland'));
          R(3, 0, v, bid('wheat_crop', 'short_grass'));
        }
      }
      break;

    case '1x2_a3': // Forge room: polished andesite arches, smooth stone slabs, damaged anvil, and encased lava pool
      for (let v = 0; v < long; v++) {
        R(4, 0, v, andesite);
        R(4, 1, v, andesite);
        if (v % 2 === 0) { R(2, 2, v, andesite); R(3, 2, v, smoothSlab); }
      }
      R(3, 0, mid, bid('lava', 'magma_block'));
      R(2, 0, mid, andesite);
      R(3, 0, Math.max(0, mid - 1), andesite);
      R(3, 0, Math.min(long - 1, mid + 1), andesite);
      R(2, 0, 0, bid('anvil', 'iron_block'));
      break;

    case '1x2_a4': { // Sapling farm: two layered rows of dirt + dark oak saplings, ladders, green carpet, chest with 28 saplings
      for (let v = 1; v < long - 1; v++) {
        R(4, 0, v, bid('dirt'));
        R(4, 1, v, bid('dark_oak_sapling', 'oak_sapling'));
        R(2, 0, v, bid('green_carpet', 'white_carpet'));
      }
      for (let dy = 0; dy <= 2; dy++) R(3, dy, 0, cell('ladder', ladderOn(away)));
      const [cx, cy, cz] = sx(1, 0, 0);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_sapling');
      break;
    }

    case '1x2_a5': // Wool room: messy pile of blue, light blue, and cyan wool
      for (let v = 0; v < long; v++) {
        R(4, 0, v, bid('blue_wool', 'white_wool'));
        R(4, 1, v, bid('light_blue_wool', 'white_wool'));
        R(3, 0, v, bid(v % 2 === 0 ? 'cyan_wool' : 'light_blue_wool', 'white_wool'));
      }
      break;

    case '1x2_a6': { // Tree-chopping room: artificial dark oak tree on dirt platform + boarded birch_planks entrance + chest with Efficiency I iron axe
      for (let v = 0; v < Math.min(long, 3); v++) for (let dy = 0; dy <= 1; dy++) R(0, dy, v, birchPlank);
      for (let dv = -1; dv <= 1; dv++) {
        const v = Math.max(0, Math.min(long - 1, mid + dv));
        R(3, 0, v, bid('dirt'));
        for (let dy = 2; dy <= 3; dy++) R(3, dy, v, bid('dark_oak_leaves', 'oak_leaves'));
      }
      R(3, 1, mid, darkLog);
      R(3, 2, mid, darkLog);
      const [cx, cy, cz] = sx(4, 0, 0);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_tree_chop');
      break;
    }

    case '1x2_a7': { // Mushroom farm: coarse dirt planter, red & brown mushrooms, table + chair + chest
      for (let v = 1; v < long - 1; v++) {
        R(4, 0, v, bid('coarse_dirt', 'dirt'));
        R(4, 1, v, bid(v % 2 === 0 ? 'red_mushroom' : 'brown_mushroom', 'dandelion'));
        R(3, 0, v, oakFence);
      }
      const [cx, cy, cz] = sx(1, 0, 0);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage');
      break;
    }

    case '1x2_a8': // Dual-staged farm: lower pumpkin farm, upper melon farm
      for (let v = 1; v < long - 1; v++) {
        R(3, -1, v, bid('farmland_moist', 'farmland'));
        R(3, 0, v, bid(v % 2 === 0 ? 'pumpkin' : 'pumpkin_stem', 'pumpkin'));
        R(4, 1, v, bid('dirt'));
        R(4, 2, v, bid(v % 2 === 0 ? 'melon' : 'melon_stem', 'melon'));
      }
      break;

    case '1x2_a9': // Large Chest Room (Wiki: 42 empty/storage chests on multi-tier shelves)
      if (wide >= 7 && long >= 15) {
        for (const u of [1, 5]) for (const dy of [0, 2, 4]) for (let v = 1; v <= 7; v++) {
          const [x, yy, z] = sx(u, dy, v);
          chest(put, t, x, yy, z, r.toCorridor, 'mansion_storage');
          R(u, dy + 1, v, oakSlab);
        }
      } else {
        for (const v of long === 7 ? [1, 3, 5] : [1]) {
          const [x, yy, z] = sx(4, 0, v);
          chest(put, t, x, yy, z, r.toCorridor, 'mansion_storage');
          R(4, 1, v, oakSlab);
        }
      }
      { const [x, yy, z] = sx(4, 0, 0); barrel(put, t, x, yy, z, r.toCorridor); }
      { const [x, yy, z] = sx(4, 0, long - 1); barrel(put, t, x, yy, z, r.toCorridor); }
      break;

    case '1x2_b1': // Redstone jail: cobblestone jail with iron doors, lever, redstone wire, cauldron, brown carpet
    case '1x2_b2': { // Small jail
      for (let v = 0; v < long; v++) for (let dy = 0; dy < 3; dy++) {
        R(2, dy, v, v === mid ? 0 : bid('iron_bars', 'cobblestone'));
      }
      R(2, 0, mid, cell('iron_door', away === 1 ? 3 : 1, 'iron_bars'));
      R(2, 1, mid, cell('iron_door', (away === 1 ? 3 : 1) | 4, 'iron_bars'));
      R(1, 1, Math.max(0, mid - 1), cell('lever', attachOn(away)));
      R(2, 2, mid, bid('redstone_wire', 'air'));
      R(4, 0, 0, bid('cauldron', 'cobblestone'));
      R(4, 0, long - 1, bid('brown_carpet', 'red_carpet'));
      break;
    }

    case '1x2_b3': { // Wood arch hallway: dark oak log arches + loot chest at end
      for (let v = 0; v < long; v += 2) {
        for (let dy = 0; dy <= 2; dy++) { R(1, dy, v, darkLog); R(3, dy, v, darkLog); }
        R(2, 2, v, darkLog);
      }
      const [cx, cy, cz] = sx(4, 0, mid);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage');
      break;
    }

    case '1x2_b4': { // Winding stairway room: dark oak log spiral column with oak slab steps leading to a loot chest
      for (let dy = 0; dy <= 2; dy++) R(3, dy, mid, darkLog);
      R(2, 0, Math.max(0, mid - 1), oakSlab);
      R(2, 1, mid, oakSlab);
      R(2, 2, Math.min(long - 1, mid + 1), oakSlab);
      const [cx, cy, cz] = sx(4, 2, mid);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage');
      break;
    }

    case '1x2_b5': // Illager head room: wool pixel art of an Illager face on the far wall + item frames
      for (let v = Math.max(0, mid - 1); v <= Math.min(long - 1, mid + 1); v++) {
        for (let dy = 0; dy <= 2; dy++) R(4, dy, v, bid('light_gray_wool', 'white_wool'));
      }
      R(4, 1, Math.max(0, mid - 1), bid('green_wool', 'lime_wool'));
      R(4, 1, Math.min(long - 1, mid + 1), bid('green_wool', 'lime_wool'));
      R(4, 2, mid, bid('gray_wool', 'white_wool'));
      for (const v of long === 7 ? [1, 3, 5] : [1]) {
        const [x, yy, z] = sx(3, 1, v);
        itemFrame(put, t, x, yy, z, away, 'mansion_frame');
      }
      break;

    // ---- 1x2 Second & Third Floor Rooms -----------------------------------------------------------------------------
    case '1x2_c1': // Medium dining room: oak stair table with potted oxeye daisy, white/gray carpet, chandelier
      for (let v = 1; v <= Math.min(5, long - 2); v++) {
        R(2, 0, v, oakFence);
        R(2, 1, v, bid('white_carpet', 'red_carpet'));
        R(1, 0, v, cell('dark_oak_stairs', stairsUp(away), 'oak_planks'));
        R(3, 0, v, cell('dark_oak_stairs', stairsUp(r.toCorridor), 'oak_planks'));
      }
      { const [x, yy, z] = sx(2, 3, mid); lantern(put, x, yy, z); P(x, yy + 1, z, oakFence); }
      break;

    case '1x2_c2': { // Double bed bedroom: 2 beds with purple & pink carpets, oak stair desk with potted allium & white carpet
      for (const v of long >= 5 ? [1, long - 2] : [0, long - 1]) {
        const [x, yy, z] = sx(3, 0, v);
        put(x, yy, z, cell('bed', away === 1 ? 3 : 1, 'white_wool'), true);
        const [x2, y2, z2] = sx(4, 0, v);
        put(x2, y2, z2, cell('bed', (away === 1 ? 3 : 1) | 4, 'white_wool'), true);
      }
      for (let v = 1; v < long - 1; v++) {
        R(2, 0, v, bid(v % 2 === 0 ? 'purple_carpet' : 'pink_carpet', 'white_carpet'));
      }
      R(1, 0, 0, oakStair);
      R(1, 1, 0, bid('white_carpet'));
      { const [x, yy, z] = sx(1, 0, Math.min(long - 1, 1)); pottedPlant(put, x, yy, z, 5); }
      break;
    }

    case '1x2_c3': { // Triple bed bedroom: 3 beds with blue & light blue carpets, oak desk with potted azure bluet
      const bedRows = long >= 7 ? [1, 3, 5] : [0, mid, long - 1];
      for (const v of bedRows) {
        const [x, yy, z] = sx(3, 0, v);
        put(x, yy, z, cell('bed', away === 1 ? 3 : 1, 'white_wool'), true);
        const [x2, y2, z2] = sx(4, 0, v);
        put(x2, y2, z2, cell('bed', (away === 1 ? 3 : 1) | 4, 'white_wool'), true);
      }
      for (let v = 1; v < long - 1; v++) {
        R(2, 0, v, bid(v % 2 === 0 ? 'blue_carpet' : 'light_blue_carpet', 'white_carpet'));
      }
      R(1, 0, 0, oakPlank);
      { const [x, yy, z] = sx(1, 1, 0); pottedPlant(put, x, yy, z, 2); }
      break;
    }

    case '1x2_d1': { // Master bedroom: four-post canopy bed (oak fence + oak slab), 3 light gray banners, bookshelf, potted birch sapling & oxeye daisy
      for (const v of long >= 5 ? [1, long - 2] : [0, long - 1]) {
        const [x, yy, z] = sx(3, 0, v);
        put(x, yy, z, cell('bed', away === 1 ? 3 : 1, 'white_wool'), true);
        const [x2, y2, z2] = sx(4, 0, v);
        put(x2, y2, z2, cell('bed', (away === 1 ? 3 : 1) | 4, 'white_wool'), true);
      }
      for (const [u, v] of [[2, 1], [4, 1], [2, Math.max(1, long - 2)], [4, Math.max(1, long - 2)]]) {
        R(u, 1, v, oakFence);
        R(u, 2, v, oakSlab);
      }
      for (let v = 1; v < long - 1; v++) R(2, 0, v, bid('red_carpet', 'white_carpet'));
      R(1, 2, mid, bid('light_gray_banner', 'light_gray_wool'));
      R(4, 0, 0, bid('bookshelf', 'oak_planks'));
      { const [x, yy, z] = sx(1, 0, 0); pottedPlant(put, x, yy, z, 3); }
      break;
    }

    case '1x2_d2': { // Bedroom with loft: center bed + loft bed accessed by 6-rung ladder, oak closet with 2 dark oak doors, red/cyan/light_blue carpets, potted red tulip & loot chest
      for (const v of long >= 5 ? [1, long - 2] : [0, long - 1]) {
        const [x, yy, z] = sx(3, 0, v);
        put(x, yy, z, cell('bed', away === 1 ? 3 : 1, 'white_wool'), true);
        const [x2, y2, z2] = sx(4, 0, v);
        put(x2, y2, z2, cell('bed', (away === 1 ? 3 : 1) | 4, 'white_wool'), true);
      }
      for (let dy = 0; dy <= 2; dy++) R(4, dy, 0, cell('ladder', ladderOn(away)));
      R(3, 2, 0, oakPlank);
      R(2, 0, 0, cell('dark_oak_door', away === 1 ? 3 : 1, 'oak_planks'));
      for (let v = 1; v < long - 1; v++) {
        R(2, 0, v, bid(v % 3 === 0 ? 'cyan_carpet' : v % 3 === 1 ? 'light_blue_carpet' : 'red_carpet', 'red_carpet'));
      }
      { const [x, yy, z] = sx(1, 0, 0); pottedPlant(put, x, yy, z, 4); }
      { const [x, yy, z] = sx(4, 0, mid); chest(put, t, x, yy, z, r.toCorridor, 'mansion_storage'); }
      break;
    }

    case '1x2_c4': { // Medium library: 3 bookshelves, 2 oak stair benches, and large desk with 4 flower pots (dandelion, poppy, red tulip, oxeye daisy)
      for (let v = 0; v < long; v++) for (let dy = 0; dy < 3; dy++) R(4, dy, v, bid('bookshelf', 'oak_planks'));
      for (let u = 1; u <= 3; u++) for (let dy = 0; dy < 2; dy++) {
        R(u, dy, 0, bid('bookshelf', 'oak_planks'));
        R(u, dy, long - 1, bid('bookshelf', 'oak_planks'));
      }
      { const [x, yy, z] = sx(2, 0, mid); lectern(put, x, yy, z, r.toCorridor); }
      { const [x, yy, z] = sx(3, 1, mid); itemFrame(put, t, x, yy, z, away, 'mansion_frame'); }
      for (let i = 0; i < Math.min(4, Math.max(1, long - 2)); i++) {
        const [x, yy, z] = sx(1, 0, 1 + i);
        pottedPlant(put, x, yy, z, [1, 0, 4, 3][i]);
      }
      break;
    }

    case '2x2_b3': { // Large library: 180+ bookshelves across 3 double-sided cases & walls + face-to-face oak stair reading lounges
      if (wide >= 15 && long >= 15) {
        for (const v of [0, 3, 6, 9, 13]) {
          for (let u = 2; u <= 11; u++) for (let dy = 0; dy < 4; dy++) {
            R(u, dy, v, bid('bookshelf', 'oak_planks'));
          }
        }
      } else {
        for (let v = 0; v < long; v++) for (let dy = 0; dy < 3; dy++) R(4, dy, v, bid('bookshelf', 'oak_planks'));
        for (let u = 1; u <= 3; u++) for (let dy = 0; dy < 2; dy++) {
          R(u, dy, 0, bid('bookshelf', 'oak_planks'));
          R(u, dy, long - 1, bid('bookshelf', 'oak_planks'));
        }
      }
      R(1, 0, Math.max(1, mid - 1), oakStair);
      R(1, 0, Math.min(long - 2, mid + 1), oakStair);
      { const [x, yy, z] = sx(2, 0, mid); lectern(put, x, yy, z, r.toCorridor); }
      { const [x, yy, z] = sx(3, 1, mid); itemFrame(put, t, x, yy, z, away, 'mansion_frame'); }
      break;
    }

    case '2x2_b4': { // Map room: table covered in lime, blue, and yellow carpets + bookshelf + chandelier
      for (let v = 0; v < long; v++) for (let dy = 0; dy < 3; dy++) R(4, dy, v, bid('bookshelf', 'oak_planks'));
      for (let v = 1; v < long - 1; v++) {
        R(2, 0, v, oakPlank);
        R(2, 1, v, bid(v % 3 === 0 ? 'yellow_carpet' : v % 2 === 0 ? 'lime_carpet' : 'blue_carpet', 'lime_carpet'));
      }
      { const [x, yy, z] = sx(1, 0, mid); lectern(put, x, yy, z, r.toCorridor); }
      { const [x, yy, z] = sx(3, 1, mid); itemFrame(put, t, x, yy, z, away, 'mansion_frame'); }
      break;
    }

    case '1x2_c_stairs': // Curved staircase with wool illager head
    case '1x2_d_stairs': { // Straight staircase with wool illager head
      for (let s = 0; s < Math.min(4, long); s++) {
        R(3, s, s, cobStair);
      }
      R(4, 2, mid, bid('light_gray_wool', 'white_wool'));
      R(4, 1, mid, bid('green_wool', 'lime_wool'));
      { const [x, yy, z] = sx(3, 1, mid); itemFrame(put, t, x, yy, z, away, 'mansion_frame'); }
      break;
    }

    case '1x2_d3': // Ritual room: cobblestone altar with black carpet and two black banners
      for (let v = 1; v < long - 1; v++) R(3, 0, v, cobStair);
      R(4, 0, mid, cob);
      R(4, 1, mid, bid('black_carpet', 'gray_carpet'));
      R(4, 2, Math.max(0, mid - 1), bid('black_banner', 'black_wool'));
      R(4, 2, Math.min(long - 1, mid + 1), bid('black_banner', 'black_wool'));
      break;

    case '1x2_d4': { // Cat statue room: black wool cat statue with lime wool eyes and white wool paws
      for (let v = Math.max(0, mid - 1); v <= Math.min(long - 1, mid + 1); v++) {
        R(3, 0, v, bid('black_wool', 'white_wool'));
        R(3, 1, v, bid('black_wool', 'white_wool'));
      }
      R(2, 0, Math.max(0, mid - 1), bid('white_wool'));
      R(3, 2, Math.max(0, mid - 1), bid('lime_wool', 'green_wool'));
      R(4, 2, Math.min(long - 1, mid + 1), bid('black_wool', 'white_wool'));
      const [x, yy, z] = sx(3, 1, mid);
      itemFrame(put, t, x, yy, z, away, 'mansion_frame');
      break;
    }

    case '1x2_d5': { // Chicken statue room: white wool chicken statue with orange wool beak and legs
      for (let v = Math.max(0, mid - 1); v <= Math.min(long - 1, mid + 1); v++) {
        R(3, 0, v, bid('orange_wool', 'white_wool'));
        R(3, 1, v, bid('white_wool'));
        R(3, 2, v, bid('white_wool'));
      }
      R(2, 2, mid, bid('orange_wool', 'white_wool'));
      const [x, yy, z] = sx(3, 1, mid);
      itemFrame(put, t, x, yy, z, away, 'mansion_frame');
      break;
    }

    // ---- 1x2 Secret Rooms -------------------------------------------------------------------------------------------
    case '1x2_s1': { // Clean chest room: lone loot chest surrounded by 4 torches on dark oak fences
      for (const [u, v] of [[1, 0], [4, 0], [1, long - 1], [4, long - 1]]) {
        R(u, 0, v, darkFence);
        R(u, 1, v, bid('torch'));
      }
      const [cx, cy, cz] = sx(3, 0, mid);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage');
      break;
    }

    case '1x2_s2': { // Fake End portal room: infested cobblestone steps, orange wool lava, green wool frame ring, trapped chest (2 ender pearls) + 2 TNT
      const infCob = bid('infested_cobblestone', 'cobblestone');
      for (let v = Math.max(0, mid - 1); v <= Math.min(long - 1, mid + 1); v++) {
        R(1, 0, v, cobStair);
        R(2, 0, v, bid('green_wool', 'lime_wool'));
        R(4, 0, v, bid('green_wool', 'lime_wool'));
        R(3, 0, v, v === mid ? bid('orange_wool', 'white_wool') : bid('green_wool', 'lime_wool'));
        R(4, 1, v, v === mid ? 0 : infCob);
      }
      R(4, 0, 0, bid('tnt'));
      R(4, 0, long - 1, bid('tnt'));
      const [tx, ty, tz] = sx(4, 1, mid);
      put(tx, ty, tz, cell('trapped_chest', (r.toCorridor + 2) & 3, 'chest'), true);
      tag(t, tx, ty, tz, 'mansion_fake_portal');
      break;
    }

    case '1x2_se1': { // Attic room: two-tiered secret room with 2 chests on the upper loft
      for (let u = 1; u <= 4; u++) for (let v = 0; v < long; v++) R(u, 2, v, darkPlank);
      { const [cx, cy, cz] = sx(4, 0, 0); chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage'); }
      { const [cx, cy, cz] = sx(4, 0, long - 1); chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage'); }
      break;
    }

    // ---- 2x2 Rooms --------------------------------------------------------------------------------------------------
    case '2x2_a1': { // Large jail: 4 cobblestone jail cells with 4 iron doors, iron bars, cauldrons, brown carpets, levers
      for (let v = 0; v < long; v++) for (let dy = 0; dy < 3; dy++) {
        R(2, dy, v, bid('iron_bars', 'cobblestone'));
        if (wide >= 12) R(8, dy, v, bid('iron_bars', 'cobblestone'));
      }
      const doorSlots = wide >= 12 && long >= 12 ? [[2, 2], [2, 6], [8, 2], [8, 6]] : [[2, 0], [2, Math.min(long - 1, 2)], [2, Math.min(long - 1, 4)], [3, mid]];
      for (const [du, dv] of doorSlots) {
        R(du, 0, dv, cell('iron_door', away === 1 ? 3 : 1, 'iron_bars'));
        R(du, 1, dv, cell('iron_door', (away === 1 ? 3 : 1) | 4, 'iron_bars'));
      }
      R(4, 0, 0, bid('cauldron', 'cobblestone'));
      R(4, 0, long - 1, bid('brown_carpet', 'red_carpet'));
      break;
    }

    case '2x2_a2': { // Large storage room: shelves holding chests, barrels, and red carpet
      for (const v of long === 7 ? [1, 3, 5] : [1]) {
        const [x, yy, z] = sx(4, 0, v);
        chest(put, t, x, yy, z, r.toCorridor, 'mansion_storage');
      }
      { const [x, yy, z] = sx(4, 0, 0); barrel(put, t, x, yy, z, r.toCorridor); }
      { const [x, yy, z] = sx(4, 0, long - 1); barrel(put, t, x, yy, z, r.toCorridor); }
      R(2, 0, mid, bid('red_carpet', 'white_carpet'));
      break;
    }

    case '2x2_a3': { // Illager statue room: giant wool illager bust holding a torch, with a lapis_block hidden inside the head
      for (let v = Math.max(0, mid - 1); v <= Math.min(long - 1, mid + 1); v++) {
        R(4, 0, v, bid('brown_wool', 'white_wool'));
        R(4, 1, v, bid('light_gray_wool', 'white_wool'));
        R(4, 2, v, bid('light_gray_wool', 'white_wool'));
      }
      R(4, 2, mid, bid('lapis_block', 'blue_wool')); // hidden Block of Lapis Lazuli inside head!
      R(2, 1, 0, bid('torch'));
      const [x, yy, z] = sx(3, 1, mid);
      itemFrame(put, t, x, yy, z, away, 'mansion_frame');
      break;
    }

    case '2x2_a4': // Nature room: polished andesite water feature + artificial dark oak tree + flowers
      for (let u = 1; u <= 4; u++) for (let v = 0; v < long; v++) {
        const [x, yy, z] = sx(u, -1, v);
        P(x, yy, z, bid('grass_block', 'dirt'));
        R(u, 0, v, bid(['poppy', 'dandelion', 'azure_bluet', 'oxeye_daisy', 'red_tulip', 'allium'][(u + v) % 6], 'dandelion'));
      }
      R(2, -1, mid, bid('water', 'air'));
      R(2, 0, mid, bid('dark_oak_leaves', 'oak_leaves'));
      R(4, 0, 0, darkLog); R(4, 1, 0, bid('dark_oak_leaves', 'oak_leaves'));
      break;

    case '2x2_b1': { // Large dining room: 3 dining tables with oak stair chairs, white carpet, 3 potted birch saplings, serving counter with magenta carpet & chandeliers
      for (let v = 1; v <= Math.min(5, long - 2); v++) {
        R(2, 0, v, oakFence);
        R(2, 1, v, bid('white_carpet', 'red_carpet'));
        R(1, 0, v, cell('oak_stairs', stairsUp(away), 'oak_planks'));
        R(3, 0, v, cell('oak_stairs', stairsUp(r.toCorridor), 'oak_planks'));
      }
      R(4, 0, 0, oakPlank);
      R(4, 1, 0, bid('magenta_carpet', 'purple_carpet'));
      { const [x, yy, z] = sx(2, 3, mid); lantern(put, x, yy, z); P(x, yy + 1, z, oakFence); }
      break;
    }

    case '2x2_b2': { // Conference room: U-shaped table with white carpets, 5 potted white tulips, and 2 hanging chandeliers
      for (let v = 1; v <= Math.min(5, long - 2); v++) {
        R(2, 0, v, oakPlank);
        R(2, 1, v, bid('white_carpet', 'red_carpet'));
        R(1, 0, v, cell('oak_stairs', stairsUp(away), 'oak_planks'));
        R(3, 0, v, cell('oak_stairs', stairsUp(r.toCorridor), 'oak_planks'));
      }
      { const [x, yy, z] = sx(4, 0, mid); pottedPlant(put, x, yy, z, 6); }
      { const [x, yy, z] = sx(2, 3, mid); lantern(put, x, yy, z); P(x, yy + 1, z, oakFence); }
      break;
    }

    case '2x2_b5': { // Arena room: fighting ring surrounded by 2-layer oak/dark_oak fences, fence gates, ladders to loft gallery, forge stations & loot chest
      R(4, 0, 1, bid('furnace', 'cobblestone'));
      R(4, 0, 2, bid('blast_furnace', 'furnace'));
      R(4, 0, 3, bid('grindstone', 'cobblestone'));
      R(4, 0, 4, bid('anvil', 'iron_block'));
      for (let v = 1; v < long - 1; v++) {
        R(2, 0, v, v === mid ? bid('dark_oak_fence_gate', 'dark_oak_fence') : darkFence);
        R(2, 1, v, v === mid ? 0 : oakFence);
      }
      for (let dy = 0; dy <= 2; dy++) R(4, dy, 0, cell('ladder', ladderOn(away)));
      const [cx, cy, cz] = sx(4, 0, long - 1);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage');
      break;
    }

    case '2x2_s1': { // Lava room: lava-filled glass case on obsidian foundations concealing a diamond block inside
      for (let v = Math.max(0, mid - 1); v <= Math.min(long - 1, mid + 1); v++) {
        R(3, 0, v, bid('obsidian'));
        R(3, 2, v, bid('obsidian'));
        R(2, 1, v, bid('glass'));
        R(4, 1, v, bid('glass'));
        R(3, 1, v, v === mid ? bid('diamond_block') : bid('lava', 'magma_block'));
      }
      const [cx, cy, cz] = sx(4, 0, long - 1);
      chest(put, t, cx, cy, cz, r.toCorridor, 'mansion_storage');
      break;
    }
  }
}

export function grandMansion(t: StructHost, put: Put, p: Site, ox?: number, oz?: number) {
  const inChunk = (x0: number, z0: number, x1: number, z1: number) =>
    ox === undefined || oz === undefined || !(x1 < ox - 1 || x0 > ox + 17 || z1 < oz - 1 || z0 > oz + 17);
  if (inChunk(p.x - 16, p.z - 11, p.x + 16, p.z + 11)) mansion(t, put, p);
  const plank = bid('dark_oak_planks', 'oak_planks'), log = bid('dark_oak_log', 'oak_log'), birch = bid('birch_planks', 'oak_planks'), cob = bid('cobblestone');
  const X0 = p.x - 15, X1 = p.x + 15, y = p.y, P = (x: number, yy: number, z: number, b: number) => put(x, yy, z, b, true);
  const rooms = mansionWingRooms(t.seed, p);

  // Openings of the main block's end walls on all three floors (the ground floor of the west end already is the old entrance).
  if (inChunk(X0 - 1, p.z - 2, X1 + 1, p.z + 2)) {
    for (const x of [X0, X1]) for (let k = 0; k < 3; k++) for (let dz = -1; dz <= 1; dz++) for (let dy = 0; dy <= 2; dy++) {
      P(x, y + k * 5 + dy, p.z + dz, 0);
    }
  }

  for (const wing of [1, -1]) {
    const ix = (i: number) => (wing > 0 ? X1 + i : X0 - i), xa = Math.min(ix(1), ix(17)), xb = Math.max(ix(1), ix(17));
    if (!inChunk(xa, p.z - 27, xb, p.z + 26)) continue;
    for (let z = p.z - 26; z <= p.z + 26; z++) {
      const dz = z - p.z;
      if (!inChunk(xa, z, xb, z)) continue;
      for (let i = 1; i <= 17; i++) {
        const x = ix(i);
        if (ox !== undefined && oz !== undefined && (x < ox - 1 || x > ox + 17)) continue;
        for (let dy = 2; dy <= 14; dy++) P(x, y - dy, z, cob);
        const outerEnd = dz === -26 || dz === 26, outerSide = i === 17 || i === 1, wallRow = [-26, -18, -10, -2, 2, 10, 18, 26].includes(dz);
        const wallCol = i === 1 || i === 7 || i === 11 || i === 17;
        const corridor = i >= 8 && i <= 10, pass = Math.abs(dz) <= 1 && i <= 7;
        for (let k = 0; k < 3; k++) {
          const fy = y - 1 + k * 5;
          P(x, fy, z, k === 0 ? cob : birch);
          for (let dy = 1; dy <= 4; dy++) {
            let b = 0;
            if (outerEnd || i === 17 || i === 1) {
              const along = outerEnd ? i : dz + 26;
              b = (outerEnd && outerSide) || along % 5 === 0
                ? log
                : (dy === 2 || dy === 3) && along % 5 !== 1 && along % 5 !== 4
                  ? cell('glass_pane', outerEnd ? PANE_X : PANE_Z, 'glass')
                  : plank;
              if (i === 1 && !outerEnd && pass) b = 0;
            } else if (corridor) {
              b = outerEnd
                ? plank
                : dy === 1 && i === 9 && dz % 2 === 0
                  ? carpet0()
                  : dy === 1 && (i === 8 || i === 10) && dz % 4 === 0
                    ? bid('white_carpet', 'red_carpet')
                    : dy === 4 && i === 9 && dz % 8 === 4
                      ? bid('lantern', 'torch')
                      : 0;
            } else if (wallCol && !pass) b = birch;
            else if (wallRow) b = birch;
            else if (pass) b = dy === 1 && i !== 7 ? carpet0() : 0;
            P(x, fy + dy, z, b);
          }
        }
        P(x, y + 14, z, plank);
      }
    }
    // Gable roof across the wing (ridge along Z).
    if (inChunk(xa, p.z - 27, xb, p.z + 27)) {
      for (let r = 0; r <= 8; r++) {
        for (const [x, face] of [[ix(1 + r), wing > 0 ? 1 : 3], [ix(17 - r), wing > 0 ? 3 : 1]] as const) {
          if (ox !== undefined && oz !== undefined && (x < ox - 1 || x > ox + 17)) continue;
          for (let z = p.z - 27; z <= p.z + 27; z++) {
            if (oz !== undefined && (z < oz - 1 || z > oz + 17)) continue;
            P(x, y + 15 + r, z, r === 8 ? log : cell('dark_oak_stairs', stairsUp(face), 'oak_planks'));
            if (r < 8 && Math.abs(z - p.z) >= 26) for (let yy = y + 15; yy < y + 15 + r; yy++) P(x, yy, z, plank);
          }
        }
      }
    }
    // Staircase tower in the corridor: lane A (i = 8) climbs ground → first floor, lane C (i = 10) first → second floor.
    const zs = p.z + 14;
    for (const [k, i] of [[0, 8], [1, 10]] as const) {
      const x = ix(i);
      if (ox !== undefined && (x < ox - 1 || x > ox + 17)) continue;
      for (let s = 0; s < 5; s++) {
        const base = y + k * 5, z = zs + s;
        if (oz !== undefined && (z < oz - 1 || z > oz + 17)) continue;
        for (let yy = base; yy < base + s; yy++) P(x, yy, z, plank);
        P(x, base + s, z, cell('dark_oak_stairs', stairsUp(2), 'oak_planks'));
        for (let yy = base + s + 1; yy <= base + 7; yy++) P(x, yy, z, 0);
      }
    }
    // Front door at the north end of the corridor: opening and a stepped landing down to the ground.
    for (let i = 8; i <= 10; i++) {
      const x = ix(i), z = p.z - 26;
      if ((ox !== undefined && (x < ox - 1 || x > ox + 17)) || (oz !== undefined && (z - 3 > oz + 17 || z < oz - 1))) continue;
      for (let dy = 0; dy <= 2; dy++) P(x, y + dy, z, 0);
      for (let n = 1; n <= 3; n++) {
        const g = t.height(x, z - n);
        for (let yy = g + 1; yy <= y - 1; yy++) P(x, yy, z - n, cob);
        P(x, y - 1, z - n, cob);
        for (let dy = 0; dy <= 2; dy++) P(x, y + dy, z - n, 0);
      }
    }
  }

  // ---- MansionGrid Asymmetric Exterior Bay Extensions (Full 3-Storey + Pitched Roof Gables + Foundation) ----
  const mGrid = mansionGridFor(t.seed, p);
  for (const wing of [1, -1] as const) {
    for (let gy = 2; gy <= 8; gy++) {
      const gx = wing > 0 ? 9 : 4;
      const cellVal = mGrid.floorRooms[0].get(gx, gy) | mGrid.floorRooms[1].get(gx, gy);
      if (gy !== 5 && (cellVal & 0xffff) === 0 && mGrid.baseGrid.get(7, gy) !== GRID_ROOM) continue;
      const has3F = (mGrid.floorRooms[2].get(gx, gy) & 0xffff) !== 0 || (mGrid.thirdFloorGrid.get(gx, gy) === GRID_ROOM);
      const topFloors = has3F ? 3 : 2;
      const extBaseX = wing > 0 ? X1 + 18 : X0 - 18;
      const extZ = p.z + (gy - 5) * 6 + ((cellVal & 3) - 1);
      if (!inChunk(extBaseX - 3, extZ - 3, extBaseX + 3, extZ + 3)) continue;
      const stairDir = wing > 0 ? 3 : 1;
      for (let bx = 0; bx <= 1; bx++) {
        const extX = extBaseX + wing * bx;
        const outerFace = bx === 1;
        for (let dz = -1; dz <= 1; dz++) {
          const z = extZ + dz;
          if ((ox !== undefined && (extX < ox - 1 || extX > ox + 17)) || (oz !== undefined && (z < oz - 1 || z > oz + 17))) continue;
          const g = t.height(extX, z);
          for (let yy = g + 1; yy <= y - 1; yy++) P(extX, yy, z, cob);
          P(extX, y, z, cob);
          const sideWall = Math.abs(dz) === 1;
          for (let fl = 0; fl < topFloors; fl++) {
            const fy = y + fl * 5;
            if (fl > 0) P(extX, fy, z, plank);
            if (outerFace || sideWall) {
              P(extX, fy + 1, z, outerFace && sideWall ? log : plank);
              P(extX, fy + 2, z, outerFace && sideWall ? log : cell('glass_pane', outerFace ? PANE_Z : PANE_X, 'glass'));
              P(extX, fy + 3, z, plank);
            }
            P(extX, fy + 4, z, fl === topFloors - 1 ? cell('dark_oak_stairs', stairsUp(stairDir), 'oak_planks') : plank);
          }
          const roofBase = y + topFloors * 5;
          P(extX, roofBase, z, sideWall ? cell('dark_oak_stairs', stairsUp(dz < 0 ? 0 : 2), 'oak_planks') : plank);
          if (dz === 0) P(extX, roofBase + 1, z, bid('dark_oak_slab', 'oak_slab'));
        }
      }
    }
  }

  // ---- Rooms ----
  for (const r of rooms) {
    if (!inChunk(r.x0 - 1, r.z0 - 1, r.x1 + 1, r.z1 + 1)) continue;
    const Y = r.y, away = (r.toCorridor + 2) & 3;
    // Doorway into the corridor (omitted for secret rooms so their corridor wall stays completely sealed!).
    if (!r.secret) {
      if (!r.secret) { for (let dy = 0; dy <= 1; dy++) { P(r.doorX, Y + dy, r.doorZ, 0); } }
    }
    const near = r.toCorridor === 1 ? r.x1 : r.x0, step = r.toCorridor === 1 ? -1 : 1;
    const U = (u: number) => near + step * u;
    const V = (v: number) => r.z0 + v;
    const R = (u: number, dy: number, v: number, b: number) => P(U(u), Y + dy, V(v), b);
    const sx = (u: number, dy: number, v: number) => [U(u), Y + dy, V(v)] as const;
    P(near, Y + 2, r.doorZ + 1, cell('torch', attachOn(r.toCorridor)));
    furnishVanillaMansionRoom(t, put, r, R, sx, P);
    void away;
  }
  void fill; void tag; void doorOn; void hash2;
  return rooms;
  function carpet0() { return bid('red_carpet', 'air'); }
}


export function buildMansionRoom(
  t: StructHost,
  put: Put,
  template: MansionTemplate,
  x0: number,
  y: number,
  z0: number,
  w = 7,
  d = 7,
  _h = 7,
  _dir = "S"
) {
  const r: WingRoom = {
    wing: 1,
    floor: template.includes("_c") || template.includes("_d") || template.startsWith("1x1_b") || template.startsWith("2x2_b") ? 1 : 0,
    column: 0,
    x0,
    x1: x0 + w - 1,
    z0,
    z1: z0 + d - 1,
    y,
    doorX: x0,
    doorZ: z0 + (d >> 1),
    toCorridor: 3,
    type: TEMPLATE_TO_LEGACY_TYPE[template],
    template,
    secret: template.includes("_s") || template.includes("_as") || template.includes("_se"),
    gridSize: template.startsWith("2x2_") ? "2x2" : template.startsWith("1x2_") ? "1x2" : "1x1",
  };
  const P = (x: number, yy: number, z: number, b: number) => put(x, yy, z, b, true);
  const R = (u: number, dy: number, v: number, b: number) => P(x0 + u, y + dy, z0 + v, b);
  const sx = (u: number, dy: number, v: number) => [x0 + u, y + dy, z0 + v] as const;
  furnishVanillaMansionRoom(t, put, r, R, sx, P);
}

export function mansionGrandLayout(seed: number, x: number, y: number, z: number) {
  const rooms = mansionWingRooms(seed, { x, y, z });
  const mobs: { species: string; x: number; y: number; z: number }[] = [];
  for (const r of rooms) {
    const cx = (r.x0 + r.x1) >> 1, cz = (r.z0 + r.z1) >> 1, y1 = r.y + 1;
    switch (r.template) {
      case "1x2_a1":
      case "1x2_a3":
      case "1x2_a8":
      case "1x2_a9":
      case "1x2_b1":
      case "1x2_b2":
      case "1x2_b3":
      case "2x2_a2":
        mobs.push({ species: "vindicator", x: cx, y: y1, z: cz });
        break;
      case "1x2_c2":
        mobs.push({ species: "vindicator", x: cx, y: y1, z: cz - 1 }, { species: "vindicator", x: cx, y: y1, z: cz + 1 });
        break;
      case "1x2_c3":
        mobs.push(
          { species: "vindicator", x: cx, y: y1, z: cz - 1 },
          { species: "vindicator", x: cx, y: y1, z: cz },
          { species: "vindicator", x: cx, y: y1, z: cz + 1 },
        );
        break;
      case "1x2_d3":
      case "2x2_b1":
        mobs.push(
          { species: "evoker", x: cx, y: y1, z: cz },
          { species: "vindicator", x: cx, y: y1, z: cz - 1 },
          { species: "vindicator", x: cx, y: y1, z: cz + 1 },
        );
        break;
      case "2x2_a1":
        mobs.push(
          { species: "vindicator", x: cx, y: y1, z: cz },
          { species: "allay", x: cx, y: y1, z: r.z0 + 1 },
          { species: "allay", x: cx, y: y1, z: Math.max(r.z0 + 1, r.z1 - 1) },
        );
        break;
      case "2x2_b2":
        mobs.push(
          { species: "evoker", x: cx, y: y1, z: cz },
          { species: "vindicator", x: cx - 1, y: y1, z: cz - 1 },
          { species: "vindicator", x: cx - 1, y: y1, z: cz + 1 },
          { species: "vindicator", x: cx + 1, y: y1, z: cz - 1 },
          { species: "vindicator", x: cx + 1, y: y1, z: cz + 1 },
          { species: "vindicator", x: cx, y: y1, z: cz - 2 },
        );
        break;
      case "2x2_b4":
        mobs.push(
          { species: "evoker", x: cx, y: y1, z: cz },
          { species: "vindicator", x: cx - 1, y: y1, z: cz },
          { species: "vindicator", x: cx + 1, y: y1, z: cz },
          { species: "vindicator", x: cx, y: y1, z: cz + 1 },
        );
        break;
    }
  }
  return { rooms, mobs };
}
