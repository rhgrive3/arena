// Nether fortress (Minecraft Wiki "Nether Fortress/Structure" / Java Edition `NetherFortressPieces`) & Nether Fossils (`NetherFossilFeature`):
//  * Starts at a plain 4-way Bridge Crossing (`hub`) and divides into an Exterior Area of open bridges and an Interior Area of
//    enclosed corridors joined by the 13×14×13 Lava Well Room (`lava_well` / `CastleEntrance`):
//  * Exterior Bridge Area:
//      - `bridge_9`, `bridge_13`, `bridge_19` (`BridgeStraight`): 3-wide open walkways with underside arch ribs and lava-floor pillars.
//      - `bridge_ruined` (`BridgeEndFiller`, max 4): procedurally collapsed broken bridge ends.
//      - `bridge_open_crossing` (`BridgeOpenIntersection`, max 5): plain 4-way open bridge crossings.
//      - `bridge_crossing` (`BridgeClosedIntersection`, max 4): enclosed 4-way crossings with nether brick & fence arches.
//      - `bridge_stairs` (`BridgeStaircase`, max 4): exterior stair room with full-block steps ascending to the roof path.
//      - `blaze_hall` (`MonsterThrone` / `BlazeSpawner`, max 2): 3 steps leading to a fenced Blaze Spawner platform.
//  * Transition Hub:
//      - `lava_well` (`CastleEntrance` / `LavaWellRoom`, 13×11×13, max 2): links bridges and corridors around a fenced indoor lava well.
//  * Interior Corridor Area (1×2 `nether_bricks_fence` windows & fence-gate-framed entrances):
//      - `corridor` (`StraightCorridor`): enclosed corridor with ceiling ribs and 1×2 fence windows.
//      - `corridor_crossing` (`CorridorIntersection`, max 5): 4-way enclosed corridor intersection.
//      - `turn_l` (max 10) & `turn_r` (max 10) (`CurvedCorridor` — up to 20 total), each with a 1/3 chance of a corner loot chest.
//      - `stairs` (`CorridorStaircase`, max 3): enclosed staircase built of actual `nether_brick_stairs` blocks.
//      - `balcony` (`CorridorBalcony`, max 2): 3-way corridor intersection with an exterior fenced observation balcony.
//      - `wart_room` (`CastleStalkRoom` / `NetherWartFarm`, max 2): central `nether_brick_stairs` stairway flanked on both sides by
//        two 2×5 rows of Soul Sand with Nether Wart growing on it, an upper landing exit, and a rear corridor with a chest.
//      - `throne_crossing` (`CastleCrossing`, max 2): two-storey pillared castle hall with four 2×2 columns and upper gallery.
//  * Nether Fossils: 14 distinct bone-block fossil templates (`fossil_1`..`fossil_14`) with 4-way rotation for Soul Sand Valleys.
import { type Put, type StructHost, bid, cell, hash2, hash3, stairsUp, tag, mulberry } from './common';
import { growJigsaw, rotSize, toWorld, worldDir, boxesOverlap, type Box, type Connector, type PieceDef, type Placed, type Pool } from './jigsaw';
import { chest, brewing } from './decor';

/** Vanilla fortresses hang 48–70 blocks up over the lava sea (Y 31). */
export const FORTRESS_Y = 48, FORTRESS_LAVA = 31, FORTRESS_RADIUS = 84;
const c = (x: number, y: number, z: number, dir: number, pool = 'any'): Connector => ({ x, y, z, dir, name: 'path', target: 'path', pool });
const def = (id: string, kind: string, size: [number, number, number], connectors: Connector[], max?: number): PieceDef => ({ id, kind, size, connectors, max });
const straight = (id: string, kind: string, w: number, h: number, l: number, max?: number) => def(id, kind, [w, h, l], [c(w >> 1, 0, 0, 0), c(w >> 1, 0, l - 1, 2)], max);

const BRIDGES = [9, 13, 19].map(l => straight('bridge_' + l, 'bridge', 5, 5, l));
const BRIDGE_RUINED = def('bridge_ruined', 'bridge', [5, 5, 9], [c(2, 0, 0, 0)], 4);
const BRIDGE_OPEN_CROSSING = def('bridge_open_crossing', 'bridge_open_crossing', [7, 5, 7], [c(3, 0, 0, 0), c(6, 0, 3, 1), c(3, 0, 6, 2), c(0, 0, 3, 3)], 7);
const BRIDGE_CROSSING = def('bridge_crossing', 'bridge_crossing', [7, 8, 7], [c(3, 0, 0, 0), c(6, 0, 3, 1), c(3, 0, 6, 2), c(0, 0, 3, 3)], 6);
const BRIDGE_STAIRS = def('bridge_stairs', 'bridge_stairs', [7, 9, 7], [c(3, 0, 0, 0), c(3, 4, 6, 2)], 4);
const HALL = straight('blaze_hall', 'blaze_hall', 7, 9, 31, 2);
const CORR = straight('corridor', 'corridor', 5, 6, 9);
const CORR_CROSS = def('corridor_crossing', 'corridor', [5, 6, 5], [c(2, 0, 0, 0), c(4, 0, 2, 1), c(2, 0, 4, 2), c(0, 0, 2, 3)], 7);
const TURN_L = def('turn_l', 'turn', [5, 6, 5], [c(2, 0, 0, 0), c(0, 0, 2, 3)], 10);
const TURN_R = def('turn_r', 'turn', [5, 6, 5], [c(2, 0, 0, 0), c(4, 0, 2, 1)], 10);
const STAIRS = def('stairs', 'stairs', [5, 10, 9], [c(2, 0, 0, 0), c(2, 4, 8, 2)], 5);
const LAVA_WELL = def('lava_well', 'lava_well', [13, 11, 13], [c(6, 0, 0, 0), c(12, 0, 6, 1), c(6, 0, 12, 2), c(0, 0, 6, 3)], 3);
const WART = def('wart_room', 'wart', [13, 10, 13], [c(6, 0, 0, 0), c(6, 0, 12, 2), c(0, 0, 6, 3), c(12, 0, 6, 1)], 3);
const BALCONY = def('balcony', 'balcony', [9, 7, 9], [c(4, 0, 0, 0), c(0, 0, 4, 3), c(8, 0, 4, 1)], 2);
const THRONE_CROSSING = def('throne_crossing', 'throne_crossing', [11, 9, 11], [c(5, 0, 0, 0), c(10, 0, 5, 1), c(5, 0, 10, 2), c(0, 0, 5, 3)], 2);
const CAP = def('cap', 'cap', [5, 7, 5], [c(2, 0, 0, 0)]);

const POOLS: Record<string, Pool> = {
  any: {
    entries: [
      ...BRIDGES.map((d, i) => ({ def: d, weight: [9, 9, 6][i] })),
      { def: BRIDGE_RUINED, weight: 3 },
      { def: BRIDGE_OPEN_CROSSING, weight: 4 },
      { def: BRIDGE_CROSSING, weight: 4 },
      { def: BRIDGE_STAIRS, weight: 3 },
      { def: CORR, weight: 8 },
      { def: CORR_CROSS, weight: 5 },
      { def: TURN_L, weight: 6 },
      { def: TURN_R, weight: 6 },
      { def: STAIRS, weight: 4 },
      { def: HALL, weight: 6 },
      { def: LAVA_WELL, weight: 5 },
      { def: WART, weight: 5 },
      { def: BALCONY, weight: 4 },
      { def: THRONE_CROSSING, weight: 3 },
    ],
    fallback: 'caps',
  },
  caps: { entries: [{ def: CAP, weight: 1 }] },
};

export const FORTRESS_PIECE_KINDS = [
  'bridge', 'bridge_open_crossing', 'bridge_crossing', 'bridge_stairs', 'blaze_hall',
  'lava_well', 'corridor', 'turn', 'stairs', 'wart', 'balcony', 'throne_crossing', 'cap',
] as const;

export interface FortressLayout {
  cx: number;
  cz: number;
  pieces: Placed[];
  hub: Box;
  spawners: [number, number, number][];
}

const LAYOUTS = new Map<string, FortressLayout>();
const world = (p: Placed, lx: number, ly: number, lz: number) => toWorld(p, lx, ly, lz);

export function fortressLayout(seed: number, cx: number, cz: number): FortressLayout {
  const key = seed + ':' + cx + ',' + cz, hit = LAYOUTS.get(key);
  if (hit) return hit;
  const Y = FORTRESS_Y, hub: Box = [cx - 4, Y, cz - 4, cx + 4, Y + 5, cz + 4];
  let best: Placed[] = [], bestScore = -1;
  for (let k = 0; k < 20; k++) {
    const pieces = growJigsaw({
      seed: (Math.imul(seed | 0, 2654435761) ^ Math.imul(cx, 40503) ^ Math.imul(cz, 65599)) + k * 7919,
      pools: POOLS,
      occupied: [hub],
      maxDepth: 13,
      maxPieces: 76,
      roots: [
        { x: cx, y: Y, z: cz - 4, dir: 0, target: 'path', pool: 'any' },
        { x: cx + 4, y: Y, z: cz, dir: 1, target: 'path', pool: 'any' },
        { x: cx, y: Y, z: cz + 4, dir: 2, target: 'path', pool: 'any' },
        { x: cx - 4, y: Y, z: cz, dir: 3, target: 'path', pool: 'any' },
      ],
      bounds: { cx, cz, r: FORTRESS_RADIUS, y0: Y - 8, y1: Y + 18 },
    });
    const hasBridge = pieces.some(p => p.def.kind === 'bridge') ? 25 : 0;
    const hasWart = pieces.some(p => p.def.kind === 'wart') ? 25 : 0;
    const hasWell = pieces.some(p => p.def.kind === 'lava_well') ? 18 : 0;
    const hasBalcony = pieces.some(p => p.def.kind === 'balcony' || p.def.kind === 'throne_crossing') ? 10 : 0;
    const kindVariety = new Set(pieces.map(p => p.def.kind)).size * 4;
    const score =
      pieces.filter(p => p.def.kind === 'blaze_hall').length * 40 +
      pieces.length +
      hasBridge +
      hasWart +
      hasWell +
      hasBalcony +
      kindVariety;
    if (score > bestScore) { best = pieces; bestScore = score; }
    if (bestScore >= 210 && hasBridge && hasWart && hasWell && pieces.some(p => p.def.kind === 'blaze_hall')) break;
  }
  const spawners = best.filter(p => p.def.kind === 'blaze_hall').map(p => world(p, 3, 3, 22));
  const L = { cx, cz, pieces: best, hub, spawners };
  if (LAYOUTS.size > 16) LAYOUTS.clear();
  LAYOUTS.set(key, L);
  return L;
}

/** Builds the fortress around (cx, cz); with (ox, oz) only what touches that chunk. */
export function netherFortress(t: StructHost, put: Put, cx: number, cz: number, ox?: number, oz?: number) {
  const L = fortressLayout(t.seed, cx, cz);
  const NB = bid('nether_bricks');
  const CRNB = bid('cracked_nether_bricks', 'nether_bricks');
  const RNB = bid('red_nether_bricks', 'nether_bricks');
  const FE = bid('nether_bricks_fence', 'nether_bricks');
  const AIR = 0;
  const lava = bid('lava');
  const Y = FORTRESS_Y;
  const near = (b: Box) => ox === undefined || oz === undefined || !(b[3] < ox - 1 || b[0] > ox + 17 || b[5] < oz - 1 || b[2] > oz + 17);
  const stairs = (dir: number, upsideDown = false) => cell('nether_brick_stairs', stairsUp(dir, upsideDown), 'nether_bricks');
  const slab = bid('nether_brick_slab', 'nether_bricks');
  const brickAt = (x: number, y: number, z: number) => {
    const r = hash3(x, y, z, t.seed + 5501);
    return r < 0.08 ? CRNB : r < 0.12 ? RNB : NB;
  };

  /** Lava lake under a footprint (pad 2): excavated down to the lava level, pillars every 6 blocks. */
  const lake = (b: Box, pillars: boolean) => {
    for (let z = oz === undefined ? b[2] - 2 : Math.max(b[2] - 2, oz - 1); z <= (oz === undefined ? b[5] + 2 : Math.min(b[5] + 2, oz + 17)); z++) {
      for (let x = ox === undefined ? b[0] - 2 : Math.max(b[0] - 2, ox - 1); x <= (ox === undefined ? b[3] + 2 : Math.min(b[3] + 2, ox + 17)); x++) {
        for (let y = FORTRESS_LAVA + 1; y < b[1]; y++) put(x, y, z, AIR, true);
        put(x, FORTRESS_LAVA, z, lava, true);
        put(x, FORTRESS_LAVA - 1, z, lava, true);
        if (pillars && (x - b[0]) % 6 === 0 && (z - b[2]) % 6 === 0 && x >= b[0] && x <= b[3] && z >= b[2] && z <= b[5]) {
          for (let y = FORTRESS_LAVA - 2; y < b[1]; y++) put(x, y, z, NB, true);
        }
      }
    }
  };

  // Central plaza (`BridgeCrossing`): 9×9 plain four-way bridge crossing with corner posts and fence parapets.
  if (near(L.hub)) {
    lake(L.hub, true);
    for (let z = L.hub[2]; z <= L.hub[5]; z++) for (let x = L.hub[0]; x <= L.hub[3]; x++) {
      const edge = x === L.hub[0] || x === L.hub[3] || z === L.hub[2] || z === L.hub[5];
      const corner = (x === L.hub[0] || x === L.hub[3]) && (z === L.hub[2] || z === L.hub[5]);
      const gap = Math.abs(x - cx) <= 1 || Math.abs(z - cz) <= 1;
      put(x, Y, z, NB, true);
      for (let dy = 1; dy <= 5; dy++) {
        const b = corner && dy <= 3 ? NB : corner && dy === 4 ? slab : edge && dy === 1 && !(gap && edge) ? FE : AIR;
        put(x, Y + dy, z, b, true);
      }
    }
    for (let dy = 1; dy <= 3; dy++) put(cx, Y + dy, cz, dy === 3 ? FE : NB, true);
  }

  for (const p of L.pieces) {
    if (!near(p.box)) continue;
    const [w, h, l] = p.def.size, kind = p.def.kind;
    const P = (lx: number, ly: number, lz: number, b: number) => {
      const [x, y, z] = world(p, lx, ly, lz);
      put(x, y, z, b, true);
    };
    const PB = (lx: number, ly: number, lz: number) => {
      const [x, y, z] = world(p, lx, ly, lz);
      put(x, y, z, brickAt(x, y, z), true);
    };
    const used = new Set<number>([p.entry]);
    for (const q of L.pieces) if (q.parent >= 0 && L.pieces[q.parent] === p) used.add(q.parentConn);

    lake(p.box, kind === 'bridge' || kind === 'bridge_open_crossing' || kind === 'bridge_crossing' || kind === 'bridge_stairs' || kind === 'blaze_hall' || kind === 'wart' || kind === 'lava_well' || kind === 'throne_crossing');
    const open = kind === 'bridge' || kind === 'bridge_open_crossing';

    if (p.def.id === 'bridge_ruined') {
      // Vanilla BridgeEndFiller: each column across X breaks off at a seed-determined length (4..8) and drops 1..2 blocks at the tip
      const rnd = mulberry((t.seed ^ Math.imul(p.bx, 73856093) ^ Math.imul(p.bz, 19349663)) >>> 0);
      const colLen = Array.from({ length: w }, () => 4 + Math.floor(rnd() * (l - 4)));
      for (let lx = 0; lx < w; lx++) {
        const maxLz = colLen[lx];
        const edge = lx === 0 || lx === w - 1;
        for (let lz = 0; lz < l; lz++) {
          for (let ly = 0; ly < h; ly++) P(lx, ly, lz, AIR);
          if (lz <= maxLz) {
            P(lx, 0, lz, lz === maxLz && rnd() < 0.5 ? CRNB : NB);
            if (edge && lz < maxLz) {
              P(lx, 1, lz, lz % 4 === 0 ? NB : FE);
              if (lz % 4 === 0) P(lx, 2, lz, slab);
            }
            if (lz === maxLz && rnd() < 0.65) {
              const [wx, wy, wz] = world(p, lx, -1, lz);
              put(wx, wy, wz, CRNB, true);
            }
          }
        }
      }
      continue;
    }

    for (let lz = 0; lz < l; lz++) for (let lx = 0; lx < w; lx++) for (let ly = 0; ly < h; ly++) {
      const edge = lx === 0 || lx === w - 1, end = lz === 0 || lz === l - 1;
      let b = AIR;
      if (ly === 0) b = NB;
      else if (open) {
        b = edge && ly === 1 ? ((lz % 6 === 0) ? NB : FE) : edge && ly === 2 && lz % 6 === 0 ? NB : AIR;
      } else if (ly === h - 1 && kind !== 'stairs' && kind !== 'bridge_stairs' && kind !== 'balcony') {
        b = NB;
      } else if ((kind !== 'stairs' && kind !== 'bridge_stairs') || ly <= h - 2) {
        if (edge) {
          // Vanilla 1×2 `nether_bricks_fence` windows along enclosed corridor walls
          b = ly >= 2 && ly <= 3 && lz % 4 === 2 && kind !== 'cap' ? FE : NB;
        } else if (end && ly <= 4) b = AIR;
        else if (end) b = NB;
      }
      P(lx, ly, lz, b);
    }

    // Seal unused connectors on enclosed pieces and open used archways with fence-gate-style side frames.
    if (!open) {
      p.def.connectors.forEach((cn, i) => {
        for (let k = -1; k <= 1; k++) for (let ly = 1; ly <= 3; ly++) {
          const lx = cn.dir === 0 || cn.dir === 2 ? cn.x + k : cn.x;
          const lz = cn.dir === 0 || cn.dir === 2 ? cn.z : cn.z + k;
          const isGateFrame = used.has(i) && Math.abs(k) === 1 && ly === 3 && (kind === 'corridor' || kind === 'turn');
          P(lx, cn.y + ly, lz, used.has(i) ? (isGateFrame ? FE : AIR) : NB);
        }
      });
    }

    switch (kind) {
      case 'bridge': {
        for (const lx of [0, w - 1]) {
          P(lx, 0, 1, stairs(worldDir(p, 2), true));
          P(lx, 0, l - 2, stairs(worldDir(p, 0), true));
        }
        if (hash2(p.bx, p.bz, t.seed + 91) < 0.35) {
          const [x, y, z] = world(p, 2, 1, p.def.size[2] >> 1);
          put(x, y, z, bid('nether_wart', 'air'), true);
          put(x, y - 1, z, bid('soul_sand'), true);
        }
        break;
      }

      case 'bridge_open_crossing': {
        // Vanilla BridgeOpenIntersection (7×5×7): open 4-way crossing with corner fence posts and open 3-wide exits
        for (let lz = 0; lz < l; lz++) for (let lx = 0; lx < w; lx++) {
          const rim = lx === 0 || lx === w - 1 || lz === 0 || lz === l - 1;
          const corner = (lx === 0 || lx === w - 1) && (lz === 0 || lz === l - 1);
          const exitGap = Math.abs(lx - 3) <= 1 || Math.abs(lz - 3) <= 1;
          if (corner) { P(lx, 1, lz, NB); P(lx, 2, lz, FE); }
          else if (rim && !exitGap) P(lx, 1, lz, FE);
          else P(lx, 1, lz, AIR);
        }
        break;
      }

      case 'bridge_crossing': {
        // Vanilla BridgeClosedIntersection (7×8×7): enclosed 4-way crossing with arches of nether brick & nether brick fences
        for (const lx of [1, 5]) for (const lz of [1, 5]) for (let ly = 1; ly <= h - 2; ly++) PB(lx, ly, lz);
        for (let lx = 0; lx < w; lx++) for (let lz = 0; lz < l; lz++) {
          const rim = lx === 0 || lx === w - 1 || lz === 0 || lz === l - 1;
          if (rim) P(lx, h - 1, lz, (lx + lz) % 2 === 0 ? NB : FE);
          else P(lx, h - 2, lz, NB);
        }
        P(3, 1, 3, slab);
        break;
      }

      case 'bridge_stairs': {
        // Vanilla BridgeStaircase (7×9×7): small exterior stair room with full-block nether brick steps leading to the roof path
        for (let step = 1; step <= 4; step++) {
          const lz = 1 + step;
          for (let lx = 2; lx <= 4; lx++) {
            for (let ly = 1; ly <= step; ly++) P(lx, ly, lz, NB);
            for (let ly = step + 1; ly <= 7; ly++) P(lx, ly, lz, AIR);
          }
        }
        for (let lx = 0; lx < w; lx++) for (let lz = 0; lz < l; lz++) {
          const rim = lx === 0 || lx === w - 1 || lz === 0 || lz === l - 1;
          if (rim && !(lz === 6 && lx >= 2 && lx <= 4)) P(lx, 5, lz, FE);
        }
        break;
      }

      case 'corridor': {
        if (p.def.id === 'corridor_crossing') {
          for (const [lx, lz] of [[1, 1], [3, 1], [1, 3], [3, 3]]) for (let ly = 1; ly <= 4; ly++) PB(lx, ly, lz);
          P(2, 4, 2, slab);
        } else {
          for (const lz of [2, 6]) {
            P(1, 4, lz, stairs(worldDir(p, 3), true));
            P(3, 4, lz, stairs(worldDir(p, 1), true));
            P(2, 4, lz, slab);
          }
        }
        break;
      }

      case 'turn': {
        // Vanilla CastleSmallCorridorLeftTurnPiece / RightTurnPiece: 1/3 chance of an interior loot chest in the outer corner
        const isLeft = p.def.id === 'turn_l';
        for (let ly = 1; ly <= 4; ly++) PB(isLeft ? 3 : 1, ly, 3);
        if (hash2(p.bx, p.bz, t.seed + 303) < (1 / 3)) {
          const cxLocal = isLeft ? 3 : 1;
          const faceLocal = isLeft ? 3 : 1;
          const [x, y, z] = world(p, cxLocal, 1, 2);
          chest(put, t, x, y, z, worldDir(p, faceLocal), 'nether_fortress_bridge');
        }
        break;
      }

      case 'stairs': {
        // Vanilla CorridorStaircase: actual `nether_brick_stairs` blocks ascending between corridor levels
        for (let k = 1; k <= 4; k++) for (let lx = 1; lx <= 3; lx++) {
          for (let ly = 0; ly < k; ly++) P(lx, ly, k, NB);
          P(lx, k, k, stairs(worldDir(p, 2)));
        }
        for (let lz = 5; lz <= 8; lz++) for (let lx = 0; lx < w; lx++) P(lx, 4, lz, NB);
        for (let lz = 5; lz <= 7; lz++) for (let lx = 1; lx <= 3; lx++) for (let ly = 5; ly <= 8; ly++) P(lx, ly, lz, AIR);
        for (let lz = 1; lz <= 8; lz++) for (const lx of [0, 4]) for (let ly = 1; ly <= 9; ly++) P(lx, ly, lz, NB);
        for (let lz = 0; lz < l; lz++) for (let lx = 0; lx < w; lx++) P(lx, 9, lz, NB);
        for (let lz = 5; lz <= 7; lz++) for (let lx = 1; lx <= 3; lx++) for (let ly = 5; ly <= 8; ly++) P(lx, ly, lz, AIR);
        for (let k = 1; k <= 4; k++) for (let lx = 1; lx <= 3; lx++) for (let ly = k + 1; ly <= 8; ly++) P(lx, ly, k, AIR);
        break;
      }

      case 'blaze_hall': {
        for (const lz of [4, 10, 16]) for (let ly = 1; ly <= 5; ly++) { P(1, ly, lz, NB); P(5, ly, lz, NB); }
        for (let lx = 1; lx <= 5; lx++) { P(lx, 1, 18, stairs(worldDir(p, 2))); P(lx, 2, 19, stairs(worldDir(p, 2))); }
        for (let lz = 20; lz <= 26; lz++) for (let lx = 1; lx <= 5; lx++) { P(lx, 1, lz, NB); P(lx, 2, lz, NB); }
        for (let lz = 19; lz <= 19; lz++) for (let lx = 1; lx <= 5; lx++) P(lx, 1, lz, NB);
        // Vanilla MonsterThrone: fenced parapet & corner posts around the elevated Blaze Spawner platform
        for (let lz = 20; lz <= 26; lz++) for (const lx of [1, 5]) P(lx, 3, lz, lz === 20 || lz === 26 ? NB : FE);
        P(3, 3, 22, bid('spawner', 'nether_bricks'));                                             // blaze spawner
        for (const [lx, lz] of [[2, 21], [3, 21], [4, 21], [2, 22], [4, 22], [2, 23], [3, 23], [4, 23]]) { P(lx, 3, lz, FE); P(lx, 4, lz, FE); }
        { const [x, y, z] = world(p, 1, 3, 25); chest(put, t, x, y, z, worldDir(p, 1), 'nether_fortress_bridge'); }
        { const [x, y, z] = world(p, 5, 3, 25); chest(put, t, x, y, z, worldDir(p, 3), 'nether_fortress_bridge'); }
        { const [x, y, z] = world(p, 3, 3, 26); brewing(put, t, x, y, z, 'fortress_brewing'); }
        break;
      }

      case 'lava_well': {
        // Vanilla CastleEntrance (13×11×13): joins the exterior bridge and interior corridor areas around an indoor
        // lava well surrounded by nether brick fences with a central lava stream pouring from the ceiling basin.
        for (const lx of [2, 10]) for (const lz of [2, 10]) for (let ly = 1; ly <= h - 2; ly++) PB(lx, ly, lz);
        for (let lz = 4; lz <= 8; lz++) for (let lx = 4; lx <= 8; lx++) {
          const rim = lx === 4 || lx === 8 || lz === 4 || lz === 8;
          const inner = lx >= 5 && lx <= 7 && lz >= 5 && lz <= 7;
          if (rim) {
            P(lx, 1, lz, NB);
            P(lx, 2, lz, (lx === 4 || lx === 8) && (lz === 4 || lz === 8) ? NB : FE);
            P(lx, 3, lz, (lx === 4 || lx === 8) && (lz === 4 || lz === 8) ? NB : FE);
          } else if (inner) {
            P(lx, 1, lz, lava);
          }
        }
        for (let ly = 2; ly <= h - 2; ly++) P(6, ly, 6, lava);
        for (let lz = 5; lz <= 7; lz++) for (let lx = 5; lx <= 7; lx++) {
          P(lx, h - 2, lz, lx === 6 && lz === 6 ? lava : NB);
        }
        for (const cPos of [3, 6, 9]) for (let ly = 5; ly <= h - 3; ly++) {
          P(0, ly, cPos, FE); P(12, ly, cPos, FE);
          P(cPos, ly, 0, FE); P(cPos, ly, 12, FE);
        }
        break;
      }

      case 'wart': {
        // Vanilla CastleStalkRoom (13×10×13): Two recessed 2×5 (and extended 2×7) Soul Sand + Nether Wart beds flanking
        // a central 3-wide `nether_brick_stairs` staircase (lx = 5..7) climbing to an upper 2nd-floor gallery (ly = 4).
        for (const lx of [2, 3, 9, 10]) {
          for (let lz = 3; lz <= 9; lz++) {
            P(lx, 1, lz, bid('soul_sand'));
            P(lx, 2, lz, cell('nether_wart', (lx + lz) & 3, 'air'));
          }
        }
        for (let lz = 2; lz <= 10; lz++) {
          for (const lx of [1, 4, 8, 11]) P(lx, 1, lz, NB);
        }
        for (const lx of [2, 3, 9, 10]) { P(lx, 1, 2, NB); P(lx, 1, 10, NB); }
        for (let step = 0; step < 4; step++) {
          const lz = 3 + step, ly = 1 + step;
          for (let lx = 5; lx <= 7; lx++) {
            for (let fillY = 1; fillY < ly; fillY++) P(lx, fillY, lz, NB);
            P(lx, ly, lz, stairs(worldDir(p, 2)));
          }
        }
        for (let lz = 7; lz <= 11; lz++) for (let lx = 1; lx <= 11; lx++) {
          if (lz >= 8 || (lx >= 4 && lx <= 8)) {
            P(lx, 4, lz, NB);
            if ((lz === 7 && (lx === 4 || lx === 8)) || (lz === 8 && (lx < 4 || lx > 8))) {
              P(lx, 5, lz, FE);
            }
          }
        }
        for (const [lx, lz] of [[4, 3], [8, 3], [4, 9], [8, 9]]) {
          for (let ly = 1; ly <= h - 2; ly++) PB(lx, ly, lz);
        }
        P(6, 1, 8, AIR); P(6, 2, 8, AIR);
        P(6, 1, 11, slab);
        { const [x, y, z] = world(p, 11, 1, 10); chest(put, t, x, y, z, worldDir(p, 3), 'nether_fortress_stairs'); }
        break;
      }

      case 'balcony': {
        // Vanilla CastleCorridorTBalconyPiece (9×7×9): enclosed T-corridor on lz = 0..4, opening onto an exterior
        // observation balcony (lz = 5..8) fenced with `nether_bricks_fence`.
        for (let lz = 5; lz < l; lz++) for (let lx = 0; lx < w; lx++) {
          for (let ly = 1; ly < h; ly++) P(lx, ly, lz, AIR);
          const edge = lx === 0 || lx === w - 1 || lz === l - 1;
          const corner = (lx === 0 || lx === w - 1) && lz === l - 1;
          if (corner) { P(lx, 1, lz, NB); P(lx, 2, lz, FE); P(lx, 3, lz, slab); }
          else if (edge) { P(lx, 1, lz, FE); }
        }
        for (let lx = 0; lx < w; lx++) for (let ly = 1; ly < h - 1; ly++) {
          const arch = lx >= 3 && lx <= 5 && ly <= 3;
          P(lx, ly, 4, arch ? AIR : NB);
        }
        if (hash2(p.bx, p.bz, t.seed + 309) < 0.5) {
          const [x, y, z] = world(p, 1, 1, 3);
          chest(put, t, x, y, z, worldDir(p, 0), 'nether_fortress_bridge');
        }
        break;
      }

      case 'throne_crossing': {
        // Vanilla CastleCrossing (11×9×11): two-storey pillared hall with four 2×2 interior columns and upper gallery
        for (const lx0 of [2, 7]) for (const lz0 of [2, 7]) {
          for (let dx = 0; dx <= 1; dx++) for (let dz = 0; dz <= 1; dz++) {
            for (let ly = 1; ly <= h - 2; ly++) PB(lx0 + dx, ly, lz0 + dz);
          }
        }
        for (let lz = 1; lz <= 9; lz++) for (let lx = 1; lx <= 9; lx++) {
          const outerRing = lx === 1 || lx === 9 || lz === 1 || lz === 9;
          const innerRim = (lx === 2 || lx === 8) && lz >= 2 && lz <= 8 || (lz === 2 || lz === 8) && lx >= 2 && lx <= 8;
          if (outerRing) P(lx, 5, lz, NB);
          else if (innerRim) { P(lx, 5, lz, slab); P(lx, 6, lz, FE); }
        }
        P(5, 1, 5, bid('netherrack'));
        P(5, 2, 5, bid('soul_fire', 'fire'));
        for (const [lx, lz] of [[4, 5], [6, 5], [5, 4], [5, 6]]) P(lx, 1, lz, stairs(worldDir(p, 0)));
        break;
      }

      case 'cap': {
        const [x, y, z] = world(p, 2, 1, 3);
        chest(put, t, x, y, z, worldDir(p, 0), 'nether_fortress_bridge');
        P(1, 2, 3, FE); P(3, 2, 3, FE);
        break;
      }
    }
    void rotSize; void boxesOverlap; void tag;
  }
  return L;
}

// ======================================================================================================================
// Vanilla 14 Nether Fossil Variants (`nether_fossils/fossil_1..14` in Soul Sand Valleys)
// ======================================================================================================================
export const NETHER_FOSSIL_COUNT = 14;

/**
 * Places one of the 14 Vanilla Nether Fossil templates (`variant = 0..13`, rotated by `rot = 0..3`) at `(cx, y, cz)`.
 */
export function netherFossil(put: Put, cx: number, y: number, cz: number, seed: number) {
  const bone = bid('bone_block');
  const coal = bid('coal_block', 'bone_block');
  const v = Math.floor(hash2(cx, cz, seed + 5270) * NETHER_FOSSIL_COUNT) % NETHER_FOSSIL_COUNT;
  const rot = Math.floor(hash2(cx, cz, seed + 5271) * 4) & 3;

  const P = (lx: number, ly: number, lz: number, blk = bone) => {
    const wx = rot === 0 ? cx + lx : rot === 1 ? cx - lz : rot === 2 ? cx - lx : cx + lz;
    const wz = rot === 0 ? cz + lz : rot === 1 ? cz + lx : rot === 2 ? cz - lz : cz - lx;
    put(wx, y + ly, wz, blk, true);
  };

  const ribArch = (lz: number, halfW: number, height: number) => {
    for (let dy = 1; dy <= height; dy++) {
      P(-halfW, dy, lz);
      P(halfW, dy, lz);
    }
    for (let lx = -halfW + 1; lx <= halfW - 1; lx++) {
      P(lx, height + (Math.abs(lx) < halfW - 1 ? 1 : 0), lz);
    }
  };

  switch (v) {
    case 0: // fossil_1: 4-rib thoracic ribcage with dorsal spine
      for (const lz of [-3, -1, 1, 3]) ribArch(lz, 3, 4);
      for (let lz = -3; lz <= 3; lz++) P(0, 5, lz);
      break;
    case 1: // fossil_2: 5-rib tapered leviathan ribcage
      ribArch(-4, 2, 3); ribArch(-2, 3, 4); ribArch(0, 4, 5); ribArch(2, 3, 4); ribArch(4, 2, 3);
      for (let lz = -4; lz <= 4; lz++) P(0, lz === 0 ? 6 : 5, lz);
      break;
    case 2: // fossil_3: Giant horned skull
      for (let lz = -2; lz <= 2; lz++) for (let lx = -2; lx <= 2; lx++) for (let dy = 1; dy <= 3; dy++) {
        if (Math.abs(lx) === 2 || lz === -2 || lz === 2 || dy === 3) P(lx, dy, lz);
      }
      P(-1, 2, -2, 0); P(1, 2, -2, 0); // eye sockets
      for (let d = 1; d <= 2; d++) { P(-2 - d, 3 + d - 1, 0); P(2 + d, 3 + d - 1, 0); } // horns
      break;
    case 3: // fossil_4: Ribcage + skull assembly
      for (const lz of [0, 2, 4]) ribArch(lz, 2, 3);
      for (let lz = 0; lz <= 4; lz++) P(0, 4, lz);
      for (let lx = -1; lx <= 1; lx++) for (let dy = 1; dy <= 3; dy++) { P(lx, dy, -2); P(lx, dy, -3); }
      P(-1, 2, -3, 0); P(1, 2, -3, 0);
      break;
    case 4: // fossil_5: Sunken spine with asymmetric broken ribs
      for (let lz = -4; lz <= 4; lz++) P(0, 1 + (lz & 1), lz);
      for (const lz of [-3, 0, 3]) {
        for (let dy = 1; dy <= 3; dy++) P(-2, dy, lz);
        P(-1, 3, lz);
        for (let dy = 1; dy <= 2; dy++) P(2, dy, lz);
      }
      break;
    case 5: // fossil_6: Tall 3-arch cathedral ribcage with coal marrow
      for (const lz of [-2, 0, 2]) ribArch(lz, 3, 5);
      for (let lz = -2; lz <= 2; lz++) P(0, 6, lz);
      P(0, 1, 0, coal);
      break;
    case 6: // fossil_7: Wide pelvic girdle and tail vertebrae
      ribArch(0, 4, 3); ribArch(1, 4, 3);
      for (let lz = -4; lz <= -1; lz++) P(0, 1 + Math.max(0, 2 + lz), lz);
      break;
    case 7: // fossil_8: Collapsed sideways ribcage
      for (const lz of [-2, 0, 2]) {
        for (let lx = -3; lx <= 1; lx++) P(lx, 1, lz);
        for (let dy = 1; dy <= 3; dy++) P(2, dy, lz);
        P(1, 3, lz);
      }
      break;
    case 8: // fossil_9: Twin interlocking arches
      ribArch(-1, 2, 4); ribArch(1, 3, 3);
      P(0, 4, 0);
      break;
    case 9: // fossil_10: Long serpentine spine with dorsal fins
      for (let lz = -4; lz <= 4; lz++) {
        const lx = Math.round(Math.sin(lz * 0.8));
        P(lx, 1, lz); P(lx, 2, lz);
        if ((lz & 1) === 0) P(lx, 3, lz);
      }
      break;
    case 10: // fossil_11: Buried skull dome with tusks
      for (let lz = -1; lz <= 2; lz++) for (let lx = -2; lx <= 2; lx++) {
        P(lx, 1, lz);
        if (Math.abs(lx) < 2 && lz < 2) P(lx, 2, lz);
      }
      for (let dy = 1; dy <= 3; dy++) { P(-2, dy, -2); P(2, dy, -2); }
      break;
    case 11: // fossil_12: 6-rib compact cage
      for (const lz of [-3, -2, 0, 1, 3]) ribArch(lz, 2, 3);
      for (let lz = -3; lz <= 3; lz++) P(0, 4, lz);
      break;
    case 12: // fossil_13: Jawbone mandibles
      for (let lz = -2; lz <= 2; lz++) {
        P(-2, 1, lz); P(2, 1, lz);
        if ((lz & 1) === 0) { P(-2, 2, lz); P(2, 2, lz); }
      }
      for (let lx = -1; lx <= 1; lx++) P(lx, 1, -2);
      break;
    default: // fossil_14: Ancient rib shrine with coal core
      ribArch(-2, 3, 4); ribArch(0, 3, 5); ribArch(2, 3, 4);
      for (let lz = -2; lz <= 2; lz++) P(0, 5, lz);
      P(0, 1, 0, coal); P(0, 2, 0, bone);
      break;
  }
}
