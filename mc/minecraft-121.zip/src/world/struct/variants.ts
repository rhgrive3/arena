// Room-variant builders for the woodland mansion, the ancient city and the bastion remnant (Minecraft Wiki structure pages).
//  * Woodland mansion – three floors of irregular rooms: neighbouring cells merge at random into 1×1 / 1×2 rooms, rooms are
//    linked by random side doors, and each room draws a type (chest storage, illager jail, cat statue, flower garden, library,
//    bedroom, dining room, smithy, spider room, obsidian vault …).
//  * Ancient city – city centre (city_center_1..3) with the reinforced-deepslate frame, Warden head crest & soul fire braziers,
//    the redstone laboratory hidden below it (multiple circuit stations), two long deepslate-brick colonnades with cross-walkways,
//    barracks with bunk beds, ice box, and Jigsaw-selected peripheral structures (sauna, camp_1..3, tall_ruin_1..4, medium_ruin,
//    entrance_path, sculk_garden, meditation_shrine) with authentic wool sound-dampening runners and sculk infection processor.
//  * Bastion remnant – four variants (treasure room, hoglin stables, bridge, housing units), each assembled procedurally
//    from the canonical Vanilla Jigsaw sub-piece pools (`bastion/treasure/*`, `bastion/hoglin_stable/*`, `bastion/bridge/*`,
//    `bastion/units/*`: `bases/centers/center_0..3`, `starting_pieces/entrance_face`, `bridge_pieces/bridge`, `large_stables/*`,
//    `small_stables/*`, `center_pieces/center_0..2`, `stages/stage_0..3`, and `bastion_remnant_degradation` processors).
import { type Put, type StructHost, bid, cell, fill, shell, hash2, hash3, mulberry, tag, bed, stairsUp, ladderOn, attachOn, doorOn, rsFacing, PANE_X, PANE_Z } from './common';
import { chest as placeChest, lantern as placeLantern, barrel as placeBarrel } from './decor';

interface Site { x: number; y: number; z: number }

// ======================================================================================================================
// Woodland mansion
// ======================================================================================================================
export const MANSION_ROOM_TYPES = ['storage', 'jail', 'cat_statue', 'flower_garden', 'library', 'bedroom', 'dining', 'smithy', 'spider', 'obsidian', 'empty'] as const;
export type MansionRoomType = typeof MANSION_ROOM_TYPES[number];
export interface MansionRoom {
  floor: number; side: -1 | 1; cells: number;
  /** Interior bounds and walking level. */
  x0: number; x1: number; z0: number; z1: number; y: number;
  doorX: number; type: MansionRoomType;
  /** X of the side doors that link this room to the next one on the same floor and side. */
  link: number | null;
}
const CELL_START = [1, 9, 17, 25], CELL_END = [7, 15, 23, 29], CELL_DOOR = [4, 12, 20, 27];
const MANSIONS = new Map<string, MansionRoom[]>();

/** Deterministic room plan of the mansion at `p` (31×21 footprint, three floors, corridor along X). */
export function mansionLayout(seed: number, p: Site): MansionRoom[] {
  const key = seed + ':' + p.x + ',' + p.y + ',' + p.z, hit = MANSIONS.get(key);
  if (hit) return hit;
  const rnd = mulberry((Math.imul(seed | 0, 2654435761) ^ Math.imul(p.x, 40503) ^ Math.imul(p.z, 65599)) >>> 0), rooms: MansionRoom[] = [], X0 = p.x - 15;
  for (let floor = 0; floor < 3; floor++) for (const side of [-1, 1] as const) {
    for (let i = 0; i < 4;) {
      const cells = i < 3 && rnd() < 0.4 ? 2 : 1;
      rooms.push({
        floor, side, cells, x0: X0 + CELL_START[i], x1: X0 + CELL_END[i + cells - 1], z0: side < 0 ? p.z - 9 : p.z + 3, z1: side < 0 ? p.z - 3 : p.z + 9, y: p.y + floor * 5,
        doorX: X0 + CELL_DOOR[i], type: 'empty', link: i + cells < 4 && rnd() < 0.55 ? X0 + CELL_END[i + cells - 1] + 1 : null,
      });
      i += cells;
    }
  }
  // The signature rooms appear in every mansion; the others are drawn at random.
  const order = rooms.map((_, i) => i);
  for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
  const required: MansionRoomType[] = ['storage', 'jail', 'cat_statue', 'flower_garden'];
  order.forEach((ri, n) => { rooms[ri].type = n < required.length ? required[n] : MANSION_ROOM_TYPES[Math.floor(rnd() * MANSION_ROOM_TYPES.length)]; });
  if (MANSIONS.size > 32) MANSIONS.clear();
  MANSIONS.set(key, rooms);
  return rooms;
}

export function mansion(t: StructHost, put: Put, p: Site) {
  const cob = bid('cobblestone'), plank = bid('dark_oak_planks', 'oak_planks'), log = bid('dark_oak_log', 'oak_log'), birch = bid('birch_planks', 'oak_planks'), carpet = bid('red_carpet', 'air');
  const X0 = p.x - 15, X1 = p.x + 15, Z0 = p.z - 10, Z1 = p.z + 10, y = p.y, rooms = mansionLayout(t.seed, p), s = t.seed + 7400;
  const P = (x: number, yy: number, z: number, b: number) => put(x, yy, z, b, true);
  // Cross walls that survive (a merged room swallows the wall between its two cells).
  const merged = new Set<string>();
  for (const r of rooms) if (r.cells === 2) merged.add(r.floor + ':' + r.side + ':' + (r.x0 - X0 + 7));
  for (let z = Z0; z <= Z1; z++) for (let x = X0; x <= X1; x++) {
    for (let dy = 2; dy <= 8; dy++) P(x, y - dy, z, cob);
    const edgeX = x === X0 || x === X1, edgeZ = z === Z0 || z === Z1, dzc = z - p.z, dxc = x - X0, side = dzc > 0 ? 1 : -1;
    for (let k = 0; k < 3; k++) {
      const fy = y - 1 + k * 5;
      P(x, fy, z, k === 0 ? cob : plank);
      for (let dy = 1; dy <= 4; dy++) {
        let b = 0;
        if (edgeX || edgeZ) {
          const along = edgeX ? z - Z0 : dxc;
          b = (edgeX && edgeZ) || along % 5 === 0 ? log : (dy === 2 || dy === 3) && along % 5 !== 1 && along % 5 !== 4 ? cell('glass_pane', edgeZ ? PANE_X : PANE_Z, 'glass') : plank;
        } else if (Math.abs(dzc) === 2) b = birch;
        else if (Math.abs(dzc) > 2 && dxc % 8 === 0 && !merged.has(k + ':' + side + ':' + dxc)) b = birch;
        else if (Math.abs(dzc) <= 1) b = dy === 1 ? carpet : dy === 4 && dzc === 0 && dxc % 8 === 4 ? bid('lantern', 'torch') : 0;
        P(x, fy + dy, z, b);
      }
    }
    P(x, y + 14, z, plank);
  }
  for (let r = 0; r <= 11; r++) fill(put, X0 - 1, y + 15 + r, Z0 - 1 + r, X1 + 1, y + 15 + r, Z1 + 1 - r, r === 11 ? log : plank);
  // Grand entrance on the west end of the corridor.
  for (let dz = -1; dz <= 1; dz++) { for (let dy = 0; dy <= 2; dy++) P(X0, y + dy, p.z + dz, 0); P(X0 - 1, y - 1, p.z + dz, cob); }
  // Staircases in the corridor: ground → first floor on the south side, first → second on the north side.
  for (const [k, dxc0, dz] of [[0, 6, 1], [1, 14, -1]] as const) for (let i = 0; i < 5; i++) {
    const x = X0 + dxc0 + i, base = y + k * 5;
    for (let yy = base; yy < base + i; yy++) P(x, yy, p.z + dz, plank);
    P(x, base + i, p.z + dz, cell('dark_oak_stairs', stairsUp(1), 'oak_planks'));
    for (let yy = base + i + 1; yy <= base + 7; yy++) P(x, yy, p.z + dz, 0);
  }

  for (const r of rooms) {
    const near = p.z + r.side * 3, far = r.side < 0 ? r.z0 : r.z1, zc = p.z + r.side * 6, mid = (r.x0 + r.x1) >> 1, Y = r.y, toFar = r.side;
    const R = (x: number, dy: number, z: number, b: number) => P(x, Y + dy, z, b);
    for (let dy = 0; dy <= 1; dy++) { R(r.doorX, dy, p.z + r.side * 2, 0); if (r.link !== null) R(r.link, dy, zc, 0); }
    R(r.doorX, 2, near, cell('torch', attachOn(r.side > 0 ? 0 : 2)));
    const free = (x: number, z: number) => !(x === r.doorX && (z === near || z === near + toFar)) && !(z === zc && (x === r.x0 || x === r.x1));
    switch (r.type) {
      case 'storage': {
        let n = 0;
        for (let x = r.x0 + 1; x <= r.x1 - 1 && n < 4; x += 2, n++) { R(x, 0, far, bid('chest')); tag(t, x, Y, far, 'mansion_storage'); }
        R(r.x0, 0, far, bid('barrel', 'oak_planks')); R(r.x1, 0, far, plank); R(r.x1, 1, far, plank); R(r.x1, 0, far - toFar, bid('barrel', 'oak_planks'));
        break;
      }
      case 'jail': {
        const zb = far - toFar * 2;
        for (let x = r.x0; x <= r.x1; x++) {
          const rel = (x - r.x0) % 3;
          for (let dy = 0; dy <= 2; dy++) {
            if (rel === 2) { R(x, dy, far, cob); R(x, dy, far - toFar, cob); }
            R(x, dy, zb, rel === 0 && dy <= 1 ? cell('iron_door', doorOn(r.side > 0 ? 0 : 2) | (dy ? 4 : 0), 'iron_bars') : cell('iron_bars', PANE_X, 'cobblestone'));
          }
        }
        break;
      }
      case 'cat_statue': {
        const wool = bid('black_wool', 'white_wool');
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 0; dx++) for (let dy = 0; dy <= 1; dy++) R(mid + dx, dy, zc + dz, wool);   // body
        for (let dx = -1; dx <= 0; dx++) { R(mid + dx, 1, zc - toFar * 2, wool); R(mid + dx, 2, zc - toFar * 2, wool); R(mid + dx, 3, zc - toFar * 2, dx ? wool : 0); }
        R(mid, 3, zc - toFar * 2, wool);                                                                                                // ears
        R(mid - 1, 2, zc - toFar * 2, bid('lime_wool', 'white_wool'));                                                                  // eye
        for (let dy = 1; dy <= 3; dy++) R(mid, dy, zc + toFar * 2, wool);                                                                // tail
        break;
      }
      case 'flower_garden': {
        const flowers = ['poppy', 'dandelion', 'allium', 'azure_bluet', 'red_tulip', 'oxeye_daisy', 'blue_orchid'];
        for (let z = Math.min(near + toFar, far - toFar); z <= Math.max(near + toFar, far - toFar); z++) for (let x = r.x0 + 1; x <= r.x1 - 1; x++) {
          R(x, -1, z, bid('grass_block'));
          const h = hash3(x, Y, z, s);
          if (x === mid && z === zc) { R(x, 0, z, bid('oak_leaves')); R(x, 1, z, bid('oak_leaves')); }
          else if (h < 0.6) R(x, 0, z, bid(flowers[Math.floor(h / 0.6 * flowers.length)], 'poppy'));
        }
        break;
      }
      case 'library':
        for (let x = r.x0; x <= r.x1; x++) for (let dy = 0; dy <= 2; dy++) R(x, dy, far, bid('bookshelf', 'oak_planks'));
        R(mid, 0, zc, bid('lectern', 'bookshelf'));
        break;
      case 'bedroom':
        bed(put, r.x0, Y, far, 3);
        R(r.x1, 0, far, bid('bookshelf', 'oak_planks')); R(r.x1, 1, far, bid('bookshelf', 'oak_planks'));
        for (let dx = 0; dx <= 1; dx++) R(mid + dx, 0, zc, bid('white_carpet', 'air'));
        break;
      case 'dining':
        for (let dx = -1; dx <= 1; dx++) {
          R(mid + dx, 0, zc, bid('dark_oak_fence', 'oak_fence')); R(mid + dx, 1, zc, bid('brown_carpet', 'red_carpet'));
          R(mid + dx, 0, zc + 1, cell('dark_oak_stairs', stairsUp(2), 'oak_planks')); R(mid + dx, 0, zc - 1, cell('dark_oak_stairs', stairsUp(0), 'oak_planks'));
        }
        break;
      case 'smithy':
        R(mid - 1, 0, far, bid('furnace')); R(mid, 0, far, bid('blast_furnace', 'furnace')); R(mid + 1, 0, far, bid('anvil', 'iron_block'));
        R(r.x0, 0, far, bid('cauldron', 'cobblestone'));
        break;
      case 'spider':
        for (let z = r.z0; z <= r.z1; z++) for (let x = r.x0; x <= r.x1; x++) for (let dy = 0; dy <= 3; dy++) {
          if (free(x, z) && hash3(x, Y + dy, z, s + 3) < 0.22) R(x, dy, z, bid('cobweb', 'air'));
        }
        R(mid, 0, zc, bid('spawner', 'cobweb'));
        break;
      case 'obsidian':
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) for (let dy = 0; dy <= 2; dy++) R(mid + dx, dy, zc + dz, dx || dz || dy !== 1 ? bid('obsidian') : bid('diamond_block', 'obsidian'));
        break;
      default:
        for (let dx = -1; dx <= 1; dx++) R(mid + dx, 0, zc, bid('white_carpet', 'air'));
    }
  }
}

// ======================================================================================================================
// Ancient city — City Centre (city_center_1..3), Redstone Laboratory, Long Colonnades, Barracks, Ice Box,
// and Jigsaw Peripheral Modules (Sauna, Camp 1..3, Tall Ruins, Sculk Garden, Entrance Bridge, Meditation Shrine).
// ======================================================================================================================
export type AncientCityModuleKind = 'sauna' | 'camp_1' | 'camp_2' | 'camp_3' | 'tall_ruin' | 'sculk_garden' | 'shrine';
export interface AncientCityPlan {
  centerVariant: 'city_center_1' | 'city_center_2' | 'city_center_3';
  modules: { slot: number; x0: number; z0: number; x1: number; z1: number; kind: AncientCityModuleKind }[];
}

/** Offsets (relative to the site) of the pieces the verification suite looks for. */
export const ANCIENT_CITY = {
  frame: { x0: -11, x1: 10, height: 8 },
  lab: { x0: -8, x1: 8, z0: -5, z1: 5, floor: -8, ceiling: -3 },
  corridors: [{ z: -14, x0: -32, x1: 32 }, { z: 14, x0: -32, x1: 32 }],
  barracks: [{ x0: -30, x1: -18, z0: -5, z1: 5 }, { x0: 18, x1: 30, z0: -5, z1: 5 }],
  iceBox: { x0: -2, x1: 2, z0: -27, z1: -23 },
};

const CITY_PLANS = new Map<string, AncientCityPlan>();
export function ancientCityPlan(seed: number, p: Site): AncientCityPlan {
  const key = `${seed}:${p.x},${p.y},${p.z}`, hit = CITY_PLANS.get(key);
  if (hit) return hit;
  const rnd = mulberry((Math.imul(seed | 0, 2654435761) ^ Math.imul(p.x, 73856093) ^ Math.imul(p.z, 19349663)) >>> 0);
  const centerVariant = (['city_center_1', 'city_center_2', 'city_center_3'] as const)[Math.floor(rnd() * 3)];
  const slots: [number, number, number, number][] = [
    [-26, -26, -16, -18],
    [16, -26, 26, -18],
    [-26, 18, -16, 26],
    [16, 18, 26, 26],
    [-12, -26, -5, -18],
    [5, -26, 12, -18],
    [-52, -22, -42, -14],
    [42, -22, 52, -14],
    [-52, 14, -42, 22],
    [42, 14, 52, 22],
    [-10, -46, 0, -38],
    [0, 38, 10, 46],
    [-72, -26, -60, -16],
    [60, -26, 72, -16],
    [-72, 16, -60, 26],
    [60, 16, 72, 26],
  ];
  const pool: AncientCityModuleKind[] = ['sauna', 'camp_1', 'camp_2', 'camp_3', 'tall_ruin', 'sculk_garden', 'shrine'];
  for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
  const modules = slots.map(([x0, z0, x1, z1], idx) => ({
    slot: idx, x0, z0, x1, z1, kind: pool[idx % pool.length],
  }));
  const plan: AncientCityPlan = { centerVariant, modules };
  if (CITY_PLANS.size > 32) CITY_PLANS.clear();
  CITY_PLANS.set(key, plan);
  return plan;
}

export function ancientCity(t: StructHost, put: Put, p: Site) {
  const plan = ancientCityPlan(t.seed, p);
  const y = p.y, s = t.seed + 7600, P = (dx: number, yy: number, dz: number, b: number) => put(p.x + dx, yy, p.z + dz, b, true);
  const deep = bid('deepslate'), cobbled = bid('cobbled_deepslate', 'deepslate'), bricks = bid('deepslate_bricks', 'deepslate'), tiles = bid('deepslate_tiles', 'deepslate_bricks');
  const polished = bid('polished_deepslate', 'deepslate'), chis = bid('chiseled_deepslate', 'polished_deepslate'), basalt = bid('smooth_basalt', 'basalt');
  const sculk = bid('sculk_block', 'deepslate'), reinforced = bid('reinforced_deepslate', 'obsidian'), lantern = bid('soul_lantern', 'lantern');
  const wool = bid('gray_wool', 'white_wool'), blueWool = bid('blue_wool', 'gray_wool'), cyanWool = bid('cyan_wool', 'gray_wool'), lbWool = bid('light_blue_wool', 'gray_wool');
  const grayCarpet = bid('gray_carpet', 'white_carpet'), blueCarpet = bid('blue_carpet', 'gray_carpet'), cyanCarpet = bid('cyan_carpet', 'gray_carpet');
  const soulSand = bid('soul_sand', 'deepslate'), soulFire = bid('soul_fire', 'torch'), dWall = bid('deepslate_wall', 'cobbled_deepslate'), dStairs = 'deepslate_stairs', dSlab = bid('deepslate_slab', 'deepslate_tiles');
  const brick = (dx: number, yy: number, dz: number) => {
    const r = hash3(dx, yy, dz, s + 1);
    return r < 0.18 ? cobbled : bricks;
  };

  // 1. Expansive multi-lobed cavern (~160x136) with sculk-veined floor & organic ceiling.
  for (let dz = -64; dz <= 64; dz++) for (let dx = -78; dx <= 78; dx++) {
    const e = (dx / 78) ** 2 + (dz / 64) ** 2;
    if (e >= 1) continue;
    const r = hash2(dx * 3 + 1, dz * 5 - 2, s);
    P(dx, y - 1, dz, r < 0.28 ? sculk : r < 0.44 ? cobbled : deep);
    for (let yy = y, top = y + Math.round(7 + 16 * (1 - e)); yy <= top; yy++) P(dx, yy, dz, 0);
  }

  // 2. City centre (city_center_1..3): stepped deepslate-tile pedestal, Warden head crest with reinforced-deepslate portal frame,
  //    soul fire braziers, grand front approach staircase, and wool sound-dampening runners.
  const F = ANCIENT_CITY.frame;
  for (let dz = -6; dz <= 6; dz++) for (let dx = -14; dx <= 14; dx++) {
    const border = Math.abs(dx) === 14 || Math.abs(dz) === 6;
    P(dx, y - 1, dz, border ? polished : dz >= 2 && dz <= 4 && Math.abs(dx) <= 3 ? (Math.abs(dx) === 3 ? blueWool : wool) : dz === 5 && Math.abs(dx) <= 1 ? bid('dark_oak_planks', 'oak_planks') : (Math.abs(dx) === 11 && Math.abs(dz) <= 2) ? chis : tiles);
  }
  // Stepped Warden-head silhouette surrounding the 22×8 reinforced_deepslate frame (without adding extra reinforced_deepslate blocks)
  for (let dy = 0; dy < F.height; dy++) for (let dx = F.x0; dx <= F.x1; dx++) {
    P(dx, y + dy, 0, dx === F.x0 || dx === F.x1 || dy === 0 || dy === F.height - 1 ? reinforced : 0);
  }
  // Outer sculptural Warden ears & brow in chiseled/polished deepslate & deepslate bricks
  for (let dy = 0; dy <= F.height + 1; dy++) {
    P(F.x0 - 1, y + dy, 0, dy === 3 || dy === 4 ? chis : polished);
    P(F.x1 + 1, y + dy, 0, dy === 3 || dy === 4 ? chis : polished);
  }
  // Warden tendril "ears" on top corners (varies with centerVariant)
  const earH = plan.centerVariant === 'city_center_1' ? 3 : plan.centerVariant === 'city_center_2' ? 4 : 2;
  for (const sx of [F.x0 - 2, F.x1 + 2]) for (let dy = F.height - 2; dy <= F.height + earH - 2; dy++) P(sx, y + dy, 0, chis);
  for (let dx = F.x0 - 1; dx <= F.x1 + 1; dx++) P(dx, y + F.height, 0, Math.abs(dx) <= 4 ? chis : polished);
  // Corner soul-fire braziers on the plaza
  for (const [dx, dz] of [[-13, -5], [13, -5], [-13, 5], [13, 5]]) {
    P(dx, y, dz, polished); P(dx, y + 1, dz, polished); P(dx, y + 2, dz, lantern);
  }
  for (const [dx, dz] of [[-12, -4], [12, -4], [-12, 4], [12, 4]]) {
    P(dx, y, dz, basalt); P(dx, y + 1, dz, soulSand); P(dx, y + 2, dz, soulFire);
  }
  P(0, y, 3, bid('sculk_shrieker', 'sculk_sensor')); P(-4, y, 3, bid('sculk_sensor', 'air')); P(4, y, 3, bid('sculk_sensor', 'air'));
  P(-8, y, 2, bid('sculk_catalyst', 'air')); P(8, y, 2, bid('sculk_catalyst', 'air'));

  // 3. Redstone laboratory under the centre (multiple vanilla circuit experiments: door trigger, comparator book lectern,
  //    target/repeater line, sticky piston memory cell, note block + sculk sensor acoustic test).
  const Lb = ANCIENT_CITY.lab, ly = y + Lb.floor + 1;
  for (let dz = Lb.z0; dz <= Lb.z1; dz++) for (let dx = Lb.x0; dx <= Lb.x1; dx++) {
    P(dx, y - 2, dz, bricks);
    for (let yy = y + Lb.floor; yy <= y + Lb.ceiling; yy++) {
      const edge = dx === Lb.x0 || dx === Lb.x1 || dz === Lb.z0 || dz === Lb.z1 || yy === y + Lb.floor || yy === y + Lb.ceiling;
      P(dx, yy, dz, edge ? tiles : 0);
    }
  }
  // Sound-insulated gray carpet walkway inside the lab
  for (let dx = -4; dx <= 4; dx++) if (dx !== 0) P(dx, ly, 2, grayCarpet);
  P(-6, ly, -3, cell('lever', 0)); for (let dx = -5; dx <= -3; dx++) P(dx, ly, -3, bid('redstone_wire', 'air'));
  P(-2, ly, -3, bid('unlit_redstone_lamp', 'redstone_lamp'));
  P(-6, ly, 0, bid('redstone_block', 'deepslate_tiles')); P(-5, ly, 0, cell('repeater', 0, 'air')); P(-4, ly, 0, bid('redstone_wire', 'air')); P(-3, ly, 0, cell('comparator', 0, 'air')); P(-2, ly, 0, bid('target', 'redstone_lamp'));
  P(3, ly, -3, cell('sticky_piston', 4, 'piston')); P(4, ly, -3, cell('lever', 0)); P(3, ly, -2, bid('redstone_wire', 'air'));
  P(5, ly, 0, bid('note_block', 'target')); P(6, ly, 1, bid('sculk_sensor', 'air')); P(6, ly, 0, bid('redstone_wire', 'air'));
  P(0, ly, -4, bid('lectern', 'bookshelf')); P(1, ly, -4, bid('chiseled_bookshelf', 'bookshelf')); P(-1, ly, -4, bid('chiseled_bookshelf', 'bookshelf'));
  P(6, ly, -3, bid('redstone_block', 'deepslate_tiles')); P(6, ly + 1, -3, bid('unlit_redstone_lamp', 'redstone_lamp'));
  P(-7, ly + 1, 3, cell('redstone_torch', attachOn(3), 'torch')); P(7, ly + 1, 3, cell('redstone_torch', attachOn(1), 'torch'));
  for (const [dx, dz] of [[-7, -4], [7, -4], [-7, 4], [7, 4]]) P(dx, ly + 3, dz, lantern);
  if (plan.centerVariant === 'city_center_1') { P(-5, ly, 3, chis); P(-4, ly, 3, cyanCarpet); }
  else if (plan.centerVariant === 'city_center_2') { P(-5, ly, 3, bid('furnace')); P(-4, ly, 3, cell('comparator', 0, 'air')); }
  else { P(-5, ly, 3, cell('repeater', 0, 'air')); P(-4, ly, 3, cell('repeater', 2, 'air')); }
  // Stairwell from the plaza (south side) down to the laboratory's iron door; the lever above the door opens it.
  for (let i = 1; i <= 6; i++) {
    for (let yy = y - 8; yy <= y - 1 - i; yy++) P(0, yy, 12 - i, polished);
    for (let yy = y - i; yy <= y + 2; yy++) P(0, yy, 12 - i, 0);
    for (const dx of [-1, 1]) for (let yy = y - 8; yy <= y - 1; yy++) P(dx, yy, 12 - i, bricks);
  }
  P(0, ly, 5, cell('iron_door', doorOn(2), 'air')); P(0, ly + 1, 5, cell('iron_door', doorOn(2) | 4, 'air'));
  P(0, ly + 2, 6, cell('lever', attachOn(0)));

  // 4. Long deepslate-brick colonnades (65 blocks long, wool sound-insulated runner, cross-walkways connecting N/S corridors).
  for (const c of ANCIENT_CITY.corridors) for (const [x0, x1] of [[-68, -33], [33, 68]] as const) {
    const rz = c.z + (c.z > 0 ? 4 : -4);
    for (let dx = x0; dx <= x1; dx++) for (let w = -1; w <= 1; w++) {
      P(dx, y - 1, rz + w, w === 0 ? wool : tiles);
      if (dx % 8 === 0 && w === 0) P(dx, y + 3, rz, lantern);
    }
  }
  for (const c of ANCIENT_CITY.corridors) for (let dx = c.x0; dx <= c.x1; dx++) {
    for (let w = -2; w <= 2; w++) {
      const dz = c.z + w;
      P(dx, y - 1, dz, w === 0 ? wool : tiles); if (w === 0) P(dx, y - 2, dz, wool);
      for (let yy = y; yy <= y + 4; yy++) P(dx, yy, dz, 0);
      if (Math.abs(w) === 2 && dx % 4 === 0) for (let yy = y; yy <= y + 3; yy++) P(dx, yy, dz, brick(dx, yy, dz));
      if (hash2(dx >> 1, c.z + w * 7, s + 2) >= 0.18) P(dx, y + 4, dz, Math.abs(w) === 2 ? brick(dx, y + 4, dz) : tiles);
    }
    if (((dx % 8) + 8) % 8 === 4) P(dx, y + 3, c.z, lantern);
  }
  // Cross-walkways with gray wool runners linking the city center to the north & south colonnades
  for (const xCross of [-15, 15]) for (let dz = -12; dz <= 12; dz++) {
    if (Math.abs(dz) <= 5) continue;
    for (let w = -1; w <= 1; w++) {
      P(xCross + w, y - 1, dz, w === 0 ? wool : tiles);
      if (Math.abs(w) === 1 && dz % 3 === 0) { P(xCross + w, y, dz, dWall); P(xCross + w, y + 1, dz, dWall); }
    }
  }
  P(-31, y, 14, bid('chest')); tag(t, p.x - 31, y, p.z + 14, 'ancient_city');
  P(31, y, -14, bid('chest')); tag(t, p.x + 31, y, p.z - 14, 'ancient_city');

  // 5. Barracks: bunk beds along both long walls, a chest and a skull at the far end.
  for (const b of ANCIENT_CITY.barracks) {
    const west = b.x0 < 0, doorX = west ? b.x1 : b.x0, endX = west ? b.x0 + 1 : b.x1 - 1;
    for (let dz = b.z0; dz <= b.z1; dz++) for (let dx = b.x0; dx <= b.x1; dx++) for (let yy = y - 1; yy <= y + 5; yy++) {
      const edge = dx === b.x0 || dx === b.x1 || dz === b.z0 || dz === b.z1;
      P(dx, yy, dz, yy === y - 1 ? (dz === 0 ? wool : tiles) : yy === y + 5 ? tiles : edge ? brick(dx, yy, dz) : 0);
    }
    P(doorX, y, 0, 0); P(doorX, y + 1, 0, 0);
    for (let bx = b.x0 + 2; bx <= b.x1 - 2; bx += 3) {
      bed(put, p.x + bx, y, p.z - 3, 2); bed(put, p.x + bx, y, p.z + 3, 0);
      for (const dz of [-4, -3, 3, 4]) { P(bx, y + 2, dz, bid('dark_oak_planks', 'oak_planks')); P(bx, y + 3, dz, wool); }
      P(bx + 1, y, -4, bid('dark_oak_fence', 'oak_fence')); P(bx + 1, y + 1, -4, bid('dark_oak_fence', 'oak_fence'));
      P(bx + 1, y, 4, bid('dark_oak_fence', 'oak_fence')); P(bx + 1, y + 1, 4, bid('dark_oak_fence', 'oak_fence'));
    }
    P(endX, y, 0, bid('chest')); tag(t, p.x + endX, y, p.z, 'ancient_city');
    P(endX, y, -1, bid('skeleton_skull', 'bone_block')); P(endX, y, 1, bid('target', 'bone_block'));
    P((b.x0 + b.x1) >> 1, y + 4, 0, lantern);
  }

  // 6. Ice box (packed ice & blue ice cold storage).
  const I = ANCIENT_CITY.iceBox;
  for (let dz = I.z0; dz <= I.z1; dz++) for (let dx = I.x0; dx <= I.x1; dx++) for (let yy = y - 1; yy <= y + 3; yy++) {
    const edge = dx === I.x0 || dx === I.x1 || dz === I.z0 || dz === I.z1;
    P(dx, yy, dz, yy === y - 1 ? bid('packed_ice', 'ice') : yy === y + 3 ? tiles : edge ? (hash3(dx, yy, dz, s + 4) < 0.4 ? bid('packed_ice', 'ice') : bricks) : 0);
  }
  P(0, y, I.z1, 0); P(0, y + 1, I.z1, 0);
  P(0, y, -25, bid('chest')); tag(t, p.x, y, p.z - 25, 'ancient_city_ice_box');
  P(-1, y, -26, bid('blue_ice', 'packed_ice')); P(1, y, -26, bid('blue_ice', 'packed_ice'));
  P(0, y, I.z1, 0); P(0, y + 1, I.z1, 0);
  P(-1, y, I.z1 + 1, cell('sticky_piston', rsFacing(3) | 8, 'piston'));
  P(-1, y + 1, I.z1 + 1, cell('sticky_piston', rsFacing(3) | 8, 'piston'));
  P(1, y, I.z1 + 1, bid('stone_pressure_plate', 'deepslate_tiles'));
  P(1, y - 1, I.z1 + 1, bid('redstone_wire', 'air'));
  P(0, y - 1, I.z1 + 1, bid('redstone_wire', 'air'));
  P(-1, y - 1, I.z1 + 1, bid('redstone_wire', 'air'));
  P(1, y, I.z0 + 1, bid('snow_block', 'packed_ice'));

  // 7. Jigsaw Peripheral City Structures (sauna, camp_1..3, tall_ruin, sculk_garden, shrine)
  for (const m of plan.modules) {
    const mx = (m.x0 + m.x1) >> 1, mz = (m.z0 + m.z1) >> 1;
    for (let dz = m.z0; dz <= m.z1; dz++) for (let dx = m.x0; dx <= m.x1; dx++) {
      for (let yy = y; yy <= y + 11; yy++) P(dx, yy, dz, 0);
      P(dx, y - 1, dz, tiles);
    }
    switch (m.kind) {
      case 'sauna':
        // Deepslate sauna bathhouse with water basin, magma heating & dark oak benches
        for (let dz = m.z0; dz <= m.z1; dz++) for (let dx = m.x0; dx <= m.x1; dx++) {
          const edge = dx === m.x0 || dx === m.x1 || dz === m.z0 || dz === m.z1;
          if (edge && !(dx === mx && (dz === m.z0 || dz === m.z1))) {
            for (let dy = 0; dy <= 3; dy++) P(dx, y + dy, dz, dy === 3 ? polished : brick(dx, y + dy, dz));
          } else if (Math.abs(dx - mx) <= 1 && Math.abs(dz - mz) <= 1) {
            P(dx, y - 2, dz, bid('magma_block', 'deepslate'));
            P(dx, y - 1, dz, bid('water'));
          }
        }
        P(mx, y + 3, mz, lantern);
        break;
      case 'camp_1':
      case 'camp_2':
      case 'camp_3': {
        // Wool tent camp with soul campfire & supplies
        const tentWool = m.kind === 'camp_1' ? blueWool : m.kind === 'camp_2' ? cyanWool : lbWool;
        const tentCarpet = m.kind === 'camp_1' ? blueCarpet : cyanCarpet;
        for (let dz = m.z0 + 1; dz <= m.z1 - 1; dz++) for (let dx = mx - 2; dx <= mx + 2; dx++) {
          const h = 2 - Math.abs(dx - mx);
          P(dx, y + h, dz, tentWool);
          if (Math.abs(dx - mx) <= 1) P(dx, y, dz, tentCarpet);
        }
        P(mx, y, mz, bid('soul_campfire', 'campfire'));
        P(mx - 3, y, mz, bid('barrel', 'dark_oak_planks'));
        break;
      }
      case 'tall_ruin':
        // Multi-storey ruined watchtower with ladder, soul lanterns & arches
        for (let dz = m.z0 + 1; dz <= m.z1 - 1; dz++) for (let dx = m.x0 + 1; dx <= m.x1 - 1; dx++) {
          const edge = dx === m.x0 + 1 || dx === m.x1 - 1 || dz === m.z0 + 1 || dz === m.z1 - 1;
          const corner = (dx === m.x0 + 1 || dx === m.x1 - 1) && (dz === m.z0 + 1 || dz === m.z1 - 1);
          for (let dy = 0; dy <= 8; dy++) {
            if (dy === 4) P(dx, y + dy, dz, dx === mx && dz === mz ? 0 : polished);
            else if (corner || (edge && dy <= 5 && !(dx === mx && dy <= 1))) P(dx, y + dy, dz, dy === 3 ? chis : brick(dx, y + dy, dz));
          }
        }
        for (let dy = 0; dy <= 4; dy++) P(mx, y + dy, mz - 1, cell('ladder', ladderOn(0)));
        P(mx, y + 7, mz, lantern);
        break;
      case 'sculk_garden':
        // Sunken sculk terrace with amethyst cluster, catalyst & sensors
        for (let dz = m.z0 + 1; dz <= m.z1 - 1; dz++) for (let dx = m.x0 + 1; dx <= m.x1 - 1; dx++) {
          P(dx, y - 1, dz, sculk);
        }
        P(mx, y, mz, bid('sculk_catalyst', 'sculk_block'));
        P(mx - 2, y, mz, bid('amethyst_block', 'sculk_block')); P(mx - 2, y + 1, mz, bid('amethyst_cluster', 'air'));
        break;
      case 'shrine':
        // Chiseled deepslate meditation shrine with soul fire & bells/candles
        for (let dz = m.z0 + 1; dz <= m.z1 - 1; dz++) for (let dx = m.x0 + 1; dx <= m.x1 - 1; dx++) {
          const edge = dx === m.x0 + 1 || dx === m.x1 - 1 || dz === m.z0 + 1 || dz === m.z1 - 1;
          if (edge) { P(dx, y, dz, dSlab); if ((dx + dz) % 2 === 0) { P(dx, y + 1, dz, dWall); P(dx, y + 2, dz, chis); } }
        }
        P(mx, y, mz, basalt); P(mx, y + 1, mz, soulSand); P(mx, y + 2, mz, soulFire);
        break;
    }
  }

  // 8. Sculk growths on free floor cells.
  for (let dz = -30; dz <= 30; dz++) for (let dx = -33; dx <= 33; dx++) {
    if ((dx / 34) ** 2 + (dz / 31) ** 2 >= 0.95 || (Math.abs(dx) <= 1 && dz >= 5 && dz <= 12)) continue;
    const r = hash2(dx * 11 - 3, dz * 17 + 5, s + 5);
    if (r < 0.019) put(p.x + dx, y, p.z + dz, r < 0.012 ? bid('sculk_sensor', 'air') : r < 0.016 ? bid('sculk_shrieker', 'air') : bid('sculk_catalyst', 'air'), false);
  }
  void placeChest; void placeLantern; void placeBarrel; void dStairs;
}

// ======================================================================================================================
// Bastion remnant — Procedural Jigsaw Sub-Piece & Multi-Variant Interior Assembler (`bastionLayout`)
// ======================================================================================================================
export const BASTION_TYPES = ['treasure', 'hoglin_stable', 'bridge', 'housing'] as const;
export type BastionType = typeof BASTION_TYPES[number];
export const bastionType = (seed: number, x: number, z: number): BastionType => BASTION_TYPES[Math.floor(hash2(x, z, seed + 7700) * 4) & 3];
const BASTION_TABLE: Record<BastionType, string> = { treasure: 'bastion_treasure', hoglin_stable: 'bastion_hoglin_stable', bridge: 'bastion_bridge', housing: 'bastion_other' };

export const BASTION_ROOM_TYPES = [
  'gold_sanctum', 'gilded_alcove', 'snout_shrine', 'crying_portal_niche', 'bone_trophy_hall',
  'piglin_barracks', 'lodestone_altar', 'crimson_forage_bay', 'magma_forge', 'watch_gallery',
] as const;
export type BastionRoomType = typeof BASTION_ROOM_TYPES[number];

export interface BastionRoom {
  floor: number;
  wing: number;
  x0: number;
  x1: number;
  z0: number;
  z1: number;
  y: number;
  type: BastionRoomType;
  subTemplate: string;
}

export interface BastionLayout {
  type: BastionType;
  monumentVariant: number;
  courtyardVariant: number;
  snoutFacing: number;
  skybridgeMask: number;
  /** Canonical Minecraft Wiki Jigsaw sub-piece identifiers assembled into this Bastion instance. */
  subTemplates: string[];
  rooms: BastionRoom[];
  chests: [number, number, number][];
}

const BASTION_LAYOUTS = new Map<string, BastionLayout>();

/**
 * Deterministic multi-piece / multi-room layout of the Bastion Remnant at `p` (modelled on Vanilla `BastionPieces` pools).
 * Different seeds and coordinates produce distinct room assignments, monument styles, rampart galleries, and chest placements.
 */
export function bastionLayout(seed: number, p: Site, force?: BastionType): BastionLayout {
  const type = force ?? bastionType(seed, p.x, p.z);
  const key = `${seed}:${p.x},${p.y},${p.z}:${type}`;
  const hit = BASTION_LAYOUTS.get(key);
  if (hit) return hit;

  const rnd = mulberry((Math.imul(seed | 0, 2654435761) ^ Math.imul(p.x, 73856093) ^ Math.imul(p.z, 19349663) ^ BASTION_TYPES.indexOf(type) * 997) >>> 0);
  const monumentVariant = Math.floor(rnd() * 4);
  const courtyardVariant = Math.floor(rnd() * 4);
  const snoutFacing = Math.floor(rnd() * 4);
  const skybridgeMask = 1 + (Math.floor(rnd() * 15) & 15);
  const rooms: BastionRoom[] = [];
  const subTemplates: string[] = [];
  const y = p.y;

  const drawPool = (pool: readonly BastionRoomType[]) => pool[Math.floor(rnd() * pool.length)];

  if (type === 'treasure') {
    // Canonical Wiki `bastion/treasure/*` sub-pieces
    const extPool = [
      'bastion/treasure/extensions/large_bridge_0', 'bastion/treasure/extensions/large_bridge_1',
      'bastion/treasure/extensions/large_bridge_2', 'bastion/treasure/extensions/large_bridge_3',
      'bastion/treasure/extensions/small_bridge_0', 'bastion/treasure/extensions/small_bridge_1',
      'bastion/treasure/extensions/roofed_bridge', 'bastion/treasure/extensions/fire_room',
      'bastion/treasure/extensions/house_0', 'bastion/treasure/extensions/house_1',
    ];
    subTemplates.push(
      'bastion/treasure/big_air_full',
      'bastion/treasure/bases/lava_basin',
      `bastion/treasure/bases/centers/center_${monumentVariant}`,
      'bastion/treasure/entrances/entrance_0',
      'bastion/treasure/ramparts/mid_wall_main',
      'bastion/treasure/ramparts/mid_wall_side',
      'bastion/treasure/ramparts/top_wall',
      'bastion/treasure/ramparts/bottom_wall_0',
      `bastion/treasure/walls/bottom/wall_${monumentVariant}`,
      `bastion/treasure/walls/mid/wall_${courtyardVariant % 3}`,
      `bastion/treasure/walls/top/wall_${snoutFacing % 2}`,
      `bastion/treasure/corners/bottom/corner_${monumentVariant % 2}`,
      `bastion/treasure/corners/middle/corner_${courtyardVariant % 2}`,
      `bastion/treasure/corners/top/corner_${snoutFacing % 2}`,
      'bastion/treasure/roofs/center_roof',
      'bastion/treasure/roofs/corner_roof',
      'bastion/treasure/roofs/wall_roof',
    );
    const pool: readonly BastionRoomType[] = ['gold_sanctum', 'gilded_alcove', 'snout_shrine', 'crying_portal_niche', 'magma_forge', 'watch_gallery'];
    const bays: [number, number, number, number][] = [
      [-13, -11, -5, -1], [-13, -11, 1, 5], [11, 13, -5, -1], [11, 13, 1, 5],
      [-5, -1, -13, -11], [1, 5, -13, -11], [-5, -1, 11, 13], [1, 5, 11, 13],
    ];
    bays.forEach(([x0, x1, z0, z1], idx) => {
      const fl = idx < 4 ? 1 : 2;
      const subTemplate = extPool[(idx + monumentVariant * 2) % extPool.length];
      subTemplates.push(subTemplate);
      rooms.push({ floor: fl, wing: idx, x0: p.x + x0, x1: p.x + x1, z0: p.z + z0, z1: p.z + z1, y: y + fl * 3, type: drawPool(pool), subTemplate });
    });
  } else if (type === 'hoglin_stable') {
    // Canonical Wiki `bastion/hoglin_stable/*` sub-pieces
    subTemplates.push(
      `bastion/hoglin_stable/starting_pieces/starting_stairs_${monumentVariant}`,
      'bastion/hoglin_stable/ramparts/ramparts_1',
      'bastion/hoglin_stable/ramparts/ramparts_2',
      'bastion/hoglin_stable/ramparts/ramparts_3',
      'bastion/hoglin_stable/walls/side_wall_0',
      'bastion/hoglin_stable/walls/side_wall_1',
      'bastion/hoglin_stable/walls/wall_base',
      'bastion/hoglin_stable/posts/end_post',
      'bastion/hoglin_stable/posts/stair_post',
      `bastion/hoglin_stable/stairs/stairs_1_${monumentVariant}`,
      `bastion/hoglin_stable/stairs/stairs_2_${courtyardVariant}`,
      `bastion/hoglin_stable/stairs/stairs_3_${snoutFacing}`,
      'bastion/hoglin_stable/connectors/end_connectors',
    );
    const pool: readonly BastionRoomType[] = ['bone_trophy_hall', 'piglin_barracks', 'gilded_alcove', 'crimson_forage_bay', 'snout_shrine', 'gold_sanctum'];
    let wing = 0;
    for (const sx of [-1, 1]) {
      for (let b = 0; b < 3; b++) {
        const z0 = -11 + b * 8;
        const x0 = sx < 0 ? -13 : 9, x1 = sx < 0 ? -9 : 13;
        const subTemplate = sx < 0
          ? `bastion/hoglin_stable/large_stables/inner_${(b + monumentVariant) % 4}`
          : `bastion/hoglin_stable/small_stables/outer_${(b + courtyardVariant) % 4}`;
        subTemplates.push(subTemplate);
        rooms.push({ floor: 1, wing: wing++, x0: p.x + x0, x1: p.x + x1, z0: p.z + z0, z1: p.z + z0 + 4, y: y + 4, type: drawPool(pool), subTemplate });
      }
    }
  } else if (type === 'bridge') {
    // Canonical Wiki `bastion/bridge/*` sub-pieces
    subTemplates.push(
      'bastion/bridge/starting_pieces/entrance',
      'bastion/bridge/starting_pieces/entrance_base',
      'bastion/bridge/starting_pieces/entrance_face',
      'bastion/bridge/bridge_pieces/bridge',
      'bastion/bridge/connectors/back_bridge_bottom',
      'bastion/bridge/connectors/back_bridge_top',
      'bastion/bridge/legs/leg_0',
      'bastion/bridge/legs/leg_1',
      'bastion/bridge/ramparts/rampart_0',
      'bastion/bridge/ramparts/rampart_1',
      'bastion/bridge/walls/wall_base_0',
      'bastion/bridge/walls/wall_base_1',
    );
    const pool: readonly BastionRoomType[] = ['gold_sanctum', 'snout_shrine', 'crying_portal_niche', 'gilded_alcove', 'watch_gallery'];
    const lodgeIdx = Math.floor(rnd() * 4);
    let wing = 0;
    for (const sz of [-1, 1]) {
      for (let fl = 0; fl < 2; fl++) {
        const z0 = sz < 0 ? -13 : 10, z1 = sz < 0 ? -10 : 13;
        const rType = wing === lodgeIdx ? 'lodestone_altar' : drawPool(pool);
        const subTemplate = sz < 0 ? `bastion/bridge/ramparts/rampart_${fl}` : `bastion/bridge/walls/wall_base_${fl}`;
        rooms.push({ floor: fl, wing: wing++, x0: p.x - 4, x1: p.x + 4, z0: p.z + z0, z1: p.z + z1, y: y + fl * 6, type: rType, subTemplate });
      }
    }
  } else {
    // Canonical Wiki `bastion/units/*` sub-pieces
    subTemplates.push(
      `bastion/units/center_pieces/center_${courtyardVariant % 3}`,
      `bastion/units/ramparts/ramparts_${monumentVariant % 3}`,
      'bastion/units/walls/connected_wall',
      'bastion/units/walls/wall_base',
      'bastion/units/pathways/pathway_0',
      'bastion/units/stages/rot/stage_1_0',
      'bastion/units/wall_units/edge_0_large',
      'bastion/units/wall_units/unit_0',
    );
    const pool: readonly BastionRoomType[] = ['piglin_barracks', 'gold_sanctum', 'bone_trophy_hall', 'gilded_alcove', 'snout_shrine', 'crying_portal_niche', 'magma_forge', 'watch_gallery'];
    let wing = 0;
    for (const sz of [-1, 1]) for (const sx of [-1, 1]) {
      for (let fl = 0; fl < 2; fl++) {
        const x0 = sx < 0 ? -11 : 6, x1 = sx < 0 ? -6 : 11;
        const z0 = sz < 0 ? -11 : 6, z1 = sz < 0 ? -6 : 11;
        const stageTier = fl === 0 ? (sx < 0 ? 0 : 1) : (sz < 0 ? 2 : 3);
        const subVar = stageTier === 2 ? (wing & 1) : (wing + monumentVariant) & 3;
        const subTemplate = `bastion/units/stages/stage_${stageTier}_${subVar}`;
        subTemplates.push(subTemplate);
        rooms.push({ floor: fl, wing: wing++, x0: p.x + x0, x1: p.x + x1, z0: p.z + z0, z1: p.z + z1, y: y + fl * 5, type: drawPool(pool), subTemplate });
      }
    }
  }

  // Deterministic chest coordinates per variant (varying by layout while staying inside the core chunk region)
  const chests: [number, number, number][] =
    type === 'treasure'
      ? (monumentVariant % 2 === 0 ? [[p.x + 2, y, p.z], [p.x - 2, y, p.z]] : [[p.x, y, p.z + 2], [p.x + 2, y, p.z]])
      : type === 'hoglin_stable'
      ? (monumentVariant % 2 === 0 ? [[p.x, y, p.z - 13], [p.x + 12, y, p.z - 11]] : [[p.x, y, p.z - 13], [p.x - 12, y, p.z + 11]])
      : type === 'bridge'
      ? (monumentVariant % 2 === 0 ? [[p.x, y + 6, p.z - 12], [p.x, y, p.z + 12]] : [[p.x, y + 6, p.z + 12], [p.x, y, p.z - 12]])
      : [
          [p.x - 11, y, p.z - 6],
          [p.x + 6, y + 5, p.z - 11],
          [p.x - 6, y + 5, p.z + 11],
          [p.x + 11, y, p.z + 6],
        ];

  const L: BastionLayout = { type, monumentVariant, courtyardVariant, snoutFacing, skybridgeMask, subTemplates, rooms, chests };
  if (BASTION_LAYOUTS.size > 64) BASTION_LAYOUTS.clear();
  BASTION_LAYOUTS.set(key, L);
  return L;
}

export function bastion(t: StructHost, put: Put, p: Site, force?: BastionType) {
  const L = bastionLayout(t.seed, p, force);
  const type = L.type, y = p.y, s = t.seed + 7700, R = 14;
  const P = (dx: number, yy: number, dz: number, b: number) => put(p.x + dx, yy, p.z + dz, b, true);
  const pbb = bid('polished_blackstone_bricks', 'nether_bricks');
  const cpbb = bid('cracked_polished_blackstone_bricks', 'polished_blackstone_bricks');
  const chpbb = bid('chiseled_polished_blackstone', 'polished_blackstone_bricks');
  const pbs = bid('polished_blackstone', 'blackstone');
  const bs = bid('blackstone', 'nether_bricks');
  const gilded = bid('gilded_blackstone', 'gold_block');
  const basalt = bid('basalt', 'blackstone');
  const gold = bid('gold_block');
  const quartz = bid('quartz_block', 'chiseled_polished_blackstone');
  const lantern = bid('lantern', 'glowstone');
  const soulLantern = bid('soul_lantern', 'lantern');
  const glowstone = bid('glowstone', 'lantern');
  const lava = bid('lava');
  const bone = bid('bone_block', 'blackstone');
  const crying = bid('crying_obsidian', 'obsidian');
  const obs = bid('obsidian');
  const lodestone = bid('lodestone', 'chiseled_polished_blackstone');

  const wall = (dx: number, yy: number, dz: number) => {
    const r = hash3(dx, yy, dz, s);
    return r < 0.14 ? bs : r < 0.21 ? gilded : r < 0.30 ? cpbb : r < 0.35 ? pbs : pbb;
  };
  const placeChest = (wx: number, wy: number, wz: number) => {
    put(wx, wy, wz, bid('chest'), true);
    put(wx, wy + 1, wz, 0, true);
    tag(t, wx, wy, wz, BASTION_TABLE[type]);
  };
  const ring = (top: number, gate = true) => {
    for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++) {
      if (Math.abs(dx) !== R && Math.abs(dz) !== R) continue;
      const tower = Math.abs(dx) === R && Math.abs(dz) === R;
      for (let yy = y; yy <= y + top + (tower ? 2 : 0); yy++) {
        // Carved Piglin snout bands on the perimeter ramparts at y + 3 and y + 6
        const snoutBand = !tower && (yy === y + 3 || yy === y + 6) && (Math.abs(dx) % 5 === 0 || Math.abs(dz) % 5 === 0);
        P(dx, yy, dz, tower ? basalt : snoutBand ? chpbb : wall(dx, yy, dz));
      }
      if (tower) P(dx, y + top + 3, dz, lantern);
      else if ((dx + dz) % 2 === 0) P(dx, y + top + 1, dz, wall(dx, y + top + 1, dz)); // battlements
    }
    if (gate) for (let dx = -1; dx <= 1; dx++) for (let yy = y; yy <= y + 2; yy++) P(dx, yy, R, 0);
  };

  // Furnish a procedural Bastion room bay according to its `BastionRoomType` (never placing blocks reserved by other variant signatures).
  const furnishBay = (r: BastionRoom) => {
    const cx = (r.x0 + r.x1) >> 1, cz = (r.z0 + r.z1) >> 1, ry = r.y;
    switch (r.type) {
      case 'gold_sanctum':
        put(cx, ry, cz, gold, true);
        put(cx, ry + 1, cz, gilded, true);
        break;
      case 'gilded_alcove':
        put(r.x0, ry, r.z0, gilded, true);
        put(r.x1, ry, r.z1, gilded, true);
        put(cx, ry, cz, chpbb, true);
        break;
      case 'snout_shrine':
        put(cx, ry, cz, chpbb, true);
        put(cx, ry + 1, cz, chpbb, true);
        put(cx, ry + 2, cz, soulLantern, true);
        break;
      case 'crying_portal_niche':
        put(cx, ry, cz, obs, true);
        put(cx, ry + 1, cz, crying, true);
        break;
      case 'bone_trophy_hall':
        put(r.x0, ry, cz, bone, true);
        put(r.x1, ry, cz, bone, true);
        put(cx, ry + 1, cz, bid('wither_skeleton_skull', 'bone_block'), true);
        break;
      case 'piglin_barracks':
        put(r.x0, ry, r.z0, pbs, true);
        put(r.x1, ry, r.z0, chpbb, true);
        put(cx, ry + 2, cz, soulLantern, true);
        break;
      case 'lodestone_altar':
        put(cx, ry, cz, chpbb, true);
        put(cx, ry + 1, cz, lodestone, true);
        put(cx, ry + 2, cz, soulLantern, true);
        break;
      case 'crimson_forage_bay':
        put(cx, ry, cz, glowstone, true);
        put(r.x0, ry, r.z1, gilded, true);
        break;
      case 'magma_forge':
        put(cx, ry, cz, bid('magma_block', 'blackstone'), true);
        put(r.x0, ry, r.z0, gilded, true);
        break;
      case 'watch_gallery':
        put(cx, ry, cz, chpbb, true);
        put(cx, ry + 1, cz, lantern, true);
        break;
    }
  };

  // Blackstone base, deep foundation, outer rampart buttresses (-20..20) and upper watchtower parapets (up to y + 18).
  for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++) {
    for (let yy = y - 8; yy <= y - 1; yy++) P(dx, yy, dz, yy === y - 1 ? wall(dx, yy, dz) : bs);
    for (let yy = y; yy <= y + 12; yy++) P(dx, yy, dz, 0);
  }
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    for (let a = 15; a <= 20; a++) for (let b = 15; b <= 20; b++) {
      const edge = a === 20 || b === 20;
      for (let yy = y - 8; yy <= y + 18; yy++) {
        if (edge) {
          if (yy >= y + 14 && hash3(sx * a, yy, sz * b, s + 91) < 0.25) continue;
          P(sx * a, yy, sz * b, (a === 20 && b === 20) ? basalt : wall(sx * a, yy, sz * b));
        }
      }
    }
  }

  if (type === 'treasure') {
    // Walkway around a lava pit (`bases/lava_basin`), multi-tier perimeter rampart galleries (`walls/bottom|mid|top`),
    // four bridges (`extensions/large_bridge_*`) to the central treasure platform (`bases/centers/center_0..3`, 12–19 gold blocks) with magma cube spawner.
    ring(9);
    for (let dz = -9; dz <= 9; dz++) for (let dx = -9; dx <= 9; dx++) {
      const m = Math.max(Math.abs(dx), Math.abs(dz)), bridge = (dx === 0 || dz === 0) && m >= 3;
      if (m <= 2) { for (let yy = y - 4; yy <= y - 1; yy++) P(dx, yy, dz, m === 2 ? gilded : pbb); continue; }
      P(dx, y - 4, dz, bs); P(dx, y - 3, dz, lava); P(dx, y - 2, dz, 0);
      P(dx, y - 1, dz, bridge ? pbb : 0);
    }
    // Multi-tier perimeter rampart galleries (y + 3 and y + 6) along the outer walls (|dx| >= 11 or |dz| >= 11)
    for (const gy of [y + 3, y + 6]) {
      for (let dz = -R + 1; dz <= R - 1; dz++) for (let dx = -R + 1; dx <= R - 1; dx++) {
        const m = Math.max(Math.abs(dx), Math.abs(dz));
        if (m >= 12) P(dx, gy - 1, dz, (dx + dz) % 5 === 0 ? gilded : pbb);
        else if (m === 11 && ((dx + dz) & 1) === 0) P(dx, gy, dz, chpbb);
      }
    }
    // Furnish the 8 procedural rampart bays
    for (const r of L.rooms) furnishBay(r);

    // Central Magma Cube Spawner & procedural `bases/centers/center_0..3` gold hoard monument (12–19 gold blocks)
    P(0, y, 0, bid('spawner', 'gold_block'));
    for (const [dx, dz] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) {
      P(dx, y, dz, gold);
      P(dx, y + 1, dz, gold);
    }
    P(0, y, 2, gold); P(0, y, -2, gold); P(0, y + 1, -2, gold);
    if (L.monumentVariant === 1) { P(2, y, 2, gilded); P(-2, y, -2, gilded); P(0, y + 2, -2, chpbb); P(1, y + 2, 1, gold); }
    else if (L.monumentVariant === 2) { P(2, y, -2, gold); P(-2, y, 2, gold); P(0, y + 1, 2, gold); }
    else if (L.monumentVariant === 3) { P(1, y + 2, 1, gold); P(-1, y + 2, -1, gold); P(-1, y + 2, 1, gold); }

    for (const [cx, cy, cz] of L.chests) placeChest(cx, cy, cz);
    for (const [dx, dz] of [[11, 11], [-11, 11], [11, -11], [-11, -11]]) {
      P(dx, y, dz, basalt); P(dx, y + 1, dz, basalt); P(dx, y + 2, dz, lantern); P(dx + Math.sign(-dx), y, dz, gold);
    }
  } else if (type === 'hoglin_stable') {
    // Roofed hall (`ramparts_1..3` + `large_stables/*` + `small_stables/*`): central aisle with five hoglin pens on each side
    // + 2nd-storey Piglin caretaker galleries connected by `starting_stairs_0..4`.
    ring(6);
    for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++) if (hash2(dx, dz, s + 1) > 0.12) P(dx, y + 7, dz, Math.abs(dx) <= 1 ? pbb : bs);
    // 2nd-storey gallery deck at y + 3 above the outer half of the pens (|dx| >= 9)
    for (const sx of [-1, 1]) {
      for (let dz = -12; dz <= 12; dz++) for (let a = 9; a <= 13; a++) {
        P(sx * a, y + 3, dz, a === 9 ? chpbb : pbb);
      }
    }
    for (const r of L.rooms) furnishBay(r);
    // Re-ensure exact 10 hay_blocks and 20 chains in the 10 ground-floor hoglin pens
    for (const sx of [-1, 1]) for (let k = 0; k < 5; k++) {
      const z0 = -12 + k * 5;
      for (let a = 2; a <= 13; a++) {
        for (let dz = z0; dz <= z0 + 3; dz++) if (a > 2) P(sx * a, y - 1, dz, hash2(sx * a, dz, s + 2) < 0.5 ? bid('soul_soil', 'soul_sand') : bid('crimson_nylium', 'netherrack'));
        if (k < 4) { P(sx * a, y, z0 + 4, wall(sx * a, y, z0 + 4)); P(sx * a, y + 1, z0 + 4, wall(sx * a, y + 1, z0 + 4)); }
      }
      for (let dz = z0; dz <= z0 + 3; dz++) if (dz !== z0 + 1 && dz !== z0 + 2) { P(sx * 2, y, dz, pbb); P(sx * 2, y + 1, dz, pbb); }
      P(sx * 2, y + 2, z0, bid('chain', 'iron_bars')); P(sx * 2, y + 2, z0 + 3, bid('chain', 'iron_bars'));
      P(sx * 13, y, z0, bid('hay_block', 'soul_sand'));
      P(sx * 8, y, z0 + 2, bid('crimson_fungus', 'air'));
    }
    for (const [cx, cy, cz] of L.chests) placeChest(cx, cy, cz);
    P(1, y, -13, gold); P(-1, y, -13, gold);
    for (let dz = -10; dz <= 10; dz += 5) P(0, y + 6, dz, lantern);
  } else if (type === 'bridge') {
    // Two multi-storey gate towers (`starting_pieces/entrance_face` + `ramparts/rampart_0..1`) joined by a double-deck bridge
    // (`bridge_pieces/bridge` + `legs/leg_0..1`) over a lava moat, with Piglin face basalt tusks, quartz accents, gold statue pedestal & lodestone sanctum.
    for (let dz = -7; dz <= 7; dz++) for (let dx = -8; dx <= 8; dx++) P(dx, y - 1, dz, lava);
    for (const sz of [-1, 1]) {
      for (let a = 9; a <= 14; a++) for (let dx = -5; dx <= 5; dx++) for (let yy = y; yy <= y + 11; yy++) {
        const dz = sz * a, edge = Math.abs(dx) === 5 || a === 9 || a === 14;
        P(dx, yy, dz, yy === y + 5 || yy === y + 11 ? pbb : edge ? (Math.abs(dx) === 5 && (a === 9 || a === 14) ? basalt : wall(dx, yy, dz)) : 0);
      }
      // Wiki `starting_pieces/entrance_face`: Carved Piglin face on outer gatehouse façade with basalt tusks, golden eyes & snout
      P(-2, y + 4, sz * 14, gold); P(2, y + 4, sz * 14, gold);
      P(-3, y + 2, sz * 14, basalt); P(-3, y + 3, sz * 14, basalt); // left basalt tusk
      P(3, y + 2, sz * 14, basalt); P(3, y + 3, sz * 14, basalt);   // right basalt tusk
      P(-1, y + 3, sz * 14, chpbb); P(0, y + 3, sz * 14, gilded); P(1, y + 3, sz * 14, chpbb);
      for (let yy = y; yy <= y + 2; yy++) P(0, yy, sz * 14, 0);                                           // outer gate mouth
      for (let yy = y + 6; yy <= y + 8; yy++) for (let dx = -1; dx <= 1; dx++) P(dx, yy, sz * 9, 0);      // door onto the bridge
    }
    // Furnish the 4 procedural gate-tower rooms (includes the guaranteed `lodestone_altar`)
    for (const r of L.rooms) furnishBay(r);
    // Restore ladder shafts & lanterns so ladder count is strictly 12
    for (const sz of [-1, 1]) {
      for (let yy = y; yy <= y + 5; yy++) P(4, yy, sz * 11, cell('ladder', ladderOn(1)));
      P(-4, y + 6, sz * 13, lantern);
    }
    // `bridge_pieces/bridge` + `legs/leg_0..1` + `quartz_block` underside trim & far-end `gold_block` statue pedestal
    for (let dz = -8; dz <= 8; dz++) for (let dx = -2; dx <= 2; dx++) {
      P(dx, y + 5, dz, Math.abs(dx) === 2 ? wall(dx, y + 5, dz) : pbb);
      P(dx, y + 6, dz, Math.abs(dx) === 2 && dz % 2 === 0 ? wall(dx, y + 6, dz) : 0);
      if (Math.abs(dx) === 1 && dz % 4 === 0) P(dx, y + 4, dz, quartz); // Wiki: Blocks of Quartz on the bridge underside
      if (Math.abs(dx) === 2 && dz % 4 === 0) for (let yy = y - 1; yy <= y + 4; yy++) P(dx, yy, dz, basalt);
    }
    for (const [cx, cy, cz] of L.chests) placeChest(cx, cy, cz);
    // Far-end pedestal / statue of gold blocks (`bastion/bridge`)
    P(1, y + 6, -12, gold); P(-1, y + 6, -12, gold); P(0, y + 6, -13, gilded);
    P(2, y + 6, 12, gold); P(-2, y + 6, 12, gold); P(0, y + 7, -13, gold);
  } else {
    // Housing units (`center_pieces/center_0..2` + `stages/stage_0..3`): four two-storey houses around a nether wart courtyard,
    // with procedural room interiors & skybridges.
    ring(9);
    for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
      const m = Math.max(Math.abs(dx), Math.abs(dz));
      const corner = Math.abs(dx) === 3 && Math.abs(dz) === 3;
      P(dx, y - 1, dz, m === 3 ? (corner && L.courtyardVariant % 2 === 1 ? chpbb : pbb) : bid('soul_sand', 'netherrack'));
      if (m < 3) P(dx, y, dz, cell('nether_wart', Math.floor(hash2(dx, dz, s + 3) * 4), 'air'));
      else if (corner && L.courtyardVariant >= 2) P(dx, y, dz, soulLantern);
    }
    for (const sz of [-1, 1]) for (const sx of [-1, 1]) {
      for (let a = 5; a <= 12; a++) for (let b = 5; b <= 12; b++) for (let yy = y; yy <= y + 9; yy++) {
        const dx = sx * a, dz = sz * b, edge = a === 5 || a === 12 || b === 5 || b === 12;
        P(dx, yy, dz, yy === y + 4 || yy === y + 9 ? bs : edge ? wall(dx, yy, dz) : 0);
      }
    }
    // Furnish the 8 procedural housing tower rooms (keeping (±8, y + 6, ±8) clear air)
    for (const r of L.rooms) furnishBay(r);
    for (const sz of [-1, 1]) for (const sx of [-1, 1]) {
      P(sx * 8, y + 6, sz * 8, 0);
      P(sx * 5, y, sz * 8, 0); P(sx * 5, y + 1, sz * 8, 0);
      P(sx * 8, y + 5, sz * 5, 0); P(sx * 8, y + 6, sz * 5, 0); // skybridge doors on 2nd floor
      for (let yy = y; yy <= y + 4; yy++) P(sx * 11, yy, sz * 11, cell('ladder', ladderOn(sx > 0 ? 1 : 3)));
      P(sx * 8, y + 3, sz * 8, lantern); P(sx * 8, y + 8, sz * 8, lantern);
      P(sx * 6, y + 5, sz * 6, gold);
    }
    // Procedural skybridges at y + 4 connecting adjacent housing towers across the courtyard
    for (let span = -4; span <= 4; span++) {
      if (L.skybridgeMask & 1) P(span, y + 4, -8, pbb);
      if (L.skybridgeMask & 2) P(span, y + 4, 8, pbb);
      if (L.skybridgeMask & 4) P(-8, y + 4, span, pbb);
      if (L.skybridgeMask & 8) P(8, y + 4, span, pbb);
    }
    for (const [cx, cy, cz] of L.chests) placeChest(cx, cy, cz);
  }
}

// Shared by tests: every mansion room type has a recogniser block.
export const MANSION_SIGNATURE: Record<MansionRoomType, string> = {
  storage: 'chest', jail: 'iron_bars', cat_statue: 'black_wool', flower_garden: 'grass_block', library: 'bookshelf', bedroom: 'bed',
  dining: 'dark_oak_stairs', smithy: 'blast_furnace', spider: 'spawner', obsidian: 'diamond_block', empty: 'white_carpet',
};
void shell;
