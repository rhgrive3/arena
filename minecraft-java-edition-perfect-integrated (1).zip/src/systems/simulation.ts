import { BLOCKS, ID } from '../game/data';
import type { Vector3 } from 'three';
import { Fluids, type FluidHost } from './fluids';
interface Node{x:number;y:number;z:number;id:number;level:number;}
export class Simulation {
  queue:Node[]=[];queued=new Set<string>();tnt=new Map<string,number>();ticks=0;fluids:Fluids;
  constructor(public host:{getBlock(x:number,y:number,z:number):number;getCell?(x:number,y:number,z:number):number;dimension?():string;setBlock(x:number,y:number,z:number,id:number,state?:number):boolean;explode(p:Vector3,r:number):void;toast(j:string,e:string):void;sound(k:string,p?:any):void;toggleDoor?(x:number,y:number,z:number,open:boolean):void;fluidHooks?:Partial<FluidHost>;}){this.fluids=new Fluids({...host.fluidHooks,getCell:(x,y,z)=>host.getCell?host.getCell(x,y,z):host.getBlock(x,y,z),setBlock:(x,y,z,id,s=0)=>host.setBlock(x,y,z,id,s),dimension:()=>host.dimension?.()??'overworld',sound:(k,p)=>host.sound(k,p)});}
  enqueue(x:number,y:number,z:number,id:number,level=0){const key=x+','+y+','+z;if(this.queued.has(key)||this.queue.length>6000)return;this.queued.add(key);this.queue.push({x,y,z,id,level});}
  notify(x:number,y:number,z:number,id:number){this.fluids.onBlockChanged(x,y,z);if([ID.sand,ID.gravel,ID.tnt,ID.redstone_wire,ID.lever,ID.piston,ID.sticky_piston,ID.redstone_lamp,ID.unlit_redstone_lamp].includes(id))this.enqueue(x,y,z,id);for(const [dx,dy,dz] of [[0,1,0],[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1]]){const n=this.host.getBlock(x+dx,y+dy,z+dz);if(n===ID.sand||n===ID.gravel)this.enqueue(x+dx,y+dy,z+dz,n);}}
  /** Powers (or unpowers) everything reachable from a lever/button at x,y,z. `support` is the block it is mounted on, which is powered too (vanilla strong power). */
  toggleLever(x:number,y:number,z:number,on=true,support?:[number,number,number]){const seen=new Set<string>(),queue:[number,number,number,number][]=[[x,y,z,15]];if(support)queue.push([support[0],support[1],support[2],15]);let lamps=0,pistons=0;for(let i=0;i<queue.length&&i<600;i++){const [a,b,c,p]=queue[i],key=a+','+b+','+c;if(seen.has(key)||p<=0)continue;seen.add(key);for(const [dx,dy,dz] of [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){const nx=a+dx,ny=b+dy,nz=c+dz,id=this.host.getBlock(nx,ny,nz);if(id===ID.redstone_wire)queue.push([nx,ny,nz,p-1]);if(id===ID.unlit_redstone_lamp||id===ID.redstone_lamp){this.host.setBlock(nx,ny,nz,on?ID.redstone_lamp:ID.unlit_redstone_lamp);lamps++;}if(id===ID.piston||id===ID.sticky_piston){if(on)this.push(nx,ny,nz,dx,dy,dz);pistons++;}if(BLOCKS[id]?.shape==='door')this.host.toggleDoor?.(nx,ny,nz,on);}}
    void lamps;void pistons;}
  push(x:number,y:number,z:number,dx:number,dy:number,dz:number){const bx=x+dx,by=y+dy,bz=z+dz,id=this.host.getBlock(bx,by,bz);if(id>0&&id!==ID.bedrock&&this.host.getBlock(bx+dx,by+dy,bz+dz)===0){this.host.setBlock(bx+dx,by+dy,bz+dz,id);this.host.setBlock(bx,by,bz,0);}}
  update(dt:number,vector:(x:number,y:number,z:number)=>Vector3){this.ticks++;this.fluids.update(dt);const budget=48,start=performance.now();let processed=0;while(this.queue.length&&processed++<budget&&performance.now()-start<2){const n=this.queue.shift()!;this.queued.delete(n.x+','+n.y+','+n.z);const current=this.host.getBlock(n.x,n.y,n.z);if(current!==n.id)continue;
      if(n.id===ID.sand||n.id===ID.gravel){const bl=this.host.getBlock(n.x,n.y-1,n.z);if(bl===0||bl===ID.water||bl===ID.lava){this.host.setBlock(n.x,n.y-1,n.z,n.id);this.host.setBlock(n.x,n.y,n.z,0);}continue;}
      if(n.id===ID.tnt){const key=n.x+','+n.y+','+n.z;if(!this.tnt.has(key)){this.tnt.set(key,4);this.host.sound('grass',n);}continue;}
    }
    for(const [key,time] of this.tnt){const t=time-dt;if(t<=0){this.tnt.delete(key);const [x,y,z]=key.split(',').map(Number);if(this.host.getBlock(x,y,z)===ID.tnt)this.host.explode(vector(x+.5,y+.5,z+.5),4);}else this.tnt.set(key,t);}
  }
  clear(){this.queue=[];this.queued.clear();this.tnt.clear();this.fluids.clear();}
}
