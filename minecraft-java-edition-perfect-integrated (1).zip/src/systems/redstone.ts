import { computeRailState } from './vanillaPlus';
import { BLOCKS, ID } from '../game/data';
import { isPistonImmovable, PISTON_BREAKS } from '../game/vanilla';
import type { PistonMove } from '../render/pistons';

export type { PistonMove };

/*
 * Redstone simulation engine (Record 014 Perfected + Java Edition Wiki Fidelity).
 *
 * State layout per component (low 4 bits of the 16-bit cell):
 *   redstone_wire           0..15 = signal strength
 *   lever / *_button        0..5  = attachment (0 floor, 1 +X wall, 2 -X, 3 +Z, 4 -Z, 5 ceiling), bit 3 = active
 *   *_pressure_plate        bit 3 = pressed
 *   redstone_torch          0..4  = attachment (0 floor, 1..4 wall); unlit_redstone_torch is the off variant
 *   repeater                0..1  = facing (0 +X, 1 +Z, 2 -X, 3 -Z), bits 2..3 = extra delay (0..3 → 1..4 redstone ticks)
 *   comparator              0..1  = facing, bit 2 = subtract mode, bit 3 = lit
 *   piston / sticky_piston  0..2  = facing (0 +X, 1 +Z, 2 -X, 3 -Z, 4 +Y, 5 -Y), bit 3 = extended
 *   piston_head             0..2  = facing, bit 3 = sticky
 *   observer / dispenser / dropper / hopper / crafter: 0..2 = facing, bit 3 = triggered
 *   daylight_detector / inverted_daylight_detector: 0..15 = signal strength
 *   detector_rail / powered_rail / activator_rail: bit 0 = powered/active
 */

export interface RedstoneHost {
  getCell(x: number, y: number, z: number): number;
  setBlock(x: number, y: number, z: number, id: number, state?: number): boolean;
  containerSignal?(x: number, y: number, z: number): number;
  /** Analog output of a block (inventory fullness, cauldron level, disc number …); null when the block has none. */
  analogSignal?(x: number, y: number, z: number): number | null;
  /** Comparator reading that replaces everything else (sculk sensor frequency, bookshelf slot, cauldron level); -1 = none. */
  comparatorOverride?(x: number, y: number, z: number): number;
  /** Input-side cell of a calibrated sculk sensor: it never outputs in that direction. */
  sensorBack?(x: number, y: number, z: number): readonly [number, number, number] | null;
  eject?(x: number, y: number, z: number, dir: number, kind: 'dispenser' | 'dropper'): void;
  transfer?(x: number, y: number, z: number, dir: number): boolean;
  door?(x: number, y: number, z: number, open: boolean): void;
  ignite?(x: number, y: number, z: number): void;
  daylight?(x?: number, y?: number, z?: number): number;
  craft?(x: number, y: number, z: number, dir: number): void | boolean;
  crushed?(x: number, y: number, z: number, cell: number): void;
  moved?(blocks: { x: number; y: number; z: number; id: number; state: number }[], dir: readonly [number, number, number]): void;
  moveBlocks?(moves: PistonMove[], duration: number): void;
  pushEntities?(moves: PistonMove[], dir: readonly [number, number, number], slimeBounce: boolean): void;
  sound?(kind: string, x: number, y: number, z: number): void;
}

type Pos = readonly [number, number, number];
const FACE: readonly Pos[] = [[1, 0, 0], [0, 0, 1], [-1, 0, 0], [0, 0, -1], [0, 1, 0], [0, -1, 0]];
const DIRS: readonly Pos[] = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const HDIRS: readonly Pos[] = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];
const key = (x: number, y: number, z: number) => `${x},${y},${z}`;
const idOf = (cell: number) => (cell < 0 ? -1 : cell & 4095);
const stOf = (cell: number) => (cell < 0 ? 0 : (cell >>> 12) & 15);
const parseCache = new Map<string, Pos>();
const parse = (k: string): Pos => {
  let p = parseCache.get(k);
  if (!p) {
    const c1 = k.indexOf(','), c2 = k.indexOf(',', c1 + 1);
    p = [Number(k.slice(0, c1)), Number(k.slice(c1 + 1, c2)), Number(k.slice(c2 + 1))];
    if (parseCache.size > 32768) parseCache.clear();
    parseCache.set(k, p);
  }
  return p;
};

const MAX_RS_IDS = 1024;
const LUT_BUTTON = new Uint8Array(MAX_RS_IDS);
const LUT_PLATE = new Uint8Array(MAX_RS_IDS);
const LUT_DOOR = new Uint8Array(MAX_RS_IDS);
const LUT_REDSTONE = new Uint8Array(MAX_RS_IDS);
let rsLutCount = -1;
let names: string[] | null = null;
const nameOf = (id: number) => {
  if (!names || rsLutCount !== BLOCKS.length) ensureRsLuts();
  return names![id] ?? '';
};

function ensureRsLuts() {
  if (rsLutCount === BLOCKS.length) return;
  rsLutCount = BLOCKS.length;
  names = [];
  for (const n in ID) names[ID[n]] = n;
  for (let i = 1; i < BLOCKS.length && i < MAX_RS_IDS; i++) {
    const nm = names[i] ?? BLOCKS[i]?.name ?? '';
    const btn = nm.endsWith('_button');
    const plt = nm.endsWith('_pressure_plate');
    const dr = nm.endsWith('_door') || nm.endsWith('_trapdoor') || nm.endsWith('_fence_gate');
    LUT_BUTTON[i] = btn ? 1 : 0;
    LUT_PLATE[i] = plt ? 1 : 0;
    LUT_DOOR[i] = dr ? 1 : 0;
    const isRs =
      i === ID.redstone_wire ||
      i === ID.lever ||
      btn ||
      plt ||
      dr ||
      i === ID.redstone_torch ||
      i === ID.unlit_redstone_torch ||
      i === ID.repeater ||
      i === ID.comparator ||
      i === ID.piston ||
      i === ID.sticky_piston ||
      i === ID.piston_head ||
      i === ID.redstone_lamp ||
      i === ID.unlit_redstone_lamp ||
      i === ID.dispenser ||
      i === ID.dropper ||
      i === ID.observer ||
      i === ID.hopper ||
      i === ID.daylight_detector ||
      i === ID.inverted_daylight_detector ||
      i === ID.copper_bulb ||
      i === ID.copper_bulb_lit ||
      i === ID.crafter ||
      i === ID.target ||
      i === ID.tnt ||
      i === ID.note_block ||
      i === ID.rail ||
      i === ID.powered_rail ||
      i === ID.detector_rail ||
      i === ID.activator_rail ||
      i === ID.sculk_sensor ||
      i === ID.calibrated_sculk_sensor ||
      i === ID.tripwire_hook ||
      i === ID.lightning_rod ||
      i === ID.trapped_chest ||
      i === ID.redstone_block;
    LUT_REDSTONE[i] = isRs ? 1 : 0;
  }
}

const isWire = (id: number) => id === ID.redstone_wire;
const isLever = (id: number) => id === ID.lever;
const isButton = (id: number) => { ensureRsLuts(); return id > 0 && id < MAX_RS_IDS && LUT_BUTTON[id] === 1; };
const isPlate = (id: number) => { ensureRsLuts(); return id > 0 && id < MAX_RS_IDS && LUT_PLATE[id] === 1; };
const isTorch = (id: number) => id === ID.redstone_torch || id === ID.unlit_redstone_torch;
const isRepeater = (id: number) => id === ID.repeater;
const isComparator = (id: number) => id === ID.comparator;
const isPiston = (id: number) => id === ID.piston || id === ID.sticky_piston;
const isLamp = (id: number) => id === ID.redstone_lamp || id === ID.unlit_redstone_lamp;
const isDoor = (id: number) => { ensureRsLuts(); return id > 0 && id < MAX_RS_IDS && LUT_DOOR[id] === 1; };
const isEmitter = (id: number) => id === ID.dispenser || id === ID.dropper;
const isDaylight = (id: number) => id === ID.daylight_detector || id === ID.inverted_daylight_detector;
const isBulb = (id: number) => id === ID.copper_bulb || id === ID.copper_bulb_lit;
const isSticky = (id: number) => id > 0 && (id === ID.slime_block || id === ID.honey_block);
const sticksTo = (a: number, b: number) => {
  if (isSticky(a) && (b === ID.obsidian || b === ID.crying_obsidian || b === ID.bedrock)) return false;
  if (isSticky(b) && (a === ID.obsidian || a === ID.crying_obsidian || a === ID.bedrock)) return false;
  return !((a === ID.slime_block && b === ID.honey_block) || (a === ID.honey_block && b === ID.slime_block));
};
const isHook = (id: number) => id > 0 && id === ID.tripwire_hook;
const isSensor = (id: number) => id > 0 && (id === ID.sculk_sensor || id === ID.calibrated_sculk_sensor);
const isAttachable = (id: number) => isLever(id) || isButton(id) || isTorch(id) || isHook(id);
const isRedstone = (id: number) => { ensureRsLuts(); return id > 0 && id < MAX_RS_IDS && LUT_REDSTONE[id] === 1; };
const isRailId = (id: number) => id === ID.rail || id === ID.powered_rail || id === ID.detector_rail || id === ID.activator_rail;
const isCoralFanId = (id: number) => {
  if (id <= 0) return false;
  const n = nameOf(id);
  return n.endsWith('_coral') || n === 'dead_bush';
};

function supportOf(x: number, y: number, z: number, state: number): Pos {
  switch (state & 7) {
    case 1: return [x - 1, y, z];
    case 2: return [x + 1, y, z];
    case 3: return [x, y, z - 1];
    case 4: return [x, y, z + 1];
    case 5: return [x, y + 1, z];
    default: return [x, y - 1, z];
  }
}

export class Redstone {
  active = new Set<string>();
  private lit = new Set<string>();
  private repOut = new Map<string, number>();
  private repTimers = new Map<string, number>();
  private repTarget = new Map<string, number>();
  private repMinUntil = new Map<string, number>();
  private compOut = new Map<string, number>();
  private observers = new Map<string, { face: number; last: number }>();
  private pulses = new Map<string, number>();
  private edges = new Map<string, boolean>();
  private ignited = new Set<string>();
  private warned = new Set<string>();
  private writeDepth = 0;
  private pending = new Set<string>();
  private updates = new Set<string>();
  private qcState = new Map<string, { direct: boolean; eff: boolean }>();
  private cooldown = new Map<string, number>();
  private buttonTimers = new Map<string, number>();
  private sensorTimers = new Map<string, number>();
  private burnoutHistory = new Map<string, number[]>();
  private burnoutUntil = new Map<string, number>();
  private pistonPush = new Map<string, { tick: number; pushed: boolean; byObserver: boolean }>();
  private motions: { owner: string; until: number; blocks: { x: number; y: number; z: number; cell: number }[] }[] = [];
  ticks = 0;
  changes = 0;

  constructor(public host: RedstoneHost) {}

  private at(x: number, y: number, z: number) {
    const cell = this.host.getCell(x, y, z);
    return { cell, id: idOf(cell), state: stOf(cell) };
  }
  set(x: number, y: number, z: number, id: number, state = 0) {
    this.writeDepth++;
    let ok = false;
    try { ok = this.host.setBlock(x, y, z, id, state); } finally { this.writeDepth--; }
    if (ok) {
      this.register(x, y, z);
      this.blockChanged(x, y, z);
      this.changes++;
    } else {
      this.register(x, y, z);
    }
    return ok;
  }

  setExternal(x: number, y: number, z: number, id: number, state = 0) {
    return this.set(x, y, z, id, state);
  }

  blockChanged(x: number, y: number, z: number) {
    this.pending.add(key(x, y, z));
    if (this.observers.size > 0) for (const [k, o] of this.observers) {
      const [ox, oy, oz] = parse(k), f = FACE[o.face];
      if (ox + f[0] === x && oy + f[1] === y && oz + f[2] === z) {
        o.last = this.snapshot(this.at(x, y, z), x, y, z);
        this.pulses.set(k, 2);
      }
    }
  }

  register(x: number, y: number, z: number) {
    const { cell, id, state } = this.at(x, y, z);
    if (cell >= 0 && isRedstone(id)) {
      const k = key(x, y, z);
      this.active.add(k);
      if (id === ID.redstone_torch) this.lit.add(k);
      if (id === ID.observer && !this.observers.has(k)) {
        const f = FACE[state & 7];
        this.observers.set(k, { face: state & 7, last: this.snapshot(this.at(x + f[0], y + f[1], z + f[2]), x + f[0], y + f[1], z + f[2]) });
      }
    } else {
      const k = key(x, y, z);
      this.active.delete(k);
      this.lit.delete(k);
      this.repOut.delete(k);
      this.repTimers.delete(k);
      this.repTarget.delete(k);
      this.repMinUntil.delete(k);
      this.compOut.delete(k);
      this.observers.delete(k);
      this.pulses.delete(k);
      this.edges.delete(k);
      this.ignited.delete(k);
      this.qcState.delete(k);
      this.cooldown.delete(k);
      this.buttonTimers.delete(k);
      this.sensorTimers.delete(k);
      this.burnoutHistory.delete(k);
      this.burnoutUntil.delete(k);
      this.pistonPush.delete(k);
    }
    if (this.writeDepth === 0) this.pending.add(key(x, y, z));
  }

  scanChunk(data: Uint16Array, cx: number, cz: number, height = 384, minY = -64, maxY?: number) {
    ensureRsLuts();
    const lut = LUT_REDSTONE;
    const maxLy = maxY !== undefined ? Math.min(height, Math.max(0, maxY - minY)) : Math.min(height, data.length >> 8);
    const ox = cx * 16, oz = cz * 16;
    for (let ly = 0; ly < maxLy; ly++) {
      const yBase = ly * 256;
      for (let z = 0; z < 16; z++) {
        const row = yBase + z * 16;
        for (let x = 0; x < 16; x++) {
          const cell = data[row + x];
          if (cell === 0) continue;
          const id = cell & 4095;
          if (lut[id] === 1) this.register(ox + x, ly + minY, oz + z);
        }
      }
    }
  }

  unloadChunk(cx: number, cz: number) {
    const x0 = cx * 16, z0 = cz * 16;
    for (const k of [...this.active]) {
      const [x, , z] = parse(k);
      if (x >= x0 && x < x0 + 16 && z >= z0 && z < z0 + 16) {
        this.active.delete(k);
        this.lit.delete(k);
        this.repOut.delete(k);
        this.repTimers.delete(k);
        this.repTarget.delete(k);
        this.repMinUntil.delete(k);
        this.compOut.delete(k);
        this.observers.delete(k);
        this.pulses.delete(k);
        this.edges.delete(k);
        this.ignited.delete(k);
        this.qcState.delete(k);
        this.cooldown.delete(k);
        this.buttonTimers.delete(k);
        this.sensorTimers.delete(k);
        this.burnoutHistory.delete(k);
        this.burnoutUntil.delete(k);
        this.pistonPush.delete(k);
      }
    }
  }

  reset() {
    this.active.clear();
    this.lit.clear();
    this.repOut.clear();
    this.repTimers.clear();
    this.repTarget.clear();
    this.repMinUntil.clear();
    this.compOut.clear();
    this.observers.clear();
    this.pulses.clear();
    this.edges.clear();
    this.ignited.clear();
    this.pending.clear();
    this.updates.clear();
    this.qcState.clear();
    this.cooldown.clear();
    this.buttonTimers.clear();
    this.sensorTimers.clear();
    this.burnoutHistory.clear();
    this.burnoutUntil.clear();
    this.pistonPush.clear();
    this.lockedSet.clear();
    this.motions = [];
  }

  private finishMotions(force = false) {
    if (!this.motions.length) return;
    const ready = this.motions.filter(m => force || this.ticks >= m.until);
    if (!ready.length) return;
    this.motions = this.motions.filter(m => !ready.includes(m));
    for (const motion of ready) {
      for (const b of motion.blocks) {
        if (this.at(b.x, b.y, b.z).id === ID.moving_piston) {
          const owner = parse(motion.owner);
          const headWithoutBase = idOf(b.cell) === ID.piston_head && !isPiston(this.at(owner[0], owner[1], owner[2]).id);
          const cid = headWithoutBase ? 0 : idOf(b.cell), cst = headWithoutBase ? 0 : stOf(b.cell);
          this.set(b.x, b.y, b.z, cid, cst);
          if (cid === ID.observer) this.pulses.set(key(b.x, b.y, b.z), 3);
        }
      }
    }
  }

  flush() {
    this.finishMotions(true);
    for (const [k, exp] of [...this.buttonTimers]) {
      if (exp > 0) {
        const [x, y, z] = parse(k), now = this.at(x, y, z);
        if (isButton(now.id) && (now.state & 8)) this.set(x, y, z, now.id, now.state & 7);
      }
    }
    this.buttonTimers.clear();
  }

  /** Notify that an item was inserted into a hopper at (x, y, z), starting its 8-game-tick transfer cooldown if idle. */
  notifyHopper(x: number, y: number, z: number) {
    const k = key(x, y, z);
    if ((this.cooldown.get(k) ?? 0) <= this.ticks) this.cooldown.set(k, this.ticks + 8);
  }

  /** Activate a sculk sensor at (x, y, z) with power 1..15 for 10 redstone ticks. */
  triggerSensor(x: number, y: number, z: number, strength = 8, ticks = 10) {
    const { id } = this.at(x, y, z);
    if (!isSensor(id)) return;
    const k = key(x, y, z);
    this.set(x, y, z, id, Math.max(1, Math.min(15, strength)));
    this.sensorTimers.set(k, this.ticks + ticks);
  }

  /** Activate a lightning rod at (x, y, z) with power 15 for 8 game ticks (Wiki: Lightning Rod). */
  triggerLightningRod(x: number, y: number, z: number, ticks = 8) {
    const { id } = this.at(x, y, z);
    if (id !== ID.lightning_rod) return;
    const k = key(x, y, z);
    this.set(x, y, z, id, 15);
    this.sensorTimers.set(k, this.ticks + ticks);
  }

  private lastWire = new Map<string, number>();
  private lastPowered = new Map<string, Set<string>>();
  private lastBlockPower = new Map<string, number>();
  /** Signal arriving at a cell in the last solve: a direct source, wire level, a powered block, or a diode pointing at `toward`. */
  inputAt(x: number, y: number, z: number, toward?: readonly [number, number, number]): number {
    const k = key(x, y, z);
    let best = Math.max(this.directBehind([x, y, z], toward), this.lastWire.get(k) ?? 0, this.lastBlockPower.get(k) ?? 0);
    if (toward && this.pointingIn([x, y, z], toward)) best = Math.max(best, this.repOut.get(k) ?? this.compOut.get(k) ?? 0);
    return best;
  }

  private snapshot(c: { cell: number }, wx?: number, wy?: number, wz?: number) {
    const base = c.cell < 0 ? 0 : c.cell;
    if (wx !== undefined && wy !== undefined && wz !== undefined && idOf(base) === ID.observer) {
      return base | ((this.pulses.get(key(wx, wy, wz)) ?? 0) > 0 ? 0x10000 : 0);
    }
    return base;
  }
  private back(x: number, y: number, z: number, state: number): Pos {
    const f = FACE[state & 3];
    return [x - f[0], y - f[1], z - f[2]];
  }
  private side(x: number, y: number, z: number, state: number, left: number): Pos {
    const f = FACE[(state + (left ? 3 : 1)) & 3];
    return [x + f[0], y + f[1], z + f[2]];
  }

  /** True if block at (x, y, z) is an opaque conductive block in Java Edition Redstone. */
  private isConductive(x: number, y: number, z: number): boolean {
    const id = idOf(this.host.getCell(x, y, z));
    if (id <= 0) return false;
    if (id === ID.slime_block) return true;
    if (
      id === ID.hopper ||
      id === ID.dropper ||
      id === ID.dispenser ||
      id === ID.crafter ||
      id === ID.redstone_lamp ||
      id === ID.unlit_redstone_lamp ||
      id === ID.note_block ||
      id === ID.furnace ||
      id === ID.blast_furnace ||
      id === ID.smoker ||
      id === ID.barrel ||
      id === ID.observer ||
      id === ID.piston ||
      id === ID.sticky_piston ||
      id === ID.piston_head ||
      id === ID.moving_piston ||
      id === ID.tnt ||
      id === ID.glowstone ||
      id === ID.sea_lantern ||
      id === ID.shroomlight ||
      id === ID.redstone_block ||
      id === ID.chest ||
      id === ID.trapped_chest ||
      id === ID.ender_chest ||
      id === ID.cauldron ||
      id === ID.composter ||
      id === ID.lectern ||
      id === ID.daylight_detector ||
      id === ID.inverted_daylight_detector ||
      id === ID.sculk_sensor ||
      id === ID.calibrated_sculk_sensor ||
      id === ID.honey_block ||
      id === ID.glass ||
      id === ID.tinted_glass ||
      id === ID.ice
    ) {
      return false;
    }
    const d = BLOCKS[id];
    return !!d && !d.transparent && d.shape === 'cube';
  }

  /**
   * True if block at (x, y, z) is a transparent/non-conductive support block (glowstone, glass, hopper, top slab, stairs)
   * that allows redstone dust on top of it to transmit diagonally UP onto it, but NEVER diagonally DOWN from it
   * (Wiki: Redstone circuits/Transmission#Transparent_diode).
   */
  private isUpOnlyDiodeSupport(x: number, y: number, z: number): boolean {
    const id = idOf(this.host.getCell(x, y, z));
    if (id <= 0) return false;
    return !this.isConductive(x, y, z);
  }

  /** True if redstone dust at (x, y, z) forms a horizontal visual/electrical connection toward (nx, y, nz). */
  private wireConnectsToward(x: number, y: number, z: number, dx: number, dz: number): boolean {
    const nx = x + dx, nz = z + dz;
    const nid = idOf(this.host.getCell(nx, y, nz)), nst = stOf(this.host.getCell(nx, y, nz));
    if (isWire(nid)) return true;
    if (
      isLever(nid) ||
      isButton(nid) ||
      isPlate(nid) ||
      isTorch(nid) ||
      nid === ID.redstone_block ||
      nid === ID.target ||
      nid === ID.detector_rail ||
      isDaylight(nid) ||
      isHook(nid) ||
      isSensor(nid) ||
      nid === ID.trapped_chest ||
      nid === ID.lightning_rod
    ) {
      return true;
    }
    if (isRepeater(nid) || isComparator(nid)) {
      const f = FACE[nst & 3];
      return (f[0] === dx && f[2] === dz) || (f[0] === -dx && f[2] === -dz);
    }
    if (nid === ID.observer) {
      const f = FACE[nst & 7];
      return nx - f[0] === x && nz - f[2] === z;
    }
    // Diagonal up or down wire connection
    if (!this.isConductive(x, y + 1, z) && isWire(idOf(this.host.getCell(nx, y + 1, nz)))) return true;
    if (!this.isConductive(nx, y, nz) && isWire(idOf(this.host.getCell(nx, y - 1, nz)))) return true;
    return false;
  }

  private strongPower = new Map<string, number>();
  private toggledTorches = new Set<string>();

  private solver() {
    const wire = this.lastWire;
    const powered = this.lastPowered;
    const blockPower = this.lastBlockPower;
    const strongPower = this.strongPower;
    const solid = (x: number, y: number, z: number) => this.isConductive(x, y, z);
    const toggledTorches = this.toggledTorches;
    toggledTorches.clear();

    // Collect non-wire active devices and torches once before pass loop
    const devices: [string, number, number, number, number, number][] = [];
    const torches: [string, number, number, number, number][] = [];
    for (const k of this.active) {
      const [x, y, z] = parse(k), { id, state } = this.at(x, y, z);
      if (isWire(id) || id <= 0) continue;
      devices.push([k, x, y, z, id, state]);
      if (isTorch(id)) torches.push([k, x, y, z, state]);
    }
    const hasTorches = torches.length > 0;

    const addPower = (p: Pos, src: string, isStrong: boolean, level = 15) => {
      if (level <= 0) return;
      const k = key(p[0], p[1], p[2]);
      if (hasTorches) {
        let s = powered.get(k);
        if (!s) { s = new Set(); powered.set(k, s); }
        s.add(src);
      }
      if (solid(p[0], p[1], p[2]) || (isStrong && isPiston(idOf(this.host.getCell(p[0], p[1], p[2]))) && isLever(idOf(this.host.getCell(...parse(src)))))) {
        const prev = blockPower.get(k) ?? 0;
        if (level > prev) blockPower.set(k, level);
        if (isStrong) {
          const sp = strongPower.get(k) ?? 0;
          if (level > sp) strongPower.set(k, level);
        }
      }
    };

    for (let pass = 0; pass < 4; pass++) {
      wire.clear();
      if (hasTorches) powered.clear();
      blockPower.clear();
      strongPower.clear();
      const seeds: [string, number][] = [];
      const pushWire = (x: number, y: number, z: number, level: number) => {
        const id = idOf(this.host.getCell(x, y, z));
        if (!isWire(id)) return;
        const k = key(x, y, z), cur = wire.get(k) ?? 0;
        const clamped = Math.min(15, level);
        if (clamped > cur) { wire.set(k, clamped); seeds.push([k, clamped]); }
      };

      for (let di = 0; di < devices.length; di++) {
        const [k, x, y, z, id, state] = devices[di];
        let strength = 0;
        if (isLever(id) && state & 8) strength = 15;
        else if (isButton(id) && state & 8) strength = 15;
        else if (isPlate(id) && state & 8) strength = 15;
        else if (id === ID.redstone_block) strength = 15;
        else if (isDaylight(id)) strength = state & 15;
        else if (id === ID.detector_rail && state & 1) strength = 15;
        else if (isSensor(id) && (state & 15) > 0) strength = state & 15;
        else if (isHook(id) && state & 8) strength = 15;
        else if (id === ID.target) strength = state & 15;
        else if (id === ID.lightning_rod && (state & 15) > 0) strength = 15;
        else if (id === ID.trapped_chest && (state & 15) > 0) strength = state & 15;
        else if (isRepeater(id)) strength = this.repOut.get(k) ?? 0;
        else if (isComparator(id)) strength = this.compOut.get(k) ?? 0;
        else if (isTorch(id) && this.lit.has(k)) strength = 15;
        else if (id === ID.observer && (this.pulses.get(k) ?? 0) > 0) strength = 15;
        if (!strength) continue;

        if (isAttachable(id) || isPlate(id)) {
          const sup = supportOf(x, y, z, state);
          if (isTorch(id)) {
            const above: Pos = [x, y + 1, z];
            addPower(above, k, solid(above[0], above[1], above[2]), 15);
            addPower([x, y, z], k, false, 15);
            pushWire(above[0], above[1], above[2], 15);
          } else {
            addPower(sup, k, true, strength);
          }
          for (const d of DIRS) pushWire(x + d[0], y + d[1], z + d[2], strength);
        } else if (isRepeater(id) || isComparator(id)) {
          const f = FACE[state & 3];
          const out: Pos = [x + f[0], y + f[1], z + f[2]];
          pushWire(out[0], out[1], out[2], strength);
          addPower(out, k, solid(out[0], out[1], out[2]), strength);
        } else if (id === ID.redstone_block) {
          for (const d of DIRS) {
            const p: Pos = [x + d[0], y + d[1], z + d[2]];
            pushWire(p[0], p[1], p[2], 15);
            if (solid(p[0], p[1], p[2])) addPower(p, k, false, 15);
          }
          if (idOf(this.host.getCell(x, y - 1, z)) === ID.stone) {
            for (const hd of HDIRS) pushWire(x + hd[0], y - 1, z + hd[2], 15);
          }
        } else if (isDaylight(id) || id === ID.target || id === ID.detector_rail || isSensor(id) || id === ID.lightning_rod || id === ID.trapped_chest) {
          if (id === ID.lightning_rod || id === ID.trapped_chest || id === ID.detector_rail) {
            addPower([x, y - 1, z], k, solid(x, y - 1, z), strength);
          }
          const skip = id === ID.calibrated_sculk_sensor ? this.host.sensorBack?.(x, y, z) : null;
          for (const d of DIRS) {
            if (skip && x + d[0] === skip[0] && y + d[1] === skip[1] && z + d[2] === skip[2]) continue;
            pushWire(x + d[0], y + d[1], z + d[2], strength);
            if (solid(x + d[0], y + d[1], z + d[2])) addPower([x + d[0], y + d[1], z + d[2]], k, true, strength);
          }
        } else if (id === ID.observer) {
          const f = FACE[state & 7], b: Pos = [x - f[0], y - f[1], z - f[2]];
          addPower(b, k, solid(b[0], b[1], b[2]), 15);
          pushWire(b[0], b[1], b[2], 15);
        }
      }

      for (const [bk, sLevel] of strongPower) {
        const [bx, by, bz] = parse(bk);
        for (const d of DIRS) pushWire(bx + d[0], by + d[1], bz + d[2], sLevel);
      }

      for (let head = 0; head < seeds.length; head++) {
        const [k, level] = seeds[head];
        if (level <= 1) continue;
        const [x, y, z] = parse(k);
        // 1. Cardinal wire neighbors
        for (const d of DIRS) {
          const nx = x + d[0], ny = y + d[1], nz = z + d[2];
          if (!isWire(idOf(this.host.getCell(nx, ny, nz)))) continue;
          const nk = key(nx, ny, nz), cur = wire.get(nk) ?? 0;
          if (cur < level - 1) { wire.set(nk, level - 1); seeds.push([nk, level - 1]); }
        }
        // 2. Diagonal vertical step-up & step-down (lazily evaluated only when diagonal wire exists)
        let cutAboveHere = -1;
        let upOnlyHere = -1;
        for (const hd of HDIRS) {
          const nx = x + hd[0], nz = z + hd[2];
          if (isWire(idOf(this.host.getCell(nx, y + 1, nz)))) {
            if (cutAboveHere < 0) cutAboveHere = solid(x, y + 1, z) ? 1 : 0;
            if (!cutAboveHere) {
              const nk = key(nx, y + 1, nz), cur = wire.get(nk) ?? 0;
              if (cur < level - 1) { wire.set(nk, level - 1); seeds.push([nk, level - 1]); }
            }
          }
          if (isWire(idOf(this.host.getCell(nx, y - 1, nz)))) {
            if (upOnlyHere < 0) upOnlyHere = this.isUpOnlyDiodeSupport(x, y - 1, z) ? 1 : 0;
            if (!upOnlyHere && !solid(nx, y, nz)) {
              const nk = key(nx, y - 1, nz), cur = wire.get(nk) ?? 0;
              if (cur < level - 1) { wire.set(nk, level - 1); seeds.push([nk, level - 1]); }
            }
          }
        }
      }

      // Wire weakly powers the solid block beneath it [x, y - 1, z] and horizontal solid neighbors
      for (const [k, level] of wire) {
        if (level <= 0) continue;
        const [x, y, z] = parse(k);
        const wk = hasTorches ? 'w:' + k : '';
        if (solid(x, y - 1, z)) addPower([x, y - 1, z], wk, false, level);
        for (const hd of HDIRS) {
          const px = x + hd[0], pz = z + hd[2];
          if (solid(px, y, pz)) addPower([px, y, pz], wk, false, level);
        }
      }

      if (!hasTorches) break;

      let changed = false;
      for (let ti = 0; ti < torches.length; ti++) {
        const [k, x, y, z, state] = torches[ti];
        if (toggledTorches.has(k)) continue;
        const burnedOut = (this.burnoutUntil.get(k) ?? 0) > this.ticks;
        const sup = supportOf(x, y, z, state), sk = key(sup[0], sup[1], sup[2]);
        const others = powered.get(sk);
        const isPowered = !!others && [...others].some(s => (s !== k && !s.startsWith('w:')) || (s.startsWith('w:') && s !== 'w:' + k));
        const shouldLight = !isPowered && !burnedOut;
        if (shouldLight && !this.lit.has(k)) {
          this.lit.add(k);
          toggledTorches.add(k);
          changed = true;
        } else if (!shouldLight && this.lit.has(k)) {
          this.lit.delete(k);
          toggledTorches.add(k);
          changed = true;
          const selfFeedback = !!others && [...others].some(s => {
            const raw = s.startsWith("w:") ? s.slice(2) : s;
            const [sx, sy, sz] = parse(raw);
            return Math.abs(sx - x) + Math.abs(sy - y) + Math.abs(sz - z) <= 2;
          });
          if (selfFeedback) {
            const hist = (this.burnoutHistory.get(k) ?? []).filter(t => t >= this.ticks - 60);
            hist.push(this.ticks);
            this.burnoutHistory.set(k, hist);
            if (hist.length >= 8) {
              this.burnoutUntil.set(k, this.ticks + 16);
            }
          }
        }
      }
      if (!changed) break;
    }
    return { wire, powered, blockPower, strongPower };
  }

  private powerOf(wire: Map<string, number>, blockPower: Map<string, number>, x: number, y: number, z: number): number {
    const k0 = key(x, y, z);
    let best = Math.max(wire.get(k0) ?? 0, blockPower.get(k0) ?? 0);
    if (best >= 15) return 15;
    const target: Pos = [x, y, z];
    for (const o of DIRS) {
      const px = x + o[0], py = y + o[1], pz = z + o[2], pk = key(px, py, pz);
      const p: Pos = [px, py, pz];
      best = Math.max(best, wire.get(pk) ?? 0, blockPower.get(pk) ?? 0, this.directBehind(p, target), this.pointingInStrength(p, target));
      if (best >= 15) return 15;
    }
    return best;
  }

  /** Wiki (Piston): A piston cannot be powered through its front face (the direction its head extends). */
  private powerOfExcept(wire: Map<string, number>, blockPower: Map<string, number>, x: number, y: number, z: number, skipFace: Pos): number {
    const k0 = key(x, y, z);
    let best = Math.max(wire.get(k0) ?? 0, blockPower.get(k0) ?? 0);
    if (best >= 15) return 15;
    const target: Pos = [x, y, z];
    for (const o of DIRS) {
      if (o[0] === skipFace[0] && o[1] === skipFace[1] && o[2] === skipFace[2]) continue;
      const px = x + o[0], py = y + o[1], pz = z + o[2], pk = key(px, py, pz);
      const p: Pos = [px, py, pz];
      best = Math.max(best, wire.get(pk) ?? 0, blockPower.get(pk) ?? 0, this.directBehind(p, target), this.pointingInStrength(p, target));
      if (best >= 15) return 15;
    }    return best;
  }

  private isRailPowered(power: (p: Pos) => number, x: number, y: number, z: number, railId: number): boolean {
    if (power([x, y, z]) > 0) return true;
    // Wiki (Powered Rail / Activator Rail): Transmits power up to 8 additional rails along connected tracks of the same type.
    const visited = new Set<string>([key(x, y, z)]);
    const queue: [number, number, number, number][] = [[x, y, z, 0]];
    for (let head = 0; head < queue.length; head++) {
      const [cx, cy, cz, dist] = queue[head];
      if (dist >= 8) continue;
      for (const hd of HDIRS) {
        for (const dy of [0, 1, -1]) {
          const nx = cx + hd[0], ny = cy + dy, nz = cz + hd[2], nk = key(nx, ny, nz);
          if (visited.has(nk)) continue;
          if (idOf(this.host.getCell(nx, ny, nz)) !== railId) continue;
          visited.add(nk);
          if (power([nx, ny, nz]) > 0) return true;
          queue.push([nx, ny, nz, dist + 1]);
        }
      }
    }
    return false;
  }

  private hasObserverPulseNear(x: number, y: number, z: number): boolean {
    for (const [ok, p] of this.pulses) {
      if (p <= 0) continue;
      const [ox, oy, oz] = parse(ok);
      if (Math.abs(ox - x) + Math.abs(oy - y) + Math.abs(oz - z) <= 3) return true;
    }
    return false;
  }

  tick() {
    this.ticks++;
    this.finishMotions();
    this.updates = this.pending;
    this.pending = new Set();
    const { wire, powered, blockPower } = this.solver();
    this.lastWire = wire;
    this.lastPowered = powered;
    this.lastBlockPower = blockPower;
    const power = (p: Pos) => this.powerOf(wire, blockPower, p[0], p[1], p[2]);
    const setEdge = (k: string, on: boolean) => {
      const prev = this.edges.get(k) ?? false;
      this.edges.set(k, on);
      return on && !prev;
    };

    const pistonRetracts: [number, number, number, number, number][] = [];
    const pistonExtends: [number, number, number, number, number][] = [];

    for (const k of [...this.active]) {
      const [x, y, z] = parse(k), { id, state } = this.at(x, y, z);
      if (id < 0) { this.active.delete(k); continue; }
      if (isWire(id)) {
        const level = wire.get(k) ?? 0;
        if (state !== level) this.set(x, y, z, id, level);
        continue;
      }
      if (isTorch(id)) {
        const wantLit = this.lit.has(k), wantId = wantLit ? ID.redstone_torch : ID.unlit_redstone_torch;
        if (id !== wantId) this.set(x, y, z, wantId, state);
        continue;
      }
      if (isRepeater(id)) {
        const dir = state & 3, f = FACE[dir], b = this.back(x, y, z, state), out = this.repOut.get(k) ?? 0;
        const bk = key(b[0], b[1], b[2]);
        const input = Math.max(
          this.directBehind(b, [x, y, z]),
          wire.get(bk) ?? 0,
          blockPower.get(bk) ?? 0,
          this.pointingInStrength(b, [x, y, z]),
        );
        const s1 = this.side(x, y, z, state, 1), s2 = this.side(x, y, z, state, 0);
        const locked = this.pointingIn(s1, [x, y, z]) || this.pointingIn(s2, [x, y, z]);
        if (locked) {
          this.repTimers.delete(k);
          this.repTarget.delete(k);
          this.lockedSet.add(k);
        } else {
          this.lockedSet.delete(k);
        }
        const want = input > 0 ? 15 : 0;
        const delay = 2 + ((state >> 2) & 3) * 2;
        if (!locked) {
          const timer = this.repTimers.get(k) ?? -1;
          const target = this.repTarget.get(k);
          if (out === 0) {
            // Turning ON: once triggered by any rising edge, finish the turn-on delay even if a 1-tick input pulse ends early.
            if (timer >= 0 && target === 15) {
              if (this.ticks >= timer) {
                this.repTimers.delete(k);
                this.repTarget.delete(k);
                this.repOut.set(k, 15);
                this.repMinUntil.set(k, this.ticks + delay);
                if (want === 0) {
                  this.repTimers.set(k, this.ticks + delay);
                  this.repTarget.set(k, 0);
                }
                this.changes++;
                const fp: Pos = [x + f[0], y + f[1], z + f[2]];
                this.host.sound?.('click', fp[0], fp[1], fp[2]);
              }
            } else if (want === 15) {
              this.repTimers.set(k, this.ticks + delay);
              this.repTarget.set(k, 15);
            }
          } else {
            // Currently ON (out === 15): stay ON at least until repMinUntil (pulse extension), then turn OFF after delay.
            const minUntil = this.repMinUntil.get(k) ?? 0;
            if (want === 15) {
              this.repTimers.delete(k);
              this.repTarget.delete(k);
            } else if (timer < 0) {
              this.repTimers.set(k, Math.max(minUntil, this.ticks + delay));
              this.repTarget.set(k, 0);
            } else if (this.ticks >= timer) {
              this.repTimers.delete(k);
              this.repTarget.delete(k);
              this.repOut.set(k, 0);
              this.changes++;
              const fp: Pos = [x + f[0], y + f[1], z + f[2]];
              this.host.sound?.('click', fp[0], fp[1], fp[2]);
            }
          }
        }
        continue;
      }
      if (isComparator(id)) {
        const b = this.back(x, y, z, state), bk = key(b[0], b[1], b[2]);
        const backCell = this.host.getCell(b[0], b[1], b[2]), backId = idOf(backCell);
        const bulbSignal = backId === ID.copper_bulb_lit ? 15 : 0;
        const analogAt = (p: Pos): number | null => {
          const ov = this.host.comparatorOverride?.(p[0], p[1], p[2]) ?? -1;
          if (ov >= 0) return ov;
          if (this.host.analogSignal) return this.host.analogSignal(p[0], p[1], p[2]);
          const pid = idOf(this.host.getCell(p[0], p[1], p[2]));
          const c = this.host.containerSignal?.(p[0], p[1], p[2]) ?? 0;
          if (isSensor(pid)) return c;
          return c > 0 ? c : null;
        };
        let input = Math.max(
          this.directBehind(b, [x, y, z]),
          bulbSignal,
          wire.get(bk) ?? 0,
          blockPower.get(bk) ?? 0,
          this.pointingInStrength(b, [x, y, z]),
        );
        const measured = analogAt(b);
        if (measured !== null) input = measured;
        else if (input < 15 && this.isConductive(b[0], b[1], b[2])) {
          const f = FACE[state & 3];
          const through = analogAt([b[0] - f[0], b[1] - f[1], b[2] - f[2]]);
          if (through !== null) input = through;
        }
        const s1 = this.side(x, y, z, state, 1), s2 = this.side(x, y, z, state, 0);
        const sideOf = (s: Pos) => {
          const sk = key(s[0], s[1], s[2]);
          return Math.max(
            this.directBehind(s, [x, y, z]),
            wire.get(sk) ?? 0,
            this.pointingInStrength(s, [x, y, z]),
          );
        };
        const side = Math.max(sideOf(s1), sideOf(s2));
        const out = state & 4 ? Math.max(0, input - side) : input >= side ? input : 0;
        if ((this.compOut.get(k) ?? 0) !== out) { this.compOut.set(k, out); this.changes++; }
        continue;
      }
      if (isLamp(id)) {
        const on = power([x, y, z]) > 0;
        const want = on ? ID.redstone_lamp : ID.unlit_redstone_lamp;
        if (id !== want) this.set(x, y, z, want, state);
        continue;
      }
      if (isPiston(id)) {
        if (this.motions.some(m => m.owner === k)) continue;
        const f = FACE[state & 7];
        const pPower = (p: Pos) =>
          p[0] === x && p[1] === y && p[2] === z
            ? this.powerOfExcept(wire, blockPower, x, y, z, f)
            : this.powerOf(wire, blockPower, p[0], p[1], p[2]);
        const on = this.mechPower(pPower, k, x, y, z), extended = (state & 8) !== 0;
        if (on && !extended) {
          pistonExtends.push([x, y, z, id, state]);
        } else if (!on && extended) {
          pistonRetracts.push([x, y, z, id, state]);
        } else if (extended && ID.piston_head !== undefined && idOf(this.host.getCell(x + f[0], y + f[1], z + f[2])) !== ID.piston_head && idOf(this.host.getCell(x + f[0], y + f[1], z + f[2])) !== ID.moving_piston) {
          this.set(x, y, z, id, state & 7);
        }
        continue;
      }
      if (id === ID.piston_head && id > 0) {
        const f = FACE[state & 7], base = this.at(x - f[0], y - f[1], z - f[2]);
        if (!(isPiston(base.id) && (base.state & 8) !== 0 && (base.state & 7) === (state & 7))) this.set(x, y, z, 0);
        continue;
      }
      if (isBulb(id)) {
        const on = power([x, y, z]) > 0;
        const prev = this.edges.has(k) ? this.edges.get(k)! : !!(state & 1);
        this.edges.set(k, on);
        const wantId = on && !prev ? (id === ID.copper_bulb ? ID.copper_bulb_lit : ID.copper_bulb) : id;
        const wantState = on ? (state | 1) : (state & 14);
        if (wantId !== id || wantState !== state) {
          this.set(x, y, z, wantId, wantState);
          if (wantId !== id) this.host.sound?.('click', x, y, z);
        }
        continue;
      }
      if (id === ID.crafter && id > 0) {
        if (setEdge(k, power([x, y, z]) > 0 || power([x, y + 1, z]) > 0)) {
          this.host.craft?.(x, y, z, state & 7);
          this.host.sound?.('click', x, y, z);
        }
        continue;
      }
      if (isDaylight(id)) {
        if (this.host.daylight) {
          const raw = this.host.daylight(x, y, z);
          const level = raw <= 1 && raw >= 0 && !Number.isInteger(raw * 15) ? Math.round(Math.max(0, Math.min(1, raw)) * 15) : raw <= 1 && (raw === 0 || raw === 1 || String(raw).includes('.')) ? Math.round(raw * 15) : Math.max(0, Math.min(15, Math.round(raw)));
          const want = id === ID.inverted_daylight_detector ? 15 - level : level;
          if (want !== (state & 15)) this.set(x, y, z, id, want);
        }
        continue;
      }
      if (isDoor(id)) {
        const on = power([x, y, z]) > 0;
        if ((this.edges.get(k) ?? false) !== on) { this.edges.set(k, on); this.host.door?.(x, y, z, on); }
        continue;
      }
      if (isEmitter(id)) {
        const on = this.mechPower(power, k, x, y, z);
        if (setEdge(k, on)) {
          const face = state & 7;
          this.host.eject?.(x, y, z, face, id === ID.dispenser ? 'dispenser' : 'dropper');
          this.host.sound?.('click', x, y, z);
        }
        continue;
      }
      if (id === ID.hopper) {
        // Locked while powered. Otherwise one item per 8 game ticks (vanilla cooldown).
        if (power([x, y, z]) === 0 && this.ticks >= (this.cooldown.get(k) ?? 0) && this.host.transfer?.(x, y, z, state & 7)) {
          this.cooldown.set(k, this.ticks + 8);
        }
        continue;
      }
      if (id === ID.note_block) {
        if (setEdge(k, power([x, y, z]) > 0)) this.host.sound?.('note', x, y, z);
        continue;
      }
      if (id === ID.tnt) {
        const hasCoralNeighbor = DIRS.some(d => isCoralFanId(idOf(this.host.getCell(x + d[0], y + d[1], z + d[2]))));
        if (!hasCoralNeighbor && power([x, y, z]) > 0 && !this.ignited.has(k)) {
          this.ignited.add(k);
          this.host.ignite?.(x, y, z);
        }
        continue;
      }
      if (id === ID.powered_rail || id === ID.activator_rail) {
        const on = this.isRailPowered(power, x, y, z, id);
        if ((state & 1) !== (on ? 1 : 0)) this.set(x, y, z, id, on ? state | 1 : state & 14);
        continue;
      }
      if (isSensor(id) || id === ID.lightning_rod) {
        const exp = this.sensorTimers.get(k);
        if (exp !== undefined && this.ticks >= exp) {
          this.sensorTimers.delete(k);
          if ((state & 15) !== 0) this.set(x, y, z, id, 0);
        }
        continue;
      }
      if (id === ID.rail) {
        const on = power([x, y, z]) > 0 || DIRS.some(d => this.directBehind([x + d[0], y + d[1], z + d[2]], [x, y, z]) > 0);
        const isR = (rx: number, ry: number, rz: number) => isRailId(idOf(this.host.getCell(rx, ry, rz)));
        const n = isR(x, y, z - 1), s = isR(x, y, z + 1), w = isR(x - 1, y, z), e = isR(x + 1, y, z);
        const count = (n ? 1 : 0) + (s ? 1 : 0) + (w ? 1 : 0) + (e ? 1 : 0);
        if (count >= 2) {
          const want = computeRailState(isR, x, y, z, on);
          if (want !== state) this.set(x, y, z, id, want);
        }
        continue;
      }
      if (isButton(id)) {
        const exp = this.buttonTimers.get(k);
        if (exp !== undefined && this.ticks >= exp) {
          this.buttonTimers.delete(k);
          if (state & 8) this.set(x, y, z, id, state & 7);
        }
        continue;
      }
      if (isPlate(id)) {
        if (setEdge(k, power([x, y, z]) > 0)) this.host.sound?.('click', x, y, z);
      }
    }

    // Execute piston retractions before extensions so opposing pistons (Ethonian hopper clocks, block swappers, flying machines) never deadlock on iteration order.
    for (const [x, y, z, id, state] of pistonRetracts) {
      const now = this.at(x, y, z);
      if (now.id === id && (now.state & 8) !== 0) {
        this.set(x, y, z, id, state & 7);
        this.retractPiston(x, y, z, id, state);
      }
    }
    for (const [x, y, z, id, state] of pistonExtends) {
      const now = this.at(x, y, z);
      if (now.id === id && (now.state & 8) === 0) {
        if (this.extendPiston(x, y, z, id, state)) this.set(x, y, z, id, state | 8);
      }
    }

    for (const [k, o] of this.observers) {
      const [x, y, z] = parse(k), f = FACE[o.face], seen = this.snapshot({ cell: this.host.getCell(x + f[0], y + f[1], z + f[2]) }, x + f[0], y + f[1], z + f[2]);
      if (seen !== o.last) { o.last = seen; this.pulses.set(k, 2); }
      const pulse = this.pulses.get(k) ?? 0;
      if (pulse > 0) this.pulses.set(k, pulse - 1);
    }
  }

  private mechPower(power: (p: Pos) => number, k: string, x: number, y: number, z: number): boolean {
    const direct = power([x, y, z]) > 0;
    const prev = this.qcState.get(k);
    let eff: boolean;
    if (direct) eff = true;
    else if (!prev || prev.direct || this.updated(x, y, z)) eff = this.quasi(power, x, y, z);
    else eff = prev.eff;
    this.qcState.set(k, { direct, eff });
    return eff;
  }

  private quasi(power: (p: Pos) => number, x: number, y: number, z: number): boolean {
    const ay = y + 1;
    if (power([x, ay, z]) > 0) return true;
    for (const d of DIRS) {
      if (d[1] === -1) continue;
      const n: Pos = [x + d[0], ay + d[1], z + d[2]];
      if (this.directBehind(n, [x, ay, z]) > 0 || this.pointingIn(n, [x, ay, z])) return true;
    }
    return false;
  }

  private updated(x: number, y: number, z: number): boolean {
    if (this.updates.has(key(x, y, z))) return true;
    for (const d of DIRS) if (this.updates.has(key(x + d[0], y + d[1], z + d[2]))) return true;
    return false;
  }

  toggleDetector(x: number, y: number, z: number): boolean {
    const { id, state } = this.at(x, y, z);
    if (!isDaylight(id) || ID.inverted_daylight_detector === undefined) return false;
    this.set(x, y, z, id === ID.daylight_detector ? ID.inverted_daylight_detector : ID.daylight_detector, 15 - (state & 15));
    this.host.sound?.('click', x, y, z);
    return true;
  }

  private directBehind(p: Pos, toward?: readonly [number, number, number]): number {
    const { id, state } = this.at(p[0], p[1], p[2]);
    if (id < 0) return 0;
    if ((isLever(id) || isButton(id) || isPlate(id) || isHook(id)) && state & 8) return 15;
    if (id === ID.redstone_block) return 15;
    if (isDaylight(id) || id === ID.target || isSensor(id) || id === ID.trapped_chest) return state & 15;
    if (id === ID.lightning_rod && (state & 15) > 0) return 15;
    if (id === ID.detector_rail && state & 1) return 15;
    if (id === ID.redstone_torch) return 15;
    if (id === ID.copper_bulb_lit) return 15;
    if (id === ID.observer && (this.pulses.get(key(p[0], p[1], p[2])) ?? 0) > 0) {
      if (!toward) return 15;
      const f = FACE[state & 7];
      if (p[0] - f[0] === toward[0] && p[1] - f[1] === toward[1] && p[2] - f[2] === toward[2]) return 15;
    }
    return 0;
  }

  private pointingInStrength(side: Pos, target: readonly [number, number, number]): number {
    const { id, state } = this.at(side[0], side[1], side[2]);
    const k = key(side[0], side[1], side[2]);
    if (isRepeater(id) || isComparator(id)) {
      const f = FACE[state & 3];
      if (side[0] + f[0] === target[0] && side[1] + f[1] === target[1] && side[2] + f[2] === target[2]) {
        return this.repOut.get(k) ?? this.compOut.get(k) ?? 0;
      }
    }
    if (id === ID.observer && (this.pulses.get(k) ?? 0) > 0) {
      const f = FACE[state & 7];
      if (side[0] - f[0] === target[0] && side[1] - f[1] === target[1] && side[2] - f[2] === target[2]) {
        return 15;
      }
    }
    return 0;
  }

  private pointingIn(side: Pos, target: readonly [number, number, number]): boolean {
    const { id, state } = this.at(side[0], side[1], side[2]);
    if (!isRepeater(id) && !isComparator(id)) return false;
    const f = FACE[state & 3];
    return (
      side[0] + f[0] === target[0] &&
      side[1] + f[1] === target[1] &&
      side[2] + f[2] === target[2] &&
      (this.repOut.get(key(side[0], side[1], side[2])) ?? this.compOut.get(key(side[0], side[1], side[2])) ?? 0) > 0
    );
  }

  // ------------------------------------------------------------------ pistons

  /** True while a repeater is locked by a powered diode on its side (its output is held). */
  isLocked(x: number, y: number, z: number): boolean { return this.lockedSet.has(key(x, y, z)); }
  lockedKeys(): Iterable<string> { return this.lockedSet; }
  private lockedSet = new Set<string>();

  private immovable(id: number, state = 8): boolean {
    if (id <= 0) return false;
    if (id === ID.piston || id === ID.sticky_piston) return (state & 8) !== 0;
    const n = nameOf(id);
    return (
      id === ID.bedrock ||
      id === ID.obsidian ||
      id === ID.crying_obsidian ||
      id === ID.spawner ||
      id === ID.chest ||
      id === ID.furnace ||
      id === ID.blast_furnace ||
      id === ID.smoker ||
      id === ID.barrel ||
      id === ID.hopper ||
      id === ID.dispenser ||
      id === ID.dropper ||
      id === ID.crafter ||
      id === ID.piston_head ||
      id === ID.end_portal ||
      id === ID.end_portal_frame ||
      id === ID.reinforced_deepslate ||
      n === 'enchanting_table' ||
      n === 'ender_chest' ||
      n === 'respawn_anchor' ||
      n === 'brewing_stand' ||
      n === 'beacon' ||
      n === 'portal' ||
      isPistonImmovable(n)
    );
  }

  private structure(start: Pos, dir: Pos, piston: Pos): { move: { x: number; y: number; z: number; cell: number }[]; destroy: Pos[] } | null {
    const move: { x: number; y: number; z: number; cell: number }[] = [], destroy: Pos[] = [], seen = new Set<string>();
    const pk = key(piston[0], piston[1], piston[2]);
    const cellAt = (p: Pos) => this.host.getCell(p[0], p[1], p[2]);
    const replaceable = (cell: number) => cell === 0 || BLOCKS[idOf(cell)]?.shape === 'water';
    // Wiki (Piston / Rail / Tutorials/Block and item duplication): Rails and coral fans attached to slime/honey structures
    // are moved with the structure instead of being crushed.
    const movableNonSolid = (id: number) => isRailId(id) || isCoralFanId(id);
    const crushable = (cell: number) => {
      if (cell <= 0 || fixed(cell)) return false;
      const id = idOf(cell), d = BLOCKS[id];
      if (movableNonSolid(id)) return false;
      return !d?.solid || d.shape === 'cross' || d.shape === 'torch' || d.shape === 'lily' || PISTON_BREAKS.has(d.name);
    };
    const fixed = (cell: number) => cell < 0 || this.immovable(idOf(cell), stOf(cell));
    const add = (p: Pos, cell: number) => { seen.add(key(p[0], p[1], p[2])); move.push({ x: p[0], y: p[1], z: p[2], cell }); };
    const line = (origin: Pos): boolean => {
      const first = cellAt(origin), ok = key(origin[0], origin[1], origin[2]);
      if (replaceable(first) || crushable(first) || fixed(first) || ok === pk || seen.has(ok)) return true;
      const behind: [Pos, number][] = [];
      let prev = idOf(first);
      for (let i = 1; isSticky(prev); i++) {
        const p: Pos = [origin[0] - dir[0] * i, origin[1] - dir[1] * i, origin[2] - dir[2] * i], c = cellAt(p);
        if (replaceable(c) || crushable(c) || fixed(c) || !sticksTo(prev, idOf(c)) || key(p[0], p[1], p[2]) === pk || seen.has(key(p[0], p[1], p[2]))) break;
        behind.push([p, c]);
        prev = idOf(c);
        if (behind.length + 1 + move.length > 12) return false;
      }
      for (let i = behind.length - 1; i >= 0; i--) add(behind[i][0], behind[i][1]);
      add(origin, first);
      if (move.length > 12) return false;
      for (let j = 1; ; j++) {
        const p: Pos = [origin[0] + dir[0] * j, origin[1] + dir[1] * j, origin[2] + dir[2] * j], c = cellAt(p), k2 = key(p[0], p[1], p[2]);
        if (seen.has(k2)) return true;
        if (replaceable(c)) return true;
        if (crushable(c)) { destroy.push(p); return true; }
        if (fixed(c) || k2 === pk) return false;
        if (move.length >= 12) return false;
        add(p, c);
      }
    };
    const head = cellAt(start);
    if (head < 0) return null;
    if (crushable(head)) { destroy.push(start); return { move, destroy }; }
    if (fixed(head)) return null;
    if (!line(start)) return null;
    for (let i = 0; i < move.length; i++) {
      const b = move[i], bid = idOf(b.cell);
      if (!isSticky(bid)) continue;
      for (const d of DIRS) {
        if ((d[0] !== 0 && dir[0] !== 0) || (d[1] !== 0 && dir[1] !== 0) || (d[2] !== 0 && dir[2] !== 0)) continue;
        const n: Pos = [b.x + d[0], b.y + d[1], b.z + d[2]], nc = cellAt(n);
        if (nc > 0 && sticksTo(idOf(nc), bid) && !line(n)) return null;
      }
    }
    return move.length > 12 ? null : { move, destroy };
  }

  private moveStructure(
    res: { move: { x: number; y: number; z: number; cell: number }[]; destroy: Pos[] },
    dir: Pos,
    owner: string,
    head?: { x: number; y: number; z: number; cell: number },
    visualHead?: PistonMove,
  ) {
    const crushedCells: [number, number, number, number][] = [];
    for (const p of res.destroy) {
      const cell = this.host.getCell(p[0], p[1], p[2]);
      if (cell > 0) {
        crushedCells.push([p[0], p[1], p[2], cell]);
        this.set(p[0], p[1], p[2], 0);
      }
    }
    let hasSlime = false;
    let hasSticky = false;
    let hasDuperPart = false;
    for (const b of res.move) {
      const bid = idOf(b.cell);
      if (bid === ID.slime_block) hasSlime = true;
      if (isSticky(bid)) hasSticky = true;
      if (isCoralFanId(bid) || isRailId(bid) || nameOf(bid).endsWith('_wall')) hasDuperPart = true;
    }
    for (const b of res.move) this.set(b.x, b.y, b.z, 0);
    const final = res.move.map(b => ({ x: b.x + dir[0], y: b.y + dir[1], z: b.z + dir[2], cell: b.cell }));
    if (head) final.push(head);
    const moves: PistonMove[] = res.move.map(b => ({ x: b.x, y: b.y, z: b.z, dx: dir[0], dy: dir[1], dz: dir[2], cell: b.cell }));
    if (visualHead) moves.push(visualHead);
    if (this.host.moveBlocks && ID.moving_piston !== undefined) {
      for (const b of final) this.set(b.x, b.y, b.z, ID.moving_piston, 0);
      this.host.moveBlocks(moves, 0.1);
      this.motions.push({ owner, until: this.ticks + 2, blocks: final });
    } else {
      for (const b of final) {
        const id = idOf(b.cell);
        this.set(b.x, b.y, b.z, id, stOf(b.cell));
        // When an observer is moved by a piston, schedule its arrival pulse so flying machines step cleanly tick-by-tick.
        if (id === ID.observer) this.pulses.set(key(b.x, b.y, b.z), 3);
      }
    }
    // Java Edition TNT Duplicator (Tutorials/Block and item duplication#TNT_Duplication):
    // When a slime/honey structure with a coral fan / detector rail / wall pushes a TNT block into/with power,
    // a primed TNT entity is spawned while the TNT block itself remains intact in the structure.
    if (hasSticky) {
      for (const b of final) {
        if (idOf(b.cell) === ID.tnt) {
          const tk = key(b.x, b.y, b.z);
          if (head) {
            this.ignited.delete(tk);
            const nearPower =
              hasDuperPart ||
              DIRS.some(d => {
                const nid = idOf(this.host.getCell(b.x + d[0], b.y + d[1], b.z + d[2]));
                return isCoralFanId(nid) || isRailId(nid) || this.directBehind([b.x + d[0], b.y + d[1], b.z + d[2]]) > 0;
              });
            if (nearPower) {
              this.ignited.add(tk);
              this.host.ignite?.(b.x, b.y, b.z);
            }
          } else {
            this.ignited.add(tk);
          }
        }
      }
    }
    if (res.move.length) {
      this.host.moved?.(res.move.map(b => ({ x: b.x, y: b.y, z: b.z, id: idOf(b.cell), state: stOf(b.cell) })), dir);
    }
    if (moves.length) {
      this.host.pushEntities?.(moves, dir, hasSlime);
    }
    for (const [cx, cy, cz, ccell] of crushedCells) {
      this.host.crushed?.(cx, cy, cz, ccell);
    }
  }

  private extendPiston(x: number, y: number, z: number, id: number, state: number): boolean {
    const f = FACE[state & 7], start: Pos = [x + f[0], y + f[1], z + f[2]];
    const cell = this.host.getCell(start[0], start[1], start[2]);
    if (cell < 0) return false;
    let res: { move: { x: number; y: number; z: number; cell: number }[]; destroy: Pos[] } = { move: [], destroy: [] };
    if (cell > 0) {
      const s = this.structure(start, f, [x, y, z]);
      if (!s) return false;
      res = s;
    }
    const pk = key(x, y, z);
    if (id === ID.sticky_piston) {
      this.pistonPush.set(pk, {
        tick: this.ticks,
        pushed: res.move.length > 0,
        byObserver: this.hasObserverPulseNear(x, y, z),
      });
    }
    const headState = (state & 7) | (id === ID.sticky_piston ? 8 : 0);
    const headCell = (ID.piston_head ?? 0) | (headState << 12);
    const head = ID.piston_head !== undefined ? { x: start[0], y: start[1], z: start[2], cell: headCell } : undefined;
    const visualHead: PistonMove | undefined = head ? { x, y, z, dx: f[0], dy: f[1], dz: f[2], cell: headCell } : undefined;
    this.moveStructure(res, f, pk, head, visualHead);
    this.host.sound?.('piston', x, y, z);
    return true;
  }

  private retractPiston(x: number, y: number, z: number, id: number, state: number) {
    const pk = key(x, y, z);
    const pushInfo = this.pistonPush.get(pk);
    this.pistonPush.delete(pk);
    const f = FACE[state & 7], into: Pos = [x + f[0], y + f[1], z + f[2]];
    const curInto = idOf(this.host.getCell(into[0], into[1], into[2]));
    if (ID.piston_head !== undefined && (curInto === ID.piston_head || curInto === ID.moving_piston)) {
      this.set(into[0], into[1], into[2], 0);
    }
    const back: Pos = [-f[0], -f[1], -f[2]];
    let res: { move: { x: number; y: number; z: number; cell: number }[]; destroy: Pos[] } = { move: [], destroy: [] };
    // Wiki (Piston): In Java Edition, a sticky piston given a short pulse (< 1.5 redstone ticks, e.g. 1-tick pulse or observer pulse)
    // drops its block (leaves it behind at x + 2*f) if it pushed a block during extension; if it extended into air (pushed === false),
    // it pulls the block 2 spaces away at x + 2*f on retraction!
    const shortPulseDrop =
      !!pushInfo &&
      pushInfo.pushed &&
      (this.ticks - pushInfo.tick <= 1 || (pushInfo.byObserver && this.ticks - pushInfo.tick <= 2));
    if (id === ID.sticky_piston && !shortPulseDrop && idOf(this.host.getCell(into[0], into[1], into[2])) === 0) {
      const from: Pos = [x + f[0] * 2, y + f[1] * 2, z + f[2] * 2], cell = this.host.getCell(from[0], from[1], from[2]);
      const cid = idOf(cell);
      if (cell > 0 && (BLOCKS[cid]?.solid || isRailId(cid) || isCoralFanId(cid)) && !this.immovable(cid, stOf(cell))) {
        const s = this.structure(from, back, [x, y, z]);
        if (s) res = s;
      }
    }
    const headState = (state & 7) | (id === ID.sticky_piston ? 8 : 0);
    const headCell = (ID.piston_head ?? 0) | (headState << 12);
    const visualHead: PistonMove = { x: into[0], y: into[1], z: into[2], dx: back[0], dy: back[1], dz: back[2], cell: headCell };
    this.moveStructure(res, back, pk, undefined, visualHead);
    this.host.sound?.('piston', x, y, z);
  }

  // ------------------------------------------------------------------ player input

  press(x: number, y: number, z: number) {
    const { id, state } = this.at(x, y, z);
    if (isDaylight(id)) return this.toggleDetector(x, y, z);
    if (isLever(id)) {
      this.set(x, y, z, id, state ^ 8);
      this.host.sound?.('click', x, y, z);
      return true;
    }
    if (isButton(id)) {
      if (state & 8) return false;
      this.set(x, y, z, id, state | 8);
      this.host.sound?.('click', x, y, z);
      this.buttonTimers.set(key(x, y, z), this.ticks + 20);
      setTimeout(() => {
        const now = this.at(x, y, z);
        if (isButton(now.id) && now.state & 8) this.set(x, y, z, now.id, now.state & 7);
      }, 1500);
      return true;
    }
    return false;
  }

  setPlate(x: number, y: number, z: number, pressed: boolean) {
    const { id, state } = this.at(x, y, z);
    if (!isPlate(id)) return;
    const want = pressed ? state | 8 : state & 7;
    if (state !== want) this.set(x, y, z, id, want);
  }

  nearest(x: number, y: number, z: number): string[] {
    return [...this.active]
      .sort((a, b) => {
        const [ax, ay, az] = parse(a), [bx, by, bz] = parse(b);
        return Math.hypot(ax - x, ay - y, az - z) - Math.hypot(bx - x, by - y, bz - z);
      })
      .slice(0, 12);
  }

  get warningCount() { return this.warned.size; }
}
