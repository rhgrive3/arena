import { BLOCKS, ID } from '../game/data';

/*
 * Unified 3-D Grid A* Pathfinding (Record 014 Perfected).
 *
 * Uses a Binary Min-Heap for O(log N) priority queue operations and supports:
 *  - Walking mobs climbing 1-block steps (with headroom validation) and dropping up to `maxDrop` blocks
 *  - Diagonal moves only when both orthogonal neighbor columns are clear (no corner cutting through walls)
 *  - Fences, walls, panes, and closed doors cannot be climbed over as floors
 *  - Unloaded chunks (id < 0) are treated as impassable
 *  - Lava, fire, cactus, magma, and berry bushes avoided (except lava/fire for fireproof mobs like Striders)
 *  - Supports both function signatures:
 *      findPath(get: GetBlock, sx, sy, sz, tx, ty, tz, maxNodesOrOpts?, maxDrop?, fireproof?)
 *      findPath(world: NavigationWorld, from: PathPoint, to: PathPoint, budget?, lavaWalker?)
 */

export type GetBlock = (x: number, y: number, z: number) => number;
export interface NavigationWorld { getBlock(x: number, y: number, z: number): number; }
export interface PathPoint {
  x: number;
  y: number;
  z: number;
  0: number;
  1: number;
  2: number;
}
export type Waypoint = PathPoint;
export interface PathOptions {
  maxNodes?: number;
  maxDrop?: number;
  tall?: number;
  avoidWater?: boolean;
  fireproof?: boolean;
}

const toGetter = (w: GetBlock | NavigationWorld): GetBlock => (typeof w === 'function' ? w : (x, y, z) => w.getBlock(x, y, z));

const CLIMB_BLOCKS = new Set(['ladder', 'vine', 'weeping_vines', 'twisting_vines', 'cave_vines']);
const MAX_PATH_IDS = 1024;
const LUT_CLIMB = new Uint8Array(MAX_PATH_IDS);
const LUT_PASS_NORM = new Uint8Array(MAX_PATH_IDS);
const LUT_PASS_FP = new Uint8Array(MAX_PATH_IDS);
const LUT_FLOOR_NORM = new Uint8Array(MAX_PATH_IDS);
const LUT_FLOOR_FP = new Uint8Array(MAX_PATH_IDS);
let pathLutCount = -1;

function ensurePathLuts() {
  if (pathLutCount === BLOCKS.length) return;
  pathLutCount = BLOCKS.length;
  LUT_PASS_NORM[0] = 1;
  LUT_PASS_FP[0] = 1;
  for (let id = 1; id < BLOCKS.length && id < MAX_PATH_IDS; id++) {
    const d = BLOCKS[id];
    if (!d) continue;
    const climb = CLIMB_BLOCKS.has(d.name);
    const haz = id === ID.lava || id === ID.fire || id === ID.cactus || id === ID.magma_block || id === ID.sweet_berry_bush;
    const blockedShape = d.shape === 'door' || d.shape === 'fence' || d.shape === 'pane';
    const basePass = !blockedShape && (!d.solid || d.shape === 'cross');

    LUT_CLIMB[id] = climb ? 1 : 0;
    LUT_PASS_NORM[id] = climb || (!haz && basePass) ? 1 : 0;
    LUT_PASS_FP[id] = climb || (haz ? (id === ID.lava || id === ID.fire) : basePass) ? 1 : 0;

    const baseFloor = d.solid && d.shape !== 'fence' && d.shape !== 'pane' && d.shape !== 'cross' && !haz;
    LUT_FLOOR_NORM[id] = climb || baseFloor ? 1 : 0;
    LUT_FLOOR_FP[id] = climb || id === ID.lava || baseFloor ? 1 : 0;
  }
}

export const isClimbable = (id: number) => {
  ensurePathLuts();
  return id > 0 && id < MAX_PATH_IDS && LUT_CLIMB[id] === 1;
};

export function passable(id: number, fireproof = false): boolean {
  if (id < 0 || id >= MAX_PATH_IDS) return false;
  ensurePathLuts();
  return (fireproof ? LUT_PASS_FP[id] : LUT_PASS_NORM[id]) === 1;
}

export function floorLike(id: number, fireproof = false): boolean {
  if (id <= 0 || id >= MAX_PATH_IDS) return false;
  ensurePathLuts();
  return (fireproof ? LUT_FLOOR_FP[id] : LUT_FLOOR_NORM[id]) === 1;
}

export function standable(w: GetBlock | NavigationWorld, x: number, y: number, z: number, tall = 2, fireproof = false): boolean {
  ensurePathLuts();
  const get = toGetter(w);
  const passLut = fireproof ? LUT_PASS_FP : LUT_PASS_NORM;
  const floorLut = fireproof ? LUT_FLOOR_FP : LUT_FLOOR_NORM;
  const atFeet = get(x, y, z);
  const below = get(x, y - 1, z);
  if (!(atFeet > 0 && atFeet < MAX_PATH_IDS && LUT_CLIMB[atFeet] === 1) && !(below > 0 && below < MAX_PATH_IDS && floorLut[below] === 1)) return false;
  const waterId = ID.water;
  for (let i = 0; i < tall; i++) {
    const c = i === 0 ? atFeet : get(x, y + i, z);
    if (c < 0 || c >= MAX_PATH_IDS || passLut[c] === 0 || (c === waterId && !fireproof && tall >= 2 && get(x, y + 1, z) === waterId)) return false;
  }
  return true;
}

export function canStand(w: GetBlock | NavigationWorld, x: number, y: number, z: number, lavaWalker = false): boolean {
  ensurePathLuts();
  const get = toGetter(w);
  const feet = get(x, y, z), head = get(x, y + 1, z), floor = get(x, y - 1, z);
  if (feet < 0 || head < 0 || floor <= 0 || feet >= MAX_PATH_IDS || head >= MAX_PATH_IDS || floor >= MAX_PATH_IDS) return false;
  if (feet === ID.water && !lavaWalker) return false;
  const passLut = lavaWalker ? LUT_PASS_FP : LUT_PASS_NORM;
  const floorLut = lavaWalker ? LUT_FLOOR_FP : LUT_FLOOR_NORM;
  return passLut[feet] === 1 && passLut[head] === 1 && floorLut[floor] === 1;
}

const GROUND_STEP_DYS = [0, 1, -1, -2, -3] as const;

export function groundStep(w: GetBlock | NavigationWorld, x: number, y: number, z: number, lavaWalker = false): number | null {
  x = Math.floor(x); z = Math.floor(z); y = Math.floor(y + 0.1);
  for (let i = 0; i < 5; i++) {
    const dy = GROUND_STEP_DYS[i];
    if (canStand(w, x, y + dy, z, lavaWalker)) return y + dy;
  }
  return null;
}

export function snapToFloor(w: GetBlock | NavigationWorld, x: number, y: number, z: number, tall = 2, down = 4, up = 2, fireproof = false): number | null {
  for (let d = 0; d <= down; d++) if (standable(w, x, y - d, z, tall, fireproof)) return y - d;
  for (let u = 1; u <= up; u++) if (standable(w, x, y + u, z, tall, fireproof)) return y + u;
  return null;
}

let lastGroundWater = false;

/** Lowest y at which a mob can stand within [y - maxDrop, y + 1]; NaN when none. */
export function groundAt(w: GetBlock | NavigationWorld, x: number, y: number, z: number, maxDrop = 3, fireproof = false): number {
  ensurePathLuts();
  const get = toGetter(w);
  const passLut = fireproof ? LUT_PASS_FP : LUT_PASS_NORM;
  const floorLut = fireproof ? LUT_FLOOR_FP : LUT_FLOOR_NORM;
  const waterId = ID.water;

  // Sliding vertical window avoids redundant get(x, yy, z) calls across dy = 1 .. -maxDrop
  let bAbove = get(x, y + 2, z);
  let bAt = get(x, y + 1, z);
  let bBelow = get(x, y, z);

  for (let dy = 1; dy >= -maxDrop; dy--) {
    const yy = y + dy;
    if (dy < 1) {
      bAbove = bAt;
      bAt = bBelow;
      bBelow = get(x, yy - 1, z);
    }
    if (
      bBelow >= 0 && bBelow < MAX_PATH_IDS &&
      (floorLut[bBelow] === 1 || bBelow === waterId) &&
      bAt >= 0 && bAt < MAX_PATH_IDS && passLut[bAt] === 1 &&
      bAbove >= 0 && bAbove < MAX_PATH_IDS && passLut[bAbove] === 1
    ) {
      if (dy === 1) {
        const bTop = get(x, y + 2, z);
        if (bTop < 0 || bTop >= MAX_PATH_IDS || passLut[bTop] === 0) continue;
      }
      lastGroundWater = bAt === waterId || bBelow === waterId;
      return yy;
    }
  }
  return NaN;
}

interface Node { x: number; y: number; z: number; g: number; f: number; h: number; parent: Node | null; closed: boolean; }

class MinHeap {
  private a: Node[] = [];
  get size() { return this.a.length; }
  clear() { this.a.length = 0; }
  push(n: Node) {
    const a = this.a;
    let i = a.length;
    a.push(n);
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (a[p].f <= n.f) break;
      a[i] = a[p];
      i = p;
    }
    a[i] = n;
  }
  pop(): Node {
    const a = this.a, top = a[0], last = a.pop()!;
    const len = a.length;
    if (len > 0) {
      let i = 0;
      for (;;) {
        let c = (i << 1) + 1;
        if (c >= len) break;
        if (c + 1 < len && a[c + 1].f < a[c].f) c++;
        if (a[c].f >= last.f) break;
        a[i] = a[c];
        i = c;
      }
      a[i] = last;
    }
    return top;
  }
}

const sharedOpen = new MinHeap();
const sharedNodes = new Map<number, Node>();
const nodePool: Node[] = [];
let poolUsed = 0;

function allocNode(x: number, y: number, z: number, g: number, f: number, h: number, parent: Node | null): Node {
  if (poolUsed < nodePool.length) {
    const n = nodePool[poolUsed++];
    n.x = x; n.y = y; n.z = z; n.g = g; n.f = f; n.h = h; n.parent = parent; n.closed = false;
    return n;
  }
  const n: Node = { x, y, z, g, f, h, parent, closed: false };
  nodePool.push(n);
  poolUsed++;
  return n;
}
const DIRS_X = [1, -1, 0, 0, 1, 1, -1, -1] as const;
const DIRS_Z = [0, 0, 1, -1, 1, -1, 1, -1] as const;

function makePoint(x: number, y: number, z: number): PathPoint {
  const pt: any = [x, y, z];
  pt.x = x + 0.5;
  pt.y = y;
  pt.z = z + 0.5;
  return pt as PathPoint;
}

export function findPath(
  w: GetBlock | NavigationWorld,
  sxOrFrom: number | { x: number; y: number; z: number },
  syOrTo: number | { x: number; y: number; z: number },
  szOrBudget?: number,
  txOrLava?: number | boolean,
  ty?: number,
  tz?: number,
  maxNodesOrOpts: number | PathOptions = 500,
  maxDropArg = 3,
  fireproofArg = false,
): PathPoint[] | null {
  ensurePathLuts();
  const get = toGetter(w);
  const objectMode = typeof sxOrFrom === 'object';
  let sx: number, sy: number, sz: number, tx: number, tyGoal: number, tzGoal: number;
  let maxNodes = 500, maxDrop = maxDropArg, fp = fireproofArg, tall = 2;

  if (objectMode) {
    const from = sxOrFrom as { x: number; y: number; z: number };
    const to = syOrTo as { x: number; y: number; z: number };
    sx = Math.floor(from.x); sy = Math.floor(from.y + 0.1); sz = Math.floor(from.z);
    tx = Math.floor(to.x); tyGoal = Math.floor(to.y + 0.1); tzGoal = Math.floor(to.z);
    if (typeof szOrBudget === 'number') maxNodes = szOrBudget;
    if (typeof txOrLava === 'boolean') fp = txOrLava;
  } else {
    sx = Math.floor(sxOrFrom as number);
    sy = Math.floor(syOrTo as number);
    sz = Math.floor(szOrBudget as number);
    tx = Math.floor(txOrLava as number);
    tyGoal = Math.floor(ty as number);
    tzGoal = Math.floor(tz as number);
    if (typeof maxNodesOrOpts === 'number') maxNodes = maxNodesOrOpts;
    else if (maxNodesOrOpts) {
      maxNodes = maxNodesOrOpts.maxNodes ?? 500;
      maxDrop = maxNodesOrOpts.maxDrop ?? 3;
      tall = maxNodesOrOpts.tall ?? 2;
      fp = !!maxNodesOrOpts.fireproof;
    }
  }

  const snappedStart = snapToFloor(get, sx, sy, sz, tall, 3, 1, fp);
  if (snappedStart !== null) sy = snappedStart;
  const snappedGoal = snapToFloor(get, tx, tyGoal, tzGoal, tall, 4, 2, fp);
  if (snappedGoal !== null) tyGoal = snappedGoal;

  if (sx === tx && sy === tyGoal && sz === tzGoal) return [];

  const passLut = fp ? LUT_PASS_FP : LUT_PASS_NORM;
  const floorLut = fp ? LUT_FLOOR_FP : LUT_FLOOR_NORM;

  const open = sharedOpen;
  const nodes = sharedNodes;
  open.clear();
  nodes.clear();
  poolUsed = 0;

  const startH = Math.abs(sx - tx) + Math.abs(sz - tzGoal) + Math.abs(sy - tyGoal) * 0.5;
  const start = allocNode(sx, sy, sz, 0, startH, startH, null);
  const startKey = 1024 | (1024 << 11) | (512 << 22);
  nodes.set(startKey, start);
  open.push(start);

  let closest = start, expanded = 0;

  while (open.size && expanded < maxNodes) {
    const cur = open.pop();
    if (cur.closed) continue;
    cur.closed = true;
    expanded++;
    const cx = cur.x, cy = cur.y, cz = cur.z;
    if (cx === tx && cz === tzGoal && Math.abs(cy - tyGoal) <= 1) {
      closest = cur;
      break;
    }
    if (cur.h < closest.h) closest = cur;

    // Vertical ladder / vine climbing links
    const curFeet = get(cx, cy, cz);
    const curHead = get(cx, cy + 1, cz);
    if ((curFeet > 0 && curFeet < MAX_PATH_IDS && LUT_CLIMB[curFeet] === 1) || (curHead > 0 && curHead < MAX_PATH_IDS && LUT_CLIMB[curHead] === 1)) {
      if (curHead >= 0 && curHead < MAX_PATH_IDS && passLut[curHead] === 1) {
        const above2 = get(cx, cy + 2, cz);
        if (above2 >= 0 && above2 < MAX_PATH_IDS && passLut[above2] === 1) {
          const ny = cy + 1, g = cur.g + 1.15;
          const k = ((cx - sx + 1024) & 2047) | (((cz - sz + 1024) & 2047) << 11) | (((ny - sy + 512) & 1023) << 22);
          const existing = nodes.get(k);
          if (existing) {
            if (!existing.closed && g < existing.g) {
              existing.g = g; existing.f = g + existing.h; existing.parent = cur; open.push(existing);
            }
          } else {
            const nh = Math.abs(cx - tx) + Math.abs(cz - tzGoal) + Math.abs(ny - tyGoal) * 0.5;
            const next = allocNode(cx, ny, cz, g, g + nh, nh, cur);
            nodes.set(k, next); open.push(next);
          }
        }
      }
      const below1 = get(cx, cy - 1, cz);
      if (below1 >= 0 && below1 < MAX_PATH_IDS && passLut[below1] === 1) {
        const below2 = get(cx, cy - 2, cz);
        if ((below1 > 0 && LUT_CLIMB[below1] === 1) || (below2 > 0 && below2 < MAX_PATH_IDS && floorLut[below2] === 1)) {
          const ny = cy - 1, g = cur.g + 1.15;
          const k = ((cx - sx + 1024) & 2047) | (((cz - sz + 1024) & 2047) << 11) | (((ny - sy + 512) & 1023) << 22);
          const existing = nodes.get(k);
          if (existing) {
            if (!existing.closed && g < existing.g) {
              existing.g = g; existing.f = g + existing.h; existing.parent = cur; open.push(existing);
            }
          } else {
            const nh = Math.abs(cx - tx) + Math.abs(cz - tzGoal) + Math.abs(ny - tyGoal) * 0.5;
            const next = allocNode(cx, ny, cz, g, g + nh, nh, cur);
            nodes.set(k, next); open.push(next);
          }
        }
      }
    }

    for (let di = 0; di < 8; di++) {
      const dx = DIRS_X[di], dz = DIRS_Z[di];
      const nx = cx + dx, nz = cz + dz;
      const diagonal = di >= 4;
      if (diagonal) {
        const c1 = get(cx + dx, cy, cz), c2 = get(cx, cy, cz + dz);
        if (c1 < 0 || c1 >= MAX_PATH_IDS || passLut[c1] === 0 || c2 < 0 || c2 >= MAX_PATH_IDS || passLut[c2] === 0) continue;
        const c3 = get(cx + dx, cy + 1, cz), c4 = get(cx, cy + 1, cz + dz);
        if (c3 < 0 || c3 >= MAX_PATH_IDS || passLut[c3] === 0 || c4 < 0 || c4 >= MAX_PATH_IDS || passLut[c4] === 0) continue;
      } else {
        const nFeet = get(nx, cy, nz);
        if (nFeet > 0 && nFeet < MAX_PATH_IDS && LUT_CLIMB[nFeet] === 1) {
          const nHead = get(nx, cy + 1, nz);
          if (nHead >= 0 && nHead < MAX_PATH_IDS && passLut[nHead] === 1) {
            const g = cur.g + 1.1;
            const k = ((nx - sx + 1024) & 2047) | (((nz - sz + 1024) & 2047) << 11) | (((cy - sy + 512) & 1023) << 22);
            const existing = nodes.get(k);
            if (existing) {
              if (!existing.closed && g < existing.g) {
                existing.g = g; existing.f = g + existing.h; existing.parent = cur; open.push(existing);
              }
            } else {
              const nh = Math.abs(nx - tx) + Math.abs(nz - tzGoal) + Math.abs(cy - tyGoal) * 0.5;
              const next: Node = { x: nx, y: cy, z: nz, g, f: g + nh, h: nh, parent: cur, closed: false };
              nodes.set(k, next); open.push(next);
            }
          }
        }
      }

      const ny = groundAt(get, nx, cy, nz, maxDrop, fp);
      if (Number.isNaN(ny)) continue;
      if (diagonal && ny !== cy) continue;
      const water = lastGroundWater;
      const step = (diagonal ? 1.414 : 1) + (ny > cy ? 0.6 : 0) + (cy > ny ? (cy - ny) * 0.3 : 0) + (water ? 2.5 : 0);
      const g = cur.g + step;
      const k = ((nx - sx + 1024) & 2047) | (((nz - sz + 1024) & 2047) << 11) | (((ny - sy + 512) & 1023) << 22);
      const existing = nodes.get(k);
      if (existing) {
        if (!existing.closed && g < existing.g) {
          existing.g = g; existing.f = g + existing.h; existing.parent = cur; open.push(existing);
        }
      } else {
        const nh = Math.abs(nx - tx) + Math.abs(nz - tzGoal) + Math.abs(ny - tyGoal) * 0.5;
        const next = allocNode(nx, ny, nz, g, g + nh, nh, cur);
        nodes.set(k, next); open.push(next);
      }
    }
  }

  if (closest === start) return objectMode ? [] : null;
  const out: PathPoint[] = [];
  for (let n: Node | null = closest; n && n !== start; n = n.parent) {
    out.push(makePoint(n.x, n.y, n.z));
  }
  out.reverse();
  return out.length ? out : (objectMode ? [] : null);
}

export function clearLine(w: GetBlock | NavigationWorld, x0: number, y: number, z0: number, x1: number, z1: number, tall = 2): boolean {
  const dx = x1 - x0, dz = z1 - z0, n = Math.ceil(Math.max(Math.abs(dx), Math.abs(dz)) * 2);
  for (let i = 1; i <= n; i++) {
    const x = Math.floor(x0 + 0.5 + (dx * i) / n), z = Math.floor(z0 + 0.5 + (dz * i) / n);
    if (!standable(w, x, y, z, tall)) return false;
  }
  return true;
}
