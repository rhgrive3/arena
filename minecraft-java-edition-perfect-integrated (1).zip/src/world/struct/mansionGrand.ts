// Grand woodland mansion: the 31×21 main block of `variants.ts` (kept as it is) gains two three-storey wings, one on each end of its
// corridor. Every wing is a 17×53 bar with a 3-wide north–south corridor in the middle (carpet, lanterns, a staircase tower rising
// ground → first → second floor) and 13 rooms per floor on both sides – 39 rooms per wing. Together the mansion covers 65×53
// blocks on three floors. Every room opens onto a corridor through a two-block doorway, the wing corridors join the main corridor on
// all three floors, and both wing corridors have a front door at their north end, so every room can be reached on foot.
import { type Put, type StructHost, bid, cell, fill, hash2, mulberry, stairsUp, attachOn, tag, PANE_X, PANE_Z } from './common';
import { mansion } from './variants';
import { chest, barrel, itemFrame, lectern, lantern, pottedPlant, carpet } from './decor';

interface Site { x: number; y: number; z: number }
export const WING_ROOM_TYPES = ['storage', 'library', 'bedroom', 'dining', 'jail', 'garden', 'gallery', 'smithy', 'spider', 'empty'] as const;
export type WingRoomType = typeof WING_ROOM_TYPES[number];
export interface WingRoom {
  wing: -1 | 1; floor: number; column: 0 | 1; x0: number; x1: number; z0: number; z1: number; y: number;
  /** World cell of the doorway (the lower block; the upper one is above) and the direction the corridor lies in. */
  doorX: number; doorZ: number; toCorridor: number; type: WingRoomType;
}
export const MANSION_WING_HALF_X = 32, MANSION_WING_HALF_Z = 26;
/** Room cell rows relative to the mansion centre: [first interior row, last interior row] – 3 + alcove + 3 per side. */
const ROWS: [number, number][] = [[-25, -19], [-17, -11], [-9, -3], [-1, 1], [3, 9], [11, 17], [19, 25]];
const CACHE = new Map<string, WingRoom[]>();

/** Deterministic room plan of both wings. */
export function mansionWingRooms(seed: number, p: Site): WingRoom[] {
  const key = seed + ':' + p.x + ',' + p.y + ',' + p.z, hit = CACHE.get(key);
  if (hit) return hit;
  const rnd = mulberry((Math.imul(seed | 0, 2246822519) ^ Math.imul(p.x, 40503) ^ Math.imul(p.z, 65599)) >>> 0), X0 = p.x - 15, X1 = p.x + 15, out: WingRoom[] = [];
  for (const wing of [1, -1] as const) for (let floor = 0; floor < 3; floor++) for (const column of [0, 1] as const) for (let r = 0; r < ROWS.length; r++) {
    if (column === 0 && r === 3) continue;                                 // the passage band replaces the west alcove
    const [a, b] = ROWS[r], i0 = column === 0 ? 2 : 12, i1 = column === 0 ? 6 : 16, ix = (i: number) => (wing > 0 ? X1 + i : X0 - i);
    const doorI = column === 0 ? 7 : 11, zc = p.z + ((a + b) >> 1);
    out.push({
      wing, floor, column, x0: Math.min(ix(i0), ix(i1)), x1: Math.max(ix(i0), ix(i1)), z0: p.z + a, z1: p.z + b, y: p.y + floor * 5,
      doorX: ix(doorI), doorZ: zc, toCorridor: (column === 0 ? (wing > 0 ? 1 : 3) : (wing > 0 ? 3 : 1)), type: 'empty',
    });
  }
  // Every wing has at least a storage room, a library, a bedroom, a jail and a garden; the rest is drawn at random.
  for (const wing of [1, -1]) {
    const rooms = out.filter(r => r.wing === wing), order = rooms.map((_, i) => i);
    for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    const required: WingRoomType[] = ['storage', 'library', 'bedroom', 'jail', 'garden', 'storage', 'dining', 'smithy'];
    order.forEach((ri, n) => { rooms[ri].type = n < required.length ? required[n] : WING_ROOM_TYPES[Math.floor(rnd() * WING_ROOM_TYPES.length)]; });
  }
  if (CACHE.size > 24) CACHE.clear();
  CACHE.set(key, out);
  return out;
}

/** Bounding box [x0, y0, z0, x1, y1, z1] of the whole mansion including both wings. */
export const grandMansionBox = (p: Site): [number, number, number, number, number, number] => [p.x - MANSION_WING_HALF_X, p.y - 14, p.z - MANSION_WING_HALF_Z - 3, p.x + MANSION_WING_HALF_X, p.y + 27, p.z + MANSION_WING_HALF_Z];

export function grandMansion(t: StructHost, put: Put, p: Site, ox?: number, oz?: number) {
  const inChunk = (x0: number, z0: number, x1: number, z1: number) => ox === undefined || oz === undefined || !(x1 < ox - 1 || x0 > ox + 17 || z1 < oz - 1 || z0 > oz + 17);
  if (inChunk(p.x - 16, p.z - 11, p.x + 16, p.z + 11)) mansion(t, put, p);
  const plank = bid('dark_oak_planks', 'oak_planks'), log = bid('dark_oak_log', 'oak_log'), birch = bid('birch_planks', 'oak_planks'), cob = bid('cobblestone');
  const X0 = p.x - 15, X1 = p.x + 15, y = p.y, P = (x: number, yy: number, z: number, b: number) => put(x, yy, z, b, true);
  const rooms = mansionWingRooms(t.seed, p);

  // Openings of the main block's end walls on all three floors (the ground floor of the west end already is the old entrance).
  if (inChunk(X0 - 1, p.z - 2, X1 + 1, p.z + 2)) for (const x of [X0, X1]) for (let k = 0; k < 3; k++) for (let dz = -1; dz <= 1; dz++) for (let dy = 0; dy <= 2; dy++) P(x, y + k * 5 + dy, p.z + dz, 0);

  for (const wing of [1, -1]) {
    const ix = (i: number) => (wing > 0 ? X1 + i : X0 - i), xa = Math.min(ix(1), ix(17)), xb = Math.max(ix(1), ix(17));
    if (!inChunk(xa, p.z - 27, xb, p.z + 26)) continue;
    for (let z = p.z - 26; z <= p.z + 26; z++) {
      const dz = z - p.z;
      if (!inChunk(xa, z, xb, z)) continue;
      for (let i = 1; i <= 17; i++) {
        const x = ix(i);
        if (ox !== undefined && oz !== undefined && (x < ox - 1 || x > ox + 17)) continue;
        for (let dy = 2; dy <= 14; dy++) P(x, y - dy, z, cob);
        const outerEnd = dz === -26 || dz === 26, outerSide = i === 17 || i === 1, wallRow = [-26, -18, -10, -2, 2, 10, 18, 26].includes(dz);
        const wallCol = i === 1 || i === 7 || i === 11 || i === 17;
        const corridor = i >= 8 && i <= 10, pass = Math.abs(dz) <= 1 && i <= 7;
        for (let k = 0; k < 3; k++) {
          const fy = y - 1 + k * 5;
          P(x, fy, z, k === 0 ? cob : plank);
          for (let dy = 1; dy <= 4; dy++) {
            let b = 0;
            if (outerEnd || i === 17 || i === 1) {
              const along = outerEnd ? i : dz + 26;
              b = (outerEnd && outerSide) || along % 5 === 0 ? log : (dy === 2 || dy === 3) && along % 5 !== 1 && along % 5 !== 4 ? cell('glass_pane', outerEnd ? PANE_X : PANE_Z, 'glass') : plank;
              if (i === 1 && !outerEnd && pass) b = 0;
            } else if (corridor) b = outerEnd ? plank : dy === 1 && i === 9 && dz % 2 === 0 ? carpet0() : dy === 4 && i === 9 && dz % 8 === 4 ? bid('lantern', 'torch') : 0;
            else if (wallCol && !pass) b = birch;
            else if (wallRow) b = birch;
            else if (pass) b = dy === 1 && i !== 7 ? carpet0() : 0;
            P(x, fy + dy, z, b);
          }
        }
        P(x, y + 14, z, plank);
      }
    }
    // Gable roof across the wing (ridge along Z).
    if (inChunk(xa, p.z - 27, xb, p.z + 27)) for (let r = 0; r <= 8; r++) for (const [x, face] of [[ix(1 + r), wing > 0 ? 1 : 3], [ix(17 - r), wing > 0 ? 3 : 1]] as const) {
      if (ox !== undefined && oz !== undefined && (x < ox - 1 || x > ox + 17)) continue;
      for (let z = p.z - 27; z <= p.z + 27; z++) {
        if (oz !== undefined && (z < oz - 1 || z > oz + 17)) continue;
        P(x, y + 15 + r, z, r === 8 ? log : cell('dark_oak_stairs', stairsUp(face), 'oak_planks'));
        if (r < 8 && Math.abs(z - p.z) >= 26) for (let yy = y + 15; yy < y + 15 + r; yy++) P(x, yy, z, plank);
      }
    }
    // Staircase tower in the corridor: lane A (i = 8) climbs ground → first floor, lane C (i = 10) first → second floor.
    const zs = p.z + 14;
    for (const [k, i] of [[0, 8], [1, 10]] as const) {
      const x = ix(i);
      if (ox !== undefined && (x < ox - 1 || x > ox + 17)) continue;
      for (let s = 0; s < 5; s++) {
        const base = y + k * 5, z = zs + s;
        if (oz !== undefined && (z < oz - 1 || z > oz + 17)) continue;
        for (let yy = base; yy < base + s; yy++) P(x, yy, z, plank);
        P(x, base + s, z, cell('dark_oak_stairs', stairsUp(2), 'oak_planks'));
        for (let yy = base + s + 1; yy <= base + 7; yy++) P(x, yy, z, 0);
      }
    }
    // Front door at the north end of the corridor: opening and a stepped landing down to the ground.
    for (let i = 8; i <= 10; i++) {
      const x = ix(i), z = p.z - 26;
      if ((ox !== undefined && (x < ox - 1 || x > ox + 17)) || (oz !== undefined && (z - 3 > oz + 17 || z < oz - 1))) continue;
      for (let dy = 0; dy <= 2; dy++) P(x, y + dy, z, 0);
      for (let n = 1; n <= 3; n++) {                                       // landing flush with the floor, columns down to the ground
        const g = t.height(x, z - n);
        for (let yy = g + 1; yy <= y - 1; yy++) P(x, yy, z - n, cob);
        P(x, y - 1, z - n, cob);
        for (let dy = 0; dy <= 2; dy++) P(x, y + dy, z - n, 0);
      }
    }
  }

  // ---- Rooms ------------------------------------------------------------------------------------------------------
  for (const r of rooms) {
    if (!inChunk(r.x0 - 1, r.z0 - 1, r.x1 + 1, r.z1 + 1)) continue;
    const Y = r.y, long = r.z1 - r.z0 + 1, away = (r.toCorridor + 2) & 3;
    // Doorway into the corridor, a torch beside it.
    for (let dy = 0; dy <= 1; dy++) { P(r.doorX, Y + dy, r.doorZ, 0); }
    const near = r.toCorridor === 1 ? r.x1 : r.x0, far = r.toCorridor === 1 ? r.x0 : r.x1, step = r.toCorridor === 1 ? -1 : 1;     // step = from the near column towards the far one
    const U = (u: number) => near + step * u;                               // u = 0 near the door … 4 far wall
    const V = (v: number) => r.z0 + v;
    const R = (u: number, dy: number, v: number, b: number) => P(U(u), Y + dy, V(v), b);
    const mid = (long - 1) >> 1;
    const sx = (u: number, dy: number, v: number) => [U(u), Y + dy, V(v)] as const;
    P(near, Y + 2, r.doorZ + 1, cell('torch', attachOn(r.toCorridor)));
    void far;
    const rr = hash2(r.x0, r.z0 + r.floor * 31, t.seed + 7421);
    switch (r.type) {
      case 'storage':
        for (const v of long === 7 ? [1, 3, 5] : [1]) { const [x, yy, z] = sx(4, 0, v); chest(put, t, x, yy, z, r.toCorridor, 'mansion_storage'); }
        { const [x, yy, z] = sx(4, 0, 0); barrel(put, t, x, yy, z, r.toCorridor); } { const [x, yy, z] = sx(4, 0, long - 1); barrel(put, t, x, yy, z, r.toCorridor); }
        R(2, 0, mid, bid('oak_planks')); R(2, 1, mid, bid('oak_pressure_plate', 'oak_planks'));
        break;
      case 'library':
        for (let v = 0; v < long; v++) for (let dy = 0; dy < 3; dy++) R(4, dy, v, bid('bookshelf', 'oak_planks'));
        for (let u = 1; u <= 3; u++) for (let dy = 0; dy < 2; dy++) { R(u, dy, 0, bid('bookshelf', 'oak_planks')); R(u, dy, long - 1, bid('bookshelf', 'oak_planks')); }
        { const [x, yy, z] = sx(2, 0, mid); lectern(put, x, yy, z, r.toCorridor); }
        { const [x, yy, z] = sx(3, 1, mid); itemFrame(put, t, x, yy, z, away, 'mansion_frame'); void x; }
        break;
      case 'bedroom':
        for (const v of long === 7 ? [1, 5] : [1]) { const [x, yy, z] = sx(3, 0, v); put(x, yy, z, cell('bed', away === 1 ? 3 : 1, 'white_wool'), true); const [x2, y2, z2] = sx(4, 0, v); put(x2, y2, z2, cell('bed', (away === 1 ? 3 : 1) | 4, 'white_wool'), true); }
        for (let u = 1; u <= 2; u++) for (let v = 1; v < long - 1; v++) { const [x, yy, z] = sx(u, 0, v); carpet(put, x, yy, z, 'red'); }
        { const [x, yy, z] = sx(1, 0, 0); pottedPlant(put, x, yy, z, Math.floor(rr * 7)); }
        { const [x, yy, z] = sx(4, 0, mid); chest(put, t, x, yy, z, r.toCorridor, 'mansion_storage'); }
        break;
      case 'dining':
        for (let v = 1; v <= Math.min(5, long - 2); v++) { R(2, 0, v, bid('oak_fence', 'oak_planks')); R(2, 1, v, bid('oak_pressure_plate', 'oak_planks')); R(1, 0, v, cell('dark_oak_stairs', stairsUp(away), 'oak_planks')); R(3, 0, v, cell('dark_oak_stairs', stairsUp(r.toCorridor), 'oak_planks')); }
        { const [x, yy, z] = sx(2, 3, mid); lantern(put, x, yy, z); P(x, yy + 1, z, bid('oak_fence', 'oak_planks')); }
        break;
      case 'jail':
        for (let v = 0; v < long; v++) for (let dy = 0; dy < 3; dy++) R(2, dy, v, v === mid ? 0 : bid('iron_bars', 'cobblestone'));
        R(2, 0, mid, cell('iron_door', away === 1 ? 3 : 1, 'iron_bars')); R(2, 1, mid, cell('iron_door', (away === 1 ? 3 : 1) | 4, 'iron_bars'));
        R(4, 0, 1, bid('cobweb', 'air')); R(3, 2, long - 2, bid('cobweb', 'air')); R(4, 0, long - 2, bid('oak_planks'));
        break;
      case 'garden':
        for (let u = 1; u <= 4; u++) for (let v = 0; v < long; v++) { const [x, yy, z] = sx(u, -1, v); P(x, yy, z, bid('grass_block', 'dirt')); R(u, 0, v, bid(['poppy', 'dandelion', 'azure_bluet', 'oxeye_daisy', 'red_tulip', 'allium'][Math.floor(hash2(U(u), V(v), t.seed + 7433) * 6)], 'dandelion')); }
        R(2, 0, mid, bid('oak_leaves', 'air')); R(2, -1, mid, bid('water', 'air'));
        break;
      case 'gallery':
        for (let u = 0; u <= 4; u++) for (let v = 0; v < long; v++) { const [x, yy, z] = sx(u, 0, v); if (u !== 0 || v !== mid) carpet(put, x, yy, z, 'purple'); }
        for (const v of long === 7 ? [1, 3, 5] : [1]) { const [x, yy, z] = sx(3, 1, v); itemFrame(put, t, x + 0, yy, z, away); void x; }
        for (const v of [0, long - 1]) { const [x, yy, z] = sx(1, 3, v); lantern(put, x, yy, z); }
        break;
      case 'smithy':
        R(4, 0, 1, bid('furnace', 'cobblestone')); R(4, 0, 2, bid('blast_furnace', 'furnace')); R(4, 0, 3, bid('grindstone', 'cobblestone')); R(4, 0, 4, bid('anvil', 'iron_block'));
        { const [x, yy, z] = sx(4, 0, long - 1); chest(put, t, x, yy, z, r.toCorridor, 'mansion_storage'); }
        break;
      case 'spider':
        for (let n = 0; n < 12; n++) { const u = 1 + Math.floor(hash2(r.x0 + n, r.z0, t.seed + 7451) * 4), v = Math.floor(hash2(r.x1, r.z0 + n, t.seed + 7452) * long), dy = 1 + (n % 3); R(u, dy, v, bid('cobweb', 'air')); }
        break;
      default:
        for (let u = 1; u <= 3; u++) { const [x, yy, z] = sx(u, 0, mid); carpet(put, x, yy, z, 'red'); }
        { const [x, yy, z] = sx(2, 3, mid); lantern(put, x, yy, z); }
    }
  }
  void fill; void tag;
  return rooms;
  function carpet0() { return bid('red_carpet', 'air'); }
}
