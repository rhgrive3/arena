// Nether fortress (Minecraft Wiki "Nether Fortress"): a jigsaw assembly (aligned pieces, one shared deck level) of open bridges,
// enclosed castle corridors, turns, a stair piece, a nether-wart room and – guaranteed – one or two very long blaze-spawner halls,
// grown from a central plaza in four directions. Everything stands on nether-brick pillars above an excavated lava lake.
import { type Put, type StructHost, bid, cell, hash2, stairsUp, tag, mulberry } from './common';
import { growJigsaw, rotSize, toWorld, worldDir, boxesOverlap, type Box, type Connector, type PieceDef, type Placed, type Pool } from './jigsaw';
import { chest, brewing } from './decor';

export const FORTRESS_Y = 26, FORTRESS_LAVA = 16, FORTRESS_RADIUS = 60;
const c = (x: number, y: number, z: number, dir: number): Connector => ({ x, y, z, dir, name: 'path', target: 'path', pool: 'any' });
const def = (id: string, kind: string, size: [number, number, number], connectors: Connector[], max?: number): PieceDef => ({ id, kind, size, connectors, max });
const straight = (id: string, kind: string, w: number, h: number, l: number, max?: number) => def(id, kind, [w, h, l], [c(w >> 1, 0, 0, 0), c(w >> 1, 0, l - 1, 2)], max);
const BRIDGES = [9, 13, 19].map(l => straight('bridge_' + l, 'bridge', 5, 5, l));
const HALL = straight('blaze_hall', 'blaze_hall', 7, 9, 31, 2), CORR = straight('corridor', 'corridor', 5, 6, 9);
const TURN_L = def('turn_l', 'turn', [5, 6, 5], [c(2, 0, 0, 0), c(0, 0, 2, 3)]), TURN_R = def('turn_r', 'turn', [5, 6, 5], [c(2, 0, 0, 0), c(4, 0, 2, 1)]);
const STAIRS = def('stairs', 'stairs', [5, 10, 9], [c(2, 0, 0, 0), c(2, 4, 8, 2)], 3);
const WART = def('wart_room', 'wart', [13, 8, 13], [c(6, 0, 0, 0), c(6, 0, 12, 2), c(0, 0, 6, 3)], 3);
const CAP = def('cap', 'cap', [5, 7, 5], [c(2, 0, 0, 0)]);
const POOLS: Record<string, Pool> = {
  any: { entries: [...BRIDGES.map((d, i) => ({ def: d, weight: [10, 10, 6][i] })), { def: CORR, weight: 8 }, { def: TURN_L, weight: 6 }, { def: TURN_R, weight: 6 }, { def: STAIRS, weight: 4 }, { def: HALL, weight: 6 }, { def: WART, weight: 5 }], fallback: 'caps' },
  caps: { entries: [{ def: CAP, weight: 1 }] },
};
export interface FortressLayout { cx: number; cz: number; pieces: Placed[]; hub: Box; spawners: [number, number, number][] }
const LAYOUTS = new Map<string, FortressLayout>();
const world = (p: Placed, lx: number, ly: number, lz: number) => toWorld(p, lx, ly, lz);

export function fortressLayout(seed: number, cx: number, cz: number): FortressLayout {
  const key = seed + ':' + cx + ',' + cz, hit = LAYOUTS.get(key);
  if (hit) return hit;
  const Y = FORTRESS_Y, hub: Box = [cx - 4, Y, cz - 4, cx + 4, Y + 5, cz + 4];
  let best: Placed[] = [], bestScore = -1;
  for (let k = 0; k < 12; k++) {
    const pieces = growJigsaw({
      seed: (Math.imul(seed | 0, 2654435761) ^ Math.imul(cx, 40503) ^ Math.imul(cz, 65599)) + k * 7919, pools: POOLS, occupied: [hub], maxDepth: 9, maxPieces: 42,
      roots: [{ x: cx, y: Y, z: cz - 4, dir: 0, target: 'path', pool: 'any' }, { x: cx + 4, y: Y, z: cz, dir: 1, target: 'path', pool: 'any' }, { x: cx, y: Y, z: cz + 4, dir: 2, target: 'path', pool: 'any' }, { x: cx - 4, y: Y, z: cz, dir: 3, target: 'path', pool: 'any' }],
      bounds: { cx, cz, r: FORTRESS_RADIUS, y0: Y - 8, y1: Y + 16 },
    });
    const score = pieces.filter(p => p.def.kind === 'blaze_hall').length * 40 + pieces.length + pieces.filter(p => p.def.kind === 'wart').length * 5;
    if (score > bestScore) { best = pieces; bestScore = score; }
    if (bestScore >= 90) break;
  }
  const spawners = best.filter(p => p.def.kind === 'blaze_hall').map(p => world(p, 3, 3, 22));
  const L = { cx, cz, pieces: best, hub, spawners };
  if (LAYOUTS.size > 8) LAYOUTS.clear();
  LAYOUTS.set(key, L);
  return L;
}

/** Builds the fortress around (cx, cz); with (ox, oz) only what touches that chunk. */
export function netherFortress(t: StructHost, put: Put, cx: number, cz: number, ox?: number, oz?: number) {
  const L = fortressLayout(t.seed, cx, cz), NB = bid('nether_bricks'), FE = bid('nether_bricks_fence', 'nether_bricks'), AIR = 0, lava = bid('lava'), Y = FORTRESS_Y;
  const near = (b: Box) => ox === undefined || oz === undefined || !(b[3] < ox - 1 || b[0] > ox + 17 || b[5] < oz - 1 || b[2] > oz + 17);
  const rnd = mulberry(t.seed ^ cx);
  void rnd;
  const stairs = (dir: number) => cell('nether_brick_stairs', stairsUp(dir), 'nether_bricks');
  const slab = bid('nether_brick_slab', 'nether_bricks');
  /** Lava lake under a footprint (pad 2): excavated down to the lava level, pillars every 6 blocks. */
  const lake = (b: Box, pillars: boolean) => {
    for (let z = oz === undefined ? b[2] - 2 : Math.max(b[2] - 2, oz - 1); z <= (oz === undefined ? b[5] + 2 : Math.min(b[5] + 2, oz + 17)); z++) for (let x = ox === undefined ? b[0] - 2 : Math.max(b[0] - 2, ox - 1); x <= (ox === undefined ? b[3] + 2 : Math.min(b[3] + 2, ox + 17)); x++) {
      for (let y = FORTRESS_LAVA + 1; y < Y; y++) put(x, y, z, AIR, true);
      put(x, FORTRESS_LAVA, z, lava, true); put(x, FORTRESS_LAVA - 1, z, lava, true);
      if (pillars && (x - b[0]) % 6 === 0 && (z - b[2]) % 6 === 0 && x >= b[0] && x <= b[3] && z >= b[2] && z <= b[5]) for (let y = FORTRESS_LAVA - 2; y < Y; y++) put(x, y, z, NB, true);
    }
  };
  // Central plaza: 9×9 deck with rails, a pillar of fences and a lantern-less obelisk; every root direction opens onto a bridge.
  if (near(L.hub)) {
    lake(L.hub, true);
    for (let z = L.hub[2]; z <= L.hub[5]; z++) for (let x = L.hub[0]; x <= L.hub[3]; x++) {
      const edge = x === L.hub[0] || x === L.hub[3] || z === L.hub[2] || z === L.hub[5], gap = Math.abs(x - cx) <= 1 || Math.abs(z - cz) <= 1;
      put(x, Y, z, NB, true);
      for (let dy = 1; dy <= 5; dy++) put(x, Y + dy, z, edge && dy === 1 && !(gap && edge) ? FE : AIR, true);
    }
    for (let dy = 1; dy <= 3; dy++) put(cx, Y + dy, cz, dy === 3 ? FE : NB, true);
  }
  for (const p of L.pieces) {
    if (!near(p.box)) continue;
    const [w, h, l] = p.def.size, kind = p.def.kind, P = (lx: number, ly: number, lz: number, b: number) => { const [x, y, z] = world(p, lx, ly, lz); put(x, y, z, b, true); };
    const used = new Set<number>([p.entry]);
    for (const q of L.pieces) if (q.parent >= 0 && L.pieces[q.parent] === p) used.add(q.parentConn);
    lake(p.box, kind === 'bridge' || kind === 'blaze_hall' || kind === 'wart');
    const open = kind === 'bridge';
    for (let lz = 0; lz < l; lz++) for (let lx = 0; lx < w; lx++) for (let ly = 0; ly < h; ly++) {
      const edge = lx === 0 || lx === w - 1, end = lz === 0 || lz === l - 1;
      let b = AIR;
      if (ly === 0) b = NB;
      else if (open) b = edge && ly === 1 ? ((lz % 6 === 0) ? NB : FE) : edge && ly === 2 && lz % 6 === 0 ? NB : AIR;
      else if (ly === h - 1 && kind !== 'stairs') b = NB;
      else if (kind !== 'stairs' || ly <= h - 2) {
        if (edge) b = ly >= 2 && ly <= h - 3 && lz % 4 === 2 && kind !== 'cap' ? FE : NB;       // windows of nether-brick fence
        else if (end && ly <= 4) b = AIR;                                                        // arches: ends are opened below, sealed per connector later
        else if (end) b = NB;
      }
      P(lx, ly, lz, b);
    }
    // Seal the connectors nothing was attached to (castle pieces) and open the used ones.
    if (!open) p.def.connectors.forEach((cn, i) => {
      const [dx, dz] = [[0, 1], [-1, 0], [0, -1], [1, 0]][cn.dir]; void dx; void dz;
      for (let k = -1; k <= 1; k++) for (let ly = 1; ly <= 3; ly++) {
        const lx = cn.dir === 0 || cn.dir === 2 ? cn.x + k : cn.x, lz = cn.dir === 0 || cn.dir === 2 ? cn.z : cn.z + k;
        P(lx, cn.y + ly, lz, used.has(i) ? AIR : NB);
      }
    });
    switch (kind) {
      case 'stairs':
        for (let k = 1; k <= 4; k++) for (let lx = 1; lx <= 3; lx++) { for (let ly = 0; ly < k; ly++) P(lx, ly, k, NB); P(lx, k, k, stairs(worldDir(p, 2))); }
        for (let lz = 5; lz <= 8; lz++) for (let lx = 0; lx < w; lx++) P(lx, 4, lz, NB);
        for (let lz = 5; lz <= 7; lz++) for (let lx = 1; lx <= 3; lx++) for (let ly = 5; ly <= 8; ly++) P(lx, ly, lz, AIR);
        for (let lz = 1; lz <= 8; lz++) for (const lx of [0, 4]) for (let ly = 1; ly <= 9; ly++) P(lx, ly, lz, ly === 9 ? NB : lz > 4 && ly <= 4 ? NB : NB);
        for (let lz = 0; lz < l; lz++) for (let lx = 0; lx < w; lx++) P(lx, 9, lz, NB);
        for (let lz = 5; lz <= 7; lz++) for (let lx = 1; lx <= 3; lx++) for (let ly = 5; ly <= 8; ly++) P(lx, ly, lz, AIR);
        for (let k = 1; k <= 4; k++) for (let lx = 1; lx <= 3; lx++) for (let ly = k + 1; ly <= 8; ly++) P(lx, ly, k, AIR);
        break;
      case 'blaze_hall': {
        for (const lz of [4, 10, 16]) for (let ly = 1; ly <= 5; ly++) { P(1, ly, lz, NB); P(5, ly, lz, NB); }
        for (let lx = 1; lx <= 5; lx++) { P(lx, 1, 18, stairs(worldDir(p, 2))); P(lx, 2, 19, stairs(worldDir(p, 2))); }
        for (let lz = 20; lz <= 26; lz++) for (let lx = 1; lx <= 5; lx++) { P(lx, 1, lz, NB); P(lx, 2, lz, NB); }
        for (let lz = 19; lz <= 19; lz++) for (let lx = 1; lx <= 5; lx++) P(lx, 1, lz, NB);
        P(3, 3, 22, bid('spawner', 'nether_bricks'));                                             // blaze spawner
        for (const [lx, lz] of [[2, 21], [3, 21], [4, 21], [2, 22], [4, 22], [2, 23], [3, 23], [4, 23]]) { P(lx, 3, lz, FE); P(lx, 4, lz, FE); }
        { const [x, y, z] = world(p, 1, 3, 25); chest(put, t, x, y, z, worldDir(p, 1), 'nether_fortress_bridge'); }
        { const [x, y, z] = world(p, 5, 3, 25); chest(put, t, x, y, z, worldDir(p, 3), 'nether_fortress_bridge'); }
        { const [x, y, z] = world(p, 3, 3, 26); brewing(put, t, x, y, z, 'fortress_brewing'); }
        break;
      }
      case 'wart':
        for (const lz of [3, 5, 7, 9]) for (let lx = 3; lx <= 9; lx++) { P(lx, 1, lz, bid('soul_sand')); P(lx, 2, lz, bid('nether_wart', 'air')); }
        for (let lz = 2; lz <= 10; lz++) for (const lx of [2, 10]) P(lx, 1, lz, NB);
        P(6, 1, 11, slab);
        { const [x, y, z] = world(p, 11, 1, 10); chest(put, t, x, y, z, worldDir(p, 3), 'nether_fortress_stairs'); }
        break;
      case 'cap': { const [x, y, z] = world(p, 2, 1, 3); chest(put, t, x, y, z, worldDir(p, 0), 'nether_fortress_bridge'); break; }
      case 'bridge':
        if (hash2(p.bx, p.bz, t.seed + 91) < 0.35) { const [x, y, z] = world(p, 2, 1, p.def.size[2] >> 1); put(x, y, z, bid('nether_wart', 'air'), true); put(x, y - 1, z, bid('soul_sand'), true); }
        break;
    }
    void rotSize; void boxesOverlap; void tag;
  }
  return L;
}
