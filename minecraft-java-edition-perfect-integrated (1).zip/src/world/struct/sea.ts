// Ocean structures (Minecraft Wiki "Ocean Monument" / "Shipwreck").
//  * Ocean monument – a 57×57 prismarine complex of up to three tiers: outer shell with sea lanterns, an inner ring wall, a central
//    water shaft, a dark-prismarine core room holding the eight gold blocks (and a treasure chest), two wet-sponge rooms and four
//    corner towers. The three elder guardians of `structureOccupants` swim in the open inner hall and the central shaft.
//  * Shipwreck – a weathered hull in one of five woods, in one of four headings, with a stern cabin (map chest + framed map), a
//    cargo hold (supply chests, barrels) and a hidden treasure chest at the keel; planks decay at random.
import { type Put, type StructHost, SEA, bid, cell, hash2, hash3, stairsUp, attachOn } from './common';
import { chest, barrel, itemFrame, lantern } from './decor';

interface Site { x: number; y: number; z: number }
export const MONUMENT_HALF = 28;

export function oceanMonument(t: StructHost, put: Put, p: Site, ox?: number, oz?: number) {
  const pb = bid('prismarine_bricks', 'prismarine'), pr = bid('prismarine'), dp = bid('dark_prismarine', 'prismarine'), lan = bid('sea_lantern', 'glowstone'), water = bid('water');
  const gold = bid('gold_block'), sponge = bid('wet_sponge', 'sponge'), s = t.seed + 7300, H = MONUMENT_HALF;
  const T = SEA - 3 - p.y;                                   // free height above the floor
  const tierB = T >= 12, tierC = T >= 17, top = tierC ? 17 : tierB ? 12 : 6;
  const wall = (x: number, y: number, z: number) => (hash3(x, y, z, s) < 0.28 ? pr : pb);
  const door = (a: number, b: number) => Math.abs(a) <= 2 || Math.abs(b) <= 2;
  const x0 = ox === undefined ? p.x - H : Math.max(p.x - H, ox - 1), x1 = ox === undefined ? p.x + H : Math.min(p.x + H, ox + 17);
  const z0 = oz === undefined ? p.z - H : Math.max(p.z - H, oz - 1), z1 = oz === undefined ? p.z + H : Math.min(p.z + H, oz + 17);
  const rooms = [[-13, 13], [13, 13]];                       // wet-sponge rooms (centre dx, dz), half size 4
  for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
    const dx = x - p.x, dz = z - p.z, m = Math.max(Math.abs(dx), Math.abs(dz)), shaft = Math.abs(dx) <= 3 && Math.abs(dz) <= 3;
    // Foundation columns down to the sea bed so the monument never hovers over a trench.
    if (m >= 20 || (m <= 4)) for (let y = Math.max(t.height(x, z) + 1, p.y - 14); y < p.y; y++) put(x, y, z, pb, true);
    for (let dy = 0; dy <= top; dy++) {
      let b = water;
      const y = p.y + dy;
      if (dy === 0) b = hash2(x, z, s + 1) < 0.25 ? dp : pb;
      else if (dy <= 5) {
        if (m >= 27) b = door(dx, dz) && dy <= 4 ? water : dy === 3 && ((dx + dz) & 3) === 0 ? lan : wall(x, y, z);
        else if (m === 20) b = door(dx, dz) && dy <= 4 ? water : dy === 4 && ((dx + dz) & 3) === 0 ? lan : wall(x, y, z);
        else if (m > 20 && m < 27 && dy === 1 && ((Math.abs(dx) + Math.abs(dz)) & 7) === 0) b = lan;
      } else if (dy === 6) b = shaft ? water : top === 6 ? (m <= 28 ? wall(x, y, z) : water) : (m <= 28 ? wall(x, y, z) : water);
      else if (tierB && dy <= 11) b = m >= 20 && m <= 21 ? (door(dx, dz) && dy <= 10 && dy >= 8 ? water : wall(x, y, z)) : water;
      else if (tierB && dy === 12) b = m <= 21 && !shaft ? wall(x, y, z) : water;
      else if (tierC && dy <= 16) b = m >= 12 && m <= 13 ? (door(dx, dz) && dy <= 15 && dy >= 14 ? water : wall(x, y, z)) : water;
      else if (tierC && dy === 17) b = m <= 13 && !shaft ? wall(x, y, z) : water;
      if (dy > 0 && dy <= 5 && m > 21 && m < 27 && Math.abs(dx) === 24 && Math.abs(dz) % 6 === 0) b = pb;       // buttress pillars in the outer corridor
      put(x, y, z, b, true);
    }
    // Corner towers.
    if (Math.abs(dx) >= 27 && Math.abs(dz) >= 27) { const h = Math.min(14, T - 1); for (let dy = 6; dy <= h; dy++) put(x, p.y + dy, z, dy === h ? lan : pb, true); }
  }

  const A = (dx: number, dy: number, dz: number, b: number) => { const x = p.x + dx, z = p.z + dz; if ((ox === undefined || (x >= ox - 1 && x <= ox + 17)) && (oz === undefined || (z >= oz - 1 && z <= oz + 17))) put(x, p.y + dy, z, b, true); };
  // Core room (north of the shaft): dark prismarine shell, the eight gold blocks, sea lanterns, treasure chest, framed crystal.
  for (let dz = -16; dz <= -10; dz++) for (let dx = -3; dx <= 3; dx++) for (let dy = 1; dy <= 5; dy++) {
    const edge = Math.abs(dx) === 3 || dz === -16 || dz === -10;
    A(dx, dy, dz, edge && !(dz === -10 && Math.abs(dx) <= 1 && dy <= 3) ? dp : water);
  }
  for (let dz = -14; dz <= -13; dz++) for (let dx = -1; dx <= 0; dx++) for (let dy = 1; dy <= 2; dy++) A(dx, dy, dz, gold);
  for (const [dx, dz] of [[-2, -15], [2, -15], [-2, -11], [2, -11]]) A(dx, 3, dz, lan);
  if (ox === undefined || (p.x + 2 >= ox - 1 && p.x + 2 <= ox + 17 && p.z - 15 >= oz! - 1 && p.z - 15 <= oz! + 17)) chest(put, t, p.x + 2, p.y + 1, p.z - 15, 2, 'monument_treasure');
  if (ox === undefined || (p.x >= ox - 1 && p.x <= ox + 17 && p.z - 15 >= oz! - 1 && p.z - 15 <= oz! + 17)) itemFrame(put, t, p.x, p.y + 3, p.z - 15, 0, 'monument_frame');
  // Wet sponge rooms.
  for (const [cx, cz] of rooms) for (let dz = -4; dz <= 4; dz++) for (let dx = -4; dx <= 4; dx++) for (let dy = 1; dy <= 5; dy++) {
    const x = cx + dx, z = cz + dz, edge = Math.abs(dx) === 4 || Math.abs(dz) === 4, inner = !edge;
    let b = water;
    if (edge) b = dz === -4 && Math.abs(dx) <= 1 && dy <= 3 ? water : pb;
    else if ((dy === 1 || dy === 5 || Math.abs(dx) === 3 || Math.abs(dz) === 3) && hash3(x + p.x, dy, z + p.z, s + 5) < 0.62) b = sponge;
    if (inner && dx === 0 && dz === 0 && dy === 3) b = lan;
    A(x, dy, z, b);
  }
  // Framed prismarine crystals on the inner ring wall.
  for (const [dx, dz, d] of [[-8, -19, 0], [8, 19, 2], [-19, 8, 3], [19, -8, 1]] as const) {
    const x = p.x + dx, z = p.z + dz;
    if ((ox === undefined || (x >= ox - 1 && x <= ox + 17)) && (oz === undefined || (z >= oz - 1 && z <= oz + 17))) itemFrame(put, t, x, p.y + 3, z, d, 'monument_frame');
  }
}

// ---- Shipwreck ---------------------------------------------------------------------------------------------------------
const WOODS = ['oak', 'spruce', 'dark_oak', 'birch', 'jungle'];
export function shipwreckBuild(t: StructHost, put: Put, p: Site) {
  const seed = t.seed + 7200, wood = WOODS[Math.floor(hash2(p.x, p.z, seed + 11) * WOODS.length)], rot = Math.floor(hash2(p.x, p.z, seed + 12) * 4);
  const planks = bid(wood + '_planks', 'oak_planks'), log = bid(wood + '_log', 'oak_log'), deckId = bid('dark_oak_planks', 'oak_planks'), fence = bid(wood + '_fence', 'oak_fence'), water = bid('water');
  const stairsName = wood + '_stairs';
  const XZ = (i: number, w: number): [number, number] => rot === 0 ? [p.x + i, p.z + w] : rot === 1 ? [p.x - w, p.z + i] : rot === 2 ? [p.x - i, p.z - w] : [p.x + w, p.z - i];
  const D = (d: number) => (d + rot) & 3;                                  // local → world direction (local 0 = north = -w … see below)
  const P = (i: number, dy: number, w: number, b: number) => { const [x, z] = XZ(i, w); put(x, p.y + dy, z, b, true); };
  const hw = (i: number) => (Math.abs(i) >= 9 ? 1 : Math.abs(i) >= 6 ? 2 : 3);
  const decay = (i: number, dy: number, w: number, k: number) => hash3(i + p.x, dy + k, w + p.z, seed) < 0.16;
  const maxDy = Math.max(6, SEA - 2 - p.y);
  // Hull, hold and deck.
  for (let i = -10; i <= 10; i++) {
    const h = hw(i);
    for (let w = -3; w <= 3; w++) for (let dy = 0; dy <= 5; dy++) {
      if (Math.abs(w) > h) { if (Math.abs(w) <= 3 && dy <= 4 && Math.abs(i) <= 10) P(i, dy, w, 0); continue; }
      const edge = Math.abs(w) === h, tip = Math.abs(i) === 10;
      let b = 0;
      if (dy === 0) b = deckId;                                                    // keel
      else if (dy <= 2) b = edge || tip ? (decay(i, dy, w, 1) && dy === 2 ? 0 : planks) : water;                       // hold
      else if (dy === 3) b = (edge || (Math.abs(i - 3) <= 1 && w === 0) ? (Math.abs(i - 3) <= 1 && w === 0 ? 0 : planks) : decay(i, dy, w, 2) ? 0 : deckId); // deck, hatch at i=3
      else if (dy === 4) b = edge && !decay(i, dy, w, 3) ? planks : 0;             // rail
      else b = 0;
      P(i, dy, w, b);
    }
  }
  // Bow rail posts, bowsprit and masts.
  for (let k = 0; k < 3; k++) P(11 + k, 3 + (k > 0 ? 1 : 0), 0, log);
  const mast = (i: number, h: number) => { for (let dy = 3; dy <= Math.min(h, maxDy); dy++) P(i, dy, 0, log); if (h >= 7 && h <= maxDy) for (let w = -2; w <= 2; w++) P(i, Math.min(h, maxDy) - 1, w, w === 0 ? log : fence); };
  mast(1, 11); mast(-5, 8 + Math.floor(hash2(p.x, p.z, seed + 13) * 3));
  // Stern cabin: map chest + framed map + lantern.
  for (let i = -9; i <= -5; i++) for (let w = -2; w <= 2; w++) for (let dy = 4; dy <= 7; dy++) {
    const edge = i === -9 || i === -5 || Math.abs(w) === 2, roof = dy === 7;
    P(i, dy, w, roof ? (decay(i, dy, w, 4) ? 0 : planks) : edge ? ((dy === 5 && (w === 0 || i === -7) && !(i === -5 && w === 0)) ? 0 : (i === -5 && w === 0 && dy <= 5 ? 0 : planks)) : 0);
  }
  const [cx, cz] = XZ(-8, 1);
  chest(put, t, cx, p.y + 4, cz, D(1), 'shipwreck_map');
  { const [fx, fz] = XZ(-8, -1); itemFrame(put, t, fx, p.y + 5, fz, D(3), 'shipwreck_frame'); }
  { const [lx, lz] = XZ(-7, -1); lantern(put, lx, p.y + 4, lz); }
  // Cargo hold: partition with a doorway, supply chests, barrels, hidden treasure at the stern keel.
  for (let w = -2; w <= 2; w++) for (let dy = 1; dy <= 2; dy++) P(-3, dy, w, Math.abs(w) <= 0 && dy <= 2 ? 0 : planks);
  for (const [i, w] of [[2, 2], [4, -2], [0, -2]] as const) { const [x, z] = XZ(i, w); chest(put, t, x, p.y + 1, z, D(w > 0 ? 0 : 2), 'shipwreck_supply'); }
  for (const [i, w] of [[5, 2], [6, 1], [-1, 2]] as const) { const [x, z] = XZ(i, w); barrel(put, t, x, p.y + 1, z, D(w > 0 ? 0 : 2)); }
  { const [x, z] = XZ(-7, 0); chest(put, t, x, p.y + 1, z, D(1), 'shipwreck_treasure'); }
  { const [x, z] = XZ(-6, 1); put(x, p.y + 1, z, cell(stairsName, stairsUp(D(1)), 'oak_stairs'), true); }
  { const [tx, tz] = XZ(-7, -1); put(tx, p.y + 1, tz, cell('torch', attachOn(D(0)), 'torch'), true); }
}
