import { BLOCKS, type BlockDef } from '../game/data';
import { isSlabBlock } from '../game/blockState';

export type Bounds = readonly [number, number, number, number, number, number];
export const CHEST_BOUNDS: Bounds = [1 / 16, 0, 1 / 16, 15 / 16, 14 / 16, 15 / 16];
const CHEST: readonly Bounds[] = [CHEST_BOUNDS];
const FULL: readonly Bounds[] = [[0, 0, 0, 1, 1, 1]];
const SLAB: readonly Bounds[] = [[0, 0, 0, 1, .5, 1]];
const TOP_SLAB: readonly Bounds[] = [[0, .5, 0, 1, 1, 1]];
const STAIRS: readonly (readonly Bounds[])[] = [
  [[0,0,0,1,.5,1],[0,.5,0,1,1,.5]],
  [[0,0,0,1,.5,1],[.5,.5,0,1,1,1]],
  [[0,0,0,1,.5,1],[0,.5,.5,1,1,1]],
  [[0,0,0,1,.5,1],[0,.5,0,.5,1,1]],
  [[0,.5,0,1,1,1],[0,0,0,1,.5,.5]],
  [[0,.5,0,1,1,1],[.5,0,0,1,.5,1]],
  [[0,.5,0,1,1,1],[0,0,.5,1,.5,1]],
  [[0,.5,0,1,1,1],[0,0,0,.5,.5,1]],
];
const T3 = 3 / 16;
/** 3px panels standing on one edge of the cell: 0 = north (z 0..3px), 1 = west (x 0..3px), 2 = south, 3 = east. Doors and open trapdoors. */
const EDGE: readonly (readonly Bounds[])[] = [[[0, 0, 0, 1, 1, T3]], [[0, 0, 0, T3, 1, 1]], [[0, 0, 1 - T3, 1, 1, 1]], [[1 - T3, 0, 0, 1, 1, 1]]];
const TRAPDOOR: readonly Bounds[] = [[0, 0, 0, 1, T3, 1]];
const TRAPDOOR_TOP: readonly Bounds[] = [[0, 1 - T3, 0, 1, 1, 1]];
const PANE: readonly Bounds[] = [[.4375, 0, 0, .5625, 1, 1]];
const PANE_X: readonly Bounds[] = [[0, 0, .4375, 1, 1, .5625]];
const CHAIN: readonly Bounds[] = [[6.5 / 16, 0, 6.5 / 16, 9.5 / 16, 1, 9.5 / 16]];
// Collision keeps the full cross so nothing slips between connected posts; the rendered arms follow the neighbours (see mesher).
const FENCE: readonly Bounds[] = [[.375, 0, .375, .625, 1, .625], [0, .4, .42, 1, .55, .58], [.42, .4, 0, .58, .55, 1], [0, .78, .42, 1, .93, .58], [.42, .78, 0, .58, .93, 1]];
const TORCH: readonly Bounds[] = [[.35, 0, .35, .65, .75, .65]];
const TORCH_MODEL: readonly Bounds[] = [[7 / 16, 0, 7 / 16, 9 / 16, 10 / 16, 9 / 16]];
const LANTERN: readonly Bounds[] = [
  [5 / 16, 0, 5 / 16, 11 / 16, 7 / 16, 11 / 16],
  [6 / 16, 7 / 16, 6 / 16, 10 / 16, 9 / 16, 10 / 16],
  [7 / 16, 9 / 16, 7 / 16, 9 / 16, 11 / 16, 9 / 16],
];
const BELL: readonly Bounds[] = [
  [1 / 16, 0, 6 / 16, 3 / 16, 15 / 16, 10 / 16],
  [13 / 16, 0, 6 / 16, 15 / 16, 15 / 16, 10 / 16],
  [1 / 16, 13 / 16, 6.5 / 16, 15 / 16, 15 / 16, 9.5 / 16],
  [5 / 16, 5 / 16, 5 / 16, 11 / 16, 12 / 16, 11 / 16],
  [4 / 16, 3 / 16, 4 / 16, 12 / 16, 5 / 16, 12 / 16],
];
const LECTERN: readonly Bounds[] = [
  [0, 0, 0, 1, 2 / 16, 1],
  [4 / 16, 2 / 16, 4 / 16, 12 / 16, 11 / 16, 12 / 16],
  [1 / 16, 10 / 16, 1 / 16, 15 / 16, 13 / 16, 6 / 16],
  [1 / 16, 11.5 / 16, 5 / 16, 15 / 16, 14.5 / 16, 11 / 16],
  [1 / 16, 13 / 16, 10 / 16, 15 / 16, 1, 15 / 16],
];
const CACTUS: readonly Bounds[] = [[1 / 16, 0, 1 / 16, 15 / 16, 1, 15 / 16]];
const FARMLAND: readonly Bounds[] = [[0, 0, 0, 1, 15 / 16, 1]];
const BED: readonly Bounds[] = [[0, 0, 0, 1, 9 / 16, 1]];
const FRAME: readonly Bounds[] = [[0, 0, 0, 1, 13 / 16, 1]];
const END_ROD: readonly Bounds[] = [[6 / 16, 0, 6 / 16, 10 / 16, 1, 10 / 16]];
const SHULKER: readonly Bounds[] = [[1 / 16, 0, 1 / 16, 15 / 16, 1, 15 / 16]];
const EGG: readonly Bounds[] = [[2 / 16, 0, 2 / 16, 14 / 16, 1, 14 / 16]];
const HEAD: readonly Bounds[] = [[.2, 0, .2, .8, .65, .8]];
const END_PORTAL_BOX: readonly Bounds[] = [[0, 0, 0, 1, 12 / 16, 1]];
// Vanilla Brewing Stand: 3 stone base plates + central blaze rod + top collar
const BREWING: readonly Bounds[] = [
  [1 / 16, 0, 9 / 16, 7 / 16, 2 / 16, 15 / 16],
  [9 / 16, 0, 9 / 16, 15 / 16, 2 / 16, 15 / 16],
  [5 / 16, 0, 1 / 16, 11 / 16, 2 / 16, 7 / 16],
  [7 / 16, 0, 7 / 16, 9 / 16, 14 / 16, 9 / 16],
];
const PLANT: readonly Bounds[] = [[.2, 0, .2, .8, .8, .8]];
const LILY: readonly Bounds[] = [[.06, 0, .06, .94, .08, .94]];
const NONE: readonly Bounds[] = [];
// Tripwire string: a thin strand along the axis it is strung on (state bit 3 = Z axis), a small cross while unattached.
const TRIPWIRE_X: readonly Bounds[] = [[0, 1 / 16, 7.5 / 16, 1, 2 / 16, 8.5 / 16]];
const TRIPWIRE_Z: readonly Bounds[] = [[7.5 / 16, 1 / 16, 0, 8.5 / 16, 2 / 16, 1]];
const TRIPWIRE_FREE: readonly Bounds[] = [TRIPWIRE_X[0], TRIPWIRE_Z[0]];
const LADDER: readonly (readonly Bounds[])[] = [[[0, 0, 0, 1, 1, 1 / 16]], [[0, 0, 0, 1 / 16, 1, 1]], [[0, 0, 15 / 16, 1, 1, 1]], [[15 / 16, 0, 0, 1, 1, 1]]];
// Low blocks with their vanilla heights (they used to be drawn as half blocks).
const px = (h: number, inset = 0): readonly Bounds[] => [[inset / 16, 0, inset / 16, 1 - inset / 16, h / 16, 1 - inset / 16]];
const LOW = { carpet: px(1), plate: px(1, 1), platePressed: px(0.5, 1), diode: px(2), detector: px(6), table: px(12), cutter: px(9), snow: px(2), campfire: px(7) };
const ANVIL_Z: readonly Bounds[] = [
  [2 / 16, 0, 2 / 16, 14 / 16, 4 / 16, 14 / 16],
  [4 / 16, 4 / 16, 3 / 16, 12 / 16, 5 / 16, 13 / 16],
  [6 / 16, 5 / 16, 4 / 16, 10 / 16, 10 / 16, 12 / 16],
  [3 / 16, 10 / 16, 0, 13 / 16, 1, 1],
];
const ANVIL_X: readonly Bounds[] = [
  [2 / 16, 0, 2 / 16, 14 / 16, 4 / 16, 14 / 16],
  [3 / 16, 4 / 16, 4 / 16, 13 / 16, 5 / 16, 12 / 16],
  [4 / 16, 5 / 16, 6 / 16, 12 / 16, 10 / 16, 10 / 16],
  [0, 10 / 16, 3 / 16, 1, 1, 13 / 16],
];
const GRINDSTONE: readonly Bounds[] = [[4 / 16, 4 / 16, 2 / 16, 12 / 16, 1, 14 / 16], [2 / 16, 0, 6 / 16, 4 / 16, 12 / 16, 10 / 16], [12 / 16, 0, 6 / 16, 14 / 16, 12 / 16, 10 / 16]];
// Piston head: a plate on the far side plus the arm, by facing (0 +X, 1 +Z, 2 -X, 3 -Z, 4 up, 5 down).
const s16 = 1 / 16;
const PISTON_HEAD: readonly (readonly Bounds[])[] = [
  [[12 * s16, 0, 0, 1, 1, 1], [0, 6 * s16, 6 * s16, 12 * s16, 10 * s16, 10 * s16]],
  [[0, 0, 12 * s16, 1, 1, 1], [6 * s16, 6 * s16, 0, 10 * s16, 10 * s16, 12 * s16]],
  [[0, 0, 0, 4 * s16, 1, 1], [4 * s16, 6 * s16, 6 * s16, 1, 10 * s16, 10 * s16]],
  [[0, 0, 0, 1, 1, 4 * s16], [6 * s16, 6 * s16, 4 * s16, 10 * s16, 10 * s16, 1]],
  [[0, 12 * s16, 0, 1, 1, 1], [6 * s16, 0, 6 * s16, 10 * s16, 12 * s16, 10 * s16]],
  [[0, 0, 0, 1, 4 * s16, 1], [6 * s16, 4 * s16, 6 * s16, 10 * s16, 1, 10 * s16]],
];
function lowBoxes(name: string, state: number): readonly Bounds[] {
  if (name === 'piston_head') return PISTON_HEAD[state & 7] ?? PISTON_HEAD[0];
  if (name === 'lectern') return LECTERN;
  if (name === 'bell') return BELL;
  if (name === 'snow_layer') return LOW.snow;
  if (name === 'campfire' || name === 'unlit_campfire') return LOW.campfire;
  if (name === 'tripwire' || name.endsWith('_carpet') || name === 'redstone_wire' || name === 'rail' || name === 'powered_rail' || name === 'detector_rail' || name === 'activator_rail') return LOW.carpet;
  if (name.endsWith('_pressure_plate')) return state & 8 ? LOW.platePressed : LOW.plate;
  if (name === 'repeater' || name === 'comparator') return LOW.diode;
  if (name.startsWith('daylight_detector') || name.endsWith('daylight_detector')) return LOW.detector;
  if (name === 'enchanting_table' || name === 'end_portal') return LOW.table;
  if (name === 'stonecutter' || name === 'bed') return LOW.cutter;
  if (name === 'anvil') return (state & 1) ? ANVIL_X : ANVIL_Z;
  if (name === 'grindstone') return GRINDSTONE;
  return name.startsWith('farmland') ? FARMLAND : SLAB;
}

/** Door state: bits 0-1 = edge the closed leaf stands on, bit 2 = upper half, bit 3 = open (left hinge: swings onto the next edge). */
export function doorEdge(state: number): number {
  return state & 8 ? ((state & 3) + 3) & 3 : state & 3;
}

// Attachable blocks (torch, lever, buttons): state bits 0-2 = attachment (0 floor, 1..4 wall with the block facing +X, -X, +Z, -Z, 5 ceiling),
// bit 3 = lever on / button pressed. Model boxes are in sixteenths of a block, taken from the vanilla models.
type Sixteenths = readonly (readonly number[])[];
/** [x0,y0,z0,x1,y1,z1, sheared end (1 = top, -1 = none), dx, dz]: wall torches lean away from the wall. */
export const TORCH16: Sixteenths = [[7, 0, 7, 9, 10, 9, -1, 0, 0], [0.5, 3, 7, 2.5, 13, 9, 1, 4, 0], [13.5, 3, 7, 15.5, 13, 9, 1, -4, 0], [7, 3, 0.5, 9, 13, 2.5, 1, 0, 4], [7, 3, 13.5, 9, 13, 15.5, 1, 0, -4]];
export const LEVER_BASE16: Sixteenths = [[5, 0, 4, 11, 3, 12], [0, 4, 5, 3, 12, 11], [13, 4, 5, 16, 12, 11], [5, 4, 0, 11, 12, 3], [5, 4, 13, 11, 12, 16], [5, 13, 4, 11, 16, 12]];
/** Handle per attachment as [off, on]: [x0,y0,z0,x1,y1,z1, sheared end (0 bottom / 1 top), dx, dz]. */
export const LEVER_STICK16: readonly Sixteenths[] = [
  [[7, 2, 7, 9, 9, 9, 1, 0, 6], [7, 2, 7, 9, 9, 9, 1, 0, -6]],
  [[2, 8, 7, 4, 14, 9, 1, 6, 0], [2, 2, 7, 4, 8, 9, 0, 6, 0]],
  [[12, 8, 7, 14, 14, 9, 1, -6, 0], [12, 2, 7, 4, 8, 9, 0, -6, 0]],
  [[7, 8, 2, 9, 14, 4, 1, 0, 6], [7, 2, 2, 9, 8, 4, 0, 0, 6]],
  [[7, 8, 12, 9, 14, 14, 1, 0, -6], [7, 2, 12, 9, 8, 14, 0, 0, -6]],
  [[7, 7, 7, 9, 14, 9, 0, 0, 6], [7, 7, 7, 9, 14, 9, 0, 0, -6]],
];
export const BUTTON16: Sixteenths = [[5, 0, 6, 11, 2, 10], [0, 6, 5, 2, 10, 11], [14, 6, 5, 16, 10, 11], [5, 6, 0, 11, 10, 2], [5, 6, 14, 11, 10, 16], [5, 14, 6, 11, 16, 10]];
const unit = (b: readonly number[]): readonly Bounds[] => [[b[0] / 16, b[1] / 16, b[2] / 16, b[3] / 16, b[4] / 16, b[5] / 16]];
const TORCH_SEL = [[6, 0, 6, 10, 10, 10], [0, 3, 6, 6.5, 13, 10], [9.5, 3, 6, 16, 13, 10], [6, 3, 0, 10, 13, 6.5], [6, 3, 9.5, 10, 13, 16]].map(unit);
const LEVER_SEL = [[5, 0, 4, 11, 10, 12], [0, 2, 5, 10, 14, 11], [6, 2, 5, 16, 14, 11], [5, 2, 0, 11, 14, 10], [5, 2, 6, 11, 14, 16], [5, 6, 4, 11, 16, 12]].map(unit);
const BUTTON_SEL = BUTTON16.map(unit);

const SEL_CACHE: (readonly Bounds[] | undefined)[] = new Array(16384);

export function selectionBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  const id = def.id;
  if (id > 0 && id < 1024 && BLOCKS[id] === def) {
    const key = (id << 4) | (state & 15);
    let cached = SEL_CACHE[key];
    if (cached === undefined) {
      cached = computeSelectionBoxes(def, state);
      SEL_CACHE[key] = cached;
    }
    return cached;
  }
  return computeSelectionBoxes(def, state);
}

function computeSelectionBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  if (def.name === 'piston_head' || def.shape === 'piston_head') return PISTON_HEAD[state & 7] ?? PISTON_HEAD[0];
  if (def.name === 'moving_piston' || def.shape === 'moving_piston') return NONE;
  if (def.name === 'lectern') return LECTERN;
  if (def.name === 'bell') return BELL;
  if (def.name === 'chain') return CHAIN;
  switch (def.shape) {
    case 'chest': return CHEST;
    case 'slab': return isSlabBlock(def) ? (state === 2 ? FULL : state === 1 ? TOP_SLAB : SLAB) : lowBoxes(def.name, state);
    case 'stairs': return STAIRS[state & 7];
    case 'door': return EDGE[doorEdge(state)];
    case 'trapdoor': return state & 8 ? EDGE[state & 3] : state & 4 ? TRAPDOOR_TOP : TRAPDOOR;
    case 'pane': return def.name === 'ladder' || def.name === 'item_frame' ? LADDER[state & 3] : state & 1 ? PANE_X : PANE;
    case 'fence': return FENCE;
    case 'torch': {
      if (def.name === 'lantern' || def.name === 'soul_lantern') return LANTERN;
      if (def.name === 'brewing_stand') return BREWING;
      const at = state & 7;
      if (def.name === 'lever') return LEVER_SEL[at] ?? LEVER_SEL[0];
      if (def.name.endsWith('_button')) return BUTTON_SEL[at] ?? BUTTON_SEL[0];
      return TORCH_SEL[at] ?? TORCH_SEL[0];
    }
    case 'cactus': return CACTUS;
    case 'bed': return BED;
    case 'end_portal_frame': return FRAME;
    case 'end_rod': return END_ROD;
    case 'shulker_box': return SHULKER;
    case 'dragon_egg': return EGG;
    case 'dragon_head': return HEAD;
    case 'end_portal': return END_PORTAL_BOX;
    case 'end_gateway': return FULL;
    case 'lantern': return def.name === 'bell' ? BELL : LANTERN;
    case 'enchanting_table': return LOW.table;
    case 'anvil': return (state & 1) ? ANVIL_X : ANVIL_Z;
    case 'brewing_stand': return BREWING;
    case 'cross': return PLANT;
    case 'lily': return LILY;
    case 'water': return NONE;
    default: return FULL;
  }
}

/** Boxes used for rendering generic box models; doors, fences, torches, levers and buttons have dedicated models in the mesher. */
export function modelBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  if (def.name === 'moving_piston' || def.shape === 'moving_piston') return NONE;
  if (def.name === 'tripwire') return !(state & 1) ? TRIPWIRE_FREE : state & 8 ? TRIPWIRE_Z : TRIPWIRE_X;
  return def.shape === 'torch' && def.name === 'brewing_stand' ? BREWING : selectionBoxes(def, state);
}

export function collisionBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  return def.solid ? selectionBoxes(def, state) : NONE;
}

export function intersectsBox(
  x: number, y: number, z: number,
  minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number,
  box: Bounds,
): boolean {
  return maxX > x + box[0] && minX < x + box[3] &&
    maxY > y + box[1] && minY < y + box[4] &&
    maxZ > z + box[2] && minZ < z + box[5];
}
