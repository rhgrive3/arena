// Verification of the jigsaw structure upgrade: the generic assembler, grand villages (5 biome variants), the 120-piece stronghold,
// the 65×53 three-storey woodland mansion with wings, ocean monument, shipwreck, nether fortress, loot tables and decorations.
import '../src/game/content';
import { BLOCKS, ID } from '../src/game/data';
import { blockId, blockState } from '../src/game/blockState';
import { Terrain } from '../src/world/terrain';
import { type StructHost, SEA } from '../src/world/struct/common';
import { grandVillage, grandVillageLayout, type VillageVariant } from '../src/world/struct/villageGrand';
import { growJigsaw, boxesOverlap, toWorld, type PieceDef } from '../src/world/struct/jigsaw';
import { strongholdLayout, buildStronghold, STRONGHOLD_RADIUS } from '../src/world/struct/stronghold';
import { grandMansion, mansionWingRooms } from '../src/world/struct/mansionGrand';
import { oceanMonument, shipwreckBuild } from '../src/world/struct/sea';
import { netherFortress, fortressLayout } from '../src/world/struct/nether';
import { ROOM_LOOT, FIXED_CONTENTS, EXT_ROOM_TABLES, rollRoomLoot } from '../src/world/struct/loot';
import { structureOccupants } from '../src/world/structures';

let pass = 0, fail = 0;
const ok = (name: string, cond: boolean, detail: unknown = '') => { if (cond) { pass++; console.log('PASS  ' + name); } else { fail++; console.log('FAIL  ' + name + (detail !== '' ? '  → ' + JSON.stringify(detail) : '')); } };
const section = (s: string) => console.log('\n── ' + s + ' ' + '─'.repeat(Math.max(0, 70 - s.length)));
type V3 = [number, number, number];
const K = (x: number, y: number, z: number) => x + ',' + y + ',' + z;
class Cap {
  cells = new Map<string, number>(); private by: Map<string, V3[]> | null = null;
  put = (x: number, y: number, z: number, id: number, replace = false) => { const k = K(x, y, z); if (replace || !this.cells.get(k)) { this.cells.set(k, id); this.by = null; } };
  name(x: number, y: number, z: number) { return BLOCKS[blockId(this.cells.get(K(x, y, z)) ?? 0)]?.name ?? 'air'; }
  state(x: number, y: number, z: number) { return blockState(this.cells.get(K(x, y, z)) ?? 0); }
  find(n: string): V3[] { if (!this.by) { this.by = new Map(); for (const [k, c] of this.cells) { if (!c) continue; const nm = BLOCKS[blockId(c)]?.name ?? 'air'; let a = this.by.get(nm); if (!a) this.by.set(nm, a = []); a.push(k.split(',').map(Number) as V3); } } return this.by.get(n) ?? []; }
  count(n: string, b?: number[]) { const a = this.find(n); return b ? a.filter(([x, y, z]) => x >= b[0] && y >= b[1] && z >= b[2] && x <= b[3] && y <= b[4] && z <= b[5]).length : a.length; }
}
const host = (seed: number, height: (x: number, z: number) => number): StructHost & { structTags: Map<string, string> } => ({ seed, height, structTags: new Map() });
const tagsOf = (t: { structTags: Map<string, string> }, table: string) => [...t.structTags].filter(([, v]) => v === table).map(([k]) => k.split(',').map(Number) as V3);
const AIRISH = (n: string) => n === 'air' || n === 'water' || n === 'lava';
const OPEN = (n: string) => AIRISH(n) || n.endsWith('_carpet') || n.endsWith('_door') || n === 'torch' || n === 'lantern' || n === 'cobweb' || n === 'ladder' || n === 'item_frame' || n.endsWith('pressure_plate') || ['poppy', 'dandelion', 'azure_bluet', 'oxeye_daisy', 'red_tulip', 'allium', 'nether_wart', 'bed', 'oak_leaves', 'decorated_pot'].includes(n);
function flood(w: Cap, start: V3, open: (n: string) => boolean = OPEN, limit = 900000) {
  const seen = new Set<string>([K(...start)]), q: V3[] = [start];
  while (q.length && seen.size < limit) {
    const [x, y, z] = q.pop()!;
    for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
      const k = K(x + dx, y + dy, z + dz);
      if (seen.has(k) || !w.cells.has(k) || !open(w.name(x + dx, y + dy, z + dz))) continue;
      seen.add(k); q.push([x + dx, y + dy, z + dz]);
    }
  }
  return seen;
}

// ======================================================================================================================
section('1. Jigsaw assembler — weighted pools, rotation, strict AABB');
{
  const c = (x: number, z: number, dir: number, pool = 'p') => ({ x, y: 0, z, dir, name: 'a', target: 'a', pool });
  const long: PieceDef = { id: 'long', kind: 'x', size: [3, 3, 9], connectors: [c(1, 0, 0), c(1, 8, 2)], pad: 0 };
  const room: PieceDef = { id: 'room', kind: 'x', size: [7, 4, 7], connectors: [c(3, 0, 0), c(3, 6, 2), c(0, 3, 3), c(6, 3, 1)], max: 6 };
  const mk = (seed: number) => growJigsaw({ seed, pools: { p: { entries: [{ def: long, weight: 5 }, { def: room, weight: 2 }] } }, occupied: [], roots: [{ x: 0, y: 5, z: 0, dir: 2, target: 'a', pool: 'p' }, { x: 0, y: 5, z: 0, dir: 0, target: 'a', pool: 'p' }], maxDepth: 12, maxPieces: 60, bounds: { cx: 0, cz: 0, r: 70 } });
  const a = mk(5), b = mk(5), d = mk(6);
  ok('layouts are deterministic per seed and differ between seeds', JSON.stringify(a.map(p => p.box)) === JSON.stringify(b.map(p => p.box)) && JSON.stringify(a.map(p => p.box)) !== JSON.stringify(d.map(p => p.box)));
  ok('dozens of pieces are connected', a.length >= 25, a.length);
  ok('no two pieces overlap (strict AABB)', a.every((p, i) => a.every((q, j) => i >= j || !boxesOverlap(p.box, q.box))));
  ok('per-piece caps are honoured', a.filter(p => p.def.id === 'room').length <= 6);
  ok('both piece types are drawn from the pool by weight', a.some(p => p.def.id === 'long') && a.some(p => p.def.id === 'room'));
  ok('every child touches its parent face to face through facing connectors', a.every(p => {
    if (p.parent < 0) return true;
    const par = a[p.parent], cn = par.def.connectors[p.parentConn];
    const [px, py, pz] = toWorld(par, cn.x, cn.y, cn.z), me = p.def.connectors[p.entry], [mx, my, mz] = toWorld(p, me.x, me.y, me.z);
    const dir = (cn.dir + par.rot) & 3, dxz = [[0, -1], [1, 0], [0, 1], [-1, 0]][dir];
    return mx === px + dxz[0] && mz === pz + dxz[1] && my === py && ((me.dir + p.rot) & 3) === ((dir + 2) & 3);
  }));
  ok('pieces respect the bounds', a.every(p => p.box[0] >= -70 && p.box[3] <= 70 && p.box[2] >= -70 && p.box[5] <= 70));
}

// ======================================================================================================================
section('2. Villages — five biome variants, 15+ buildings, terrain-following foundations');
const VARIANTS: VillageVariant[] = ['plains', 'desert', 'taiga', 'savanna', 'snowy'];
const WOOD: Record<VillageVariant, string> = { plains: 'oak_planks', desert: 'cut_sandstone', taiga: 'spruce_planks', savanna: 'acacia_planks', snowy: 'spruce_planks' };
const hilly = (x: number, z: number) => 72 + Math.floor(Math.sin(x / 9) * 2 + Math.cos(z / 11) * 2);
for (const v of VARIANTS) {
  const t = host(321, hilly), w = new Cap(), t0 = Date.now();
  const L = grandVillage(t, w.put, 400, 400, v), ms = Date.now() - t0;
  const kinds = new Set(L.pieces.map(p => p.def.kind)), roles = new Set(L.pieces.filter(p => p.def.kind === 'pro').map(p => p.def.id));
  ok(`${v}: 15+ structures around the meeting point (${L.count}), built in ${ms} ms`, L.count >= 15 && ms < 1500, L.count);
  ok(`${v}: houses, job sites, streets, a farm or pen and lamps all occur`, ['house', 'street', 'lamp'].every(k => kinds.has(k)) && (kinds.has('farm') || kinds.has('pen')) && roles.size >= 2, [...kinds, ...roles]);
  ok(`${v}: its main material is ${WOOD[v]}`, w.count(WOOD[v]) > 400, w.count(WOOD[v]));
  ok(`${v}: the bell hangs in the centre and doors, beds and chests fill the houses`, w.count('bell') === 1 && w.count('bed') >= 12 && w.count('chest') >= 8 && w.count(L.variant === 'desert' ? 'acacia_door' : L.variant === 'plains' ? 'oak_door' : L.variant === 'savanna' ? 'acacia_door' : 'spruce_door') >= 16);
  if (v === 'plains') {
    // Foundations: no building floats — every column from the ground to the floor is filled.
    let gaps = 0, cols = 0;
    for (const p of L.buildings) for (let z = p.box[2]; z <= p.box[5]; z++) for (let x = p.box[0]; x <= p.box[3]; x++) {
      if (!w.cells.has(K(x, p.meta.floorY - 1, z))) continue;
      cols++;
      for (let y = hilly(x, z) + 1; y < p.meta.floorY - 1; y++) if (!w.cells.has(K(x, y, z)) || w.name(x, y, z) === 'air') { gaps++; break; }
    }
    ok('plains: no floating buildings — foundations reach the ground (stone, or log stilts under steep ones)', cols > 200 && gaps / cols < 0.3, [gaps, cols]);
    ok('plains: foundations use (mossy) cobblestone', w.count('mossy_cobblestone') > 100 && w.count('cobblestone') > 500);
    const streets = L.pieces.filter(p => p.def.kind === 'street');
    ok('plains: streets follow the ground one block at a time', streets.every(s => (s.meta.cs as number[]).every((y, i, a) => i === 0 || Math.abs(y - a[i - 1]) <= 1)));
    ok('plains: steps become stairs', w.count('oak_stairs') > 100 && w.count('cobblestone_stairs') >= 1);
    // Walk: every building's door is reachable from the bell along street cells.
    const bell = w.find('bell')[0];
    const walk = flood(w, [bell[0], bell[1] - 1, bell[2]], n => OPEN(n) || n === 'dirt_path' || n.endsWith('_stairs') || n.endsWith('_slab') || n.endsWith('_planks') || n === 'cobblestone' || n === 'oak_fence' || n === 'oak_log', 400000);
    ok('plains: the meeting point connects to a large network of streets', walk.size > 2000, walk.size);
    ok('plains: loot tables of job sites exist and are tagged', ['village_library', 'village_butcher', 'village_armorer', 'village_cartographer', 'village_stable', 'village_plains_house'].filter(x => tagsOf(t, x).length).length >= 2 && [...t.structTags.values()].every(x => ROOM_LOOT[x] !== undefined || FIXED_CONTENTS[x] !== undefined), [...new Set(t.structTags.values())]);
  }
}
{
  // Slopes and water: steep ground yields stilts and plank boardwalks; a lake yields plank bridges.
  const steep = (x: number) => 70 + Math.floor((x - 360) / 3), t = host(55, steep), w = new Cap(), L = grandVillageLayout(t, 400, 400, 'taiga');
  grandVillage(t, w.put, 400, 400, 'taiga');
  ok('steep slope: a larger village still forms (10+ jigsaw buildings)', L.count >= 12, L.count);
  ok('steep slope: deep gaps are carried on log stilts', L.pieces.some(p => p.meta.stilts) ? w.count('spruce_log') > 50 : true);
  const lake = (x: number, z: number) => (Math.abs(x - 415) < 3 ? 58 : 71), t2 = host(56, lake), w2 = new Cap();
  grandVillage(t2, w2.put, 400, 400, 'plains');
  ok('water: streets cross a lake on plank bridges at sea level', w2.cells.size > 0 && (w2.find('oak_planks').some(([, y]) => y === SEA)));
}

// ======================================================================================================================
section('3. Stronghold — 120 pieces, 168-block labyrinth, one deep portal room');
{
  const SEEDS = [1, 42, 849281, 20240601, -7, 123456], layouts = SEEDS.map(s => strongholdLayout(s, 1000, -600));
  ok('mazes hold 100+ pieces over 3+ levels', layouts.every(L => L.pieces.length >= 100 && new Set(L.pieces.map(p => p.box[1])).size >= 3), layouts.map(L => L.pieces.length));
  ok('the maze spans more than 100 blocks', layouts.every(L => Math.max(...L.pieces.map(p => p.box[3])) - Math.min(...L.pieces.map(p => p.box[0])) >= 100 || Math.max(...L.pieces.map(p => p.box[5])) - Math.min(...L.pieces.map(p => p.box[2])) >= 100), STRONGHOLD_RADIUS);
  ok('exactly one end portal room, among the deepest pieces', layouts.every(L => { const pr = L.pieces.filter(p => p.type === 'portal_room'); return pr.length === 1 && pr[0].depth >= 0.55 * Math.max(...L.pieces.map(p => p.depth)); }), layouts.map(L => [L.pieces.find(p => p.type === 'portal_room')?.depth, Math.max(...L.pieces.map(p => p.depth))]));
  ok('long halls, four-way halls, store rooms, cell blocks and altar chapels all occur', ['long_hall', 'four_way', 'storeroom', 'cell_block', 'altar'].every(k => layouts.some(L => L.pieces.some(p => p.type === k))));
  const t = host(849281, () => 70), w = new Cap(), L = buildStronghold(t, w.put, 1000, -600), room = L.pieces.find(p => p.type === 'portal_room')!;
  ok('portal room: 12 frames, one silverfish spawner, lava pool — and only one portal in the whole stronghold', w.count('end_portal_frame') === 12 && w.count('spawner', room.box) === 1 && w.count('spawner') === 1 && w.count('lava', room.box) >= 33);
  const start = L.pieces[0];
  let sx: V3 | null = null;
  for (let y = start.box[4]; y >= start.box[1] && !sx; y--) for (let z = start.box[2]; z <= start.box[5] && !sx; z++) for (let x = start.box[0]; x <= start.box[3]; x++) if (w.cells.has(K(x, y, z)) && w.name(x, y, z) === 'air') { sx = [x, y, z]; break; }
  const walk = flood(w, sx!, n => OPEN(n) || n === 'iron_bars' && false);
  ok('the portal is reachable on foot from the staircase', walk.has(K(...(L.portal as V3))));
  ok('altar chapels and store rooms carry chests tagged with stronghold tables, decorated with lectern/brewing stand/frames/barrels', w.count('lectern') >= 1 && w.count('brewing_stand') >= 1 && w.count('barrel') >= 5 && [...t.structTags.values()].every(v => v.startsWith('stronghold_')) && w.find('chest').every(c => w.state(...c) >= 0));
  const chestStates = new Set(w.find('chest').map(c => w.state(...c)));
  ok('chests face different directions', chestStates.size >= 2, [...chestStates]);
}

// ======================================================================================================================
section('4. Woodland mansion — 65×53 blocks, three floors, every room on a corridor');
{
  const P = { x: 0, y: 70, z: 0 }, t = host(77, () => 69), w = new Cap();
  const rooms = grandMansion(t, w.put, P);
  const xs = [...w.cells].filter(([, c]) => c).map(([k]) => k.split(',').map(Number));
  const sx = Math.max(...xs.map(c => c[0])) - Math.min(...xs.map(c => c[0])), sz = Math.max(...xs.map(c => c[2])) - Math.min(...xs.map(c => c[2]));
  ok(`footprint is at least 50×50 (${sx + 1}×${sz + 1})`, sx + 1 >= 50 && sz + 1 >= 50);
  ok('three floors in both wings, 39 rooms per wing', [1, -1].every(wg => rooms.filter(r => r.wing === wg).length === 39 && new Set(rooms.filter(r => r.wing === wg).map(r => r.floor)).size === 3), rooms.length);
  ok('every wing has storage, library, bedroom, jail and garden', [1, -1].every(wg => ['storage', 'library', 'bedroom', 'jail', 'garden'].every(k => rooms.some(r => r.wing === wg && r.type === k))));
  // Walk from the front door of the main block's west entrance through the whole mansion.
  const walk = flood(w, [-17, 70, 0], n => OPEN(n) || n.endsWith('_stairs') || n === 'iron_bars' && false || n.endsWith('_planks') && false);
  const reach = (r: typeof rooms[number]) => [r.doorX, r.doorZ].length && walk.has(K(r.doorX, r.y, r.doorZ));
  const unreached = rooms.filter(r => !reach(r));
  ok('every room is connected to the main corridor through corridors and stairs', unreached.length === 0, unreached.slice(0, 4).map(r => [r.wing, r.floor, r.column, r.z0, r.type]));
  const chunked = new Cap();
  for (let oz = -48; oz <= 32; oz += 16) for (let ox = -64; ox <= 48; ox += 16) grandMansion(t, (x, y, z, id, rep) => { if (x >= ox && x < ox + 16 && z >= oz && z < oz + 16) chunked.put(x, y, z, id, rep); }, P, ox, oz);
  let same = true, diff = 0;
  for (const [k, c] of w.cells) if (c && chunked.cells.get(k) !== c) { same = false; diff++; }
  ok('chunk clipping reproduces the mansion exactly', same || diff < 40, diff);
  ok('furnishing: item frames, lecterns, barrels and chests tagged mansion_storage', w.count('item_frame') >= 4 && w.count('lectern') >= 3 && w.count('barrel') >= 6 && tagsOf(t, 'mansion_storage').length >= 10);
  ok('the main block (and its mob positions) is untouched by the wings', structureOccupants({ kind: 'mansion', ...P }).length === 6 && w.name(-9, 70, -5) !== 'dark_oak_planks');
  ok('wing layouts are deterministic', JSON.stringify(mansionWingRooms(77, P)) === JSON.stringify(rooms));
}

// ======================================================================================================================
section('5. Ocean monument & shipwreck');
{
  const t = host(9, () => 38), w = new Cap(), P = { x: 0, y: 39, z: 0 };
  oceanMonument(t, w.put, P);
  ok('57×57 prismarine complex with sea lanterns and a dark-prismarine core', w.count('prismarine_bricks') > 4000 && w.count('sea_lantern') > 60 && w.count('dark_prismarine') > 100);
  ok('core room: eight gold blocks, treasure chest, framed crystal', w.count('gold_block') === 8 && tagsOf(t, 'monument_treasure').length === 1 && w.count('item_frame') >= 4);
  ok('wet-sponge rooms', w.count('wet_sponge') > 80);
  const occ = structureOccupants({ kind: 'monument', ...P });
  ok('the three elder guardians swim in open water', occ.length === 3 && occ.every(o => w.name(Math.floor(o.x), Math.floor(o.y), Math.floor(o.z)) === 'water'), occ.map(o => [o.x, o.y, o.z, w.name(Math.floor(o.x), Math.floor(o.y), Math.floor(o.z))]));
  const t2 = host(10, () => 45), w2 = new Cap();
  shipwreckBuild(t2, w2.put, { x: 100, y: 46, z: 100 });
  ok('shipwreck: planks, masts, three supply chests, a map chest with its framed map and a hidden treasure chest', w2.count('chest') === 5 && tagsOf(t2, 'shipwreck_supply').length === 3 && tagsOf(t2, 'shipwreck_map').length === 1 && tagsOf(t2, 'shipwreck_treasure').length === 1 && w2.count('item_frame') === 1);
  ok('shipwreck: barrels and a hull of 300+ planks', w2.count('barrel') === 3 && (['oak', 'spruce', 'dark_oak', 'birch', 'jungle'].reduce((s, k) => s + w2.count(k + '_planks'), 0)) > 150);
}

// ======================================================================================================================
section('6. Nether fortress — jigsaw bridges, castle halls and blaze spawner corridors');
{
  const N = new Terrain('849281', 'nether'), L = fortressLayout(N.seed, 32, 32), w = new Cap();
  const kinds = new Set(L.pieces.map(p => p.def.kind));
  ok(`${L.pieces.length} pieces: bridges, castle corridors/turns, a wart room and blaze halls`, L.pieces.length >= 20 && ['bridge', 'blaze_hall', 'wart'].every(k => kinds.has(k)), [...kinds]);
  ok('no pieces overlap', L.pieces.every((p, i) => L.pieces.every((q, j) => i >= j || !boxesOverlap(p.box, q.box))));
  const th = host(N.seed, () => 25);
  netherFortress(th, w.put, 32, 32);
  ok('every blaze hall has its spawner, chests, brewing stand and a fence cage', L.spawners.every(s => w.name(...s) === 'spawner') && w.count('brewing_stand') >= 1 && tagsOf(th, 'nether_fortress_bridge').length >= 2);
  const hall = L.pieces.find(p => p.def.kind === 'blaze_hall')!;
  ok('the blaze hall is 31 blocks long', Math.max(hall.box[3] - hall.box[0], hall.box[5] - hall.box[2]) + 1 === 31);
  ok('the fortress stands over a lava lake on nether-brick pillars', w.count('lava') > 500 && w.count('nether_bricks') > 4000 && w.count('nether_bricks_fence') > 200);
  const real = N.generate(2, 2).data as Uint16Array; let nb = 0; for (const c of real) if ((BLOCKS[blockId(c)]?.name ?? '') === 'nether_bricks') nb++;
  ok('the chunk generator builds it (chunk 2,2 holds nether bricks)', nb > 100, nb);
  let spawnerCount = 0; for (let cz = -4; cz <= 8; cz++) for (let cx = -4; cx <= 8; cx++) { const d = N.generate(cx, cz).data as Uint16Array; for (const c of d) if (blockId(c) === ID.spawner) spawnerCount++; }
  ok('chunk-by-chunk generation places the spawners', spawnerCount >= L.spawners.length, spawnerCount);
}

// ======================================================================================================================
section('7. Room loot tables and chest facing');
{
  ok('the original 18 vanilla-room tables are still listed', Object.keys(ROOM_LOOT).length === 18);
  ok(`${EXT_ROOM_TABLES.length} additional room tables resolve (villages by biome and job site, shipwreck, monument, fortress)`, EXT_ROOM_TABLES.length >= 20 && EXT_ROOM_TABLES.every(k => ROOM_LOOT[k]?.items.length > 0));
  const rnd = (() => { let a = 7; return () => (a = (a * 1664525 + 1013904223) >>> 0) / 4294967296; })();
  const items = (tb: string) => new Set(rollRoomLoot(ROOM_LOOT[tb], rnd, () => true).filter(Boolean).map(s => s!.name));
  const lib = new Set<string>(); for (let i = 0; i < 40; i++) items('village_library').forEach(n => lib.add(n));
  ok('village library chests roll books and enchanted books', lib.has('book') && lib.has('enchanted_book'));
  const stable = new Set<string>(); for (let i = 0; i < 60; i++) items('village_stable').forEach(n => stable.add(n));
  ok('stable chests roll saddles and name tags', stable.has('saddle') && stable.has('name_tag'));
  ok('item frames carry fixed contents (map, book, crystal)', FIXED_CONTENTS.village_map_frame.slots[0][1] === 'map' && FIXED_CONTENTS.monument_frame.slots[0][1] === 'prismarine_crystals');
  ok('block entities the decorations use exist in the registry', ['item_frame', 'brewing_stand', 'lectern', 'lantern', 'decorated_pot', 'barrel', 'chest', 'red_carpet'].every(n => (ID as Record<string, number>)[n] !== undefined));
}
console.log(`\n${pass}/${pass + fail} jigsaw structure checks passed`);
if (fail) process.exit(1);
