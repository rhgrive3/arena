// Product name and version shown in the UI (title screen, footer, debug overlay).
export const BRAND = {
  name: 'BLOCKWORLD',
  version: '26.3',
};
