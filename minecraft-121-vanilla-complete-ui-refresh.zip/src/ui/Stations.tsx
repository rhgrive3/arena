import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Flame, ArrowRight, Package, Check, Shield, Plus } from 'lucide-react';
import type { Engine } from '../game/engine';
import type { GameSnapshot, Stack } from '../game/types';
import { resolve } from '../game/data';
import { SMELTING, FUEL } from '../systems/crafting';
import { EFFECTS, roman, enchLabel, brewResult } from '../systems/magic';
import * as SV from '../game/survival';
import { Button, ItemIcon, Panel, Slot } from './common';
import { LEVEL_XP } from '../entities/villagers';
import { findCrafterRecipe } from '../systems/automation';
import * as V from '../game/vanilla';
import { BANNER_PATTERNS, bannerColorOf, bannerDataUrl, patternDef, describeLayers, MAX_BANNER_LAYERS } from '../systems/banners';
import { mapRGBA, mapMarker, MAP_SIZE } from '../systems/maps';
import { isTrimTemplate, isTrimMaterial, isTrimmableArmor } from '../systems/trims';
import { BEACON_PRIMARY_POWERS, beaconRange, beaconDuration, isBeaconPayment } from '../systems/beacon';
import { SIGN_MAX_LINE_CHARS, setSignLine, signSideDataUrl, newSignData } from '../systems/signs';

export const STATION_KINDS = ['furnace', 'container', 'trade', 'enchanting', 'anvil', 'grindstone', 'smithing', 'stonecutter', 'brewing', 'loom', 'cartography', 'lectern', 'crafter', 'beacon', 'sign'] as const;
export type StationKind = (typeof STATION_KINDS)[number];
export const isStation = (s: string): s is StationKind => (STATION_KINDS as readonly string[]).includes(s);

const TITLES: Record<StationKind, [string, string, string]> = {
  furnace: ['かまど', 'Furnace', 'SMELTING · FUEL · OUTPUT'],
  container: ['チェスト', 'Chest', 'A PLACE FOR EVERYTHING'],
  trade: ['村人との取引', 'Villager trades', 'TRADE. GROW. DISCOVER.'],
  crafter: ['自動作業台', 'Crafter', 'A LITTLE REDSTONE. A LOT OF POSSIBILITIES.'],
  enchanting: ['エンチャントテーブル', 'Enchanting table', 'LAPIS · LEVELS · BOOKSHELVES'],
  anvil: ['金床', 'Anvil', 'REPAIR · COMBINE · RENAME'],
  grindstone: ['砥石', 'Grindstone', 'DISENCHANT · REPAIR'],
  smithing: ['鍛冶台', 'Smithing table', 'TEMPLATE · GEAR · MATERIAL'],
  stonecutter: ['石切台', 'Stonecutter', 'ONE BLOCK, MANY SHAPES'],
  brewing: ['醸造台', 'Brewing stand', 'BOTTLES · INGREDIENT · BLAZE POWDER'],
  loom: ['織機', 'Loom', 'BANNER · DYE · PATTERN'],
  cartography: ['製図台', 'Cartography table', 'MAP · PAPER · GLASS'],
  lectern: ['書見台', 'Lectern', 'READ · WRITE · SIGN'],
  beacon: ['ビーコン', 'Beacon', 'PYRAMID · PRIMARY POWER · OFFERING'],
  sign: ['看板の編集', 'Edit Sign', '4 LINES · FRONT & BACK · DYE & GLOW'],
};
/** How many inventory items each selection-style station works on. */
const NEED: Partial<Record<StationKind, number>> = { enchanting: 1, anvil: 2, grindstone: 2, smithing: 3, stonecutter: 1, loom: 3, cartography: 2, beacon: 1 };

/** Explorer map: draws the real painted map data (unexplored pixels stay parchment) plus the player's arrow. */
export function MapView({ engine, id, version = 0, px = 256 }: { engine: Engine; id: number; version?: number; px?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current, m = engine.maps.get(id);
    if (!c || !m) return;
    c.width = MAP_SIZE; c.height = MAP_SIZE;
    const ctx = c.getContext('2d')!;
    ctx.fillStyle = '#cdb98f'; ctx.fillRect(0, 0, MAP_SIZE, MAP_SIZE);
    const img = ctx.createImageData(MAP_SIZE, MAP_SIZE);
    mapRGBA(m, img.data);
    const tmp = document.createElement('canvas'); tmp.width = tmp.height = MAP_SIZE;
    tmp.getContext('2d')!.putImageData(img, 0, 0);
    ctx.drawImage(tmp, 0, 0);
    const mk = m.dim === engine.dimension ? mapMarker(m, engine.position.x, engine.position.z) : null;
    if (mk) {
      ctx.save(); ctx.translate(mk[0], mk[1]); ctx.rotate(-engine.input.yaw);
      ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#111'; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(0, -4.5); ctx.lineTo(3.2, 3.5); ctx.lineTo(0, 1.8); ctx.lineTo(-3.2, 3.5); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.restore();
    }
  }, [engine, id, version]);
  return <canvas ref={ref} className="map-canvas" style={{ width: px, height: px }} aria-label="map" />;
}

export function Stations({ engine, snapshot, kind, onClose }: { engine: Engine; snapshot: GameSnapshot; kind: StationKind; onClose: () => void }) {
  const ja = engine.settings.language === 'ja', t = (j: string, e: string) => (ja ? j : e);
  const [, force] = useState(0), refresh = () => force(x => x + 1);
  const [sel, setSel] = useState<number[]>(() => Array(NEED[kind] ?? 0).fill(-1));
  const [name, setName] = useState('');
  const [pattern, setPattern] = useState('stripe_bottom');
  const [pg, setPg] = useState(0);
  const [signing, setSigning] = useState(false);
  const [title, setTitle] = useState('');
  const [bulk, setBulk] = useState(false);
  const [crafterPick, setCrafterPick] = useState(-1);
  const [beaconPrimary, setBeaconPrimary] = useState<string>(() => engine.beacons.get(`${engine.dimension}:${engine.stationKey}`)?.primary ?? 'speed');
  const [beaconSecondary, setBeaconSecondary] = useState<string>(() => engine.beacons.get(`${engine.dimension}:${engine.stationKey}`)?.secondary ?? 'regeneration');
  const [signSide, setSignSide] = useState<'front' | 'back'>(() => engine.signSide ?? 'front');
  const creative = engine.meta.mode === 'creative', lv = SV.level(engine);
  if ((kind === 'furnace' || kind === 'container' || kind === 'crafter') && !engine.containers[engine.stationKey]) {
    engine.containers[engine.stationKey] = kind === 'furnace' ? [null, null, null] : kind === 'crafter' ? Array(9).fill(null) : Array(27).fill(null);
  }
  const slots: (Stack | null)[] = kind === 'container' ? SV.getContainerSlots(engine) : (engine.containers[engine.stationKey] ?? []);
  const A = (k: number): Stack | null => (sel[k] >= 0 ? SV.slotAt(engine, sel[k]) : null);
  const clear = (k: number) => setSel(s => s.map((v, i) => (i === k ? -1 : v)));
  const done = (ok: boolean, reset = false) => { if (ok) { if (reset) setSel(s => s.map(() => -1)); refresh(); } };
  const name1 = (n: string) => (ja ? resolve(n)?.ja : n.replace(/_/g, ' ')) ?? n;

  const furnacePut = (i: number) => {
    const s = SV.slotAt(engine, i);
    if (!s) return;
    const dest = SMELTING[s.name] ? 0 : FUEL[s.name] ? 1 : -1;
    if (dest < 0 || (slots[dest] && slots[dest]!.name !== s.name)) return;
    const n = Math.min(64 - (slots[dest]?.count ?? 0), s.count);
    if (n <= 0) return;
    if (slots[dest]) slots[dest]!.count += n; else slots[dest] = { name: s.name, count: n };
    engine.removeItem(s.name, n);
  };
  const click = (i: number) => {
    const s = SV.slotAt(engine, i);
    if (!s) return;
    if (kind === 'furnace') furnacePut(i);
    else if (kind === 'crafter') setCrafterPick(i);
    else if (kind === 'container') SV.containerPut(engine, i, slots);
    else if (kind === 'brewing') SV.brewPut(engine, i);
    else if (kind === 'lectern') {
      if (engine.stationKey !== 'hand' && slots.length === 1 && !slots[0] && ['writable_book', 'written_book', 'book', 'enchanted_book'].includes(s.name)) { slots[0] = { ...s, count: 1 }; SV.takeFrom(engine, i, 1); }
    } else if (NEED[kind]) {
      const next = [...sel], at = next.indexOf(i);
      if (at >= 0) next[at] = -1;
      else {
        let pos = next.indexOf(-1);
        if (kind === 'smithing') pos = (s.name === 'netherite_upgrade' || isTrimTemplate(s.name)) ? 0 : (isTrimmableArmor(s.name) || s.name.startsWith('diamond_')) ? 1 : (s.name === 'netherite_ingot' || isTrimMaterial(s.name)) ? 2 : -1;
        if (kind === 'loom') pos = s.name.endsWith('_banner') ? 0 : s.name.endsWith('_dye') ? 1 : s.name.endsWith('_banner_pattern') ? 2 : -1;
        if (kind === 'cartography') pos = s.name === 'filled_map' && next[0] < 0 ? 0 : 1;
        if (kind === 'beacon') pos = isBeaconPayment(s.name) ? 0 : -1;
        if (pos < 0) return;
        next[pos] = i;
        if (kind === 'anvil' && pos === 0) setName(s.label ?? '');
      }
      setSel(next);
      return;
    }
    refresh();
  };
  const input = (k: number, label: string) => <div className="st-input"><Slot stack={A(k)} onClick={() => clear(k)} label={label} /><small>{label}</small></div>;
  const result = (stack: Stack | null, extra?: ReactNode) => <div className="st-result"><ArrowRight size={26} /><Slot stack={stack} />{extra}</div>;

  let body: ReactNode = null, hint = '';
  if (kind === 'furnace') {
    hint = t('石炭・木材・棒を燃料に使えます', 'Coal, planks and sticks work as fuel');
    body = <div className="furnace-machine"><div className="furnace-input"><span>{t('材料', 'Input')}</span><Slot stack={slots[0]} onClick={() => done(SV.containerTake(engine, slots, 0))} /><Flame size={22} className={engine.furnaces[engine.stationKey]?.burn > 0 ? 'burning' : ''} /><Slot stack={slots[1]} onClick={() => done(SV.containerTake(engine, slots, 1))} /><span>{t('燃料', 'Fuel')}</span></div><div className="smelt-arrow"><ArrowRight size={38} /><div className="smelt-progress"><i style={{ width: `${(engine.furnaces[engine.stationKey]?.progress ?? 0) * 100}%` }} /></div></div><div className="furnace-output"><span>{t('完成', 'Output')}</span><Slot stack={slots[2]} onClick={() => done(SV.containerTake(engine, slots, 2))} /></div></div>;
  } else if (kind === 'container') {
    hint = t('アイテムはワールドと一緒に保存されます（エンチャントも保持）', 'Contents are saved with your world (enchantments included)');
    body = <div className="chest-grid">{slots.map((s, i) => <Slot key={i} stack={s} onClick={() => done(SV.containerTake(engine, slots, i))} />)}</div>;
  } else if (kind === 'trade') {
    const title = engine.mobs.tradeTitle(), hero = engine.mobs.heroTimer > 0;
    const activeMob = engine.mobs.activeVillager ?? engine.mobs.tradingMob;
    const villager = activeMob?.villager;
    const xpVal = villager?.xp ?? activeMob?.xp ?? 0;
    const lvlVal = villager?.level ?? activeMob?.level ?? 1;
    const next = LEVEL_XP[lvlVal] ?? 250;
    hint = t(`${title.ja}${hero ? ' · 村の英雄割引中' : ''} — 取引すると村人が経験を積み、職業ブロックの近くで日中に在庫を補充します`, `${title.en}${hero ? ' · Hero of the Village discount' : ''} — trading levels the villager up and stock replenishes near a job block`);
    const trades = engine.mobs.tradeOffers();
    body = <div className="trade-list">
      <div className="trade-profile"><strong>{ja ? title.ja : title.en}</strong><small>{xpVal} / {next} XP</small><span className="trade-progress"><i style={{ width: `${Math.min(100, (xpVal / next) * 100)}%` }} /></span></div>
      {trades.length === 0 && <p className="muted">{t('この村人はまだ職業がありません。近くにコンポスター・書見台・溶鉱炉などの職業ブロックを置いてください。', 'This villager has no profession yet. Place a job-site block (composter, lectern, blast furnace…) nearby.')}</p>}
      {trades.map((tr, i) => {
        const used = villager?.uses?.[tr.id] ?? 0;
        const soldOut = used >= tr.maxUses;
        return <div key={tr.id ?? i} title={`${name1(tr.give)} > ${name1(tr.get)}`}><ItemIcon name={tr.give} /><span>{tr.n}</span><ArrowRight size={19} /><ItemIcon name={tr.get} /><span>{tr.count}</span><Button disabled={soldOut || !!tr.pending || engine.countItem(tr.give) < tr.n} onClick={() => { if (engine.tradeOffer(tr)) { engine.mobs.recordTrade(tr); engine.audio?.play('click'); refresh(); } }}>{tr.pending ? t('探索中…', 'Searching…') : soldOut ? t('在庫切れ', 'Sold out') : t('取引', 'Trade')}</Button></div>;
      })}
    </div>;
  } else if (kind === 'crafter') {
    hint = t('持ちものを選んで、マスをクリックすると1個ずつ配置。空きマスの小さなボタンでホッパー搬入の有効・無効を切り替えます。', 'Select an inventory item, then click a grid slot to place one. Toggle empty slots to control hopper input.');
    const mask = engine.crafterMask(engine.stationKey), match = findCrafterRecipe(slots, mask), selected = crafterPick >= 0 ? SV.slotAt(engine, crafterPick) : null;
    body = <div className="st-row"><div className="crafter-grid">{Array.from({ length: 9 }, (_, i) => <div key={i} className={`crafter-slot ${mask & (1 << i) ? 'disabled' : ''}`}><Slot stack={slots[i] ?? null} label={t(`材料 ${i + 1}`, `Ingredient ${i + 1}`)} onClick={() => {
      if (mask & (1 << i)) return;
      if (selected && (!slots[i] || slots[i]!.name === selected.name && slots[i]!.count < (resolve(selected.name)?.stack ?? 64))) {
        if (slots[i]) slots[i]!.count++; else slots[i] = { ...selected, count: 1 };
        SV.takeFrom(engine, crafterPick, 1);
        if (!SV.slotAt(engine, crafterPick)) setCrafterPick(-1);
      } else if (!selected) SV.containerTake(engine, slots, i);
      refresh();
    }} />{!slots[i] && <button aria-label={t(`マス ${i + 1} を切り替え`, `Toggle slot ${i + 1}`)} onClick={() => { engine.toggleCrafterSlot(i); refresh(); }}>{mask & (1 << i) ? '+' : 'x'}</button>}</div>)}</div><div className="st-result"><ArrowRight size={24} /><Slot stack={match ? { name: match.result, count: match.count } : null} label={t('完成品のプレビュー', 'Recipe preview')} /></div><div className="crafter-note"><strong>{t('信号を受け取ると、自動クラフト。', 'One pulse. One recipe.')}</strong><p>{t('レバーやボタンで信号を送ってください。完成品は正面のチェストへ入り、チェストがなければ排出されます。', 'Send a pulse with a lever or button. The result goes into the container in front, or drops into the world.')}</p>{selected && <Button onClick={() => setCrafterPick(-1)}>{t('選択を解除', 'Clear selection')}: {name1(selected.name)}</Button>}</div></div>;
  } else if (kind === 'enchanting') {
    const item = A(0), offers = sel[0] >= 0 ? SV.enchantOffers(engine, sel[0]) : [], shelves = SV.bookshelves(engine), lapis = engine.countItem('lapis_lazuli');
    hint = t('本棚を台の2マス外側に最大15個置くとレベル30まで解放。金床でエンチャントの本を合成できます。', 'Up to 15 bookshelves two blocks away unlock level 30. Combine enchanted books on an anvil.');
    body = <div className="st-row">
      <div className="st-inputs">{input(0, t('アイテム', 'Item'))}<div className="st-note">📚 {shelves}/15</div><div className="st-note"><ItemIcon name="lapis_lazuli" size={18} /> {creative ? '∞' : lapis} · Lv {lv}</div></div>
      <div className="st-options">
        {offers.length === 0 && <p className="muted">{!item ? t('下の持ちものから、エンチャントするアイテム（道具・武器・防具・本）を選んでください。', 'Pick a tool, weapon, armor piece or book from your inventory below.') : item.ench ? t('すでにエンチャントされています。金床で本と合成するか、砥石で外せます。', 'Already enchanted — combine with books on an anvil or strip it on a grindstone.') : t('このアイテムにはエンチャントできません。', 'This item cannot be enchanted.')}</p>}
        {offers.map((o, i) => {
          const ok = creative || (lv >= o.level && lapis >= o.cost);
          return <button key={i} className="st-option" disabled={!ok} onClick={() => done(SV.doEnchant(engine, sel[0], i))}>
            <b>{o.cost}</b>
            <span>{enchLabel(o.list[0][0], o.list[0][1], ja)}{o.list.length > 1 ? ' . . . ?' : ''}</span>
            <small>{t('必要レベル', 'Requires level')} {o.level} · {t('消費', 'Costs')} {o.cost} Lv + {t('ラピス', 'lapis')} ×{o.cost}</small>
          </button>;
        })}
      </div>
    </div>;
  } else if (kind === 'anvil') {
    const r = SV.anvilPreview(engine, sel[0], sel[1], name), afford = creative || (!!r && lv >= r.cost && r.cost <= 39);
    hint = t('左: 対象 / 右: 同じアイテム・修理素材・エンチャントの本。名前だけの変更もできます。', 'Left: target · right: same item, repair material or enchanted book. Renaming alone works too.');
    body = <div className="st-row">
      <div className="st-inputs"><div className="st-slots">{input(0, t('対象', 'Target'))}<Plus size={18} />{input(1, t('素材', 'Sacrifice'))}</div><input className="st-name" value={name} maxLength={35} placeholder={t('名前を変更（任意）', 'Rename (optional)')} onChange={e => setName(e.target.value)} onKeyDown={e => e.stopPropagation()} /></div>
      {result(r?.result ?? null, <><span className={`st-cost ${r && !afford ? 'bad' : ''}`}>{r ? (r.cost > 39 && !creative ? t('コストが高すぎます！', 'Too expensive!') : `${t('コスト', 'Cost')}: ${r.cost} Lv`) : '—'}</span><Button primary disabled={!r || !afford} onClick={() => { if (SV.doAnvil(engine, sel[0], sel[1], name)) { setName(''); done(true, true); } }}>{t('合成する', 'Combine')}</Button></>)}
    </div>;
  } else if (kind === 'grindstone') {
    const r = SV.grindPreview(engine, sel[0], sel[1]);
    hint = t('エンチャントを外して経験値に戻します（呪いは残ります）。同じ道具2つで修理も可能。', 'Removes enchantments for XP (curses stay). Two of the same tool are merged and repaired.');
    body = <div className="st-row"><div className="st-inputs"><div className="st-slots">{input(0, 'A')}<Plus size={18} />{input(1, 'B')}</div></div>{result(r?.result ?? null, <><span className="st-cost">{r ? `+${r.xp} XP` : '—'}</span><Button primary disabled={!r} onClick={() => done(SV.doGrind(engine, sel[0], sel[1]), true)}>{t('研ぐ', 'Grind')}</Button></>)}</div>;
  } else if (kind === 'smithing') {
    const r = SV.smithPreview(engine, sel[0], sel[1], sel[2]);
    hint = t('ネザライト強化、または「防具装飾の鍛冶型（16種）＋防具＋鉱石/インゴット素材（10種）」でマルチレイヤー防具トリムを施せます。', 'Upgrade diamond gear to Netherite, or apply any of the 16 Armor Trim smithing templates × 10 mineral materials.');
    body = <div className="st-row"><div className="st-inputs"><div className="st-slots">{input(0, t('鍛冶型', 'Template'))}{input(1, t('装備', 'Gear'))}{input(2, t('素材', 'Material'))}</div></div>{result(r, <Button primary disabled={!r} onClick={() => done(SV.doSmith(engine, sel[0], sel[1], sel[2]), true)}>{t('加工する', 'Smith')}</Button>)}</div>;
  } else if (kind === 'stonecutter') {
    const opts = SV.stonecutOptions(engine, sel[0]);
    hint = t('石材1個から階段・ハーフブロック(×2)・壁・レンガ等を無駄なく切り出せます。', 'Cut stairs, slabs (×2), walls and bricks from a single block with no waste.');
    body = <div className="st-row">
      <div className="st-inputs">{input(0, t('石材', 'Block'))}<label className="st-note"><input type="checkbox" checked={bulk} onChange={e => setBulk(e.target.checked)} /> {t('スタックごと加工', 'Whole stack')}</label></div>
      <div className="st-grid">{opts.length === 0 && <p className="muted">{A(0) ? t('この素材は加工できません', 'Nothing can be cut from this') : t('石材を選んでください', 'Pick a stone block')}</p>}{opts.map(o => <button key={o.result} title={name1(o.result)} onClick={() => done(SV.doStonecut(engine, sel[0], o.result, bulk))}><ItemIcon name={o.result} size={30} />×{o.count}</button>)}</div>
    </div>;
  } else if (kind === 'brewing') {
    const st = engine.furnaces[engine.stationKey], ing = slots[3];
    hint = t('水入り瓶 + ネザーウォート → 奇妙なポーション → 各素材。レッドストーンで延長、グロウストーンで強化、火薬でスプラッシュ化。', 'Water bottle + nether wart → awkward potion → ingredient. Redstone extends, glowstone strengthens, gunpowder makes it splash.');
    body = <div className="brew-stand">
      <div className="brew-fuel"><Slot stack={slots[4] ?? null} onClick={() => done(SV.containerTake(engine, slots, 4))} label={t('ブレイズパウダー', 'Blaze powder')} /><span>{t('燃料', 'Fuel')} {st?.burn ?? 0}/20</span></div>
      <div className="brew-fuel"><Slot stack={ing ?? null} onClick={() => done(SV.containerTake(engine, slots, 3))} label={t('材料', 'Ingredient')} /><div className="brew-bar"><i style={{ width: `${(st?.progress ?? 0) * 100}%` }} /></div></div>
      <div className="brew-fuel"><div className="brew-bottles">{[0, 1, 2].map(i => <Slot key={i} stack={slots[i] ?? null} onClick={() => done(SV.containerTake(engine, slots, i))} label={t('瓶', 'Bottle')} />)}</div><span>{ing && [0, 1, 2].some(i => slots[i] && brewResult(slots[i]!.name, ing.name)) ? `→ ${[0, 1, 2].map(i => (slots[i] ? brewResult(slots[i]!.name, ing.name) : null)).filter(Boolean).map(n => name1(n!)).filter((v, i, a) => a.indexOf(v) === i).join(' / ')}` : t('瓶 ×3', 'Bottles ×3')}</span></div>
    </div>;
  } else if (kind === 'loom') {
    const banner = A(0), dye = A(1), pitem = A(2);
    const base = banner ? bannerColorOf(banner.name) : 'white', dyeId = dye ? dye.name.replace(/_dye$/, '') : 'red', have = banner?.patterns ?? [];
    const preview = banner && dye ? [...have, { p: pattern, c: dyeId }] : have, def = patternDef(pattern);
    const ok = !!banner && !!dye && have.length < MAX_BANNER_LAYERS && (!def?.item || pitem?.name === def.item);
    hint = t('旗＋染料で模様を重ねます（最大6層）。特殊な模様は対応する「旗の模様」アイテムを3つ目の枠に入れると織れます（消費されません）。', 'Weave up to six dyed layers. Special designs need their banner-pattern item in the third slot (it is not consumed).');
    body = <div className="st-row">
      <div className="st-inputs">
        <div className="st-slots">{input(0, t('旗', 'Banner'))}<Plus size={18} />{input(1, t('染料', 'Dye'))}<Plus size={18} />{input(2, t('模様アイテム', 'Pattern item'))}</div>
        <div className="banner-preview">
          {banner ? <img src={bannerDataUrl(base, preview, 4)} alt="banner preview" /> : <p className="muted">{t('旗を選ぶとプレビュー', 'Pick a banner to preview')}</p>}
          <div className="st-note">{have.length}/{MAX_BANNER_LAYERS} {t('層', 'layers')}{have.length ? ' — ' + describeLayers(have) : ''}{def?.item && pitem?.name !== def.item ? ' · ' + t('要: ', 'needs ') + def.item.replace(/_/g, ' ') : ''}</div>
        </div>
        <Button primary disabled={!ok} onClick={() => done(SV.doLoom(engine, sel[0], sel[1], pattern, sel[2]))}>{t('模様を織る', 'Weave pattern')}</Button>
      </div>
      <div className="st-grid loom-grid">{BANNER_PATTERNS.map(p => <button key={p.id} className={pattern === p.id ? 'active' : ''} onClick={() => setPattern(p.id)} title={ja ? p.ja : p.en}><img src={bannerDataUrl(base, [{ p: p.id, c: dyeId }], 1)} alt="" width={22} height={44} /><span>{ja ? p.ja : p.en}{p.item ? ' 🔒' : ''}</span></button>)}</div>
    </div>;
  } else if (kind === 'cartography') {
    const hand = engine.stationKey === 'hand', handMap = hand ? SV.handStack(engine, (engine as unknown as { bookHand?: SV.Hand }).bookHand ?? 'main') : null;
    const map = hand ? handMap : A(0), md = SV.mapOf(engine, map);
    hint = hand ? t('地図は手に持って歩くと描き込まれます。製図台で 紙=縮小 / ガラス板=ロック / 白紙の地図=複製 ができます。', 'Hold a map while walking to fill it in. At a cartography table: paper zooms out, a glass pane locks, an empty map copies.') : t('地図 + 紙（縮小）/ ガラス板（ロック）/ 白紙の地図（複製）', 'Map + paper (zoom out) / glass pane (lock) / empty map (copy)');
    body = <div className="st-row">
      {!hand && <div className="st-inputs"><div className="st-slots">{input(0, t('地図', 'Map'))}<Plus size={18} />{input(1, t('紙など', 'Paper…'))}</div><Button primary disabled={!A(0) || !A(1)} onClick={() => done(SV.doCartography(engine, sel[0], sel[1]))}>{t('加工する', 'Apply')}</Button></div>}
      <div className="st-result">{md ? <><MapView engine={engine} id={md.id} version={md.version} /><span className="st-cost">1:{2 ** md.scale} · #{md.id}{md.locked ? ' 🔒' : ''} · {t('探索', 'explored')} {Math.round(100 * engine.maps.get(md.id)!.px.reduce((n, v) => n + (v ? 1 : 0), 0) / (MAP_SIZE * MAP_SIZE))}%</span></> : <p className="muted">{t('地図を選ぶとここに表示されます。白紙の地図は手に持って右クリックで作成。', 'Pick a map to preview it. Right-click with an empty map to create one.')}</p>}</div>
    </div>;
  } else if (kind === 'lectern') {
    const book = SV.lecternBook(engine), hand = engine.stationKey === 'hand';
    const isBook = book?.name === 'writable_book' || book?.name === 'written_book', editable = book?.name === 'writable_book', written = book?.name === 'written_book';
    const pages = book ? (isBook ? SV.bookPages(book) : ['']) : [], cur = Math.min(pg, Math.max(0, pages.length - 1));
    const go = (n: number) => { const k = Math.max(0, Math.min(pages.length - 1, n)); setPg(k); if (!hand) SV.setLecternPage(engine, k); refresh(); };
    const gen = V.GENERATION_NAMES[book?.gen ?? 0]?.[ja ? 0 : 1] ?? '';
    hint = hand ? t('本と羽根ペンは書き込めます（最大100ページ・1ページ1024文字）。署名するとタイトル付きの本になり、編集できなくなります。', 'Book & quill: up to 100 pages of 1024 characters. Signing adds a title and locks it.') : t('本を置くと読めます。ページをめくるとコンパレーターの出力が変わります。', 'Place a book to read it. Turning pages changes the comparator output.');
    body = <div className="st-row">
      {!hand && <div className="st-inputs"><Slot stack={book} onClick={() => { done(SV.containerTake(engine, slots, 0)); setPg(0); }} label={t('本', 'Book')} /><small>{t('本', 'Book')}</small></div>}
      {book && isBook ? <div className="book-ui">
        <div className="book-head">{written ? `“${book.title}” — ${book.author} · ${gen}` : t('本と羽根ペン', 'Book & Quill')}</div>
        <textarea className="book-page" readOnly={!editable} value={pages[cur] ?? ''} maxLength={V.BOOK_MAX_PAGE_CHARS} placeholder={editable ? t('ここに書き込めます…', 'Write here…') : t('（白紙）', '(blank)')} onChange={e => { SV.bookEdit(book, cur, e.target.value); refresh(); }} onKeyDown={e => e.stopPropagation()} />
        <div className="book-nav"><Button disabled={cur <= 0} onClick={() => go(cur - 1)}>◀</Button><span>{t('ページ', 'Page')} {cur + 1} / {pages.length} · {(pages[cur] ?? '').length}/{V.BOOK_MAX_PAGE_CHARS}</span><Button disabled={cur >= pages.length - 1} onClick={() => go(cur + 1)}>▶</Button></div>
        {editable && <div className="book-actions">
          <Button disabled={pages.length >= V.BOOK_MAX_PAGES} onClick={() => { SV.bookAddPage(book); setPg(pages.length); refresh(); }}>{t('+ ページ追加', '+ Add page')}</Button>
          <Button disabled={pages.length <= 1} onClick={() => { SV.bookRemovePage(book, cur); setPg(Math.max(0, cur - 1)); refresh(); }}>{t('ページ削除', 'Delete page')}</Button>
          {!signing ? <Button primary onClick={() => setSigning(true)}>{t('署名する…', 'Sign…')}</Button>
            : <span className="book-sign"><input value={title} maxLength={V.BOOK_MAX_TITLE} placeholder={t('タイトル（15文字まで）', 'Title (max 15)')} onChange={e => setTitle(e.target.value)} onKeyDown={e => e.stopPropagation()} /><Button primary disabled={!title.trim()} onClick={() => { if (SV.bookSign(engine, book, title)) { setSigning(false); refresh(); } }}>{t('署名して完成', 'Sign & close')}</Button><Button onClick={() => setSigning(false)}>{t('戻る', 'Back')}</Button></span>}
        </div>}
        {written && <Button disabled={!V.canCopyBook(book.gen ?? 0) || engine.countItem('writable_book') < 1} onClick={() => { if (SV.bookCopy(engine, book)) refresh(); }}>{t('コピーを作る（本と羽根ペン1個）', 'Copy (uses a book & quill)')}</Button>}
      </div> : book ? <p className="muted">{t('この本は白紙です。', 'This book is blank.')}</p> : <p className="muted">{t('下の持ちものから本を選んで書見台に置いてください。', 'Pick a book from your inventory to place it on the lectern.')}</p>}
    </div>;
  } else if (kind === 'beacon') {
    const tier = SV.currentBeaconTier(engine);
    const pay = A(0);
    const canConfirm = tier >= 1 && (creative || (!!pay && isBeaconPayment(pay.name)));
    hint = t(
      `ピラミッド階層: ${tier}/4段（効果範囲 ${beaconRange(tier)}m · 持続 ${beaconDuration(tier)}s）— 鉄・金・エメラルド・ダイヤ・ネザライトのブロックで1〜4段のピラミッドを下に組み、供物を捧げて決定ボタンを押してください。`,
      `Pyramid tier: ${tier}/4 (range ${beaconRange(tier)}m · ${beaconDuration(tier)}s) — build a 1–4 layer mineral block pyramid below, insert an ingot/gem offering, and click Confirm.`,
    );
    body = <div className="st-row">
      <div className="st-inputs">
        <div className="st-note"><strong>⛰ {t(`ピラミッド ${tier} 段`, `Pyramid Tier ${tier}`)}</strong> · {beaconRange(tier)}m</div>
        <div className="st-slots">{input(0, t('供物 (インゴット/宝石)', 'Offering'))}</div>
        <div className="st-note">
          <ItemIcon name="iron_ingot" size={18} />
          <ItemIcon name="gold_ingot" size={18} />
          <ItemIcon name="emerald" size={18} />
          <ItemIcon name="diamond" size={18} />
          <ItemIcon name="netherite_ingot" size={18} />
        </div>
        <Button primary disabled={!canConfirm} onClick={() => {
          if (SV.activateBeacon(engine, beaconPrimary, tier >= 4 ? beaconSecondary : undefined, sel[0])) {
            done(true, true);
            engine.onToast('ビーコンの力を解放しました！', 'Beacon power activated!');
          }
        }}><Check size={16} />{t('決定', 'Confirm')}</Button>
      </div>
      <div className="st-options">
        <div className="st-note"><strong>{t('主効果（1〜3段）', 'Primary Power (Tiers 1–3)')}</strong></div>
        <div className="st-grid">
          {BEACON_PRIMARY_POWERS.map(p => {
            const unlocked = tier >= p.minTier;
            return <button key={p.id} className={beaconPrimary === p.id ? 'active' : ''} disabled={!unlocked} onClick={() => setBeaconPrimary(p.id)} title={`${ja ? p.ja : p.en} (Tier ${p.minTier})`}>
              <strong>{ja ? p.ja : p.en}</strong>
              <small>Tier {p.minTier}</small>
            </button>;
          })}
        </div>
        <div className="st-note" style={{ marginTop: 8 }}><strong>{t('副効果（4段ピラミッドで解放）', 'Secondary Power (Tier 4 Pyramid)')}</strong></div>
        <div className="st-grid">
          <button className={beaconSecondary === 'regeneration' ? 'active' : ''} disabled={tier < 4} onClick={() => setBeaconSecondary('regeneration')}>
            <strong>{t('再生能力 I', 'Regeneration I')}</strong>
            <small>Tier 4</small>
          </button>
          <button className={beaconSecondary === beaconPrimary ? 'active' : ''} disabled={tier < 4} onClick={() => setBeaconSecondary(beaconPrimary)}>
            <strong>{ja ? EFFECTS[beaconPrimary]?.ja : EFFECTS[beaconPrimary]?.en} II</strong>
            <small>Tier 4</small>
          </button>
        </div>
      </div>
    </div>;
  } else if (kind === 'sign') {
    const sKey = `${engine.dimension}:${engine.stationKey}`;
    let sd = engine.signs.get(sKey);
    if (!sd) {
      sd = newSignData(engine.input.yaw, false, 'oak');
      engine.signs.set(sKey, sd);
    }
    const sideData = sd[signSide];
    hint = t(
      '最大4行のテキストを入力できます（表・裏の両面対応）。看板を手に持った染料で右クリックすると色変更、輝くイカスミで発光、ハニカムで編集ロックできます。',
      'Enter up to 4 lines on Front or Back. Right-click the sign with Dye to recolor, Glow Ink Sac to make text glow, or Honeycomb to wax and lock.',
    );
    body = <div className="st-row">
      <div className="st-inputs">
        <div className="st-slots">
          <Button primary={signSide === 'front'} onClick={() => setSignSide('front')}>{t('表面 (Front)', 'Front Side')}</Button>
          <Button primary={signSide === 'back'} onClick={() => setSignSide('back')}>{t('裏面 (Back)', 'Back Side')}</Button>
        </div>
        <img src={signSideDataUrl(sideData, sd.wood)} alt="sign preview" style={{ width: 220, height: 110, borderRadius: 6, border: '2px solid #4a3822', imageRendering: 'pixelated' }} />
        <div className="st-note">
          {t('文字色', 'Color')}: <b>{sideData.color}</b> · {sideData.glow ? t('✦ 発光中', '✦ Glowing') : t('通常', 'Normal')}
        </div>
      </div>
      <div className="st-options" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {[0, 1, 2, 3].map(lineIdx => (
          <input
            key={lineIdx}
            className="st-name"
            value={sideData.lines[lineIdx] ?? ''}
            maxLength={SIGN_MAX_LINE_CHARS}
            placeholder={t(`${lineIdx + 1}行目…`, `Line ${lineIdx + 1}…`)}
            onChange={e => {
              setSignLine(sd!, signSide, lineIdx, e.target.value);
              engine.syncSign(sKey);
              refresh();
            }}
            onKeyDown={e => e.stopPropagation()}
          />
        ))}
      </div>
    </div>;
  }

  const [tj, te] = TITLES[kind];
  return <Panel title={t(tj, te)} onBack={onClose} wide>
    <div className="station-layout">
      <div className="station-top">{body}</div>
      <div className="station-inventory">
        <div className="section-label"><Package size={15} />{NEED[kind] ? t('持ちもの — クリックで選択 / 解除', 'Inventory — click to select / deselect') : t('持ちもの — クリックで移動', 'Inventory — click to transfer')}<span>Lv {lv}</span></div>
        <div className="inventory-grid">{snapshot.inventory.map((s, i) => <Slot key={i + 9} stack={s} selected={sel.includes(i + 9) || (kind === 'crafter' && crafterPick === i + 9)} onClick={() => click(i + 9)} />)}</div>
        <div className="section-label hotbar-label">{t('ホットバー', 'Hotbar')}</div>
        <div className="inventory-grid">{snapshot.hotbar.map((s, i) => <Slot key={i} stack={s} selected={sel.includes(i) || (kind === 'crafter' ? crafterPick === i : !NEED[kind] && engine.selected === i)} onClick={() => click(i)} />)}</div>
      </div>
    </div>
    <footer className="panel-footer"><span className="muted">{hint}</span><Button primary onClick={onClose}><Check size={15} />{t('完了', 'Done')}</Button></footer>
  </Panel>;
}

/** In-game HUD additions: active effects, attack cooldown, charge meter, shield state / cooldown, hit direction, held map and the off-hand slot. */
const MAP_ICONS: Record<string, string> = { monument: '🔱', mansion: '🏚', red_x: '✖', trial_chambers: '🗝' };
/** Explorer map held in the hand: north-up mini map with the player arrow in the middle and the target icon (clamped to the rim). */
function ExplorerMapHud({ s, ja }: { s: GameSnapshot; ja: boolean }) {
  const map = s.hotbar[s.selected]?.map;
  if (!map) return null;
  const dx = map.x - s.x, dz = map.z - s.z, dist = Math.hypot(dx, dz), px = dx / 8, pz = dz / 8, len = Math.hypot(px, pz), k = len > 52 ? 52 / len : 1;
  return <div style={{ position: 'absolute', right: 14, bottom: 150, width: 132, height: 148, padding: 6, background: '#d9c79a', border: '3px solid #6b5332', boxShadow: '0 6px 18px rgba(0,0,0,.45)', color: '#3b2d18', font: '11px "Courier New",monospace', pointerEvents: 'none', zIndex: 5 }}>
    <div style={{ position: 'relative', width: 114, height: 114, background: 'repeating-linear-gradient(0deg,#cdb886 0 1px,transparent 1px 19px),repeating-linear-gradient(90deg,#cdb886 0 1px,transparent 1px 19px),#e6d7ad', overflow: 'hidden' }}>
      <span style={{ position: 'absolute', left: 51, top: 1, fontWeight: 700 }}>N</span>
      <span style={{ position: 'absolute', left: 57 - 6, top: 57 - 8, fontSize: 14, transform: `rotate(${-s.yaw}rad)`, color: '#1d5fb8' }}>▲</span>
      <span style={{ position: 'absolute', left: 57 + px * k - 8, top: 57 + pz * k - 9, fontSize: 15, color: map.icon === 'red_x' ? '#c8281e' : '#3b2d18', opacity: k < 1 ? 0.7 : 1 }}>{MAP_ICONS[map.icon] ?? '◆'}</span>
    </div>
    <div style={{ marginTop: 3, textAlign: 'center', fontWeight: 700 }}>{ja ? `目標まで ${Math.round(dist)} m` : `${Math.round(dist)} m to target`}</div>
  </div>;
}

export function HudExtras({ s, ja, engine }: { s: GameSnapshot; ja: boolean; engine?: Engine | null }) {
  const fmt = (sec: number) => (sec > 3600 ? '∞' : `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`);
  return <>
    <ExplorerMapHud s={s} ja={ja} />
    {s.effects.some(f => f.id === 'blindness' || f.id === 'darkness') && <div className="blind-overlay" />}
    {s.effects.some(f => f.id === 'nausea') && <div className="nausea-overlay" />}
    {s.effects.some(f => f.id === 'night_vision') && <div className="nightvision-overlay" />}
    {s.effects.length > 0 && <div className="effect-list">{s.effects.map(f => {
      const d = EFFECTS[f.id];
      return d ? <div key={f.id} className={d.bad ? 'bad' : ''} style={{ borderColor: d.color }}><i style={{ background: d.color }} /><span>{ja ? d.ja : d.en}{f.amp > 0 ? ' ' + roman(f.amp + 1) : ''}</span><b>{fmt(f.t)}</b></div> : null;
    })}</div>}
    {s.mode !== 'creative' && s.attackCharge < 0.98 && <div className="attack-meter"><i style={{ width: `${s.attackCharge * 100}%` }} /></div>}
    {s.useCharge > 0 && <div className="attack-meter use"><i style={{ width: `${s.useCharge * 100}%` }} /></div>}
    {s.blocking && <div className={`block-indicator ${s.shieldActive ? 'ready' : ''}`}><Shield size={14} />{s.shieldActive ? (ja ? 'ガード中' : 'Blocking') : (ja ? '構え中…' : 'Raising…')}</div>}
    {s.shieldCd > 0 && <div className="shield-cd"><Shield size={14} />{ja ? '盾 使用不能' : 'Shield disabled'} {s.shieldCd.toFixed(1)}s<i style={{ width: `${(s.shieldCd / 5) * 100}%` }} /></div>}
    {s.hitAge < 0.9 && <div className="hit-indicator" style={{ transform: `rotate(${s.hitAngle}deg)`, opacity: 1 - s.hitAge / 0.9 }}><i /></div>}
    {engine && s.heldMapId >= 0 && engine.maps.has(s.heldMapId) && <div className="held-map"><MapView engine={engine} id={s.heldMapId} version={s.mapVersion} px={170} /></div>}
    {s.offhand && <div className="offhand-slot"><Slot stack={s.offhand} label="off-hand" /></div>}
  </>;
}
