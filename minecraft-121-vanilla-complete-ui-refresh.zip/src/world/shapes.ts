import { BLOCKS, type BlockDef } from '../game/data';
import { blockId, blockState, isSlabBlock } from '../game/blockState';

export type Bounds = readonly [number, number, number, number, number, number];
export type StairShape = 'straight' | 'inner_left' | 'inner_right' | 'outer_left' | 'outer_right';

export const CHEST_BOUNDS: Bounds = [1 / 16, 0, 1 / 16, 15 / 16, 14 / 16, 15 / 16];
const CHEST: readonly Bounds[] = [CHEST_BOUNDS];
const FULL: readonly Bounds[] = [[0, 0, 0, 1, 1, 1]];
const SLAB: readonly Bounds[] = [[0, 0, 0, 1, .5, 1]];
const TOP_SLAB: readonly Bounds[] = [[0, .5, 0, 1, 1, 1]];
const STAIRS: readonly (readonly Bounds[])[] = [
  [[0,0,0,1,.5,1],[0,.5,0,1,1,.5]],
  [[0,0,0,1,.5,1],[.5,.5,0,1,1,1]],
  [[0,0,0,1,.5,1],[0,.5,.5,1,1,1]],
  [[0,0,0,1,.5,1],[0,.5,0,.5,1,1]],
  [[0,.5,0,1,1,1],[0,0,0,1,.5,.5]],
  [[0,.5,0,1,1,1],[.5,0,0,1,.5,1]],
  [[0,.5,0,1,1,1],[0,0,.5,1,.5,1]],
  [[0,.5,0,1,1,1],[0,0,0,.5,.5,1]],
];
const T3 = 3 / 16;
/** 3px panels standing on one edge of the cell: 0 = north (z 0..3px), 1 = west (x 0..3px), 2 = south, 3 = east. Doors and open trapdoors. */
const EDGE: readonly (readonly Bounds[])[] = [[[0, 0, 0, 1, 1, T3]], [[0, 0, 0, T3, 1, 1]], [[0, 0, 1 - T3, 1, 1, 1]], [[1 - T3, 0, 0, 1, 1, 1]]];
const TRAPDOOR: readonly Bounds[] = [[0, 0, 0, 1, T3, 1]];
const TRAPDOOR_TOP: readonly Bounds[] = [[0, 1 - T3, 0, 1, 1, 1]];
const PANE: readonly Bounds[] = [[.4375, 0, 0, .5625, 1, 1]];
const PANE_X: readonly Bounds[] = [[0, 0, .4375, 1, 1, .5625]];
const CHAIN: readonly Bounds[] = [[6.5 / 16, 0, 6.5 / 16, 9.5 / 16, 1, 9.5 / 16]];
const FENCE: readonly Bounds[] = [[.375, 0, .375, .625, 1, .625], [0, .4, .42, 1, .55, .58], [.42, .4, 0, .58, .55, 1], [0, .78, .42, 1, .93, .58], [.42, .78, 0, .58, .93, 1]];
const TORCH: readonly Bounds[] = [[.35, 0, .35, .65, .75, .65]];
const TORCH_MODEL: readonly Bounds[] = [[7 / 16, 0, 7 / 16, 9 / 16, 10 / 16, 9 / 16]];
const LANTERN: readonly Bounds[] = [
  [5 / 16, 0, 5 / 16, 11 / 16, 7 / 16, 11 / 16],
  [6 / 16, 7 / 16, 6 / 16, 10 / 16, 9 / 16, 10 / 16],
  [7 / 16, 9 / 16, 7 / 16, 9 / 16, 11 / 16, 9 / 16],
];
const BELL: readonly Bounds[] = [
  [1 / 16, 0, 6 / 16, 3 / 16, 15 / 16, 10 / 16],
  [13 / 16, 0, 6 / 16, 15 / 16, 15 / 16, 10 / 16],
  [1 / 16, 13 / 16, 6.5 / 16, 15 / 16, 15 / 16, 9.5 / 16],
  [5 / 16, 5 / 16, 5 / 16, 11 / 16, 12 / 16, 11 / 16],
  [4 / 16, 3 / 16, 4 / 16, 12 / 16, 5 / 16, 12 / 16],
];
const LECTERN: readonly Bounds[] = [
  [0, 0, 0, 1, 2 / 16, 1],
  [4 / 16, 2 / 16, 4 / 16, 12 / 16, 11 / 16, 12 / 16],
  [1 / 16, 10 / 16, 1 / 16, 15 / 16, 13 / 16, 6 / 16],
  [1 / 16, 11.5 / 16, 5 / 16, 15 / 16, 14.5 / 16, 11 / 16],
  [1 / 16, 13 / 16, 10 / 16, 15 / 16, 1, 15 / 16],
];
// Vanilla 3D Hopper (top funnel + middle funnel + bottom spout)
const HOPPER_BOXES: readonly Bounds[] = [
  [0, 10 / 16, 0, 1, 1, 1],
  [4 / 16, 4 / 16, 4 / 16, 12 / 16, 10 / 16, 12 / 16],
  [6 / 16, 0, 6 / 16, 10 / 16, 4 / 16, 10 / 16],
];
// Vanilla 3D Cauldron (raised base floor + 4 outer walls)
const CAULDRON_BOXES: readonly Bounds[] = [
  [0, 3 / 16, 0, 1, 4 / 16, 1],
  [0, 3 / 16, 0, 2 / 16, 1, 1],
  [14 / 16, 3 / 16, 0, 1, 1, 1],
  [2 / 16, 3 / 16, 0, 14 / 16, 1, 2 / 16],
  [2 / 16, 3 / 16, 14 / 16, 14 / 16, 1, 1],
];
// Vanilla 3D Composter (bottom floor + 4 wooden walls)
const COMPOSTER_BOXES: readonly Bounds[] = [
  [0, 0, 0, 1, 2 / 16, 1],
  [0, 2 / 16, 0, 2 / 16, 1, 1],
  [14 / 16, 2 / 16, 0, 1, 1, 1],
  [2 / 16, 2 / 16, 0, 14 / 16, 1, 2 / 16],
  [2 / 16, 2 / 16, 14 / 16, 14 / 16, 1, 1],
];
const CACTUS: readonly Bounds[] = [[1 / 16, 0, 1 / 16, 15 / 16, 1, 15 / 16]];
const CHORUS_PLANT: readonly Bounds[] = [[2 / 16, 0, 2 / 16, 14 / 16, 1, 14 / 16]];
const CHORUS_FLOWER: readonly Bounds[] = [[1 / 16, 0, 1 / 16, 15 / 16, 1, 15 / 16]];
const FARMLAND: readonly Bounds[] = [[0, 0, 0, 1, 15 / 16, 1]];
const BED: readonly Bounds[] = [[0, 0, 0, 1, 9 / 16, 1]];
const FRAME: readonly Bounds[] = [[0, 0, 0, 1, 13 / 16, 1]];
const FRAME_EYE: readonly Bounds[] = [[0, 0, 0, 1, 13 / 16, 1], [4 / 16, 13 / 16, 4 / 16, 12 / 16, 1, 12 / 16]];
const END_ROD: readonly Bounds[] = [[6 / 16, 0, 6 / 16, 10 / 16, 1, 10 / 16]];
const END_ROD_SEL: readonly (readonly Bounds[])[] = [
  [[6 / 16, 0, 6 / 16, 10 / 16, 1, 10 / 16]],
  [[0, 6 / 16, 6 / 16, 1, 10 / 16, 10 / 16]],
  [[0, 6 / 16, 6 / 16, 1, 10 / 16, 10 / 16]],
  [[6 / 16, 6 / 16, 0, 10 / 16, 10 / 16, 1]],
  [[6 / 16, 6 / 16, 0, 10 / 16, 10 / 16, 1]],
  [[6 / 16, 0, 6 / 16, 10 / 16, 1, 10 / 16]],
];
const SHULKER: readonly Bounds[] = [[0, 0, 0, 1, 1, 1]];
const EGG: readonly Bounds[] = [[1 / 16, 0, 1 / 16, 15 / 16, 1, 15 / 16]];
const HEAD: readonly Bounds[] = [[3 / 16, 0, 2 / 16, 13 / 16, 11 / 16, 14 / 16]];
const CONDUIT_BOX: readonly Bounds[] = [[5 / 16, 5 / 16, 5 / 16, 11 / 16, 11 / 16, 11 / 16]];
const CONDUIT_ACTIVE_BOX: readonly Bounds[] = [[4 / 16, 4 / 16, 4 / 16, 12 / 16, 12 / 16, 12 / 16]];
const SEA_PICKLE_BOX: readonly Bounds[] = [[4 / 16, 0, 4 / 16, 12 / 16, 7 / 16, 12 / 16]];
const TURTLE_EGG_BOX: readonly Bounds[] = [[3 / 16, 0, 3 / 16, 13 / 16, 7 / 16, 13 / 16]];
const SKULL_BOX: readonly Bounds[] = [[4 / 16, 0, 4 / 16, 12 / 16, 8 / 16, 12 / 16]];
const PIGLIN_HEAD_BOX: readonly Bounds[] = [[3 / 16, 0, 2 / 16, 13 / 16, 8 / 16, 12 / 16]];
const WALL_SKULL_BOXES: readonly (readonly Bounds[])[] = [
  [[4 / 16, 4 / 16, 0, 12 / 16, 12 / 16, 8 / 16]],
  [[0, 4 / 16, 4 / 16, 8 / 16, 12 / 16, 12 / 16]],
  [[4 / 16, 4 / 16, 8 / 16, 12 / 16, 12 / 16, 1]],
  [[8 / 16, 4 / 16, 4 / 16, 1, 12 / 16, 12 / 16]],
];
const HEAVY_CORE_BOX: readonly Bounds[] = [[4 / 16, 0, 4 / 16, 12 / 16, 8 / 16, 12 / 16]];
const SNIFFER_EGG_BOX: readonly Bounds[] = [[1 / 16, 0, 2 / 16, 15 / 16, 1, 14 / 16]];
const FLOWER_POT_BOX: readonly Bounds[] = [[5 / 16, 0, 5 / 16, 11 / 16, 6 / 16, 11 / 16]];
const CANDLE_BOXES: readonly (readonly Bounds[])[] = [
  [[7 / 16, 0, 7 / 16, 9 / 16, 6 / 16, 9 / 16]],
  [[5 / 16, 0, 6 / 16, 11 / 16, 6 / 16, 10 / 16]],
  [[5 / 16, 0, 5 / 16, 11 / 16, 6 / 16, 11 / 16]],
  [[5 / 16, 0, 5 / 16, 11 / 16, 6 / 16, 11 / 16]],
];
const CAKE_BOXES: readonly (readonly Bounds[])[] = [
  [[1 / 16, 0, 1 / 16, 15 / 16, 8 / 16, 15 / 16]],
  [[3 / 16, 0, 1 / 16, 15 / 16, 8 / 16, 15 / 16]],
  [[5 / 16, 0, 1 / 16, 15 / 16, 8 / 16, 15 / 16]],
  [[7 / 16, 0, 1 / 16, 15 / 16, 8 / 16, 15 / 16]],
  [[9 / 16, 0, 1 / 16, 15 / 16, 8 / 16, 15 / 16]],
  [[11 / 16, 0, 1 / 16, 15 / 16, 8 / 16, 15 / 16]],
  [[13 / 16, 0, 1 / 16, 15 / 16, 8 / 16, 15 / 16]],
];
const CANDLE_CAKE_BOX: readonly Bounds[] = [
  [1 / 16, 0, 1 / 16, 15 / 16, 8 / 16, 15 / 16],
  [7 / 16, 8 / 16, 7 / 16, 9 / 16, 14 / 16, 9 / 16],
];
const BAMBOO_BOX: readonly Bounds[] = [[5 / 16, 0, 5 / 16, 11 / 16, 1, 11 / 16]];
const END_PORTAL_BOX: readonly Bounds[] = [[0, 0, 0, 1, 12 / 16, 1]];
const BREWING: readonly Bounds[] = [
  [1 / 16, 0, 9 / 16, 7 / 16, 2 / 16, 15 / 16],
  [9 / 16, 0, 9 / 16, 15 / 16, 2 / 16, 15 / 16],
  [5 / 16, 0, 1 / 16, 11 / 16, 2 / 16, 7 / 16],
  [7 / 16, 0, 7 / 16, 9 / 16, 14 / 16, 9 / 16],
];
const PLANT: readonly Bounds[] = [[.2, 0, .2, .8, .8, .8]];
const LILY: readonly Bounds[] = [[.06, 0, .06, .94, .08, .94]];
const NONE: readonly Bounds[] = [];
const TRIPWIRE_X: readonly Bounds[] = [[0, 1 / 16, 7.5 / 16, 1, 2 / 16, 8.5 / 16]];
const TRIPWIRE_Z: readonly Bounds[] = [[7.5 / 16, 1 / 16, 0, 8.5 / 16, 2 / 16, 1]];
const TRIPWIRE_FREE: readonly Bounds[] = [TRIPWIRE_X[0], TRIPWIRE_Z[0]];
const LADDER: readonly (readonly Bounds[])[] = [[[0, 0, 0, 1, 1, 1 / 16]], [[0, 0, 0, 1 / 16, 1, 1]], [[0, 0, 15 / 16, 1, 1, 1]], [[15 / 16, 0, 0, 1, 1, 1]]];
const px = (h: number, inset = 0): readonly Bounds[] => [[inset / 16, 0, inset / 16, 1 - inset / 16, h / 16, 1 - inset / 16]];
const LOW = { carpet: px(1), plate: px(1, 1), platePressed: px(0.5, 1), diode: px(2), detector: px(6), table: px(12), cutter: px(9), snow: px(2), campfire: px(7) };
const ANVIL_Z: readonly Bounds[] = [
  [2 / 16, 0, 2 / 16, 14 / 16, 4 / 16, 14 / 16],
  [4 / 16, 4 / 16, 3 / 16, 12 / 16, 5 / 16, 13 / 16],
  [6 / 16, 5 / 16, 4 / 16, 10 / 16, 10 / 16, 12 / 16],
  [3 / 16, 10 / 16, 0, 13 / 16, 1, 1],
];
const ANVIL_X: readonly Bounds[] = [
  [2 / 16, 0, 2 / 16, 14 / 16, 4 / 16, 14 / 16],
  [3 / 16, 4 / 16, 4 / 16, 13 / 16, 5 / 16, 12 / 16],
  [4 / 16, 5 / 16, 6 / 16, 12 / 16, 10 / 16, 10 / 16],
  [0, 10 / 16, 3 / 16, 1, 1, 13 / 16],
];
const GRINDSTONE: readonly Bounds[] = [[4 / 16, 4 / 16, 2 / 16, 12 / 16, 1, 14 / 16], [2 / 16, 0, 6 / 16, 4 / 16, 12 / 16, 10 / 16], [12 / 16, 0, 6 / 16, 14 / 16, 12 / 16, 10 / 16]];
const s16 = 1 / 16;
const PISTON_HEAD: readonly (readonly Bounds[])[] = [
  [[12 * s16, 0, 0, 1, 1, 1], [0, 6 * s16, 6 * s16, 12 * s16, 10 * s16, 10 * s16]],
  [[0, 0, 12 * s16, 1, 1, 1], [6 * s16, 6 * s16, 0, 10 * s16, 10 * s16, 12 * s16]],
  [[0, 0, 0, 4 * s16, 1, 1], [4 * s16, 6 * s16, 6 * s16, 1, 10 * s16, 10 * s16]],
  [[0, 0, 0, 1, 1, 4 * s16], [6 * s16, 6 * s16, 4 * s16, 10 * s16, 10 * s16, 1]],
  [[0, 12 * s16, 0, 1, 1, 1], [6 * s16, 0, 6 * s16, 10 * s16, 12 * s16, 10 * s16]],
  [[0, 0, 0, 1, 4 * s16, 1], [6 * s16, 4 * s16, 6 * s16, 10 * s16, 1, 10 * s16]],
];
function lowBoxes(name: string, state: number): readonly Bounds[] {
  if (name === 'piston_head') return PISTON_HEAD[state & 7] ?? PISTON_HEAD[0];
  if (name === 'lectern') return LECTERN;
  if (name === 'bell') return BELL;
  if (name === 'hopper') return HOPPER_BOXES;
  if (name === 'cauldron' || name === 'water_cauldron' || name === 'lava_cauldron' || name === 'powder_snow_cauldron') return CAULDRON_BOXES;
  if (name === 'composter') return COMPOSTER_BOXES;
  if (name === 'heavy_core') return HEAVY_CORE_BOX;
  if (name === 'sniffer_egg') return SNIFFER_EGG_BOX;
  if (name === 'cake') return CAKE_BOXES[Math.min(6, state & 7)];
  if (name.endsWith('candle_cake')) return CANDLE_CAKE_BOX;
  if (name === 'snow_layer' || name === 'snow') return LOW.snow;
  if (name === 'campfire' || name === 'unlit_campfire' || name === 'soul_campfire') return LOW.campfire;
  if (name === 'tripwire' || name === 'moss_carpet' || name.endsWith('_carpet') || name === 'redstone_wire' || name === 'rail' || name === 'powered_rail' || name === 'detector_rail' || name === 'activator_rail') return LOW.carpet;
  if (name.endsWith('_pressure_plate')) return state & 8 ? LOW.platePressed : LOW.plate;
  if (name === 'repeater' || name === 'comparator') return LOW.diode;
  if (name.startsWith('daylight_detector') || name.endsWith('daylight_detector')) return LOW.detector;
  if (name === 'enchanting_table' || name === 'end_portal') return LOW.table;
  if (name === 'stonecutter' || name === 'bed' || name.endsWith('_bed')) return LOW.cutter;
  if (name === 'anvil' || name === 'chipped_anvil' || name === 'damaged_anvil') return (state & 1) ? ANVIL_X : ANVIL_Z;
  if (name === 'grindstone') return GRINDSTONE;
  if (name === 'sea_pickle') return SEA_PICKLE_BOX;
  return name.startsWith('farmland') ? FARMLAND : SLAB;
}

/**
 * Computes the Vanilla Java Edition corner shape ('straight', 'inner_left', 'inner_right', 'outer_left', 'outer_right')
 * of a stair block at (x, y, z) from its neighboring stairs.
 * Stair facing: 0 = step on -Z (north), 1 = step on +X (east), 2 = step on +Z (south), 3 = step on -X (west).
 */
const STAIR_DIR: readonly [number, number][] = [[0, -1], [1, 0], [0, 1], [-1, 0]];
export function stairShapeAt(
  getCell: (x: number, y: number, z: number) => number,
  x: number,
  y: number,
  z: number,
): StairShape {
  const cell = getCell(x, y, z);
  const id = blockId(cell);
  const def = BLOCKS[id];
  if (!def || def.shape !== 'stairs') return 'straight';
  const st = blockState(cell);
  const facing = st & 3;
  const top = st & 4;
  const [fx, fz] = STAIR_DIR[facing];

  // 1. Check behind the stair (in direction of the raised step +fx, +fz) for an outer corner
  const backCell = getCell(x + fx, y, z + fz);
  const backDef = BLOCKS[blockId(backCell)];
  if (backDef?.shape === 'stairs' && (blockState(backCell) & 4) === top) {
    const bf = blockState(backCell) & 3;
    if (bf === ((facing + 1) & 3)) return 'outer_right';
    if (bf === ((facing + 3) & 3)) return 'outer_left';
  }

  // 2. Check in front of the stair (in direction -fx, -fz) for an inner corner
  const frontCell = getCell(x - fx, y, z - fz);
  const frontDef = BLOCKS[blockId(frontCell)];
  if (frontDef?.shape === 'stairs' && (blockState(frontCell) & 4) === top) {
    const ff = blockState(frontCell) & 3;
    if (ff === ((facing + 1) & 3)) return 'inner_right';
    if (ff === ((facing + 3) & 3)) return 'inner_left';
  }
  return 'straight';
}

/** Returns the 3D AABB boxes for a stair given its state (0..7) and StairShape. */
export function stairBoxesForShape(state: number, shape: StairShape): readonly Bounds[] {
  const facing = state & 3;
  const top = (state & 4) !== 0;
  if (shape === 'straight') return STAIRS[state & 7];
  const baseSlab: Bounds = top ? [0, 0.5, 0, 1, 1, 1] : [0, 0, 0, 1, 0.5, 1];
  const y0 = top ? 0 : 0.5, y1 = top ? 0.5 : 1;
  // Quarter-step octants: NW(0), NE(1), SE(2), SW(3)
  const oct = (q: number): Bounds => {
    const x0 = q === 1 || q === 2 ? 0.5 : 0;
    const z0 = q === 2 || q === 3 ? 0.5 : 0;
    return [x0, y0, z0, x0 + 0.5, y1, z0 + 0.5];
  };
  // Full half-step octant pairs per facing: 0(-Z)=[0,1], 1(+X)=[1,2], 2(+Z)=[2,3], 3(-X)=[3,0]
  if (shape === 'outer_left') return [baseSlab, oct(facing)];
  if (shape === 'outer_right') return [baseSlab, oct((facing + 1) & 3)];
  if (shape === 'inner_left') return [baseSlab, oct(facing), oct((facing + 1) & 3), oct((facing + 3) & 3)];
  return [baseSlab, oct(facing), oct((facing + 1) & 3), oct((facing + 2) & 3)];
}

export function stairBoxesAt(
  getCell: (x: number, y: number, z: number) => number,
  x: number,
  y: number,
  z: number,
): readonly Bounds[] {
  const cell = getCell(x, y, z);
  const st = blockState(cell);
  const shape = stairShapeAt(getCell, x, y, z);
  return stairBoxesForShape(st, shape);
}

/** True for ultra-thin floor blocks (carpets, pressure plates, snow layers, repeaters/comparators) that must never snag entities horizontally from the side. */
export function isThinFloorBlock(def: BlockDef): boolean {
  const n = def.name;
  return (
    n.endsWith('_carpet') ||
    n === 'moss_carpet' ||
    n.endsWith('_pressure_plate') ||
    n === 'snow_layer' ||
    n === 'snow' ||
    n === 'sculk_vein' ||
    n === 'frogspawn' ||
    n === 'repeater' ||
    n === 'comparator'
  );
}

/** Door state: bits 0-1 = edge the closed leaf stands on, bit 2 = upper half, bit 3 = open (left hinge: swings onto the next edge). */
export function doorEdge(state: number): number {
  return state & 8 ? ((state & 3) + 3) & 3 : state & 3;
}

type Sixteenths = readonly (readonly number[])[];
export const TORCH16: Sixteenths = [[7, 0, 7, 9, 10, 9, -1, 0, 0], [0.5, 3, 7, 2.5, 13, 9, 1, 4, 0], [13.5, 3, 7, 15.5, 13, 9, 1, -4, 0], [7, 3, 0.5, 9, 13, 2.5, 1, 0, 4], [7, 3, 13.5, 9, 13, 15.5, 1, 0, -4]];
export const LEVER_BASE16: Sixteenths = [[5, 0, 4, 11, 3, 12], [0, 4, 5, 3, 12, 11], [13, 4, 5, 16, 12, 11], [5, 4, 0, 11, 12, 3], [5, 4, 13, 11, 12, 16], [5, 13, 4, 11, 16, 12]];
export const LEVER_STICK16: readonly Sixteenths[] = [
  [[7, 2, 7, 9, 9, 9, 1, 0, 6], [7, 2, 7, 9, 9, 9, 1, 0, -6]],
  [[2, 8, 7, 4, 14, 9, 1, 6, 0], [2, 2, 7, 4, 8, 9, 0, 6, 0]],
  [[12, 8, 7, 14, 14, 9, 1, -6, 0], [12, 2, 7, 4, 8, 9, 0, -6, 0]],
  [[7, 8, 2, 9, 14, 4, 1, 0, 6], [7, 2, 2, 9, 8, 4, 0, 0, 6]],
  [[7, 8, 12, 9, 14, 14, 1, 0, -6], [7, 2, 12, 9, 8, 14, 0, 0, -6]],
  [[7, 7, 7, 9, 14, 9, 0, 0, 6], [7, 7, 7, 9, 14, 9, 0, 0, -6]],
];
export const BUTTON16: Sixteenths = [[5, 0, 6, 11, 2, 10], [0, 6, 5, 2, 10, 11], [14, 6, 5, 16, 10, 11], [5, 6, 0, 11, 10, 2], [5, 6, 14, 11, 10, 16], [5, 14, 6, 11, 16, 10]];
const unit = (b: readonly number[]): readonly Bounds[] => [[b[0] / 16, b[1] / 16, b[2] / 16, b[3] / 16, b[4] / 16, b[5] / 16]];
const TORCH_SEL = [[6, 0, 6, 10, 10, 10], [0, 3, 6, 6.5, 13, 10], [9.5, 3, 6, 16, 13, 10], [6, 3, 0, 10, 13, 6.5], [6, 3, 9.5, 10, 13, 16]].map(unit);
const LEVER_SEL = [[5, 0, 4, 11, 10, 12], [0, 2, 5, 10, 14, 11], [6, 2, 5, 16, 14, 11], [5, 2, 0, 11, 14, 10], [5, 2, 6, 11, 14, 16], [5, 6, 4, 11, 16, 12]].map(unit);
const BUTTON_SEL = BUTTON16.map(unit);

const SEL_CACHE: (readonly Bounds[] | undefined)[] = new Array(65536);

export function selectionBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  const id = def.id;
  if (id > 0 && id < 4096 && BLOCKS[id] === def) {
    const key = (id << 4) | (state & 15);
    let cached = SEL_CACHE[key];
    if (cached === undefined) {
      cached = computeSelectionBoxes(def, state);
      SEL_CACHE[key] = cached;
    }
    return cached;
  }
  return computeSelectionBoxes(def, state);
}

function computeSelectionBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  if (def.name === 'cave_air' || def.name === 'void_air' || def.name === 'structure_void') return NONE;
  if (def.name === 'piston_head' || def.shape === 'piston_head') return PISTON_HEAD[state & 7] ?? PISTON_HEAD[0];
  if (def.name === 'moving_piston' || def.shape === 'moving_piston') return NONE;
  if (def.name === 'lectern') return LECTERN;
  if (def.name === 'bell') return BELL;
  if (def.name === 'chain') return CHAIN;
  if (def.name === 'hopper') return HOPPER_BOXES;
  if (def.name === 'cauldron' || def.name === 'water_cauldron' || def.name === 'lava_cauldron' || def.name === 'powder_snow_cauldron') return CAULDRON_BOXES;
  if (def.name === 'composter') return COMPOSTER_BOXES;
  if (def.name === 'heavy_core') return HEAVY_CORE_BOX;
  if (def.name === 'sniffer_egg') return SNIFFER_EGG_BOX;
  if (def.name === 'cake') return CAKE_BOXES[Math.min(6, state & 7)];
  if (def.name.endsWith('candle_cake')) return CANDLE_CAKE_BOX;
  if (def.name === 'candle' || def.name.endsWith('_candle')) return CANDLE_BOXES[state & 3];
  if (def.name === 'flower_pot' || def.name.startsWith('potted_')) return FLOWER_POT_BOX;
  if (def.name === 'stonecutter') return LOW.cutter;
  if (def.name === 'conduit') return state > 0 ? CONDUIT_ACTIVE_BOX : CONDUIT_BOX;
  if (def.name === 'sea_pickle') return SEA_PICKLE_BOX;
  if (def.name === 'turtle_egg') return TURTLE_EGG_BOX;
  if (def.name === 'chorus_plant') return CHORUS_PLANT;
  if (def.name === 'chorus_flower') return CHORUS_FLOWER;
  if (def.name === 'skeleton_skull' || def.name === 'wither_skeleton_skull' || def.name === 'zombie_head' || def.name === 'creeper_head' || def.name === 'player_head') return SKULL_BOX;
  if (def.name === 'piglin_head') return PIGLIN_HEAD_BOX;
  if (def.name.endsWith('_wall_skull') || def.name.endsWith('_wall_head')) return WALL_SKULL_BOXES[state & 3];
  if (def.name === 'bamboo') return BAMBOO_BOX;
  switch (def.shape) {
    case 'chest': return CHEST;
    case 'slab': return isSlabBlock(def) ? ((state & 7) === 2 ? FULL : (state & 7) === 1 ? TOP_SLAB : SLAB) : lowBoxes(def.name, state);
    case 'stairs': return STAIRS[state & 7];
    case 'door': return EDGE[doorEdge(state)];
    case 'trapdoor': return state & 8 ? EDGE[state & 3] : state & 4 ? TRAPDOOR_TOP : TRAPDOOR;
    case 'pane': return def.name === 'ladder' || def.name === 'item_frame' || def.name.endsWith('_wall_banner') || def.name.endsWith('_wall_sign') || def.name.endsWith('_wall_hanging_sign') || def.name.endsWith('_coral_wall_fan') ? LADDER[state & 3] : state & 1 ? PANE_X : PANE;
    case 'fence': return FENCE;
    case 'torch': {
      if (def.name === 'lantern' || def.name === 'soul_lantern') return LANTERN;
      if (def.name === 'brewing_stand') return BREWING;
      const at = def.name.includes('wall_torch') ? ((state & 3) + 1) : (state & 7);
      if (def.name === 'lever') return LEVER_SEL[at] ?? LEVER_SEL[0];
      if (def.name.endsWith('_button')) return BUTTON_SEL[at] ?? BUTTON_SEL[0];
      return TORCH_SEL[at] ?? TORCH_SEL[0];
    }
    case 'cactus': return CACTUS;
    case 'bed': return BED;
    case 'end_portal_frame': return state & 4 ? FRAME_EYE : FRAME;
    case 'end_rod': return END_ROD_SEL[state & 7] ?? END_ROD;
    case 'shulker_box': return SHULKER;
    case 'dragon_egg': return EGG;
    case 'dragon_head': return HEAD;
    case 'end_portal': return END_PORTAL_BOX;
    case 'end_gateway': return FULL;
    case 'lantern': return def.name === 'bell' ? BELL : LANTERN;
    case 'enchanting_table': return LOW.table;
    case 'anvil': return (state & 1) ? ANVIL_X : ANVIL_Z;
    case 'brewing_stand': return BREWING;
    case 'cross': return PLANT;
    case 'lily': return LILY;
    case 'water': return NONE;
    default: return FULL;
  }
}

/** Boxes used for rendering generic box models; doors, fences, torches, levers and buttons have dedicated models in the mesher. */
const MODEL_CACHE = new Array<readonly Bounds[] | undefined>(4096 * 16);
export function modelBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  const ck = (def.id << 4) | (state & 15);
  const hit = MODEL_CACHE[ck];
  if (hit !== undefined) return hit;
  const res = computeModelBoxes(def, state);
  MODEL_CACHE[ck] = res;
  return res;
}
function computeModelBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  if (def.name === 'moving_piston' || def.shape === 'moving_piston' || def.name === 'cave_air' || def.name === 'void_air' || def.name === 'structure_void') return NONE;
  if (def.name === 'tripwire') return !(state & 1) ? TRIPWIRE_FREE : state & 8 ? TRIPWIRE_Z : TRIPWIRE_X;
  return def.shape === 'torch' && def.name === 'brewing_stand' ? BREWING : selectionBoxes(def, state);
}

export function collisionBoxes(def: BlockDef, state = 0): readonly Bounds[] {
  if (!def.solid) return NONE;
  if (def.name.endsWith('_pressure_plate') || ((def.name === 'snow_layer' || def.name === 'snow') && (state & 7) === 0)) return NONE;
  if (def.name.endsWith('_fence_gate') && (state & 8) !== 0) return NONE;
  return selectionBoxes(def, state);
}

export function intersectsBox(
  x: number, y: number, z: number,
  minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number,
  box: Bounds,
): boolean {
  return maxX > x + box[0] && minX < x + box[3] &&
    maxY > y + box[1] && minY < y + box[4] &&
    maxZ > z + box[2] && minZ < z + box[5];
}
