import { RAW_BLOCKS, INTERNAL_BLOCKS, ALL_BLOCKS, ID, item, ITEM_ID, type BlockDef, type Pattern, type Shape } from './data';

export const OFFICIAL_1060_NAMES: readonly string[] = ["air", "stone", "granite", "polished_granite", "diorite", "polished_diorite", "andesite", "polished_andesite", "deepslate", "cobbled_deepslate", "polished_deepslate", "calcite", "tuff", "tuff_slab", "tuff_stairs", "tuff_wall", "chiseled_tuff", "polished_tuff", "polished_tuff_slab", "polished_tuff_stairs", "polished_tuff_wall", "tuff_bricks", "tuff_brick_slab", "tuff_brick_stairs", "tuff_brick_wall", "chiseled_tuff_bricks", "dripstone_block", "grass_block", "dirt", "coarse_dirt", "podzol", "rooted_dirt", "mud", "crimson_nylium", "warped_nylium", "cobblestone", "oak_planks", "spruce_planks", "birch_planks", "jungle_planks", "acacia_planks", "cherry_planks", "dark_oak_planks", "mangrove_planks", "bamboo_planks", "crimson_planks", "warped_planks", "bamboo_mosaic", "oak_sapling", "spruce_sapling", "birch_sapling", "jungle_sapling", "acacia_sapling", "cherry_sapling", "dark_oak_sapling", "mangrove_propagule", "bedrock", "sand", "suspicious_sand", "suspicious_gravel", "red_sand", "gravel", "coal_ore", "deepslate_coal_ore", "iron_ore", "deepslate_iron_ore", "copper_ore", "deepslate_copper_ore", "gold_ore", "deepslate_gold_ore", "redstone_ore", "deepslate_redstone_ore", "emerald_ore", "deepslate_emerald_ore", "lapis_ore", "deepslate_lapis_ore", "diamond_ore", "deepslate_diamond_ore", "nether_gold_ore", "nether_quartz_ore", "ancient_debris", "coal_block", "raw_iron_block", "raw_copper_block", "raw_gold_block", "heavy_core", "amethyst_block", "budding_amethyst", "iron_block", "copper_block", "gold_block", "diamond_block", "netherite_block", "exposed_copper", "weathered_copper", "oxidized_copper", "chiseled_copper", "exposed_chiseled_copper", "weathered_chiseled_copper", "oxidized_chiseled_copper", "cut_copper", "exposed_cut_copper", "weathered_cut_copper", "oxidized_cut_copper", "cut_copper_stairs", "exposed_cut_copper_stairs", "weathered_cut_copper_stairs", "oxidized_cut_copper_stairs", "cut_copper_slab", "exposed_cut_copper_slab", "weathered_cut_copper_slab", "oxidized_cut_copper_slab", "waxed_copper_block", "waxed_exposed_copper", "waxed_weathered_copper", "waxed_oxidized_copper", "waxed_chiseled_copper", "waxed_exposed_chiseled_copper", "waxed_weathered_chiseled_copper", "waxed_oxidized_chiseled_copper", "waxed_cut_copper", "waxed_exposed_cut_copper", "waxed_weathered_cut_copper", "waxed_oxidized_cut_copper", "waxed_cut_copper_stairs", "waxed_exposed_cut_copper_stairs", "waxed_weathered_cut_copper_stairs", "waxed_oxidized_cut_copper_stairs", "waxed_cut_copper_slab", "waxed_exposed_cut_copper_slab", "waxed_weathered_cut_copper_slab", "waxed_oxidized_cut_copper_slab", "oak_log", "spruce_log", "birch_log", "jungle_log", "acacia_log", "cherry_log", "dark_oak_log", "mangrove_log", "mangrove_roots", "muddy_mangrove_roots", "crimson_stem", "warped_stem", "bamboo_block", "stripped_oak_log", "stripped_spruce_log", "stripped_birch_log", "stripped_jungle_log", "stripped_acacia_log", "stripped_cherry_log", "stripped_dark_oak_log", "stripped_mangrove_log", "stripped_crimson_stem", "stripped_warped_stem", "stripped_oak_wood", "stripped_spruce_wood", "stripped_birch_wood", "stripped_jungle_wood", "stripped_acacia_wood", "stripped_cherry_wood", "stripped_dark_oak_wood", "stripped_mangrove_wood", "stripped_crimson_hyphae", "stripped_warped_hyphae", "stripped_bamboo_block", "oak_wood", "spruce_wood", "birch_wood", "jungle_wood", "acacia_wood", "cherry_wood", "dark_oak_wood", "mangrove_wood", "crimson_hyphae", "warped_hyphae", "oak_leaves", "spruce_leaves", "birch_leaves", "jungle_leaves", "acacia_leaves", "cherry_leaves", "dark_oak_leaves", "mangrove_leaves", "azalea_leaves", "flowering_azalea_leaves", "sponge", "wet_sponge", "glass", "tinted_glass", "lapis_block", "sandstone", "chiseled_sandstone", "cut_sandstone", "cobweb", "short_grass", "fern", "azalea", "flowering_azalea", "dead_bush", "seagrass", "sea_pickle", "white_wool", "orange_wool", "magenta_wool", "light_blue_wool", "yellow_wool", "lime_wool", "pink_wool", "gray_wool", "light_gray_wool", "cyan_wool", "purple_wool", "blue_wool", "brown_wool", "green_wool", "red_wool", "black_wool", "dandelion", "poppy", "blue_orchid", "allium", "azure_bluet", "red_tulip", "orange_tulip", "white_tulip", "pink_tulip", "oxeye_daisy", "cornflower", "lily_of_the_valley", "wither_rose", "torchflower", "pitcher_plant", "spore_blossom", "brown_mushroom", "red_mushroom", "crimson_fungus", "warped_fungus", "crimson_roots", "warped_roots", "nether_sprouts", "weeping_vines", "twisting_vines", "sugar_cane", "kelp", "moss_carpet", "pink_petals", "moss_block", "hanging_roots", "big_dripleaf", "small_dripleaf", "bamboo", "oak_slab", "spruce_slab", "birch_slab", "jungle_slab", "acacia_slab", "cherry_slab", "dark_oak_slab", "mangrove_slab", "bamboo_slab", "bamboo_mosaic_slab", "crimson_slab", "warped_slab", "stone_slab", "smooth_stone_slab", "sandstone_slab", "cut_sandstone_slab", "petrified_oak_slab", "cobblestone_slab", "brick_slab", "stone_brick_slab", "mud_brick_slab", "nether_brick_slab", "quartz_slab", "red_sandstone_slab", "cut_red_sandstone_slab", "purpur_slab", "prismarine_slab", "prismarine_brick_slab", "dark_prismarine_slab", "smooth_quartz", "smooth_red_sandstone", "smooth_sandstone", "smooth_stone", "bricks", "bookshelf", "chiseled_bookshelf", "decorated_pot", "mossy_cobblestone", "obsidian", "torch", "end_rod", "chorus_plant", "chorus_flower", "purpur_block", "purpur_pillar", "purpur_stairs", "spawner", "chest", "crafting_table", "farmland", "furnace", "ladder", "cobblestone_stairs", "snow", "ice", "snow_block", "cactus", "clay", "jukebox", "oak_fence", "spruce_fence", "birch_fence", "jungle_fence", "acacia_fence", "cherry_fence", "dark_oak_fence", "mangrove_fence", "bamboo_fence", "crimson_fence", "warped_fence", "pumpkin", "carved_pumpkin", "jack_o_lantern", "netherrack", "soul_sand", "soul_soil", "basalt", "polished_basalt", "smooth_basalt", "soul_torch", "glowstone", "infested_stone", "infested_cobblestone", "infested_stone_bricks", "infested_mossy_stone_bricks", "infested_cracked_stone_bricks", "infested_chiseled_stone_bricks", "infested_deepslate", "stone_bricks", "mossy_stone_bricks", "cracked_stone_bricks", "chiseled_stone_bricks", "packed_mud", "mud_bricks", "deepslate_bricks", "cracked_deepslate_bricks", "deepslate_tiles", "cracked_deepslate_tiles", "chiseled_deepslate", "reinforced_deepslate", "brown_mushroom_block", "red_mushroom_block", "mushroom_stem", "iron_bars", "chain", "glass_pane", "melon", "vine", "glow_lichen", "brick_stairs", "stone_brick_stairs", "mud_brick_stairs", "mycelium", "lily_pad", "nether_bricks", "cracked_nether_bricks", "chiseled_nether_bricks", "nether_brick_fence", "nether_brick_stairs", "sculk", "sculk_vein", "sculk_catalyst", "sculk_shrieker", "enchanting_table", "end_portal_frame", "end_stone", "end_stone_bricks", "dragon_egg", "sandstone_stairs", "ender_chest", "emerald_block", "oak_stairs", "spruce_stairs", "birch_stairs", "jungle_stairs", "acacia_stairs", "cherry_stairs", "dark_oak_stairs", "mangrove_stairs", "bamboo_stairs", "bamboo_mosaic_stairs", "crimson_stairs", "warped_stairs", "command_block", "beacon", "cobblestone_wall", "mossy_cobblestone_wall", "brick_wall", "prismarine_wall", "red_sandstone_wall", "mossy_stone_brick_wall", "granite_wall", "stone_brick_wall", "mud_brick_wall", "nether_brick_wall", "andesite_wall", "red_nether_brick_wall", "sandstone_wall", "end_stone_brick_wall", "diorite_wall", "blackstone_wall", "polished_blackstone_wall", "polished_blackstone_brick_wall", "cobbled_deepslate_wall", "polished_deepslate_wall", "deepslate_brick_wall", "deepslate_tile_wall", "anvil", "chipped_anvil", "damaged_anvil", "chiseled_quartz_block", "quartz_block", "quartz_bricks", "quartz_pillar", "quartz_stairs", "white_terracotta", "orange_terracotta", "magenta_terracotta", "light_blue_terracotta", "yellow_terracotta", "lime_terracotta", "pink_terracotta", "gray_terracotta", "light_gray_terracotta", "cyan_terracotta", "purple_terracotta", "blue_terracotta", "brown_terracotta", "green_terracotta", "red_terracotta", "black_terracotta", "barrier", "light", "hay_block", "white_carpet", "orange_carpet", "magenta_carpet", "light_blue_carpet", "yellow_carpet", "lime_carpet", "pink_carpet", "gray_carpet", "light_gray_carpet", "cyan_carpet", "purple_carpet", "blue_carpet", "brown_carpet", "green_carpet", "red_carpet", "black_carpet", "terracotta", "packed_ice", "dirt_path", "sunflower", "lilac", "rose_bush", "peony", "tall_grass", "large_fern", "white_stained_glass", "orange_stained_glass", "magenta_stained_glass", "light_blue_stained_glass", "yellow_stained_glass", "lime_stained_glass", "pink_stained_glass", "gray_stained_glass", "light_gray_stained_glass", "cyan_stained_glass", "purple_stained_glass", "blue_stained_glass", "brown_stained_glass", "green_stained_glass", "red_stained_glass", "black_stained_glass", "white_stained_glass_pane", "orange_stained_glass_pane", "magenta_stained_glass_pane", "light_blue_stained_glass_pane", "yellow_stained_glass_pane", "lime_stained_glass_pane", "pink_stained_glass_pane", "gray_stained_glass_pane", "light_gray_stained_glass_pane", "cyan_stained_glass_pane", "purple_stained_glass_pane", "blue_stained_glass_pane", "brown_stained_glass_pane", "green_stained_glass_pane", "red_stained_glass_pane", "black_stained_glass_pane", "prismarine", "prismarine_bricks", "dark_prismarine", "prismarine_stairs", "prismarine_brick_stairs", "dark_prismarine_stairs", "sea_lantern", "red_sandstone", "chiseled_red_sandstone", "cut_red_sandstone", "red_sandstone_stairs", "repeating_command_block", "chain_command_block", "magma_block", "nether_wart_block", "warped_wart_block", "red_nether_bricks", "bone_block", "structure_void", "shulker_box", "white_shulker_box", "orange_shulker_box", "magenta_shulker_box", "light_blue_shulker_box", "yellow_shulker_box", "lime_shulker_box", "pink_shulker_box", "gray_shulker_box", "light_gray_shulker_box", "cyan_shulker_box", "purple_shulker_box", "blue_shulker_box", "brown_shulker_box", "green_shulker_box", "red_shulker_box", "black_shulker_box", "white_glazed_terracotta", "orange_glazed_terracotta", "magenta_glazed_terracotta", "light_blue_glazed_terracotta", "yellow_glazed_terracotta", "lime_glazed_terracotta", "pink_glazed_terracotta", "gray_glazed_terracotta", "light_gray_glazed_terracotta", "cyan_glazed_terracotta", "purple_glazed_terracotta", "blue_glazed_terracotta", "brown_glazed_terracotta", "green_glazed_terracotta", "red_glazed_terracotta", "black_glazed_terracotta", "white_concrete", "orange_concrete", "magenta_concrete", "light_blue_concrete", "yellow_concrete", "lime_concrete", "pink_concrete", "gray_concrete", "light_gray_concrete", "cyan_concrete", "purple_concrete", "blue_concrete", "brown_concrete", "green_concrete", "red_concrete", "black_concrete", "white_concrete_powder", "orange_concrete_powder", "magenta_concrete_powder", "light_blue_concrete_powder", "yellow_concrete_powder", "lime_concrete_powder", "pink_concrete_powder", "gray_concrete_powder", "light_gray_concrete_powder", "cyan_concrete_powder", "purple_concrete_powder", "blue_concrete_powder", "brown_concrete_powder", "green_concrete_powder", "red_concrete_powder", "black_concrete_powder", "turtle_egg", "sniffer_egg", "dead_tube_coral_block", "dead_brain_coral_block", "dead_bubble_coral_block", "dead_fire_coral_block", "dead_horn_coral_block", "tube_coral_block", "brain_coral_block", "bubble_coral_block", "fire_coral_block", "horn_coral_block", "tube_coral", "brain_coral", "bubble_coral", "fire_coral", "horn_coral", "dead_brain_coral", "dead_bubble_coral", "dead_fire_coral", "dead_horn_coral", "dead_tube_coral", "tube_coral_fan", "brain_coral_fan", "bubble_coral_fan", "fire_coral_fan", "horn_coral_fan", "dead_tube_coral_fan", "dead_brain_coral_fan", "dead_bubble_coral_fan", "dead_fire_coral_fan", "dead_horn_coral_fan", "blue_ice", "conduit", "polished_granite_stairs", "smooth_red_sandstone_stairs", "mossy_stone_brick_stairs", "polished_diorite_stairs", "mossy_cobblestone_stairs", "end_stone_brick_stairs", "stone_stairs", "smooth_sandstone_stairs", "smooth_quartz_stairs", "granite_stairs", "andesite_stairs", "red_nether_brick_stairs", "polished_andesite_stairs", "diorite_stairs", "cobbled_deepslate_stairs", "polished_deepslate_stairs", "deepslate_brick_stairs", "deepslate_tile_stairs", "polished_granite_slab", "smooth_red_sandstone_slab", "mossy_stone_brick_slab", "polished_diorite_slab", "mossy_cobblestone_slab", "end_stone_brick_slab", "smooth_sandstone_slab", "smooth_quartz_slab", "granite_slab", "andesite_slab", "red_nether_brick_slab", "polished_andesite_slab", "diorite_slab", "cobbled_deepslate_slab", "polished_deepslate_slab", "deepslate_brick_slab", "deepslate_tile_slab", "scaffolding", "redstone_torch", "redstone_block", "repeater", "comparator", "piston", "sticky_piston", "slime_block", "honey_block", "observer", "hopper", "dispenser", "dropper", "lectern", "target", "lever", "lightning_rod", "daylight_detector", "sculk_sensor", "calibrated_sculk_sensor", "tripwire_hook", "trapped_chest", "tnt", "redstone_lamp", "note_block", "stone_button", "polished_blackstone_button", "oak_button", "spruce_button", "birch_button", "jungle_button", "acacia_button", "cherry_button", "dark_oak_button", "mangrove_button", "bamboo_button", "crimson_button", "warped_button", "stone_pressure_plate", "polished_blackstone_pressure_plate", "light_weighted_pressure_plate", "heavy_weighted_pressure_plate", "oak_pressure_plate", "spruce_pressure_plate", "birch_pressure_plate", "jungle_pressure_plate", "acacia_pressure_plate", "cherry_pressure_plate", "dark_oak_pressure_plate", "mangrove_pressure_plate", "bamboo_pressure_plate", "crimson_pressure_plate", "warped_pressure_plate", "iron_door", "oak_door", "spruce_door", "birch_door", "jungle_door", "acacia_door", "cherry_door", "dark_oak_door", "mangrove_door", "bamboo_door", "crimson_door", "warped_door", "copper_door", "exposed_copper_door", "weathered_copper_door", "oxidized_copper_door", "waxed_copper_door", "waxed_exposed_copper_door", "waxed_weathered_copper_door", "waxed_oxidized_copper_door", "iron_trapdoor", "oak_trapdoor", "spruce_trapdoor", "birch_trapdoor", "jungle_trapdoor", "acacia_trapdoor", "cherry_trapdoor", "dark_oak_trapdoor", "mangrove_trapdoor", "bamboo_trapdoor", "crimson_trapdoor", "warped_trapdoor", "copper_trapdoor", "exposed_copper_trapdoor", "weathered_copper_trapdoor", "oxidized_copper_trapdoor", "waxed_copper_trapdoor", "waxed_exposed_copper_trapdoor", "waxed_weathered_copper_trapdoor", "waxed_oxidized_copper_trapdoor", "oak_fence_gate", "spruce_fence_gate", "birch_fence_gate", "jungle_fence_gate", "acacia_fence_gate", "cherry_fence_gate", "dark_oak_fence_gate", "mangrove_fence_gate", "bamboo_fence_gate", "crimson_fence_gate", "warped_fence_gate", "powered_rail", "detector_rail", "rail", "activator_rail", "structure_block", "jigsaw", "wheat", "oak_sign", "spruce_sign", "birch_sign", "jungle_sign", "acacia_sign", "cherry_sign", "dark_oak_sign", "mangrove_sign", "bamboo_sign", "crimson_sign", "warped_sign", "oak_hanging_sign", "spruce_hanging_sign", "birch_hanging_sign", "jungle_hanging_sign", "acacia_hanging_sign", "cherry_hanging_sign", "dark_oak_hanging_sign", "mangrove_hanging_sign", "bamboo_hanging_sign", "crimson_hanging_sign", "warped_hanging_sign", "dried_kelp_block", "cake", "white_bed", "orange_bed", "magenta_bed", "light_blue_bed", "yellow_bed", "lime_bed", "pink_bed", "gray_bed", "light_gray_bed", "cyan_bed", "purple_bed", "blue_bed", "brown_bed", "green_bed", "red_bed", "black_bed", "crafter", "nether_wart", "brewing_stand", "cauldron", "flower_pot", "skeleton_skull", "wither_skeleton_skull", "player_head", "zombie_head", "creeper_head", "dragon_head", "piglin_head", "white_banner", "orange_banner", "magenta_banner", "light_blue_banner", "yellow_banner", "lime_banner", "pink_banner", "gray_banner", "light_gray_banner", "cyan_banner", "purple_banner", "blue_banner", "brown_banner", "green_banner", "red_banner", "black_banner", "loom", "composter", "barrel", "smoker", "blast_furnace", "cartography_table", "fletching_table", "grindstone", "smithing_table", "stonecutter", "bell", "lantern", "soul_lantern", "campfire", "soul_campfire", "shroomlight", "bee_nest", "beehive", "honeycomb_block", "lodestone", "crying_obsidian", "blackstone", "blackstone_slab", "blackstone_stairs", "gilded_blackstone", "polished_blackstone", "polished_blackstone_slab", "polished_blackstone_stairs", "chiseled_polished_blackstone", "polished_blackstone_bricks", "polished_blackstone_brick_slab", "polished_blackstone_brick_stairs", "cracked_polished_blackstone_bricks", "respawn_anchor", "candle", "white_candle", "orange_candle", "magenta_candle", "light_blue_candle", "yellow_candle", "lime_candle", "pink_candle", "gray_candle", "light_gray_candle", "cyan_candle", "purple_candle", "blue_candle", "brown_candle", "green_candle", "red_candle", "black_candle", "small_amethyst_bud", "medium_amethyst_bud", "large_amethyst_bud", "amethyst_cluster", "pointed_dripstone", "ochre_froglight", "verdant_froglight", "pearlescent_froglight", "frogspawn", "copper_grate", "exposed_copper_grate", "weathered_copper_grate", "oxidized_copper_grate", "waxed_copper_grate", "waxed_exposed_copper_grate", "waxed_weathered_copper_grate", "waxed_oxidized_copper_grate", "copper_bulb", "exposed_copper_bulb", "weathered_copper_bulb", "oxidized_copper_bulb", "waxed_copper_bulb", "waxed_exposed_copper_bulb", "waxed_weathered_copper_bulb", "waxed_oxidized_copper_bulb", "trial_spawner", "vault", "water", "lava", "tall_seagrass", "piston_head", "moving_piston", "wall_torch", "fire", "soul_fire", "redstone_wire", "oak_wall_sign", "spruce_wall_sign", "birch_wall_sign", "acacia_wall_sign", "cherry_wall_sign", "jungle_wall_sign", "dark_oak_wall_sign", "mangrove_wall_sign", "bamboo_wall_sign", "oak_wall_hanging_sign", "spruce_wall_hanging_sign", "birch_wall_hanging_sign", "acacia_wall_hanging_sign", "cherry_wall_hanging_sign", "jungle_wall_hanging_sign", "dark_oak_wall_hanging_sign", "mangrove_wall_hanging_sign", "crimson_wall_hanging_sign", "warped_wall_hanging_sign", "bamboo_wall_hanging_sign", "redstone_wall_torch", "soul_wall_torch", "nether_portal", "attached_pumpkin_stem", "attached_melon_stem", "pumpkin_stem", "melon_stem", "water_cauldron", "lava_cauldron", "powder_snow_cauldron", "end_portal", "cocoa", "tripwire", "potted_torchflower", "potted_oak_sapling", "potted_spruce_sapling", "potted_birch_sapling", "potted_jungle_sapling", "potted_acacia_sapling", "potted_cherry_sapling", "potted_dark_oak_sapling", "potted_mangrove_propagule", "potted_fern", "potted_dandelion", "potted_poppy", "potted_blue_orchid", "potted_allium", "potted_azure_bluet", "potted_red_tulip", "potted_orange_tulip", "potted_white_tulip", "potted_pink_tulip", "potted_oxeye_daisy", "potted_cornflower", "potted_lily_of_the_valley", "potted_wither_rose", "potted_red_mushroom", "potted_brown_mushroom", "potted_dead_bush", "potted_cactus", "carrots", "potatoes", "skeleton_wall_skull", "wither_skeleton_wall_skull", "zombie_wall_head", "player_wall_head", "creeper_wall_head", "dragon_wall_head", "piglin_wall_head", "white_wall_banner", "orange_wall_banner", "magenta_wall_banner", "light_blue_wall_banner", "yellow_wall_banner", "lime_wall_banner", "pink_wall_banner", "gray_wall_banner", "light_gray_wall_banner", "cyan_wall_banner", "purple_wall_banner", "blue_wall_banner", "brown_wall_banner", "green_wall_banner", "red_wall_banner", "black_wall_banner", "torchflower_crop", "pitcher_crop", "beetroots", "end_gateway", "frosted_ice", "kelp_plant", "dead_tube_coral_wall_fan", "dead_brain_coral_wall_fan", "dead_bubble_coral_wall_fan", "dead_fire_coral_wall_fan", "dead_horn_coral_wall_fan", "tube_coral_wall_fan", "brain_coral_wall_fan", "bubble_coral_wall_fan", "fire_coral_wall_fan", "horn_coral_wall_fan", "bamboo_sapling", "potted_bamboo", "void_air", "cave_air", "bubble_column", "sweet_berry_bush", "weeping_vines_plant", "twisting_vines_plant", "crimson_wall_sign", "warped_wall_sign", "potted_crimson_fungus", "potted_warped_fungus", "potted_crimson_roots", "potted_warped_roots", "candle_cake", "white_candle_cake", "orange_candle_cake", "magenta_candle_cake", "light_blue_candle_cake", "yellow_candle_cake", "lime_candle_cake", "pink_candle_cake", "gray_candle_cake", "light_gray_candle_cake", "cyan_candle_cake", "purple_candle_cake", "blue_candle_cake", "brown_candle_cake", "green_candle_cake", "red_candle_cake", "black_candle_cake", "powder_snow", "cave_vines", "cave_vines_plant", "big_dripleaf_stem", "potted_azalea_bush", "potted_flowering_azalea_bush"];
export const OFFICIAL_1060_SET: ReadonlySet<string> = new Set(OFFICIAL_1060_NAMES);

const DIRECT_RENAMES: ReadonlyArray<readonly [string, string, string]> = [
  ["mangrove_sapling", "mangrove_propagule", "\u30de\u30f3\u30b0\u30ed\u30fc\u30d6\u306e\u80ce\u751f\u82bd"],
  ["crimson_log", "crimson_stem", "\u771f\u7d05\u306e\u5e79"],
  ["warped_log", "warped_stem", "\u6b6a\u3093\u3060\u5e79"],
  ["nether_bricks_fence", "nether_brick_fence", "\u30cd\u30b6\u30fc\u30ec\u30f3\u30ac\u306e\u30d5\u30a7\u30f3\u30b9"],
  ["deepslate_stairs", "cobbled_deepslate_stairs", "\u6df1\u5c64\u5ca9\u306e\u4e38\u77f3\u306e\u968e\u6bb5"],
  ["deepslate_slab", "cobbled_deepslate_slab", "\u6df1\u5c64\u5ca9\u306e\u4e38\u77f3\u306e\u30cf\u30fc\u30d5\u30d6\u30ed\u30c3\u30af"],
  ["deepslate_wall", "cobbled_deepslate_wall", "\u6df1\u5c64\u5ca9\u306e\u4e38\u77f3\u306e\u58c1"],
  ["wheat_crop", "wheat", "\u5c0f\u9ea6"],
  ["portal", "nether_portal", "\u30cd\u30b6\u30fc\u30dd\u30fc\u30bf\u30eb"],
  ["snow_layer", "snow", "\u96ea"],
  ["sculk_block", "sculk", "\u30b9\u30ab\u30eb\u30af"],
  ["bed", "red_bed", "\u8d64\u306e\u30d9\u30c3\u30c9"],
];

const INTERNAL_STATE_NAMES: ReadonlySet<string> = new Set(["unlit_redstone_lamp", "unlit_redstone_torch", "inverted_daylight_detector", "copper_bulb_lit", "exposed_copper_bulb_lit", "weathered_copper_bulb_lit", "oxidized_copper_bulb_lit", "farmland_moist", "unlit_campfire", "ominous_vault", "item_frame"]);

interface RawSpec {
  name: string;
  ja: string;
  color: string;
  pattern: Pattern;
  hardness: number;
  tool?: string;
  tier?: number;
  shape?: Shape;
  solid?: boolean;
  transparent?: boolean;
  light?: number;
  drop?: string;
  stack?: number;
  category?: string;
}

const NEW_OFFICIAL_SPECS: readonly RawSpec[] = [
  {"name": "acacia_fence_gate", "ja": "アカシアのフェンスゲート", "color": "#ba6337", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "acacia_wall_hanging_sign", "ja": "アカシアの壁付き吊り看板", "color": "#ba6337", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "acacia_hanging_sign", "category": "decorations"},
  {"name": "acacia_wall_sign", "ja": "アカシアの壁付き看板", "color": "#ba6337", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "acacia_sign", "category": "decorations"},
  {"name": "acacia_wood", "ja": "アカシアの木", "color": "#676157", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "attached_melon_stem", "ja": "実がなったスイカの茎", "color": "#8c9c42", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "melon_seeds", "category": "nature"},
  {"name": "attached_pumpkin_stem", "ja": "実がなったカボチャの茎", "color": "#8c9c42", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "pumpkin_seeds", "category": "nature"},
  {"name": "bamboo_block", "ja": "竹ブロック", "color": "#6ca338", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "bamboo_button", "ja": "竹のボタン", "color": "#c9b458", "pattern": "planks", "hardness": 0.5, "tool": "axe", "shape": "torch", "solid": false, "transparent": true, "category": "redstone"},
  {"name": "bamboo_door", "ja": "竹のドア", "color": "#c9b458", "pattern": "planks", "hardness": 3, "tool": "axe", "shape": "door", "transparent": true, "category": "building"},
  {"name": "bamboo_fence", "ja": "竹のフェンス", "color": "#c9b458", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "building"},
  {"name": "bamboo_fence_gate", "ja": "竹のフェンスゲート", "color": "#c9b458", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "bamboo_planks", "ja": "竹の板材", "color": "#c9b458", "pattern": "planks", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "bamboo_pressure_plate", "ja": "竹の感圧板", "color": "#c9b458", "pattern": "planks", "hardness": 0.5, "tool": "axe", "shape": "slab", "transparent": true, "category": "redstone"},
  {"name": "bamboo_sapling", "ja": "タケノコ", "color": "#84b04e", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "bamboo", "category": "nature"},
  {"name": "bamboo_slab", "ja": "竹のハーフブロック", "color": "#c9b458", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "slab", "transparent": true, "category": "building"},
  {"name": "bamboo_stairs", "ja": "竹の階段", "color": "#c9b458", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "bamboo_trapdoor", "ja": "竹のトラップドア", "color": "#c9b458", "pattern": "planks", "hardness": 3, "tool": "axe", "shape": "trapdoor", "transparent": true, "category": "building"},
  {"name": "bamboo_wall_hanging_sign", "ja": "竹の壁付き吊り看板", "color": "#c9b458", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "bamboo_hanging_sign", "category": "decorations"},
  {"name": "bamboo_wall_sign", "ja": "竹の壁付き看板", "color": "#c9b458", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "bamboo_sign", "category": "decorations"},
  {"name": "big_dripleaf_stem", "ja": "大きなドリップリーフの茎", "color": "#538c30", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "big_dripleaf", "category": "nature"},
  {"name": "birch_fence_gate", "ja": "シラカバのフェンスゲート", "color": "#cbb783", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "birch_wall_hanging_sign", "ja": "シラカバの壁付き吊り看板", "color": "#cbb783", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "birch_hanging_sign", "category": "decorations"},
  {"name": "birch_wall_sign", "ja": "シラカバの壁付き看板", "color": "#cbb783", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "birch_sign", "category": "decorations"},
  {"name": "birch_wood", "ja": "シラカバの木", "color": "#e0dccb", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "black_candle_cake", "ja": "黒のろうそくが立てられたケーキ", "color": "#151519", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "black_candle", "stack": 1, "category": "decorations"},
  {"name": "black_concrete_powder", "ja": "黒のコンクリートパウダー", "color": "#080a0f", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "black_wall_banner", "ja": "黒の壁掛け旗", "color": "#151519", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "black_banner", "category": "decorations"},
  {"name": "blackstone_slab", "ja": "ブラックストーンのハーフブロック", "color": "#322d33", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "blackstone_stairs", "ja": "ブラックストーンの階段", "color": "#322d33", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "blackstone_wall", "ja": "ブラックストーンの壁", "color": "#322d33", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "blue_candle_cake", "ja": "青のろうそくが立てられたケーキ", "color": "#35399d", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "blue_candle", "stack": 1, "category": "decorations"},
  {"name": "blue_concrete_powder", "ja": "青のコンクリートパウダー", "color": "#2d2f8f", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "blue_wall_banner", "ja": "青の壁掛け旗", "color": "#35399d", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "blue_banner", "category": "decorations"},
  {"name": "brain_coral_wall_fan", "ja": "ノウサンゴの壁扇", "color": "#cf5aa0", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "dead_brain_coral_fan", "category": "nature"},
  {"name": "brick_slab", "ja": "レンガのハーフブロック", "color": "#9a5a48", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "brick_stairs", "ja": "レンガの階段", "color": "#9a5a48", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "brick_wall", "ja": "レンガの壁", "color": "#9a5a48", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "brown_candle_cake", "ja": "茶色のろうそくが立てられたケーキ", "color": "#724829", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "brown_candle", "stack": 1, "category": "decorations"},
  {"name": "brown_concrete_powder", "ja": "茶色のコンクリートパウダー", "color": "#603c20", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "brown_wall_banner", "ja": "茶色の壁掛け旗", "color": "#724829", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "brown_banner", "category": "decorations"},
  {"name": "bubble_column", "ja": "気泡柱", "color": "#3a98d4", "pattern": "water", "hardness": 100, "solid": false, "transparent": true, "shape": "water", "drop": "", "category": "nature"},
  {"name": "bubble_coral_wall_fan", "ja": "ミズタマサンゴの壁扇", "color": "#a52ca2", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "dead_bubble_coral_fan", "category": "nature"},
  {"name": "cake", "ja": "ケーキ", "color": "#f2e6d8", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "drop": "", "stack": 1, "category": "food"},
  {"name": "candle_cake", "ja": "ろうそくが立てられたケーキ", "color": "#e8d8a8", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "candle", "stack": 1, "category": "decorations"},
  {"name": "cave_air", "ja": "洞窟の空気", "color": "#ffffff", "pattern": "misc", "hardness": 0, "solid": false, "transparent": true, "shape": "cube", "drop": "", "stack": 0, "category": "nature"},
  {"name": "cave_vines_plant", "ja": "洞窟のツタの茎", "color": "#668f28", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "light": 14, "drop": "glow_berries", "category": "nature"},
  {"name": "cherry_fence_gate", "ja": "サクラのフェンスゲート", "color": "#e6b4bc", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "cherry_wall_hanging_sign", "ja": "サクラの壁付き吊り看板", "color": "#e6b4bc", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "cherry_hanging_sign", "category": "decorations"},
  {"name": "cherry_wall_sign", "ja": "サクラの壁付き看板", "color": "#e6b4bc", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "cherry_sign", "category": "decorations"},
  {"name": "cherry_wood", "ja": "サクラの木", "color": "#3b222c", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "chipped_anvil", "ja": "欠けた金床", "color": "#585e5b", "pattern": "metal", "hardness": 5.0, "tool": "pickaxe", "tier": 1, "shape": "anvil", "transparent": true, "category": "utility"},
  {"name": "chiseled_nether_bricks", "ja": "模様入りのネザーレンガ", "color": "#3f2127", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "category": "building"},
  {"name": "chiseled_quartz_block", "ja": "模様入りのクォーツブロック", "color": "#e7e2d6", "pattern": "quartz", "hardness": 0.8, "tool": "pickaxe", "tier": 1, "category": "building"},
  {"name": "chiseled_red_sandstone", "ja": "模様入りの赤い砂岩", "color": "#b96a38", "pattern": "stone", "hardness": 0.8, "tool": "pickaxe", "tier": 1, "category": "building"},
  {"name": "cracked_deepslate_bricks", "ja": "ひび割れた深層岩レンガ", "color": "#404245", "pattern": "bricks", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "category": "building"},
  {"name": "cracked_deepslate_tiles", "ja": "ひび割れた深層岩タイル", "color": "#323437", "pattern": "bricks", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "category": "building"},
  {"name": "cracked_polished_blackstone_bricks", "ja": "ひび割れた磨かれたブラックストーンレンガ", "color": "#2a262e", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "category": "building"},
  {"name": "creeper_wall_head", "ja": "壁付きのクリーパーの頭", "color": "#58b048", "pattern": "wool", "hardness": 1.0, "shape": "slab", "transparent": true, "drop": "creeper_head", "category": "decorations"},
  {"name": "crimson_button", "ja": "真紅のボタン", "color": "#6e2640", "pattern": "planks", "hardness": 0.5, "tool": "axe", "shape": "torch", "solid": false, "transparent": true, "category": "redstone"},
  {"name": "crimson_door", "ja": "真紅のドア", "color": "#6e2640", "pattern": "planks", "hardness": 3, "tool": "axe", "shape": "door", "transparent": true, "category": "building"},
  {"name": "crimson_fence", "ja": "真紅のフェンス", "color": "#6e2640", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "building"},
  {"name": "crimson_fence_gate", "ja": "真紅のフェンスゲート", "color": "#6e2640", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "crimson_hyphae", "ja": "真紅の菌糸体", "color": "#5c192b", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "crimson_pressure_plate", "ja": "真紅の感圧板", "color": "#6e2640", "pattern": "planks", "hardness": 0.5, "tool": "axe", "shape": "slab", "transparent": true, "category": "redstone"},
  {"name": "crimson_slab", "ja": "真紅のハーフブロック", "color": "#6e2640", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "slab", "transparent": true, "category": "building"},
  {"name": "crimson_stairs", "ja": "真紅の階段", "color": "#6e2640", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "crimson_trapdoor", "ja": "真紅のトラップドア", "color": "#6e2640", "pattern": "planks", "hardness": 3, "tool": "axe", "shape": "trapdoor", "transparent": true, "category": "building"},
  {"name": "crimson_wall_hanging_sign", "ja": "真紅の壁付き吊り看板", "color": "#6e2640", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "crimson_hanging_sign", "category": "decorations"},
  {"name": "crimson_wall_sign", "ja": "真紅の壁付き看板", "color": "#6e2640", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "crimson_sign", "category": "decorations"},
  {"name": "cut_copper_slab", "ja": "切り込み入りの銅のハーフブロック", "color": "#bf6b4d", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "cut_copper_stairs", "ja": "切り込み入りの銅の階段", "color": "#bf6b4d", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "cut_red_sandstone", "ja": "研がれた赤い砂岩", "color": "#c2713d", "pattern": "stone", "hardness": 0.8, "tool": "pickaxe", "tier": 1, "category": "building"},
  {"name": "cut_red_sandstone_slab", "ja": "研がれた赤い砂岩のハーフブロック", "color": "#c2713d", "pattern": "stone", "hardness": 0.8, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "cut_sandstone_slab", "ja": "研がれた砂岩のハーフブロック", "color": "#e4d9aa", "pattern": "stone", "hardness": 0.8, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "cyan_candle_cake", "ja": "青緑のろうそくが立てられたケーキ", "color": "#158a91", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "cyan_candle", "stack": 1, "category": "decorations"},
  {"name": "cyan_concrete_powder", "ja": "青緑のコンクリートパウダー", "color": "#157788", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "cyan_wall_banner", "ja": "青緑の壁掛け旗", "color": "#158a91", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "cyan_banner", "category": "decorations"},
  {"name": "damaged_anvil", "ja": "壊れかけの金床", "color": "#505552", "pattern": "metal", "hardness": 5.0, "tool": "pickaxe", "tier": 1, "shape": "anvil", "transparent": true, "category": "utility"},
  {"name": "dark_oak_fence_gate", "ja": "ダークオークのフェンスゲート", "color": "#4a3219", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "dark_oak_wall_hanging_sign", "ja": "ダークオークの壁付き吊り看板", "color": "#4a3219", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "dark_oak_hanging_sign", "category": "decorations"},
  {"name": "dark_oak_wall_sign", "ja": "ダークオークの壁付き看板", "color": "#4a3219", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "dark_oak_sign", "category": "decorations"},
  {"name": "dark_oak_wood", "ja": "ダークオークの木", "color": "#3c2e1d", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "dark_prismarine_slab", "ja": "ダークプリズマリンのハーフブロック", "color": "#335b4f", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "dark_prismarine_stairs", "ja": "ダークプリズマリンの階段", "color": "#335b4f", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "dead_brain_coral", "ja": "死んだノウサンゴ", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "dead_brain_coral_wall_fan", "ja": "死んだノウサンゴの壁扇", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "dead_bubble_coral", "ja": "死んだミズタマサンゴ", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "dead_bubble_coral_wall_fan", "ja": "死んだミズタマサンゴの壁扇", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "dead_fire_coral", "ja": "死んだミレサンゴ", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "dead_fire_coral_wall_fan", "ja": "死んだミレサンゴの壁扇", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "dead_horn_coral", "ja": "死んだシカツノサンゴ", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "dead_horn_coral_wall_fan", "ja": "死んだシカツノサンゴの壁扇", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "dead_tube_coral", "ja": "死んだクダサンゴ", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "dead_tube_coral_wall_fan", "ja": "死んだクダサンゴの壁扇", "color": "#837c77", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "deepslate_brick_slab", "ja": "深層岩レンガのハーフブロック", "color": "#46484b", "pattern": "bricks", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "deepslate_brick_stairs", "ja": "深層岩レンガの階段", "color": "#46484b", "pattern": "bricks", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "deepslate_brick_wall", "ja": "深層岩レンガの壁", "color": "#46484b", "pattern": "bricks", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "deepslate_tile_slab", "ja": "深層岩タイルのハーフブロック", "color": "#37393c", "pattern": "bricks", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "deepslate_tile_stairs", "ja": "深層岩タイルの階段", "color": "#37393c", "pattern": "bricks", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "deepslate_tile_wall", "ja": "深層岩タイルの壁", "color": "#37393c", "pattern": "bricks", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "dragon_wall_head", "ja": "壁付きのドラゴンの頭", "color": "#28222e", "pattern": "obsidian", "hardness": 1.0, "shape": "dragon_head", "transparent": true, "drop": "dragon_head", "category": "decorations"},
  {"name": "exposed_cut_copper_slab", "ja": "風化した切り込み入りの銅のハーフブロック", "color": "#a17e68", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "exposed_cut_copper_stairs", "ja": "風化した切り込み入りの銅の階段", "color": "#a17e68", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "fire_coral_wall_fan", "ja": "ミレサンゴの壁扇", "color": "#a6262f", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "dead_fire_coral_fan", "category": "nature"},
  {"name": "flower_pot", "ja": "植木鉢", "color": "#8f4c36", "pattern": "bricks", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "category": "decorations"},
  {"name": "frogspawn", "ja": "カエルの卵", "color": "#6b5e4c", "pattern": "plant", "hardness": 0, "shape": "lily", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "gray_candle_cake", "ja": "灰色のろうそくが立てられたケーキ", "color": "#3f4448", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "gray_candle", "stack": 1, "category": "decorations"},
  {"name": "gray_concrete_powder", "ja": "灰色のコンクリートパウダー", "color": "#373a3e", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "gray_wall_banner", "ja": "灰色の壁掛け旗", "color": "#3f4448", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "gray_banner", "category": "decorations"},
  {"name": "green_candle_cake", "ja": "緑のろうそくが立てられたケーキ", "color": "#556e1c", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "green_candle", "stack": 1, "category": "decorations"},
  {"name": "green_concrete_powder", "ja": "緑のコンクリートパウダー", "color": "#495b24", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "green_wall_banner", "ja": "緑の壁掛け旗", "color": "#556e1c", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "green_banner", "category": "decorations"},
  {"name": "heavy_core", "ja": "ヘビーコア", "color": "#5a5d6b", "pattern": "metal", "hardness": 10.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "utility"},
  {"name": "heavy_weighted_pressure_plate", "ja": "重量用感圧板", "color": "#dcdcdc", "pattern": "metal", "hardness": 0.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "redstone"},
  {"name": "honeycomb_block", "ja": "ハニカムブロック", "color": "#e8a832", "pattern": "wool", "hardness": 0.6, "category": "decorations"},
  {"name": "horn_coral_wall_fan", "ja": "シカツノサンゴの壁扇", "color": "#d4c33f", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "dead_horn_coral_fan", "category": "nature"},
  {"name": "iron_trapdoor", "ja": "鉄のトラップドア", "color": "#c4cbc7", "pattern": "metal", "hardness": 5, "tool": "pickaxe", "tier": 1, "shape": "trapdoor", "transparent": true, "category": "redstone"},
  {"name": "jack_o_lantern", "ja": "ジャック・オ・ランタン", "color": "#e89832", "pattern": "bark", "hardness": 1.0, "tool": "axe", "light": 15, "category": "decorations"},
  {"name": "jungle_fence_gate", "ja": "ジャングルのフェンスゲート", "color": "#a67754", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "jungle_wall_hanging_sign", "ja": "ジャングルの壁付き吊り看板", "color": "#a67754", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "jungle_hanging_sign", "category": "decorations"},
  {"name": "jungle_wall_sign", "ja": "ジャングルの壁付き看板", "color": "#a67754", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "jungle_sign", "category": "decorations"},
  {"name": "jungle_wood", "ja": "ジャングルの木", "color": "#574429", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "kelp_plant", "ja": "コンブの茎", "color": "#5e9434", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "kelp", "category": "nature"},
  {"name": "lava_cauldron", "ja": "溶岩入りの大釜", "color": "#f88720", "pattern": "metal", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "transparent": true, "light": 15, "drop": "cauldron", "category": "utility"},
  {"name": "light_blue_candle_cake", "ja": "空色のろうそくが立てられたケーキ", "color": "#3aafd9", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "light_blue_candle", "stack": 1, "category": "decorations"},
  {"name": "light_blue_concrete_powder", "ja": "空色のコンクリートパウダー", "color": "#2389c7", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "light_blue_wall_banner", "ja": "空色の壁掛け旗", "color": "#3aafd9", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "light_blue_banner", "category": "decorations"},
  {"name": "light_gray_candle_cake", "ja": "薄灰色のろうそくが立てられたケーキ", "color": "#8e8e87", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "light_gray_candle", "stack": 1, "category": "decorations"},
  {"name": "light_gray_concrete_powder", "ja": "薄灰色のコンクリートパウダー", "color": "#7d7d73", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "light_gray_wall_banner", "ja": "薄灰色の壁掛け旗", "color": "#8e8e87", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "light_gray_banner", "category": "decorations"},
  {"name": "light_weighted_pressure_plate", "ja": "軽量用感圧板", "color": "#f6d33c", "pattern": "metal", "hardness": 0.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "redstone"},
  {"name": "lilac", "ja": "ライラック", "color": "#c28bd4", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "category": "nature"},
  {"name": "lime_candle_cake", "ja": "黄緑のろうそくが立てられたケーキ", "color": "#70b91a", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "lime_candle", "stack": 1, "category": "decorations"},
  {"name": "lime_concrete_powder", "ja": "黄緑のコンクリートパウダー", "color": "#5ea918", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "lime_wall_banner", "ja": "黄緑の壁掛け旗", "color": "#70b91a", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "lime_banner", "category": "decorations"},
  {"name": "magenta_candle_cake", "ja": "赤紫のろうそくが立てられたケーキ", "color": "#be45b4", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "magenta_candle", "stack": 1, "category": "decorations"},
  {"name": "magenta_concrete_powder", "ja": "赤紫のコンクリートパウダー", "color": "#a9309f", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "magenta_wall_banner", "ja": "赤紫の壁掛け旗", "color": "#be45b4", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "magenta_banner", "category": "decorations"},
  {"name": "mangrove_button", "ja": "マングローブのボタン", "color": "#7a362e", "pattern": "planks", "hardness": 0.5, "tool": "axe", "shape": "torch", "solid": false, "transparent": true, "category": "redstone"},
  {"name": "mangrove_door", "ja": "マングローブのドア", "color": "#7a362e", "pattern": "planks", "hardness": 3, "tool": "axe", "shape": "door", "transparent": true, "category": "building"},
  {"name": "mangrove_fence", "ja": "マングローブのフェンス", "color": "#7a362e", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "building"},
  {"name": "mangrove_fence_gate", "ja": "マングローブのフェンスゲート", "color": "#7a362e", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "mangrove_pressure_plate", "ja": "マングローブの感圧板", "color": "#7a362e", "pattern": "planks", "hardness": 0.5, "tool": "axe", "shape": "slab", "transparent": true, "category": "redstone"},
  {"name": "mangrove_slab", "ja": "マングローブのハーフブロック", "color": "#7a362e", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "slab", "transparent": true, "category": "building"},
  {"name": "mangrove_stairs", "ja": "マングローブの階段", "color": "#7a362e", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "mangrove_trapdoor", "ja": "マングローブのトラップドア", "color": "#7a362e", "pattern": "planks", "hardness": 3, "tool": "axe", "shape": "trapdoor", "transparent": true, "category": "building"},
  {"name": "mangrove_wall_hanging_sign", "ja": "マングローブの壁付き吊り看板", "color": "#7a362e", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "mangrove_hanging_sign", "category": "decorations"},
  {"name": "mangrove_wall_sign", "ja": "マングローブの壁付き看板", "color": "#7a362e", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "mangrove_sign", "category": "decorations"},
  {"name": "mangrove_wood", "ja": "マングローブの木", "color": "#544339", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "mossy_cobblestone_slab", "ja": "苔むした丸石のハーフブロック", "color": "#798474", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "mossy_cobblestone_stairs", "ja": "苔むした丸石の階段", "color": "#798474", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "mossy_cobblestone_wall", "ja": "苔むした丸石の壁", "color": "#798474", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "mossy_stone_brick_slab", "ja": "苔むした石レンガのハーフブロック", "color": "#838c7c", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "mossy_stone_brick_stairs", "ja": "苔むした石レンガの階段", "color": "#838c7c", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "mossy_stone_brick_wall", "ja": "苔むした石レンガの壁", "color": "#838c7c", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "mud_brick_slab", "ja": "泥レンガのハーフブロック", "color": "#8a6a4f", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "mud_brick_stairs", "ja": "泥レンガの階段", "color": "#8a6a4f", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "mud_brick_wall", "ja": "泥レンガの壁", "color": "#8a6a4f", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "oak_fence_gate", "ja": "オークのフェンスゲート", "color": "#b8945f", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "oak_wall_hanging_sign", "ja": "オークの壁付き吊り看板", "color": "#b8945f", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "oak_hanging_sign", "category": "decorations"},
  {"name": "oak_wall_sign", "ja": "オークの壁付き看板", "color": "#b8945f", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "oak_sign", "category": "decorations"},
  {"name": "oak_wood", "ja": "オークの木", "color": "#6b5130", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "ochre_froglight", "ja": "黄土色のフロッグライト", "color": "#f5e39e", "pattern": "quartz", "hardness": 0.3, "light": 15, "category": "decorations"},
  {"name": "orange_candle_cake", "ja": "橙色のろうそくが立てられたケーキ", "color": "#f17614", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "orange_candle", "stack": 1, "category": "decorations"},
  {"name": "orange_concrete_powder", "ja": "橙色のコンクリートパウダー", "color": "#e06101", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "orange_wall_banner", "ja": "橙色の壁掛け旗", "color": "#f17614", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "orange_banner", "category": "decorations"},
  {"name": "oxidized_cut_copper_slab", "ja": "酸化した切り込み入りの銅のハーフブロック", "color": "#52a384", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "oxidized_cut_copper_stairs", "ja": "酸化した切り込み入りの銅の階段", "color": "#52a384", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "pearlescent_froglight", "ja": "真珠色のフロッグライト", "color": "#f0c4eb", "pattern": "quartz", "hardness": 0.3, "light": 15, "category": "decorations"},
  {"name": "peony", "ja": "ボタン", "color": "#f09ec4", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "category": "nature"},
  {"name": "petrified_oak_slab", "ja": "石化したオークのハーフブロック", "color": "#b8945f", "pattern": "planks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "piglin_wall_head", "ja": "壁付きのピグリンの頭", "color": "#e3a38c", "pattern": "wool", "hardness": 1.0, "shape": "slab", "transparent": true, "drop": "piglin_head", "category": "decorations"},
  {"name": "pink_candle_cake", "ja": "桃色のろうそくが立てられたケーキ", "color": "#ee8dac", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "pink_candle", "stack": 1, "category": "decorations"},
  {"name": "pink_concrete_powder", "ja": "桃色のコンクリートパウダー", "color": "#d6658f", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "pink_wall_banner", "ja": "桃色の壁掛け旗", "color": "#ee8dac", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "pink_banner", "category": "decorations"},
  {"name": "pitcher_crop", "ja": "ウツボカズラの芽", "color": "#6a8f48", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "pitcher_plant", "category": "nature"},
  {"name": "player_head", "ja": "プレイヤーの頭", "color": "#c6966b", "pattern": "wool", "hardness": 1.0, "shape": "slab", "transparent": true, "category": "decorations"},
  {"name": "player_wall_head", "ja": "壁付きのプレイヤーの頭", "color": "#c6966b", "pattern": "wool", "hardness": 1.0, "shape": "slab", "transparent": true, "drop": "player_head", "category": "decorations"},
  {"name": "polished_andesite_slab", "ja": "磨かれた安山岩のハーフブロック", "color": "#9a9f94", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "polished_andesite_stairs", "ja": "磨かれた安山岩の階段", "color": "#9a9f94", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "polished_basalt", "ja": "磨かれた玄武岩", "color": "#58585e", "pattern": "deepslate", "hardness": 1.25, "tool": "pickaxe", "tier": 1, "category": "building"},
  {"name": "polished_blackstone_brick_slab", "ja": "磨かれたブラックストーンレンガのハーフブロック", "color": "#2f2b33", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "polished_blackstone_brick_stairs", "ja": "磨かれたブラックストーンレンガの階段", "color": "#2f2b33", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "polished_blackstone_brick_wall", "ja": "磨かれたブラックストーンレンガの壁", "color": "#2f2b33", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "polished_blackstone_button", "ja": "磨かれたブラックストーンのボタン", "color": "#35313a", "pattern": "stone", "hardness": 0.5, "tool": "pickaxe", "tier": 1, "shape": "torch", "solid": false, "transparent": true, "category": "redstone"},
  {"name": "polished_blackstone_pressure_plate", "ja": "磨かれたブラックストーンの感圧板", "color": "#35313a", "pattern": "stone", "hardness": 0.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "redstone"},
  {"name": "polished_blackstone_slab", "ja": "磨かれたブラックストーンのハーフブロック", "color": "#35313a", "pattern": "stone", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "polished_blackstone_stairs", "ja": "磨かれたブラックストーンの階段", "color": "#35313a", "pattern": "stone", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "polished_blackstone_wall", "ja": "磨かれたブラックストーンの壁", "color": "#35313a", "pattern": "stone", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "polished_deepslate_slab", "ja": "磨かれた深層岩のハーフブロック", "color": "#4a4c4f", "pattern": "deepslate", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "polished_deepslate_stairs", "ja": "磨かれた深層岩の階段", "color": "#4a4c4f", "pattern": "deepslate", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "polished_deepslate_wall", "ja": "磨かれた深層岩の壁", "color": "#4a4c4f", "pattern": "deepslate", "hardness": 3.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "polished_diorite_slab", "ja": "磨かれた閃緑岩のハーフブロック", "color": "#cfcec6", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "polished_diorite_stairs", "ja": "磨かれた閃緑岩の階段", "color": "#cfcec6", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "polished_granite_slab", "ja": "磨かれた花崗岩のハーフブロック", "color": "#a8826f", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "polished_granite_stairs", "ja": "磨かれた花崗岩の階段", "color": "#a8826f", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "polished_tuff_slab", "ja": "磨かれた凝灰岩のハーフブロック", "color": "#71776b", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "polished_tuff_stairs", "ja": "磨かれた凝灰岩の階段", "color": "#71776b", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "polished_tuff_wall", "ja": "磨かれた凝灰岩の壁", "color": "#71776b", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "potted_acacia_sapling", "ja": "植えられたアカシアの苗木", "color": "#8b9b49", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "acacia_sapling", "category": "decorations"},
  {"name": "potted_allium", "ja": "植えられたアリウム", "color": "#b07bd0", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "allium", "category": "decorations"},
  {"name": "potted_azalea_bush", "ja": "植えられたツツジ", "color": "#4f7d35", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "azalea", "category": "decorations"},
  {"name": "potted_azure_bluet", "ja": "植えられたヒナソウ", "color": "#e9eef0", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "azure_bluet", "category": "decorations"},
  {"name": "potted_bamboo", "ja": "植えられた竹", "color": "#79a64a", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "bamboo", "category": "decorations"},
  {"name": "potted_birch_sapling", "ja": "植えられたシラカバの苗木", "color": "#86a94e", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "birch_sapling", "category": "decorations"},
  {"name": "potted_blue_orchid", "ja": "植えられたヒスイラン", "color": "#3aa6c9", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "blue_orchid", "category": "decorations"},
  {"name": "potted_cactus", "ja": "植えられたサボテン", "color": "#558434", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "cactus", "category": "decorations"},
  {"name": "potted_cherry_sapling", "ja": "植えられたサクラの苗木", "color": "#e5a9ba", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "cherry_sapling", "category": "decorations"},
  {"name": "potted_cornflower", "ja": "植えられたヤグルマギク", "color": "#4e74d4", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "cornflower", "category": "decorations"},
  {"name": "potted_crimson_fungus", "ja": "植えられた真紅のキノコ", "color": "#a03a2a", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "crimson_fungus", "category": "decorations"},
  {"name": "potted_crimson_roots", "ja": "植えられた真紅の根", "color": "#8a2430", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "crimson_roots", "category": "decorations"},
  {"name": "potted_dandelion", "ja": "植えられたタンポポ", "color": "#f1ce49", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "dandelion", "category": "decorations"},
  {"name": "potted_dark_oak_sapling", "ja": "植えられたダークオークの苗木", "color": "#456d30", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "dark_oak_sapling", "category": "decorations"},
  {"name": "potted_dead_bush", "ja": "植えられた枯れ木", "color": "#8b693c", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "dead_bush", "category": "decorations"},
  {"name": "potted_fern", "ja": "植えられたシダ", "color": "#5d8e3e", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "fern", "category": "decorations"},
  {"name": "potted_flowering_azalea_bush", "ja": "植えられた開花したツツジ", "color": "#b06a9a", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "flowering_azalea", "category": "decorations"},
  {"name": "potted_jungle_sapling", "ja": "植えられたジャングルの苗木", "color": "#4f8a3b", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "jungle_sapling", "category": "decorations"},
  {"name": "potted_lily_of_the_valley", "ja": "植えられたスズラン", "color": "#f3f5f0", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "lily_of_the_valley", "category": "decorations"},
  {"name": "potted_mangrove_propagule", "ja": "植えられたマングローブの胎生芽", "color": "#5d853e", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "mangrove_propagule", "category": "decorations"},
  {"name": "potted_oak_sapling", "ja": "植えられたオークの苗木", "color": "#6e963f", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "oak_sapling", "category": "decorations"},
  {"name": "potted_orange_tulip", "ja": "植えられた橙色のチューリップ", "color": "#e57c35", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "orange_tulip", "category": "decorations"},
  {"name": "potted_oxeye_daisy", "ja": "植えられたフランスギク", "color": "#f3f1e4", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "oxeye_daisy", "category": "decorations"},
  {"name": "potted_pink_tulip", "ja": "植えられた桃色のチューリップ", "color": "#e89cb8", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "pink_tulip", "category": "decorations"},
  {"name": "potted_poppy", "ja": "植えられたポピー", "color": "#dc5540", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "poppy", "category": "decorations"},
  {"name": "potted_red_tulip", "ja": "植えられた赤いチューリップ", "color": "#d8382c", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "red_tulip", "category": "decorations"},
  {"name": "potted_spruce_sapling", "ja": "植えられたトウヒの苗木", "color": "#426b45", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "spruce_sapling", "category": "decorations"},
  {"name": "potted_torchflower", "ja": "植えられたトーチフラワー", "color": "#e4a34c", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "torchflower", "category": "decorations"},
  {"name": "potted_warped_fungus", "ja": "植えられた歪んだキノコ", "color": "#3aa89a", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "warped_fungus", "category": "decorations"},
  {"name": "potted_warped_roots", "ja": "植えられた歪んだ根", "color": "#2a8a7a", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "warped_roots", "category": "decorations"},
  {"name": "potted_white_tulip", "ja": "植えられた白いチューリップ", "color": "#f0eee6", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "white_tulip", "category": "decorations"},
  {"name": "potted_wither_rose", "ja": "植えられたウィザーローズ", "color": "#2a2426", "pattern": "plant", "hardness": 0, "shape": "torch", "solid": true, "transparent": true, "drop": "wither_rose", "category": "decorations"},
  {"name": "powder_snow_cauldron", "ja": "粉雪入りの大釜", "color": "#f4fafe", "pattern": "metal", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "transparent": true, "drop": "cauldron", "category": "utility"},
  {"name": "prismarine_brick_slab", "ja": "プリズマリンレンガのハーフブロック", "color": "#63ab9e", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "prismarine_brick_stairs", "ja": "プリズマリンレンガの階段", "color": "#63ab9e", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "prismarine_slab", "ja": "プリズマリンのハーフブロック", "color": "#6caa9d", "pattern": "prismarine", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "prismarine_stairs", "ja": "プリズマリンの階段", "color": "#6caa9d", "pattern": "prismarine", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "prismarine_wall", "ja": "プリズマリンの壁", "color": "#6caa9d", "pattern": "prismarine", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "purple_candle_cake", "ja": "紫のろうそくが立てられたケーキ", "color": "#7a2aad", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "purple_candle", "stack": 1, "category": "decorations"},
  {"name": "purple_concrete_powder", "ja": "紫のコンクリートパウダー", "color": "#64209c", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "purple_wall_banner", "ja": "紫の壁掛け旗", "color": "#7a2aad", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "purple_banner", "category": "decorations"},
  {"name": "raw_gold_block", "ja": "金の原石ブロック", "color": "#dec36e", "pattern": "ore", "hardness": 5.0, "tool": "pickaxe", "tier": 3, "category": "building"},
  {"name": "red_candle_cake", "ja": "赤のろうそくが立てられたケーキ", "color": "#a12823", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "red_candle", "stack": 1, "category": "decorations"},
  {"name": "red_concrete_powder", "ja": "赤のコンクリートパウダー", "color": "#8e2121", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "red_nether_brick_slab", "ja": "赤いネザーレンガのハーフブロック", "color": "#46070a", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "red_nether_brick_stairs", "ja": "赤いネザーレンガの階段", "color": "#46070a", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "red_nether_brick_wall", "ja": "赤いネザーレンガの壁", "color": "#46070a", "pattern": "bricks", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "red_wall_banner", "ja": "赤の壁掛け旗", "color": "#a12823", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "red_banner", "category": "decorations"},
  {"name": "redstone_wall_torch", "ja": "壁付きレッドストーントーチ", "color": "#e0463a", "pattern": "torch", "hardness": 0, "shape": "torch", "solid": false, "transparent": true, "light": 7, "drop": "redstone_torch", "category": "redstone"},
  {"name": "rose_bush", "ja": "バラの低木", "color": "#b82428", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "category": "nature"},
  {"name": "sculk_vein", "ja": "スカルクヴェイン", "color": "#0d3b47", "pattern": "obsidian", "hardness": 0.2, "tool": "hoe", "shape": "lily", "solid": false, "transparent": true, "drop": "", "category": "nature"},
  {"name": "skeleton_wall_skull", "ja": "壁付きのスケルトンの頭蓋骨", "color": "#d4d2c8", "pattern": "stone", "hardness": 1.0, "shape": "slab", "transparent": true, "drop": "skeleton_skull", "category": "decorations"},
  {"name": "smooth_quartz_slab", "ja": "滑らかなクォーツのハーフブロック", "color": "#ece6da", "pattern": "quartz", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "smooth_quartz_stairs", "ja": "滑らかなクォーツの階段", "color": "#ece6da", "pattern": "quartz", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "smooth_red_sandstone", "ja": "滑らかな赤い砂岩", "color": "#c2713d", "pattern": "sand", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "category": "building"},
  {"name": "smooth_red_sandstone_slab", "ja": "滑らかな赤い砂岩のハーフブロック", "color": "#c2713d", "pattern": "sand", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "smooth_red_sandstone_stairs", "ja": "滑らかな赤い砂岩の階段", "color": "#c2713d", "pattern": "sand", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "smooth_sandstone_slab", "ja": "滑らかな砂岩のハーフブロック", "color": "#e3d7a7", "pattern": "sand", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "smooth_sandstone_stairs", "ja": "滑らかな砂岩の階段", "color": "#e3d7a7", "pattern": "sand", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "smooth_stone_slab", "ja": "滑らかな石のハーフブロック", "color": "#a2a39c", "pattern": "stone", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "sniffer_egg", "ja": "スニッファーの卵", "color": "#8c3b35", "pattern": "terracotta", "hardness": 0.5, "shape": "slab", "transparent": true, "category": "nature"},
  {"name": "soul_wall_torch", "ja": "壁付き魂の松明", "color": "#4fd8e8", "pattern": "torch", "hardness": 0, "shape": "torch", "solid": false, "transparent": true, "light": 10, "drop": "soul_torch", "category": "utility"},
  {"name": "spruce_fence_gate", "ja": "トウヒのフェンスゲート", "color": "#785836", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "spruce_wall_hanging_sign", "ja": "トウヒの壁付き吊り看板", "color": "#785836", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "spruce_hanging_sign", "category": "decorations"},
  {"name": "spruce_wall_sign", "ja": "トウヒの壁付き看板", "color": "#785836", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "spruce_sign", "category": "decorations"},
  {"name": "spruce_wood", "ja": "トウヒの木", "color": "#3b2714", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stone_button", "ja": "石のボタン", "color": "#92938a", "pattern": "stone", "hardness": 0.5, "tool": "pickaxe", "tier": 1, "shape": "torch", "solid": false, "transparent": true, "category": "redstone"},
  {"name": "stone_pressure_plate", "ja": "石の感圧板", "color": "#92938a", "pattern": "stone", "hardness": 0.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "redstone"},
  {"name": "stone_slab", "ja": "石のハーフブロック", "color": "#92938a", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "stone_stairs", "ja": "石の階段", "color": "#92938a", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "stripped_acacia_log", "ja": "樹皮を剥いだアカシアの原木", "color": "#ba6337", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_acacia_wood", "ja": "樹皮を剥いだアカシアの木", "color": "#ba6337", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_bamboo_block", "ja": "表皮を剥いだ竹ブロック", "color": "#c9b458", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_birch_log", "ja": "樹皮を剥いだシラカバの原木", "color": "#cbb783", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_birch_wood", "ja": "樹皮を剥いだシラカバの木", "color": "#cbb783", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_cherry_log", "ja": "樹皮を剥いだサクラの原木", "color": "#e6b4bc", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_cherry_wood", "ja": "樹皮を剥いだサクラの木", "color": "#e6b4bc", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_crimson_hyphae", "ja": "表皮を剥いだ真紅の菌糸体", "color": "#6e2640", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_crimson_stem", "ja": "表皮を剥いだ真紅の幹", "color": "#6e2640", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_dark_oak_log", "ja": "樹皮を剥いだダークオークの原木", "color": "#4a3219", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_dark_oak_wood", "ja": "樹皮を剥いだダークオークの木", "color": "#4a3219", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_jungle_log", "ja": "樹皮を剥いだジャングルの原木", "color": "#a67754", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_jungle_wood", "ja": "樹皮を剥いだジャングルの木", "color": "#a67754", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_mangrove_log", "ja": "樹皮を剥いだマングローブの原木", "color": "#7a362e", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_mangrove_wood", "ja": "樹皮を剥いだマングローブの木", "color": "#7a362e", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_oak_log", "ja": "樹皮を剥いだオークの原木", "color": "#b8945f", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_oak_wood", "ja": "樹皮を剥いだオークの木", "color": "#b8945f", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_spruce_log", "ja": "樹皮を剥いだトウヒの原木", "color": "#785836", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_spruce_wood", "ja": "樹皮を剥いだトウヒの木", "color": "#785836", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_warped_hyphae", "ja": "表皮を剥いだ歪んだの菌糸体", "color": "#28756f", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "stripped_warped_stem", "ja": "表皮を剥いだ歪んだの幹", "color": "#28756f", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "structure_void", "ja": "ストラクチャーヴォイド", "color": "#e06666", "pattern": "glass", "hardness": 0, "solid": false, "transparent": true, "shape": "cube", "drop": "", "category": "utility"},
  {"name": "tall_seagrass", "ja": "背の高い海草", "color": "#458e3e", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "seagrass", "category": "nature"},
  {"name": "torchflower_crop", "ja": "トーチフラワーの芽", "color": "#5e9642", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "torchflower_seeds", "category": "nature"},
  {"name": "tube_coral_wall_fan", "ja": "クダサンゴの壁扇", "color": "#3258c9", "pattern": "plant", "hardness": 0, "shape": "pane", "solid": false, "transparent": true, "drop": "dead_tube_coral_fan", "category": "nature"},
  {"name": "tuff_brick_slab", "ja": "凝灰岩レンガのハーフブロック", "color": "#6e7368", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "tuff_brick_stairs", "ja": "凝灰岩レンガの階段", "color": "#6e7368", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "tuff_brick_wall", "ja": "凝灰岩レンガの壁", "color": "#6e7368", "pattern": "bricks", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "tuff_slab", "ja": "凝灰岩のハーフブロック", "color": "#7d8273", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "tuff_stairs", "ja": "凝灰岩の階段", "color": "#7d8273", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "tuff_wall", "ja": "凝灰岩の壁", "color": "#7d8273", "pattern": "stone", "hardness": 1.5, "tool": "pickaxe", "tier": 1, "shape": "fence", "transparent": true, "category": "building"},
  {"name": "twisting_vines_plant", "ja": "ねじれツタの茎", "color": "#248f7e", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "twisting_vines", "category": "nature"},
  {"name": "verdant_froglight", "ja": "新緑色のフロッグライト", "color": "#b8f2be", "pattern": "quartz", "hardness": 0.3, "light": 15, "category": "decorations"},
  {"name": "void_air", "ja": "奈落の空気", "color": "#ffffff", "pattern": "misc", "hardness": 0, "solid": false, "transparent": true, "shape": "cube", "drop": "", "stack": 0, "category": "nature"},
  {"name": "wall_torch", "ja": "壁付き松明", "color": "#f4be54", "pattern": "torch", "hardness": 0, "shape": "torch", "solid": false, "transparent": true, "light": 14, "drop": "torch", "category": "utility"},
  {"name": "warped_button", "ja": "歪んだのボタン", "color": "#28756f", "pattern": "planks", "hardness": 0.5, "tool": "axe", "shape": "torch", "solid": false, "transparent": true, "category": "redstone"},
  {"name": "warped_door", "ja": "歪んだのドア", "color": "#28756f", "pattern": "planks", "hardness": 3, "tool": "axe", "shape": "door", "transparent": true, "category": "building"},
  {"name": "warped_fence", "ja": "歪んだのフェンス", "color": "#28756f", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "building"},
  {"name": "warped_fence_gate", "ja": "歪んだのフェンスゲート", "color": "#28756f", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "fence", "transparent": true, "category": "redstone"},
  {"name": "warped_hyphae", "ja": "歪んだの菌糸体", "color": "#3a2542", "pattern": "bark", "hardness": 2, "tool": "axe", "category": "building"},
  {"name": "warped_pressure_plate", "ja": "歪んだの感圧板", "color": "#28756f", "pattern": "planks", "hardness": 0.5, "tool": "axe", "shape": "slab", "transparent": true, "category": "redstone"},
  {"name": "warped_slab", "ja": "歪んだのハーフブロック", "color": "#28756f", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "slab", "transparent": true, "category": "building"},
  {"name": "warped_stairs", "ja": "歪んだの階段", "color": "#28756f", "pattern": "planks", "hardness": 2, "tool": "axe", "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "warped_trapdoor", "ja": "歪んだのトラップドア", "color": "#28756f", "pattern": "planks", "hardness": 3, "tool": "axe", "shape": "trapdoor", "transparent": true, "category": "building"},
  {"name": "warped_wall_hanging_sign", "ja": "歪んだの壁付き吊り看板", "color": "#28756f", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "warped_hanging_sign", "category": "decorations"},
  {"name": "warped_wall_sign", "ja": "歪んだの壁付き看板", "color": "#28756f", "pattern": "planks", "hardness": 1, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "warped_sign", "category": "decorations"},
  {"name": "water_cauldron", "ja": "水入りの大釜", "color": "#3f76e4", "pattern": "metal", "hardness": 2.0, "tool": "pickaxe", "tier": 1, "transparent": true, "drop": "cauldron", "category": "utility"},
  {"name": "waxed_cut_copper_slab", "ja": "錆止めされた切り込み入りの銅のハーフブロック", "color": "#bf6b4d", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "waxed_cut_copper_stairs", "ja": "錆止めされた切り込み入りの銅の階段", "color": "#bf6b4d", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "waxed_exposed_cut_copper_slab", "ja": "錆止めされた風化した切り込み入りの銅のハーフブロック", "color": "#a17e68", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "waxed_exposed_cut_copper_stairs", "ja": "錆止めされた風化した切り込み入りの銅の階段", "color": "#a17e68", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "waxed_oxidized_cut_copper_slab", "ja": "錆止めされた酸化した切り込み入りの銅のハーフブロック", "color": "#52a384", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "waxed_oxidized_cut_copper_stairs", "ja": "錆止めされた酸化した切り込み入りの銅の階段", "color": "#52a384", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "waxed_weathered_cut_copper_slab", "ja": "錆止めされた錆びた切り込み入りの銅のハーフブロック", "color": "#6c996f", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "waxed_weathered_cut_copper_stairs", "ja": "錆止めされた錆びた切り込み入りの銅の階段", "color": "#6c996f", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "weathered_cut_copper_slab", "ja": "錆びた切り込み入りの銅のハーフブロック", "color": "#6c996f", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "slab", "transparent": true, "category": "building"},
  {"name": "weathered_cut_copper_stairs", "ja": "錆びた切り込み入りの銅の階段", "color": "#6c996f", "pattern": "bricks", "hardness": 3.0, "tool": "pickaxe", "tier": 2, "shape": "stairs", "transparent": true, "category": "building"},
  {"name": "weeping_vines_plant", "ja": "しだれツタの茎", "color": "#8f242a", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "drop": "weeping_vines", "category": "nature"},
  {"name": "white_candle_cake", "ja": "白のろうそくが立てられたケーキ", "color": "#eaeced", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "white_candle", "stack": 1, "category": "decorations"},
  {"name": "white_concrete_powder", "ja": "白のコンクリートパウダー", "color": "#cfd5d6", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "white_wall_banner", "ja": "白の壁掛け旗", "color": "#eaeced", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "white_banner", "category": "decorations"},
  {"name": "wither_rose", "ja": "ウィザーローズ", "color": "#2a2426", "pattern": "plant", "hardness": 0, "shape": "cross", "solid": false, "transparent": true, "category": "nature"},
  {"name": "wither_skeleton_wall_skull", "ja": "壁付きのウィザースケルトンの頭蓋骨", "color": "#2b2b2b", "pattern": "obsidian", "hardness": 1.0, "shape": "slab", "transparent": true, "drop": "wither_skeleton_skull", "category": "decorations"},
  {"name": "yellow_candle_cake", "ja": "黄色のろうそくが立てられたケーキ", "color": "#f9c628", "pattern": "food", "hardness": 0.5, "shape": "slab", "transparent": true, "light": 3, "drop": "yellow_candle", "stack": 1, "category": "decorations"},
  {"name": "yellow_concrete_powder", "ja": "黄色のコンクリートパウダー", "color": "#f1af15", "pattern": "sand", "hardness": 0.5, "tool": "shovel", "category": "building"},
  {"name": "yellow_wall_banner", "ja": "黄色の壁掛け旗", "color": "#f9c628", "pattern": "wool", "hardness": 1.0, "tool": "axe", "solid": false, "transparent": true, "shape": "pane", "stack": 16, "drop": "yellow_banner", "category": "decorations"},
  {"name": "zombie_wall_head", "ja": "壁付きのゾンビの頭", "color": "#4c7844", "pattern": "wool", "hardness": 1.0, "shape": "slab", "transparent": true, "drop": "zombie_head", "category": "decorations"},
];

let finalized = false;
export function finalizeOfficial121Blocks(): void {
  if (finalized) return;
  finalized = true;
  const oldRedBedSlot = ID.red_bed;

  // 1. Direct 1-to-1 renames of existing custom blocks to their official 1.21.1 names
  for (const [oldName, newName, ja] of DIRECT_RENAMES) {
    const slot = ID[oldName];
    if (slot !== undefined && RAW_BLOCKS[slot]) {
      RAW_BLOCKS[slot].name = newName;
      RAW_BLOCKS[slot].ja = ja;
      ID[newName] = slot;
      ID[oldName] = slot;
    }
  }

  // Mark the old duplicate red_bed slot as replaceable now that slot 384 (bed) is red_bed
  if (oldRedBedSlot !== undefined && oldRedBedSlot !== ID.red_bed && RAW_BLOCKS[oldRedBedSlot]) {
    RAW_BLOCKS[oldRedBedSlot].name = '__duplicate_red_bed__';
  }

  // 2. Extract internal state/entity blocks so they move to INTERNAL_BLOCKS[1060..1070]
  const extractedInternals: BlockDef[] = [];
  for (let i = 1; i < RAW_BLOCKS.length; i++) {
    const b = RAW_BLOCKS[i];
    if (b && INTERNAL_STATE_NAMES.has(b.name)) {
      extractedInternals.push({ ...b });
    }
  }

  // 3. Replace all non-official slots in RAW_BLOCKS[0..853] in-place, then append remaining official blocks
  let specIdx = 0;
  const makeBlockDef = (id: number, s: RawSpec): BlockDef => ({
    id,
    name: s.name,
    ja: s.ja,
    color: s.color,
    pattern: s.pattern,
    hardness: s.hardness,
    tool: s.tool ?? '',
    tier: s.tier,
    solid: s.solid ?? true,
    transparent: s.transparent ?? false,
    shape: s.shape ?? 'cube',
    category: s.category ?? 'building',
    drop: s.drop,
    light: s.light,
    stack: s.stack ?? 64,
  });

  for (let i = 1; i < RAW_BLOCKS.length; i++) {
    const cur = RAW_BLOCKS[i];
    if (!cur || !OFFICIAL_1060_SET.has(cur.name)) {
      if (specIdx < NEW_OFFICIAL_SPECS.length) {
        const s = NEW_OFFICIAL_SPECS[specIdx++];
        RAW_BLOCKS[i] = makeBlockDef(i, s);
        ID[s.name] = i;
      }
    }
  }

  while (specIdx < NEW_OFFICIAL_SPECS.length) {
    const id = RAW_BLOCKS.length;
    const s = NEW_OFFICIAL_SPECS[specIdx++];
    RAW_BLOCKS.push(makeBlockDef(id, s));
    ID[s.name] = id;
  }

  // 4. Register extracted internal state/entity blocks at 1060..1070
  let nextInternalId = RAW_BLOCKS.length;
  for (const def of extractedInternals) {
    const id = nextInternalId++;
    def.id = id;
    INTERNAL_BLOCKS[id] = def;
    ID[def.name] = id;
  }

  // 5. Populate ALL_BLOCKS (0..1070)
  ALL_BLOCKS.length = 0;
  for (let i = 0; i < RAW_BLOCKS.length; i++) ALL_BLOCKS.push(RAW_BLOCKS[i]);
  for (let i = RAW_BLOCKS.length; i < nextInternalId; i++) ALL_BLOCKS.push(INTERNAL_BLOCKS[i]);

  // 6. Restore all backward-compatible aliases in ID
  ID.lit_copper_bulb = ID.copper_bulb_lit;
  ID.daylight_detector_inverted = ID.inverted_daylight_detector;
  ID.beach_sand = ID.sand;
  ID.crimson_leaves = ID.nether_wart_block;
  ID.warped_leaves = ID.warped_wart_block;
  ID.crimson_sapling = ID.crimson_fungus;
  ID.warped_sapling = ID.warped_fungus;
  ID.jungle_fern = ID.large_fern;
  ID.melon_block = ID.melon;
  ID.pumpkin_block = ID.pumpkin;
  ID.sandstone_fence = ID.sandstone_wall;
  ID.red_sandstone_fence = ID.red_sandstone_wall;
  ID.stone_bricks_fence = ID.stone_brick_wall;
  ID.cobblestone_fence = ID.cobblestone_wall;
  ID.quartz_wall = ID.quartz_slab;
  ID.quartz_block_fence = ID.quartz_slab;
  ID.purpur_wall = ID.purpur_slab;
  ID.purpur_block_fence = ID.purpur_slab;
  ID.end_stone_bricks_fence = ID.end_stone_brick_wall;
  ID.deepslate_fence = ID.cobbled_deepslate_wall;
  ID.granite_fence = ID.granite_wall;
  ID.diorite_fence = ID.diorite_wall;
  ID.andesite_fence = ID.andesite_wall;
  ID.obsidian_bricks = ID.obsidian;
  ID.leaf_litter = ID.short_grass;
  ID.pale_oak_log = ID.birch_log;
  ID.pale_oak_leaves = ID.birch_leaves;
  ID.pale_oak_planks = ID.birch_planks;
  ID.pale_oak_sapling = ID.birch_sapling;
  ID.poplar_log = ID.birch_log;
  ID.poplar_leaves = ID.birch_leaves;
  ID.poplar_planks = ID.birch_planks;
  ID.poplar_sapling = ID.birch_sapling;

  for (const w of ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak', 'cherry']) {
    ID[`${w}_planks_wall`] = ID[`${w}_fence`];
    ID[`open_${w}_door`] = ID[`${w}_door`];
  }
  ID.open_iron_door = ID.iron_door;
  for (const prefix of ['', 'exposed_', 'weathered_', 'oxidized_']) {
    const d = prefix ? `${prefix}copper_door` : 'copper_door';
    const t = prefix ? `${prefix}copper_trapdoor` : 'copper_trapdoor';
    ID[`open_${d}`] = ID[d];
    ID[`open_${t}`] = ID[t];
  }
  for (const col of ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black']) {
    ID[`${col}_wool_slab`] = ID[`${col}_carpet`];
    ID[`${col}_wool_stairs`] = ID[`${col}_wool`];
    ID[`${col}_concrete_slab`] = ID[`${col}_concrete`];
    ID[`${col}_concrete_stairs`] = ID[`${col}_concrete`];
  }

  for (const bd of ALL_BLOCKS) {
    if (!bd) continue;
    if (bd.name === 'candle_cake' || bd.name.endsWith('_candle_cake')) {
      bd.solid = false;
      bd.transparent = true;
      bd.shape = 'lantern';
    } else if (bd.name === 'flower_pot' || bd.name.startsWith('potted_')) {
      bd.solid = false;
      bd.transparent = true;
    }
  }
  // 7. Register missing official 1.21.1 non-block items (C-05)
  const MISSING_OFFICIAL_ITEMS: ReadonlyArray<readonly [string, string, string, Pattern, Partial<BlockDef>]> = [
    ['oak_boat', 'オークのボート', '#b8945f', 'tool', { stack: 1, category: 'tools' }],
    ['spruce_boat', 'トウヒのボート', '#785836', 'tool', { stack: 1, category: 'tools' }],
    ['birch_boat', 'シラカバのボート', '#cbb783', 'tool', { stack: 1, category: 'tools' }],
    ['jungle_boat', 'ジャングルのボート', '#a67754', 'tool', { stack: 1, category: 'tools' }],
    ['acacia_boat', 'アカシアのボート', '#ba6337', 'tool', { stack: 1, category: 'tools' }],
    ['cherry_boat', 'サクラのボート', '#e6b4bc', 'tool', { stack: 1, category: 'tools' }],
    ['dark_oak_boat', 'ダークオークのボート', '#4a3219', 'tool', { stack: 1, category: 'tools' }],
    ['mangrove_boat', 'マングローブのボート', '#7a362e', 'tool', { stack: 1, category: 'tools' }],
    ['bamboo_raft', '竹のいかだ', '#c9b458', 'tool', { stack: 1, category: 'tools' }],
    ['oak_chest_boat', 'チェスト付きオークのボート', '#b8945f', 'tool', { stack: 1, category: 'tools' }],
    ['spruce_chest_boat', 'チェスト付きトウヒのボート', '#785836', 'tool', { stack: 1, category: 'tools' }],
    ['birch_chest_boat', 'チェスト付きシラカバのボート', '#cbb783', 'tool', { stack: 1, category: 'tools' }],
    ['jungle_chest_boat', 'チェスト付きジャングルのボート', '#a67754', 'tool', { stack: 1, category: 'tools' }],
    ['acacia_chest_boat', 'チェスト付きアカシアのボート', '#ba6337', 'tool', { stack: 1, category: 'tools' }],
    ['cherry_chest_boat', 'チェスト付きサクラのボート', '#e6b4bc', 'tool', { stack: 1, category: 'tools' }],
    ['dark_oak_chest_boat', 'チェスト付きダークオークのボート', '#4a3219', 'tool', { stack: 1, category: 'tools' }],
    ['mangrove_chest_boat', 'チェスト付きマングローブのボート', '#7a362e', 'tool', { stack: 1, category: 'tools' }],
    ['bamboo_chest_raft', 'チェスト付き竹のいかだ', '#c9b458', 'tool', { stack: 1, category: 'tools' }],
    ['pufferfish_bucket', 'フグ入りバケツ', '#e8c232', 'misc', { stack: 1, category: 'tools' }],
    ['salmon_bucket', 'サケ入りバケツ', '#ce8066', 'misc', { stack: 1, category: 'tools' }],
    ['cod_bucket', 'タラ入りバケツ', '#b8b393', 'misc', { stack: 1, category: 'tools' }],
    ['tropical_fish_bucket', '熱帯魚入りバケツ', '#e87a32', 'misc', { stack: 1, category: 'tools' }],
    ['axolotl_bucket', 'ウーパールーパー入りバケツ', '#f0a1c8', 'misc', { stack: 1, category: 'tools' }],
    ['tadpole_bucket', 'オタマジャクシ入りバケツ', '#4a3a2a', 'misc', { stack: 1, category: 'tools' }],
    ['recovery_compass', 'リカバリーコンパス', '#2998a6', 'tool', { stack: 1, category: 'tools' }],
    ['tipped_arrow', '効能付きの矢', '#c858d8', 'tool', { stack: 64, category: 'tools' }],
    ['netherite_upgrade_smithing_template', 'ネザライト強化の鍛冶型', '#5a4a52', 'metal', { stack: 64, category: 'materials' }],
    ['turtle_scute', 'カメのウロコ', '#489c46', 'misc', { stack: 64, category: 'materials' }],
    ['beef', '生の牛肉', '#bb5a51', 'food', { food: 3, stack: 64, category: 'food' }],
    ['knowledge_book', '知恵の本', '#4aa858', 'misc', { stack: 1, category: 'tools' }],
    ['debug_stick', 'デバッグ棒', '#b678e8', 'tool', { stack: 1, category: 'tools' }],
    ['disc_fragment_5', 'レコードの破片（5）', '#285e68', 'misc', { stack: 64, category: 'materials' }],
    ['command_block_minecart', 'コマンドブロック付きトロッコ', '#c78861', 'metal', { stack: 1, category: 'tools' }],
    ['torchflower_seeds', 'トーチフラワーの種', '#d99a3c', 'misc', { stack: 64, category: 'materials' }],
    ['pitcher_pod', 'ウツボカズラのさや', '#6a8a9c', 'misc', { stack: 64, category: 'materials' }],
  ];
  for (const [n, ja, col, pat, ext] of MISSING_OFFICIAL_ITEMS) {
    if (ITEM_ID[n] === undefined) item(n, ja, col, pat, ext);
  }
}
