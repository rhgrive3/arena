import { placeExtraStructures, locateExtra } from './structures';
import { OverworldGen } from './overworld';
import { ID, BLOCKS } from '../game/data';
import { makeCell } from '../game/blockState';
import '../game/content';
import { random, hashSeed } from '../input/math';
import type { Dimension } from '../game/types';

export const CHUNK = 16;
export const HEIGHT = 384;
export const MIN_Y = -64;
export const SEA = 63;

/**
 * Every biome this generator can produce, with the English and Japanese names used by the UI (Minecraft Wiki naming).
 * Keep this list in sync with biomeAt(): the biome regression test (scripts/verify-biomes.ts) fails when a label is missing.
 */
export const BIOME_LABELS: Record<string, { en: string; ja: string; group: 'overworld' | 'nether' | 'end' }> = {
  lush_caves: { en: 'Lush Caves', ja: '繁茂した洞窟', group: 'overworld' },
  dripstone_caves: { en: 'Dripstone Caves', ja: '鍾乳洞', group: 'overworld' },
  deep_dark: { en: 'Deep Dark', ja: 'ディープダーク', group: 'overworld' },
  plains: { en: 'Plains', ja: '平原', group: 'overworld' },
  forest: { en: 'Forest', ja: '森', group: 'overworld' },
  birch_forest: { en: 'Birch Forest', ja: 'シラカバの森', group: 'overworld' },
  flower_forest: { en: 'Flower Forest', ja: '花畑の森', group: 'overworld' },
  meadow: { en: 'Meadow', ja: '草地', group: 'overworld' },
  cherry_grove: { en: 'Cherry Grove', ja: '桜の林', group: 'overworld' },
  taiga: { en: 'Taiga', ja: 'タイガ', group: 'overworld' },
  snowy_plains: { en: 'Snowy Plains', ja: '雪原', group: 'overworld' },
  snowy_slopes: { en: 'Snowy Slopes', ja: '雪の斜面', group: 'overworld' },
  windswept_hills: { en: 'Windswept Hills', ja: '吹きさらしの丘', group: 'overworld' },
  desert: { en: 'Desert', ja: '砂漠', group: 'overworld' },
  savanna: { en: 'Savanna', ja: 'サバンナ', group: 'overworld' },
  jungle: { en: 'Jungle', ja: 'ジャングル', group: 'overworld' },
  swamp: { en: 'Swamp', ja: '沼地', group: 'overworld' },
  badlands: { en: 'Badlands', ja: 'バッドランド', group: 'overworld' },
  mushroom_fields: { en: 'Mushroom Fields', ja: 'キノコ島', group: 'overworld' },
  beach: { en: 'Beach', ja: '砂浜', group: 'overworld' },
  stony_shore: { en: 'Stony Shore', ja: '石だらけの海岸', group: 'overworld' },
  river: { en: 'River', ja: '河川', group: 'overworld' },
  frozen_river: { en: 'Frozen River', ja: '凍った川', group: 'overworld' },
  ocean: { en: 'Ocean', ja: '海洋', group: 'overworld' },
  deep_ocean: { en: 'Deep Ocean', ja: '深海', group: 'overworld' },
  frozen_ocean: { en: 'Frozen Ocean', ja: '凍った海', group: 'overworld' },
  nether_wastes: { en: 'Nether Wastes', ja: 'ネザーの荒れ地', group: 'nether' },
  crimson_forest: { en: 'Crimson Forest', ja: '真紅の森', group: 'nether' },
  warped_forest: { en: 'Warped Forest', ja: '歪んだ森', group: 'nether' },
  soul_sand_valley: { en: 'Soul Sand Valley', ja: 'ソウルサンドの谷', group: 'nether' },
  basalt_deltas: { en: 'Basalt Deltas', ja: '玄武岩の三角州', group: 'nether' },
  the_end: { en: 'The End', ja: 'ジ・エンド', group: 'end' },
};

export const BIOME_TINTS: Record<string, [number, number, number]> = {
  plains: [0.97, 1.25, 0.60],          // #91bd59 (Vanilla Plains vibrant yellow-green)
  forest: [0.81, 1.28, 0.60],          // #79c05a (Vanilla Forest fresh green)
  birch_forest: [0.91, 1.24, 0.69],    // #88bb67 (Birch Forest sunny soft green)
  flower_forest: [0.97, 1.26, 0.60],   // Flower Forest vibrant
  taiga: [0.89, 1.22, 0.87],           // #86b783 (Taiga cool boreal blue-green)
  snowy_plains: [0.85, 1.20, 1.00],    // #80b497 (Snowy pine frost-green)
  snowy_slopes: [0.85, 1.20, 1.00],    // Frost green
  windswept_hills: [0.92, 1.21, 0.91], // Windswept highlands muted green
  desert: [1.27, 1.21, 0.57],          // #bfb655 (Dry scorched olive-gold)
  savanna: [1.27, 1.22, 0.57],         // #bfb755 (Warm golden savanna grass)
  jungle: [0.59, 1.34, 0.41],          // #59c93c (Deep lush emerald jungle)
  swamp: [0.70, 0.75, 0.38],           // #6a7039 (Dark murky bog-green)
  badlands: [0.96, 0.86, 0.51],        // #90814d (Mesa dry baked clay tint)
  cherry_grove: [0.97, 1.23, 0.66],    // Soft springtime green
  mushroom_fields: [0.57, 1.34, 0.42], // Lush mycelium island green
  beach: [0.97, 1.25, 0.60],
  river: [0.95, 1.23, 0.75],
  ocean: [0.95, 1.23, 0.75],
  frozen_river: [0.86, 1.05, 1.10],
  frozen_ocean: [0.86, 1.05, 1.10],
  deep_ocean: [0.80, 1.05, 0.92],
  meadow: [0.86, 1.30, 0.62],
  stony_shore: [0.92, 1.10, 0.92],
  snowy_beach: [0.92, 1.05, 1.02],
  nether_wastes: [1.0, 1.0, 1.0],
  crimson_forest: [1.1, 0.7, 0.7],
  warped_forest: [0.6, 1.1, 1.1],
  soul_sand_valley: [0.8, 0.7, 0.7],
  basalt_deltas: [0.8, 0.8, 0.8],
  the_end: [1.0, 1.0, 1.0],
};

export class Noise {
  p = new Uint8Array(512);
  constructor(seed: number) {
    const r = random(seed), a = Array.from({ length: 256 }, (_, i) => i);
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(r() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    for (let i = 0; i < 512; i++) this.p[i] = a[i & 255];
  }
  fade(t: number) { return t * t * t * (t * (t * 6 - 15) + 10); }
  grad(h: number, x: number, y: number, z: number) {
    h &= 15;
    const u = h < 8 ? x : y, v = h < 4 ? y : h === 12 || h === 14 ? x : z;
    return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
  }
  n3(x: number, y: number, z: number) {
    const X = Math.floor(x) & 255, Y = Math.floor(y) & 255, Z = Math.floor(z) & 255;
    x -= Math.floor(x); y -= Math.floor(y); z -= Math.floor(z);
    const u = this.fade(x), v = this.fade(y), w = this.fade(z), p = this.p;
    const A = p[X] + Y, AA = p[A] + Z, AB = p[A + 1] + Z, B = p[X + 1] + Y, BA = p[B] + Z, BB = p[B + 1] + Z;
    const l = (a: number, b: number, t: number) => a + (b - a) * t;
    return l(
      l(l(this.grad(p[AA], x, y, z), this.grad(p[BA], x - 1, y, z), u), l(this.grad(p[AB], x, y - 1, z), this.grad(p[BB], x - 1, y - 1, z), u), v),
      l(l(this.grad(p[AA + 1], x, y, z - 1), this.grad(p[BA + 1], x - 1, y, z - 1), u), l(this.grad(p[AB + 1], x, y - 1, z - 1), this.grad(p[BB + 1], x - 1, y - 1, z - 1), u), v),
      w,
    );
  }
  n2(x: number, z: number) { return this.n3(x, 0.137, z); }
  fbm(x: number, z: number, octaves = 4) {
    let value = 0, amp = 0.57;
    for (let i = 0; i < octaves; i++) {
      value += this.n2(x, z) * amp;
      x *= 2.03; z *= 2.03; amp *= 0.5;
    }
    return value;
  }
}

export const smooth = (a: number, b: number, x: number) => {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

export function coordHash(x: number, z: number, seed: number) {
  let h = Math.imul(x, 374761393) ^ Math.imul(z, 668265263) ^ seed;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

type PutFn = (x: number, y: number, z: number, id: number, replace?: boolean) => void;

export const END_GATEWAY_MAIN: readonly [number, number, number] = [46, 33, 0];
export const END_OUTER_ARRIVAL: readonly [number, number, number] = [520, 30, 0];

export function endPillars(): { x: number; z: number; h: number; r: number; caged: boolean }[] {
  const res = [];
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI) / 4;
    const dist = 27;
    res.push({
      x: Math.round(Math.cos(a) * dist),
      z: Math.round(Math.sin(a) * dist),
      h: 37 + ((i * 5) % 14),
      r: i % 2 === 0 ? 2 : 1,
      caged: i === 1 || i === 5,
    });
  }
  return res;
}

export class Terrain {
  seed: number;
  noise: Noise;
  dimension: Dimension;
  /** Vanilla-style multi-noise source for overworld height and biomes (see overworld.ts). */
  gen: OverworldGen;
  private structCache = new Map<number, ReturnType<Terrain['regionStructureCompute']>>();
  private spawnLevel = NaN;

  constructor(seed: string, dimension: Dimension = 'overworld') {
    this.seed = hashSeed(seed);
    this.noise = new Noise(this.seed);
    this.dimension = dimension;
    this.gen = new OverworldGen(this.noise);
  }


  spawnPoint(): [number, number, number] {
    if (this.dimension === 'nether') return [0, 25, 4];
    if (this.dimension === 'end') return [0, 30, 42];
    const sx = -11, sz = 27;
    return [sx, Math.max(SEA + 1, this.height(sx, sz) + 1), sz];
  }

  spawnPosition(above = 1.05): [number, number, number] {
    const [x, y, z] = this.spawnPoint();
    return [x + 0.5, y + above - 1, z + 0.5];
  }

  spawnYaw(): number {
    if (this.dimension === 'end') return 0;
    return -2.4;
  }

  private dungeonAt(cx: number, cz: number): [number, number, number, number, number] | null {
    if (this.dimension !== 'overworld' || coordHash(cx, cz, this.seed + 1234) >= 0.09) return null;
    const ox = cx * 16 + 4 + Math.floor(coordHash(cx, cz, this.seed + 1235) * 8);
    const oz = cz * 16 + 4 + Math.floor(coordHash(cx, cz, this.seed + 1236) * 8);
    const surf = this.height(ox, oz);
    if (surf < SEA + 2) return null;
    const y0 = Math.max(MIN_Y + 5, Math.min(surf - 10, -30 + Math.floor(coordHash(cx, cz, this.seed + 1237) * 70)));
    const rx = coordHash(cx, cz, this.seed + 1238) < 0.5 ? 3 : 4;
    const rz = coordHash(cx, cz, this.seed + 1239) < 0.5 ? 3 : 4;
    return [ox, y0, oz, rx, rz];
  }

  private dungeon(put: PutFn, room: [number, number, number, number, number]) {
    const [cx, y0, cz, rx, rz] = room;
    const cob = ID.cobblestone, mossy = ID.mossy_cobblestone ?? cob;
    for (let dy = 0; dy <= 5; dy++) {
      for (let dz = -rz - 1; dz <= rz + 1; dz++) {
        for (let dx = -rx - 1; dx <= rx + 1; dx++) {
          const wall = Math.abs(dx) === rx + 1 || Math.abs(dz) === rz + 1;
          if (dy === 0) put(cx + dx, y0, cz + dz, coordHash(cx + dx, cz + dz, this.seed + 1240) < 0.72 ? mossy : cob, true);
          else if (dy === 5) put(cx + dx, y0 + 5, cz + dz, cob, true);
          else if (wall) put(cx + dx, y0 + dy, cz + dz, cob, true);
          else put(cx + dx, y0 + dy, cz + dz, 0, true);
        }
      }
    }
    put(cx, y0 + 1, cz, ID.spawner ?? cob, true);
    put(cx - rx, y0 + 1, cz, ID.chest, true);
    if (coordHash(cx, cz, this.seed + 1241) < 0.65) put(cx, y0 + 1, cz - rz, ID.chest, true);
  }

  locate(what: string, px: number, pz: number): [number, number, number] | null {
    const q = what.toLowerCase();
    const extra = locateExtra(this, q, px, pz);
    if (extra) return extra;
    if (q === 'stronghold' || q === 'end_portal') {
      const [sx, sz] = this.strongholdPos();
      return [sx, 32, sz];
    }
    if (q === 'endcity' || q === 'end_city' || q === 'endship') {
      return [518, 30, 8];
    }
    if (q === 'fortress') {
      return [32, 26, 32];
    }
    const pcx = Math.floor(px / 16), pcz = Math.floor(pz / 16);
    if (q === 'dungeon' || q === 'spawner') {
      let best: [number, number, number] | null = null, bestD = Infinity;
      for (let dz = -24; dz <= 24; dz++) for (let dx = -24; dx <= 24; dx++) {
        const d = this.dungeonAt(pcx + dx, pcz + dz);
        if (d) {
          const dist = Math.hypot(d[0] - px, d[2] - pz);
          if (dist < bestD) { bestD = dist; best = [d[0], d[1] + 1, d[2]]; }
        }
      }
      return best;
    }
    if (['village', 'plains_village', 'desert_village', 'pyramid', 'desert_pyramid', 'temple', 'ruined_portal', 'witch_hut', 'desert_fossil'].includes(q)) {
      const prx = Math.floor(px / 96), prz = Math.floor(pz / 96);
      let best: [number, number, number] | null = null, bestD = Infinity;
      if (q === 'village' || q === 'plains_village') {
        const d0 = Math.hypot(15 - px, 16 - pz);
        bestD = d0; best = [15, this.height(15, 16) + 1, 16];
      }
      for (let dz = -12; dz <= 12; dz++) for (let dx = -12; dx <= 12; dx++) {
        const s = this.regionStructure(prx + dx, prz + dz);
        if (!s) continue;
        const match =
          (q === 'village' && (s.type === 'plains_village' || s.type === 'desert_village')) ||
          ((q === 'pyramid' || q === 'temple' || q === 'desert_pyramid') && s.type === 'desert_pyramid') ||
          s.type === q;
        if (match) {
          const dist = Math.hypot(s.x - px, s.z - pz);
          if (dist < bestD) { bestD = dist; best = [s.x, this.height(s.x, s.z) + 1, s.z]; }
        }
      }
      return best;
    }
    // Biome search
    for (let r = 0; r <= 64; r++) {
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;
        const wx = Math.round(px) + dx * 24, wz = Math.round(pz) + dz * 24;
        if (this.biome(wx, wz) === q) return [wx, this.height(wx, wz) + 1, wz];
      }
    }
    return null;
  }

  strongholdPos(): [number, number] {
    const a = coordHash(17, 29, this.seed + 42) * Math.PI * 2;
    const d = 58 + coordHash(31, 47, this.seed + 77) * 24;
    return [Math.round(Math.cos(a) * d), Math.round(Math.sin(a) * d)];
  }

  private outerEndIslandMask(x: number, z: number): number {
    const dMain = Math.hypot(x, z);
    if (dMain <= 56) return 1 - smooth(42, 58, dMain);
    if (dMain < 120) return 0;
    // Guaranteed arrival island & End City plateau around (520, 0)
    const dArr = Math.hypot(x - 520, z);
    if (dArr < 44) return 1 - smooth(28, 44, dArr);
    const dShip = Math.hypot(x - 538, z + 18);
    if (dShip < 14) return 0;
    const n = this.noise.fbm(x * 0.014 + 410, z * 0.014 - 230, 3);
    return smooth(0.16, 0.34, n);
  }

  height(x: number, z: number): number {
    if (this.dimension === 'nether') {
      const dSpawn = Math.hypot(x, z - 4);
      let raw = 20 + this.noise.fbm(x * 0.032, z * 0.032, 3) * 14 + this.noise.n2(x * 0.08, z * 0.08) * 3;
      // Open lava seas: carve basins below y=17 so the lava level is visible (Wiki: lava sea in the Nether).
      const basin = this.noise.fbm(x * 0.011 - 60, z * 0.011 + 90, 2);
      if (basin > 0.12) raw -= Math.min(14, (basin - 0.12) * 90);
      const flat = 25;
      const blend = smooth(4, 14, dSpawn);
      return Math.floor(flat * (1 - blend) + raw * blend);
    }
    if (this.dimension === 'end') {
      const dMain = Math.hypot(x, z);
      if (dMain <= 60) {
        if (dMain > 56) return -20;
        const base = 24 + this.noise.fbm(x * 0.035, z * 0.035, 3) * 5;
        const flatCenter = 27;
        const b = smooth(10, 24, dMain);
        return Math.floor(flatCenter * (1 - b) + base * b - smooth(42, 56, dMain) * 10);
      }
      const mask = this.outerEndIslandMask(x, z);
      if (mask <= 0.05) return -20;
      const dArr = Math.hypot(x - 520, z);
      if (dArr < 34) return 27 + Math.floor(this.noise.n2(x * 0.06, z * 0.06) * 2 * smooth(16, 30, dArr));
      return Math.floor(20 + mask * 10 + this.noise.n2(x * 0.04, z * 0.04) * 3);
    }

    return Math.max(MIN_Y + 8, Math.min(MIN_Y + HEIGHT - 64, Math.floor(this.adapt(x, z, this.gen.column(x, z).hf))));
  }

  /** Terrain adaptation: the starter area and villages/pyramids sit on gently levelled ground that blends into the landscape. */
  private adapt(x: number, z: number, h: number): number {
    const ds = Math.hypot(x - 6, z - 10);
    if (ds < 120) {
      if (Number.isNaN(this.spawnLevel)) this.spawnLevel = Math.max(66.5, Math.min(72.5, this.gen.column(6, 10).hf));
      const f = smooth(120, 52, ds);
      h = h * (1 - f) + (this.spawnLevel + this.noise.n2(x * 0.021 + 3.7, z * 0.021 - 1.9) * 1.6) * f;
    }
    const rx0 = Math.floor((x - 56) / 112), rz0 = Math.floor((z - 56) / 112);
    for (let dz = 0; dz <= 1; dz++) for (let dx = 0; dx <= 1; dx++) {
      const s = this.regionStructure(rx0 + dx, rz0 + dz);
      if (!s || s.flat === undefined) continue;
      const d = Math.hypot(x - s.x, z - s.z);
      if (d < 48) { const f = smooth(48, 24, d); h = h * (1 - f) + (s.flat + this.noise.n2(x * 0.05, z * 0.05) * 0.5) * f; }
    }
    return h;
  }

  private climate(x: number, z: number) {
    const c = this.gen.column(x, z);
    return { temp: c.T, humid: c.H, weird: c.W };
  }

  biomeAt(x: number, z: number, h: number): string {
    if (this.dimension === 'nether') {
      const t = this.noise.fbm(x * 0.009 + 120, z * 0.009 - 80, 3);
      const w = this.noise.fbm(x * 0.011 - 90, z * 0.011 + 140, 3);
      if (t > 0.22) return w > 0 ? 'crimson_forest' : 'basalt_deltas';
      if (t < -0.22) return w > 0 ? 'warped_forest' : 'soul_sand_valley';
      return 'nether_wastes';
    }
    if (this.dimension === 'end') return 'the_end';

    return this.gen.biomeAt(x, z, h);
  }

  /** Underground biome at a block position, or null on the surface / outside the cave biomes. */
  caveBiome(x: number, y: number, z: number): string | null {
    if (this.dimension !== 'overworld' || y > 56 || y > this.height(x, z) - 8) return null;
    if (y < 0 && this.noise.fbm(x * 0.009 + 910, z * 0.009 + 620, 2) > 0.3) return 'deep_dark';
    if (this.noise.fbm(x * 0.012 + 500, z * 0.012 - 320, 2) > 0.24) return 'lush_caves';
    if (this.noise.fbm(x * 0.014 - 700, z * 0.014 + 260, 2) > 0.26) return 'dripstone_caves';
    return null;
  }

  biome(x: number, z: number) { return this.biomeAt(x, z, this.height(x, z)); }

  surface(biome: string, x: number, z: number, h = SEA + 5): number {
    if (biome === 'desert' || biome === 'beach' || biome === 'snowy_beach') return ID.sand;
    if (biome === 'ocean' || biome === 'deep_ocean' || biome === 'frozen_ocean') {
      // Wiki: gravel, sand and clay floors; deep oceans are mostly gravel.
      const n = coordHash(x, z, this.seed + 17);
      return h < SEA - 26 ? (n < 0.6 ? ID.gravel : ID.sand) : n < 0.3 ? ID.gravel : n < 0.36 ? ID.clay : ID.sand;
    }
    if (biome === 'river' || biome === 'frozen_river') {
      if (h < SEA) { const n = coordHash(x, z, this.seed + 19); return n < 0.25 ? ID.clay : n < 0.5 ? ID.gravel : ID.sand; }
      return ID.sand;
    }
    if (biome === 'stony_shore') { const n = coordHash(x, z, this.seed + 21); return n < 0.55 ? ID.stone : n < 0.8 ? ID.gravel : ID.andesite ?? ID.stone; }
    if (biome === 'snowy_slopes') return ID.snow_block;
    if (biome === 'snowy_plains') return ID.grass_block;   // snow layer is placed above the grass, like vanilla
    if (biome === 'badlands') return ID.red_sand;
    if (biome === 'crimson_forest') return ID.crimson_nylium;
    if (biome === 'warped_forest') return ID.warped_nylium;
    if (biome === 'soul_sand_valley') return coordHash(x, z, this.seed + 31) < 0.35 ? ID.soul_soil : ID.soul_sand;
    if (biome === 'basalt_deltas') return coordHash(x, z, this.seed + 37) < 0.55 ? ID.basalt : ID.blackstone;
    if (biome === 'nether_wastes') return ID.netherrack;
    if (biome === 'the_end') return ID.end_stone;
    if (biome === 'mushroom_fields') return ID.mycelium;
    if (biome === 'taiga' && this.noise.n2(x * 0.12 + 9, z * 0.12 - 4) > 0.18) return ID.podzol;
    if (biome === 'windswept_hills' && this.noise.n2(x * 0.11, z * 0.11) > 0.16) return ID.stone;
    return ID.grass_block;
  }

  private regionStructure(rx: number, rz: number) {
    const key = (rx + 32768) * 65536 + (rz + 32768);
    let v = this.structCache.get(key);
    if (v === undefined) {
      v = this.regionStructureCompute(rx, rz);
      if (v && (v.type === 'plains_village' || v.type === 'desert_village' || v.type === 'desert_pyramid')) v.flat = Math.floor(this.gen.column(v.x, v.z).hf) + 0.5;
      this.structCache.set(key, v);
    }
    return v;
  }

  private regionStructureCompute(rx: number, rz: number): { type: 'plains_village' | 'desert_village' | 'desert_pyramid' | 'ruined_portal' | 'witch_hut' | 'desert_fossil'; x: number; z: number; flat?: number } | null {
    // Keep region (0, 0) & (-1, -1) reserved for handcrafted starter cabin, starter village, ruined portal & stronghold
    if (Math.abs(rx) <= 0 && Math.abs(rz) <= 0) return null;
    const h = coordHash(rx, rz, this.seed + 7711);
    if (h > 0.55) return null;
    const sx = rx * 112 + 24 + Math.floor(coordHash(rx, rz, this.seed + 101) * 56);
    const sz = rz * 112 + 24 + Math.floor(coordHash(rx, rz, this.seed + 202) * 56);
    // Raw (un-adapted) terrain: height() itself consults this function for the levelling above.
    const bh = Math.floor(this.gen.column(sx, sz).hf);
    const b = this.gen.biomeAt(sx, sz, bh);
    if (bh <= SEA + 1) return null;
    if (b === 'desert') {
      return h < 0.25 ? { type: 'desert_village', x: sx, z: sz } : h < 0.42 ? { type: 'desert_pyramid', x: sx, z: sz } : { type: 'desert_fossil', x: sx, z: sz };
    }
    if (b === 'swamp') {
      return { type: 'witch_hut', x: sx, z: sz };
    }
    if (b === 'plains' || b === 'savanna' || b === 'taiga') {
      return h < 0.34 ? { type: 'plains_village', x: sx, z: sz } : { type: 'ruined_portal', x: sx, z: sz };
    }
    if (h < 0.15) return { type: 'ruined_portal', x: sx, z: sz };
    return null;
  }

  private collectNearbyStructures(ox: number, oz: number) {
    const boxes: [number, number, number, number][] = [
      [-27, -22, -15, -10], // Starter cabin
      [2, 2, 32, 32],       // Starter village
      [36, 28, 48, 40],     // Starter ruined portal
    ];
    const rx = Math.floor((ox + 8) / 112), rz = Math.floor((oz + 8) / 112);
    const list: NonNullable<ReturnType<Terrain['regionStructure']>>[] = [];
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const s = this.regionStructure(rx + dx, rz + dz);
      if (s) {
        list.push(s);
        boxes.push([s.x - 22, s.z - 22, s.x + 22, s.z + 22]);
      }
    }
    return { boxes, list };
  }

  generate(cx: number, cz: number, edits: [string, number][] = [], structures = true) {
    const padded = new Uint16Array(18 * 18 * HEIGHT);
    const data = new Uint16Array(16 * 16 * HEIGHT);
    const idx = (x: number, y: number, z: number) => (y - MIN_Y) * 324 + (z + 1) * 18 + x + 1;
    const tint = new Float32Array(16 * 16 * 3);
    let maxY = SEA + 2;
    const ox = cx * 16, oz = cz * 16;

    const put: PutFn = (x, y, z, id, replace = true) => {
      x -= ox; z -= oz;
      if (x < -1 || x > 16 || z < -1 || z > 16 || y < MIN_Y || y >= MIN_Y + HEIGHT) return;
      const i = idx(x, y, z);
      if (replace || !padded[i]) padded[i] = id;
      maxY = Math.max(maxY, y + 1);
    };

    const foundation = (x: number, yStart: number, z: number, id: number) => {
      for (let dy = 0; dy < 10; dy++) {
        const yy = yStart - dy;
        if (yy <= MIN_Y + 1) break;
        const lx = x - ox, lz = z - oz;
        if (lx >= -1 && lx <= 16 && lz >= -1 && lz <= 16 && dy > 0 && padded[idx(lx, yy, lz)] !== 0 && padded[idx(lx, yy, lz)] !== ID.water) break;
        put(x, yy, z, id, true);
      }
    };

    // Fast void skip for outer empty End regions
    if (this.dimension === 'end') {
      const centerDist = Math.hypot(ox + 8, oz + 8);
      if (centerDist > 64 && centerDist < 116) {
        for (const [key, cell] of edits) {
          const [x, y, z] = key.split(',').map(Number);
          put(x, y, z, cell);
        }
        for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) for (let y = 0; y < HEIGHT; y++) data[y * 256 + z * 16 + x] = padded[idx(x, y + MIN_Y, z)];
        return { data, padded, tint, maxY: Math.min(MIN_Y + HEIGHT, maxY + 2) };
      }
    }

    const nearby = this.dimension === 'overworld' ? this.collectNearbyStructures(ox, oz) : { boxes: [], list: [] };
    const inExcl = (wx: number, wz: number) => {
      for (let i = 0; i < nearby.boxes.length; i++) {
        const b = nearby.boxes[i];
        if (wx >= b[0] && wx <= b[2] && wz >= b[1] && wz <= b[3]) return true;
      }
      return false;
    };

    const hMap = new Int16Array(20 * 20);
    const biomeTintGrid = new Float32Array(20 * 20 * 3);
    const biomeGrid: (string | undefined)[] = new Array(400);
    for (let gz = -2; gz <= 17; gz++) for (let gx = -2; gx <= 17; gx++) {
      const gi = (gz + 2) * 20 + (gx + 2);
      const hh = this.height(ox + gx, oz + gz);
      hMap[gi] = hh;
      const bn = this.biomeAt(ox + gx, oz + gz, hh);
      biomeGrid[gi] = bn;
      const bt = BIOME_TINTS[bn] ?? [1, 1, 1];
      biomeTintGrid[gi * 3] = bt[0]; biomeTintGrid[gi * 3 + 1] = bt[1]; biomeTintGrid[gi * 3 + 2] = bt[2];
    }
    const getH = (x: number, z: number) => hMap[(z + 2) * 20 + (x + 2)];
    const getBiome = (x: number, z: number) => biomeGrid[(z + 2) * 20 + (x + 2)] ?? 'plains';
    // Flowers grow in patches of one kind (vanilla picks the flower from a smooth noise field), not as per-block confetti.
    const flowerAt = (fx: number, fz: number, kinds: (number | undefined)[]) => {
      const v = this.noise.n2(fx / 13 + 77.7, fz / 13 - 33.3) * 0.5 + this.noise.n2(fx / 5 - 12.1, fz / 5 + 8.6) * 0.12 + 0.5;
      return kinds[Math.max(0, Math.min(kinds.length - 1, Math.floor(((v - 0.2) / 0.6) * kinds.length)))] ?? ID.poppy;
    };

    for (let z = -1; z <= 16; z++) for (let x = -1; x <= 16; x++) {
      const wx = ox + x, wz = oz + z, h = getH(x, z);
      const biome = getBiome(x, z);
      let top = this.surface(biome, wx, wz, h);
      if (this.dimension === 'overworld' && h > 112) {
        const alt = h + Math.floor(coordHash(wx, wz, this.seed + 97) * 7) - 3;
        if (alt > 150 && biome !== 'badlands') top = ID.snow_block;
        else if (alt > 122 && top === ID.grass_block) top = ID.stone;
      }
      // Snowy mountains show rock where the slope is too steep for snow to settle.
      if (biome === 'snowy_slopes' && top === ID.snow_block && Math.max(Math.abs(getH(x + 1, z) - getH(x - 1, z)), Math.abs(getH(x, z + 1) - getH(x, z - 1))) >= 3 && this.noise.n2(wx / 11 + 6.6, wz / 11 - 2.4) > -0.25) top = ID.stone;
      // Steep faces (more than 3 blocks of drop to a neighbour) show bare rock, like vanilla mountain sides.
      const cliff = Math.max(Math.abs(getH(x + 1, z) - getH(x - 1, z)), Math.abs(getH(x, z + 1) - getH(x, z - 1))) > 6 || Math.max(Math.abs(getH(x + 1, z) - h), Math.abs(getH(x - 1, z) - h), Math.abs(getH(x, z + 1) - h), Math.abs(getH(x, z - 1) - h)) > 3;

      if (x >= 0 && x < 16 && z >= 0 && z < 16) {
        // Smooth biome tint across a 5x5 neighborhood (center-heavy kernel) so biome
        // borders blend naturally instead of showing hard per-column seams.
        let r = 0, g = 0, b = 0, wsum = 0;
        for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
          const gi = ((z + dz + 2) * 20 + (x + dx + 2)) * 3;
          const wgt = 3 - Math.max(Math.abs(dx), Math.abs(dz)); // 3 center, 2 ring1, 1 ring2
          r += biomeTintGrid[gi] * wgt; g += biomeTintGrid[gi + 1] * wgt; b += biomeTintGrid[gi + 2] * wgt; wsum += wgt;
        }
        // Gentle smooth per-column variation (noise-based, no harsh random checkerboard)
        const vary = 0.97 + this.noise.n2(wx * 0.05, wz * 0.05) * 0.055 + coordHash(wx, wz, this.seed + 303) * 0.02;
        const ti = (z * 16 + x) * 3;
        tint[ti] = (r / wsum) * vary; tint[ti + 1] = (g / wsum) * vary; tint[ti + 2] = (b / wsum) * vary;
      }

      if (this.dimension === 'nether') {
        const ceilH = Math.floor(62 + this.noise.fbm(wx * 0.03 + 30, wz * 0.03 - 40, 3) * 10);
        const lavaLevel = 16;
        for (let y = 0; y <= 77; y++) {
          let id = 0;
          if (y === 0 || y === 77) id = ID.bedrock;
          else if (y <= h) {
            id = y === h && h > lavaLevel ? top : (y > h - 3 && biome === 'soul_sand_valley' ? top : ID.netherrack);
            if (biome === 'basalt_deltas' && y >= h - 2) id = top;
            if (id === ID.netherrack && y < h - 1) {
              const ore = coordHash(wx + y * 211, wz - y * 173, this.seed + 91);
              if (ore < 0.015) id = ID.nether_quartz_ore;
              else if (ore < 0.024) id = ID.nether_gold_ore;
              else if (ore < 0.026 && y <= 10) id = ID.ancient_debris;
            }
          } else if (y <= lavaLevel) {
            id = ID.lava;
          } else if (y >= ceilH) {
            id = ID.netherrack;
          }
          if (id) {
            padded[idx(x, y, z)] = id;
            maxY = Math.max(maxY, y + 1);
          }
        }
        // Hanging glowstone clusters on Nether ceiling
        if (coordHash(wx, wz, this.seed + 511) < 0.014) {
          const len = 2 + Math.floor(coordHash(wx, wz, this.seed + 512) * 4);
          for (let dy = 1; dy <= len; dy++) put(wx, ceilH - dy, wz, ID.glowstone, true);
        }
        // Basalt spires in basalt deltas
        if (biome === 'basalt_deltas' && h > lavaLevel + 1 && coordHash(wx, wz, this.seed + 523) < 0.032) {
          const spire = 2 + Math.floor(coordHash(wx, wz, this.seed + 524) * 5);
          for (let dy = 1; dy <= spire; dy++) put(wx, h + dy, wz, ID.basalt, true);
        }
        // Biome flora (Wiki: fungi forests, soul sand valley fire, basalt deltas magma).
        if (biome === 'crimson_forest') {
          const r = coordHash(wx, wz, this.seed + 531);
          if (r < 0.05 && ID.crimson_fungus !== undefined) put(wx, h + 1, wz, ID.crimson_fungus, false);
          else if (r < 0.12 && ID.crimson_roots !== undefined) put(wx, h + 1, wz, ID.crimson_roots, false);
          else if (r > 0.985 && ID.weeping_vines !== undefined) for (let dy = 1; dy <= 4; dy++) put(wx, h + 6 - dy, wz, ID.weeping_vines, false);
        } else if (biome === 'warped_forest') {
          const r = coordHash(wx, wz, this.seed + 532);
          if (r < 0.05 && ID.warped_fungus !== undefined) put(wx, h + 1, wz, ID.warped_fungus, false);
          else if (r < 0.1 && ID.warped_roots !== undefined) put(wx, h + 1, wz, ID.warped_roots, false);
          else if (r < 0.16 && ID.nether_sprouts !== undefined) put(wx, h + 1, wz, ID.nether_sprouts, false);
          else if (r > 0.985 && ID.twisting_vines !== undefined) for (let dy = 1; dy <= 4; dy++) put(wx, h + 6 - dy, wz, ID.twisting_vines, false);
        } else if (biome === 'nether_wastes') {
          const r = coordHash(wx, wz, this.seed + 533);
          if (r < 0.012 && ID.fire !== undefined) put(wx, h + 1, wz, ID.fire, false);
          if (r > 0.995 && ID.magma_block !== undefined) put(wx, h, wz, ID.magma_block, true);
        } else if (biome === 'soul_sand_valley') {
          const r = coordHash(wx, wz, this.seed + 534);
          if (r < 0.02 && ID.soul_fire !== undefined && (top === ID.soul_sand || top === ID.soul_soil)) put(wx, h + 1, wz, ID.soul_fire, false);
          if (r > 0.99 && ID.soul_torch !== undefined) put(wx, h + 1, wz, ID.soul_torch, false);
        } else if (biome === 'basalt_deltas') {
          const r = coordHash(wx, wz, this.seed + 535);
          if (r < 0.03 && ID.magma_block !== undefined) put(wx, h, wz, ID.magma_block, true);
          else if (r > 0.992 && ID.gilded_blackstone !== undefined) put(wx, h, wz, ID.gilded_blackstone, true);
        }
        // Nether bone fossil arches in Soul Sand Valley
        if (biome === 'soul_sand_valley' && h > lavaLevel + 1 && coordHash(wx, wz, this.seed + 527) < 0.015) {
          const archH = 3 + Math.floor(coordHash(wx, wz, this.seed + 528) * 3);
          for (let dy = 1; dy <= archH; dy++) {
            put(wx - 2, h + dy, wz, ID.bone_block, true);
            put(wx + 2, h + dy, wz, ID.bone_block, true);
          }
          for (let dx = -1; dx <= 1; dx++) put(wx + dx, h + archH + 1, wz, ID.bone_block, true);
        }
        continue;
      }

      if (this.dimension === 'end') {
        if (h < -10) continue;
        const bottom = Math.max(4, h - 10 - Math.floor(Math.abs(this.noise.n2(wx * 0.08, wz * 0.08)) * 10));
        for (let y = bottom; y <= h; y++) {
          padded[idx(x, y, z)] = ID.end_stone;
          maxY = Math.max(maxY, y + 1);
        }
        continue;
      }

      // Overworld terrain column
      const temp = this.climate(wx, wz).temp;
      for (let y = MIN_Y; y <= Math.max(h, SEA); y++) {
        let id = 0;
        if (y <= h) {
          if (biome === 'badlands' && y > h - 14) {
            const band = ((y + Math.floor(this.noise.n2(wx * 0.05, wz * 0.05) * 3)) % 6 + 6) % 6;
            id = y === h && h < SEA + 14 ? ID.red_sand : band === 0 ? ID.orange_terracotta : band === 1 ? ID.red_terracotta : band === 2 ? ID.yellow_terracotta : band === 3 ? ID.white_terracotta : ID.terracotta;
          } else {
            id = y === h ? (cliff && top === ID.grass_block ? ID.stone : top) : y > h - 4 ? (top === ID.sand || top === ID.red_sand ? top : cliff ? ID.stone : ID.dirt) : ID.stone;
          }
          if (y === MIN_Y) id = ID.bedrock;
          else if (id === ID.stone && y < 6 - ((wx * 7 + wz * 13 + y * 3) & 7)) id = ID.deepslate;
          if (y < h - 5 && y > MIN_Y + 2) {
            const cave = this.noise.n3(wx * 0.052, y * 0.069, wz * 0.052);
            const tube = Math.abs(this.noise.n3(wx * 0.037 + 90, y * 0.055, wz * 0.037 + 90));
            // "Cheese" caverns: wide open halls deep underground (1.18-style), on top of the older spaghetti tunnels.
            const cheese = y < 44 ? this.noise.n3(wx * 0.017 + 300, y * 0.031, wz * 0.017 - 300) : -1;
            if ((Math.abs(cave) < 0.065 && y < h - 9) || (tube < 0.033 && y < 52) || cheese > 0.5) {
              id = y < -54 ? ID.lava : 0;
            } else if (id === ID.stone || id === ID.deepslate) {
              const ore = coordHash(wx + y * 311, wz - y * 137, this.seed);
              let o = 0;
              if (ore < 0.014) { if (y > 0) o = ID.coal_ore; }
              else if (ore < 0.026) { if (y < 72) o = ID.iron_ore; }
              else if (ore < 0.034) { if (y < 96 && y > -16) o = ID.copper_ore; }
              else if (ore < 0.039) { if (y < 32) o = ID.gold_ore; }
              else if (ore < 0.045) { if (y < 16) o = ID.redstone_ore; }
              else if (ore < 0.0495) { if (y < 16) o = ID.diamond_ore; }
              else if (ore < 0.0535) { if (y < 64 && y > -32) o = ID.lapis_ore; }
              else if (ore < 0.0565) { if (y > 96) o = ID.emerald_ore; }
              if (o) id = id === ID.deepslate ? (ID['deepslate_' + BLOCKS[o].name] ?? o) : o;
            }
          }
        } else if (y <= SEA) {
          // Cold biomes freeze the top layer of still water (Wiki: ice in snowy/frozen biomes).
          const freezes = biome === 'snowy_plains' || biome === 'snowy_slopes' || biome === 'frozen_river' || biome === 'frozen_ocean' || biome === 'snowy_beach';
          // Frozen oceans are broken pack ice rather than one solid sheet.
          id = y === SEA && freezes && (biome !== 'frozen_ocean' || this.noise.n2(wx / 17 + 9.3, wz / 17 + 2.1) > -0.18) ? ID.ice : ID.water;
        }
        padded[idx(x, y, z)] = id;
      }
      maxY = Math.max(maxY, h + 1);
      // Cave biomes: decorate the floors and ceilings of carved caves (lush caves, dripstone caves, deep dark).
      {
        const kDark = this.noise.fbm(wx * 0.009 + 910, wz * 0.009 + 620, 2) > 0.3;
        const kLush = this.noise.fbm(wx * 0.012 + 500, wz * 0.012 - 320, 2) > 0.24;
        const kDrip = !kLush && this.noise.fbm(wx * 0.014 - 700, wz * 0.014 + 260, 2) > 0.26;
        if (kDark || kLush || kDrip) {
          const limit = Math.min(h - 8, 56);
          for (let y = MIN_Y + 3; y < limit; y++) {
            const i = idx(x, y, z);
            if (padded[i] !== 0) continue;
            const kind = y < 0 && kDark ? 3 : kLush ? 1 : kDrip ? 2 : 0;
            if (!kind) continue;
            const below = padded[i - 324], above = padded[i + 324];
            const solidBelow = below !== 0 && below !== ID.lava && BLOCKS[below]?.solid && BLOCKS[below].shape === 'cube';
            const solidAbove = above !== 0 && above !== ID.lava && BLOCKS[above]?.solid && BLOCKS[above].shape === 'cube';
            const r = coordHash(wx + y * 131, wz - y * 71, this.seed + 808);
            if (solidBelow) {
              if (kind === 1) { padded[i - 324] = r > 0.93 ? ID.clay : ID.moss_block; padded[i] = r < 0.1 ? ID.azalea : r < 0.14 ? ID.flowering_azalea : r < 0.36 ? ID.short_grass : r < 0.44 ? ID.moss_carpet : r < 0.47 ? ID.big_dripleaf : 0; }
              else if (kind === 2) { if (r < 0.7) padded[i - 324] = ID.dripstone_block; if (r < 0.26) padded[i] = ID.pointed_dripstone; }
              else { if (r < 0.9) padded[i - 324] = r < 0.02 ? ID.sculk_catalyst : ID.sculk_block; padded[i] = r > 0.985 ? ID.sculk_shrieker : r > 0.96 ? ID.sculk_sensor : 0; }
            } else if (solidAbove) {
              if (kind === 1) { padded[i + 324] = ID.moss_block; padded[i] = r < 0.16 ? ID.cave_vines : r < 0.2 ? ID.spore_blossom : r < 0.26 ? ID.hanging_roots : 0; }
              else if (kind === 2) { if (r < 0.7) padded[i + 324] = ID.dripstone_block; if (r < 0.32) padded[i] = ID.pointed_dripstone; }
              else if (r < 0.6) padded[i + 324] = ID.sculk_block;
            }
          }
        }
      }
      // Snow cover: a thin snow layer on grass in snowy plains and frozen rivers, never under water.
      if (h >= SEA && (biome === 'snowy_plains' || biome === 'snowy_beach') && ID.snow_layer !== undefined && !inExcl(wx, wz) && (top === ID.grass_block || top === ID.sand || top === ID.snow_block)) {
        put(wx, h + 1, wz, ID.snow_layer, false);
      }
      // Swamp pools: water flush with the low ground, with lily pads on top (Wiki: swamp is waterlogged).
      // Snowy plains: small ponds with an ice sheet on top (Wiki: snow-covered frozen lakes).
      if (biome === 'snowy_plains' && h >= SEA + 1 && !inExcl(wx, wz) && this.noise.n2(wx / 8 + 40.5, wz / 8 - 12.5) > 0.5) put(wx, h, wz, ID.ice, true);
      // Ocean vegetation: seagrass and kelp on the floor, sea pickles on sand; warm oceans grow coral.
      if ((biome === 'ocean' || biome === 'deep_ocean') && h < SEA - 1) {
        const r2 = coordHash(wx, wz, this.seed + 77);
        const floor = this.surface(biome, wx, wz, h);
        if (temp > 0.34 && floor === ID.sand && r2 < 0.05 && ID.tube_coral_block !== undefined) {
          const kind = [ID.tube_coral_block, ID.brain_coral_block, ID.bubble_coral_block, ID.fire_coral_block, ID.horn_coral_block][Math.floor(coordHash(wx, wz, this.seed + 78) * 5)];
          for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
            const d = Math.hypot(dx, dz);
            if (d > 2.4) continue;
            const x2 = wx + dx, z2 = wz + dz, h2 = this.height(x2, z2);
            if (h2 >= SEA - 1) continue;
            put(x2, h2 + 1, z2, d > 1.6 ? (ID.tube_coral ?? kind) : kind, true);
          }
        } else if (r2 < 0.05) {
          const tall = 2 + Math.floor(coordHash(wx, wz, this.seed + 79) * 8);
          for (let k = 1; k <= tall && h + k < SEA; k++) put(wx, h + k, wz, ID.kelp ?? ID.seagrass, true);
        } else if (r2 < 0.16) {
          put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
        } else if (r2 > 0.985 && floor === ID.sand && h > SEA - 8) put(wx, h + 1, wz, ID.sea_pickle ?? ID.seagrass, false);
      }
      if ((biome === 'river' || biome === 'frozen_river') && h < SEA - 1 && biome !== 'frozen_river') {
        if (coordHash(wx, wz, this.seed + 81) < 0.08) put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
      }
      if (biome === 'swamp' && h < SEA) {
        if (coordHash(wx, wz, this.seed + 82) < 0.06) put(wx, h + 1, wz, ID.seagrass ?? ID.kelp, true);
        if (coordHash(wx, wz, this.seed + 83) < 0.004 && h + 2 < SEA) put(wx, h + 2, wz, ID.seagrass ?? ID.kelp, false);
      }

      // Overworld flora & surface details (strictly matched to biome & excluded from structures!)
      if (h < SEA && h >= SEA - 3 && (biome === 'swamp' || biome === 'river') && coordHash(wx, wz, this.seed + 61) < (biome === 'swamp' ? 0.075 : 0.014)) {
        put(wx, SEA + 1, wz, ID.lily_pad ?? ID.short_grass, false);
      }

      if (h > SEA + 1 && !cliff && (top === ID.grass_block || top === ID.podzol || top === ID.mycelium) && !inExcl(wx, wz)) {
        const r = coordHash(wx, wz, this.seed + 44);
        if (biome === 'cherry_grove') {
          if (r < 0.28) put(wx, h + 1, wz, ID.pink_petals ?? ID.poppy, false);
        } else if (biome === 'flower_forest') {
          if (r < 0.2) put(wx, h + 1, wz, flowerAt(wx, wz, [ID.dandelion, ID.poppy, ID.allium, ID.azure_bluet, ID.orange_tulip, ID.pink_tulip, ID.white_tulip, ID.oxeye_daisy, ID.cornflower, ID.lily_of_the_valley]), false);
          else if (r < 0.38) put(wx, h + 1, wz, ID.short_grass, false);
        } else if (biome === 'taiga') {
          if (r < 0.11) put(wx, h + 1, wz, r < 0.075 ? (ID.fern ?? ID.short_grass) : ID.brown_mushroom, false);
        } else if (biome === 'mushroom_fields') {
          if (r < 0.06) put(wx, h + 1, wz, r < 0.03 ? ID.red_mushroom : ID.brown_mushroom, false);
        } else if (biome === 'meadow') {
          // Wiki: meadows are grassy with many flowers and no trees.
          if (r < 0.11) put(wx, h + 1, wz, flowerAt(wx, wz, [ID.dandelion, ID.poppy, ID.cornflower, ID.allium, ID.azure_bluet, ID.oxeye_daisy]), false);
          else if (r < 0.45) put(wx, h + 1, wz, ID.short_grass, false);
        } else if (biome === 'birch_forest') {
          if (r < 0.08) put(wx, h + 1, wz, r < 0.015 ? (ID.lily_of_the_valley ?? ID.dandelion) : ID.short_grass, false);
        } else if (biome === 'plains' || biome === 'sunflower_plains') {
          // Mostly short grass; flowers appear in occasional fields rather than everywhere.
          const field = this.noise.n2(wx / 37 + 5.5, wz / 37 - 9.9) > 0.22;
          if (r < (field ? 0.09 : 0.006)) put(wx, h + 1, wz, flowerAt(wx, wz, [ID.dandelion, ID.poppy, ID.azure_bluet, ID.oxeye_daisy, ID.cornflower]), false);
          else if (r < 0.3) put(wx, h + 1, wz, ID.short_grass, false);
        } else if (biome === 'swamp') {
          if (r < 0.12) put(wx, h + 1, wz, r < 0.03 ? (ID.blue_orchid ?? ID.short_grass) : r < 0.05 ? (ID.brown_mushroom ?? ID.short_grass) : ID.short_grass, false);
        } else if (biome === 'jungle') {
          if (r < 0.4) put(wx, h + 1, wz, r < 0.18 ? (ID.jungle_fern ?? ID.fern) : ID.short_grass, false);
          if (r > 0.965 && ID.bamboo !== undefined) for (let k = 1; k <= 2 + Math.floor(coordHash(wx, wz, this.seed + 84) * 6); k++) put(wx, h + k, wz, ID.bamboo, false);
          if (r > 0.992) for (let k = 1; k <= 3; k++) put(wx, h + k, wz, ID.cocoa ?? ID.jungle_log, false);
        } else if (biome === 'taiga' && r > 0.94 && ID.sweet_berry_bush !== undefined) {
          put(wx, h + 1, wz, ID.sweet_berry_bush, false);
        } else if (r < 0.09) {
          const f = r < 0.01 ? ID.poppy : r < 0.018 ? ID.dandelion : r < 0.024 ? ID.cornflower : r < 0.029 ? ID.oxeye_daisy : r < 0.034 ? ID.red_mushroom : r < 0.039 ? ID.brown_mushroom : ID.short_grass;
          put(wx, h + 1, wz, f ?? ID.short_grass, false);
        }
        // Sugar cane strictly next to water!
        const nextToWater = getH(x + 1, z) < SEA || getH(x - 1, z) < SEA || getH(x, z + 1) < SEA || getH(x, z - 1) < SEA;
        if (nextToWater && h === SEA + 1 && coordHash(wx, wz, this.seed + 66) < 0.06) {
          const sh = 2 + Math.floor(coordHash(wx, wz, this.seed + 67) * 2);
          for (let yy = 1; yy <= sh; yy++) put(wx, h + yy, wz, ID.sugar_cane, false);
        }
      }

      // Authentic Cactus & Desert Fossils (flat sand, strictly isolated)
      if ((biome === 'desert' || biome === 'badlands') && !cliff && h > SEA + 1 && (top === ID.sand || top === ID.red_sand) && !inExcl(wx, wz)) {
        const dr = coordHash(wx, wz, this.seed + 55);
        const flatNeighbors = getH(x + 1, z) <= h && getH(x - 1, z) <= h && getH(x, z + 1) <= h && getH(x, z - 1) <= h;
        if (dr < 0.0045 && flatNeighbors && ((wx + wz) & 1) === 0) {
          const ch = 1 + Math.floor(coordHash(wx, wz, this.seed + 59) * 3);
          for (let y = 1; y <= ch; y++) put(wx, h + y, wz, ID.cactus, true);
        } else if (dr < 0.018) {
          put(wx, h + 1, wz, ID.dead_bush ?? ID.short_grass, false);
        } else if (dr > 0.9996 && flatNeighbors && biome === 'desert') {   // surface fossils are a rare find, not scenery
          // Desert bone fossil spine emerging from dunes
          for (let dy = -1; dy <= 2; dy++) put(wx, h + dy, wz, ID.bone_block, true);
          put(wx - 1, h + 1, wz, ID.bone_block, true);
          put(wx + 1, h + 1, wz, ID.bone_block, true);
        }
      }
    }

    // Overworld Trees & Giant Mushrooms (strictly matched to exact trunk biome!)
    if (this.dimension === 'overworld') {
      for (let gz = Math.floor((oz - 5) / 7); gz <= Math.floor((oz + 21) / 7); gz++) {
        for (let gx = Math.floor((ox - 5) / 7); gx <= Math.floor((ox + 21) / 7); gx++) {
          const r = coordHash(gx, gz, this.seed + 818);
          const x = gx * 7 + Math.floor(coordHash(gx, gz, this.seed + 23) * 7);   // full-cell jitter: no visible planting grid
          const z = gz * 7 + Math.floor(coordHash(gx, gz, this.seed + 24) * 7);
          const h = this.height(x, z);
          if (h <= SEA + 2 || inExcl(x, z)) continue;
          const biome = this.biomeAt(x, z, h);
          const chance = biome === 'forest' ? 0.65 : biome === 'taiga' ? 0.62 : biome === 'jungle' ? 0.8 : biome === 'cherry_grove' ? 0.68 : biome === 'birch_forest' ? 0.7 : biome === 'flower_forest' ? 0.42 : biome === 'plains' ? 0.05 : biome === 'savanna' ? 0.14 : biome === 'swamp' ? 0.3 : biome === 'snowy_plains' ? 0.09 : biome === 'mushroom_fields' ? 0.28 : 0;
          if (r > chance) continue;
          const surf = this.surface(biome, x, z, h);
          if (surf !== ID.grass_block && surf !== ID.podzol && surf !== ID.mycelium && surf !== ID.snow_block) continue;

          if (biome === 'mushroom_fields') {
            const red = coordHash(gx, gz, this.seed + 911) < 0.5;
            const stemH = 4 + Math.floor(r * 4);
            for (let y = 1; y <= stemH; y++) put(x, h + y, z, ID.mushroom_stem ?? ID.bone_block ?? ID.birch_log);
            const cap = red ? ID.red_mushroom_block : ID.brown_mushroom_block;
            for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
              if (Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
              put(x + dx, h + stemH + 1, z + dz, cap, false);
              if (red && (Math.abs(dx) === 2 || Math.abs(dz) === 2)) put(x + dx, h + stemH, z + dz, cap, false);
            }
            continue;
          }

          const birch = (biome === 'forest' && r < 0.19) || biome === 'birch_forest';
          const cherry = biome === 'cherry_grove';
          const spruce = biome === 'taiga' || biome === 'snowy_plains';
          const acacia = biome === 'savanna';
          const jungle = biome === 'jungle';
          const swamp = biome === 'swamp';

          if (acacia) {
            // Authentic Savanna Acacia: diagonal angled trunk + branching umbrella canopies
            const bDir = (Math.floor(r * 4) % 4);
            const adx = bDir === 0 ? 1 : bDir === 1 ? -1 : 0;
            const adz = bDir === 2 ? 1 : bDir === 3 ? -1 : 0;
            let cx = x, cz = z;
            for (let y = 1; y <= 3; y++) put(cx, h + y, cz, ID.acacia_log);
            cx += adx; cz += adz;
            for (let y = 4; y <= 6; y++) put(cx, h + y, cz, ID.acacia_log);
            // Branch 1 + top umbrella canopy
            const topY = h + 7;
            for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
              if (Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
              put(cx + dx, topY, cz + dz, ID.acacia_leaves, false);
            }
            for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
              put(cx + dx, topY + 1, cz + dz, ID.acacia_leaves, false);
            }
            // Side branch
            const bx = cx - adx * 2, bz = cz - adz * 2, by = h + 5;
            put(cx - adx, h + 4, cz - adz, ID.acacia_log);
            put(bx, by, bz, ID.acacia_log);
            for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
              put(bx + dx, by + 1, bz + dz, ID.acacia_leaves, false);
            }
          } else if (jungle) {
            // Giant Jungle Tree with towering trunk and trailing vines
            const tall = 10 + Math.floor(r * 6);
            for (let y = 1; y <= tall; y++) {
              put(x, h + y, z, ID.jungle_log);
              if (y > 2 && y < tall - 1 && ((x + z + y) & 1) === 0) {
                put(x + 1, h + y, z, ID.jungle_leaves, false);
                put(x, h + y, z + 1, ID.jungle_leaves, false);
              }
            }
            for (let dy = -2; dy <= 1; dy++) {
              const rad = dy === 1 ? 2 : 3;
              for (let dz = -rad; dz <= rad; dz++) for (let dx = -rad; dx <= rad; dx++) {
                if (Math.abs(dx) === rad && Math.abs(dz) === rad && dy > -1) continue;
                put(x + dx, h + tall + dy, z + dz, ID.jungle_leaves, false);
              }
            }
            if (r < 0.22) put(x + 2, h + 1, z, ID.melon, false);
          } else if (swamp) {
            // Swamp Willow-style Oak with hanging vines down to water
            const trunk = 5 + Math.floor(r * 2);
            for (let y = 1; y <= trunk; y++) put(x, h + y, z, ID.oak_log);
            for (let dy = -1; dy <= 2; dy++) {
              const rad = dy === 2 ? 1 : 3;
              for (let dz = -rad; dz <= rad; dz++) for (let dx = -rad; dx <= rad; dx++) {
                if (Math.abs(dx) === rad && Math.abs(dz) === rad) continue;
                put(x + dx, h + trunk + dy, z + dz, ID.oak_leaves, false);
              }
            }
            // Hanging vines on canopy perimeter
            for (let i = 0; i < 6; i++) {
              const vx = x + ((i % 3) - 1) * 3, vz = z + (Math.floor(i / 3) * 2 - 1) * 3;
              for (let vy = 1; vy <= 3; vy++) put(vx, h + trunk - vy, vz, ID.oak_leaves, false);
            }
          } else if (spruce) {
            // Spruce / Taiga conical tiered evergreen
            const trunk = 7 + Math.floor(r * 3);
            for (let y = 1; y <= trunk + 1; y++) put(x, h + y, z, ID.spruce_log);
            for (let y = trunk + 2; y >= 3; y--) {
              const fromTop = trunk + 2 - y;
              const rad = fromTop === 0 ? 0 : fromTop === 1 ? 1 : (fromTop % 2 === 0 ? 2 : 1);
              for (let dz = -rad; dz <= rad; dz++) for (let dx = -rad; dx <= rad; dx++) {
                if (Math.abs(dx) === rad && Math.abs(dz) === rad && rad === 2) continue;
                put(x + dx, h + y, z + dz, ID.spruce_leaves, false);
              }
            }
            put(x, h + trunk + 2, z, ID.spruce_leaves, false);
          } else if (cherry) {
            // Cherry Grove branching pink canopy
            const trunk = 5;
            for (let y = 1; y <= trunk; y++) put(x, h + y, z, ID.cherry_log);
            put(x + 1, h + trunk, z, ID.cherry_log);
            put(x + 2, h + trunk + 1, z, ID.cherry_log);
            for (let dy = -1; dy <= 2; dy++) {
              const rad = dy === 2 ? 2 : 3;
              for (let dz = -rad; dz <= rad; dz++) for (let dx = -rad; dx <= rad; dx++) {
                if (Math.abs(dx) === rad && Math.abs(dz) === rad) continue;
                put(x + 1 + dx, h + trunk + dy, z + dz, ID.cherry_leaves, false);
              }
            }
          } else {
            // Forest & Birch standard deciduous trees
            const log = birch ? ID.birch_log : ID.oak_log;
            const leaf = birch ? ID.birch_leaves : ID.oak_leaves;
            const trunk = birch ? 6 + Math.floor(r * 2) : 5 + Math.floor(r * 2);
            for (let y = 1; y <= trunk; y++) put(x, h + y, z, log);
            for (let dy = -2; dy <= 1; dy++) {
              const radius = dy === 1 ? 1 : 2;
              for (let dz = -radius; dz <= radius; dz++) for (let dx = -radius; dx <= radius; dx++) {
                if (Math.abs(dx) === radius && Math.abs(dz) === radius && (dy === 1 || coordHash(x + dx, z + dz, dy + 44) < 0.55)) continue;
                put(x + dx, h + trunk + dy, z + dz, leaf, false);
              }
            }
          }
        }
      }
    }

    // Nether Crimson & Warped Giant Fungi
    if (this.dimension === 'nether') {
      for (let gz = Math.floor((oz - 4) / 9); gz <= Math.floor((oz + 20) / 9); gz++) {
        for (let gx = Math.floor((ox - 4) / 9); gx <= Math.floor((ox + 20) / 9); gx++) {
          const r = coordHash(gx, gz, this.seed + 613);
          if (r > 0.45) continue;
          const x = gx * 9 + Math.floor(coordHash(gx, gz, this.seed + 25) * 6);
          const z = gz * 9 + Math.floor(coordHash(gx, gz, this.seed + 26) * 6);
          const h = this.height(x, z);
          if (h <= 17) continue;
          const b = this.biomeAt(x, z, h);
          if (b !== 'crimson_forest' && b !== 'warped_forest') continue;
          const crimson = b === 'crimson_forest';
          const stem = crimson ? ID.crimson_log : ID.warped_log;
          const wart = crimson ? ID.crimson_leaves : ID.warped_leaves;
          const trunk = 5 + Math.floor(r * 5);
          for (let y = 1; y <= trunk; y++) put(x, h + y, z, stem);
          for (let dy = -2; dy <= 1; dy++) {
            const rad = dy === 1 ? 1 : 2;
            for (let dz = -rad; dz <= rad; dz++) for (let dx = -rad; dx <= rad; dx++) {
              if (Math.abs(dx) === rad && Math.abs(dz) === rad && dy > -1) continue;
              put(x + dx, h + trunk + dy, z + dz, dy === -1 && Math.abs(dx) === 1 && dz === 0 ? ID.shroomlight : wart, false);
            }
          }
        }
      }
    }

    // Outer End Chorus Trees
    if (this.dimension === 'end') {
      for (let gz = Math.floor((oz - 3) / 10); gz <= Math.floor((oz + 19) / 10); gz++) {
        for (let gx = Math.floor((ox - 3) / 10); gx <= Math.floor((ox + 19) / 10); gx++) {
          const x = gx * 10 + Math.floor(coordHash(gx, gz, this.seed + 911) * 7);
          const z = gz * 10 + Math.floor(coordHash(gx, gz, this.seed + 912) * 7);
          if (Math.hypot(x, z) < 120) continue;
          if (Math.hypot(x - 518, z - 12) < 20) continue; // Keep End City footprint clear
          const h = this.height(x, z);
          if (h < 10) continue;
          if (coordHash(gx, gz, this.seed + 913) < 0.35) {
            this.chorusTree(put, x, h + 1, z);
          }
        }
      }
    }

    // Structures
    if (structures && this.dimension === 'overworld') {
      // Starter cabin & starter village near spawn (always clean cross-chunk!)
      if (ox < 0 && ox >= -48 && oz < 0 && oz >= -48) this.cabin(put, foundation, -24, -19);
      if (ox >= -16 && ox < 48 && oz >= -16 && oz < 48) {
        this.plainsHouse(put, foundation, 6, 8, 5, 5);
        this.plainsHouse(put, foundation, 20, 10, 6, 5);
        this.plainsHouse(put, foundation, 8, 22, 5, 6);
        this.villageWellAndPaths(put, foundation, 15, 16);
        this.ruinedPortal(put, foundation, 40, 32);
      }
      // Stronghold End Portal Room!
      const [shx, shz] = this.strongholdPos();
      if (Math.abs(ox + 8 - shx) < 28 && Math.abs(oz + 8 - shz) < 28) {
        this.stronghold(put, shx, shz);
      }
      // Underground Monster Rooms (Dungeons with Spawner & Loot Chests)
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const room = this.dungeonAt(cx + dx, cz + dz);
        if (room) this.dungeon(put, room);
      }
      // Procedural Region Villages, Desert Villages, Desert Pyramids & Ruined Portals
      for (const s of nearby.list) {
        if (Math.abs(ox + 8 - s.x) > 36 || Math.abs(oz + 8 - s.z) > 36) continue;
        if (s.type === 'desert_village') this.desertVillage(put, foundation, s.x, s.z);
        else if (s.type === 'desert_pyramid') this.desertPyramid(put, foundation, s.x, s.z);
        else if (s.type === 'plains_village') {
          this.plainsHouse(put, foundation, s.x - 10, s.z - 8, 5, 5);
          this.plainsHouse(put, foundation, s.x + 5, s.z - 6, 6, 5);
          this.plainsHouse(put, foundation, s.x - 6, s.z + 6, 5, 6);
          this.villageWellAndPaths(put, foundation, s.x, s.z);
        } else if (s.type === 'ruined_portal') {
          this.ruinedPortal(put, foundation, s.x, s.z);
        } else if (s.type === 'witch_hut') {
          this.witchHut(put, foundation, s.x, s.z);
        } else if (s.type === 'desert_fossil') {
          this.desertFossil(put, s.x, s.z);
        }
      }
    }

    if (structures && this.dimension === 'nether') {
      // Safe landing pad at (0, 25, 0..10)
      if (Math.abs(ox) <= 16 && Math.abs(oz) <= 16) {
        for (let dz = -4; dz <= 12; dz++) for (let dx = -4; dx <= 4; dx++) {
          put(dx, 24, dz, ID.netherrack, true);
          for (let dy = 1; dy <= 5; dy++) put(dx, 24 + dy, dz, 0, true);
        }
      }
      // Guaranteed Nether Fortress near (32, 32) + region fortresses
      const nrx = Math.floor((ox + 8) / 128), nrz = Math.floor((oz + 8) / 128);
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const rrx = nrx + dx, rrz = nrz + dz;
        const fx = rrx === 0 && rrz === 0 ? 32 : rrx * 128 + 48;
        const fz = rrx === 0 && rrz === 0 ? 32 : rrz * 128 + 48;
        if ((rrx === 0 && rrz === 0) || coordHash(rrx, rrz, this.seed + 5555) < 0.42) {
          if (Math.abs(ox + 8 - fx) < 36 && Math.abs(oz + 8 - fz) < 36) this.fortress(put, fx, fz);
        }
      }
    }

    if (structures && this.dimension === 'end') {
      // Main Island Features
      if (Math.hypot(ox + 8, oz + 8) <= 72) {
        // Obsidian arrival platform at (0, 29, 42)
        for (let dz = 40; dz <= 44; dz++) for (let dx = -2; dx <= 2; dx++) {
          put(dx, 29, dz, ID.obsidian, true);
          for (let dy = 1; dy <= 5; dy++) put(dx, 29 + dy, dz, 0, true);
        }
        // 8 Obsidian Pillars
        for (const pil of endPillars()) {
          if (Math.abs(ox + 8 - pil.x) > 16 || Math.abs(oz + 8 - pil.z) > 16) continue;
          for (let y = 18; y <= pil.h; y++) {
            for (let dz = -pil.r; dz <= pil.r; dz++) for (let dx = -pil.r; dx <= pil.r; dx++) {
              if (dx * dx + dz * dz <= pil.r * pil.r + 1) put(pil.x + dx, y, pil.z + dz, ID.obsidian, true);
            }
          }
          put(pil.x, pil.h + 1, pil.z, ID.bedrock, true);
          if (pil.caged) {
            const cr = pil.r + 1;
            for (let y = pil.h + 1; y <= pil.h + 4; y++) {
              for (let dz = -cr; dz <= cr; dz++) for (let dx = -cr; dx <= cr; dx++) {
                if (Math.abs(dx) === cr || Math.abs(dz) === cr || y === pil.h + 4) put(pil.x + dx, y, pil.z + dz, ID.iron_bars, true);
              }
            }
          }
        }
        // Central Exit Portal Fountain at (0, 28, 0)
        if (Math.abs(ox + 8) < 16 && Math.abs(oz + 8) < 16) {
          for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
            const r2 = dx * dx + dz * dz;
            if (r2 <= 10) {
              put(dx, 27, dz, ID.bedrock, true);
              if (r2 >= 5) put(dx, 28, dz, ID.bedrock, true);
              else put(dx, 28, dz, 0, true);
            }
          }
          for (let dy = 1; dy <= 4; dy++) put(0, 27 + dy, 0, ID.bedrock, true);
          put(1, 30, 0, ID.torch, false); put(-1, 30, 0, ID.torch, false);
          put(0, 30, 1, ID.torch, false); put(0, 30, -1, ID.torch, false);
        }
        // End Gateway pedestal frame at (46, 33, 0)
        if (Math.abs(ox + 8 - END_GATEWAY_MAIN[0]) < 16 && Math.abs(oz + 8 - END_GATEWAY_MAIN[2]) < 16) {
          const [gx, gy, gz] = END_GATEWAY_MAIN;
          for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
            put(gx + dx, gy - 1, gz + dz, ID.bedrock, true);
            put(gx + dx, gy + 1, gz + dz, ID.bedrock, true);
          }
          put(gx, gy - 2, gz, ID.bedrock, true);
          put(gx, gy + 2, gz, ID.bedrock, true);
        }
      }

      // Guaranteed End City + End Ship on Arrival Island (520, 0)!
      if (Math.abs(ox + 8 - 526) < 42 && Math.abs(oz + 8) < 42) {
        this.endCity(put, 514, 8);
        this.endShip(put, 534, -18);
      }
      // Return Gateway at Outer Arrival Island (508, 29, 0)
      if (Math.abs(ox + 8 - 508) < 16 && Math.abs(oz + 8) < 16) {
        put(508, 28, 0, ID.bedrock, true);
        put(508, 30, 0, ID.bedrock, true);
        put(508, 29, 0, ID.end_gateway, true);
      }
      // Additional Procedural End Cities in Outer End
      const erx = Math.floor((ox + 8) / 144), erz = Math.floor((oz + 8) / 144);
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const rx2 = erx + dx, rz2 = erz + dz;
        const ex = rx2 * 144 + 72, ez = rz2 * 144 + 72;
        if (Math.hypot(ex, ez) < 160 || Math.hypot(ex - 520, ez) < 90) continue;
        if (coordHash(rx2, rz2, this.seed + 9876) < 0.35 && this.height(ex, ez) >= 20) {
          if (Math.abs(ox + 8 - ex) < 36 && Math.abs(oz + 8 - ez) < 36) this.endCity(put, ex - 4, ez - 4);
        }
      }
    }

    if (structures) placeExtraStructures(this, put, ox, oz);

    for (const [key, cell] of edits) {
      const [x, y, z] = key.split(',').map(Number);
      put(x, y, z, cell, true);
    }
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) for (let y = 0; y < HEIGHT; y++) {
      data[y * 256 + z * 16 + x] = padded[idx(x, y + MIN_Y, z)];
    }
    return { data, padded, tint, maxY: Math.min(MIN_Y + HEIGHT, maxY + 2) };
  }

  private placeBed(put: PutFn, x: number, y: number, z: number, facing: number) {
    // facing: 0=+Z, 1=-X, 2=-Z, 3=+X; head extends in -Z for facing=0? Keep simple: head at +1Z or +1X
    const dx = facing === 3 ? 1 : facing === 1 ? -1 : 0;
    const dz = facing === 0 ? 1 : facing === 2 ? -1 : 0;
    put(x, y, z, makeCell(ID.bed, facing), true);
    put(x + dx, y, z + dz, makeCell(ID.bed, facing | 4), true);
  }

  cabin(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const y = this.height(x + 3, z + 3) + 1;
    for (let dz = 0; dz < 7; dz++) for (let dx = 0; dx < 7; dx++) {
      foundation(x + dx, y - 1, z + dz, ID.cobblestone);
      for (let dy = 0; dy < 4; dy++) {
        const wall = dx === 0 || dx === 6 || dz === 0 || dz === 6;
        let id = wall ? ID.oak_planks : 0;
        if ((dx === 0 || dx === 6) && (dz === 0 || dz === 6)) id = ID.oak_log;
        if (wall && dy === 1 && (dx === 3 || dz === 3)) id = ID.glass;
        if (dz === 6 && dx === 3 && dy < 2) id = 0;
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    // Clear doorway front step
    put(x + 3, y, z + 6, ID.oak_door, true);
    put(x + 3, y + 1, z + 6, 0, true);
    // Solid gable roof
    for (let dy = 0; dy < 4; dy++) {
      for (let dz = -1; dz < 8; dz++) for (let dx = dy - 1; dx < 8 - dy; dx++) {
        put(x + dx, y + 4 + dy, z + dz, dy === 3 ? ID.oak_slab : ID.oak_planks, true);
      }
    }
    this.placeBed(put, x + 1, y, z + 1, 0);
    put(x + 5, y, z + 1, ID.crafting_table);
    put(x + 4, y, z + 1, ID.furnace);
    put(x + 5, y, z + 4, ID.chest);
    put(x + 1, y + 2, z + 4, ID.torch);
  }

  plainsHouse(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number, w = 5, d = 5) {
    const y = this.height(x + Math.floor(w / 2), z + Math.floor(d / 2)) + 1;
    const rnd = coordHash(x, z, this.seed + 4242);
    for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) {
      foundation(x + dx, y - 1, z + dz, ID.cobblestone);
      for (let dy = 0; dy < 3; dy++) {
        const wall = dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1;
        let id = wall ? ID.oak_planks : 0;
        if ((dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1)) id = ID.oak_log;
        // Windows on all walls (varied positions), door on front (+Z)
        if (wall && dy === 1) {
          const win = (dx === 1 || dx === w - 2 || dz === 1 || dz === d - 2) && !(dz === d - 1 && dx === Math.floor(w / 2));
          if (win) id = ID.glass;
        }
        if (dz === d - 1 && dx === Math.floor(w / 2) && dy < 2) id = dy === 0 ? ID.oak_door : 0;
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    // FULL solid hipped roof with overhang + chimney (fixes the missing ceiling bug!)
    for (let dz = -1; dz < d + 1; dz++) for (let dx = -1; dx < w + 1; dx++) put(x + dx, y + 3, z + dz, ID.oak_planks, true);
    for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) put(x + dx, y + 4, z + dz, ID.oak_planks, true);
    for (let dz = 1; dz < d - 1; dz++) for (let dx = 1; dx < w - 1; dx++) put(x + dx, y + 5, z + dz, ID.oak_slab, true);
    // Chimney
    const chx = x + (rnd < 0.5 ? 1 : w - 2), chz = z + 1;
    for (let dy = 4; dy <= 6; dy++) { put(chx, y + dy, chz, ID.cobblestone, true); }

    this.placeBed(put, x + 1, y, z + 1, 0);
    put(x + w - 2, y, z + 1, ID.crafting_table);
    put(x + w - 2, y, z + d - 2, ID.chest);
    put(x + Math.floor(w / 2), y + 2, z + Math.floor(d / 2), ID.torch);
  }

  villageWellAndPaths(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const pathId = ID.dirt_path ?? ID.gravel;
    for (let i = -8; i <= 10; i++) {
      const py = this.height(x + i, z); if (py > SEA) put(x + i, py, z, pathId);
      const pz = this.height(x, z + i); if (pz > SEA) put(x, pz, z + i, pathId);
    }
    const wy = this.height(x, z) + 1;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      foundation(x + dx, wy - 1, z + dz, ID.mossy_cobblestone ?? ID.cobblestone);
      put(x + dx, wy, z + dz, dx === 0 && dz === 0 ? ID.water : (ID.mossy_cobblestone ?? ID.cobblestone), true);
      if (Math.abs(dx) === 1 && Math.abs(dz) === 1) {
        put(x + dx, wy + 1, z + dz, ID.oak_fence, true);
        put(x + dx, wy + 2, z + dz, ID.oak_fence, true);
      }
      put(x + dx, wy + 3, z + dz, ID.oak_planks, true);
    }
    const ly = this.height(x + 5, z + 1) + 1;
    put(x + 5, ly, z + 1, ID.oak_fence);
    put(x + 5, ly + 1, z + 1, ID.oak_fence);
    put(x + 5, ly + 2, z + 1, ID.lantern ?? ID.torch);
  }

  desertVillage(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, cx: number, cz: number) {
    // Authentic Desert Sandstone Houses + Desert Well + Market Stall + Farm
    const houses = [[cx - 11, cz - 9, 6, 6], [cx + 4, cz - 8, 7, 6], [cx - 8, cz + 5, 6, 6]];
    for (const [hx, hz, w, d] of houses) {
      const y = this.height(hx + 3, hz + 3) + 1;
      for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) {
        foundation(hx + dx, y - 1, hz + dz, ID.sandstone);
        for (let dy = 0; dy < 4; dy++) {
          const wall = dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1;
          let id = 0;
          if (dy === 3) {
            // Flat roof with stepped parapet border
            id = wall ? ID.cut_sandstone : ID.sandstone;
          } else if (wall) {
            id = dy === 2 ? ID.cut_sandstone : ID.sandstone;
            if ((dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1)) id = ID.smooth_sandstone;
            if (dy === 1 && ((dx === 2 || dx === 3) && (dz === 0 || dz === d - 1) || (dz === 2) && (dx === 0 || dx === w - 1))) id = 0;
          }
          if (dz === d - 1 && dx === Math.floor(w / 2) && dy < 2) id = 0;
          put(hx + dx, y + dy, hz + dz, id, true);
        }
        // Rooftop parapet corners & orange terracotta trim
        if ((dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1)) put(hx + dx, y + 4, hz + dz, ID.orange_terracotta, true);
        else if (dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1) put(hx + dx, y + 4, hz + dz, ID.sandstone_slab, true);
      }
      this.placeBed(put, hx + 1, y, hz + 1, 0);
      put(hx + w - 2, y, hz + 1, ID.crafting_table);
      put(hx + w - 2, y, hz + d - 2, ID.chest);
      put(hx + 2, y + 2, hz + 2, ID.torch);
    }

    // Desert Well at center
    const wy = this.height(cx, cz) + 1;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      foundation(cx + dx, wy - 1, cz + dz, ID.sandstone);
      put(cx + dx, wy, cz + dz, dx === 0 && dz === 0 ? ID.water : ID.sandstone, true);
      if (Math.abs(dx) === 1 && Math.abs(dz) === 1) {
        put(cx + dx, wy + 1, cz + dz, ID.sandstone, true);
        put(cx + dx, wy + 2, cz + dz, ID.sandstone, true);
      }
      put(cx + dx, wy + 3, cz + dz, ID.sandstone_slab, true);
    }

    // Market Stall with colorful awning
    const mx = cx + 6, mz = cz + 6, my = this.height(mx + 2, mz + 2) + 1;
    for (let dz = 0; dz < 4; dz++) for (let dx = 0; dx < 5; dx++) {
      foundation(mx + dx, my - 1, mz + dz, ID.cut_sandstone);
      for (let dy = 0; dy < 4; dy++) put(mx + dx, my + dy, mz + dz, 0, true);
      if ((dx === 0 || dx === 4) && (dz === 0 || dz === 3)) {
        put(mx + dx, my, mz + dz, ID.oak_fence, true);
        put(mx + dx, my + 1, mz + dz, ID.oak_fence, true);
        put(mx + dx, my + 2, mz + dz, ID.oak_fence, true);
      }
      put(mx + dx, my + 3, mz + dz, dx % 2 === 0 ? ID.orange_wool : ID.white_wool, true);
    }
    put(mx + 1, my, mz + 1, ID.hay_block, true);
    put(mx + 2, my, mz + 1, ID.chest, true);
  }

  desertPyramid(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, cx: number, cz: number) {
    const y = this.height(cx, cz) + 1;
    const half = 9;
    // Stepped 19x19 pyramid base + foundation
    for (let dz = -half; dz <= half; dz++) for (let dx = -half; dx <= half; dx++) {
      foundation(cx + dx, y - 1, cz + dz, ID.sandstone);
    }
    for (let step = 0; step < 9; step++) {
      const r = half - step;
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        const edge = Math.abs(dx) === r || Math.abs(dz) === r;
        const inner = Math.abs(dx) < r - 1 && Math.abs(dz) < r - 1 && step < 7;
        put(cx + dx, y + step, cz + dz, inner ? 0 : edge ? ID.sandstone : ID.cut_sandstone, true);
      }
    }
    // Sun & Ankh Terracotta Floor Pattern + Secret Treasure Pit beneath center!
    for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
      const isCenter = dx === 0 && dz === 0;
      const isCross = (dx === 0 || dz === 0) && Math.abs(dx) <= 2 && Math.abs(dz) <= 2;
      put(cx + dx, y - 1, cz + dz, isCenter ? ID.blue_terracotta : isCross ? ID.orange_terracotta : ID.sandstone, true);
    }
    // Buried treasure chamber below center (safe sandstone walls + 4 chests + TNT trap below center)
    for (let dy = 2; dy <= 7; dy++) {
      for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
        const wall = Math.abs(dx) === 2 || Math.abs(dz) === 2 || dy === 7;
        put(cx + dx, y - dy, cz + dz, wall ? ID.cut_sandstone : 0, true);
      }
    }
    put(cx + 1, y - 6, cz, ID.chest, true);
    put(cx - 1, y - 6, cz, ID.chest, true);
    put(cx, y - 6, cz + 1, ID.chest, true);
    put(cx, y - 6, cz - 1, ID.chest, true);
    put(cx, y - 7, cz, ID.tnt, true);

    // Twin Front Towers & Arched Entrance facing +Z
    for (const sx of [-7, 5]) {
      for (let dz = 6; dz <= 10; dz++) for (let dx = sx; dx <= sx + 2; dx++) {
        foundation(cx + dx, y - 1, cz + dz, ID.sandstone);
        for (let dy = 0; dy < 9; dy++) {
          const id = dy === 4 && dx === sx + 1 ? ID.chiseled_sandstone : dy === 5 && dx === sx + 1 ? ID.orange_terracotta : ID.sandstone;
          put(cx + dx, y + dy, cz + dz, id, true);
        }
      }
    }
    for (let dy = 0; dy < 3; dy++) for (let dx = -1; dx <= 1; dx++) {
      for (let dz = 6; dz <= 10; dz++) put(cx + dx, y + dy, cz + dz, 0, true);
    }
    put(cx - 2, y + 2, cz + 8, ID.torch, true);
    put(cx + 2, y + 2, cz + 8, ID.torch, true);
  }

  witchHut(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const y = SEA + 4;
    // 4 Stilt Legs from swamp bed up to hut floor
    for (const [lx, lz] of [[x, z], [x + 6, z], [x, z + 6], [x + 6, z + 6]]) {
      foundation(lx, SEA - 1, lz, ID.spruce_log);
      for (let yy = SEA; yy <= y; yy++) put(lx, yy, lz, ID.spruce_log, true);
    }
    // Floor
    for (let dz = 0; dz <= 6; dz++) for (let dx = 0; dx <= 6; dx++) {
      put(x + dx, y, z + dz, ID.spruce_planks, true);
    }
    // Walls & Windows
    for (let dy = 1; dy <= 3; dy++) for (let dz = 0; dz <= 6; dz++) for (let dx = 0; dx <= 6; dx++) {
      const wall = dx === 0 || dx === 6 || dz === 0 || dz === 6;
      if (wall) {
        let id = ID.spruce_planks;
        if (dy === 2 && ((dx === 3 && (dz === 0 || dz === 6)) || (dz === 3 && dx === 6))) id = ID.oak_fence;
        if (dz === 6 && dx === 3 && dy < 3) id = 0;
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    // Roof Overhang
    for (let dz = -1; dz <= 7; dz++) for (let dx = -1; dx <= 7; dx++) {
      put(x + dx, y + 4, z + dz, ID.spruce_planks, true);
    }
    for (let dz = 0; dz <= 6; dz++) for (let dx = 0; dx <= 6; dx++) {
      put(x + dx, y + 5, z + dz, ID.spruce_slab, true);
    }
    // Witch Hut Interior
    put(x + 2, y + 1, z + 2, ID.crafting_table, true);
    put(x + 4, y + 1, z + 2, ID.cauldron ?? ID.blackstone, true);
    put(x + 1, y + 2, z + 5, ID.torch, true);
  }

  desertFossil(put: PutFn, cx: number, cz: number) {
    const y = this.height(cx, cz);
    // Huge curved bone ribs protruding from desert sand
    for (let r = 0; r < 4; r++) {
      const fz = cz + r * 3 - 4;
      for (let dy = 0; dy <= 4; dy++) {
        put(cx - 3, y + dy, fz, ID.bone_block, true);
        put(cx + 3, y + dy, fz, ID.bone_block, true);
      }
      for (let dx = -2; dx <= 2; dx++) {
        put(cx + dx, y + 4, fz, ID.bone_block, true);
      }
      put(cx, y + 5, fz, ID.bone_block, true);
    }
  }

  ruinedPortal(put: PutFn, foundation: (x: number, y: number, z: number, id: number) => void, x: number, z: number) {
    const y = this.height(x, z) + 1;
    for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
      if (Math.abs(dx) + Math.abs(dz) <= 3) {
        foundation(x + dx, y - 1, z + dz, ID.netherrack);
        put(x + dx, y - 1, z + dz, coordHash(dx, dz, 11) < 0.25 ? ID.magma_block : ID.netherrack, true);
      }
    }
    for (let dy = 0; dy < 5; dy++) {
      put(x - 1, y + dy, z, dy === 2 ? ID.crying_obsidian : ID.obsidian, true);
      if (dy < 4) put(x + 2, y + dy, z, ID.obsidian, true);
    }
    put(x, y, z, ID.obsidian, true); put(x + 1, y, z, ID.obsidian, true);
    put(x, y + 4, z, ID.crying_obsidian, true); put(x + 1, y + 4, z, ID.gold_ore, true);
    put(x - 2, y, z + 1, ID.chest, true);
  }

  stronghold(put: PutFn, cx: number, cz: number) {
    const floorY = 30;
    const surfY = this.height(cx, cz);
    // Stone brick spiral shaft from surface down to portal chamber
    for (let y = floorY; y <= surfY + 2; y++) {
      for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
        const wall = Math.abs(dx) === 2 || Math.abs(dz) === 2;
        put(cx + dx, y, cz + dz - 7, wall ? (coordHash(dx + y, dz, 33) < 0.25 ? ID.mossy_stone_bricks : ID.stone_bricks) : 0, true);
      }
      if (y <= surfY) put(cx, y, cz - 6, ID.ladder, true);
    }
    // End Portal Chamber (11x7x11) with doorway connecting to spiral ladder shaft
    for (let dy = 0; dy < 7; dy++) for (let dz = -5; dz <= 5; dz++) for (let dx = -5; dx <= 5; dx++) {
      const door = dz === -5 && Math.abs(dx) <= 1 && dy >= 1 && dy <= 3;
      const shell = !door && (Math.abs(dx) === 5 || Math.abs(dz) === 5 || dy === 0 || dy === 6);
      const brick = coordHash(dx + dy, dz, 71) < 0.25 ? ID.mossy_stone_bricks : ID.stone_bricks;
      put(cx + dx, floorY + dy, cz + dz, shell ? brick : 0, true);
    }
    // Staircase up to End Portal ring
    for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
      put(cx + dx, floorY + 1, cz + dz, Math.abs(dx) <= 1 && Math.abs(dz) <= 1 ? ID.lava : ID.stone_bricks, true);
    }
    put(cx, floorY + 1, cz + 3, ID.stone_brick_stairs, true);
    // 12 End Portal Frames forming 3x3 inner ring! (3 pre-filled with eyes, 9 empty!)
    const ring: [number, number, number, boolean][] = [
      [-1, -2, 0, true], [0, -2, 0, false], [1, -2, 0, false],
      [2, -1, 1, false], [2, 0, 1, true], [2, 1, 1, false],
      [1, 2, 2, false], [0, 2, 2, false], [-1, 2, 2, true],
      [-2, 1, 3, false], [-2, 0, 3, false], [-2, -1, 3, false],
    ];
    for (const [dx, dz, facing, eye] of ring) {
      put(cx + dx, floorY + 2, cz + dz, makeCell(ID.end_portal_frame, facing | (eye ? 4 : 0)), true);
    }
    put(cx - 4, floorY + 1, cz - 4, ID.chest, true);
    put(cx + 4, floorY + 2, cz + 4, ID.torch, true);
    put(cx - 4, floorY + 2, cz + 4, ID.torch, true);
    put(cx + 4, floorY + 2, cz - 4, ID.torch, true);
  }

  fortress(put: PutFn, x: number, z: number) {
    const y = 26;
    // Tall Nether Brick pillars descending into the lava ocean
    for (const [px, pz] of [[0, 0], [13, 0], [0, 13], [13, 13], [6, 6]]) {
      for (let yy = 8; yy < y; yy++) {
        for (let dz = 0; dz < 2; dz++) for (let dx = 0; dx < 2; dx++) put(x + px + dx, yy, z + pz + dz, ID.nether_bricks, true);
      }
    }
    // Fortress Courtyard & Battlements
    for (let dz = 0; dz < 15; dz++) for (let dx = 0; dx < 15; dx++) {
      put(x + dx, y, z + dz, ID.nether_bricks, true);
      for (let dy = 1; dy <= 5; dy++) put(x + dx, y + dy, z + dz, 0, true);
      const wall = dx === 0 || dx === 14 || dz === 0 || dz === 14;
      if (wall) {
        put(x + dx, y + 1, z + dz, ID.nether_bricks, true);
        if ((dx + dz) % 2 === 0) put(x + dx, y + 2, z + dz, ID.nether_bricks, true);
      }
    }
    // Blaze Spawner Sanctuary Platform in center
    for (let dz = 5; dz <= 9; dz++) for (let dx = 5; dx <= 9; dx++) {
      put(x + dx, y + 1, z + dz, ID.nether_bricks, true);
    }
    put(x + 7, y + 2, z + 7, ID.glowstone, true);
    put(x + 2, y + 1, z + 2, ID.chest, true);
    put(x + 12, y + 1, z + 12, ID.chest, true);
    put(x + 2, y + 2, z + 12, ID.fire, true);
    put(x + 12, y + 2, z + 2, ID.fire, true);
  }

  chorusTree(put: PutFn, x: number, y: number, z: number) {
    const h = 3 + Math.floor(coordHash(x, z, this.seed + 313) * 3);
    for (let dy = 0; dy < h; dy++) put(x, y + dy, z, ID.chorus_plant, true);
    const branches: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    for (let b = 0; b < 2; b++) {
      const [bx, bz] = branches[(Math.abs(x + z) + b) % 4];
      put(x + bx, y + h - 1, z + bz, ID.chorus_plant, true);
      put(x + bx, y + h, z + bz, ID.chorus_plant, true);
      put(x + bx, y + h + 1, z + bz, ID.chorus_flower, true);
    }
    put(x, y + h, z, ID.chorus_flower, true);
  }

  endCity(put: PutFn, x: number, z: number) {
    const y = Math.max(27, this.height(x + 5, z + 5) + 1);
    // Grand 11x11 Base Hall -> Rising Purpur Tower -> Crown Room with Chests & End Rods
    for (let dz = 0; dz < 11; dz++) for (let dx = 0; dx < 11; dx++) {
      for (let yy = y - 3; yy < y; yy++) put(x + dx, yy, z + dz, ID.end_stone_bricks, true);
      for (let dy = 0; dy < 7; dy++) {
        const wall = dx === 0 || dx === 10 || dz === 0 || dz === 10;
        let id = 0;
        if (dy === 0 || dy === 6) id = ID.end_stone_bricks;
        else if (wall) {
          id = (dx === 0 || dx === 10) && (dz === 0 || dz === 10) ? ID.purpur_pillar : dy === 3 && (dx === 5 || dz === 5) ? ID.magenta_stained_glass : ID.purpur_block;
          if (dz === 0 && dx === 5 && dy <= 2) id = 0;
        }
        put(x + dx, y + dy, z + dz, id, true);
      }
    }
    // Upper Spire Tower (7x7 rising 12 blocks!)
    for (let dy = 7; dy < 20; dy++) for (let dz = 2; dz <= 8; dz++) for (let dx = 2; dx <= 8; dx++) {
      const wall = dx === 2 || dx === 8 || dz === 2 || dz === 8;
      let id = 0;
      if (dy === 13 || dy === 19) id = ID.purpur_block;
      else if (wall) {
        id = (dx === 2 || dx === 8) && (dz === 2 || dz === 8) ? ID.purpur_pillar : dy % 4 === 2 && (dx === 5 || dz === 5) ? ID.magenta_stained_glass : ID.end_stone_bricks;
      }
      put(x + dx, y + dy, z + dz, id, true);
    }
    // Crown Room Loot & End Rods
    for (let dy = 20; dy < 26; dy++) for (let dz = 1; dz <= 9; dz++) for (let dx = 1; dx <= 9; dx++) {
      const wall = dx === 1 || dx === 9 || dz === 1 || dz === 9;
      let id = 0;
      if (dy === 25) id = ID.purpur_block;
      else if (wall) id = dy === 22 && (dx === 5 || dz === 5) ? ID.magenta_stained_glass : ID.purpur_block;
      put(x + dx, y + dy, z + dz, id, true);
    }
    // Central ladder & End Rod lighting & Treasure Chests!
    for (let dy = 1; dy <= 20; dy++) put(x + 5, y + dy, z + 5, ID.ladder, true);
    put(x + 3, y + 20, z + 3, ID.chest, true);
    put(x + 7, y + 20, z + 7, ID.shulker_box, true);
    put(x + 3, y + 21, z + 7, ID.end_rod, true);
    put(x + 7, y + 21, z + 3, ID.end_rod, true);
    put(x + 2, y + 1, z + 2, ID.end_rod, true);
    put(x + 8, y + 1, z + 8, ID.end_rod, true);
    put(x + 5, y + 1, z - 1, ID.end_rod, true);
  }

  endShip(put: PutFn, x: number, z: number) {
    const y = 39;
    // Floating End Ship hull (7 wide x 15 long)
    for (let dz = 0; dz < 15; dz++) {
      const hw = dz < 2 ? 1 : dz < 4 ? 2 : dz > 12 ? 2 : 3;
      for (let dx = -hw; dx <= hw; dx++) {
        put(x + dx, y, z + dz, ID.purpur_block, true);
        put(x + dx, y + 1, z + dz, Math.abs(dx) === hw ? ID.end_stone_bricks : ID.purpur_block, true);
        put(x + dx, y + 2, z + dz, Math.abs(dx) === hw || dz === 0 || dz === 14 ? ID.purpur_block : 0, true);
        if (Math.abs(dx) === hw || dz === 14) put(x + dx, y + 3, z + dz, ID.purpur_stairs, true);
      }
    }
    // Stern Cabin
    for (let dy = 2; dy <= 6; dy++) for (let dz = 10; dz <= 14; dz++) for (let dx = -3; dx <= 3; dx++) {
      const wall = Math.abs(dx) === 3 || dz === 10 || dz === 14 || dy === 6;
      put(x + dx, y + dy, z + dz, wall ? (dy === 4 && Math.abs(dx) <= 1 ? ID.magenta_stained_glass : ID.purpur_pillar) : 0, true);
    }
    put(x, y + 2, z + 10, 0, true); put(x, y + 3, z + 10, 0, true);
    // Mast + End Rods
    for (let dy = 2; dy <= 10; dy++) put(x, y + dy, z + 6, ID.end_stone_bricks, true);
    put(x, y + 11, z + 6, ID.end_rod, true);
    put(x, y + 3, z - 1, ID.dragon_head, true);
    put(x, y + 2, z + 12, ID.chest, true); // Contains Elytra!
    put(x - 1, y + 2, z + 12, ID.brewing_stand, true);
    put(x + 1, y + 2, z + 12, ID.end_rod, true);
  }
}

export function blockIndex(x: number, y: number, z: number) { return (y - MIN_Y) * 256 + z * 16 + x; }
export function blockName(id: number) { return BLOCKS[id]?.name ?? 'air'; }
