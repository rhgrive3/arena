// Overworld terrain + biome source, modelled on vanilla 1.18+ "multi-noise" generation.
//
// Five slowly varying climate parameters are sampled per column:
//   C  continentalness  ocean → coast → inland            (decides the base height)
//   E  erosion          mountainous (low) → flat (high)   (decides how much relief there is)
//   W  weirdness        folded into PV "peaks & valleys"   (valleys become rivers, peaks become ridges)
//   T  temperature, H humidity                             (only pick the biome, never the height)
//
// Height is a *continuous* function of (C, E, PV) plus small detail noise — there are no thresholds that make the ground
// jump, so cliffs can only come from the mountain/ridge terms whose slopes are bounded by the noise wavelengths.
// The biome is then chosen from the very same parameters, which keeps biomes and terrain shape consistent
// (mountain biomes sit on mountains, swamps on flat lowland, rivers in the valleys, beaches on the coast).

export interface NoiseLike { n2(x: number, z: number): number; fbm(x: number, z: number, octaves?: number): number; }

const SEA = 63;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const sstep = (a: number, b: number, x: number) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** Continentalness → ground offset from sea level for flat lowland (deep ocean … beach … far inland plateau). */
const CONT: [number, number][] = [[-0.62, -35], [-0.45, -31], [-0.33, -19], [-0.22, -9], [-0.165, -1.5], [-0.12, 1.6], [-0.05, 3.2], [0.1, 5.5], [0.35, 8.5], [0.7, 12]];
function spline(pts: [number, number][], v: number) {
  if (v <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) if (v <= pts[i][0]) { const a = pts[i - 1], b = pts[i]; return a[1] + ((b[1] - a[1]) * (v - a[0])) / (b[0] - a[0]); }
  return pts[pts.length - 1][1];
}

// Temperature bands (vanilla: frozen, cold, temperate, warm, hot).
const T_FROZEN = -0.45, T_COLD = -0.15, T_WARM = 0.2, T_HOT = 0.52;
/** Spawn sits in the middle of a guaranteed temperate lowland so every world starts in a forest/plains area. */
const SPAWN_X = -11, SPAWN_Z = 27;

export class Column {
  x = NaN; z = NaN;
  C = 0; E = 0; W = 0; T = 0; H = 0; pv = 0;
  /** Unrounded surface height. */
  hf = SEA;
  inland = 0; mount = 0; hills = 0; swampy = 0; river = 0; island = 0;
  /** 0 at the valley floor … 1 on the ridge line. */
  s = 0;
  /** Share of the full mountain relief present here (0 = lowland, 1 = summit of a full mountain). */
  high = 0;
}

export class OverworldGen {
  private cache: Column[] = Array.from({ length: 8192 }, () => new Column());
  private kC: number; private kE: number; private kW: number; private kT: number; private kH: number;

  constructor(private n: NoiseLike) {
    // Perlin fBm has no fixed amplitude, so each field is normalised to a standard deviation of 0.4 for this seed.
    // That makes the thresholds below mean the same share of the world for every seed.
    this.kC = this.norm(37.13, -81.71, 4); this.kE = this.norm(-143.3, 59.9, 2); this.kW = this.norm(211.7, 97.3, 2);
    this.kT = this.norm(-17.9, -263.1, 3); this.kH = this.norm(301.3, 9.1, 3);
  }

  private norm(ox: number, oz: number, octaves: number) {
    let sum = 0;
    for (let j = 0; j < 40; j++) for (let i = 0; i < 40; i++) { const v = this.n.fbm(ox + i * 0.61, oz + j * 0.61, octaves); sum += v * v; }
    return 0.4 / Math.sqrt(sum / 1600);
  }

  column(x: number, z: number): Column {
    x = Math.floor(x); z = Math.floor(z);
    const c = this.cache[(Math.imul(x, 73856093) ^ Math.imul(z, 19349663)) & 8191];
    if (c.x !== x || c.z !== z) this.compute(x, z, c);
    return c;
  }

  private compute(x: number, z: number, c: Column) {
    const n = this.n;
    // A gentle domain warp hides the grid alignment of the lattice noise.
    const qx = x + n.n2(x * 0.0063 + 11.3, z * 0.0063 - 7.7) * 20, qz = z + n.n2(x * 0.0063 - 31.9, z * 0.0063 + 17.1) * 20;
    let C = clamp(n.fbm(qx / 1300 + 37.13, qz / 1300 - 81.71, 4) * this.kC, -1.15, 1.15);
    // Erosion and weirdness shape the big relief, so they only use two octaves: every extra octave of fBm adds as much
    // slope as the first one, and steep mountain flanks came almost entirely from that fine detail.
    let E = clamp(n.fbm(qx / 1000 - 143.3, qz / 1000 + 59.9, 2) * this.kE, -1.15, 1.15);
    const W = clamp(n.fbm(qx / 560 + 211.7, qz / 560 + 97.3, 2) * this.kW, -1, 1);
    /** Smoothed continentalness: mountains fade in over a long distance from the coast. */
    const Cs = n.fbm(qx / 1300 + 37.13, qz / 1300 - 81.71, 2) * this.kC;
    // Climate gets an extra small-scale warp so biome borders wiggle by a few blocks instead of running dead straight.
    // (Jittering the coordinates, not the values, keeps borders clean even where the climate changes very slowly.)
    const bx = qx + n.n2(x / 41 + 3.9, z / 41 - 14.2) * 10, bz = qz + n.n2(x / 41 - 23.7, z / 41 + 5.8) * 10;
    let T = clamp(n.fbm(bx / 1500 - 17.9, bz / 1500 - 263.1, 3) * this.kT, -1.15, 1.15);
    let H = clamp(n.fbm(bx / 1050 + 301.3, bz / 1050 + 9.1, 3) * this.kH, -1.15, 1.15);
    let pv = 1 - Math.abs(3 * Math.abs(W) - 2);

    const dSpawn = Math.hypot(x - SPAWN_X, z - SPAWN_Z);
    if (dSpawn < 560) {
      const f = sstep(560, 200, dSpawn);
      C = lerp(C, Math.max(C, 0.2), f);
      E = lerp(E, clamp(E, -0.02, 0.38), f);
      T = lerp(T, clamp(T, -0.08, 0.16), f);
      H = lerp(H, clamp(H, -0.08, 0.26), f);
      if (dSpawn < 150) pv = lerp(pv, Math.max(pv, -0.25), sstep(150, 80, dSpawn));   // no river through the starter village
    }

    const inland = sstep(-0.17, 0.02, C);
    const mount = sstep(-0.1, -0.7, E) * sstep(-0.05, 0.4, Math.min(C, Cs));
    const hills = sstep(0.4, -0.2, E);
    const swampy = sstep(0.42, 0.6, E) * sstep(-0.1, 0, C) * (1 - mount);
    const s = clamp((pv + 0.86) / 1.86, 0, 1);
    const island = sstep(-0.9, -1.02, C);

    let off = spline(CONT, C);
    if (C < -0.15) off += sstep(-0.15, -0.32, C) * n.fbm(x / 130 + 5.5, z / 130 - 9.5, 2) * 7;            // sea-floor relief
    if (island > 0) off = lerp(off, 4.5 + n.fbm(x / 60 + 9.1, z / 60 + 4.4, 2) * 4, island);                // mushroom island
    let river = 0, high = 0;
    if (inland > 0) {
      // Land sinks towards the valley floor so river banks are always low and gentle, however high the hinterland is.
      if (off > 2.2) off = lerp(off, 2.2, sstep(-0.3, -0.86, pv) * inland);
      const ss = s * s * (3 - 2 * s);
      high = mount * Math.pow(s, 1.5);
      const rolling = n.fbm(x / 115 + 71.3, z / 115 - 13.9, 3), bumps = n.n2(x / 29 - 5.1, z / 29 + 44.7);
      let relief = (2.5 + 15 * hills) * ss + 82 * high + rolling * (5 + 9 * hills) * (0.35 + 0.65 * s) + bumps * 1.2;
      if (mount > 0) {
        const ridge = 1 - Math.abs(n.n2(x / 58 + 19.7, z / 58 + 3.3)) * 2;                                  // sharp crests on the summits
        relief += mount * s * s * (ridge * 5 + n.n2(x / 19 + 7.7, z / 19 - 2.2) * 1.5);
        relief += mount * s * n.fbm(x / 52 - 40.4, z / 52 + 21.2, 2) * 9;                                   // spurs and gullies
      }
      off += inland * relief;
      // Erosion 6: waterlogged flats with shallow pools (swamps when the climate fits).
      if (swampy > 0) off = lerp(off, -0.55 + n.n2(x / 9 + 3.3, z / 9 - 8.8) * 1.6 + n.n2(x / 23 - 1.4, z / 23 + 6.2) * 1.1, swampy);
      // Badlands: terrace the hills into mesas.
      const mesa = sstep(T_HOT - 0.02, T_HOT + 0.1, T) * sstep(0.35, 0.8, hills) * inland;
      if (mesa > 0 && off > 4) { const t = off / 7, f = Math.floor(t); off = lerp(off, (f + sstep(0.3, 0.7, t - f)) * 7, mesa); }
      river = sstep(-0.86, -0.95, pv) * sstep(-0.19, -0.1, C);
      if (river > 0) off = lerp(off, -4.3 + bumps * 0.8, river);
    }

    c.x = x; c.z = z; c.C = C; c.E = E; c.W = W; c.T = T; c.H = H; c.pv = pv;
    c.hf = SEA + off + 0.5; c.inland = inland; c.mount = mount; c.hills = hills; c.swampy = swampy; c.river = river; c.island = island; c.s = s; c.high = high;
  }

  /** Biome for the column at (x, z) whose final surface height is h. */
  biomeAt(x: number, z: number, h: number): string {
    const c = this.column(x, z), { C, E, W, T, H } = c;
    const frozen = T < T_FROZEN, cold = T < T_COLD, hot = T >= T_HOT, warm = !hot && T >= T_WARM;

    if (c.island > 0.5) return h >= SEA - 5 ? 'mushroom_fields' : 'deep_ocean';
    if (h < SEA) {
      // The first two blocks of depth along the coast still belong to the beach (vanilla beaches include the shallows).
      const shallows = h >= SEA - 2 && C > -0.19 && C < -0.13;
      if (C < -0.15 && !shallows) return frozen ? 'frozen_ocean' : h < SEA - 26 ? 'deep_ocean' : 'ocean';
      if (!shallows) {
        if (c.swampy > 0.7 && !frozen) return 'swamp';
        return frozen ? 'frozen_river' : 'river';
      }
    }
    if (c.river > 0.25 && h <= SEA + 1) return frozen ? 'frozen_river' : 'river';
    if (C < -0.13 && h <= SEA + 2) {
      if (frozen) return 'snowy_beach';
      if (E < -0.3) return 'stony_shore';
      return hot && H < 0 ? 'desert' : 'beach';
    }

    // Highlands: slope and peak biomes.
    if (c.high > 0.2) {
      const snowLine = 126 + this.n.n2(x / 37 + 1.7, z / 37 - 6.1) * 5;
      if (h >= snowLine) return T < T_WARM ? 'snowy_slopes' : hot ? 'badlands' : 'windswept_hills';
      if (frozen) return 'snowy_slopes';
      if (hot) return 'badlands';
      if (warm) return H < -0.05 ? 'savanna' : H > 0.3 ? 'jungle' : 'forest';
      if (cold) return H > 0.12 ? 'taiga' : c.s > 0.7 ? 'windswept_hills' : 'meadow';
      return W > 0 && Math.abs(H) < 0.22 ? 'cherry_grove' : H < 0.05 ? 'meadow' : c.s > 0.7 ? 'windswept_hills' : 'forest';
    }
    // Hill tops (vanilla "plateau" biomes): meadows, and cherry groves in mild climates.
    if (c.hills > 0.65 && c.s > 0.55 && C > 0.05 && !frozen && !hot && !warm) {
      if (!cold && W > 0.3 && Math.abs(H) < 0.2) return 'cherry_grove';
      if (H < (cold ? 0 : -0.15)) return 'meadow';
    }

    // Lowlands and hills: the classic temperature × humidity table.
    if (c.swampy > 0.7 && !frozen && h <= SEA + 3) return 'swamp';
    if (frozen) return H > 0.3 ? 'taiga' : 'snowy_plains';
    if (hot) return (c.hills > 0.6 && C > 0.05) || c.mount > 0.25 ? 'badlands' : 'desert';
    if (c.hills > 0.75 && c.s > 0.62 && !warm && H < 0.15 && W < 0 && h >= SEA + 24) return 'windswept_hills';
    if (cold) return H < -0.12 ? 'plains' : H < 0.1 ? 'forest' : 'taiga';
    if (warm) return H < -0.08 ? 'savanna' : H < 0.12 ? (W > 0 ? 'forest' : 'plains') : 'jungle';
    if (H < -0.32) return W < 0 ? 'flower_forest' : 'plains';
    if (H < -0.08) return 'plains';
    if (H < 0.14) return 'forest';
    if (H < 0.34) return 'birch_forest';
    return W < 0 ? 'flower_forest' : 'forest';
  }
}
