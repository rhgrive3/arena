// Terrain diagnostics: writes a biome map + shaded relief map as PNG and prints area / slope statistics.
// Usage: node render-maps.mjs <seed> <centerX> <centerZ> <blocksPerPixel> <outfile> [stats]
import fs from 'node:fs';
import zlib from 'node:zlib';
import '../src/game/content';
import { Terrain, SEA } from '../src/world/terrain';

const [seed = '849281', cxArg = '0', czArg = '0', scaleArg = '10', out = '/tmp/map.png', statsArg = ''] = process.argv.slice(2);
const cx = Number(cxArg), cz = Number(czArg), scale = Number(scaleArg), N = 520;
const t = new Terrain(seed);

const COLORS: Record<string, string> = {
  plains: '#8db360', forest: '#2f7d32', birch_forest: '#6fa05a', flower_forest: '#b06fc0', taiga: '#1f6a5c', snowy_plains: '#f4f8fa', snowy_slopes: '#c4d6e6',
  windswept_hills: '#7a7f78', meadow: '#58d06a', cherry_grove: '#ff9ec8', desert: '#f2c66a', savanna: '#bdb25f', jungle: '#3f8f0f', swamp: '#3c5a4a', badlands: '#d2581e',
  mushroom_fields: '#ff30e0', beach: '#fbe98a', stony_shore: '#a2a284', snowy_beach: '#fff4d0', river: '#4f8fe8', frozen_river: '#a8b8ff', ocean: '#2a4fb0', deep_ocean: '#162a6a', frozen_ocean: '#8088d8',
};
const hex = (h: string) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
function png(w: number, h: number, rgb: Uint8Array) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * 3 + 1)] = 0; Buffer.from(rgb.buffer, y * w * 3, w * 3).copy(raw, y * (w * 3 + 1) + 1); }
  const table = new Int32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; table[n] = c; }
  const crc = (b: Buffer) => { let c = -1; for (const v of b) c = table[(c ^ v) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
  const chunk = (type: string, data: Buffer) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]), c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([len, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

const H = new Int16Array(N * N), img = new Uint8Array(N * 2 * N * 3), area: Record<string, number> = {};
for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) H[j * N + i] = t.height(Math.round(cx + (i - N / 2) * scale), Math.round(cz + (j - N / 2) * scale));
for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
  const x = Math.round(cx + (i - N / 2) * scale), z = Math.round(cz + (j - N / 2) * scale), h = H[j * N + i], b = t.biomeAt(x, z, h);
  area[b] = (area[b] ?? 0) + 1;
  const bc = hex(COLORS[b] ?? '#ff0000');
  // relief colour: bathymetry blues, then green → tan → grey → white with a NW hillshade
  let rc: number[];
  if (h < SEA) { const d = Math.min(1, (SEA - h) / 36); rc = [70 - d * 50, 130 - d * 80, 220 - d * 90]; }
  else { const e = h - SEA; rc = e < 6 ? [150, 190, 110] : e < 20 ? [120, 170, 90] : e < 40 ? [170, 165, 110] : e < 62 ? [140, 130, 115] : e < 85 ? [175, 175, 175] : [245, 245, 250]; }
  const hl = i > 0 && j > 0 ? H[(j - 1) * N + i - 1] : h, shade = h < SEA ? 1 : Math.max(0.55, Math.min(1.35, 1 + ((h - hl) / scale) * 1.6));
  const o1 = (j * N * 2 + i) * 3, o2 = (j * N * 2 + N + i) * 3;
  for (let k = 0; k < 3; k++) { img[o1 + k] = bc[k]; img[o2 + k] = Math.max(0, Math.min(255, rc[k] * shade)); }
}
fs.writeFileSync(out, png(N * 2, N, img));
console.log(`wrote ${out} — seed ${seed}, centre ${cx},${cz}, ${scale} blocks/px (left: biomes, right: relief)`);
console.log('area %: ' + Object.entries(area).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${(v / (N * N) * 100).toFixed(1)}`).join(' · '));

if (statsArg) {
  // 1-block slopes on land, sampled across ±3000 blocks.
  const buckets = [0, 0, 0, 0, 0, 0], names = ['0', '1', '2', '3', '4-5', '6+'];
  let n = 0, maxStep = 0, maxAt = '', hMax = -999, hMin = 999, drop8 = 0, maxDrop8 = 0, dropAt = '';
  for (let z = -3000; z <= 3000; z += 13) for (let x = -3000; x <= 3000; x += 13) {
    const h = t.height(x, z); hMax = Math.max(hMax, h); hMin = Math.min(hMin, h);
    if (h < SEA) continue;
    const step = Math.max(Math.abs(t.height(x + 1, z) - h), Math.abs(t.height(x, z + 1) - h));
    buckets[step >= 6 ? 5 : step >= 4 ? 4 : step]++; n++;
    if (step > maxStep) { maxStep = step; maxAt = `${x},${z} (${t.biome(x, z)})`; }
    const d8 = Math.max(Math.abs(t.height(x + 8, z) - h), Math.abs(t.height(x, z + 8) - h));
    if (d8 >= 16) drop8++;
    if (d8 > maxDrop8) { maxDrop8 = d8; dropAt = `${x},${z} (${t.biome(x, z)})`; }
  }
  console.log(`height range ${hMin}…${hMax} · land columns sampled ${n}`);
  console.log('step to next block: ' + names.map((k, i) => `${k}: ${(buckets[i] / n * 100).toFixed(2)}%`).join(' · ') + ` · max ${maxStep} at ${maxAt}`);
  console.log(`height change over 8 blocks ≥16: ${(drop8 / n * 100).toFixed(3)}% · max ${maxDrop8} at ${dropAt}`);
  const g = t.gen, P: Record<string, number[]> = { C: [], E: [], W: [], T: [], H: [] };
  for (let z = -6000; z <= 6000; z += 97) for (let x = -6000; x <= 6000; x += 97) { const c = g.column(x, z); P.C.push(c.C); P.E.push(c.E); P.W.push(c.W); P.T.push(c.T); P.H.push(c.H); }
  for (const [k, a] of Object.entries(P)) { a.sort((p, q) => p - q); const q = (f: number) => a[Math.floor(f * (a.length - 1))].toFixed(2); console.log(`${k}: p2 ${q(0.02)} p10 ${q(0.1)} p25 ${q(0.25)} p50 ${q(0.5)} p75 ${q(0.75)} p90 ${q(0.9)} p98 ${q(0.98)}`); }
  const t0 = Date.now(); for (let k = 0; k < 16; k++) t.generate(100 + (k & 3), 60 + (k >> 2)); console.log('chunk generation', ((Date.now() - t0) / 16).toFixed(1), 'ms');
}
