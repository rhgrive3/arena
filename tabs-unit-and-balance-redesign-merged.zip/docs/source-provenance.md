# Source Archive

The complete user-supplied archive is preserved, without modification, at:

`reference/recreate-uebs-war-simulator-pro-merged.zip`

- Repository: https://github.com/rhgrive3/arena
- Original file: https://github.com/rhgrive3/arena/blob/main/recreate-uebs-war-simulator-pro-merged.zip
- Download: https://raw.githubusercontent.com/rhgrive3/arena/main/recreate-uebs-war-simulator-pro-merged.zip
- SHA-256: `03d261298a8b6859e4ee8bfd69e3cb6768dfb274c01fa0cb0db264469c329126`
- Integrity: `unzip -t` verified every entry with no errors.

The archived React application, Three.js engine, models, simulation, campaign,
audio, terrain, effects, tests and documentation were restored before changes.
The host project's Vite/Tailwind configuration was retained. Dependencies were
installed with npm; the archive's old compiled bundle was not used as source.

This is an original, procedural battle simulator with TABS-inspired mechanics,
not an official TABS release. No TABS game assets are included.