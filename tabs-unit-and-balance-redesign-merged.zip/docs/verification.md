# Verification

## Commands

```sh
npm install
npx playwright install --with-deps chromium
npx tsc --noEmit
npx tsx --test tests/*.test.ts
npx tsx scripts/balance-report.ts --write
npm run build
TEST_PRODUCTION=1 npx playwright test
```

All 18 browser tests run directly against the compiled production bundle via
`npm run preview`. Chromium uses SwiftShader for reproducible software WebGL.

## Coverage

- `tests/units.test.ts`: complete purchasable roster, six bounded faction tabs,
  computed costs, monotonic pricing, ability premiums, all campaign unlocks,
  eight naive-spam fixtures and 60 successful tactical campaign battles.
- `tests/simulation.test.ts`: all unit types, summon hits and misses, dead
  summoners, separate token limits, expiry and accounting, three-stage ice slow,
  balloon mass, incapacity, popping, fall damage, immunity, death and pause,
  mammoth movement-only trample, ballista piercing, reaper execution, and new
  mechanics remaining identical at 0.5x, 1x, 2x and 4x across frame rates.
- `tests/balance.test.ts`: fifteen equal-budget counters, three seeds, both
  orientations, no spending advantage and no timeout counted as victory.
- `tests/rendering.test.ts`: all 38 models, +Z unlit eyes, cached geometry with
  independent bones, mammoth legs/tusks/trunk, snake segments, ballista wheels,
  reaper tentacles, attached balloons, stacking ice, bounds and effect cleanup.
- `tests/refinements.test.ts`: original shields, flanks, healing, lifesteal,
  charge, aura, terrain, orders, undo, formations, MVP and progression behavior.
- `tests/effects.test.ts`: original hit, explosion, lightning, blood and bounded
  effect pools.
- `tests/browser.spec.ts`: eighteen end-to-end cases, including all six faction
  tabs and number shortcuts, visible icons, clean menu + help dialog, actual
  rendered summon/freeze/balloon events, campaign completion and progress,
  both-team placement and undo, scene switching, results, unobstructed 37-unit
  showcase gallery, mobile HUD, one- and two-finger touch drag/pan/rotate/paint
  controls and an actionable WebGL failure screen.

## Recorded Browser Results

- Production bundle (`TEST_PRODUCTION=1 npx playwright test`): 18/18 passed.
- TypeScript check (`npx tsc --noEmit`) and production build (`npm run build`) passed.
- Node unit/simulation/rendering/balance tests (`npx tsx --test tests/*.test.ts`): 139/139 passed.

See `docs/balance-report.json` for the raw simulation results and
`docs/balance.md` for assumptions and the scope of the balancing claims.

The complete original ZIP is preserved in `reference/`; `unzip -t` confirms every
entry. Checksum and source are documented in `docs/source-provenance.md`.

`npm audit --omit=dev` reports no production dependency vulnerabilities.
Browser verification is Chromium desktop/mobile emulation, not certification
of every browser, physical mobile device or graphics driver.
