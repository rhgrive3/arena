# Ancient Arsenal: Balance Model

## Roster

37 purchasable units, 1 summoned token and 6 factions. Kingdom and Warband have
9 slots, Mystic 7, Undead 5, Machine 3, and Ancient 4. Number keys 1-9 and Q/E
are generated from the same faction definitions as the dock.

New units: Snake Archer, Ice Archer, Balloon Archer, Mammoth, Ballista, Reaper.
Models are original procedural geometry, face +Z, and have unlit eye parts.
Bone geometry is cached and instanced. Persistent ice and balloons use three
shared draw calls rather than allocating a render object per affected unit.

## Price Calculation

`src/game/units.ts::combatValue` is the single source of truth for every price.
There are no hand-written per-unit price overrides. Prices round up to 5 gold,
with a minimum of 25. The snake token is zero-cost but cannot be purchased.

```
cycle = windup + cooldown
armor = min(0.75, baseArmor + 0.6 * frontalShield)
sustain = 12 * regeneration + 6 * lifesteal * damage / cycle
effectiveHP = (hp + sustain) / (1 - armor)

coverage = 1 + 0.75 * AoE + 0.55 * cleave + 0.45 * pierce + 0.28 * chain
reach = ranged ? 1.45 + min(32, range) / 28 : 1 + max(0, range - 2.4) * 0.12
mobility = 1 + max(0, speed - 4) * 0.07
effectiveDPS = (damage / cycle * coverage + 1.4 * trample)
               * reach * mobility * rageFactor * cavalryFactor
combatValue = 1.35 * sqrt(effectiveHP * effectiveDPS) + abilityPremium
```

Rage and cavalry have a 1.25 average-output factor. Cavalry still delivers up
to 1.5x on the actual charge. The premium includes summoning (155), balloon
control (165), stacking freeze (85), slow (42), command aura (450 * buff), healing,
execution, floating, hunting, impact, armor penetration and splash coverage.
Every unit's card cost and showcase tag derive directly from `combatValue`.

These are modeling assumptions (12 seconds of regeneration and 60% frontal
exposure), not a claim that a formula predicts every battle. The empirical
fixtures below validate the intended counters.

## Mechanics And Counterplay

- Snake arrows summon at actual hits or ground impacts. Ability metadata survives
  the shooter's death. Tokens expire after 12 seconds; limits are 3 per archer
  and 24 per team, separate from the 50 deployed units. Expiry does not
  manufacture kills, losses or gold.
- Ice arrows stack to three for movement and action rates of 55%, 40% and 25%.
  A hit refreshes the 4.5-second timer. All stacks clear on thaw.
- Balloon lift uses a damped vertical spring with target height
  `5.8 / sqrt(max(0.6, mass))`. Heavy units have shorter suspension. Hits do not
  refresh it. Popping restores gravity; landing inflicts damage and knockdown,
  then grants 3.5 seconds of balloon immunity.
- Mammoths trample only while actually moving. Pulses are separated by at least
  0.65 seconds, affect light enemies near the feet, and never hurt allies.
  Tusks and trunk deliver a separate wide melee sweep.
- Halberds gain up to 3.4x damage against high mass. Crossbows ignore 65% of
  armor and receive a smaller anti-heavy bonus. Shield reduction remains
  directional. Floating targets outside melee reach cannot be hit from below.
- Ballista bolts pass through up to five different enemies, with 220 base damage,
  36 range and a 6.3-second attack cycle. Tank splash/pierce and lightning chains
  maintain visited-target sets to avoid repeated hits on one victim.
- Reapers hover, cleave with a scythe, and check nearby opponents every 1.1 seconds
  for an execution at 42 HP or lower. Heavy units and allies cannot be executed.

## Reproducible Validation

Run `npx tsx scripts/balance-report.ts --write` to regenerate
`docs/balance-report.json`, including the full price table, actual spend,
formation composition, stage budget and results. Seeds are 1, 7 and 2026.

- 15 counter fixtures, each played with both team orientations and all three
  seeds: 90 completed battles. The counter never spends more than its opponent.
  Unspent gold is less than the cheapest remaining unit in the prescribed army.
- Single-heavy tests use exactly one mammoth (1,000 G), giant (480 G) or tank
  (1,015 G), against halberds, crossbows and a balloon archer. Multi-heavy tests
  use equal allowances around 2,000 G to permit larger formations.
- Snake archer, railgun and mage shooting lines lose to a mixed cavalry,
  assassin and shield assault at matched budgets.
- At 1,000 G, zombie and skeleton formations lose to bombers, giants and mammoths.
- The in-game auto-deploy planner wins all 20 stages on all three seeds, without
  changing HP, gold, damage or unlocks. It avoids duplicate kings because their
  auras do not stack, and responds to heavy and anti-heavy threats.
- Latest-unlocked-unit clump spam loses the eight specified difficult stages.
  This is a regression fixture, not a claim that every monotype must lose every
  stage. Easy tutorial stages intentionally remain forgiving.

Results are deterministic for these formations and seeds. Different terrain,
spacing, mixed armies and future units still require playtesting.