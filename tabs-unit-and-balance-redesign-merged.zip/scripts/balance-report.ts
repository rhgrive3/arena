import { BattleSimulation } from "../src/game/simulation";
import { STAGES } from "../src/game/campaign";
import { DEFS, DEPLOY, combatValue } from "../src/game/units";
import { MATCHUPS, SEEDS, deployPlan, finish } from "../tests/balance-helpers";
import { writeFileSync } from "node:fs";

const report = {
  seeds: SEEDS,
  prices: DEPLOY.map(kind => ({ kind, ...combatValue(DEFS[kind]) })),
  matchups: [] as { name: string; budget: number; spent: number[]; wins: number; total: number }[],
  campaign: [] as { stage: number; budget: number; wins: number; total: number; army: string }[],
};

if (!process.argv.includes("--campaign-only")) {
  console.log("EQUAL BUDGET MATCHUPS (both teams, counter wins / 6)");
  for (const m of MATCHUPS) {
    let spent: number[] = [];
    const wins = ([0, 1] as const).flatMap(team => SEEDS.map(seed => {
      const s = new BattleSimulation(seed); s.reset(false);
      spent = [deployPlan(s, team, m.budget, m.counter), deployPlan(s, team === 0 ? 1 : 0, m.budget, m.opponent)];
      return finish(s) === team;
    })).filter(Boolean).length;
    report.matchups.push({ name: m.name, budget: m.budget, spent, wins, total: SEEDS.length * 2 });
    console.log(m.name, `${wins}/6`, `${spent.join("/")} of ${m.budget} G`);
  }
}
if (!process.argv.includes("--matchups-only")) {
  console.log("CAMPAIGN AUTO DEPLOY (wins / 3)");
  for (let i = 0; i < STAGES.length; i++) {
    let army = "";
    const wins = SEEDS.map(seed => {
      const s = new BattleSimulation(seed); s.setupStage(STAGES[i], i); s.autoDeploy();
      const composition = new Map<string, number>();
      for (const u of s.units.filter(u => u.team === 0)) composition.set(u.kind, (composition.get(u.kind) ?? 0) + 1);
      army = [...composition].map(([k, n]) => `${k}:${n}`).join(" ");
      return finish(s, 300) === 0;
    }).filter(Boolean).length;
    report.campaign.push({ stage: i + 1, budget: STAGES[i].budget, wins, total: SEEDS.length, army });
    console.log(i + 1, wins, STAGES[i].budget, army);
  }
}
console.log("KEY PRICES", Object.fromEntries(["mage", "bomber", "mammoth", "zeus", "tank"].map(k => [k, DEFS[k as keyof typeof DEFS].cost])));
if (process.argv.includes("--write")) writeFileSync("docs/balance-report.json", JSON.stringify(report, null, 2) + "\n");