import * as THREE from "three";

/* ============================================================
   Procedural smooth geometry builders for unit rigs.
   Every geometry is built once per cached unit kind/team during
   rig baking and merged into vertex-coloured bone meshes, so the
   runtime draw-call count stays constant regardless of detail.
   ============================================================ */

const PI = Math.PI;
const TAU = PI * 2;

/**
 * Normalises a geometry for safe vertex-colour merging in `bake()`:
 * drops unused attributes (e.g. `uv`) and guarantees vertex normals exist.
 */
export function prepGeo(g: THREE.BufferGeometry): THREE.BufferGeometry {
  if (g.attributes.uv) g.deleteAttribute("uv");
  if (!g.attributes.normal) g.computeVertexNormals();
  return g;
}

/**
 * Smooth surface of revolution from `[radius, y]` profile points.
 * Uses spline interpolation when `smoothSegs > 0`, and optionally scales X/Z
 * independently for elliptical torsos and helmets.
 */
export function latheGeo(
  pts: [number, number][],
  radialSeg = 22,
  sx = 1,
  sz = 1,
  smoothSegs = 0,
): THREE.BufferGeometry {
  let vecs = pts.map(([r, y]) => new THREE.Vector2(Math.max(0.0001, r), y));
  if (smoothSegs > 0 && vecs.length >= 3) {
    const spline = new THREE.SplineCurve(vecs);
    vecs = spline.getPoints(smoothSegs).map(p => new THREE.Vector2(Math.max(0.0001, p.x), p.y));
  }
  // Cap ends cleanly with r=0 only if the first/last point is intended to close.
  const firstR = pts[0][0], lastR = pts[pts.length - 1][0];
  if (firstR === 0) vecs[0].x = 0;
  if (lastR === 0) vecs[vecs.length - 1].x = 0;
  const g = new THREE.LatheGeometry(vecs, radialSeg);
  if (sx !== 1 || sz !== 1) g.scale(sx, 1, sz);
  g.computeVertexNormals();
  return prepGeo(g);
}

/**
 * Variable-radius lofted tube along a 3D Catmull-Rom curve.
 * Far smoother and more organic than chained spheres or cylinders.
 */
export function loftTube(
  points: THREE.Vector3[],
  radiusFn: (t: number) => number,
  tubularSeg = 18,
  radialSeg = 10,
  capEnds = true,
): THREE.BufferGeometry {
  const curve = new THREE.CatmullRomCurve3(points);
  const frames = curve.computeFrenetFrames(tubularSeg, false);
  const positions: number[] = [];
  const indices: number[] = [];
  const p = new THREE.Vector3();
  const v = new THREE.Vector3();

  for (let i = 0; i <= tubularSeg; i++) {
    const t = i / tubularSeg;
    curve.getPointAt(t, p);
    const r = Math.max(0.0005, radiusFn(t));
    const N = frames.normals[i];
    const B = frames.binormals[i];
    for (let j = 0; j <= radialSeg; j++) {
      const a = (j / radialSeg) * TAU;
      const ca = Math.cos(a), sa = Math.sin(a);
      v.copy(p).addScaledVector(N, ca * r).addScaledVector(B, sa * r);
      positions.push(v.x, v.y, v.z);
    }
  }
  const stride = radialSeg + 1;
  for (let i = 0; i < tubularSeg; i++) {
    for (let j = 0; j < radialSeg; j++) {
      const a = i * stride + j;
      const b = (i + 1) * stride + j;
      const c = (i + 1) * stride + (j + 1);
      const d = i * stride + (j + 1);
      indices.push(a, b, d, b, c, d);
    }
  }
  if (capEnds) {
    const startCenterIdx = positions.length / 3;
    const p0 = curve.getPointAt(0);
    positions.push(p0.x, p0.y, p0.z);
    for (let j = 0; j < radialSeg; j++) indices.push(startCenterIdx, j + 1, j);

    const endCenterIdx = positions.length / 3;
    const p1 = curve.getPointAt(1);
    positions.push(p1.x, p1.y, p1.z);
    const base = tubularSeg * stride;
    for (let j = 0; j < radialSeg; j++) indices.push(endCenterIdx, base + j, base + j + 1);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  g.setIndex(indices);
  g.computeVertexNormals();
  return g;
}

/** Smoothly rounded extruded shape with bevels, centred on Z = 0. */
export function extrudeShape(
  shape: THREE.Shape,
  depth: number,
  bevel = 0.015,
  curveSeg = 18,
): THREE.BufferGeometry {
  const g = new THREE.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: bevel > 0,
    bevelThickness: bevel,
    bevelSize: bevel,
    bevelSegments: 3,
    curveSegments: curveSeg,
  });
  g.translate(0, 0, -depth / 2);
  g.computeVertexNormals();
  return prepGeo(g);
}

/* ============ organic face helpers ============ */

/** Surface Z of the standard ellipsoid head `(0.26, 0.28, 0.26)` at `(x, y)`. */
export function headSurfaceZ(x: number, y: number, rx = 0.26, ry = 0.28, rz = 0.26): number {
  const k = 1 - (x / rx) ** 2 - (y / ry) ** 2;
  return rz * Math.sqrt(Math.max(0.02, k));
}

/** Smooth mouth curve conformed directly onto the head ellipsoid. */
export function mouthCurveGeo(
  width: number,
  yCenter: number,
  smileLift: number,
  thick = 0.01,
  zBias = 0.008,
): THREE.BufferGeometry {
  const pts: THREE.Vector3[] = [];
  const steps = 8;
  for (let i = 0; i <= steps; i++) {
    const t = (i / steps) * 2 - 1;
    const x = t * width;
    const y = yCenter + (t * t - 0.5) * smileLift;
    const z = headSurfaceZ(x, y) + zBias;
    pts.push(new THREE.Vector3(x, y, z));
  }
  // Taper slightly at the corners for a natural hand-drawn stroke look.
  return loftTube(pts, t => thick * (0.45 + 0.55 * Math.sin(t * PI)), 18, 8, true);
}

/** Smooth curved eyebrow conformed onto the head ellipsoid. */
export function browCurveGeo(
  side: number,
  sep: number,
  yCenter: number,
  tilt: number,
  len = 0.075,
  thick = 0.012,
): THREE.BufferGeometry {
  const pts: THREE.Vector3[] = [];
  for (let i = 0; i <= 4; i++) {
    const u = i / 4 - 0.5;
    const x = side * (sep + u * len * 1.4);
    const y = yCenter + (1 - (u * 2) ** 2) * 0.012 + u * side * tilt * 0.06;
    const z = headSurfaceZ(x, y) + 0.011;
    pts.push(new THREE.Vector3(x, y, z));
  }
  return loftTube(pts, t => thick * (0.55 + 0.45 * Math.sin(t * PI)), 10, 8, true);
}

/**
 * Conformed curved open/grin mouth cavity + clean upper teeth strip (no beaded teeth!).
 */
export function openMouthCavityGeo(width: number, height: number, yCenter: number, zBias = 0.004): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-width, 0.005);
  shape.quadraticCurveTo(0, 0.015, width, 0.005);
  shape.quadraticCurveTo(0, -height, -width, 0.005);
  const g = new THREE.ExtrudeGeometry(shape, { depth: 0.018, bevelEnabled: true, bevelThickness: 0.004, bevelSize: 0.004, bevelSegments: 2, curveSegments: 14 });
  g.translate(0, yCenter, 0);
  // Bend vertices onto the curved head surface.
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), zLocal = pos.getZ(i);
    pos.setZ(i, headSurfaceZ(x, y) + zBias + zLocal);
  }
  g.computeVertexNormals();
  return prepGeo(g);
}

export function upperTeethGeo(width: number, height: number, yCenter: number): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-width * 0.85, 0);
  shape.quadraticCurveTo(0, 0.006, width * 0.85, 0);
  shape.lineTo(width * 0.72, -height);
  shape.quadraticCurveTo(0, -height - 0.004, -width * 0.72, -height);
  shape.closePath();
  const g = new THREE.ExtrudeGeometry(shape, { depth: 0.01, bevelEnabled: false, curveSegments: 12 });
  g.translate(0, yCenter, 0);
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), zLocal = pos.getZ(i);
    pos.setZ(i, headSurfaceZ(x, y) + 0.014 + zLocal);
  }
  g.computeVertexNormals();
  return prepGeo(g);
}

/** Curved lower lip or warpaint/scar strip conformed onto the face surface. */
export function faceStripGeo(
  pts2D: [number, number][],
  thick: number,
  zBias = 0.007,
): THREE.BufferGeometry {
  const pts = pts2D.map(([x, y]) => new THREE.Vector3(x, y, headSurfaceZ(x, y) + zBias));
  return loftTube(pts, t => thick * (0.6 + 0.4 * Math.sin(t * PI)), 14, 8, true);
}

/* ============ torso, clothing & strap builders ============ */

/**
 * Tailored tunic / coat torso: smoothly rounds from neck collar through
 * natural shoulders, chest, cinched waist, and flared skirt hem below the hip.
 * Eliminates blocky boxes and snowman sphere stacks.
 */
export function tunicTorsoGeo(
  cw: number,
  opts: { flare?: number; hemY?: number; waistR?: number; chestPush?: number } = {},
): THREE.BufferGeometry {
  const sx = cw * 0.54;
  const sz = cw * 0.36;
  const hemY = opts.hemY ?? -0.2;
  const flare = opts.flare ?? 1.08;
  const waistR = opts.waistR ?? 0.85;
  const profile: [number, number][] = [
    [0.0, hemY],
    [flare, hemY],
    [flare * 0.96, hemY + 0.14],
    [waistR, 0.1],
    [0.95, 0.35],
    [1.04, 0.62],
    [0.96, 0.78],
    [0.54, 0.88],
    [0.26, 0.93],
    [0.0, 0.92],
  ];
  const g = latheGeo(profile, 24, sx, sz, 28);
  const pos = g.attributes.position;
  const push = opts.chestPush ?? 0.03;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    // Subtle chest fullness in front (+Z), slight hollow at lower back, gentle cloth folds near hem.
    if (y > 0.25 && y < 0.78 && z > 0) {
      const k = Math.sin(((y - 0.25) / 0.53) * PI);
      pos.setZ(i, z + push * k * (z / Math.max(0.05, sz)));
    }
    if (y < 0.05) {
      const fold = 1 + 0.035 * Math.cos(Math.atan2(x, z) * 6) * Math.min(1, (0.05 - y) / 0.25);
      pos.setX(i, x * fold);
      pos.setZ(i, z * fold);
    }
  }
  g.computeVertexNormals();
  return g;
}

/**
 * Full-length flowing mage/cleric/monk/shaman robe: continuous curve from collar to ankle hem
 * with subtle vertical cloth pleats.
 */
export function robeTorsoGeo(cw: number, hemRadius = 0.62): THREE.BufferGeometry {
  const sx = cw * 0.54;
  const sz = cw * 0.37;
  const baseR = hemRadius / sx;
  const profile: [number, number][] = [
    [0.0, -1.04],
    [baseR, -1.04],
    [baseR * 0.92, -0.78],
    [baseR * 0.78, -0.45],
    [1.06, -0.12],
    [0.86, 0.1],
    [0.96, 0.38],
    [1.03, 0.65],
    [0.92, 0.79],
    [0.52, 0.89],
    [0.27, 0.93],
    [0.0, 0.92],
  ];
  const g = latheGeo(profile, 26, sx, sz, 34);
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    if (y < 0.08) {
      const t = Math.min(1, (0.08 - y) / 1.12);
      const pleat = 1 + 0.04 * Math.cos(Math.atan2(x, z) * 7) * t;
      pos.setX(i, x * pleat);
      pos.setZ(i, z * pleat);
    }
  }
  g.computeVertexNormals();
  return g;
}

/**
 * Sculpted steel cuirass / breastplate with flared fauld/tasset skirt and front ridge.
 */
export function cuirassGeo(cw: number, skirtY = -0.16): THREE.BufferGeometry {
  const sx = cw * 0.58;
  const sz = cw * 0.4;
  const profile: [number, number][] = [
    [0.0, skirtY],
    [1.12, skirtY],
    [1.02, -0.02],
    [0.86, 0.12],
    [0.98, 0.38],
    [1.06, 0.64],
    [0.95, 0.78],
    [0.56, 0.87],
    [0.32, 0.92],
    [0.0, 0.9],
  ];
  const g = latheGeo(profile, 24, sx, sz, 28);
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    // Classic breastplate keel down the front (+Z) chest.
    if (y > 0.14 && y < 0.8 && z > 0) {
      const k = Math.sin(((y - 0.14) / 0.66) * PI);
      const ridge = Math.max(0, 1 - Math.abs(x) / (sx * 0.7));
      pos.setZ(i, z + (0.045 * ridge + 0.025) * k);
    }
  }
  g.computeVertexNormals();
  return g;
}

/**
 * Anatomical muscular bare torso (for giant, troll, orc, berserker, zeus):
 * broad lats & pecs, defined waist, optional gut swell.
 */
export function muscularTorsoGeo(cw: number, gut = 0): THREE.BufferGeometry {
  const sx = cw * 0.56;
  const sz = cw * 0.38;
  const profile: [number, number][] = [
    [0.0, -0.02],
    [0.92, -0.02],
    [0.86, 0.12],
    [0.98, 0.38],
    [1.09, 0.64],
    [0.98, 0.78],
    [0.58, 0.87],
    [0.3, 0.92],
    [0.0, 0.9],
  ];
  const g = latheGeo(profile, 24, sx, sz, 26);
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    // Pectoral curve at upper front.
    if (y > 0.44 && y < 0.78 && z > 0) {
      const ky = Math.sin(((y - 0.44) / 0.34) * PI);
      const kx = Math.sin(Math.min(1, Math.abs(x) / (sx * 0.85)) * PI);
      pos.setZ(i, z + 0.045 * ky * kx);
    }
    // Optional belly bulge at lower front.
    if (gut > 0 && y > -0.02 && y < 0.48 && z > -sz * 0.2) {
      const ky = Math.sin(((y + 0.02) / 0.5) * PI);
      const bulge = 1 + gut * 0.34 * ky * Math.max(0.2, (z / sz + 0.4));
      pos.setZ(i, z + gut * 0.14 * ky * Math.max(0, z / sz));
      pos.setX(i, x * (1 + gut * 0.12 * ky));
      void bulge;
    }
  }
  g.computeVertexNormals();
  return g;
}

/**
 * Conformed strap / belt / baldric that hugs an elliptical torso surface tightly
 * so rectangular box corners NEVER poke out of the chest or back.
 */
export function ringBandGeo(rx: number, rz: number, y: number, thick = 0.015, width = 0.04): THREE.BufferGeometry {
  return torsoStrapGeo(rx, rz, y, y, thick, width, 0, false);
}

export function torsoStrapGeo(
  rx: number,
  rz: number,
  yLeft: number,
  yRight: number,
  thick = 0.028,
  width = 0.065,
  yBias = 0,
  followTorso = true,
): THREE.BufferGeometry {
  const segs = 28;
  const positions: number[] = [];
  const indices: number[] = [];
  const p = new THREE.Vector3();
  const n = new THREE.Vector3();
  const tangent = new THREE.Vector3();
  const binormal = new THREE.Vector3();

  for (let i = 0; i <= segs; i++) {
    const a = (i / segs) * TAU;
    const ca = Math.cos(a), sa = Math.sin(a);
    const y = ((ca + 1) * 0.5) * (yRight - yLeft) + yLeft + yBias;
    // Follow the torso profile (wider at chest y~0.6, slight waist cinch y~0.1, chest swell in front).
    const rScale = !followTorso ? 1.0
      : y < 0.12 ? 0.87 + Math.abs(y - 0.12) * 0.45
      : y < 0.65 ? 0.87 + ((y - 0.12) / 0.53) * 0.18
      : 1.05 - ((y - 0.65) / 0.25) * 0.15;
    const chestSwell = followTorso && sa > 0 && y > 0.2 && y < 0.8 ? 0.036 * Math.sin(((y - 0.2) / 0.6) * PI) * sa : 0;
    p.set(rx * rScale * ca, y, rz * rScale * sa + chestSwell);
    n.set(ca / Math.max(0.05, rx), 0, sa / Math.max(0.05, rz)).normalize();
    tangent.set(-rx * sa, -0.5 * sa * (yRight - yLeft), rz * ca).normalize();
    binormal.crossVectors(tangent, n).normalize();
    if (binormal.y < 0) binormal.negate();

    const hw = width * 0.5;
    const corners = [
      p.clone().addScaledVector(n, thick).addScaledVector(binormal, hw),
      p.clone().addScaledVector(n, thick).addScaledVector(binormal, -hw),
      p.clone().addScaledVector(n, -0.012).addScaledVector(binormal, -hw),
      p.clone().addScaledVector(n, -0.012).addScaledVector(binormal, hw),
    ];
    for (const c of corners) positions.push(c.x, c.y, c.z);
  }
  for (let i = 0; i < segs; i++) {
    const b0 = i * 4, b1 = (i + 1) * 4;
    for (let s = 0; s < 4; s++) {
      const ns = (s + 1) % 4;
      indices.push(b0 + s, b1 + s, b1 + ns, b0 + s, b1 + ns, b0 + ns);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  g.setIndex(indices);
  g.computeVertexNormals();
  return g;
}

/**
 * Smoothly draped cloak with flared hem, back curve and vertical cloth folds.
 */
export function cloakGeo(wTop: number, wBot: number, len: number, folds = 3): THREE.BufferGeometry {
  const cols = 14, rows = 12;
  const thick = 0.028;
  const positions: number[] = [];
  const indices: number[] = [];

  for (let layer = 0; layer < 2; layer++) {
    const zOff = layer === 0 ? 0 : -thick;
    for (let r = 0; r <= rows; r++) {
      const v = r / rows;
      const w = wTop + (wBot - wTop) * Math.pow(v, 0.85);
      const y = -v * len;
      const arch = -0.06 - 0.14 * Math.pow(v, 1.35);
      for (let c = 0; c <= cols; c++) {
        const u = (c / cols) * 2 - 1;
        // Wrap gently around the shoulders near the top, ripple into drapes toward the hem.
        const shoulderWrap = (1 - v) * 0.06 * (1 - u * u);
        const ripple = Math.sin(u * PI * folds) * 0.032 * v;
        const x = u * w * 0.5;
        const z = arch + shoulderWrap + ripple + zOff - u * u * 0.04 * (1 - 0.4 * v);
        positions.push(x, y, z);
      }
    }
  }
  const stride = cols + 1;
  const layerVerts = (rows + 1) * stride;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const a = r * stride + c, b = a + 1, d = a + stride, e = d + 1;
      indices.push(a, d, b, b, d, e);
      const fa = layerVerts + a, fb = layerVerts + b, fd = layerVerts + d, fe = layerVerts + e;
      indices.push(fa, fb, fd, fb, fe, fd);
    }
  }
  // Stitch perimeter edges so the cloak is watertight.
  for (let c = 0; c < cols; c++) {
    indices.push(c, c + 1, layerVerts + c, c + 1, layerVerts + c + 1, layerVerts + c);
    const bot = rows * stride + c;
    indices.push(bot, layerVerts + bot, bot + 1, bot + 1, layerVerts + bot, layerVerts + bot + 1);
  }
  for (let r = 0; r < rows; r++) {
    const l = r * stride, nl = (r + 1) * stride;
    indices.push(l, layerVerts + l, nl, nl, layerVerts + l, layerVerts + nl);
    const ri = r * stride + cols, nri = (r + 1) * stride + cols;
    indices.push(ri, nri, layerVerts + ri, nri, layerVerts + nri, layerVerts + ri);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  g.setIndex(indices);
  g.computeVertexNormals();
  return g;
}

/** Tapered rounded boot with calf cuff, instep and rounded toe (replaces boxy boot soles). */
export function bootGeo(rLeg: number, len = 0.24): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-rLeg * 0.55, 0);
  shape.quadraticCurveTo(0, -rLeg * 0.3, rLeg * 0.55, 0);
  shape.lineTo(rLeg * 0.52, len * 0.65);
  shape.quadraticCurveTo(rLeg * 0.45, len * 1.05, 0, len * 1.08);
  shape.quadraticCurveTo(-rLeg * 0.45, len * 1.05, -rLeg * 0.52, len * 0.65);
  shape.closePath();
  const g = new THREE.ExtrudeGeometry(shape, {
    depth: rLeg * 0.62,
    bevelEnabled: true,
    bevelThickness: rLeg * 0.22,
    bevelSize: rLeg * 0.12,
    bevelSegments: 3,
    curveSegments: 14,
  });
  g.rotateX(PI / 2);
  g.translate(0, rLeg * 0.42, -rLeg * 0.15);
  g.computeVertexNormals();
  return prepGeo(g);
}

/* ============ headgear builders (smooth, fitted, zero floating rings) ============ */

/**
 * One-piece kettle helmet: rounded crown smoothly flaring into a wide protective brim.
 */
export function kettleHelmGeo(r = 0.295, brimR = 0.43): THREE.BufferGeometry {
  // Closed profile: inner cavity top->bottom, then outer surface bottom->top
  // so LatheGeometry produces outward normals on BOTH outer dome and brim!
  const profile: [number, number][] = [
    [0, 0.04],
    [r * 0.9, 0.03],
    [brimR * 0.96, -0.06],
    [brimR, -0.04],
    [brimR * 0.9, 0.0],
    [r, 0.05],
    [r * 0.95, 0.15],
    [r * 0.78, 0.26],
    [r * 0.42, 0.33],
    [0, 0.35],
  ];
  return latheGeo(profile, 28, 1, 1.04, 28);
}

/**
 * Rounded knight/soldier helmet (sallet / barbute / norman dome) with integrated swept neck tail.
 */
export function warHelmGeo(r = 0.295, neckTail = 0.12): THREE.BufferGeometry {
  const profile: [number, number][] = [
    [0, 0.0],
    [r * 0.88, -0.09],
    [r * 1.02, -0.1],
    [r * 1.04, -0.06],
    [r, 0.04],
    [r * 0.96, 0.15],
    [r * 0.8, 0.26],
    [r * 0.44, 0.34],
    [0, 0.36],
  ];
  const g = latheGeo(profile, 28, 0.98, 1.04, 26);
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    // Clean brow arch in front (+Z) so eyes & brow show clearly, while cheek flaps stay low.
    if (z > 0.02 && y < 0.12) {
      const front = Math.min(1, (z - 0.02) / (r * 0.85));
      const center = Math.max(0, 1 - (Math.abs(x) / (r * 0.85)) ** 2);
      pos.setY(i, y + 0.14 * front * center);
    }
    if (z < -0.04 && y < 0.04) {
      const back = Math.min(1, (-z - 0.04) / (r * 0.9));
      const low = Math.max(0, (0.04 - y) / 0.14);
      pos.setZ(i, z - neckTail * back * low);
      pos.setY(i, y - 0.05 * back * low);
    }
  }
  g.computeVertexNormals();
  return g;
}

/**
 * Full enclosed knight great-helm / bascinet visor shell with a clean eye-slit gap.
 */
export function visorFaceGeo(r = 0.295): THREE.BufferGeometry {
  const pts: [number, number][] = [
    [0, -0.18],
    [r * 0.78, -0.18],
    [r * 0.95, -0.06],
    [r * 0.94, 0.015],
    [0, 0.02],
  ];
  const g = latheGeo(pts, 24, 0.96, 1.06, 16);
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const z = pos.getZ(i);
    if (z < 0) pos.setZ(i, z * 0.35);
    else pos.setZ(i, z + 0.055 * Math.max(0, 1 - Math.abs(pos.getX(i)) / r));
  }
  g.computeVertexNormals();
  return g;
}

/**
 * Smooth continuous horsehair crest fin (replaces segmented spheres on helmets).
 */
export function crestFinGeo(len = 0.44, height = 0.16, thick = 0.055): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-0.14, 0);
  shape.quadraticCurveTo(-0.26, height * 0.8, -0.08, height);
  shape.quadraticCurveTo(0.14, height * 1.05, len * 0.56, height * 0.45);
  shape.quadraticCurveTo(len * 0.54, 0.04, 0.18, 0);
  shape.closePath();
  const g = extrudeShape(shape, thick, 0.014, 18);
  g.rotateY(-PI / 2); // align curve along Z (front-to-back)
  return g;
}

/** Wing plume shape for Paladin helmet. */
export function wingPlumeGeo(): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(0, 0);
  shape.quadraticCurveTo(0.06, 0.16, 0.02, 0.34);
  shape.quadraticCurveTo(-0.06, 0.28, -0.05, 0.22);
  shape.quadraticCurveTo(-0.11, 0.2, -0.07, 0.13);
  shape.quadraticCurveTo(-0.12, 0.1, -0.05, 0.02);
  shape.closePath();
  return extrudeShape(shape, 0.02, 0.008, 16);
}

/**
 * Genuine cloth hood: wraps the back/top/sides of the head smoothly, with an
 * open front arch framing the face and a gently pointed peak trailing behind.
 */
export function clothHoodGeo(r = 0.282): THREE.BufferGeometry {
  // Trim, fitted cloth hood hugging the skull without ballooning into a space helmet.
  const uSeg = 24, vSeg = 18;
  const positions: number[] = [];
  const indices: number[] = [];
  const thick = 0.015;

  for (let layer = 0; layer < 2; layer++) {
    const dr = layer === 0 ? thick : 0;
    for (let iv = 0; iv <= vSeg; iv++) {
      const v = iv / vSeg;
      const z = 0.09 - v * 0.42;
      const arch = Math.sin(Math.min(1, v * 1.15) * PI * 0.52);
      const backDrop = v > 0.66 ? ((v - 0.66) / 0.34) ** 1.35 : 0;
      const curR = Math.max(0.004, (0.242 + (r - 0.242) * arch) * (1 - backDrop * 0.94) + dr);
      const yMid = 0.035 + Math.sin(v * PI * 0.85) * 0.055 - backDrop * 0.14;
      for (let iu = 0; iu <= uSeg; iu++) {
        const a = -PI * 0.68 + (iu / uSeg) * (PI * 1.36);
        const x = Math.sin(a) * curR * 0.96;
        const y = yMid + Math.cos(a) * curR * 1.04;
        const browPeak = Math.max(0, 1 - v * 4) * Math.max(0, Math.cos(a)) * 0.075;
        positions.push(x, y, z + browPeak);
      }
    }
  }
  const stride = uSeg + 1;
  const layerVerts = (vSeg + 1) * stride;
  for (let iv = 0; iv < vSeg; iv++) {
    for (let iu = 0; iu < uSeg; iu++) {
      const a = iv * stride + iu, b = a + 1, d = a + stride, e = d + 1;
      indices.push(a, b, d, b, e, d);
      const fa = layerVerts + a, fb = layerVerts + b, fd = layerVerts + d, fe = layerVerts + e;
      indices.push(fa, fd, fb, fb, fd, fe);
    }
  }
  for (let iu = 0; iu < uSeg; iu++) {
    indices.push(iu, layerVerts + iu, iu + 1, iu + 1, layerVerts + iu, layerVerts + iu + 1);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  g.setIndex(indices);
  g.computeVertexNormals();
  return g;
}

/**
 * Genuine wizard hat: wavy brim + bent conical crown along a graceful curve.
 */
export function wizardBrimGeo(innerR = 0.25, outerR = 0.52): THREE.BufferGeometry {
  const segR = 8, segA = 32;
  const positions: number[] = [];
  const indices: number[] = [];
  const thick = 0.022;
  for (let layer = 0; layer < 2; layer++) {
    const yOff = layer === 0 ? thick : 0;
    for (let ir = 0; ir <= segR; ir++) {
      const t = ir / segR;
      const r = innerR + (outerR - innerR) * t;
      for (let ia = 0; ia <= segA; ia++) {
        const a = (ia / segA) * TAU;
        const wave = Math.sin(a * 2 + 0.5) * 0.04 * t * t - 0.03 * t * t;
        positions.push(Math.sin(a) * r, wave + yOff, Math.cos(a) * r);
      }
    }
  }
  const stride = segA + 1;
  const lv = (segR + 1) * stride;
  for (let ir = 0; ir < segR; ir++) {
    for (let ia = 0; ia < segA; ia++) {
      const a = ir * stride + ia, b = a + 1, d = a + stride, e = d + 1;
      indices.push(a, d, b, b, d, e);
      indices.push(lv + a, lv + b, lv + d, lv + b, lv + e, lv + d);
    }
  }
  for (let ia = 0; ia < segA; ia++) {
    const out = segR * stride + ia;
    indices.push(out, out + 1, lv + out, out + 1, lv + out + 1, lv + out);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  g.setIndex(indices);
  g.computeVertexNormals();
  return g;
}

export function wizardCrownGeo(): THREE.BufferGeometry {
  const pts = [
    new THREE.Vector3(0, -0.02, 0),
    new THREE.Vector3(0.01, 0.22, -0.02),
    new THREE.Vector3(0.05, 0.45, -0.08),
    new THREE.Vector3(0.14, 0.62, -0.22),
    new THREE.Vector3(0.24, 0.6, -0.36),
  ];
  return loftTube(pts, t => 0.3 * Math.pow(1 - t * 0.94, 1.05), 20, 18, true);
}

/**
 * Genuine pirate tricorn hat: soft crown + three upturned triangular brim wings.
 */
export function tricornBrimGeo(): THREE.BufferGeometry {
  const segR = 8, segA = 36;
  const positions: number[] = [];
  const indices: number[] = [];
  const thick = 0.022;
  for (let layer = 0; layer < 2; layer++) {
    const yOff = layer === 0 ? thick : 0;
    for (let ir = 0; ir <= segR; ir++) {
      const t = ir / segR;
      for (let ia = 0; ia <= segA; ia++) {
        const a = (ia / segA) * TAU; // 0 = +Z front corner
        // Three corners (front 0, back-left +2.15, back-right -2.15), folded sides in between.
        const tri = Math.cos(a * 3); // +1 at corners, -1 at mid-sides
        const outer = 0.43 + 0.08 * tri;
        const r = 0.24 + (outer - 0.24) * t;
        const turnUp = (1 - tri) * 0.5 * 0.18 * Math.pow(t, 1.3);
        positions.push(Math.sin(a) * r, turnUp + yOff, Math.cos(a) * r);
      }
    }
  }
  const stride = segA + 1;
  const lv = (segR + 1) * stride;
  for (let ir = 0; ir < segR; ir++) {
    for (let ia = 0; ia < segA; ia++) {
      const a = ir * stride + ia, b = a + 1, d = a + stride, e = d + 1;
      indices.push(a, d, b, b, d, e);
      indices.push(lv + a, lv + b, lv + d, lv + b, lv + e, lv + d);
    }
  }
  for (let ia = 0; ia < segA; ia++) {
    const out = segR * stride + ia;
    indices.push(out, out + 1, lv + out, out + 1, lv + out + 1, lv + out);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  g.setIndex(indices);
  g.computeVertexNormals();
  return g;
}

/** Tapered curved horn or fang along a 3D curve. */
export function curvedHornGeo(
  len = 0.3,
  baseR = 0.045,
  sweepX = 0.14,
  sweepY = 0.26,
  sweepZ = -0.06,
): THREE.BufferGeometry {
  const pts = [
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(sweepX * 0.4, sweepY * 0.45, sweepZ * 0.3),
    new THREE.Vector3(sweepX * 0.85, sweepY * 0.85, sweepZ * 0.7),
    new THREE.Vector3(sweepX, sweepY, sweepZ),
  ];
  void len;
  return loftTube(pts, t => baseR * (1 - t * 0.92), 14, 10, true);
}

/** Curved fleur-de-lis crown point. */
export function crownSpikeGeo(): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-0.045, 0);
  shape.lineTo(-0.032, 0.09);
  shape.quadraticCurveTo(-0.07, 0.14, -0.055, 0.18);
  shape.quadraticCurveTo(-0.025, 0.15, -0.018, 0.12);
  shape.quadraticCurveTo(-0.022, 0.2, 0, 0.24);
  shape.quadraticCurveTo(0.022, 0.2, 0.018, 0.12);
  shape.quadraticCurveTo(0.025, 0.15, 0.055, 0.18);
  shape.quadraticCurveTo(0.07, 0.14, 0.032, 0.09);
  shape.lineTo(0.045, 0);
  shape.closePath();
  return extrudeShape(shape, 0.018, 0.004, 12);
}

/** Heater shield with curved cross-section and rounded rim. */
export function heaterShieldGeo(w = 0.56, h = 0.84): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(-w * 0.5, h * 0.46);
  shape.quadraticCurveTo(0, h * 0.54, w * 0.5, h * 0.46);
  shape.lineTo(w * 0.5, h * 0.02);
  shape.quadraticCurveTo(w * 0.42, -h * 0.34, 0, -h * 0.52);
  shape.quadraticCurveTo(-w * 0.42, -h * 0.34, -w * 0.5, h * 0.02);
  shape.closePath();
  const g = extrudeShape(shape, 0.04, 0.012, 16);
  // Subtle barrel curve across width so the shield wraps the forearm.
  const pos = g.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    pos.setZ(i, z - (x / (w * 0.5)) ** 2 * 0.08);
  }
  g.computeVertexNormals();
  return g;
}

/** Smooth curved rib arch for skeletons (replaces boxy straight rib bars). */
export function ribArchGeo(side: number, width: number, depth: number): THREE.BufferGeometry {
  const pts = [
    new THREE.Vector3(0, 0, -depth * 0.45),
    new THREE.Vector3(side * width * 0.72, -0.01, -depth * 0.25),
    new THREE.Vector3(side * width * 0.96, -0.03, 0.04),
    new THREE.Vector3(side * width * 0.45, -0.05, depth * 0.46),
  ];
  return loftTube(pts, () => 0.022, 12, 8, true);
}
