import * as THREE from "three";
import type { CombatUnit } from "./simulation";
import { DEFS, MAX_TOTAL, MAX_SUMMONS_PER_TEAM } from "./units";

/** Three draw calls for all persistent status effects, including summoned units. */
function makeBalloonGeometry() {
  const pts: THREE.Vector2[] = [];
  for (let i = 0; i <= 14; i++) {
    const t = i / 14;
    const y = -1 + t * 2;
    const rx = t < 0.14 ? 0.12 + (0.14 - t) * 1.15 : Math.sin(((t - 0.12) / 0.88) * Math.PI) * (0.64 + t * 0.34);
    pts.push(new THREE.Vector2(Math.max(0.001, rx), y));
  }
  return new THREE.LatheGeometry(pts, 14);
}

export class StatusRenderer {
  private balloons: THREE.InstancedMesh;
  private strings: THREE.InstancedMesh;
  private ice: THREE.InstancedMesh;
  private transform = new THREE.Object3D();
  private up = new THREE.Vector3(0, 1, 0);
  private direction = new THREE.Vector3();
  private anchor = new THREE.Vector3();
  private unitDir = new THREE.Vector3();
  private color = new THREE.Color();

  constructor(private scene: THREE.Scene) {
    const capacity = MAX_TOTAL + MAX_SUMMONS_PER_TEAM * 2;
    this.balloons = new THREE.InstancedMesh(makeBalloonGeometry(), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.24, metalness: 0.08 }), capacity * 3);
    this.strings = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.013, 0.013, 1, 4), new THREE.MeshBasicMaterial({ color: 0xeee3d2 }), capacity * 3);
    this.ice = new THREE.InstancedMesh(new THREE.ConeGeometry(1, 1, 6), new THREE.MeshStandardMaterial({ color: 0xb0f0ff, emissive: 0x2b6d90, emissiveIntensity: 0.55, roughness: 0.22, transparent: true, opacity: 0.78 }), capacity * 6);
    for (const mesh of [this.balloons, this.strings, this.ice]) {
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.frustumCulled = false;
      mesh.count = 0;
      scene.add(mesh);
    }
  }

  sync(units: CombatUnit[], time: number, alpha = 1) {
    let bi = 0, ci = 0;
    const t = this.transform;
    for (const u of units) {
      if (u.dead) continue;
      const d = DEFS[u.kind];
      const ux = u.prevPosition.x + (u.position.x - u.prevPosition.x) * alpha;
      const uy = u.prevPosition.y + (u.position.y - u.prevPosition.y) * alpha;
      const uz = u.prevPosition.z + (u.position.z - u.prevPosition.z) * alpha;
      if (u.balloonT > 0) {
        for (let i = 0; i < 3; i++) {
          if (bi >= this.balloons.instanceMatrix.count) break;
          const sway = Math.sin(time * 2.3 + u.id + i * 1.4) * 0.16;
          const dx = (i - 1) * 0.62 + sway, dy = d.height + 2.35 + (i % 2) * 0.45;
          t.position.set(ux + dx, uy + dy, uz + Math.cos(i * 2.1) * 0.3);
          t.rotation.set(sway * 0.3, 0, -sway * 0.8);
          t.scale.set(0.46, 0.54, 0.46); t.updateMatrix();
          this.balloons.setMatrixAt(bi, t.matrix);
          this.balloons.setColorAt(bi, this.color.setHex([0xefb84d, 0xe474a6, 0x6ec3d8][i]));
          this.anchor.set(ux, uy + d.height * 0.65, uz);
          this.direction.copy(t.position).sub(this.anchor);
          const len = this.direction.length() || 1;
          t.position.copy(this.anchor).addScaledVector(this.direction, 0.5);
          this.unitDir.copy(this.direction).divideScalar(len);
          t.quaternion.setFromUnitVectors(this.up, this.unitDir);
          t.scale.set(1, len, 1); t.updateMatrix();
          this.strings.setMatrixAt(bi++, t.matrix);
        }
      }
      if (u.slowT > 0) {
        const count = u.freezeStacks ? u.freezeStacks * 2 : 3;
        for (let i = 0; i < count; i++) {
          if (ci >= this.ice.instanceMatrix.count) break;
          const angle = i * Math.PI * 2 / count;
          t.position.set(ux + Math.cos(angle) * d.radius * 0.88, uy + 0.34, uz + Math.sin(angle) * d.radius * 0.88);
          t.rotation.set(Math.sin(angle) * 0.38, angle, Math.cos(angle) * 0.38);
          t.scale.set(0.18 + d.radius * 0.11, 0.8 + u.freezeStacks * 0.16, 0.18); t.updateMatrix();
          this.ice.setMatrixAt(ci++, t.matrix);
        }
      }
    }
    this.balloons.count = this.strings.count = bi;
    this.ice.count = ci;
    for (const mesh of [this.balloons, this.strings, this.ice]) mesh.instanceMatrix.needsUpdate = true;
    if (this.balloons.instanceColor) this.balloons.instanceColor.needsUpdate = true;
  }

  dispose() {
    for (const mesh of [this.balloons, this.strings, this.ice]) {
      this.scene.remove(mesh);
      mesh.geometry.dispose();
      (mesh.material as THREE.Material).dispose();
      mesh.dispose();
    }
  }
}