import { DEFS, type UnitKind } from "./units";

export type Pattern = "line" | "block" | "wedge" | "flank" | "arc";

export interface EnemyGroup { kind: UnitKind; count: number; x: number; z: number; pattern: Pattern }
export interface Stage {
  id: number;
  scene: number;
  name: string;
  hint: string;
  budget: number;
  unlock: UnitKind[];
  enemies: EnemyGroup[];
}

export interface SceneInfo { id: number; name: string; sub: string; color: string }
export const SCENES: SceneInfo[] = [
  { id: 1, name: "辺境の荒野", sub: "不死の軍勢", color: "#9fc27a" },
  { id: 2, name: "裂け谷", sub: "蛮族の襲撃", color: "#e48a4a" },
  { id: 3, name: "霜の峠", sub: "神秘の守護者", color: "#b58cff" },
  { id: 4, name: "王都決戦", sub: "全軍総力戦", color: "#e0503f" },
];

/** Available before clearing stage 1. */
export const STARTER_UNITS: UnitKind[] = ["spear", "guardian", "archer"];

const g = (kind: UnitKind, count: number, x: number, z: number, pattern: Pattern = "line"): EnemyGroup => ({ kind, count, x, z, pattern });

export const STAGES: Stage[] = [
  // ---- Scene 1: Borderland Wastes (Undead) ----
  { id: 1, scene: 1, name: "墓地の夜", hint: "ゾンビの群れが迫る。槍兵を並べて迎え撃とう。", budget: 250, unlock: ["swordsman", "pirate"],
    enemies: [g("zombie", 8, 22, 0), g("skeleton", 3, 28, 4)] },
  { id: 2, scene: 1, name: "霧の街道", hint: "後ろから骨弓兵が狙ってくる。盾兵を前衛に置こう。", budget: 400, unlock: ["crossbow", "robot"],
    enemies: [g("zombie", 10, 20, -4), g("skeleton", 6, 24, 4), g("bonearcher", 5, 36, 0)] },
  { id: 3, scene: 1, name: "廃村の包囲", hint: "左右から挟み撃ちしてくる。前線を横に広げよう。", budget: 500, unlock: ["halberdier", "king"],
    enemies: [g("zombie", 10, 22, 0, "flank"), g("skeleton", 6, 24, 0, "block"), g("bonearcher", 5, 36, 0)] },
  { id: 4, scene: 1, name: "朽ちた関所", hint: "骨の部隊が中央突破を狙う。射撃と盾で受け止めよう。", budget: 600, unlock: ["cleric", "zeus"],
    enemies: [g("skeleton", 10, 24, 0, "wedge"), g("bonearcher", 6, 36, -6), g("zombie", 8, 20, 12)] },
  { id: 5, scene: 1, name: "闇の主", hint: "吸血鬼は攻撃しながら回復する。火力で一気に落とそう。", budget: 750, unlock: ["knight", "tank"],
    enemies: [g("skeleton", 10, 22, 0, "block"), g("bonearcher", 7, 36, 0), g("vampire", 2, 28, 0), g("zombie", 8, 18, 0, "flank")] },

  // ---- Scene 2: Rift Canyon (Warband) ----
  { id: 6, scene: 2, name: "峡谷の哨戒", hint: "オークの一撃は重い。大盾と槍で体勢を守ろう。", budget: 780, unlock: ["orc", "railgun"],
    enemies: [g("orc", 7, 22, 0, "block"), g("berserker", 4, 28, 0, "flank"), g("javelin", 5, 36, 0)] },
  { id: 7, scene: 2, name: "赤土の野営", hint: "投槍兵が盾ごと吹き飛ばす。弩兵や弓で先に仕留めよう。", budget: 860, unlock: ["berserker"],
    enemies: [g("orc", 8, 22, -6, "block"), g("javelin", 6, 34, 4), g("berserker", 5, 26, 12)] },
  { id: 8, scene: 2, name: "魔術の峡間", hint: "呪術師の弾は動きを鈍らせる。左右に散開して攻めよう。", budget: 960, unlock: ["javelin"],
    enemies: [g("orc", 9, 24, 0, "wedge"), g("berserker", 6, 28, 0, "flank"), g("shaman", 3, 38, 0), g("javelin", 4, 34, -8)] },
  { id: 9, scene: 2, name: "火薬庫", hint: "爆弾兵は密集に強い。少人数ずつ間隔を空けて置こう。", budget: 1080, unlock: ["bomber"],
    enemies: [g("bomber", 2, 32, 0), g("orc", 8, 22, 0, "flank"), g("berserker", 4, 26, 8), g("shaman", 2, 40, -6)] },
  { id: 10, scene: 2, name: "巨人の谷", hint: "巨人は一振りで複数を巻き込む。騎兵の突撃や戟兵が有効だ。", budget: 1200, unlock: ["shaman"],
    enemies: [g("giant", 2, 30, 0), g("orc", 8, 22, -10), g("berserker", 5, 24, 12), g("javelin", 4, 38, 0), g("shaman", 2, 42, -6)] },

  // ---- Scene 3: Frost Pass (Mystic) ----
  { id: 11, scene: 3, name: "雪林の関", hint: "エルフの射程が長い。盾を先頭に立てて距離を詰めよう。", budget: 1220, unlock: ["elf"],
    enemies: [g("elf", 7, 34, 0), g("monk", 6, 22, 0, "block"), g("frost", 2, 40, 4)] },
  { id: 12, scene: 3, name: "氷結の坂", hint: "氷の術師と刺客の連携。後衛の近くに護衛を残そう。", budget: 1300, unlock: ["monk"],
    enemies: [g("frost", 4, 34, 0), g("monk", 8, 22, 0, "block"), g("elf", 5, 40, -8), g("assassin", 4, 24, 0, "flank")] },
  { id: 13, scene: 3, name: "霧隠れの峠", hint: "刺客の大群が射手や僧侶を狙う。前後の隙をなくそう。", budget: 1400, unlock: ["assassin"],
    enemies: [g("assassin", 7, 24, 0, "flank"), g("mage", 4, 36, 0), g("monk", 7, 26, -8), g("elf", 4, 42, 8)] },
  { id: 14, scene: 3, name: "魔導陣", hint: "追尾魔弾と僧侶の回復が厄介。騎兵や刺客で後衛を崩そう。", budget: 1520, unlock: ["mage"],
    enemies: [g("mage", 3, 34, 0, "arc"), g("frost", 2, 38, -10), g("monk", 10, 22, 4, "block"), g("cleric", 2, 44, 0), g("elf", 3, 40, 10)] },
  { id: 15, scene: 3, name: "氷峰の祭壇", hint: "守りの硬い聖なる陣。手数と回復で正面から競り勝とう。", budget: 1650, unlock: ["frost"],
    enemies: [g("mage", 3, 36, 0, "arc"), g("frost", 2, 40, -8), g("cleric", 2, 46, 0), g("monk", 10, 22, 0, "wedge"), g("assassin", 6, 26, 0, "flank"), g("elf", 5, 42, 8)] },

  // ---- Scene 4: Royal Citadel (All Factions) ----
  { id: 16, scene: 4, name: "外郭門", hint: "盾と斧槍と魔導の混成軍。正面突破と側面攻撃を合わせよう。", budget: 1700, unlock: ["zombie", "skeleton"],
    enemies: [g("guardian", 6, 20, 0, "block"), g("halberdier", 5, 24, 0, "line"), g("crossbow", 6, 36, -6), g("mage", 2, 42, 6), g("assassin", 3, 24, 0, "flank")] },
  { id: 17, scene: 4, name: "燃える広場", hint: "爆弾と魔法の集中砲火。隊列を左右に分けて突っ込もう。", budget: 1850, unlock: ["bonearcher"],
    enemies: [g("bomber", 2, 32, 0), g("orc", 9, 22, 0, "flank"), g("mage", 2, 38, 8), g("shaman", 2, 42, -8), g("halberdier", 6, 24, 0)] },
  { id: 18, scene: 4, name: "王宮回廊", hint: "刺客と吸血鬼が横を突く。側面を守りながら押し上げよう。", budget: 1950, unlock: ["troll"],
    enemies: [g("assassin", 8, 24, 0, "flank"), g("vampire", 3, 28, 0), g("frost", 4, 38, -8), g("paladin", 2, 22, 0)] },
  { id: 19, scene: 4, name: "玉座の前", hint: "トロールの再生と僧侶の回復が重なる。火力で押し切ろう。", budget: 2150, unlock: ["vampire"],
    enemies: [g("troll", 2, 28, 0), g("vampire", 3, 26, 0, "flank"), g("cleric", 3, 44, 0), g("halberdier", 8, 22, 0, "block"), g("mage", 3, 40, -10), g("crossbow", 4, 42, 8)] },
  { id: 20, scene: 4, name: "王都決戦", hint: "全軍の精鋭が立ち塞がる。持てる兵種を総動員して挑め。", budget: 2450, unlock: ["paladin", "giant"],
    enemies: [g("giant", 2, 32, -6), g("troll", 1, 34, 8), g("vampire", 3, 28, 0), g("paladin", 2, 26, 10),
      g("mage", 3, 40, -8), g("frost", 3, 42, 8), g("cleric", 3, 46, 0), g("halberdier", 7, 20, 0, "block"), g("assassin", 5, 24, 0, "flank")] },
];

// Balanced player budget multipliers: modest advantage early, tight parity later so lazy clump-spam fails.
const additions: [number, UnitKind][] = [[6, "snakearcher"], [7, "icearcher"], [8, "balloonarcher"], [10, "mammoth"], [12, "ballista"], [18, "reaper"]];
for (const [id, kind] of additions) STAGES[id - 1].unlock.push(kind);
STAGES[7].enemies.push(g("snakearcher", 2, 39, 12));
STAGES[9].enemies[0] = g("mammoth", 1, 30, 0);
STAGES[9].hint = "マンモスは密集を踏み潰す。戟兵を広く並べ、弩と風船で集中攻撃しよう。";
STAGES[10].enemies.push(g("icearcher", 2, 36, 13));
STAGES[13].enemies.push(g("balloonarcher", 2, 38, 14));
STAGES[15].enemies.push(g("ballista", 1, 42, -15));
STAGES[17].enemies.push(g("reaper", 1, 30, -12));
STAGES[19].enemies.push(g("mammoth", 1, 31, 18));

const RATIO = [
  1.2, 1.08, 1.06, 1.08, 1.08,
  1.04, 1.08, 1.06, 1.14, 1.08,
  1.06, 1.06, 1.05, 1.06, 1.08,
  1.06, 1.08, 1.06, 1.06, 1.18,
];
for (let i = 0; i < STAGES.length; i++) {
  const s = STAGES[i];
  s.budget = Math.max(300, Math.round((enemyCost(s) * RATIO[i]) / 25) * 25);
}

/** Units usable once `cleared` stages are done (0 = nothing cleared yet). */
export function unlockedThrough(cleared: number): UnitKind[] {
  const set = new Set<UnitKind>(STARTER_UNITS);
  for (let i = 0; i < Math.min(cleared, STAGES.length); i++) for (const k of STAGES[i].unlock) set.add(k);
  return [...set];
}

export function stagePositions(gr: EnemyGroup): { x: number; z: number }[] {
  const out: { x: number; z: number }[] = [];
  const n = gr.count;
  const sp = 2.3;
  switch (gr.pattern) {
    case "line":
      for (let i = 0; i < n; i++) out.push({ x: gr.x, z: gr.z + (i - (n - 1) / 2) * sp });
      break;
    case "block": {
      const cols = Math.max(1, Math.ceil(Math.sqrt(n)));
      for (let i = 0; i < n; i++) out.push({ x: gr.x + Math.floor(i / cols) * sp, z: gr.z + (i % cols - (cols - 1) / 2) * sp });
      break;
    }
    case "wedge": {
      let rank = 0, placed = 0;
      while (placed < n) {
        const inRank = Math.min(n - placed, rank + 1);
        for (let i = 0; i < inRank; i++) out.push({ x: gr.x + rank * sp, z: gr.z + (i - (inRank - 1) / 2) * sp });
        placed += inRank;
        rank++;
      }
      break;
    }
    case "flank": {
      const half = Math.ceil(n / 2);
      for (let i = 0; i < n; i++) {
        const side = i < half ? -1 : 1;
        const idx = i < half ? i : i - half;
        const per = i < half ? half : n - half;
        out.push({ x: gr.x + (idx % 3) * sp, z: side * 16 + (Math.floor(idx / 3) - (Math.ceil(per / 3) - 1) / 2) * sp });
      }
      break;
    }
    case "arc": {
      const spread = Math.min(Math.PI * 0.9, 0.34 * n);
      for (let i = 0; i < n; i++) {
        const a = n === 1 ? 0 : -spread / 2 + (i / (n - 1)) * spread;
        out.push({ x: gr.x + Math.abs(Math.sin(a)) * 6, z: gr.z + Math.cos(a) * 12 });
      }
      break;
    }
  }
  return out;
}

export function enemyCost(stage: Stage): number {
  return stage.enemies.reduce((sum, e) => sum + DEFS[e.kind].cost * e.count, 0);
}

/* ---- progress persistence ---- */

const KEY = "ebs.story.cleared";
let memoryCleared = 0;

export function loadCleared(): number {
  try {
    if (typeof window !== "undefined" && "localStorage" in window && window.localStorage) {
      const raw = window.localStorage.getItem(KEY);
      if (raw !== null) {
        const n = parseInt(raw, 10);
        if (Number.isFinite(n)) {
          memoryCleared = Math.max(memoryCleared, Math.max(0, Math.min(STAGES.length, n)));
        }
      }
    }
  } catch {
    /* storage blocked or unavailable — fall back to in-memory state */
  }
  return memoryCleared;
}

export function saveCleared(cleared: number) {
  const clamped = Number.isFinite(cleared) ? Math.max(0, Math.min(STAGES.length, Math.floor(cleared))) : 0;
  memoryCleared = Math.max(memoryCleared, clamped);
  try {
    if (typeof window !== "undefined" && "localStorage" in window && window.localStorage) {
      window.localStorage.setItem(KEY, String(memoryCleared));
    }
  } catch {
    /* storage blocked or unavailable — progress remains preserved in memoryCleared */
  }
}
