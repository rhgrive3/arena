import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { GEO, M, TEAM_COLORS, type TeamId, type UnitKind } from "./units";
import {
  bootGeo, browCurveGeo, cloakGeo, clothHoodGeo, crestFinGeo, crownSpikeGeo,
  cuirassGeo, curvedHornGeo, extrudeShape, faceStripGeo, headSurfaceZ,
  heaterShieldGeo, kettleHelmGeo, latheGeo, loftTube, mouthCurveGeo,
  muscularTorsoGeo, openMouthCavityGeo, prepGeo, ribArchGeo, ringBandGeo, robeTorsoGeo,
  torsoStrapGeo, tricornBrimGeo, tunicTorsoGeo, upperTeethGeo, visorFaceGeo,
  warHelmGeo, wingPlumeGeo, wizardBrimGeo, wizardCrownGeo,
} from "./rig-geo";

/* ============================================================
   Character rigs. Every rig faces +Z (facing = atan2(x, z)).
   Static meshes of each bone are merged into one vertex-coloured
   geometry, so posing a unit costs ~10 matrix updates per frame.
   ============================================================ */

export interface Spring { x: number; v: number }
export interface RigPart { group: THREE.Group; geometry: THREE.BufferGeometry; material: THREE.Material }
export type HandMode = "fixed" | "follow";

export interface UnitRig {
  root: THREE.Group;
  body: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  hand: THREE.Group;
  lLeg: THREE.Group;
  rLeg: THREE.Group;
  lArm: THREE.Group;
  rArm: THREE.Group;
  cloak: THREE.Group | null;
  flLeg?: THREE.Group;
  frLeg?: THREE.Group;
  blLeg?: THREE.Group;
  brLeg?: THREE.Group;
  appendages?: THREE.Group[];
  headH: number;
  heavy: boolean;
  scale: number;
  tilt: number;
  kind: UnitKind;
  handMode: HandMode;
  handRest: number;
  parts: RigPart[];
  fx: Record<string, Spring>;
}

const PI = Math.PI, TAU = PI * 2;
const dark = (c: number, f = 0.55) => new THREE.Color(c).multiplyScalar(f).getHex();
const light = (c: number, f = 0.35) => new THREE.Color(c).lerp(new THREE.Color(0xffffff), f).getHex();
const bCache = new Map<number, THREE.MeshBasicMaterial>();
const B = (c: number) => {
  let m = bCache.get(c);
  if (!m) { m = new THREE.MeshBasicMaterial({ color: c }); bCache.set(c, m); }
  return m;
};
const STEEL = 0xaab3c2, STEEL_LIGHT = 0xdce3ed, STEEL_DARK = 0x5c6472, IRON = 0x434954;
const GOLD = 0xe0b04a, GOLD_LIGHT = 0xf5d478, BRASS = 0xb88a3e, COPPER = 0xc87442;
const LEATHER = 0x523a24, LEATHER_DARK = 0x2f2114, BONE = 0xe8e0c8, BONE_DARK = 0xc7bea2;
const steel = (c = STEEL) => M(c, 0.32, 0.82);
const gold = (c = GOLD) => M(c, 0.28, 0.85);
const leather = (c = LEATHER) => M(c, 0.78, 0.08);
const cloth = (c: number) => M(c, 0.88, 0.04);
const boneMat = (c = BONE) => M(c, 0.68, 0.06);

const gCache = new Map<string, THREE.BufferGeometry>();
function cached(key: string, make: () => THREE.BufferGeometry): THREE.BufferGeometry {
  let g = gCache.get(key);
  if (!g) { g = make(); gCache.set(key, g); }
  return g;
}

function part(
  parent: THREE.Object3D, geo: THREE.BufferGeometry, mat: THREE.Material,
  sx = 1, sy = 1, sz = 1, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0,
): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.scale.set(sx, sy, sz);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  parent.add(m);
  return m;
}

/** A smooth tapered link between two 3D points (organic tendons, cords, spokes). */
function link(parent: THREE.Object3D, mat: THREE.Material, a: THREE.Vector3, b: THREE.Vector3, radius: number) {
  const m = new THREE.Mesh(GEO.cyl, mat);
  m.position.copy(a).add(b).multiplyScalar(0.5);
  const direction = b.clone().sub(a);
  m.scale.set(radius, direction.length(), radius);
  m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.normalize());
  parent.add(m);
  return m;
}

/** Smooth Catmull-Rom lofted tube helper with radius function. */
function swept(
  parent: THREE.Object3D,
  points: number[][],
  radius: number | ((t: number) => number),
  mat: THREE.Material,
  taper = 0.1,
  seg = 20,
  radial = 10,
) {
  const vecs = points.map(p => new THREE.Vector3(p[0], p[1], p[2]));
  const rFn = typeof radius === "function"
    ? radius
    : (t: number) => radius * (1 - (1 - taper) * Math.pow(t, 1.45));
  const geo = loftTube(vecs, rFn, seg, radial, true);
  return part(parent, geo, mat);
}

const BALLOON_GEO = (() => {
  return latheGeo([
    [0, -0.34],
    [0.05, -0.32],
    [0.03, -0.26],
    [0.14, -0.14],
    [0.24, 0.02],
    [0.28, 0.18],
    [0.22, 0.3],
    [0, 0.35],
  ], 18, 1, 1, 16);
})();

/* ============ faces: smooth conformed curves & expressive TABS Wobbler eyes ============ */

interface Face {
  sep?: number; y?: number; z?: number; size?: number;
  sclera?: number; pupil?: number; brow?: number; browColor?: number;
  uneven?: boolean; look?: number; lookY?: number;
  mouth?: "smile" | "flat" | "open" | "grin" | "none";
  socket?: boolean;
  /** True when the face sits behind a steel visor slit (eye glow sits further forward). */
  visored?: boolean;
}

function addFace(head: THREE.Group, skin: number, f: Face = {}) {
  const sep = f.sep ?? 0.098, y = f.y ?? 0.032, z = f.z ?? 0.224, r = f.size ?? 0.06;
  const skinDark = dark(skin, 0.78), skinShadow = dark(skin, 0.65);

  if (f.visored) {
    for (const s of [-1, 1]) {
      part(head, GEO.sph, B(f.pupil ?? 0xa4ecff), r * 0.72, r * 0.48, 0.03, s * 0.088, 0.035, 0.248);
      part(head, GEO.sph, B(0xffffff), r * 0.26, r * 0.22, 0.02, s * 0.088, 0.038, 0.268);
    }
    return;
  }

  for (const s of [-1, 1]) {
    const k = f.uneven && s > 0 ? 1.32 : 1;
    if (f.socket) {
      part(head, GEO.sph, boneMat(BONE_DARK), r * 1.62, r * 1.75, r * 0.65, s * sep, y, z - 0.008);
      part(head, GEO.sph, B(0x0b0907), r * 1.42, r * 1.55, r * 0.52, s * sep, y, z + 0.002);
      part(head, GEO.sph, B(f.pupil ?? 0x7fe8ff), r * 0.62, r * 0.62, r * 0.38, s * sep, y - 0.002, z + r * 0.58);
      part(head, GEO.sph, B(0xffffff), r * 0.24, r * 0.24, r * 0.16, s * sep + r * 0.12, y + r * 0.12, z + r * 0.82);
    } else {
      part(head, GEO.sph, M(skinDark, 0.68), r * 1.15 * k, r * 1.18 * k, r * 0.5 * k, s * sep, y, z - 0.01);
      part(head, GEO.sph, M(skinShadow, 0.62), r * 1.15 * k, r * 0.44 * k, r * 0.56 * k, s * sep, y + r * 0.76 * k, z + 0.005, 0, 0, -s * 0.06);
      part(head, GEO.sph, B(f.sclera ?? 0xf7f3e6), r * k, r * 1.08 * k, r * 0.56 * k, s * sep, y, z);
      part(head, GEO.sph, B(f.pupil ?? 0x18130e), r * 0.55 * k, r * 0.62 * k, r * 0.36 * k,
        s * sep * 0.94 + (f.look ?? 0) * r * 0.22 * (f.uneven && s > 0 ? -1 : 1), y + (f.lookY ?? 0) * r * 0.25, z + r * 0.44 * k);
      part(head, GEO.sph, B(0xffffff), r * 0.2 * k, r * 0.2 * k, r * 0.11 * k, s * sep * 0.94 + r * 0.15, y + r * 0.28, z + r * 0.75 * k);
    }
    if (f.brow !== undefined || !f.socket) {
      const browTilt = f.brow ?? 0;
      const bKey = `brow:${s}:${sep}:${y + r * 1.45}:${browTilt}`;
      part(head, cached(bKey, () => browCurveGeo(s, sep, y + r * 1.45, browTilt)), B(f.browColor ?? 0x2a1d12));
    }
  }

  const mouth = f.mouth ?? "smile";
  if (mouth === "smile") {
    part(head, cached("m:smile", () => mouthCurveGeo(0.065, -0.108, 0.034, 0.0085)), B(0x3a1c14));
    part(head, cached("m:smile_lip", () => mouthCurveGeo(0.045, -0.128, 0.014, 0.007, 0.003)), M(skinDark, 0.62));
  } else if (mouth === "flat") {
    part(head, cached("m:flat", () => mouthCurveGeo(0.062, -0.115, 0.0, 0.0075)), B(0x3a1c14));
    part(head, cached("m:flat_lip", () => mouthCurveGeo(0.044, -0.132, 0.0, 0.006, 0.003)), M(skinDark, 0.62));
  } else if (mouth === "open") {
    part(head, cached("m:open_cav", () => openMouthCavityGeo(0.056, 0.062, -0.095)), B(0x280d0b));
    part(head, cached("m:open_teeth", () => upperTeethGeo(0.05, 0.018, -0.096)), B(0xf3eee0));
    part(head, GEO.sph, M(0x9a3d3b, 0.7), 0.032, 0.016, 0.018, 0, -0.138, headSurfaceZ(0, -0.138) + 0.006);
    part(head, cached("m:open_lip", () => mouthCurveGeo(0.048, -0.156, -0.012, 0.0065, 0.003)), M(skinDark, 0.62));
  } else if (mouth === "grin") {
    part(head, cached("m:grin_cav", () => openMouthCavityGeo(0.072, 0.042, -0.1)), B(0x2b0f0d));
    part(head, cached("m:grin_teeth", () => upperTeethGeo(0.066, 0.022, -0.101)), B(0xf5f0e2));
    part(head, cached("m:grin_lip", () => mouthCurveGeo(0.056, -0.142, 0.02, 0.0065, 0.003)), M(skinDark, 0.62));
  }

  if (!f.socket) {
    const nz = headSurfaceZ(0, -0.025);
    part(head, GEO.sph, M(skin, 0.58), 0.026, 0.045, 0.032, 0, -0.02, nz + 0.006, -0.18, 0, 0);
    part(head, GEO.sph, M(skin, 0.6), 0.038, 0.032, 0.036, 0, -0.046, nz + 0.014);
    for (const s of [-1, 1]) part(head, GEO.sph, M(skinDark, 0.62), 0.017, 0.015, 0.018, s * 0.018, -0.05, nz + 0.008);
  } else {
    part(head, GEO.cone, B(0x0b0907), 0.032, 0.068, 0.026, 0, -0.052, headSurfaceZ(0, -0.052) + 0.005, PI, 0, 0);
  }
}

/* ============ humanoid ============ */

type HumanKind = Exclude<
  UnitKind,
  "knight" | "robot" | "tank" | "railgun" | "mammoth" | "snake" | "ballista" | "reaper"
>;

interface Look {
  skin: number; armor: number; pants: number; boot: number;
  chest: number; scale: number; head: number; legs: number; tilt: number;
  arm?: number; armW?: number; shoulder?: number; stance?: number; belly?: number;
}

function lookOf(kind: HumanKind, tc: number, tcd: number): Look {
  const base: Look = {
    skin: 0xe6b88e, armor: tc, pants: 0x2f3540, boot: 0x241d13,
    chest: 0.74, scale: 1, head: 1.28, legs: 1, tilt: 0.04,
  };
  switch (kind) {
    case "spear": return base;
    case "snakearcher": return { ...base, skin: 0xdeb086, armor: 0x3b623b, pants: 0x2a452a, boot: 0x3a2c1a, chest: 0.68, scale: 1.0, tilt: 0.05 };
    case "icearcher": return { ...base, skin: 0xe8e0d5, armor: 0x4b79a4, pants: 0x2c405c, boot: 0x253247, chest: 0.68, scale: 1.0, tilt: 0.05 };
    case "balloonarcher": return { ...base, skin: 0xeac096, armor: 0xa83242, pants: 0x2f2a44, boot: 0x3a2014, chest: 0.7, scale: 1.0, tilt: 0.05 };
    case "guardian": return { ...base, armor: 0x8d96a6, pants: 0x3a404c, boot: 0x2b2f38, chest: 0.9, scale: 1.06, head: 1.22, legs: 0.9, tilt: 0.02, arm: 0.95, armW: 1.22, shoulder: 0.06, stance: 0.04 };
    case "archer": return { ...base, armor: 0x6e5a38, pants: 0x4a3b28, boot: 0x2a2016, chest: 0.66, scale: 0.98, tilt: 0.06, stance: -0.01 };
    case "crossbow": return { ...base, armor: tcd, pants: 0x353a44, chest: 0.74, scale: 1.02, head: 1.26, legs: 0.98, tilt: 0.05, stance: 0.02 };
    case "swordsman": return { ...base, armor: 0x9aa3b2, pants: 0x3d4450, chest: 0.72, scale: 1.0, head: 1.26, legs: 1.02, tilt: 0.05 };
    case "halberdier": return { ...base, armor: 0x7f8896, pants: 0x333945, chest: 0.74, scale: 1.08, head: 1.2, legs: 1.1, tilt: 0.03, arm: 1.08, armW: 0.95 };
    case "paladin": return { ...base, armor: 0xd8dbe2, pants: 0x2f3540, boot: 0x2b2f38, chest: 0.86, scale: 1.14, head: 1.2, legs: 0.96, tilt: 0.02, shoulder: 0.05, stance: 0.02 };
    case "orc": return { ...base, skin: 0x84b455, armor: 0x55452e, pants: 0x3a3326, boot: 0x1f1a12, chest: 0.94, scale: 1.22, head: 1.16, legs: 0.9, tilt: 0.14, arm: 1.16, armW: 1.38, shoulder: 0.09, stance: 0.04, belly: 0.85 };
    case "berserker": return { ...base, skin: 0xd29a6c, armor: 0xd29a6c, pants: 0x4f3a26, boot: 0x2a2016, chest: 0.84, scale: 1.1, head: 1.22, tilt: 0.1, arm: 1.05, armW: 1.25, shoulder: 0.05, stance: 0.03 };
    case "javelin": return { ...base, skin: 0xcf966a, armor: 0x7a6242, pants: 0x4a3b28, chest: 0.7, scale: 1.0, head: 1.28, legs: 1.02, tilt: 0.06 };
    case "bomber": return { ...base, skin: 0xcf966a, armor: 0x6b5a3e, pants: 0x2f3540, chest: 0.78, head: 1.3, legs: 0.9, tilt: 0.08, stance: 0.02, belly: 0.45 };
    case "shaman": return { ...base, skin: 0x8fa060, armor: 0x6a5a3a, pants: 0x4a4230, boot: 0x3a3020, chest: 0.7, scale: 1.04, head: 1.3, legs: 0.92, tilt: 0.22 };
    case "troll": return { ...base, skin: 0x82966c, armor: 0x82966c, pants: 0x544434, boot: 0x3a2c20, chest: 1.02, scale: 1.68, head: 1.16, legs: 0.9, tilt: 0.18, arm: 1.3, armW: 1.42, shoulder: 0.11, stance: 0.05, belly: 0.85 };
    case "giant": return { ...base, skin: 0xbf9070, armor: 0xbf9070, pants: 0x544434, boot: 0x3a2c20, chest: 1.04, scale: 1.9, head: 1.18, legs: 0.92, tilt: 0.05, arm: 1.3, armW: 1.38, shoulder: 0.12, stance: 0.06, belly: 0.65 };
    case "elf": return { ...base, skin: 0xf0dcb8, armor: 0x3f6b3a, pants: 0x2f4a2c, boot: 0x4a3826, chest: 0.56, scale: 0.97, legs: 1.12, tilt: 0.02, arm: 1.06, armW: 0.78, shoulder: -0.03, stance: -0.02 };
    case "monk": return { ...base, skin: 0xdca87e, armor: 0xc8a058, pants: 0xb08a4a, boot: 0x5a4630, chest: 0.68, scale: 1.0, head: 1.26, legs: 1.04, tilt: 0.05, armW: 1.1, stance: 0.02 };
    case "assassin": return { ...base, armor: 0x2b2f3a, pants: 0x23262e, boot: 0x18191f, chest: 0.58, scale: 0.96, head: 1.22, legs: 1.04, tilt: 0.16, armW: 0.82, shoulder: -0.02 };
    case "mage": return { ...base, armor: tc, pants: 0x2a2f3a, boot: tcd, chest: 0.64, head: 1.28, tilt: 0.02 };
    case "frost": return { ...base, skin: 0xe8dcc8, armor: 0x4f7fbf, pants: 0x2f4462, boot: 0x2a3a52, chest: 0.64, head: 1.28, tilt: 0.02 };
    case "cleric": return { ...base, armor: 0xf0ead8, pants: 0xd8cfb0, boot: 0x5a4630, chest: 0.68, head: 1.28, tilt: 0.02 };
    case "zombie": return { ...base, skin: 0x9fb072, armor: 0x5a5a44, pants: 0x3a3a2e, boot: 0x2a2a20, chest: 0.7, head: 1.3, tilt: 0.34, arm: 1.12, armW: 0.9, stance: 0.02 };
    case "skeleton": return { ...base, skin: 0xece5cd, armor: 0xece5cd, pants: 0xe0d9c0, boot: 0xcfc8ae, chest: 0.5, scale: 1.02, head: 1.35, legs: 1.05, tilt: 0.05, shoulder: -0.04, stance: -0.02 };
    case "bonearcher": return { ...base, skin: 0xe6dfc6, armor: 0xe6dfc6, pants: 0xd8d0b4, boot: 0xc6bfa6, chest: 0.5, scale: 1.0, head: 1.35, legs: 1.05, tilt: 0.05, shoulder: -0.04, stance: -0.02 };
    case "vampire": return { ...base, skin: 0xe8dcd0, armor: 0x241f2c, pants: 0x1c1824, boot: 0x141119, chest: 0.7, scale: 1.08, head: 1.22, legs: 1.08, tilt: 0.04, armW: 0.9 };
    case "king": return { ...base, skin: 0xefc39a, armor: 0x8a2f3c, pants: 0x5a1620, boot: 0x3d1016, chest: 0.88, scale: 1.2, head: 1.2, legs: 0.94, tilt: 0.03, armW: 1.1, shoulder: 0.06, stance: 0.03, belly: 0.45 };
    case "pirate": return { ...base, skin: 0xd19a6a, armor: 0x4a3a52, pants: 0x2e2734, boot: 0x241d22, chest: 0.72, scale: 1.02, head: 1.26, legs: 1.0, tilt: 0.07, stance: 0.02 };
    case "zeus": return { ...base, skin: 0xe9c9a0, armor: 0xf2ead4, pants: 0xf2ead4, boot: 0xc2a45c, chest: 0.98, scale: 1.3, head: 1.14, legs: 1.12, tilt: 0.0, armW: 1.24, shoulder: 0.07, stance: 0.03 };
  }
}

/** Shared smooth limb geometry: seamless thigh/arm -> knee/elbow -> calf/forearm. */
function legTubeGeo(r: number, len: number): THREE.BufferGeometry {
  return cached(`leg:${r.toFixed(3)}:${len.toFixed(3)}`, () =>
    latheGeo([
      [0, -0.92 * len],
      [r * 0.64, -0.92 * len],
      [r * 0.72, -0.7 * len],
      [r * 0.82, -0.48 * len],
      [r * 0.8, -0.4 * len],
      [r * 0.94, -0.18 * len],
      [r * 0.9, 0.0],
      [0, 0.04],
    ], 18, 1, 1.06, 20),
  );
}

function armSegmentGeo(r: number, len: number, bare: boolean): THREE.BufferGeometry {
  return cached(`arm:${r.toFixed(3)}:${len.toFixed(3)}:${bare ? 1 : 0}`, () =>
    latheGeo([
      [0, -0.72 * len],
      [r * (bare ? 0.68 : 0.76), -0.72 * len],
      [r * (bare ? 0.84 : 0.82), -0.56 * len],
      [r * 0.76, -0.38 * len],
      [r * (bare ? 0.88 : 0.92), -0.16 * len],
      [r * 0.95, -0.02],
      [0, 0.05],
    ], 16, 1, 1.05, 18),
  );
}

function buildHumanoid(kind: HumanKind, team: TeamId): UnitRig {
  const tc = TEAM_COLORS[team], tcd = dark(tc), tcl = light(tc, 0.35);
  const L = lookOf(kind, tc, tcd);
  const cw = L.chest, ww = cw * 0.84;
  const rx = cw * 0.55, rz = cw * 0.37;
  const skel = kind === "skeleton" || kind === "bonearcher";
  const armored = kind === "guardian" || kind === "swordsman" || kind === "halberdier" || kind === "paladin" || kind === "king" || kind === "vampire" || kind === "zeus";
  const robed = kind === "mage" || kind === "frost" || kind === "cleric" || kind === "monk" || kind === "shaman";
  const plated = kind === "guardian" || kind === "swordsman" || kind === "halberdier" || kind === "paladin";
  const bareChest = kind === "berserker" || kind === "orc" || kind === "troll" || kind === "giant";
  const isColossus = kind === "troll" || kind === "giant";

  const root = new THREE.Group();
  root.rotation.order = "YXZ";
  root.scale.setScalar(L.scale);
  const body = new THREE.Group();
  root.add(body);
  const hipY = 1.02 * L.legs;

  /* ---- 1. legs & seamless rounded boots ---- */
  const mkLeg = (side: number) => {
    const p = new THREE.Group();
    p.position.set(side * (0.16 + cw * 0.05 + (L.stance ?? 0)), hipY, 0);
    body.add(p);
    if (skel) {
      part(p, GEO.sph, boneMat(L.skin), 0.075, 0.075, 0.075, 0, -0.04, 0);
      part(p, GEO.cyl, boneMat(L.skin), 0.046, 0.42 * L.legs, 0.046, 0, -0.24 * L.legs, 0);
      part(p, GEO.sph, boneMat(L.pants), 0.078, 0.074, 0.082, 0, -0.45 * L.legs, 0.02);
      part(p, GEO.cyl, boneMat(L.pants), 0.04, 0.42 * L.legs, 0.04, side * 0.012, -0.67 * L.legs, 0);
      part(p, GEO.cyl, boneMat(BONE_DARK), 0.022, 0.38 * L.legs, 0.022, -side * 0.022, -0.67 * L.legs, -0.012);
      part(p, GEO.sph, boneMat(L.boot), 0.06, 0.05, 0.12, 0, -0.92 * L.legs, 0.05);
      for (const t of [-0.032, 0, 0.032]) part(p, GEO.sph, boneMat(L.skin), 0.014, 0.02, 0.045, t, -0.94 * L.legs, 0.16);
      return p;
    }
    const th = isColossus ? 0.175 : kind === "orc" ? 0.155 : 0.13;
    const shinM = armored
      ? (kind === "paladin" ? steel(0xe0e4ec) : kind === "king" || kind === "zeus" ? gold(L.boot) : steel(STEEL_DARK))
      : M(L.pants, 0.8);
    part(p, legTubeGeo(th, L.legs), M(isColossus ? L.skin : L.pants, 0.82));
    if (armored) {
      part(p, cached(`greave:${th}:${L.legs}`, () =>
        latheGeo([[0, -0.88 * L.legs], [th * 0.88, -0.88 * L.legs], [th * 0.94, -0.62 * L.legs], [th * 0.92, -0.43 * L.legs], [0, -0.43 * L.legs]], 16, 1, 1.06, 12),
      ), shinM);
    }
    const kneeM = armored ? (kind === "paladin" || kind === "king" || kind === "zeus" ? gold() : steel(STEEL_LIGHT)) : leather(0x3d2d1d);
    part(p, GEO.sph, kneeM, th * 0.85, 0.1, th * 0.6, 0, -0.45 * L.legs, th * 0.6);
    part(p, cached(`boot:${th.toFixed(3)}`, () => bootGeo(th, th * 1.8)), armored ? shinM : leather(L.boot), 1, 1, 1, 0, -0.99 * L.legs, 0);
    part(p, GEO.cyl, armored ? shinM : leather(dark(L.boot, 0.8)), th * 0.88, 0.12, th * 0.94, 0, -0.82 * L.legs, 0);
    if (kind === "zombie" && side < 0) part(p, GEO.cyl, boneMat(), 0.045, 0.16, 0.045, 0, -0.58 * L.legs, 0.08);
    return p;
  };
  const lLeg = mkLeg(1), rLeg = mkLeg(-1);

  /* ---- 2. seamless torso & fitted clothing ---- */
  const torso = new THREE.Group();
  torso.position.set(0, hipY + 0.04, 0);
  torso.rotation.x = L.tilt;
  body.add(torso);

  if (skel) {
    part(torso, GEO.sph, boneMat(L.skin), ww * 0.46, 0.12, cw * 0.28, 0, 0.0, 0);
    for (let i = 0; i < 6; i++) {
      part(torso, GEO.cyl, boneMat(L.skin), 0.048, 0.11, 0.048, 0, 0.12 + i * 0.12, -0.04);
      part(torso, GEO.cone, boneMat(L.pants), 0.024, 0.065, 0.024, 0, 0.12 + i * 0.12, -0.1, -PI / 2, 0, 0);
    }
    part(torso, GEO.cyl, boneMat(L.skin), 0.036, 0.46, 0.024, 0, 0.48, cw * 0.24);
    part(torso, GEO.sph, B(kind === "bonearcher" ? 0x7eff9e : tcl), 0.075, 0.11, 0.06, 0, 0.48, 0.01);
    for (let i = 0; i < 4; i++) {
      const ry = 0.28 + i * 0.13, rw = cw * (0.45 + i * 0.035);
      for (const s of [-1, 1]) {
        if (kind === "skeleton" && i === 1 && s < 0) continue;
        part(torso, cached(`rib:${s}:${rw.toFixed(2)}`, () => ribArchGeo(s, rw, cw * 0.46)), boneMat(L.skin), 1, 1, 1, 0, ry, -0.01);
      }
    }
    for (const s of [-1, 1]) part(torso, GEO.cyl, boneMat(L.skin), 0.028, cw * 0.56, 0.028, s * cw * 0.26, 0.78, 0.02, 0, 0, PI / 2 - s * 0.18);
    part(torso, cached(`skel_sash:${cw}`, () => torsoStrapGeo(cw * 0.44, cw * 0.28, 0.66, 0.18, 0.02, 0.085)), M(tc));
    if (kind === "bonearcher") {
      part(torso, GEO.cyl, leather(0x4a3220), 0.09, 0.54, 0.09, 0.16, 0.5, -rz - 0.06, 0.2, 0, -0.15);
      for (let i = 0; i < 3; i++) {
        part(torso, GEO.cyl, boneMat(), 0.015, 0.24, 0.015, 0.13 + i * 0.03, 0.84, -rz - 0.11);
        part(torso, GEO.sph, B(0x88ff9e), 0.024, 0.045, 0.014, 0.13 + i * 0.03, 0.94, -rz - 0.11);
      }
    }
  } else if (robed) {
    const robeC = kind === "frost" ? 0x4673ab : kind === "cleric" ? 0xf0ead8 : kind === "monk" ? 0xc8a058 : kind === "shaman" ? 0x6a5a3a : tc;
    part(torso, cached(`robe:${cw.toFixed(2)}`, () => robeTorsoGeo(cw, kind === "monk" ? 0.56 : 0.62)), cloth(robeC));
    const beltC = kind === "frost" ? 0xbfe4ff : kind === "monk" ? 0x8a642e : kind === "shaman" ? 0xd8cfb0 : GOLD;
    part(torso, cached(`belt:${cw.toFixed(2)}`, () => torsoStrapGeo(rx * 0.88, rz * 0.88, 0.12, 0.12, 0.024, 0.095)), cloth(beltC));
    if (kind === "mage" || kind === "frost") {
      part(torso, GEO.sph, M(kind === "frost" ? 0xbfe4ff : GOLD, 0.4, 0.5), 0.05, 0.5, 0.03, 0, -0.25, rz * 1.06);
      part(torso, GEO.sph, leather(0x4a2a18), 0.07, 0.12, 0.09, -rx * 0.94, 0.02, 0.04, 0, 0, 0.14);
    }
    if (kind === "cleric") {
      for (const s of [-1, 1]) part(torso, GEO.sph, cloth(tc), 0.065, 0.55, 0.04, s * 0.1, 0.08, rz * 0.95);
      part(torso, GEO.cyl, gold(), 0.02, 0.22, 0.02, 0, 0.56, rz * 1.04);
      part(torso, GEO.cyl, gold(), 0.02, 0.16, 0.02, 0, 0.6, rz * 1.04, 0, 0, PI / 2);
    }
    if (kind === "monk") {
      part(torso, cached(`kasaya:${cw.toFixed(2)}`, () => torsoStrapGeo(rx * 1.01, rz * 1.01, 0.22, 0.72, 0.026, 0.14)), cloth(0xe2b659));
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * TAU;
        part(torso, GEO.sph, M(i % 4 === 0 ? GOLD : 0x523117, 0.55, 0.15), 0.032, 0.032, 0.032,
          Math.cos(a) * rx * 0.65, 0.8 + Math.cos(a) * -0.05, Math.sin(a) * rz * 0.65 + 0.04);
      }
    }
    if (kind === "shaman") {
      part(torso, cached(`sha_sash:${cw.toFixed(2)}`, () => torsoStrapGeo(rx * 1.02, rz * 1.02, 0.2, 0.74, 0.022, 0.09)), cloth(tc));
      for (let i = -3; i <= 3; i++) {
        const a = i * 0.28;
        part(torso, GEO.cone, boneMat(0xe8e0c8), 0.026, 0.095, 0.026, Math.sin(a) * rx * 0.78, 0.78 - Math.abs(i) * 0.015, Math.cos(a) * rz * 0.82, PI + 0.3, 0, -i * 0.12);
      }
    }
  } else if (plated) {
    const steelC = kind === "paladin" ? 0xe4e8ef : kind === "halberdier" ? 0x7f8896 : kind === "swordsman" ? 0x9aa3b2 : STEEL;
    part(torso, cached(`cuirass:${cw.toFixed(2)}`, () => cuirassGeo(cw)), steel(steelC));
    part(torso, cached(`belt:${cw.toFixed(2)}`, () => torsoStrapGeo(rx * 0.92, rz * 0.94, 0.13, 0.13, 0.024, 0.075)), leather(LEATHER_DARK));
    part(torso, GEO.sph, gold(BRASS), 0.06, 0.06, 0.03, 0, 0.13, rz * 1.02);
    for (const s of [-1, 1]) {
      part(torso, GEO.sph, steel(steelC), 0.21, 0.14, 0.22, s * (cw * 0.56 + 0.06), 0.78, 0, 0, 0, -s * 0.25);
      part(torso, GEO.ring, gold(kind === "paladin" ? GOLD : BRASS), 0.18, 0.18, 0.18, s * (cw * 0.54 + 0.04), 0.74, 0, PI / 2, 0, 0);
    }
    if (kind === "guardian") {
      part(torso, cached(`gd_tab:${cw}`, () => torsoStrapGeo(rx * 1.1, rz * 1.18, 0.22, 0.72, 0.024, 0.1)), cloth(tc));
      part(torso, cached("gd_skirt", () => cloakGeo(0.24, 0.3, 0.26, 2)), cloth(tc), 1, 1, 1, 0, 0.1, rz * 1.08, 0, PI, 0);
    } else if (kind === "swordsman") {
      part(torso, cached(`sash:${cw}`, () => torsoStrapGeo(rx * 1.1, rz * 1.18, 0.2, 0.74, 0.024, 0.09)), cloth(tc));
    } else if (kind === "halberdier") {
      part(torso, cached(`sash:${cw}`, () => torsoStrapGeo(rx * 1.1, rz * 1.18, 0.72, 0.18, 0.024, 0.085)), cloth(tc));
    } else if (kind === "paladin") {
      part(torso, cached(`sash_p:${cw}`, () => torsoStrapGeo(rx * 1.1, rz * 1.18, 0.18, 0.74, 0.024, 0.11)), cloth(tc));
      part(torso, GEO.cyl, gold(), 0.02, 0.24, 0.02, 0, 0.52, rz * 1.13);
      part(torso, GEO.cyl, gold(), 0.02, 0.18, 0.02, 0, 0.56, rz * 1.13, 0, 0, PI / 2);
      for (const s of [-1, 1]) part(torso, cached("wing_p", wingPlumeGeo), gold(GOLD), 0.55, 0.55, 0.55, s * (cw * 0.58 + 0.08), 0.88, -0.02, 0, s * 0.6, s * -0.45);
    }
  } else if (bareChest) {
    part(torso, cached(`musc:${cw.toFixed(2)}:${L.belly ?? 0}`, () => muscularTorsoGeo(cw, L.belly ?? 0)), M(L.skin, 0.68));
    part(torso, cached(`loin:${cw.toFixed(2)}`, () => tunicTorsoGeo(cw * 1.04, { hemY: -0.24, flare: 1.06, waistR: 0.92, chestPush: 0 })),
      cloth(kind === "orc" ? 0x4a3d2a : 0x5c442c), 1, 0.44, 1, 0, -0.04, 0);
    part(torso, cached(`brute_belt:${cw.toFixed(2)}`, () => torsoStrapGeo(rx * 0.96, rz * 0.98, 0.08, 0.08, 0.028, 0.095)), leather(0x3a2818));
    part(torso, cached("brute_flap", () => cloakGeo(0.22, 0.28, 0.34, 2)), cloth(tc), 1, 1, 1, 0, 0.06, rz * 1.04, 0, PI, 0);
    if (kind === "berserker") {
      part(torso, cached("b_s1", () => torsoStrapGeo(rx * 1.02, rz * 1.02, 0.16, 0.74, 0.022, 0.07)), leather(0x4a2f1c));
      part(torso, cached("b_s2", () => torsoStrapGeo(rx * 1.02, rz * 1.02, 0.74, 0.16, 0.022, 0.07)), leather(0x3a2414));
      part(torso, GEO.ring, gold(BRASS), 0.09, 0.09, 0.09, 0, 0.48, rz * 1.06, PI / 2, 0, 0);
    } else if (kind === "orc") {
      part(torso, cached("orc_s", () => torsoStrapGeo(rx * 1.04, rz * 1.04, 0.74, 0.16, 0.024, 0.085)), leather(0x3e3324));
      for (const s of [-1, 1]) {
        part(torso, GEO.sph, leather(0x3d3426), 0.22, 0.14, 0.22, s * (cw * 0.54 + 0.06), 0.78, 0, 0, 0, -s * 0.22);
        part(torso, GEO.cone, steel(0x8b939f), 0.042, 0.15, 0.042, s * (cw * 0.56 + 0.08), 0.92, 0, 0, 0, -s * 0.2);
      }
    } else if (kind === "troll") {
      // Seamless muscular trapezius & deltoid blend + mossy dorsal ridges + bone belt buckle
      for (const s of [-1, 1]) {
        part(torso, GEO.sph, M(L.skin, 0.68), 0.22, 0.16, 0.2, s * 0.2, 0.88, -0.02, 0, 0, -s * 0.25);
        part(torso, GEO.sph, M(L.skin, 0.68), 0.22, 0.16, 0.22, s * (cw * 0.5 + 0.04), 0.76, 0);
      }
      part(torso, cached("tr_harness", () => torsoStrapGeo(rx * 1.03, rz * 1.03, 0.18, 0.76, 0.026, 0.09)), leather(0x3e2d1e));
      part(torso, GEO.sph, boneMat(0xe6dec4), 0.085, 0.07, 0.045, 0, 0.08, rz * 1.06);
      for (let i = 0; i < 4; i++) part(torso, GEO.cone, M(0x486236, 0.85), 0.055, 0.16, 0.055, 0, 0.32 + i * 0.14, -rz * 1.02, -PI / 2 + 0.2, 0, 0);
    } else if (kind === "giant") {
      // Seamless muscular trapezius & deltoid blend + heavy leather/iron harness
      for (const s of [-1, 1]) {
        part(torso, GEO.sph, M(L.skin, 0.68), 0.23, 0.16, 0.2, s * 0.21, 0.88, -0.02, 0, 0, -s * 0.25);
        part(torso, GEO.sph, M(L.skin, 0.68), 0.22, 0.16, 0.22, s * (cw * 0.5 + 0.04), 0.76, 0);
      }
      part(torso, cached("gi_s1", () => torsoStrapGeo(rx * 1.03, rz * 1.03, 0.18, 0.78, 0.028, 0.095)), leather(0x3e2a19));
      part(torso, cached("gi_s2", () => torsoStrapGeo(rx * 1.03, rz * 1.03, 0.78, 0.18, 0.028, 0.095)), leather(0x3e2a19));
      part(torso, GEO.ring, steel(IRON), 0.12, 0.12, 0.12, 0, 0.52, rz * 1.06, PI / 2, 0, 0);
      part(torso, GEO.sph, gold(BRASS), 0.09, 0.08, 0.045, 0, 0.08, rz * 1.06);
    }
  } else {
    const hemY = kind === "vampire" || kind === "king" || kind === "pirate" || kind === "zeus" ? -0.28 : -0.2;
    part(torso, cached(`tunic:${cw.toFixed(2)}:${hemY}`, () => tunicTorsoGeo(cw, { hemY, flare: 1.08 })), cloth(L.armor));
    part(torso, cached(`belt:${cw.toFixed(2)}`, () => torsoStrapGeo(rx * 0.9, rz * 0.9, 0.1, 0.1, 0.022, 0.075)), leather(0x2a2016));
    part(torso, GEO.sph, gold(BRASS), 0.05, 0.055, 0.025, 0, 0.1, rz * 0.96);

    if (kind === "spear") {
      part(torso, cached(`chest_sp:${cw}`, () => cuirassGeo(cw * 0.98, 0.22)), steel(0x9aa3b2));
      part(torso, cached(`sash_sp:${cw}`, () => torsoStrapGeo(rx * 1.09, rz * 1.17, 0.72, 0.22, 0.024, 0.075)), cloth(tcd));
      for (const s of [-1, 1]) part(torso, GEO.sph, steel(0x9aa3b2), 0.18, 0.12, 0.18, s * (cw * 0.54 + 0.05), 0.78, 0, 0, 0, -s * 0.2);
    } else if (kind === "archer" || kind === "elf" || kind === "javelin") {
      part(torso, cached(`baldric:${cw}`, () => torsoStrapGeo(rx * 1.01, rz * 1.01, 0.2, 0.75, 0.022, 0.075)), cloth(tc));
      if (kind === "archer" || kind === "elf") {
        part(torso, GEO.cyl, leather(0x4a3220), 0.1, 0.58, 0.1, 0.18, 0.5, -rz - 0.06, 0.2, 0, -0.15);
        for (let i = 0; i < 4; i++) {
          part(torso, GEO.cyl, M(0xb69250), 0.016, 0.26, 0.016, 0.14 + i * 0.032, 0.86, -rz - 0.12);
          part(torso, GEO.sph, B(tcl), 0.028, 0.05, 0.015, 0.14 + i * 0.032, 0.96, -rz - 0.12);
        }
      }
    } else if (kind === "crossbow") {
      part(torso, cached(`xbow_sash:${cw}`, () => torsoStrapGeo(rx * 1.01, rz * 1.01, 0.18, 0.74, 0.022, 0.085)), cloth(0xd9cfa8));
      part(torso, GEO.cyl, leather(0x4a3926), 0.12, 0.34, 0.08, -0.1, 0.32, -rz - 0.06);
    } else if (kind === "bomber") {
      part(torso, cached(`bomb_sash:${cw}`, () => torsoStrapGeo(rx * 1.01, rz * 1.01, 0.2, 0.74, 0.024, 0.085)), cloth(tc));
      part(torso, GEO.sph, leather(0x3b2f20), 0.22, 0.24, 0.12, 0, 0.48, -rz - 0.08);
      for (const x of [-0.12, 0.12]) {
        part(torso, GEO.sph, M(0x25252a, 0.5, 0.2), 0.11, 0.11, 0.11, x, 0.74, -rz - 0.08);
        part(torso, GEO.sph, B(0xff9a3a), 0.03, 0.05, 0.03, x, 0.87, -rz - 0.08);
      }
      for (let i = 0; i < 3; i++) part(torso, GEO.sph, M(0x25252a, 0.5, 0.2), 0.075, 0.075, 0.075, -0.16 + i * 0.16, 0.06, rz + 0.04);
    } else if (kind === "assassin") {
      part(torso, cached(`ass_sash:${cw}`, () => torsoStrapGeo(rx * 1.02, rz * 1.02, 0.72, 0.2, 0.02, 0.07)), cloth(tc));
      for (let i = 0; i < 3; i++) part(torso, GEO.cone, steel(STEEL_LIGHT), 0.018, 0.12, 0.012, -0.06 + i * 0.06, 0.56 - i * 0.05, rz * 1.04, 0, 0, -0.5);
    } else if (kind === "pirate") {
      part(torso, cached(`pir_sash:${cw}`, () => torsoStrapGeo(rx * 0.94, rz * 0.94, 0.12, 0.12, 0.028, 0.13)), cloth(0x9a202c));
      part(torso, cached(`pir_b:${cw}`, () => torsoStrapGeo(rx * 1.02, rz * 1.02, 0.2, 0.74, 0.024, 0.08)), leather(0x3a2618));
      part(torso, GEO.sph, cloth(0xdfd6c2), cw * 0.16, 0.28, 0.04, 0, 0.62, rz * 0.96);
    } else if (kind === "vampire") {
      part(torso, GEO.sph, cloth(0x8a1f2a), cw * 0.16, 0.34, 0.04, 0, 0.52, rz * 0.98);
      part(torso, GEO.sph, B(0xff2a3c), 0.045, 0.06, 0.03, 0, 0.6, rz * 1.05);
      part(torso, cached("vamp_col", () =>
        latheGeo([[0.2, 0.0], [0.31, 0.26], [0.34, 0.26], [0.23, 0.0]], 22, 1, 0.85, 14),
      ), cloth(0x1e1624), 1, 1, 1, 0, 0.8, -0.06, -0.25, 0, 0);
      for (const s of [-1, 1]) part(torso, GEO.sph, cloth(0x241f2c), 0.18, 0.12, 0.18, s * (cw * 0.54 + 0.06), 0.78, 0);
    } else if (kind === "king") {
      part(torso, cached(`king_mantle:${cw}`, () =>
        latheGeo([[0.22, 0.85], [cw * 0.6, 0.68], [cw * 0.74, 0.69], [cw * 0.68, 0.83], [0.24, 0.93], [0, 0.92]], 24, 1, 0.76, 16),
      ), cloth(0xf7f4eb));
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU;
        part(torso, GEO.sph, B(0x1c1816), 0.016, 0.024, 0.012, Math.cos(a) * cw * 0.6, 0.76, Math.sin(a) * cw * 0.45);
      }
      part(torso, GEO.ring, gold(), cw * 0.38, cw * 0.3, 0.14, 0, 0.88, 0, PI / 2, 0, 0);
      part(torso, GEO.sph, B(0xff4a5a), 0.055, 0.055, 0.035, 0, 0.64, rz * 1.04);
    } else if (kind === "zeus") {
      part(torso, cached(`zeus_sash:${cw}`, () => torsoStrapGeo(rx * 1.04, rz * 1.04, 0.2, 0.75, 0.026, 0.11)), gold());
      part(torso, GEO.sph, B(0x9fe0ff), 0.065, 0.065, 0.04, 0, 0.1, rz * 1.04);
      part(torso, GEO.sph, gold(), 0.2, 0.13, 0.2, cw * 0.56 + 0.06, 0.78, 0, 0, 0, -0.2);
    } else if (kind === "snakearcher") {
      part(torso, cached(`sn_baldric:${cw}`, () => torsoStrapGeo(rx * 1.02, rz * 1.02, 0.2, 0.76, 0.024, 0.085)), leather(0x4a3524));
      for (const s of [-1, 1]) part(torso, GEO.sph, gold(BRASS), 0.18, 0.12, 0.19, s * (cw * 0.54 + 0.05), 0.78, 0, 0, 0, -s * 0.2);
      // Coiled emerald viper wrapping across the shoulder and chest
      swept(
        torso,
        [[-0.22, 0.18, -rz * 0.95], [0.22, 0.36, -rz * 0.95], [0.34, 0.62, 0.04], [0.16, 0.84, rz * 0.92], [-0.14, 0.88, rz * 0.78], [-0.24, 0.98, rz * 0.55]],
        t => 0.052 * (1 - t * 0.25),
        M(0x5fa642, 0.55),
        0.7, 20, 9,
      );
      part(torso, GEO.sph, M(0x74b84d, 0.5), 0.075, 0.055, 0.095, -0.26, 1.02, rz * 0.76);
      for (const s of [-1, 1]) part(torso, GEO.sph, B(0xffdf62), 0.018, 0.02, 0.016, -0.26 + s * 0.038, 1.04, rz * 0.76 + 0.06);
    } else if (kind === "icearcher") {
      part(torso, cached(`ice_col:${cw}`, () =>
        latheGeo([[0.22, 0.82], [cw * 0.56, 0.76], [cw * 0.62, 0.88], [0.24, 0.95], [0, 0.92]], 20, 1, 0.78, 12),
      ), cloth(0xf4f8fc));
      part(torso, cached(`ice_sash:${cw}`, () => torsoStrapGeo(rx * 1.02, rz * 1.02, 0.2, 0.75, 0.022, 0.08)), cloth(0xbfe8ff));
      part(torso, GEO.quadCone, B(0xaef2ff), 0.065, 0.14, 0.045, 0, 0.54, rz * 1.05);
      for (const s of [-1, 1]) part(torso, GEO.sph, steel(0x9fc0d8), 0.18, 0.12, 0.2, s * (cw * 0.54 + 0.05), 0.78, 0, 0, 0, -s * 0.2);
    } else if (kind === "balloonarcher") {
      part(torso, cached(`bal_sash:${cw}`, () => torsoStrapGeo(rx * 1.02, rz * 1.02, 0.2, 0.74, 0.024, 0.095)), cloth(0xf2c94c));
      // Leather backpack harness + 4 Lathe teardrop balloons on cords
      part(torso, GEO.sph, leather(0x462e20), 0.18, 0.22, 0.1, 0, 0.5, -rz - 0.06);
      part(torso, GEO.ring, gold(), 0.1, 0.1, 0.08, 0, 0.68, -rz - 0.1, PI / 2, 0, 0);
      const palette = [0xf0b84a, 0xe070a4, 0x62bdd6, 0x7fd49a];
      const anchors = [[-0.28, 1.86, -0.42], [0.28, 1.98, -0.4], [0.02, 2.2, -0.28], [-0.04, 1.64, -0.56]];
      anchors.forEach(([bx, by, bz], i) => {
        link(torso, B(0xf0e4c8), new THREE.Vector3(0, 0.68, -rz - 0.1), new THREE.Vector3(bx, by - 0.24, bz), 0.008);
        part(torso, BALLOON_GEO, M(palette[i], 0.25, 0.12), 0.78, 0.85, 0.78, bx, by, bz);
        part(torso, GEO.sph, B(0xffffff), 0.048, 0.065, 0.038, bx + 0.055, by + 0.11, bz + 0.17);
      });
    } else if (kind === "zombie") {
      part(torso, cached(`zom_tear:${cw}`, () => torsoStrapGeo(rx * 1.01, rz * 1.01, 0.7, 0.24, 0.015, 0.14)), cloth(0x3a3a2a));
      part(torso, GEO.sph, M(0x5a2a22), 0.12, 0.08, 0.04, 0.14, 0.42, rz * 0.96);
      part(torso, GEO.cyl, M(0xe0d8c0), 0.016, 0.16, 0.016, 0.14, 0.5, rz * 0.98, 0, 0, PI / 2);
    }
  }

  // Smooth neck connecting torso to head (thicker & taller on colossi so head is 100% attached!).
  const neckR = skel ? 0.052 : isColossus ? 0.165 : kind === "orc" ? 0.135 : 0.105;
  const neckH = isColossus ? 0.28 : 0.22;
  part(torso, GEO.cyl, skel ? boneMat(L.skin) : M(L.skin, 0.6), neckR, neckH, neckR, 0, 0.94, isColossus ? 0.03 : 0);

  /* ---- 3. draped flowing cloth cloak ---- */
  let cloak: THREE.Group | null = null;
  const cloakColor: Partial<Record<HumanKind, [number, number, number]>> = {
    spear: [tcd, 0.72, 1.05], guardian: [tcd, 0.8, 1.2], halberdier: [tcd, 0.72, 1.05],
    king: [0x8a1c28, 1.0, 1.38], zeus: [0xf4eee0, 0.92, 1.32], elf: [0x2f5f33, 0.68, 1.15],
    mage: [tcd, 0.7, 1.2], frost: [0x3a5f8f, 0.7, 1.2], assassin: [tc, 0.24, 1.4],
    skeleton: [tcd, 0.52, 0.85], bonearcher: [tcd, 0.52, 0.85], cleric: [0xd9cfb0, 0.64, 1.05],
    paladin: [tcd, 0.86, 1.25], vampire: [0x2a1420, 1.12, 1.5], shaman: [0x4a4230, 0.68, 1.15],
    monk: [tc, 0.58, 0.95], icearcher: [0x36597d, 0.68, 1.12], snakearcher: [0x2a452a, 0.62, 1.05],
  };
  const cc = cloakColor[kind];
  if (cc) {
    cloak = new THREE.Group();
    cloak.position.set(0, 0.84, -rz * 0.78);
    torso.add(cloak);
    const wTop = cw * cc[1] * 0.88, wBot = cw * cc[1] * 1.32, len = cc[2];
    part(cloak, cached(`cloak:${wTop.toFixed(2)}:${wBot.toFixed(2)}:${len.toFixed(2)}`, () => cloakGeo(wTop, wBot, len, 3)), cloth(cc[0]));
  }

  /* ---- 4. rounded head & bespoke headgear ---- */
  const head = new THREE.Group();
  const brute = kind === "giant" || kind === "troll" || kind === "orc";
  head.position.set(0, isColossus ? 1.12 : kind === "orc" ? 1.12 : kind === "zeus" ? 1.14 : 1.1, brute ? 0.08 : 0);
  head.scale.setScalar(L.head);
  torso.add(head);

  part(head, GEO.sph, M(L.skin, 0.6), 0.26, 0.28, 0.26);
  if (!skel) {
    part(head, GEO.sph, M(L.skin, 0.58), isColossus ? 0.2 : 0.175, 0.14, isColossus ? 0.18 : 0.165, 0, -0.115, 0.045);
    for (const s of [-1, 1]) part(head, GEO.sph, M(L.skin, 0.6), 0.046, 0.068, 0.036, s * 0.255, -0.01, 0.0);
  } else {
    // Sculpted skeletal jawbone with carved tooth definitions
    part(head, GEO.sph, boneMat(L.skin), 0.165, 0.11, 0.15, 0, -0.145, 0.05);
    part(head, cached("skel_teeth", () => upperTeethGeo(0.062, 0.022, -0.105)), boneMat(0xf5f0e2));
  }

  let headExtra = 0;
  switch (kind) {
    case "spear":
      part(head, cached("h:war", () => warHelmGeo(0.305, 0.11)), steel(0xa3acb9), 1, 1, 1, 0, 0.04, -0.01);
      part(head, cached("h:band_sp", () => ringBandGeo(0.304, 0.314, 0.1, 0.012, 0.03)), gold(BRASS));
      part(head, cached("h:crest", () => crestFinGeo(0.42, 0.16, 0.05)), cloth(tc), 1, 1, 1, 0, 0.36, -0.02);
      part(head, cached("h:nasal", () => faceStripGeo([[0, 0.14], [0, 0.04]], 0.018, 0.022)), steel(0xa3acb9));
      headExtra = 0.16;
      addFace(head, L.skin, { brow: 0.12, mouth: "flat" });
      break;

    case "guardian":
      part(head, cached("h:war_g", () => warHelmGeo(0.315, 0.13)), steel(0x959fae), 1, 1, 1, 0, 0.04, -0.01);
      part(head, cached("h:visor", () => visorFaceGeo(0.295)), steel(0x7d8694), 1, 1, 1, 0, 0.04, 0.02);
      part(head, cached("h:band_g", () => ringBandGeo(0.308, 0.32, 0.1, 0.014, 0.035)), gold(GOLD));
      part(head, cached("h:crest_g", () => crestFinGeo(0.4, 0.16, 0.055)), cloth(tc), 1, 1, 1, 0, 0.37, -0.02);
      headExtra = 0.16;
      addFace(head, L.skin, { visored: true, pupil: 0xa4ecff });
      break;

    case "swordsman":
      part(head, cached("h:war_s", () => warHelmGeo(0.305, 0.08)), steel(0xa8b1bf), 1, 1, 1, 0, 0.06, -0.01);
      part(head, cached("h:band_sw", () => ringBandGeo(0.302, 0.312, 0.11, 0.012, 0.03)), gold(BRASS));
      part(head, GEO.cone, steel(0xbec6d3), 0.04, 0.12, 0.04, 0, 0.42, -0.01);
      addFace(head, L.skin, { brow: 0.14, mouth: "smile" });
      break;

    case "halberdier":
      part(head, cached("h:war_h", () => warHelmGeo(0.305, 0.12)), steel(0x7f8896), 1, 1, 1, 0, 0.05, -0.01);
      part(head, cached("h:comb_h", () => crestFinGeo(0.38, 0.13, 0.032)), steel(0x9ea7b5), 1, 1, 1, 0, 0.35, -0.02);
      part(head, cached("h:plume_h", () => crestFinGeo(0.3, 0.14, 0.04)), cloth(tc), 1, 1, 1, 0, 0.41, -0.14, -0.3, 0, 0);
      headExtra = 0.16;
      addFace(head, L.skin, { brow: 0.16, mouth: "flat" });
      break;

    case "paladin":
      part(head, cached("h:war_p", () => warHelmGeo(0.315, 0.12)), steel(0xe2e6ee), 1, 1, 1, 0, 0.05, -0.01);
      part(head, cached("h:band_p", () => ringBandGeo(0.31, 0.322, 0.11, 0.015, 0.038)), gold(GOLD));
      part(head, cached("h:nasal_p", () => faceStripGeo([[0, 0.16], [0, 0.03]], 0.02, 0.025)), gold(GOLD));
      for (const s of [-1, 1]) {
        part(head, cached("h:wing_plume", wingPlumeGeo), gold(GOLD_LIGHT), 1, 1, 1, s * 0.28, 0.22, -0.04, -0.25, s * 0.6, s * -0.35);
      }
      headExtra = 0.22;
      addFace(head, L.skin, { brow: 0.14, mouth: "flat" });
      break;

    case "crossbow":
      part(head, cached("h:kettle", () => kettleHelmGeo(0.3, 0.43)), steel(0x828b99), 1, 1, 1, 0, 0.07, -0.01);
      part(head, cached("h:kettle_r", () => ringBandGeo(0.305, 0.315, 0.14, 0.012, 0.032)), steel(0x555c68));
      addFace(head, L.skin, { brow: 0.1, mouth: "flat" });
      break;

    case "king":
      part(head, GEO.dome, cloth(0x6d2530), 0.295, 0.26, 0.295, 0, 0.08, -0.005);
      part(head, GEO.cyl, gold(GOLD), 0.3, 0.09, 0.3, 0, 0.14, 0);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        part(head, cached("h:fleur", crownSpikeGeo), gold(GOLD), 1, 1, 1, Math.sin(a) * 0.265, 0.18, Math.cos(a) * 0.265, 0, a, 0);
      }
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * TAU + 0.5;
        part(head, GEO.sph, B(0x9c1c2c), 0.036, 0.036, 0.036, Math.sin(a) * 0.29, 0.14, Math.cos(a) * 0.29);
      }
      for (const s of [-1, 1]) {
        part(head, cached(`king_must:${s}`, () =>
          loftTube([new THREE.Vector3(0, -0.08, 0.255), new THREE.Vector3(s * 0.07, -0.09, 0.245), new THREE.Vector3(s * 0.13, -0.115, 0.2)],
            t => 0.025 * (1 - t * 0.6), 8, 8, true),
        ), M(0xf5eedb, 0.85));
      }
      part(head, cached("king_beard", () =>
        loftTube([new THREE.Vector3(0, -0.14, 0.22), new THREE.Vector3(0, -0.25, 0.17), new THREE.Vector3(0, -0.35, 0.11)],
          t => 0.12 * (1 - t * 0.78), 10, 12, true),
      ), M(0xf0e6cf, 0.85));
      addFace(head, L.skin, { brow: 0.1, mouth: "flat", sclera: 0xf8f2e4, pupil: 0x3a2a18 });
      break;

    case "archer":
      part(head, cached("h:hood_ar", () => clothHoodGeo(0.282)), cloth(0x5b462b));
      part(head, cached("h:f_ar", wingPlumeGeo), cloth(tcl), 0.65, 0.65, 0.65, 0.24, 0.2, -0.06, -0.2, 0.5, -0.4);
      addFace(head, L.skin, { mouth: "smile" });
      break;

    case "snakearcher":
      part(head, cached("h:turban", () =>
        latheGeo([[0, 0.06], [0.25, 0.06], [0.31, 0.12], [0.32, 0.24], [0.22, 0.33], [0, 0.36]], 24, 1, 1.04, 20),
      ), cloth(0x3b623b), 1, 1, 1, 0, 0.04, -0.02);
      part(head, cached("h:turban_band", () => ringBandGeo(0.308, 0.32, 0.13, 0.016, 0.042)), gold(GOLD));
      // Sculpted cobra hood crest rising from the brow
      swept(head, [[0, 0.15, 0.28], [0, 0.31, 0.3], [0, 0.36, 0.22]], t => 0.042 * (1 - 0.35 * t), M(0x6da844, 0.5), 0.4, 10, 8);
      part(head, GEO.sph, gold(GOLD), 0.095, 0.08, 0.035, 0, 0.29, 0.29, -0.15, 0, 0);
      part(head, GEO.sph, M(0x78b84c, 0.5), 0.068, 0.055, 0.09, 0, 0.33, 0.31);
      for (const s of [-1, 1]) {
        part(head, GEO.sph, B(0xffe066), 0.018, 0.02, 0.016, s * 0.036, 0.34, 0.37);
        part(head, GEO.cone, boneMat(), 0.01, 0.04, 0.01, s * 0.024, 0.29, 0.37, PI, 0, 0);
      }
      addFace(head, L.skin, { brow: 0.14, mouth: "grin" });
      break;

    case "icearcher":
      part(head, cached("h:hood_ice", () => clothHoodGeo(0.285)), cloth(0x4b79a4));
      part(head, cached("h:ice_band", () => ringBandGeo(0.288, 0.298, 0.13, 0.014, 0.034)), steel(0xcfe8f8));
      // 5-shard crystalline frost diadem
      for (const [ang, h, rad] of [[0, 0.24, 0.02], [-0.42, 0.19, 0.0], [0.42, 0.19, 0.0], [-0.84, 0.15, -0.04], [0.84, 0.15, -0.04]]) {
        part(head, GEO.quadCone, B(0xc4f4ff), 0.042, h, 0.042, Math.sin(ang) * 0.26, 0.24, Math.cos(ang) * 0.25 + rad, 0.18, 0, -ang * 0.35);
      }
      addFace(head, L.skin, { brow: -0.06, mouth: "flat", sclera: 0xeaf6ff, pupil: 0x2c79d8, browColor: 0xdceaf5 });
      break;

    case "balloonarcher":
      part(head, cached("h:bal_cap", () =>
        latheGeo([[0, 0.05], [0.24, 0.05], [0.3, 0.1], [0.31, 0.22], [0.2, 0.32], [0, 0.35]], 24, 1, 1.04, 18),
      ), cloth(0xa83242), 1, 1, 1, 0, 0.04, -0.01);
      part(head, cached("h:bal_trim", () => ringBandGeo(0.3, 0.312, 0.1, 0.014, 0.036)), cloth(0xf2c94c));
      for (const s of [-1, 1]) {
        part(head, GEO.cyl, gold(BRASS), 0.068, 0.045, 0.068, s * 0.095, 0.16, 0.265, PI / 2, 0, 0);
        part(head, GEO.cyl, B(0x9ce8ff), 0.05, 0.05, 0.05, s * 0.095, 0.16, 0.27, PI / 2, 0, 0);
      }
      part(head, cached("h:bal_plume", wingPlumeGeo), cloth(0xf0c85a), 0.78, 0.78, 0.78, 0.24, 0.24, -0.05, -0.2, 0.5, -0.4);
      headExtra = 0.85;
      addFace(head, L.skin, { brow: 0.08, mouth: "smile" });
      break;

    case "elf":
      for (const s of [-1, 1]) part(head, GEO.cone, M(L.skin, 0.6), 0.045, 0.26, 0.045, s * 0.26, 0.07, -0.02, -0.1, 0, -s * 1.15);
      part(head, GEO.dome, M(0xe8d9a0, 0.72), 0.285, 0.27, 0.29, 0, 0.05, -0.01);
      for (let i = -2; i <= 2; i++) {
        const a = i * 0.28;
        part(head, cached(`elf_h:${i}`, () =>
          loftTube([new THREE.Vector3(Math.sin(a) * 0.24, 0.1, -0.18), new THREE.Vector3(Math.sin(a) * 0.26, -0.1, -0.28), new THREE.Vector3(Math.sin(a) * 0.2, -0.32, -0.26)],
            t => 0.065 * (1 - t * 0.55), 8, 8, true),
        ), M(0xe8d9a0, 0.72));
      }
      part(head, cached("elf_circ", () => ringBandGeo(0.282, 0.29, 0.12, 0.01, 0.025)), steel(0xd6c98a));
      part(head, GEO.sph, B(0x4fc27a), 0.032, 0.04, 0.022, 0, 0.13, 0.285);
      addFace(head, L.skin, { sclera: 0xf8f6ea, pupil: 0x2a9a5a, brow: -0.08, mouth: "smile", browColor: 0x9a8350 });
      break;

    case "pirate":
      part(head, GEO.dome, cloth(0x28212c), 0.275, 0.24, 0.275, 0, 0.08, 0);
      part(head, cached("h:tricorn", tricornBrimGeo), cloth(0x28212c), 1, 1, 1, 0, 0.12, 0);
      part(head, cached("h:pir_band", () => ringBandGeo(0.282, 0.285, 0.11, 0.014, 0.042)), cloth(0x8a1f2a));
      part(head, cached("h:pir_plume", wingPlumeGeo), cloth(0xf8f4e8), 0.8, 0.8, 0.8, -0.24, 0.24, -0.08, -0.3, -0.4, 0.4);
      part(head, GEO.sph, leather(0x1c161e), 0.072, 0.072, 0.03, -0.098, 0.032, headSurfaceZ(-0.098, 0.032) + 0.008);
      part(head, cached("pir_strap", () => faceStripGeo([[-0.18, 0.06], [-0.098, 0.032], [0.16, 0.11]], 0.008, 0.012)), leather(0x1c161e));
      part(head, cached("pir_beard", () =>
        loftTube([new THREE.Vector3(0, -0.14, 0.22), new THREE.Vector3(0, -0.24, 0.18)], t => 0.1 * (1 - t * 0.5), 6, 10, true),
      ), M(0x4a3828, 0.85));
      addFace(head, L.skin, { brow: 0.2, mouth: "grin", size: 0.056 });
      break;

    case "orc":
      part(head, cached("h:orc_cap", () => warHelmGeo(0.285, 0.06)), steel(0x4a5059), 1, 0.85, 1, 0, 0.07, -0.01);
      part(head, cached("h:orc_rim", () => ringBandGeo(0.285, 0.295, 0.12, 0.012, 0.036)), steel(0x2e3238));
      part(head, GEO.cone, steel(0x7c8490), 0.04, 0.12, 0.04, 0, 0.36, 0);
      for (const s of [-1, 1]) {
        part(head, GEO.cone, M(L.skin, 0.6), 0.055, 0.25, 0.05, s * 0.28, 0.06, 0, 0, 0, -s * 1.25);
        part(head, cached(`orc_tusk:${s}`, () => curvedHornGeo(0.14, 0.032, s * 0.03, 0.12, 0.03)), boneMat(0xf0e6c0), 1, 1, 1, s * 0.09, -0.16, 0.21);
      }
      addFace(head, L.skin, { sclera: 0xffe9a0, pupil: 0xd02a1c, brow: 0.42, mouth: "grin", browColor: 0x1d1a10 });
      break;

    case "berserker":
      part(head, cached("h:ber_hawk", () => crestFinGeo(0.36, 0.18, 0.055)), cloth(tc), 1, 1, 1, 0, 0.22, -0.02);
      for (const s of [-1, 1]) {
        part(head, cached(`ber_paint:${s}`, () => faceStripGeo([[s * 0.06, -0.03], [s * 0.16, -0.02]], 0.01, 0.008)), B(0xb8322a));
      }
      part(head, cached("ber_beard", () =>
        loftTube([new THREE.Vector3(0, -0.15, 0.22), new THREE.Vector3(0, -0.26, 0.17)], t => 0.11 * (1 - t * 0.6), 6, 10, true),
      ), M(0x7a4a24, 0.85));
      headExtra = 0.12;
      addFace(head, L.skin, { brow: 0.36, mouth: "open", browColor: 0x3a2412 });
      break;

    case "javelin":
      part(head, cached("h:jav_band", () => ringBandGeo(0.268, 0.272, 0.14, 0.016, 0.055)), cloth(tc));
      part(head, cached("h:jav_tail", () =>
        loftTube([new THREE.Vector3(0.05, 0.13, -0.27), new THREE.Vector3(0.12, 0.02, -0.4), new THREE.Vector3(0.18, -0.12, -0.46)],
          t => 0.03 * (1 - t * 0.5), 8, 8, true),
      ), cloth(tc));
      addFace(head, L.skin, { brow: 0.12, mouth: "smile" });
      break;

    case "bomber":
      part(head, cached("h:bomb_cap", () => warHelmGeo(0.285, 0.05)), leather(0x4a3524), 1, 0.9, 1, 0, 0.06, -0.01);
      part(head, cached("h:bomb_strap", () => ringBandGeo(0.282, 0.292, 0.14, 0.012, 0.034)), leather(0x2a2016));
      for (const s of [-1, 1]) {
        part(head, GEO.cyl, steel(0xb9803a), 0.072, 0.05, 0.072, s * 0.095, 0.16, 0.26, PI / 2, 0, 0);
        part(head, GEO.cyl, B(0x7fe8ff), 0.052, 0.055, 0.052, s * 0.095, 0.16, 0.265, PI / 2, 0, 0);
      }
      addFace(head, L.skin, { brow: 0.2, mouth: "grin", sclera: 0xfaf3d8 });
      break;

    case "shaman":
      // Authentic horned animal skull helm perched cleanly over the brow & cranium (no clown-nose ball!)
      part(head, cached("h:sha_skull", () => warHelmGeo(0.295, 0.06)), boneMat(0xe6dfc8), 1, 0.92, 1.05, 0, 0.08, 0.0);
      part(head, cached("h:sha_trim", () => ringBandGeo(0.29, 0.31, 0.11, 0.016, 0.04)), leather(0x4a3524));
      // Carved bone nasal ridge & upper skull teeth along the brow line (above the eyes, y >= 0.12)
      part(head, cached("h:sha_ridge", () => faceStripGeo([[0, 0.24], [0, 0.11]], 0.024, 0.028)), boneMat(0xd4cbb0));
      for (let i = -2; i <= 2; i++) {
        const a = i * 0.22;
        part(head, GEO.cone, boneMat(0xf0e8d0), 0.018, 0.055, 0.018, Math.sin(a) * 0.26, 0.1, Math.cos(a) * 0.28, PI, 0, 0);
      }
      for (const s of [-1, 1]) {
        part(head, cached(`sha_horn:${s}`, () =>
          loftTube([
            new THREE.Vector3(s * 0.2, 0.19, 0.02),
            new THREE.Vector3(s * 0.36, 0.29, -0.04),
            new THREE.Vector3(s * 0.44, 0.43, -0.14),
            new THREE.Vector3(s * 0.36, 0.5, -0.24),
          ], t => 0.055 * (1 - t * 0.85), 14, 10, true),
        ), boneMat(0xd4cbb0));
        part(head, cached("h:sha_plume", wingPlumeGeo), cloth(tc), 0.65, 0.65, 0.65, s * 0.16, 0.28, -0.22, -0.35, s * 0.3, -s * 0.25);
      }
      addFace(head, L.skin, { socket: true, pupil: 0xffd06a, size: 0.058, brow: 0.15, mouth: "flat" });
      break;

    case "troll":
      part(head, cached("h:troll_crest", () => crestFinGeo(0.34, 0.15, 0.055)), cloth(0x3a5828), 1, 1, 1, 0, 0.24, -0.03);
      for (const s of [-1, 1]) {
        part(head, GEO.cone, M(L.skin, 0.6), 0.058, 0.24, 0.052, s * 0.28, 0.06, 0, 0, 0, -s * 1.2);
        part(head, cached(`tr_tusk:${s}`, () => curvedHornGeo(0.15, 0.034, s * 0.02, 0.13, 0.03)), boneMat(0xf0e6c0), 1, 1, 1, s * 0.09, -0.16, 0.21);
      }
      addFace(head, L.skin, { brow: 0.32, mouth: "open", sep: 0.1, size: 0.066, y: 0.04, sclera: 0xf6e8a8, pupil: 0x2a3a14 });
      break;

    case "giant":
      part(head, cached("h:giant_hair", () => crestFinGeo(0.34, 0.13, 0.075)), M(0x3a2a1a, 0.9), 1, 1, 1, 0, 0.24, -0.03);
      part(head, cached("h:giant_band", () => ringBandGeo(0.268, 0.276, 0.13, 0.014, 0.038)), leather(0x3a2616));
      for (const s of [-1, 1]) {
        part(head, cached(`gi_tusk:${s}`, () => curvedHornGeo(0.13, 0.03, 0, 0.11, 0.025)), boneMat(0xf0e6c0), 1, 1, 1, s * 0.085, -0.16, 0.21);
      }
      part(head, cached("gi_beard", () =>
        loftTube([new THREE.Vector3(0, -0.14, 0.22), new THREE.Vector3(0, -0.28, 0.18)], t => 0.13 * (1 - t * 0.45), 6, 10, true),
      ), M(0x5a3e28, 0.88));
      addFace(head, L.skin, { brow: 0.3, mouth: "open", sep: 0.095, size: 0.066, y: 0.048 });
      break;

    case "monk":
      part(head, cached("monk_stubble", () =>
        loftTube([new THREE.Vector3(0, -0.15, 0.21), new THREE.Vector3(0, -0.21, 0.18)], t => 0.08 * (1 - t * 0.5), 4, 8, true),
      ), M(0x5c422a, 0.85));
      for (let i = -1; i <= 1; i++) {
        part(head, GEO.sph, M(0xb88642, 0.6), 0.012, 0.012, 0.008, i * 0.04, 0.16, headSurfaceZ(i * 0.04, 0.16) + 0.004);
      }
      addFace(head, L.skin, { brow: -0.08, mouth: "smile", pupil: 0x2a1a10 });
      break;

    case "assassin":
      part(head, cached("h:hood_ass", () => clothHoodGeo(0.28)), cloth(0x23262e));
      part(head, cached("h:ass_band", () => ringBandGeo(0.278, 0.285, 0.14, 0.01, 0.032)), cloth(tc));
      part(head, cached("h:ass_mask", () =>
        latheGeo([[0.0, -0.22], [0.23, -0.2], [0.275, -0.08], [0.275, -0.005], [0, -0.005]], 20, 1, 1.03, 12),
      ), cloth(0x161820));
      addFace(head, L.skin, { size: 0.052, brow: 0.5, mouth: "none", pupil: 0x0d0a08, y: 0.042 });
      break;

    case "mage":
      part(head, cached("h:wiz_brim", () => wizardBrimGeo(0.24, 0.52)), cloth(tcd), 1, 1, 1, 0, 0.11, 0);
      part(head, cached("h:wiz_crown", wizardCrownGeo), cloth(tcd), 1, 1, 1, 0, 0.11, 0);
      part(head, cached("h:wiz_band", () => ringBandGeo(0.28, 0.28, 0.145, 0.015, 0.04)), gold(GOLD));
      part(head, cached("mage_beard", () =>
        loftTube([new THREE.Vector3(0, -0.14, 0.22), new THREE.Vector3(0, -0.28, 0.18), new THREE.Vector3(0, -0.4, 0.13)],
          t => 0.11 * (1 - t * 0.82), 10, 10, true),
      ), M(0xece7d6, 0.85));
      addFace(head, L.skin, { brow: -0.05, mouth: "smile", browColor: 0xece7d6 });
      headExtra = 0.55;
      break;

    case "frost":
      part(head, GEO.dome, M(0xdce6f2, 0.72), 0.295, 0.27, 0.295, 0, 0.06, -0.02);
      for (let i = -2; i <= 2; i++) {
        const a = i * 0.3;
        part(head, cached(`fr_h:${i}`, () =>
          loftTube([new THREE.Vector3(Math.sin(a) * 0.24, 0.08, -0.18), new THREE.Vector3(Math.sin(a) * 0.25, -0.12, -0.27)],
            t => 0.065 * (1 - t * 0.55), 8, 8, true),
        ), M(0xdce6f2, 0.72));
      }
      part(head, cached("h:frost_band", () => ringBandGeo(0.292, 0.298, 0.13, 0.014, 0.036)), steel(0xcfe4f5));
      for (let i = -2; i <= 2; i++) {
        const a = i * 0.42;
        part(head, GEO.quadCone, B(0xbfefff), 0.032, 0.18 - Math.abs(i) * 0.02, 0.032, Math.sin(a) * 0.275, 0.24, Math.cos(a) * 0.275, 0.15, 0, -a * 0.3);
      }
      addFace(head, L.skin, { sclera: 0xeaf6ff, pupil: 0x2a6ad8, brow: -0.06, mouth: "flat", browColor: 0xdceaf5 });
      headExtra = 0.3;
      break;

    case "cleric":
      part(head, cached("h:hood_cl", () => clothHoodGeo(0.282)), cloth(0xece4d0));
      part(head, cached("h:cl_band", () => ringBandGeo(0.282, 0.292, 0.13, 0.012, 0.032)), gold(GOLD));
      part(head, GEO.ring, gold(GOLD), 0.26, 0.26, 0.26, 0, 0.48, -0.02, PI / 2 - 0.15, 0, 0);
      addFace(head, L.skin, { brow: -0.18, mouth: "smile", pupil: 0x3a2a1a });
      headExtra = 0.35;
      break;

    case "zombie":
      part(head, GEO.sph, M(0x4a3325, 0.8), 0.16, 0.08, 0.09, 0.1, 0.14, 0.14);
      part(head, GEO.sph, boneMat(0xe0d8c0), 0.1, 0.06, 0.08, -0.1, 0.2, 0.1, 0, 0, 0.25);
      addFace(head, L.skin, { sclera: 0xe6e8a8, pupil: 0x2a2a14, uneven: true, look: 1.1, brow: -0.25, mouth: "open", size: 0.064, browColor: 0x3a3a20 });
      break;

    case "skeleton":
      part(head, cached("h:sk_band", () => ringBandGeo(0.262, 0.268, 0.13, 0.012, 0.032)), cloth(tc));
      addFace(head, L.skin, { socket: true, pupil: tcl, brow: 0.2, mouth: "none", size: 0.058 });
      break;

    case "bonearcher":
      part(head, cached("h:hood_ba", () => clothHoodGeo(0.282)), cloth(tcd));
      addFace(head, L.skin, { socket: true, pupil: 0x9fffa8, brow: 0.2, mouth: "none", size: 0.058 });
      break;

    case "vampire":
      for (const s of [-1, 1]) {
        part(head, GEO.cone, M(L.skin, 0.6), 0.045, 0.22, 0.045, s * 0.26, 0.08, 0, 0, 0, -s * 1.15);
        part(head, GEO.cone, B(0xf6f2e6), 0.018, 0.075, 0.018, s * 0.05, -0.14, 0.23, PI, 0, 0);
      }
      part(head, GEO.dome, M(0x141018, 0.65), 0.275, 0.25, 0.285, 0, 0.07, -0.02);
      part(head, GEO.cone, M(0x141018, 0.65), 0.06, 0.14, 0.06, 0, 0.13, 0.24, PI, 0, 0);
      addFace(head, L.skin, { sclera: 0xf2e8e0, pupil: 0x8a1420, brow: 0.2, mouth: "grin", size: 0.058 });
      break;

    case "zeus": {
      const hair = 0xf2ede0;
      part(head, GEO.dome, M(hair, 0.78), 0.295, 0.26, 0.295, 0, 0.07, -0.025);
      part(head, GEO.sph, M(hair, 0.78), 0.29, 0.21, 0.23, 0, 0.03, -0.13);
      for (let i = -2; i <= 2; i++) {
        const a = i * 0.34;
        part(head, cached(`zeus_curl:${i}`, () =>
          loftTube([new THREE.Vector3(Math.sin(a) * 0.25, 0.08, -0.18), new THREE.Vector3(Math.sin(a) * 0.27, -0.16, -0.25), new THREE.Vector3(Math.sin(a) * 0.23, -0.26, -0.18)],
            t => 0.072 * (1 - t * 0.3), 10, 8, true),
        ), M(hair, 0.78));
      }
      part(head, cached("zeus_circ", () => ringBandGeo(0.29, 0.298, 0.145, 0.012, 0.028)), gold(GOLD));
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * TAU;
        if (Math.abs(Math.sin(a)) < 0.22 && Math.cos(a) > 0) continue;
        part(head, cached("laurel_leaf", wingPlumeGeo), gold(GOLD), 0.38, 0.38, 0.38,
          Math.sin(a) * 0.28, 0.18, Math.cos(a) * 0.285, 0.25, a, -0.25);
      }
      for (const s of [-1, 1]) {
        part(head, cached(`zeus_must:${s}`, () =>
          loftTube([new THREE.Vector3(0, -0.08, 0.255), new THREE.Vector3(s * 0.09, -0.095, 0.245), new THREE.Vector3(s * 0.16, -0.13, 0.18)],
            t => 0.032 * (1 - t * 0.5), 8, 8, true),
        ), M(hair, 0.8));
      }
      part(head, cached("zeus_beard", () =>
        loftTube([new THREE.Vector3(0, -0.13, 0.22), new THREE.Vector3(0, -0.32, 0.18), new THREE.Vector3(0, -0.5, 0.1)],
          t => 0.15 * (1 - t * 0.75), 12, 12, true),
      ), M(hair, 0.8));
      addFace(head, L.skin, { sclera: 0xbfe6ff, pupil: 0x2c79d8, brow: -0.16, mouth: "smile", size: 0.066, browColor: 0xf2ede0 });
      headExtra = 0.16;
      break;
    }
  }

  /* ---- 5. smooth tapered arms & gloves ---- */
  const bareArms = kind === "berserker" || kind === "giant" || kind === "orc" || kind === "troll" || kind === "monk";
  const armL = L.arm ?? 1, armW = L.armW ?? 1;
  const mkArm = (side: number) => {
    const a = new THREE.Group();
    a.position.set(side * (cw * 0.49 + 0.07 + (L.shoulder ?? 0)), 0.74, 0);
    torso.add(a);
    const r = (skel ? 0.05 : 0.105) * armW;
    const sleeveC = bareArms ? L.skin : L.armor;
    const foreC = plated || kind === "spear" ? 0x8b93a1
      : kind === "archer" || kind === "crossbow" || kind === "javelin" || kind === "bonearcher" || kind === "snakearcher" || kind === "icearcher" || kind === "balloonarcher" ? 0x4a3826
      : bareArms ? L.skin : L.armor;
    if (skel) {
      part(a, GEO.sph, boneMat(L.skin), 0.06, 0.06, 0.06, 0, -0.02, 0);
      part(a, GEO.cyl, boneMat(L.skin), 0.036, 0.36, 0.036, 0, -0.2, 0);
      part(a, GEO.cyl, boneMat(L.skin), 0.032, 0.34, 0.032, 0, -0.52, 0);
      part(a, GEO.sph, boneMat(L.skin), 0.075, 0.075, 0.075, 0, -0.72, 0);
      return a;
    }
    part(a, armSegmentGeo(r, armL, bareArms), M(sleeveC, bareArms ? 0.65 : 0.8));
    if (!bareArms && foreC !== sleeveC) {
      part(a, GEO.cyl, armored ? steel(foreC) : leather(foreC), r * 0.85, 0.28 * armL, r * 0.88, 0, -0.56 * armL, 0);
    }
    if (robed && kind !== "monk") part(a, GEO.cone, cloth(kind === "mage" ? tc : L.armor), 0.18, 0.36, 0.18, 0, -0.48, 0, PI, 0, 0);
    if (bareArms) part(a, GEO.cyl, kind === "monk" ? gold(GOLD) : leather(0x4a3a28), r * 0.9, 0.14, r * 0.92, 0, -0.56 * armL, 0);
    part(a, GEO.sph, armored ? steel(STEEL_DARK) : M(L.skin, 0.6), 0.095 * armW, 0.095 * armW, 0.095 * armW, 0, -0.72 * armL, 0);
    return a;
  };
  const lArm = mkArm(1), rArm = mkArm(-1);
  const hand = new THREE.Group();
  hand.position.set(0, -0.72 * armL, 0.04);
  rArm.add(hand);

  /* ---- 6. weapons & curved shields ---- */
  let handMode: HandMode = "follow";
  let handRest = 0;
  const polearm = (len: number, thick: number, tipLen: number, headType?: "axe" | "spear" | "halberd") => {
    part(hand, GEO.cyl, M(0x6b4a2a, 0.7), thick, len, thick, 0, 0, len * 0.35, PI / 2, 0, 0);
    part(hand, GEO.cone, steel(STEEL_DARK), thick * 1.6, 0.18, thick * 1.6, 0, 0, -len * 0.14, -PI / 2, 0, 0);
    part(hand, GEO.cyl, steel(STEEL_LIGHT), thick * 1.45, 0.14, thick * 1.45, 0, 0, len * 0.72, PI / 2, 0, 0);
    if (headType === "axe") {
      part(hand, cached("w:axe", () => {
        const sh = new THREE.Shape();
        sh.moveTo(0, -0.06);
        sh.quadraticCurveTo(0.28, 0.12, 0.32, 0.34);
        sh.quadraticCurveTo(0.1, 0.26, 0, 0.18);
        sh.closePath();
        return extrudeShape(sh, 0.036, 0.01, 14);
      }), steel(0x9aa3b2), 1, 1, 1, 0, -0.06, len * 0.76, 0, PI / 2, 0);
      part(hand, GEO.cone, steel(STEEL_LIGHT), 0.045, 0.18, 0.045, 0, -0.08, len * 0.76, PI, 0, 0);
    } else if (headType === "halberd") {
      part(hand, GEO.cone, steel(0xc7cfdb), thick * 2.8, tipLen, thick * 2.8, 0, 0, len * 0.78, PI / 2, 0, 0);
      part(hand, cached("w:halb", () => {
        const sh = new THREE.Shape();
        sh.moveTo(0, -0.04);
        sh.quadraticCurveTo(0.24, 0.12, 0.28, 0.3);
        sh.quadraticCurveTo(0.08, 0.22, 0, 0.14);
        sh.closePath();
        return extrudeShape(sh, 0.032, 0.008, 12);
      }), steel(0x9aa3b2), 1, 1, 1, 0, -0.08, len * 0.7, 0, PI / 2, 0);
      part(hand, GEO.cone, steel(0x8b939f), 0.045, 0.22, 0.045, 0, -0.1, len * 0.68, PI, 0, 0);
    } else {
      part(hand, GEO.cone, steel(0xc7cfdb), thick * 2.8, tipLen, thick * 2.8, 0, 0, len * 0.78, PI / 2, 0, 0);
    }
  };
  const staffWithOrb = (robe: number, glow: number) => {
    part(hand, GEO.cyl, M(0x4a3520), 0.04, 1.75, 0.04, 0, 0, 0.3, PI / 2, 0, 0);
    part(hand, GEO.cone, gold(robe), 0.075, 0.22, 0.075, 0, 0, 1.04, PI / 2, 0, 0);
    part(hand, GEO.sph, B(glow), 0.15, 0.15, 0.15, 0, 0.0, 1.2);
    part(hand, GEO.sph, B(0xffffff), 0.08, 0.08, 0.08, 0, 0.0, 1.2);
    part(hand, GEO.ring, steel(robe), 0.2, 0.2, 0.2, 0, 0.0, 1.2, 0.6, 0.4, 0);
    part(hand, GEO.ring, steel(robe), 0.2, 0.2, 0.2, 0, 0.0, 1.2, 0.0, 0.9, 0.0);
  };
  const roundShield = (r: number, faceC: number, rimC: number) => {
    part(lArm, GEO.cyl, M(faceC, 0.7), r, 0.055, r, 0.12, -0.5, 0.2, PI / 2, 0, 0);
    part(lArm, GEO.ring, steel(rimC), r, r, 0.5, 0.12, -0.5, 0.228);
    part(lArm, GEO.sph, steel(STEEL_LIGHT), r * 0.28, r * 0.28, 0.07, 0.12, -0.5, 0.25);
    for (let i = 0; i < 4; i++) {
      const a = (i + 0.5) * (PI / 2);
      part(lArm, GEO.sph, gold(BRASS), 0.025, 0.025, 0.02, 0.12 + Math.cos(a) * r * 0.76, -0.5 + Math.sin(a) * r * 0.76, 0.235);
    }
  };
  const swordInHand = (len: number, guardC = GOLD) => {
    part(hand, GEO.cyl, leather(LEATHER_DARK), 0.028, 0.22, 0.028, 0, 0, -0.05, PI / 2, 0, 0);
    part(hand, GEO.sph, gold(guardC), 0.055, 0.055, 0.055, 0, 0, -0.16);
    part(hand, GEO.cyl, gold(guardC), 0.03, 0.28, 0.03, 0, 0, 0.05, 0, 0, PI / 2);
    part(hand, GEO.box, steel(0xdde3ec), 0.036, 0.1, len, 0, 0, 0.08 + len * 0.5);
    part(hand, GEO.box, steel(STEEL_DARK), 0.042, 0.028, len * 0.75, 0, 0, 0.08 + len * 0.42);
    part(hand, GEO.cone, steel(0xdde3ec), 0.052, 0.18, 0.024, 0, 0, 0.15 + len, PI / 2, 0, 0);
  };

  switch (kind) {
    case "spear":
      roundShield(0.38, 0x7a5532, tc);
      polearm(2.7, 0.035, 0.46);
      part(hand, GEO.sph, cloth(tc), 0.018, 0.09, 0.2, 0, 0.06, 2.0);
      handMode = "fixed"; handRest = 0.1;
      break;
    case "guardian":
      part(lArm, cached("w:heater", () => heaterShieldGeo(0.64, 0.92)), steel(0xa0a9b8), 1, 1, 1, 0.1, -0.44, 0.28);
      part(lArm, cached("w:heater_in", () => heaterShieldGeo(0.46, 0.7)), cloth(tc), 1, 1, 1, 0.1, -0.44, 0.305);
      part(lArm, GEO.box, gold(GOLD), 0.05, 0.48, 0.03, 0.1, -0.42, 0.32);
      part(lArm, GEO.box, gold(GOLD), 0.28, 0.05, 0.03, 0.1, -0.34, 0.32);
      swordInHand(0.86);
      handRest = -0.9;
      break;
    case "archer": case "elf": case "bonearcher": {
      const big = kind === "elf" ? 1.18 : 1;
      const limbC = kind === "bonearcher" ? 0xcabc96 : kind === "elf" ? 0xc8a060 : 0x7a5228;
      swept(
        hand,
        [[0, -0.68 * big, -0.32 * big], [0, -0.44 * big, -0.02], [0, 0, 0.1], [0, 0.44 * big, -0.02], [0, 0.68 * big, -0.32 * big]],
        t => (0.046 - Math.abs(t - 0.5) * 0.024) * big,
        M(limbC, 0.65),
        0.8, 18, 8,
      );
      part(hand, GEO.cyl, B(0xe6dcb0), 0.009, 1.32 * big, 0.009, 0, 0, -0.31 * big);
      part(hand, GEO.cyl, M(skel ? 0xd8d0b4 : 0xb69250), 0.02, 1.05, 0.02, 0, 0, 0.18, PI / 2, 0, 0);
      part(hand, GEO.cone, steel(), 0.045, 0.14, 0.045, 0, 0, 0.74, PI / 2, 0, 0);
      part(hand, GEO.box, B(tcl), 0.05, 0.014, 0.14, 0, 0, -0.26);
      part(hand, GEO.box, B(tcl), 0.014, 0.05, 0.14, 0, 0, -0.26);
      if (kind === "elf") for (const s of [-1, 1]) part(hand, GEO.sph, B(0x4fc27a), 0.045, 0.1, 0.035, 0, s * 0.68 * big, -0.32 * big);
      handMode = "fixed"; handRest = 0;
      break;
    }
    case "snakearcher": {
      swept(
        hand,
        [[0, -0.76, -0.36], [0, -0.52, -0.05], [0, -0.24, 0.13], [0, 0, 0.11], [0, 0.24, 0.13], [0, 0.52, -0.05], [0, 0.76, -0.36]],
        t => 0.054 - Math.abs(t - 0.5) * 0.03,
        M(0x5a4224),
        0.8, 20, 8,
      );
      for (const s of [-1, 1]) {
        part(hand, GEO.sph, M(0x6da842), 0.06, 0.075, 0.1, 0, s * 0.76, -0.34, s * 0.4, 0, 0);
        part(hand, GEO.sph, B(0xffe066), 0.018, 0.018, 0.018, 0.045, s * 0.77, -0.31);
      }
      part(hand, GEO.cyl, B(0xf5edd1), 0.01, 1.48, 0.01, 0, 0, -0.35);
      part(hand, GEO.cyl, M(0xb89658), 0.02, 1.14, 0.02, 0, 0, 0.24, PI / 2, 0, 0);
      part(hand, GEO.cone, B(0x78e850), 0.048, 0.18, 0.048, 0, 0, 0.86, PI / 2, 0, 0);
      part(hand, GEO.box, B(0x8ad65e), 0.05, 0.014, 0.14, 0, 0, -0.26);
      handMode = "fixed"; handRest = 0;
      break;
    }
    case "icearcher": {
      swept(
        hand,
        [[0, -0.78, -0.36], [0, -0.5, -0.04], [0, -0.22, 0.13], [0, 0, 0.11], [0, 0.22, 0.13], [0, 0.5, -0.04], [0, 0.78, -0.36]],
        t => 0.054 - Math.abs(t - 0.5) * 0.026,
        M(0x74cbe8, 0.22, 0.35),
        0.8, 20, 6,
      );
      for (const s of [-1, 1]) part(hand, GEO.quadCone, B(0xcff7ff), 0.05, 0.18, 0.05, 0, s * 0.72, -0.26, -s * 0.8, 0, 0);
      part(hand, GEO.cyl, B(0xe8faff), 0.01, 1.5, 0.01, 0, 0, -0.35);
      part(hand, GEO.cyl, M(0x9ad8f0), 0.02, 1.14, 0.02, 0, 0, 0.24, PI / 2, 0, 0);
      part(hand, GEO.quadCone, B(0xbbf2ff), 0.06, 0.22, 0.06, 0, 0, 0.88, PI / 2, 0, 0);
      handMode = "fixed"; handRest = 0;
      break;
    }
    case "balloonarcher": {
      swept(
        hand,
        [[0, -0.72, -0.34], [0, -0.46, -0.02], [0, 0, 0.11], [0, 0.46, -0.02], [0, 0.72, -0.34]],
        t => 0.048 - Math.abs(t - 0.5) * 0.022,
        gold(),
        0.8, 18, 8,
      );
      part(hand, GEO.cyl, B(0xf5edd1), 0.01, 1.4, 0.01, 0, 0, -0.33);
      part(hand, GEO.cyl, M(0xb89658), 0.02, 1.12, 0.02, 0, 0, 0.24, PI / 2, 0, 0);
      part(hand, BALLOON_GEO, M(0xf078b4, 0.28, 0.1), 0.3, 0.34, 0.3, 0, 0, 0.88, PI / 2, 0, 0);
      handMode = "fixed"; handRest = 0;
      break;
    }
    case "crossbow":
      part(hand, GEO.box, M(0x6b4a2a), 0.08, 0.09, 0.84, 0, 0, 0.18);
      swept(hand, [[-0.48, 0, 0.44], [-0.24, 0, 0.58], [0, 0, 0.6], [0.24, 0, 0.58], [0.48, 0, 0.44]], () => 0.036, steel(0x5a606c), 1, 14, 6);
      part(hand, GEO.cyl, B(0xe6dcb0), 0.009, 0.94, 0.009, 0, 0, 0.44, 0, 0, PI / 2);
      part(hand, GEO.ring, steel(IRON), 0.09, 0.09, 0.09, 0, 0, 0.68, PI / 2, 0, 0);
      part(hand, GEO.cyl, steel(), 0.018, 0.5, 0.018, 0, 0.06, 0.38, PI / 2, 0, 0);
      part(hand, GEO.cone, steel(), 0.038, 0.11, 0.038, 0, 0.06, 0.66, PI / 2, 0, 0);
      handMode = "fixed"; handRest = 0;
      break;
    case "swordsman":
      swordInHand(0.92);
      roundShield(0.24, 0x7a5532, tc);
      handRest = -0.6;
      break;
    case "halberdier":
      polearm(3.3, 0.04, 0.5, "halberd");
      roundShield(0.32, 0x7a5532, tc);
      handMode = "fixed"; handRest = 0.1;
      break;
    case "paladin":
      swordInHand(1.04);
      part(lArm, cached("w:heater_p", () => heaterShieldGeo(0.48, 0.74)), steel(0xd8dbe2), 1, 1, 1, 0.1, -0.42, 0.24);
      part(lArm, cached("w:heater_pi", () => heaterShieldGeo(0.34, 0.54)), cloth(tc), 1, 1, 1, 0.1, -0.42, 0.265);
      part(lArm, GEO.box, gold(GOLD), 0.04, 0.36, 0.03, 0.1, -0.4, 0.28);
      part(lArm, GEO.box, gold(GOLD), 0.22, 0.04, 0.03, 0.1, -0.34, 0.28);
      handRest = -0.7;
      break;
    case "orc":
      roundShield(0.38, 0x6a4a2a, 0x8b939f);
      polearm(1.15, 0.05, 0.2, "axe");
      handRest = -1.1;
      break;
    case "berserker":
      polearm(0.95, 0.045, 0.2, "axe");
      part(lArm, GEO.cyl, M(0x5d4226), 0.042, 0.85, 0.042, 0, -0.72, 0.28, PI / 2 - 0.5, 0, 0);
      part(lArm, cached("w:b_axe", () => {
        const sh = new THREE.Shape();
        sh.moveTo(0, -0.04); sh.quadraticCurveTo(0.24, 0.12, 0.28, 0.3); sh.quadraticCurveTo(0.08, 0.22, 0, 0.14); sh.closePath();
        return extrudeShape(sh, 0.032, 0.008, 10);
      }), steel(0x9aa3b2), 1, 1, 1, 0, -0.5, 0.62, -0.5, PI / 2, 0);
      handRest = -1.0;
      break;
    case "javelin":
      part(hand, GEO.cyl, M(0x9a7a4a), 0.032, 1.7, 0.032, 0.1, 0, 0.3, PI / 2, 0, 0);
      part(hand, GEO.cone, steel(0xc7cfdb), 0.07, 0.34, 0.07, 0.1, 0, 1.2, PI / 2, 0, 0);
      part(lArm, GEO.cyl, M(0x9a7a4a), 0.028, 1.5, 0.028, -0.14, -0.2, 0.2, PI / 2, 0, 0);
      part(lArm, GEO.cone, steel(0xc7cfdb), 0.065, 0.3, 0.065, -0.14, -0.2, 0.98, PI / 2, 0, 0);
      handMode = "fixed"; handRest = -0.2;
      break;
    case "bomber":
      part(hand, GEO.sph, M(0x25252a, 0.5, 0.2), 0.21, 0.21, 0.21, 0, 0.12, 0.18);
      part(hand, GEO.cyl, steel(IRON), 0.065, 0.05, 0.065, 0, 0.31, 0.18);
      part(hand, GEO.cyl, M(0xa58a5a), 0.02, 0.14, 0.02, 0, 0.38, 0.18);
      part(hand, GEO.sph, B(0xffb050), 0.065, 0.065, 0.065, 0, 0.46, 0.18);
      part(hand, GEO.sph, B(0xfff4b0), 0.035, 0.035, 0.035, 0, 0.48, 0.18);
      handRest = 0;
      break;
    case "shaman":
      part(hand, GEO.cyl, M(0x4a3520), 0.04, 1.65, 0.04, 0, 0, 0.28, PI / 2, 0, 0);
      part(hand, GEO.sph, boneMat(0xe8e0c8), 0.14, 0.14, 0.15, 0, 0, 1.12);
      for (const s of [-1, 1]) {
        part(hand, GEO.sph, B(0x1a140c), 0.038, 0.038, 0.03, s * 0.055, 0.04, 1.24);
        part(hand, cached(`sha_st_horn:${s}`, () => curvedHornGeo(0.16, 0.028, s * 0.08, 0.06, -0.04)), boneMat(0xd4cbb0), 1, 1, 1, s * 0.1, 0.02, 1.12);
      }
      part(hand, GEO.quadCone, B(0x8fe06a), 0.055, 0.16, 0.055, 0, 0, 1.3, PI / 2, 0, 0);
      handMode = "fixed"; handRest = -1.4;
      break;
    case "troll": case "giant": {
      const s = kind === "giant" ? 1.12 : 1.0;
      // Tapered gnarled war-club with iron bands and spikes
      part(hand, cached(`club:${s}`, () =>
        latheGeo([[0, -0.2], [0.065 * s, -0.2], [0.08 * s, 0.6 * s], [0.18 * s, 1.5 * s], [0.24 * s, 2.05 * s], [0.18 * s, 2.3 * s], [0, 2.35 * s]], 16, 1, 1, 14),
      ), M(0x5c3e22, 0.88), 1, 1, 1, 0, 0, 0, PI / 2, 0, 0);
      for (const z of [1.45 * s, 2.0 * s]) {
        part(hand, GEO.cyl, steel(IRON), 0.22 * s, 0.09, 0.22 * s, 0, 0, z, PI / 2, 0, 0);
      }
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        part(hand, GEO.cone, steel(0x8b93a0), 0.055 * s, 0.18 * s, 0.055 * s,
          Math.cos(a) * 0.24 * s, Math.sin(a) * 0.24 * s, 1.95 * s, Math.sin(a) * (PI / 2), 0, -Math.cos(a) * (PI / 2));
      }
      handRest = -1.1;
      break;
    }
    case "monk":
      for (const arm of [lArm, rArm]) {
        part(arm, GEO.ring, gold(GOLD), 0.125, 0.125, 0.125, 0, -0.64, 0.01, PI / 2, 0, 0);
        part(arm, GEO.sph, B(0xffe88a), 0.06, 0.06, 0.06, 0, -0.74, 0.05);
      }
      handRest = -0.35;
      break;
    case "assassin":
      swordInHand(0.56, IRON);
      part(lArm, GEO.box, steel(0xd9dfe8), 0.032, 0.08, 0.48, 0, -0.62, 0.32, -0.9, 0, 0);
      part(lArm, GEO.cone, steel(0xd9dfe8), 0.045, 0.12, 0.025, 0, -0.44, 0.5, -0.9 + PI / 2, 0, 0);
      handRest = -0.9;
      break;
    case "mage": staffWithOrb(GOLD, team === 0 ? 0xd9a8ff : 0xffc0a0); handMode = "fixed"; handRest = -1.45; break;
    case "frost":
      staffWithOrb(0x8fc0f0, 0x9fe0ff);
      for (let i = 0; i < 4; i++) {
        const a = (i * PI) / 2;
        part(hand, GEO.quadCone, B(0xd8f4ff), 0.035, 0.2, 0.035, Math.cos(a) * 0.16, Math.sin(a) * 0.16, 1.24, PI / 2, 0, 0);
      }
      handMode = "fixed"; handRest = -1.45;
      break;
    case "cleric":
      part(hand, GEO.cyl, M(0xe0d8c0), 0.04, 1.65, 0.04, 0, 0, 0.3, PI / 2, 0, 0);
      part(hand, GEO.ring, gold(GOLD), 0.2, 0.2, 0.2, 0, 0, 1.18, 0, PI / 2, 0);
      part(hand, GEO.sph, B(0xfff2b0), 0.1, 0.1, 0.1, 0, 0, 1.18);
      part(hand, GEO.box, gold(GOLD), 0.04, 0.28, 0.04, 0, 0, 1.18);
      part(hand, GEO.box, gold(GOLD), 0.04, 0.04, 0.22, 0, 0, 1.18);
      handMode = "fixed"; handRest = -1.45;
      break;
    case "king":
      swordInHand(1.28);
      part(lArm, GEO.cyl, gold(GOLD), 0.038, 1.45, 0.038, 0.08, -0.52, 0.22, PI / 2 - 0.4, 0, 0);
      part(lArm, GEO.sph, gold(GOLD), 0.095, 0.095, 0.095, 0.08, -0.25, 0.82);
      part(lArm, GEO.sph, B(0xff3b4e), 0.055, 0.055, 0.055, 0.08, -0.22, 0.89);
      part(lArm, GEO.box, gold(GOLD_LIGHT), 0.025, 0.11, 0.025, 0.08, -0.14, 0.86);
      part(lArm, GEO.box, gold(GOLD_LIGHT), 0.08, 0.025, 0.025, 0.08, -0.13, 0.86);
      handMode = "fixed"; handRest = -0.2;
      break;
    case "pirate":
      // Flintlock pistol in right hand + boarding cutlass with brass knuckle guard in left hand
      part(hand, GEO.box, M(0x4a321e, 0.75), 0.06, 0.11, 0.36, 0, -0.02, 0.34, 0.15, 0, 0);
      part(hand, GEO.cyl, steel(0x8a8f98), 0.036, 0.48, 0.036, 0, 0.02, 0.68, PI / 2, 0, 0);
      part(hand, GEO.cone, gold(BRASS), 0.055, 0.1, 0.055, 0, 0.02, 0.94, -PI / 2, 0, 0);
      part(hand, GEO.ring, gold(BRASS), 0.044, 0.044, 0.06, 0, 0.02, 0.56);
      part(lArm, GEO.ring, gold(BRASS), 0.09, 0.09, 0.1, 0, -0.7, 0.16, 0, PI / 2, 0);
      part(lArm, cached("w:cutlass", () => {
        const sh = new THREE.Shape();
        sh.moveTo(0, -0.04); sh.quadraticCurveTo(0.4, -0.05, 0.68, 0.06); sh.quadraticCurveTo(0.38, 0.03, 0, 0.04); sh.closePath();
        return extrudeShape(sh, 0.026, 0.005, 12);
      }), steel(STEEL_LIGHT), 1, 1, 1, 0, -0.68, 0.22, -0.35, -PI / 2, 0);
      handMode = "fixed"; handRest = -0.15;
      break;
    case "zeus":
      // Sculpted golden winged thunderbolt (zigzag lightning spear, zero floating boxes!)
      swept(
        hand,
        [[0, 0, -0.45], [0, 0.05, 0.05], [0, -0.06, 0.55], [0, 0.07, 1.05], [0, -0.05, 1.55], [0, 0, 2.15]],
        t => 0.068 * (1 - Math.abs(t - 0.5) * 0.45),
        gold(GOLD_LIGHT),
        0.5, 22, 8,
      );
      swept(
        hand,
        [[0, 0, -0.35], [0, 0.06, 0.1], [0, -0.07, 0.55], [0, 0.08, 1.05], [0, -0.06, 1.55], [0, 0, 2.28]],
        t => 0.036 * (1 - Math.abs(t - 0.5) * 0.5),
        B(0xbfe8ff),
        0.4, 22, 6,
      );
      part(hand, GEO.sph, B(0xe8f6ff), 0.14, 0.14, 0.18, 0, 0, 0.65);
      for (const s of [-1, 1]) {
        part(hand, cached("zeus_wing", wingPlumeGeo), gold(GOLD), 0.9, 0.9, 0.9, s * 0.14, 0, 0.65, 0, s * 0.5, -s * 0.4);
        part(hand, GEO.cone, B(0x9fd8ff), 0.045, 0.38, 0.045, s * 0.09, 0, 1.85, PI / 2, s * 0.18, 0);
      }
      part(hand, GEO.cone, gold(GOLD_LIGHT), 0.065, 0.42, 0.065, 0, 0, 2.25, PI / 2, 0, 0);
      handMode = "fixed"; handRest = -1.25;
      break;
    case "skeleton":
      swordInHand(0.86, 0x5a4630);
      roundShield(0.3, 0x7a5532, 0x8c8f8a);
      handRest = -1.0;
      break;
    case "vampire":
      swordInHand(1.02);
      part(hand, GEO.ring, gold(GOLD), 0.095, 0.095, 0.08, 0, 0, 0.04, 0, PI / 2, 0);
      part(hand, GEO.box, B(0x9a1420), 0.042, 0.02, 0.78, 0, 0, 0.52);
      handRest = -0.6;
      break;
    case "zombie":
      break;
  }

  const headH = (hipY + 1.45 + 0.28 * L.head + headExtra) * L.scale;
  return {
    root, body, torso, head, hand, lLeg, rLeg, lArm, rArm, cloak, headH,
    heavy: kind === "giant" || kind === "troll",
    scale: L.scale, tilt: L.tilt, kind, handMode, handRest, parts: [], fx: {},
  };
}

/* ============ machines: contoured sci-fi armor & articulated mecha rigs ============ */

function chamferPanel(w: number, h: number, d: number, bevel = 0.04): THREE.BufferGeometry {
  const s = new THREE.Shape();
  s.moveTo(-w / 2, -h / 2);
  s.lineTo(w / 2, -h / 2);
  s.lineTo(w / 2, h / 2);
  s.lineTo(-w / 2, h / 2);
  s.closePath();
  return extrudeShape(s, d, bevel, 4);
}

function buildRobot(team: TeamId): UnitRig {
  const tc = TEAM_COLORS[team], tcd = dark(tc);
  const shell = 0xa2aebc, shellDark = 0x4f5a68, trim = 0x262f3b;
  const glow = team === 0 ? 0x7fe8ff : 0xffaa70;
  const root = new THREE.Group();
  root.rotation.order = "YXZ";
  const body = new THREE.Group();
  root.add(body);

  // Sculpted pelvic chassis block
  part(body, cached("rob:pelvis", () => chamferPanel(0.56, 0.22, 0.42, 0.04)), steel(trim), 1, 1, 1, 0, 0.98, 0);

  const lLeg = new THREE.Group(); lLeg.position.set(0.27, 0.96, 0); body.add(lLeg);
  const rLeg = new THREE.Group(); rLeg.position.set(-0.27, 0.96, 0); body.add(rLeg);
  for (const g of [lLeg, rLeg]) {
    part(g, GEO.sph, steel(STEEL_LIGHT), 0.12, 0.12, 0.12, 0, -0.02, 0);
    part(g, legTubeGeo(0.15, 0.95), steel(shellDark));
    part(g, cached("rob:greave", () =>
      latheGeo([[0, -0.84], [0.14, -0.84], [0.16, -0.58], [0.15, -0.4], [0, -0.4]], 16, 1, 1.12, 12),
    ), steel(shell));
    part(g, GEO.cyl, steel(STEEL_LIGHT), 0.13, 0.28, 0.13, 0, -0.42, 0.02, 0, 0, PI / 2);
    part(g, GEO.sph, B(glow), 0.055, 0.055, 0.045, 0, -0.42, 0.16);
    part(g, GEO.cyl, gold(COPPER), 0.038, 0.38, 0.038, 0, -0.62, -0.14, -0.1, 0, 0);
    part(g, cached("rob:foot", () => bootGeo(0.16, 0.3)), steel(trim), 1, 1, 1, 0, -0.92, -0.02);
  }

  const torso = new THREE.Group();
  torso.position.set(0, 1.02, 0);
  body.add(torso);
  part(torso, cached("rob:cuirass", () => cuirassGeo(0.88, 0.15)), steel(shell));
  part(torso, cached("rob:belt", () => torsoStrapGeo(0.45, 0.33, 0.12, 0.12, 0.026, 0.085)), steel(trim));
  for (const s of [-1, 1]) {
    part(torso, cached("rob:vent", () => chamferPanel(0.16, 0.08, 0.06, 0.015)), steel(tcd), 1, 1, 1, s * 0.22, 0.62, 0.4, 0, s * 0.25, -s * 0.15);
  }
  // Glowing turbine arc-reactor on chest (outside cuirass surface at z=0.43)
  part(torso, GEO.ring, steel(STEEL_LIGHT), 0.15, 0.15, 0.16, 0, 0.56, 0.43);
  part(torso, GEO.sph, B(glow), 0.105, 0.105, 0.055, 0, 0.56, 0.44);
  part(torso, GEO.sph, B(0xffffff), 0.052, 0.052, 0.035, 0, 0.56, 0.465);
  for (const s of [-1, 1]) {
    part(torso, GEO.sph, steel(shell), 0.24, 0.16, 0.25, s * 0.54, 0.78, 0, 0, 0, -s * 0.22);
    part(torso, GEO.ring, steel(tcd), 0.2, 0.2, 0.2, s * 0.52, 0.74, 0, PI / 2, 0, 0);
    // Dorsal jump-jet thrusters
    part(torso, GEO.cyl, steel(shellDark), 0.11, 0.38, 0.11, s * 0.2, 0.52, -0.32, 0.18, 0, 0);
    part(torso, GEO.cone, steel(trim), 0.12, 0.2, 0.12, s * 0.2, 0.3, -0.38, 0.25, 0, 0);
    part(torso, GEO.sph, B(0xff8e48), 0.075, 0.075, 0.05, s * 0.2, 0.22, -0.4);
  }

  const head = new THREE.Group();
  head.position.set(0, 1.08, 0.02);
  torso.add(head);
  part(head, GEO.sph, steel(shellDark), 0.25, 0.26, 0.25);
  part(head, cached("rob:helm", () => warHelmGeo(0.295, 0.1)), steel(shell), 1, 1, 1, 0, 0.04, -0.01);
  part(head, cached("rob:visor_f", () => visorFaceGeo(0.285)), steel(trim), 1, 1, 1, 0, 0.03, 0.02);
  part(head, cached("rob:crest", () => crestFinGeo(0.36, 0.12, 0.04)), steel(tcd), 1, 1, 1, 0, 0.32, -0.02);
  for (const s of [-1, 1]) {
    part(head, GEO.sph, B(glow), 0.068, 0.048, 0.04, s * 0.095, 0.04, 0.265);
    part(head, GEO.sph, B(0xffffff), 0.025, 0.02, 0.02, s * 0.095, 0.045, 0.285);
    part(head, GEO.cyl, steel(STEEL_LIGHT), 0.022, 0.28, 0.022, s * 0.27, 0.2, -0.04, -0.2, 0, -s * 0.15);
    part(head, GEO.sph, B(glow), 0.038, 0.038, 0.038, s * 0.29, 0.34, -0.07);
  }

  const lArm = new THREE.Group(); lArm.position.set(0.56, 0.76, 0); torso.add(lArm);
  const rArm = new THREE.Group(); rArm.position.set(-0.56, 0.76, 0); torso.add(rArm);
  for (const g of [lArm, rArm]) {
    part(g, armSegmentGeo(0.12, 1.0, false), steel(shellDark));
    part(g, GEO.cyl, steel(shell), 0.11, 0.3, 0.11, 0, -0.54, 0);
    part(g, GEO.cyl, steel(STEEL_LIGHT), 0.11, 0.22, 0.11, 0, -0.38, 0, 0, 0, PI / 2);
    part(g, GEO.sph, steel(trim), 0.1, 0.1, 0.1, 0, -0.72, 0);
  }
  // Left forearm tactical energy shield
  part(lArm, cached("rob:shield", () => heaterShieldGeo(0.44, 0.68)), steel(shellDark), 1, 1, 1, 0.12, -0.48, 0.2);
  part(lArm, cached("rob:shield_in", () => heaterShieldGeo(0.3, 0.48)), B(glow), 1, 1, 1, 0.12, -0.48, 0.225);

  const hand = new THREE.Group();
  hand.position.set(0, -0.72, 0.04);
  rArm.add(hand);
  part(hand, GEO.cyl, steel(trim), 0.034, 0.26, 0.034, 0, 0, -0.04, PI / 2, 0, 0);
  part(hand, cached("rob:blade", () => chamferPanel(0.05, 0.12, 0.92, 0.015)), steel(STEEL_LIGHT), 1, 1, 1, 0, 0, 0.56);
  part(hand, GEO.cone, steel(STEEL_LIGHT), 0.065, 0.22, 0.04, 0, 0, 1.1, PI / 2, 0, 0);
  part(hand, GEO.box, B(glow), 0.058, 0.032, 0.9, 0, -0.055, 0.56);

  const cloak = new THREE.Group();
  cloak.position.set(0, 0.8, -0.32);
  torso.add(cloak);
  part(cloak, cached("rob:cloak", () => cloakGeo(0.45, 0.62, 0.65, 2)), cloth(tcd));

  return {
    root, body, torso, head, hand, lLeg, rLeg, lArm, rArm, cloak,
    headH: 2.95, heavy: false, scale: 1, tilt: 0.02, kind: "robot",
    handMode: "follow", handRest: 0, parts: [], fx: {},
  };
}

function buildTank(team: TeamId): UnitRig {
  const tc = TEAM_COLORS[team], tcd = dark(tc);
  const hull = 0x5c6b4c, hullDark = 0x3e4833, steelC = 0x5a6472;
  const glow = team === 0 ? 0x8ff4ff : 0xffb488;
  const root = new THREE.Group();
  root.rotation.order = "YXZ";
  const body = new THREE.Group();
  root.add(body);

  // Trapezoidal tank track assemblies with angled front/rear horns, ERA side skirts, & 6 roadwheels
  const trackProfile = cached("tk:track_prof", () => {
    const sh = new THREE.Shape();
    sh.moveTo(-1.05, -0.34);
    sh.lineTo(0.95, -0.34);
    sh.lineTo(1.22, 0.04);
    sh.lineTo(1.05, 0.22);
    sh.lineTo(-1.08, 0.22);
    sh.lineTo(-1.24, -0.02);
    sh.closePath();
    const g = extrudeShape(sh, 0.34, 0.03, 6);
    g.rotateY(PI / 2);
    return prepGeo(g);
  });

  const lLeg = new THREE.Group(); lLeg.position.set(0.68, 0.46, 0); body.add(lLeg);
  const rLeg = new THREE.Group(); rLeg.position.set(-0.68, 0.46, 0); body.add(rLeg);
  for (const g of [lLeg, rLeg]) {
    part(g, trackProfile, M(0x23272e, 0.85, 0.2));
    part(g, cached("tk:skirt", () => chamferPanel(0.38, 0.2, 2.36, 0.03)), M(hullDark, 0.65, 0.35), 1, 1, 1, 0, 0.16, 0);
    for (let i = 0; i < 5; i++) {
      part(g, cached("tk:era", () => chamferPanel(0.41, 0.15, 0.38, 0.02)), M(hull, 0.65, 0.35), 1, 1, 1, 0, 0.16, -0.84 + i * 0.42);
    }
    for (let i = 0; i < 6; i++) {
      const wz = -0.88 + i * 0.35;
      const isEnd = i === 0 || i === 5;
      const r = isEnd ? 0.22 : 0.2, wy = isEnd ? -0.04 : -0.18;
      part(g, GEO.cyl, steel(0x3a4049), r, 0.38, r, 0, wy, wz, 0, 0, PI / 2);
      part(g, GEO.cyl, steel(STEEL_LIGHT), r * 0.44, 0.4, r * 0.44, 0, wy, wz, 0, 0, PI / 2);
    }
  }

  const torso = new THREE.Group();
  torso.position.set(0, 0.72, 0);
  body.add(torso);
  // Sloped composite tank hull (extruded side profile with sharp sloped glacis)
  const hullGeo = cached("tk:hull_prof", () => {
    const sh = new THREE.Shape();
    sh.moveTo(-1.25, -0.12);
    sh.lineTo(1.1, -0.12);
    sh.lineTo(1.52, 0.14);
    sh.lineTo(0.95, 0.36);
    sh.lineTo(-1.18, 0.36);
    sh.lineTo(-1.32, 0.12);
    sh.closePath();
    const g = extrudeShape(sh, 1.38, 0.05, 6);
    g.rotateY(PI / 2);
    return prepGeo(g);
  });
  part(torso, hullGeo, M(hull, 0.65, 0.35));
  part(torso, cached("tk:stripe", () => chamferPanel(0.56, 0.06, 1.5, 0.015)), M(tcd, 0.6, 0.35), 1, 1, 1, 0, 0.37, -0.1);
  for (const s of [-1, 1]) {
    part(torso, GEO.cyl, steel(0x3a404a), 0.075, 0.12, 0.075, s * 0.46, 0.28, 1.36, PI / 2, 0, 0);
    part(torso, GEO.sph, B(glow), 0.055, 0.055, 0.035, s * 0.46, 0.28, 1.42);
    part(torso, GEO.cyl, steel(0x3a404a), 0.09, 0.44, 0.09, s * 0.42, 0.26, -1.28, 0, 0, PI / 2);
    part(torso, GEO.sph, B(0xff7a38), 0.05, 0.05, 0.035, s * 0.56, 0.26, -1.28);
  }

  // Contoured cast turret + angled gun mantlet + 120mm rifled cannon with bore evacuator & muzzle brake
  part(torso, cached("tk:turret_ dome", () =>
    latheGeo([[0, 0.34], [0.62, 0.34], [0.66, 0.48], [0.54, 0.72], [0.36, 0.76], [0, 0.76]], 20, 0.88, 1.18, 14),
  ), steel(steelC), 1, 1, 1, 0, 0, -0.08);
  part(torso, cached("tk:bustle", () => chamferPanel(0.82, 0.26, 0.42, 0.04)), steel(hullDark), 1, 1, 1, 0, 0.58, -0.78);
  part(torso, cached("tk:mantlet", () => chamferPanel(0.46, 0.28, 0.34, 0.04)), steel(STEEL_DARK), 1, 1, 1, 0, 0.56, 0.54);
  for (const s of [-1, 1]) {
    part(torso, GEO.cyl, steel(STEEL_DARK), 0.042, 0.22, 0.042, s * 0.52, 0.58, 0.2, 0.5, 0, -s * 0.38);
  }
  part(torso, GEO.cyl, steel(steelC), 0.08, 2.15, 0.08, 0, 0.58, 1.32, PI / 2, 0, 0);
  part(torso, GEO.cyl, steel(STEEL_LIGHT), 0.12, 0.38, 0.12, 0, 0.58, 1.52, PI / 2, 0, 0);
  part(torso, cached("tk:brake", () => chamferPanel(0.22, 0.18, 0.24, 0.03)), steel(STEEL_DARK), 1, 1, 1, 0, 0.58, 2.34);

  // Commander cupola + tank commander head with steel helmet & glowing tactical goggles (+Z > 0.18)
  const head = new THREE.Group();
  head.position.set(0, 0.96, -0.06);
  head.scale.setScalar(0.86);
  torso.add(head);
  part(head, GEO.cyl, steel(hullDark), 0.32, 0.16, 0.32, 0, -0.18, 0);
  part(head, GEO.sph, M(0xe6b88e, 0.6), 0.26, 0.28, 0.26);
  part(head, GEO.sph, M(0xe6b88e, 0.58), 0.175, 0.135, 0.165, 0, -0.115, 0.045);
  part(head, cached("tk:cmd_helm", () => warHelmGeo(0.295, 0.06)), steel(hullDark), 1, 0.92, 1, 0, 0.06, -0.01);
  for (const s of [-1, 1]) {
    part(head, GEO.cyl, gold(BRASS), 0.072, 0.05, 0.072, s * 0.095, 0.16, 0.26, PI / 2, 0, 0);
    part(head, GEO.cyl, B(glow), 0.052, 0.055, 0.052, s * 0.095, 0.16, 0.265, PI / 2, 0, 0);
  }
  addFace(head, 0xe6b88e, { brow: 0.15, mouth: "grin" });

  // Flush hull-mounted side sponsons
  const lArm = new THREE.Group(); lArm.position.set(0.72, 0.22, 0.25); torso.add(lArm);
  const rArm = new THREE.Group(); rArm.position.set(-0.72, 0.22, 0.25); torso.add(rArm);
  for (const g of [lArm, rArm]) {
    part(g, cached("tk:sponson", () => chamferPanel(0.18, 0.2, 0.44, 0.03)), steel(hullDark), 1, 1, 1, 0, 0, 0);
    part(g, GEO.cyl, steel(STEEL_DARK), 0.032, 0.42, 0.032, 0, 0, 0.32, PI / 2, 0, 0);
  }
  const hand = new THREE.Group();
  hand.position.set(0, 0, 0.2);
  rArm.add(hand);
  part(hand, GEO.cyl, steel(steelC), 0.05, 0.24, 0.05, 0, 0, 0.12, PI / 2, 0, 0);

  return {
    root, body, torso, head, hand, lLeg, rLeg, lArm, rArm, cloak: null,
    headH: 2.65, heavy: true, scale: 1, tilt: 0.02, kind: "tank",
    handMode: "fixed", handRest: -0.2, parts: [], fx: {},
  };
}

function buildRailgun(team: TeamId): UnitRig {
  const tc = TEAM_COLORS[team], tcd = dark(tc);
  const shell = 0x798798, trim = 0x242c36, accent = team === 0 ? 0x7fe8ff : 0xffaa70;
  const root = new THREE.Group();
  root.rotation.order = "YXZ";
  const body = new THREE.Group();
  root.add(body);

  part(body, cached("rg:pelvis", () => chamferPanel(0.48, 0.18, 0.34, 0.035)), steel(trim), 1, 1, 1, 0, 0.94, 0);

  const lLeg = new THREE.Group(); lLeg.position.set(0.24, 0.92, 0); body.add(lLeg);
  const rLeg = new THREE.Group(); rLeg.position.set(-0.24, 0.92, 0); body.add(rLeg);
  for (const g of [lLeg, rLeg]) {
    part(g, legTubeGeo(0.135, 0.92), steel(trim));
    part(g, cached("rg:greave", () =>
      latheGeo([[0, -0.8], [0.125, -0.8], [0.14, -0.54], [0.135, -0.38], [0, -0.38]], 16, 1, 1.1, 12),
    ), steel(shell));
    part(g, GEO.cyl, steel(STEEL_LIGHT), 0.1, 0.22, 0.1, 0, -0.4, 0.02, 0, 0, PI / 2);
    part(g, GEO.sph, B(accent), 0.05, 0.03, 0.04, 0, -0.4, 0.14);
    part(g, cached("rg:foot", () => bootGeo(0.14, 0.26)), steel(shell), 1, 1, 1, 0, -0.88, -0.02);
  }

  const torso = new THREE.Group();
  torso.position.set(0, 0.96, 0);
  body.add(torso);
  part(torso, cached("rg:cuirass", () => cuirassGeo(0.74, 0.12)), steel(shell));
  part(torso, cached("rg:belt", () => torsoStrapGeo(0.39, 0.28, 0.12, 0.12, 0.024, 0.08)), steel(trim));
  for (const s of [-1, 1]) {
    part(torso, cached("rg:chevron", () => chamferPanel(0.14, 0.06, 0.05, 0.01)), steel(tcd), 1, 1, 1, s * 0.18, 0.6, 0.33, 0, s * 0.22, -s * 0.15);
  }
  part(torso, GEO.ring, steel(STEEL_LIGHT), 0.11, 0.11, 0.12, 0, 0.54, 0.36);
  part(torso, GEO.sph, B(accent), 0.075, 0.075, 0.045, 0, 0.54, 0.37);
  // Dorsal twin-coil plasma capacitor backpack
  part(torso, cached("rg:pack", () => chamferPanel(0.48, 0.42, 0.22, 0.035)), steel(0x36404d), 1, 1, 1, 0, 0.48, -0.3);
  for (const s of [-1, 1]) {
    part(torso, GEO.cyl, steel(0x36404d), 0.085, 0.48, 0.085, s * 0.16, 0.52, -0.36);
    part(torso, GEO.cyl, B(accent), 0.072, 0.2, 0.072, s * 0.16, 0.54, -0.37);
    part(torso, GEO.ring, gold(COPPER), 0.09, 0.09, 0.08, s * 0.16, 0.64, -0.36, PI / 2, 0, 0);
  }

  const head = new THREE.Group();
  head.position.set(0, 1.04, 0.02);
  torso.add(head);
  part(head, GEO.sph, steel(trim), 0.23, 0.24, 0.23);
  part(head, cached("rg:helm", () => warHelmGeo(0.275, 0.08)), steel(shell), 1, 1, 1, 0, 0.04, -0.01);
  part(head, cached("rg:visor", () => visorFaceGeo(0.265)), steel(trim), 1, 1, 1, 0, 0.03, 0.02);
  part(head, GEO.sph, B(accent), 0.06, 0.045, 0.04, -0.085, 0.035, 0.25);
  part(head, GEO.cyl, gold(COPPER), 0.048, 0.1, 0.048, 0.095, 0.035, 0.25, PI / 2, 0, 0);
  part(head, GEO.sph, B(accent), 0.042, 0.042, 0.03, 0.095, 0.035, 0.295);
  part(head, GEO.cyl, steel(STEEL_LIGHT), 0.022, 0.32, 0.022, 0.22, 0.24, -0.08, -0.2, 0, 0);
  part(head, GEO.sph, B(accent), 0.042, 0.042, 0.042, 0.22, 0.42, -0.11);

  const lArm = new THREE.Group(); lArm.position.set(0.46, 0.72, 0); torso.add(lArm);
  const rArm = new THREE.Group(); rArm.position.set(-0.46, 0.72, 0); torso.add(rArm);
  for (const [idx, g] of [lArm, rArm].entries()) {
    const s = idx === 0 ? 1 : -1;
    part(g, GEO.sph, steel(shell), 0.16, 0.12, 0.17, s * 0.03, 0.02, 0);
    part(g, armSegmentGeo(0.105, 0.95, false), steel(trim));
    part(g, GEO.cyl, steel(shell), 0.095, 0.28, 0.095, 0, -0.5, 0.02);
  }
  const hand = new THREE.Group();
  hand.position.set(0, -0.66, 0.04);
  rArm.add(hand);
  // Long twin-rail electromagnetic sniper rifle with copper induction rings & glowing core
  part(hand, cached("rg:rec", () => chamferPanel(0.14, 0.18, 0.74, 0.025)), steel(trim), 1, 1, 1, 0, 0, 0.26);
  part(hand, GEO.cyl, steel(trim), 0.036, 0.34, 0.036, 0, 0.14, 0.32, PI / 2, 0, 0); // ballistic scope
  part(hand, GEO.sph, B(accent), 0.032, 0.032, 0.02, 0, 0.14, 0.5);
  for (const s of [-1, 1]) {
    part(hand, GEO.cyl, steel(STEEL_LIGHT), 0.028, 1.82, 0.028, s * 0.055, 0.03, 0.98, PI / 2, 0, 0);
  }
  part(hand, GEO.cyl, B(accent), 0.024, 1.76, 0.024, 0, 0.03, 0.98, PI / 2, 0, 0);
  for (let i = 0; i < 6; i++) {
    part(hand, GEO.ring, gold(COPPER), 0.11, 0.11, 0.12, 0, 0.03, 0.56 + i * 0.24);
  }
  part(hand, cached("rg:muzzle", () => chamferPanel(0.16, 0.14, 0.16, 0.02)), steel(trim), 1, 1, 1, 0, 0.03, 1.9);

  return {
    root, body, torso, head, hand, lLeg, rLeg, lArm, rArm, cloak: null,
    headH: 2.75, heavy: false, scale: 1, tilt: 0.02, kind: "railgun",
    handMode: "fixed", handRest: -1.15, parts: [], fx: {},
  };
}

/* ============ cavalry: sculpted warhorse, smooth barding & plated rider ============ */

function buildKnight(team: TeamId): UnitRig {
  const tc = TEAM_COLORS[team], tcd = dark(tc);
  const horseC = team === 0 ? 0x8a6038 : 0x5a4a3c;
  const skin = 0xe6b88e;
  const root = new THREE.Group();
  root.rotation.order = "YXZ";
  const body = new THREE.Group();
  root.add(body);

  part(body, GEO.sph, M(horseC, 0.72), 0.5, 0.46, 0.98, 0, 1.34, 0);
  part(body, GEO.sph, M(horseC, 0.72), 0.46, 0.4, 0.62, 0, 1.3, 0.42);
  part(body, GEO.sph, M(dark(horseC, 0.9), 0.72), 0.4, 0.37, 0.62, 0, 1.4, -0.55);
  part(body, GEO.sph, M(horseC, 0.72), 0.3, 0.4, 0.3, 0, 1.74, 0.78, 0.55, 0, 0);
  part(body, GEO.sph, M(horseC, 0.72), 0.21, 0.24, 0.44, 0, 2.02, 1.16, 0.35, 0, 0);
  part(body, GEO.sph, M(0x6a5038, 0.8), 0.2, 0.2, 0.24, 0, 1.94, 1.55);
  for (const s of [-1, 1]) {
    part(body, GEO.cone, M(dark(horseC, 0.8), 0.8), 0.05, 0.16, 0.05, s * 0.1, 2.16, 1.34, -0.2, 0, 0);
    part(body, GEO.sph, B(0xf7f3e6), 0.05, 0.06, 0.03, s * 0.14, 2.02, 1.62);
    part(body, GEO.sph, B(0x1a120d), 0.03, 0.04, 0.025, s * 0.15, 2.02, 1.64);
    part(body, cached(`rein:${s}`, () =>
      loftTube([new THREE.Vector3(s * 0.17, 1.92, 1.5), new THREE.Vector3(s * 0.24, 1.96, 0.9), new THREE.Vector3(s * 0.18, 1.98, 0.2)],
        () => 0.014, 10, 6, true),
    ), leather(LEATHER_DARK));
  }
  part(body, GEO.sph, B(0x2a1a14), 0.04, 0.03, 0.02, 0, 1.9, 1.78);
  part(body, cached("h:mane", () =>
    loftTube([new THREE.Vector3(0, 2.22, 1.18), new THREE.Vector3(0, 2.04, 0.82), new THREE.Vector3(0, 1.72, 0.45)],
      t => 0.075 * (1 - t * 0.2), 10, 8, true),
  ), M(0x2e2318, 0.85));
  part(body, cached("h:tail", () =>
    loftTube([new THREE.Vector3(0, 1.48, -0.95), new THREE.Vector3(0, 1.2, -1.16), new THREE.Vector3(0, 0.78, -1.24)],
      t => 0.075 * (1 - t * 0.65), 10, 8, true),
  ), M(0x2e2318, 0.85));

  part(body, cached("h:peytral", () =>
    latheGeo([[0, 1.12], [0.53, 1.12], [0.56, 1.48], [0.46, 1.68], [0, 1.68]], 20, 0.96, 0.9, 16),
  ), steel(0x7d8694), 1, 1, 1, 0, 0, 0.42);
  part(body, cached("h:caparison", () =>
    latheGeo([[0.36, 1.76], [0.52, 1.04], [0.57, 1.05], [0.54, 1.48], [0.36, 1.82], [0, 1.8]], 22, 1, 1.32, 16),
  ), cloth(tcd), 1, 1, 1, 0, 0.0, -0.18);
  part(body, GEO.sph, steel(0x8e98a6), 0.16, 0.16, 0.34, 0, 2.06, 1.38, 0.42, 0, 0);
  part(body, GEO.cone, gold(), 0.04, 0.14, 0.04, 0, 2.18, 1.44, 0.9, 0, 0);
  part(body, GEO.sph, leather(0x553f26), 0.34, 0.12, 0.28, 0, 1.82, 0);

  const mkHLeg = (x: number, z: number) => {
    const p = new THREE.Group();
    p.position.set(x, 0.95, z);
    body.add(p);
    part(p, GEO.cyl, M(dark(horseC, 0.82), 0.8), 0.12, 0.46, 0.12, 0, -0.24, 0);
    part(p, GEO.sph, M(dark(horseC, 0.8), 0.78), 0.115, 0.11, 0.12, 0, -0.44, 0.01);
    part(p, GEO.cyl, M(dark(horseC, 0.88), 0.8), 0.085, 0.4, 0.085, 0, -0.64, 0);
    part(p, GEO.cyl, M(0xe8e0d0, 0.6), 0.095, 0.12, 0.095, 0, -0.76, 0);
    part(p, GEO.sph, M(0x1c1710), 0.13, 0.09, 0.16, 0, -0.88, 0.04);
    return p;
  };
  const flLeg = mkHLeg(0.3, 0.66), frLeg = mkHLeg(-0.3, 0.66), blLeg = mkHLeg(0.3, -0.6), brLeg = mkHLeg(-0.3, -0.6);

  for (const s of [-1, 1]) {
    part(body, GEO.cyl, M(0x2f3540, 0.82), 0.1, 0.5, 0.1, s * 0.38, 1.62, 0.12, 0.5, 0, 0);
    part(body, GEO.cyl, steel(0x8b93a1), 0.09, 0.34, 0.09, s * 0.42, 1.34, 0.3);
    part(body, GEO.ring, steel(STEEL_LIGHT), 0.075, 0.075, 0.08, s * 0.45, 1.18, 0.32, 0, PI / 2, 0);
  }
  const torso = new THREE.Group();
  torso.position.set(0, 1.9, -0.05);
  body.add(torso);
  part(torso, cached("kn:cuirass", () => cuirassGeo(0.76)), steel(0x8b93a1));
  part(torso, cached("kn:tabard", () => torsoStrapGeo(0.42, 0.3, 0.2, 0.72, 0.022, 0.1)), cloth(tc));
  part(torso, cached("kn:belt", () => ringBandGeo(0.38, 0.27, 0.12, 0.022, 0.075)), M(0xd9d2c0, 0.5, 0.3));
  for (const s of [-1, 1]) part(torso, GEO.sph, steel(STEEL_LIGHT), 0.22, 0.16, 0.22, s * 0.44, 0.78, 0);
  const cloak = new THREE.Group();
  cloak.position.set(0, 0.84, -0.24);
  torso.add(cloak);
  part(cloak, cached("kn:cloak", () => cloakGeo(0.56, 0.82, 1.0, 3)), cloth(tcd));

  const head = new THREE.Group();
  head.position.set(0, 1.12, 0);
  head.scale.setScalar(1.22);
  torso.add(head);
  part(head, GEO.sph, M(skin, 0.6), 0.26, 0.28, 0.26);
  part(head, GEO.sph, M(skin, 0.58), 0.175, 0.135, 0.165, 0, -0.115, 0.045);
  for (const s of [-1, 1]) part(head, GEO.sph, M(skin, 0.6), 0.046, 0.068, 0.036, s * 0.255, -0.01, 0);
  part(head, cached("kn:helm", () => warHelmGeo(0.305, 0.1)), steel(0x9aa3b2), 1, 1, 1, 0, 0.05, -0.01);
  part(head, cached("kn:band", () => ringBandGeo(0.305, 0.315, 0.12, 0.014, 0.036)), gold(GOLD));
  part(head, cached("kn:crest", () => crestFinGeo(0.42, 0.16, 0.05)), cloth(tc), 1, 1, 1, 0, 0.37, -0.02);
  addFace(head, skin, { brow: 0.16, mouth: "grin" });

  const mkArm = (side: number) => {
    const a = new THREE.Group();
    a.position.set(side * 0.43, 0.8, 0.06);
    torso.add(a);
    part(a, armSegmentGeo(0.11, 1, false), steel(0x8b93a1));
    part(a, GEO.sph, steel(0x8b93a1), 0.13, 0.13, 0.15, 0, 0.02, 0);
    part(a, GEO.sph, M(skin), 0.095, 0.095, 0.095, 0, -0.72, 0);
    return a;
  };
  const lArm = mkArm(1), rArm = mkArm(-1);
  const hand = new THREE.Group();
  hand.position.set(0, -0.72, 0.04);
  rArm.add(hand);
  part(hand, GEO.cyl, M(0x8a6a3a), 0.045, 3.6, 0.045, 0, 0, 1.2, PI / 2, 0, 0);
  part(hand, GEO.cone, steel(STEEL_LIGHT), 0.15, 0.3, 0.15, 0, 0, 0.28, PI / 2, 0, 0);
  part(hand, GEO.cone, steel(0xc9d1dc), 0.09, 0.44, 0.09, 0, 0, 3.05, PI / 2, 0, 0);
  part(hand, GEO.quadCone, cloth(tc), 0.16, 0.42, 0.02, 0, 0.1, 2.5, 0, PI / 2, 0);
  part(lArm, cached("kn:shield", () => heaterShieldGeo(0.42, 0.62)), cloth(tc), 1, 1, 1, 0, -0.5, 0.16);
  part(lArm, GEO.ring, gold(GOLD), 0.16, 0.16, 0.2, 0, -0.5, 0.2);

  return {
    root, body, torso, head, hand, lLeg: flLeg, rLeg: frLeg, lArm, rArm, cloak,
    flLeg, frLeg, blLeg, brLeg, headH: 3.7, heavy: true, scale: 1, tilt: 0.06, kind: "knight",
    handMode: "fixed", handRest: -0.1, parts: [], fx: {},
  };
}

function specialBase(kind: UnitKind): UnitRig {
  const root = new THREE.Group(), body = new THREE.Group(), torso = new THREE.Group(), head = new THREE.Group();
  const hand = new THREE.Group(), lArm = new THREE.Group(), rArm = new THREE.Group(), lLeg = new THREE.Group(), rLeg = new THREE.Group();
  root.rotation.order = "YXZ";
  root.add(body); body.add(torso, lLeg, rLeg); torso.add(head, lArm, rArm); rArm.add(hand);
  return { root, body, torso, head, hand, lArm, rArm, lLeg, rLeg, cloak: null, headH: 2.5, heavy: false, scale: 1, tilt: 0, kind, handMode: "fixed", handRest: 0, parts: [], fx: {} };
}

/* ============ summoned snake: undulating 8-segment viper with sculpted cobra hood ============ */

function buildSnake(team: TeamId): UnitRig {
  const r = specialBase("snake");
  r.headH = 0.75;
  const tc = TEAM_COLORS[team];
  const scales = M(0x558438, 0.58), scalesHi = M(0x70a246, 0.52), belly = M(0xd6ca8c, 0.65), stripe = M(tc, 0.6);
  r.head.position.set(0, 0.38, 0.38);

  // Smooth sculpted flared cobra hood (lathe/ellipsoid wings, never stuck-on balls)
  part(r.head, GEO.sph, scales, 0.24, 0.09, 0.22, 0, 0.0, -0.08, 0.35, 0, 0);
  part(r.head, GEO.sph, stripe, 0.19, 0.095, 0.16, 0, 0.01, -0.07, 0.35, 0, 0);
  part(r.head, GEO.sph, scalesHi, 0.165, 0.105, 0.25, 0, 0.02, 0.08);
  part(r.head, GEO.sph, belly, 0.15, 0.055, 0.21, 0, -0.06, 0.1, 0.12, 0, 0);
  for (const s of [-1, 1]) {
    part(r.head, GEO.sph, B(0xffdf60), 0.044, 0.052, 0.04, s * 0.11, 0.065, 0.21);
    part(r.head, GEO.sph, B(0x14180c), 0.015, 0.042, 0.015, s * 0.11, 0.065, 0.245);
    part(r.head, GEO.cone, boneMat(0xf8f3e4), 0.018, 0.085, 0.018, s * 0.065, -0.06, 0.25, PI);
    part(r.head, GEO.box, B(0xd94c52), 0.014, 0.01, 0.065, s * 0.024, -0.045, 0.49, 0, s * 0.45, 0);
  }
  part(r.head, GEO.box, B(0xd94c52), 0.022, 0.012, 0.19, 0, -0.045, 0.38);

  r.appendages = [];
  for (let i = 0; i < 8; i++) {
    const g = new THREE.Group();
    const y = i === 0 ? 0.28 : i === 1 ? 0.2 : 0.13;
    g.position.set(0, y, 0.26 - i * 0.16);
    r.body.add(g);
    const sz = 0.14 * (1 - i * 0.095);
    part(g, GEO.sph, i % 2 === 0 ? scales : scalesHi, sz * 1.12, sz * 0.92, 0.19);
    if (i > 0 && i < 7) part(g, GEO.sph, stripe, sz * 0.85, sz * 0.32, 0.11, 0, sz * 0.68, 0);
    part(g, GEO.sph, belly, sz * 0.8, sz * 0.36, 0.16, 0, -sz * 0.65, 0);
    r.appendages.push(g);
  }
  return r;
}

/* ============ mammoth: towering woolly war mammoth with contoured saddle blanket & tusks ============ */

function buildMammoth(team: TeamId): UnitRig {
  const r = specialBase("mammoth");
  r.heavy = true; r.headH = 5.1;
  const tc = TEAM_COLORS[team], tcd = dark(tc);
  const fur = M(0x5c3724, 0.92), furMid = M(0x74472e, 0.92), furLight = M(0x8a5a3d, 0.9), furDark = M(0x3a2117, 0.95);

  // Sculpted mammoth anatomy: towering shoulder hump sloping down to muscular hindquarters
  part(r.body, GEO.sph, furMid, 1.38, 1.56, 1.45, 0, 2.95, 0.55);
  part(r.body, GEO.sph, fur, 1.32, 1.32, 1.75, 0, 2.55, -0.25);
  part(r.body, GEO.sph, furDark, 1.12, 1.15, 1.18, 0, 2.35, -1.15);
  part(r.body, GEO.sph, furDark, 1.02, 0.78, 1.55, 0, 1.9, -0.2);
  for (const s of [-1, 1]) {
    part(r.body, GEO.cone, furDark, 0.68, 1.05, 1.55, s * 0.85, 1.65, -0.2, 0, 0, -s * 0.24);
    part(r.body, GEO.cone, fur, 0.62, 0.9, 0.95, s * 0.92, 1.72, 0.62, 0.1, 0, -s * 0.22);
  }
  part(r.body, GEO.cone, furDark, 0.88, 1.05, 0.65, 0, 1.85, 1.25, 0.25, 0, 0);

  // Smooth contoured curved war blanket draped naturally over the back (no flat rectangular slab!)
  part(r.body, cached("mam:blanket_c", () =>
    latheGeo([[0.5, 1.05], [1.38, 0.15], [1.45, 0.18], [1.32, 0.88], [0.52, 1.15], [0, 1.15]], 22, 1, 1.08, 16),
  ), cloth(tc), 1, 1, 1, 0, 2.66, -0.32, -0.12, 0, 0);
  part(r.body, cached("mam:girth_c", () => ringBandGeo(1.36, 1.36, 0.0, 0.045, 0.14)), leather(0x3a2616), 1, 1, 1, 0, 2.62, -0.25);
  for (const s of [-1, 1]) {
    part(r.body, GEO.ring, gold(), 0.2, 0.2, 0.14, s * 1.34, 3.05, -0.32, 0, PI / 2, 0);
    part(r.body, GEO.cyl, leather(0x3a2616), 0.048, 0.95, 0.048, s * 0.78, 4.02, -0.68, -0.15, 0, s * 0.18);
    part(r.body, GEO.cone, boneMat(0xf0e2be), 0.075, 0.3, 0.075, s * 0.86, 4.52, -0.75, -0.15, 0, s * 0.18);
    part(r.body, cached("mam:flag", () => cloakGeo(0.18, 0.26, 0.55, 2)), cloth(tcd), 1, 1, 1, s * 0.82, 4.3, -0.72);
  }

  r.head.position.set(0, 3.45, 1.42);
  part(r.head, GEO.sph, furLight, 0.92, 1.02, 0.88, 0, 0.05, 0);
  part(r.head, GEO.sph, furMid, 0.72, 0.72, 0.68, 0, 0.62, -0.05);
  part(r.head, GEO.sph, furMid, 0.64, 0.2, 0.42, 0, 0.28, 0.48); // organic heavy brow ridge
  part(r.head, GEO.sph, furMid, 0.72, 0.58, 0.56, 0, -0.25, 0.36);
  for (let i = -2; i <= 2; i++) {
    part(r.head, GEO.cone, furLight, 0.11, 0.44, 0.11, i * 0.2, 0.78, 0.38, 0.75, 0, i * 0.14);
  }
  for (const s of [-1, 1]) {
    part(r.head, GEO.sph, furDark, 0.34, 0.56, 0.14, s * 0.96, 0.06, -0.12, 0, -s * 0.45, s * 0.14);
    part(r.head, GEO.sph, M(0xa87658), 0.22, 0.38, 0.08, s * 0.96, 0.04, -0.06, 0, -s * 0.45, s * 0.14);
    part(r.head, GEO.sph, B(0xf8efd8), 0.11, 0.11, 0.07, s * 0.54, 0.1, 0.74);
    part(r.head, GEO.sph, B(0x28180e), 0.065, 0.08, 0.05, s * 0.54, 0.09, 0.795);
    part(r.head, GEO.sph, B(0xffffff), 0.024, 0.026, 0.02, s * 0.52, 0.12, 0.835);
    swept(
      r.head,
      [[s * 0.46, -0.35, 0.5], [s * 0.78, -0.96, 1.25], [s * 1.04, -0.82, 2.2], [s * 0.76, -0.1, 2.86]],
      t => 0.24 * (1 - 0.86 * Math.pow(t, 1.35)),
      boneMat(0xf4e8c8),
      0.04, 24, 12,
    );
    part(r.head, GEO.ring, gold(), 0.21, 0.21, 0.2, s * 0.72, -0.84, 1.12, 0.4, s * 0.35, 0);
    part(r.head, GEO.ring, steel(IRON), 0.14, 0.14, 0.14, s * 1.0, -0.66, 2.22, -0.5, -s * 0.35, 0);
  }
  const trunk = new THREE.Group();
  trunk.position.set(0, -0.25, 0.74);
  r.head.add(trunk);
  swept(
    trunk,
    [[0, 0, 0], [0, -0.78, 0.32], [0, -1.62, 0.48], [0, -2.18, 0.96], [0, -1.96, 1.48]],
    t => 0.38 * (1 - 0.65 * t) + (t > 0.9 ? 0.04 : 0),
    furLight,
    0.35, 24, 12,
  );
  for (let i = 0; i < 12; i++) {
    const t = (i + 1) / 14;
    const ty = -t * 1.95, tz = t < 0.55 ? t * 0.65 : 0.36 + (t - 0.55) * 1.35;
    part(trunk, GEO.sph, furDark, 0.32 - t * 0.16, 0.038, 0.24 - t * 0.11, 0, ty, tz, 0.25, 0, 0);
  }
  r.appendages = [trunk];

  const leg = (x: number, z: number) => {
    const g = new THREE.Group();
    g.position.set(x, 1.56, z);
    r.body.add(g);
    part(g, GEO.sph, furMid, 0.44, 0.5, 0.48, 0, -0.08, 0);
    part(g, GEO.cyl, fur, 0.37, 1.15, 0.37, 0, -0.66, 0);
    part(g, GEO.sph, furDark, 0.43, 0.24, 0.48, 0, -1.3, 0.05);
    for (const toe of [-0.18, 0, 0.18]) {
      part(g, GEO.sph, boneMat(0xcac0a4), 0.08, 0.09, 0.1, toe, -1.39, 0.44);
    }
    return g;
  };
  r.flLeg = leg(0.86, 0.95); r.frLeg = leg(-0.86, 0.95); r.blLeg = leg(0.82, -1.18); r.brLeg = leg(-0.82, -1.18);
  r.lLeg = r.flLeg; r.rLeg = r.frLeg;
  swept(r.body, [[0, 2.5, -2.05], [0.06, 1.85, -2.42], [0.22, 1.25, -2.38]], t => 0.09 - t * 0.03, furDark, 0.6);
  part(r.body, GEO.cone, furDark, 0.14, 0.36, 0.14, 0.22, 1.18, -2.38, PI, 0, 0);
  return r;
}

/* ============ ballista: wheeled torsion siege engine + smooth crew engineer ============ */

function buildBallista(team: TeamId): UnitRig {
  const r = specialBase("ballista");
  r.heavy = true; r.headH = 3.15;
  const tc = TEAM_COLORS[team];
  const wood = M(0x6e4b30, 0.8), woodDark = M(0x4c321f, 0.84), iron = steel(0x525a65), rope = M(0xc8b282, 0.88);

  part(r.body, cached("bal:deck", () => chamferPanel(1.68, 0.22, 2.55, 0.04)), woodDark, 1, 1, 1, 0, 0.62, -0.05);
  for (const s of [-1, 1]) {
    part(r.body, cached("bal:beam", () => chamferPanel(0.2, 0.26, 2.7, 0.03)), wood, 1, 1, 1, s * 0.64, 0.78, 0);
    part(r.body, GEO.box, iron, 0.24, 0.3, 0.34, s * 0.64, 0.78, 1.18);
    part(r.body, GEO.box, iron, 0.24, 0.3, 0.34, s * 0.64, 0.78, -1.15);
    part(r.body, cached("bal:shield", () => heaterShieldGeo(0.52, 0.72)), cloth(tc), 1, 1, 1, s * 0.8, 0.82, 0.1, 0, s * (PI / 2), 0);
  }
  part(r.body, GEO.cyl, iron, 0.09, 2.04, 0.09, 0, 0.58, 0.92, 0, 0, PI / 2);
  part(r.body, GEO.cyl, iron, 0.09, 2.04, 0.09, 0, 0.58, -0.92, 0, 0, PI / 2);

  // 4 Spoked chariot wheels with iron tire rims (stored in appendages)
  const wheels: THREE.Group[] = [];
  for (const x of [-1.02, 1.02]) for (const z of [-0.92, 0.92]) {
    const g = new THREE.Group(); g.position.set(x, 0.58, z); r.body.add(g);
    part(g, GEO.ring, iron, 0.56, 0.56, 1.5, 0, 0, 0, 0, PI / 2);
    part(g, GEO.ring, wood, 0.49, 0.49, 1.1, 0, 0, 0, 0, PI / 2);
    part(g, GEO.cyl, iron, 0.15, 0.24, 0.15, 0, 0, 0, 0, 0, PI / 2);
    for (let i = 0; i < 4; i++) part(g, GEO.box, woodDark, 0.09, 0.96, 0.07, 0, 0, 0, i * PI / 4);
    wheels.push(g);
  }
  r.appendages = wheels;

  // Torsion weapon mount: elevation pedestal, twin rope torsion coils, swept bow arms & winch
  part(r.torso, GEO.cyl, iron, 0.2, 0.7, 0.2, 0, 1.06, 0.25);
  part(r.torso, cached("bal:stock", () => chamferPanel(0.38, 0.24, 2.95, 0.035)), woodDark, 1, 1, 1, 0, 1.52, 0.38);
  part(r.torso, GEO.box, gold(BRASS), 0.12, 0.06, 2.86, 0, 1.65, 0.42);
  part(r.torso, cached("bal:front", () => chamferPanel(1.55, 0.42, 0.44, 0.04)), wood, 1, 1, 1, 0, 1.52, 1.2);
  for (const s of [-1, 1]) {
    part(r.torso, GEO.cyl, rope, 0.14, 0.68, 0.14, s * 0.62, 1.54, 1.2);
    part(r.torso, GEO.cyl, iron, 0.16, 0.12, 0.16, s * 0.62, 1.88, 1.2);
    part(r.torso, GEO.cyl, iron, 0.16, 0.12, 0.16, s * 0.62, 1.2, 1.2);
    swept(r.torso, [[s * 0.62, 1.54, 1.2], [s * 1.25, 1.56, 0.95], [s * 1.72, 1.58, 0.35]], t => 0.11 - t * 0.05, wood, 0.5);
    swept(r.torso, [[s * 1.72, 1.58, 0.35], [0, 1.62, -0.58]], 0.018, B(0xeadac0), 1, 8, 6);
  }
  part(r.torso, GEO.cyl, gold(BRASS), 0.16, 0.12, 0.16, 0.28, 1.48, -0.82, 0, 0, PI / 2);
  part(r.torso, GEO.cyl, iron, 0.04, 0.5, 0.04, 0, 1.48, -0.82, 0, 0, PI / 2);

  // Smooth standing siege engineer at rear winch (using tunicTorsoGeo, cuirassGeo, kettleHelmGeo, & addFace)
  for (const s of [-1, 1]) {
    part(r.torso, legTubeGeo(0.115, 0.68), M(0x343a46, 0.82), 1, 1, 1, s * 0.16, 1.28, -1.04);
    part(r.torso, cached("bal:boot", () => bootGeo(0.115, 0.2)), leather(LEATHER_DARK), 1, 1, 1, s * 0.16, 0.68, -1.04);
    part(r.torso, armSegmentGeo(0.1, 0.72, false), cloth(tc), 1, 1, 1, s * 0.34, 1.78, -0.98, 0.6, 0, 0);
  }
  part(r.torso, cached("bal:crew_tunic", () => tunicTorsoGeo(0.62)), cloth(tc), 1, 0.85, 1, 0, 1.22, -1.04);
  part(r.torso, cached("bal:crew_cuirass", () => cuirassGeo(0.62, 0.2)), steel(0x8892a2), 1, 0.82, 1, 0, 1.24, -1.04);
  r.head.position.set(0, 2.12, -1.04);
  part(r.head, GEO.sph, M(0xe6b88e, 0.6), 0.25, 0.27, 0.25);
  part(r.head, GEO.sph, M(0xe6b88e, 0.58), 0.165, 0.125, 0.155, 0, -0.11, 0.045);
  part(r.head, cached("bal:kettle", () => kettleHelmGeo(0.29, 0.4)), steel(0x8892a2), 1, 1, 1, 0, 0.06, -0.01);
  part(r.head, cached("bal:band", () => ringBandGeo(0.29, 0.3, 0.11, 0.014, 0.034)), cloth(tc));
  addFace(r.head, 0xe6b88e, { brow: 0.1, mouth: "flat" });

  // Loaded heavy siege bolt in slider trough
  r.hand.position.set(0, 1.72, 0.2);
  r.torso.add(r.hand);
  part(r.hand, GEO.cyl, M(0xcdb588), 0.052, 2.65, 0.052, 0, 0, 0.45, PI / 2);
  part(r.hand, GEO.quadCone, steel(STEEL_LIGHT), 0.16, 0.5, 0.13, 0, 0, 1.98, PI / 2);
  for (const s of [-1, 1]) part(r.hand, GEO.box, cloth(tc), 0.15, 0.024, 0.34, s * 0.08, 0, -0.62, 0, 0, s * 0.25);
  return r;
}

/* ============ reaper: seamless wraith robe + ribcage + lantern + scythe + 4 tendrils ============ */

function buildReaper(team: TeamId): UnitRig {
  const r = specialBase("reaper");
  r.kind = "reaper"; r.scale = 1.24; r.headH = 4.3; r.heavy = true;
  r.root.scale.setScalar(r.scale);
  r.torso.position.set(0, 1.35, 0);
  const shroud = cloth(0x181422), cloakDark = cloth(0x261f34), trim = steel(0x6e6486), accent = TEAM_COLORS[team];
  const glow = team === 0 ? 0xa8d8ff : 0xffaa70;

  // Seamless pleated spectral robe + tattered hem strips + shoulder mantle
  part(r.torso, cached("rea:robe", () => robeTorsoGeo(0.76, 0.72)), shroud, 1, 1.55, 1, 0, -0.08, 0);
  part(r.torso, cached("rea:mantle", () =>
    latheGeo([[0.22, 0.84], [0.48, 0.6], [0.64, 0.58], [0.58, 0.82], [0.22, 0.94], [0, 0.92]], 22, 1, 0.82, 14),
  ), cloakDark);
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU;
    part(r.torso, GEO.cone, i % 2 ? cloakDark : shroud, 0.22, 1.15 + (i % 3) * 0.16, 0.11,
      Math.cos(a) * 0.34, -0.78, Math.sin(a) * 0.28, Math.sin(a) * 0.12, a, -Math.cos(a) * 0.12);
  }
  // Exposed skeletal ribcage + glowing soul core
  part(r.torso, GEO.cyl, boneMat(), 0.038, 0.48, 0.03, 0, 0.48, 0.24);
  for (let i = 0; i < 4; i++) {
    const ry = 0.3 + i * 0.11, rw = 0.28 + i * 0.025;
    for (const s of [-1, 1]) {
      part(r.torso, cached(`rea_rib:${s}:${rw.toFixed(2)}`, () => ribArchGeo(s, rw, 0.28)), boneMat(), 1, 1, 1, 0, ry, 0.02);
    }
  }
  part(r.torso, GEO.sph, B(0xc084ff), 0.085, 0.12, 0.06, 0, 0.5, 0.22);
  part(r.torso, GEO.ring, gold(0x9a8858), 0.11, 0.11, 0.11, 0, 0.5, 0.26);
  for (const s of [-1, 1]) {
    part(r.torso, GEO.sph, trim, 0.2, 0.12, 0.24, s * 0.48, 0.78, 0);
    part(r.torso, GEO.cone, trim, 0.04, 0.22, 0.04, s * 0.54, 0.9, 0, 0, 0, -s * 0.6);
  }

  // Deep pointed cowl + gaunt skull (with unlit eyes at z > 0.24)
  r.head.position.set(0, 1.14, 0.05);
  part(r.head, cached("rea:hood", () => clothHoodGeo(0.35)), shroud, 1, 1.12, 1.1, 0, 0.02, -0.02);
  part(r.head, GEO.cone, shroud, 0.24, 0.52, 0.24, 0, 0.42, -0.22, -0.6, 0, 0);
  part(r.head, GEO.sph, B(0x07050b), 0.26, 0.28, 0.2, 0, 0.02, 0.06);
  part(r.head, GEO.sph, boneMat(), 0.22, 0.24, 0.21, 0, 0.01, 0.06);
  part(r.head, GEO.sph, boneMat(BONE_DARK), 0.14, 0.1, 0.13, 0, -0.14, 0.08);
  part(r.head, cached("rea:teeth", () => upperTeethGeo(0.062, 0.022, -0.102)), boneMat(0xf6f1e2), 1, 1, 1, 0, 0, 0.02);
  addFace(r.head, BONE, { socket: true, pupil: 0xc99eff, mouth: "none", size: 0.065, z: 0.24 });

  // Skeletal arms + glowing Soul Lantern in left hand + curved crescent Grim Scythe in right
  for (const [arm, side] of [[r.lArm, 1], [r.rArm, -1]] as [THREE.Group, number][]) {
    arm.position.set(side * 0.48, 0.78, 0);
    part(arm, GEO.cone, shroud, 0.22, 0.52, 0.22, 0, -0.26, 0, PI);
    part(arm, GEO.cyl, boneMat(), 0.04, 0.44, 0.04, 0, -0.52, 0);
    part(arm, GEO.sph, boneMat(), 0.075, 0.075, 0.075, 0, -0.74, 0.02);
  }
  part(r.lArm, GEO.cyl, trim, 0.015, 0.22, 0.015, 0, -0.86, 0.05);
  part(r.lArm, GEO.ring, trim, 0.09, 0.12, 0.09, 0, -1.04, 0.05);
  part(r.lArm, GEO.sph, B(glow), 0.075, 0.1, 0.075, 0, -1.04, 0.05);

  r.hand.position.set(0, -0.74, 0.05);
  swept(r.hand, [[0, 0, -0.65], [0, 0.04, 0.8], [0, -0.03, 2.25]], () => 0.044, M(0x362830, 0.75), 1, 14, 8);
  part(r.hand, GEO.ring, trim, 0.11, 0.11, 0.14, 0, 0, 2.25);
  swept(r.hand, [[0, 0, 2.24], [0.58, 0, 2.48], [1.26, 0, 2.22], [1.74, 0, 1.42]], t => 0.16 * (1 - 0.92 * Math.pow(t, 1.4)), steel(0xd8dfe8), 0.02, 24, 6);
  swept(r.hand, [[0.06, 0, 2.3], [0.6, 0, 2.54], [1.28, 0, 2.26], [1.72, 0, 1.48]], t => 0.05 * (1 - 0.85 * t), B(0xc8a4ff), 0.02, 20, 6);
  r.handRest = -1.1; r.handMode = "follow";

  // 4 Flowing tapered spectral shadow tendrils (stored in appendages)
  r.appendages = [];
  for (let i = 0; i < 4; i++) {
    const s = i % 2 ? -1 : 1, g = new THREE.Group();
    g.position.set(s * 0.22, 0.26 + Math.floor(i / 2) * 0.34, -0.14);
    r.torso.add(g);
    swept(
      g,
      [[0, 0, 0], [s * 0.5, 0.34, -0.4], [s * 1.12, 0.12, 0.06], [s * 1.52, -0.5, 0.58]],
      t => 0.105 * (1 - 0.85 * t),
      cloakDark,
      0.04, 20, 8,
    );
    part(g, GEO.sph, B(accent), 0.052, 0.052, 0.052, s * 1.4, -0.34, 0.46);
    r.appendages.push(g);
  }
  return r;
}

/* ============ baking ============ */

const MAT_STD = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.76, metalness: 0.04 });
const MAT_METAL = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.24, metalness: 0.84 });
const MAT_BASIC = new THREE.MeshBasicMaterial({ vertexColors: true });
const CLASS_MAT: THREE.Material[] = [MAT_STD, MAT_METAL, MAT_BASIC];

function classOf(m: THREE.Material): 0 | 1 | 2 {
  if (m instanceof THREE.MeshBasicMaterial) return 2;
  return (m as THREE.MeshStandardMaterial).metalness >= 0.3 ? 1 : 0;
}

interface Baked { template: UnitRig; specs: RigPart[] }
const bakedCache = new Map<string, Baked>();

function bake(template: UnitRig): Baked {
  const specs: RigPart[] = [];
  const groups: THREE.Group[] = [];
  template.root.traverse(o => { if (o instanceof THREE.Group) groups.push(o); });
  for (const g of groups) {
    const buckets: THREE.BufferGeometry[][] = [[], [], []];
    for (const c of g.children) {
      if (!(c instanceof THREE.Mesh)) continue;
      c.updateMatrix();
      const raw = c.geometry as THREE.BufferGeometry;
      const geo = (raw.index ? raw.toNonIndexed() : raw.clone()).applyMatrix4(c.matrix);
      if (geo.attributes.uv) geo.deleteAttribute("uv");
      if (!geo.attributes.normal) geo.computeVertexNormals();
      const mat = c.material as THREE.MeshStandardMaterial | THREE.MeshBasicMaterial;
      const cls = classOf(mat);
      const pos = geo.attributes.position, norm = geo.attributes.normal;
      const aoAttr = geo.attributes.ao;
      const n = pos.count;
      let minY = Infinity, maxY = -Infinity;
      for (let i = 0; i < n; i++) {
        const y = pos.getY(i);
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
      const spanY = Math.max(0.05, maxY - minY);
      const colors = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        let shade = 1;
        if (cls !== 2) {
          const nx = norm ? norm.getX(i) : 0, ny = norm ? norm.getY(i) : 0, nz = norm ? norm.getZ(i) : 0;
          const h = (pos.getY(i) - minY) / spanY - 0.5;
          const key = ny * 0.13 + nz * 0.065 + Math.abs(nx) * 0.03;
          const ao = aoAttr ? aoAttr.getX(i) : 1;
          shade = (cls === 1 ? 1 + key * 1.15 + h * 0.1 : 1 + key * 0.85 + h * 0.08) * ao;
          shade = Math.max(0.64, Math.min(1.22, shade));
        }
        colors[i * 3] = Math.min(1, mat.color.r * shade);
        colors[i * 3 + 1] = Math.min(1, mat.color.g * shade);
        colors[i * 3 + 2] = Math.min(1, mat.color.b * shade);
      }
      if (geo.attributes.ao) geo.deleteAttribute("ao");
      geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
      buckets[cls].push(geo);
    }
    buckets.forEach((list, i) => {
      if (!list.length) return;
      const merged = mergeGeometries(list, false);
      for (const l of list) l.dispose();
      if (merged) {
        merged.computeBoundingSphere();
        specs.push({ group: g, geometry: merged, material: CLASS_MAT[i] });
      }
    });
  }
  return { template, specs };
}

function cloneTree(src: THREE.Object3D, map: Map<THREE.Object3D, THREE.Group>): THREE.Group {
  const g = new THREE.Group();
  g.position.copy(src.position);
  g.quaternion.copy(src.quaternion);
  g.scale.copy(src.scale);
  g.rotation.order = src.rotation.order;
  map.set(src, g);
  for (const child of src.children) if (child instanceof THREE.Group) g.add(cloneTree(child, map));
  return g;
}

function instantiate(b: Baked): UnitRig {
  const t = b.template;
  const map = new Map<THREE.Object3D, THREE.Group>();
  const root = cloneTree(t.root, map);
  const pick = (g?: THREE.Group | null) => (g ? map.get(g) : undefined);
  return {
    root, body: pick(t.body)!, torso: pick(t.torso)!, head: pick(t.head)!, hand: pick(t.hand)!,
    lLeg: pick(t.lLeg)!, rLeg: pick(t.rLeg)!, lArm: pick(t.lArm)!, rArm: pick(t.rArm)!, cloak: pick(t.cloak) ?? null,
    flLeg: pick(t.flLeg), frLeg: pick(t.frLeg), blLeg: pick(t.blLeg), brLeg: pick(t.brLeg),
    appendages: t.appendages?.map(g => pick(g)!),
    headH: t.headH, heavy: t.heavy, scale: t.scale, tilt: t.tilt, kind: t.kind, handMode: t.handMode, handRest: t.handRest,
    parts: b.specs.map(s => ({ group: map.get(s.group)!, geometry: s.geometry, material: s.material })),
    fx: {},
  };
}

export function buildUnitRig(kind: UnitKind, team: TeamId): UnitRig {
  const key = `${kind}:${team}`;
  let baked = bakedCache.get(key);
  if (!baked) {
    const template =
      kind === "knight" ? buildKnight(team)
      : kind === "mammoth" ? buildMammoth(team)
      : kind === "snake" ? buildSnake(team)
      : kind === "ballista" ? buildBallista(team)
      : kind === "reaper" ? buildReaper(team)
      : kind === "robot" ? buildRobot(team)
      : kind === "tank" ? buildTank(team)
      : kind === "railgun" ? buildRailgun(team)
      : buildHumanoid(kind, team);
    baked = bake(template);
    bakedCache.set(key, baked);
  }
  const rig = instantiate(baked);
  rig.torso.rotation.x = rig.tilt;
  return rig;
}
