import assert from "node:assert/strict";
import { test } from "node:test";
import { BattleSimulation } from "../src/game/simulation";
import { DEFS } from "../src/game/units";
import { MATCHUPS, SEEDS, deployPlan, finish } from "./balance-helpers";

for (const matchup of MATCHUPS) {
  test(`equal-budget counter: ${matchup.name}, both team orientations, three seeds`, () => {
    for (const counterTeam of [0, 1] as const) {
      const otherTeam = counterTeam === 0 ? 1 : 0;
      let wins = 0;
      for (const seed of SEEDS) {
        const sim = new BattleSimulation(seed); sim.reset(false);
        const counterCost = deployPlan(sim, counterTeam, matchup.budget, matchup.counter);
        const opponentCost = deployPlan(sim, otherTeam, matchup.budget, matchup.opponent);
        assert.ok(counterCost <= matchup.budget && opponentCost <= matchup.budget);
        assert.ok(counterCost <= opponentCost, "the counter must not get a spending advantage");
        assert.ok(matchup.budget - counterCost < Math.min(...matchup.counter.map(g => DEFS[g.kind].cost)), "counter cannot afford another unit in its composition");
        assert.ok(matchup.budget - opponentCost < Math.min(...matchup.opponent.map(g => DEFS[g.kind].cost)), "opponent cannot afford another unit in its composition");
        wins += finish(sim) === counterTeam ? 1 : 0;
        assert.equal(sim.phase, "over", "a timeout is not a victory");
      }
      assert.ok(wins >= 2, `${matchup.name}: team ${counterTeam} won ${wins}/3`);
    }
  });
}