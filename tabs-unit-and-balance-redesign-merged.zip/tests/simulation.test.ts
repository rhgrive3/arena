import assert from "node:assert/strict";
import { test } from "node:test";
import { Vector3 } from "three";
import { BattleSimulation, FIXED_STEP } from "../src/game/simulation";
import { DEFS, DEPLOY, MAX_PER_TEAM, MAX_SUMMONS_PER_TEAM, SNAKE_LIFETIME, type UnitKind } from "../src/game/units";
import { STAGES } from "../src/game/campaign";

function empty() {
  const sim = new BattleSimulation();
  sim.reset(false);
  return sim;
}
function run(sim: BattleSimulation, seconds: number) {
  for (let i = 0; i < Math.ceil(seconds / FIXED_STEP / sim.speed); i++) sim.advance(FIXED_STEP);
}
function dummy(sim: BattleSimulation, x: number, z = 0, hp = 1e6) {
  const d = sim.spawn(1, "spear", x, z);
  d.hp = d.maxHp = hp;
  d.order = "hold";
  d.cooldown = 1e9;
  return d;
}

test("snake arrows summon independent biting tokens after impact, including after the archer dies", () => {
  const s = empty(), archer = s.spawn(0, "snakearcher", -12, 0), victim = dummy(s, 0);
  const witness = s.spawn(0, "spear", -60, 30); witness.order = "hold";
  archer.cooldown = 1e9;
  s.begin(); s.fire(archer, victim);
  s.damage(archer, 1e6, 1);
  run(s, 0.8);
  const snake = s.units.find(u => u.kind === "snake");
  assert.ok(snake, "arrow retains summon metadata when its shooter is dead");
  assert.equal(snake.summonOwner, archer.id);
  assert.ok(snake.expiresAt! > s.time + SNAKE_LIFETIME - 1);
  assert.equal(s.deployedCount(0), 1);
  assert.equal(s.spawned[0], 2, "tokens do not inflate deployed troops");
  const before = victim.hp;
  run(s, 2.5);
  assert.ok(victim.hp < before && snake.damageDealt > 0, "independent token repeatedly bites");
  const kills = [...s.kills], losses = [...s.losses];
  run(s, SNAKE_LIFETIME + 1);
  assert.equal(s.summonCount(0), 0);
  assert.deepEqual(s.kills, kills); assert.deepEqual(s.losses, losses);
});

test("missed snake arrows summon at the ground impact, not at the moved target", () => {
  const s = empty(), a = s.spawn(0, "snakearcher", -10, 0), v = dummy(s, 0);
  a.order = "hold"; a.cooldown = 1e9;
  s.begin(); s.fire(a, v); v.position.z = 25;
  let token;
  for (let i = 0; i < 180 && !token; i++) { s.advance(FIXED_STEP); token = s.units.find(u => u.kind === "snake"); }
  assert.ok(token); assert.ok(Math.abs(token.position.z) < 1);
  assert.equal(v.hp, v.maxHp);
});

test("summons have separate bounded capacity, cannot be bought, and cannot overfill either team", () => {
  const s = empty(); s.setupSandbox(); s.clearUnits();
  for (let i = 0; i < MAX_PER_TEAM; i++) s.spawn(0, i === 0 ? "snakearcher" : "spear", -12 - Math.floor(i / 10) * 3, i === 0 ? 0 : 15 + (i % 10) * 2).order = "hold";
  const victim = dummy(s, 0), a = s.units[0]; a.cooldown = 1e9;
  s.begin(); s.fire(a, victim); run(s, 0.8);
  assert.equal(s.deployedCount(0), MAX_PER_TEAM); assert.equal(s.summonCount(0), 1);
  assert.equal(s.deploy("snake", -10, -30).reason, "locked");
  assert.equal(s.deploy("snake", 10, -30, 1, 1).reason, "locked");
  for (let i = 0; i < 12; i++) s.fire(a, victim);
  run(s, 0.9); assert.ok(s.summonCount(0) <= 3, "per-summoner limit");
  while (s.summonCount(0) < MAX_SUMMONS_PER_TEAM) s.spawn(0, "snake", -50, -30);
  s.fire(a, victim); run(s, 0.9); assert.equal(s.summonCount(0), MAX_SUMMONS_PER_TEAM);
});

test("ice arrows stack to three, slow movement and attacks, and fully thaw", () => {
  const s = empty(), a = s.spawn(0, "icearcher", -8, 0), v = dummy(s, 0);
  a.order = "hold"; a.cooldown = 1e9;
  s.begin();
  for (let i = 0; i < 5; i++) { s.fire(a, v); run(s, 0.4); }
  assert.equal(v.freezeStacks, 3); assert.ok(v.slowT > 3);
  v.cooldown = 10; v.order = "auto";
  const x = v.position.x;
  run(s, 0.5);
  assert.ok(Math.abs(v.position.x - x) < DEFS.spear.speed * 0.5 * 0.4);
  assert.ok(v.cooldown > 9.8, "75% slower cooldown");
  v.order = "hold"; run(s, 5);
  assert.equal(v.freezeStacks, 0); assert.equal(v.slowT, 0);
});

test("balloon arrows lift, incapacitate, burst, fall, damage and recover with immunity", () => {
  const s = empty(), a = s.spawn(0, "balloonarcher", -10, 0), v = dummy(s, 0);
  a.order = "hold"; a.cooldown = 1e9;
  s.begin(); s.fire(a, v); run(s, 1);
  assert.ok(v.balloonT > 0 && v.airborne && v.position.y > 0.5);
  assert.equal(s.isDown(v), true); assert.equal(v.windup, null);
  const cd = v.cooldown, x = v.position.x;
  run(s, 0.5); assert.equal(v.cooldown, cd); assert.equal(v.position.x, x);
  const hp = v.hp;
  let landed = false;
  for (let i = 0; i < 360; i++) { s.advance(FIXED_STEP); if (!v.airborne && v.balloonT === 0) { landed = true; break; } }
  assert.ok(landed); assert.equal(v.position.y, 0); assert.ok(v.downTime > 0 && v.hp < hp);
  assert.ok(v.balloonImmunity > 3);
  s.fire(a, v); run(s, 0.7); assert.equal(v.balloonT, 0, "no permanent balloon lock");
  run(s, 2); assert.equal(s.isDown(v), false);
  const events = s.drainEvents().map(e => e.type);
  assert.ok(events.includes("balloon") && events.includes("pop") && events.includes("land"));
});

test("balloon lift obeys mass and cannot be extended by repeated shots", () => {
  const apex = (kind: UnitKind) => {
    const s = empty(), a = s.spawn(0, "balloonarcher", -10, 0), v = s.spawn(1, kind, 0, 0);
    a.order = v.order = "hold"; a.cooldown = v.cooldown = 1e9;
    s.begin(); s.fire(a, v); run(s, 0.7);
    const remaining = v.balloonT;
    for (let i = 0; i < 4; i++) s.fire(a, v);
    run(s, 0.5); assert.ok(v.balloonT < remaining, "hits do not refresh duration");
    run(s, 0.7); return v.position.y;
  };
  const light = apex("spear"), heavy = apex("mammoth");
  assert.ok(light > 3.5 && heavy > 0.3 && heavy < light * 0.4, `${light} / ${heavy}`);
});

test("moving mammoths trample nearby light enemies, but not allies or stationary targets at a distance", () => {
  const s = empty(), m = s.spawn(0, "mammoth", -8, 0), v = dummy(s, 0, 1.1);
  const ally = s.spawn(0, "spear", 0, -1), heavy = s.spawn(1, "tank", 0, -2);
  ally.order = heavy.order = "hold"; ally.cooldown = heavy.cooldown = m.cooldown = 1e9;
  s.begin(); s.command([m.id], "move", new Vector3(10, 0, 0)); run(s, 3.3);
  assert.ok(v.hp < v.maxHp, "movement alone deals trample damage");
  assert.equal(ally.hp, ally.maxHp); assert.equal(heavy.hp, heavy.maxHp);
  assert.ok(s.drainEvents().some(e => e.type === "trample"));
  const still = empty(), parked = still.spawn(0, "mammoth", 0, 0), nearby = dummy(still, 0, 2);
  parked.order = "hold"; parked.cooldown = 1e9; still.begin(); run(still, 2);
  assert.equal(nearby.hp, nearby.maxHp, "no passive stationary aura damage");
});

test("ballista bolts pierce a line with heavy knockback even after their operator dies", () => {
  const s = empty(), gun = s.spawn(0, "ballista", -15, 0);
  const units = [0, 2, 4, 6].map(x => dummy(s, x));
  s.spawn(0, "spear", -50, 30).order = "hold";
  gun.cooldown = 1e9; s.begin(); s.fire(gun, units[0]); s.damage(gun, 1e6, 1); run(s, 0.65);
  assert.ok(units.filter(u => u.hp < u.maxHp).length >= 3);
  assert.ok(units.some(u => u.airborne));
});

test("reaper tentacles execute only nearby low-HP light opponents", () => {
  const s = empty(), r = s.spawn(0, "reaper", -1, 0), low = dummy(s, 1, 0, 35), high = dummy(s, 2, 2, 1000);
  const heavy = s.spawn(1, "mammoth", 2, -2), ally = s.spawn(0, "spear", 0, 2);
  heavy.hp = ally.hp = 35;
  for (const u of [r, heavy, ally]) { u.order = "hold"; u.cooldown = 1e9; }
  s.begin(); run(s, 0.2);
  assert.ok(low.dead && low.airborne); assert.equal(high.hp, 1000);
  assert.equal(heavy.hp, 35); assert.equal(ally.hp, 35);
  assert.ok(r.position.y > 0, "floating motion also exists in the simulation");
});

test("summoning, freezing and floating remain deterministic at 0.5x, 1x, 2x and 4x", () => {
  const scenario = (speed: number, fps: number) => {
    const s = new BattleSimulation(71); s.reset(false);
    for (const [i, kind] of (["snakearcher", "icearcher", "balloonarcher"] as const).entries()) s.spawn(0, kind, -14, (i - 1) * 3);
    const target = s.spawn(1, "mammoth", 5, 0);
    target.hp = target.maxHp = 100000; target.order = "hold"; target.cooldown = 1e9;
    s.begin(); s.speed = speed;
    for (let i = 0; i < 12 * fps / speed; i++) s.advance(1 / fps);
    return { time: s.time, units: s.units, shots: s.projectiles, gold: s.gold, kills: s.kills };
  };
  const reference = scenario(1, 60);
  for (const [speed, fps] of [[0.5, 60], [1, 30], [2, 60], [4, 20]]) assert.deepEqual(scenario(speed, fps), reference, `${speed}x / ${fps} FPS`);
});

test("pausing and killing balloon victims never leaves orphaned floating state", () => {
  const s = empty(), a = s.spawn(0, "balloonarcher", -9, 0), v = dummy(s, 0);
  a.cooldown = 1e9; s.begin(); s.fire(a, v); run(s, 1);
  assert.ok(v.balloonT > 0);
  s.togglePause();
  const snapshot = JSON.stringify(s.units);
  run(s, 3); assert.equal(JSON.stringify(s.units), snapshot);
  s.togglePause(); s.damage(v, 1e9, 0);
  assert.equal(v.balloonT, 0); assert.ok(v.dead && v.airborne);
  run(s, 2); assert.equal(v.position.y, 0); assert.equal(v.airborne, false);
  s.reset(false); assert.equal(s.units.length, 0); assert.equal(s.projectiles.length, 0);
});

test("targeting excludes self and allies, even when they are closer", () => {
  const s = empty();
  const blue = s.spawn(0, "spear", -20, 0);
  const ally = s.spawn(0, "spear", -18, 0);
  const red = s.spawn(1, "spear", 30, 0);
  assert.equal(s.nearestEnemy(blue)?.id, red.id);
  assert.equal(s.nearestEnemy(blue, 5), undefined);
  for (const u of s.units) u.order = "hold";
  s.begin();
  run(s, 6);
  assert.equal(blue.hp, blue.maxHp);
  assert.equal(ally.hp, ally.maxHp);
  assert.deepEqual(s.kills, [0, 0]);
});

test("friendly fire is rejected; kills count deaths, not hits", () => {
  const s = empty();
  const u = s.spawn(1, "spear", 0, 0);
  s.damage(u, 10000, 1);
  assert.equal(u.hp, DEFS.spear.hp);
  s.damage(u, 10, 0);
  assert.deepEqual(s.kills, [0, 0]);
  s.damage(u, 10000, 0);
  s.damage(u, 10000, 0);
  assert.equal(u.hp, 0);
  assert.deepEqual(s.kills, [1, 0]);
  assert.deepEqual(s.losses, [0, 1]);
});

test("setup is frozen until both armies exist", () => {
  const s = empty();
  assert.equal(s.begin(), false);
  s.setupStage(STAGES[0], 0);
  assert.equal(s.begin(), false, "an empty player side cannot start");
  s.deploy("spear", -20, 0, 1);
  assert.equal(s.begin(), true);
  const other = empty();
  other.setupStage(STAGES[0], 0);
  other.deploy("spear", -20, 0, 1);
  const positions = other.units.map(u => u.position.toArray());
  run(other, 10);
  assert.equal(other.time, 0);
  assert.deepEqual(other.units.map(u => u.position.toArray()), positions);
});

test("idle troops pursue distant enemies and finish a battle", () => {
  const s = empty();
  const blue = s.spawn(0, "spear", -40, 0);
  const red = s.spawn(1, "zombie", 40, 0);
  s.begin();
  run(s, 2);
  assert.ok(blue.position.x > -36);
  assert.ok(red.position.x < 37);
  run(s, 90);
  assert.equal(s.phase, "over");
  assert.equal(s.result?.winner, 0);
  assert.equal(s.kills[0], s.losses[1]);
  assert.equal(s.kills[1], s.losses[0]);
});

test("projectiles own independent position and velocity vectors", () => {
  const s = empty();
  const archer = s.spawn(0, "archer", -15, 0);
  const first = dummy(s, 0, 0);
  const second = dummy(s, 0, 10);
  s.begin();
  s.fire(archer, first);
  const original = s.projectiles[0].velocity.clone();
  s.fire(archer, second);
  assert.equal(s.projectiles.length, 2);
  assert.deepEqual(s.projectiles[0].velocity, original);
  s.projectiles[1].velocity.set(0, 0, 0);
  assert.deepEqual(s.projectiles[0].velocity, original);
});

for (const kind of DEPLOY) {
  test(`${kind} reaches and damages an enemy`, () => {
    const s = empty();
    s.spawn(0, kind, -15, 0);
    const target = dummy(s, 15, 0, 5000);
    s.begin();
    s.speed = 4;
    run(s, 30);
    assert.ok(target.hp < 5000, `${kind} never hit its target`);
    assert.ok(s.units.filter(u => u.team === 0 && !u.dead).length > 0, `${kind} died without a fight`);
  });
}

test("area attacks hurt enemies only, and only within the blast", () => {
  const s = empty();
  const mage = s.spawn(0, "mage", -12, 0);
  const target = dummy(s, 0, 0);
  const nearby = dummy(s, 1.8, 1.8);
  const far = dummy(s, 5.5, 0);
  const ally = s.spawn(0, "spear", 0, -2);
  ally.order = "hold";
  s.begin();
  s.fire(mage, target);
  run(s, 1.4);
  assert.ok(target.hp < target.maxHp);
  assert.ok(nearby.hp < nearby.maxHp);
  assert.equal(far.hp, far.maxHp);
  assert.equal(ally.hp, ally.maxHp);
});

test("batch deployment never overspends and can be undone exactly", () => {
  const s = empty();
  s.setupSandbox();
  s.gold[0] = DEFS.archer.cost * 2 + 10;
  assert.equal(s.deploy("archer", -10, 0, 5).count, 2);
  assert.equal(s.gold[0], 10);
  assert.equal(s.deploy("archer", -10, 0, 1).reason, "funds");
  assert.equal(s.undoDeploy(), true);
  assert.equal(s.gold[0], DEFS.archer.cost * 2 + 10);
  assert.equal(s.count(0), 16);
  assert.equal(s.spawned[0], 16);
  assert.equal(s.canUndo, false);
});

test("deployment rejects bad zones and non-finite coordinates", () => {
  const s = empty();
  s.setupSandbox();
  for (const [x, z] of [[5, 0], [-200, 0], [-10, 100], [NaN, 0], [-10, Infinity]]) {
    assert.equal(s.deploy("spear", x, z).reason, "zone");
  }
  assert.equal(s.deploy("spear", -10, 0, NaN).count, 0);
  assert.equal(s.count(0), 16);
  const edge = s.deploy("spear", -3, 46, 5);
  assert.equal(edge.count, 5);
  assert.ok(s.units.every(u => u.dead || u.team !== 0 || s.isDeployPosition(u.position.x, u.position.z)));
});

test("the team cap counts living units, not fading corpses", () => {
  const s = empty();
  s.setupSandbox();
  for (let i = 0; i < MAX_PER_TEAM - 17; i++) s.spawn(0, "spear", -70 + (i % 10) * 5, -35 + Math.floor(i / 10) * 5);
  assert.equal(s.count(0), MAX_PER_TEAM - 1);
  assert.equal(s.deploy("spear", -20, 30, 5).count, 1);
  assert.equal(s.count(0), MAX_PER_TEAM);
  assert.equal(s.deploy("spear", -20, 30, 5).reason, "limit");
  s.damage(s.units[0], 1e6, 1);
  assert.equal(s.deploy("spear", -20, 30, 5).count, 1);
  assert.equal(s.count(0), MAX_PER_TEAM);
});

test("repeated placement separates units instead of stacking them", () => {
  const s = empty();
  s.setupSandbox();
  s.gold[0] = 4000;
  for (let i = 0; i < 4; i++) assert.equal(s.deploy("zombie", -15, 5, 5).count, 5);
  for (const a of s.units) for (const b of s.units) {
    if (a !== b && a.team === 0 && b.team === 0) assert.ok(a.position.distanceTo(b.position) > 1.3);
  }
});

test("movement orders take priority over auto targeting, then hold position", () => {
  const s = empty();
  const blue = s.spawn(0, "spear", -4, 0);
  const red = s.spawn(1, "spear", 0, 0);
  red.order = "hold";
  red.cooldown = 1e9;
  s.begin();
  s.command([blue.id], "move", new Vector3(-22, 0, 0));
  run(s, 2);
  assert.ok(blue.position.x < -10);
  assert.equal(blue.targetId, null);
  assert.equal(red.hp, red.maxHp);
  run(s, 5);
  assert.equal(blue.order, "hold");
  assert.ok(blue.position.distanceTo(new Vector3(-22, 0, 0)) < 0.8);
  const before = blue.position.clone();
  run(s, 2);
  assert.ok(blue.position.distanceTo(before) < 0.1);
  s.command([blue.id], "auto");
  run(s, 1);
  assert.ok(blue.position.x > before.x + 2);
});

test("formation destinations stay distinct at the battlefield boundary", () => {
  const s = empty();
  for (let i = 0; i < 49; i++) s.spawn(0, "spear", -40 + i % 7 * 3, -10 + Math.floor(i / 7) * 3);
  s.command(s.units.map(u => u.id), "move", new Vector3(78, 0, 52));
  const destinations = s.units.map(u => u.destination!);
  assert.equal(new Set(destinations.map(p => p.toArray().join(":"))).size, 49);
  assert.ok(destinations.every(p => p.x <= 76 && p.z <= 50));
});

test("pausing freezes time, budget, units and projectiles", () => {
  const s = empty();
  s.setupSandbox();
  s.begin();
  run(s, 2);
  s.togglePause();
  const snapshot = JSON.stringify({ time: s.time, units: s.units, shots: s.projectiles, gold: s.gold });
  run(s, 10);
  assert.equal(JSON.stringify({ time: s.time, units: s.units, shots: s.projectiles, gold: s.gold }), snapshot);
  s.togglePause();
  s.advance(FIXED_STEP);
  assert.equal(s.phase, "playing");
  assert.ok(s.time > 2);
});

test("fixed timestep is identical at 1x/2x/4x and different frame rates", () => {
  const baseline = empty();
  baseline.setupSandbox();
  baseline.begin();
  run(baseline, 24);
  for (const [speed, fps] of [[2, 30], [4, 20]]) {
    const s = empty();
    s.setupSandbox();
    s.begin();
    s.speed = speed;
    for (let i = 0; i < 24 * fps / speed; i++) s.advance(1 / fps);
    assert.equal(s.time, baseline.time);
    assert.deepEqual(s.kills, baseline.kills);
    assert.deepEqual(s.units, baseline.units);
    assert.deepEqual(s.projectiles, baseline.projectiles);
  }
});

test("a preset battle always reaches a result with valid accounting", () => {
  for (const stage of [STAGES[0], STAGES[9], STAGES[19]]) {
    const s = new BattleSimulation(2026);
    s.setupStage(stage, 19);
    s.deploy("spear", -20, 0, 5);
    s.begin();
    s.speed = 4;
    for (let t = 0; t < 12000 && s.phase === "playing"; t++) s.advance(FIXED_STEP);
    assert.equal(s.phase, "over", `${stage.id} must end`);
    assert.equal(s.kills[0], s.losses[1]);
    assert.equal(s.kills[1], s.losses[0]);
    for (const team of [0, 1] as const) assert.equal(s.spawned[team] - s.losses[team], s.count(team));
    assert.ok(s.units.every(u => u.position.toArray().every(Number.isFinite)));
    assert.ok(s.units.every(u => u.position.y >= 0 && u.position.y < 40));
  }
});

test("restarting a stage resets time, counters, shots, speed and orders", () => {
  const s = empty();
  s.setupStage(STAGES[4], 4);
  s.deploy("mage", -12, 20, 2);
  s.begin();
  s.speed = 4;
  run(s, 30);
  s.setupStage(STAGES[4], 4);
  assert.equal(s.phase, "setup");
  assert.equal(s.time, 0);
  assert.equal(s.speed, 1);
  assert.deepEqual(s.kills, [0, 0]);
  assert.deepEqual(s.losses, [0, 0]);
  assert.equal(s.result, null);
  assert.equal(s.projectiles.length, 0);
  assert.equal(s.canUndo, false);
  assert.equal(s.gold[0], STAGES[4].budget);
  assert.ok(s.units.every(u => u.hp === u.maxHp && u.targetId === null && u.order === "auto" && !s.isDown(u)));
});

test("sub-step render interpolation bridges 0.5x and variable frames cleanly", () => {
  const s = empty();
  const blue = s.spawn(0, "knight", -20, 0);
  const red = dummy(s, 30, 0);
  assert.equal(s.interpolationAlpha, 1);
  s.begin();
  s.speed = 0.5;
  s.advance(0.01); // 0.005s sim time (< FIXED_STEP)
  assert.ok(s.interpolationAlpha > 0.25 && s.interpolationAlpha < 0.35);
  for (let i = 0; i < 6; i++) s.advance(FIXED_STEP);
  s.advance(FIXED_STEP); // 0.5x -> fractional step
  const a1 = s.interpolationAlpha;
  assert.ok(a1 >= 0 && a1 <= 1);
  const interpX = blue.prevPosition.x + (blue.position.x - blue.prevPosition.x) * a1;
  assert.ok(interpX >= blue.prevPosition.x && interpX <= blue.position.x);
  void red;
});

test("every unit kind stays inside the field and never goes invalid during a mixed battle", () => {
  const s = empty();
  s.setupSandbox();
  for (const kind of DEPLOY) s.deploy(kind, -30 + DEPLOY.indexOf(kind) * 1.2, 30, 1);
  s.begin();
  s.speed = 4;
  run(s, 40);
  for (const u of s.units) {
    assert.ok(Number.isFinite(u.position.x) && Number.isFinite(u.position.z));
    assert.ok(Math.abs(u.position.x) <= 78 && Math.abs(u.position.z) <= 52);
  }
});
