import assert from "node:assert/strict";
import { test } from "node:test";
import * as THREE from "three";
import { UnitBatchRenderer } from "../src/game/unit-renderer";
import { buildUnitRig } from "../src/game/rigs";
import { ALL_KINDS, DEPLOY } from "../src/game/units";
import { BattleSimulation } from "../src/game/simulation";
import { StatusRenderer } from "../src/game/status-renderer";
import { buildStageEnv } from "../src/game/stages3d";
import { AudioFX } from "../src/game/audio";

const instanced = (scene: THREE.Scene) => scene.children.filter((o): o is THREE.InstancedMesh => o instanceof THREE.InstancedMesh);
const total = (scene: THREE.Scene) => instanced(scene).reduce((n, m) => n + m.count, 0);

test("every unit type bakes into a handful of bone parts with vertex colors", () => {
  for (const kind of ALL_KINDS) for (const team of [0, 1] as const) {
    const rig = buildUnitRig(kind, team);
    assert.ok(rig.parts.length >= 6 && rig.parts.length <= 26, `${kind}: ${rig.parts.length} parts`);
    for (const p of rig.parts) {
      assert.ok(p.geometry.getAttribute("color"), `${kind} part is vertex colored`);
      assert.ok(p.geometry.getAttribute("position").count > 0);
      let inTree = false;
      rig.root.traverse(o => { if (o === p.group) inTree = true; });
      assert.ok(inTree, `${kind} part belongs to the rig's own bones`);
    }
    assert.ok(rig.head && rig.torso && rig.hand && rig.lArm && rig.rArm && rig.lLeg && rig.rLeg, kind);
  }
});

test("every character has the same eye construction (basic-material head parts)", () => {
  for (const kind of ALL_KINDS) {
    const rig = buildUnitRig(kind, 0);
    const headParts = rig.parts.filter(p => p.group === rig.head);
    assert.ok(headParts.some(p => p.material instanceof THREE.MeshBasicMaterial), `${kind} head needs unlit eyes`);
    // eyes must sit on the +Z (front) side of the head: some basic geometry has vertices with z > 0.18
    const eyes = headParts.find(p => p.material instanceof THREE.MeshBasicMaterial)!;
    eyes.geometry.computeBoundingBox();
    assert.ok(eyes.geometry.boundingBox!.max.z > 0.18, `${kind} eyes face forward`);
  }
});

test("mammoth has four independent legs, curved tusks, a moving trunk and forward eyes", () => {
  const r = buildUnitRig("mammoth", 0);
  assert.equal(new Set([r.flLeg, r.frLeg, r.blLeg, r.brLeg]).size, 4);
  assert.ok(r.flLeg!.position.z > r.blLeg!.position.z);
  assert.ok(r.appendages?.length === 1);
  assert.ok(r.head.position.z > 0);
  const head = r.parts.filter(p => p.group === r.head);
  assert.ok(head.some(p => { p.geometry.computeBoundingBox(); return p.geometry.boundingBox!.max.z > 2.5; }));
});

test("snake, ballista and reaper expose independently cloned moving appendages", () => {
  for (const kind of ["snake", "ballista", "reaper"] as const) {
    const a = buildUnitRig(kind, 0), b = buildUnitRig(kind, 0);
    assert.ok(a.appendages && a.appendages.length >= 4);
    assert.notEqual(a.appendages[0], b.appendages![0]);
    a.appendages[0].rotation.y = 0.9;
    assert.notEqual(a.appendages[0].rotation.y, b.appendages![0].rotation.y);
  }
});

test("balloons and stacking ice follow the victim in 3D with interpolation and release every instance", () => {
  const scene = new THREE.Scene(), effects = new StatusRenderer(scene), sim = new BattleSimulation();
  sim.reset(false);
  const u = sim.spawn(0, "spear", 5, 3);
  u.prevPosition.set(5, 2, 3);
  u.balloonT = 2; u.position.y = 4; u.slowT = 3; u.freezeStacks = 3;
  effects.sync(sim.units, 1, 0.5);
  assert.deepEqual(instanced(scene).map(m => m.count), [3, 3, 6]);
  const matrix = new THREE.Matrix4(); instanced(scene)[0].getMatrixAt(0, matrix);
  assert.ok(matrix.elements[13] > 3 + 3 && matrix.elements[13] < 4 + 5);
  u.dead = true; effects.sync(sim.units, 2, 1);
  assert.equal(total(scene), 0);
  effects.dispose(); assert.equal(scene.children.length, 0);
});

test("rigs of the same kind share baked geometry but not skeletons", () => {
  const a = buildUnitRig("orc", 0), b = buildUnitRig("orc", 0), other = buildUnitRig("orc", 1);
  assert.notEqual(a.root, b.root);
  assert.notEqual(a.rArm, b.rArm);
  assert.equal(a.parts[0].geometry, b.parts[0].geometry);
  assert.notEqual(a.parts[0].geometry, other.parts[0].geometry, "team colors are baked per team");
  a.rArm.rotation.x = 1.2;
  assert.ok(Math.abs(b.rArm.rotation.x) < 1e-9, "posing one unit must not move another");
});

test("baked rendering: one instance per bone part, matrices follow the animated skeleton", () => {
  const scene = new THREE.Scene();
  const renderer = new UnitBatchRenderer(scene);
  let expected = 0;
  const rigs: ReturnType<typeof buildUnitRig>[] = [];
  for (let i = 0; i < 70; i++) {
    const rig = buildUnitRig("spear", 0);
    rig.root.position.set(i % 10 * 2, 0, Math.floor(i / 10) * 2);
    rig.rArm.rotation.x = i * 0.02;
    expected += rig.parts.length;
    renderer.add(i, rig);
    rigs.push(rig);
  }
  renderer.sync();
  assert.equal(total(scene), expected);
  assert.ok(renderer.drawCalls <= rigs[0].parts.length, "70 identical units cost no more draw calls than one");
  assert.ok(instanced(scene).every(m => m.count <= m.instanceMatrix.count), "buffers grew to fit 70 units");

  const m = new THREE.Matrix4();
  const arm = rigs[5].parts.find(p => p.group === rigs[5].rArm)!;
  const batch = instanced(scene).find(x => x.geometry === arm.geometry)!;
  const seen = new Set<string>();
  for (let i = 0; i < batch.count; i++) { batch.getMatrixAt(i, m); seen.add(m.elements.map(n => n.toFixed(4)).join()); }
  rigs[5].root.updateMatrixWorld(true);
  assert.ok(seen.has(arm.group.matrixWorld.elements.map(n => n.toFixed(4)).join()), "instance matrix equals the bone's world matrix");

  renderer.remove(0);
  renderer.sync();
  assert.equal(total(scene), expected - rigs[0].parts.length);
  renderer.clear();
  renderer.sync();
  assert.ok(instanced(scene).every(x => x.count === 0 && !x.visible));
  renderer.dispose();
  assert.equal(scene.children.length, 0);
});

test("cavalry has four articulated legs and its head ahead of the tail (+Z is forward)", () => {
  const rig = buildUnitRig("knight", 0);
  assert.ok(rig.flLeg && rig.frLeg && rig.blLeg && rig.brLeg);
  assert.equal(rig.flLeg.position.z, 0.66);
  assert.equal(rig.blLeg.position.z, -0.6);
  const bodyPart = rig.parts.filter(p => p.group === rig.body);
  let max = -Infinity, min = Infinity;
  for (const p of bodyPart) { p.geometry.computeBoundingBox(); max = Math.max(max, p.geometry.boundingBox!.max.z); min = Math.min(min, p.geometry.boundingBox!.min.z); }
  assert.ok(max > 1.5 && min > -1.3 && max > Math.abs(min), "horse head extends further forward than the tail extends back");
});

test("all 4 stage environments build distinct sky/fog/props and dispose cleanly", () => {
  const scene = new THREE.Scene();
  const skies = new Set<number>();
  for (const id of [1, 2, 3, 4]) {
    const env = buildStageEnv(scene, id);
    assert.ok(env.group.children.length >= 25, `stage ${id} should have rich scenery`);
    skies.add((scene.background as THREE.Color).getHex());
    env.dispose();
    assert.equal(scene.children.length, 0, `stage ${id} disposed cleanly`);
  }
  assert.equal(skies.size, 4, "each chapter has a distinct sky atmosphere");
});

test("humanoid rigs differentiate anatomical proportions (shoulder breadth, stance, hunch) and audio supports all new SFX", () => {
  const guardian = buildUnitRig("guardian", 0);
  const orc = buildUnitRig("orc", 0);
  const elf = buildUnitRig("elf", 0);
  const shaman = buildUnitRig("shaman", 0);
  assert.ok(orc.lArm.position.x > elf.lArm.position.x * 1.35, "orc has broader shoulders than elf");
  assert.ok(guardian.lLeg.position.x > elf.lLeg.position.x * 1.25, "guardian has a wider stance than elf");
  assert.ok(shaman.tilt > elf.tilt + 0.15, "shaman has a stooped hunch");

  const audio = new AudioFX();
  for (const sfx of ["freeze", "balloon", "pop", "summon", "trample", "tentacle", "reap"] as const) {
    assert.doesNotThrow(() => audio.sfx(sfx, 0));
  }
  audio.dispose();
});
