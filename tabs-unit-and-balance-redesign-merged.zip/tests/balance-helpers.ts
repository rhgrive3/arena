import { BattleSimulation } from "../src/game/simulation";
import { DEFS, MAX_PER_TEAM, type UnitKind, type TeamId } from "../src/game/units";

export const SEEDS = [1, 7, 2026];
export interface ArmyPlan { kind: UnitKind; share: number; x?: number; spread?: number }
export interface Matchup { name: string; budget: number; counter: ArmyPlan[]; opponent: ArmyPlan[] }

export function deployPlan(sim: BattleSimulation, team: TeamId, budget: number, plan: ArmyPlan[]) {
  let spent = 0;
  const sign = team === 0 ? -1 : 1;
  const placed = new Map<ArmyPlan, number>();
  for (const group of plan) {
    const def = DEFS[group.kind];
    const n = Math.min(MAX_PER_TEAM - sim.deployedCount(team), Math.floor(budget * group.share / def.cost), Math.floor((budget - spent) / def.cost));
    for (let i = 0; i < n; i++) {
      const columns = Math.min(n, 10);
      sim.spawn(team, group.kind, sign * (group.x ?? 18) + sign * Math.floor(i / 10) * 2.2, (i % 10 - (columns - 1) / 2) * (group.spread ?? 2.3));
      spent += def.cost;
    }
    placed.set(group, n);
  }
  // Spend the same allowance, without gifting the counter army extra units or stats.
  while (sim.deployedCount(team) < MAX_PER_TEAM) {
    const group = plan.find(g => DEFS[g.kind].cost <= budget - spent);
    if (!group) break;
    const i = placed.get(group) ?? 0;
    sim.spawn(team, group.kind, sign * ((group.x ?? 18) + 3 + Math.floor(i / 10) * 2.2), (i % 10 - 4.5) * (group.spread ?? 2.3));
    placed.set(group, i + 1);
    spent += DEFS[group.kind].cost;
  }
  sim.gold[team] = budget - spent;
  return spent;
}

export function finish(sim: BattleSimulation, seconds = 240) {
  sim.begin(); sim.speed = 4;
  while (sim.phase === "playing" && sim.time < seconds) { sim.advance(0.1); sim.drainEvents(); }
  return sim.result?.winner ?? null;
}

export const MATCHUPS: Matchup[] = [
  ...(["mammoth", "giant", "tank"] as UnitKind[]).map(kind => {
    const budget = DEFS[kind].cost;
    const balloonShare = DEFS.balloonarcher.cost / budget;
    return {
      name: `single-heavy / ${kind}`, budget,
      counter: [{ kind: "balloonarcher" as UnitKind, share: balloonShare, x: 26, spread: 4 }, { kind: "halberdier" as UnitKind, share: (1 - balloonShare) / 2, x: 14, spread: 4 }, { kind: "crossbow" as UnitKind, share: (1 - balloonShare) / 2, x: 24, spread: 4 }],
      opponent: [{ kind, share: 1 }],
    };
  }),
  ...(["mammoth", "giant", "tank"] as UnitKind[]).map(kind => ({
    name: `anti-heavy / ${kind}`, budget: DEFS[kind].cost * Math.ceil(1900 / DEFS[kind].cost),
    counter: [{ kind: "halberdier" as UnitKind, share: 0.4, x: 14, spread: 4.5 }, { kind: "crossbow" as UnitKind, share: 0.4, x: 22, spread: 4.5 }, { kind: "balloonarcher" as UnitKind, share: 0.2, x: 24 }],
    opponent: [{ kind, share: 1, spread: 4 }],
  })),
  ...(["snakearcher", "railgun", "mage"] as UnitKind[]).map(kind => ({
    name: `flankers / ${kind}`, budget: DEFS[kind].cost * Math.ceil(1900 / DEFS[kind].cost),
    counter: [{ kind: "assassin" as UnitKind, share: 0.5, x: 16, spread: 4 }, { kind: "knight" as UnitKind, share: 0.35, x: 16, spread: 30 }, { kind: "guardian" as UnitKind, share: 0.15, x: 14 }],
    opponent: [{ kind, share: 1, x: 24, spread: 2.3 }],
  })),
  ...(["zombie", "skeleton"] as UnitKind[]).flatMap(kind => (["bomber", "giant", "mammoth"] as UnitKind[]).map(aoe => ({
    name: `${aoe} / ${kind}`, budget: 1000,
    counter: [{ kind: aoe, share: 1, x: 18, spread: 2.2 }], opponent: [{ kind, share: 1, x: 18, spread: 1.5 }],
  }))),
];