import { iglooParts } from '../world/struct/extra';
import { TRIM_MAT_BY_ID } from '../systems/trims';
// Extra mob behaviours modelled on Minecraft Java Edition:
//  * climbing        – ground mobs walk to ladders / vines and climb them towards their target; spiders scale solid walls
//  * villager sleep  – villagers claim a free bed at night, walk to it, lie down and wake at sunrise or when hurt
//  * panic + golems  – villagers flee from zombies / illagers; a group of >=3 villagers that panicked (or slept recently) spawns an iron golem
//  * equipment       – zombies, skeletons, piglins, illagers ... pick armour / weapons off the ground and wear them (armour points + damage bonus)
//  * structure mobs  – ocean monuments hold exactly 3 elder guardians (+ guardians), woodland mansions hold evokers and vindicators
//  * dragon breath   – the perched Ender Dragon spits breath clouds that linger on the ground; glass bottles collect them
import * as THREE from 'three';

/**
 * Box3.setFromObject semantics for batched rigs: every object contributes its geometry box transformed by its world matrix,
 * except baked rig batches, which contribute their vertices (= the transformed corners of the original cubes). The result is
 * therefore identical to the union of the per-cube boxes the unbatched rig produced.
 */
const _rigTmp = new THREE.Box3();
function rigBounds(root: THREE.Object3D): THREE.Box3 {
  const out = new THREE.Box3();
  root.updateWorldMatrix(true, true);
  root.traverse(o => {
    const geo = (o as THREE.Mesh).geometry as THREE.BufferGeometry | undefined;
    if (!geo) return;
    if (o.userData.rigBatch) {
      _rigTmp.makeEmpty();
      _rigTmp.expandByObject(o, true);
    } else {
      if (geo.boundingBox === null) geo.computeBoundingBox();
      _rigTmp.copy(geo.boundingBox!).applyMatrix4(o.matrixWorld);
    }
    out.union(_rigTmp);
  });
  return out;
}
import { BLOCKS, ID, resolve } from '../game/data';
import { locateExtra } from '../world/structures';
import { groundAt, isThinPassableBlockName } from './pathfinding';
import { MUSIC_DISCS } from '../game/extras';
import type { Mob, MobHost, Species } from './mobs';

export interface BehaviorCtx {
  host: MobHost;
  mobs: Mob[];
  scene: THREE.Scene;
  timeline: number;
  rnd(): number;
  spawn(species: Species, x: number, z: number, baby?: boolean, exactY?: number): Mob | undefined;
  damageMob(m: Mob, d: number, dir?: THREE.Vector3, crit?: boolean): void;
  steer(m: Mob, goal: THREE.Vector3): void;
  walk(m: Mob, move: number, dt: number, ridden: boolean): void;
}

export interface Gear { armor: (string | null)[]; armorPts: number[]; weapon: string | null; weaponBonus: number; meshes: THREE.Object3D[] }
export interface BedSite { x: number; y: number; z: number; hx: number; hz: number }
export type MobX = Mob & {
  climbing?: boolean; climbT?: number; sleeping?: boolean; bed?: BedSite | null; bedT?: number; bedBan?: number;
  panic?: number; slept?: number; golemT?: number; gear?: Gear; lootT?: number; structure?: boolean; sayT?: number; gearBox?: THREE.Box3;
};
export interface BreathCloud { pos: THREE.Vector3; radius: number; life: number; maxLife: number; mesh: THREE.Mesh; hurt: number; spark: number }

const FLY = new Set(['bee', 'blaze', 'ghast', 'wither', 'vex', 'phantom', 'allay', 'parrot', 'bat', 'breeze', 'dragon', 'shulker']);
const SWIM = new Set(['fish', 'salmon', 'tropical_fish', 'pufferfish', 'tadpole', 'dolphin', 'squid', 'glow_squid', 'guardian', 'elder_guardian', 'axolotl']);
const CLIMB_NAMES = new Set(['ladder', 'vine', 'weeping_vines', 'twisting_vines', 'cave_vines']);
const THREATS = new Set(['zombie', 'husk', 'drowned', 'zombie_villager', 'pillager', 'vindicator', 'evoker', 'ravager', 'vex', 'witch', 'zoglin', 'illusioner']);
const LOOTERS = new Set(['zombie', 'husk', 'drowned', 'zombie_villager', 'skeleton', 'stray', 'bogged', 'wither_skeleton', 'piglin', 'piglin_brute', 'zombified_piglin', 'pillager', 'vindicator']);

export const isClimbable = (id: number) => id > 0 && !!BLOCKS[id] && CLIMB_NAMES.has(BLOCKS[id].name);

// ---------------------------------------------------------------------------------------------------- equipment tables
const ARMOR_POINTS: Record<string, [number, number, number, number]> = {
  leather: [1, 3, 2, 1], golden: [2, 5, 3, 1], chainmail: [2, 5, 4, 1], copper: [2, 5, 4, 1], iron: [2, 6, 5, 2], diamond: [3, 8, 6, 3], netherite: [3, 8, 6, 3], turtle: [2, 0, 0, 0],
};
const SLOT_NAMES = ['helmet', 'chestplate', 'leggings', 'boots'];
export const TIER_COLORS: Record<string, string> = { leather: '#a0652d', golden: '#e4c35b', chainmail: '#9aa0a5', copper: '#c7835e', iron: '#d0d7d2', diamond: '#58cfc4', netherite: '#655b60', turtle: '#5da05d', wooden: '#a88754', stone: '#92978d' };

export function armorInfo(name: string): { slot: number; pts: number; tier: string } | null {
  const m = /^(leather|golden|chainmail|copper|iron|diamond|netherite|turtle)_(helmet|chestplate|leggings|boots)$/.exec(name);
  if (!m) return name === 'turtle_helmet' ? { slot: 0, pts: 2, tier: 'turtle' } : null;
  const slot = SLOT_NAMES.indexOf(m[2]);
  return { slot, pts: ARMOR_POINTS[m[1]][slot], tier: m[1] };
}
export function weaponInfo(name: string): { bonus: number; tier: string } | null {
  const m = /^(wooden|stone|copper|iron|golden|diamond|netherite)_(sword|axe)$/.exec(name);
  if (!m) return null;
  const d = resolve(name)?.damage ?? 3;
  return { bonus: Math.max(1, Math.round(d * 0.6)), tier: m[1] };
}
export const ARMOR_TOUGHNESS: Record<string, number> = { diamond: 2, netherite: 3 };
/** Damage multiplier for a mob wearing `pts` armour points (vanilla: each point blocks 4 %, capped at 80 %). */
export const armorFactor = (pts: number) => 1 - Math.min(20, pts) * 0.04;
/** Java Edition armor + toughness damage formula: damage * (1 - min(20, max(def / 5, def - damage / (2 + toughness / 4))) / 25). */
export function armorDamage(rawDamage: number, defPts: number, toughness = 0): number {
  if (defPts <= 0) return rawDamage;
  const eff = Math.min(20, Math.max(defPts / 5, defPts - rawDamage / (2 + toughness / 4)));
  return Math.max(1, Math.round(rawDamage * (1 - eff / 25)));
}

const HEAD_DIRS: readonly [number, number][] = [[1, 0], [0, 1], [-1, 0], [0, -1]];

export class MobBehaviors {
  curBonus = 0;
  clouds: BreathCloud[] = [];
  private pendingBreath: { t: number; x: number; z: number }[] = [];
  private beds: BedSite[] = [];
  private bedScanAt = -999;
  private occupied = new Map<string, number>();
  private populated = new Set<string>();
  private structT = 0;
  private breathT = 3;
  private cloudGeo = new THREE.CircleGeometry(1, 28);

  constructor(private ctx: BehaviorCtx) {}

  reset() {
    for (const c of this.clouds) { this.ctx.scene.remove(c.mesh); (c.mesh.material as THREE.Material).dispose(); }
    this.clouds = []; this.pendingBreath = []; this.occupied.clear(); this.populated.clear(); this.beds = []; this.bedScanAt = -999;
  }

  bonusOf(m: Mob) { return (m as MobX).gear?.weaponBonus ?? 0; }
  armorOf(m: Mob) { return (m as MobX).gear?.armorPts.reduce((a, b) => a + b, 0) ?? 0; }
  toughnessOf(m: Mob) { return (m as MobX).gear?.armor.reduce((acc, n) => acc + (n ? (ARMOR_TOUGHNESS[armorInfo(n)?.tier ?? ''] ?? 0) : 0), 0) ?? 0; }

  // ------------------------------------------------------------------------------------------------------- climbing
  /** Sets m.dir towards a nearby ladder / vine when the target is clearly above the mob. Returns true when it took over steering. */
  approachClimb(m0: Mob, goal: THREE.Vector3): boolean {
    const m = m0 as MobX, p = m.group.position, host = this.ctx.host;
    if (FLY.has(m.species) || SWIM.has(m.species) || goal.y - p.y < ((m.species === 'spider' || m.species === 'cave_spider') ? 1.2 : 1.6) || Math.hypot(goal.x - p.x, goal.z - p.z) > 28) return false;
    if (m.sleeping) return false;
    // Spiders ignore detours: they walk straight at a target above them and climb whatever wall is in the way (see climb()).
    if (m.species === 'spider' || m.species === 'cave_spider') {
      m.dir = Math.atan2(-(goal.x - p.x), -(goal.z - p.z)); m.path = null;
      return true;
    }
    let best = Infinity, bx = 0, bz = 0;
    const fy = Math.floor(p.y);
    for (let dz = -6; dz <= 6; dz++) for (let dx = -6; dx <= 6; dx++) {
      const d = dx * dx + dz * dz; if (d >= best) continue;
      for (let dy = -1; dy <= 1; dy++) if (isClimbable(host.getBlock(Math.floor(p.x) + dx, fy + dy, Math.floor(p.z) + dz))) { best = d; bx = Math.floor(p.x) + dx + 0.5; bz = Math.floor(p.z) + dz + 0.5; break; }
    }
    if (best === Infinity) return false;
    m.dir = Math.atan2(-(bx - p.x), -(bz - p.z));
    m.path = null;
    return true;
  }

  /** Called from walk(): returns true while the mob is hanging on / moving along a climbable block (the normal walk step is skipped). */
  climb(m0: Mob, move: number, dt: number): boolean {
    const m = m0 as MobX, sp = m.species;
    if (FLY.has(sp) || SWIM.has(sp) || m.sleeping) return false;
    const p = m.group.position, host = this.ctx.host;
    const chasing = m.state === 'chase' || m.state === 'follow';
    const goal = chasing ? host.position : null;

    if (sp === 'spider' || sp === 'cave_spider') {
      // Spiders cling to any solid wall between them and a target above them, and hop over the edge at the top.
      const g = host.position;
      const wantUp = chasing && g.y > p.y + 0.6;
      const hd = Math.hypot(g.x - p.x, g.z - p.z) || 1, ux = (g.x - p.x) / hd, uz = (g.z - p.z) / hd;
      const solidAt = (x: number, y: number, z: number) => { const d = BLOCKS[host.getBlock(x, y, z)]; return d?.solid === true && !isThinPassableBlockName(d.name); };
      const touching = solidAt(p.x + ux * 0.6, p.y + 0.4, p.z + uz * 0.6) || solidAt(p.x - Math.sin(m.dir) * 0.6, p.y + 0.4, p.z - Math.cos(m.dir) * 0.6);
      if (wantUp && touching) { m.vy = 0; p.y += 2.6 * dt; m.climbing = true; return true; }
      if (m.climbing && wantUp) { m.climbing = false; p.x += ux * 0.75; p.z += uz * 0.75; m.vy = 0; return true; }
      m.climbing = false;
    }

    const cx = Math.floor(p.x), cz = Math.floor(p.z), fy = Math.floor(p.y + 0.1);
    const at = (y: number) => isClimbable(host.getBlock(cx, y, cz));
    const inside = at(fy) || at(fy + 1);
    if (!inside) {
      if (m.climbing && sp !== 'spider' && sp !== 'cave_spider') {
        // Reached the top of the ladder: step onto the neighbouring block that offers a floor
        m.climbing = false; m.vy = 0;
        const pref = goal ? Math.atan2(-(goal.x - p.x), -(goal.z - p.z)) : m.dir;
        const order = [0, 1, 2, 3].map(i => HEAD_DIRS[i]).sort((a, b) => Math.abs(Math.atan2(-a[0], -a[1]) - pref) - Math.abs(Math.atan2(-b[0], -b[1]) - pref));
        const y0 = Math.round(p.y);
        for (const [dx, dz] of order) {
          if (BLOCKS[host.getBlock(cx + dx, y0 - 1, cz + dz)]?.solid && host.getBlock(cx + dx, y0, cz + dz) <= 0 && host.getBlock(cx + dx, y0 + 1, cz + dz) <= 0) {
            p.set(cx + dx + 0.5, y0, cz + dz + 0.5);
            return true;
          }
        }
      }
      m.climbing = false;
      return false;
    }
    // Hanging on a climbable block
    m.climbing = true; m.vy = 0; m.path = null;
    // Keep climbing to the top of the ladder unless the target is clearly below (then climb down); idle mobs climb down.
    const want = goal ? (goal.y - p.y > -1.0 ? 1 : -1) : -1;
    if (want > 0) { p.y += 2.4 * dt; return true; }
    if (want < 0) {
      const below = host.getBlock(cx, Math.floor(p.y - 0.06), cz);
      if (BLOCKS[below]?.solid) { m.climbing = false; return false; }
      p.y -= 2.0 * dt; return true;
    }
    return true;
  }

  // ------------------------------------------------------------------------------------------------------- villagers
  private scanBeds(center: THREE.Vector3) {
    const host = this.ctx.host, out: BedSite[] = [];
    if (!host.getCell) { this.beds = out; return; }
    const R = 20, cx0 = Math.floor(center.x), cz0 = Math.floor(center.z), cy0 = Math.floor(center.y);
    for (let y = cy0 - 4; y <= cy0 + 4; y++) for (let z = cz0 - R; z <= cz0 + R; z++) for (let x = cx0 - R; x <= cx0 + R; x++) {
      if (host.getBlock(x, y, z) !== ID.bed) continue;
      const st = (host.getCell(x, y, z) >>> 12) & 15;
      if (st & 4) continue;
      const [hx, hz] = HEAD_DIRS[st & 3];
      if (host.getBlock(x + hx, y, z + hz) !== ID.bed) continue;
      out.push({ x, y, z, hx, hz });
    }
    this.beds = out;
    this.bedScanAt = this.ctx.timeline;
  }

  private bedKey(b: BedSite) { return b.x + ',' + b.y + ',' + b.z; }

  wake(m0: Mob) {
    const m = m0 as MobX;
    if (m.bed) this.occupied.delete(this.bedKey(m.bed));
    if (m.sleeping && m.bed) m.group.position.set(m.bed.x + 0.5 - m.bed.hx * 0.1, m.bed.y + 0.6, m.bed.z + 0.5 - m.bed.hz * 0.1);
    m.sleeping = false; m.slept = this.ctx.timeline; m.bed = null; m.bedT = 0;
    m.group.rotation.order = 'XYZ'; m.group.rotation.set(0, m.dir, 0);
  }

  /** Villager night routine. Returns true when the villager is busy sleeping / walking to bed (regular AI skipped). */
  sleepTick(m0: Mob, dt: number, daylight: number): boolean {
    const m = m0 as MobX, p = m.group.position, ctx = this.ctx;
    const wakeUp = daylight > 0.32 || m.hurtTimer > 0 || (m.panic ?? 0) > 0;
    if (m.sleeping) {
      if (wakeUp) { this.wake(m); return false; }
      m.swing = 0;
      return true;
    }
    if (daylight >= 0.22 || (m.panic ?? 0) > 0 || (m.bedBan ?? 0) > ctx.timeline) { if (m.bed) { this.occupied.delete(this.bedKey(m.bed)); m.bed = null; } return false; }
    if (!m.bed) {
      if (ctx.timeline - this.bedScanAt > 15) this.scanBeds(p);
      let best = 26 * 26, pick: BedSite | null = null;
      for (const b of this.beds) {
        const k = this.bedKey(b), owner = this.occupied.get(k);
        if (owner !== undefined && owner !== m.id) continue;
        const d = (b.x + 0.5 - p.x) ** 2 + (b.z + 0.5 - p.z) ** 2 + (b.y - p.y) ** 2 * 4;
        if (d < best) { best = d; pick = b; }
      }
      if (!pick) return false;
      m.bed = pick; m.bedT = 0; this.occupied.set(this.bedKey(pick), m.id);
    }
    const b = m.bed;
    const gx = b.x + 0.5, gz = b.z + 0.5, d = Math.hypot(gx - p.x, gz - p.z);
    m.bedT = (m.bedT ?? 0) + dt;
    if (d < 1.15 && Math.abs(p.y - b.y) < 1.6) {
      m.sleeping = true; m.path = null; m.state = 'wander'; m.vy = 0;
      p.set(gx - b.hx * 0.3, b.y + 0.78, gz - b.hz * 0.3);
      m.group.rotation.order = 'YXZ';
      m.group.rotation.set(Math.PI / 2, Math.atan2(b.hx, b.hz), 0);
      return true;
    }
    if ((m.bedT ?? 0) > 45) { this.occupied.delete(this.bedKey(b)); m.bed = null; m.bedBan = ctx.timeline + 60; return false; }
    m.dir = Math.atan2(-(gx - p.x), -(gz - p.z));
    ctx.steer(m, new THREE.Vector3(gx, b.y + 0.2, gz));
    ctx.walk(m, m.speed * 1.2, dt, false);
    m.group.rotation.y = m.dir;
    return true;
  }

  /** Panic: villagers run from zombies and illagers within 9 blocks; panicking groups call an iron golem. Returns true when fleeing. */
  panicTick(m0: Mob, dt: number): boolean {
    const m = m0 as MobX, ctx = this.ctx, p = m.group.position;
    m.panic = Math.max(0, (m.panic ?? 0) - dt);
    let threat: Mob | null = null, best = 81;
    for (const o of ctx.mobs) {
      if (!THREATS.has(o.species)) continue;
      const d = (o.group.position.x - p.x) ** 2 + (o.group.position.y - p.y) ** 2 + (o.group.position.z - p.z) ** 2;
      if (d < best) { best = d; threat = o; }
    }
    if (threat) {
      if (m.panic === 0) ctx.host.particles.spark?.(p.clone().setY(p.y + 1.9), '#c0392b', 4);
      m.panic = 8;
      m.state = 'flee'; m.timer = 1.2;
      m.dir = Math.atan2(-(p.x - threat.group.position.x), -(p.z - threat.group.position.z)) + (ctx.rnd() - 0.5) * 0.6;
    }
    // Golem summoning check (vanilla: >=3 villagers around, one of them slept recently; panic accelerates it)
    m.golemT = (m.golemT ?? 3 + ctx.rnd() * 3) - dt;
    if (m.golemT <= 0) {
      m.golemT = 3;
      const slept = m.slept !== undefined && ctx.timeline - m.slept < 600;
      if (m.panic > 0 || slept) this.trySpawnGolem(m, m.panic > 0 ? 0.5 : 0.02);
    }
    return m.panic > 0;
  }

  trySpawnGolem(m: MobX, chance: number): Mob | null {
    const ctx = this.ctx, p = m.group.position;
    let villagers = 0;
    for (const o of ctx.mobs) {
      const d = o.group.position.distanceTo(p);
      if (o.species === 'iron_golem' && d < 28) return null;
      if (o.species === 'villager' && d < 16 && !o.baby) villagers++;
    }
    if (villagers < 3 || ctx.rnd() > chance) return null;
    const get = (x: number, y: number, z: number) => ctx.host.getBlock(x, y, z);
    for (let i = 0; i < 12; i++) {
      const x = p.x + (ctx.rnd() - 0.5) * 12, z = p.z + (ctx.rnd() - 0.5) * 12;
      const gy = groundAt(get, Math.floor(x), Math.floor(p.y + 0.01), Math.floor(z), 5);
      if (Number.isNaN(gy) || Math.abs(gy - p.y) > 4) continue;
      let free = true;
      for (let dy = 0; dy < 3 && free; dy++) if (get(Math.floor(x), Math.floor(gy) + dy, Math.floor(z)) > 0) free = false;
      if (!free) continue;
      const g = ctx.spawn('iron_golem', x, z, false, gy);
      if (!g) continue;
      ctx.host.particles.burst(g.group.position.clone().setY(g.group.position.y + 1), '#d8d8d8', 22, 2);
      ctx.host.sound('golem_summon', g.group.position);
      ctx.host.toast('村人たちの危機にアイアンゴーレムが現れた！', 'An iron golem appeared to defend the village!');
      return g;
    }
    return null;
  }

  // ------------------------------------------------------------------------------------------------------- equipment
  canLoot(m: Mob) { return LOOTERS.has(m.species) && !m.baby; }

  private wantsItem(m: MobX, name: string): boolean {
    const a = armorInfo(name);
    if (a) return a.pts > (m.gear?.armorPts[a.slot] ?? 0);
    const w = weaponInfo(name);
    return !!w && w.bonus > (m.gear?.weaponBonus ?? 0);
  }

  /** Every ~0.8 s a looting mob picks the nearest useful armour / weapon item lying within 2.6 blocks. Returns the item picked up. */
  lootTick(m0: Mob, dt: number): string | null {
    const m = m0 as MobX;
    m.lootT = (m.lootT ?? this.ctx.rnd()) - dt;
    if (m.lootT > 0 || !this.canLoot(m) || !this.ctx.host.particles.takeNear) return null;
    m.lootT = 0.8;
    const got = this.ctx.host.particles.takeNear(m.group.position, 2.6, n => this.wantsItem(m, n));
    if (!got) return null;
    this.equip(m, got.name);
    return got.name;
  }

  equip(m0: Mob, name: string, trim?: { pattern: string; material: string }) {
    const m = m0 as MobX, ctx = this.ctx;
    if (!m.gear) m.gear = { armor: [null, null, null, null], armorPts: [0, 0, 0, 0], weapon: null, weaponBonus: 0, meshes: [] };
    if (!m.gearBox) {
      const saveRot = m.group.rotation.clone();
      m.group.rotation.set(0, 0, 0); m.group.updateMatrixWorld(true);
      const box = rigBounds(m.group);
      m.group.rotation.copy(saveRot); m.group.updateMatrixWorld(true);
      const s = m.group.scale.x || 1, o = m.group.position;
      m.gearBox = new THREE.Box3(new THREE.Vector3((box.min.x - o.x) / s, (box.min.y - o.y) / s, (box.min.z - o.z) / s), new THREE.Vector3((box.max.x - o.x) / s, (box.max.y - o.y) / s, (box.max.z - o.z) / s));
    }
    const g = m.gear, a = armorInfo(name), w = weaponInfo(name);
    const dropOld = (old: string | null) => { if (old) ctx.host.particles.drop(m.group.position.clone().setY(m.group.position.y + 0.6), old, 1, TIER_COLORS[(armorInfo(old) ?? weaponInfo(old))?.tier ?? 'iron'] ?? '#ccc'); };
    const box = m.gearBox, size = new THREE.Vector3(), c = new THREE.Vector3();
    box.getSize(size); box.getCenter(c);
    const addMesh = (color: string, sx: number, sy: number, sz: number, x: number, y: number, z: number, parent: THREE.Object3D = m.group) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), new THREE.MeshLambertMaterial({ color }));
      mesh.position.set(x, y, z); mesh.castShadow = true; parent.add(mesh); g.meshes.push(mesh); return mesh;
    };
    if (a) {
      dropOld(g.armor[a.slot]);
      g.armor[a.slot] = name; g.armorPts[a.slot] = a.pts;
      const col = TIER_COLORS[a.tier] ?? '#ccc', H = size.y, W = Math.min(size.x, H * 0.6), D = Math.max(0.3, Math.min(size.z, H * 0.3));
      const old = g.meshes.filter(o => o.userData.slot === a.slot);
      for (const o of old) { o.parent?.remove(o); g.meshes.splice(g.meshes.indexOf(o), 1); }
      let mesh: THREE.Mesh;
      if (a.slot === 0) { const hs = H * 0.27; mesh = addMesh(col, hs, hs * 0.55, hs, c.x, box.min.y + H * 0.9, c.z); }
      else if (a.slot === 1) mesh = addMesh(col, W * 0.9, H * 0.34, D * 1.15, c.x, box.min.y + H * 0.58, c.z);
      else if (a.slot === 2) mesh = addMesh(col, W * 0.82, H * 0.3, D * 1.05, c.x, box.min.y + H * 0.34, c.z);
      else mesh = addMesh(col, W * 0.84, H * 0.1, D * 1.2, c.x, box.min.y + H * 0.06, c.z);
      mesh.userData.slot = a.slot;
      if (trim && TRIM_MAT_BY_ID[trim.material]) {
        const tcol = TRIM_MAT_BY_ID[trim.material].color;
        const tmesh = addMesh(tcol, mesh.scale.x * 1.03, mesh.scale.y * 0.45, mesh.scale.z * 1.03, mesh.position.x, mesh.position.y, mesh.position.z);
        tmesh.userData.slot = a.slot;
      }
    } else if (w) {
      dropOld(g.weapon);
      for (const o of g.meshes.filter(o => o.userData.weapon)) { o.parent?.remove(o); g.meshes.splice(g.meshes.indexOf(o), 1); }
      g.weapon = name; g.weaponBonus = w.bonus;
      const arm = m.limbs?.find(l => l.kind === 'arm')?.node;
      const blade = addMesh(TIER_COLORS[w.tier] ?? '#ccc', 0.07, 0.07, 0.62, 0, -0.5, -0.36, arm ?? m.group);
      if (!arm) blade.position.set(size.x * 0.55, box.min.y + size.y * 0.55, -0.3);
      blade.userData.weapon = true;
    }
    ctx.host.particles.burst(m.group.position.clone().setY(m.group.position.y + 1.2), '#ffe27a', 8, 1);
    ctx.host.sound('equip', m.group.position);
  }

  onKill(m0: Mob) {
    const m = m0 as MobX;
    if (m.sleeping || m.bed) this.wake(m);
    // Vanilla (loot table entities/creeper, condition killed_by #skeletons): only when a skeleton-type mob dealt the killing blow.
    // 作業B: was "any skeleton within 14 blocks"; now uses the killer recorded by damageMob / projectile hits.
    const killer = (m0 as { lastAttacker?: string }).lastAttacker;
    if (m.species === 'creeper' && (killer === 'skeleton' || killer === 'stray' || killer === 'bogged' || killer === 'wither_skeleton')) {
      const d = MUSIC_DISCS[Math.floor(this.ctx.rnd() * MUSIC_DISCS.length)];
      this.ctx.host.particles.drop(m.group.position.clone().setY(m.group.position.y + 0.6), d.name, 1, d.color);
    }
    if (!m.gear) return;
    const pos = m.group.position.clone().setY(m.group.position.y + 0.6);
    for (const n of [...m.gear.armor, m.gear.weapon]) if (n) this.ctx.host.particles.drop(pos, n, 1, TIER_COLORS[(armorInfo(n) ?? weaponInfo(n))?.tier ?? 'iron'] ?? '#ccc');
  }

  // ------------------------------------------------------------------------------------------------------- structures
  private waterY(x: number, y0: number, z: number, y1: number): number | null {
    const host = this.ctx.host;
    for (let y = y0; y <= y1; y++) if (host.getBlock(x, y, z) === ID.water && host.getBlock(x, y + 1, z) === ID.water) return y;
    return null;
  }

  private populateStructures() {
    const ctx = this.ctx, host = ctx.host;
    if (host.dimension !== 'overworld') return;
    const px = host.position.x, pz = host.position.z;
    const mon = locateExtra(host.terrain, 'monument', px, pz);
    if (mon && Math.hypot(mon[0] - px, mon[2] - pz) < 72) {
      const key = 'monument:' + mon[0] + ',' + mon[2];
      if (!this.populated.has(key) && host.getBlock(mon[0], mon[1] + 4, mon[2]) >= 0) {
        this.populated.add(key);
        const elders = [[0, 0], [-13, 0], [13, 0], [0, 13], [0, -13], [-9, 9], [9, -9], [9, 9], [-9, -9]];
        let placed = 0;
        for (const [dx, dz] of elders) {
          if (placed >= 3) break;
          const y = this.waterY(mon[0] + dx, mon[1] + 1, mon[2] + dz, mon[1] + 14);
          if (y === null) continue;
          const e = ctx.spawn('elder_guardian', mon[0] + dx + 0.5, mon[2] + dz + 0.5, false, y + 0.5);
          if (e) { (e as MobX).structure = true; placed++; }
        }
        for (let i = 0, tries = 0; i < 8 && tries < 40; tries++) {
          const dx = Math.floor((ctx.rnd() - 0.5) * 34), dz = Math.floor((ctx.rnd() - 0.5) * 34);
          const y = this.waterY(mon[0] + dx, mon[1] + 1, mon[2] + dz, mon[1] + 14);
          if (y === null) continue;
          const g = ctx.spawn('guardian', mon[0] + dx + 0.5, mon[2] + dz + 0.5, false, y + 0.5);
          if (g) { (g as MobX).structure = true; i++; }
        }
      }
    }
    const ig = locateExtra(host.terrain, 'igloo', px, pz);
    if (ig && Math.hypot(ig[0] - px, ig[2] - pz) < 48) {
      const key = 'igloo:' + ig[0] + ',' + ig[2], G = iglooParts(host.terrain.seed, { x: ig[0], y: ig[1], z: ig[2] });
      if (G.basement && !this.populated.has(key) && host.getBlock(G.villager[0], G.villager[1], G.villager[2]) >= 0) {
        this.populated.add(key);
        // Wiki: the basement cells hold a (cleric) villager and a zombie villager waiting to be cured.
        for (const [sp, c] of [['villager', G.villager], ['zombie_villager', G.zombieVillager]] as const) {
          const e = ctx.spawn(sp as Species, c[0] + 0.5, c[2] + 0.5, false, c[1]);
          if (e) (e as MobX).structure = true;
        }
      }
    }
    const man = locateExtra(host.terrain, 'mansion', px, pz);
    if (man && Math.hypot(man[0] - px, man[2] - pz) < 72) {
      const key = 'mansion:' + man[0] + ',' + man[2];
      if (!this.populated.has(key) && host.getBlock(man[0], man[1] + 2, man[2]) >= 0) {
        this.populated.add(key);
        const kinds: Species[] = ['evoker', 'evoker', 'vindicator', 'vindicator', 'vindicator', 'vindicator'];
        for (const sp of kinds) {
          for (let tries = 0; tries < 30; tries++) {
            const x = man[0] + Math.floor((ctx.rnd() - 0.5) * 22), z = man[2] + Math.floor((ctx.rnd() - 0.5) * 22);
            let y = -999;
            for (let yy = man[1] - 1; yy <= man[1] + 9; yy++) if (BLOCKS[host.getBlock(x, yy - 1, z)]?.solid && host.getBlock(x, yy, z) === 0 && host.getBlock(x, yy + 1, z) === 0) { y = yy; break; }
            if (y === -999) continue;
            const e = ctx.spawn(sp, x + 0.5, z + 0.5, false, y);
            if (e) { (e as MobX).structure = true; break; }
          }
        }
      }
    }
  }

  // ------------------------------------------------------------------------------------------------------- dragon breath
  spawnBreathCloud(x: number, y: number, z: number, radius = 3, life = 30) {
    if (this.clouds.length > 12) { const old = this.clouds.shift()!; this.ctx.scene.remove(old.mesh); }
    const mat = new THREE.MeshBasicMaterial({ color: '#b04be0', transparent: true, opacity: 0.5, depthWrite: false, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(this.cloudGeo, mat);
    mesh.rotation.x = -Math.PI / 2; mesh.position.set(x, y + 0.06, z); mesh.scale.setScalar(radius);
    this.ctx.scene.add(mesh);
    const c: BreathCloud = { pos: new THREE.Vector3(x, y, z), radius, life, maxLife: life, mesh, hurt: 0.5, spark: 0 };
    this.clouds.push(c);
    return c;
  }

  /** Right-click with a glass bottle: collects the cloud the player is aiming at (each bottle shrinks it by 0.5). */
  collectBreath(origin: THREE.Vector3, dir: THREE.Vector3): boolean {
    let best: BreathCloud | null = null, bd = Infinity;
    for (const c of this.clouds) {
      if (c.radius <= 0.2) continue;
      // intersect the view ray with the cloud plane
      const t = dir.y < -0.01 ? (c.pos.y + 0.1 - origin.y) / dir.y : -1;
      let d: number;
      if (t > 0 && t < 7) d = Math.hypot(origin.x + dir.x * t - c.pos.x, origin.z + dir.z * t - c.pos.z);
      else d = Math.hypot(origin.x - c.pos.x, origin.z - c.pos.z);
      if (d <= c.radius + 0.6 && origin.distanceTo(c.pos) < 8 && d < bd) { bd = d; best = c; }
    }
    if (!best) return false;
    best.radius -= 0.5;
    best.mesh.scale.setScalar(Math.max(0.01, best.radius));
    if (best.radius <= 0.2) best.life = 0;
    this.ctx.host.sound('bottle_fill', best.pos);
    return true;
  }

  private updateClouds(dt: number) {
    const ctx = this.ctx, host = ctx.host;
    for (let i = this.clouds.length - 1; i >= 0; i--) {
      const c = this.clouds[i];
      c.life -= dt;
      // vanilla: the cloud shrinks as it ages
      const target = 3 * Math.max(0, c.life / c.maxLife);
      if (c.radius > target) c.radius = Math.max(0, c.radius - dt * 0.12);
      c.mesh.scale.setScalar(Math.max(0.01, c.radius));
      (c.mesh.material as THREE.MeshBasicMaterial).opacity = 0.35 + 0.15 * Math.sin(ctx.timeline * 4 + i);
      if (c.life <= 0 || c.radius <= 0.2) {
        ctx.scene.remove(c.mesh); (c.mesh.material as THREE.Material).dispose(); this.clouds.splice(i, 1); continue;
      }
      c.spark -= dt;
      if (c.spark <= 0) {
        c.spark = 0.18;
        const a = ctx.rnd() * 6.283, r = Math.sqrt(ctx.rnd()) * c.radius;
        host.particles.spark?.(new THREE.Vector3(c.pos.x + Math.cos(a) * r, c.pos.y + 0.3, c.pos.z + Math.sin(a) * r), '#e08cff', 1);
      }
      c.hurt -= dt;
      if (c.hurt <= 0) {
        c.hurt = 0.6;
        if (Math.hypot(host.position.x - c.pos.x, host.position.z - c.pos.z) < c.radius && Math.abs(host.position.y - c.pos.y) < 2.2) host.damage(2);
        for (const m of ctx.mobs) {
          if (m.species === 'dragon' || m.species === 'enderman' || m.species === 'shulker') continue;
          if (Math.hypot(m.group.position.x - c.pos.x, m.group.position.z - c.pos.z) < c.radius && Math.abs(m.group.position.y - c.pos.y) < 2) ctx.damageMob(m, 2);
        }
      }
    }
  }

  // ------------------------------------------------------------------------------------------------------- per-frame
  update(dt: number) {
    const ctx = this.ctx, host = ctx.host;
    this.updateClouds(dt);
    for (let i = this.pendingBreath.length - 1; i >= 0; i--) {
      const b = this.pendingBreath[i]; b.t -= dt;
      if (b.t <= 0) { this.pendingBreath.splice(i, 1); const y = host.terrain.height(Math.floor(b.x), Math.floor(b.z)) + 1; this.spawnBreathCloud(b.x, y, b.z); }
    }
    const dragon = ctx.mobs.find(m => m.species === 'dragon');
    if (dragon && host.dimension === 'end') {
      this.breathT -= dt;
      if (dragon.state === 'perch' && this.breathT <= 0 && Math.hypot(host.position.x, host.position.z) < 48) {
        this.breathT = 5;
        this.pendingBreath.push({ t: 1.3, x: host.position.x + (ctx.rnd() - 0.5) * 3, z: host.position.z + (ctx.rnd() - 0.5) * 3 });
        host.particles.burst(dragon.group.position.clone().setY(dragon.group.position.y + 1.2), '#d966ff', 26, 3);
        host.sound('dragon_breath', dragon.group.position);
      }
    }
    this.structT -= dt;
    if (this.structT <= 0) { this.structT = 4; this.populateStructures(); }
    // Mob voices: every mob near the player speaks now and then (species specific sound, see audio/sound.ts)
    for (const m0 of ctx.mobs) {
      const m = m0 as MobX;
      m.sayT = (m.sayT ?? 4 + ctx.rnd() * 12) - dt;
      if (m.sayT > 0) continue;
      m.sayT = 8 + ctx.rnd() * 14;
      if (m.group.position.distanceToSquared(host.position) > 28 * 28 || m.species === 'dragon') continue;
      host.sound((m.sleeping ? 'snore:' : 'say:') + m.species, m.group.position);
    }
  }
}

// ============================================================================
// 1.21 Species-Specific Behaviours & Status Effects
// ============================================================================
// Species-specific behaviour added with the dungeon / 1.21 pass. Lives next to MobManager (which owns models, physics and the generic
// AI) and is driven through a handful of hooks: `pre` (per-mob tick, may take over the mob for this frame), `modifyDamage`, `onDeath`,
// `interact`, `dodgeProjectile`, `creeperExplode` and `lightning`.
//
// Nothing here draws: behaviours only set the flags documented in game/events.ts and emit events through `host.emit`.
import type { MobManager } from './mobs';
import {
  mobArmor, damageAfterArmor, INFESTED_CHANCE, infestedCount, OOZING_SLIMES, weavingCount, cobwebSpots, windKnockback,
  WIND_CHARGED_RADIUS, creeperRadius, explosionDamage, MOB_HEADS, LIGHTNING_CHARGE_RADIUS, EFFECTS_121,
} from '../systems/combat121';

const idSet = (names: string[]) => new Set(names.map(n => (ID as Record<string, number | undefined>)[n]).filter((v): v is number => v !== undefined));
const lazy = (names: string[]) => { let s: Set<number> | null = null; return () => (s ??= idSet(names)); };
/** Blocks an enderman may pick up (vanilla `enderman_holdable`). */
export const HOLDABLE = lazy(['grass_block', 'dirt', 'coarse_dirt', 'podzol', 'mycelium', 'sand', 'red_sand', 'gravel', 'clay', 'cactus', 'pumpkin', 'melon', 'tnt', 'dandelion', 'poppy', 'blue_orchid', 'allium', 'azure_bluet', 'cornflower', 'oxeye_daisy', 'lily_of_the_valley', 'red_tulip', 'orange_tulip', 'white_tulip', 'pink_tulip', 'red_mushroom', 'brown_mushroom', 'crimson_nylium', 'warped_nylium', 'crimson_fungus', 'warped_fungus', 'crimson_roots', 'warped_roots', 'moss_block', 'mud', 'rooted_dirt']);
export const FLOWERS = lazy(['dandelion', 'poppy', 'blue_orchid', 'allium', 'azure_bluet', 'cornflower', 'oxeye_daisy', 'lily_of_the_valley', 'red_tulip', 'orange_tulip', 'white_tulip', 'pink_tulip', 'sunflower', 'torchflower', 'pitcher_plant', 'flowering_azalea', 'pink_petals', 'spore_blossom', 'cherry_leaves', 'flowering_azalea_leaves']);
export const HIVES = lazy(['bee_nest', 'beehive']);
export const BEE_CROPS = lazy(['wheat_crop', 'carrots', 'potatoes', 'beetroots', 'melon_stem', 'pumpkin_stem', 'sweet_berry_bush']);
const SAND = lazy(['sand', 'beach_sand', 'red_sand']);
/** Blocks a sniffer can dig in (vanilla `sniffer_diggable_block`). */
export const DIGGABLE = lazy(['grass_block', 'dirt', 'coarse_dirt', 'podzol', 'rooted_dirt', 'moss_block', 'mud', 'muddy_mangrove_roots']);

export const ENDERMAN_PICK_CHANCE = 0.05;
export const ENDERMAN_PLACE_CHANCE = 0.08;
export const TURTLE_DIG_TIME = 4;
export const TURTLE_HOME_RANGE = 24;
export const EGG_NIGHT_CHANCE = 1 / 20;
export const EGG_DAY_CHANCE = 1 / 240;
export const BEE_SPEED = 2.6;
export const BEE_POLLINATE_TIME = 3;
export const BEE_HIVE_TIME = 12;
export const BEE_MAX_CROPS = 10;
export const HIVE_MAX_HONEY = 5;
export const ALLAY_RANGE = 16;
export const ALLAY_SPEED = 3.4;
export const ALLAY_NOTE_MEMORY = 30;
export const SNIFFER_DIG_TIME = 4.5;
export const SNIFFER_COOLDOWN = 90;
export const WOLF_ARMOR_HP = 64;
const SAVED = ['charged', 'carried', 'fx', 'bonusArmor', 'trial', 'ominous', 'hive', 'nectar', 'home', 'pregnant', 'wanted', 'heldCount', 'wolfArmor', 'maps', 'dug'] as const;

/** A random tick of a turtle egg block (cell state: bits 0-1 = eggs-1, bits 2-3 = crack stage). Eggs crack far faster at night. */
export function tickTurtleEgg(state: number, night: boolean, rng: () => number): { state: number; hatch: number } {
  if (rng() >= (night ? EGG_NIGHT_CHANCE : EGG_DAY_CHANCE)) return { state, hatch: 0 };
  const eggs = (state & 3) + 1, crack = (state >> 2) & 3;
  if (crack >= 2) return { state: 0, hatch: eggs };
  return { state: (state & 3) | ((crack + 1) << 2), hatch: 0 };
}
/** A lit campfire within five blocks below a hive (with nothing solid in between) keeps the bees calm while it is harvested. */
export function campfireBelow(get: (x: number, y: number, z: number) => number, x: number, y: number, z: number): boolean {
  const camp = (ID as Record<string, number | undefined>).campfire;
  if (camp === undefined) return false;
  for (let dy = 1; dy <= 5; dy++) {
    const id = get(x, y - dy, z);
    if (id === camp || (ID.soul_campfire !== undefined && id === ID.soul_campfire)) return true;
    if (id !== 0 && BLOCKS[id]?.solid) return false;
  }
  return false;
}

export class Behaviors {
  /** Breach level of the weapon used for the current melee hit (set by the player's attack code, like `MobManager.looting`). */
  breach = 0;

  constructor(private mgr: MobManager) {}
  private get host() { return this.mgr.host; }
  private rnd() { return this.mgr.rnd(); }
  private solid(x: number, y: number, z: number) { const id = this.host.getBlock(x, y, z); return id > 0 && !!BLOCKS[id]?.solid; }
  private drop(m: Mob, name: string, count: number, dy = 0.5) {
    const def = resolve(name);
    if (def && count > 0) this.host.particles.drop(m.group.position.clone().add(new THREE.Vector3(0, dy, 0)), name, count, def.color || '#b88b65');
  }
  /** Feet level of the first standable spot (3 blocks of headroom) in the column, searched around `y`. */
  private floorY(x: number, y: number, z: number): number | null {
    for (let yy = Math.floor(y) + 4; yy >= Math.floor(y) - 8; yy--) {
      if (this.solid(x, yy - 1, z) && !this.solid(x, yy, z) && !this.solid(x, yy + 1, z) && !this.solid(x, yy + 2, z)) return yy;
    }
    return null;
  }
  private skyExposed(x: number, y: number, z: number) {
    for (let yy = Math.floor(y); yy < Math.floor(y) + 40; yy++) { const id = this.host.getBlock(x, yy, z); if (id > 0 && id !== ID.water) return false; }
    return true;
  }
  /** Nearest block whose id is in `set` inside a (2r+1)·(2ry+1)·(2r+1) box around `p`. */
  findBlock(set: Set<number>, p: THREE.Vector3, r: number, ry: number): [number, number, number] | null {
    const bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z), h = this.host;
    let best: [number, number, number] | null = null, bestD = Infinity;
    for (let dy = -ry; dy <= ry; dy++) for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
      const d = dx * dx + dy * dy + dz * dz;
      if (d < bestD && set.has(h.getBlock(bx + dx, by + dy, bz + dz))) { bestD = d; best = [bx + dx, by + dy, bz + dz]; }
    }
    return best;
  }
  private flyTo(m: Mob, tx: number, ty: number, tz: number, speed: number, dt: number): number {
    const p = m.group.position, dx = tx - p.x, dy = ty - p.y, dz = tz - p.z, d = Math.hypot(dx, dy, dz);
    if (d > 0.001) {
      const s = Math.min(d, speed * dt) / d;
      p.x += dx * s; p.y += dy * s; p.z += dz * s;
      if (Math.hypot(dx, dz) > 0.05) m.dir = Math.atan2(-dx, -dz);
    }
    return d;
  }

  // ===== per-mob tick =====================================================================================================
  /** Returns true when the behaviour fully drove the mob this frame (the generic AI is skipped). */
  pre(m: Mob, dt: number, daylight: number): boolean {
    if (m.fx) for (const k of Object.keys(m.fx)) { m.fx[k] -= dt; if (m.fx[k] <= 0) delete m.fx[k]; }
    if (m.wasBaby === undefined) m.wasBaby = m.baby;
    else if (m.wasBaby && !m.baby) {
      m.wasBaby = false;
      if (m.species === 'turtle') this.drop(m, 'scute', 1);                 // a baby turtle sheds a scute when it grows up
    }
    switch (m.species) {
      case 'enderman': return this.enderman(m, dt);
      case 'turtle': return this.turtle(m, dt);
      case 'bee': return this.bee(m, dt, daylight);
      case 'allay': return this.allay(m, dt);
      case 'sniffer': return this.sniffer(m, dt);
      case 'armadillo': this.armadillo(m, dt); return false;
      default: return false;
    }
  }

  // ---- Enderman ---------------------------------------------------------------------------------------------------------
  private enderman(m: Mob, dt: number): boolean {
    const h = this.host, p = m.group.position;
    m.bt = (m.bt ?? 0) - dt;
    if (m.bt <= 0) {
      m.bt = 0.5;
      const inWater = h.getBlock(p.x, p.y + 0.2, p.z) === ID.water || h.getBlock(p.x, p.y + 2.2, p.z) === ID.water;
      const rained = !inWater && h.dimension === 'overworld' && !!h.raining?.() && this.skyExposed(p.x, p.y + 2.9, p.z);
      if (inWater || rained) {
        m.hp -= 1;
        m.hurtTimer = 0.24;
        this.teleport(m, inWater ? 'water' : 'rain');
        if (m.hp <= 0) { this.mgr.kill(m); return true; }
      }
    }
    if (m.state === 'wander' || m.state === 'graze') {
      m.bt2 = (m.bt2 ?? 2) - dt;
      if (m.bt2 <= 0) { m.bt2 = 2; this.endermanBlock(m); }
    }
    return false;
  }
  /** Random teleport to dry, standable ground within 16 blocks (covered ground while it rains). */
  teleport(m: Mob, cause: 'water' | 'rain' | 'projectile'): boolean {
    const h = this.host, p = m.group.position, raining = h.dimension === 'overworld' && !!h.raining?.();
    let spot: [number, number, number] | null = null;
    for (let i = 0; i < 24; i++) {
      const x = p.x + (this.rnd() - 0.5) * 32, z = p.z + (this.rnd() - 0.5) * 32, y = this.floorY(x, p.y + (this.rnd() - 0.5) * 8, z);
      if (y === null || Math.hypot(x - p.x, z - p.z) < 3) continue;
      if (h.getBlock(x, y, z) === ID.water || h.getBlock(x, y + 1, z) === ID.water || h.getBlock(x, y - 1, z) === ID.water) continue;
      if (raining && this.skyExposed(x, y + 2.9, z)) { spot ??= [x, y, z]; continue; }
      spot = [x, y, z];
      break;
    }
    if (!spot) return false;
    h.particles.burst(p.clone().add(new THREE.Vector3(0, 1.4, 0)), '#a780cf', 18);
    p.set(spot[0], spot[1], spot[2]);
    m.path = null;
    h.particles.burst(p.clone().add(new THREE.Vector3(0, 1.4, 0)), '#a780cf', 18);
    h.sound('portal', p);
    h.emit?.('enderman_teleport', { x: p.x, y: p.y, z: p.z, mobId: m.id, cause });
    return true;
  }
  /**
   * Picks up a holdable block within two blocks of the enderman, or sets the carried one down on a free spot next to it.
   * `force` skips the random roll (used by tests and scripted events).
   */
  endermanBlock(m: Mob, force = false): boolean {
    const h = this.host, p = m.group.position, bx = Math.floor(p.x), by = Math.floor(p.y + 0.01), bz = Math.floor(p.z);
    if (!h.setBlock) return false;
    const spots: [number, number, number][] = [];
    if (!m.carried) {
      if (!force && this.rnd() > ENDERMAN_PICK_CHANCE) return false;
      for (let dy = -1; dy <= 1; dy++) for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
        if (dx === 0 && dz === 0 && dy < 0) continue;                                    // never the block it is standing on
        if (HOLDABLE().has(h.getBlock(bx + dx, by + dy, bz + dz))) spots.push([bx + dx, by + dy, bz + dz]);
      }
      if (!spots.length) return false;
      const [x, y, z] = spots[Math.floor(this.rnd() * spots.length) % spots.length], id = h.getBlock(x, y, z);
      if (!h.setBlock(x, y, z, 0)) return false;
      m.carried = id;
      h.emit?.('enderman_block', { x, y, z, mobId: m.id, block: id, action: 'pick' });
      return true;
    }
    if (!force && this.rnd() > ENDERMAN_PLACE_CHANCE) return false;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      if ((dx || dz) && h.getBlock(bx + dx, by, bz + dz) === 0 && this.solid(bx + dx, by - 1, bz + dz)) spots.push([bx + dx, by, bz + dz]);
    }
    if (!spots.length) return false;
    const [x, y, z] = spots[Math.floor(this.rnd() * spots.length) % spots.length];
    if (!h.setBlock(x, y, z, m.carried)) return false;
    h.emit?.('enderman_block', { x, y, z, mobId: m.id, block: m.carried, action: 'place' });
    m.carried = undefined;
    return true;
  }
  /** Arrows, tridents and snowballs never hit an enderman: it teleports away and the projectile flies on. */
  dodgeProjectile(m: Mob): boolean {
    if (m.species !== 'enderman') return false;
    this.teleport(m, 'projectile');
    m.state = 'chase';
    m.timer = 4;
    return true;
  }

  // ---- Turtle -----------------------------------------------------------------------------------------------------------
  private findSand(p: THREE.Vector3): [number, number, number] | null {
    const s = this.findBlock(SAND(), p, 6, 3);
    return s ? [s[0], s[1] + 1, s[2]] : null;
  }
  private turtle(m: Mob, dt: number): boolean {
    const p = m.group.position;
    if (!m.home) m.home = this.findSand(p) ?? [Math.floor(p.x), Math.floor(p.y), Math.floor(p.z)];   // the beach it was born on
    const [hx, hy, hz] = m.home, dx = hx + 0.5 - p.x, dz = hz + 0.5 - p.z, d = Math.hypot(dx, dz);
    if (m.digging) {
      m.digTimer = (m.digTimer ?? 0) - dt;
      this.mgr.walk(m, 0, dt, false);
      if (m.digTimer <= 0) { m.digging = false; this.layEggs(m); }
      return true;
    }
    if (m.pregnant || (d > TURTLE_HOME_RANGE && !m.leashed && m.love <= 0)) {                             // homing instinct
      if (m.pregnant && d < 1.6 && Math.abs(p.y - hy) < 3) { m.digging = true; m.digTimer = TURTLE_DIG_TIME; return true; }
      if (!m.pregnant && d < TURTLE_HOME_RANGE * 0.5) return false;
      m.dir = Math.atan2(-dx, -dz);
      m.state = 'wander';
      this.mgr.walk(m, m.speed * 1.3, dt, false);
      return true;
    }
    return false;
  }
  /** Lays 1–4 eggs on the sand of the home beach. */
  layEggs(m: Mob): boolean {
    const h = this.host, p = m.group.position, egg = (ID as Record<string, number | undefined>).turtle_egg;
    m.pregnant = false;
    if (!h.setBlock || egg === undefined) return false;
    const bx = Math.floor(p.x), by = Math.floor(p.y + 0.01), bz = Math.floor(p.z);
    for (const [dx, dz] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]]) for (let dy = 1; dy >= -2; dy--) {
      const x = bx + dx, y = by + dy, z = bz + dz, here = h.getBlock(x, y, z);
      if ((here !== 0 && here !== ID.water) || !SAND().has(h.getBlock(x, y - 1, z))) continue;
      const eggs = 1 + Math.floor(this.rnd() * 4);
      if (!h.setBlock(x, y, z, egg, eggs - 1)) continue;
      m.home = [x, y, z];
      h.emit?.('turtle_lay', { x, y, z, eggs });
      return true;
    }
    return false;
  }

  // ---- Bee --------------------------------------------------------------------------------------------------------------
  private bee(m: Mob, dt: number, daylight: number): boolean {
    const h = this.host, p = m.group.position;
    if (m.anger > 0) { m.pollinating = false; if (m.inHive) this.leaveHive(m, false); return false; }
    if (m.hive && !HIVES().has(h.getBlock(m.hive[0], m.hive[1], m.hive[2]))) { if (m.inHive) this.leaveHive(m, false); m.hive = null; }
    const rest = daylight < 0.25 || (h.dimension === 'overworld' && !!h.raining?.());
    if ((m.inHive ?? 0) > 0 && m.hive) {
      m.inHive! -= dt;
      p.set(m.hive[0] + 0.5, m.hive[1] + 0.3, m.hive[2] + 0.5);
      if (m.inHive! <= 0) { if (rest) m.inHive = 5; else this.leaveHive(m, true); }
      return true;
    }
    m.bt = (m.bt ?? 0) - dt;
    if (!m.hive && m.bt <= 0) { m.bt = 4; m.hive = this.findBlock(HIVES(), p, 10, 5); }
    if (m.hive && (rest || m.nectar)) {                                              // fly home (growing crops on the way)
      const d = this.flyTo(m, m.hive[0] + 0.5, m.hive[1] + 0.5, m.hive[2] + 0.5, BEE_SPEED, dt);
      if (m.nectar) this.pollinateCrop(m);
      if (d < 0.95) { m.inHive = m.nectar ? BEE_HIVE_TIME : 5; m.honeyReady = !!m.nectar; m.nectar = false; m.group.visible = false; }
      return true;
    }
    if (rest) return false;
    if (m.pollinating) {
      m.bt3 = (m.bt3 ?? 0) - dt;
      p.y += Math.sin(this.mgr.timeline * 9 + m.id) * dt * 0.25;
      if (m.bt3 <= 0) {
        m.pollinating = false; m.nectar = true; m.cropsGrown = 0; m.flower = null;
        h.emit?.('bee_pollinate', { x: p.x, y: p.y, z: p.z, mobId: m.id });
      }
      return true;
    }
    if (m.nectar) { this.pollinateCrop(m); return false; }                            // homeless bee: keeps wandering with its pollen
    m.bt2 = (m.bt2 ?? 0) - dt;
    if (!m.flower && m.bt2 <= 0) { m.bt2 = 3; m.flower = this.findBlock(FLOWERS(), p, 8, 4); }
    if (m.flower) {
      const [fx, fy, fz] = m.flower;
      if (!FLOWERS().has(h.getBlock(fx, fy, fz))) { m.flower = null; return false; }
      if (this.flyTo(m, fx + 0.5, fy + 0.75, fz + 0.5, BEE_SPEED, dt) < 0.3) { m.pollinating = true; m.bt3 = BEE_POLLINATE_TIME; }
      return true;
    }
    return false;
  }
  /** A bee carrying pollen fertilises the crop it flies over — one growth stage, at most ten crops per trip. */
  private pollinateCrop(m: Mob) {
    const h = this.host, p = m.group.position, x = Math.floor(p.x), z = Math.floor(p.z), key = x + ',' + z;
    if ((m.cropsGrown ?? 0) >= BEE_MAX_CROPS || !h.growCrop || m.lastCrop === key) return;
    for (let dy = 0; dy <= 3; dy++) {
      const y = Math.floor(p.y) - dy, id = h.getBlock(x, y, z);
      if (id === 0) continue;
      if (BEE_CROPS().has(id)) {
        m.lastCrop = key;
        if (h.growCrop(x, y, z)) { m.cropsGrown = (m.cropsGrown ?? 0) + 1; h.emit?.('bee_grow_crop', { x, y, z, mobId: m.id }); }
      }
      return;
    }
  }
  private leaveHive(m: Mob, deposit: boolean) {
    const h = this.host, hive = m.hive;
    m.inHive = 0;
    m.group.visible = true;
    if (!hive) return;
    const a = this.rnd() * Math.PI * 2;
    m.group.position.set(hive[0] + 0.5 + Math.cos(a) * 1.2, hive[1] + 0.4, hive[2] + 0.5 + Math.sin(a) * 1.2);
    if (deposit && m.honeyReady && h.setBlock && h.getState) {
      const level = h.getState(hive[0], hive[1], hive[2]), id = h.getBlock(hive[0], hive[1], hive[2]);
      if (level < HIVE_MAX_HONEY && HIVES().has(id)) {
        h.setBlock(hive[0], hive[1], hive[2], id, level + 1);
        h.emit?.('hive_honey', { x: hive[0], y: hive[1], z: hive[2], level: level + 1 });
      }
    }
    m.honeyReady = false;
  }
  /** Harvesting a hive without a campfire underneath sends every bee of that hive after the player. Returns how many got angry. */
  angerHive(x: number, y: number, z: number): number {
    let n = 0;
    for (const m of this.mgr.mobs) {
      if (m.species !== 'bee') continue;
      const mine = m.hive && m.hive[0] === x && m.hive[1] === y && m.hive[2] === z;
      if (!mine && m.group.position.distanceTo(this._v.set(x + 0.5, y + 0.5, z + 0.5)) > 6) continue;
      if (m.inHive) this.leaveHive(m, false);
      m.anger = 25; m.state = 'chase'; m.pollinating = false;
      n++;
    }
    return n;
  }
  private _v = new THREE.Vector3();

  // ---- Allay ------------------------------------------------------------------------------------------------------------
  private allay(m: Mob, dt: number): boolean {
    if (!m.wanted) return false;
    const h = this.host, p = m.group.position, held = m.heldCount ?? 0;
    m.noteTimer = Math.max(0, (m.noteTimer ?? 0) - dt);
    if (m.noteTimer <= 0) m.noteBlock = null;
    m.bt = Math.max(0, (m.bt ?? 0) - dt);
    if (held < 64 && m.bt <= 0) {                                                      // collect matching items lying around
      const d = h.nearestDrop?.(m.wanted, p.x, p.y, p.z, ALLAY_RANGE, m.noteBlock);
      if (d) {
        if (this.flyTo(m, d.x, d.y + 0.3, d.z, ALLAY_SPEED, dt) < 0.9) m.heldCount = held + (h.takeDrop?.(m.wanted, d.x, d.y, d.z, 1.3) ?? 0);
        return true;
      }
    }
    const nb = m.noteBlock, tx = nb ? nb[0] + 0.5 : h.position.x, ty = nb ? nb[1] + 1.7 : h.position.y + 1.6, tz = nb ? nb[2] + 0.5 : h.position.z;
    if (held > 0) {                                                                    // bring them to the note block / the player
      if (this.flyTo(m, tx, ty, tz, ALLAY_SPEED, dt) < (nb ? 0.5 : 2.2)) {
        const at = nb ? new THREE.Vector3(nb[0] + 0.5, nb[1] + 1.2, nb[2] + 0.5) : p.clone();
        h.particles.drop(at, m.wanted, held, resolve(m.wanted)?.color ?? '#9fd8ff');
        h.emit?.('allay_deliver', { x: at.x, y: at.y, z: at.z, mobId: m.id, item: m.wanted, count: held, to: nb ? 'note_block' : 'player' });
        m.heldCount = 0;
        m.bt = 3;
      }
      return true;
    }
    if (Math.hypot(tx - p.x, tz - p.z) > 3) this.flyTo(m, tx, ty, tz, ALLAY_SPEED * 0.8, dt);
    else p.y += (ty + Math.sin(this.mgr.timeline * 2 + m.id) * 0.25 - p.y) * Math.min(1, dt * 3);
    return true;
  }
  /** A note block played: every allay within 16 blocks delivers to it for the next 30 seconds. */
  noteBlockPlayed(x: number, y: number, z: number) {
    for (const m of this.mgr.mobs) {
      if (m.species !== 'allay' || m.group.position.distanceTo(this._v.set(x + 0.5, y + 0.5, z + 0.5)) > ALLAY_RANGE) continue;
      m.noteBlock = [x, y, z];
      m.noteTimer = ALLAY_NOTE_MEMORY;
    }
  }

  // ---- Sniffer / armadillo ----------------------------------------------------------------------------------------------
  private sniffer(m: Mob, dt: number): boolean {
    if (m.baby) return false;
    const h = this.host, p = m.group.position, x = Math.floor(p.x), y = Math.floor(p.y - 0.5), z = Math.floor(p.z), key = `${x},${y},${z}`;
    if (m.digging) {
      m.digTimer = (m.digTimer ?? 0) - dt;
      this.mgr.walk(m, 0, dt, false);
      if (m.digTimer <= 0) {
        const item = this.rnd() < 0.5 ? 'torchflower_seeds' : 'pitcher_pod';
        m.digging = false;
        m.digCooldown = SNIFFER_COOLDOWN;
        (m.dug ??= []).push(key);
        if (m.dug.length > 20) m.dug.shift();                                           // it remembers its last 20 dig sites
        this.drop(m, item, 1, 0.3);
        h.emit?.('sniffer_dig', { x, y, z, mobId: m.id, item });
      }
      return true;
    }
    m.digCooldown = (m.digCooldown ?? 12) - dt;
    if (m.digCooldown > 0 || m.love > 0 || (m.state !== 'wander' && m.state !== 'graze')) return false;
    if (!DIGGABLE().has(h.getBlock(x, y, z)) || m.dug?.includes(key)) return false;
    m.digging = true;
    m.digTimer = SNIFFER_DIG_TIME;
    return true;
  }
  private armadillo(m: Mob, dt: number) {
    m.scuteTimer = (m.scuteTimer ?? 300 + this.rnd() * 300) - dt;
    if (m.scuteTimer > 0 || m.baby) return;
    m.scuteTimer = 300 + this.rnd() * 300;
    this.drop(m, 'armadillo_scute', 1, 0.3);
    this.host.emit?.('armadillo_scute', { x: m.group.position.x, y: m.group.position.y, z: m.group.position.z, mobId: m.id, brushed: false });
  }

  // ===== interaction ======================================================================================================
  /** Right-click handling that takes priority over the generic one. null = not handled. */
  interact(m: Mob, item: string): boolean | 'consume' | null {
    const h = this.host, p = m.group.position, hearts = () => h.particles.burst(p.clone().add(new THREE.Vector3(0, 1.2, 0)), '#e47b83', 8, 1);
    if (m.species === 'armadillo' && item === 'brush') {
      if (m.baby) return true;
      this.drop(m, 'armadillo_scute', 1, 0.4);
      h.wearHeld?.(16);
      h.sound('wood', p);
      h.emit?.('armadillo_scute', { x: p.x, y: p.y, z: p.z, mobId: m.id, brushed: true });
      return true;
    }
    if (m.species === 'wolf' && m.tamed) {
      const armor = m.wolfArmor ?? 0;
      if (item === 'wolf_armor' && armor <= 0) { m.wolfArmor = WOLF_ARMOR_HP; hearts(); h.toast('オオカミに鎧を着せました', 'Wolf armor equipped'); return 'consume'; }
      if (item === 'shears' && armor > 0) { m.wolfArmor = 0; this.drop(m, 'wolf_armor', 1); h.sound('wood', p); return true; }
      if (item === 'armadillo_scute' && armor > 0 && armor < WOLF_ARMOR_HP) { m.wolfArmor = Math.min(WOLF_ARMOR_HP, armor + 8); hearts(); return 'consume'; }
    }
    if (m.species === 'allay') {
      if (item && !m.wanted) {
        m.wanted = item; m.heldCount = 0; m.tamed = true;
        hearts();
        h.toast(`アレイが「${resolve(item)?.ja ?? item}」を集め始めました`, `The allay now collects ${item.replace(/_/g, ' ')}`);
        return 'consume';
      }
      if (!item && m.wanted) {
        h.addItem(m.wanted, 1 + (m.heldCount ?? 0));
        m.wanted = undefined; m.heldCount = 0;
        return true;
      }
      return true;
    }
    return null;
  }

  // ===== damage / death ===================================================================================================
  /** Armor (reduced by Breach on melee hits), wolf armor absorption and the Infested effect. */
  modifyDamage(m: Mob, damage: number, melee: boolean): number {
    let out = damage;
    if (out <= 0) return out;
    const armor = mobArmor(m.species, m.bonusArmor ?? 0);
    if (armor > 0) out = Math.max(1, Math.round(damageAfterArmor(out, armor, melee ? this.breach : 0)));
    if (m.species === 'wolf' && (m.wolfArmor ?? 0) > 0) {
      m.wolfArmor = Math.max(0, m.wolfArmor! - out);
      if (m.wolfArmor === 0) this.host.sound('stone', m.group.position);
      return 0;
    }
    if (m.fx?.infested && this.rnd() < INFESTED_CHANCE) this.infest(m.group.position, m.id);
    return out;
  }
  /** Infested: silverfish burst out of whatever was hit. */
  infest(p: THREE.Vector3, entity: 'player' | number): number {
    const n = infestedCount(() => this.rnd());
    let spawned = 0;
    for (let i = 0; i < n; i++) if (this.mgr.spawn('silverfish', p.x + (this.rnd() - 0.5) * 1.6, p.z + (this.rnd() - 0.5) * 1.6, false, p.y)) spawned++;
    this.host.emit?.('effect_trigger', { effect: 'infested', entity, x: p.x, y: p.y, z: p.z, count: spawned });
    return spawned;
  }
  /** Oozing: two slimes ooze out of the corpse. */
  ooze(p: THREE.Vector3, entity: 'player' | number): number {
    let spawned = 0;
    for (let i = 0; i < OOZING_SLIMES; i++) {
      const s = this.mgr.spawn('slime', p.x + (i ? 0.6 : -0.6), p.z + (this.rnd() - 0.5), false, p.y);
      if (s) { s.hp = s.maxHp = 4; spawned++; }
    }
    this.host.emit?.('effect_trigger', { effect: 'oozing', entity, x: p.x, y: p.y, z: p.z, count: spawned });
    return spawned;
  }
  /** Weaving: 2–3 cobwebs appear where the holder died. */
  weave(p: THREE.Vector3, entity: 'player' | number): number {
    const h = this.host, web = (ID as Record<string, number | undefined>).cobweb;
    if (!h.setBlock || web === undefined) return 0;
    const spots = cobwebSpots((x, y, z) => h.getBlock(x, y, z) === 0, p.x, p.y + 0.1, p.z, weavingCount(() => this.rnd()), () => this.rnd());
    let placed = 0;
    for (const [x, y, z] of spots) if (h.setBlock(x, y, z, web)) placed++;
    h.emit?.('effect_trigger', { effect: 'weaving', entity, x: p.x, y: p.y, z: p.z, count: placed });
    return placed;
  }
  /** A burst of wind: pushes mobs (and optionally the player) away without damage. Returns the number of mobs moved. */
  windBurst(x: number, y: number, z: number, radius: number, source: 'mace' | 'wind_charged' | 'wind_charge', exclude?: Mob | null, pushPlayer = false): number {
    const h = this.host;
    let n = 0;
    for (const o of this.mgr.mobs) {
      if (o === exclude || o.species === 'dragon' || o.species === 'shulker') continue;
      const q = o.group.position, k = windKnockback(x, y, z, q.x, q.y + 0.5, q.z, radius);
      if (!k) continue;
      q.x += k[0]; q.z += k[2];
      o.vy = Math.max(o.vy, 4 + k[1] * 3);
      n++;
    }
    if (pushPlayer) {
      const k = windKnockback(x, y, z, h.position.x, h.position.y + 0.5, h.position.z, radius);
      if (k) h.knockPlayer?.(k[0] * 4, 6 + k[1] * 4, k[2] * 4);
    }
    h.particles.burst(this._v.set(x, y, z).clone(), '#d8eaff', 26, 6);
    h.sound('explosion', { x, y, z });
    h.emit?.('wind_burst', { x, y, z, radius, source });
    return n;
  }
  /** Called at the very start of MobManager.kill (the mob is still in the list). */
  onDeath(m: Mob) {
    const h = this.host, p = m.group.position;
    if (m.carried) { const n = BLOCKS[m.carried]?.name; if (n) this.drop(m, n, 1); m.carried = undefined; }
    if ((m.wolfArmor ?? 0) > 0) this.drop(m, 'wolf_armor', 1);
    if (m.wanted && m.heldCount) this.drop(m, m.wanted, m.heldCount);
    if (m.inHive) m.group.visible = true;
    const fx = m.fx;
    if (fx) {
      m.fx = undefined;
      if (fx.oozing) this.ooze(p, m.id);
      if (fx.wind_charged) {
        this.windBurst(p.x, p.y + 0.5, p.z, WIND_CHARGED_RADIUS, 'wind_charged', m, true);
        h.emit?.('effect_trigger', { effect: 'wind_charged', entity: m.id, x: p.x, y: p.y, z: p.z, count: 1 });
      }
      if (fx.weaving) this.weave(p, m.id);
    }
    h.onMobDeath?.(m);
  }
  /** Gives a mob one of the 1.21 effects (splash potions, ominous trial spawners). */
  applyEffect(m: Mob, id: string, sec: number) {
    if (!(EFFECTS_121 as readonly string[]).includes(id)) return false;
    (m.fx ??= {})[id] = Math.max(m.fx[id] ?? 0, sec);
    return true;
  }
  splash(pos: THREE.Vector3, id: string, sec: number, radius = 4): number {
    let n = 0;
    for (const m of this.mgr.mobs) if (m.group.position.distanceTo(pos) <= radius && this.applyEffect(m, id, sec)) n++;
    return n;
  }

  // ===== creepers & lightning ==============================================================================================
  /** A creeper goes off: twice the blast when charged, and a charged blast makes one victim drop its head. */
  creeperExplode(m: Mob) {
    const pos = m.group.position.clone(), r = creeperRadius(!!m.charged);
    // 作業B: kind 'mob' → mobExplosionDropDecay; mob damage stays in blast() below (未変更: no exposure for mob victims of creepers).
    this.mgr.explosionCtx = { kind: 'mob', mobsHandled: true };
    try { this.host.explode(pos, r); } finally { this.mgr.explosionCtx = null; }
    this.blast(pos, r, !!m.charged, m);
  }
  /** Explosion damage to mobs. Returns the head dropped by a charged-creeper blast (at most one), if any. */
  blast(pos: THREE.Vector3, r: number, charged: boolean, exclude?: Mob | null): string | null {
    let head: string | null = null;
    for (const o of [...this.mgr.mobs]) {
      if (o === exclude || !this.mgr.mobs.includes(o)) continue;
      const dmg = explosionDamage(r, o.group.position.distanceTo(pos));
      if (dmg <= 0) continue;
      const at = o.group.position.clone();
      this.mgr.extraDamage(o, dmg);
      const name = MOB_HEADS[o.species];
      if (charged && !head && name && !this.mgr.mobs.includes(o)) {
        head = name;
        this.host.particles.drop(at.add(new THREE.Vector3(0, 0.5, 0)), name, 1, resolve(name)?.color ?? '#888');
        this.host.emit?.('mob_head_drop', { x: at.x, y: at.y, z: at.z, head: name, victim: o.species });
      }
    }
    return head;
  }
  /** A lightning bolt (storm or a Channeling trident) lands at `pos`: creepers become charged, pigs and villagers are transformed. */
  lightning(pos: THREE.Vector3, channeling = false): number {
    const h = this.host;
    let charged = 0;
    h.emit?.('lightning', { x: pos.x, y: pos.y, z: pos.z, channeling });
    for (const o of [...this.mgr.mobs]) {
      if (!this.mgr.mobs.includes(o) || o.group.position.distanceTo(pos) > LIGHTNING_CHARGE_RADIUS) continue;
      const q = o.group.position;
      if (o.species === 'creeper') {
        if (!o.charged) { this.mgr.chargeCreeper(o); charged++; h.emit?.('creeper_charged', { x: q.x, y: q.y, z: q.z, mobId: o.id }); }
      } else if (o.species === 'pig') this.mgr.replaceSpecies(o, 'zombified_piglin');
      else if (o.species === 'villager') this.mgr.replaceSpecies(o, 'witch');
      else if (o.species !== 'dragon') this.mgr.extraDamage(o, 5);
    }
    h.particles.burst(pos.clone(), '#fff7c2', 30, 7);
    return charged;
  }

  // ===== persistence ======================================================================================================
  saveExtra(m: Mob): Record<string, unknown> | undefined {
    const out: Record<string, unknown> = {}, src = m as unknown as Record<string, unknown>;
    for (const k of SAVED) { const v = src[k]; if (v !== undefined && v !== null && v !== false && v !== 0) out[k] = v; }
    return Object.keys(out).length ? out : undefined;
  }
  loadExtra(m: Mob, extra?: Record<string, unknown>) {
    if (!extra) return;
    const dst = m as unknown as Record<string, unknown>;
    for (const k of SAVED) if (extra[k] !== undefined) dst[k] = extra[k];
  }
}
