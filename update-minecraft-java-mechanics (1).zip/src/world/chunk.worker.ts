import { Terrain } from "./terrain";
import { meshChunk, type MeshData } from "./mesher";
import { packMesh, emptyPackedMesh, packedTransfers } from "./meshPack";

let terrain: Terrain | undefined, seed = "", dimension = "";
let tiles: number[][] | undefined;

function extendY(m: MeshData, range: [number, number]) {
  const p = m.position;
  for (let i = 1; i < p.length; i += 3) {
    const y = p[i];
    if (y < range[0]) range[0] = y;
    if (y > range[1]) range[1] = y;
  }
}

self.onmessage = (event: MessageEvent) => {
  const m = event.data;
  try {
    if (m.tiles) tiles = m.tiles;
    if (!tiles) throw new Error("tile table missing");
    if (!terrain || seed !== m.seed || dimension !== m.dimension) {
      terrain = new Terrain(m.seed, m.dimension);
      seed = m.seed;
      dimension = m.dimension;
    }
    const generated = terrain.generate(m.cx, m.cz, m.edits, m.structures);
    if (m.sideOnly) {
      const solid = emptyPackedMesh(), water = emptyPackedMesh();
      const response = {
        type: "chunk", key: m.key, cx: m.cx, cz: m.cz, version: m.version, epoch: m.epoch,
        sideOnly: true, genMaxY: generated.maxY, data: generated.data.buffer,
        solid, water, minY: 0, maxY: generated.maxY
      };
      self.postMessage(response, [generated.data.buffer] as any);
      return;
    }
    const solidMesh = meshChunk(generated.padded, generated.maxY, tiles, generated.tint);
    const range: [number, number] = [Infinity, -Infinity];
    extendY(solidMesh.solid, range);
    extendY(solidMesh.water, range);
    if (range[0] > range[1]) { range[0] = 0; range[1] = 0; }
    // Compact GPU layout (see world/meshPack.ts): ~40 % fewer vertex bytes, range-checked so the image is unchanged.
    const solid = packMesh(solidMesh.solid), water = packMesh(solidMesh.water);
    const response = {
      type: "chunk", key: m.key, cx: m.cx, cz: m.cz, version: m.version, epoch: m.epoch,
      genMaxY: generated.maxY, data: generated.data.buffer,
      solid, water,
      minY: range[0], maxY: range[1]
    };
    self.postMessage(response, [generated.data.buffer, ...packedTransfers(solid), ...packedTransfers(water)] as any);
  } catch (error) {
    self.postMessage({ type: "error", key: m.key, epoch: m.epoch, message: String(error) });
  }
};
