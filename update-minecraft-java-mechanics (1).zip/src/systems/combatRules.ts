// 作業B: Java Edition 1.21.x の近接戦闘ルール（エンジン非依存の純粋関数）。
// 出典: Minecraft Wiki — Melee attack / Damage (Invulnerability timer) / Attribute (entity_interaction_range,
// knockback_resistance) / Knockback (mechanic) / 各モブのページ。速度の単位は特記なき限りブロック/秒（Java の値 ×20）。

export const TPS = 20;

/** Attribute entity_interaction_range: default 3 (survival). Creative adds +2 → 5 (Wiki: Interaction range). */
export const ENTITY_REACH_SURVIVAL = 3;
export const ENTITY_REACH_CREATIVE = 5;
export const entityReach = (mode: string) => (mode === 'creative' ? ENTITY_REACH_CREATIVE : ENTITY_REACH_SURVIVAL);
/** Attribute block_interaction_range: 4.5 survival, 5 creative (Wiki: Interaction range). */
export const blockReach = (mode: string) => (mode === 'creative' ? 5 : 4.5);

// ---------------------------------------------------------------------------------------------- hitboxes (EntityType sizes)
/** EntityType dimensions [width, height] for adults (babies are scaled via the model scale). Java 1.21 EntityType.java. */
const HITBOX: Record<string, [number, number]> = {
  cow: [0.9, 1.4], mooshroom: [0.9, 1.4], pig: [0.9, 0.9], sheep: [0.9, 1.3], chicken: [0.4, 0.7],
  zombie: [0.6, 1.95], husk: [0.6, 1.95], drowned: [0.6, 1.95], zombie_villager: [0.6, 1.95],
  skeleton: [0.6, 1.99], stray: [0.6, 1.99], bogged: [0.6, 1.99], wither_skeleton: [0.7, 2.4],
  creeper: [0.6, 1.7], spider: [1.4, 0.9], cave_spider: [0.7, 0.5], enderman: [0.6, 2.9],
  villager: [0.6, 1.95], wandering_trader: [0.6, 1.95], pillager: [0.6, 1.95], vindicator: [0.6, 1.95], evoker: [0.6, 1.95], witch: [0.6, 1.95],
  piglin: [0.6, 1.95], piglin_brute: [0.6, 1.95], zombified_piglin: [0.6, 1.95],
  wolf: [0.6, 0.85], cat: [0.6, 0.7], ocelot: [0.6, 0.7], fox: [0.6, 0.7], rabbit: [0.4, 0.5],
  horse: [1.3965, 1.6], donkey: [1.3965, 1.5], mule: [1.3965, 1.6], skeleton_horse: [1.3965, 1.6], zombie_horse: [1.3965, 1.6],
  iron_golem: [1.4, 2.7], snow_golem: [0.7, 1.9], fish: [0.5, 0.3], salmon: [0.7, 0.4], tropical_fish: [0.5, 0.4], pufferfish: [0.7, 0.7],
  dolphin: [0.9, 0.6], squid: [0.8, 0.8], glow_squid: [0.8, 0.8], turtle: [1.2, 0.4], axolotl: [0.75, 0.42], tadpole: [0.4, 0.3], frog: [0.5, 0.5],
  blaze: [0.6, 1.8], ghast: [4, 4], wither: [0.9, 3.5], dragon: [16, 8], warden: [0.9, 2.9],
  slime: [2.04, 2.04], magma_cube: [2.04, 2.04],          // size 4 (0.52 × size); smaller ones use the model scale
  bee: [0.7, 0.6], shulker: [1, 1], hoglin: [1.3965, 1.4], zoglin: [1.3965, 1.4], strider: [0.9, 1.7],
  vex: [0.4, 0.8], ravager: [1.95, 2.2], phantom: [0.9, 0.5], silverfish: [0.4, 0.3], endermite: [0.4, 0.3], breeze: [0.6, 1.77],
  guardian: [0.85, 0.85], elder_guardian: [1.9975, 1.9975], panda: [1.3, 1.25], polar_bear: [1.4, 1.4], llama: [0.9, 1.87],
  parrot: [0.5, 0.9], goat: [0.9, 1.3], camel: [1.7, 2.375], armadillo: [0.7, 0.65], sniffer: [1.9, 1.75], allay: [0.35, 0.6], bat: [0.5, 0.9],
};
export function mobHitbox(species: string, scale = 1): [number, number] {
  const b = HITBOX[species] ?? [0.6, 1.95];
  return [b[0] * scale, b[1] * scale];
}
export interface AABB { minX: number; minY: number; minZ: number; maxX: number; maxY: number; maxZ: number }
/** Feet-centred box (entity position = bottom centre, like Java). */
export function boxAt(x: number, y: number, z: number, w: number, h: number): AABB {
  const r = w / 2;
  return { minX: x - r, minY: y, minZ: z - r, maxX: x + r, maxY: y + h, maxZ: z + r };
}
export const inflate = (b: AABB, x: number, y: number, z: number): AABB => ({ minX: b.minX - x, minY: b.minY - y, minZ: b.minZ - z, maxX: b.maxX + x, maxY: b.maxY + y, maxZ: b.maxZ + z });
export const intersects = (a: AABB, b: AABB) => a.minX < b.maxX && a.maxX > b.minX && a.minY < b.maxY && a.maxY > b.minY && a.minZ < b.maxZ && a.maxZ > b.minZ;

/** Slab test: entry distance t (≥ 0) of the ray origin + t·dir (dir need not be unit) into the box, or null. Inside → 0. */
export function rayAABB(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, b: AABB, maxT = Infinity): number | null {
  let t0 = 0, t1 = maxT;
  const axes: [number, number, number, number][] = [[ox, dx, b.minX, b.maxX], [oy, dy, b.minY, b.maxY], [oz, dz, b.minZ, b.maxZ]];
  for (const [o, d, lo, hi] of axes) {
    if (Math.abs(d) < 1e-12) { if (o < lo || o > hi) return null; continue; }
    let a = (lo - o) / d, c = (hi - o) / d;
    if (a > c) { const s = a; a = c; c = s; }
    if (a > t0) t0 = a;
    if (c < t1) t1 = c;
    if (t0 > t1) return null;
  }
  return t0;
}

/**
 * Voxel DDA: distance along the unit ray to the first block for which `solid(id)` holds, or Infinity within maxDist.
 * Blocks are treated as full cubes (Java uses outline shapes for picking — 未確認: non-cube outlines are approximated).
 */
export function rayBlockDistance(getBlock: (x: number, y: number, z: number) => number, solid: (id: number) => boolean,
  ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, maxDist: number): number {
  let x = Math.floor(ox), y = Math.floor(oy), z = Math.floor(oz);
  const sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
  const tdx = Math.abs(1 / (dx || 1e-12)), tdy = Math.abs(1 / (dy || 1e-12)), tdz = Math.abs(1 / (dz || 1e-12));
  let tmx = (dx > 0 ? x + 1 - ox : ox - x) * tdx, tmy = (dy > 0 ? y + 1 - oy : oy - y) * tdy, tmz = (dz > 0 ? z + 1 - oz : oz - z) * tdz;
  let t = 0;
  for (let i = 0; i < 256 && t <= maxDist; i++) {
    if (solid(getBlock(x, y, z))) return t;
    if (tmx < tmy && tmx < tmz) { x += sx; t = tmx; tmx += tdx; }
    else if (tmy < tmz) { y += sy; t = tmy; tmy += tdy; }
    else { z += sz; t = tmz; tmz += tdz; }
  }
  return Infinity;
}

/** Decides what a left click hits: Java picks whichever of block / entity is closer along the view ray. */
export function resolveClick(entityT: number | null, entityReach: number, blockT: number, blockReachD: number): 'entity' | 'block' | 'miss' {
  const e = entityT !== null && entityT <= entityReach ? entityT : Infinity;
  const b = blockT <= blockReachD ? blockT : Infinity;
  if (e < b) return 'entity';
  if (b < Infinity) return 'block';
  return 'miss';
}

// ------------------------------------------------------------------------------------------------- invulnerability timer
/** Wiki Damage › Invulnerability timer: 10 game ticks (0.5 s) — later hits only deal the excess over the last damage. */
export const INVULNERABLE_SECONDS = 10 / TPS;
export interface IFrameState { hurtAt?: number; lastHurt?: number }
/**
 * Returns the damage that actually applies, and whether this was a "fresh" hit (fresh hits knock back / animate).
 * `now` is a continuous clock in seconds so the result does not depend on the frame rate.
 */
export function applyIFrames(st: IFrameState, amount: number, now: number): { dmg: number; fresh: boolean } {
  if (!(amount > 0)) return { dmg: 0, fresh: false };
  if (st.hurtAt !== undefined && now - st.hurtAt < INVULNERABLE_SECONDS) {
    const last = st.lastHurt ?? 0;
    if (amount <= last) return { dmg: 0, fresh: false };
    st.lastHurt = amount;                       // does not restart the timer
    return { dmg: amount - last, fresh: false };
  }
  st.hurtAt = now; st.lastHurt = amount;
  return { dmg: amount, fresh: true };
}

// ------------------------------------------------------------------------------------------------------------- knockback
/** LivingEntity.hurt knockback strength from a damaging entity (Java 0.4). */
export const BASE_KNOCKBACK = 0.4;
/** Attribute knockback_resistance (EntityType defaults). Netherite armour adds 0.1 per piece. 未確認: zoglin. */
export const KNOCKBACK_RESISTANCE: Record<string, number> = { iron_golem: 1, warden: 1, ravager: 0.75, hoglin: 0.6, zoglin: 0.6, shulker: 1, dragon: 1 };
export interface Vel { x: number; y: number; z: number }
/**
 * LivingEntity.knockback(strength, …) in blocks/second. (px, pz) is the push direction (away from the attacker).
 * Java: strength *= 1 − resistance; v.xz = v.xz/2 + dir·strength; on ground v.y = min(0.4, v.y/2 + strength).
 */
export function applyKnockback(v: Vel, strength: number, px: number, pz: number, onGround: boolean, resistance = 0): Vel {
  const s = strength * (1 - Math.min(1, Math.max(0, resistance)));
  if (s <= 0) return v;
  const len = Math.hypot(px, pz);
  const nx = len > 1e-7 ? px / len : 0, nz = len > 1e-7 ? pz / len : 0;
  const bt = { x: v.x / TPS, y: v.y / TPS, z: v.z / TPS };
  v.x = (bt.x / 2 + nx * s) * TPS;
  v.z = (bt.z / 2 + nz * s) * TPS;
  if (onGround) v.y = Math.min(0.4, bt.y / 2 + s) * TPS;
  return v;
}
/** Horizontal drag per tick for a walking mob: ground 0.91 × slipperiness 0.6, air 0.91. Frame-rate independent. */
export function dampHorizontal(v: Vel, dt: number, onGround: boolean) {
  const f = Math.pow(onGround ? 0.546 : 0.91, dt * TPS);
  v.x *= f; v.z *= f;
}

// ---------------------------------------------------------------------------------------------- attack speed & damage
/** attack_speed attribute of the held item (Wiki Melee attack table). Hoes depend on the material. */
export function attackSpeed(name?: string): number {
  if (!name) return 4;
  if (name.endsWith('_sword')) return 1.6;
  if (name === 'trident') return 1.1;
  if (name === 'mace') return 0.6;
  if (name.endsWith('_pickaxe')) return 1.2;
  if (name.endsWith('_axe')) return name.startsWith('wooden') || name.startsWith('stone') ? 0.8 : name.startsWith('iron') ? 0.9 : 1;
  if (name.endsWith('_shovel')) return 1;
  if (name.endsWith('_hoe')) {
    if (name.startsWith('wooden') || name.startsWith('golden')) return 1;
    if (name.startsWith('stone')) return 2;
    if (name.startsWith('iron')) return 3;
    return 4;                                              // diamond, netherite
  }
  return 4;
}
/** Wiki: p = clamp((t + 0.5) / T, 0, 1), T = 20 / attackSpeed ticks (rounding of T 未確認 — not applied). */
export function attackStrength(secondsSinceReset: number, speed: number): number {
  const ticks = secondsSinceReset * TPS, T = TPS / speed;
  return Math.min(1, Math.max(0, (ticks + 0.5) / T));
}

export interface CritState {
  charge: number; fallDistance: number; onGround: boolean; onClimbable: boolean; inWater: boolean;
  blind: boolean; slowFalling: boolean; levitation: boolean; riding: boolean; sprinting: boolean;
}
/**
 * Player.attack: crit when strength > 0.9 (Wiki states 84.8 % on the displayed meter — 未確認 which scale), falling, not on
 * ground / climbable / in water, no Blindness (Wiki also lists Slow Falling & Levitation), not riding, not sprinting.
 */
export function canCrit(s: CritState): boolean {
  return s.charge > 0.9 && s.fallDistance > 0 && !s.onGround && !s.onClimbable && !s.inWater && !s.blind
    && !s.slowFalling && !s.levitation && !s.riding && !s.sprinting;
}
/** Sprint-knockback attack: sprinting with a charged swing. */
export const sprintKnock = (charge: number, sprinting: boolean) => sprinting && charge > 0.9;
/**
 * Sweep: sword, charged, not a crit or sprint-knockback, on ground, and walkDist delta (horizontal distance × 0.6 per tick)
 * below the movement_speed attribute 0.1 → horizontal speed < 3.33 b/s (要確認: player speed attribute while sprinting).
 */
export function canSweep(o: { sword: boolean; charge: number; crit: boolean; sprintKnock: boolean; onGround: boolean; horizSpeed: number }): boolean {
  return o.sword && o.charge > 0.9 && !o.crit && !o.sprintKnock && o.onGround && o.horizSpeed * 0.6 / TPS < 0.1;
}
/** Sweep damage = 1 + sweeping_damage_ratio × (cooldown-scaled base damage); ratio = level / (level + 1). */
export const sweepDamage = (scaledBase: number, sweepingEdge: number) => 1 + (sweepingEdge / (sweepingEdge + 1)) * scaledBase;
/** Swept targets: inside the target's box inflated by (1, 0.25, 1), and within 3 blocks of the player (distanceToSqr < 9). */
export const SWEEP_INFLATE = { x: 1, y: 0.25, z: 1 } as const;
export const SWEEP_PLAYER_RANGE = 3;

/**
 * Player.attack damage: base × (0.2 + 0.8p²), ×1.5 when critical (base only), + enchantment bonus × p.
 * `extra` (mace smash) is added afterwards unscaled. No integer rounding.
 */
export function meleeDamage(base: number, enchBonus: number, charge: number, crit: boolean, extra = 0): { total: number; scaledBase: number } {
  let f = Math.max(0, base) * (0.2 + charge * charge * 0.8);
  const scaledBase = f;
  if (crit) f *= 1.5;
  return { total: f + enchBonus * charge + extra, scaledBase };
}

// ------------------------------------------------------------------------------------------------------ on-hit effects
export type Difficulty = 'peaceful' | 'easy' | 'normal' | 'hard';
/**
 * Regional difficulty lower bound per difficulty (no inhabited time / moon phase: 未確認 — this project has no regional
 * difficulty tracking). Wiki Difficulty: easy 0.75, normal 1.5, hard 2.25 minimum.
 */
export const regionalMin = (d: string) => (d === 'hard' ? 2.25 : d === 'normal' ? 1.5 : d === 'easy' ? 0.75 : 0);
/** Effect a mob's melee attack inflicts, by attacker species: [effect, seconds, amplifier] or null. */
export function meleeEffect(species: string, difficulty: string): [string, number, number] | null {
  const d = difficulty;
  switch (species) {
    case 'cave_spider': return d === 'normal' ? ['poison', 7, 0] : d === 'hard' ? ['poison', 15, 0] : null;      // Wiki Cave Spider
    case 'wither_skeleton': return ['wither', 10, 0];                                                            // Wiki Wither Skeleton
    case 'husk': { const s = 7 * Math.floor(regionalMin(d)); return s > 0 ? ['hunger', s, 0] : null; }            // Wiki Husk (regional difficulty)
    case 'bee': return d === 'normal' ? ['poison', 10, 0] : d === 'hard' ? ['poison', 18, 0] : null;              // 未確認 (Wiki Bee)
    case 'pufferfish': return ['poison', 6, 0];                                                                  // 未確認: 60 ticks × puff state
    default: return null;                                                                                        // spider, witch, stray, bogged …: none
  }
}
/** Arrow effects (tipped arrows shot by mobs). 未確認: Stray 30 s Slowness, Bogged 4 s Poison. */
export function arrowEffect(species: string): [string, number] | undefined {
  return species === 'stray' ? ['slowness', 30] : species === 'bogged' ? ['poison', 4] : undefined;
}
/** Fire Aspect: 80 fire ticks (4 s) per level (Wiki Fire Aspect). */
export const fireAspectSeconds = (level: number) => 4 * level;
/** Fire-immune mobs (EntityType.fireImmune). */
export const FIRE_IMMUNE = new Set(['blaze', 'ghast', 'magma_cube', 'strider', 'wither_skeleton', 'wither', 'dragon', 'zombified_piglin', 'zoglin', 'warden']);
/** Thorns per armour piece: chance 0.15 × level, damage 1–4 (level > 10 → level − 10). */
export function thornsDamage(level: number, rnd: () => number): number {
  if (level <= 0 || rnd() >= 0.15 * level) return 0;
  return level > 10 ? level - 10 : 1 + Math.floor(rnd() * 4);
}
