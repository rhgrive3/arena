import { entityFxBox } from '../render/particles';
import {
  waxCopper, scrapeCopper, bindLodestoneCompass, amethystDrops, ominousBottleAmplifier,
  OMINOUS_BOTTLE_DURATION, RAID_OMEN_DURATION, TRIAL_OMEN_BASE_DURATION,
  suspiciousStewEffect, bundleWeight, bundleDropAll, DEFAULT_GAMERULES, parseCoords, parseSelector,
} from '../systems/vanillaPlus';
// Player systems (v11+v14): equipment slots, off-hand & shield, attack cooldown / sweep / crits, charged bow, crossbow, trident, mace,
// status effects, enchantment effects, linked nether portals (1:8), dragon re-summoning and the workstation back-ends.
// Kept outside engine.ts as plain functions over the Engine instance so the big class only needs thin hooks.
import * as THREE from 'three';
import type { Engine } from './engine';
import { BLOCKS, ID, resolve, type BlockDef } from './data';
import { makeCell, blockId, blockState } from './blockState';
import type { Stack, WorldSave, Screen } from './types';
import { SEA } from '../world/terrain';
import { blockDrops, FATIGUE_MULTIPLIER } from '../systems/mining';
import { fallDamageAmount } from './playerPhysics';
import { EXTRA_LOOT, type ExtraKind } from '../world/structures';
import { ROOM_LOOT, FIXED_CONTENTS, rollRoomLoot, lootTagAt } from '../world/struct/loot';
import {
  ENCHANTS, ENCHANT_BY_ID, EFFECTS, lvl, armorSlotOf, potionEffects, enchantOptions, applyEnchants, anvilCombine,
  grindstone as grind, brewResult, BREW_INGREDIENTS, isBottle, rng, hashStr, canApply, type EnchantOption,
} from '../systems/magic';
import { SMITHING, STONECUT } from '../systems/crafting';
import { smashDamage, windBurstVelocity, WIND_BURST_RADIUS, cobwebSpeedFactor } from '../systems/combat121';
import * as CR from '../systems/combatRules';
import { blockLightAt as propagatedBlockLight } from '../world/lightField';
import * as V from './vanilla';
import { addLayer, type BannerLayer } from '../systems/banners';
import { isTrimTemplate, isTrimMaterial, isTrimmableArmor, trimPatternOf, trimMaterialOf } from '../systems/trims';
import { pickArchaeologyLoot } from '../systems/pots';
import { beaconPyramidTier, beaconRange, beaconDuration, isBeaconPayment } from '../systems/beacon';

import { newMap, updateMap, zoomedOut, lockedCopy, deserializeMap, serializeMap, type MapData, type MapSample, type MapSave } from '../systems/maps';

const UP = new THREE.Vector3(0, 1, 0);
const any = (e: unknown) => e as any;
const creative = (e: Engine) => e.meta.mode === 'creative';
const inWater = (e: Engine) => e.getBlock(e.position.x, e.position.y + 0.6, e.position.z) === ID.water;
/** Java experience curve (see vanilla.ts): piecewise quadratic totals instead of the old √xp. */
export const level = (e: Engine) => V.levelFromXp(e.xp);
export function spendLevels(e: Engine, n: number) { e.xp = V.xpAfterLevels(e.xp, -n); e.lastLevel = level(e); }

// ---- Hands, hunger bookkeeping ------------------------------------------------------------------------------------------
export type Hand = 'main' | 'off';
export const handStack = (e: Engine, h: Hand): Stack | null => (h === 'off' ? e.offhand : e.hotbar[e.selected]) ?? null;
export function setHand(e: Engine, h: Hand, s: Stack | null) { if (h === 'off') e.offhand = s; else e.hotbar[e.selected] = s; }
const useHandOf = (e: Engine): Hand => any(e).useHand ?? 'main';
const foodOf = (e: Engine): V.FoodState => ({ food: e.hunger, sat: any(e).saturation ?? 5, exh: any(e).exhaustion ?? 0, timer: any(e).foodTimer ?? 0, acc: any(e).foodAcc ?? 0, ptick: any(e).foodPtick ?? 0 });
const storeFood = (e: Engine, f: V.FoodState) => { e.hunger = f.food; const a = any(e); a.saturation = f.sat; a.exhaustion = f.exh; a.foodTimer = f.timer; a.foodAcc = f.acc; a.foodPtick = f.ptick; };
/** Adds exhaustion (sprinting, jumping, attacking, damage …); every 4.0 is converted into −1 saturation, then −1 food. */
export function exhaust(e: Engine, n: number) { if (creative(e) || e.meta.mode === 'spectator') return; const f = foodOf(e); V.addExhaustion(f, n); storeFood(e, f); }
export function eatNow(e: Engine, nutrition: number, saturation: number) { const f = foodOf(e); V.eatFood(f, nutrition, saturation); storeFood(e, f); }

// ---- Inventory with equipment: 0–8 hotbar · 9–35 inventory · 36–39 armor (head, chest, legs, feet) · 40 off-hand --------
export const slotAt = (e: Engine, i: number): Stack | null => (i < 9 ? e.hotbar[i] : i < 36 ? e.inventory[i - 9] : i < 40 ? e.armor[i - 36] : i === 40 ? e.offhand : null) ?? null;
export function setSlot(e: Engine, i: number, s: Stack | null) {
  if (s && s.count <= 0) s = null;
  if (i < 9) e.hotbar[i] = s; else if (i < 36) e.inventory[i - 9] = s; else if (i < 40) e.armor[i - 36] = s; else if (i === 40) e.offhand = s;
}
const accepts = (i: number, s: Stack | null) => !s || i < 36 || i === 40 || armorSlotOf(s.name) === i - 36;
const hasMeta = (s: Stack) => !!s.ench || !!s.label || s.durability !== undefined || !!s.loaded || !!s.patterns?.length || !!s.bannerBase || !!s.trim || !!s.sherds?.length || s.mapId !== undefined || !!s.pages || !!s.title || !!s.map || !!s.tag || s.repairCost !== undefined;
export function syncEquip(e: Engine) { e.elytraEquipped = e.armor[1]?.name === 'elytra'; if (!e.elytraEquipped) e.gliding = false; }
export function swapSlots(e: Engine, a: number, b: number) {
  if (a === b) return false;
  const sa = slotAt(e, a), sb = slotAt(e, b);
  if (!accepts(b, sa) || !accepts(a, sb)) { e.onToast('そのスロットには装備できません', 'That item does not fit there'); return false; }
  for (const [i, s] of [[a, sa], [b, sb]] as const) if (i >= 36 && i < 40 && s && lvl(s, 'curse_of_binding') && !creative(e)) { e.onToast('束縛の呪いで外せません', 'Curse of Binding: cannot be removed'); return false; }
  const max = sa ? resolve(sa.name)?.stack ?? 64 : 64;
  if (sa && sb && sa.name === sb.name && max > 1 && !hasMeta(sa) && !hasMeta(sb)) {   // merge identical stacks
    const n = Math.min(max - sb.count, sa.count);
    sb.count += n; sa.count -= n;
    if (sa.count <= 0) setSlot(e, a, null);
  } else { setSlot(e, a, sb); setSlot(e, b, sa); }
  syncEquip(e);
  return true;
}
/** Adds a stack keeping its metadata (durability, enchantments, custom name). */
export function addStack(e: Engine, s: Stack): boolean {
  const def = resolve(s.name);
  if (!def) return false;
  if (def.stack > 1 && !hasMeta(s)) return e.addItem(s.name, s.count);
  for (const arr of [e.hotbar, e.inventory]) for (let i = 0; i < arr.length; i++) if (!arr[i]) { arr[i] = { ...s }; return true; }
  return false;
}
export function takeFrom(e: Engine, i: number, n = 1) { const s = slotAt(e, i); if (!s) return; s.count -= n; if (s.count <= 0) setSlot(e, i, null); }
export function rememberDrop(e: Engine, s: Stack) { if (hasMeta(s)) (any(e).metaDrops ??= []).push({ ...s, count: 1 }); }
/** Item pickup: dropped gear gets its enchantments / wear back. */
export function pickup(e: Engine, name: string, count: number): boolean {
  if (name === 'xp_orb') { e.addXp(count); return true; }                    // death / orb drops go straight into the experience bar
  const list: Stack[] = any(e).metaDrops ?? [], i = list.findIndex(s => s.name === name);
  if (i >= 0 && count === 1) { if (!addStack(e, list[i])) return false; list.splice(i, 1); return true; }
  return e.addItem(name, count);
}
export function toggleElytra(e: Engine) {
  if (e.armor[1]?.name === 'elytra') { if (addStack(e, e.armor[1])) e.armor[1] = null; }
  else { for (let i = 0; i < 36; i++) if (slotAt(e, i)?.name === 'elytra') { swapSlots(e, i, 37); break; } }
  syncEquip(e);
}
function equipHeld(e: Engine, held: Stack): boolean {
  const slot = armorSlotOf(held.name), prev = e.armor[slot];
  if (prev && lvl(prev, 'curse_of_binding') && !creative(e)) return true;
  e.armor[slot] = held; e.hotbar[e.selected] = prev; syncEquip(e);
  e.audio?.play('wood'); e.handDip = 0.18;
  const def = resolve(held.name);
  e.onToast(`${def?.ja ?? held.name} を装備しました`, `Equipped ${held.name.replace(/_/g, ' ')}`);
  return true;
}

// ---- Armor & durability --------------------------------------------------------------------------------------------------
const ARMOR_VALUES: Record<string, [number, number, number, number]> = { leather: [1, 3, 2, 1], chainmail: [2, 5, 4, 1], iron: [2, 6, 5, 2], golden: [2, 5, 3, 1], diamond: [3, 8, 6, 3], netherite: [3, 8, 6, 3], turtle: [2, 0, 0, 0], copper: [2, 4, 3, 1], wooden: [1, 2, 1, 1], stone: [1, 3, 2, 1] };
export function armorPoints(e: Engine): number {
  let n = 0;
  e.armor.forEach((s, i) => { const v = s && ARMOR_VALUES[s.name.split('_')[0]]; if (v) n += v[i]; });
  return Math.min(20, n);
}
const toughness = (e: Engine) => e.armor.reduce((n, s) => n + (s?.name.startsWith('diamond_') ? 2 : s?.name.startsWith('netherite_') ? 3 : 0), 0);
const enchSum = (e: Engine, id: string) => e.armor.reduce((n, s) => n + lvl(s, id), 0);
/** Wears a stack down; Unbreaking gives a chance to ignore each point. Returns true when it broke. */
export function wearStack(e: Engine, s: Stack, n = 1): boolean {
  const max = resolve(s.name)?.durability;
  if (!max || creative(e)) return false;
  const unb = lvl(s, 'unbreaking');
  for (let i = 0; i < n; i++) if (!unb || Math.random() < 1 / (unb + 1)) s.durability = (s.durability ?? max) - 1;
  return (s.durability ?? max) <= 0;
}
export function wear(e: Engine, where: 'main' | 'off' | number, n = 1) {
  const s = where === 'main' ? e.hotbar[e.selected] : where === 'off' ? e.offhand : e.armor[where];
  if (!s || !wearStack(e, s, n)) return;
  if (where === 'main') e.hotbar[e.selected] = null; else if (where === 'off') e.offhand = null; else e.armor[where] = null;
  const def = resolve(s.name);
  e.audio?.play('glass');
  e.onToast(`${def?.ja ?? s.name} が壊れました`, `${s.name.replace(/_/g, ' ')} broke`);
  syncEquip(e);
}
/** Mending: XP repairs a random damaged equipped item (2 durability per point) before it is added to the bar. */
export function mend(e: Engine, xp: number): number {
  const cands = [e.hotbar[e.selected], e.offhand, ...e.armor].filter(s => s && lvl(s, 'mending') && s.durability !== undefined && s.durability < (resolve(s.name)?.durability ?? 0)) as Stack[];
  if (!cands.length) return xp;
  const s = cands[Math.floor(Math.random() * cands.length)], max = resolve(s.name)!.durability!;
  const repair = Math.min(max - s.durability!, xp * 2);
  s.durability! += repair;
  return xp - Math.ceil(repair / 2);
}

// ---- Status effects ------------------------------------------------------------------------------------------------------
export const has = (e: Engine, id: string) => (e.effects[id]?.t ?? 0) > 0;
/** 0 when absent, otherwise the 1-based level. */
export const amp = (e: Engine, id: string) => (has(e, id) ? e.effects[id].amp + 1 : 0);
export function addEffect(e: Engine, id: string, sec: number, a = 0): boolean {
  if (!EFFECTS[id]) return false;
  if (id === 'instant_health') { e.health = Math.min(20, e.health + 4 * 2 ** a); return true; }
  if (id === 'instant_damage') { hurt(e, 6 * 2 ** a, 'magic'); return true; }
  if (id === 'saturation') { eatNow(e, 1 + a, 2 * (1 + a)); return true; }
  const cur = e.effects[id];
  if (!cur || a > cur.amp || (a === cur.amp && sec > cur.t)) e.effects[id] = { t: sec, amp: a };
  if (id === 'absorption') e.absorption = Math.max(e.absorption, 4 * (a + 1));
  if (id === 'levitation') e.levitationTimer = Math.max(e.levitationTimer, sec);
  return true;
}
export function clearEffects(e: Engine) { e.effects = {}; e.absorption = 0; e.levitationTimer = 0; }
/**
 * Movement multipliers (Java 1.21). 'effects': movement_speed modifiers — Speed +20 % and Slowness −15 % per level, both
 * ADD_MULTIPLIED_TOTAL, so they multiply. 'use': the input is scaled by 0.2 while an item is in use (bow, crossbow, food, raised
 * shield — LocalPlayer.aiStep uses 0.2 for all). 'sneak': sneaking_speed attribute 0.3 + 0.15 per Swift Sneak level (max 1).
 * 'stuck': cobweb displacement factor (Entity.makeStuckInBlock). 'all': the combined ground factor kept for older callers.
 */
export type SpeedPart = 'all' | 'effects' | 'use' | 'sneak' | 'stuck';
export function speedFactor(e: Engine, part: SpeedPart = 'all'): number {
  const effects = (1 + 0.2 * amp(e, 'speed')) * Math.max(0, 1 - 0.15 * amp(e, 'slowness'));
  const use = e.blocking || (e.useItemName && e.useTime > 0.05) ? 0.2 : 1;
  const sneak = Math.min(1, 0.3 + 0.15 * lvl(e.armor[2], 'swift_sneak'));
  const stuck = cobwebSpeedFactor(!!any(e).w121?.inCobweb?.(), has(e, 'weaving'));
  if (part === 'effects') return effects;
  if (part === 'use') return use;
  if (part === 'sneak') return sneak;
  if (part === 'stuck') return stuck;
  let f = effects * use * stuck;
  if (e.input.crouch) f *= sneak / 0.3;
  if (inWater(e)) f *= 1 + 0.33 * lvl(e.armor[3], 'depth_strider');
  return Math.max(0.05, f);
}
/** LivingEntity.getJumpBoostPower: +0.1 blocks / tick per Jump Boost level on top of the 0.42 jump. */
export const jumpBoost = (e: Engine) => 0.1 * amp(e, 'jump_boost');
export const oxygenRate = (e: Engine) => (has(e, 'water_breathing') ? 0 : (e.armor[0]?.name === 'turtle_helmet' ? 0.5 : 1) / (1 + lvl(e.armor[0], 'respiration')));
export function drown(e: Engine, dt: number) { const a = any(e); a._drown = (a._drown ?? 0) + dt; if (a._drown >= 1) { a._drown = 0; hurt(e, 2, 'drown'); } }
/**
 * Fall damage (LivingEntity.calculateFallDamage): ceil((distance − 3 − Jump Boost level) × multiplier). `multiplier` comes from
 * the landing block (hay bale / honey block 0.2, slime 0 unless sneaking); beds halve the distance before this is called.
 */
export function fallDamage(e: Engine, fall: number, multiplier = 1) {
  if (has(e, 'slow_falling')) return;
  const a = any(e);
  if (a.windFloor !== undefined) { if (e.elapsed - (a.windFloorAt ?? 0) < 10) fall = Math.max(0, Math.min(fall, a.windFloor - e.position.y)); a.windFloor = undefined; }
  const dmg = fallDamageAmount(fall, amp(e, 'jump_boost'), multiplier);
  if (dmg > 0) hurt(e, dmg, 'fall');
}
/**
 * 作業B: the effect of a mob's melee hit is decided by the mob that actually attacked (was: nearest hostile within 5 blocks).
 * Values: combatRules.meleeEffect (cave spider 7 s / 15 s poison, wither skeleton 10 s wither, husk hunger by regional difficulty).
 */
function mobEffect(e: Engine, species: string | undefined) {
  if (!species) return;
  if (species === 'wither') { addEffect(e, 'wither', e.meta.difficulty === 'hard' ? 40 : 10, 1); return; }   // wither skulls (未確認: melee path)
  const fx = CR.meleeEffect(species, e.meta.difficulty);
  if (fx) addEffect(e, fx[0], fx[1], fx[2]);
}

/** Who / what dealt the damage: the position matters for the shield arc, `axe` disables shields, `pierce` > 0 ignores them. */
export interface Attacker {
  from?: THREE.Vector3; axe?: boolean; pierce?: number;
  /** 作業B: species of the attacking mob (on-hit effects) and the mob itself (Thorns hits only this attacker). */
  species?: string;
  mob?: unknown;
}
export type HurtResult = 'none' | 'blocked' | 'hit' | 'dead';
export const shieldCooldown = (e: Engine) => Math.max(0, (any(e).shieldCdUntil ?? -1) - e.elapsed);
/** Raised for ≥ 5 ticks, not disabled, and still the item in the raising hand. */
export function shieldReady(e: Engine): boolean {
  const sr = any(e).shieldRaise as { hand: Hand; start: number } | null | undefined;
  return !!sr && !!e.blocking && handStack(e, sr.hand)?.name === 'shield' && e.elapsed - sr.start >= V.SHIELD_DELAY && shieldCooldown(e) <= 0;
}
/** Axe hits / wardens put every shield on a 5 second cooldown and lower it. */
export function disableShield(e: Engine, seconds = V.SHIELD_DISABLE) {
  any(e).shieldCdUntil = e.elapsed + seconds; any(e).shieldRaise = null; e.blocking = false;
  e.audio?.play('glass');
  e.onToast(`盾が${seconds}秒間使用不能になった！`, `Your shield is disabled for ${seconds} seconds!`);
}

/**
 * All damage to the player: shield (180° arc, 5-tick warm-up, piercing arrows ignore it, axes disable it), armor (with toughness),
 * Resistance, Protection enchantments, absorption, food exhaustion, totems and death drops.
 */
export function hurt(e: Engine, amount: number, source = 'generic', silent = false, atk?: Attacker): HurtResult {
  if (creative(e) || e.meta.mode === 'spectator' || e.dead || !(amount > 0)) return 'none';
  if (source === 'fire' && has(e, 'fire_resistance')) return 'none';
  const yaw = e.input.yaw ?? 0;
  if (atk?.from) any(e).lastHit = { angle: V.hitAngle(yaw, e.position.x, e.position.z, atk.from.x, atk.from.z), t: e.elapsed };
  if (source !== 'sonic_boom' && atk?.from && (source === 'mob' || source === 'projectile' || source === 'explosion') && !V.SHIELD_BYPASS.has(source) && !((atk.pierce ?? 0) > 0)
    && shieldReady(e) && V.attackerInFront(yaw, e.position.x, e.position.z, atk.from.x, atk.from.z)) {
    const hand = (any(e).shieldRaise as { hand: Hand }).hand, cost = V.shieldWear(amount);
    if (cost) wear(e, hand, cost);
    e.audio?.play('wood');
    e.particles.burst(e.camera.position.clone().add(e.camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(0.8)), '#c9b98a', 6, 2);
    if (atk.axe) disableShield(e);
    return 'blocked';
  }
  // 作業B: invulnerability timer — within 10 ticks of a hit only damage above the previous one applies (excess only).
  // 'void' bypasses it (未確認: Java DamageTypeTags.BYPASSES_COOLDOWN contents).
  let fresh = true;
  if (source !== 'void') {
    const r = CR.applyIFrames(any(e)._iframes ??= {}, amount, e.elapsed);
    if (r.dmg <= 0) return 'none';
    amount = r.dmg; fresh = r.fresh;
  }
  // Fill in the attacker from the mob manager when the host did not pass it (engine's mob damage hook only sends `from`).
  if (source === 'mob' && atk && !atk.species && e.mobs?.attacker) { atk.species = e.mobs.attacker.species; atk.mob ??= e.mobs.attacker; }
  // 作業B: knockback 0.4 away from the attacker, added to engine.velocity (blocks/second) — 作業A owns how it decays.
  if (fresh && atk?.from && (source === 'mob' || source === 'projectile')) knockPlayer(e, CR.BASE_KNOCKBACK, e.position.x - atk.from.x, e.position.z - atk.from.z);
  let dmg = amount;
  const armorApplies = !['fall', 'drown', 'starve', 'void', 'magic', 'sonic_boom'].includes(source);
  if (armorApplies) {
    const a = armorPoints(e);
    dmg *= 1 - Math.min(20, Math.max(a / 5, a - (4 * dmg) / (toughness(e) + 8))) / 25;
  }
  if (source !== 'void' && source !== 'starve') {
    dmg *= Math.max(0, 1 - 0.2 * amp(e, 'resistance'));
    let epf = enchSum(e, 'protection');
    if (source === 'fire') epf += 2 * enchSum(e, 'fire_protection');
    if (source === 'explosion') epf += 2 * enchSum(e, 'blast_protection');
    if (source === 'projectile') epf += 2 * enchSum(e, 'projectile_protection');
    if (source === 'fall') epf += 3 * lvl(e.armor[3], 'feather_falling');
    dmg *= 1 - Math.min(20, epf) / 25;
  }
  if (dmg <= 0.01) return 'none';
  if (armorApplies) for (let i = 0; i < 4; i++) if (e.armor[i]) wear(e, i, Math.max(1, Math.floor(amount / 4)));
  if (source === 'mob') {
    // 作業B: Thorns rolls per armour piece and only hurts the attacking mob (was: every mob within 3.5 blocks).
    const mob = atk?.mob as Parameters<typeof e.mobs.damageMob>[0] | undefined;
    if (mob && typeof e.mobs.damageMob === 'function') for (let i = 0; i < 4; i++) {
      const d = CR.thornsDamage(lvl(e.armor[i], 'thorns'), Math.random);
      if (d > 0) { e.mobs.damageMob(mob, d, new THREE.Vector3(mob.group.position.x - e.position.x, 0, mob.group.position.z - e.position.z).normalize()); wear(e, i, 2); }
    }
    mobEffect(e, atk?.species);
  }
  if (e.absorption > 0) { const a = Math.min(e.absorption, dmg); e.absorption -= a; dmg -= a; }
  if (dmg > 0 && armorApplies) exhaust(e, 0.1);                       // Java: damaging hits cost 0.1 exhaustion (fall / drowning / magic cost none)
  e.health = Math.max(0, e.health - dmg);
  e.hitFlash = 0.35;
  any(e).w121?.onPlayerHurt?.(dmg, source);
  if (!silent) e.audio?.play('hurt');
  if (e.health > 0) return 'hit';
  const totem = e.hotbar[e.selected]?.name === 'totem_of_undying' ? 'main' : e.offhand?.name === 'totem_of_undying' ? 'off' : null;
  if (totem && source !== 'void') {
    if (totem === 'main') e.hotbar[e.selected] = null; else e.offhand = null;
    clearEffects(e);
    e.health = 1;
    addEffect(e, 'regeneration', 45, 1); addEffect(e, 'absorption', 5, 1); addEffect(e, 'fire_resistance', 40, 0);
    e.particles.burst(e.position.clone().add(new THREE.Vector3(0, 1, 0)), '#f6d33c', 40, 6);
    e.audio?.play('levelup');
    e.onToast('不死のトーテムが発動した！', 'Totem of Undying saved you!');
    return 'hit';
  }
  any(e).w121?.onPlayerDeath?.();
  deathDrops(e);
  e.dead = true;
  e.pause();
  e.onScreen('death');
  return 'dead';
}

/**
 * Death: everything in the inventory, armour and off-hand drops where the player died — except items with Curse of Vanishing,
 * which are destroyed. Experience drops as 7 points per level (max 100) and the level resets.
 */
export function deathDrops(e: Engine): { dropped: number; vanished: number; xp: number } {
  const res = { dropped: 0, vanished: 0, xp: 0 };
  if (creative(e) || any(e).gamerules?.keepInventory) return res;
  const pos = e.position.clone().add(new THREE.Vector3(0, 0.6, 0));
  const handle = (s: Stack | null) => {
    if (!s || s.count <= 0) return;
    if (lvl(s, 'curse_of_vanishing')) { res.vanished += s.count; return; }
    res.dropped += s.count;
    const color = resolve(s.name)?.color ?? '#aaaaaa';
    if (hasMeta(s)) for (let i = 0; i < s.count; i++) { rememberDrop(e, { ...s, count: 1 }); e.particles.drop(pos, s.name, 1, color, s); }
    else e.particles.drop(pos, s.name, s.count, color);
  };
  for (const s of [...e.hotbar, ...e.inventory, ...e.armor, e.offhand]) handle(s);
  e.hotbar = Array(9).fill(null); e.inventory = Array(27).fill(null); e.armor = [null, null, null, null]; e.offhand = null;
  any(e).shieldRaise = null; e.blocking = false; e.useItemName = ''; e.useTime = 0;
  syncEquip(e);
  res.xp = V.deathXp(e.xp);
  if (res.xp > 0) e.particles.drop(pos, 'xp_orb', res.xp, '#b8f25a');
  e.xp = 0; e.lastLevel = 0;
  e.statistics.deaths = (e.statistics.deaths ?? 0) + 1;
  if (res.vanished) e.onToast(`消滅の呪いで ${res.vanished} 個のアイテムが消えた`, `${res.vanished} item(s) vanished (Curse of Vanishing)`);
  return res;
}

// ---- Melee: attack cooldown, crits, sweep, mace smash and weapon enchantments -----------------------------------------------
/** 作業B: attack_speed per item (hoes by material: wood/gold 1, stone 2, iron 3, diamond/netherite 4) — combatRules.attackSpeed. */
function attackSpeed(name?: string): number { return CR.attackSpeed(name); }
/** Wiki: clamp((t + 0.5) / T) with T = 20 / attack_speed ticks. */
export const attackCharge = (e: Engine) => CR.attackStrength(e.elapsed - e.attackAt, attackSpeed(e.hotbar[e.selected]?.name));
/** Netherite armour: knockback_resistance 0.1 per piece. */
export const playerKnockbackResistance = (e: Engine) => e.armor.reduce((n, s) => n + (s?.name.startsWith('netherite_') ? 0.1 : 0), 0);
/**
 * 作業B: knockback on the player, given as an ADDITION to engine.velocity (blocks/second) as agreed with 作業A. The horizontal
 * impulse is strength × (1 − resistance); on the ground the vertical speed is raised towards min(0.4, vy/2 + strength) b/t.
 * The current code overwrites horizontal velocity from input every frame, so the horizontal part may not show until 作業A lands.
 */
export function knockPlayer(e: Engine, strength: number, px: number, pz: number) {
  const before = { x: e.velocity.x, y: e.velocity.y, z: e.velocity.z };
  const after = CR.applyKnockback({ x: 0, y: before.y, z: 0 }, strength, px, pz, e.grounded, playerKnockbackResistance(e));
  e.velocity.x += after.x; e.velocity.z += after.z;
  if (after.y > before.y) e.velocity.y += after.y - before.y;
}
const CLIMBABLE = /^(ladder|vine|weeping_vines|twisting_vines|cave_vines|scaffolding)/;
const UNDEAD = new Set(['zombie', 'skeleton', 'wither', 'wither_skeleton', 'zombie_villager', 'stray', 'bogged', 'phantom', 'drowned', 'husk', 'zoglin', 'zombified_piglin', 'skeleton_horse', 'zombie_horse']);
const ARTHROPOD = new Set(['spider', 'bee', 'cave_spider', 'silverfish', 'endermite']);
const AQUATIC = new Set(['fish', 'salmon', 'tropical_fish', 'pufferfish', 'tadpole', 'dolphin', 'squid', 'glow_squid', 'turtle', 'guardian', 'elder_guardian', 'axolotl', 'drowned']);
/**
 * 作業B: Java Player.attack. The view ray is tested against mob hitboxes and blocks: whichever is closer wins (entity reach 3 in
 * survival / 5 in creative, block reach 4.5 / 5). Returns true when an entity was attacked (the caller then skips mining).
 * Damage = base × (0.2 + 0.8p²) (× 1.5 crit, base only) + enchantments × p (+ mace smash), no rounding. A fresh swing at air
 * resets the cooldown. Invulnerability, knockback and burning are applied by the mob manager.
 */
export function tryAttack(e: Engine, held: Stack | null, tool: ReturnType<typeof resolve>): boolean {
  if (e.blocking) return false;                                              // Java: no attacking while a shield is raised
  const fresh = !e.swingHeld, a = any(e);
  e.swingHeld = true;
  const charge = attackCharge(e);
  if (!fresh && (charge < 1 || e.elapsed - (a._hitCheck ?? 0) < 0.1)) return false;   // holding the button re-swings at full strength only
  if (fresh && e.elapsed - e.attackAt < 0.1) return false;
  a._hitCheck = e.elapsed;
  const dir = e.camera.getWorldDirection(new THREE.Vector3()), o = e.camera.position, name = held?.name ?? '';
  const mode = e.meta.mode, reach = CR.entityReach(mode);
  const blockT = typeof e.getBlock === 'function'
    ? CR.rayBlockDistance((x, y, z) => e.getBlock(x, y, z), id => id > 0 && id !== ID.water && id !== ID.lava && id !== ID.air, o.x, o.y, o.z, dir.x, dir.y, dir.z, CR.blockReach(mode))
    : Infinity;
  const mobs = e.mobs as typeof e.mobs & { rayPick?: typeof e.mobs.rayPick };
  const pick = typeof mobs.rayPick === 'function' ? mobs.rayPick(o, dir, Math.min(reach, blockT)) : undefined;
  const missReset = () => { if (fresh && blockT === Infinity) { e.attackAt = e.elapsed; e.handDip = 0.12; } };   // swinging at air
  if (pick === null) { missReset(); return false; }
  const target = pick?.mob;
  const base = (tool?.damage ?? 2) + 3 * amp(e, 'strength') - 4 * amp(e, 'weakness');
  const special = target ? (UNDEAD.has(target.species) ? 2.5 * lvl(held, 'smite') : 0) + (ARTHROPOD.has(target.species) ? 2.5 * lvl(held, 'bane_of_arthropods') : 0) + (AQUATIC.has(target.species) ? 2.5 * lvl(held, 'impaling') : 0) : 0;
  const ench = (lvl(held, 'sharpness') ? 0.5 * lvl(held, 'sharpness') + 0.5 : 0) + special;
  const fall = Math.max(0, (a.fallTop ?? e.position.y) - e.position.y), falling = !e.grounded && e.velocity.y < 0;
  const smash = name === 'mace' && falling && fall > 1.5;
  const smashBonus = smash ? smashDamage(fall, lvl(held, 'density')) : 0;
  const sprinting = !!(a.sprinting ?? e.input.run);
  const feet = typeof e.getBlock === 'function' ? BLOCKS[e.getBlock(e.position.x, e.position.y + 0.1, e.position.z)]?.name ?? '' : '';
  const crit = CR.canCrit({ charge, fallDistance: falling ? fall : 0, onGround: e.grounded, onClimbable: CLIMBABLE.test(feet), inWater: typeof e.getBlock === 'function' && inWater(e),
    blind: has(e, 'blindness'), slowFalling: has(e, 'slow_falling'), levitation: has(e, 'levitation'), riding: !!e.mobs.riding, sprinting });
  const { total: dmg, scaledBase } = CR.meleeDamage(base, ench, charge, crit, smashBonus);
  e.mobs.looting = lvl(held, 'looting');
  if (e.mobs.behaviors) e.mobs.behaviors.breach = name === 'mace' ? lvl(held, 'breach') : 0;
  e.mobs.lastHit = null;
  if (!e.mobs.hit(o, dir, dmg, crit, reach, blockT)) { missReset(); return false; }
  e.attackAt = e.elapsed;
  e.handDip = 0.12;
  const m = any(e.mobs).lastHit as (ReturnType<typeof e.mobs.nearestHostile>), flat = dir.clone().setY(0).normalize();
  const landed = typeof e.mobs.lastHitDamage === 'number' ? (e.mobs.lastHitDamage > 0 || !m) : true;
  if (landed) exhaust(e, 0.1);                                               // each damaging attack costs 0.1 exhaustion
  if (m && landed) {
    // Java: Player.crit(target) on a critical hit, Player.magicCrit(target) when the weapon's enchantments add damage to this mob.
    const hitBox = () => entityFxBox(m.group, m.head);
    if (crit) e.particles.crit?.(hitBox);
    if (lvl(held, 'sharpness') > 0 || special > 0) e.particles.enchantedHit?.(hitBox);
    const fire = lvl(held, 'fire_aspect');
    if (fire && typeof e.mobs.ignite === 'function') { e.mobs.ignite(m, CR.fireAspectSeconds(fire)); e.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 1, 0)), '#ff8a2a', 10, 3); }
    const sk = CR.sprintKnock(charge, sprinting), kb = lvl(held, 'knockback') + (sk ? 1 : 0);
    if (kb > 0 && typeof e.mobs.knock === 'function') e.mobs.knock(m, kb * 0.5, flat.x, flat.z);       // Java: knockback(k × 0.5, yaw)
    const sweep = CR.canSweep({ sword: name.endsWith('_sword'), charge, crit, sprintKnock: sk, onGround: e.grounded, horizSpeed: Math.hypot(e.velocity.x, e.velocity.z) });
    if (sweep) {
      const sw = lvl(held, 'sweeping_edge'), sd = CR.sweepDamage(scaledBase, sw);
      let n = 0;
      if (typeof e.mobs.damageMob === 'function' && Array.isArray(e.mobs.mobs)) {
        const [tw, th] = CR.mobHitbox(m.species, m.group.scale.y), tp = m.group.position;
        const area = CR.inflate(CR.boxAt(tp.x, tp.y, tp.z, tw, th), CR.SWEEP_INFLATE.x, CR.SWEEP_INFLATE.y, CR.SWEEP_INFLATE.z);
        for (const o2 of [...e.mobs.mobs]) {
          if (o2 === m || o2.hp <= 0 || o2.tamed) continue;
          const [w2, h2] = CR.mobHitbox(o2.species, o2.group.scale.y), q = o2.group.position;
          if (!CR.intersects(area, CR.boxAt(q.x, q.y, q.z, w2, h2)) || q.distanceToSquared(e.position) >= CR.SWEEP_PLAYER_RANGE ** 2) continue;
          if (typeof e.mobs.knock === 'function') e.mobs.knock(o2, CR.BASE_KNOCKBACK, flat.x, flat.z);
          e.mobs.damageMob(o2, sd); n++;
        }
      } else n = e.mobs.hurtNear(m.group.position, 1.9, sd, m);
      if (n) any(e.particles).spark?.(m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0)), '#ffffff', 12);
    }
    if (smash) {
      a.fallTop = e.position.y;                                                    // a landed smash cancels the fall damage
      const wb = lvl(held, 'wind_burst'), at = m.group.position;
      e.velocity.y = Math.max(e.velocity.y, wb ? windBurstVelocity(wb) : 2);
      if (wb) {
        a.windFloor = e.position.y; a.windFloorAt = e.elapsed;
        e.grounded = false;
        e.mobs.behaviors?.windBurst(at.x, at.y + 0.5, at.z, WIND_BURST_RADIUS, 'mace', m);
      }
      any(e).w121?.events.emit('mace_smash', { x: at.x, y: at.y, z: at.z, fall, damage: dmg, density: lvl(held, 'density'), breach: lvl(held, 'breach'), windBurst: wb });
      e.mobs.hurtNear(m.group.position, 3, Math.max(1, dmg * 0.25), m);
      e.particles.burst(m.group.position.clone(), '#d8d8e8', 30, 7);
      e.audio?.play('explosion', m.group.position);
    }
    if (held && tool?.durability) wear(e, 'main', name.endsWith('_sword') || name === 'trident' || name === 'mace' ? 1 : 2);
  }
  return true;
}

// ---- Mining helpers: Efficiency / Haste / Fatigue / Aqua Affinity, Silk Touch and Fortune ----------------------------------
/**
 * Time multiplier for breaking blocks from status effects and water (minecraft.wiki "Breaking"): Haste / Conduit Power
 * ×(1 + 0.2 × level) speed, Mining Fatigue 0.3 / 0.09 / 0.0027 / 0.00081 (hard-coded per level), head under water ×0.2 unless the
 * helmet has Aqua Affinity. Efficiency is part of the tool speed (systems/mining.ts breakProgressPerTick), being on the ground too.
 */
export function miningFactor(e: Engine, _held: Stack | null, underwater: boolean): number {
  let speed = 1;
  const haste = Math.max(amp(e, 'haste'), amp(e, 'conduit_power'));
  if (haste) speed *= 1 + 0.2 * haste;
  const fatigue = amp(e, 'mining_fatigue');
  if (fatigue) speed *= FATIGUE_MULTIPLIER[Math.min(4, fatigue)];
  if (underwater && !lvl(e.armor[0], 'aqua_affinity')) speed *= 0.2;
  return 1 / speed;
}
const SILKY = /_ore$|^grass_block$|^stone$|^deepslate$|glass|^ice$|^packed_ice$|_leaves$|^mycelium$|^podzol$|^bookshelf$|^glowstone$|^sea_lantern$|^melon$|^clay$|^snow_block$|coral|^sculk|^cobweb$|^amethyst|^gilded_blackstone$/;
export function drops(_e: Engine, b: BlockDef, tool: ReturnType<typeof resolve>, held: Stack | null, state: number) {
  if (b.name === 'frosted_ice') return [];
  if (b.name === 'budding_amethyst' || b.name.endsWith('_amethyst_bud') || b.name === 'amethyst_cluster') {
    return amethystDrops(b.name, tool?.tool === 'pickaxe' || (held?.name ?? '').endsWith('_pickaxe'), lvl(held, 'silk_touch') > 0, lvl(held, 'fortune'));
  }
  const list = blockDrops(b, tool, state);
  if (lvl(held, 'silk_touch') && SILKY.test(b.name) && b.name !== 'spawner' && (list.length || /glass|_leaves$|^ice$|^packed_ice$|cobweb/.test(b.name))) return [{ name: b.name, count: 1 }];
  const fortune = lvl(held, 'fortune');
  if (fortune && list.length) {
    if (/_ore$/.test(b.name) && list[0].name !== b.name) list[0].count *= 1 + Math.max(0, Math.floor(Math.random() * (fortune + 2)) - 1);
    else if (['glowstone', 'melon', 'sea_lantern', 'nether_wart', 'wheat_crop', 'carrots', 'carrot_crop', 'potatoes', 'potato_crop', 'beetroots', 'beetroot_crop', 'sweet_berry_bush'].includes(b.name)) list[0].count += Math.floor(Math.random() * (fortune + 1));
    else if (b.name === 'gravel' && Math.random() < 0.14 * fortune) list[0].name = 'flint';
  }
  return list;
}

// ---- Use: equipping, shield, bow / crossbow / trident charging, potions, special foods -------------------------------------
const CHARGE: Record<string, number> = { bow: 1, crossbow: 1.25, trident: 0.5 };
/** Eating/drinking duration in seconds: 0.8s (16 ticks) for dried_kelp, 1.6s (32 ticks) for regular food & drinks. */
export const eatDuration = (name: string): number => (name === 'dried_kelp' ? 0.8 : 1.6);
export const isDrinkItem = (name: string): boolean =>
  name === 'milk_bucket' || name === 'honey_bottle' || name === 'water_bottle' || name === 'potion' ||
  name.endsWith('_potion') || /^potion_|^awkward_|^mundane_|^thick_/.test(name);
export const isEating = (e: Engine): boolean => !!e.useItemName && !CHARGE[e.useItemName] && e.useTime >= 0;

export function foodEffects(e: Engine, name: string) {
  if (name === 'golden_apple') { addEffect(e, 'regeneration', 5, 1); addEffect(e, 'absorption', 120, 0); }
  else if (name === 'enchanted_golden_apple') { addEffect(e, 'regeneration', 20, 1); addEffect(e, 'absorption', 120, 3); addEffect(e, 'resistance', 300, 0); addEffect(e, 'fire_resistance', 300, 0); }
  else if (name === 'rotten_flesh' && Math.random() < 0.8) addEffect(e, 'hunger', 30, 0);
  else if (name === 'spider_eye') addEffect(e, 'poison', 5, 0);
  else if (name === 'poisonous_potato' && Math.random() < 0.6) addEffect(e, 'poison', 5, 0);
  else if (name === 'pufferfish') { addEffect(e, 'hunger', 15, 2); addEffect(e, 'poison', 60, 1); addEffect(e, 'nausea', 15, 0); }
  else if (name === 'honey_bottle') delete e.effects.poison;
  else if (name === 'suspicious_stew') {
    const fx = suspiciousStewEffect(e.hotbar[e.selected] ?? { name: 'suspicious_stew', count: 1 });
    if (fx) addEffect(e, fx.id, fx.duration, fx.amplifier);
  }
}

export function completeEat(e: Engine, held: Stack, def: ReturnType<typeof resolve>, hand: Hand = useHandOf(e)): boolean {
  const name = held.name;
  const potion = potionEffects(name);
  if (potion && !potion.splash) {
    for (const [id, sec, a] of potion.effects) addEffect(e, id, sec, a);
    e.audio?.play('drink');
    if (!creative(e)) setHand(e, hand, { name: 'glass_bottle', count: 1 });
    e.handDip = 0.22;
    return true;
  }
  if (['water_bottle', 'awkward_potion', 'mundane_potion', 'thick_potion', 'potion'].includes(name)) {
    e.audio?.play('drink');
    e.handDip = 0.22;
    if (!creative(e)) setHand(e, hand, { name: 'glass_bottle', count: 1 });
    return true;
  }
  if (name === 'ominous_bottle') {
    const ampVal = ominousBottleAmplifier(held);
    addEffect(e, 'bad_omen', OMINOUS_BOTTLE_DURATION, ampVal);
    e.audio?.play('drink');
    e.handDip = 0.22;
    if (!creative(e)) {
      held.count--;
      if (held.count <= 0) setHand(e, hand, null);
    }
    return true;
  }
  if (name === 'milk_bucket') {
    clearEffects(e);
    e.mobs.badOmen = false;
    e.audio?.play('drink');
    e.handDip = 0.22;
    if (!creative(e)) setHand(e, hand, { name: 'bucket', count: 1 });
    return true;
  }
  if (def?.food) {
    if (name === 'suspicious_stew') {
      const fx = suspiciousStewEffect(held);
      if (fx) addEffect(e, fx.id, fx.duration, fx.amplifier);
    }
    if (name === 'golden_apple') { addEffect(e, 'regeneration', 5, 1); addEffect(e, 'absorption', 120, 0); }
    else if (name === 'enchanted_golden_apple') { addEffect(e, 'regeneration', 20, 1); addEffect(e, 'absorption', 120, 3); addEffect(e, 'resistance', 300, 0); addEffect(e, 'fire_resistance', 300, 0); }
    else if (name === 'rotten_flesh' && Math.random() < 0.8) addEffect(e, 'hunger', 30, 0);
    else if (name === 'spider_eye') addEffect(e, 'poison', 5, 0);
    else if (name === 'poisonous_potato' && Math.random() < 0.6) addEffect(e, 'poison', 5, 0);
    else if (name === 'pufferfish') { addEffect(e, 'hunger', 15, 2); addEffect(e, 'poison', 60, 1); addEffect(e, 'nausea', 15, 0); }
    else if (name === 'honey_bottle') delete e.effects.poison;
    const [nutrition, sat] = V.foodValue(name, def.food);
    eatNow(e, nutrition, sat);
    e.audio?.play(name === 'honey_bottle' ? 'drink' : 'eat');
    e.handDip = 0.22;
    if (name === 'chorus_fruit') {
      const rx = e.position.x + (Math.random() - 0.5) * 14, rz = e.position.z + (Math.random() - 0.5) * 14;
      e.teleport(rx, e.terrain.height(rx, rz) + 1.1, rz);
    }
    if (!creative(e)) {
      held.count--;
      const emptyContainer = name === 'honey_bottle' ? { name: 'glass_bottle', count: 1 } : (name === 'suspicious_stew' || name === 'mushroom_stew' || name === 'rabbit_stew' || name === 'beetroot_soup') ? { name: 'bowl', count: 1 } : null;
      if (held.count <= 0) setHand(e, hand, emptyContainer);
      else if (name === 'honey_bottle') addStack(e, { name: 'glass_bottle', count: 1 });
    }
    return true;
  }
  return false;
}

/**
 * Brush interaction on Suspicious Sand / Suspicious Gravel:
 * Advances dusting stage 0 -> 1 -> 2 -> 3 -> excavation, emitting sand/gravel dust particles and brush sound,
 * then drops the excavated Pottery Sherd / relic and converts the block to regular sand or gravel.
 */
export function brushBlock(e: Engine, x: number, y: number, z: number, hand: Hand = 'main'): { stage: number; completed: boolean; loot: string | null } | null {
  const cell = e.getCell(x, y, z), id = blockId(cell);
  if (id !== ID.suspicious_sand && id !== ID.suspicious_gravel) return null;
  const st = blockState(cell) & 3;
  const col = BLOCKS[id]?.color ?? '#d9c98e';
  e.particles.brushDust?.(x, y, z, col, 12);
  e.audio?.play('brush', { x, y, z });
  e.handDip = 0.16;
  const bmap: Map<string, number> = (any(e)._brushMap ??= new Map());
  const k = `${x},${y},${z}`;
  if (st < 3) {
    e.setBlock(x, y, z, id, st + 1);
    bmap.set(k, e.elapsed + 2.5);
    return { stage: st + 1, completed: false, loot: null };
  }
  bmap.delete(k);
  const loot = pickArchaeologyLoot(x, y, z, e.terrain.seed | 0);
  e.setBlock(x, y, z, id === ID.suspicious_sand ? ID.sand : ID.gravel, 0);
  e.particles.drop(new THREE.Vector3(x + 0.5, y + 0.85, z + 0.5), loot, 1, resolve(loot)?.color ?? '#b86843');
  wear(e, hand, 1);
  const def = resolve(loot);
  e.onToast(`発掘成功: ${def?.ja ?? loot}`, `Excavated ${loot.replace(/_/g, ' ')}`);
  return { stage: 4, completed: true, loot };
}

const chargeTime = (e: Engine) => { const s = handStack(e, useHandOf(e)); if (!s) return 1; if (s.name === 'crossbow') return Math.max(0.25, 1.25 - 0.25 * lvl(s, 'quick_charge')); return CHARGE[s.name] ?? eatDuration(s.name); };
const AMMO = new Set(['arrow', 'spectral_arrow', 'tipped_arrow']);
/** Java's projectile search: the off-hand first, then the inventory front to back (hotbar 0‥8, then the rows) — whichever arrow comes first. */
export function findAmmo(e: Engine): { name: string; slot: number } | null {
  if (e.offhand && AMMO.has(e.offhand.name)) return { name: e.offhand.name, slot: 40 };
  for (let i = 0; i < 36; i++) { const s = slotAt(e, i); if (s && AMMO.has(s.name)) return { name: s.name, slot: i }; }
  return null;
}
const arrowName = (e: Engine): string | null => (creative(e) ? 'arrow' : findAmmo(e)?.name ?? null);
function takeAmmo(e: Engine) { if (creative(e)) return; const a = findAmmo(e); if (a) takeFrom(e, a.slot, 1); }
function loadCrossbow(e: Engine, held: Stack) {
  if (!arrowName(e)) return;
  takeAmmo(e);
  held.loaded = true;
  e.audio?.play('click');
  e.handDip = 0.15;
}
function fireCrossbow(e: Engine, held: Stack, hand: Hand) {
  const dir = e.camera.getWorldDirection(new THREE.Vector3()), multi = lvl(held, 'multishot') > 0, pierce = lvl(held, 'piercing');
  // Piercing arrows pass through pierce + 1 mobs; only the centre arrow of a Multishot volley can be picked up again.
  [-0.17, 0, 0.17].forEach((off, i) => {
    if (!multi && off !== 0) return;
    e.mobs.shootPlayerArrow(e.camera.position, dir.clone().applyAxisAngle(UP, off), 34, 9, { pierce, recover: !creative(e) && off === 0 ? 'arrow' : undefined });
    void i;
  });
  held.loaded = false;
  e.handDip = 0.22;
  wear(e, hand, multi ? 3 : 1);
}
function release(e: Engine, held: Stack, time: number, hand: Hand) {
  const dir = e.camera.getWorldDirection(new THREE.Vector3()), origin = e.camera.position.clone();
  if (held.name === 'bow') {
    const ammo = creative(e) ? { name: 'arrow' } : findAmmo(e);
    if (!ammo) { e.onToast('矢がありません', 'Out of arrows'); return; }
    const power = Math.min(1, (time * time + time * 2) / 3);
    if (power < 0.1) return;
    const infinite = lvl(held, 'infinity') > 0 && ammo.name === 'arrow';
    if (!infinite) takeAmmo(e);
    const pw = lvl(held, 'power'), dmg = (2 + power * 4) * (1 + (pw ? 0.25 * (pw + 1) : 0));
    // Infinity arrows can't be picked up again (Java: pickup = creative only); normal arrows that stick in a block can.
    e.mobs.shootPlayerArrow(origin, dir, 8 + power * 24, Math.max(1, Math.round(dmg)), { flame: lvl(held, 'flame') > 0, punch: lvl(held, 'punch'), recover: !infinite && !creative(e) ? ammo.name : undefined });
    e.handDip = 0.2;
    wear(e, hand, 1);
  } else if (held.name === 'trident') {
    if (time < 0.5) return;
    const rip = lvl(held, 'riptide');
    if (rip) {                                                       // Riptide: launches the player instead (needs water or rain)
      if (!inWater(e) && !(e.weather !== 'clear' && e.dimension === 'overworld')) return;
      const p = e.position;
      for (let i = 0; i < (6 + rip * 4) * 4; i++) { p.addScaledVector(dir, 0.25); if (e.collides(p)) { p.addScaledVector(dir, -0.25); break; } }
      e.velocity.y = Math.max(e.velocity.y, dir.y * 12);
      any(e).fallTop = p.y;
      e.audio?.play('water');
      wear(e, hand, 1);
      return;
    }
    const stack = { ...held }, loyalty = lvl(held, 'loyalty'), channel = lvl(held, 'channeling') > 0;
    setHand(e, hand, null);
    e.audio?.play('bow');
    e.mobs.launchProjectile('trident', origin.clone().addScaledVector(dir, 0.7), dir, 26, undefined, {
      damage: 8, gravity: 7, color: '#4fa69a',
      onEnd: pos => {
        if (channel && e.weather === 'storm' && e.dimension === 'overworld') { e.environment.triggerLightning(); e.audio?.play('thunder'); e.mobs.strikeLightning(pos); e.mobs.hurtNear(pos, 3, 10); }
        wearStack(e, stack, 1);
        if (creative(e) || loyalty) (any(e).returning ??= []).push({ stack, t: 0.3 + 0.9 / Math.max(1, loyalty) });
        else { (any(e).metaDrops ??= []).push({ ...stack, count: 1 }); e.particles.drop(pos, 'trident', 1, '#4fa69a'); }
      },
    });
  }
}
function splash(e: Engine, pos: THREE.Vector3, effects: [string, number, number][], color: string) {
  e.particles.burst(pos, color, 28, 4);
  e.audio?.play('glass', pos);
  const d = pos.distanceTo(e.position.clone().add(new THREE.Vector3(0, 0.9, 0)));
  for (const [id, sec, a] of effects) {
    if (d < 4) addEffect(e, id, Math.max(1, sec * (1 - d / 4)), a);
    if (id === 'instant_damage') e.mobs.hurtNear(pos, 4, 6 * 2 ** a);
    else if (id === 'poison' || id === 'wither') e.mobs.hurtNear(pos, 4, 3 + 2 * a);
  }
}
/** Replaces one item of the held stack by another (bucket ↔ filled bucket, bottle ↔ water bottle), spilling when the inventory is full. */
function swapOne(e: Engine, out: string) {
  if (creative(e)) return;
  const h = e.hotbar[e.selected];
  if (!h) return;
  if (h.count <= 1) { e.hotbar[e.selected] = { name: out, count: 1 }; return; }
  e.consumeSelected();
  if (!addStack(e, { name: out, count: 1 })) e.particles.drop(e.position.clone(), out, 1, '#3f76e4');
}
/** Cauldron: block state 0‥3 = water layers, 4 = lava. Buckets fill / empty it, bottles move one layer. Returns false when nothing happens. */
export function cauldronUse(e: Engine, t: { x: number; y: number; z: number }, held: Stack): boolean {
  const st = blockState(e.getCell(t.x, t.y, t.z)), lava = st >= 4, lv = lava ? 3 : st, name = held.name;
  const set = (s: number) => { e.setBlock(t.x, t.y, t.z, ID.cauldron, s); e.audio?.play('water'); e.handDip = 0.2; };
  const note = (n: number) => e.onToast(`大釜の水位 ${n}/3`, `Cauldron level ${n}/3`);
  if (name === 'water_bucket' && !lava) { set(3); swapOne(e, 'bucket'); note(3); return true; }
  if (name === 'lava_bucket' && !lava && lv === 0) { set(4); swapOne(e, 'bucket'); e.onToast('大釜に溶岩', 'Lava cauldron'); return true; }
  if (name === 'bucket' && lava) { set(0); swapOne(e, 'lava_bucket'); return true; }
  if (name === 'bucket' && lv === 3) { set(0); swapOne(e, 'water_bucket'); note(0); return true; }
  if (name === 'glass_bottle' && !lava && lv >= 1) { set(lv - 1); swapOne(e, 'water_bottle'); note(lv - 1); return true; }
  if (name === 'water_bottle' && !lava && lv < 3) { set(lv + 1); swapOne(e, 'glass_bottle'); note(lv + 1); return true; }
  return false;
}
/** Next free map id. */
export function allocMapId(e: Engine): number { const id = e.nextMapId || 1; e.nextMapId = id + 1; return id; }
/** Creates a fresh explorer map centred on the player and returns its id. */
export function newMapFor(e: Engine): number {
  const id = allocMapId(e), m = newMap(id, e.dimension, e.position.x, e.position.z, 0);
  e.maps.set(id, m);
  return id;
}
/** Map data behind a filled map stack (legacy "x,z|zoom|lock" labels are converted on first use). */
export function mapOf(e: Engine, s: Stack | null | undefined): MapData | null {
  if (!s || s.name !== 'filled_map') return null;
  if (s.mapId === undefined) {
    const [pos = '0,0', zoom = '1', lock = ''] = (s.label ?? '').split('|'), [x = 0, z = 0] = pos.split(',').map(Number);
    const id = allocMapId(e), m = newMap(id, e.dimension, x || 0, z || 0, Math.max(0, Math.min(4, (Number(zoom) || 1) - 1)));
    m.locked = !!lock; e.maps.set(id, m); s.mapId = id; delete s.label;
  }
  return e.maps.get(s.mapId) ?? null;
}
/** Runs before the engine's own right-click logic. Returns true when the click was fully handled. */
export function useItem(e: Engine, held: Stack | null, def: ReturnType<typeof resolve>, hand: Hand = useHandOf(e)): boolean {
  if (!held) return false;
  const name = held.name, dir = e.camera.getWorldDirection(new THREE.Vector3());
  if (armorSlotOf(name) >= 0) return equipHeld(e, held);
  const tgt = e.target;
  if (tgt && !e.input.crouch && BLOCKS[tgt.id]?.name === 'cauldron' && cauldronUse(e, tgt, held)) return true;
  if (tgt && !e.input.crouch) {
    const tname = BLOCKS[tgt.id]?.name ?? '';
    if (name === 'honeycomb' && waxCopper((x, y, z) => e.getCell(x, y, z), (x, y, z, id, st = 0) => e.setBlock(x, y, z, id, st), tgt.x, tgt.y, tgt.z)) {
      if (!creative(e)) { held.count--; if (held.count <= 0) setHand(e, hand, null); }
      e.audio?.play('wood', tgt); e.handDip = 0.18;
      e.onToast('銅ブロックにハニカムで錆止めを施しました', 'Waxed copper block with Honeycomb');
      return true;
    }
    if (name.endsWith('_axe')) {
      const scraped = scrapeCopper((x, y, z) => e.getCell(x, y, z), (x, y, z, id, st = 0) => e.setBlock(x, y, z, id, st), tgt.x, tgt.y, tgt.z);
      if (scraped) {
        wear(e, hand, 1); e.audio?.play('stone', tgt); e.handDip = 0.18;
        e.onToast(scraped === 'unwaxed' ? '銅ブロックの錆止めを剥がしました' : '銅ブロックの錆を1段階落としました', scraped === 'unwaxed' ? 'Scraped wax off copper' : 'Scraped oxidation off copper');
        return true;
      }
    }
    if (tname === 'respawn_anchor') {
      const charges = blockState(e.getCell(tgt.x, tgt.y, tgt.z)) & 7;
      if (name === 'glowstone' && charges < 4) {
        e.setBlock(tgt.x, tgt.y, tgt.z, tgt.id, charges + 1);
        if (!creative(e)) { held.count--; if (held.count <= 0) setHand(e, hand, null); }
        e.audio?.play('portal', tgt); e.handDip = 0.18;
        e.onToast(`リスポーンアンカーをチャージしました (${charges + 1}/4)`, `Respawn Anchor charged (${charges + 1}/4)`);
        return true;
      }
      if (charges > 0) {
        if (e.dimension === 'nether') {
          any(e).netherRespawn = { x: tgt.x + 0.5, y: tgt.y + 1, z: tgt.z + 0.5, anchor: [tgt.x, tgt.y, tgt.z] };
          e.audio?.play('portal', tgt); e.handDip = 0.18;
          e.onToast('ネザーのリスポーン地点を設定しました', 'Respawn point set in the Nether');
        } else {
          e.setBlock(tgt.x, tgt.y, tgt.z, 0, 0);
          e.explode(new THREE.Vector3(tgt.x + 0.5, tgt.y + 0.5, tgt.z + 0.5), 5);
          e.onToast('リスポーンアンカーはネザー以外では爆発します！', 'Respawn Anchor explodes outside the Nether!');
        }
        return true;
      }
    }
    if (tname === 'lodestone' && name === 'compass') {
      const bound = bindLodestoneCompass(held, e.dimension, tgt.x, tgt.y, tgt.z);
      if (held.count <= 1) setHand(e, hand, bound);
      else { held.count--; addStack(e, bound); }
      e.audio?.play('click', tgt); e.handDip = 0.18;
      e.onToast(`ロードストーンコンパスを記録しました (${tgt.x}, ${tgt.y}, ${tgt.z})`, `Lodestone Compass bound to (${tgt.x}, ${tgt.y}, ${tgt.z})`);
      return true;
    }
  }
  if (name === 'bundle') {
    if (bundleWeight(held) > 0) {
      for (const item of bundleDropAll(held)) {
        if (!addStack(e, item)) e.particles.drop(e.position.clone(), item.name, item.count, resolve(item.name)?.color ?? '#aaa', item);
      }
      e.audio?.play('wood'); e.handDip = 0.18;
      e.onToast('バンドルの中身をすべて取り出しました', 'Emptied bundle contents');
      return true;
    }
  }
  if (name === 'spyglass') {
    e.useItemName = 'spyglass'; e.useTime = 0; any(e).useHand = hand;
    e.audio?.play('click');
    return true;
  }
  if (name === 'ominous_bottle') {
    if (any(e.input).useHeld) {
      e.useItemName = name; e.useTime = 0; any(e).useHand = hand; any(e)._eatStep = 0;
      e.audio?.play('drink');
      return true;
    }
    return completeEat(e, held, def, hand);
  }
  if (name === 'shield') {                                                       // raised while the button is held (see tick)
    if (shieldCooldown(e) > 0) { e.onToast(`盾は使用不能（残り ${shieldCooldown(e).toFixed(1)} 秒）`, `Shield disabled (${shieldCooldown(e).toFixed(1)} s left)`); return true; }
    any(e).shieldRaise = { hand, start: e.elapsed }; e.blocking = true;
    return true;
  }
  if (name === 'bow' || name === 'trident' || (name === 'crossbow' && !held.loaded)) {
    if (name !== 'trident' && !arrowName(e)) { e.onToast('矢がありません', 'Out of arrows'); return true; }
    if (!any(e.input).useHeld) { if (name === 'crossbow') loadCrossbow(e, held); else release(e, held, 1.1, hand); return true; }   // tap / gamepad input
    e.useItemName = name; e.useTime = 0; any(e).useHand = hand;
    return true;
  }
  if (name === 'crossbow') { fireCrossbow(e, held, hand); return true; }
  if (name === 'brush' && tgt && (tgt.id === ID.suspicious_sand || tgt.id === ID.suspicious_gravel)) {
    brushBlock(e, tgt.x, tgt.y, tgt.z, hand);
    return true;
  }
  const potion = potionEffects(name);
  if (potion) {
    if (potion.splash) {
      e.mobs.launchProjectile('potion', e.camera.position.clone().addScaledVector(dir, 0.7), dir.clone().add(new THREE.Vector3(0, 0.18, 0)), 15, undefined, { gravity: 16, color: def?.color ?? '#c9c9ff', onEnd: pos => splash(e, pos, potion.effects, def?.color ?? '#c9c9ff') });
      e.audio?.play('bow');
      if (!creative(e)) e.consumeSelected();
      e.handDip = 0.22;
      return true;
    }
    if (any(e.input).useHeld) {
      e.useItemName = name; e.useTime = 0; any(e).useHand = hand; any(e)._eatStep = 0;
      e.audio?.play('drink');
      return true;
    }
    return completeEat(e, held, def, hand);
  }
  if (['water_bottle', 'awkward_potion', 'mundane_potion', 'thick_potion', 'potion'].includes(name) || name === 'milk_bucket') {
    if (any(e.input).useHeld) {
      e.useItemName = name; e.useTime = 0; any(e).useHand = hand; any(e)._eatStep = 0;
      e.audio?.play('drink');
      return true;
    }
    return completeEat(e, held, def, hand);
  }
  if (name === 'experience_bottle') {
    e.addXp(3 + Math.floor(Math.random() * 9));
    e.particles.burst(e.camera.position.clone().addScaledVector(dir, 2), '#b8f25a', 14, 3);
    e.audio?.play('glass'); e.handDip = 0.2;
    if (!creative(e)) e.consumeSelected();
    return true;
  }
  if (name === 'glass_bottle') {
    const t = e.target;
    const wet = inWater(e) || (!!t && (e.getBlock(t.x + t.normal.x, t.y + t.normal.y, t.z + t.normal.z) === ID.water || t.id === ID.water));
    if (!wet) return false;
    if (!creative(e)) e.consumeSelected();
    if (!addStack(e, { name: 'water_bottle', count: 1 })) e.particles.drop(e.position.clone(), 'water_bottle', 1, '#3f76e4');
    e.audio?.play('water'); e.handDip = 0.2;
    return true;
  }
  if (name === 'map') {                                                          // an empty map becomes an explorer map centred on the player
    const fm: Stack = { name: 'filled_map', count: 1, mapId: newMapFor(e) };
    if (creative(e)) addStack(e, fm);
    else if (held.count <= 1) e.hotbar[e.selected] = fm;
    else { e.consumeSelected(); if (!addStack(e, fm)) e.particles.drop(e.position.clone(), 'filled_map', 1, '#d8c89a'); }
    e.audio?.play('wood'); e.handDip = 0.2;
    e.onToast('地図を作成しました。持って歩くと描き込まれます', 'Map created — walk around while holding it to fill it in');
    return true;
  }
  if (name === 'filled_map') { mapOf(e, held); e.stationKey = 'hand'; any(e).bookHand = hand; e.pause(true); e.onScreen('cartography'); return true; }
  if (name === 'writable_book' || name === 'written_book') { e.stationKey = 'hand'; any(e).bookHand = hand; e.pause(true); e.onScreen('lectern'); return true; }
  if (def?.food && (e.hunger < 20 || creative(e) || ['golden_apple', 'enchanted_golden_apple', 'chorus_fruit', 'honey_bottle'].includes(name))) {
    // Allow golden apple to cure zombie villager first if looking at one
    if ((name === 'golden_apple' || name === 'enchanted_golden_apple') && e.mobs.pick(e.camera.position, dir)?.species === 'zombie_villager') {
      return false;
    }
    // Allow seed foods (carrot, potato, sweet_berries) to plant on farmland/soil first
    if ((name === 'carrot' || name === 'potato') && tgt && (tgt.id === ID.farmland || tgt.id === ID.farmland_moist) && tgt.normal.y > 0) {
      return false;
    }
    if (any(e.input).useHeld) {
      e.useItemName = name; e.useTime = 0; any(e).useHand = hand; any(e)._eatStep = 0;
      e.audio?.play(name === 'honey_bottle' ? 'drink' : 'eat');
      e.particles.crumbs?.(e.camera.position, dir, def.color ?? '#c89656', 4);
      return true;
    }
    return completeEat(e, held, def, hand);
  }
  return false;                                                                 // the engine's food / placement code continues
}

/** Per-frame update: effect timers and ticks, hunger, shield state, charge-and-release weapons, Frost Walker, maps, loyalty returns. */
export function tick(e: Engine, dt: number) {
  const fx = e.effects, a = any(e), acc: Record<string, number> = (a._fxAcc ??= {});
  for (const id of Object.keys(fx)) { fx[id].t -= dt; if (fx[id].t <= 0) { delete fx[id]; if (id === 'absorption') e.absorption = 0; } }
  if (e.levitationTimer > 0) fx.levitation = { t: e.levitationTimer, amp: 0 }; else delete fx.levitation;
  const every = (id: string, period: number, fn: () => void) => {
    if (!has(e, id)) { acc[id] = 0; return; }
    acc[id] = (acc[id] ?? 0) + dt;
    while (acc[id] >= period) { acc[id] -= period; fn(); }
  };
  every('regeneration', 2.5 / 2 ** Math.max(0, amp(e, 'regeneration') - 1), () => { if (!e.dead) e.health = Math.min(20, e.health + 1); });
  every('poison', 1.25 / 2 ** Math.max(0, amp(e, 'poison') - 1), () => { if (e.health > 1) hurt(e, 1, 'magic', true); });
  every('wither', 2 / 2 ** Math.max(0, amp(e, 'wither') - 1), () => hurt(e, 1, 'magic', true));
  if (has(e, 'hunger')) exhaust(e, 0.005 * amp(e, 'hunger') * 20 * dt);   // Java: 0.005 × level exhaustion every tick

  const using = !!a.input.useHeld && !e.dead;
  const sr = a.shieldRaise as { hand: Hand; start: number } | null | undefined;
  if (sr) {
    if (!using || handStack(e, sr.hand)?.name !== 'shield' || shieldCooldown(e) > 0) { a.shieldRaise = null; e.blocking = false; }
    else e.blocking = true;
  } else e.blocking = false;
  if (e.useItemName) {
    const hand = useHandOf(e), held = handStack(e, hand);
    if (!held || e.useItemName !== held.name) { e.useItemName = ''; e.useTime = 0; a._eatStep = 0; }
    else if (CHARGE[held.name]) {
      if (using) {
        e.useTime += dt;
        if (held.name === 'crossbow' && !held.loaded && e.useTime >= chargeTime(e)) { loadCrossbow(e, held); e.useItemName = ''; e.useTime = 0; }
      } else { const t = e.useTime; e.useItemName = ''; e.useTime = 0; release(e, held, t, hand); }
    } else {
      // Continuous eating / drinking (1.6s = 32 ticks, or 0.8s = 16 ticks for dried_kelp)
      if (using) {
        e.useTime += dt;
        const step = Math.floor(e.useTime / 0.2);
        if (step > (a._eatStep ?? 0)) {
          a._eatStep = step;
          const def = resolve(held.name);
          e.audio?.play(isDrinkItem(held.name) ? 'drink' : 'eat');
          e.particles.crumbs?.(e.camera.position, e.camera.getWorldDirection(new THREE.Vector3()), def?.color ?? '#c89656', 5);
          e.handDip = 0.14;
        }
        const need = eatDuration(held.name);
        if (e.useTime >= need) {
          completeEat(e, held, resolve(held.name), hand);
          e.useItemName = ''; e.useTime = 0; a._eatStep = 0;
        }
      } else {
        e.useItemName = ''; e.useTime = 0; a._eatStep = 0;
      }
    }
  }
  const returning: { stack: Stack; t: number }[] = a.returning ?? [];
  for (let i = returning.length - 1; i >= 0; i--) {
    returning[i].t -= dt;
    if (returning[i].t > 0) continue;
    if (!addStack(e, returning[i].stack)) { (a.metaDrops ??= []).push(returning[i].stack); e.particles.drop(e.position.clone(), returning[i].stack.name, 1, '#4fa69a'); }
    e.audio?.play('xp');
    returning.splice(i, 1);
  }
  hungerTick(e, dt);
  frostWalker(e, dt);
  bubbleColumnTick(e, dt);
  beaconTick(e, dt);
  brushDecayTick(e);
  updateMaps(e, dt);
  omenTransitionTick(e);
}

/** 1.21 Ominous Bottle -> Bad Omen -> Raid Omen (30s in village) / Trial Omen (15m * level near trial spawner). */
export function omenTransitionTick(e: Engine) {
  const a = any(e);
  if (has(e, 'bad_omen')) {
    const lv = amp(e, 'bad_omen');
    const nearSpawner = a.w121?.trials?.spawners && [...a.w121.trials.spawners.values()].some((s: any) => Math.hypot(s.x + 0.5 - e.position.x, s.y + 0.5 - e.position.y, s.z + 0.5 - e.position.z) <= 14);
    if (nearSpawner) {
      delete e.effects.bad_omen;
      addEffect(e, 'trial_omen', TRIAL_OMEN_BASE_DURATION * lv, lv - 1);
      for (const s of a.w121.trials.spawners.values()) {
        if (Math.hypot(s.x + 0.5 - e.position.x, s.y + 0.5 - e.position.y, s.z + 0.5 - e.position.z) <= 14) s.ominous = true;
      }
      e.onToast('不吉な予感が「試練の予兆」に変化した！', 'Bad Omen became Trial Omen!');
      return;
    }
    const nearVillage = e.mobs?.mobs.some(m => m.species === 'villager' && m.group.position.distanceTo(e.position) < 24);
    if (nearVillage && !e.mobs?.raid) {
      delete e.effects.bad_omen;
      addEffect(e, 'raid_omen', RAID_OMEN_DURATION, Math.max(0, lv - 1));
      a._raidOmenArmed = true;
      a._raidOmenLevel = Math.max(1, Math.min(5, lv));     // level II+ adds a bonus wave and enchanted raider gear
      e.onToast('不吉な予感が「襲撃の凶兆」（30秒）に変化した！', 'Bad Omen became Raid Omen (30s)!');
    }
  }
  if (a._raidOmenArmed && !has(e, 'raid_omen')) {
    a._raidOmenArmed = false;
    // The raid only starts if the player is still inside a village when Raid Omen runs out.
    e.mobs?.startRaid(e.position.clone(), a._raidOmenLevel ?? 1);
  }
}

/** Hunger: movement exhaustion by distance (sprint 0.1 / m on the ground, swimming 0.01 / m) plus Java's FoodData tick. */
export function hungerTick(e: Engine, dt: number) {
  const a = any(e);
  if (e.dead || (e.meta.mode !== 'survival' && e.meta.mode !== 'adventure')) { a._lastPos = null; return; }
  const p = e.position, last = a._lastPos as THREE.Vector3 | null | undefined;
  if (last) {
    const d = Math.hypot(p.x - last.x, p.z - last.z);
    if (d < 3 && !e.gliding) {
      if (inWater(e)) exhaust(e, 0.01 * d);
      else if (e.grounded && e.input.run && V.canSprintWith(e.hunger) && !e.input.crouch) exhaust(e, 0.1 * d);
    }
  }
  (a._lastPos ??= new THREE.Vector3()).copy(p);
  const f = foodOf(e);
  V.tickFood(f, dt, { health: () => e.health, difficulty: e.meta.difficulty, heal: n => { e.health = Math.min(20, e.health + n); }, hurt: n => { hurt(e, n, 'starve'); } });
  storeFood(e, f);
}

// ---- Frost Walker -------------------------------------------------------------------------------------------------------
const NEIGH6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
/** Java FrostedIceBlock tick: ages 0‥3 then melts back into water; blocks with ≥ 4 frosted neighbours melt more slowly, and it needs light. */
/** Computes distance-attenuated artificial block light (torches, lanterns, glowstone, lava, campfires...) at (x, y, z). */
/**
 * 作業B: block light by propagation (world/lightField.ts): −1 per block of path distance, stopped by opaque blocks, max 15.
 * Was: distance-only within ±6 blocks, which passed through walls and missed torches 7+ blocks away.
 */
export function blockLightAt(e: Engine, x: number, y: number, z: number): number {
  return propagatedBlockLight((bx, by, bz) => e.getBlock(bx, by, bz), x, y, z);
}

export function frostTick(e: Engine, x: number, y: number, z: number): boolean {
  if (e.getBlock(x, y, z) !== ID.frosted_ice) return false;
  const age = blockState(e.getCell(x, y, z));
  const neigh = NEIGH6.filter(([dx, dy, dz]) => e.getBlock(x + dx, y + dy, z + dz) === ID.frosted_ice).length;
  let open = e.dimension !== 'overworld' || (e.environment?.daylight ?? 1) > 0;
  if (e.dimension === 'overworld') for (let dy = 1; dy <= 40 && open; dy++) if (BLOCKS[e.getBlock(x, y + dy, z)]?.solid) open = false;   // no sky above → dark
  const skyBright = e.dimension === 'overworld' ? (open ? (e.environment?.daylight ?? 1) * 15 : 0) : 15;
  const blkBright = blockLightAt(e, x, y, z);
  const bright = Math.max(skyBright, blkBright);
  if ((Math.random() < 1 / 3 || neigh < 4 || blkBright > 11 - age) && bright > 11 - age) {
    if (age < 3) e.setBlock(x, y, z, ID.frosted_ice, age + 1);
    else { e.setBlock(x, y, z, ID.water, 0); return false; }
  }
  return true;
}

/** Detects whether a water cell at (x, y, z) sits in a Soul Sand ('up') or Magma Block ('down') Bubble Column. */
export function bubbleColumnMode(e: Engine, x: number, y: number, z: number): 'up' | 'down' | null {
  const bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z);
  if (e.getBlock(bx, by, bz) !== ID.water) return null;
  for (let dy = 1; dy <= 24; dy++) {
    const bid = e.getBlock(bx, by - dy, bz);
    if (bid === ID.water) continue;
    if (bid === ID.soul_sand) return 'up';
    if (bid === ID.magma_block) return 'down';
    return null;
  }
  return null;
}

/** Per-frame Bubble Column physics & particle emitter (Soul Sand upward lift / Magma Block downward vortex). */
export function bubbleColumnTick(e: Engine, dt: number) {
  const px = Math.floor(e.position.x), py = Math.floor(e.position.y + 0.5), pz = Math.floor(e.position.z);
  const mode = bubbleColumnMode(e, px, py, pz);
  if (mode) {
    if (mode === 'up') e.velocity.y = Math.min(11, e.velocity.y + 28 * dt);
    else e.velocity.y = Math.max(-9, e.velocity.y - 22 * dt);
    e.oxygen = Math.min(20, e.oxygen + dt * 6);
    e.particles.bubbleColumn?.(px, py, pz, mode, e.elapsed);
  }
  const a = any(e);
  a._bubT = (a._bubT ?? 0) + dt;
  if (a._bubT < 0.12) return;
  a._bubT = 0;
  for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++) for (let dy = -2; dy <= 2; dy++) {
    const m = bubbleColumnMode(e, px + dx, py + dy, pz + dz);
    if (m) e.particles.bubbleColumn?.(px + dx, py + dy, pz + dz, m, e.elapsed);
  }
}

function brushDecayTick(e: Engine) {
  const bmap: Map<string, number> | undefined = any(e)._brushMap;
  if (!bmap || !bmap.size) return;
  for (const [k, due] of bmap) {
    if (e.elapsed < due) continue;
    const [x, y, z] = k.split(',').map(Number);
    const cell = e.getCell(x, y, z), id = blockId(cell), st = blockState(cell) & 3;
    if ((id === ID.suspicious_sand || id === ID.suspicious_gravel) && st > 0) {
      e.setBlock(x, y, z, id, st - 1);
      if (st - 1 > 0) bmap.set(k, e.elapsed + 1.2);
      else bmap.delete(k);
    } else bmap.delete(k);
  }
}
/** Boots with Frost Walker turn water *source* blocks under / around the walker (radius 2 + level, max 16) into frosted ice. */
export function frostWalker(e: Engine, dt: number) {
  const a = any(e), lv = lvl(e.armor[3], 'frost_walker');
  const queue: Map<string, number> = (a._frost ??= new Map());
  a._frostT = (a._frostT ?? 0) + dt;
  if (lv > 0 && a._frostT >= 0.1 && e.grounded && !e.flying && ID.frosted_ice !== undefined) {
    a._frostT = 0;
    const r = Math.min(16, 2 + lv), px = Math.floor(e.position.x), py = Math.floor(e.position.y) - 1, pz = Math.floor(e.position.z);
    for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) {
      if (dx * dx + dz * dz > r * r) continue;
      const x = px + dx, z = pz + dz;
      if (e.getBlock(x, py, z) !== ID.water || e.getBlock(x, py + 1, z) !== 0 || blockState(e.getCell(x, py, z)) !== 0) continue;
      if (e.setBlock(x, py, z, ID.frosted_ice, 0)) queue.set(`${x},${py},${z}`, e.elapsed + 1 + Math.random());
    }
  }
  if (!queue.size) return;
  for (const [k, due] of queue) {
    if (e.elapsed < due) continue;
    const [x, y, z] = k.split(',').map(Number);
    if (frostTick(e, x, y, z)) queue.set(k, e.elapsed + 1 + Math.random()); else queue.delete(k);
  }
}

// ---- Explorer maps: painted around the holder while a map is in the main or off hand ----------------------------------------
const MAP_COLORS: [RegExp, string][] = [[/^grass_block$|^short_grass$|^fern$/, '#7fb238'], [/leaves$/, '#007c00'], [/sand$|sandstone/, '#f7e9a3'], [/^snow/, '#ffffff'], [/^ice$|^frosted_ice$|packed_ice|blue_ice/, '#a0a0ff'],
  [/_log$|_planks$|_wood$/, '#8f7748'], [/^dirt$|coarse_dirt|^podzol$|^farmland$|^mycelium$/, '#976d4d'], [/^stone$|cobblestone|andesite|diorite|granite|deepslate|_ore$|^gravel$/, '#707070'], [/^lava$|^magma/, '#ff0000'], [/^netherrack$/, '#700200'], [/^end_stone$/, '#f7e9a3']];
const mapColorOf = (d: BlockDef) => { for (const [re, c] of MAP_COLORS) if (re.test(d.name)) return c; return d.color; };
/** Top-most map-coloured block of a world column; glass, torches and small plants are transparent to maps, water reports its depth. */
export function sampleColumn(e: Engine, x: number, z: number): MapSample | null {
  const top = Math.min(e.terrain.height(x, z) + 14, 380);
  for (let y = top; y > -64; y--) {
    const id = e.getBlock(x, y, z);
    if (id < 0) return null;
    if (id === 0) continue;
    const d = BLOCKS[id];
    if (!d) continue;
    if (d.name === 'water') { let depth = 1; while (depth < 12 && e.getBlock(x, y - depth, z) === ID.water) depth++; return { color: '#4040ff', y, water: true, depth }; }
    if (d.shape === 'water' || (!d.solid && !/leaves/.test(d.name)) || /glass|^torch|barrier|^air$/.test(d.name)) continue;
    return { color: mapColorOf(d), y };
  }
  return null;
}
export function updateMaps(e: Engine, dt: number) {
  const a = any(e);
  a._mapT = (a._mapT ?? 0) + dt;
  if (a._mapT < 0.1 || !e.maps?.size) return;
  a._mapT = 0;
  const seen = new Set<number>();
  for (const s of [e.hotbar[e.selected], e.offhand]) {
    const m = s ? mapOf(e, s) : null;
    if (!m || seen.has(m.id) || m.dim !== e.dimension) continue;
    seen.add(m.id);
    updateMap(m, e.position.x, e.position.z, (x, z) => sampleColumn(e, x, z), Math.max(32, (e.settings?.distance ?? 4) * 16));
  }
}

// ---- Dimension travel ------------------------------------------------------------------------------------------------------
export function writeEdit(e: Engine, x: number, y: number, z: number, id: number, state = 0) {
  const key = `${x},${y},${z}`, cell = makeCell(id, state), cKey = Math.floor(x / 16) + ',' + Math.floor(z / 16);
  e.edits.set(key, cell);
  let bucket = e.editsByChunk.get(cKey);
  if (!bucket) { bucket = new Map(); e.editsByChunk.set(cKey, bucket); }
  bucket.set(key, cell);
}
function buildPortal(e: Engine, x: number, y: number, z: number) {      // frame in the x–y plane; portal cells (x, x+1) × (y … y+2)
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 2; dx++) {
    writeEdit(e, x + dx, y - 1, z + dz, ID.obsidian);
    for (let dy = 0; dy <= 3; dy++) writeEdit(e, x + dx, y + dy, z + dz, 0);
  }
  for (let dx = -1; dx <= 2; dx++) writeEdit(e, x + dx, y + 3, z, ID.obsidian);
  for (let dy = 0; dy <= 2; dy++) {
    writeEdit(e, x - 1, y + dy, z, ID.obsidian); writeEdit(e, x + 2, y + dy, z, ID.obsidian);
    writeEdit(e, x, y + dy, z, ID.portal); writeEdit(e, x + 1, y + dy, z, ID.portal);
  }
}
/** Nether portals: coordinates scale 1:8, an existing portal near the target is reused, otherwise a new one is built. */
export function netherTravel(e: Engine) {
  const toNether = e.dimension !== 'nether', sx = e.position.x, sz = e.position.z;
  const tx = Math.floor(toNether ? sx / 8 : sx * 8), tz = Math.floor(toNether ? sz / 8 : sz * 8);
  e.changeDimension(toNether ? 'nether' : 'overworld');
  const range = toNether ? 16 : 128;
  let best: [number, number, number] | null = null, bestD = range * range + 1;
  for (const [key, cell] of e.edits) {
    if (blockId(cell) !== ID.portal) continue;
    const [x, y, z] = key.split(',').map(Number), d = (x - tx) ** 2 + (z - tz) ** 2;
    if (d < bestD || (d === bestD && best !== null && y < best[1])) { bestD = d; best = [x, y, z]; }
  }
  let px: number, py: number, pz: number, built = false;
  if (best) { [px, py, pz] = best; while (blockId(e.edits.get(`${px},${py - 1},${pz}`) ?? 0) === ID.portal) py--; }
  else {
    px = tx; pz = tz;
    const h = e.terrain.height(px, pz);
    py = toNether ? Math.max(19, Math.min(48, h + 1)) : Math.max(h, SEA) + 1;
    buildPortal(e, px, py, pz);
    built = true;
  }
  e.position.set(px + 0.5, py + 0.05, pz + 0.5);
  e.velocity.set(0, 0, 0);
  any(e).fallTop = py;
  e.portalLock = true;
  e.portalCharge = 0;
  e.achievement('nether');
  e.onToast(`${toNether ? 'ネザー' : 'オーバーワールド'}へ（${px}, ${py}, ${pz}）${built ? ' — 新しいポータルを生成' : ' — 既存ポータルに接続'}`, `${toNether ? 'Nether' : 'Overworld'} (${px}, ${py}, ${pz})${built ? ' — new portal built' : ' — linked to existing portal'}`);
}
/** Four end crystals on the sides of the exit portal bring the Ender Dragon back. */
export function checkDragonRespawn(e: Engine) {
  if (e.dimension !== 'end' || !e.dragonDefeated) return;
  const crystals = (any(e.mobs).crystals ?? []) as { pos: THREE.Vector3 }[];
  const sides = new Set(crystals.filter(c => Math.hypot(c.pos.x, c.pos.z) < 5.6 && Math.abs(c.pos.y - 29.5) < 4).map(c => (Math.abs(c.pos.x) > Math.abs(c.pos.z) ? (c.pos.x > 0 ? 'e' : 'w') : c.pos.z > 0 ? 's' : 'n')));
  if (sides.size < 4) { e.onToast(`エンドクリスタル ${sides.size}/4 — 出口ポータルの四辺に置くとドラゴンを再召喚`, `End crystals ${sides.size}/4 — place one on each side of the exit portal`); return; }
  e.dragonDefeated = false;
  e.mobs.host.dragonDefeated = false;
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (dx || dz) e.setBlock(dx, 28, dz, 0);
  e.mobs.clear();
  e.mobs.populate();
  e.environment.triggerLightning();
  e.audio?.play('explosion');
  e.onToast('エンダードラゴンが再召喚された！', 'The Ender Dragon has been resummoned!');
}

// ---- Workstations ------------------------------------------------------------------------------------------------------------
const STATION_OF: Record<string, Screen> = { enchanting_table: 'enchanting', anvil: 'anvil', grindstone: 'grindstone', smithing_table: 'smithing', stonecutter: 'stonecutter', brewing_stand: 'brewing', loom: 'loom', cartography_table: 'cartography', lectern: 'lectern', beacon: 'beacon' };
export function openStation(e: Engine, t: { x: number; y: number; z: number; id: number }): boolean {
  const kind = STATION_OF[BLOCKS[t.id]?.name ?? ''];
  if (!kind) return false;
  e.stationKey = `${t.x},${t.y},${t.z}`;
  if (kind === 'brewing') { e.containers[e.stationKey] ??= [null, null, null, null, null]; e.furnaces[e.stationKey] ??= { burn: 0, progress: 0 }; }
  if (kind === 'lectern') e.containers[e.stationKey] ??= [null];
  e.audio?.play('click');
  e.pause(true);
  e.onScreen(kind);
  return true;
}
export function bookshelves(e: Engine): number {
  const [x, y, z] = e.stationKey.split(',').map(Number);
  if (!Number.isFinite(x)) return 0;
  let n = 0;
  for (let dy = 0; dy <= 1; dy++) for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
    if (Math.max(Math.abs(dx), Math.abs(dz)) !== 2 || e.getBlock(x + dx, y + dy, z + dz) !== ID.bookshelf) continue;
    if (!BLOCKS[e.getBlock(x + Math.trunc(dx / 2), y + dy, z + Math.trunc(dz / 2))]?.solid) n++;     // needs a free gap towards the table
  }
  return Math.min(15, n);
}
export function enchantOffers(e: Engine, i: number): EnchantOption[] {
  const s = slotAt(e, i);
  return !s || s.ench ? [] : enchantOptions(s.name, bookshelves(e), e.enchantSeed);
}
export function doEnchant(e: Engine, i: number, option: number): boolean {
  const s = slotAt(e, i), o = enchantOffers(e, i)[option];
  if (!s || !o) return false;
  if (!creative(e)) {
    if (level(e) < o.level || e.countItem('lapis_lazuli') < o.cost) return false;
    e.removeItem('lapis_lazuli', o.cost);
    spendLevels(e, o.cost);
  }
  const out = applyEnchants({ ...s, count: 1 }, o.list);
  if (s.count > 1) { s.count--; if (!addStack(e, out)) e.particles.drop(e.position.clone(), out.name, 1, '#b06ad8'); }
  else setSlot(e, i, out);
  e.enchantSeed = ((Math.imul(e.enchantSeed, 1103515245) + 12345) >>> 0) % 2147483647 || 1;
  e.audio?.play('levelup');
  e.statistics.enchanted = (e.statistics.enchanted ?? 0) + 1;
  e.achievement('enchant');
  return true;
}
export const anvilPreview = (e: Engine, li: number, ri: number, name: string) => (li < 0 ? null : anvilCombine(slotAt(e, li), ri >= 0 ? slotAt(e, ri) : null, name));
export function doAnvil(e: Engine, li: number, ri: number, name: string): boolean {
  const r = anvilPreview(e, li, ri, name), left = slotAt(e, li);
  if (!r || !left) return false;
  if (!creative(e)) { if (level(e) < r.cost || r.cost > 39) return false; spendLevels(e, r.cost); }
  if (ri >= 0 && r.useRight) takeFrom(e, ri, r.useRight);
  if (left.count > 1) { left.count--; addStack(e, { ...r.result, count: 1 }); } else setSlot(e, li, { ...r.result, count: 1 });
  e.audio?.play('stone');
  return true;
}
export const grindPreview = (e: Engine, ai: number, bi: number) => grind(ai >= 0 ? slotAt(e, ai) : null, bi >= 0 ? slotAt(e, bi) : null);
export function doGrind(e: Engine, ai: number, bi: number): boolean {
  const r = grindPreview(e, ai, bi);
  if (!r) return false;
  const keep = ai >= 0 ? ai : bi;
  if (ai >= 0 && bi >= 0) setSlot(e, bi, null);
  setSlot(e, keep, r.result);
  if (r.xp) e.addXp(r.xp);
  e.audio?.play('stone');
  return true;
}
export function smithPreview(e: Engine, ti: number, bi: number, ai: number): Stack | null {
  const t = slotAt(e, ti), b = slotAt(e, bi), a = slotAt(e, ai);
  if (!t || !b || !a) return null;
  if (isTrimTemplate(t.name) && isTrimmableArmor(b.name) && isTrimMaterial(a.name)) {
    const pattern = trimPatternOf(t.name)!, material = trimMaterialOf(a.name)!;
    if (b.trim?.pattern === pattern && b.trim?.material === material) return null;
    return { ...b, count: 1, trim: { pattern, material } };
  }
  const r = SMITHING.find(x => x.template === t.name && x.base === b.name && x.addition === a.name);
  if (!r) return null;
  const oldMax = resolve(b.name)?.durability ?? 0, newMax = resolve(r.result)?.durability ?? 0;
  const out: Stack = { ...b, name: r.result };
  if (b.durability !== undefined && newMax) out.durability = Math.max(1, newMax - (oldMax - b.durability));
  return out;
}

/** Beacon pyramid tier (0..4) at the current stationKey (or given coordinates). */
export function currentBeaconTier(e: Engine, key = e.stationKey): number {
  const [x, y, z] = key.split(',').map(Number);
  if (!Number.isFinite(x)) return 0;
  return beaconPyramidTier((bx, by, bz) => e.getBlock(bx, by, bz), x, y, z);
}

/** Confirm Beacon powers: consumes 1 mineral payment item (iron/gold/emerald/diamond/netherite ingot) and activates the beacon. */
export function activateBeacon(e: Engine, primary: string, secondary?: string, paymentSlot = -1): boolean {
  const [x, y, z] = e.stationKey.split(',').map(Number);
  if (!Number.isFinite(x)) return false;
  const tier = beaconPyramidTier((bx, by, bz) => e.getBlock(bx, by, bz), x, y, z);
  if (tier <= 0) return false;
  if (!creative(e)) {
    const pay = paymentSlot >= 0 ? slotAt(e, paymentSlot) : null;
    if (!pay || !isBeaconPayment(pay.name)) return false;
    takeFrom(e, paymentSlot, 1);
  }
  const sec = tier >= 4 ? secondary : undefined;
  const bKey = `${e.dimension}:${e.stationKey}`;
  (any(e).beacons as Map<string, { primary: string; secondary?: string }>).set(bKey, { primary, secondary: sec });
  const dur = beaconDuration(tier);
  const ampVal = sec === primary ? 1 : 0;
  addEffect(e, primary, dur, ampVal);
  if (sec === 'regeneration' && primary !== 'regeneration') addEffect(e, 'regeneration', dur, 0);
  e.audio?.play('beacon', { x, y, z });
  any(e).syncBeacons?.();
  return true;
}

export function beaconTick(e: Engine, dt: number) {
  const a = any(e);
  a._beaconT = (a._beaconT ?? 0) + dt;
  if (a._beaconT < 2.0) return;
  a._beaconT = 0;
  const beacons: Map<string, { primary: string; secondary?: string }> | undefined = a.beacons;
  if (!beacons || !beacons.size) return;
  for (const [k, cfg] of beacons) {
    const [dim, coords] = k.split(':');
    if (dim !== e.dimension) continue;
    const [x, y, z] = coords.split(',').map(Number);
    if (e.getBlock(x, y, z) !== ID.beacon) continue;
    const tier = beaconPyramidTier((bx, by, bz) => e.getBlock(bx, by, bz), x, y, z);
    if (tier <= 0) continue;
    const range = beaconRange(tier);
    if (Math.hypot(e.position.x - (x + 0.5), e.position.z - (z + 0.5)) <= range && e.position.y >= y - range) {
      const dur = beaconDuration(tier);
      const ampVal = tier >= 4 && cfg.secondary === cfg.primary ? 1 : 0;
      addEffect(e, cfg.primary, dur, ampVal);
      if (tier >= 4 && cfg.secondary === 'regeneration' && cfg.primary !== 'regeneration') {
        addEffect(e, 'regeneration', dur, 0);
      }
    }
  }
}
export function doSmith(e: Engine, ti: number, bi: number, ai: number): boolean {
  const out = smithPreview(e, ti, bi, ai);
  if (!out) return false;
  takeFrom(e, ti, 1); takeFrom(e, ai, 1); setSlot(e, bi, out);
  e.audio?.play('stone');
  return true;
}
export const stonecutOptions = (e: Engine, i: number) => (i < 0 ? [] : STONECUT[slotAt(e, i)?.name ?? ''] ?? []);
export function doStonecut(e: Engine, i: number, result: string, all = false): boolean {
  const s = slotAt(e, i), o = s ? (STONECUT[s.name] ?? []).find(x => x.result === result) : undefined;
  if (!s || !o) return false;
  let done = 0;
  for (let n = all ? s.count : 1; n > 0; n--) { if (!e.addItem(o.result, o.count)) break; takeFrom(e, i, 1); done++; }
  if (done) e.audio?.play('stone');
  return done > 0;
}
/** Brewing stand slots: 0–2 bottles, 3 ingredient, 4 blaze powder. `state.burn` holds the remaining fuel charges. */
export function brewTick(e: Engine, state: { burn: number; progress: number }, slots: (Stack | null)[], dt: number) {
  const ing = slots[3];
  if (!ing || ![0, 1, 2].some(i => slots[i] && brewResult(slots[i]!.name, ing.name))) { state.progress = 0; return; }
  if (state.burn <= 0) {
    const fuel = slots[4];
    if (fuel?.name !== 'blaze_powder') { state.progress = 0; return; }
    fuel.count--; if (fuel.count <= 0) slots[4] = null;
    state.burn = 20;
  }
  state.progress += dt / 10;
  if (state.progress < 1) return;
  state.progress = 0; state.burn -= 1;
  for (let i = 0; i < 3; i++) { const b = slots[i], out = b ? brewResult(b.name, ing.name) : null; if (out) slots[i] = { name: out, count: 1 }; }
  ing.count--; if (ing.count <= 0) slots[3] = null;
  e.audio?.play('water');
  e.achievement('brew');
}
export function brewPut(e: Engine, i: number): boolean {
  const s = slotAt(e, i), slots = e.containers[e.stationKey];
  if (!s || !slots || slots.length !== 5) return false;
  const stackInto = (dest: number) => {
    if (slots[dest] && slots[dest]!.name !== s.name) return false;
    const n = Math.min(64 - (slots[dest]?.count ?? 0), s.count);
    if (n <= 0) return false;
    if (slots[dest]) slots[dest]!.count += n; else slots[dest] = { name: s.name, count: n };
    takeFrom(e, i, n);
    return true;
  };
  if (isBottle(s.name)) { const dest = [0, 1, 2].find(k => !slots[k]); if (dest === undefined) return false; slots[dest] = { name: s.name, count: 1 }; takeFrom(e, i, 1); return true; }
  if (s.name === 'blaze_powder' && (!slots[4] || (slots[3] && slots[3].name !== 'blaze_powder'))) return stackInto(4);
  if (BREW_INGREDIENTS.has(s.name)) return stackInto(3);
  return false;
}
export function containerTake(e: Engine, slots: (Stack | null)[], i: number): boolean {
  const s = slots[i];
  if (!s || !addStack(e, s)) return false;
  slots[i] = null;
  return true;
}
export function containerPut(e: Engine, i: number, slots: (Stack | null)[]): boolean {
  const s = slotAt(e, i);
  if (!s) return false;
  const max = resolve(s.name)?.stack ?? 64, plain = max > 1 && !hasMeta(s);
  let dest = plain ? slots.findIndex(x => x?.name === s.name && x.count < max && !hasMeta(x)) : -1;
  if (dest < 0) dest = slots.findIndex(x => !x);
  if (dest < 0) return false;
  if (slots[dest]) { const n = Math.min(max - slots[dest]!.count, s.count); slots[dest]!.count += n; takeFrom(e, i, n); }
  else { slots[dest] = { ...s }; setSlot(e, i, null); }
  return true;
}
/** Loom: banner + dye (+ a banner-pattern item for the special designs; Java doesn't consume it). Up to six layers. */
export function doLoom(e: Engine, bi: number, di: number, pattern: string, pi = -1): boolean {
  const banner = slotAt(e, bi), dye = slotAt(e, di), pitem = pi >= 0 ? slotAt(e, pi) : null;
  if (!banner?.name.endsWith('_banner') || !dye?.name.endsWith('_dye')) return false;
  const layers = addLayer(banner.patterns, pattern, dye.name.replace(/_dye$/, ''), pitem?.name);
  if (!layers) { e.onToast('この模様は織れません（6層まで／特殊模様は模様アイテムが必要）', 'Cannot weave that pattern (max 6 layers; special designs need their pattern item)'); return false; }
  const out: Stack = { ...banner, count: 1, patterns: layers as BannerLayer[] };
  takeFrom(e, di, 1);
  if (banner.count > 1) { banner.count--; if (!addStack(e, out)) e.particles.drop(e.position.clone(), out.name, 1, '#d8d2c4'); } else setSlot(e, bi, out);
  e.audio?.play('wood');
  return true;
}
/** Cartography table: paper zooms out (new, larger map that keeps what was drawn), a glass pane locks a copy, an empty map duplicates. */
export function doCartography(e: Engine, mi: number, oi: number): boolean {
  const map = slotAt(e, mi), other = slotAt(e, oi), md = mapOf(e, map);
  if (!map || !md || !other) return false;
  if (other.name === 'map') { takeFrom(e, oi, 1); addStack(e, { ...map, count: 1 }); }                          // copy: same map id, shared data
  else if (md.locked) { e.onToast('ロックされた地図は変更できません', 'Locked maps cannot be changed'); return false; }
  else if (other.name === 'paper') {
    if (md.scale >= 4) { e.onToast('これ以上縮小できません', 'Already at the largest scale'); return false; }
    takeFrom(e, oi, 1);
    const nm = zoomedOut(md, allocMapId(e)); e.maps.set(nm.id, nm); map.mapId = nm.id;
  } else if (other.name === 'glass_pane') {
    takeFrom(e, oi, 1);
    const nm = lockedCopy(md, allocMapId(e)); e.maps.set(nm.id, nm); map.mapId = nm.id;
  } else return false;
  e.audio?.play('wood');
  return true;
}
// ---- Books: the lectern (or the held book) edits real pages --------------------------------------------------------------------
export const lecternBook = (e: Engine): Stack | null => (e.stationKey === 'hand' ? handStack(e, any(e).bookHand ?? 'main') : e.containers[e.stationKey]?.[0]) ?? null;
/** Normalises legacy single-textarea books (label) into pages. */
export function bookPages(b: Stack): string[] { if (!b.pages) { b.pages = [b.label ?? '']; delete b.label; } if (!b.pages.length) b.pages.push(''); return b.pages; }
export function bookEdit(b: Stack, page: number, text: string): boolean {
  if (b.name !== 'writable_book') return false;
  const pages = bookPages(b);
  if (page < 0 || page >= pages.length) return false;
  pages[page] = text.slice(0, V.BOOK_MAX_PAGE_CHARS);
  return true;
}
export function bookAddPage(b: Stack): boolean { const p = bookPages(b); if (b.name !== 'writable_book' || p.length >= V.BOOK_MAX_PAGES) return false; p.push(''); return true; }
export function bookRemovePage(b: Stack, page: number): boolean { const p = bookPages(b); if (b.name !== 'writable_book' || p.length <= 1) return false; p.splice(page, 1); return true; }
/** "Sign and close": needs a title (≤ 15 chars); the book becomes a written book (original) and can no longer be edited. */
export function bookSign(e: Engine, b: Stack, title: string): boolean {
  const t = title.trim().slice(0, V.BOOK_MAX_TITLE);
  if (b.name !== 'writable_book' || !t) return false;
  const pages = V.clampPages(bookPages(b));
  b.name = 'written_book'; b.title = t; b.author = 'Player'; b.gen = 0; b.pages = pages; delete b.label;
  e.audio?.play('levelup');
  return true;
}
/** Copies a signed book (original / first copy only) using one book and quill from the inventory; the generation goes up by one. */
export function bookCopy(e: Engine, b: Stack): boolean {
  if (b.name !== 'written_book' || !V.canCopyBook(b.gen ?? 0) || e.countItem('writable_book') < 1) return false;
  e.removeItem('writable_book', 1);
  const copy: Stack = { name: 'written_book', count: 1, pages: [...bookPages(b)], title: b.title, author: b.author, gen: (b.gen ?? 0) + 1 };
  if (!addStack(e, copy)) e.particles.drop(e.position.clone(), 'written_book', 1, '#8a6a3f');
  return true;
}
/** Page currently open on a lectern (0-based) and the comparator signal that page produces. */
export const lecternPage = (e: Engine, key = e.stationKey): number => (e.lecternPages?.[key] ?? 0);
export function setLecternPage(e: Engine, page: number, key = e.stationKey) {
  const b = e.containers[key]?.[0];
  if (!b) return;
  const n = bookPages(b).length;
  (e.lecternPages ??= {})[key] = Math.max(0, Math.min(n - 1, page));
}

/** Deterministic loot for a container tagged with a room table (stronghold library, village weaponsmith, bastion treasure room …). */
export function rollRoom(e: Engine, table: string, x: number, y: number, z: number, size = 27): (Stack | null)[] {
  const r = rng(hashStr(`${table}:${x},${y},${z}:${e.terrain.seed}`));
  const slots = rollRoomLoot(ROOM_LOOT[table], r, n => !!resolve(n), n => resolve(n)?.stack ?? 64, size) as (Stack | null)[];
  const pool = ENCHANTS.filter(x => !x.curse);
  for (const st of slots) if (st?.name === 'enchanted_book') { const pickE = pool[Math.floor(r() * pool.length)]; st.ench = { [pickE.id]: 1 + Math.floor(r() * pickE.max) }; }
  return slots;
}

/** Loot of a generated chest that its structure piece tagged with a room table; null when the chest carries no tag. */
export function roomLootFor(e: Engine, x: number, y: number, z: number): (Stack | null)[] | null {
  const table = lootTagAt(e.terrain, x, y, z);
  return table && ROOM_LOOT[table] ? rollRoom(e, table, x, y, z) : null;
}
/** Generated block entities that are not chests get their contents on first access; positions the player has edited are never seeded again. */
export function seedNatural(e: Engine, x: number, y: number, z: number) {
  const key = `${x},${y},${z}`;
  if (e.containers[key] || e.edits.has(key)) return;
  const table = lootTagAt(e.terrain, x, y, z), fixed = table ? FIXED_CONTENTS[table] : undefined;
  if (fixed) {
    const slots: (Stack | null)[] = Array(fixed.size).fill(null);
    for (const [i, name, count] of fixed.slots) if (resolve(name)) slots[i] = { name, count };
    e.containers[key] = slots;
  } else if (table === 'jungle_temple_dispenser') e.containers[key] = rollRoom(e, table, x, y, z, 9);
}
/** Item frame: right-click takes the displayed item, or hangs the held one in an empty frame. */
export function useItemFrame(e: Engine, x: number, y: number, z: number): boolean {
  const key = `${x},${y},${z}`, slots = (e.containers[key] ??= [null]), held = e.hotbar[e.selected];
  if (slots[0]) { e.addItem(slots[0].name, slots[0].count); slots[0] = null; e.audio?.play('click'); }
  else if (held) { slots[0] = { ...held, count: 1 }; if (e.meta.mode !== 'creative') e.consumeSelected(); e.audio?.play('click'); }
  e.handDip = 0.18;
  return true;
}

/** Deterministic loot for chests generated by the v11 structures. */
export function rollLoot(e: Engine, kind: ExtraKind, x: number, y: number, z: number): (Stack | null)[] {
  const slots: (Stack | null)[] = Array(27).fill(null), table = EXTRA_LOOT[kind], r = rng(hashStr(`${kind}:${x},${y},${z}:${e.terrain.seed}`));
  const rolls = table.rolls[0] + Math.floor(r() * (table.rolls[1] - table.rolls[0] + 1)), total = table.items.reduce((s, i) => s + i[3], 0);
  for (let n = 0; n < rolls; n++) {
    let w = r() * total;
    const it = table.items.find(i => (w -= i[3]) <= 0) ?? table.items[0];
    let slot = Math.floor(r() * 27);
    while (slots[slot]) slot = (slot + 1) % 27;
    const st: Stack = { name: it[0], count: Math.min(it[1] + Math.floor(r() * (it[2] - it[1] + 1)), resolve(it[0])?.stack ?? 64) };
    if (it[0] === 'enchanted_book') {
      const pool = kind === 'ancient_city' ? ENCHANTS.filter(x => x.id === 'swift_sneak' || x.id === 'mending' || x.id === 'protection') : ENCHANTS.filter(x => !x.curse);
      const pickE = pool[Math.floor(r() * pool.length)];
      st.ench = { [pickE.id]: 1 + Math.floor(r() * pickE.max) };
    }
    slots[slot] = st;
  }
  return slots;
}

// ---- Commands, save data, HUD ---------------------------------------------------------------------------------------------
export function command(e: Engine, cmd: string, args: string[]): string {
  if (cmd === 'effect') {
    if (args[0] === 'clear') { clearEffects(e); return 'Effects cleared'; }
    const rest = args[0] === 'give' ? args.slice(1) : args, id = rest[0]?.replace(/^minecraft:/, '');
    if (!id || !EFFECTS[id]) return 'Usage: /effect give <effect> [seconds] [amplifier] · /effect clear — ' + Object.keys(EFFECTS).join(', ');
    addEffect(e, id, Number(rest[1]) || 30, Math.max(0, Math.min(9, Number(rest[2]) || 0)));
    return `Applied ${EFFECTS[id].en}`;
  }
  if (cmd === 'enchant') {
    const s = e.hotbar[e.selected], def = ENCHANT_BY_ID[args[0]?.replace(/^minecraft:/, '') ?? ''];
    if (!s || !def) return 'Usage: /enchant <enchantment> [level] (hold the item) — ' + ENCHANTS.map(x => x.id).join(', ');
    if (!canApply(def, s.name)) return `${def.en} cannot be applied to ${s.name}`;
    const l = Math.max(1, Math.min(def.max, Number(args[1]) || 1));
    e.hotbar[e.selected] = applyEnchants(s.count > 1 ? { ...s, count: 1 } : s, [[def.id, l]]);
    return `Applied ${def.en} ${l}`;
  }
  if (cmd === 'xp') {
    const raw = args[0] ?? '', n = Number(raw.replace(/L$/i, '')) || 0;
    if (/L$/i.test(raw)) { e.xp = V.xpAfterLevels(e.xp, n); e.lastLevel = level(e); } else e.addXp(n);
    return `Level ${level(e)} (${Math.floor(e.xp)} xp)`;
  }
  if (cmd === 'clear') { e.hotbar = Array(9).fill(null); e.inventory = Array(27).fill(null); e.armor = [null, null, null, null]; e.offhand = null; syncEquip(e); return 'Inventory cleared'; }
  if (cmd === 'gamerule') {
    const gr = (any(e).gamerules ??= { ...DEFAULT_GAMERULES });
    const rule = args[0] as keyof typeof DEFAULT_GAMERULES | undefined;
    if (!rule || !(rule in DEFAULT_GAMERULES)) return 'Rules: ' + Object.keys(DEFAULT_GAMERULES).join(', ');
    if (args[1] !== undefined) gr[rule] = args[1].toLowerCase() === 'true' || args[1] === '1';
    return `Gamerule ${rule} = ${gr[rule]}`;
  }
  if (cmd === 'setblock') {
    const c = parseCoords(args.slice(0, 3), { x: e.position.x, y: e.position.y, z: e.position.z, yaw: e.input?.yaw, pitch: e.input?.pitch });
    const bname = (args[3] ?? '').replace(/^minecraft:/, '');
    const bid = bname === 'air' ? 0 : ID[bname];
    if (!c || bid === undefined) return 'Usage: /setblock <x> <y> <z> <block>';
    e.setBlock(c[0], c[1], c[2], bid, Number(args[4]) || 0);
    return `Set block at ${c[0]}, ${c[1]}, ${c[2]} to ${bname}`;
  }
  if (cmd === 'fill') {
    const pose = { x: e.position.x, y: e.position.y, z: e.position.z, yaw: e.input?.yaw, pitch: e.input?.pitch };
    const c1 = parseCoords(args.slice(0, 3), pose), c2 = parseCoords(args.slice(3, 6), pose);
    const bname = (args[6] ?? '').replace(/^minecraft:/, ''), mode = (args[7] ?? 'replace').toLowerCase();
    const bid = bname === 'air' ? 0 : ID[bname];
    if (!c1 || !c2 || bid === undefined) return 'Usage: /fill <x1> <y1> <z1> <x2> <y2> <z2> <block> [replace|hollow|outline|destroy]';
    const x0 = Math.min(c1[0], c2[0]), x1 = Math.max(c1[0], c2[0]);
    const y0 = Math.min(c1[1], c2[1]), y1 = Math.max(c1[1], c2[1]);
    const z0 = Math.min(c1[2], c2[2]), z1 = Math.max(c1[2], c2[2]);
    let count = 0;
    for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
      const border = x === x0 || x === x1 || y === y0 || y === y1 || z === z0 || z === z1;
      if (mode === 'outline' && !border) continue;
      if (mode === 'hollow' && !border) { e.setBlock(x, y, z, 0, 0); count++; continue; }
      e.setBlock(x, y, z, bid, 0);
      count++;
    }
    return `Filled ${count} blocks with ${bname}`;
  }
  if (cmd === 'clone') {
    const pose = { x: e.position.x, y: e.position.y, z: e.position.z, yaw: e.input?.yaw, pitch: e.input?.pitch };
    const c1 = parseCoords(args.slice(0, 3), pose), c2 = parseCoords(args.slice(3, 6), pose), dst = parseCoords(args.slice(6, 9), pose);
    if (!c1 || !c2 || !dst) return 'Usage: /clone <x1> <y1> <z1> <x2> <y2> <z2> <dx> <dy> <dz>';
    const x0 = Math.min(c1[0], c2[0]), x1 = Math.max(c1[0], c2[0]);
    const y0 = Math.min(c1[1], c2[1]), y1 = Math.max(c1[1], c2[1]);
    const z0 = Math.min(c1[2], c2[2]), z1 = Math.max(c1[2], c2[2]);
    const buf: [number, number, number, number, number][] = [];
    for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
      const cell = e.getCell(x, y, z);
      buf.push([x - x0, y - y0, z - z0, blockId(cell), blockState(cell)]);
    }
    for (const [ox, oy, oz, id, st] of buf) e.setBlock(dst[0] + ox, dst[1] + oy, dst[2] + oz, id, st);
    return `Cloned ${buf.length} blocks`;
  }
  if (cmd === 'summon') {
    const sp = (args[0] ?? '').replace(/^minecraft:/, '');
    const pose = { x: e.position.x, y: e.position.y, z: e.position.z, yaw: e.input?.yaw, pitch: e.input?.pitch };
    const c = args.length >= 4 ? parseCoords(args.slice(1, 4), pose) : [Math.floor(e.position.x), Math.floor(e.position.y), Math.floor(e.position.z)];
    if (!sp || !c) return 'Usage: /summon <entity> [x y z]';
    const m = e.mobs?.spawn(sp as any, c[0] + 0.5, c[2] + 0.5, false, c[1]);
    return m ? `Summoned ${sp} at ${c[0]}, ${c[1]}, ${c[2]}` : `Could not summon ${sp}`;
  }
  if (cmd === 'kill') {
    if (args[0] && args[0].startsWith('@')) {
      const sel = parseSelector(args[0]);
      if (sel && sel.target === 'e') {
        let n = 0;
        for (const m of [...(e.mobs?.mobs ?? [])]) {
          if (sel.type && m.species !== sel.type) continue;
          if (sel.maxDistance !== undefined && m.group.position.distanceTo(e.position) > sel.maxDistance) continue;
          e.mobs.kill(m);
          n++;
        }
        return `Killed ${n} entity(s)`;
      }
    }
    hurt(e, 1000, 'void');
    return 'Ouch.';
  }
  return 'Unknown command. /help';
}
export function loadPlayer(e: Engine, save?: WorldSave) {
  e.armor = [0, 1, 2, 3].map(i => save?.armor?.[i] ?? null);
  e.offhand = save?.offhand ?? null;
  e.effects = { ...(save?.effects ?? {}) };
  e.absorption = save?.absorption ?? 0;
  e.enchantSeed = save?.enchantSeed ?? (hashStr(e.meta.seed + e.meta.id) % 2147483647 || 1);
  e.attackAt = -10; e.useTime = 0; e.useItemName = ''; e.blocking = false; e.portalLock = false; e.swingHeld = false;
  e.saturation = save?.saturation ?? 5; e.exhaustion = save?.exhaustion ?? 0; e.foodTimer = 0; e.foodAcc = 0; e.foodPtick = 0;
  e.shieldCdUntil = (save?.shieldCd ?? 0) > 0 ? e.elapsed + save!.shieldCd! : -1;
  e.maps = new Map(((save?.maps ?? []) as MapSave[]).map(s => { const m = deserializeMap(s); return [m.id, m] as [number, MapData]; }));
  e.nextMapId = Math.max(save?.nextMapId ?? 1, ...[...e.maps.keys()].map(k => k + 1), 1);
  e.lecternPages = { ...(save?.lecternPages ?? {}) };
  if (save && save.xpV !== 2) e.xp = V.migrateOldXp(e.xp);           // old saves stored level² — keep the level and bar progress
  e.lastLevel = level(e);
  e.banners = new Map(Object.entries(save?.banners ?? {}));
  any(e).shieldRaise = null; any(e).useHand = 'main'; any(e)._frost = new Map();
  const a = any(e); a.metaDrops = []; a.returning = []; a._fxAcc = {};
  if (save?.elytraEquipped && !save.armor) {                         // saves from before equipment slots: wear the elytra properly
    for (let i = 0; i < 36; i++) if (slotAt(e, i)?.name === 'elytra') { e.armor[1] = slotAt(e, i); setSlot(e, i, null); break; }
  }
  syncEquip(e);
}
export const savePlayer = (e: Engine) => ({
  armor: e.armor, offhand: e.offhand, effects: e.effects, absorption: e.absorption, enchantSeed: e.enchantSeed,
  saturation: e.saturation, exhaustion: e.exhaustion, xpV: 2, shieldCd: Math.max(0, shieldCooldown(e)),
  maps: [...e.maps.values()].map(serializeMap), nextMapId: e.nextMapId, lecternPages: e.lecternPages,
});
export function hud(e: Engine) {
  return {
    armorSlots: e.armor.map(s => (s ? { ...s } : null)), offhand: e.offhand ? { ...e.offhand } : null,
    effects: Object.entries(e.effects).map(([id, v]) => ({ id, t: v.t, amp: v.amp })), absorption: e.absorption,
    attackCharge: attackCharge(e), useCharge: e.useItemName ? Math.min(1, e.useTime / chargeTime(e)) : (any(e).gameplay?.useProgress?.() ?? 0), blocking: e.blocking,
    saturation: e.saturation, xpProgress: V.xpProgress(e.xp), shieldCd: shieldCooldown(e), shieldActive: shieldReady(e),
    hitAngle: e.lastHit?.angle ?? 0, hitAge: e.lastHit ? e.elapsed - e.lastHit.t : 99,
    heldMapId: (() => { for (const s of [e.hotbar[e.selected], e.offhand]) if (s?.name === 'filled_map') return mapOf(e, s)?.id ?? -1; return -1; })(),
    mapVersion: (() => { for (const s of [e.hotbar[e.selected], e.offhand]) if (s?.name === 'filled_map') return mapOf(e, s)?.version ?? 0; return 0; })(),
  };
}
/** Worlds saved with the old 128-block height: lift overworld edits so builds stay on the (now higher) ground. */
export function liftLegacyOverworld(store: { edits: Map<string, number>; containers: Record<string, unknown>; furnaces: Record<string, unknown> }, dy = 43) {
  const shift = (key: string) => { const [x, y, z] = key.split(',').map(Number); return `${x},${y + dy},${z}`; };
  const edits = new Map<string, number>();
  for (const [k, v] of store.edits) edits.set(shift(k), v);
  store.edits = edits;
  store.containers = Object.fromEntries(Object.entries(store.containers).map(([k, v]) => [shift(k), v]));
  store.furnaces = Object.fromEntries(Object.entries(store.furnaces).map(([k, v]) => [shift(k), v]));
}

// ---- Two-handed right-click and comparator readings (kept here so they can be unit-tested against a stub engine) --------------
/**
 * Java's use order: the main hand acts first; only when it passes (`attempt` returns false: nothing placed, used or opened) is the
 * off-hand tried. The off-hand attempt swaps the two stacks around the shared handling code, so block placement, eating, buckets,
 * bows, shields and books work from the off-hand with identical rules and item consumption.
 */
export function useBothHands(e: Engine, attempt: () => boolean): void {
  e.handCtx = 'main';
  if (attempt() || !e.offhand) return;
  const main = e.hotbar[e.selected];
  e.hotbar[e.selected] = e.offhand; e.offhand = main;
  e.handCtx = 'off';
  try { attempt(); } finally {
    const used = e.hotbar[e.selected];
    e.hotbar[e.selected] = e.offhand; e.offhand = used;
    e.handCtx = 'main';
  }
}
const ANALOG_CONTAINERS = new Set(['chest', 'trapped_chest', 'barrel', 'furnace', 'blast_furnace', 'smoker', 'hopper', 'dropper', 'dispenser', 'brewing_stand']);
/**
 * Comparator reading of a block. Inventories read their fullness; the cauldron (water level), jukebox (disc number), composter
 * (fill stage), lectern (open page), end portal frame (eye) and respawn anchor (charges) read their own state. null = no analog output.
 */
export function analogSignal(e: Engine, x: number, y: number, z: number): number | null {
  const ov = any(e).gameplay?.comparatorOverride?.(x, y, z) ?? -1;
  if (ov >= 0) return ov;
  const id = e.getBlock(x, y, z);
  if (id <= 0) return null;
  const name = BLOCKS[id]?.name ?? '', key = `${x},${y},${z}`, st = blockState(e.getCell(x, y, z));
  if (name === 'copper_bulb_lit' || name === 'lit_copper_bulb') return 15;
  if (name === 'copper_bulb') return st & 8 ? 15 : 0;
  if (name === 'cauldron') return V.cauldronSignal(st);
  if (name === 'composter') return V.composterSignal(st);
  if (name === 'jukebox') return V.DISC_SIGNAL[e.containers[key]?.[0]?.name ?? ''] ?? (st > 0 ? st : 0);
  if (name === 'cake') return Math.max(0, 14 - (st & 7) * 2);
  if (name === 'lectern') { const b = e.containers[key]?.[0]; return b ? V.lecternSignal(lecternPage(e, key), bookPages(b).length) : 0; }
  if (name === 'end_portal_frame') return st & 4 ? 15 : 0;
  if (name === 'respawn_anchor') return V.anchorSignal(st);
  if (!ANALOG_CONTAINERS.has(name) && !/shulker_box$/.test(name)) return null;
  const slots = e.containers[key];
  if (!slots || !slots.length) return 0;
  return V.fullnessSignal(slots.map(s => (s ? { count: s.count, max: resolve(s.name)?.stack ?? 64 } : null)));
}
