export type Pattern = 'grass' | 'dirt' | 'stone' | 'sand' | 'bark' | 'rings' | 'leaves' | 'planks' | 'water' | 'glass' | 'bricks' | 'cobble' | 'tnt' | 'ore' | 'gravel' | 'snow' | 'plant' | 'craft' | 'furnace' | 'chest' | 'torch' | 'lava' | 'obsidian' | 'wool' | 'metal' | 'gem' | 'tool' | 'food' | 'misc' | 'cactus' | 'nylium' | 'bed' | 'purpur' | 'end_portal_frame' | 'shulker' | 'debris' | 'concrete' | 'terracotta' | 'prismarine' | 'quartz' | 'mushroom' | 'sponge' | 'amethyst' | 'deepslate' | 'target';
export type Shape = 'cube' | 'chest' | 'cross' | 'water' | 'slab' | 'stairs' | 'fence' | 'pane' | 'torch' | 'door' | 'trapdoor' | 'lily' | 'cactus' | 'bed' | 'end_portal_frame' | 'end_rod' | 'shulker_box' | 'dragon_egg' | 'dragon_head' | 'end_portal' | 'end_gateway' | 'lantern' | 'enchanting_table' | 'anvil' | 'brewing_stand' | 'piston_head' | 'moving_piston';
export interface BlockDef { id: number; name: string; ja: string; color: string; pattern: Pattern; hardness: number; tool: string; solid: boolean; transparent: boolean; shape: Shape; category: string; drop?: string; light?: number; tier?: number; stack: number; food?: number; damage?: number; durability?: number; }
export const BLOCKS: BlockDef[] = [{ id: 0, name: 'air', ja: '空気', color: '#ffffff', pattern: 'misc', hardness: 0, tool: '', solid: false, transparent: true, shape: 'cube', category: 'nature', stack: 0 }];
export const ID: Record<string, number> = { air: 0 };
export function block(name: string, ja: string, color: string, pattern: Pattern, hardness = 1, extra: Partial<BlockDef> = {}) {
  if (ID[name] !== undefined) return ID[name];
  const id = BLOCKS.length;
  BLOCKS.push({ id, name, ja, color, pattern, hardness, tool: '', solid: true, transparent: false, shape: 'cube', category: 'building', stack: 64, ...extra });
  ID[name] = id; return id;
}

block('grass_block', '草ブロック', '#6f9846', 'grass', .6, { tool: 'shovel', drop: 'dirt', category: 'nature' });
block('dirt', '土', '#8a6244', 'dirt', .5, { tool: 'shovel', category: 'nature' });
block('stone', '石', '#92938a', 'stone', 1.5, { tool: 'pickaxe', tier: 1, drop: 'cobblestone' });
block('sand', '砂', '#dfd29a', 'sand', .5, { tool: 'shovel', category: 'nature' });
block('oak_log', 'オークの原木', '#6b5130', 'bark', 2, { tool: 'axe', category: 'nature' });
block('oak_leaves', 'オークの葉', '#548637', 'leaves', .2, { transparent: true, category: 'nature' });
block('oak_planks', 'オークの板材', '#b8945f', 'planks', 2, { tool: 'axe' });
block('water', '水', '#329caa', 'water', 100, { solid: false, transparent: true, shape: 'water', category: 'nature' });
block('glass', 'ガラス', '#b4dce1', 'glass', .3, { transparent: true, category: 'building' });
block('stone_bricks', '石レンガ', '#8b8e83', 'bricks', 1.5, { tool: 'pickaxe', tier: 1 });
block('bedrock', '岩盤', '#454843', 'stone', Infinity, { tier: 99 });
block('snow_block', '雪ブロック', '#e4edf0', 'snow', .2, { tool: 'shovel', category: 'nature' });
block('gravel', '砂利', '#99918a', 'gravel', .6, { tool: 'shovel', category: 'nature' });
block('coal_ore', '石炭鉱石', '#8b8d84', 'ore', 3, { tool: 'pickaxe', tier: 1, drop: 'coal', category: 'ores' });
block('iron_ore', '鉄鉱石', '#92918a', 'ore', 3, { tool: 'pickaxe', tier: 2, category: 'ores' });
block('gold_ore', '金鉱石', '#92918a', 'ore', 3, { tool: 'pickaxe', tier: 3, category: 'ores' });
block('diamond_ore', 'ダイヤモンド鉱石', '#828b89', 'ore', 3, { tool: 'pickaxe', tier: 3, drop: 'diamond', category: 'ores' });
block('cobblestone', '丸石', '#82877e', 'bricks', 2, { tool: 'pickaxe', tier: 1 });
block('birch_log', 'シラカバの原木', '#e0dccb', 'bark', 2, { tool: 'axe', category: 'nature' });
block('birch_leaves', 'シラカバの葉', '#77a34a', 'leaves', .2, { transparent: true, category: 'nature' });
block('poppy', 'ポピー', '#dc5540', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature' });
block('short_grass', '草', '#70a246', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature', drop: 'wheat_seeds' });
block('crafting_table', '作業台', '#a37b46', 'craft', 2.5, { tool: 'axe', category: 'utility' });
block('furnace', 'かまど', '#777c76', 'furnace', 3.5, { tool: 'pickaxe', tier: 1, category: 'utility' });
block('chest', 'チェスト', '#b88438', 'chest', 2.5, { tool: 'axe', shape: 'chest', transparent: true, category: 'utility' });
block('torch', '松明', '#f4be54', 'torch', 0, { solid: false, transparent: true, shape: 'torch', light: 14, category: 'utility' });
block('lava', '溶岩', '#f88720', 'lava', 100, { solid: false, transparent: true, shape: 'water', light: 15, category: 'nature' });
block('obsidian', '黒曜石', '#171026', 'obsidian', 50, { tool: 'pickaxe', tier: 4 });
block('netherrack', 'ネザーラック', '#85433d', 'stone', .4, { tool: 'pickaxe', tier: 1, category: 'nature' });
block('end_stone', 'エンドストーン', '#d9d59c', 'stone', 3, { tool: 'pickaxe', tier: 1, category: 'nature' });
block('dandelion', 'タンポポ', '#f1ce49', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature' });
block('white_wool', '白い羊毛', '#e4e2d8', 'wool', .8, { category: 'decorations' });
export const ITEMS: BlockDef[] = [];
export const ITEM_ID: Record<string, number> = {};
export function item(name: string, ja: string, color: string, pattern: Pattern, extra: Partial<BlockDef> = {}) {
  if (ITEM_ID[name] !== undefined) return;
  ITEM_ID[name] = ITEMS.length;
  ITEMS.push({ id: ITEMS.length, name, ja, color, pattern, hardness: 0, tool: '', solid: false, transparent: true, shape: 'cube', category: 'items', stack: 64, ...extra });
}
item('stick', '棒', '#a27d49', 'tool');
item('coal', '石炭', '#3d4140', 'gem', { category: 'materials' });
item('diamond', 'ダイヤモンド', '#55d9cf', 'gem', { category: 'materials' });
item('iron_ingot', '鉄インゴット', '#d4d9d6', 'metal', { category: 'materials' });
item('gold_ingot', '金インゴット', '#efc64d', 'metal', { category: 'materials' });
item('apple', 'リンゴ', '#d84c38', 'food', { food: 4, stack: 64, category: 'food' });
item('bread', 'パン', '#c9954e', 'food', { food: 5, category: 'food' });
item('wheat', '小麦', '#d6b658', 'plant', { category: 'materials' });
item('wheat_seeds', '小麦の種', '#81a64d', 'misc', { category: 'materials' });
item('raw_beef', '生の牛肉', '#bb5a51', 'food', { food: 3, category: 'food' });
item('cooked_beef', 'ステーキ', '#8f5436', 'food', { food: 8, category: 'food' });
item('porkchop', '生の豚肉', '#d89389', 'food', { food: 3, category: 'food' });
item('cooked_porkchop', '焼き豚', '#ba8b57', 'food', { food: 8, category: 'food' });
item('leather', '革', '#a26841', 'misc', { category: 'materials' });
item('feather', '羽根', '#e8e7df', 'tool', { category: 'materials' });
item('bone', '骨', '#dcd9c7', 'tool', { category: 'materials' });
item('rotten_flesh', '腐った肉', '#927148', 'food', { food: 4, category: 'food' });
item('string', '糸', '#e2e1d8', 'misc', { category: 'materials' });
item('gunpowder', '火薬', '#737570', 'misc', { category: 'materials' });
item('bucket', 'バケツ', '#aab6b6', 'misc', { stack: 1, category: 'tools' });
item('water_bucket', '水入りバケツ', '#4ba5c5', 'misc', { stack: 1, category: 'tools' });
export function resolve(name: string) { return ID[name] !== undefined ? { ...BLOCKS[ID[name]], block: true } : ITEM_ID[name] !== undefined ? { ...ITEMS[ITEM_ID[name]], block: false } : undefined; }
export const isSolid = (id: number) => !!BLOCKS[id]?.solid;
export const isOpaque = (id: number) => !!id && !BLOCKS[id]?.transparent;
/**
 * Minecraft準拠の面別タイル割当。
 * face: 0=+X 1=-X 2=+Y(上面) 3=-Y(下面) 4=+Z(前面) 5=-Z(背面)
 * チェストの留め具は前面のみ、かまどの口は前面のみ、上面・下面は無地。
 */
export function faceTile(b: BlockDef, face: number) {
  const n = b.name;
  // Directional blocks intentionally use separate atlas tiles on all six faces.
  if (n === 'cactus') return face === 2 ? 'cactus_top' : face === 3 ? 'cactus_bottom' : 'cactus_side';
  if (n === 'basalt') return face === 2 || face === 3 ? 'basalt_top' : 'basalt_side';
  if (n === 'pumpkin' || n === 'carved_pumpkin') return face === 2 || face === 3 ? 'pumpkin_top' : face === 4 ? 'pumpkin_front' : 'pumpkin';
  if (n === 'melon') return face === 2 || face === 3 ? 'melon_top' : 'melon';
  if (n === 'quartz_block' || n === 'quartz_pillar') return face === 2 || face === 3 ? 'quartz_block_top' : 'quartz_block_side';
  if (n === 'bone_block') return face === 2 || face === 3 ? 'bone_block_top' : 'bone_block_side';
  if (n === 'hay_block') return face === 2 || face === 3 ? 'hay_block_top' : 'hay_block_side';
  if (n === 'bookshelf') return face === 2 || face === 3 ? 'oak_planks' : 'bookshelf';
  if (n === 'chiseled_bookshelf') return face === 2 || face === 3 ? 'oak_planks' : face === 4 ? 'bookshelf' : 'oak_planks';
  if (n === 'lectern') return face === 2 ? 'oak_planks' : face === 3 ? 'oak_planks' : face === 4 ? 'bookshelf' : 'oak_planks';
  if (n === 'jukebox') return face === 2 ? 'jukebox_top' : 'jukebox_side';
  if (n === 'respawn_anchor') return face === 2 ? 'respawn_anchor_top' : face === 3 ? 'crying_obsidian' : 'respawn_anchor_side';
  if (n === 'mushroom_block' || n === 'red_mushroom_block' || n === 'brown_mushroom_block') {
    return face === 2 ? n + '_top' : face === 3 ? n + '_stem' : n + '_side';
  }
  if (n === 'redstone_lamp' || n === 'unlit_redstone_lamp') return face === 2 || face === 3 ? n + '_top' : n + '_side';
  if (n === 'sea_lantern') return face === 2 || face === 3 ? 'sea_lantern_top' : 'sea_lantern_side';
  if (n === 'prismarine') return face === 2 || face === 3 ? 'prismarine_top' : 'prismarine_side';
  if (n === 'target') return face === 2 || face === 3 ? 'target_top' : 'target_side';
  if (n === 'sponge') return face === 2 || face === 3 ? 'sponge_top' : 'sponge_side';
  if (n === 'amethyst_block') return face === 2 || face === 3 ? 'amethyst_block_top' : 'amethyst_block_side';
  if (n === 'piston' || n === 'sticky_piston') return face === 2 || face === 3 ? n + '_top' : face === 4 ? n + '_front' : n + '_side';
  if (n === 'dispenser' || n === 'dropper' || n === 'observer') return face === 2 || face === 3 ? n + '_top' : face === 4 ? n + '_front' : n + '_side';
  if (n.endsWith('_door')) { const d = n.replace(/^open_/, ''); return face === 2 ? d + '_top' : d + '_bottom'; }
  if (n.endsWith('_button')) return n.replace(/_button$/, '_planks');
  if (n === 'lever') return face === 3 ? 'cobblestone' : 'lever';
  if (n === 'lantern') return face === 2 || face === 3 ? 'lantern_top' : 'lantern';
  if (n === 'soul_lantern') return face === 2 || face === 3 ? 'lantern_top' : 'soul_lantern';
  if (n === 'enchanting_table') return face === 2 ? 'enchanting_table_top' : face === 3 ? 'obsidian' : 'enchanting_table_side';
  if (n === 'farmland' || n === 'farmland_moist') return face === 2 ? 'farmland_top' : 'dirt';
  if (n === 'crafter') return face === 2 ? 'crafting_table_top' : face === 3 ? 'furnace_bottom' : face === 4 ? 'dispenser_front' : 'crafting_table_side';
  if (n === 'sandstone' || n === 'red_sandstone') return face === 2 ? n + '_top' : face === 3 ? n + '_bottom' : n + '_side';
  if (n === 'chiseled_sandstone') return n;
  if (n === 'cut_sandstone') return face === 2 || face === 3 ? 'sandstone_top' : n;
  if (n === 'purpur_pillar' || n === 'bone_block' || n === 'hay_block') return face === 2 || face === 3 ? n + '_top' : n;
  if (n === 'ancient_debris') return face === 2 || face === 3 ? 'ancient_debris_top' : 'ancient_debris_side';
  if (n === 'crimson_nylium' || n === 'warped_nylium') return face === 2 ? n : face === 3 ? 'netherrack' : n + '_side';
  if (n === 'end_portal_frame') return face === 2 ? 'end_portal_frame_top' : face === 3 ? 'end_stone' : 'end_portal_frame_side';
  if (n === 'shulker_box') return face === 2 ? 'shulker_box_top' : face === 3 ? 'shulker_box_bottom' : 'shulker_box_side';
  if (n === 'bed') return face === 2 ? 'bed_head_top' : face === 3 ? 'bed_foot_top' : face === 1 ? 'bed_head_side' : 'bed_side';
  if (n === 'chest') return face === 2 ? 'chest_top' : face === 3 ? 'chest_bottom' : face === 4 ? 'chest_front' : 'chest_side';
  if (n === 'trapped_chest') return face === 2 ? 'chest_top' : face === 3 ? 'chest_bottom' : face === 4 ? 'trapped_chest_front' : 'chest_side';
  if (n === 'ender_chest') return face === 2 ? 'ender_chest_top' : face === 3 ? 'ender_chest_bottom' : face === 4 ? 'ender_chest_front' : 'ender_chest_side';
  if (n === 'barrel') return face === 2 || face === 3 ? 'barrel_top' : face === 4 ? 'barrel_front' : 'barrel_side';
  if (n === 'tnt') return face === 2 || face === 3 ? 'tnt_top' : 'tnt_side';
  if (n === 'crafting_table') return face === 2 ? 'crafting_table_top' : face === 3 ? 'oak_planks' : face === 4 ? 'crafting_table_front' : 'crafting_table_side';
  if (b.pattern === 'furnace') {
    const key = n.startsWith('blast_furnace') ? 'blast_furnace' : n.startsWith('smoker') ? 'smoker' : n.startsWith('observer') ? 'observer' : n.startsWith('dropper') ? 'dropper' : n.startsWith('dispenser') ? 'dispenser' : 'furnace';
    return face === 2 ? key + '_top' : face === 3 ? key + '_bottom' : face === 4 ? key + '_front' : key + '_side';
  }
  if (n === 'moss_block') return 'moss_block';
  if (n === 'muddy_mangrove_roots') return (face === 2 || face === 3) ? 'muddy_mangrove_roots_top' : 'muddy_mangrove_roots_side';
  if (n === 'mangrove_roots') return (face === 2 || face === 3) ? 'mangrove_roots_top' : 'mangrove_roots_side';
  if (b.pattern === 'grass') return face === 2 ? n : face === 3 ? 'dirt' : (n === 'grass_block' ? 'grass_side' : n + '_side');
  if (b.pattern === 'bark') return (face === 2 || face === 3) ? n + '_top' : n;
  return n;
}
export const ATLAS_COLS = 16;
export const TILE = 20;
