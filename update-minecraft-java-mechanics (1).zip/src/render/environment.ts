import * as THREE from 'three';
import { makeAtlasTexture, makeAtlasDataArray, atlasCanvas } from '../textures/atlas';
import { canvas } from '../textures/canvas';
import { dynamicFov, NETHER_ATMOSPHERES, type FovState as VisualFovState } from './visuals';
import type { ParticleSystem } from './particles';
import { random } from '../input/math';
import { underwaterFog } from '../game/vanilla';
const NV_WATER = new THREE.Color('#37a9c4');
import type { Settings, Dimension } from '../game/types';


// =====================================================================================================================
// Weather & atmosphere (Java Edition)
// ---------------------------------------------------------------------------------------------------------------------
// * Precipitation: a biome without precipitation stays dry; otherwise it snows where the temperature is below 0.15 and
//   rains elsewhere. Above Y=80 the temperature drops by 0.05 / 40 = 0.00125 per block, so cold-ish biomes get a snow line.
// * Nether biome ambience (biome JSON `effects.particle`): soul sand valley = ash (0.00625), crimson forest = crimson_spore
//   (0.025), warped forest = warped_spore (0.01428), basalt deltas = white_ash (0.118093334); nether wastes has none.
// * Dynamic FOV: AbstractClientPlayer.getFieldOfViewModifier + GameRenderer.tickFov.
// =====================================================================================================================

export type Precipitation = 'none' | 'rain' | 'snow';
export const SNOW_TEMPERATURE = 0.15;
export const TEMPERATURE_LAPSE_START_Y = 80;
export const TEMPERATURE_LAPSE_PER_BLOCK = 0.05 / 40;

const CLIMATE = (t: number, wet = true) => ({ t, wet });
/** Base temperature and "has precipitation" of every Java Edition overworld biome. */
export const BIOME_CLIMATE: Record<string, { t: number; wet: boolean }> = {
  snowy_plains: CLIMATE(0), ice_spikes: CLIMATE(0), snowy_taiga: CLIMATE(-0.5), snowy_beach: CLIMATE(0.05), frozen_river: CLIMATE(0),
  frozen_ocean: CLIMATE(0), deep_frozen_ocean: CLIMATE(0.5), grove: CLIMATE(-0.2), snowy_slopes: CLIMATE(-0.3), jagged_peaks: CLIMATE(-0.7), frozen_peaks: CLIMATE(-0.7),
  taiga: CLIMATE(0.25), old_growth_pine_taiga: CLIMATE(0.3), old_growth_spruce_taiga: CLIMATE(0.25),
  windswept_hills: CLIMATE(0.2), windswept_gravelly_hills: CLIMATE(0.2), windswept_forest: CLIMATE(0.2), stony_shore: CLIMATE(0.2),
  meadow: CLIMATE(0.5), cherry_grove: CLIMATE(0.5), stony_peaks: CLIMATE(1.0),
  plains: CLIMATE(0.8), sunflower_plains: CLIMATE(0.8), forest: CLIMATE(0.7), flower_forest: CLIMATE(0.7), birch_forest: CLIMATE(0.6), old_growth_birch_forest: CLIMATE(0.6),
  dark_forest: CLIMATE(0.7), pale_garden: CLIMATE(0.7), swamp: CLIMATE(0.8), mangrove_swamp: CLIMATE(0.8), river: CLIMATE(0.5), beach: CLIMATE(0.8),
  ocean: CLIMATE(0.5), deep_ocean: CLIMATE(0.5), cold_ocean: CLIMATE(0.5), deep_cold_ocean: CLIMATE(0.5), lukewarm_ocean: CLIMATE(0.5), deep_lukewarm_ocean: CLIMATE(0.5), warm_ocean: CLIMATE(0.5),
  mushroom_fields: CLIMATE(0.9), jungle: CLIMATE(0.95), sparse_jungle: CLIMATE(0.95), bamboo_jungle: CLIMATE(0.95),
  dripstone_caves: CLIMATE(0.8), lush_caves: CLIMATE(0.5), deep_dark: CLIMATE(0.8),
  desert: CLIMATE(2, false), savanna: CLIMATE(2, false), savanna_plateau: CLIMATE(2, false), windswept_savanna: CLIMATE(2, false),
  badlands: CLIMATE(2, false), eroded_badlands: CLIMATE(2, false), wooded_badlands: CLIMATE(2, false),
};

export interface AtmosphereWorld {
  surfaceAt(x: number, z: number): { y: number; solid: boolean } | null;
  biomeAt(x: number, z: number): string;
}

export function biomeClimate(biome: string): { t: number; wet: boolean } {
  biome = biome.replace(/^minecraft:/, '');
  const c = BIOME_CLIMATE[biome];
  if (c) return c;
  if (/desert|savanna|badlands/.test(biome)) return { t: 2, wet: false };
  if (/snow|frozen|ice_|grove|jagged/.test(biome)) return { t: 0, wet: true };
  return { t: 0.8, wet: true };
}

/** Biome temperature at a height (Biome.getHeightAdjustedTemperature without the ±8 block noise). */
export function biomeTemperature(biome: string, y = 64): number {
  const t = biomeClimate(biome).t;
  return y > TEMPERATURE_LAPSE_START_Y ? t - (y - TEMPERATURE_LAPSE_START_Y) * TEMPERATURE_LAPSE_PER_BLOCK : t;
}

/** What falls from the sky at this biome / height while the weather is rainy or stormy. */
export function precipitationAt(biome: string, y = 64, dimension: Dimension | string = 'overworld'): Precipitation {
  if (dimension !== 'overworld') return 'none';
  if (!biomeClimate(biome).wet) return 'none';
  return biomeTemperature(biome, y) < SNOW_TEMPERATURE ? 'snow' : 'rain';
}

/** Lowest Y at which the biome gets snow instead of rain (-Infinity: always snow, Infinity: never). */
export function snowLine(biome: string): number {
  const c = biomeClimate(biome);
  if (!c.wet) return Infinity;
  if (c.t < SNOW_TEMPERATURE) return -Infinity;
  const y = TEMPERATURE_LAPSE_START_Y + (c.t - SNOW_TEMPERATURE) / TEMPERATURE_LAPSE_PER_BLOCK;
  return y > 320 ? Infinity : Math.floor(y) + 1;
}

/** Seconds⁻¹ at which rain and snow cross-fade when the precipitation type changes ("gradually increase / decrease in density"). */
export const PRECIPITATION_BLEND_RATE = 1.6;
export function stepPrecipitationMix(mix: { rain: number; snow: number }, target: Precipitation, dt: number) {
  const k = Math.min(1, Math.max(0, dt) * PRECIPITATION_BLEND_RATE);
  mix.rain += ((target === 'rain' ? 1 : 0) - mix.rain) * k;
  mix.snow += ((target === 'snow' ? 1 : 0) - mix.snow) * k;
  return mix;
}

/** Snowflakes: slow, with a lot of sideways sway (rain falls at 20‥28 blocks/s in this renderer). */
export const SNOW = { count: 900, box: [40, 30, 40] as [number, number, number], fall: 1.35, sway: 0.75, size: 0.11, opacity: 0.92 };

export interface NetherAmbientSpec {
  /** Java Edition particle id. */
  particle: 'ash' | 'white_ash' | 'crimson_spore' | 'warped_spore';
  /** `effects.particle.probability` of the biome. */
  probability: number;
  /** sRGB colour range of the particle (0‥1). */
  color: [number, number, number];
  color2: [number, number, number];
  /** Average drift in blocks / second. */
  drift: [number, number, number];
  /** 1 = velocities spread like `random * random` (white ash gusts), 0 = uniform. */
  spread: number;
  jitter: number;
  size: number;
  opacity: number;
  count: number;
}
export const NETHER_DUST_CAPACITY = 1000;
const WHITE_ASH_P = 0.118093334;
const dustCount = (p: number) => Math.round((NETHER_DUST_CAPACITY * p) / WHITE_ASH_P);
export const NETHER_AMBIENT: Record<string, NetherAmbientSpec> = {
  // AshParticle: grey of brightness random * 0.5, sinks slowly.
  soul_sand_valley: { particle: 'ash', probability: 0.00625, color: [0.05, 0.05, 0.05], color2: [0.5, 0.5, 0.5], drift: [0, -1.0, 0], spread: 0, jitter: 0.35, size: 0.13, opacity: 0.9, count: dustCount(0.00625) },
  // SuspendedParticle (crimson): (0.9, 0.4, 0.5), practically motionless.
  crimson_forest: { particle: 'crimson_spore', probability: 0.025, color: [0.9, 0.4, 0.5], color2: [0.78, 0.3, 0.42], drift: [0, -0.04, 0], spread: 0, jitter: 0.18, size: 0.1, opacity: 0.95, count: dustCount(0.025) },
  // SuspendedParticle (warped): (0.1, 0.1, 0.3), drifts down at random * random * 0.19 blocks / tick.
  warped_forest: { particle: 'warped_spore', probability: 0.01428, color: [0.1, 0.1, 0.3], color2: [0.16, 0.2, 0.42], drift: [0, -0.95, 0], spread: 1, jitter: 0.12, size: 0.1, opacity: 0.95, count: dustCount(0.01428) },
  // WhiteAshParticle: (0.729, 0.694, 0.761), blown sideways and down — "noticeable like a storm".
  basalt_deltas: { particle: 'white_ash', probability: WHITE_ASH_P, color: [0.7294118, 0.69411767, 0.7607843], color2: [0.62, 0.59, 0.65], drift: [-0.95, -1.25, -0.95], spread: 1, jitter: 0.1, size: 0.1, opacity: 0.85, count: dustCount(WHITE_ASH_P) },
};
export function netherAmbientFor(dimension: Dimension | string, biome: string): NetherAmbientSpec | null {
  return dimension === 'nether' ? NETHER_AMBIENT[biome] ?? null : null;
}

// ---- Dynamic FOV ----------------------------------------------------------------------------------------------------

export const FOV_EFFECTS = {
  /** Sprinting multiplies the movement speed attribute by 1.3 -> FOV x1.15. */
  sprintSpeed: 1.3,
  /** Speed: +20 % per level -> FOV x1.1 (I), x1.2 (II). */
  speedPerLevel: 0.2,
  /** Slowness: -15 % per level -> FOV x0.925 (I). */
  slownessPerLevel: 0.15,
  flying: 1.1,
  /** A fully drawn bow (20 ticks) narrows the view by 15 %. */
  bowZoom: 0.15,
  bowFullTicks: 20,
  min: 0.1,
  max: 1.5,
  /** GameRenderer.tickFov: fov += (target - fov) * 0.5 every tick. */
  lerpPerTick: 0.5,
  /** Camera inside water / lava: x 60/70. */
  submerged: 60 / 70,
};

export interface FovState {
  sprinting?: boolean;
  flying?: boolean;
  /** Speed level (1 = Speed I), 0 when the effect is absent. */
  speed?: number;
  slowness?: number;
  /** Ticks the bow has been drawn for; 0 / undefined when not drawing. */
  bowTicks?: number;
  submerged?: boolean;
  /** Spyglass: the modifier while scoping in first person (Java: 0.1); 0 / undefined otherwise. */
  scope?: number;
  /** "FOV Effects" accessibility slider, 0‥1 (default 1). */
  effectScale?: number;
}

/** AbstractClientPlayer.getFieldOfViewModifier. */
export function fovModifier(s: FovState): number {
  let f = 1;
  if (s.flying) f *= FOV_EFFECTS.flying;
  const speed = (s.sprinting ? FOV_EFFECTS.sprintSpeed : 1) * (1 + FOV_EFFECTS.speedPerLevel * (s.speed ?? 0)) * Math.max(0, 1 - FOV_EFFECTS.slownessPerLevel * (s.slowness ?? 0));
  f *= (speed + 1) / 2;
  const bow = s.bowTicks ?? 0;
  if (bow > 0) {
    let t = bow / FOV_EFFECTS.bowFullTicks;
    t = t > 1 ? 1 : t * t;
    f *= 1 - t * FOV_EFFECTS.bowZoom;
  }
  else if (s.scope && s.scope > 0) return s.scope;
  f = Math.min(FOV_EFFECTS.max, Math.max(FOV_EFFECTS.min, f));
  return 1 + (f - 1) * (s.effectScale ?? 1);
}

/** GameRenderer.tickFov, frame-rate independent: half of the remaining difference per 1/20 s. */
export function stepFovModifier(current: number, target: number, dt: number): number {
  const k = 1 - Math.pow(1 - FOV_EFFECTS.lerpPerTick, Math.max(0, dt) * 20);
  return Math.min(FOV_EFFECTS.max, Math.max(FOV_EFFECTS.min, current + (target - current) * k));
}

/** The vertical FOV in degrees for a settled modifier. */
export function fovDegrees(baseFov: number, modifier: number, s: FovState = {}): number {
  const sub = s.submerged ? 1 + (FOV_EFFECTS.submerged - 1) * (s.effectScale ?? 1) : 1;
  return baseFov * modifier * sub;
}

// ---- Drifting point fields (snow, nether ash & spores) -----------------------------------------------------------------

/** A box of points that drifts with the wind and wraps around the camera, so it reads as an endless field. */
export class DriftField {
  geometry = new THREE.BufferGeometry();
  material: THREE.ShaderMaterial;
  points: THREE.Points;
  count = 0;

  constructor(public capacity: number, public box: [number, number, number], rnd: () => number = Math.random) {
    const pos = new Float32Array(capacity * 3), seed = new Float32Array(capacity * 3);
    for (let i = 0; i < capacity; i++) {
      pos[i * 3] = rnd() * box[0]; pos[i * 3 + 1] = rnd() * box[1]; pos[i * 3 + 2] = rnd() * box[2];
      seed[i * 3] = rnd() * 6.2831853; seed[i * 3 + 1] = rnd(); seed[i * 3 + 2] = rnd();
    }
    this.geometry.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.geometry.setAttribute('aSeed', new THREE.BufferAttribute(seed, 3));
    this.geometry.setDrawRange(0, 0);
    this.material = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uBox: { value: new THREE.Vector3(box[0], box[1], box[2]) },
        uDrift: { value: new THREE.Vector3(0, -1, 0) }, uSpread: { value: 0 }, uJitter: { value: 0.3 }, uSize: { value: 0.1 }, uScale: { value: 600 },
        uColor: { value: new THREE.Vector3(1, 1, 1) }, uColor2: { value: new THREE.Vector3(1, 1, 1) }, uOpacity: { value: 0 },
      },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute vec3 aSeed; uniform float uTime; uniform vec3 uCam; uniform vec3 uBox; uniform vec3 uDrift; uniform float uSpread; uniform float uJitter; uniform float uSize; uniform float uScale; varying float vShade; varying float vFade;
      void main(){
        float sp = mix(0.75 + aSeed.y * 0.5, aSeed.y * aSeed.y * 4.0, uSpread);
        vec3 p = position + uDrift * sp * uTime;
        p += vec3(sin(uTime * 0.6 + aSeed.x), sin(uTime * 0.45 + aSeed.x * 1.7) * 0.5, cos(uTime * 0.5 + aSeed.x * 1.3)) * uJitter;
        p = mod(p - uCam + 0.5 * uBox, uBox) - 0.5 * uBox;
        vec4 mv = viewMatrix * vec4(uCam + p, 1.0);
        gl_Position = projectionMatrix * mv;
        gl_PointSize = clamp(uSize * uScale / max(0.1, -mv.z), 1.0, 14.0);
        vShade = aSeed.z;
        vec3 e = abs(p) / (0.5 * uBox);
        vFade = 1.0 - smoothstep(0.75, 1.0, max(e.x, max(e.y, e.z)));
      }`,
      fragmentShader: `uniform vec3 uColor; uniform vec3 uColor2; uniform float uOpacity; varying float vShade; varying float vFade;
      void main(){ gl_FragColor = vec4(mix(uColor, uColor2, vShade), uOpacity * vFade); }`,
    });
    this.points = new THREE.Points(this.geometry, this.material);
    this.points.frustumCulled = false;
    this.points.visible = false;
  }

  setCount(n: number) {
    this.count = Math.max(0, Math.min(this.capacity, Math.round(n)));
    this.geometry.setDrawRange(0, this.count);
  }

  dispose() { this.geometry.dispose(); this.material.dispose(); }
}

export interface AtmosphereInput {
  dt: number;
  elapsed: number;
  camera: { x: number; y: number; z: number };
  /** Pixels per block at distance 1 (viewport height / (2 tan(fov / 2))). */
  scale: number;
  dimension: Dimension | string;
  /** Biome at the player (may be a cave biome). */
  biome: string;
  /** Surface biome of the player's column; decides rain / snow. */
  precipBiome?: string;
  weather: 'clear' | 'rain' | 'storm';
}

/** Snowfall + nether biome ash / spores, and the rain <-> snow cross-fade. */
export class AtmosphereFx {
  snow = new DriftField(SNOW.count, SNOW.box);
  dust = new DriftField(NETHER_DUST_CAPACITY, [32, 22, 32]);
  mix = { rain: 0, snow: 0 };
  precipitation: Precipitation = 'none';
  dustSpec: NetherAmbientSpec | null = null;
  dustFade = 0;

  constructor(scene?: THREE.Scene) {
    const u = this.snow.material.uniforms;
    u.uDrift.value.set(0.25, -SNOW.fall, 0.1);
    u.uJitter.value = SNOW.sway;
    u.uSize.value = SNOW.size;
    this.snow.setCount(SNOW.count);
    if (scene) scene.add(this.snow.points, this.dust.points);
  }

  private applyDust(spec: NetherAmbientSpec) {
    const u = this.dust.material.uniforms;
    u.uColor.value.set(spec.color[0], spec.color[1], spec.color[2]);
    u.uColor2.value.set(spec.color2[0], spec.color2[1], spec.color2[2]);
    u.uDrift.value.set(spec.drift[0], spec.drift[1], spec.drift[2]);
    u.uSpread.value = spec.spread;
    u.uJitter.value = spec.jitter;
    u.uSize.value = spec.size;
    this.dust.setCount(spec.count);
  }

  update(i: AtmosphereInput) {
    const dt = Math.min(0.1, Math.max(0, i.dt));
    // Rain / snow
    this.precipitation = i.weather === 'clear' ? 'none' : precipitationAt(i.precipBiome ?? i.biome, i.camera.y, i.dimension);
    stepPrecipitationMix(this.mix, this.precipitation, dt);
    const su = this.snow.material.uniforms;
    su.uTime.value = i.elapsed;
    su.uCam.value.set(i.camera.x, i.camera.y, i.camera.z);
    su.uScale.value = i.scale;
    su.uOpacity.value = SNOW.opacity * this.mix.snow * (i.weather === 'storm' ? 1 : 0.85);
    this.snow.points.visible = this.mix.snow > 0.01;

    // Nether ash / spores: fade the old biome's particles out before the new ones fade in.
    const spec = netherAmbientFor(i.dimension, i.biome);
    if (spec !== this.dustSpec) {
      this.dustFade = Math.max(0, this.dustFade - dt * 2);
      if (this.dustFade <= 0) { this.dustSpec = spec; if (spec) this.applyDust(spec); }
    } else if (spec) this.dustFade = Math.min(1, this.dustFade + dt * 2);
    const du = this.dust.material.uniforms;
    du.uTime.value = i.elapsed;
    du.uCam.value.set(i.camera.x, i.camera.y, i.camera.z);
    du.uScale.value = i.scale;
    du.uOpacity.value = this.dustSpec ? this.dustSpec.opacity * this.dustFade : 0;
    this.dust.points.visible = !!this.dustSpec && this.dustFade > 0.01;
    return this;
  }

  dispose() {
    this.snow.points.removeFromParent(); this.dust.points.removeFromParent();
    this.snow.dispose(); this.dust.dispose();
  }
}

export class Environment {
  atlas = makeAtlasTexture();
  atlasArray: THREE.DataArrayTexture;
  material: THREE.MeshLambertMaterial;
  depthMaterial: THREE.MeshDepthMaterial;
  fallback: THREE.MeshLambertMaterial;
  water: THREE.ShaderMaterial;
  sky: THREE.Mesh;
  skyMaterial: THREE.ShaderMaterial;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  sunSprite: THREE.Mesh;
  moon: THREE.Mesh;
  moonMat: THREE.MeshBasicMaterial;
  glow: THREE.Sprite;
  stars: THREE.Points;
  clouds: THREE.InstancedMesh;
  cloudMat: THREE.MeshLambertMaterial;
  rays: THREE.Group;
  rain: THREE.Points;
  rainMat: THREE.ShaderMaterial;
  ambientParticles: THREE.Points;
  ambientMat: THREE.ShaderMaterial;
  weather: 'clear' | 'rain' | 'storm' = 'clear';
  lightning = 0;
  /** Snowfall, nether ash / spores and the rain <-> snow blend. */
  atmosphere!: AtmosphereFx;
  /** What is falling at the player right now ('snow' in cold biomes / above the snow line). */
  precipitation: Precipitation = 'none';
  /** Smoothed FOV multiplier (sprint, Speed, bow draw …). */
  fovScale = 1;
  private lastElapsed = 0;
  private world?: AtmosphereWorld;
  private weatherCursor = 0;
  private splashTime = 0;
  private splashOrigin = new THREE.Vector3();

  uniforms = {
    uTime: { value: 0 },
    uAtlasSize: { value: new THREE.Vector2(atlasCanvas.width, atlasCanvas.height) },
    uAtlasArray: { value: null as THREE.DataArrayTexture | null },
    uDay: { value: 1 },
    uDim: { value: 0 },
    uRain: { value: 0 },
    uHeldLight: { value: new THREE.Vector4(0, 0, 0, 0) },
    uNight: { value: 0 },
  };
  waterUniforms = {
    uTime: { value: 0 },
    uSun: { value: new THREE.Vector3(-0.5, 0.8, 0.3) },
    uFog: { value: new THREE.Color('#bbd8d8') },
    uNear: { value: 52 },
    uFar: { value: 120 },
    uDay: { value: 1 },
    uSkyTop: { value: new THREE.Color('#5eaee0') },
    uSkyHorizon: { value: new THREE.Color('#cce4dc') },
    uUnderwater: { value: 0 },
  };

  failed = false;
  daylight = 1;
  private lastMoonPhase = -1;
  private moonTexs: THREE.CanvasTexture[] = [];

  // Reusable scratch objects (zero per-frame allocations)
  private _sunDir = new THREE.Vector3();
  private _target = new THREE.Vector3();
  private _lightRight = new THREE.Vector3();
  private _lightUp = new THREE.Vector3();
  private _worldUp = new THREE.Vector3(0, 1, 0);
  private _top = new THREE.Color();
  private _horizon = new THREE.Color();
  private _cNightTop = new THREE.Color('#0b152a');
  private _cDayTop = new THREE.Color('#5eaee0');
  private _cNightHor = new THREE.Color('#1c2a40');
  private _cDayHor = new THREE.Color('#cce4dc');
  private _cSunset = new THREE.Color('#f09d62');
  private _cNetherTop = new THREE.Color('#421c1a');
  private _cNetherHor = new THREE.Color('#8f3e28');
  private _cEndTop = new THREE.Color('#141020');
  private _cEndHor = new THREE.Color('#352845');
  private _cSunDay = new THREE.Color('#fff1d4');
  private _cSunTwil = new THREE.Color('#ff9452');
  private _cCloudDay = new THREE.Color('#fffef5');
  private _cCloudTwil = new THREE.Color('#ffbfa0');
  private _cCloudNight = new THREE.Color('#3f4f6e');
  private _cCloudStorm = new THREE.Color('#5a6778');

  /** Shadow-map taps of the voxel material: 5 (stable Vogel disk) on High / Ultra, 1 (hardware PCF) on Low / Medium. */
  shadowTaps: 1 | 5 = 5;

  /** Switches the voxel shadow filter with the quality preset (recompiles the terrain program only when it changes). */
  setShadowQuality(quality: Settings['quality']) {
    const taps: 1 | 5 = quality === 'low' || quality === 'medium' ? 1 : 5;
    if (taps === this.shadowTaps) return;
    this.shadowTaps = taps;
    this.material.needsUpdate = true;
  }

  constructor(public scene: THREE.Scene, public renderer: THREE.WebGLRenderer, settings: Settings) {
    this.shadowTaps = settings.quality === 'low' || settings.quality === 'medium' ? 1 : 5;
    const maxAniso = Math.min(8, renderer.capabilities.getMaxAnisotropy?.() || 4);
    this.atlasArray = makeAtlasDataArray(maxAniso);
    this.uniforms.uAtlasArray.value = this.atlasArray;
    const useArray = renderer.capabilities.isWebGL2;

    this.material = new THREE.MeshLambertMaterial({
      map: this.atlas,
      vertexColors: true,
      alphaTest: 0.35,
      side: THREE.FrontSide,
    });
    this.fallback = new THREE.MeshLambertMaterial({ vertexColors: true });

    const sampleSnippet = useArray
      ? `vec2 tileUV = vec2(vMapUv.x, 1.0 - vMapUv.y);
        vec4 sampledDiffuseColor = texture(uAtlasArray, vec3(tileUV, floor(vTile + 0.5)));
        vec2 texelDx = dFdx(vMapUv) * 16.0;
        vec2 texelDy = dFdy(vMapUv) * 16.0;
        float texLod = clamp(0.5 * log2(max(dot(texelDx, texelDx), dot(texelDy, texelDy)) + 0.000001), 0.0, 3.0);
        if (sampledDiffuseColor.a < mix(0.35, 0.18, texLod / 3.0)) discard;
        sampledDiffuseColor.a = 1.0;`
      : `vec2 tileOrigin = vec2(mod(floor(vTile + 0.5), 16.0), floor(floor(vTile + 0.5) / 16.0)) * 20.0;
        vec2 uvFlipped = vec2(fract(vMapUv.x), 1.0 - fract(vMapUv.y));
        vec2 atlasUV = (tileOrigin + vec2(2.0) + clamp(uvFlipped * 16.0, 0.5, 15.5)) / uAtlasSize;
        vec4 sampledDiffuseColor = texture2D(map, atlasUV);
        if (sampledDiffuseColor.a < 0.35) discard;
        sampledDiffuseColor.a = 1.0;`;

    this.material.onBeforeCompile = (shader) => {
      Object.assign(shader.uniforms, this.uniforms);
      shader.vertexShader =
        'attribute float tile; attribute float wind; attribute vec2 aLight; varying float vTile; varying vec2 vLight; varying vec3 vWorldPos; uniform float uTime;\n' +
        shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace(
        '#include <uv_vertex>',
        '#include <uv_vertex>\nvTile = tile;\nvLight = aLight;',
      );
      shader.vertexShader = shader.vertexShader.replace(
        '#include <begin_vertex>',
        '#include <begin_vertex>\nif (wind > 0.0) { vec2 windPos = (modelMatrix * vec4(position, 1.0)).xz; transformed.x += sin(windPos.y * 0.8 + uTime * 1.45) * wind * 0.08; transformed.z += cos(windPos.x * 0.75 + uTime * 1.1) * wind * 0.055; }',
      );
      shader.vertexShader = shader.vertexShader.replace(
        '#include <project_vertex>',
        '#include <project_vertex>\nvWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;',
      );

      shader.fragmentShader =
        (useArray ? 'uniform mediump sampler2DArray uAtlasArray;\n' : '') +
        'varying float vTile; varying vec2 vLight; varying vec3 vWorldPos; uniform vec2 uAtlasSize; uniform float uTime; uniform float uDay; uniform float uDim; uniform float uRain; uniform vec4 uHeldLight; uniform float uNight;\n' +
        shader.fragmentShader;
      // Shadow filtering. The include has to be expanded here: at onBeforeCompile time the source still says
      // `#include <shadowmap_pars_fragment>`, so the old in-place `phi` replacement never matched and the screen-space
      // dither noise stayed on. High / Ultra: the 5-tap Vogel disk with a fixed rotation (stable while the camera turns).
      // Medium: one hardware-filtered PCF tap (2×2 bilinear compare) — at ~19 shadow texels per block the edge looks the
      // same, but every terrain pixel saves four shadow-map fetches, the biggest single fragment cost on mobile GPUs.
      shader.fragmentShader = shader.fragmentShader.replace('#include <shadowmap_pars_fragment>', voxelShadowPars(this.shadowTaps));
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <map_fragment>',
        `${sampleSnippet}
        if (uRain > 0.01) sampledDiffuseColor.rgb *= mix(1.0, 0.88, uRain);
        diffuseColor *= sampledDiffuseColor;`,
      );
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <lights_fragment_end>',
        `#include <lights_fragment_end>
        float skyMask = mix(uDim > 0.5 ? 0.42 : clamp(pow(vLight.x, 1.15), 0.0, 1.0), 1.0, uNight * 0.85);
        float dayLevel = mix(uDim > 0.5 ? 0.55 : mix(0.14, 1.0, uDay), 1.0, uNight * 0.9);
        float flicker = 0.97 + 0.03 * sin(uTime * 3.0 + (vWorldPos.x + vWorldPos.z) * 0.15);
        float heldDist = length(vWorldPos - uHeldLight.xyz);
        float heldGlow = uHeldLight.w * pow(clamp(1.0 - heldDist / 11.0, 0.0, 1.0), 1.7);
        float blockVal = max(pow(vLight.y, 1.2) * flicker, heldGlow);
        reflectedLight.directDiffuse *= skyMask;
        float caveMin = max(uDim > 1.5 ? 0.22 : uDim > 0.5 ? 0.42 : 0.055, 0.78 * uNight);
        reflectedLight.indirectDiffuse *= max(skyMask * dayLevel, caveMin);
        totalEmissiveRadiance += diffuseColor.rgb * vec3(1.05, 0.72, 0.36) * blockVal * 1.15;`,
      );
    };
    this.material.customProgramCacheKey = () => (useArray ? 'voxel-atlas-array-v8:' : 'voxel-atlas-2d-v8:') + this.shadowTaps;

    // Dedicated custom depth material for shadow casting so greedy-meshed quads and cutouts sample the exact tile
    this.depthMaterial = new THREE.MeshDepthMaterial({
      depthPacking: THREE.RGBADepthPacking,
      map: this.atlas,
      alphaTest: 0.35,
    });
    this.depthMaterial.onBeforeCompile = (shader) => {
      Object.assign(shader.uniforms, this.uniforms);
      shader.vertexShader =
        'attribute float tile; attribute float wind; varying float vTile; uniform float uTime;\n' +
        shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace(
        '#include <uv_vertex>',
        '#include <uv_vertex>\nvTile = tile;',
      );
      shader.vertexShader = shader.vertexShader.replace(
        '#include <begin_vertex>',
        '#include <begin_vertex>\nif (wind > 0.0) { vec2 windPos = (modelMatrix * vec4(position, 1.0)).xz; transformed.x += sin(windPos.y * 0.8 + uTime * 1.45) * wind * 0.08; transformed.z += cos(windPos.x * 0.75 + uTime * 1.1) * wind * 0.055; }',
      );
      shader.fragmentShader =
        (useArray ? 'uniform mediump sampler2DArray uAtlasArray;\n' : '') +
        'varying float vTile; uniform vec2 uAtlasSize;\n' +
        shader.fragmentShader;
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <map_fragment>',
        `${sampleSnippet}
        diffuseColor *= sampledDiffuseColor;`,
      );
    };
    this.depthMaterial.customProgramCacheKey = () => useArray ? 'voxel-depth-array-v6' : 'voxel-depth-2d-v6';

    renderer.debug.checkShaderErrors = true;
    renderer.debug.onShaderError = (...args: any[]) => {
      this.failed = true;
      const program = args[1];
      const message = program?.diagnostics?.fragmentShader?.log || 'Shader compilation fallback';
      console.warn('[Shader safety fallback]', message);
    };

    // Water: one continuous surface. Colour and transparency follow the per-vertex depth from the mesher (clear over the
    // shallows, deep blue offshore), the sky is reflected with a Fresnel term, ripples are a sum of directional waves in
    // world space (so they line up across chunks) and fade with distance to avoid shimmer.
    this.water = new THREE.ShaderMaterial({
      uniforms: this.waterUniforms,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      vertexShader: `attribute float tile; attribute vec2 aLight; uniform float uTime;
      varying float vFluid; varying vec3 vWorld; varying vec3 vNormal; varying float vDepth; varying float vShore; varying float vTop;
      void main(){
        vec4 world = modelMatrix * vec4(position, 1.0);
        vTop = step(0.5, normal.y);
        world.y += vTop * (sin(world.x * 0.55 + uTime * 1.1) + sin(world.z * 0.63 - uTime * 0.9)) * (tile > 0.5 ? 0.008 : 0.016);
        vWorld = world.xyz;
        vNormal = normalize(mat3(modelMatrix) * normal);
        vFluid = tile;
        vDepth = aLight.y;
        vShore = aLight.x;
        gl_Position = projectionMatrix * viewMatrix * world;
      }`,
      fragmentShader: `uniform float uTime; uniform float uDay; uniform float uUnderwater; uniform float uNear; uniform float uFar;
      uniform vec3 uSun; uniform vec3 uFog; uniform vec3 uSkyTop; uniform vec3 uSkyHorizon;
      varying float vFluid; varying vec3 vWorld; varying vec3 vNormal; varying float vDepth; varying float vShore; varying float vTop;
      float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float vnoise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y); }
      void main(){
        vec3 toCam = cameraPosition - vWorld;
        float dist = length(toCam);
        vec3 view = toCam / dist;
        float fog = smoothstep(uNear, uFar, dist);
        float t = uTime;
        vec2 wp = vWorld.xz;
        if (vFluid > 0.5) {
          vec2 lp = floor(wp * 16.0) / 16.0;  // snap to the 16px block grid so lava keeps a pixel-art look
          float flow = vnoise(lp * 0.55 + vec2(t * 0.05, -t * 0.04)) * 0.65 + vnoise(lp * 1.7 - vec2(t * 0.08, t * 0.06)) * 0.35;
          vec3 col = mix(vec3(0.62, 0.11, 0.01), vec3(1.0, 0.56, 0.07), smoothstep(0.25, 0.75, flow));
          col += vec3(1.0, 0.72, 0.25) * smoothstep(0.72, 0.95, flow) * 0.7;
          gl_FragColor = vec4(mix(col, uFog, fog * 0.6), 1.0);
        } else {
          vec2 g = vec2(0.0);
          g += vec2(0.92, 0.39) * cos(dot(wp, vec2(0.92, 0.39)) * 0.9 + t * 1.2) * 0.050;
          g += vec2(-0.45, 0.89) * cos(dot(wp, vec2(-0.45, 0.89)) * 1.7 - t * 1.6) * 0.036;
          g += vec2(0.31, -0.95) * cos(dot(wp, vec2(0.31, -0.95)) * 3.1 + t * 2.2) * 0.026;
          g += vec2(-0.80, -0.60) * cos(dot(wp, vec2(-0.80, -0.60)) * 5.3 - t * 2.9) * 0.016;
          g /= 1.0 + dist * 0.055 + dist * dist * 0.0008;
          vec3 n = vTop > 0.5 ? normalize(vec3(-g.x, 1.0, -g.y)) : normalize(vNormal);
          bool below = !gl_FrontFacing;
          if (below) n = -n;
          float ndv = max(dot(view, n), 0.0);
          float fres = min(0.8, 0.02 + 0.98 * pow(1.0 - ndv, 5.0));
          vec3 r = reflect(-view, n);
          r.y = abs(r.y);
          vec3 sky = mix(uSkyHorizon, uSkyTop, pow(clamp(r.y, 0.0, 1.0), 0.32));
          float sd = max(dot(r, normalize(uSun)), 0.0);
          float distAtten = clamp(dist / 90.0, 0.0, 1.0);
          float specPow = mix(380.0, 72.0, distAtten);
          float specAmp = mix(2.4, 0.55, distAtten);
          sky += vec3(1.0, 0.93, 0.78) * (pow(sd, specPow) * specAmp + pow(sd, 48.0) * 0.20) * step(0.0, uSun.y) * uDay;
          float lightK = mix(0.16, 1.0, uDay);
          float dk = smoothstep(0.05, 0.9, vDepth);
          vec3 body = mix(vec3(0.07, 0.42, 0.50), vec3(0.012, 0.15, 0.30), dk) * lightK;
          vec3 col = mix(body, sky, fres);
          float alpha = mix(mix(0.6, 0.9, dk), 1.0, fres);
          // Thin, broken foam line only where the surface actually touches land.
          float foam = smoothstep(0.22, 0.5, vShore) * smoothstep(0.3, 0.72, vnoise(wp * 2.6 + vec2(t * 0.22, -t * 0.16))) * 0.45 * vTop;
          col = mix(col, vec3(0.93, 0.97, 1.0) * lightK, foam);
          alpha = max(alpha, foam);
          if (below) { col = mix(vec3(0.03, 0.2, 0.3) * lightK, sky, 0.35); alpha = 0.75; }
          if (uUnderwater > 0.5) fog = min(1.0, fog * 1.6 + 0.15);
          gl_FragColor = vec4(mix(col, uFog, fog), alpha);
        }
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
    });

    this.skyMaterial = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uTop: { value: new THREE.Color('#5eaee0') },
        uHorizon: { value: new THREE.Color('#cce4dc') },
        uSunset: { value: new THREE.Color('#f09d62') },
        uSun: { value: new THREE.Vector3(-0.5, 0.8, 0.3) },
        uDay: { value: 1 },
        uTwilight: { value: 0 },
      },
      vertexShader: 'varying vec3 vDirection; void main(){ vDirection = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: `varying vec3 vDirection; uniform vec3 uTop; uniform vec3 uHorizon; uniform vec3 uSunset; uniform vec3 uSun; uniform float uDay; uniform float uTwilight;
      void main(){
        vec3 d = normalize(vDirection);
        float h = pow(max(d.y, 0.0), 0.5);
        vec3 baseHorizon = mix(uHorizon, uSunset, uTwilight * 0.72);
        vec3 col = mix(baseHorizon, uTop, h);
        float s = max(dot(d, normalize(uSun)), 0.0);
        col += mix(vec3(1.0, 0.78, 0.44), vec3(1.0, 0.46, 0.22), uTwilight) * pow(s, 32.0) * (0.24 + uTwilight * 0.38);
        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
    });

    this.sky = new THREE.Mesh(new THREE.SphereGeometry(380, 20, 14), this.skyMaterial);
    this.sky.renderOrder = -100;
    scene.add(this.sky);

    this.sun = new THREE.DirectionalLight('#fff1d4', 2.2);
    this.sun.castShadow = true;
    const shadowRes = settings.quality === 'low' ? 1024 : 2048;
    this.sun.shadow.mapSize.set(shadowRes, shadowRes);
    Object.assign(this.sun.shadow.camera, { left: -54, right: 54, top: 54, bottom: -54, near: 1, far: 190 });
    this.sun.shadow.bias = -0.0005;
    this.sun.shadow.normalBias = 0.08;
    this.sun.shadow.radius = 1.0;
    scene.add(this.sun, this.sun.target);

    this.hemi = new THREE.HemisphereLight('#d7ebff', '#7b7c4e', 1.45);
    scene.add(this.hemi);

    const sunCanvas = canvas(16);
    const sctx = sunCanvas.getContext('2d') as CanvasRenderingContext2D;
    sctx.fillStyle = '#fff5ce';
    sctx.fillRect(0, 0, 16, 16);
    sctx.fillStyle = '#ffffff';
    sctx.fillRect(3, 3, 10, 10);
    const sunTex = new THREE.CanvasTexture(sunCanvas as HTMLCanvasElement);
    sunTex.magFilter = THREE.NearestFilter;
    sunTex.colorSpace = THREE.SRGBColorSpace;

    // Pre-generate 8 moon phase textures
    for (let phase = 0; phase < 8; phase++) {
      const mc = canvas(16);
      const mctx = mc.getContext('2d') as CanvasRenderingContext2D;
      mctx.fillStyle = '#182235';
      mctx.fillRect(0, 0, 16, 16);
      mctx.fillStyle = '#e2eae6';
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const lit =
            phase === 0 ? true :
            phase === 1 ? x < 12 :
            phase === 2 ? x < 8 :
            phase === 3 ? x < 4 :
            phase === 4 ? false :
            phase === 5 ? x >= 12 :
            phase === 6 ? x >= 8 :
            x >= 4;
          if (lit) mctx.fillRect(x, y, 1, 1);
        }
      }
      mctx.fillStyle = 'rgba(130, 148, 152, 0.55)';
      mctx.fillRect(3, 3, 4, 4);
      mctx.fillRect(10, 8, 3, 5);
      mctx.fillRect(4, 12, 3, 2);
      const mt = new THREE.CanvasTexture(mc as HTMLCanvasElement);
      mt.magFilter = THREE.NearestFilter;
      mt.colorSpace = THREE.SRGBColorSpace;
      this.moonTexs.push(mt);
    }

    this.sunSprite = new THREE.Mesh(
      new THREE.PlaneGeometry(14, 14),
      new THREE.MeshBasicMaterial({ map: sunTex, fog: false, toneMapped: false }),
    );
    this.moonMat = new THREE.MeshBasicMaterial({ map: this.moonTexs[0], fog: false, toneMapped: false });
    this.moon = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), this.moonMat);
    scene.add(this.sunSprite, this.moon);

    const glowCanvas = canvas(64);
    const gc = glowCanvas.getContext('2d') as CanvasRenderingContext2D;
    const gradient = gc.createRadialGradient(32, 32, 0, 32, 32, 32);
    gradient.addColorStop(0, 'rgba(255,238,171,.62)');
    gradient.addColorStop(0.22, 'rgba(255,226,153,.22)');
    gradient.addColorStop(1, 'rgba(255,220,130,0)');
    gc.fillStyle = gradient;
    gc.fillRect(0, 0, 64, 64);
    this.glow = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: new THREE.CanvasTexture(glowCanvas as HTMLCanvasElement),
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        fog: false,
      }),
    );
    this.glow.scale.set(78, 78, 1);
    scene.add(this.glow);

    const rnd = random(9841);
    const starPositions: number[] = [];
    for (let i = 0; i < 750; i++) {
      const a = rnd() * Math.PI * 2;
      const y = rnd() * 2 - 1;
      const r = Math.sqrt(1 - y * y);
      starPositions.push(Math.cos(a) * r * 300, y * 300, Math.sin(a) * r * 300);
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.Float32BufferAttribute(starPositions, 3));
    this.stars = new THREE.Points(
      sg,
      new THREE.PointsMaterial({
        color: '#e5f1ff',
        size: 1.35,
        sizeAttenuation: false,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        fog: false,
      }),
    );
    scene.add(this.stars);

    this.cloudMat = new THREE.MeshLambertMaterial({ color: '#fffef5', transparent: true, opacity: 0.9 });
    this.clouds = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), this.cloudMat, 70);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < 70; i++) {
      const group = Math.floor(i / 5);
      dummy.position.set(
        (group % 5) * 62 - 140 + rand(rnd, 16),
        192 + Math.floor(group / 5) * 3.5 + rand(rnd, 1.5),
        Math.floor(group / 5) * 76 - 150 + rand(rnd, 14),
      );
      dummy.scale.set(10 + rnd() * 14, 1.8 + rnd() * 2, 8 + rnd() * 11);
      dummy.updateMatrix();
      this.clouds.setMatrixAt(i, dummy.matrix);
    }
    this.clouds.instanceMatrix.needsUpdate = true;
    scene.add(this.clouds);

    this.rays = new THREE.Group();
    const rayMat = new THREE.MeshBasicMaterial({
      color: '#fff0c5',
      transparent: true,
      opacity: 0.008,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
    });
    for (let i = 0; i < 3; i++) {
      const ray = new THREE.Mesh(new THREE.PlaneGeometry(2.5 + i * 0.7, 90), rayMat);
      ray.position.set(-16 + i * 16, 40, -30 - i * 8);
      ray.rotation.z = -0.45;
      this.rays.add(ray);
    }
    scene.add(this.rays);

    const rainGeo = new THREE.BufferGeometry();
    const drops: number[] = [];
    const speeds: number[] = [];
    for (let i = 0; i < 1000; i++) {
      drops.push((Math.random() - 0.5) * 40, Math.random() * 48, (Math.random() - 0.5) * 40);
      speeds.push(20 + Math.random() * 8);
    }
    rainGeo.setAttribute('position', new THREE.Float32BufferAttribute(drops, 3));
    rainGeo.setAttribute('aSpeed', new THREE.Float32BufferAttribute(speeds, 1));
    rainGeo.setAttribute('aSurface', new THREE.Float32BufferAttribute(new Float32Array(1000).fill(-1000), 1));
    rainGeo.setAttribute('aClimate', new THREE.Float32BufferAttribute(new Float32Array(1000).fill(1), 1));
    this.rainMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uOpacity: { value: 0 }, uColor: { value: new THREE.Color('#bcd7ee') }, uSnow: { value: 0 }, uSampled: { value: 0 } },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute float aSpeed; attribute float aSurface; attribute float aClimate;
      uniform float uTime; uniform float uSnow; uniform float uSampled; varying float vSnow; varying float vVisible; varying float vDistance;
      void main(){
        vSnow = mix(uSnow, step(1.5, aClimate), uSampled);
        vec3 p = position;
        float speed = mix(aSpeed, 1.1 + aSpeed * 0.025, vSnow);
        p.y = mod(p.y - uTime * speed, 48.0);
        p.x += vSnow * sin(uTime * 0.7 + position.z * 0.8) * 0.65;
        p.z += vSnow * cos(uTime * 0.5 + position.x) * 0.45;
        vec4 world = modelMatrix * vec4(p, 1.0);
        vVisible = mix(1.0, step(0.5, aClimate) * step(aSurface + 0.05, world.y), uSampled);
        vec4 mv = viewMatrix * world;
        vDistance = length(mv.xyz);
        gl_PointSize = mix(clamp(260.0 / max(1.0, -mv.z), 4.0, 22.0), clamp(55.0 / max(1.0, -mv.z), 1.5, 5.5), vSnow);
        gl_Position = projectionMatrix * mv;
      }`,
      fragmentShader: `uniform float uOpacity; uniform vec3 uColor; varying float vSnow; varying float vVisible; varying float vDistance;
      void main(){
        if(vVisible < 0.5) discard;
        vec2 p = gl_PointCoord - 0.5;
        if(vSnow < 0.5 && abs(p.x) > 0.065) discard;
        if(vSnow > 0.5 && abs(p.x) > 0.23 && abs(p.y) > 0.23) discard;
        float fade = 1.0 - smoothstep(16.0, 28.0, vDistance);
        gl_FragColor = vec4(mix(uColor, vec3(0.93, 0.96, 1.0), vSnow), uOpacity * fade);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
    });
    this.rain = new THREE.Points(rainGeo, this.rainMat);
    this.rain.frustumCulled = false;
    scene.add(this.rain);

    const ambGeo = new THREE.BufferGeometry();
    const ambPos: number[] = [];
    const ambPhase: number[] = [];
    for (let i = 0; i < 512; i++) {
      ambPos.push((Math.random() - 0.5) * 56, Math.random() * 18, (Math.random() - 0.5) * 56);
      ambPhase.push(Math.random() * 6.283);
    }
    ambGeo.setAttribute('position', new THREE.Float32BufferAttribute(ambPos, 3));
    ambGeo.setAttribute('aPhase', new THREE.Float32BufferAttribute(ambPhase, 1));
    this.ambientMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uColor: { value: new THREE.Color('#f6b8cc') }, uOpacity: { value: 0.7 }, uFall: { value: 0.6 }, uDrift: { value: 1.4 }, uSize: { value: 0.1 } },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute float aPhase; uniform float uTime; uniform float uFall; uniform float uDrift; uniform float uSize; varying float vGlow; varying float vFade;
      void main(){ vec3 p = position; p.y = mod(p.y - uTime * uFall + sin(uTime * 0.35 + aPhase) * 0.18, 18.0); p.x += sin(uTime * 0.45 + aPhase) * uDrift; p.z += cos(uTime * 0.4 + aPhase * 1.3) * uDrift; vGlow = 0.83 + 0.17 * sin(uTime * 0.6 + aPhase * 2.0); vec4 mv = modelViewMatrix * vec4(p, 1.0); vFade = 1.0 - smoothstep(18.0, 32.0, length(mv.xyz)); gl_PointSize = clamp(uSize * 500.0 / max(1.0, -mv.z), 1.0, 5.0); gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform float uOpacity; uniform vec3 uColor; varying float vGlow; varying float vFade; void main(){ gl_FragColor = vec4(uColor * vGlow, uOpacity * vFade);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      }`,
    });
    this.ambientParticles = new THREE.Points(ambGeo, this.ambientMat);
    this.ambientParticles.frustumCulled = false;
    scene.add(this.ambientParticles);

    this.atmosphere = new AtmosphereFx(scene);

    scene.fog = new THREE.Fog('#cce4dc', 52, 120);
  }

  /**
   * Dynamic FOV: sprinting x1.15, Speed I/II x1.1/x1.2, Slowness x0.925, creative flight x1.1 and a drawn bow down to x0.85,
   * eased like GameRenderer.tickFov; x60/70 while the camera is submerged.
   */
  attachWorld(world: AtmosphereWorld) {
    this.world = world;
    this.weatherCursor = 0;
    this.rainMat.uniforms.uSampled.value = 1;
    (this.rain.geometry.getAttribute('aClimate').array as Float32Array).fill(0);
  }

  updateFov(camera: THREE.PerspectiveCamera, a: number, b: number | FovState, c?: FovState | VisualFovState | number): number {
    if (typeof b === 'number') {
      const dt = a, base = b, state = (c ?? {}) as VisualFovState;
      if (!Number.isFinite(dt) || dt <= 0) return camera.fov;
      const target = dynamicFov(base, state);
      camera.fov += (target - camera.fov) * (1 - Math.exp(-10 * Math.min(dt, 0.25)));
      if (Math.abs(camera.fov - target) < 0.005) camera.fov = target;
      camera.updateProjectionMatrix();
      return camera.fov;
    }
    const baseFov = a, state = b as FovState, dt = typeof c === 'number' ? c : 0.05;
    this.fovScale = stepFovModifier(this.fovScale ?? 1, fovModifier(state), dt);
    const fov = fovDegrees(baseFov, this.fovScale, state);
    if (Math.abs(camera.fov - fov) > 0.01) {
      camera.fov = fov;
      camera.updateProjectionMatrix();
    }
    return fov;
  }

  private sampleWeather(dimension: Dimension) {
    if (!this.world || !this.rain.visible) return;
    const geo = this.rain.geometry;
    const positions = geo.getAttribute('position');
    const surfaces = geo.getAttribute('aSurface');
    const climates = geo.getAttribute('aClimate');
    for (let i = 0; i < 48; i++) {
      const index = this.weatherCursor++ % positions.count;
      const x = Math.floor(positions.getX(index) + this.rain.position.x);
      const z = Math.floor(positions.getZ(index) + this.rain.position.z);
      const surface = this.world.surfaceAt(x, z);
      surfaces.setX(index, surface?.y ?? 10000);
      const climate = surface ? precipitationAt(this.world.biomeAt(x, z), surface.y, dimension) : 'none';
      climates.setX(index, climate === 'snow' ? 2 : climate === 'rain' ? 1 : 0);
    }
    surfaces.needsUpdate = climates.needsUpdate = true;
  }

  rainSplashes(dt: number, camera: THREE.Camera, particles: ParticleSystem, dimension: Dimension) {
    if (!this.world || dimension !== 'overworld' || this.weather === 'clear') { this.splashTime = 0; return; }
    this.splashTime += dt;
    if (this.splashTime < 0.07) return;
    this.splashTime %= 0.07;
    for (let i = 0; i < (this.weather === 'storm' ? 6 : 4); i++) {
      const x = Math.floor(camera.position.x + (Math.random() - 0.5) * 18);
      const z = Math.floor(camera.position.z + (Math.random() - 0.5) * 18);
      const surface = this.world.surfaceAt(x, z);
      if (!surface?.solid || Math.abs(surface.y - camera.position.y) > 18 || precipitationAt(this.world.biomeAt(x, z), surface.y, dimension) !== 'rain') continue;
      particles.rainSplash(this.splashOrigin.set(x + Math.random(), surface.y + 0.03, z + Math.random()), 1);
    }
  }

  markShadow() {
    this.renderer.shadowMap.needsUpdate = true;
  }

  triggerLightning() {
    this.lightning = 1.0;
  }

  update(
    elapsed: number,
    time: number,
    camera: THREE.Camera,
    dimension: Dimension,
    settings: Settings,
    weather: 'clear' | 'rain' | 'storm' = 'clear',
    biome = 'plains',
    moonPhase = 0,
    heldLightIntensity = 0,
    underwater = false,
    nightVision = 0,
    precipBiome: string = biome,
  ) {
    this.uniforms.uNight.value = nightVision;
    this.weather = weather;
    this.lightning = Math.max(0, this.lightning - 0.08);
    this.uniforms.uTime.value = elapsed;
    this.waterUniforms.uTime.value = elapsed;
    this.rainMat.uniforms.uTime.value = elapsed;
    this.ambientMat.uniforms.uTime.value = elapsed;
    this.uniforms.uDim.value = dimension === 'nether' ? 1 : dimension === 'end' ? 2 : 0;
    this.uniforms.uRain.value = dimension === 'overworld' && weather !== 'clear' ? (weather === 'storm' ? 1 : 0.7) : 0;
    this.uniforms.uHeldLight.value.set(camera.position.x, camera.position.y, camera.position.z, heldLightIntensity);

    if (this.failed) this.material.visible = false;

    const angle = time * Math.PI * 2;
    const sinA = Math.sin(angle);
    const day = Math.max(0, sinA);
    const rainDim = weather === 'storm' ? 0.55 : weather === 'rain' ? 0.78 : 1.0;
    const effDay = Math.min(1, day * rainDim + this.lightning * 0.85);
    const twilight = dimension === 'overworld' ? Math.max(0, 1 - Math.abs(sinA) * 3.2) : 0;
    this._sunDir.set(-0.6, sinA, Math.cos(angle) * 0.55).normalize();
    this.daylight = day;
    this.uniforms.uDay.value = effDay;
    this.waterUniforms.uDay.value = effDay;

    if (moonPhase !== this.lastMoonPhase) {
      this.lastMoonPhase = moonPhase;
      this.moonMat.map = this.moonTexs[((moonPhase % 8) + 8) % 8];
      this.moonMat.needsUpdate = true;
    }

    const p = camera.position;
    this.sky.position.copy(p);
    this.stars.position.copy(p);
    (this.stars.material as THREE.PointsMaterial).opacity =
      dimension === 'end' ? 0.55 : dimension === 'overworld' ? Math.pow(1 - day, 3) * (weather === 'clear' ? 0.92 : 0.15) : 0;

    const shadowTexel = 108 / this.sun.shadow.mapSize.x;
    this._lightRight.crossVectors(this._worldUp, this._sunDir);
    if (this._lightRight.lengthSq() < 1e-6) this._lightRight.set(1, 0, 0);
    this._lightRight.normalize();
    this._lightUp.crossVectors(this._sunDir, this._lightRight).normalize();
    this._target.set(p.x, Math.round(p.y / 8) * 8, p.z);
    const snapA = Math.round(this._target.dot(this._lightRight) / shadowTexel) * shadowTexel;
    const snapB = Math.round(this._target.dot(this._lightUp) / shadowTexel) * shadowTexel;
    const snapC = this._target.dot(this._sunDir);
    this._target.set(0, 0, 0).addScaledVector(this._lightRight, snapA).addScaledVector(this._lightUp, snapB).addScaledVector(this._sunDir, snapC);
    if (this.sun.target.position.distanceToSquared(this._target) > 1e-4) {
      this.sun.target.position.copy(this._target);
      this.sun.target.updateMatrixWorld();
      this.sun.position.copy(this._target).addScaledVector(this._sunDir, 100);
      this.sun.updateMatrixWorld();
    }
    this.sun.intensity = dimension === 'overworld' ? (0.12 + effDay * 2.05) : dimension === 'nether' ? 0.45 : 0.65;
    this.sun.color.copy(this._cSunDay).lerp(this._cSunTwil, twilight * 0.75);
    this.hemi.intensity = dimension === 'overworld' ? (0.35 + effDay * 1.2) : dimension === 'nether' ? 0.95 : 0.85;

    this.sunSprite.position.copy(p).addScaledVector(this._sunDir, 260);
    this.sunSprite.lookAt(p);
    this.moon.position.copy(p).addScaledVector(this._sunDir, -260);
    this.moon.lookAt(p);
    this.glow.position.copy(this.sunSprite.position);
    this.sunSprite.visible = dimension === 'overworld' && day > 0.02;
    this.glow.visible = dimension === 'overworld' && day > 0.02 && weather === 'clear';
    this.moon.visible = dimension === 'overworld' && day < 0.25;

    if (dimension === 'nether') {
      if (biome === 'warped_forest') {
        this._top.set('#11292e');
        this._horizon.set('#23646e');
      } else if (biome === 'soul_sand_valley') {
        this._top.set('#14282e');
        this._horizon.set('#255866');
      } else if (biome === 'basalt_deltas') {
        this._top.set('#2b292e');
        this._horizon.set('#59555e');
      } else if (biome === 'crimson_forest') {
        this._top.set('#471111');
        this._horizon.set('#8f2020');
      } else {
        this._top.copy(this._cNetherTop);
        this._horizon.copy(this._cNetherHor);
      }
    } else if (dimension === 'end') {
      this._top.copy(this._cEndTop);
      this._horizon.copy(this._cEndHor);
    } else {
      this._top.copy(this._cNightTop).lerp(this._cDayTop, effDay);
      this._horizon.copy(this._cNightHor).lerp(this._cDayHor, effDay);
      if (twilight > 0.01 && weather === 'clear') this._horizon.lerp(this._cSunset, twilight * 0.55);
      if (this.lightning > 0.05) {
        this._top.lerp(this._cCloudDay, this.lightning * 0.5);
        this._horizon.lerp(this._cCloudDay, this.lightning * 0.6);
      }
    }

    this.skyMaterial.uniforms.uTop.value.copy(this._top);
    this.skyMaterial.uniforms.uHorizon.value.copy(this._horizon);
    this.skyMaterial.uniforms.uSun.value.copy(this._sunDir);
    this.skyMaterial.uniforms.uDay.value = effDay;
    this.skyMaterial.uniforms.uTwilight.value = twilight;

    const fog = this.scene.fog as THREE.Fog;
    if (underwater) {
      fog.color.set('#145a6e').lerp(NV_WATER, nightVision);        // Night Vision: brighter water and a much longer underwater view
      const uf = underwaterFog(nightVision);
      fog.near = uf.near;
      fog.far = uf.far;
    } else {
      fog.color.copy(this._horizon);
      fog.near = settings.distance * 16 * 0.56;
      fog.far = settings.distance * 16 * 1.35;
    }
    this.waterUniforms.uFog.value.copy(fog.color);
    this.waterUniforms.uSun.value.copy(this._sunDir);
    this.waterUniforms.uNear.value = fog.near;
    this.waterUniforms.uFar.value = fog.far;
    this.waterUniforms.uSkyTop.value.copy(this._top);
    this.waterUniforms.uSkyHorizon.value.copy(this._horizon);
    this.waterUniforms.uUnderwater.value = underwater ? 1 : 0;

    this.clouds.position.x = Math.sin(elapsed * 0.006) * 20;
    this.clouds.visible = dimension === 'overworld';
    this.cloudMat.color.copy(this._cCloudNight).lerp(this._cCloudDay, day);
    if (twilight > 0.05) this.cloudMat.color.lerp(this._cCloudTwil, twilight * 0.65);
    if (weather !== 'clear') this.cloudMat.color.lerp(this._cCloudStorm, 0.55);

    this.rays.visible = settings.bloom && dimension === 'overworld' && day > 0.2 && weather === 'clear' && !underwater;
    // Precipitation: rain in temperate biomes, snow where the temperature is below 0.15, nothing in dry biomes.
    const dtEnv = Math.min(0.1, Math.max(0, elapsed - this.lastElapsed));
    this.lastElapsed = elapsed;
    const pcam = camera as THREE.PerspectiveCamera;
    const domH = this.renderer.domElement?.height || 720;
    const pxScale = domH / (2 * Math.tan(((pcam.fov || 70) * Math.PI) / 360));
    this.atmosphere.update({ dt: dtEnv, elapsed, camera: p, scale: pxScale, dimension, biome, precipBiome, weather });
    this.precipitation = this.atmosphere.precipitation;
    const rainMix = this.atmosphere.mix.rain;
    this.rain.visible = dimension === 'overworld' && weather !== 'clear' && (this.precipitation !== 'none' || !!this.world || rainMix > 0.01) && !underwater;
    this.rainMat.uniforms.uOpacity.value = this.precipitation === 'snow' ? 0.8 : (weather === 'storm' ? 0.65 : 0.44) * (this.world ? 1 : Math.max(0.2, rainMix));
    this.rainMat.uniforms.uSnow.value = this.precipitation === 'snow' ? 1 : 0;
    const rx = Math.round(p.x / 16) * 16, rz = Math.round(p.z / 16) * 16;
    if (this.world && (this.rain.position.x !== rx || this.rain.position.z !== rz)) {
      const climates = this.rain.geometry.getAttribute('aClimate');
      (climates.array as Float32Array).fill(0); climates.needsUpdate = true;
    }
    // The rain volume is 48 blocks tall; keep it centred on the camera height (it used to sit at Y 16‥64, below the surface).
    this.rain.position.set(rx, Math.round(p.y / 16) * 16 - 24, rz);
    this.rain.geometry.setDrawRange(0, settings.quality === 'low' ? 500 : 1000);
    this.sampleWeather(dimension);

    this.ambientParticles.position.set(p.x, Math.max(18, p.y - 4), p.z);
    this.ambientParticles.geometry.setDrawRange(0, 180);
    this.ambientMat.uniforms.uDrift.value = 1.4;
    this.ambientMat.uniforms.uSize.value = 0.1;
    if (dimension === 'nether') {
      // Java Edition: ash / white ash / spores per biome (AtmosphereFx); the nether wastes have no ambient particle.
      this.ambientParticles.visible = false;
      const atmosphere = NETHER_ATMOSPHERES[biome];
      if (atmosphere) {
        this.ambientParticles.visible = true;
        this.ambientMat.uniforms.uColor.value.set(atmosphere.color);
        this.ambientMat.uniforms.uOpacity.value = atmosphere.opacity;
        this.ambientMat.uniforms.uFall.value = atmosphere.fall;
        this.ambientMat.uniforms.uDrift.value = atmosphere.drift;
        this.ambientMat.uniforms.uSize.value = atmosphere.size;
        this.ambientParticles.geometry.setDrawRange(0, Math.round(atmosphere.density * (settings.quality === 'low' ? 0.55 : 1)));
      }
    } else if (dimension === 'end') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#b87cff');
      this.ambientMat.uniforms.uOpacity.value = 0.55;
      this.ambientMat.uniforms.uFall.value = -0.2;
    } else if (biome === 'cherry_grove') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#f8bfd2');
      this.ambientMat.uniforms.uOpacity.value = 0.85;
      this.ambientMat.uniforms.uFall.value = 0.85;
    } else if (biome === 'desert' || biome === 'badlands') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#dfc68a');
      this.ambientMat.uniforms.uOpacity.value = 0.35;
      this.ambientMat.uniforms.uFall.value = 0.15;
    } else if (day < 0.35 && (biome === 'swamp' || biome === 'forest' || biome === 'flower_forest' || biome === 'plains')) {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#d8f56c');
      this.ambientMat.uniforms.uOpacity.value = 0.85;
      this.ambientMat.uniforms.uFall.value = 0.05;
    } else if (biome === 'forest' || biome === 'flower_forest' || biome === 'jungle') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#e9f2c4');
      this.ambientMat.uniforms.uOpacity.value = 0.38;
      this.ambientMat.uniforms.uFall.value = 0.18;
    } else {
      this.ambientParticles.visible = false;
    }
  }

  dispose() {
    this.atmosphere.dispose();
    this.atlas.dispose();
    this.atlasArray.dispose();
    this.material.dispose();
    this.depthMaterial.dispose();
    this.fallback.dispose();
    this.water.dispose();
    this.skyMaterial.dispose();
    this.rainMat.dispose();
    this.ambientMat.dispose();
    for (const mt of this.moonTexs) mt.dispose();
    for (const obj of [this.sky, this.sunSprite, this.moon, this.stars, this.clouds, this.rain, this.ambientParticles] as Array<
      THREE.Object3D & { geometry: THREE.BufferGeometry; material: THREE.Material & { map?: THREE.Texture } }
    >) {
      obj.geometry.dispose();
      obj.material.map?.dispose();
      obj.material.dispose();
    }
    this.glow.material.map?.dispose();
    this.glow.material.dispose();
    this.sun.shadow.map?.dispose();
  }
}

function rand(r: () => number, n: number) {
  return (r() - 0.5) * n;
}

/**
 * three.js r18x `shadowmap_pars_fragment` with the PCF kernel of the directional `getShadow( sampler2DShadow … )` replaced.
 * Only the first (directional / spot) PCF kernel is touched; if a future three.js changes the chunk text the regex simply
 * does not match and the stock chunk is used unchanged.
 */
const PCF_KERNEL = /float phi = interleavedGradientNoise\( gl_FragCoord\.xy \) \* PI2;(\s*)shadow = \(([\s\S]*?)\) \* 0\.2;/;
function voxelShadowPars(taps: 1 | 5): string {
  const chunk = THREE.ShaderChunk.shadowmap_pars_fragment;
  const at = chunk.indexOf('getShadow( sampler2DShadow');
  if (at < 0) return chunk;
  const head = chunk.slice(0, at), tail = chunk.slice(at);
  const kernel = taps === 1
    ? (_m: string, ws: string) => `float phi = 0.0;${ws}shadow = texture( shadowMap, vec3( shadowCoord.xy, shadowCoord.z ) );`
    : (_m: string, ws: string, body: string) => `float phi = 0.0;${ws}shadow = (${body}) * 0.2;`;
  return head + tail.replace(PCF_KERNEL, kernel as (substring: string, ...args: string[]) => string);
}
