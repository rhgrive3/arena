import type { BlockDef } from '../game/data';
import type { Context2D } from './canvas';

const rgb = (hex: string): [number, number, number] => [
  Number.parseInt(hex.slice(1, 3), 16) || 0,
  Number.parseInt(hex.slice(3, 5), 16) || 0,
  Number.parseInt(hex.slice(5, 7), 16) || 0,
];

function shadeHex(hex: string, n: number): string {
  const [r, g, b] = rgb(hex.startsWith('#') ? hex : '#888888');
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v + n))).toString(16).padStart(2, '0');
  return `#${clamp(r)}${clamp(g)}${clamp(b)}`;
}

function drawGrid(ctx: Context2D, rows: string[], pal: Record<string, string>) {
  for (let y = 0; y < rows.length && y < 16; y++) {
    const row = rows[y];
    for (let x = 0; x < row.length && x < 16; x++) {
      const ch = row[x];
      if (ch === '.' || ch === ' ') continue;
      const col = pal[ch];
      if (!col) continue;
      ctx.fillStyle = col;
      ctx.fillRect(x, y, 1, 1);
    }
  }
}

export function addOutline(ctx: Context2D, outlineCol: string) {
  const img = ctx.getImageData(0, 0, 16, 16);
  const d = img.data;
  const mask = new Uint8Array(256);
  for (let i = 0; i < 256; i++) mask[i] = d[i * 4 + 3] > 20 ? 1 : 0;
  ctx.fillStyle = outlineCol;
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      if (mask[y * 16 + x]) continue;
      const n =
        (x > 0 && mask[y * 16 + x - 1]) ||
        (x < 15 && mask[y * 16 + x + 1]) ||
        (y > 0 && mask[(y - 1) * 16 + x]) ||
        (y < 15 && mask[(y + 1) * 16 + x]);
      if (n) ctx.fillRect(x, y, 1, 1);
    }
  }
}

// =====================================================================================================================
// 1. LOGS (All 12 Wood Species — Side Bark & Top Concentric Rings with Bark Rim)
// =====================================================================================================================

interface LogSpec {
  barkDark: string;
  barkMid: string;
  barkLight: string;
  barkAccent: string;
  sapwood: string;
  ring1: string;
  ring2: string;
  core: string;
  style: 'vertical' | 'birch' | 'cherry' | 'jungle' | 'acacia' | 'fungus' | 'poplar';
}

const LOG_SPECS: Record<string, LogSpec> = {
  oak: {
    barkDark: '#423019', barkMid: '#6b5130', barkLight: '#85673f', barkAccent: '#543e22',
    sapwood: '#d4b379', ring1: '#b8945f', ring2: '#9c7a48', core: '#785a32', style: 'vertical',
  },
  spruce: {
    barkDark: '#221509', barkMid: '#3b2714', barkLight: '#52381e', barkAccent: '#2e1d0e',
    sapwood: '#ba905e', ring1: '#9c7244', ring2: '#825c34', core: '#634424', style: 'vertical',
  },
  birch: {
    barkDark: '#2b2a26', barkMid: '#e3e0d5', barkLight: '#f2efe6', barkAccent: '#b8b4a6',
    sapwood: '#e2d3a8', ring1: '#cdb888', ring2: '#b59f6e', core: '#947e50', style: 'birch',
  },
  jungle: {
    barkDark: '#382a17', barkMid: '#574429', barkLight: '#735a38', barkAccent: '#4f692c',
    sapwood: '#cfa07a', ring1: '#b5845e', ring2: '#996a47', core: '#785032', style: 'jungle',
  },
  acacia: {
    barkDark: '#423e37', barkMid: '#676157', barkLight: '#827b6f', barkAccent: '#544f46',
    sapwood: '#d69469', ring1: '#ba6337', ring2: '#9c4e27', core: '#7d3b1b', style: 'acacia',
  },
  dark_oak: {
    barkDark: '#1f170e', barkMid: '#3c2e1d', barkLight: '#523f29', barkAccent: '#2b2014',
    sapwood: '#735636', ring1: '#573e24', ring2: '#422e19', core: '#2e1f10', style: 'vertical',
  },
  cherry: {
    barkDark: '#211118', barkMid: '#3b222c', barkLight: '#543340', barkAccent: '#8c6270',
    sapwood: '#f7d4da', ring1: '#e6aab4', ring2: '#cf8c98', core: '#b06c78', style: 'cherry',
  },
  mangrove: {
    barkDark: '#2e231d', barkMid: '#544339', barkLight: '#6e584b', barkAccent: '#6b362e',
    sapwood: '#b08368', ring1: '#8c3930', ring2: '#702922', core: '#541b16', style: 'vertical',
  },
  pale_oak: {
    barkDark: '#474440', barkMid: '#78736d', barkLight: '#969088', barkAccent: '#5e5a55',
    sapwood: '#f0ece3', ring1: '#dbd6cc', ring2: '#c4bfb5', core: '#a6a198', style: 'vertical',
  },
  crimson: {
    barkDark: '#2e0b16', barkMid: '#4f1628', barkLight: '#702038', barkAccent: '#cf365a',
    sapwood: '#c43658', ring1: '#942442', ring2: '#731931', core: '#4f1021', style: 'fungus',
  },
  warped: {
    barkDark: '#1f1326', barkMid: '#3a2542', barkLight: '#52355c', barkAccent: '#2ebdb2',
    sapwood: '#3cc7bc', ring1: '#28968e', ring2: '#1b6e68', core: '#124f4b', style: 'fungus',
  },
  poplar: {
    barkDark: '#4a4838', barkMid: '#c4be9b', barkLight: '#d9d3b2', barkAccent: '#7d7a60',
    sapwood: '#ebe5c5', ring1: '#d4cca6', ring2: '#bab28c', core: '#99916d', style: 'poplar',
  },
};

export function drawLogTile(name: string, ctx: Context2D, rnd: () => number): boolean {
  const isTop = name.endsWith('_log_top');
  const species = name.replace(/_log(_top)?$/, '');
  const spec = LOG_SPECS[species];
  if (!spec) return false;

  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (isTop) {
    // 1. 1px outer bark rim matching the side bark texture
    r(0, 0, 16, 16, spec.barkMid);
    for (let i = 0; i < 16; i += 2) {
      r(i, 0, 1, 1, spec.barkDark);
      r(15, i, 1, 1, spec.barkDark);
      r(15 - i, 15, 1, 1, spec.barkDark);
      r(0, 15 - i, 1, 1, spec.barkDark);
    }
    if (spec.style === 'birch') {
      for (const k of [3, 7, 12]) { r(k, 0, 2, 1, spec.barkDark); r(15, k, 1, 2, spec.barkDark); r(k, 15, 2, 1, spec.barkDark); r(0, k, 1, 2, spec.barkDark); }
    }
    // Beveled dark corners on outer bark rim
    r(0, 0, 1, 1, spec.barkDark); r(15, 0, 1, 1, spec.barkDark);
    r(0, 15, 1, 1, spec.barkDark); r(15, 15, 1, 1, spec.barkDark);

    // 2. Concentric sapwood & heartwood growth rings (1..14)
    r(1, 1, 14, 14, spec.sapwood);
    r(2, 2, 12, 12, spec.ring1);
    r(3, 3, 10, 10, spec.ring2);
    r(4, 4, 8, 8, spec.ring1);
    r(5, 5, 6, 6, spec.ring2);
    r(6, 6, 4, 4, spec.ring1);
    r(7, 7, 2, 2, spec.core);

    // Organic radial/corner ring softening so rings read as natural wood rather than flat nested squares
    const corners: [number, number, string][] = [
      [1, 1, spec.ring1], [14, 1, spec.ring1], [1, 14, spec.ring1], [14, 14, spec.ring1],
      [2, 2, spec.ring2], [13, 2, spec.ring2], [2, 13, spec.ring2], [13, 13, spec.ring2],
      [3, 3, spec.ring1], [12, 3, spec.ring1], [3, 12, spec.ring1], [12, 12, spec.ring1],
      [4, 4, spec.ring2], [11, 4, spec.ring2], [4, 11, spec.ring2], [11, 11, spec.ring2],
      [5, 5, spec.ring1], [10, 5, spec.ring1], [5, 10, spec.ring1], [10, 10, spec.ring1],
    ];
    for (const [cx, cy, ccol] of corners) r(cx, cy, 1, 1, ccol);
    // Subtle grain highlights along sapwood & heartwood
    r(2, 1, 4, 1, shadeHex(spec.sapwood, 14));
    r(1, 3, 1, 4, shadeHex(spec.sapwood, 14));
    r(6, 4, 3, 1, shadeHex(spec.ring1, 12));
    r(4, 7, 1, 3, shadeHex(spec.ring1, 12));
    r(8, 7, 1, 1, shadeHex(spec.core, -16));
    return true;
  }

  // Side Bark (`<species>_log`)
  if (spec.style === 'birch' || spec.style === 'poplar') {
    r(0, 0, 16, 16, spec.barkMid);
    // Subtle papery horizontal shading bands
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const n = (x * 7 + y * 13) % 11;
        if (n === 0) r(x, y, 1, 1, spec.barkLight);
        else if (n === 1 || n === 2) r(x, y, 1, 1, spec.barkAccent);
      }
    }
    // Authentic horizontal birch lenticel scars & dark knots
    const marks: [number, number, number][] = [
      [1, 2, 4], [10, 1, 3], [5, 5, 5], [13, 6, 3],
      [0, 9, 3], [7, 8, 4], [3, 12, 5], [11, 13, 4], [6, 15, 3],
    ];
    for (const [mx, my, mw] of marks) {
      r(mx, my, mw, 1, spec.barkDark);
      r((mx + 1) % 16, (my + 1) % 16, Math.max(1, mw - 2), 1, '#57544c');
      if (mx > 0) r(mx - 1, my, 1, 1, '#7a766b');
      if (mx + mw < 16) r(mx + mw, my, 1, 1, '#7a766b');
    }
    return true;
  }

  if (spec.style === 'cherry') {
    r(0, 0, 16, 16, spec.barkMid);
    // Vertical dark maroon fissures
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const colType = (x + (y >> 2)) % 4;
        if (colType === 0) r(x, y, 1, 1, spec.barkDark);
        else if (colType === 2) r(x, y, 1, 1, spec.barkLight);
      }
    }
    // Signature horizontal dusty-rose cherry bark lenticel stripes
    const bands: [number, number, number][] = [
      [2, 2, 4], [9, 3, 5], [1, 6, 3], [6, 8, 5], [12, 7, 3],
      [3, 11, 4], [10, 12, 4], [0, 14, 3], [7, 15, 4],
    ];
    for (const [bx, by, bw] of bands) {
      r(bx, by, bw, 1, spec.barkAccent);
      r(bx + 1, by, Math.max(1, bw - 2), 1, shadeHex(spec.barkAccent, 22));
      r(bx, (by + 1) % 16, bw, 1, spec.barkDark);
    }
    return true;
  }

  if (spec.style === 'jungle') {
    r(0, 0, 16, 16, spec.barkMid);
    // Jungle bark has horizontal-leaning ridges + mossy green patches
    for (let y = 0; y < 16; y++) {
      const rowCol = y % 4 === 0 ? spec.barkDark : y % 4 === 1 ? spec.barkLight : spec.barkMid;
      r(0, y, 16, 1, rowCol);
      for (let x = 0; x < 16; x += 4) {
        r((x + (y >> 1)) % 16, y, 1, 1, spec.barkDark);
        r((x + 2 + (y >> 1)) % 16, y, 1, 1, spec.barkLight);
      }
    }
    const moss: [number, number, number, number][] = [[2, 3, 3, 2], [10, 6, 4, 2], [4, 11, 3, 2], [12, 13, 3, 2]];
    for (const [mx, my, mw, mh] of moss) {
      r(mx, my, mw, mh, spec.barkAccent);
      r(mx + 1, my, 1, 1, shadeHex(spec.barkAccent, 18));
    }
    return true;
  }

  if (spec.style === 'acacia') {
    r(0, 0, 16, 16, spec.barkMid);
    for (let x = 0; x < 16; x += 4) {
      for (let y = 0; y < 16; y++) {
        const shift = ((y + x) >> 2) & 1;
        const fx = (x + shift) & 15;
        r(fx, y, 1, 1, spec.barkDark);
        r((fx + 1) & 15, y, 1, 1, y % 5 === 0 ? spec.barkMid : spec.barkLight);
        r((fx + 2) & 15, y, 1, 1, y % 3 === 0 ? spec.barkLight : spec.barkMid);
        r((fx + 3) & 15, y, 1, 1, spec.barkAccent);
      }
    }
    r(4, 4, 2, 3, spec.barkDark); r(5, 5, 1, 1, spec.barkLight);
    r(11, 10, 2, 3, spec.barkDark); r(12, 11, 1, 1, spec.barkLight);
    return true;
  }

  if (spec.style === 'fungus') {
    r(0, 0, 16, 16, spec.barkMid);
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const k = (x + (y >> 1)) % 4;
        if (k === 0) r(x, y, 1, 1, spec.barkDark);
        else if (k === 2) r(x, y, 1, 1, spec.barkLight);
      }
    }
    // Glowing wavy bioluminescent fungus veins
    for (let y = 0; y < 16; y++) {
      const vx1 = (3 + Math.round(Math.sin(y * 0.6) * 1.5)) & 15;
      const vx2 = (10 + Math.round(Math.cos(y * 0.55) * 1.5)) & 15;
      if (y % 4 !== 0) {
        r(vx1, y, 1, 1, spec.barkAccent);
        if (y % 2 === 0) r(vx1, y, 1, 1, shadeHex(spec.barkAccent, 32));
      }
      if ((y + 2) % 4 !== 0) {
        r(vx2, y, 1, 1, spec.barkAccent);
        if (y % 2 === 1) r(vx2, y, 1, 1, shadeHex(spec.barkAccent, 32));
      }
    }
    return true;
  }

  // Classic vertical fissured bark (Oak, Spruce, Dark Oak, Mangrove, Pale Oak)
  r(0, 0, 16, 16, spec.barkMid);
  // 4 organic vertical bark columns with staggered fissures and highlights
  const colOffsets = [0, 4, 8, 12];
  for (let ci = 0; ci < 4; ci++) {
    const x0 = colOffsets[ci];
    const shift = (ci * 5) % 16;
    for (let y = 0; y < 16; y++) {
      const wy = (y + shift) % 16;
      const wiggle = wy >= 6 && wy <= 10 ? 1 : 0;
      const furrowX = (x0 + wiggle) % 16;
      const ridgeX = (furrowX + 1) % 16;
      const bodyX = (furrowX + 2) % 16;
      const slopeX = (furrowX + 3) % 16;
      r(furrowX, y, 1, 1, spec.barkDark);
      r(ridgeX, y, 1, 1, wy % 5 === 0 ? spec.barkMid : spec.barkLight);
      r(bodyX, y, 1, 1, wy % 4 === 0 ? spec.barkLight : spec.barkMid);
      r(slopeX, y, 1, 1, wy % 3 === 0 ? spec.barkDark : spec.barkAccent);
    }
  }
  // Bark knots
  r(5, 4, 2, 3, spec.barkDark); r(6, 5, 1, 1, spec.barkLight);
  r(12, 11, 2, 3, spec.barkDark); r(13, 12, 1, 1, spec.barkLight);
  void rnd;
  return true;
}

// =====================================================================================================================
// 2. OBSIDIAN FAMILY (Obsidian, Crying Obsidian, Obsidian Bricks, Respawn Anchor)
// =====================================================================================================================

const OBSIDIAN_MAP = [
  '0122100134321011',
  '1343210243221023',
  '2432210132210134',
  '1322100011100232',
  '0111001233210121',
  '0000123443210010',
  '1221024332210122',
  '3432013221101343',
  '2321001110012432',
  '1210123321023321',
  '0001344321012210',
  '0122433210001100',
  '1343322100123321',
  '2432210012344321',
  '1321100124332210',
  '0110001233211000',
];

const OBSIDIAN_PAL: Record<string, string> = {
  '0': '#090611', // Deep fracture cleavage
  '1': '#140d21', // Dark volcanic glass base
  '2': '#1f1533', // Mid-dark violet obsidian
  '3': '#31214f', // Conchoidal violet facet
  '4': '#4c3678', // Sharp lavender-violet specular ridge
};

export function drawObsidianTile(name: string, ctx: Context2D): boolean {
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === 'obsidian') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // Extra crisp specular glints on top-left facet edges
    r(4, 1, 1, 1, '#634899');
    r(13, 1, 1, 1, '#634899');
    r(8, 5, 1, 1, '#634899');
    r(3, 9, 1, 1, '#634899');
    r(8, 12, 1, 1, '#634899');
    return true;
  }

  if (name === 'crying_obsidian') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // Glowing dimensional purple-magenta-cyan tears embedded in the cleavage trenches
    const tears: [number, number, number, number][] = [
      [2, 2, 2, 3], [10, 1, 2, 4], [6, 5, 3, 2],
      [1, 8, 2, 3], [12, 7, 2, 4], [5, 11, 3, 3], [10, 13, 3, 2],
    ];
    for (const [tx, ty, tw, th] of tears) {
      r(tx - 1, ty, tw + 2, th, '#4a128c');
      r(tx, ty, tw, th, '#8c30eb');
      r(tx, ty, Math.max(1, tw - 1), Math.max(1, th - 1), '#d47aff');
      r(tx, ty, 1, 1, '#f7dcff');
    }
    r(3, 3, 1, 1, '#9ef8ff');
    r(12, 8, 1, 1, '#9ef8ff');
    r(6, 12, 1, 1, '#9ef8ff');
    return true;
  }

  if (name === 'obsidian_bricks') {
    r(0, 0, 16, 16, '#090611');
    for (let row = 0; row < 4; row++) {
      const y = row * 4;
      const off = (row % 2) * 4;
      for (let bx = -4; bx < 16; bx += 8) {
        const x0 = Math.max(0, bx + off);
        const x1 = Math.min(16, bx + off + 7);
        if (x1 <= x0) continue;
        r(x0, y + 1, x1 - x0, 3, '#1d1330');
        r(x0, y + 1, x1 - x0, 1, '#3f2b63');
        r(x0, y + 1, 1, 3, '#31214f');
        r(x0, y + 3, x1 - x0, 1, '#120b1f');
      }
    }
    return true;
  }

  if (name === 'respawn_anchor_top') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // Ornate obsidian border with crying obsidian corners and golden-purple portal vortex
    r(2, 2, 12, 12, '#090611');
    r(1, 1, 3, 3, '#7c2ae8'); r(12, 1, 3, 3, '#7c2ae8');
    r(1, 12, 3, 3, '#7c2ae8'); r(12, 12, 3, 3, '#7c2ae8');
    r(2, 2, 1, 1, '#d88cff'); r(13, 2, 1, 1, '#d88cff');
    r(2, 13, 1, 1, '#d88cff'); r(13, 13, 1, 1, '#d88cff');
    r(3, 3, 10, 10, '#2e1654');
    r(4, 4, 8, 8, '#6e22b5');
    r(5, 5, 6, 6, '#c97826');
    r(6, 6, 4, 4, '#ffcf54');
    r(7, 7, 2, 2, '#fff8c4');
    return true;
  }

  if (name === 'respawn_anchor_side') {
    drawGrid(ctx, OBSIDIAN_MAP, OBSIDIAN_PAL);
    // Upper golden rune band + lower crying obsidian arches
    r(0, 3, 16, 4, '#090611');
    for (let x = 1; x < 15; x += 3) {
      r(x, 4, 2, 2, '#d99626');
      r(x, 4, 1, 1, '#ffe078');
    }
    r(2, 9, 4, 6, '#4a128c'); r(3, 10, 2, 5, '#9b3ff5'); r(3, 11, 1, 3, '#e09eff');
    r(10, 9, 4, 6, '#4a128c'); r(11, 10, 2, 5, '#9b3ff5'); r(11, 11, 1, 3, '#e09eff');
    return true;
  }

  return false;
}

// =====================================================================================================================
// 3. CHEST FAMILY (Chest, Trapped Chest, Ender Chest — Top, Bottom, Side, Front)
// =====================================================================================================================

export function drawChestTile(name: string, ctx: Context2D): boolean {
  const r = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  };

  if (name === 'chest_top' || name === 'chest_bottom') {
    // Authentic warm golden-ochre oak chest lid top with dark timber border and recessed panel
    r(0, 0, 16, 16, '#2b1b0b');
    r(1, 1, 14, 14, '#4a3014');
    r(2, 2, 12, 12, '#c79142');
    r(2, 2, 12, 1, '#dba656');
    r(2, 2, 1, 12, '#dba656');
    r(2, 13, 12, 1, '#8f6322');
    r(13, 2, 1, 12, '#8f6322');
    r(3, 3, 10, 10, '#b57f32');
    for (let y = 4; y < 13; y += 3) {
      r(3, y, 10, 1, '#a37027');
      r(4, y + 1, 8, 1, '#c28b3b');
    }
    // Corner iron/dark-wood studs
    r(1, 1, 2, 2, '#241608'); r(13, 1, 2, 2, '#241608');
    r(1, 13, 2, 2, '#241608'); r(13, 13, 2, 2, '#241608');
    return true;
  }

  if (name === 'chest_side' || name === 'chest_front' || name === 'trapped_chest_front') {
    // Unified lid (rows 0..4), dark seam (row 5), lower box (rows 6..15)
    r(0, 0, 16, 16, '#2b1b0b');
    // Lid panel (rows 1..4)
    r(1, 1, 14, 4, '#4a3014');
    r(2, 1, 12, 4, '#c28b3b');
    r(2, 1, 12, 1, '#dba656');
    r(2, 4, 12, 1, '#8f6322');
    r(3, 2, 10, 2, '#b57f32');
    // Crisp 1px lid-opening seam across all 4 faces at row 5
    r(0, 5, 16, 1, '#1a1006');
    // Lower chest box (rows 6..14)
    r(1, 6, 14, 9, '#4a3014');
    r(2, 6, 12, 9, '#b57f32');
    r(2, 6, 12, 1, '#d49d4c');
    r(2, 14, 12, 1, '#7d541b');
    r(2, 6, 1, 9, '#c79142');
    r(13, 6, 1, 9, '#8c6020');
    for (const py of [8, 11, 13]) r(3, py, 10, 1, '#9e6c25');
    for (const py of [7, 10, 12]) r(4, py, 8, 1, '#c48e3e');

    if (name === 'trapped_chest_front') {
      // Iconic redstone trap stain ring around the front latch
      r(5, 3, 6, 7, '#9e1e16');
      r(6, 3, 4, 7, '#d93226');
      r(5, 4, 6, 5, '#c4281e');
    }
    if (name === 'chest_front' || name === 'trapped_chest_front') {
      // 3D-shaded silver lock plate spanning the lid seam (x=6..9, y=4..8)
      r(6, 4, 4, 5, '#1f2426');
      r(7, 4, 2, 4, '#cfd9db');
      r(7, 4, 2, 1, '#ffffff');
      r(7, 7, 2, 1, '#7d878a');
      r(7, 5, 2, 1, '#e3eded');
      r(7, 6, 1, 1, '#384042'); // Keyhole slot
    }
    return true;
  }

  if (name === 'ender_chest_top' || name === 'ender_chest_bottom') {
    r(0, 0, 16, 16, '#081012');
    r(1, 1, 14, 14, '#122226');
    r(2, 2, 12, 12, '#1c343a');
    r(2, 2, 12, 1, '#2d5059');
    r(2, 2, 1, 12, '#2d5059');
    r(3, 3, 10, 10, '#15282d');
    if (name === 'ender_chest_top') {
      r(4, 4, 8, 8, '#0d1b1f');
      r(5, 5, 6, 6, '#193036');
      r(6, 6, 4, 4, '#24444d');
      r(7, 7, 2, 2, '#32786a');
      r(4, 4, 8, 1, '#26434c');
      r(4, 4, 1, 8, '#26434c');
    }
    return true;
  }

  if (name === 'ender_chest_side' || name === 'ender_chest_front') {
    r(0, 0, 16, 16, '#081012');
    // Ribbed dark obsidian-teal lid (rows 1..4)
    r(1, 1, 14, 4, '#122226');
    r(2, 1, 12, 4, '#1e363d');
    r(2, 1, 12, 1, '#325661');
    r(3, 2, 10, 2, '#16292e');
    // Lid seam at row 5
    r(0, 5, 16, 1, '#050a0c');
    // Lower obsidian vault box (rows 6..14) with vertical obsidian ribs
    r(1, 6, 14, 9, '#122226');
    r(2, 6, 12, 9, '#1c333a');
    r(2, 6, 12, 1, '#2e515c');
    for (let x = 3; x < 13; x += 2) {
      r(x, 7, 1, 7, '#132429');
      r(x + 1, 7, 1, 7, '#26434c');
    }
    // Subtle glowing ender particles on the dark stone
    r(4, 9, 1, 1, '#4ad9b5');
    r(11, 12, 1, 1, '#4ad9b5');
    if (name === 'ender_chest_front') {
      // Golden-emerald Eye of Ender lock latch
      r(6, 4, 4, 5, '#141f1c');
      r(7, 4, 2, 4, '#e8c444');
      r(7, 4, 2, 1, '#fff099');
      r(7, 7, 2, 1, '#9e7b1b');
      r(7, 5, 2, 2, '#38cf82');
      r(7, 5, 1, 1, '#a8ffe0');
    }
    return true;
  }

  return false;
}

// =====================================================================================================================
// 4. ALL 2D ITEM REPRESENTATIONS (Tools, Weapons, Armor, Ingots, Gems, Ores, Foods, Potions, Buckets, Misc)
// =====================================================================================================================

const SWORD_MAP = [
  '.............OO.',
  '............OHLO',
  '...........OHBLO',
  '..........OHBGLO',
  '.........OHBGLO.',
  '........OHBGLO..',
  '.......OHBGLO...',
  '....OO.OHBGLO...',
  '....OGOHBGLO....',
  '.....OGBGLO.....',
  '....OWGGLO......',
  '...OSWGOO.......',
  '..OSWO..OO......',
  '.OPSO...O.......',
  '.OPO............',
  '................',
];

const PICKAXE_MAP = [
  '.......OOOOO....',
  '.....OOHHHHBO...',
  '....OHBBBBGBLO..',
  '...OHBGOOOWGBLO.',
  '...OHGO..OSWGBLO',
  '...OOO..OSWOBBLO',
  '.......OSWO.OBLO',
  '......OSWO..OBLO',
  '.....OSWO...OBLO',
  '....OSWO....OBO.',
  '...OSWO.....OO..',
  '..OSWO..........',
  '.OSWO...........',
  'OSWO............',
  'OSO.............',
  '................',
];

const AXE_MAP = [
  '......OOOOO.....',
  '.....OHHHHBO....',
  '....OHBBBBGLO...',
  '....OHBBBGBWLO..',
  '....OHBBGOWGBLO.',
  '.....OHGOOSWGLO.',
  '......OO.OSWO.O.',
  '........OSWO....',
  '.......OSWO.....',
  '......OSWO......',
  '.....OSWO.......',
  '....OSWO........',
  '...OSWO.........',
  '..OSWO..........',
  '.OSO............',
  '................',
];

const SHOVEL_MAP = [
  '..........OOOO..',
  '.........OHHHBO.',
  '........OHBBBGLO',
  '........OHBBGGLO',
  '........OHBGGBLO',
  '........OOWGBLO.',
  '........OSWOO...',
  '.......OSWO.....',
  '......OSWO......',
  '.....OSWO.......',
  '....OSWO........',
  '...OSWO.........',
  '..OSWO..........',
  '.OSWO...........',
  '.OSO............',
  '................',
];

const HOE_MAP = [
  '.....OOOOOOO....',
  '....OHHHHHHBO...',
  '....OHBBBBGBLO..',
  '....OHOOOOWGBO..',
  '.........OSWOO..',
  '........OSWO....',
  '.......OSWO.....',
  '......OSWO......',
  '.....OSWO.......',
  '....OSWO........',
  '...OSWO.........',
  '..OSWO..........',
  '.OSWO...........',
  'OSWO............',
  'OSO.............',
  '................',
];

const HELMET_MAP = [
  '................',
  '....OOOOOOOO....',
  '...OHHHHHHHBO...',
  '..OHBBBBBBBBGO..',
  '..OHBBBBBBBBGO..',
  '..OHBBOOOOBBGO..',
  '..OHBO.OO.OBGO..',
  '..OBGO.OO.OGGO..',
  '..OBGO....OGGO..',
  '..OGGO....OGGO..',
  '...OO......OO...',
  '................',
  '................',
  '................',
  '................',
  '................',
];

const CHESTPLATE_MAP = [
  '................',
  '.OOOO......OOOO.',
  'OHHHBO....OBHHHO',
  'OHBBBGO..OGBBBHO',
  'OHBBBBGOOGBBBBHO',
  'OHBBBBBBBBBBBBHO',
  '.OOBBBBBBBBBBGO.',
  '..OHBBBBBBBBGO..',
  '..OHBBBGGGBBGO..',
  '..OHBBBGGGBBGO..',
  '..OHBBBBBBBBGO..',
  '..OBGGGGGGGGGO..',
  '...OOOOOOOOOO...',
  '................',
  '................',
  '................',
];

const LEGGINGS_MAP = [
  '................',
  '...OOOOOOOOOO...',
  '..OHHHHHHHHHGO..',
  '..OHBBBOOBBBGO..',
  '..OGGGGGGGGGGO..',
  '..OHBBO..OBBGO..',
  '..OHBBO..OBBGO..',
  '..OHBBO..OBBGO..',
  '..OHHGO..OHHGO..',
  '..OHBBO..OBBGO..',
  '..OHBBO..OBBGO..',
  '..OBGGO..OGGGO..',
  '..OOOO....OOOO..',
  '................',
  '................',
  '................',
];

const BOOTS_MAP = [
  '................',
  '................',
  '................',
  '................',
  '................',
  '..OOOO....OOOO..',
  '..OHHBO..OBHHO..',
  '..OHBBO..OBBHO..',
  '..OHBBO..OBBHO..',
  '.OOHBGO..OGBHOO.',
  'OHBBBGO..OGBBBHO',
  'OBGGGGO..OGGGGGO',
  'OOOOOO....OOOOOO',
  '................',
  '................',
  '................',
];

const INGOT_MAP = [
  '................',
  '................',
  '................',
  '................',
  '....OOOOOOOOO...',
  '...OHHHHHHHHBO..',
  '..OHHBBBBBBBGLO.',
  '.OHBBBBBBBBGGLO.',
  '.OBGGGGGGGGGGO..',
  '..OOOOOOOOOOO...',
  '................',
  '................',
  '................',
  '................',
  '................',
  '................',
];

export function drawRefinedItem(def: BlockDef, ctx: Context2D): boolean {
  const n = def.name;
  const col = def.color;
  const r = (x: number, y: number, w: number, h: number, c: string) => {
    ctx.fillStyle = c;
    ctx.fillRect(x, y, w, h);
  };
  ctx.clearRect(0, 0, 16, 16);

  // 1. Standard Tool & Weapon Tiers (Sword, Pickaxe, Axe, Shovel, Hoe)
  if (/^(wooden|stone|copper|iron|golden|diamond|netherite)_(sword|pickaxe|axe|shovel|hoe)$/.test(n)) {
    const type = n.split('_').pop()!;
    const netherite = n.startsWith('netherite_');
    const pal: Record<string, string> = {
      O: shadeHex(col, -85),
      H: shadeHex(col, 55),
      B: col,
      G: shadeHex(col, -25),
      L: shadeHex(col, -45),
      W: netherite ? '#7a3b36' : '#b88c52',
      S: netherite ? '#4f2420' : '#7d5a30',
      P: shadeHex(col, 35),
    };
    const map =
      type === 'sword' ? SWORD_MAP :
      type === 'pickaxe' ? PICKAXE_MAP :
      type === 'axe' ? AXE_MAP :
      type === 'shovel' ? SHOVEL_MAP : HOE_MAP;
    drawGrid(ctx, map, pal);
    return true;
  }

  // 2. All Armor Pieces (Helmet, Chestplate, Leggings, Boots + Turtle Helmet + Wolf Armor)
  if (n.endsWith('_helmet') || n.endsWith('_chestplate') || n.endsWith('_leggings') || n.endsWith('_boots')) {
    const chain = n.startsWith('chainmail_');
    const pal: Record<string, string> = {
      O: shadeHex(col, -80),
      H: shadeHex(col, 48),
      B: col,
      G: shadeHex(col, -28),
    };
    const map =
      n.endsWith('_helmet') ? HELMET_MAP :
      n.endsWith('_chestplate') ? CHESTPLATE_MAP :
      n.endsWith('_leggings') ? LEGGINGS_MAP : BOOTS_MAP;
    drawGrid(ctx, map, pal);
    if (chain) {
      // Metallic ring-mail checker pattern
      for (let y = 2; y < 13; y++) {
        for (let x = 2; x < 14; x++) {
          if ((x + y) % 2 === 0 && ctx.getImageData(x, y, 1, 1).data[3] > 0) {
            r(x, y, 1, 1, shadeHex(col, -35));
          }
        }
      }
    }
    return true;
  }

  if (n === 'wolf_armor') {
    r(3, 5, 10, 6, '#9c6c5e'); r(5, 3, 6, 4, '#b88576'); r(4, 6, 8, 4, '#cf9e8f');
    r(4, 10, 2, 4, '#785045'); r(10, 10, 2, 4, '#785045');
    addOutline(ctx, '#3d251e');
    return true;
  }

  // 3. Ingots, Bricks & Smithing Upgrades
  if (n.endsWith('_ingot') || n === 'brick' || n === 'nether_brick') {
    drawGrid(ctx, INGOT_MAP, {
      O: shadeHex(col, -80),
      H: shadeHex(col, 52),
      B: col,
      G: shadeHex(col, -24),
      L: shadeHex(col, -42),
    });
    return true;
  }

  if (n === 'netherite_upgrade' || n.endsWith('_armor_trim_smithing_template')) {
    const trimCol = n === 'netherite_upgrade' ? '#f2c842' : '#58e8dc';
    const bodyCol = n === 'netherite_upgrade' ? '#632929' : '#4a5661';
    r(3, 2, 10, 12, bodyCol);
    r(4, 3, 8, 10, shadeHex(bodyCol, 18));
    r(5, 4, 6, 2, trimCol);
    r(5, 7, 2, 4, trimCol); r(9, 7, 2, 4, trimCol);
    r(6, 11, 4, 1, trimCol);
    addOutline(ctx, '#1f1924');
    return true;
  }

  if (n.endsWith('_pottery_sherd')) {
    r(4, 3, 8, 10, '#8c4c34');
    r(3, 5, 10, 6, '#9e583e');
    r(5, 4, 6, 8, '#b5694c');
    r(6, 6, 4, 4, '#703925');
    r(7, 5, 2, 6, '#cf8363');
    addOutline(ctx, '#3b1c11');
    return true;
  }

  // 4. Gems, Raw Ores, Nuggets, Shards & Dusts
  if (n === 'diamond' || n === 'emerald') {
    const em = n === 'emerald';
    if (em) {
      r(5, 2, 6, 12, '#1f9c44'); r(4, 3, 8, 10, '#2fc95a');
      r(5, 4, 6, 8, '#52e879'); r(6, 4, 2, 5, '#c4ffd2'); r(6, 4, 1, 2, '#ffffff');
      r(6, 10, 4, 2, '#177332');
      addOutline(ctx, '#0b3818');
    } else {
      r(6, 2, 4, 12, '#2ba6b0'); r(4, 3, 8, 10, '#3ecfd9'); r(3, 5, 10, 6, '#58e8f0');
      r(5, 4, 6, 6, '#82f7fc'); r(5, 4, 3, 3, '#ffffff');
      r(6, 9, 5, 3, '#208891'); r(4, 8, 3, 3, '#2caeb8');
      addOutline(ctx, '#113c42');
    }
    return true;
  }

  if (n === 'coal' || n === 'charcoal') {
    const ch = n === 'charcoal';
    r(4, 3, 8, 10, ch ? '#47392d' : '#2e3236');
    r(3, 5, 10, 7, ch ? '#382c22' : '#232629');
    r(5, 4, 4, 3, ch ? '#665343' : '#525961');
    r(6, 5, 2, 1, ch ? '#826b57' : '#78828c');
    addOutline(ctx, '#121314');
    return true;
  }

  if (n === 'raw_iron' || n === 'raw_copper' || n === 'raw_gold') {
    const acc = n === 'raw_copper' ? '#439675' : shadeHex(col, -32);
    r(4, 3, 7, 9, col);
    r(3, 6, 10, 6, shadeHex(col, -14));
    r(6, 4, 5, 5, shadeHex(col, 28));
    r(4, 8, 3, 3, acc);
    r(9, 7, 3, 3, acc);
    r(7, 4, 2, 2, '#fff5d6');
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'gold_nugget' || n === 'iron_nugget') {
    r(5, 5, 6, 6, col);
    r(6, 4, 4, 8, col);
    r(6, 5, 2, 2, '#ffffff');
    r(7, 9, 3, 2, shadeHex(col, -30));
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'lapis_lazuli' || n === 'flint' || n === 'clay_ball' || n === 'heart_of_the_sea') {
    r(4, 3, 8, 10, col);
    r(3, 5, 10, 6, col);
    r(5, 4, 4, 3, shadeHex(col, 40));
    r(6, 9, 5, 3, shadeHex(col, -28));
    if (n === 'lapis_lazuli') { r(8, 6, 2, 1, '#e6c35c'); r(5, 9, 1, 1, '#e6c35c'); }
    if (n === 'heart_of_the_sea') { r(6, 6, 4, 4, '#7cf2ff'); r(7, 7, 2, 2, '#ffffff'); }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'quartz' || n === 'amethyst_shard' || n === 'echo_shard' || n === 'prismarine_shard' || n === 'prismarine_crystals') {
    const echo = n === 'echo_shard';
    for (let i = 0; i < 9; i++) {
      r(3 + i, 11 - i, 3, 3, echo ? '#0d3b47' : col);
      r(3 + i, 11 - i, 2, 1, echo ? '#38e0f0' : shadeHex(col, 48));
    }
    r(4, 9, 3, 4, echo ? '#19697a' : shadeHex(col, -22));
    r(8, 7, 4, 3, echo ? '#19697a' : shadeHex(col, -22));
    addOutline(ctx, echo ? '#05161c' : shadeHex(col, -85));
    return true;
  }

  // Powders & Dusts (Redstone, Glowstone Dust, Sugar, Gunpowder, Blaze Powder, Bone Meal)
  if (n === 'redstone' || n === 'glowstone_dust' || n === 'sugar' || n === 'gunpowder' || n === 'blaze_powder' || n === 'bone_meal') {
    r(6, 4, 4, 3, shadeHex(col, 35));
    r(4, 6, 8, 4, col);
    r(3, 9, 10, 3, shadeHex(col, -18));
    r(2, 11, 12, 2, shadeHex(col, -32));
    r(6, 5, 2, 2, '#ffffff');
    r(5, 8, 2, 1, shadeHex(col, 25));
    r(9, 9, 2, 1, shadeHex(col, -40));
    addOutline(ctx, shadeHex(col, -90));
    return true;
  }

  // All 16 Dyes
  if (n.endsWith('_dye')) {
    r(5, 4, 6, 8, col);
    r(4, 5, 8, 6, col);
    r(5, 5, 3, 2, shadeHex(col, 42));
    r(6, 9, 5, 2, shadeHex(col, -26));
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  // 5. Seeds, Crops & Plants
  if (n.endsWith('_seeds') || n === 'pitcher_pod' || n === 'cocoa_beans') {
    if (n === 'cocoa_beans' || n === 'pitcher_pod') {
      r(5, 3, 6, 10, col); r(4, 5, 8, 6, shadeHex(col, 16)); r(6, 4, 2, 3, shadeHex(col, 38));
      addOutline(ctx, shadeHex(col, -80));
      return true;
    }
    const seeds: [number, number][] = [[3, 5], [8, 3], [11, 7], [5, 10], [9, 11], [6, 7]];
    for (const [sx, sy] of seeds) {
      r(sx, sy, 2, 3, shadeHex(col, -65));
      r(sx, sy, 2, 2, col);
      r(sx, sy, 1, 1, shadeHex(col, 40));
    }
    return true;
  }

  if (n === 'wheat') {
    for (let i = 0; i < 10; i++) {
      r(2 + i, 12 - i, 4, 3, '#c99e38');
      r(2 + i, 12 - i, 2, 2, '#f0ce62');
    }
    r(9, 2, 5, 5, '#f5dc78'); r(11, 1, 3, 3, '#fff09e');
    r(5, 7, 5, 3, '#b83c2e');
    addOutline(ctx, '#4a3510');
    return true;
  }

  // 6. All Foods (Distinct silhouettes per food item!)
  if (n === 'apple' || n === 'golden_apple' || n === 'enchanted_golden_apple') {
    const ench = n === 'enchanted_golden_apple';
    r(4, 4, 8, 9, col); r(3, 5, 10, 7, col);
    r(5, 5, 3, 3, ench ? '#f7b8ff' : shadeHex(col, 55));
    r(6, 10, 5, 2, shadeHex(col, -28));
    addOutline(ctx, ench ? '#5c1f7a' : shadeHex(col, -85));
    r(7, 1, 2, 3, '#5c3c1e');
    r(9, 2, 3, 2, '#5ca638');
    return true;
  }

  if (n === 'bread') {
    r(2, 6, 12, 6, '#c98e3e');
    r(3, 5, 10, 7, '#dba24e');
    r(4, 5, 8, 2, '#f2c474');
    r(5, 6, 1, 3, '#9e6824'); r(8, 6, 1, 3, '#9e6824'); r(11, 6, 1, 3, '#9e6824');
    r(3, 10, 10, 2, '#9e6824');
    addOutline(ctx, '#472c0e');
    return true;
  }

  if (n === 'raw_beef' || n === 'cooked_beef' || n === 'porkchop' || n === 'cooked_porkchop' || n === 'mutton' || n === 'cooked_mutton') {
    const raw = n.startsWith('raw_') || n === 'porkchop' || n === 'mutton';
    r(3, 4, 10, 8, col);
    r(2, 5, 12, 6, col);
    r(4, 5, 6, 3, shadeHex(col, 24));
    r(5, 9, 7, 2, shadeHex(col, -25));
    // Bone / fat marbling
    r(9, 6, 3, 3, raw ? '#f5ebe6' : '#e8dec8');
    r(10, 7, 1, 1, shadeHex(col, -30));
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'chicken' || n === 'cooked_chicken' || n === 'rabbit' || n === 'cooked_rabbit') {
    r(4, 4, 8, 8, col);
    r(3, 5, 9, 6, shadeHex(col, 16));
    r(5, 5, 4, 3, shadeHex(col, 36));
    r(11, 10, 3, 2, '#f2eee4'); // Drumstick bone end
    r(11, 4, 3, 2, '#f2eee4');
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'cod' || n === 'cooked_cod' || n === 'salmon' || n === 'cooked_salmon' || n === 'tropical_fish' || n === 'pufferfish') {
    if (n === 'pufferfish') {
      r(4, 4, 8, 8, '#ebb82c'); r(3, 5, 10, 6, '#f5cc3d'); r(5, 9, 6, 3, '#f7f0c6');
      r(5, 6, 2, 2, '#1c2426'); r(9, 6, 2, 2, '#1c2426');
      addOutline(ctx, '#5c430c');
      return true;
    }
    const isSalmon = n.includes('salmon');
    const headCol = isSalmon && n === 'salmon' ? '#4f6e58' : shadeHex(col, -20);
    // Plump curved fish body + dorsal/pectoral fins + forked tail
    r(5, 5, 6, 6, col);
    r(4, 6, 7, 5, col);
    r(6, 4, 6, 5, shadeHex(col, 22));
    r(9, 3, 4, 4, headCol);
    r(4, 4, 3, 2, shadeHex(col, -18)); // Dorsal fin
    r(8, 9, 3, 2, shadeHex(col, -18)); // Ventral fin
    r(2, 10, 3, 4, headCol); // Forked tail
    r(1, 12, 2, 2, headCol); r(3, 13, 2, 2, headCol);
    if (n === 'tropical_fish') { r(6, 5, 2, 5, '#ffffff'); r(9, 4, 1, 4, '#ffffff'); }
    r(11, 4, 1, 1, '#14181a'); // Eye
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'carrot' || n === 'golden_carrot' || n === 'beetroot') {
    const beet = n === 'beetroot';
    for (let i = 0; i < 8; i++) {
      const w = Math.max(2, Math.floor((i + 2) / 2));
      r(3 + i, 12 - i, w, w, col);
      r(3 + i, 12 - i, 1, 1, shadeHex(col, 42));
    }
    addOutline(ctx, shadeHex(col, -85));
    r(11, 2, 3, 3, beet ? '#629c3b' : '#4fa638');
    r(12, 1, 2, 2, '#78cf54');
    return true;
  }

  if (n === 'potato' || n === 'baked_potato' || n === 'poisonous_potato' || n === 'egg') {
    r(4, 4, 8, 9, col);
    r(5, 3, 6, 11, col);
    r(5, 4, 3, 3, shadeHex(col, 36));
    if (n === 'baked_potato') { r(6, 5, 4, 4, '#fff2b2'); r(7, 6, 2, 2, '#e8a838'); }
    if (n === 'poisonous_potato') { r(5, 7, 2, 2, '#5ca638'); r(8, 9, 2, 2, '#5ca638'); }
    addOutline(ctx, shadeHex(col, -80));
    return true;
  }

  if (n === 'melon_slice' || n === 'glistering_melon_slice') {
    const gl = n === 'glistering_melon_slice';
    r(3, 6, 10, 6, '#3e7a28'); // Green rind
    r(4, 6, 8, 5, '#a8c958');
    r(4, 4, 8, 6, '#cf382e'); // Red flesh
    r(5, 5, 1, 1, gl ? '#fff08a' : '#261c18');
    r(8, 6, 1, 1, gl ? '#fff08a' : '#261c18');
    r(10, 5, 1, 1, gl ? '#fff08a' : '#261c18');
    if (gl) { r(6, 4, 2, 1, '#f2c842'); r(9, 4, 2, 1, '#f2c842'); }
    addOutline(ctx, '#224215');
    return true;
  }

  if (n === 'sweet_berries' || n === 'glow_berries' || n === 'chorus_fruit' || n === 'popped_chorus_fruit') {
    r(5, 3, 6, 3, '#4c852e');
    r(4, 6, 4, 5, col); r(8, 6, 4, 5, col); r(6, 9, 4, 5, shadeHex(col, 16));
    r(5, 7, 1, 1, '#ffffff'); r(9, 7, 1, 1, '#ffffff'); r(7, 10, 1, 1, '#ffffff');
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'cookie' || n === 'pumpkin_pie' || n === 'cake' || n === 'honeycomb') {
    r(3, 4, 10, 8, col);
    r(4, 3, 8, 10, shadeHex(col, 14));
    if (n === 'cookie') {
      r(5, 5, 2, 2, '#472814'); r(9, 6, 2, 2, '#472814'); r(6, 9, 2, 2, '#472814');
    } else if (n === 'cake') {
      r(3, 4, 10, 4, '#f7f4eb'); r(5, 5, 2, 2, '#d9322a'); r(9, 5, 2, 2, '#d9322a');
      r(3, 8, 10, 4, '#c78c44');
    } else if (n === 'pumpkin_pie') {
      r(4, 5, 8, 6, '#d97829'); r(5, 6, 3, 2, '#f09846');
    }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'bowl' || n.endsWith('_stew') || n.endsWith('_soup')) {
    r(3, 8, 10, 4, '#8a5d32');
    r(4, 11, 8, 2, '#694422');
    if (n !== 'bowl') {
      r(4, 6, 8, 3, col);
      r(5, 6, 3, 2, shadeHex(col, 35));
      if (n === 'mushroom_stew') { r(8, 6, 2, 2, '#d93b30'); r(6, 7, 2, 1, '#f2eee4'); }
    } else {
      r(4, 7, 8, 2, '#4f3218');
    }
    addOutline(ctx, '#36210e');
    return true;
  }

  if (n === 'rotten_flesh' || n === 'spider_eye' || n === 'fermented_spider_eye' || n === 'dried_kelp') {
    r(4, 4, 8, 8, col);
    r(3, 6, 10, 5, shadeHex(col, -16));
    r(5, 5, 3, 2, shadeHex(col, 36));
    if (n === 'rotten_flesh') { r(6, 7, 4, 2, '#5a7d3a'); }
    if (n.includes('spider_eye')) { r(6, 6, 3, 3, '#1f080d'); r(6, 6, 1, 1, '#ff9ea8'); }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  // 7. Buckets & Bottles & Potions
  if (n.includes('bucket')) {
    r(3, 4, 10, 8, '#9aa4a6');
    r(4, 11, 8, 3, '#768082');
    r(4, 5, 3, 6, '#dce3e6');
    if (n !== 'bucket') {
      const liq = n === 'water_bucket' ? '#2c7fe8' : n === 'lava_bucket' ? '#ff6e14' : n === 'milk_bucket' ? '#f7f7f2' : '#e6f4fa';
      r(4, 3, 8, 3, liq);
      r(5, 3, 4, 1, shadeHex(liq, 48));
    } else {
      r(4, 4, 8, 2, '#4a5254');
    }
    addOutline(ctx, '#292e30');
    return true;
  }

  if (n === 'glass_bottle' || n === 'dragon_breath' || n === 'ominous_bottle' || /^(potion_|splash_)|_potion$|^water_bottle$|^potion$|^honey_bottle$|^experience_bottle$/.test(n)) {
    const splash = n.startsWith('splash_');
    r(6, 1, 4, 2, '#9e6e3e'); // Cork
    r(5, 3, 6, 2, '#cbe4eb'); // Bottle neck rim
    if (splash) r(8, 2, 3, 2, '#cbe4eb');
    r(4, 5, 8, 8, '#cbe4eb');
    r(5, 12, 6, 2, '#a3c4cf');
    if (n !== 'glass_bottle') {
      const liq = n === 'experience_bottle' ? '#b8f242' : n === 'dragon_breath' ? '#d952ff' : n === 'ominous_bottle' ? '#384e8a' : col;
      r(5, 6, 6, 7, liq);
      r(5, 6, 2, 3, shadeHex(liq, 60));
    } else {
      r(5, 6, 2, 4, '#ffffff');
    }
    addOutline(ctx, '#2b3c42');
    return true;
  }

  // 8. Ranged, Special Weapons & Utility Gear
  if (n === 'bow') {
    for (let i = 2; i < 14; i++) {
      const bx = 4 + Math.round(Math.sin(((i - 2) / 11) * Math.PI) * 6);
      r(bx, i, 2, 1, i === 7 || i === 8 ? '#c79a5b' : '#7d562c');
    }
    r(4, 2, 1, 12, '#e6e3d8');
    addOutline(ctx, '#2b1b0a');
    return true;
  }

  if (n === 'arrow' || n === 'spectral_arrow') {
    const tip = n === 'spectral_arrow' ? '#ffd83d' : '#d0d7d9';
    for (let i = 3; i < 12; i++) r(i, 15 - i, 2, 1, '#9c7340');
    r(11, 1, 4, 4, tip); r(12, 1, 3, 1, '#ffffff');
    r(1, 11, 4, 4, '#f2efe6');
    addOutline(ctx, '#2b1e10');
    return true;
  }

  if (n === 'fishing_rod' || n === 'carrot_on_a_stick' || n === 'warped_fungus_on_a_stick') {
    for (let i = 2; i < 12; i++) r(i, 14 - i, 2, 1, '#8c6436');
    r(12, 3, 1, 8, '#e3e0d5');
    const bait = n === 'carrot_on_a_stick' ? '#f08226' : n === 'warped_fungus_on_a_stick' ? '#28b5a8' : '#e03b2e';
    r(11, 10, 3, 4, bait);
    addOutline(ctx, '#2b1d0e');
    return true;
  }

  if (n === 'compass' || n === 'clock') {
    const gold = n === 'clock';
    const body = gold ? '#f0c43e' : '#b8c2c4';
    r(3, 3, 10, 10, body);
    r(4, 2, 8, 12, body);
    r(2, 4, 12, 8, body);
    r(4, 4, 8, 8, gold ? '#243059' : '#262b2e');
    r(7, 4, 2, 4, gold ? '#ffd84a' : '#e62e24'); // Red needle / gold hand
    r(7, 8, 2, 3, '#e0e6e8');
    addOutline(ctx, gold ? '#4f3908' : '#262b2c');
    return true;
  }

  if (n === 'spyglass') {
    for (let i = 2; i < 13; i++) {
      const c1 = i < 6 ? '#5e3d22' : '#d48248';
      r(i, 14 - i, 3, 3, c1);
      r(i, 14 - i, 2, 1, i < 6 ? '#855832' : '#f2aa6b');
    }
    r(12, 1, 3, 3, '#7ae8f5');
    addOutline(ctx, '#26170b');
    return true;
  }

  if (n === 'trial_key' || n === 'ominous_trial_key') {
    const om = n === 'ominous_trial_key';
    const kCol = om ? '#4c6ed9' : '#d47f48';
    const glow = om ? '#82f5ff' : '#ffd86b';
    r(3, 3, 6, 6, kCol); r(5, 5, 2, 2, glow);
    for (let i = 7; i < 14; i++) r(i, i, 2, 2, kCol);
    r(10, 12, 2, 3, kCol); r(12, 13, 2, 2, glow);
    addOutline(ctx, '#1f1612');
    return true;
  }

  if (n === 'bundle') {
    r(4, 5, 8, 9, '#a8693c');
    r(3, 6, 10, 7, '#bd7a4a');
    r(5, 3, 6, 2, '#c9935b');
    r(4, 5, 8, 1, '#e6c24c'); // Gold drawstring tie
    r(5, 7, 3, 4, '#d49260');
    addOutline(ctx, '#3b1f0d');
    return true;
  }

  if (n === 'goat_horn') {
    r(3, 8, 5, 5, '#7a6c5b');
    r(6, 10, 6, 4, '#948470');
    r(10, 6, 4, 6, '#aba08c');
    r(11, 3, 2, 4, '#cfc6b4');
    addOutline(ctx, '#29231d');
    return true;
  }

  if (n === 'name_tag') {
    r(3, 6, 9, 6, '#d6c698');
    r(4, 7, 7, 4, '#ebe0be');
    r(5, 8, 5, 1, '#7a6e52');
    r(11, 3, 3, 4, '#9e7644');
    addOutline(ctx, '#383020');
    return true;
  }

  if (n === 'book' || n === 'writable_book' || n === 'written_book' || n === 'enchanted_book') {
    const cover = n === 'enchanted_book' ? '#8c3bb5' : n === 'written_book' ? '#9e2848' : '#9c5c34';
    r(3, 2, 10, 12, cover);
    r(4, 3, 8, 10, shadeHex(cover, 22));
    r(11, 3, 2, 10, '#f5f0dc'); // Book pages
    r(3, 7, 9, 2, '#f2c842'); // Gold strap
    if (n === 'writable_book') { r(11, 1, 3, 6, '#ffffff'); r(10, 6, 2, 4, '#dcd8c8'); }
    addOutline(ctx, '#291509');
    return true;
  }

  if (n === 'paper' || n === 'map' || n === 'filled_map' || n === 'buried_treasure_map' || n.endsWith('_explorer_map') || n.endsWith('_banner_pattern')) {
    r(2, 2, 12, 12, '#e8dec0');
    r(3, 3, 10, 10, '#f5eed8');
    if (n.includes('map')) {
      r(4, 4, 4, 5, '#5ca644');
      r(8, 5, 4, 6, '#3e84c9');
      r(6, 9, 3, 2, '#d9382e'); // Red X / marker
    } else if (n.endsWith('_banner_pattern')) {
      r(5, 5, 6, 6, '#8c653e');
      r(6, 6, 4, 4, '#c49660');
    } else {
      for (const py of [5, 8, 11]) r(4, py, 8, 1, '#c9bfa2');
    }
    addOutline(ctx, '#4a402c');
    return true;
  }

  if (n.endsWith('_minecart') || n === 'minecart') {
    if (n !== 'minecart') {
      const inner = n === 'chest_minecart' ? '#c28b3b' : n === 'tnt_minecart' ? '#cc382c' : n === 'hopper_minecart' ? '#586063' : '#787d7a';
      r(4, 2, 8, 6, inner);
      r(5, 3, 6, 3, shadeHex(inner, 28));
    }
    r(2, 6, 12, 6, '#879194');
    r(3, 7, 10, 4, '#b8c4c7');
    r(3, 6, 10, 1, '#e6eff2');
    r(4, 12, 2, 2, '#2e3336'); r(10, 12, 2, 2, '#2e3336');
    addOutline(ctx, '#24292b');
    return true;
  }

  if (n === 'slime_ball' || n === 'magma_cream' || n === 'snowball' || n === 'fire_charge' || n === 'wind_charge' || n === 'xp_orb') {
    r(4, 3, 8, 10, col);
    r(3, 4, 10, 8, col);
    r(5, 4, 3, 3, n === 'fire_charge' ? '#fff08a' : '#ffffff');
    r(6, 9, 5, 3, shadeHex(col, -28));
    if (n === 'magma_cream') { r(5, 6, 6, 3, '#ff9d26'); }
    if (n === 'fire_charge') { r(5, 6, 6, 5, '#ffab26'); }
    if (n === 'wind_charge') { r(4, 6, 8, 3, '#ffffff'); }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'leather' || n === 'rabbit_hide' || n === 'hoglin_hide' || n === 'scute' || n === 'armadillo_scute' || n === 'phantom_membrane' || n === 'nautilus_shell' || n === 'disc_fragment' || n === 'ink_sac' || n === 'glow_ink_sac' || n === 'rabbit_foot' || n === 'string' || n === 'feather' || n === 'bone' || n === 'stick' || n === 'breeze_rod') {
    if (n === 'stick' || n === 'bone' || n === 'feather' || n === 'breeze_rod') {
      for (let i = 0; i < 10; i++) {
        r(3 + i, 12 - i, 2, 2, col);
        r(3 + i, 12 - i, 1, 1, shadeHex(col, 38));
      }
      if (n === 'bone') { r(2, 11, 3, 3, col); r(11, 2, 3, 3, col); }
      if (n === 'feather') { r(6, 4, 5, 5, shadeHex(col, 18)); }
      addOutline(ctx, shadeHex(col, -85));
      return true;
    }
    if (n === 'string') {
      for (let i = 2; i < 13; i++) {
        const sx = 4 + Math.round(Math.sin(i * 0.8) * 3);
        r(sx, i, 2, 1, '#f2f0e8');
      }
      addOutline(ctx, '#5c5a52');
      return true;
    }
    r(3, 3, 10, 10, col);
    r(4, 2, 8, 12, col);
    r(5, 4, 4, 4, shadeHex(col, 36));
    r(6, 9, 5, 3, shadeHex(col, -25));
    if (n === 'nautilus_shell') { r(6, 6, 4, 4, '#9e4c36'); }
    addOutline(ctx, shadeHex(col, -85));
    return true;
  }

  if (n === 'ominous_banner' || n === 'piglin_banner') {
    r(4, 1, 8, 13, col);
    r(5, 2, 6, 10, shadeHex(col, 24));
    r(6, 4, 4, 4, '#dcd8c8');
    r(7, 5, 2, 2, '#242428');
    addOutline(ctx, '#1f1c18');
    return true;
  }

  if (n === 'item_frame') {
    r(2, 2, 12, 12, '#b88548');
    r(4, 4, 8, 8, '#7a4824');
    r(5, 5, 6, 6, '#945a30');
    addOutline(ctx, '#38220f');
    return true;
  }
  if (n === 'painting' || n === 'sign') {
    r(2, 2, 12, 9, '#9c7240');
    r(3, 3, 10, 7, n === 'painting' ? '#5894c9' : '#c4965a');
    if (n === 'painting') { r(3, 7, 10, 3, '#5ea142'); r(8, 4, 2, 2, '#ffd84a'); }
    if (n === 'sign') { r(7, 11, 2, 4, '#6e4e28'); }
    addOutline(ctx, '#382510');
    return true;
  }

  if (n === "ender_pearl" || n === "ender_eye") {
    r(4, 3, 8, 10, "#175a4e"); r(3, 4, 10, 8, "#175a4e");
    r(4, 4, 8, 8, "#277d6d"); r(5, 4, 6, 7, "#38a18e"); r(5, 4, 3, 3, "#88f2db");
    if (n === "ender_eye") {
      r(5, 5, 6, 6, "#45c954"); r(6, 6, 4, 4, "#85ff8e"); r(7, 5, 2, 6, "#112e17"); r(6, 5, 1, 1, "#ffffff");
    }
    addOutline(ctx, "#08241f");
    return true;
  }
  if (n === "blaze_rod") {
    for (let i = 0; i < 11; i++) { r(2 + i, 12 - i, 3, 2, "#d96b12"); r(2 + i, 12 - i, 2, 1, "#ffcf3b"); }
    r(4, 10, 1, 1, "#ffffff"); r(9, 5, 1, 1, "#ffffff");
    addOutline(ctx, "#4a1c04");
    return true;
  }
  if (n === "ghast_tear") {
    r(7, 2, 2, 3, "#d2eef2"); r(6, 5, 4, 4, "#eafafb"); r(5, 8, 6, 5, "#bde2e8"); r(6, 8, 2, 3, "#ffffff");
    addOutline(ctx, "#3d5c63");
    return true;
  }
  if (n === "netherite_scrap") {
    r(3, 4, 10, 8, "#5e433c"); r(4, 3, 8, 10, "#4d352f");
    r(5, 5, 6, 2, "#8c695e"); r(4, 8, 7, 2, "#75554c"); r(5, 11, 5, 1, "#8c695e");
    addOutline(ctx, "#241614");
    return true;
  }
  if (n === "elytra") {
    r(2, 3, 5, 10, "#75708a"); r(9, 3, 5, 10, "#75708a");
    r(3, 4, 3, 8, "#9690b0"); r(10, 4, 3, 8, "#9690b0");
    r(6, 2, 4, 4, "#4a4659"); r(4, 3, 2, 2, "#bab4d4"); r(10, 3, 2, 2, "#bab4d4");
    addOutline(ctx, "#23202b");
    return true;
  }
  if (n === "firework_rocket") {
    r(6, 1, 4, 2, "#c92a22"); r(5, 3, 6, 2, "#e63b30");
    r(5, 5, 6, 7, "#f2eee4"); r(5, 6, 6, 2, "#e63b30"); r(5, 10, 6, 2, "#e63b30");
    r(7, 12, 2, 3, "#8c6538");
    addOutline(ctx, "#2e1c12");
    return true;
  }
  if (n === "end_crystal") {
    r(4, 2, 8, 8, "#eb73eb"); r(5, 3, 6, 6, "#ffb8ff"); r(6, 4, 4, 4, "#ffffff");
    r(3, 11, 10, 3, "#3b3247"); r(5, 10, 6, 2, "#5e5270");
    addOutline(ctx, "#211329");
    return true;
  }
  if (n === "shulker_shell") {
    r(3, 4, 10, 8, "#8c5691"); r(4, 3, 8, 8, "#a66cab"); r(5, 4, 6, 4, "#c993cf");
    addOutline(ctx, "#361c38");
    return true;
  }
  if (n === "flint_and_steel") {
    r(2, 5, 6, 7, "#4d5250"); r(3, 6, 4, 5, "#6e7573");
    r(8, 2, 5, 9, "#cfd6d4"); r(9, 3, 3, 6, "#ffffff");
    addOutline(ctx, "#1c1f1e");
    return true;
  }
  if (n === "shears") {
    r(2, 9, 5, 5, "#8c5230"); r(8, 9, 5, 5, "#8c5230");
    r(5, 2, 3, 7, "#cfd6d4"); r(8, 3, 3, 6, "#b8c2bf"); r(6, 2, 1, 5, "#ffffff");
    addOutline(ctx, "#242928");
    return true;
  }
  if (n === "nether_star") {
    r(7, 1, 2, 14, "#d9f7ff"); r(1, 7, 14, 2, "#d9f7ff");
    r(4, 4, 8, 8, "#b8e2f2"); r(5, 5, 6, 6, "#ffffff");
    addOutline(ctx, "#2e4659");
    return true;
  }
  if (n.startsWith("music_disc_")) {
    r(4, 2, 8, 12, "#22252a"); r(2, 4, 12, 8, "#22252a"); r(3, 3, 10, 10, "#2f333b");
    r(4, 4, 4, 2, "#4f5663"); r(8, 10, 4, 2, "#4f5663");
    r(5, 5, 6, 6, col); r(6, 6, 4, 4, shadeHex(col, 35)); r(7, 7, 2, 2, "#14161a");
    addOutline(ctx, "#0e1014");
    return true;
  }
  if (n === "brush") {
    for (let i = 0; i < 6; i++) r(2 + i, 12 - i, 2, 2, "#8c5c32");
    r(7, 6, 3, 3, "#cf8254");
    r(9, 2, 5, 5, "#f2efe4"); r(10, 3, 3, 3, "#ffffff");
    addOutline(ctx, "#2b1c0e");
    return true;
  }
  if (n === "shield") {
    r(3, 1, 10, 11, "#9c703e"); r(4, 12, 8, 2, "#855d30"); r(6, 14, 4, 1, "#6e4b24");
    r(3, 1, 10, 1, "#c4cccf"); r(3, 1, 1, 11, "#c4cccf"); r(12, 1, 1, 11, "#879094");
    r(7, 5, 2, 5, "#d8e0e3");
    addOutline(ctx, "#24190c");
    return true;
  }
  if (n === "crossbow") {
    for (let i = 3; i < 13; i++) r(i, i, 2, 2, "#75522d");
    r(2, 6, 2, 6, "#9c7142"); r(6, 2, 6, 2, "#9c7142");
    r(3, 3, 8, 1, "#e0dcd0"); r(3, 3, 1, 8, "#e0dcd0");
    r(6, 6, 3, 3, "#9ea8ab");
    addOutline(ctx, "#26190c");
    return true;
  }
  if (n === "trident") {
    for (let i = 3; i < 14; i++) r(15 - i, i, 2, 1, "#3b8c82");
    r(9, 1, 2, 5, "#7af0e0"); r(11, 2, 2, 4, "#a8fff5"); r(13, 4, 2, 3, "#7af0e0");
    r(9, 5, 5, 2, "#52b8ab");
    addOutline(ctx, "#143b36");
    return true;
  }
  if (n === "mace") {
    for (let i = 2; i < 9; i++) r(i, 14 - i, 2, 2, "#6e7885");
    r(7, 2, 7, 7, "#585b69"); r(8, 3, 5, 5, "#878b9c"); r(9, 3, 2, 2, "#dce0ed");
    addOutline(ctx, "#1e2029");
    return true;
  }
  if (n === "heavy_core") {
    r(3, 4, 10, 9, "#4d505e"); r(4, 3, 8, 10, "#666a7a");
    r(5, 4, 6, 3, "#999fb2"); r(6, 7, 4, 3, "#2b2d36");
    addOutline(ctx, "#1a1b21");
    return true;
  }
  if (n === "totem_of_undying") {
    r(5, 2, 6, 5, "#ebb844"); r(2, 6, 12, 3, "#f5cc58"); r(5, 9, 6, 5, "#cfa032");
    r(6, 4, 1, 1, "#2bc958"); r(9, 4, 1, 1, "#2bc958"); r(7, 5, 2, 2, "#a67b24");
    addOutline(ctx, "#4a3309");
    return true;
  }
  if (n === "boat") {
    r(2, 6, 12, 6, "#b58448"); r(3, 10, 10, 3, "#8a6232"); r(4, 7, 8, 3, "#6b4a22");
    r(5, 4, 2, 5, "#d4a462"); r(9, 4, 2, 5, "#d4a462"); // Paddles
    addOutline(ctx, "#33210d");
    return true;
  }
  if (n === "saddle") {
    r(3, 4, 10, 7, "#9e5c34"); r(4, 3, 8, 7, "#bd7244"); r(5, 4, 6, 3, "#d48858");
    r(6, 10, 4, 4, "#7a4424"); r(7, 13, 2, 2, "#c2cccc");
    addOutline(ctx, "#381c0c");
    return true;
  }
  if (n === "lead") {
    r(3, 3, 9, 9, "#b8905c"); r(5, 5, 5, 5, "#6b5030");
    r(10, 10, 4, 4, "#d4ae76");
    addOutline(ctx, "#382815");
    return true;
  }
  if (n === "sculk") {
    r(3, 3, 10, 10, "#0b222b"); r(5, 4, 2, 2, "#2cd8e8"); r(9, 7, 2, 2, "#2cd8e8"); r(6, 10, 3, 2, "#197a8a");
    addOutline(ctx, "#051014");
    return true;
  }
  return false;
}
