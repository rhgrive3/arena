import * as THREE from "three";
import { GEO, M, type UnitKind } from "./units";

/* ============================================================
   Shared sculpting kit for the character rigs: colour helpers,
   the material palette and the `part()` primitive placer.
   ============================================================ */

export type HumanKind = Exclude<UnitKind, "knight" | "robot" | "tank" | "railgun" | "catapult" | "hwacha" | "mammoth" | "snake">;

export const PI = Math.PI;
export const dark = (c: number, f = 0.55) => new THREE.Color(c).multiplyScalar(f).getHex();
export const light = (c: number, f = 0.35) => new THREE.Color(c).lerp(new THREE.Color(0xffffff), f).getHex();
const bCache = new Map<number, THREE.MeshBasicMaterial>();
/** Unlit material (eyes, glows, deep shadow). */
export const B = (c: number) => {
  let m = bCache.get(c);
  if (!m) { m = new THREE.MeshBasicMaterial({ color: c }); bCache.set(c, m); }
  return m;
};
export const STEEL = 0xaab3c2, STEEL_LIGHT = 0xdce3ed, STEEL_DARK = 0x5c6472, IRON = 0x434954;
export const GOLD = 0xe0b04a, GOLD_LIGHT = 0xf5d478, BRASS = 0xb88a3e, COPPER = 0xc87442;
export const LEATHER = 0x523a24, LEATHER_DARK = 0x2f2114, BONE = 0xe8e0c8, BONE_DARK = 0xc7bea2;
export const steel = (c = STEEL) => M(c, 0.32, 0.82);
export const gold = (c = GOLD) => M(c, 0.28, 0.85);
export const leather = (c = LEATHER) => M(c, 0.78, 0.08);
export const cloth = (c: number) => M(c, 0.88, 0.04);
export const boneMat = (c = BONE) => M(c, 0.68, 0.06);
/* Finer material grades used by the wardrobe. The baker sorts anything with metalness >= 0.3 into the
   reflective batch, so these stay on the right side of that line while still reading differently. */
/** Polished plate: brighter, sharper highlight than field steel. */
export const plateMat = (c = STEEL_LIGHT) => M(c, 0.22, 0.9);
/** Blackened or oiled iron: metallic but matte. */
export const ironMat = (c = IRON) => M(c, 0.55, 0.7);
/** Burnished gold for jewellery and fine trim. */
export const gildMat = (c = GOLD_LIGHT) => M(c, 0.18, 0.95);
/** Lacquer: hard, glossy, non-metallic. */
export const lacquer = (c: number) => M(c, 0.18, 0.12);
/** Waxed leather: slightly glossier than harness leather. */
export const waxLeather = (c = LEATHER) => M(c, 0.58, 0.1);
/** Rough hide and fur. */
export const hide = (c: number) => M(c, 0.96, 0.02);
/** Heavy wool: fully matte. */
export const wool = (c: number) => M(c, 0.98, 0.0);
/** Silk and satin: soft sheen. */
export const silk = (c: number) => M(c, 0.55, 0.06);
/** Horn, bone, ivory. */
export const horn = (c: number) => M(c, 0.5, 0.08);

/**
 * Chooses the form of a block from its proportions, so nothing on a unit is a raw cube:
 * rods become pills, plates keep crisp chamfered edges, and chunky volumes become soft rounded blocks.
 */
export function sculpt(sx: number, sy: number, sz: number): THREE.BufferGeometry {
  const dims = [sx, sy, sz];
  const hi = Math.max(sx, sy, sz), lo = Math.min(sx, sy, sz);
  const mid = sx + sy + sz - hi - lo;
  if (hi < 0.09) return GEO.box;
  if (lo < 0.07 || lo < mid * 0.34) {
    // Square slabs lying flat (headbands, hat brims, bases) are discs; other plates keep crisp chamfers.
    if (lo === sy && sy >= 0.03 && hi <= mid * 1.25 && hi >= 0.3) return GEO.pillY;
    return lo >= 0.03 ? GEO.bevel : GEO.box;
  }
  if (hi >= mid * 1.7 && mid <= lo * 1.7) return [GEO.pillX, GEO.pillY, GEO.pillZ][dims.indexOf(hi)];
  return GEO.soft;
}

export function part(
  parent: THREE.Object3D, geo: THREE.BufferGeometry, mat: THREE.Material,
  sx: number, sy: number, sz: number, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0,
): THREE.Mesh {
  if (geo === GEO.box) {
    // Long flat bars of steel are blades: give them a ridge and a point instead of a slab.
    const metal = (mat as THREE.MeshStandardMaterial).metalness > 0.5;
    const wide = Math.max(sx, sy), thin = Math.min(sx, sy);
    if (metal && sz >= wide * 3.2 && thin <= wide * 0.6 && sz >= 0.45) { geo = GEO.blade; if (sx < sy) sx *= 1.5; else sy *= 1.5; }
    else geo = sculpt(sx, sy, sz);
  }
  const m = new THREE.Mesh(geo, mat);
  m.scale.set(sx, sy, sz);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  parent.add(m);
  return m;
}
