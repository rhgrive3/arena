import * as THREE from "three";
import { GEO, M } from "./units";
import {
  B, BRASS, COPPER, GOLD, LEATHER, LEATHER_DARK, PI, STEEL_DARK, STEEL_LIGHT,
  boneMat, cloth, dark, gildMat, gold, hide, horn, ironMat, lacquer, leather, light, part, plateMat, silk, steel, waxLeather, wool,
  type HumanKind,
} from "./rig-kit";

/* ============================================================
   Wardrobe: clothing, armour and gear layered over the base body.
   Everything here is authored in the local space of a bone
   (torso, upper arm, thigh or shin) so it follows the animation.
   The face is never touched: head accessories stay on the crown,
   the sides and the back of the head.
   ============================================================ */

type G = THREE.Group;
type Mat = THREE.Material;

/** Two light primitives for small hardware, so studs and hoops do not cost a full sphere or torus each. */
const KIT = {
  stud: new THREE.SphereGeometry(1, 7, 4),
  hoop: new THREE.TorusGeometry(1, 0.06, 5, 12),
  arc: new THREE.TorusGeometry(1, 0.08, 5, 10, PI),
};

export interface Wardrobe {
  torso: G; lArm: G; rArm: G; shins: G[]; thighs: G[]; cloak: G | null;
  cw: number; ww: number; legs: number; tc: number; tcd: number; tcl: number; skin: number; armor: number;
  skel: boolean; armored: boolean;
}

/* ---------- tailoring primitives ---------- */

/** Horizontal band around a limb or the waist (r = radius). */
const band = (g: G, mat: Mat, r: number, y: number, h = 0.045, z = 0, rz = r) => part(g, GEO.pillY, mat, r * 2, h, rz * 2.06, 0, y, z);
/** Thin hoop lying flat: piping, hems, metal rims. */
const hoop = (g: G, mat: Mat, r: number, y: number, tube = 0.02, z = 0, rz = r, x = 0) => part(g, KIT.hoop, mat, r, rz, tube / 0.06, x, y, z, PI / 2, 0, 0);
/** Flattened stud facing +Z (rotate with ry to face sideways). */
const stud = (g: G, mat: Mat, r: number, x: number, y: number, z: number, ry = 0, rx = 0) => part(g, KIT.stud, mat, r, r, r * 0.6, x, y, z, rx, ry, 0);
/** Chamfered plate. */
const plate = (g: G, mat: Mat, w: number, h: number, d: number, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0) => part(g, GEO.bevel, mat, w, h, d, x, y, z, rx, ry, rz);
/** Waist belt sized to the torso, with an optional buckle. */
function waistBelt(w: Wardrobe, mat: Mat, y: number, h: number, grow = 0.02, buckle?: Mat, buckleW = 0.12) {
  part(w.torso, GEO.pillY, mat, w.ww + 0.06 + grow, h, w.cw * 0.65 + grow, 0, y, 0);
  if (buckle) {
    const z = w.cw * 0.325 + grow / 2 + 0.02;
    plate(w.torso, buckle, buckleW, h * 0.9, 0.03, 0, y, z);
    plate(w.torso, buckle, buckleW * 0.3, h * 0.55, 0.035, 0, y, z + 0.01);
  }
}
/** Soft pouch with a flap and a stud. */
function pouch(g: G, x: number, y: number, z: number, w: number, h: number, d: number, body: Mat, flap: Mat, pin: Mat, ry = 0) {
  const m = new THREE.Group(); m.position.set(x, y, z); m.rotation.y = ry; g.add(m);
  part(m, GEO.soft, body, w, h, d, 0, 0, 0);
  plate(m, flap, w * 1.04, h * 0.42, d * 1.08, 0, h * 0.3, 0.002);
  stud(m, pin, 0.016, 0, h * 0.1, d * 0.52);
  // The pouch is a helper group; bake() only reads meshes directly under bones, so move the meshes up.
  flatten(m, g);
}
/** Re-parents a helper group's meshes into the bone with their transforms applied. */
function flatten(tmp: G, bone: G) {
  tmp.updateMatrix();
  for (const c of [...tmp.children]) {
    if (c instanceof THREE.Mesh) {
      c.updateMatrix();
      c.matrix.premultiply(tmp.matrix);
      c.matrix.decompose(c.position, c.quaternion, c.scale);
      bone.add(c);
    }
  }
  bone.remove(tmp);
}
/** Row of studs along a line. */
function rivets(g: G, mat: Mat, from: [number, number, number], to: [number, number, number], n: number, r = 0.016, ry = 0) {
  for (let i = 0; i < n; i++) {
    const t = n === 1 ? 0.5 : i / (n - 1);
    stud(g, mat, r, from[0] + (to[0] - from[0]) * t, from[1] + (to[1] - from[1]) * t, from[2] + (to[2] - from[2]) * t, ry);
  }
}
/** Studs around part of a horizontal ellipse (a0..a1 in radians, 0 = +Z front). */
function rivetRing(g: G, mat: Mat, rx: number, rz: number, y: number, n: number, a0 = 0.9, a1 = PI * 2 - 0.9, r = 0.016) {
  for (let i = 0; i < n; i++) {
    const a = a0 + (a1 - a0) * (n === 1 ? 0.5 : i / (n - 1));
    stud(g, mat, r, Math.sin(a) * rx, y, Math.cos(a) * rz, a);
  }
}
/** Hanging fringe / tassels. */
function fringe(g: G, mat: Mat, n: number, x0: number, x1: number, y: number, z: number, len: number, rx = 0) {
  for (let i = 0; i < n; i++) {
    const x = n === 1 ? (x0 + x1) / 2 : x0 + ((x1 - x0) * i) / (n - 1);
    part(g, GEO.cone, mat, 0.03, len, 0.03, x, y - len / 2, z, PI + rx, 0, 0);
  }
}
/** String of beads across the chest front. */
function necklace(g: G, mat: Mat, cw: number, n: number, y: number, sag: number, halfW: number, r = 0.02, pendant?: { mat: Mat; r: number }) {
  for (let i = 0; i < n; i++) {
    const u = n === 1 ? 0 : (i / (n - 1)) * 2 - 1;
    stud(g, mat, r, u * halfW, y - (1 - u * u) * sag, cw * 0.33 + 0.012 + Math.abs(u) * 0.005, u * 0.4);
  }
  if (pendant) part(g, GEO.cone, pendant.mat, pendant.r, pendant.r * 1.7, pendant.r * 0.6, 0, y - sag - pendant.r * 1.1, cw * 0.33 + 0.02, PI, 0, 0);
}
/** Standing collar around the neck. */
const collar = (g: G, mat: Mat, r = 0.15, y = 0.91, h = 0.1, z = -0.01) => part(g, GEO.cyl, mat, r, h, r * 1.05, 0, y, z);
/** Cloak lining and shoulder clasps. */
function cloakFinish(w: Wardrobe, lining: Mat, clasp: Mat, chain = true) {
  if (!w.cloak) return;
  const sheet = w.cloak.children.find(c => c instanceof THREE.Mesh) as THREE.Mesh | undefined;
  if (sheet && sheet.geometry === GEO.cape) part(w.cloak, GEO.cape, lining, sheet.scale.x * 0.94, sheet.scale.y * 0.97, 0.04, 0, sheet.position.y + sheet.scale.y * 0.01, -0.012);
  for (const sd of [-1, 1]) stud(w.torso, clasp, 0.035, sd * w.cw * 0.36, 0.86, w.cw * 0.2, sd * 0.5);
  if (chain) part(w.torso, KIT.arc, clasp, w.cw * 0.36, 0.08, 0.3, 0, 0.84, w.cw * 0.32, 0, 0, PI);
}
/** Hanging sheathed blade on the hip. */
function scabbard(g: G, side: number, body: Mat, trim: Mat, len: number, x: number, y: number, z: number, lean = 0.35) {
  const s = new THREE.Group(); s.position.set(x, y, z); s.rotation.set(-lean, 0, side * 0.1); g.add(s);
  part(s, GEO.pillY, body, 0.06, len, 0.085, 0, -len / 2, 0);
  band(s, trim, 0.035, -0.05, 0.05, 0, 0.047);
  band(s, trim, 0.034, -len * 0.55, 0.035, 0, 0.046);
  part(s, GEO.cone, trim, 0.035, 0.08, 0.045, 0, -len - 0.03, 0, PI, 0, 0);
  flatten(s, g);
}
/** Layered pauldron on an upper arm: cap, rim and lames stepping down the outside. */
function pauldron(a: G, side: number, mat: Mat, trim: Mat, r = 0.2, lames = 2, opts: { spike?: Mat; studs?: boolean; flat?: number } = {}) {
  const flat = opts.flat ?? 0.62;
  part(a, GEO.dome, mat, r, r * flat, r * 1.04, side * 0.015, 0.03, 0);
  hoop(a, trim, r * 0.99, 0.035, 0.03, 0, r * 1.03, side * 0.015);
  for (let k = 0; k < lames; k++) {
    const lr = r * (1.02 - k * 0.06);
    // Each lame is a curved half-band: a flattened pill hugging the outer side of the arm.
    part(a, GEO.pillY, mat, lr * 1.1, 0.06, lr * 2.0, side * (lr * 0.45), -0.03 - k * 0.07, 0, 0, 0, -side * (0.08 + k * 0.08));
  }
  if (opts.spike) part(a, GEO.cone, opts.spike, 0.05, 0.2, 0.05, side * r * 0.5, 0.03 + r * flat * 0.9, 0, 0, 0, -side * 0.4);
  if (opts.studs) for (let i = 0; i < 3; i++) stud(a, trim, 0.016, side * r * 0.72, 0.09 - i * 0.03, (i - 1) * r * 0.55, side * PI / 2);
}
/** Forearm protection in three styles. */
function bracer(a: G, side: number, style: "leather" | "plate" | "wrap" | "splint", mat: Mat, trim: Mat, lace?: Mat) {
  if (style === "plate") {
    part(a, GEO.softer, mat, 0.21, 0.27, 0.3, side * 0.02, -0.52, 0.0);
    part(a, GEO.blade, trim, 0.035, 0.02, 0.22, side * 0.12, -0.5, 0, PI / 2, 0, 0);
    band(a, trim, 0.125, -0.4, 0.03);
    band(a, trim, 0.145, -0.64, 0.035);
  } else if (style === "leather") {
    part(a, GEO.pillY, mat, 0.26, 0.2, 0.28, 0, -0.52, 0);
    band(a, trim, 0.135, -0.43, 0.025);
    band(a, trim, 0.14, -0.61, 0.025);
    if (lace) for (let k = 0; k < 3; k++) part(a, GEO.pillX, lace, 0.1, 0.016, 0.018, side * 0.13, -0.46 - k * 0.055, 0, 0, side * PI / 2, k % 2 ? 0.5 : -0.5);
  } else if (style === "splint") {
    band(a, mat, 0.135, -0.52, 0.2);
    for (let i = 0; i < 4; i++) {
      const ang = -0.5 + i * 0.55;
      plate(a, trim, 0.03, 0.2, 0.032, side * Math.sin(ang + PI / 2) * 0.135, -0.52, Math.cos(ang + PI / 2) * 0.135, 0, ang + PI / 2, 0);
    }
  } else {
    for (let k = 0; k < 4; k++) band(a, k % 2 ? mat : trim, 0.13 + k * 0.003, -0.44 - k * 0.055, 0.045);
  }
}
/** Shin protection. */
function greave(sh: G, legs: number, mat: Mat, trim: Mat, opts: { ridge?: boolean; knee?: boolean; studs?: boolean } = {}) {
  part(sh, GEO.softer, mat, 0.24, 0.34 * legs, 0.2, 0, -0.2 * legs, 0.045);
  if (opts.ridge) part(sh, GEO.blade, trim, 0.035, 0.03, 0.28 * legs, 0, -0.2 * legs, 0.15, PI / 2, 0, 0);
  if (opts.knee) part(sh, GEO.dome, mat, 0.1, 0.07, 0.1, 0, -0.01, 0.1, PI / 2, 0, 0);
  if (opts.studs) for (const sd of [-1, 1]) rivets(sh, trim, [sd * 0.1, -0.08 * legs, 0.08], [sd * 0.09, -0.3 * legs, 0.08], 3, 0.014, sd * 0.6);
  band(sh, trim, 0.13, -0.37 * legs, 0.035);
}
/** Plates hanging over the thigh (follow the leg). */
function thighGuard(th: G, side: number, legs: number, mat: Mat, trim: Mat, r = 0.144, studs = true) {
  plate(th, mat, 0.2, 0.26, 0.035, side * 0.02, -0.2 * legs, r + 0.02, -0.1, 0, side * 0.05);
  plate(th, mat, 0.035, 0.24, 0.2, side * (r + 0.02), -0.22 * legs, 0.01, 0, 0, side * 0.08);
  hoop(th, trim, r + 0.035, -0.06 * legs, 0.025);
  if (studs) { stud(th, trim, 0.018, side * 0.02, -0.1 * legs, r + 0.045); stud(th, trim, 0.018, side * (r + 0.045), -0.12 * legs, 0.01, side * PI / 2); }
}
/** Boot top: folded cuff, strap and buckle. */
function bootCuff(sh: G, legs: number, mat: Mat, strapM: Mat, buckle?: Mat, h = 0.1, r = 0.165) {
  band(sh, mat, r, -0.27 * legs, h);
  band(sh, strapM, r - 0.01, -0.27 * legs + h * 0.1, 0.03);
  if (buckle) plate(sh, buckle, 0.045, 0.045, 0.02, r * 0.8, -0.27 * legs + h * 0.1, r * 0.55, 0, 0.6, 0);
}
/** Cloth wraps up a shin. */
function legWraps(sh: G, legs: number, a: Mat, b: Mat, n = 4, r = 0.14) {
  for (let k = 0; k < n; k++) band(sh, k % 2 ? a : b, r + k * 0.004, -0.04 * legs - k * 0.06 * legs, 0.05);
}
/** Front tabard panel hanging from the chest past the belt. */
function tabard(w: Wardrobe, mat: Mat, trim: Mat, width = 0.5, top = 0.74, len = 1.05, back = true) {
  const { torso, cw } = w;
  part(torso, GEO.cape, mat, cw * width, len, 0.04, 0, top - len / 2, cw * 0.34 + 0.015, 0, PI, 0);
  part(torso, GEO.cape, trim, cw * width * 1.03, len * 1.02, 0.03, 0, top - len / 2 - 0.012, cw * 0.34 + 0.005, 0, PI, 0);
  if (back) part(torso, GEO.cape, mat, cw * width, len * 0.95, 0.04, 0, top - len * 0.475, -cw * 0.34 - 0.015);
}
/** Overlapping horizontal lames at the waist (fauld). */
function fauld(w: Wardrobe, mat: Mat, trim: Mat, n = 3, y0 = -0.02) {
  const { torso, ww, cw } = w;
  for (let k = 0; k < n; k++) {
    const r = ww * 0.5 + 0.045 + k * 0.022;
    band(torso, mat, r, y0 - k * 0.065, 0.065, 0, cw * 0.325 + 0.03 + k * 0.02);
  }
  hoop(torso, trim, ww * 0.5 + 0.05 + n * 0.02, y0 - n * 0.065 + 0.01, 0.022, 0, cw * 0.325 + 0.04 + n * 0.02);
}
/** Quilted gambeson rows across the torso. */
function quilting(w: Wardrobe, mat: Mat, y0: number, y1: number, n: number) {
  const { torso, cw } = w;
  for (let k = 0; k < n; k++) {
    const y = y0 + ((y1 - y0) * k) / (n - 1);
    part(torso, GEO.pillX, mat, cw * 0.9, 0.025, 0.02, 0, y, cw * 0.325);
  }
}
/** Mail: a dull iron sheet with a hoop hem. */
const mail = () => ironMat(0x5a6068);

/* ============================================================ */

export function dressUp(kind: HumanKind, w: Wardrobe) {
  const { torso, lArm, rArm, shins, thighs, cw, ww, legs, tc, tcd, tcl } = w;
  const arms: [G, G] = [lArm, rArm];
  const sides = [1, -1] as const;
  const depth = cw * 0.6;
  const front = cw * 0.325;

  switch (kind) {
    /* ================= KINGDOM ================= */
    case "spear": {
      // Line infantry: quilted gambeson under a breastplate, mail skirt, issue boots.
      const pad = cloth(dark(tc, 0.5));
      quilting(w, cloth(dark(tc, 0.4)), 0.26, 0.4, 3);
      part(torso, GEO.robe, mail(), ww * 0.76, 0.34, depth * 0.72, 0, -0.12, 0);
      hoop(torso, ironMat(0x7a8088), ww * 0.74, -0.29, 0.025, 0, depth * 0.72);
      waistBelt(w, leather(), 0.04, 0.1, 0.03, steel(STEEL_LIGHT), 0.11);
      pouch(torso, -ww * 0.46, -0.04, depth * 0.3, 0.12, 0.14, 0.09, leather(), leather(LEATHER_DARK), gold(BRASS), 0.3);
      scabbard(torso, 1, leather(LEATHER_DARK), steel(STEEL_DARK), 0.42, ww * 0.5 + 0.03, -0.02, -0.04, 0.5);
      part(torso, GEO.pillY, cloth(0xd8cfb0), 0.07, 0.16, 0.07, ww * 0.3, -0.06, -depth * 0.52, 0.3, 0, 0); // water flask
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        pauldron(a, side, steel(0x9aa3b2), steel(STEEL_DARK), 0.19, 1);
        for (let k = 0; k < 3; k++) band(a, pad, 0.128 - k * 0.006, -0.16 - k * 0.07, 0.035);
        bracer(a, side, "leather", leather(), leather(LEATHER_DARK), cloth(0xd9c79a));
      }
      for (const sh of shins) { legWraps(sh, legs, cloth(0x3a3f4a), cloth(0x444a56), 3, 0.135); bootCuff(sh, legs, leather(0x2a2219), leather(LEATHER_DARK), gold(BRASS)); }
      cloakFinish(w, cloth(tcl), steel(STEEL_LIGHT), false);
      break;
    }
    case "guardian": {
      // Heavy infantry: full harness, every joint covered, nothing left to chance.
      const pl = plateMat(0xb9c1ce), tr = gold(BRASS), dk = steel(STEEL_DARK);
      part(torso, GEO.robe, cloth(tcd), ww * 0.8, 0.42, depth * 0.74, 0, -0.15, 0);
      fauld(w, pl, tr, 3, 0.0);
      part(torso, GEO.pillY, pl, 0.34, 0.12, 0.32, 0, 0.9, 0); // gorget
      hoop(torso, tr, 0.17, 0.95, 0.025);
      part(torso, GEO.blade, pl, 0.07, 0.06, 0.46, 0, 0.5, front + 0.02, PI / 2, 0, 0); // breastplate ridge
      plate(torso, pl, cw * 0.9, 0.16, 0.05, 0, 0.3, front - 0.01, 0.1); // plackart
      for (const sd of sides) rivets(torso, tr, [sd * cw * 0.4, 0.74, front - 0.01], [sd * cw * 0.4, 0.36, front + 0.005], 4);
      waistBelt(w, waxLeather(LEATHER_DARK), 0.08, 0.08, 0.06, tr, 0.14);
      // Back plate with two straps and a heavy buckle.
      plate(torso, pl, cw * 0.86, 0.5, 0.05, 0, 0.5, -front - 0.02);
      for (const sd of sides) plate(torso, waxLeather(LEATHER_DARK), 0.06, 0.6, 0.03, sd * 0.1, 0.5, -front - 0.05, 0, 0, sd * 0.5);
      stud(torso, tr, 0.03, 0, 0.5, -front - 0.07, PI);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        pauldron(a, side, pl, tr, 0.24, 3, { studs: true });
        band(a, dk, 0.135, -0.22, 0.05);
        part(a, GEO.cone, pl, 0.08, 0.16, 0.04, side * 0.13, -0.39, -0.02, 0, 0, -side * PI / 2); // couter wing
        bracer(a, side, "plate", pl, tr);
        band(a, dk, 0.15, -0.68, 0.05);
      }
      for (const [i, th] of thighs.entries()) thighGuard(th, i === 0 ? 1 : -1, legs, pl, tr);
      for (const sh of shins) greave(sh, legs, pl, tr, { ridge: true, knee: true });
      cloakFinish(w, cloth(light(tcd, 0.12)), tr);
      break;
    }
    case "archer": {
      // Ranger: laced jerkin, hood thrown back, bracer on the bow arm, quiver belt across the chest.
      const jerk = waxLeather(0x5a4530), dkL = leather(LEATHER_DARK), lace = cloth(0xd9c79a);
      part(torso, GEO.robe, cloth(0x4a3b28), ww * 0.78, 0.36, depth * 0.74, 0, -0.13, 0);
      hoop(torso, cloth(0x3a2e20), ww * 0.74, -0.3, 0.02, 0, depth * 0.72);
      plate(torso, jerk, cw * 0.8, 0.5, 0.04, 0, 0.5, front - 0.005);
      for (let k = 0; k < 4; k++) part(torso, GEO.pillX, lace, 0.09, 0.016, 0.02, 0, 0.34 + k * 0.1, front + 0.02, 0, 0, k % 2 ? 0.5 : -0.5);
      part(torso, GEO.dome, cloth(tcd), 0.22, 0.14, 0.2, 0, 0.84, -0.12, -0.5, 0, 0); // hood at the nape
      part(torso, GEO.pillY, dkL, 0.06, 0.74, 0.03, -cw * 0.08, 0.44, front + 0.005, 0, 0, 0.55); // quiver strap
      stud(torso, gold(BRASS), 0.03, -cw * 0.24, 0.66, front + 0.02);
      waistBelt(w, leather(), 0.04, 0.09, 0.025, gold(BRASS), 0.1);
      pouch(torso, ww * 0.44, -0.04, depth * 0.3, 0.12, 0.14, 0.09, leather(), dkL, gold(BRASS), -0.3);
      part(torso, GEO.pillY, cloth(0xd8cfb0), 0.08, 0.17, 0.08, -ww * 0.32, -0.06, -depth * 0.5, 0.2, 0, 0.2); // water skin
      scabbard(torso, -1, dkL, steel(STEEL_DARK), 0.26, -ww * 0.5 - 0.02, 0.0, 0.02, 0.3); // knife
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, cloth(0x5a4530), 0.13, -0.3, 0.07);
        if (i === 0) { part(a, GEO.pillY, jerk, 0.27, 0.26, 0.29, 0, -0.52, 0); band(a, dkL, 0.14, -0.42, 0.025); band(a, dkL, 0.145, -0.63, 0.025); for (let k = 0; k < 4; k++) part(a, GEO.pillX, lace, 0.1, 0.014, 0.016, side * 0.135, -0.44 - k * 0.05, 0, 0, side * PI / 2, k % 2 ? 0.5 : -0.5); }
        else { bracer(a, side, "wrap", leather(0x4a3826), leather(0x3a2c1c)); band(a, leather(0x3a2c1c), 0.11, -0.72, 0.04); }
        part(a, GEO.dome, jerk, 0.19, 0.1, 0.2, 0, -0.01, 0);
        hoop(a, dkL, 0.19, -0.005, 0.02, 0, 0.2);
      }
      for (const sh of shins) { legWraps(sh, legs, cloth(0x4a3b28), cloth(0x3f3222), 4, 0.135); bootCuff(sh, legs, leather(0x2a2016), dkL, undefined, 0.08, 0.16); }
      break;
    }
    case "crossbow": {
      // Arbalest: brigandine studded through cloth, quarrel case, spanning hook, pavise on the back.
      const brig = cloth(dark(tc, 0.6)), tr = gold(BRASS), dkL = leather(LEATHER_DARK);
      plate(torso, brig, cw * 0.98, 0.5, 0.05, 0, 0.5, 0);
      for (let r = 0; r < 4; r++) for (let c = -2; c <= 2; c++) stud(torso, tr, 0.015, c * cw * 0.17, 0.34 + r * 0.1, front + 0.02);
      part(torso, GEO.robe, cloth(0x353a44), ww * 0.8, 0.38, depth * 0.76, 0, -0.13, 0);
      hoop(torso, cloth(tcl), ww * 0.76, -0.31, 0.02, 0, depth * 0.74);
      part(torso, GEO.pillY, dkL, 0.07, 0.8, 0.03, cw * 0.1, 0.44, front + 0.005, 0, 0, -0.5); // bandolier
      for (let k = 0; k < 3; k++) stud(torso, steel(STEEL_LIGHT), 0.018, cw * 0.1 - (k - 1) * 0.14, 0.44 + (k - 1) * 0.22, front + 0.025);
      waistBelt(w, leather(), 0.04, 0.1, 0.03, steel(STEEL_LIGHT), 0.11);
      plate(torso, leather(0x3a2c1c), 0.13, 0.24, 0.12, ww * 0.46, -0.06, depth * 0.1, 0, 0, 0.1); // quarrel case
      for (let k = 0; k < 3; k++) part(torso, GEO.cyl, steel(), 0.012, 0.1, 0.012, ww * 0.46 + (k - 1) * 0.035, 0.08, depth * 0.1);
      part(torso, KIT.arc, steel(STEEL_DARK), 0.06, 0.06, 0.5, -ww * 0.46, -0.04, depth * 0.3, PI / 2, 0, PI); // spanning hook
      pouch(torso, -ww * 0.44, -0.04, depth * 0.1, 0.11, 0.13, 0.09, leather(), dkL, tr, 0.4);
      // Pavise strapped to the back.
      plate(torso, M(0x6b5636, 0.8), 0.46, 0.7, 0.06, 0, 0.42, -depth * 0.62);
      plate(torso, cloth(tc), 0.14, 0.62, 0.02, 0, 0.42, -depth * 0.62 - 0.035);
      plate(torso, steel(STEEL_DARK), 0.48, 0.06, 0.07, 0, 0.78, -depth * 0.62);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        part(a, GEO.dome, brig, 0.2, 0.11, 0.21, 0, 0.0, 0);
        rivetRing(a, tr, 0.17, 0.18, 0.02, 4, -2, 2, 0.014);
        band(a, cloth(0x353a44), 0.13, -0.3, 0.06);
        bracer(a, side, i === 0 ? "plate" : "leather", i === 0 ? steel(0x8b93a1) : leather(), i === 0 ? steel(STEEL_DARK) : dkL, cloth(0xd9c79a));
      }
      for (const sh of shins) bootCuff(sh, legs, leather(0x2a2219), dkL, steel(STEEL_LIGHT), 0.12, 0.17);
      break;
    }
    case "swordsman": {
      // Man-at-arms: half plate, sword belt with scabbard, asymmetric shoulders for the sword arm.
      const pl = steel(0x9aa3b2), hi = plateMat(0xc9d1dc), tr = gold(BRASS), dkL = waxLeather(LEATHER_DARK);
      part(torso, GEO.robe, cloth(tcd), ww * 0.78, 0.4, depth * 0.72, 0, -0.14, 0);
      fauld(w, pl, tr, 2, 0.0);
      plate(torso, hi, cw * 0.86, 0.14, 0.05, 0, 0.3, front - 0.005, 0.12);
      part(torso, GEO.blade, hi, 0.06, 0.05, 0.4, 0, 0.52, front + 0.015, PI / 2, 0, 0);
      for (const sd of sides) rivets(torso, tr, [sd * cw * 0.38, 0.7, front - 0.005], [sd * cw * 0.38, 0.4, front + 0.005], 3);
      waistBelt(w, dkL, 0.06, 0.08, 0.04, tr, 0.12);
      part(torso, GEO.pillY, dkL, 0.07, 0.3, 0.03, 0, 0.0, -front - 0.03, 0, 0, 1.1); // belt tail at the back
      scabbard(torso, 1, lacquer(0x1d1a22), hi, 0.86, ww * 0.5 + 0.04, 0.02, -0.08, 0.45);
      scabbard(torso, -1, dkL, steel(STEEL_DARK), 0.28, -ww * 0.5 - 0.02, 0.0, 0.06, 0.3);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        if (i === 0) pauldron(a, side, pl, tr, 0.22, 2, { studs: true });
        else { part(a, GEO.dome, pl, 0.19, 0.11, 0.2, 0, 0.02, 0); hoop(a, tr, 0.19, 0.02, 0.025, 0, 0.2); }
        band(a, cloth(tcd), 0.13, -0.22, 0.06);
        bracer(a, side, "plate", pl, tr);
      }
      for (const [i, th] of thighs.entries()) thighGuard(th, i === 0 ? 1 : -1, legs, pl, tr, 0.144, false);
      for (const sh of shins) greave(sh, legs, pl, tr, { ridge: true });
      break;
    }
    case "halberdier": {
      // Pike-and-halberd block: breastplate with plackart, tassets, a bedroll and tools on the back.
      const pl = steel(0x7f8896), hi = plateMat(0xaab3c0), tr = steel(STEEL_LIGHT);
      part(torso, GEO.robe, cloth(tcd), ww * 0.8, 0.4, depth * 0.74, 0, -0.14, 0);
      fauld(w, pl, tr, 3, 0.0);
      plate(torso, hi, cw * 0.92, 0.18, 0.05, 0, 0.28, front - 0.005, 0.14);
      for (let k = 0; k < 2; k++) plate(torso, hi, cw * 0.8 - k * 0.1, 0.1, 0.045, 0, 0.5 + k * 0.14, front, 0.05);
      for (const sd of sides) rivets(torso, tr, [sd * cw * 0.4, 0.72, front - 0.01], [sd * cw * 0.4, 0.34, front + 0.005], 4);
      waistBelt(w, waxLeather(LEATHER_DARK), 0.08, 0.08, 0.05, tr, 0.12);
      part(torso, GEO.pillX, wool(dark(tc, 0.75)), ww * 0.9, 0.15, 0.15, 0, 0.14, -depth * 0.6); // bedroll
      for (const sd of sides) band(torso, leather(LEATHER_DARK), 0.08, 0.14, 0.03, -depth * 0.6, 0.08) && plate(torso, leather(LEATHER_DARK), 0.04, 0.18, 0.16, sd * ww * 0.28, 0.14, -depth * 0.6);
      pouch(torso, -ww * 0.46, -0.03, depth * 0.2, 0.12, 0.15, 0.09, leather(), leather(LEATHER_DARK), tr, 0.4);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        pauldron(a, side, pl, tr, 0.23, 3);
        band(a, cloth(tcd), 0.13, -0.22, 0.06);
        bracer(a, side, "plate", pl, tr);
      }
      for (const [i, th] of thighs.entries()) thighGuard(th, i === 0 ? 1 : -1, legs, pl, tr);
      for (const sh of shins) greave(sh, legs, pl, tr, { knee: true });
      cloakFinish(w, cloth(light(tcd, 0.1)), tr, false);
      break;
    }
    case "paladin": {
      // Holy knight: white-and-gold harness under a tabard, every edge gilded, a book of vows at the belt.
      const pl = plateMat(0xe2e6ee), gd = gildMat(), tr = gold();
      part(torso, GEO.robe, cloth(tcd), ww * 0.8, 0.42, depth * 0.74, 0, -0.15, 0);
      fauld(w, pl, gd, 3, 0.0);
      tabard(w, silk(tc), gd, 0.46, 0.76, 1.0);
      // Sun emblem on the tabard.
      hoop(torso, gd, 0.11, 0.5, 0.03, front + 0.05, 0.11); 
      part(torso, KIT.hoop, gd, 0.11, 0.11, 0.5, 0, 0.5, front + 0.05);
      for (let i = 0; i < 8; i++) { const a = (i / 8) * PI * 2; part(torso, GEO.cone, gd, 0.02, 0.07, 0.015, Math.sin(a) * 0.15, 0.5 + Math.cos(a) * 0.15, front + 0.05, 0, 0, -a); }
      part(torso, GEO.pillY, pl, 0.34, 0.12, 0.32, 0, 0.9, 0);
      hoop(torso, gd, 0.17, 0.95, 0.025);
      waistBelt(w, silk(0xf4efe2), 0.08, 0.08, 0.06, gd, 0.14);
      plate(torso, waxLeather(0x5a2e2a), 0.1, 0.18, 0.14, -ww * 0.5, -0.04, 0.0, 0, 0, 0.1); // book
      plate(torso, gd, 0.11, 0.03, 0.15, -ww * 0.5, 0.04, 0.0);
      hoop(torso, gd, 0.028, 0.07, 0.012, 0.0, 0.028, -ww * 0.5);
      plate(torso, pl, cw * 0.86, 0.5, 0.05, 0, 0.5, -front - 0.02);
      for (const sd of sides) plate(torso, waxLeather(LEATHER_DARK), 0.06, 0.6, 0.03, sd * 0.1, 0.5, -front - 0.05, 0, 0, sd * 0.5);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        pauldron(a, side, pl, gd, 0.25, 3, { studs: true, flat: 0.7 });
        part(a, GEO.cone, gd, 0.05, 0.16, 0.03, side * 0.2, 0.12, -0.06, -0.3, 0, -side * 0.5); // gilt feather
        band(a, tr, 0.135, -0.22, 0.04);
        part(a, GEO.cone, pl, 0.08, 0.16, 0.04, side * 0.13, -0.39, -0.02, 0, 0, -side * PI / 2);
        bracer(a, side, "plate", pl, gd);
      }
      for (const [i, th] of thighs.entries()) thighGuard(th, i === 0 ? 1 : -1, legs, pl, gd);
      for (const sh of shins) greave(sh, legs, pl, gd, { ridge: true, knee: true });
      cloakFinish(w, silk(0xf4efe2), gd);
      break;
    }
    case "king": {
      // Monarch: brocade, ermine, a chain of office, gilded harness beneath the robe.
      const gd = gildMat(), vel = silk(0x8a2f3c), brocade = silk(0x6d2530);
      part(torso, GEO.robe, vel, ww * 0.86, 0.46, depth * 0.8, 0, -0.17, 0);
      hoop(torso, gd, ww * 0.84, -0.39, 0.03, 0, depth * 0.78);
      for (let i = 0; i < 6; i++) { const a = (i / 6) * PI * 2 + 0.3; plate(torso, gd, 0.05, 0.3, 0.02, Math.sin(a) * ww * 0.6, -0.2, Math.cos(a) * depth * 0.62, 0.1 * Math.cos(a), a, 0); }
      for (let k = 0; k < 3; k++) plate(torso, gd, 0.05, 0.5, 0.025, (k - 1) * cw * 0.26, 0.5, front + 0.01);
      plate(torso, brocade, cw * 0.9, 0.2, 0.04, 0, 0.26, front - 0.005);
      // Chain of office with a pendant.
      necklace(torso, gd, cw, 9, 0.7, 0.14, cw * 0.36, 0.024, { mat: gd, r: 0.05 });
      stud(torso, B(0xff4a5a), 0.028, 0, 0.5, front + 0.055);
      waistBelt(w, gd, 0.06, 0.09, 0.05, gd, 0.16);
      for (const sd of sides) stud(torso, B(0x4ad0ff), 0.02, sd * 0.14, 0.06, front + 0.05);
      plate(torso, gd, 0.07, 0.32, 0.03, 0, -0.12, front + 0.04); // belt tongue
      pouch(torso, ww * 0.46, -0.04, depth * 0.25, 0.12, 0.14, 0.09, silk(0x5a1620), gd, gd, -0.3);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        pauldron(a, side, gd, gildMat(GOLD), 0.23, 2, { flat: 0.68 });
        stud(a, B(0xff4a5a), 0.03, side * 0.12, 0.1, 0.12, side * 0.7);
        band(a, silk(0xf7f4eb), 0.14, -0.18, 0.08); // ermine sleeve
        for (let k = -1; k <= 1; k++) stud(a, B(0x1c1816), 0.012, side * 0.13, -0.18 + k * 0.03, k * 0.06, side * PI / 2);
        band(a, vel, 0.125, -0.3, 0.05);
        bracer(a, side, "plate", gd, gildMat(GOLD));
      }
      for (const [i, th] of thighs.entries()) thighGuard(th, i === 0 ? 1 : -1, legs, gd, gildMat(GOLD), 0.144, false);
      for (const sh of shins) greave(sh, legs, gd, gildMat(GOLD), { ridge: true, knee: true });
      cloakFinish(w, silk(0xf7f4eb), gd);
      break;
    }

    /* ================= WARBAND ================= */
    case "orc": {
      // Warband brute: scrap iron riveted to hide, trophies, one spiked shoulder.
      const scrap = ironMat(0x4a4e55), rust = ironMat(0x6b5444), bone = boneMat(), hd = hide(0x3a3024);
      part(torso, GEO.softer, hd, cw * 1.14, 0.14, depth * 1.14, 0, 0.8, 0);
      for (let i = 0; i < 12; i++) { const a = (i / 12) * PI * 2; part(torso, GEO.cone, hide(i % 2 ? 0x3a3024 : 0x2a221a), 0.09, 0.24, 0.09, Math.sin(a) * cw * 0.6, 0.76, Math.cos(a) * depth * 0.62, PI - Math.cos(a) * 0.9, 0, Math.sin(a) * 0.9); }
      // Chest plate: three dented scrap plates on a cross strap.
      plate(torso, leather(LEATHER_DARK), 0.09, 0.9, 0.03, 0, 0.42, front - 0.005, 0, 0, 0.6);
      plate(torso, scrap, 0.26, 0.22, 0.04, -cw * 0.14, 0.58, front + 0.01, 0.05, 0, 0.1);
      plate(torso, rust, 0.22, 0.2, 0.04, cw * 0.18, 0.46, front + 0.012, 0, 0, -0.15);
      plate(torso, scrap, cw * 0.8, 0.2, 0.05, 0, 0.14, front, 0.1);
      rivets(torso, bone, [-cw * 0.3, 0.14, front + 0.03], [cw * 0.3, 0.14, front + 0.03], 4, 0.02);
      rivets(torso, steel(STEEL_DARK), [-cw * 0.24, 0.66, front + 0.035], [-cw * 0.04, 0.5, front + 0.035], 3, 0.018);
      necklace(torso, horn(0xe8e0c8), cw, 7, 0.68, 0.1, cw * 0.3, 0.022);
      waistBelt(w, hide(LEATHER_DARK), 0.04, 0.14, 0.05);
      part(torso, GEO.sph, bone, 0.08, 0.09, 0.05, 0, 0.04, depth * 0.58);
      for (const sd of sides) stud(torso, B(0x120d0a), 0.02, sd * 0.03, 0.055, depth * 0.58 + 0.04);
      for (const f of [1, -1]) { part(torso, GEO.cape, hide(0x5a4028), ww * 0.62, 0.44, 0.04, 0, -0.2, f * depth * 0.5, 0, f > 0 ? PI : 0, 0); fringe(torso, hide(0x3a3024), 5, -ww * 0.28, ww * 0.28, -0.42, f * depth * 0.52, 0.14); }
      for (let k = 0; k < 3; k++) part(torso, GEO.cone, bone, 0.025, 0.1, 0.025, ww * 0.42 + k * 0.05, -0.1, depth * 0.3, PI, 0, 0); // tusk trophies
      part(torso, GEO.sph, bone, 0.07, 0.08, 0.06, -ww * 0.48, -0.1, -depth * 0.2); // skull at the hip
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        if (i === 0) pauldron(a, side, scrap, rust, 0.26, 2, { spike: steel(0x8b939f), studs: true, flat: 0.7 });
        else for (let k = 0; k < 2; k++) band(a, B(tc), 0.14, -0.08 - k * 0.05, 0.028);
        band(a, gold(BRASS), 0.135, -0.24, 0.05);
        bracer(a, side, i === 0 ? "wrap" : "splint", leather(LEATHER_DARK), i === 0 ? leather(LEATHER) : rust);
        if (i === 1) for (let k = 0; k < 2; k++) part(a, GEO.cone, steel(0x8b939f), 0.03, 0.08, 0.03, side * 0.15, -0.46 - k * 0.1, 0, 0, 0, -side * PI / 2);
      }
      for (const sh of shins) { legWraps(sh, legs, hide(0x4a3a28), hide(0x6b5236), 3, 0.17); plate(sh, rust, 0.12, 0.16, 0.035, 0, -0.14 * legs, 0.14, -0.1); }
      break;
    }
    case "berserker": {
      // Northman: bare chest under a wolf pelt, bear-claw necklace, studded kilt, arm rings.
      const fur = hide(0x5a4028), furD = hide(0x3d2a18), bone = horn(0xe8e0c8);
      part(torso, GEO.dome, fur, 0.3, 0.2, 0.3, cw * 0.4, 0.78, -0.02); // pelt over the left shoulder
      part(torso, GEO.cape, fur, 0.4, 0.8, 0.05, cw * 0.3, 0.42, -depth * 0.52, 0.1, 0, 0.15);
      for (let i = 0; i < 6; i++) part(torso, GEO.cone, i % 2 ? fur : furD, 0.06, 0.2, 0.06, cw * 0.4 + Math.sin(i) * 0.2, 0.76, Math.cos(i * 1.1) * 0.22, PI - Math.cos(i * 1.1) * 0.9, 0, Math.sin(i) * 0.7);
      part(torso, GEO.sph, furD, 0.12, 0.1, 0.14, cw * 0.44, 0.9, 0.08); // wolf's head
      for (const sd of sides) part(torso, GEO.cone, furD, 0.03, 0.08, 0.03, cw * 0.44 + sd * 0.07, 1.0, 0.04);
      necklace(torso, bone, cw, 7, 0.62, 0.1, cw * 0.3, 0.018);
      for (let i = -2; i <= 2; i++) part(torso, GEO.cone, bone, 0.02, 0.09 + (2 - Math.abs(i)) * 0.02, 0.02, i * 0.07, 0.5 - (4 - i * i) * 0.01, front + 0.02, PI + 0.3, 0, 0);
      waistBelt(w, waxLeather(LEATHER), 0.04, 0.13, 0.05, gold(BRASS), 0.13);
      for (const f of [1, -1]) {
        for (let i = 0; i < 5; i++) plate(torso, leather(i % 2 ? 0x4a3220 : 0x5a4028), ww * 0.2, 0.4, 0.03, (i - 2) * ww * 0.21, -0.22, f * depth * 0.5, f * -0.08, 0, 0);
        rivets(torso, gold(BRASS), [-ww * 0.42, -0.1, f * depth * 0.52], [ww * 0.42, -0.1, f * depth * 0.52], 5, 0.016, f > 0 ? 0 : PI);
      }
      scabbard(torso, -1, leather(LEATHER_DARK), steel(STEEL_DARK), 0.3, -ww * 0.5 - 0.02, 0.0, 0.04, 0.3);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, gold(BRASS), 0.135, -0.16, 0.05);
        band(a, B(tc), 0.128, -0.24, 0.03);
        band(a, B(tc), 0.126, -0.29, 0.018);
        bracer(a, side, "wrap", leather(LEATHER), leather(LEATHER_DARK));
        band(a, steel(STEEL_DARK), 0.14, -0.6, 0.035);
      }
      for (const sh of shins) { band(sh, fur, 0.17, -0.27 * legs, 0.12); for (let k = 0; k < 6; k++) part(sh, GEO.cone, furD, 0.035, 0.1, 0.035, Math.sin(k) * 0.16, -0.21 * legs, Math.cos(k) * 0.16, PI + Math.cos(k) * 0.5, 0, -Math.sin(k) * 0.5); band(sh, leather(LEATHER_DARK), 0.15, -0.36 * legs, 0.03); }
      break;
    }
    case "javelin": {
      // Skirmisher: light tunic, chest sash, javelin case, sandal straps - built to run.
      const sashM = cloth(tc), tun = cloth(0x7a6242), dkL = leather(0x3a2c1c);
      part(torso, GEO.robe, tun, ww * 0.78, 0.36, depth * 0.74, 0, -0.13, 0);
      hoop(torso, cloth(0xd9c08a), ww * 0.74, -0.3, 0.02, 0, depth * 0.72);
      part(torso, GEO.pillY, sashM, 0.14, 0.86, 0.04, 0, 0.44, front + 0.005, 0, 0, 0.5);
      part(torso, GEO.pillY, sashM, 0.14, 0.86, 0.04, 0, 0.44, -front - 0.005, 0, 0, -0.5);
      stud(torso, gold(BRASS), 0.03, -cw * 0.3, 0.7, front + 0.02);
      waistBelt(w, leather(), 0.04, 0.08, 0.02, gold(BRASS), 0.09);
      part(torso, GEO.cyl, leather(0x4a3826), 0.1, 0.5, 0.1, ww * 0.1, 0.5, -depth * 0.62, 0.15, 0, 0.1); // javelin case
      hoop(torso, dkL, 0.105, 0.72, 0.02, -depth * 0.62 - 0.04, 0.105, ww * 0.1);
      pouch(torso, ww * 0.44, -0.03, depth * 0.3, 0.1, 0.12, 0.08, leather(), dkL, gold(BRASS), -0.3);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, cloth(0xd9c08a), 0.128, -0.1, 0.04);
        band(a, gold(BRASS), 0.13, -0.22, 0.03);
        if (i === 0) bracer(a, side, "leather", leather(0x4a3826), dkL, cloth(0xd9c79a)); else bracer(a, side, "wrap", leather(0x4a3826), cloth(0xd9c08a));
      }
      for (const sh of shins) for (let k = 0; k < 4; k++) { band(sh, dkL, 0.12 + k * 0.004, -0.05 * legs - k * 0.07 * legs, 0.022); plate(sh, dkL, 0.025, 0.07, 0.03, 0, -0.085 * legs - k * 0.07 * legs, 0.125, 0, 0, 0.5); }
      break;
    }
    case "bomber": {
      // Demolitionist: leather apron over the coat, tool belt, gauntlets, knee pads.
      const apron = waxLeather(0x4a3826), dkL = leather(LEATHER_DARK), iron = ironMat();
      plate(torso, apron, cw * 0.62, 0.78, 0.04, 0, 0.3, front + 0.005);
      for (const sd of sides) plate(torso, dkL, 0.04, 0.5, 0.025, sd * cw * 0.22, 0.72, front + 0.01, 0, 0, sd * 0.25);
      plate(torso, apron, cw * 0.4, 0.14, 0.05, 0, 0.5, front + 0.02); // apron pocket
      for (let k = 0; k < 3; k++) part(torso, GEO.cyl, k === 1 ? gold(COPPER) : iron, 0.018, 0.1, 0.018, (k - 1) * 0.06, 0.56, front + 0.03);
      waistBelt(w, leather(), 0.04, 0.11, 0.03, iron, 0.12);
      pouch(torso, ww * 0.46, -0.04, depth * 0.2, 0.14, 0.16, 0.1, leather(), dkL, iron, -0.3);
      part(torso, GEO.pillY, iron, 0.04, 0.2, 0.04, -ww * 0.46, -0.1, depth * 0.3, 0.1, 0, 0.3); // pliers
      part(torso, GEO.pillY, iron, 0.04, 0.2, 0.04, -ww * 0.44, -0.1, depth * 0.3, -0.1, 0, 0.3);
      part(torso, GEO.cyl, M(0xd8c090), 0.012, 0.6, 0.012, -ww * 0.3, 0.2, -depth * 0.3, 0.4, 0, 1.2); // slow match coil
      hoop(torso, M(0xd8c090), 0.1, 0.1, 0.012, -depth * 0.56, 0.1, -ww * 0.3);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        part(a, GEO.dome, apron, 0.19, 0.1, 0.2, 0, -0.01, 0);
        band(a, cloth(0x2f3540), 0.13, -0.28, 0.07);
        bracer(a, side, "leather", leather(0x5a4530), dkL);
        band(a, leather(0x5a4530), 0.16, -0.68, 0.08); // gauntlet cuff
        band(a, dkL, 0.15, -0.65, 0.025);
      }
      for (const sh of shins) { part(sh, GEO.dome, leather(0x5a4530), 0.1, 0.06, 0.1, 0, -0.02, 0.11, PI / 2, 0, 0); band(sh, dkL, 0.14, -0.04 * legs, 0.03); bootCuff(sh, legs, leather(0x2a2219), dkL, iron, 0.1, 0.17); }
      break;
    }
    case "shaman": {
      // Witch doctor: feather mantle, bead strands, fetish pouches, a totem over the shoulder.
      const bone = boneMat(), bead = [B(0xd8402a), B(0xe8c050), B(0x3fa0c0)], rope = M(0xb49a6a, 0.95);
      for (let i = 0; i < 16; i++) {
        const a = (i / 16) * PI * 2, c = [0x3a2f20, 0xd8cfb0, 0x8a2f2a, 0x2f4a3a][i % 4];
        part(torso, GEO.cone, cloth(c), 0.05, 0.3 + (i % 2) * 0.08, 0.02, Math.sin(a) * cw * 0.62, 0.72 - 0.15, Math.cos(a) * depth * 0.64, PI + Math.cos(a) * 0.35, a, -Math.sin(a) * 0.35);
      }
      part(torso, GEO.softer, hide(0x4a4230), cw * 1.1, 0.12, depth * 1.1, 0, 0.8, 0);
      for (let s = 0; s < 3; s++) necklace(torso, bead[s], cw, 7 + s * 2, 0.7 - s * 0.05, 0.08 + s * 0.05, cw * (0.2 + s * 0.07), 0.016);
      part(torso, GEO.sph, bone, 0.06, 0.07, 0.04, 0, 0.5, front + 0.03); // small skull pendant
      waistBelt(w, rope, 0.04, 0.06, 0.02);
      band(torso, rope, ww * 0.5 + 0.04, 0.1, 0.03, 0, depth * 0.52 + 0.04);
      for (let k = 0; k < 3; k++) pouch(torso, (k - 1) * ww * 0.36, -0.06, depth * 0.3 + (k === 1 ? 0.03 : 0), 0.08, 0.11, 0.07, hide([0x6b5236, 0x8a2f2a, 0x3a3f2a][k]), hide(0x3a2f20), bone, (1 - k) * 0.4);
      fringe(torso, hide(0x3a2f20), 7, -ww * 0.4, ww * 0.4, -0.06, depth * 0.56, 0.16);
      // Totem pole across the back.
      part(torso, GEO.cyl, M(0x4a3520), 0.035, 1.3, 0.035, -cw * 0.2, 0.5, -depth * 0.6, 0, 0, 0.35);
      part(torso, GEO.sph, bone, 0.09, 0.1, 0.08, -cw * 0.42, 1.1, -depth * 0.6);
      for (let k = 0; k < 4; k++) part(torso, GEO.cone, cloth([0xd8402a, 0xe8c050, 0xd8cfb0, 0x3fa0c0][k]), 0.03, 0.2, 0.012, -cw * 0.42 + (k - 1.5) * 0.05, 0.98, -depth * 0.6 - 0.03, PI, 0, (k - 1.5) * 0.2);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, horn(0xe8e0c8), 0.135, -0.14, 0.04);
        for (let k = 0; k < 3; k++) stud(a, bead[k], 0.014, side * 0.135, -0.14, (k - 1) * 0.05, side * PI / 2);
        bracer(a, side, "splint", hide(0x3a2f20), horn(0xd4cbb0));
        for (let k = 0; k < 3; k++) part(a, GEO.cone, cloth([0xd8402a, 0xd8cfb0, 0x2f4a3a][k]), 0.025, 0.16, 0.01, side * 0.12, -0.7, -0.04 + k * 0.04, PI + 0.4, 0, side * 0.2);
      }
      for (const sh of shins) { legWraps(sh, legs, hide(0x4a4230), hide(0x6b5236), 3, 0.135); for (let k = 0; k < 3; k++) stud(sh, bead[k], 0.014, 0.0, -0.05 * legs - k * 0.06 * legs, 0.14); }
      break;
    }
    case "troll": {
      // Cave troll: iron collar, rope harness, shackles, patchwork loincloth, moss.
      const iron = ironMat(0x3d4147), rope = M(0xa88f62, 0.95), moss = hide(0x4e6a3a);
      part(torso, GEO.pillY, iron, 0.46, 0.14, 0.44, 0, 0.9, 0);
      for (let i = 0; i < 6; i++) { const a = (i / 6) * PI * 2 + 0.5; part(torso, GEO.cone, iron, 0.045, 0.12, 0.045, Math.sin(a) * 0.23, 0.9, Math.cos(a) * 0.22, PI / 2 * Math.cos(a), 0, -PI / 2 * Math.sin(a)); }
      for (const sd of sides) { part(torso, GEO.pillY, rope, 0.1, 0.98, 0.05, 0, 0.42, front + 0.01, 0, 0, sd * 0.55); part(torso, GEO.pillY, rope, 0.1, 0.98, 0.05, 0, 0.42, -front - 0.01, 0, 0, -sd * 0.55); }
      part(torso, GEO.sph, rope, 0.09, 0.09, 0.06, 0, 0.42, front + 0.03); // harness knot
      for (const sd of sides) part(torso, GEO.dome, iron, 0.3, 0.16, 0.3, sd * (cw / 2 + 0.2), 0.84, 0);
      for (const sd of sides) rivetRing(torso, steel(STEEL_DARK), 0.26, 0.26, 0.86, 4, -1.6 + (sd > 0 ? 0 : 3.2), 1.6 + (sd > 0 ? 0 : 3.2), 0.024);
      waistBelt(w, hide(0x5a4a3a), 0.02, 0.18, 0.06, iron, 0.2);
      for (const f of [1, -1]) for (let i = 0; i < 4; i++) plate(torso, hide([0x6a4a30, 0x4e6a3a, 0x5a4a3a, 0x3a3326][(i + (f > 0 ? 0 : 2)) % 4]), ww * 0.26, 0.4 + (i % 2) * 0.08, 0.04, (i - 1.5) * ww * 0.27, -0.26, f * depth * 0.52, f * -0.08, 0, 0);
      for (let k = 0; k < 4; k++) part(torso, GEO.sph, moss, 0.07, 0.04, 0.07, Math.sin(k * 2.1) * cw * 0.4, 0.86, -Math.abs(Math.cos(k)) * depth * 0.5, 0, 0, 0); // moss clumps on the shoulders
      part(torso, GEO.sph, moss, 0.14, 0.06, 0.12, cw * 0.3, 0.74, -depth * 0.45);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, rope, 0.14, -0.2, 0.05);
        band(a, rope, 0.138, -0.26, 0.04);
        band(a, iron, 0.15, -0.6, 0.08); // shackle
        rivetRing(a, steel(STEEL_DARK), 0.15, 0.15, -0.6, 3, -1.5, 1.5, 0.018);
        for (let k = 0; k < 3; k++) part(a, KIT.hoop, iron, 0.04, 0.04, 0.5, side * 0.16, -0.68 - k * 0.07, 0.0, 0, PI / 2 * (k % 2), 0); // broken chain
      }
      for (const [k, sh] of shins.entries()) { legWraps(sh, legs, hide(0x4a3a28), rope, 3, 0.17); if (k === 1) { band(sh, iron, 0.18, -0.34 * legs, 0.07); for (let c = 0; c < 2; c++) part(sh, KIT.hoop, iron, 0.045, 0.045, 0.5, 0.0, -0.42 * legs - c * 0.06, -0.18, 0, PI / 2 * (c % 2), 0); } }
      break;
    }
    case "giant": {
      // Hill giant: plank-and-hide armour lashed on with rope, a bone pauldron, a stolen gate for a buckle.
      const plank = M(0x6a4a30, 0.9), plankD = M(0x4f3620, 0.9), rope = M(0xa88f62, 0.95), bone = boneMat();
      for (let i = 0; i < 6; i++) { const a = (i / 6) * PI * 2 + PI / 6; plate(torso, i % 2 ? plank : plankD, 0.16, 0.6, 0.05, Math.sin(a) * cw * 0.54, 0.4, Math.cos(a) * depth * 0.62, 0, a, 0); }
      for (const y of [0.22, 0.58]) band(torso, rope, cw * 0.56, y, 0.05, 0, depth * 0.66);
      for (const y of [0.22, 0.58]) rivetRing(torso, ironMat(), cw * 0.56, depth * 0.66, y, 5, -1.6, 1.6, 0.02);
      part(torso, GEO.dome, bone, 0.34, 0.26, 0.32, cw / 2 + 0.2, 0.82, 0); // bone pauldron
      for (let k = 0; k < 4; k++) part(torso, GEO.cone, bone, 0.04, 0.2, 0.04, cw / 2 + 0.2 + Math.sin(k * 1.6) * 0.25, 0.86, Math.cos(k * 1.6) * 0.25, PI / 2 * Math.cos(k * 1.6), 0, -PI / 2 * Math.sin(k * 1.6) * 0.5);
      part(torso, GEO.softer, hide(0x5a4a3a), 0.3, 0.12, 0.44, -(cw / 2 + 0.2), 0.84, 0); // hide pad on the other shoulder
      waistBelt(w, hide(0x4a3a28), 0.02, 0.2, 0.06);
      plate(torso, ironMat(0x4a4e55), 0.28, 0.2, 0.04, 0, 0.02, front + 0.06); // iron buckle plate
      for (const sd of sides) for (const sy of sides) stud(torso, steel(STEEL_DARK), 0.022, sd * 0.1, 0.02 + sy * 0.06, front + 0.085);
      for (const f of [1, -1]) part(torso, GEO.cape, hide(0x5a4a3a), ww * 0.7, 0.5, 0.05, 0, -0.24, f * depth * 0.52, 0, f > 0 ? PI : 0, 0);
      part(torso, GEO.sph, bone, 0.09, 0.1, 0.08, ww * 0.5, -0.06, -depth * 0.3); // trophy skull
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, rope, 0.14, -0.14, 0.04);
        band(a, rope, 0.138, -0.2, 0.04);
        if (i === 0) for (let k = 0; k < 3; k++) plate(a, plank, 0.05, 0.24, 0.04, side * 0.14, -0.52, (k - 1) * 0.07, 0, 0, 0); // splinted forearm
        else bracer(a, side, "wrap", hide(0x4a3a28), rope);
        band(a, rope, 0.14, -0.4, 0.03);
        band(a, rope, 0.148, -0.64, 0.03);
      }
      for (const [k, sh] of shins.entries()) { band(sh, hide(0x5a4028), 0.19, -0.26 * legs, 0.14); for (let c = 0; c < 6; c++) part(sh, GEO.cone, hide(0x3d2a18), 0.04, 0.12, 0.04, Math.sin(c) * 0.18, -0.19 * legs, Math.cos(c) * 0.18, PI + Math.cos(c) * 0.5, 0, -Math.sin(c) * 0.5); if (k === 0) band(sh, ironMat(0x3d4147), 0.19, -0.36 * legs, 0.06); }
      break;
    }
    case "pirate": {
      // Corsair: long coat with turned cuffs, baldric and holster, sash, bucket boots.
      const coat = cloth(0x4a3a52), coatD = cloth(0x3a2c40), gd = gold(), lace = cloth(0xf4efe2);
      for (const sd of sides) part(torso, GEO.cape, coat, cw * 0.46, 0.7, 0.05, sd * cw * 0.3, 0.1, -depth * 0.46, 0.05, 0, sd * 0.08); // coat tails
      for (const sd of sides) plate(torso, coatD, cw * 0.2, 0.42, 0.03, sd * cw * 0.3, 0.66, front + 0.01, 0, 0, sd * 0.5); // lapels
      for (const sd of sides) plate(torso, gd, 0.05, 0.14, 0.02, sd * cw * 0.28, 0.72, front + 0.03, 0, 0, sd * 0.5);
      part(torso, GEO.pillY, waxLeather(0x3a2618), 0.09, 0.9, 0.035, 0, 0.44, front + 0.01, 0, 0, -0.5); // baldric
      part(torso, GEO.pillY, waxLeather(0x3a2618), 0.09, 0.9, 0.035, 0, 0.44, -front - 0.01, 0, 0, 0.5);
      stud(torso, gd, 0.03, cw * 0.22, 0.66, front + 0.03);
      waistBelt(w, silk(0x9a202c), 0.06, 0.14, 0.03);
      waistBelt(w, waxLeather(0x3a2618), 0.03, 0.06, 0.05, gd, 0.13);
      part(torso, GEO.pillY, silk(0x9a202c), 0.1, 0.34, 0.03, ww * 0.42, -0.14, depth * 0.4, 0.2, 0, 0.1); // sash tail
      // Holstered pistol on the left hip, cutlass hanger on the right.
      plate(torso, waxLeather(0x3a2618), 0.08, 0.2, 0.12, -ww * 0.5, -0.08, depth * 0.1, 0, 0, 0.1);
      part(torso, GEO.pillY, M(0x3a2c22, 0.7), 0.05, 0.12, 0.08, -ww * 0.5, 0.06, depth * 0.1, 0, 0, 0.5);
      scabbard(torso, 1, waxLeather(0x241d22), gd, 0.6, ww * 0.5 + 0.04, 0.0, -0.06, 0.5);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, coat, 0.138, -0.1, 0.05);
        band(a, coatD, 0.16, -0.6, 0.1); // turned cuff
        rivets(a, gd, [side * 0.16, -0.58, 0.04], [side * 0.16, -0.58, -0.04], 2, 0.014, side * PI / 2);
        band(a, lace, 0.135, -0.68, 0.05); // lace at the wrist
      }
      for (const sh of shins) { band(sh, leather(0x241d22), 0.18, -0.25 * legs, 0.13); band(sh, leather(0x1a1418), 0.19, -0.2 * legs, 0.03); }
      break;
    }
    case "sapper": {
      // Tunneller: canvas apron, satchel, powder horn, a shovel on the back, kneepads worn through.
      const canvas = cloth(0x8a7a5a), dkL = leather(LEATHER_DARK), iron = ironMat();
      plate(torso, canvas, cw * 0.6, 0.7, 0.04, 0, 0.32, front + 0.005);
      for (const sd of sides) plate(torso, dkL, 0.04, 0.44, 0.025, sd * cw * 0.2, 0.74, front + 0.01, 0, 0, sd * 0.3);
      for (let k = 0; k < 2; k++) plate(torso, cloth(0x6b5e44), cw * 0.2, 0.12, 0.05, (k - 0.5) * cw * 0.3, 0.3, front + 0.02);
      waistBelt(w, leather(), 0.04, 0.1, 0.03, iron, 0.11);
      // Satchel on a cross strap.
      part(torso, GEO.pillY, dkL, 0.07, 0.9, 0.03, 0, 0.44, -front - 0.005, 0, 0, 0.5);
      part(torso, GEO.soft, canvas, 0.24, 0.22, 0.12, ww * 0.5 + 0.02, -0.04, -0.04);
      plate(torso, cloth(0x6b5e44), 0.25, 0.1, 0.13, ww * 0.5 + 0.02, 0.04, -0.04);
      stud(torso, iron, 0.018, ww * 0.5 + 0.02, -0.04, 0.03);
      part(torso, GEO.cone, horn(0xd8cfb0), 0.05, 0.22, 0.05, -ww * 0.48, -0.1, 0.02, 0.3, 0, 0.6); // powder horn
      hoop(torso, gold(BRASS), 0.04, -0.02, 0.012, 0.0, 0.04, -ww * 0.48);
      // Shovel across the back.
      part(torso, GEO.cyl, M(0x6b4a2a, 0.8), 0.025, 1.1, 0.025, 0, 0.44, -depth * 0.6, 0, 0, 0.6);
      plate(torso, iron, 0.16, 0.22, 0.03, -0.3, 0.92, -depth * 0.6, 0, 0, 0.6);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, cloth(0x7a3a26), 0.13, -0.3, 0.07);
        bracer(a, side, "leather", leather(0x5a4530), dkL);
        band(a, leather(0x5a4530), 0.155, -0.67, 0.06);
      }
      for (const sh of shins) { plate(sh, leather(0x5a4530), 0.14, 0.12, 0.04, 0, -0.02, 0.11, -0.1); band(sh, dkL, 0.135, -0.05 * legs, 0.025); bootCuff(sh, legs, leather(0x2a2219), dkL, iron, 0.09, 0.165); }
      break;
    }

    /* ================= MYSTIC ================= */
    case "elf": {
      // Sylvan ranger: leaf-lame shoulders, vine-laced bracers, a long hooded cloak with a leaf clasp.
      const leafA = silk(0x3f6b3a), leafB = silk(0x2f5a30), gd = gildMat(0xd6c98a), bark = waxLeather(0x4a3826);
      part(torso, GEO.robe, cloth(0x2f4a2c), ww * 0.76, 0.34, depth * 0.72, 0, -0.12, 0);
      for (let i = 0; i < 8; i++) { const a = (i / 8) * PI * 2 + 0.2; part(torso, GEO.cone, i % 2 ? leafA : leafB, 0.07, 0.24, 0.025, Math.sin(a) * ww * 0.5, -0.36, Math.cos(a) * depth * 0.56, PI + 0.1 * Math.cos(a), a, -0.1 * Math.sin(a)); }
      plate(torso, leafA, cw * 0.74, 0.44, 0.035, 0, 0.5, front - 0.005);
      for (let k = 0; k < 3; k++) part(torso, GEO.cone, leafB, 0.06, 0.16, 0.015, (k - 1) * 0.16, 0.56 - Math.abs(k - 1) * 0.04, front + 0.02, PI, 0, (k - 1) * 0.3); // leaf scales
      part(torso, GEO.cone, gd, 0.045, 0.12, 0.012, 0, 0.76, front + 0.02, PI, 0, 0); // leaf clasp
      stud(torso, B(0x4fc27a), 0.02, 0, 0.72, front + 0.03);
      waistBelt(w, bark, 0.04, 0.07, 0.02, gd, 0.1);
      part(torso, GEO.pillY, bark, 0.06, 0.4, 0.025, 0, 0.44, front + 0.012, 0, 0, 0.55); // quiver strap
      pouch(torso, ww * 0.44, -0.03, depth * 0.3, 0.1, 0.12, 0.08, bark, waxLeather(0x3a2c1c), gd, -0.3);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        for (let k = 0; k < 3; k++) part(a, GEO.cone, k % 2 ? leafA : leafB, 0.09, 0.22, 0.03, side * (0.06 + k * 0.05), 0.06 - k * 0.08, (k - 1) * 0.02, 0, 0, -side * (0.9 + k * 0.2)); // leaf lames
        band(a, cloth(0x2f4a2c), 0.128, -0.26, 0.05);
        bracer(a, side, "leather", bark, waxLeather(0x3a2c1c));
        for (let k = 0; k < 3; k++) part(a, GEO.pillX, M(0x5aa050, 0.6), 0.12, 0.012, 0.012, side * 0.135, -0.46 - k * 0.05, 0, 0, side * PI / 2, k % 2 ? 0.6 : -0.6); // vines
      }
      for (const sh of shins) { band(sh, waxLeather(0x4a3826), 0.15, -0.27 * legs, 0.08); for (let k = 0; k < 4; k++) part(sh, GEO.cone, leafB, 0.05, 0.12, 0.02, Math.sin(k * 1.57 + 0.5) * 0.15, -0.23 * legs, Math.cos(k * 1.57 + 0.5) * 0.15, PI + Math.cos(k * 1.57 + 0.5) * 0.4, 0, -Math.sin(k * 1.57 + 0.5) * 0.4); }
      cloakFinish(w, cloth(0x4a7a44), gd, false);
      break;
    }
    case "monk": {
      // Warrior monk: robe folded off one shoulder, knotted rope belt, hand and leg wraps.
      const robeD = cloth(0xa07838), rope = M(0xb49a6a, 0.95), wrap = cloth(0xe8dcc0);
      part(torso, GEO.pillY, robeD, 0.16, 1.0, 0.05, 0, 0.42, front + 0.01, 0, 0, 0.55); // diagonal drape
      part(torso, GEO.pillY, robeD, 0.16, 1.0, 0.05, 0, 0.42, -front - 0.01, 0, 0, -0.55);
      part(torso, GEO.softer, robeD, 0.3, 0.12, 0.36, -cw * 0.44, 0.84, 0); // folded shoulder
      part(torso, GEO.robe, robeD, ww * 0.74, 0.3, depth * 0.72, 0, -0.1, 0);
      waistBelt(w, rope, 0.06, 0.05, 0.02);
      waistBelt(w, rope, 0.0, 0.05, 0.02);
      part(torso, GEO.sph, rope, 0.07, 0.07, 0.05, cw * 0.2, 0.03, front + 0.02); // knot
      for (const sd of [0, 1]) part(torso, GEO.pillY, rope, 0.04, 0.4, 0.04, cw * 0.2 + sd * 0.05, -0.2, front + 0.02, 0.1, 0, sd * 0.15 - 0.05);
      fringe(torso, rope, 2, cw * 0.19, cw * 0.26, -0.4, front + 0.02, 0.08);
      part(torso, GEO.cyl, M(0x6b4a2a, 0.85), 0.05, 0.3, 0.05, -ww * 0.46, -0.06, -0.02, 0.3, 0, 0.2); // prayer scroll case
      for (const a of arms) { bracer(a, 1, "wrap", wrap, cloth(0xd8c8a8)); band(a, wrap, 0.11, -0.72, 0.05); }
      for (const sh of shins) { legWraps(sh, legs, wrap, cloth(0xd8c8a8), 5, 0.13); band(sh, rope, 0.135, -0.3 * legs, 0.02); }
      break;
    }
    case "assassin": {
      // Night blade: layered leather harness bristling with sheaths, a half cape, thigh holster.
      const lth = waxLeather(0x1b1c22), lthD = leather(0x101115), st = steel(0x8b93a1);
      for (const sd of sides) part(torso, GEO.pillY, lth, 0.1, 0.9, 0.035, 0, 0.44, front + 0.005, 0, 0, sd * 0.5);
      for (const sd of sides) part(torso, GEO.pillY, lth, 0.1, 0.9, 0.035, 0, 0.44, -front - 0.005, 0, 0, sd * 0.5);
      plate(torso, lth, cw * 0.56, 0.3, 0.04, 0, 0.56, front + 0.005);
      for (let k = 0; k < 4; k++) { plate(torso, lthD, 0.035, 0.14, 0.03, -0.12 + k * 0.08, 0.56, front + 0.03, 0, 0, -0.25); part(torso, GEO.cone, st, 0.012, 0.06, 0.008, -0.12 + k * 0.08 + 0.02, 0.66, front + 0.035, 0, 0, -0.25); }
      part(torso, GEO.cape, cloth(dark(tc, 0.5)), 0.32, 0.7, 0.04, cw * 0.3, 0.5, -depth * 0.5, 0.15, 0, 0.3); // half cape over the shoulder
      part(torso, GEO.softer, cloth(dark(tc, 0.5)), 0.32, 0.1, 0.36, cw * 0.44, 0.84, 0);
      waistBelt(w, lth, 0.04, 0.09, 0.03, st, 0.08);
      for (const sd of sides) pouch(torso, sd * ww * 0.44, -0.04, depth * 0.3, 0.1, 0.1, 0.08, lth, lthD, st, -sd * 0.3);
      part(torso, GEO.pillY, lth, 0.05, 0.3, 0.03, -ww * 0.3, -0.1, -depth * 0.5, -0.2, 0, 0.3);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, lth, 0.135, -0.16, 0.06);
        rivets(a, st, [side * 0.135, -0.14, 0.05], [side * 0.135, -0.14, -0.05], 2, 0.012, side * PI / 2);
        bracer(a, side, "leather", lth, lthD, cloth(0x4a4a52));
        if (i === 1) for (let k = 0; k < 3; k++) plate(a, lthD, 0.025, 0.12, 0.025, side * 0.13, -0.5, (k - 1) * 0.05);
      }
      for (const [i, th] of thighs.entries()) if (i === 1) { band(th, lth, 0.15, -0.26 * legs, 0.05); for (let k = 0; k < 2; k++) { plate(th, lthD, 0.035, 0.16, 0.035, -0.12, -0.26 * legs, (k - 0.5) * 0.06, 0.1); part(th, GEO.cone, st, 0.012, 0.06, 0.008, -0.12, -0.15 * legs, (k - 0.5) * 0.06); } }
      for (const sh of shins) { legWraps(sh, legs, cloth(0x23262e), lth, 3, 0.135); band(sh, lthD, 0.15, -0.3 * legs, 0.06); }
      break;
    }
    case "mage": {
      // Arcanist: layered mantle with runic trim, chained grimoire, a sash of reagents.
      const robe = silk(tc), robeD = silk(dark(tc, 0.72)), gd = gildMat(), glow = B(0xd9a8ff);
      part(torso, GEO.softer, robeD, cw * 1.5, 0.3, cw * 0.98, 0, 0.7, 0);
      part(torso, GEO.softer, robe, cw * 1.3, 0.18, cw * 0.86, 0, 0.6, 0);
      hoop(torso, gd, cw * 0.72, 0.56, 0.03, 0, cw * 0.48);
      for (let i = 0; i < 7; i++) { const a = (i / 7) * PI * 2 + 0.4; stud(torso, glow, 0.018, Math.sin(a) * cw * 0.7, 0.6, Math.cos(a) * cw * 0.46, a); }
      collar(torso, robeD, 0.15, 0.92, 0.12);
      stud(torso, gd, 0.04, 0, 0.8, cw * 0.36);
      stud(torso, glow, 0.03, 0, 0.66, cw * 0.4);
      hoop(torso, gd, 0.06, 0.66, 0.012, cw * 0.395, 0.06);
      plate(torso, gd, 0.08, 0.84, 0.02, 0, 0.0, cw * 0.32 + 0.04); // embroidered front band
      for (let k = 0; k < 4; k++) stud(torso, glow, 0.012, 0, 0.3 - k * 0.2, cw * 0.32 + 0.06);
      band(torso, silk(tcl), cw * 0.52, 0.1, 0.11);
      for (const sd of sides) plate(torso, silk(tcl), 0.09, 0.5 + (sd > 0 ? 0.1 : 0), 0.03, sd * 0.07 - 0.1, -0.16, cw * 0.38, 0.1, 0, sd * 0.05);
      hoop(torso, gd, 0.57, -0.84, 0.03, 0, 0.57);
      for (let i = 0; i < 9; i++) { const a = (i / 9) * PI * 2 + 0.35; stud(torso, glow, 0.02, Math.sin(a) * 0.6, -0.94, Math.cos(a) * 0.6, a); }
      // Grimoire on a chain, potion and scroll case.
      plate(torso, waxLeather(0x4a2a18), 0.12, 0.2, 0.16, -cw * 0.54, -0.02, 0.06, 0, 0, 0.18);
      plate(torso, gd, 0.13, 0.03, 0.17, -cw * 0.54, 0.08, 0.06, 0, 0, 0.18);
      for (let k = 0; k < 3; k++) part(torso, KIT.hoop, gd, 0.025, 0.025, 0.4, -cw * 0.5, 0.18 + k * 0.045, 0.06, 0, PI / 2 * (k % 2), 0);
      part(torso, GEO.sph, B(0xff7a9a), 0.06, 0.07, 0.06, cw * 0.46, -0.02, cw * 0.22);
      part(torso, GEO.cyl, M(0x6b4a2a), 0.025, 0.06, 0.025, cw * 0.46, 0.07, cw * 0.22);
      part(torso, GEO.pillY, M(0xe6dcb0, 0.7), 0.07, 0.24, 0.07, cw * 0.4, -0.04, -cw * 0.2, 0.5, 0, 0);
      for (const [i, a] of arms.entries()) { band(a, gd, 0.165, -0.6, 0.04); band(a, robeD, 0.15, -0.12, 0.07); stud(a, glow, 0.016, (i === 0 ? 1 : -1) * 0.15, -0.12, 0, (i === 0 ? 1 : -1) * PI / 2); }
      cloakFinish(w, silk(light(tc, 0.3)), gd, false);
      break;
    }
    case "frost": {
      // Winter witch: fur-trimmed mantle, ice-crystal shoulders, icicle pendant.
      const robeD = silk(0x3a5f8f), fur = hide(0xeef3f8), ice = B(0xbfe8ff), sil = steel(0xbfd0e4);
      part(torso, GEO.softer, robeD, cw * 1.5, 0.3, cw * 0.98, 0, 0.7, 0);
      part(torso, GEO.softer, fur, cw * 1.34, 0.16, cw * 0.9, 0, 0.62, 0);
      for (let i = 0; i < 10; i++) { const a = (i / 10) * PI * 2; part(torso, GEO.cone, fur, 0.05, 0.14, 0.05, Math.sin(a) * cw * 0.66, 0.54, Math.cos(a) * cw * 0.44, PI + Math.cos(a) * 0.3, 0, -Math.sin(a) * 0.3); }
      for (const sd of sides) for (let k = 0; k < 3; k++) part(torso, GEO.cone, ice, 0.035, 0.18 + k * 0.05, 0.035, sd * (cw * 0.5 + k * 0.08), 0.8 + k * 0.03, (k - 1) * 0.08, -0.2 + k * 0.1, 0, -sd * (0.5 + k * 0.25));
      collar(torso, fur, 0.16, 0.92, 0.12);
      stud(torso, sil, 0.04, 0, 0.8, cw * 0.36);
      part(torso, GEO.cone, ice, 0.03, 0.14, 0.03, 0, 0.56, cw * 0.4, PI, 0, 0); // icicle pendant
      hoop(torso, sil, 0.05, 0.64, 0.012, cw * 0.395, 0.05);
      band(torso, silk(0xbfe4ff), cw * 0.52, 0.1, 0.11);
      for (const sd of sides) plate(torso, silk(0xbfe4ff), 0.09, 0.5 + (sd > 0 ? 0.1 : 0), 0.03, sd * 0.07 - 0.1, -0.16, cw * 0.38, 0.1, 0, sd * 0.05);
      band(torso, fur, 0.6, -0.9, 0.08, 0, 0.6);
      for (let i = 0; i < 9; i++) { const a = (i / 9) * PI * 2 + 0.35; stud(torso, ice, 0.02, Math.sin(a) * 0.6, -0.82, Math.cos(a) * 0.6, a); }
      part(torso, GEO.sph, B(0x9fe0ff), 0.06, 0.07, 0.06, cw * 0.46, -0.02, cw * 0.22);
      part(torso, GEO.cyl, sil, 0.025, 0.06, 0.025, cw * 0.46, 0.07, cw * 0.22);
      pouch(torso, -cw * 0.48, -0.04, 0.0, 0.11, 0.13, 0.09, waxLeather(0x2a3a52), silk(0x3a5f8f), sil, 0.5);
      for (const a of arms) { band(a, fur, 0.17, -0.6, 0.06); band(a, robeD, 0.15, -0.12, 0.07); band(a, silk(0x4f7fbf), 0.148, -0.18, 0.02); }
      cloakFinish(w, fur, sil, false);
      break;
    }
    case "cleric": {
      // Healer: white habit, a stole in the order's colour, rope cincture, book and censer.
      const habit = cloth(0xf0ead8), stole = silk(tc), gd = gildMat(), rope = M(0xd9c08a, 0.95);
      part(torso, GEO.softer, cloth(0xd9cfb0), cw * 1.5, 0.3, cw * 0.98, 0, 0.7, 0);
      hoop(torso, gd, cw * 0.72, 0.64, 0.025, 0, cw * 0.47);
      collar(torso, habit, 0.15, 0.92, 0.12);
      for (const sd of sides) { part(torso, GEO.pillY, stole, 0.12, 1.5, 0.03, sd * cw * 0.2, -0.1, cw * 0.32 + 0.05); part(torso, GEO.pillY, stole, 0.12, 0.9, 0.03, sd * cw * 0.2, 0.2, -cw * 0.32 - 0.05); for (let k = 0; k < 3; k++) { plate(torso, gd, 0.07, 0.02, 0.015, sd * cw * 0.2, 0.4 - k * 0.5, cw * 0.32 + 0.07); plate(torso, gd, 0.02, 0.07, 0.015, sd * cw * 0.2, 0.4 - k * 0.5, cw * 0.32 + 0.07); } }
      for (const sd of sides) part(torso, GEO.pillX, gd, 0.12, 0.02, 0.015, sd * cw * 0.2, -0.82, cw * 0.32 + 0.07);
      part(torso, GEO.cone, gd, 0.05, 0.14, 0.015, 0, 0.56, cw * 0.4, PI, 0, 0); // pendant
      hoop(torso, gd, 0.045, 0.66, 0.01, cw * 0.395, 0.045);
      stud(torso, B(0xfff2b0), 0.022, 0, 0.6, cw * 0.41);
      band(torso, rope, cw * 0.52, 0.1, 0.035);
      band(torso, rope, cw * 0.52, 0.05, 0.035);
      part(torso, GEO.sph, rope, 0.06, 0.06, 0.045, cw * 0.3, 0.07, cw * 0.36);
      for (let k = 0; k < 2; k++) part(torso, GEO.pillY, rope, 0.035, 0.44, 0.035, cw * 0.3 + k * 0.05, -0.18, cw * 0.38, 0.1, 0, k * 0.12);
      fringe(torso, rope, 2, cw * 0.29, cw * 0.36, -0.4, cw * 0.38, 0.08);
      plate(torso, waxLeather(0x5a2e2a), 0.1, 0.18, 0.14, -cw * 0.5, -0.04, -cw * 0.05, 0, 0, 0.1);
      plate(torso, gd, 0.11, 0.03, 0.15, -cw * 0.5, 0.04, -cw * 0.05);
      // Censer on a chain at the back of the belt.
      for (let k = 0; k < 3; k++) part(torso, KIT.hoop, gd, 0.02, 0.02, 0.4, cw * 0.3, 0.02 - k * 0.04, -cw * 0.34, 0, PI / 2 * (k % 2), 0);
      part(torso, GEO.sph, gd, 0.06, 0.07, 0.06, cw * 0.3, -0.16, -cw * 0.34);
      stud(torso, B(0xffb060), 0.02, cw * 0.3, -0.18, -cw * 0.34 - 0.05, PI);
      for (const a of arms) { band(a, gd, 0.165, -0.6, 0.03); band(a, cloth(0xd9cfb0), 0.15, -0.12, 0.07); }
      cloakFinish(w, silk(light(tc, 0.5)), gd, false);
      break;
    }
    case "zeus": {
      // Storm god: himation draped from the shoulder, gold fibula, armbands, strapped greaves.
      const toga = silk(0xf4eee0), togaD = silk(0xe4dcc6), gd = gildMat(), sky = B(0x9fd8ff);
      part(torso, GEO.pillY, toga, 0.26, 1.1, 0.07, 0, 0.42, front + 0.02, 0, 0, 0.55); // drape across the chest
      part(torso, GEO.pillY, togaD, 0.24, 1.0, 0.06, 0, 0.44, -front - 0.02, 0, 0, -0.55);
      part(torso, GEO.softer, toga, 0.36, 0.14, 0.4, cw * 0.44, 0.86, 0); // gathered on the shoulder
      for (let k = 0; k < 3; k++) part(torso, GEO.pillY, togaD, 0.04, 0.5, 0.04, cw * 0.46 + (k - 1) * 0.07, 0.2, -depth * 0.3, -0.1, 0, (k - 1) * 0.08); // folds falling behind
      stud(torso, gd, 0.05, cw * 0.42, 0.88, cw * 0.2, 0.6); // fibula
      stud(torso, sky, 0.025, cw * 0.42, 0.88, cw * 0.24, 0.6);
      hoop(torso, gd, cw * 0.5 + 0.03, 0.08, 0.035, 0, depth * 0.5 + 0.03);
      part(torso, GEO.robe, toga, ww * 0.86, 0.5, depth * 0.8, 0, -0.18, 0);
      hoop(torso, gd, ww * 0.84, -0.42, 0.03, 0, depth * 0.78);
      for (let i = 0; i < 6; i++) { const a = (i / 6) * PI * 2 + 0.2; part(torso, GEO.cone, sky, 0.015, 0.08, 0.01, Math.sin(a) * ww * 0.82, -0.36, Math.cos(a) * depth * 0.76, 0, a, 0.3); } // lightning motif at the hem
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        if (i === 1) pauldron(a, side, gd, gildMat(GOLD), 0.22, 1, { flat: 0.66 });
        band(a, gd, 0.14, -0.2, 0.05);
        part(a, KIT.arc, gd, 0.15, 0.15, 0.5, 0, -0.2, 0, PI / 2, 0, 0);
        band(a, gd, 0.14, -0.6, 0.05);
        stud(a, sky, 0.016, side * 0.14, -0.6, 0, side * PI / 2);
      }
      for (const sh of shins) { greave(sh, legs, gd, gildMat(GOLD), { ridge: true }); for (let k = 0; k < 2; k++) band(sh, waxLeather(0x8a6a3a), 0.125, -0.1 * legs - k * 0.12 * legs, 0.02); }
      break;
    }

    /* ================= UNDEAD ================= */
    case "zombie": {
      // Walking corpse: what is left of a labourer's clothes, bandages, a rope belt.
      const rag = cloth(0x5a5a44), ragD = cloth(0x3a3a2e), wrap = cloth(0xb8ad94), rope = M(0x8a7a5a, 0.95);
      for (let i = 0; i < 5; i++) plate(torso, i % 2 ? rag : ragD, ww * 0.2, 0.24 + (i % 3) * 0.1, 0.03, (i - 2) * ww * 0.22, -0.14 - (i % 3) * 0.05, depth * 0.5, 0.1, 0, (i - 2) * 0.1);
      for (let i = 0; i < 4; i++) plate(torso, i % 2 ? ragD : rag, ww * 0.24, 0.2 + ((i + 1) % 3) * 0.1, 0.03, (i - 1.5) * ww * 0.26, -0.12, -depth * 0.5, -0.1, 0, 0);
      waistBelt(w, rope, 0.04, 0.045, 0.02);
      part(torso, GEO.pillY, rope, 0.035, 0.3, 0.035, ww * 0.3, -0.1, depth * 0.44, 0.2, 0, 0.2);
      plate(torso, ragD, cw * 0.4, 0.06, 0.03, 0.1, 0.7, front + 0.04, 0, 0, 0.5); // torn collar
      for (let k = 0; k < 3; k++) band(torso, wrap, 0.145 - k * 0.004, 0.84 + k * 0.03, 0.03); // neck bandage
      for (const sd of sides) stud(torso, M(0x4a2a22), 0.03, sd * 0.1, 0.3 + sd * 0.1, front + 0.03); // old wounds
      for (const [i, a] of arms.entries()) {
        if (i === 0) { for (let k = 0; k < 3; k++) band(a, k % 2 ? wrap : cloth(0xa0957c), 0.12, -0.46 - k * 0.07, 0.05); plate(a, rag, 0.1, 0.16, 0.03, 0.1, -0.3, 0.02, 0, 0, 0.3); }
        else { band(a, rag, 0.135, -0.2, 0.12); plate(a, ragD, 0.08, 0.14, 0.03, -0.1, -0.34, 0.0, 0, 0, -0.4); }
      }
      for (const [k, sh] of shins.entries()) { if (k === 0) legWraps(sh, legs, wrap, cloth(0xa0957c), 3, 0.13); else { band(sh, ragD, 0.14, -0.08 * legs, 0.08); plate(sh, rag, 0.1, 0.16, 0.03, 0.08, -0.2 * legs, 0.04, 0, 0, 0.2); } }
      break;
    }
    case "skeleton": {
      // Risen soldier: half a rusted cuirass, a rope belt, the rags of a tabard, one rusted greave.
      const rust = ironMat(0x6b5444), rustD = ironMat(0x4a3a30), rope = M(0x7a6a4a, 0.95);
      plate(torso, rust, cw * 0.56, 0.42, 0.05, -cw * 0.1, 0.5, front - 0.02, 0.05, 0, 0.1);
      rivets(torso, rustD, [-cw * 0.3, 0.68, front + 0.005], [-cw * 0.3, 0.34, front + 0.01], 3, 0.015);
      plate(torso, rustD, 0.06, 0.5, 0.03, cw * 0.2, 0.5, front - 0.01, 0, 0, -0.4); // broken strap
      waistBelt(w, rope, 0.05, 0.05, 0.02);
      for (let i = 0; i < 4; i++) { const x = (i - 1.5) * ww * 0.24; plate(torso, cloth(i % 2 ? tcd : dark(tcd, 0.7)), ww * 0.2, 0.3 + (i % 3) * 0.1, 0.03, x, -0.16 - (i % 3) * 0.05, cw * 0.27, 0.08, 0, (i - 1.5) * 0.06); plate(torso, cloth(dark(tcd, 0.7)), ww * 0.2, 0.24 + ((i + 1) % 3) * 0.08, 0.03, x, -0.13, -cw * 0.27, -0.08, 0, 0); }
      part(lArm, GEO.dome, rust, 0.16, 0.1, 0.17, 0, 0.0, 0);
      hoop(lArm, rustD, 0.16, 0.0, 0.025, 0, 0.17);
      rivetRing(lArm, rustD, 0.14, 0.15, 0.03, 3, -1.5, 1.5, 0.014);
      band(lArm, rust, 0.1, -0.5, 0.14);
      for (const a of arms) band(a, leather(0x4a3a28), 0.07, -0.6, 0.05);
      for (const [k, sh] of shins.entries()) if (k === 0) { part(sh, GEO.softer, rust, 0.16, 0.3 * legs, 0.14, 0, -0.2 * legs, 0.03); band(sh, rustD, 0.085, -0.36 * legs, 0.03); } else band(sh, rope, 0.07, -0.3 * legs, 0.03);
      cloakFinish(w, cloth(dark(tcd, 0.6)), rustD, false);
      break;
    }
    case "bonearcher": {
      // Risen hunter: ragged hood over the shoulders, leather bracer still laced, bandaged ribs.
      const rag = cloth(tcd), ragD = cloth(dark(tcd, 0.6)), lth = leather(0x4a3826), wrap = cloth(0xb8ad94);
      part(torso, GEO.softer, ragD, cw * 1.4, 0.2, cw * 0.95, 0, 0.74, 0);
      for (let i = 0; i < 8; i++) { const a = (i / 8) * PI * 2; part(torso, GEO.cone, i % 2 ? rag : ragD, 0.06, 0.26 + (i % 3) * 0.06, 0.02, Math.sin(a) * cw * 0.6, 0.56, Math.cos(a) * cw * 0.42, PI, a, 0); }
      for (let k = 0; k < 3; k++) band(torso, wrap, 0.3 + k * 0.01, 0.36 - k * 0.08, 0.03, 0, cw * 0.3);
      waistBelt(w, leather(0x3a2c1c), 0.05, 0.06, 0.02, ironMat(0x6b5444), 0.08);
      for (let i = 0; i < 4; i++) { const x = (i - 1.5) * ww * 0.24; plate(torso, cloth(i % 2 ? tcd : dark(tcd, 0.7)), ww * 0.2, 0.3 + (i % 3) * 0.1, 0.03, x, -0.16 - (i % 3) * 0.05, cw * 0.27, 0.08, 0, (i - 1.5) * 0.06); plate(torso, ragD, ww * 0.2, 0.24 + ((i + 1) % 3) * 0.08, 0.03, x, -0.13, -cw * 0.27, -0.08, 0, 0); }
      scabbard(torso, -1, leather(LEATHER_DARK), ironMat(0x6b5444), 0.24, -ww * 0.5, 0.0, 0.02, 0.3);
      part(torso, GEO.pillY, lth, 0.05, 0.7, 0.025, 0, 0.44, front - 0.03, 0, 0, 0.55);
      part(lArm, GEO.pillY, lth, 0.17, 0.22, 0.18, 0, -0.52, 0);
      for (let k = 0; k < 3; k++) part(lArm, GEO.pillX, cloth(0xd9c79a), 0.08, 0.012, 0.014, 0.085, -0.46 - k * 0.05, 0, 0, PI / 2, k % 2 ? 0.5 : -0.5);
      band(rArm, wrap, 0.075, -0.52, 0.1);
      for (const sh of shins) legWraps(sh, legs, wrap, cloth(0xa0957c), 3, 0.08);
      cloakFinish(w, ragD, ironMat(0x6b5444), false);
      break;
    }
    case "vampire": {
      // Night noble: waistcoat and cravat, coat tails, gilt buttons, a ruby at the throat.
      const coat = silk(0x241f2c), vest = silk(0x3a1a2a), gd = gildMat(), lace = silk(0xf4efe2), ruby = B(0xff2a3c);
      plate(torso, vest, cw * 0.46, 0.56, 0.04, 0, 0.42, front + 0.005);
      rivets(torso, gd, [0.0, 0.64, front + 0.03], [0.0, 0.22, front + 0.03], 5, 0.014);
      for (const sd of sides) plate(torso, coat, cw * 0.2, 0.46, 0.035, sd * cw * 0.3, 0.6, front + 0.012, 0, 0, sd * 0.45); // lapels
      band(torso, lace, 0.15, 0.86, 0.1); // cravat
      part(torso, GEO.cone, lace, 0.08, 0.16, 0.03, 0, 0.72, front + 0.03, PI, 0, 0);
      stud(torso, ruby, 0.025, 0, 0.78, front + 0.05);
      hoop(torso, gd, 0.04, 0.78, 0.01, front + 0.05, 0.04);
      for (const sd of sides) part(torso, GEO.cape, coat, cw * 0.5, 0.86, 0.05, sd * cw * 0.26, 0.02, -depth * 0.5, 0.05, 0, sd * 0.06); // coat tails
      waistBelt(w, silk(0x1c1824), 0.06, 0.1, 0.03, gd, 0.1);
      stud(torso, ruby, 0.02, 0, 0.06, front + 0.06);
      scabbard(torso, 1, lacquer(0x141119), gd, 0.9, ww * 0.5 + 0.04, 0.02, -0.08, 0.45);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        part(a, GEO.dome, coat, 0.2, 0.13, 0.21, 0, 0.02, 0);
        hoop(a, gd, 0.2, 0.02, 0.02, 0, 0.21);
        stud(a, ruby, 0.02, side * 0.14, 0.1, 0.1, side * 0.6);
        band(a, coat, 0.15, -0.6, 0.08);
        rivets(a, gd, [side * 0.15, -0.58, 0.03], [side * 0.15, -0.58, -0.03], 2, 0.012, side * PI / 2);
        band(a, lace, 0.135, -0.67, 0.04);
      }
      for (const sh of shins) { band(sh, lacquer(0x141119), 0.165, -0.26 * legs, 0.08); plate(sh, gd, 0.04, 0.04, 0.02, 0.13, -0.26 * legs, 0.08, 0, 0.6, 0); }
      cloakFinish(w, silk(0x8a1f2a), gd);
      break;
    }
    case "necromancer": {
      // Death priest: bone pauldrons, a ribcage breast ornament, vials, chains and skull charms.
      const robeD = silk(0x1c1626), bone = boneMat(), old = ironMat(0x5a4e66), glow = B(0x8fff6a);
      part(torso, GEO.softer, robeD, cw * 1.5, 0.3, cw * 0.98, 0, 0.7, 0);
      for (const sd of sides) { part(torso, GEO.dome, bone, 0.28, 0.2, 0.28, sd * (cw / 2 + 0.16), 0.8, 0); for (let k = 0; k < 3; k++) part(torso, GEO.cone, bone, 0.03, 0.18, 0.03, sd * (cw / 2 + 0.16 + Math.sin(k * 1.4) * 0.22), 0.84, Math.cos(k * 1.4 + 0.5) * 0.22, 0.5 * Math.cos(k * 1.4 + 0.5), 0, -sd * (0.8 + k * 0.2)); }
      collar(torso, robeD, 0.16, 0.92, 0.14);
      for (let k = 0; k < 4; k++) part(torso, KIT.arc, bone, 0.12 + k * 0.04, 0.05, 0.4, 0, 0.66 - k * 0.09, cw * 0.33 + 0.02, 0, 0, PI); // ribs
      part(torso, GEO.pillY, bone, 0.05, 0.4, 0.03, 0, 0.5, cw * 0.33 + 0.03); // sternum
      part(torso, GEO.sph, bone, 0.06, 0.07, 0.05, 0, 0.3, cw * 0.34 + 0.03);
      stud(torso, glow, 0.012, -0.02, 0.31, cw * 0.34 + 0.08); stud(torso, glow, 0.012, 0.02, 0.31, cw * 0.34 + 0.08);
      band(torso, silk(0x5a3a7a), cw * 0.52, 0.1, 0.11);
      for (let k = 0; k < 3; k++) { part(torso, GEO.cyl, B([0x7dff8a, 0x9a6aff, 0xff6a6a][k]), 0.03, 0.08, 0.03, cw * 0.3 + k * 0.08, -0.02, cw * 0.3 - k * 0.04); part(torso, GEO.cyl, old, 0.02, 0.03, 0.02, cw * 0.3 + k * 0.08, 0.04, cw * 0.3 - k * 0.04); }
      for (let k = 0; k < 4; k++) part(torso, KIT.hoop, old, 0.03, 0.03, 0.4, -cw * 0.44, 0.0 - k * 0.05, cw * 0.2, 0, PI / 2 * (k % 2), 0); // chain
      part(torso, GEO.sph, bone, 0.05, 0.06, 0.045, -cw * 0.44, -0.24, cw * 0.2);
      hoop(torso, old, 0.57, -0.84, 0.03, 0, 0.57);
      for (let i = 0; i < 7; i++) { const a = (i / 7) * PI * 2; part(torso, GEO.cone, robeD, 0.07, 0.3, 0.02, Math.sin(a) * 0.6, -1.0, Math.cos(a) * 0.6, PI, a, 0); } // tattered under-hem
      for (let i = 0; i < 7; i++) { const a = (i / 7) * PI * 2 + 0.4; stud(torso, glow, 0.018, Math.sin(a) * 0.6, -0.9, Math.cos(a) * 0.6, a); }
      for (const [i, a] of arms.entries()) { band(a, old, 0.165, -0.6, 0.03); band(a, robeD, 0.15, -0.12, 0.07); for (let k = 0; k < 2; k++) part(a, GEO.cone, bone, 0.025, 0.12, 0.025, (i === 0 ? 1 : -1) * 0.16, -0.62 - k * 0.07, (k - 0.5) * 0.08, PI, 0, 0); }
      cloakFinish(w, silk(0x4a2a5a), old, false);
      break;
    }

    /* ================= OUTLAND ================= */
    case "hoplite": {
      // Bronze hoplite: epomides over the shoulders, baldric, strapped greaves, tunic folds.
      const bz = gold(0xb8873a), bzL = gildMat(0xd2a455), bzD = gold(0x8a6428), lth = waxLeather(0x6b4a2a), tun = cloth(0x8a2a24);
      for (const sd of sides) { plate(torso, bz, 0.2, 0.05, 0.4, sd * cw * 0.3, 0.84, 0, 0, 0, -sd * 0.1); rivets(torso, bzL, [sd * cw * 0.3, 0.87, 0.14], [sd * cw * 0.3, 0.87, -0.14], 2, 0.016, 0, ); plate(torso, bz, 0.2, 0.2, 0.04, sd * cw * 0.3, 0.74, front - 0.01, 0.1); }
      part(torso, GEO.pillY, lth, 0.08, 0.9, 0.03, 0, 0.44, front + 0.012, 0, 0, 0.5); // baldric
      part(torso, GEO.pillY, lth, 0.08, 0.9, 0.03, 0, 0.44, -front - 0.012, 0, 0, -0.5);
      stud(torso, bzL, 0.03, -cw * 0.22, 0.66, front + 0.03);
      part(torso, GEO.blade, bzL, 0.05, 0.03, 0.3, 0, 0.44, front + 0.025, PI / 2, 0, 0); // abdominal line
      for (const sd of sides) part(torso, KIT.arc, bzL, 0.1, 0.06, 0.3, sd * cw * 0.2, 0.42, front + 0.02, 0, 0, 0); // muscle lines
      waistBelt(w, lth, 0.1, 0.07, 0.03, bzL, 0.1);
      part(torso, GEO.robe, tun, ww * 0.7, 0.3, depth * 0.68, 0, -0.08, 0);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        for (let k = 0; k < 3; k++) plate(a, k % 2 ? lth : cloth(tc), 0.07, 0.16, 0.03, side * 0.1, -0.02 - k * 0.02, (k - 1) * 0.09, 0, 0, -side * 0.5); // shoulder pteruges
        band(a, lth, 0.13, -0.3, 0.025);
        if (i === 1) { part(a, GEO.softer, bz, 0.2, 0.26, 0.3, side * 0.02, -0.52, 0.0); band(a, bzD, 0.135, -0.4, 0.025); band(a, bzD, 0.145, -0.64, 0.03); }
        else band(a, lth, 0.135, -0.6, 0.05);
      }
      for (const sh of shins) { greave(sh, legs, bz, bzL, { ridge: false, knee: true }); for (let k = 0; k < 2; k++) band(sh, lth, 0.125, -0.12 * legs - k * 0.12 * legs, 0.02); }
      cloakFinish(w, cloth(0xb04a40), bzL, false);
      break;
    }
    case "samurai": {
      // Samurai: laced plates everywhere, haidate on the thighs, splinted suneate, an obi knot at the back.
      const lac = lacquer(0x2a2228), lacL = lacquer(0x3a3038), cord = silk(tc), gd = gildMat(), obi = silk(0x8a1f2a);
      // Dou lacing rows and a crest.
      for (let k = 0; k < 4; k++) for (let c = -2; c <= 2; c++) plate(torso, cord, 0.025, 0.05, 0.02, c * cw * 0.16, 0.2 + k * 0.17 + 0.035, front + 0.02);
      hoop(torso, gd, 0.07, 0.62, 0.012, front + 0.04, 0.07);
      waistBelt(w, obi, 0.1, 0.14, 0.04);
      part(torso, GEO.softer, obi, 0.3, 0.14, 0.12, 0, 0.1, -front - 0.08); // obi knot
      for (const sd of sides) plate(torso, obi, 0.12, 0.3, 0.04, sd * 0.1, -0.1, -front - 0.07, -0.15, 0, sd * 0.2);
      for (let k = 0; k < 5; k++) plate(torso, lac, cw * 0.2, 0.36, 0.05, (k - 2) * cw * 0.215, -0.1, -cw * 0.31, 0.12, 0, 0); // rear kusazuri
      for (let k = 0; k < 5; k++) plate(torso, cord, cw * 0.2, 0.03, 0.056, (k - 2) * cw * 0.215, -0.24, -cw * 0.325, 0.12, 0, 0);
      for (let k = 0; k < 3; k++) part(torso, GEO.cone, cord, 0.03, 0.2, 0.012, (k - 1) * 0.06, 0.26, -front - 0.1, PI, 0, (k - 1) * 0.3); // agemaki tassel
      part(torso, GEO.sph, cord, 0.05, 0.05, 0.03, 0, 0.5, -front - 0.1);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        for (let k = 0; k < 3; k++) band(a, k === 1 ? cord : lacL, 0.13, -0.1 - k * 0.07, 0.04); // kote lames
        plate(a, lac, 0.04, 0.26, 0.09, side * 0.13, -0.52, 0.0, 0, 0, -side * 0.05); // kote plate
        plate(a, gd, 0.02, 0.1, 0.03, side * 0.15, -0.5, 0.0);
        band(a, cord, 0.135, -0.64, 0.03);
      }
      for (const [i, th] of thighs.entries()) { const side = i === 0 ? 1 : -1; plate(th, lac, 0.22, 0.3, 0.035, side * 0.02, -0.26 * legs, 0.15, -0.1); for (let r = 0; r < 2; r++) for (let c = 0; c < 2; c++) plate(th, cord, 0.03, 0.03, 0.02, side * 0.02 + (c - 0.5) * 0.08, -0.2 * legs - r * 0.1, 0.17); }
      for (const sh of shins) { bracerShin(sh, legs, lac, cord); }
      break;
    }
    case "ninja": {
      // Shinobi: crossed chest wraps, cross-laced arm guards, kunai pouch on the thigh, a scroll at the belt.
      const wrap = cloth(0x1d2028), wrapD = cloth(0x14151a), cord = cloth(tc), st = steel(STEEL_DARK);
      for (const sd of sides) part(torso, GEO.pillY, wrapD, 0.12, 0.9, 0.035, 0, 0.44, front + 0.005, 0, 0, sd * 0.5);
      for (const sd of sides) part(torso, GEO.pillY, wrapD, 0.12, 0.9, 0.035, 0, 0.44, -front - 0.005, 0, 0, sd * 0.5);
      plate(torso, st, 0.1, 0.1, 0.02, 0, 0.52, front + 0.03, 0, 0, PI / 4); // crossing plate
      waistBelt(w, cord, 0.06, 0.1, 0.02);
      part(torso, GEO.softer, cord, 0.2, 0.1, 0.1, 0, 0.06, -front - 0.06); // knot
      for (const sd of sides) plate(torso, cord, 0.08, 0.34, 0.03, sd * 0.08, -0.14, -front - 0.05, -0.1, 0, sd * 0.25);
      part(torso, GEO.cyl, M(0xd8c8a8, 0.8), 0.035, 0.2, 0.035, -ww * 0.46, -0.04, 0.04, PI / 2 - 0.3, 0, 0); // scroll
      hoop(torso, cord, 0.038, -0.04, 0.012, 0.04, 0.038, -ww * 0.46);
      for (let k = 0; k < 2; k++) plate(torso, st, 0.09, 0.09, 0.012, -0.12 + k * 0.1, 0.1, -cw * 0.34 - 0.02, 0, 0, PI / 4); // stars at the back
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, wrapD, 0.135, -0.18, 0.05);
        part(a, GEO.pillY, wrapD, 0.26, 0.26, 0.27, 0, -0.52, 0);
        for (let k = 0; k < 4; k++) part(a, GEO.pillX, cord, 0.12, 0.012, 0.012, side * 0.13, -0.42 - k * 0.06, 0, 0, side * PI / 2, k % 2 ? 0.7 : -0.7);
        plate(a, st, 0.03, 0.2, 0.06, side * 0.14, -0.52, 0.0);
      }
      for (const [i, th] of thighs.entries()) if (i === 1) { band(th, wrapD, 0.15, -0.24 * legs, 0.05); plate(th, wrapD, 0.1, 0.14, 0.05, -0.12, -0.28 * legs, 0.06, 0.1, 0, -0.1); for (let k = 0; k < 3; k++) part(th, GEO.cone, st, 0.012, 0.07, 0.008, -0.12, -0.18 * legs, 0.03 + k * 0.03, 0, 0, 0); }
      for (const sh of shins) { legWraps(sh, legs, wrap, wrapD, 4, 0.135); for (let k = 0; k < 3; k++) part(sh, GEO.pillX, cord, 0.1, 0.01, 0.01, 0, -0.05 * legs - k * 0.07 * legs, 0.14, 0, 0, k % 2 ? 0.6 : -0.6); band(sh, wrapD, 0.15, -0.32 * legs, 0.05); }
      break;
    }
    case "harpooner": {
      // Whaler: oilskin coat with wide lapels, knife belt, net bundle, sea boots folded at the knee.
      const oil = waxLeather(0x3f6a78), oilD = waxLeather(0x2f5260), rope = M(0xc9b27a, 0.95), brass = gold(BRASS);
      for (const sd of sides) plate(torso, oilD, cw * 0.22, 0.4, 0.04, sd * cw * 0.28, 0.66, front + 0.01, 0, 0, sd * 0.4); // lapels
      for (const sd of sides) part(torso, GEO.cape, oil, cw * 0.46, 0.66, 0.05, sd * cw * 0.28, 0.1, -depth * 0.46, 0.05, 0, sd * 0.06); // coat skirts
      for (const sd of sides) part(torso, GEO.cape, oil, cw * 0.36, 0.5, 0.05, sd * cw * 0.32, 0.02, depth * 0.46, 0, PI, -sd * 0.06);
      for (let k = 0; k < 3; k++) plate(torso, brass, 0.04, 0.04, 0.02, cw * 0.08, 0.26 + k * 0.14, front + 0.03); // toggles
      waistBelt(w, waxLeather(0x3a2c1c), 0.06, 0.1, 0.04, brass, 0.11);
      scabbard(torso, -1, waxLeather(0x3a2c1c), steel(STEEL_DARK), 0.3, -ww * 0.5 - 0.02, 0.02, 0.02, 0.3); // gutting knife
      part(torso, GEO.softer, rope, 0.26, 0.2, 0.14, ww * 0.3, 0.3, -depth * 0.6); // net bundle
      for (let k = 0; k < 3; k++) hoop(torso, M(0xa88f62, 0.95), 0.1 - k * 0.02, 0.22 + k * 0.08, 0.012, -depth * 0.6, 0.06, ww * 0.3);
      part(torso, GEO.sph, cloth(0xd8402a), 0.07, 0.07, 0.07, -ww * 0.3, 0.3, -depth * 0.6); // float
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, oilD, 0.14, -0.1, 0.05);
        band(a, oil, 0.16, -0.5, 0.08); // rolled sleeve
        band(a, oilD, 0.15, -0.46, 0.02);
        if (i === 0) part(a, GEO.cone, steel(STEEL_LIGHT), 0.02, 0.08, 0.012, side * 0.14, -0.3, 0.06, 0, 0, side * 2.6); // fish hook
      }
      for (const sh of shins) { band(sh, waxLeather(0x241d16), 0.18, -0.2 * legs, 0.14); band(sh, waxLeather(0x1a1410), 0.19, -0.14 * legs, 0.03); }
      break;
    }
    case "snakearcher": {
      // Desert archer: layered sash wraps, gold armlets, snakeskin bracer, bead strands.
      const sash = silk(0xefe6cc), sashD = silk(0xd9cfae), gd = gildMat(), snake = waxLeather(0x4d6a2c), snakeL = waxLeather(0x6a8a3a), lth = leather(0x4a3826);
      for (let k = 0; k < 3; k++) band(torso, k % 2 ? sash : sashD, ww * 0.5 + 0.03 + k * 0.004, 0.12 - k * 0.055, 0.05, 0, depth * 0.52 + 0.03);
      part(torso, GEO.pillY, sashD, 0.16, 0.9, 0.04, 0, 0.44, front + 0.005, 0, 0, -0.5);
      part(torso, GEO.pillY, sashD, 0.16, 0.9, 0.04, 0, 0.44, -front - 0.005, 0, 0, 0.5);
      stud(torso, gd, 0.03, cw * 0.22, 0.66, front + 0.025);
      stud(torso, B(0x3fd08a), 0.016, cw * 0.22, 0.66, front + 0.04);
      necklace(torso, B(0xd8402a), cw, 9, 0.7, 0.1, cw * 0.3, 0.014);
      necklace(torso, gd, cw, 7, 0.66, 0.14, cw * 0.26, 0.016, { mat: gd, r: 0.035 });
      pouch(torso, ww * 0.44, -0.03, depth * 0.3, 0.1, 0.12, 0.08, lth, leather(0x3a2c1c), gd, -0.3);
      part(torso, GEO.pillY, sashD, 0.1, 0.36, 0.03, -ww * 0.4, -0.16, depth * 0.4, 0.2, 0, 0.1); // sash tail
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        band(a, gd, 0.135, -0.16, 0.04);
        band(a, gd, 0.13, -0.22, 0.02);
        if (i === 0) { for (let k = 0; k < 4; k++) band(a, k % 2 ? snake : snakeL, 0.125 + k * 0.004, -0.42 - k * 0.055, 0.05); band(a, gd, 0.14, -0.63, 0.025); }
        else bracer(a, side, "wrap", sash, sashD);
      }
      for (const sh of shins) for (let k = 0; k < 4; k++) { band(sh, lth, 0.12 + k * 0.004, -0.05 * legs - k * 0.07 * legs, 0.022); plate(sh, lth, 0.025, 0.07, 0.03, 0, -0.085 * legs - k * 0.07 * legs, 0.125, 0, 0, -0.5); }
      break;
    }
    case "valkyrie": {
      // Shield-maiden of the sky: feathered pauldrons, knotwork cuirass, gold discs on the belt, winged greaves.
      const pl = plateMat(0xdfe5ee), gd = gildMat(), feather = cloth(0xf6f3ea), featherD = cloth(0xe2dccb);
      part(torso, KIT.arc, gd, 0.14, 0.08, 0.4, 0, 0.56, front + 0.02, 0, 0, 0);
      part(torso, KIT.arc, gd, 0.14, 0.08, 0.4, 0, 0.56, front + 0.02, 0, 0, PI);
      for (const sd of sides) part(torso, KIT.arc, gd, 0.1, 0.06, 0.3, sd * cw * 0.26, 0.6, front + 0.015, 0, 0, sd * 0.8);
      part(torso, GEO.pillY, pl, 0.32, 0.1, 0.3, 0, 0.9, 0);
      hoop(torso, gd, 0.16, 0.95, 0.025);
      waistBelt(w, waxLeather(0x3a2c1c), 0.1, 0.07, 0.04, gd, 0.1);
      for (let i = -2; i <= 2; i++) if (i) stud(torso, gd, 0.028, Math.sin(i * 0.5) * (ww * 0.5 + 0.04), 0.1, Math.cos(i * 0.5) * (depth * 0.5 + 0.04), i * 0.5);
      for (const sd of sides) part(torso, GEO.pillY, waxLeather(0x3a2c1c), 0.05, 0.3, 0.025, sd * ww * 0.2, -0.1, front - 0.02, 0.05, 0, 0);
      for (const [i, a] of arms.entries()) {
        const side = i === 0 ? 1 : -1;
        part(a, GEO.dome, pl, 0.21, 0.13, 0.22, side * 0.01, 0.03, 0);
        hoop(a, gd, 0.21, 0.03, 0.025, 0, 0.22, side * 0.01);
        for (let k = 0; k < 4; k++) part(a, GEO.cone, k % 2 ? featherD : feather, 0.05, 0.22 - k * 0.02, 0.015, side * (0.1 + k * 0.03), -0.02 - k * 0.06, (k - 1.5) * 0.08, 0, 0, -side * (0.6 + k * 0.1)); // feather lames
        band(a, gd, 0.135, -0.24, 0.03);
        band(a, gd, 0.13, -0.28, 0.02);
        part(a, GEO.softer, pl, 0.2, 0.26, 0.3, side * 0.02, -0.52, 0.0);
        band(a, gd, 0.125, -0.4, 0.025); band(a, gd, 0.145, -0.64, 0.03);
        part(a, GEO.cone, gd, 0.03, 0.12, 0.012, side * 0.13, -0.5, 0.0, 0, 0, side * 0.3);
      }
      for (const sh of shins) { greave(sh, legs, pl, gd, { knee: true }); for (const sd of sides) part(sh, GEO.cone, gd, 0.025, 0.1, 0.012, sd * 0.12, -0.1 * legs, 0.06, -0.3, 0, sd * 0.7); }
      break;
    }
    case "fanbearer": {
      // Court official: crossed lapels, rank badge, jade pendant on a long cord, hanging ornaments at the belt.
      const robeD = silk(0xd4ccb2), red = silk(0xb23a3a), jade = B(0x5fbf8a), gd = gildMat();
      for (const sd of sides) plate(torso, robeD, cw * 0.3, 0.5, 0.035, sd * cw * 0.2, 0.62, front + 0.008, 0, 0, sd * 0.55); // crossed lapels
      plate(torso, red, 0.04, 0.5, 0.03, -0.02, 0.6, front + 0.02, 0, 0, 0.55); // lapel piping
      plate(torso, red, cw * 0.4, cw * 0.4, 0.025, 0, 0.44, front + 0.03); // rank badge
      plate(torso, gd, cw * 0.42, 0.02, 0.028, 0, 0.44 + cw * 0.2, front + 0.03);
      plate(torso, gd, cw * 0.42, 0.02, 0.028, 0, 0.44 - cw * 0.2, front + 0.03);
      part(torso, GEO.cone, gd, 0.06, 0.1, 0.015, 0, 0.5, front + 0.045, 0, 0, 0); // crane motif
      for (const sd of sides) part(torso, GEO.cone, gd, 0.08, 0.04, 0.012, sd * 0.07, 0.44, front + 0.045, 0, 0, -sd * 1.2);
      waistBelt(w, red, 0.1, 0.12, 0.03, gd, 0.1);
      waistBelt(w, gd, 0.1, 0.03, 0.045);
      for (let k = 0; k < 3; k++) part(torso, GEO.cyl, k === 1 ? jade : gd, 0.03, 0.05 + (k === 1 ? 0.05 : 0), 0.03, (k - 1) * 0.1, -0.04 - (k === 1 ? 0.03 : 0), depth * 0.52 + 0.02); // belt ornaments
      for (let k = 0; k < 3; k++) part(torso, GEO.cyl, red, 0.01, 0.1, 0.01, (k - 1) * 0.1, 0.0, depth * 0.52 + 0.02);
      part(torso, GEO.pillY, red, 0.03, 0.9, 0.012, cw * 0.1, 0.4, front + 0.012); // pendant cord
      part(torso, GEO.cyl, jade, 0.05, 0.015, 0.05, cw * 0.1, -0.06, front + 0.03, PI / 2, 0, 0); // jade disc
      fringe(torso, red, 3, cw * 0.07, cw * 0.13, -0.11, front + 0.03, 0.14);
      for (const sd of sides) part(torso, GEO.pillY, red, 0.06, 0.4, 0.025, sd * 0.1, -0.16, -front - 0.03, -0.1, 0, sd * 0.15); // sash ends at the back
      for (const a of arms) { band(a, red, 0.165, -0.6, 0.03); band(a, robeD, 0.15, -0.12, 0.07); band(a, silk(0xe9e2cc), 0.148, -0.19, 0.02); }
      for (const sh of shins) { band(sh, lacquer(0x17161c), 0.15, -0.28 * legs, 0.06); band(sh, cloth(0xf4f1e6), 0.145, -0.36 * legs, 0.03); }
      break;
    }
  }
}

/**
 * Mounted knight's harness: the rider has no leg bones of its own, so everything hangs from the torso and arms.
 * Lance-side pauldron is heavier, a surcoat covers the saddle plates, the sword rides on the left hip.
 */
export function dressRider(torso: G, lArm: G, rArm: G, tc: number) {
  const pl = plateMat(0xc9d1dc), tr = gold(BRASS), dk = steel(STEEL_DARK), front = 0.22;
  part(torso, GEO.pillY, pl, 0.3, 0.1, 0.28, 0, 0.9, 0); // gorget
  hoop(torso, tr, 0.15, 0.95, 0.022);
  part(torso, GEO.blade, pl, 0.06, 0.05, 0.34, 0, 0.5, front + 0.02, PI / 2, 0, 0);
  for (const sd of [-1, 1]) rivets(torso, tr, [sd * 0.26, 0.74, front], [sd * 0.26, 0.4, front + 0.01], 3);
  plate(torso, pl, 0.6, 0.14, 0.05, 0, 0.28, front - 0.005, 0.12); // plackart
  for (const sd of [-1, 1]) part(torso, GEO.cape, silk(tc), 0.34, 0.5, 0.04, sd * 0.2, 0.04, sd * 0 + (sd > 0 ? 0.2 : -0.2), 0, sd > 0 ? PI : 0, 0); // surcoat skirts front/back
  for (let k = 0; k < 2; k++) band(torso, pl, 0.34 + k * 0.02, 0.0 - k * 0.06, 0.06, 0, 0.26 + k * 0.02);
  hoop(torso, tr, 0.4, -0.1, 0.022, 0, 0.3);
  part(torso, GEO.pillY, waxLeather(LEATHER_DARK), 0.74, 0.07, 0.48, 0, 0.1, 0);
  plate(torso, tr, 0.11, 0.06, 0.03, 0, 0.1, front + 0.04);
  scabbard(torso, 1, lacquer(0x1d1a22), tr, 0.8, 0.37, 0.02, -0.06, 0.5);
  for (const [i, a] of [lArm, rArm].entries()) {
    const side = i === 0 ? 1 : -1;
    pauldron(a, side, pl, tr, i === 1 ? 0.22 : 0.18, i === 1 ? 3 : 1, { studs: i === 1 });
    band(a, dk, 0.12, -0.22, 0.045);
    part(a, GEO.cone, pl, 0.07, 0.14, 0.035, side * 0.11, -0.39, -0.02, 0, 0, -side * PI / 2);
    part(a, GEO.softer, pl, 0.19, 0.24, 0.26, side * 0.02, -0.52, 0.0);
    band(a, tr, 0.11, -0.41, 0.025);
    band(a, tr, 0.125, -0.63, 0.03);
  }
}

/** Samurai suneate: splinted shin guards laced with cord. */
function bracerShin(sh: G, legs: number, lac: Mat, cord: Mat) {
  band(sh, cloth(0x23262e), 0.135, -0.18 * legs, 0.3 * legs);
  for (let i = 0; i < 5; i++) {
    const ang = -0.8 + i * 0.4;
    plate(sh, lac, 0.035, 0.28 * legs, 0.03, Math.sin(ang) * 0.14, -0.18 * legs, Math.cos(ang) * 0.14, 0, ang, 0);
  }
  band(sh, cord, 0.145, -0.06 * legs, 0.025);
  band(sh, cord, 0.145, -0.3 * legs, 0.025);
}

/* ============================================================ */

export function detailTorso(kind: HumanKind, t: THREE.Group, cw: number, tc: number) {
  const front = cw * 0.325;
  if (kind === "spear" || kind === "guardian" || kind === "swordsman" || kind === "halberdier" || kind === "paladin" || kind === "king") {
    const m = kind === "king" ? gildMat() : kind === "paladin" ? plateMat(0xe2e6ee) : plateMat(0xc9d1dc);
    part(t, GEO.cyl, m, 0.21, 0.14, 0.21, 0, 0.85, 0.01);
    for (const s of [-1, 1]) part(t, KIT.hoop, gold(BRASS), 0.22, 0.22, 0.4, s * (cw / 2 + 0.11), 0.71, 0, PI / 2, 0, 0);
  }
  if (kind === "spear" || kind === "halberdier" || kind === "guardian") {
    // Unit badge on the breast.
    stud(t, gold(BRASS), 0.04, cw * 0.22, 0.66, front + 0.03);
    part(t, GEO.cone, cloth(tc), 0.025, 0.05, 0.012, cw * 0.22, 0.66, front + 0.05, PI, 0, 0);
  }
  if (kind === "paladin") { part(t, GEO.sph, B(0x8ff4ff), 0.05, 0.05, 0.035, 0, 0.5, front + 0.06); part(t, GEO.ring, gold(), 0.26, 0.26, 0.26, 0, 1.02, -0.22); }
  if (kind === "king") {
    part(t, GEO.softer, silk(0xf7f4eb), cw + 0.18, 0.2, cw * 0.76, 0, 0.8, -0.02); // ermine
    for (let i = -2; i <= 2; i++) stud(t, B(0x1c1816), 0.014, i * 0.18, 0.78, cw * 0.38);
    for (let i = -1; i <= 1; i++) stud(t, B(0x1c1816), 0.014, i * 0.2, 0.78, -cw * 0.38, PI);
  }
  if (kind === "pirate") {
    plate(t, cloth(0xdfd6c2), cw * 0.46, 0.7, 0.03, 0, 0.46, front - 0.02);
    for (let k = 0; k < 4; k++) stud(t, gildMat(), 0.016, 0.05, 0.3 + k * 0.1, front + 0.015);
  }
  if (kind === "zeus") { part(t, GEO.sph, B(0x9fe0ff), 0.06, 0.06, 0.04, 0, 0.1, front + 0.06); }
  if (kind === "orc" || kind === "berserker") for (const s of [-1, 1]) part(t, GEO.sph, M(0x6e8a48, 0.65), 0.19, 0.15, 0.1, s * 0.18, 0.63, cw * 0.3);
  if (kind === "troll") for (let i = 0; i < 3; i++) part(t, GEO.cone, M(0x3a542a), 0.05, 0.14, 0.05, 0, 0.36 + i * 0.15, -cw * 0.34, -PI / 2, 0, 0);
  if (kind === "giant") part(t, KIT.hoop, ironMat(), 0.12, 0.12, 0.6, 0, 0.74, cw * 0.34);
  if (kind === "vampire") part(t, GEO.bevel, silk(0x1a1220), 0.56, 0.34, 0.06, 0, 0.96, -0.14, -0.25, 0, 0);
  if (kind === "monk") for (let i = 0; i < 10; i++) stud(t, i % 2 === 0 ? horn(0x5c3818) : gildMat(), 0.028, Math.cos(i * PI / 5) * 0.24, 0.76 - Math.abs(Math.sin(i * PI / 5)) * 0.06, Math.sin(i * PI / 5) * 0.22, i * PI / 5 + PI / 2);
}

/* ============================================================ */

/**
 * Head accessories. The face (eyes, brows, nose, mouth) is built elsewhere and is never touched:
 * everything here sits on the crown (y > 0.14), at the sides (|x| > 0.25) or behind the ears (z < 0.05).
 */
export function detailHead(kind: HumanKind, h: THREE.Group, tc: number, tcl: number, skin: number) {
  void tcl;
  const aventail = (mat: Mat, w = 0.56, len = 0.36) => part(h, GEO.cape, mat, w, len, 0.05, 0, -0.1, -0.2, 0.25, 0, 0);
  const earring = (mat: Mat, side: number, r = 0.035) => part(h, KIT.hoop, mat, r, r, 0.3, side * 0.31, -0.08, 0.0, 0, PI / 2, 0);
  switch (kind) {
    case "spear":
      aventail(mail());
      break;
    case "guardian":
      break;
    case "swordsman":
      break;
    case "halberdier":
      for (const s of [-1, 1]) plate(h, waxLeather(LEATHER_DARK), 0.025, 0.24, 0.05, s * 0.27, -0.14, -0.04); // chin straps along the jaw sides
      break;
    case "paladin":
      break;
    case "king":
      break;
    case "crossbow":
      hoop(h, cloth(0x6b5e44), 0.3, 0.06, 0.03, 0, 0.3); // arming-cap edge under the brim
      for (const s of [-1, 1]) plate(h, waxLeather(LEATHER_DARK), 0.02, 0.26, 0.04, s * 0.27, -0.12, -0.04, 0, 0, s * 0.05);
      break;
    case "archer":
      break;
    case "orc":
      for (const s of [-1, 1]) earring(ironMat(0x6b7078), s, 0.04);
      break;
    case "berserker":
      for (let i = 0; i < 4; i++) stud(h, horn(0xe8e0c8), 0.02, 0.12 + i * 0.02, 0.1 - i * 0.1, -0.24 - i * 0.02, PI); // beads in a back braid
      part(h, GEO.pillY, hide(0x8a5a32), 0.05, 0.36, 0.05, 0.12, -0.14, -0.26, 0.3, 0, -0.1);
      earring(gold(BRASS), -1, 0.03);
      break;
    case "javelin":
      break;
    case "bomber":
      for (const s of [-1, 1]) plate(h, hide(0x5a4530), 0.05, 0.14, 0.12, s * 0.29, -0.14, -0.02); // ear flaps
      break;
    case "shaman":
      for (const s of [-1, 1]) part(h, GEO.cone, horn(0xd4cbb0), 0.075, 0.36, 0.075, s * 0.32, 0.18, 0.0, 0.2, 0, -s * 0.85);
      for (let i = 0; i < 5; i++) part(h, GEO.cone, cloth([0xd8402a, 0xd8cfb0, 0x2f4a3a, 0xe8c050, 0xd8cfb0][i]), 0.03, 0.34, 0.012, (i - 2) * 0.08, 0.3, -0.2 - Math.abs(i - 2) * 0.02, -1.2 + Math.abs(i - 2) * 0.1, 0, (i - 2) * 0.25); // feather fan at the back
      for (const s of [-1, 1]) for (let k = 0; k < 3; k++) stud(h, B([0xd8402a, 0xe8c050, 0x3fa0c0][k]), 0.016, s * 0.3, -0.04 - k * 0.05, -0.08, s * PI / 2);
      break;
    case "troll":
      for (const s of [-1, 1]) earring(ironMat(0x6b7078), s, 0.045);
      part(h, GEO.sph, hide(0x4e6a3a), 0.12, 0.05, 0.1, 0.1, 0.3, -0.1); // moss
      part(h, GEO.sph, M(0xa88f62, 0.95), 0.06, 0.06, 0.05, 0, 0.1, -0.3); // rope knot at the back
      break;
    case "giant":
      part(h, GEO.sph, M(0x3a2a1a, 0.9), 0.1, 0.1, 0.1, 0, 0.34, -0.1); // topknot
      part(h, GEO.cone, boneMat(), 0.02, 0.26, 0.02, 0, 0.36, -0.1, 0, 0, PI / 2);
      earring(gold(BRASS), 1, 0.045);
      break;
    case "pirate":
      earring(gildMat(), 1, 0.045);
      break;
    case "sapper":
      for (const s of [-1, 1]) plate(h, cloth(tc), 0.06, 0.26, 0.03, s * 0.08, -0.1, -0.3, 0.4, 0, s * 0.3); // bandana tails
      part(h, GEO.sph, cloth(tc), 0.06, 0.05, 0.05, 0, 0.08, -0.3);
      break;
    case "elf":
      part(h, GEO.cape, M(0xe8d9a0, 0.8), 0.4, 0.7, 0.05, 0, -0.2, -0.22, 0.15, 0, 0); // long hair
      band(h, waxLeather(0x4a3826), 0.1, -0.3, 0.04, -0.3);
      break;
    case "monk":
      for (let i = 0; i < 3; i++) stud(h, horn(0x5c3818), 0.02, 0.0, -0.1 - i * 0.07, -0.3, PI); // beads down the back
      break;
    case "assassin":
      break;
    case "mage":
      break;
    case "frost":
      break;
    case "cleric":
      break;
    case "zombie":
      band(h, cloth(0xb8ad94), 0.27, 0.18, 0.05, -0.01, 0.27); // bandage around the crown
      plate(h, cloth(0xb8ad94), 0.08, 0.2, 0.03, -0.26, 0.0, -0.1, 0, 0, 0.2); // loose end
      break;
    case "skeleton":
      break;
    case "bonearcher":
      break;
    case "vampire":
      part(h, GEO.cape, silk(0x141018), 0.36, 0.5, 0.05, 0, -0.2, -0.22, 0.15, 0, 0); // slicked hair sweeping back
      earring(gildMat(), -1, 0.025);
      stud(h, B(0xff2a3c), 0.012, -0.31, -0.12, 0.0, -PI / 2);
      break;
    case "necromancer":
      for (const s of [-1, 1]) { stud(h, boneMat(), 0.03, s * 0.3, -0.16, -0.12, s * PI / 2); part(h, GEO.pillY, ironMat(0x5a4e66), 0.008, 0.16, 0.008, s * 0.3, -0.06, -0.12); }
      break;
    case "hoplite":
      break;
    case "samurai":
      part(h, GEO.pillY, silk(tc), 0.03, 0.3, 0.03, 0, -0.1, -0.36, 0.3, 0, 0); // helmet cord tail
      break;
    case "ninja":
      part(h, GEO.sph, cloth(tc), 0.06, 0.05, 0.05, 0, 0.0, -0.3); // knot at the back
      break;
    case "harpooner":
      part(h, GEO.cone, steel(STEEL_LIGHT), 0.015, 0.07, 0.01, 0.26, 0.14, 0.06, 0, 0, 2.6); // hook pinned to the cap
      break;
    case "snakearcher":
      for (const s of [-1, 1]) for (let k = 0; k < 3; k++) stud(h, B([0xd8402a, 0xe8c050, 0x3fd08a][k]), 0.015, s * 0.31, 0.0 - k * 0.05, -0.1, s * PI / 2); // bead strands
      part(h, GEO.cape, silk(0xefe6cc), 0.46, 0.4, 0.05, 0, -0.16, -0.22, 0.2, 0, 0); // neck cloth
      break;
    case "valkyrie":
      break;
    case "fanbearer":
      for (const s of [-1, 1]) plate(h, silk(0xb23a3a), 0.03, 0.36, 0.012, s * 0.06, -0.1, -0.3, 0.2, 0, s * 0.1); // ribbons
      break;
    case "zeus":
      hoop(h, gildMat(), 0.08, -0.1, 0.02, -0.3, 0.08); // hair ring at the back
      break;
  }
  void skin;
}
