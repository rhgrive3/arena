import * as THREE from "three";
import { GEO, M } from "./units";
import {
  B, BONE, BONE_DARK, BRASS, GOLD, GOLD_LIGHT, IRON, LEATHER, LEATHER_DARK, PI, STEEL_DARK, STEEL_LIGHT, hide,
  boneMat, cloth, dark, gildMat, gold, horn, ironMat, lacquer, leather, light, part, plateMat, silk, steel, waxLeather,
} from "./rig-kit";

/* ============================================================
   Armory: sculpted weapons and shields.
   Every piece is generated as real geometry (lathed hilts, tapered
   and bevelled blades, wedge-ground axe heads, dished shields) and
   then dropped onto a bone like any other part, so it bakes into the
   same vertex-coloured batch and costs no extra draw calls.
   Conventions in the weapon hand: the weapon runs along +Z from the
   grip, blades are broad along Y and thin along X, and a chopping
   edge faces -Y (the direction of the downswing).
   ============================================================ */

type G = THREE.Object3D;
type Mat = THREE.Material;
type V2 = [number, number];
type V3 = [number, number, number];

const smoothstep = (a: number, b: number, x: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/* ---------------- geometry kit ---------------- */

/** Gives a generated geometry the attribute layout every baked primitive shares (indexed, normal, uv). */
function finish(g: THREE.BufferGeometry, flat: boolean): THREE.BufferGeometry {
  g.clearGroups();
  if (flat && g.index) g = g.toNonIndexed();
  if (flat || !g.attributes.normal) g.computeVertexNormals();
  const n = g.attributes.position.count;
  g.setAttribute("uv", new THREE.Float32BufferAttribute(new Float32Array(n * 2), 2));
  if (!g.index) g.setIndex(Array.from({ length: n }, (_, i) => i));
  return g;
}

/** Flat-shaded triangle soup → geometry. Each triangle is turned to face away from `inside(c)`. */
function soup(tris: THREE.Vector3[][], outward: (c: THREE.Vector3) => THREE.Vector3): THREE.BufferGeometry {
  const pos: number[] = [];
  const e1 = new THREE.Vector3(), e2 = new THREE.Vector3(), n = new THREE.Vector3(), c = new THREE.Vector3();
  for (const [a, b, d] of tris) {
    e1.subVectors(b, a); e2.subVectors(d, a); n.crossVectors(e1, e2);
    if (n.lengthSq() < 1e-14) continue;
    c.copy(a).add(b).add(d).multiplyScalar(1 / 3);
    const flip = n.dot(outward(c)) < 0;
    for (const p of flip ? [a, d, b] : [a, b, d]) pos.push(p.x, p.y, p.z);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  return finish(g, true);
}

/** Solid of revolution around +Z. `profile` is [radius, z] from the back end to the front end. */
export function latheZ(profile: V2[], seg = 12, flat = false): THREE.BufferGeometry {
  const g = new THREE.LatheGeometry(profile.map(([r, z]) => new THREE.Vector2(Math.max(0, r), z)), seg);
  g.rotateX(PI / 2);
  return finish(g, flat);
}

/**
 * Tube swept along a smooth path with a varying, optionally elliptical cross-section.
 * `wide` is the direction the section's first axis prefers (the flat of a bow limb, for example).
 */
export function sweep(points: V3[], radius: (t: number) => number, o: { seg?: number; radial?: number; squash?: number; wide?: V3; closed?: boolean; cap?: boolean } = {}): THREE.BufferGeometry {
  const seg = o.seg ?? 16, rad = o.radial ?? 7, squash = o.squash ?? 1, closed = !!o.closed;
  const curve = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)), closed, "centripetal");
  const wide = o.wide ? new THREE.Vector3(...o.wide).normalize() : null;
  const pos: number[] = [], idx: number[] = [];
  const rings = closed ? seg : seg + 1;
  const T = new THREE.Vector3(), N = new THREE.Vector3(), Bn = new THREE.Vector3(), P = new THREE.Vector3();
  const ref = new THREE.Vector3();
  for (let i = 0; i < rings; i++) {
    const t = i / seg;
    curve.getPointAt(t, P);
    curve.getTangentAt(Math.min(1, t), T);
    if (wide) ref.copy(wide);
    else { const a = Math.abs(T.x), b = Math.abs(T.y), c = Math.abs(T.z); ref.set(a <= b && a <= c ? 1 : 0, b < a && b <= c ? 1 : 0, c < a && c < b ? 1 : 0); }
    N.copy(ref).addScaledVector(T, -ref.dot(T));
    if (N.lengthSq() < 1e-8) N.set(1, 0, 0).addScaledVector(T, -T.x);
    N.normalize();
    Bn.crossVectors(T, N);
    const r = radius(t);
    for (let j = 0; j < rad; j++) {
      const a = (j / rad) * PI * 2;
      pos.push(
        P.x + (N.x * Math.cos(a) + Bn.x * Math.sin(a) * squash) * r,
        P.y + (N.y * Math.cos(a) + Bn.y * Math.sin(a) * squash) * r,
        P.z + (N.z * Math.cos(a) + Bn.z * Math.sin(a) * squash) * r,
      );
    }
  }
  const spans = closed ? seg : seg;
  for (let i = 0; i < spans; i++) for (let j = 0; j < rad; j++) {
    const i1 = (i + 1) % rings;
    const a = i * rad + j, b = i1 * rad + j, c = i1 * rad + ((j + 1) % rad), d = i * rad + ((j + 1) % rad);
    idx.push(a, d, b, d, c, b);
  }
  if (!closed && o.cap !== false) {
    // End caps: a fan around each end's centre.
    for (const end of [0, seg]) {
      const t = end / seg;
      curve.getPointAt(t, P);
      const ci = pos.length / 3;
      pos.push(P.x, P.y, P.z);
      for (let j = 0; j < rad; j++) {
        const a = end * rad + j, d = end * rad + ((j + 1) % rad);
        if (end === 0) idx.push(ci, d, a); else idx.push(ci, a, d);
      }
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return finish(g, false);
}

export type Orient = "side" | "front" | "flat";
/**
 * Extruded silhouette with bevelled edges. `side`: outline in (z, y), thin along X (axe heads, guards).
 * `front`: outline in (x, y), thin along Z (badges, plaques). `flat`: outline in (x, z), thin along Y.
 * `taper(u, v)` scales the thickness at each outline point, which grinds wedges and edges.
 */
export function slab(outline: V2[], depth: number, o: { bevel?: number; orient?: Orient; taper?: (u: number, v: number) => number; holes?: V2[][]; curveSegments?: number } = {}): THREE.BufferGeometry {
  const shape = new THREE.Shape(outline.map(([u, v]) => new THREE.Vector2(u, v)));
  for (const h of o.holes ?? []) shape.holes.push(new THREE.Path(h.map(([u, v]) => new THREE.Vector2(u, v))));
  const bevel = o.bevel ?? Math.min(0.012, depth * 0.3);
  const g = new THREE.ExtrudeGeometry(shape, {
    depth, steps: 1, curveSegments: o.curveSegments ?? 4,
    bevelEnabled: bevel > 0, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 1,
  });
  g.translate(0, 0, -depth / 2);
  if (o.taper) {
    const p = g.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) p.setZ(i, p.getZ(i) * o.taper(p.getX(i), p.getY(i)));
  }
  const orient = o.orient ?? "side";
  if (orient === "side") g.rotateY(-PI / 2);
  else if (orient === "flat") g.rotateX(PI / 2);
  return finish(g, true);
}

export interface BladeOpts {
  len: number;
  /** Half-width across the edges at t ∈ [0, 1); the point is at t = 1. */
  width: (t: number) => number;
  /** Half-thickness. */
  th: number | ((t: number) => number);
  section?: "hex" | "diamond" | "single";
  /** Sweeps the blade toward +Y over its length (a sabre or katana curve). */
  curve?: number;
  /** Moves the point toward the spine (+Y), as a fraction of the last half-width. */
  apex?: number;
  stations?: number;
}

/** Ground blade along +Z from z = 0: bevelled cross-section, distal taper, a true point. Flat-shaded so every grind catches light. */
export function blade(o: BladeOpts): THREE.BufferGeometry {
  const n = o.stations ?? 10;
  const th = typeof o.th === "number" ? (() => o.th as number) : o.th;
  const bow = (t: number) => (o.curve ?? 0) * t * t;
  const section = o.section ?? "hex";
  const ring = (t: number): THREE.Vector3[] => {
    const w = o.width(t), h = th(t), z = o.len * t, y0 = bow(t);
    const pts: V2[] = section === "diamond" ? [[0, w], [h, 0], [0, -w], [-h, 0]]
      : section === "single" ? [[h * 0.75, w], [h, w * 0.15], [0, -w], [-h, w * 0.15], [-h * 0.75, w]]
      : [[0, w], [h, w * 0.4], [h, -w * 0.4], [0, -w], [-h, -w * 0.4], [-h, w * 0.4]];
    return pts.map(([x, y]) => new THREE.Vector3(x, y + y0, z));
  };
  const rings: THREE.Vector3[][] = [];
  for (let i = 0; i < n; i++) rings.push(ring(i / n));
  const last = rings[rings.length - 1];
  const lw = o.width((n - 1) / n);
  const apex = new THREE.Vector3(0, bow(1) + (o.apex ?? 0) * lw, o.len);
  const tris: THREE.Vector3[][] = [];
  for (let i = 0; i < n - 1; i++) {
    const a = rings[i], b = rings[i + 1], k = a.length;
    for (let j = 0; j < k; j++) { const j1 = (j + 1) % k; tris.push([a[j], b[j], b[j1]], [a[j], b[j1], a[j1]]); }
  }
  for (let j = 0; j < last.length; j++) tris.push([last[j], apex, last[(j + 1) % last.length]]);
  const base = rings[0], bc = new THREE.Vector3(0, bow(0), 0);
  for (let j = 0; j < base.length; j++) tris.push([bc, base[j], base[(j + 1) % base.length]]);
  return soup(tris, c => {
    if (c.z < 1e-4) return new THREE.Vector3(0, 0, -1);
    return new THREE.Vector3(c.x, c.y - bow(Math.min(1, c.z / o.len)), 0.0001);
  });
}

/**
 * Curved panel facing +Z (shields): rows from `top` to `bottom`, half-width `hw(y)`, front surface z = `bulge(x, y)`.
 * Front and back are smooth; the edge band is its own crisp strip.
 */
export function panel(top: number, bottom: number, hw: (y: number) => number, bulge: (x: number, y: number) => number, thick: number, rows = 12, cols = 10): THREE.BufferGeometry {
  const pos: number[] = [], idx: number[] = [];
  const grid = (dz: number) => {
    const base = pos.length / 3;
    for (let r = 0; r <= rows; r++) {
      const y = lerp(top, bottom, r / rows), w = hw(y);
      for (let c = 0; c <= cols; c++) { const x = lerp(-w, w, c / cols); pos.push(x, y, bulge(x, y) + dz); }
    }
    return base;
  };
  const f = grid(0), b = grid(-thick);
  const at = (base: number, r: number, c: number) => base + r * (cols + 1) + c;
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    idx.push(at(f, r, c), at(f, r + 1, c), at(f, r, c + 1), at(f, r, c + 1), at(f, r + 1, c), at(f, r + 1, c + 1));
    idx.push(at(b, r, c), at(b, r, c + 1), at(b, r + 1, c), at(b, r, c + 1), at(b, r + 1, c + 1), at(b, r + 1, c));
  }
  // Edge band: walk the outline once and stitch front to back with duplicated vertices.
  const ring: [number, number][] = [];
  for (let c = 0; c <= cols; c++) ring.push([0, c]);
  for (let r = 1; r <= rows; r++) ring.push([r, cols]);
  for (let c = cols - 1; c >= 0; c--) ring.push([rows, c]);
  for (let r = rows - 1; r >= 1; r--) ring.push([r, 0]);
  const e = pos.length / 3;
  for (const [r, c] of ring) {
    const i = at(f, r, c) * 3, j = at(b, r, c) * 3;
    pos.push(pos[i], pos[i + 1], pos[i + 2], pos[j], pos[j + 1], pos[j + 2]);
  }
  for (let k = 0; k < ring.length; k++) {
    const k1 = (k + 1) % ring.length, a = e + k * 2, d = e + k1 * 2;
    idx.push(a, a + 1, d, d, a + 1, d + 1);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  // The edge band is clockwise in screen space for a +Z viewer; flip any triangle facing inward.
  g.computeVertexNormals();
  const p = g.attributes.position as THREE.BufferAttribute, ix = g.index!;
  const A = new THREE.Vector3(), Bv = new THREE.Vector3(), C = new THREE.Vector3(), nrm = new THREE.Vector3();
  for (let t = 0; t < ix.count; t += 3) {
    if (ix.getX(t) < e) continue;
    A.fromBufferAttribute(p, ix.getX(t)); Bv.fromBufferAttribute(p, ix.getX(t + 1)); C.fromBufferAttribute(p, ix.getX(t + 2));
    nrm.subVectors(Bv, A).cross(C.clone().sub(A));
    const mid = A.clone().add(Bv).add(C).multiplyScalar(1 / 3);
    if (nrm.x * mid.x + nrm.y * (mid.y - (top + bottom) / 2) < 0) { const s = ix.getX(t + 1); ix.setX(t + 1, ix.getX(t + 2)); ix.setX(t + 2, s); }
  }
  g.computeVertexNormals();
  return finish(g, false);
}

/** Splits long outline edges so a badge laid onto a curved surface follows it instead of cutting through. */
function densify(pts: V2[], step: number): V2[] {
  const out: V2[] = [];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    const n = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / step));
    for (let k = 0; k < n; k++) out.push([lerp(a[0], b[0], k / n), lerp(a[1], b[1], k / n)]);
  }
  return out;
}

/** Moves every vertex's z onto a surface (for badges laid on a dished or curved shield). */
function conform(g: THREE.BufferGeometry, surface: (x: number, y: number) => number): THREE.BufferGeometry {
  const p = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) p.setZ(i, p.getZ(i) + surface(p.getX(i), p.getY(i)));
  g.computeVertexNormals();
  return g;
}

const STUD = finish(new THREE.SphereGeometry(1, 7, 4), false);
const put = (g: G, geo: THREE.BufferGeometry, mat: Mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, s = 1) =>
  part(g, geo, mat, s, s, s, x, y, z, rx, ry, rz);
const stud = (g: G, mat: Mat, r: number, x: number, y: number, z: number, flat = 0.6, rx = 0, ry = 0) =>
  part(g, STUD, mat, r, r, r * flat, x, y, z, rx, ry, 0);
const torus = (R: number, tube: number, seg = 24, arc = PI * 2) => finish(new THREE.TorusGeometry(R, tube, 5, seg, arc), false);

/**
 * Builds a sub-assembly in a temporary frame and bakes each mesh's full transform into its geometry,
 * so complex pieces can be authored in their own space without adding bones (bake treats every Group as one).
 */
export function frame(bone: G, pos: V3, rot: V3, build: (f: THREE.Group) => void, scale = 1) {
  const f = new THREE.Group();
  f.position.set(...pos); f.rotation.set(...rot); f.scale.setScalar(scale);
  build(f);
  f.updateMatrix();
  const m = new THREE.Matrix4();
  for (const c of [...f.children]) {
    if (!(c instanceof THREE.Mesh)) continue;
    c.updateMatrix();
    m.multiplyMatrices(f.matrix, c.matrix);
    bone.add(new THREE.Mesh((c.geometry as THREE.BufferGeometry).clone().applyMatrix4(m), c.material));
  }
}

/* ---------------- materials ---------------- */

const BLADE = () => plateMat(0xe3e9f1);
const FULLER = () => steel(0x8f99a8);
const WOOD = (c = 0x6b4a2a) => M(c, 0.72, 0.04);
const GRIP = () => waxLeather(LEATHER_DARK);

/* ---------------- hilts and hafts ---------------- */

/** Leather-wrapped grip along Z with raised cord turns. */
export function grip(g: G, z0: number, z1: number, r: number, mat: Mat = GRIP(), turns = 6) {
  const pts: V2[] = [[0, z0], [r * 0.9, z0]];
  const n = turns * 2;
  for (let i = 0; i <= n; i++) {
    const t = i / n, z = lerp(z0 + 0.008, z1 - 0.008, t);
    const swell = 1 + 0.1 * Math.sin(t * PI);
    pts.push([r * swell * (i % 2 ? 1.1 : 0.96), z]);
  }
  pts.push([r * 0.9, z1], [0, z1]);
  put(g, latheZ(pts, 9), mat);
}

type Pommel = "wheel" | "ball" | "pear" | "gem" | "ring" | "none";
function pommel(g: G, z: number, kind: Pommel, mat: Mat, size = 1, gem?: number) {
  const s = size;
  if (kind === "wheel") {
    put(g, latheZ([[0, z - 0.05 * s], [0.035 * s, z - 0.05 * s], [0.062 * s, z - 0.032 * s], [0.066 * s, z], [0.062 * s, z + 0.032 * s], [0.03 * s, z + 0.045 * s], [0.026 * s, z + 0.06 * s], [0, z + 0.06 * s]], 14).rotateZ(0), mat, 0, 0, 0, 0, 0, 0);
    // A wheel pommel is a disc seen face-on from the side: squash it across X.
    const last = g.children[g.children.length - 1] as THREE.Mesh; last.scale.set(0.55, 1, 1);
    stud(g, gem !== undefined ? B(gem) : mat, 0.026 * s, 0.03 * s, 0, z, 0.5, 0, PI / 2);
    stud(g, gem !== undefined ? B(gem) : mat, 0.026 * s, -0.03 * s, 0, z, 0.5, 0, PI / 2);
  } else if (kind === "ball") {
    put(g, latheZ([[0, z - 0.06 * s], [0.04 * s, z - 0.055 * s], [0.058 * s, z - 0.025 * s], [0.055 * s, z + 0.015 * s], [0.03 * s, z + 0.04 * s], [0.024 * s, z + 0.06 * s], [0, z + 0.06 * s]], 12), mat);
  } else if (kind === "pear") {
    put(g, latheZ([[0, z - 0.1 * s], [0.025 * s, z - 0.095 * s], [0.05 * s, z - 0.06 * s], [0.055 * s, z - 0.02 * s], [0.035 * s, z + 0.02 * s], [0.028 * s, z + 0.05 * s], [0.04 * s, z + 0.06 * s], [0, z + 0.065 * s]], 12), mat);
    if (gem !== undefined) stud(g, B(gem), 0.03 * s, 0, 0, z - 0.1 * s, 1);
  } else if (kind === "gem") {
    put(g, latheZ([[0, z - 0.02 * s], [0.05 * s, z - 0.02 * s], [0.06 * s, z + 0.01 * s], [0.03 * s, z + 0.05 * s], [0, z + 0.05 * s]], 12), mat);
    put(g, latheZ([[0, z - 0.11 * s], [0.045 * s, z - 0.06 * s], [0.05 * s, z - 0.03 * s], [0, z - 0.015 * s]], 8, true), B(gem ?? 0xff3a4a));
  } else if (kind === "ring") {
    put(g, torus(0.05 * s, 0.014 * s, 12), mat, 0, 0, z - 0.04 * s, 0, PI / 2, 0);
  }
}

type Guard = "cross" | "curved" | "winged" | "disc" | "bar";
/** Crossguard across Y (the blade's width) just ahead of the fist. */
function guard(g: G, z: number, kind: Guard, mat: Mat, w: number, o: { thick?: number; knob?: Mat; gem?: number } = {}) {
  const th = o.thick ?? 0.05;
  if (kind === "disc") {
    put(g, latheZ([[0, z - 0.014], [w, z - 0.014], [w * 1.04, z], [w, z + 0.014], [0, z + 0.014]], 16), mat);
    put(g, latheZ([[0, z + 0.012], [0.045, z + 0.012], [0.04, z + 0.05], [0, z + 0.05]], 8), mat);
    return;
  }
  const curl = kind === "curved" ? 0.06 : kind === "winged" ? 0.035 : 0;
  const pts: V2[] = [];
  const n = 8;
  // Top edge from -w to w (toward the blade), then bottom edge back: a bar that thickens at the centre.
  for (let i = 0; i <= n; i++) {
    const v = lerp(-w, w, i / n), a = Math.abs(v) / w;
    const lang = kind === "bar" ? 0 : 0.045 * Math.max(0, 1 - a * 3.2);
    pts.push([z + th * 0.5 + curl * a * a + lang + (kind === "winged" ? 0.03 * a * a * a : 0), v]);
  }
  for (let i = n; i >= 0; i--) {
    const v = lerp(-w, w, i / n), a = Math.abs(v) / w;
    const drop = kind === "winged" ? 0.02 * (1 - a) : 0;
    pts.push([z - th * 0.5 + curl * a * a - 0.012 * (1 - a) - drop + (kind === "winged" ? 0.02 * a * a : 0), v]);
  }
  put(g, slab(pts, kind === "winged" ? 0.05 : 0.044, { bevel: 0.01, taper: (u) => 1 - 0.35 * Math.min(1, Math.abs(u) / w) }), mat);
  const knob = o.knob ?? mat;
  for (const s of [-1, 1]) {
    const zk = z + curl + (kind === "winged" ? 0.02 : 0);
    put(g, latheZ([[0, -0.03], [0.026, -0.022], [0.032, 0], [0.026, 0.022], [0, 0.03]], 8), knob, 0, s * (w + 0.012), zk, 0, 0, 0);
  }
  if (o.gem !== undefined) for (const s of [-1, 1]) stud(g, B(o.gem), 0.022, s * 0.026, 0, z, 0.5, 0, PI / 2);
}

/** Straight double-edged blade with a fuller groove on both flats. */
function longBlade(g: G, z0: number, len: number, w0: number, w1: number, o: { th?: number; tip?: number; fuller?: number; mat?: Mat; fullerMat?: Mat } = {}) {
  const th = o.th ?? 0.018, tip = o.tip ?? 0.2;
  const bodyT = 1 - tip;
  const w = (t: number) => t < bodyT ? lerp(w0, w1, t / bodyT) : w1 * Math.pow(Math.max(0, 1 - (t - bodyT) / tip), 0.62);
  put(g, blade({ len, width: w, th: t => th * (1 - 0.35 * t), stations: 12 }), o.mat ?? BLADE(), 0, 0, z0);
  const fl = o.fuller ?? 0.62;
  if (fl > 0) {
    const fg = new THREE.BoxGeometry(0.004, 1, 1);
    for (const s of [-1, 1]) {
      const fz = len * fl;
      part(g, fg, o.fullerMat ?? FULLER(), 1, w0 * 0.42, fz, s * th * 0.99, 0, z0 + 0.03 + fz / 2);
    }
  }
}

/* ---------------- swords ---------------- */

export interface SwordOpts {
  len: number; w0: number; w1: number;
  grip: [number, number]; gripR?: number; gripMat?: Mat;
  guard: Guard; guardW: number; guardMat: Mat; guardZ?: number;
  pommel: Pommel; pommelMat?: Mat; gem?: number;
  bladeMat?: Mat; fuller?: number; th?: number; tip?: number; ricasso?: Mat;
}
export function sword(g: G, o: SwordOpts) {
  const gz = o.guardZ ?? 0.1;
  grip(g, o.grip[0], o.grip[1], o.gripR ?? 0.034, o.gripMat ?? GRIP());
  put(g, latheZ([[0, o.grip[1] - 0.01], [(o.gripR ?? 0.034) * 1.2, o.grip[1] - 0.01], [(o.gripR ?? 0.034) * 1.35, gz - 0.02], [0, gz - 0.02]], 8), o.guardMat);
  guard(g, gz, o.guard, o.guardMat, o.guardW, { gem: o.gem });
  if (o.ricasso) part(g, new THREE.BoxGeometry(1, 1, 1), o.ricasso, 0.05, o.w0 * 2.25, 0.05, 0, 0, gz + 0.045);
  longBlade(g, gz + 0.02, o.len, o.w0, o.w1, { mat: o.bladeMat, fuller: o.fuller, th: o.th, tip: o.tip });
  pommel(g, o.grip[0] - 0.035, o.pommel, o.pommelMat ?? o.guardMat, 1, o.gem);
}

/** Single-edged sabre or katana: curved, point swept toward the spine. */
function curvedBlade(g: G, z0: number, len: number, w: number, curve: number, mat: Mat, o: { taper?: number; th?: number; hamon?: Mat } = {}) {
  const tp = o.taper ?? 0.78;
  put(g, blade({
    len, section: "single", curve, apex: 0.7, stations: 14, th: o.th ?? 0.02,
    width: t => (t < 0.86 ? lerp(w, w * tp, t / 0.86) : w * tp * Math.pow(1 - (t - 0.86) / 0.14, 0.5)),
  }), mat, 0, 0, z0);
  if (o.hamon) {
    // Temper line: a pale band along the edge on both flats.
    const pts: V3[] = [];
    for (let i = 0; i <= 10; i++) { const t = i / 10 * 0.86; pts.push([0, curve * t * t - lerp(w, w * tp, t / 0.86) * 0.35 + Math.sin(i * 1.9) * 0.006, z0 + len * t]); }
    for (const s of [-1, 1]) put(g, sweep(pts.map(([x, y, z]) => [x + s * (o.th ?? 0.02) * 0.62, y, z] as V3), () => 0.006, { seg: 20, radial: 4, squash: 0.25, wide: [0, 1, 0] }), o.hamon);
  }
}

/* ---------------- hafted weapons ---------------- */

/** Wooden haft along Z with an iron butt cap and an optional leather grip band. */
export function haft(g: G, z0: number, z1: number, r: number, wood: Mat = WOOD(), o: { gripAt?: [number, number]; cap?: Mat; taper?: number; bands?: number[]; bandMat?: Mat } = {}) {
  const tp = o.taper ?? 0.85;
  put(g, latheZ([[0, z0], [r * 0.96, z0], [r, z0 + 0.03], [r * lerp(1, tp, 0.5), (z0 + z1) / 2], [r * tp, z1 - 0.01], [0, z1]], 8), wood);
  if (o.gripAt) grip(g, o.gripAt[0], o.gripAt[1], r * 1.08, GRIP(), Math.max(3, Math.round((o.gripAt[1] - o.gripAt[0]) / 0.05)));
  if (o.cap) put(g, latheZ([[0, z0 - 0.06], [r * 0.7, z0 - 0.055], [r * 1.18, z0 + 0.02], [r * 1.2, z0 + 0.06], [r * 1.05, z0 + 0.07], [0, z0 + 0.07]], 8), o.cap);
  for (const bz of o.bands ?? []) put(g, latheZ([[0, bz - 0.02], [r * 1.22, bz - 0.02], [r * 1.28, bz], [r * 1.22, bz + 0.02], [0, bz + 0.02]], 8), o.bandMat ?? ironMat());
}

/** Leaf or lozenge spearhead on a socket, with langets nailed down the shaft. */
export function spearhead(g: G, z: number, len: number, w: number, mat: Mat = BLADE(), o: { r?: number; socketMat?: Mat; langets?: boolean; shape?: "leaf" | "lozenge" | "spike" } = {}) {
  const r = o.r ?? 0.04, sm = o.socketMat ?? steel(STEEL_DARK);
  const sock = len * 0.32;
  put(g, latheZ([[0, z - 0.02], [r * 1.25, z - 0.02], [r * 1.35, z + 0.01], [r * 1.12, z + 0.04], [r * 1.18, z + 0.06], [r * 1.05, z + sock * 0.7], [r * 0.7, z + sock], [0, z + sock]], 9), sm);
  const shape = o.shape ?? "leaf";
  const width = shape === "spike" ? (t: number) => w * (1 - t) * 0.6 + 0.004
    : shape === "lozenge" ? (t: number) => w * (t < 0.3 ? 0.35 + 0.65 * t / 0.3 : Math.pow((1 - t) / 0.7, 0.9))
    : (t: number) => w * Math.pow(Math.sin(Math.min(1, t * 1.25 + 0.12) * PI * 0.5 + (t > 0.45 ? (t - 0.45) * 2.2 : 0)), 1) * (t < 0.45 ? 0.45 + t * 1.22 : Math.max(0, (1 - t) / 0.55));
  put(g, blade({ len: len - sock * 0.6, width, th: t => r * 0.55 * (1 - t * 0.6), section: "diamond", stations: 9 }), mat, 0, 0, z + sock * 0.6);
  if (o.langets !== false) for (const s of [-1, 1]) {
    part(g, new THREE.BoxGeometry(1, 1, 1), sm, 0.012, r * 0.8, 0.2, s * r * 0.98, 0, z - 0.1);
    stud(g, gold(BRASS), 0.012, s * r * 1.06, 0, z - 0.05, 0.6, 0, PI / 2 * s);
    stud(g, gold(BRASS), 0.012, s * r * 1.06, 0, z - 0.15, 0.6, 0, PI / 2 * s);
  }
}

/** Bearded axe head mounted at z on a haft of radius r; the edge faces -Y. `scale` grows the whole head. */
export function axeHead(g: G, z: number, r: number, s: number, mat: Mat, o: { edge?: Mat; double?: boolean; crude?: boolean; spike?: Mat } = {}) {
  const P = (u: number, v: number): V2 => [z + u * s, v * s];
  const out: V2[] = [
    P(0.075, r / s + 0.03), P(0.075, -0.05), P(0.1, -0.1), P(0.2, -0.2), P(0.27, -0.33),
    P(0.21, -0.36), P(0.12, -0.385), P(0.02, -0.39), P(-0.08, -0.375), P(-0.17, -0.34),
    P(-0.23, -0.3), P(-0.17, -0.24), P(-0.11, -0.16), P(-0.07, -0.1), P(-0.07, -0.05), P(-0.075, r / s + 0.03),
  ];
  if (o.crude) { out[6] = P(0.12, -0.36); out[8] = P(-0.08, -0.35); }
  const back: V2[] = o.double
    ? [P(-0.075, r / s + 0.03), P(-0.07, 0.05), P(-0.11, 0.12), P(-0.2, 0.22), P(-0.14, 0.27), P(0.0, 0.29), P(0.14, 0.27), P(0.2, 0.22), P(0.11, 0.12), P(0.07, 0.05), P(0.075, r / s + 0.03)]
    : [P(-0.075, r / s + 0.03), P(-0.06, r / s + 0.09), P(0.06, r / s + 0.09), P(0.075, r / s + 0.03)];
  const outline = [...out, ...back.slice(1, -1)];
  put(g, slab(outline, 0.07 * s, {
    bevel: 0.008 * s,
    taper: (_u, v) => { const d = Math.abs(v) / s; return 1 - 0.82 * smoothstep(0.1, 0.37, o.double ? d : -v / s); },
  }), mat);
  // Bright honed edge along the bit.
  const edge = (pts: V2[]) => put(g, sweep(pts.map(([u, v]) => [0, v, u] as V3), t => 0.012 * s * (0.5 + Math.sin(t * PI) * 0.6), { seg: 14, radial: 4, squash: 0.35, wide: [0, 1, 0] }), o.edge ?? plateMat(0xf2f5fa));
  edge([P(0.265, -0.325), P(0.18, -0.37), P(0.05, -0.385), P(-0.08, -0.37), P(-0.21, -0.305)].map(([u, v]) => [u, v + 0.012 * s] as V2));
  if (o.double) edge([P(-0.2, 0.215), P(-0.1, 0.27), P(0.05, 0.28), P(0.19, 0.215)].map(([u, v]) => [u, v - 0.012 * s] as V2));
  // Eye collar and wedge rivets.
  put(g, latheZ([[0, z - 0.085 * s], [r * 1.35, z - 0.085 * s], [r * 1.4, z + 0.085 * s], [0, z + 0.085 * s]], 8), mat);
  for (const k of [-1, 1]) stud(g, gold(BRASS), 0.016 * s, k * 0.04 * s, -0.09 * s, z, 0.5, 0, k * PI / 2);
  if (o.spike) put(g, latheZ([[0, 0], [0.03 * s, 0], [0.022 * s, 0.06 * s], [0, 0.16 * s]], 6, true), o.spike, 0, r + 0.04 * s, z, -PI / 2, 0, 0);
}

/* ---------------- shields ---------------- */

export interface Heraldry { field?: Mat; second?: Mat; charge?: "cross" | "star" | "chevron" | "rays" | "fleur" | "sun" | "skull" | "bands" | "none"; chargeMat?: Mat }

/** Badge silhouettes in the unit square (x, y ∈ [-1, 1]). */
function chargeOutline(kind: NonNullable<Heraldry["charge"]>): V2[][] {
  if (kind === "cross") return [[[-0.2, 1], [0.2, 1], [0.2, 0.32], [0.72, 0.32], [0.72, -0.08], [0.2, -0.08], [0.2, -1], [-0.2, -1], [-0.2, -0.08], [-0.72, -0.08], [-0.72, 0.32], [-0.2, 0.32]]];
  if (kind === "star") {
    const p: V2[] = [];
    for (let i = 0; i < 16; i++) { const a = PI / 2 + i * PI / 8, r = i % 2 ? 0.36 : (i % 4 === 0 ? 1 : 0.7); p.push([Math.cos(a) * r, Math.sin(a) * r]); }
    return [p];
  }
  if (kind === "chevron") return [[[-1, -0.55], [0, 0.45], [1, -0.55], [1, -0.05], [0, 0.95], [-1, -0.05]]];
  if (kind === "sun") {
    const p: V2[] = [];
    for (let i = 0; i < 24; i++) { const a = i * PI / 12, r = i % 2 ? 0.62 : 1; p.push([Math.cos(a) * r, Math.sin(a) * r]); }
    return [p];
  }
  if (kind === "fleur") return [
    [[0, 1], [0.22, 0.62], [0.2, 0.2], [0.1, -0.05], [-0.1, -0.05], [-0.2, 0.2], [-0.22, 0.62]],
    [[0.12, 0.05], [0.42, 0.42], [0.78, 0.4], [0.8, 0.1], [0.55, -0.12], [0.3, -0.2], [0.14, -0.12]],
    [[-0.12, 0.05], [-0.14, -0.12], [-0.3, -0.2], [-0.55, -0.12], [-0.8, 0.1], [-0.78, 0.4], [-0.42, 0.42]],
    [[-0.5, -0.1], [0.5, -0.1], [0.5, -0.28], [-0.5, -0.28]],
    [[0, -0.28], [0.2, -0.6], [0.1, -0.85], [-0.1, -0.85], [-0.2, -0.6]],
  ];
  if (kind === "skull") return [[[-0.6, 0.2], [-0.5, 0.7], [0, 0.95], [0.5, 0.7], [0.6, 0.2], [0.35, -0.2], [0.3, -0.6], [-0.3, -0.6], [-0.35, -0.2]]];
  return [];
}
function charge(g: G, h: Heraldry, size: number, x: number, y: number, surface: (x: number, y: number) => number) {
  if (!h.charge || h.charge === "none" || h.charge === "rays" || h.charge === "bands") return;
  for (const o of chargeOutline(h.charge)) {
    const geo = slab(densify(o.map(([u, v]) => [u * size + x, v * size + y] as V2), size * 0.25), 0.014, { orient: "front", bevel: 0.004 });
    put(g, conform(geo, surface), h.chargeMat ?? gildMat());
  }
  if (h.charge === "skull") for (const s of [-1, 1]) {
    const geo = slab([[-0.14, -0.1], [0.14, -0.1], [0.16, 0.12], [-0.12, 0.14]].map(([u, v]) => [(u + s * 0.25) * size + x, v * size + y + 0.12 * size] as V2), 0.02, { orient: "front", bevel: 0.003 });
    put(g, conform(geo, (a, b) => surface(a, b) + 0.004), B(0x14100c));
  }
}

export interface RoundShieldOpts {
  r: number; dome?: number; thick?: number;
  face: Mat; rim: Mat; boss: Mat; rivet?: Mat; rivets?: number;
  heraldry?: Heraldry; planks?: Mat; bossSpike?: Mat; spikes?: Mat; flatRim?: number; cracked?: boolean;
}
/** Dished round shield facing +Z, built around (0,0,0) at its back face. */
export function roundShield(g: G, o: RoundShieldOpts) {
  const R = o.r, d = o.dome ?? R * 0.16, th = o.thick ?? 0.045;
  const flat = o.flatRim ?? 0;
  const front = (r: number) => r > R - flat ? 0.0 : d * (1 - Math.pow(r / (R - flat), 2)) + (flat ? 0.0 : 0);
  const prof: V2[] = [];
  const N = 8;
  for (let i = 0; i <= N; i++) { const r = R * i / N; prof.push([r, front(r) - th]); }
  prof.push([R * 1.0, -th * 0.4]);
  for (let i = N; i >= 0; i--) { const r = R * i / N; prof.push([r, front(r)]); }
  // Lathe expects back→front ordering by surface walk: back centre, out to the rim, then in across the face.
  put(g, latheZ(prof, 28), o.face);
  const surf = (x: number, y: number) => front(Math.hypot(x, y)) + 0.003;
  const h = o.heraldry;
  if (h) {
    if (h.charge === "rays" || h.charge === "bands") {
      // Alternating painted wedges or bands over the whole field.
      const n = h.charge === "rays" ? 8 : 4;
      for (let i = 0; i < n; i++) {
        const pts: V2[] = [];
        if (h.charge === "rays") {
          const a0 = (i / n) * PI * 2 + PI / 8, a1 = a0 + PI / n;
          pts.push([0, 0]);
          for (let k = 0; k <= 4; k++) { const a = lerp(a0, a1, k / 4); pts.push([Math.cos(a) * R * 0.86, Math.sin(a) * R * 0.86]); }
        } else {
          const y0 = -R * 0.86 + (i * 2 + 0.5) * R * 0.86 / n, y1 = y0 + R * 0.86 / n;
          const xr = (y: number) => Math.sqrt(Math.max(0, (R * 0.86) ** 2 - y * y));
          pts.push([-xr(y0), y0], [xr(y0), y0], [xr(y1), y1], [-xr(y1), y1]);
        }
        put(g, conform(slab(pts, 0.008, { orient: "front", bevel: 0 }), surf), h.second ?? h.field ?? o.face);
      }
    } else {
      const field: V2[] = [];
      for (let i = 0; i < 28; i++) { const a = i / 28 * PI * 2; field.push([Math.cos(a) * R * 0.86, Math.sin(a) * R * 0.86]); }
      if (h.field) put(g, conform(slab(field, 0.008, { orient: "front", bevel: 0 }), surf), h.field);
      charge(g, h, R * 0.5, 0, 0, (x, y) => surf(x, y) + 0.006);
    }
  }
  if (o.planks) for (let i = -2; i <= 2; i++) {
    const x = i * R * 0.34, yr = Math.sqrt(Math.max(0, R * R * 0.86 - x * x));
    if (yr < 0.05) continue;
    put(g, conform(slab([[x - 0.006, -yr], [x + 0.006, -yr], [x + 0.006, yr], [x - 0.006, yr]], 0.006, { orient: "front", bevel: 0 }), (a, b) => surf(a, b) + 0.004), o.planks);
  }
  if (o.cracked) put(g, conform(slab([[R * 0.2, R * 0.75], [R * 0.32, R * 0.4], [R * 0.18, R * 0.12], [R * 0.25, -R * 0.1], [R * 0.21, -R * 0.1], [R * 0.13, R * 0.12], [R * 0.27, R * 0.4], [R * 0.16, R * 0.75]], 0.006, { orient: "front", bevel: 0 }), (a, b) => surf(a, b) + 0.008), B(0x1a140e));
  // Rolled metal rim.
  put(g, torus(R, th * 0.62, 32), o.rim, 0, 0, -th * 0.45);
  // Boss.
  const rb = R * 0.24, bz = front(0) - 0.004;
  put(g, latheZ([[0, bz], [rb * 1.38, bz], [rb * 1.38, bz + 0.012], [rb * 1.05, bz + 0.016], [rb * 0.98, bz + rb * 0.3], [rb * 0.7, bz + rb * 0.72], [rb * 0.3, bz + rb * 0.88], [0, bz + rb * 0.9]], 16), o.boss);
  if (o.bossSpike) put(g, latheZ([[0, bz + rb * 0.82], [rb * 0.4, bz + rb * 0.82], [0, bz + rb * 2]], 8, true), o.bossSpike);
  const nr = o.rivets ?? 10;
  for (let i = 0; i < nr; i++) {
    const a = (i / nr) * PI * 2 + PI / nr, rr = R * 0.92;
    stud(g, o.rivet ?? o.rim, 0.018, Math.cos(a) * rr, Math.sin(a) * rr, front(rr) + 0.006, 0.6);
    if (i % 2 === 0) stud(g, o.rivet ?? o.rim, 0.014, Math.cos(a) * rb * 1.2, Math.sin(a) * rb * 1.2, bz + 0.016, 0.6);
  }
  if (o.spikes) for (let i = 0; i < 6; i++) {
    const a = (i / 6) * PI * 2, rr = R * 0.66;
    put(g, latheZ([[0, 0], [0.026, 0], [0, 0.12]], 6, true), o.spikes, Math.cos(a) * rr, Math.sin(a) * rr, front(rr));
  }
  // Grip bar and arm strap on the back.
  put(g, latheZ([[0, -0.1], [0.022, -0.1], [0.022, 0.1], [0, 0.1]], 6), WOOD(0x4a3220), 0, 0, -th - 0.02, PI / 2, 0, 0);
}

export interface PanelShieldOpts {
  w: number; h: number; style: "heater" | "tower" | "kite";
  curve?: number; thick?: number;
  face: Mat; rim: Mat; heraldry?: Heraldry; boss?: Mat; studs?: Mat; band?: Mat;
}
/** Heater, kite or tower shield facing +Z, centred on (0,0); curved around the bearer. */
export function panelShield(g: G, o: PanelShieldOpts) {
  const W = o.w / 2, H = o.h / 2, th = o.thick ?? 0.045, k = o.curve ?? 0.7;
  let hw: (y: number) => number;
  if (o.style === "tower") {
    const rc = W * 0.35;
    hw = y => {
      const yy = Math.abs(y);
      return yy > H - rc ? W - rc + Math.sqrt(Math.max(0, rc * rc - (yy - (H - rc)) ** 2)) : W;
    };
  } else {
    const y0 = o.style === "kite" ? H * 0.45 : H * 0.42;
    const topR = o.style === "kite" ? W * 0.9 : 0;
    hw = y => {
      if (y > y0) return o.style === "kite" ? Math.sqrt(Math.max(0.0004, 1 - ((y - y0) / (H - y0)) ** 2)) * W * 0.98 + 0.01 : W;
      const s = (y0 - y) / (y0 + H);
      return Math.max(0.006, W * Math.pow(Math.max(0, 1 - Math.pow(s, o.style === "kite" ? 1.4 : 2.1)), o.style === "kite" ? 0.9 : 0.62));
    };
    void topR;
  }
  const bulge = (x: number, y: number) => -k * x * x - k * 0.18 * y * y + 0.02;
  put(g, panel(H, -H, hw, bulge, th, 14, 10), o.face);
  const surf = (x: number, y: number) => bulge(x, y) + 0.003;
  // Painted field inset from the rim.
  if (o.heraldry) {
    const hh = o.heraldry;
    const inset = 0.86;
    if (hh.field) put(g, panel(H - 0.03, -H + 0.05, y => Math.max(0.004, hw(y) * inset - 0.012), (x, y) => surf(x, y) + 0.002, 0.004, 12, 8), hh.field);
    charge(g, hh, Math.min(W, H) * 0.5, 0, H * 0.08, (x, y) => surf(x, y) + 0.01);
  }
  // Rim: a rolled edge following the outline.
  const outline: V3[] = [];
  const n = 18;
  for (let i = 0; i <= n; i++) { const y = lerp(H, -H, i / n); outline.push([hw(y), y, bulge(hw(y), y) - th * 0.45]); }
  for (let i = n - 1; i >= 1; i--) { const y = lerp(H, -H, i / n); outline.push([-hw(y), y, bulge(-hw(y), y) - th * 0.45]); }
  const dedup = outline.filter((p, i) => i === 0 || Math.hypot(p[0] - outline[i - 1][0], p[1] - outline[i - 1][1]) > 0.012);
  put(g, sweep(dedup, () => th * 0.65, { closed: true, seg: 64, radial: 6 }), o.rim);
  if (o.band) {
    put(g, panel(H * 0.06, -H * 0.06, y => hw(y) * 0.97, (x, y) => surf(x, y) + 0.008, 0.006, 2, 10), o.band);
    put(g, panel(H * 0.97, -H * 0.94, y => Math.min(hw(y) * 0.97, W * 0.08), (x, y) => surf(x, y) + 0.008, 0.006, 12, 2), o.band);
  }
  if (o.boss) {
    const rb = Math.min(W, H) * 0.3, bz = surf(0, 0);
    put(g, latheZ([[0, bz - 0.01], [rb * 1.3, bz - 0.01], [rb * 1.3, bz + 0.01], [rb, bz + 0.016], [rb * 0.92, bz + rb * 0.35], [rb * 0.55, bz + rb * 0.7], [0, bz + rb * 0.78]], 16), o.boss);
  }
  if (o.studs) {
    for (let i = 1; i < n; i += 2) {
      const y = lerp(H, -H, i / n);
      for (const s of [-1, 1]) { const x = s * (hw(y) - 0.045); if (hw(y) > 0.06) stud(g, o.studs, 0.016, x, y, surf(x, y) + 0.006, 0.6); }
    }
  }
}

/* ---------------- bows ---------------- */

export interface BowOpts { span: number; draw: number; belly: number; wood: Mat; grip?: Mat; nock?: Mat; string?: number; recurve?: number; bone?: boolean; leaf?: Mat }
/** Drawn recurve bow in the Y-Z plane; the grip is at the origin and the nocked string is pulled back to z = -draw. */
export function bow(g: G, o: BowOpts) {
  const s = o.span, rc = o.recurve ?? 0.08;
  const tipZ = -o.draw * 0.62;
  for (const sd of [-1, 1]) {
    const pts: V3[] = [
      [0, 0, 0], [0, sd * s * 0.14, -o.belly * 0.15], [0, sd * s * 0.4, -o.belly * 0.55],
      [0, sd * s * 0.72, tipZ * 0.82], [0, sd * s * 0.92, tipZ + rc * 0.2], [0, sd * (s + rc * 0.25), tipZ + rc],
    ];
    put(g, sweep(pts, t => (0.036 - 0.024 * t) * (o.bone ? 1.15 : 1), { seg: 18, radial: 6, squash: 0.62, wide: [1, 0, 0] }), o.wood);
    if (o.bone) for (let k = 1; k <= 3; k++) {
      const t = k / 4, p = pts[Math.min(pts.length - 1, Math.round(t * (pts.length - 1)))];
      put(g, latheZ([[0, -0.025], [0.038, -0.02], [0.045, 0], [0.038, 0.02], [0, 0.025]], 8), boneMat(BONE_DARK), 0, p[1], p[2], PI / 2, 0, 0);
    }
    if (o.nock) put(g, latheZ([[0, -0.03], [0.02, -0.03], [0.024, 0.02], [0, 0.04]], 6), o.nock, 0, sd * (s + rc * 0.25), tipZ + rc, sd > 0 ? -PI / 2 : PI / 2, 0, 0);
    if (o.leaf) put(g, slab([[0, 0], [0.06, 0.05], [0.14, 0.02], [0.2, -0.04], [0.1, -0.03]], 0.012, { orient: "side", bevel: 0.002 }), o.leaf, 0, sd * s * 0.86, tipZ * 0.92, sd > 0 ? 0.9 : -0.9, 0, 0);
    // String: from the tip to the drawn nock point.
    const tip = new THREE.Vector3(0, sd * (s + rc * 0.15), tipZ + rc * 0.8), nk = new THREE.Vector3(0, 0, -o.draw);
    const mid = tip.clone().add(nk).multiplyScalar(0.5), len = tip.distanceTo(nk);
    const str = latheZ([[0.006, -len / 2], [0.006, len / 2]], 4);
    const m = new THREE.Mesh(str, B(o.string ?? 0xe8dfc0));
    m.position.copy(mid);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), nk.clone().sub(tip).normalize());
    g.add(m);
  }
  grip(g, -0.075, 0.075, 0.042, o.grip ?? GRIP(), 4);
  put(g, latheZ([[0, -0.012], [0.012, -0.01], [0.012, 0.01], [0, 0.012]], 5), gold(BRASS), 0.04, 0.03, 0.02);
}

/** Nocked arrow with a bodkin or broadhead and three fletchings, nock at z0. */
export function arrow(g: G, z0: number, len: number, o: { shaft?: number; fletch?: Mat; head?: Mat; broad?: boolean; r?: number } = {}) {
  const r = o.r ?? 0.014;
  put(g, latheZ([[0, z0], [r * 1.1, z0], [r, z0 + 0.04], [r, z0 + len], [0, z0 + len]], 6), M(o.shaft ?? 0xb69250, 0.7));
  put(g, latheZ([[0, z0 - 0.025], [r * 1.3, z0 - 0.02], [r * 1.3, z0 + 0.02], [0, z0 + 0.02]], 6), M(0x2a2016));
  const hz = z0 + len;
  if (o.broad) put(g, blade({ len: 0.16, width: t => 0.05 * (1 - t) + (t < 0.12 ? -0.03 * (1 - t / 0.12) : 0), th: 0.008, section: "diamond", stations: 4 }), o.head ?? steel(), 0, 0, hz - 0.01);
  else put(g, latheZ([[0, hz - 0.03], [r * 1.5, hz - 0.03], [r * 2.6, hz + 0.04], [0, hz + 0.14]], 6, true), o.head ?? steel());
  const fl = o.fletch ?? cloth(0xf2ecdc);
  for (let i = 0; i < 3; i++) {
    const a = i * PI * 2 / 3;
    const geo = slab([[z0 + 0.04, 0], [z0 + 0.22, 0], [z0 + 0.18, 0.045], [z0 + 0.06, 0.05]], 0.006, { bevel: 0 });
    const m = new THREE.Mesh(geo, fl);
    m.rotation.z = a;
    m.position.set(0, 0, 0);
    // Rotate about the shaft: position each vane off the axis.
    geo.translate(0, r * 0.6, 0);
    g.add(m);
  }
}

/* ---------------- staves ---------------- */

/** Wizard staff: shaped shaft with ferrules and a claw head cradling a glowing orb. */
export function orbStaff(g: G, o: { len: number; wood: Mat; metal: Mat; glow: number; core?: number; crystals?: number; prongs?: number }) {
  const L = o.len, top = L * 0.62, bot = -L * 0.38;
  put(g, latheZ([[0, bot], [0.03, bot], [0.04, bot + 0.1], [0.036, 0], [0.042, top - 0.2], [0.05, top - 0.06], [0, top - 0.06]], 9), o.wood);
  put(g, latheZ([[0, bot - 0.08], [0.02, bot - 0.06], [0.045, bot + 0.02], [0.047, bot + 0.06], [0, bot + 0.06]], 8), o.metal);
  for (const z of [-0.1, 0.12]) put(g, latheZ([[0, z - 0.02], [0.048, z - 0.02], [0.052, z], [0.048, z + 0.02], [0, z + 0.02]], 9), o.metal);
  // Collar that flares into the head.
  put(g, latheZ([[0, top - 0.12], [0.05, top - 0.12], [0.06, top - 0.06], [0.08, top], [0.07, top + 0.04], [0, top + 0.04]], 10), o.metal);
  const oz = top + 0.2;
  put(g, GEO.sph, B(o.glow), 0, 0, oz, 0, 0, 0, 0.13);
  put(g, GEO.sph, B(o.core ?? 0xffffff), 0, 0, oz, 0, 0, 0, 0.07);
  const np = o.prongs ?? 4;
  for (let i = 0; i < np; i++) {
    const a = (i / np) * PI * 2 + PI / 4, c = Math.cos(a), s = Math.sin(a);
    put(g, sweep([[c * 0.05, s * 0.05, top + 0.02], [c * 0.15, s * 0.15, top + 0.12], [c * 0.16, s * 0.16, oz + 0.04], [c * 0.07, s * 0.07, oz + 0.16]], t => 0.022 * (1 - t * 0.7), { seg: 10, radial: 5 }), o.metal);
  }
  if (o.crystals) for (let i = 0; i < o.crystals; i++) {
    const a = (i / o.crystals) * PI * 2, c = Math.cos(a), s = Math.sin(a);
    put(g, latheZ([[0, 0], [0.035, 0.06], [0.03, 0.18], [0, 0.26]], 4, true), B(0xd8f4ff), c * 0.13, s * 0.13, oz - 0.02, -s * 0.6, c * 0.6, 0);
  }
}

/** A gnarled wooden staff (necromancer, shaman): a wandering path that thickens toward a knotted head. */
export function gnarledStaff(g: G, len: number, wood: Mat, seed = 1) {
  const pts: V3[] = [];
  for (let i = 0; i <= 8; i++) {
    const t = i / 8, z = -len * 0.38 + len * t;
    pts.push([Math.sin(i * 1.7 + seed) * 0.025, Math.cos(i * 2.3 + seed) * 0.02, z]);
  }
  put(g, sweep(pts, t => 0.034 + 0.012 * t + 0.008 * Math.sin(t * 40 + seed), { seg: 24, radial: 7 }), wood);
  const top = pts[pts.length - 1];
  // Knots and a forked crown.
  for (let i = 0; i < 3; i++) put(g, GEO.sph, wood, Math.sin(i * 2 + seed) * 0.04, Math.cos(i * 2 + seed) * 0.04, -len * 0.1 + i * len * 0.2, 0, 0, 0, 0.05);
  for (let i = 0; i < 3; i++) {
    const a = i * PI * 2 / 3 + seed;
    put(g, sweep([[top[0], top[1], top[2] - 0.05], [top[0] + Math.cos(a) * 0.1, top[1] + Math.sin(a) * 0.1, top[2] + 0.08], [top[0] + Math.cos(a) * 0.12, top[1] + Math.sin(a) * 0.12, top[2] + 0.22]], t => 0.03 * (1 - t * 0.8), { seg: 8, radial: 5 }), wood);
  }
  return new THREE.Vector3(top[0], top[1], top[2]);
}

/* ---------------- misc ---------------- */

/** Rows of studs spiralling round a haft (used on clubs). */
export function club(g: G, len: number, r0: number, r1: number, wood: Mat, iron: Mat, spikes: number, seed = 0) {
  const prof: V2[] = [[0, -0.3], [r0 * 0.9, -0.3], [r0, -0.22]];
  for (let i = 0; i <= 10; i++) {
    const t = i / 10, z = lerp(-0.2, len, t);
    const bump = 1 + 0.12 * Math.sin(t * 19 + seed) * smoothstep(0.3, 0.6, t);
    prof.push([lerp(r0, r1, Math.pow(t, 1.6)) * bump, z]);
  }
  prof.push([r1 * 0.75, len + r1 * 0.35], [0, len + r1 * 0.45]);
  put(g, latheZ(prof, 11), wood);
  for (const t of [0.0, 0.62, 0.9]) {
    const z = lerp(-0.2, len, t), r = lerp(r0, r1, Math.pow(t, 1.6)) * 1.06;
    put(g, torus(r, 0.022 + r * 0.06, 14), iron, 0, 0, z);
    for (let k = 0; k < 6; k++) { const a = k / 6 * PI * 2 + t * 3; stud(g, gold(BRASS), 0.014 + r * 0.03, Math.cos(a) * r * 1.02, Math.sin(a) * r * 1.02, z, 0.6, 0, 0); }
  }
  for (let i = 0; i < spikes; i++) {
    const t = 0.55 + 0.42 * ((i * 0.618 + seed) % 1), a = i * 2.4 + seed;
    const z = lerp(-0.2, len, t), r = lerp(r0, r1, Math.pow(t, 1.6));
    const c = Math.cos(a), s = Math.sin(a);
    const m = put(g, latheZ([[0, 0], [0.045, 0], [0.035, 0.05], [0, 0.2]], 6, true), iron, c * r * 0.9, s * r * 0.9, z);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(c, s, 0.25).normalize());
  }
}

export { B, BONE, BRASS, GOLD, GOLD_LIGHT, IRON, LEATHER, STEEL_DARK, STEEL_LIGHT, cloth, dark, gildMat, gold, horn, ironMat, lacquer, leather, light, plateMat, silk, steel, waxLeather, WOOD, GRIP, BLADE, curvedBlade, longBlade, put, stud, torus, pommel, guard };

/* ---------------- royal mantle ---------------- */

export interface MantleOpts {
  len: number; top: number; hem: number;
  velvet: Mat; lining: Mat; fur: Mat; spot: Mat; braid: Mat; crest?: Mat; motif?: Mat;
}
/**
 * Floor-length mantle hung from a cloak bone at the shoulders: it wraps forward over the shoulders,
 * falls in deepening folds, flares back over the legs and trails slightly at the centre.
 * Velvet outside, a contrasting lining inside, an ermine border with spots, a gold braid and an embroidered crest.
 */
export function mantle(g: G, o: MantleOpts) {
  const L = o.len;
  const halfW = (t: number) => lerp(o.top, o.hem, Math.pow(t, 0.85));
  const S = (u: number, t: number): THREE.Vector3 => {
    const x = u * halfW(t);
    const y = -L * t * (1 + 0.07 * (1 - u * u) * t);
    let z = 0.3 * u * u * Math.pow(1 - t, 2.4);
    z -= 0.2 * Math.pow(t, 1.5) + 0.09 * smoothstep(0.05, 0.35, t);
    z -= (0.012 + 0.055 * Math.pow(t, 0.9)) * Math.cos(u * PI * 3.5) * (1 - 0.6 * Math.pow(Math.abs(u), 4));
    z += 0.05 * Math.pow(Math.abs(u), 5) * t;
    return new THREE.Vector3(x, y, z);
  };
  const NX = 24, NY = 12;
  const sheet = (dz: number, outward: boolean) => {
    const pos: number[] = [], idx: number[] = [];
    for (let j = 0; j <= NY; j++) for (let i = 0; i <= NX; i++) { const p = S(i / NX * 2 - 1, j / NY); pos.push(p.x, p.y, p.z + dz); }
    const row = NX + 1;
    for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) {
      const a = j * row + i, b = a + 1, c = a + row, d = c + 1;
      // Rows run downward and columns run to +X, so (a, c, b) faces +Z.
      if (outward) idx.push(a, b, c, b, d, c); else idx.push(a, c, b, b, c, d);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    return finish(geo, false);
  };
  put(g, sheet(0, true), o.velvet);
  put(g, sheet(0.02, false), o.lining);
  // Ermine border: down one edge, along the hem, up the other.
  const edge = (u: number): V3[] => Array.from({ length: 9 }, (_, k) => { const p = S(u, k / 8); return [p.x, p.y, p.z + 0.01]; });
  const hem: V3[] = Array.from({ length: 13 }, (_, k) => { const p = S(-1 + (k / 12) * 2, 1); return [p.x, p.y, p.z + 0.01]; });
  const furR = 0.055;
  for (const path of [edge(-1), edge(1)]) put(g, sweep(path, t => furR * (0.75 + 0.25 * t), { seg: 16, radial: 7, squash: 0.55, wide: [1, 0, 0] }), o.fur);
  put(g, sweep(hem, () => furR * 1.1, { seg: 26, radial: 7, squash: 0.6, wide: [0, 1, 0] }), o.fur);
  // Ermine tails: little black flecks on the outside of the border.
  const fleck = (p: THREE.Vector3) => { stud(g, o.spot, 0.016, p.x, p.y, p.z - 0.035, 0.6); };
  for (let k = 1; k < 8; k++) for (const u of [-1, 1]) { const p = S(u, k / 8 + 0.05); fleck(new THREE.Vector3(p.x - u * 0.01, p.y, p.z)); }
  for (let k = 1; k < 12; k++) { const p = S(-1 + (k / 12) * 2, 1); fleck(new THREE.Vector3(p.x, p.y + 0.01, p.z - 0.02)); }
  // Gold braid inside the fur.
  const braid = (pts: V3[]) => put(g, sweep(pts, () => 0.013, { seg: 24, radial: 4, squash: 0.5 }), o.braid);
  braid(Array.from({ length: 9 }, (_, k) => { const p = S(-0.88, 0.04 + k / 8 * 0.9); return [p.x, p.y, p.z - 0.012] as V3; }));
  braid(Array.from({ length: 9 }, (_, k) => { const p = S(0.88, 0.04 + k / 8 * 0.9); return [p.x, p.y, p.z - 0.012] as V3; }));
  braid(Array.from({ length: 13 }, (_, k) => { const p = S(-0.88 + (k / 12) * 1.76, 0.93); return [p.x, p.y, p.z - 0.012] as V3; }));
  // Embroidery on the back: a crest at the shoulders and a scatter of small gold stars.
  const surfZ = (x: number, y: number) => { const t = Math.min(1, Math.max(0, -y / L)); return S(x / halfW(t), t).z - 0.006; };
  const badge = (outline: V2[], cx: number, cy: number, size: number, mat: Mat) => {
    const geo = slab(densify(outline.map(([u, v]) => [u * size, v * size] as V2), size * 0.2), 0.01, { orient: "front", bevel: 0.002 });
    geo.rotateY(PI);
    geo.translate(cx, cy, 0);
    put(g, conform(geo, surfZ), mat);
  };
  if (o.crest) for (const outline of chargeOutline("fleur")) badge(outline, 0, -L * 0.24, 0.22, o.crest);
  if (o.motif) {
    const star: V2[] = [];
    for (let i = 0; i < 8; i++) { const a = i * PI / 4, r = i % 2 ? 0.38 : 1; star.push([Math.cos(a) * r, Math.sin(a) * r]); }
    for (let j = 0; j < 4; j++) for (let i = -2; i <= 2; i++) {
      const t = 0.52 + j * 0.13, u = (i + (j % 2 ? 0.5 : 0)) * 0.36;
      if (Math.abs(u) > 0.78) continue;
      const p = S(u, t);
      badge(star, p.x, p.y, 0.035, o.motif);
    }
  }
}

/* ---------------- mammoth tusks ---------------- */

/**
 * One great tusk on side `sd`: a single smooth ivory spiral that leaves the skull beside the trunk, sweeps down,
 * forward and outward, then curls up and in. A fur-and-leather sheath hides the root, gold war-rings in the
 * team colour bind the middle, and the tips are capped with iron points.
 */
export function mammothTusk(head: G, sd: number, tc: number) {
  const root: V3 = [sd * 0.34, -0.42, 0.5];
  const path: V3[] = ([
    [sd * 0.34, -0.42, 0.5], [sd * 0.44, -0.86, 0.72], [sd * 0.58, -1.24, 1.1], [sd * 0.7, -1.42, 1.58],
    [sd * 0.72, -1.28, 2.04], [sd * 0.6, -0.92, 2.32], [sd * 0.4, -0.56, 2.36],
  ] as V3[]).map(p => [root[0] + (p[0] - root[0]) * 1.22, root[1] + (p[1] - root[1]) * 1.12, root[2] + (p[2] - root[2]) * 1.18] as V3);
  const r = (t: number) => 0.2 * Math.pow(1 - t, 0.72) + 0.012;
  put(head, sweep(path, r, { seg: 40, radial: 12 }), horn(0xf1ead4));
  // Growth bands: a faint darker ivory ring every hand-span near the root.
  const curve = new THREE.CatmullRomCurve3(path.map(p => new THREE.Vector3(...p)), false, "centripetal");
  const ringAt = (t: number, R: number, tube: number, mat: Mat) => {
    const P = curve.getPointAt(t), T = curve.getTangentAt(t);
    const m = put(head, torus(R, tube, 18), mat, P.x, P.y, P.z);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), T);
    return P;
  };
  for (const t of [0.08, 0.15]) ringAt(t, r(t) * 1.0, r(t) * 0.08, horn(0xd8cdb0));
  // Root sheath of shaggy fur over a leather cuff.
  const P0 = curve.getPointAt(0.02), T0 = curve.getTangentAt(0.02);
  const sheath = put(head, latheZ([[0, -0.12], [0.24, -0.12], [0.25, 0.0], [0.22, 0.1], [0.19, 0.16], [0, 0.16]], 12), hide(0x4a3626), P0.x, P0.y, P0.z);
  sheath.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), T0);
  // War rings: two gold bands with a team-coloured wrap between them.
  for (const t of [0.34, 0.44]) ringAt(t, r(t) * 1.02, 0.03, gildMat());
  const wrapP = curve.getPointAt(0.39), wrapT = curve.getTangentAt(0.39);
  const wrap = put(head, latheZ([[0, -0.07], [r(0.39) * 1.06, -0.07], [r(0.39) * 1.08, 0], [r(0.39) * 1.06, 0.07], [0, 0.07]], 14), cloth(tc), wrapP.x, wrapP.y, wrapP.z);
  wrap.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), wrapT);
  for (let k = 0; k < 4; k++) {
    const a = (k / 4) * PI * 2;
    const P = curve.getPointAt(0.39), T = curve.getTangentAt(0.39);
    const N = new THREE.Vector3(0, 1, 0).cross(T).normalize(), Bv = T.clone().cross(N);
    const d = N.multiplyScalar(Math.cos(a)).add(Bv.multiplyScalar(Math.sin(a))).multiplyScalar(r(0.39) * 1.1);
    stud(head, gildMat(), 0.028, P.x + d.x, P.y + d.y, P.z + d.z, 1);
  }
  // Iron tip caps: a ferrule and a sharpened point following the curl.
  const Pt = curve.getPointAt(0.9), Tt = curve.getTangentAt(0.9);
  const cap = put(head, latheZ([[0, -0.05], [r(0.9) * 1.25, -0.05], [r(0.9) * 1.3, 0.0], [r(0.96) * 1.2, 0.11], [0, 0.26]], 10, true), ironMat(0x5c6470), Pt.x, Pt.y, Pt.z);
  cap.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), Tt);
  ringAt(0.88, r(0.88) * 1.3, 0.016, gildMat());
}
