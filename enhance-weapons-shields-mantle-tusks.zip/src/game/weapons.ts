import * as THREE from "three";
import { GEO, M, type TeamId } from "./units";
import {
  B, BLADE, BONE, BRASS, GOLD, GRIP, IRON, STEEL_DARK, STEEL_LIGHT, WOOD,
  arrow, axeHead, blade, bow, club, cloth, curvedBlade, frame, gildMat, gnarledStaff, gold, grip, guard, haft, ironMat,
  lacquer, latheZ, leather, longBlade, orbStaff, panelShield, plateMat, pommel, put, roundShield, silk, slab, spearhead,
  steel, stud, sweep, sword, torus, waxLeather,
} from "./armory";
import { BONE_DARK, LEATHER_DARK, PI, boneMat, type HumanKind } from "./rig-kit";
import type { HandMode } from "./rigs";

/* ============================================================
   Every humanoid's weapon and shield, built from the armory kit.
   `hand` is the weapon hand (scaled 1.18 inside the right arm);
   shields and off-hand weapons are authored in left-arm space.
   ============================================================ */

type G = THREE.Group;
type V2 = [number, number];
export interface Armed { handMode: HandMode; handRest: number }
interface Ctx { kind: HumanKind; team: TeamId; hand: G; lArm: G; rArm: G; tc: number; tcd: number; tcl: number; skin: number }

/** Swallow-tailed pennon trailing back along a shaft from z = at. */
function pennon(g: G, at: number, len: number, h: number, mat: THREE.Material, r = 0.04) {
  const pts: V2[] = [[at, r * 0.6], [at, r * 0.6 + h], [at - len, r * 0.6 + h * 0.86], [at - len * 0.72, r * 0.6 + h * 0.5], [at - len, r * 0.6 + h * 0.12]];
  put(g, slab(pts, 0.012, { bevel: 0.003 }), mat);
  put(g, latheZ([[0, at - 0.015], [r * 1.25, at - 0.015], [r * 1.25, at + 0.015], [0, at + 0.015]], 8), gold(BRASS));
  put(g, latheZ([[0, at - len * 0.32 - 0.015], [r * 1.2, at - len * 0.32 - 0.015], [r * 1.2, at - len * 0.32 + 0.015], [0, at - len * 0.32 + 0.015]], 8), gold(BRASS));
}

/** Short straight dagger along +Z. */
function dagger(g: G, len: number, mat: THREE.Material, hilt: THREE.Material, o: { curve?: number; w?: number } = {}) {
  grip(g, -0.11, 0.05, 0.03, GRIP(), 4);
  guard(g, 0.07, "curved", hilt, 0.09, { thick: 0.032 });
  pommel(g, -0.13, "ball", hilt, 0.8);
  if (o.curve) curvedBlade(g, 0.08, len, o.w ?? 0.042, o.curve, mat, { taper: 0.7, th: 0.016 });
  else longBlade(g, 0.08, len, o.w ?? 0.042, (o.w ?? 0.042) * 0.8, { tip: 0.3, fuller: 0.5, th: 0.015 });
}

export function armHumanoid(c: Ctx): Armed {
  const { kind, team, hand, lArm, tc, tcd, tcl } = c;
  switch (kind) {
    case "spear": {
      frame(lArm, [0.12, -0.46, 0.17], [0, 0.06, 0], f => roundShield(f, {
        r: 0.5, face: WOOD(0x7a5532), rim: steel(), boss: steel(STEEL_LIGHT), rivet: gold(BRASS),
        heraldry: { field: cloth(tc), charge: "star", chargeMat: gildMat() },
      }));
      haft(hand, -0.42, 2.14, 0.036, WOOD(0x6b4a2a), { cap: steel(STEEL_DARK), gripAt: [-0.12, 0.14], bands: [0.9] });
      spearhead(hand, 2.08, 0.52, 0.065, BLADE(), { r: 0.036 });
      pennon(hand, 2.04, 0.42, 0.17, cloth(tc), 0.036);
      return { handMode: "fixed", handRest: 0.1 };
    }
    case "guardian": {
      frame(lArm, [0.1, -0.42, 0.26], [0, 0.05, 0], f => panelShield(f, {
        w: 0.84, h: 1.24, style: "tower", curve: 0.75, face: steel(0x8d96a6), rim: steel(STEEL_LIGHT),
        heraldry: { field: cloth(tc), charge: "cross", chargeMat: gildMat() }, studs: gold(BRASS), band: steel(STEEL_LIGHT),
      }));
      sword(hand, { len: 0.82, w0: 0.058, w1: 0.046, grip: [-0.12, 0.06], guard: "cross", guardW: 0.16, guardMat: gold(), pommel: "wheel" });
      return { handMode: "follow", handRest: -0.9 };
    }
    case "archer": case "elf": case "bonearcher": case "snakearcher": {
      const elf = kind === "elf", bone = kind === "bonearcher", snake = kind === "snakearcher";
      const s = elf ? 1.18 : 1;
      bow(hand, {
        span: 0.54 * s, draw: 0.5 * s, belly: 0.14, recurve: elf ? 0.05 : 0.09,
        wood: bone ? boneMat(0xcabc96) : elf ? M(0xc8a060, 0.5, 0.1) : snake ? M(0x5a7a34, 0.6) : WOOD(0x7a5228),
        grip: elf ? silk(0x2f6a35) : bone ? leather(0x3a2418) : GRIP(), nock: elf ? gildMat() : bone ? boneMat(BONE_DARK) : gold(BRASS),
        bone, leaf: elf ? M(0x4fc27a, 0.6) : undefined,
      });
      if (snake) {
        arrow(hand, -0.5 * s, 0.6, { fletch: cloth(0x5fa046), head: steel() });
        // The arrow on the string is already half snake.
        put(hand, GEO.sph, M(0x4f8a3a, 0.6), 0, 0, 0.62, 0, 0, 0, 1);
        (hand.children[hand.children.length - 1] as THREE.Mesh).scale.set(0.06, 0.05, 0.1);
        for (const sd of [-1, 1]) stud(hand, B(0xffd84a), 0.016, sd * 0.035, 0.03, 0.68, 1);
        part2(hand, B(0xd03a3a), 0.012, 0.012, 0.09, 0, -0.01, 0.76);
        for (let i = 0; i < 4; i++) { put(hand, GEO.sph, M(i % 2 ? 0x3f7a2e : 0x5fa046, 0.6), Math.sin(i * 1.6) * 0.03, 0, 0.12 + i * 0.12); (hand.children[hand.children.length - 1] as THREE.Mesh).scale.set(0.04, 0.04, 0.07); }
      } else {
        arrow(hand, -0.5 * s, 1.0 * s, { shaft: bone ? 0xd8d0b4 : 0xb69250, fletch: bone ? cloth(0x3a2418) : cloth(tcl), broad: !elf, head: bone ? ironMat(0x6a6a62) : steel() });
      }
      return { handMode: "fixed", handRest: 0 };
    }
    case "crossbow": {
      const wood = WOOD(0x6b4a2a);
      // Stock: a shaped tiller with a dropped butt.
      put(hand, slab([[-0.34, -0.02], [-0.34, -0.15], [-0.26, -0.14], [-0.08, -0.06], [0.2, -0.045], [0.64, -0.04], [0.66, 0.0], [0.64, 0.035], [0.05, 0.04], [-0.12, 0.035], [-0.28, 0.03]], 0.085, { bevel: 0.012 }), wood);
      for (const z of [0.1, 0.42]) put(hand, latheZ([[0, z - 0.02], [0.06, z - 0.02], [0.06, z + 0.02], [0, z + 0.02]], 4).rotateZ(PI / 4), ironMat());
      put(hand, slab([[0.5, 0.03], [0.66, 0.03], [0.66, 0.06], [0.5, 0.06]], 0.1, { bevel: 0.006 }), ironMat(), 0, 0, 0);
      // Steel prod across X, bent forward at the tips.
      put(hand, sweep([[-0.5, 0, 0.5], [-0.3, 0, 0.57], [0, 0, 0.6], [0.3, 0, 0.57], [0.5, 0, 0.5]], t => 0.022 + 0.012 * Math.sin(t * PI), { seg: 20, radial: 6, squash: 0.55, wide: [0, 1, 0] }), steel(0x6a7280));
      for (const sd of [-1, 1]) {
        put(hand, latheZ([[0, -0.02], [0.022, -0.015], [0.022, 0.02], [0, 0.025]], 6), gold(BRASS), sd * 0.5, 0, 0.5, 0, sd * PI / 2, 0);
        const a = new THREE.Vector3(sd * 0.5, 0, 0.49), b2 = new THREE.Vector3(0, 0.045, 0.22);
        const m = new THREE.Mesh(latheZ([[0.006, -a.distanceTo(b2) / 2], [0.006, a.distanceTo(b2) / 2]], 4), B(0xe6dcb0));
        m.position.copy(a).add(b2).multiplyScalar(0.5);
        m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), b2.clone().sub(a).normalize());
        hand.add(m);
      }
      // Nut, trigger lever and foot stirrup.
      put(hand, GEO.cyl, ironMat(), 0, 0.04, 0.22, 0, 0, PI / 2); (hand.children[hand.children.length - 1] as THREE.Mesh).scale.set(0.035, 0.1, 0.035);
      put(hand, sweep([[0, -0.04, 0.12], [0, -0.1, 0.06], [0, -0.13, -0.08], [0, -0.12, -0.2]], t => 0.014 * (1 - t * 0.4), { seg: 10, radial: 5 }), ironMat());
      put(hand, torus(0.08, 0.014, 12, PI), steel(STEEL_DARK), 0, -0.02, 0.66, PI / 2, 0, 0);
      // Quarrel on the tiller.
      put(hand, latheZ([[0, 0.22], [0.014, 0.22], [0.014, 0.66], [0, 0.66]], 6), M(0x8a6a3a, 0.7), 0, 0.06, 0);
      put(hand, latheZ([[0, 0.64], [0.03, 0.66], [0, 0.78]], 4, true), steel(), 0, 0.06, 0);
      for (const sd of [-1, 1]) put(hand, slab([[0.24, 0], [0.34, 0], [0.31, 0.035], [0.25, 0.035]], 0.005, { bevel: 0 }), cloth(tcl), sd * 0.004, 0.06, 0, 0, 0, sd * 0.6);
      return { handMode: "fixed", handRest: 0 };
    }
    case "swordsman": {
      sword(hand, { len: 0.92, w0: 0.06, w1: 0.047, grip: [-0.12, 0.06], guard: "curved", guardW: 0.17, guardMat: steel(STEEL_LIGHT), pommel: "wheel", pommelMat: gold(BRASS) });
      frame(lArm, [0.1, -0.5, 0.13], [0, 0.06, 0], f => roundShield(f, {
        r: 0.3, dome: 0.07, face: steel(0x9aa3b2), rim: gold(BRASS), boss: plateMat(), rivets: 8,
        heraldry: { field: cloth(tc), second: cloth(tcl), charge: "rays" },
      }));
      return { handMode: "follow", handRest: -0.6 };
    }
    case "halberdier": {
      haft(hand, -0.52, 2.5, 0.04, WOOD(0x5a3d24), { cap: steel(STEEL_DARK), gripAt: [-0.14, 0.16], bands: [1.1] });
      spearhead(hand, 2.44, 0.56, 0.05, BLADE(), { r: 0.04, shape: "lozenge", langets: false });
      // Halberd blade (crescent edge up, +Y) and back hook.
      put(hand, slab([[2.24, 0.03], [2.2, 0.12], [2.12, 0.27], [2.2, 0.37], [2.36, 0.41], [2.52, 0.39], [2.6, 0.33], [2.47, 0.23], [2.44, 0.1], [2.43, 0.03]], 0.05, {
        bevel: 0.006, taper: (_u, v) => 1 - 0.8 * smooth(0.14, 0.4, v),
      }), steel(0xb8c1cd));
      put(hand, sweep([[0, 0.39, 2.13], [0, 0.42, 2.3], [0, 0.4, 2.52], [0, 0.34, 2.6]], () => 0.009, { seg: 12, radial: 4, squash: 0.35, wide: [0, 1, 0] }), plateMat(0xf2f5fa));
      put(hand, slab([[2.28, -0.03], [2.38, -0.03], [2.36, -0.1], [2.46, -0.3], [2.36, -0.22], [2.3, -0.1]], 0.04, { bevel: 0.005, taper: (_u, v) => 1 - 0.6 * smooth(-0.1, -0.3, v) }), steel(0xb8c1cd));
      put(hand, latheZ([[0, 2.2], [0.056, 2.2], [0.06, 2.24], [0.056, 2.47], [0, 2.47]], 8), steel(STEEL_DARK));
      for (const z of [2.27, 2.4]) for (const sd of [-1, 1]) stud(hand, gold(BRASS), 0.013, sd * 0.06, 0, z, 0.6, 0, sd * PI / 2);
      put(hand, slab([[2.15, 0.0], [2.2, 0.05], [2.18, 0.0], [2.2, -0.05]], 0.02, { bevel: 0 }), cloth(tc), 0, 0, 0);
      frame(lArm, [0.12, -0.5, 0.15], [0, 0.06, 0], f => roundShield(f, {
        r: 0.4, dome: 0.07, face: steel(0x7f8896), rim: steel(STEEL_LIGHT), boss: steel(STEEL_LIGHT), rivet: gold(BRASS), rivets: 10,
        heraldry: { field: cloth(tc), charge: "chevron", chargeMat: plateMat() },
      }));
      return { handMode: "fixed", handRest: 0.1 };
    }
    case "paladin": {
      sword(hand, {
        len: 1.0, w0: 0.08, w1: 0.064, grip: [-0.38, 0.08], gripR: 0.036, gripMat: silk(tcd), guard: "winged", guardW: 0.24, guardMat: gildMat(),
        pommel: "gem", gem: 0x7fd8ff, ricasso: gildMat(), fuller: 0.6,
      });
      frame(lArm, [0.1, -0.4, 0.22], [0, 0.05, 0], f => panelShield(f, {
        w: 0.58, h: 0.84, style: "heater", curve: 0.9, face: plateMat(0xd8dbe2), rim: gildMat(),
        heraldry: { field: cloth(tc), charge: "cross", chargeMat: gildMat() }, studs: gildMat(),
      }));
      return { handMode: "follow", handRest: -0.7 };
    }
    case "orc": {
      frame(lArm, [0.1, -0.48, 0.17], [0, 0.06, 0.2], f => roundShield(f, {
        r: 0.48, dome: 0.06, face: WOOD(0x6a4a2a), rim: ironMat(0x4a4e55), boss: ironMat(0x5a5e66), rivet: ironMat(0x3a3e45), bossSpike: steel(0x8b939f),
        planks: M(0x3a2818, 0.9), spikes: steel(0x8b939f), heraldry: { second: cloth(tc), charge: "rays" },
      }));
      haft(hand, -0.28, 0.98, 0.048, WOOD(0x5a3d24), { gripAt: [-0.18, 0.12], cap: ironMat(0x4a4e55), bands: [0.62] });
      axeHead(hand, 0.84, 0.048, 1.3, ironMat(0x7c838d), { crude: true, spike: ironMat(0x7c838d) });
      return { handMode: "follow", handRest: -1.1 };
    }
    case "berserker": {
      const one = (g: G) => {
        haft(g, -0.24, 0.88, 0.04, WOOD(0x5d4226), { gripAt: [-0.16, 0.1], cap: ironMat(), bands: [] });
        axeHead(g, 0.76, 0.04, 1.0, steel(0x9aa3b2));
      };
      one(hand);
      frame(lArm, [0, -0.74, 0.04], [-0.5, 0, 0], f => one(f));
      return { handMode: "follow", handRest: -1.0 };
    }
    case "javelin": {
      const jav = (g: G, len: number, x: number) => {
        haft(g, -0.55 + x, -0.55 + len, 0.03, WOOD(0x9a7a4a), { taper: 0.9 });
        spearhead(g, -0.6 + len, 0.36, 0.048, BLADE(), { r: 0.03, shape: "lozenge", langets: false });
        grip(g, -0.06, 0.12, 0.034, cloth(0xd9c79a), 4);
      };
      frame(hand, [0.1, 0, 0], [0, 0, 0], f => jav(f, 1.7, 0));
      frame(lArm, [-0.16, -0.2, 0.2], [0, 0, 0], f => jav(f, 1.5, 0));
      return { handMode: "fixed", handRest: -0.2 };
    }
    case "bomber": {
      put(hand, latheZ([[0, -0.2], [0.12, -0.17], [0.19, -0.08], [0.2, 0.02], [0.17, 0.12], [0.1, 0.18], [0, 0.2]], 14), M(0x25252a, 0.5, 0.2), 0, 0.12, 0.18, -PI / 2, 0, 0);
      put(hand, torus(0.2, 0.016, 18), ironMat(0x5a5a60), 0, 0.12, 0.18, PI / 2, 0, 0);
      put(hand, latheZ([[0, 0], [0.045, 0], [0.045, 0.06], [0.035, 0.07], [0, 0.07]], 8), gold(BRASS), 0, 0.31, 0.18, -PI / 2, 0, 0);
      put(hand, sweep([[0, 0.37, 0.18], [0.02, 0.42, 0.17], [0.0, 0.46, 0.19]], () => 0.012, { seg: 6, radial: 4 }), M(0xa58a5a));
      put(hand, GEO.sph, B(0xffb050), 0, 0.48, 0.19, 0, 0, 0, 0.06);
      put(hand, GEO.sph, B(0xfff0a0), 0, 0.5, 0.19, 0, 0, 0, 0.03);
      return { handMode: "follow", handRest: 0 };
    }
    case "shaman": {
      const top = gnarledStaff(hand, 1.6, WOOD(0x4a3520), 1.3);
      // Horned beast skull lashed to the fork.
      put(hand, latheZ([[0, -0.12], [0.1, -0.1], [0.13, 0], [0.11, 0.08], [0, 0.12]], 10), boneMat(), top.x, top.y + 0.02, top.z + 0.12, 0, 0, 0);
      put(hand, latheZ([[0, 0], [0.06, 0.02], [0.05, 0.12], [0, 0.16]], 8), boneMat(), top.x, top.y - 0.06, top.z + 0.16, -0.6, 0, 0);
      for (const sd of [-1, 1]) {
        put(hand, sweep([[top.x + sd * 0.08, top.y + 0.06, top.z + 0.16], [top.x + sd * 0.2, top.y + 0.12, top.z + 0.2], [top.x + sd * 0.24, top.y + 0.04, top.z + 0.32], [top.x + sd * 0.18, top.y - 0.02, top.z + 0.36]], t => 0.03 * (1 - t * 0.8), { seg: 10, radial: 5 }), boneMat(BONE_DARK));
        stud(hand, B(0x8fe06a), 0.022, top.x + sd * 0.05, top.y - 0.04, top.z + 0.2, 1);
      }
      for (let i = 0; i < 3; i++) put(hand, slab([[0, 0], [0.05, -0.02], [0.2, 0], [0.05, 0.02]], 0.008, { orient: "front", bevel: 0 }), cloth(i === 1 ? tc : 0xd8cfb0), top.x + 0.06, top.y - 0.08 - i * 0.03, top.z - 0.02, 0, 0, -1.3 - i * 0.2);
      return { handMode: "fixed", handRest: -1.4 };
    }
    case "troll":
      club(hand, 2.05, 0.09, 0.26, WOOD(0x5e4228), ironMat(0x6a707a), 7, 0.3);
      return { handMode: "follow", handRest: -1.1 };
    case "giant":
      club(hand, 2.3, 0.12, 0.32, WOOD(0x6a4a2a), ironMat(0x6a707a), 9, 0.7);
      return { handMode: "follow", handRest: -1.1 };
    case "monk":
      return { handMode: "follow", handRest: -0.3 };
    case "assassin": {
      dagger(hand, 0.5, plateMat(0xd9dfe8), steel(STEEL_DARK), { curve: 0.05, w: 0.044 });
      frame(lArm, [0, -0.73, 0.04], [-0.9, 0, 0], f => dagger(f, 0.42, plateMat(0xd9dfe8), steel(STEEL_DARK), { curve: 0.04, w: 0.04 }), 1.18);
      return { handMode: "follow", handRest: -0.9 };
    }
    case "mage":
      orbStaff(hand, { len: 1.75, wood: WOOD(0x3a2818), metal: gildMat(), glow: team === 0 ? 0xd9a8ff : 0xffc0a0 });
      return { handMode: "fixed", handRest: -1.45 };
    case "frost":
      orbStaff(hand, { len: 1.75, wood: M(0xb8c8d8, 0.4, 0.1), metal: steel(0x8fc0f0), glow: 0x9fe0ff, crystals: 5, prongs: 3 });
      return { handMode: "fixed", handRest: -1.45 };
    case "cleric": {
      haft(hand, -0.52, 1.0, 0.036, M(0xe0d8c0, 0.5), { cap: gildMat(), bands: [-0.1, 0.12, 0.6] , bandMat: gildMat() });
      put(hand, latheZ([[0, 0.95], [0.05, 0.95], [0.07, 1.0], [0.05, 1.04], [0, 1.04]], 10), gildMat());
      put(hand, torus(0.19, 0.03, 24), gildMat(), 0, 0, 1.24, 0, PI / 2, 0);
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * PI * 2, l = i % 2 ? 0.08 : 0.14;
        const m = put(hand, latheZ([[0, 0], [0.022, 0], [0, l]], 4, true), gildMat(), 0, Math.cos(a) * 0.21, 1.24 + Math.sin(a) * 0.21);
        m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(0, Math.cos(a), Math.sin(a)));
      }
      put(hand, GEO.sph, B(0xfff2b0), 0, 0, 1.24, 0, 0, 0, 0.1);
      put(hand, GEO.sph, B(0xffffff), 0, 0, 1.24, 0, 0, 0, 0.055);
      put(hand, slab([[1.42, 0.022], [1.56, 0.022], [1.56, -0.022], [1.42, -0.022]], 0.04, { bevel: 0.006 }), gildMat());
      put(hand, slab([[1.5, 0.08], [1.535, 0.08], [1.535, -0.08], [1.5, -0.08]], 0.04, { bevel: 0.006 }), gildMat());
      return { handMode: "fixed", handRest: -1.45 };
    }
    case "king": {
      sword(hand, {
        len: 1.6, w0: 0.085, w1: 0.066, grip: [-0.2, 0.2], gripR: 0.036, gripMat: silk(0x8a2f3c), guardZ: 0.25,
        guard: "winged", guardW: 0.27, guardMat: gildMat(), pommel: "gem", gem: 0xff3a4a, ricasso: gildMat(), fuller: 0.55,
      });
      for (const z of [-0.1, 0.06]) put(hand, torus(0.04, 0.008, 12), gildMat(), 0, 0, z);
      // Sceptre in the left hand: knopped gold rod, orb and cross.
      frame(lArm, [0.0, -0.74, 0.04], [-0.75, 0, 0], f => {
        put(f, latheZ([[0, -0.22], [0.03, -0.22], [0.045, -0.18], [0.025, -0.14], [0.022, 0.0], [0.04, 0.03], [0.022, 0.06], [0.024, 0.52], [0.045, 0.56], [0.03, 0.6], [0, 0.6]], 10), gildMat());
        put(f, GEO.sph, gildMat(), 0, 0, 0.72, 0, 0, 0, 0.12);
        put(f, torus(0.122, 0.014, 20), gold(), 0, 0, 0.72, 0, PI / 2, 0);
        put(f, torus(0.122, 0.014, 20), gold(), 0, 0, 0.72, 0, 0, 0);
        for (let i = 0; i < 4; i++) { const a = i * PI / 2 + PI / 4; stud(f, B(i % 2 ? 0xff3a4a : 0x4ad0ff), 0.026, Math.cos(a) * 0.125, Math.sin(a) * 0.125, 0.72, 0.6, Math.sin(a) * -1.2, Math.cos(a) * 1.2); }
        put(f, slab([[0.82, 0.02], [1.02, 0.02], [1.02, -0.02], [0.82, -0.02]], 0.035, { bevel: 0.006 }), gildMat());
        put(f, slab([[0.9, 0.075], [0.94, 0.075], [0.94, -0.075], [0.9, -0.075]], 0.035, { bevel: 0.006 }), gildMat());
      });
      return { handMode: "fixed", handRest: -0.2 };
    }
    case "pirate": {
      // Flintlock pistol: shaped stock, octagonal barrel with a flared muzzle, lock and trigger guard.
      put(hand, slab([[-0.16, -0.16], [-0.04, -0.2], [0.03, -0.12], [0.06, -0.06], [0.3, -0.04], [0.5, -0.035], [0.5, 0.03], [0.08, 0.045], [-0.04, 0.03], [-0.14, -0.02], [-0.2, -0.1]], 0.07, { bevel: 0.012 }), WOOD(0x3a2c22));
      put(hand, latheZ([[0, 0.1], [0.032, 0.1], [0.03, 0.62], [0.034, 0.72], [0.042, 0.8], [0.03, 0.8], [0, 0.78]], 8, true), M(0x8a8f98, 0.35, 0.8), 0, 0.03, 0);
      for (const z of [0.3, 0.5]) put(hand, latheZ([[0, z - 0.012], [0.04, z - 0.012], [0.04, z + 0.012], [0, z + 0.012]], 8), gold(BRASS), 0, 0.0, 0);
      put(hand, latheZ([[0, -0.24], [0.04, -0.22], [0.052, -0.17], [0.045, -0.14], [0, -0.13]], 10), gold(BRASS), 0, -0.13, 0, 0.5, 0, 0);
      put(hand, slab([[0.02, 0.0], [0.16, 0.0], [0.16, 0.05], [0.02, 0.05]], 0.012, { bevel: 0.003 }), steel(0x8a8f98), 0.04, 0, 0);
      put(hand, slab([[0.02, 0.04], [0.06, 0.04], [0.09, 0.1], [0.07, 0.12], [0.04, 0.08]], 0.02, { bevel: 0.003 }), steel(0x8a8f98), 0.04, 0, 0);
      put(hand, torus(0.05, 0.008, 10, PI), gold(BRASS), 0, -0.06, 0.08, 0, PI / 2, PI);
      // Cutlass in the left hand: curved blade, brass knuckle bow and cup.
      frame(lArm, [0, -0.74, 0.04], [-0.35, 0, 0], f => {
        grip(f, -0.1, 0.06, 0.03, GRIP(), 4);
        put(f, latheZ([[0, 0.05], [0.07, 0.06], [0.085, 0.09], [0.04, 0.1], [0, 0.1]], 12), gold(BRASS));
        put(f, sweep([[0, -0.06, 0.08], [0, -0.1, 0.02], [0, -0.09, -0.08], [0, -0.03, -0.13]], () => 0.012, { seg: 10, radial: 5 }), gold(BRASS));
        pommel(f, -0.12, "ball", gold(BRASS), 0.8);
        curvedBlade(f, 0.1, 0.6, 0.05, 0.07, BLADE(), { taper: 0.95, th: 0.016 });
      }, 1.0);
      return { handMode: "fixed", handRest: -0.15 };
    }
    case "zeus": {
      put(hand, latheZ([[0, -0.1], [0.05, -0.08], [0.045, 0.6], [0.05, 1.4], [0.06, 1.6], [0.05, 1.64], [0, 1.64]], 10), M(0xe8e0c4, 0.55));
      for (let i = 0; i < 3; i++) put(hand, latheZ([[0, -0.03], [0.07, -0.03], [0.085, 0], [0.07, 0.03], [0, 0.03]], 10), gildMat(), 0, 0, 0.2 + i * 0.35);
      put(hand, latheZ([[0, 1.55], [0.06, 1.55], [0.1, 1.64], [0.08, 1.7], [0, 1.7]], 10), gildMat());
      put(hand, GEO.sph, B(0xe4f2ff), 0, 0, 1.82, 0, 0, 0, 0.17);
      put(hand, GEO.sph, B(0x9fd8ff), 0, 0, 1.82, 0, 0, 0, 0.1);
      for (let i = 0; i < 6; i++) {
        const a = i / 6 * PI * 2;
        const spike = put(hand, latheZ([[0, 0], [0.04, 0], [0, 0.3]], 5, true), gildMat(), Math.cos(a) * 0.13, Math.sin(a) * 0.13, 1.82);
        spike.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(Math.cos(a), Math.sin(a), 0.15).normalize());
      }
      for (let i = 0; i < 5; i++) {
        const a = i / 5 * PI * 2, bx = Math.cos(a), by = Math.sin(a);
        const pts: [number, number, number][] = [[bx * 0.2, by * 0.2, 1.82]];
        for (let seg = 1; seg <= 4; seg++) { const r0 = 0.2 + seg * 0.2, j = (seg % 2 ? 1 : -1) * 0.1; pts.push([bx * r0 + by * j, by * r0 - bx * j, 1.82]); }
        for (let k = 0; k < pts.length - 1; k++) {
          const p0 = new THREE.Vector3(...pts[k]), p1 = new THREE.Vector3(...pts[k + 1]);
          const m = new THREE.Mesh(latheZ([[0.045 * (1 - k * 0.2), -p0.distanceTo(p1) / 2], [0.036 * (1 - k * 0.2), p0.distanceTo(p1) / 2]], 4), B(0xe6f2ff));
          m.position.copy(p0).add(p1).multiplyScalar(0.5);
          m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), p1.clone().sub(p0).normalize());
          hand.add(m);
        }
      }
      put(hand, torus(0.36, 0.016, 28), gildMat(), 0, 0, 1.82, 0, PI / 2, 0);
      put(hand, torus(0.52, 0.016, 32), gildMat(), 0, 0, 1.82, 0, PI / 2, 0);
      return { handMode: "fixed", handRest: -1.3 };
    }
    case "sapper": {
      put(hand, latheZ([[0, -0.3], [0.24, -0.3], [0.27, -0.15], [0.28, 0], [0.27, 0.15], [0.24, 0.3], [0, 0.3]], 14), WOOD(0x6b4a2a), 0.2, 0.18, 0.2, 0, PI / 2, 0);
      for (const k of [-0.22, -0.08, 0.08, 0.22]) put(hand, torus(0.272 - Math.abs(k) * 0.12, 0.014, 18), ironMat(), 0.2 + k, 0.18, 0.2, 0, PI / 2, 0);
      put(hand, latheZ([[0, 0], [0.07, 0], [0.06, 0.04], [0, 0.04]], 8), M(0x2a2420), 0.2, 0.44, 0.2, -PI / 2, 0, 0);
      put(hand, sweep([[0.2, 0.47, 0.2], [0.22, 0.56, 0.21], [0.17, 0.64, 0.2]], () => 0.013, { seg: 6, radial: 4 }), M(0xd8c090));
      put(hand, GEO.sph, B(0xffa040), 0.17, 0.68, 0.2, 0, 0, 0, 0.07);
      put(hand, GEO.sph, B(0xfff2b0), 0.17, 0.7, 0.2, 0, 0, 0, 0.035);
      return { handMode: "fixed", handRest: -0.9 };
    }
    case "necromancer": {
      const top = gnarledStaff(hand, 1.8, M(0x2a1f18, 0.85), 2.1);
      const z = top.z + 0.16;
      put(hand, latheZ([[0, -0.14], [0.1, -0.12], [0.15, -0.02], [0.14, 0.08], [0.08, 0.14], [0, 0.15]], 12), boneMat(), top.x, top.y + 0.02, z, -PI / 2, 0, 0);
      put(hand, GEO.soft, boneMat(BONE_DARK), top.x, top.y - 0.1, z + 0.04, 0, 0, 0, 1);
      (hand.children[hand.children.length - 1] as THREE.Mesh).scale.set(0.15, 0.08, 0.12);
      for (const sgn of [-1, 1]) put(hand, GEO.sph, B(0x8fff6a), top.x + sgn * 0.055, top.y + 0.02, z + 0.12, 0, 0, 0, 0.038);
      put(hand, torus(0.24, 0.012, 24), B(0x5fd04a), top.x, top.y, z, 0.5, 0.3, 0);
      for (const sgn of [-1, 1]) put(hand, sweep([[top.x, top.y, top.z - 0.1], [top.x + sgn * 0.14, top.y, top.z - 0.02], [top.x + sgn * 0.17, top.y + 0.02, z + 0.06]], t => 0.022 * (1 - t * 0.8), { seg: 8, radial: 5 }), boneMat());
      return { handMode: "fixed", handRest: -1.45 };
    }
    case "skeleton": {
      sword(hand, { len: 0.88, w0: 0.056, w1: 0.046, grip: [-0.12, 0.06], guard: "bar", guardW: 0.15, guardMat: ironMat(0x5a4630), pommel: "ball", pommelMat: ironMat(0x5a4630), bladeMat: steel(0x8c8f8a), fuller: 0.5 });
      // Notches hacked into the edge.
      for (const z of [0.4, 0.62, 0.78]) put(hand, slab([[z, -0.07], [z + 0.03, -0.07], [z + 0.012, -0.04]], 0.05, { bevel: 0 }), B(0x2a2620));
      frame(lArm, [0.1, -0.5, 0.16], [0, 0.06, -0.15], f => roundShield(f, {
        r: 0.4, dome: 0.05, face: WOOD(0x6a5440), rim: ironMat(0x6a5444), boss: ironMat(0x7a6454), rivet: ironMat(0x4a3a30),
        planks: M(0x3a2c20, 0.9), cracked: true, rivets: 8,
      }));
      return { handMode: "follow", handRest: -1.0 };
    }
    case "vampire": {
      // Rapier: needle blade, swept hilt of rings, a pear pommel set with a ruby.
      grip(hand, -0.12, 0.05, 0.028, steel(STEEL_DARK), 7);
      put(hand, blade({ len: 1.08, width: t => 0.028 * (1 - t * 0.45) * (t > 0.9 ? (1 - t) / 0.1 : 1) + 0.002, th: 0.012, section: "diamond", stations: 8 }), plateMat(0xe8ecf2), 0, 0, 0.1);
      guard(hand, 0.07, "bar", gildMat(), 0.15, { thick: 0.028 });
      put(hand, latheZ([[0, 0.06], [0.06, 0.065], [0.075, 0.09], [0.07, 0.1], [0, 0.1]], 14), gildMat());
      for (const sd of [-1, 1]) put(hand, torus(0.06, 0.009, 14), gildMat(), 0, sd * 0.055, 0.12, PI / 2, 0, 0);
      put(hand, sweep([[0, -0.15, 0.07], [0, -0.1, 0.0], [0, -0.09, -0.1], [0, -0.03, -0.14]], () => 0.011, { seg: 10, radial: 5 }), gildMat());
      pommel(hand, -0.15, "pear", gildMat(), 0.85, 0xc81428);
      return { handMode: "follow", handRest: -0.6 };
    }
    case "zombie":
      return { handMode: "follow", handRest: 0 };
    case "hoplite": {
      frame(lArm, [0.12, -0.46, 0.2], [0, 0.06, 0], f => roundShield(f, {
        r: 0.66, dome: 0.13, flatRim: 0.08, face: gold(0xb8873a), rim: gold(0xd2a455), boss: gold(0xd2a455), rivet: gold(0xd2a455), rivets: 14,
        heraldry: { field: cloth(tc), charge: "chevron", chargeMat: M(0xf4f1e6, 0.6) },
      }));
      haft(hand, -0.42, 2.26, 0.036, WOOD(0x6b4a2a), { gripAt: [-0.12, 0.14] });
      spearhead(hand, 2.2, 0.5, 0.06, BLADE(), { r: 0.036, socketMat: gold(0xb8873a) });
      // Sauroter: bronze butt spike.
      put(hand, latheZ([[0, -0.72], [0.022, -0.6], [0.042, -0.46], [0.045, -0.4], [0, -0.4]], 8, true), gold(0xb8873a));
      return { handMode: "fixed", handRest: 0.1 };
    }
    case "samurai": {
      // Tsuka bound in team-coloured cord, a round tsuba, gold habaki, a curved blade with a temper line.
      put(hand, latheZ([[0, -0.32], [0.034, -0.32], [0.036, 0.12], [0, 0.12]], 8), cloth(0xf0eadc));
      for (let i = 0; i < 6; i++) put(hand, GEO.bevel, cloth(tc), 0, 0, -0.27 + i * 0.07, 0, 0, PI / 4, 1);
      for (let i = 0; i < 6; i++) (hand.children[hand.children.length - 6 + i] as THREE.Mesh).scale.set(0.074, 0.074, 0.034);
      put(hand, latheZ([[0, -0.36], [0.03, -0.355], [0.04, -0.33], [0.04, -0.31], [0, -0.31]], 10), gildMat());
      guard(hand, 0.14, "disc", ironMat(0x2a2620), 0.085);
      put(hand, torus(0.086, 0.008, 18), gold(), 0, 0, 0.14);
      put(hand, latheZ([[0, 0.15], [0.03, 0.15], [0.026, 0.2], [0, 0.2]], 4), gildMat());
      curvedBlade(hand, 0.17, 1.15, 0.045, 0.09, plateMat(0xe8ecf2), { taper: 0.72, th: 0.018, hamon: M(0xf6f8fb, 0.3, 0.1) });
      return { handMode: "follow", handRest: -0.75 };
    }
    case "ninja": {
      // Four-point throwing star pinched between the fingers, a tanto in the off hand.
      const star: V2[] = [];
      for (let i = 0; i < 8; i++) { const a = i * PI / 4, r = i % 2 ? 0.035 : 0.14; star.push([Math.cos(a) * r, Math.sin(a) * r]); }
      const hole: V2[] = []; for (let i = 0; i < 8; i++) { const a = -i * PI / 4; hole.push([Math.cos(a) * 0.015, Math.sin(a) * 0.015]); }
      put(hand, slab(star, 0.014, { orient: "flat", bevel: 0.004, holes: [hole], taper: (u, v) => 1 - 0.7 * Math.min(1, Math.hypot(u, v) / 0.14) }), plateMat(), 0, 0.04, 0.13);
      frame(lArm, [0, -0.73, 0.04], [-0.9, 0, 0], f => {
        put(f, latheZ([[0, -0.12], [0.03, -0.12], [0.03, 0.06], [0, 0.06]], 8), cloth(0x15131a));
        for (let i = 0; i < 3; i++) put(f, GEO.bevel, cloth(tc), 0, 0, -0.09 + i * 0.06, 0, 0, PI / 4, 1);
        for (let i = 0; i < 3; i++) (f.children[f.children.length - 3 + i] as THREE.Mesh).scale.set(0.062, 0.062, 0.03);
        guard(f, 0.07, "disc", ironMat(0x2a2620), 0.05);
        curvedBlade(f, 0.09, 0.36, 0.036, 0.015, plateMat(0xd9dfe8), { taper: 0.9, th: 0.014 });
      }, 1.0);
      return { handMode: "follow", handRest: -0.4 };
    }
    case "harpooner": {
      haft(hand, -0.65, 1.42, 0.04, WOOD(0x7a5a34), { gripAt: [-0.14, 0.14], bands: [1.3] });
      put(hand, latheZ([[0, 1.38], [0.032, 1.38], [0.028, 1.82], [0, 1.82]], 6), steel(STEEL_DARK), 0.0, 0, 0);
      put(hand, slab([[2.14, 0], [1.98, 0.065], [1.85, 0.14], [1.9, 0.05], [1.8, 0.03], [1.8, -0.03], [1.9, -0.05], [1.85, -0.14], [1.98, -0.065]], 0.04, {
        bevel: 0.005, taper: (_u, v) => 1 - 0.75 * Math.min(1, Math.abs(v) / 0.14),
      }), steel(0xc7cfdb));
      put(hand, torus(0.07, 0.022, 12), M(0xc9b27a, 0.95), 0, 0, 1.3);
      put(hand, sweep([[0.02, -0.06, 1.28], [0.04, -0.14, 0.9], [0.03, -0.16, 0.4], [0.02, -0.12, -0.1]], () => 0.012, { seg: 12, radial: 4 }), M(0xc9b27a, 0.95));
      put(lArm, torus(0.2, 0.03, 16), M(0xc9b27a, 0.95), 0, -0.74, 0.02, 0, PI / 2, 0);
      put(lArm, torus(0.17, 0.03, 16), M(0xb09a64, 0.95), 0.03, -0.74, 0.03, 0, PI / 2, 0);
      return { handMode: "fixed", handRest: -0.2 };
    }
    case "valkyrie": {
      haft(hand, -0.32, 1.78, 0.034, WOOD(0x6b4a2a), { cap: gildMat(), gripAt: [-0.1, 0.14] });
      spearhead(hand, 1.72, 0.48, 0.06, BLADE(), { r: 0.034, socketMat: gildMat() });
      // Winged lugs: feathered, gilded at the root.
      for (const sd of [-1, 1]) {
        put(hand, slab([[1.66, sd * 0.03], [1.74, sd * 0.05], [1.66, sd * 0.24], [1.58, sd * 0.28], [1.6, sd * 0.18], [1.54, sd * 0.2], [1.58, sd * 0.1]], 0.02, { bevel: 0.004 }), M(0xf6f3ea, 0.7));
      }
      put(hand, GEO.sph, gildMat(), 0, 0, 1.66, 0, 0, 0, 0.055);
      frame(lArm, [0.1, -0.5, 0.15], [0, 0.06, 0], f => roundShield(f, {
        r: 0.38, dome: 0.08, face: steel(0xcfd6e2), rim: gildMat(), boss: gildMat(), rivet: gildMat(), rivets: 8,
        heraldry: { field: cloth(tc), second: cloth(0xf4f1e6), charge: "rays" },
      }));
      return { handMode: "fixed", handRest: 0.15 };
    }
    case "fanbearer": {
      // Gunbai war fan: lacquered paddle, red sun on both faces, a gilt rim and a cord tassel.
      put(hand, latheZ([[0, -0.2], [0.036, -0.2], [0.04, -0.15], [0.034, 0.5], [0.05, 0.56], [0, 0.56]], 8), lacquer(0x15131a));
      const fan: V2[] = [];
      for (let i = 0; i <= 26; i++) {
        const a = -PI * 0.36 + (i / 26) * PI * 1.72;
        fan.push([1.1 + Math.sin(a) * 0.66 * -1 + 0.0, Math.cos(a) * 0.66]);
      }
      const shape: V2[] = [[0.5, 0.06], ...fan.map(([z, y]) => [z, y] as V2).filter(([z]) => z > 0.52), [0.5, -0.06]];
      put(hand, slab(shape, 0.04, { bevel: 0.008, curveSegments: 6 }), lacquer(0x1a1418));
      for (const sd of [-1, 1]) {
        const ring: V2[] = []; for (let i = 0; i < 28; i++) { const a = i / 28 * PI * 2; ring.push([1.12 + Math.cos(a) * 0.56, Math.sin(a) * 0.56]); }
        put(hand, slab(ring, 0.006, { bevel: 0 }), cloth(0xf4f1e6), sd * 0.032, 0, 0);
        const sun: V2[] = []; for (let i = 0; i < 24; i++) { const a = i / 24 * PI * 2; sun.push([1.12 + Math.cos(a) * 0.27, Math.sin(a) * 0.27]); }
        put(hand, slab(sun, 0.006, { bevel: 0 }), B(0xc8323a), sd * 0.037, 0, 0);
      }
      const rim: [number, number, number][] = [];
      for (let i = 0; i < 30; i++) { const a = i / 30 * PI * 2; rim.push([0, Math.sin(a) * 0.6, 1.12 + Math.cos(a) * 0.6]); }
      put(hand, sweep(rim, () => 0.022, { closed: true, seg: 40, radial: 5 }), gildMat());
      put(hand, sweep([[0, 0, -0.2], [0, -0.06, -0.28], [0, -0.12, -0.42]], () => 0.01, { seg: 6, radial: 4 }), cloth(tc));
      put(hand, latheZ([[0, 0], [0.03, 0.02], [0.05, 0.12], [0.04, 0.2], [0, 0.2]], 8), cloth(tc), 0, -0.13, -0.42, PI / 2 + 0.3, 0, 0);
      return { handMode: "follow", handRest: -0.9 };
    }
  }
  return { handMode: "follow", handRest: 0 };
}

const smooth = (a: number, b: number, x: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
function part2(g: G, mat: THREE.Material, sx: number, sy: number, sz: number, x: number, y: number, z: number) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), mat);
  m.scale.set(sx, sy, sz); m.position.set(x, y, z); g.add(m);
}
void IRON; void GOLD; void BONE; void LEATHER_DARK; void waxLeather;

/** Couched lance: grip and flared vamplate, a fluted shaft wound with a team-coloured spiral, steel head and pennon. */
export function knightLance(g: G, tc: number) {
  put(g, latheZ([[0, -0.62], [0.04, -0.6], [0.05, -0.5], [0.045, -0.22], [0.05, 0.16], [0.07, 0.42], [0.066, 0.9], [0.05, 2.0], [0.034, 2.9], [0, 2.92]], 10), WOOD(0x9a7448));
  grip(g, -0.2, 0.14, 0.05, GRIP(), 6);
  put(g, latheZ([[0, 0.16], [0.07, 0.16], [0.2, 0.26], [0.21, 0.29], [0.19, 0.3], [0.07, 0.46], [0, 0.46]], 16), steel(0x9aa3b2));
  put(g, torus(0.205, 0.016, 20), gold(), 0, 0, 0.28);
  const helix: [number, number, number][] = [];
  for (let i = 0; i <= 36; i++) {
    const t = i / 36, z = lerp(0.5, 2.55, t), r = lerp(0.068, 0.04, (z - 0.42) / 2.5) + 0.004, a = t * PI * 2 * 5;
    helix.push([Math.cos(a) * r, Math.sin(a) * r, z]);
  }
  put(g, sweep(helix, () => 0.016, { seg: 90, radial: 4, squash: 0.4 }), cloth(tc));
  put(g, latheZ([[0, 2.84], [0.045, 2.84], [0.05, 2.9], [0.04, 2.96], [0, 2.96]], 8), steel(STEEL_DARK));
  put(g, blade({ len: 0.36, width: t => 0.07 * (t < 0.3 ? 0.55 + t * 1.5 : (1 - t) / 0.7), th: 0.035, section: "diamond", stations: 6 }), BLADE(), 0, 0, 2.94);
  pennon(g, 2.66, 0.62, 0.24, cloth(tc), 0.036);
  put(g, slab([[2.66, 0.07], [2.66, 0.2], [2.36, 0.18], [2.36, 0.09]], 0.014, { bevel: 0.002 }), cloth(0xf4f1e6), 0.0, 0.0, 0.0);
}
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
