// Software-rasterised contact sheets of every baked unit rig: front / side / back plus two
// animated poses, so costume work can be checked without a GPU. Usage:
//   npx tsx tools/render-sheet.ts [outDir] [kind,kind,...]
import * as THREE from "three";
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { buildUnitRig, type UnitRig } from "../src/game/rigs";
import { DEPLOY, FACTIONS, type UnitKind } from "../src/game/units";

const ZOOM = Number(process.env.ZOOM ?? 1);
const CELL_W = 170 * ZOOM, CELL_H = 230 * ZOOM, PAD = 6 * ZOOM;
const outDir = process.argv[2] ?? "/tmp/sheets";
const only = process.argv[3]?.split(",").filter(Boolean) as UnitKind[] | undefined;
fs.mkdirSync(outDir, { recursive: true });

interface Tri { p: THREE.Vector3[]; c: THREE.Color; metal: boolean; basic: boolean }

function collect(rig: UnitRig): Tri[] {
  rig.root.updateMatrixWorld(true);
  const tris: Tri[] = [];
  for (const part of rig.parts) {
    const g = part.geometry;
    const pos = g.attributes.position, col = g.attributes.color;
    const idx = g.index;
    const n = idx ? idx.count : pos.count;
    const m = part.group.matrixWorld;
    const metal = (part.material as THREE.MeshStandardMaterial).metalness >= 0.3;
    const basic = part.material instanceof THREE.MeshBasicMaterial;
    for (let i = 0; i < n; i += 3) {
      const p: THREE.Vector3[] = [], c = new THREE.Color(0, 0, 0);
      for (let k = 0; k < 3; k++) {
        const vi = idx ? idx.getX(i + k) : i + k;
        p.push(new THREE.Vector3().fromBufferAttribute(pos, vi).applyMatrix4(m));
        c.r += col.getX(vi) / 3; c.g += col.getY(vi) / 3; c.b += col.getZ(vi) / 3;
      }
      tris.push({ p, c, metal, basic });
    }
  }
  return tris;
}

function pose(rig: UnitRig, which: 0 | 1 | 2) {
  if (which === 0) return;
  if (which === 1) {
    // mid-stride walk
    rig.lLeg.rotation.x = 0.55; rig.rLeg.rotation.x = -0.45;
    // Knees only fold backward (positive x): the trailing (left) leg folds at toe-off, the leading leg lands straight.
    if (rig.lShin) rig.lShin.rotation.x = 0.75;
    if (rig.rShin) rig.rShin.rotation.x = 0.1;
    rig.lArm.rotation.x = -0.5; rig.rArm.rotation.x = 0.5;
    rig.torso.rotation.y = 0.12;
    if (rig.cloak) rig.cloak.rotation.x = 0.4;
  } else {
    // attack wind-up
    rig.rArm.rotation.set(-2.2, 0, -0.4);
    rig.lArm.rotation.set(-0.9, 0.3, 0.6);
    rig.torso.rotation.x = rig.tilt + 0.25;
    rig.torso.rotation.y = -0.3;
    rig.head.rotation.y = 0.4;
    rig.lLeg.rotation.x = 0.3; rig.rLeg.rotation.x = -0.3;
    if (rig.lShin) rig.lShin.rotation.x = 0.4;
  }
}

function renderCell(img: Float32Array, W: number, ox: number, oy: number, tris: Tri[], yaw: number) {
  const zbuf = new Float32Array(CELL_W * CELL_H).fill(Infinity);
  const cy = Math.cos(yaw), sy = Math.sin(yaw);
  const rot = (v: THREE.Vector3) => new THREE.Vector3(v.x * cy + v.z * sy, v.y, -v.x * sy + v.z * cy);
  let minY = Infinity, maxY = -Infinity, minX = Infinity, maxX = -Infinity;
  const rt = tris.map(t => ({ ...t, p: t.p.map(rot) }));
  for (const t of rt) for (const p of t.p) { minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y); minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x); }
  const span = Math.max(maxY - minY, (maxX - minX) * CELL_H / CELL_W) * 1.06;
  const scale = (CELL_H - 2 * PAD) / span;
  const cx = (minX + maxX) / 2, cyy = (minY + maxY) / 2;
  const L = new THREE.Vector3(-0.5, 0.8, 0.9).normalize();
  const camL = new THREE.Vector3(L.x * cy - L.z * sy, L.y, L.x * sy + L.z * cy); // light is fixed to the viewer
  for (const t of rt) {
    const [a, b, c] = t.p;
    const n = new THREE.Vector3().subVectors(b, a).cross(new THREE.Vector3().subVectors(c, a));
    if (n.lengthSq() === 0) continue;
    n.normalize();
    if (n.z < 0) continue; // back-face
    const diff = Math.max(0, n.dot(camL));
    const rim = Math.pow(1 - Math.max(0, n.z), 3) * 0.25;
    const shade = t.basic ? 1 : (t.metal ? 0.3 + diff * 0.95 + Math.pow(diff, 14) * 0.5 : 0.42 + diff * 0.7) + rim;
    const sx = (p: THREE.Vector3) => (p.x - cx) * scale + CELL_W / 2;
    const sY = (p: THREE.Vector3) => CELL_H / 2 - (p.y - cyy) * scale;
    const x0 = sx(a), y0 = sY(a), x1 = sx(b), y1 = sY(b), x2 = sx(c), y2 = sY(c);
    const area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
    if (Math.abs(area) < 1e-6) continue;
    const bx0 = Math.max(0, Math.floor(Math.min(x0, x1, x2))), bx1 = Math.min(CELL_W - 1, Math.ceil(Math.max(x0, x1, x2)));
    const by0 = Math.max(0, Math.floor(Math.min(y0, y1, y2))), by1 = Math.min(CELL_H - 1, Math.ceil(Math.max(y0, y1, y2)));
    for (let y = by0; y <= by1; y++) for (let x = bx0; x <= bx1; x++) {
      const px = x + 0.5, py = y + 0.5;
      let w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) / area;
      let w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) / area;
      let w2 = 1 - w0 - w1;
      if (w0 < 0 || w1 < 0 || w2 < 0) continue;
      const z = -(w0 * a.z + w1 * b.z + w2 * c.z);
      const zi = y * CELL_W + x;
      if (z >= zbuf[zi]) continue;
      zbuf[zi] = z;
      const o = ((oy + y) * W + ox + x) * 3;
      img[o] = t.c.r * shade; img[o + 1] = t.c.g * shade; img[o + 2] = t.c.b * shade;
    }
  }
  // thin dark outline from depth discontinuities
  for (let y = 1; y < CELL_H - 1; y++) for (let x = 1; x < CELL_W - 1; x++) {
    const z = zbuf[y * CELL_W + x];
    if (z === Infinity) continue;
    const edge = [zbuf[y * CELL_W + x + 1], zbuf[y * CELL_W + x - 1], zbuf[(y + 1) * CELL_W + x], zbuf[(y - 1) * CELL_W + x]].some(nz => nz === Infinity || Math.abs(nz - z) > 0.08);
    if (edge) { const o = ((oy + y) * W + ox + x) * 3; img[o] *= 0.35; img[o + 1] *= 0.35; img[o + 2] *= 0.35; }
  }
}

function crc32(buf: Uint8Array) {
  let c, crc = 0xffffffff;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = (crc >>> 8) ^ c;
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function chunk(type: string, data: Uint8Array) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, "ascii"), Buffer.from(data)]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function writePng(file: string, img: Float32Array, W: number, H: number) {
  const raw = Buffer.alloc((W * 3 + 1) * H);
  for (let y = 0; y < H; y++) {
    raw[y * (W * 3 + 1)] = 0;
    for (let x = 0; x < W * 3; x++) raw[y * (W * 3 + 1) + 1 + x] = Math.max(0, Math.min(255, Math.round(Math.pow(Math.min(1, img[y * W * 3 + x]), 1 / 1.6) * 255)));
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const png = Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr), chunk("IDAT", zlib.deflateSync(raw, { level: 6 })), chunk("IEND", new Uint8Array(0)),
  ]);
  fs.writeFileSync(file, png);
}

const views: [string, number, 0 | 1 | 2][] = [["front", 0, 0], ["3/4", Math.PI * 0.3, 0], ["side", Math.PI / 2, 0], ["back", Math.PI, 0], ["walk", Math.PI * 0.2, 1], ["attack", -Math.PI * 0.25, 2]];
const groups = only ? [{ id: "custom", units: only }] : FACTIONS.map(f => ({ id: f.id, units: f.units.filter(u => DEPLOY.includes(u)) }));
for (const g of groups) {
  const W = views.length * CELL_W, H = g.units.length * CELL_H;
  const img = new Float32Array(W * H * 3).fill(0.16);
  g.units.forEach((kind, row) => {
    views.forEach(([, yaw, ps], col) => {
      const rig = buildUnitRig(kind, 0);
      pose(rig, ps);
      renderCell(img, W, col * CELL_W, row * CELL_H, collect(rig), yaw);
    });
  });
  const file = path.join(outDir, `${g.id}.png`);
  writePng(file, img, W, H);
  console.log("wrote", file, `${W}x${H}`, g.units.join(","));
}
