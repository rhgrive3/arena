// Prints per-unit baked geometry statistics (bone parts, vertices, triangles) so that
// costume changes can be checked against the renderer budget.
import { buildUnitRig } from "../src/game/rigs";
import { DEPLOY } from "../src/game/units";

let totalV = 0, totalT = 0;
const rows: string[] = [];
for (const kind of DEPLOY) {
  const rig = buildUnitRig(kind, 0);
  let v = 0, t = 0;
  for (const p of rig.parts) {
    v += p.geometry.attributes.position.count;
    t += (p.geometry.index ? p.geometry.index.count : p.geometry.attributes.position.count) / 3;
  }
  totalV += v; totalT += t;
  rows.push(`${kind.padEnd(12)} parts=${String(rig.parts.length).padStart(2)} verts=${String(v).padStart(6)} tris=${String(Math.round(t)).padStart(6)}`);
}
console.log(rows.join("\n"));
console.log(`TOTAL verts=${totalV} tris=${Math.round(totalT)} avg verts=${Math.round(totalV / DEPLOY.length)}`);
