// Dev-only WebGL contact sheet of the real unit materials, for close inspection of models.
// /tools/preview/index.html?kinds=king,knight&views=0,0.9,1.57,3.14&focus=hand&pose=attack&cell=360
import * as THREE from "three";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { OUTLINE_MAT, buildUnitRig, hasOutline, setRigEnvironment, type UnitRig } from "../../src/game/rigs";
import type { UnitKind } from "../../src/game/units";

const q = new URLSearchParams(location.search);
const kinds = (q.get("kinds") ?? "king").split(",") as UnitKind[];
const views = (q.get("views") ?? "0,0.8,1.57,3.14").split(",").map(Number);
const focus = q.get("focus") ?? "all"; // all | hand | larm | head | cloak | legs
const pose = q.get("pose") ?? "idle";
const team = Number(q.get("team") ?? 0) as 0 | 1;
const cell = Number(q.get("cell") ?? 320);
const pitch = Number(q.get("pitch") ?? 0.12);
const W = cell * views.length, H = Math.round(cell * 1.25) * kinds.length;
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(1);
renderer.setSize(W, H);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
renderer.setScissorTest(true);
document.body.appendChild(renderer.domElement);
const pmrem = new THREE.PMREMGenerator(renderer);
const probe = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
setRigEnvironment(probe);

function applyPose(rig: UnitRig) {
  if (pose === "walk") {
    rig.lLeg.rotation.x = 0.55; rig.rLeg.rotation.x = -0.45;
    if (rig.lShin) rig.lShin.rotation.x = 0.75;
    if (rig.rShin) rig.rShin.rotation.x = 0.1;
    rig.lArm.rotation.x = -0.5; rig.rArm.rotation.x = 0.5;
    if (rig.cloak) rig.cloak.rotation.x = 0.4;
    if (rig.flLeg) { rig.flLeg.rotation.x = 0.5; rig.brLeg!.rotation.x = 0.4; rig.frLeg!.rotation.x = -0.4; rig.blLeg!.rotation.x = -0.4; }
  } else if (pose === "attack") {
    rig.rArm.rotation.set(-2.2, 0, -0.4);
    rig.lArm.rotation.set(-0.9, 0.3, 0.6);
    rig.torso.rotation.x = rig.tilt + 0.25;
  } else if (pose === "shoot") {
    rig.lArm.rotation.set(-1.48, 0.25, 0.06); rig.rArm.rotation.set(-1.42, -0.35, -0.06);
    rig.hand.rotation.x = 1.42; rig.torso.rotation.y = -0.4;
  } else if (pose === "guard") {
    rig.rArm.rotation.x = rig.handRest; rig.lArm.rotation.x = -1.2;
  }
  if (pose !== "attack" && pose !== "shoot") rig.hand.rotation.x = rig.handMode === "fixed" ? rig.handRest - rig.rArm.rotation.x : rig.handRest;
  rig.torso.rotation.y = pose === "idle" ? -0.16 : rig.torso.rotation.y;
}

const focusGroup = (rig: UnitRig): THREE.Object3D | null =>
  focus === "hand" ? rig.hand : focus === "larm" ? rig.lArm : focus === "head" ? rig.head : focus === "cloak" ? (rig.cloak ?? rig.torso) : focus === "legs" ? (rig.flLeg ?? rig.lLeg) : focus === "torsoarea" ? rig.torso : null;

kinds.forEach((kind, row) => {
  views.forEach((yaw, col) => {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x2a2f33);
    scene.environment = probe; scene.environmentIntensity = 0.07;
    scene.add(new THREE.HemisphereLight(0xe9eddf, 0x414d54, 2.8));
    const key = new THREE.DirectionalLight(0xffe6af, 3.8); key.position.set(-4, 8, 7); scene.add(key);
    const rim = new THREE.DirectionalLight(0xa6c8e4, 3); rim.position.set(4, 4, -5); scene.add(rim);
    const rig = buildUnitRig(kind, team);
    applyPose(rig);
    for (const p of rig.parts) {
      p.group.add(new THREE.Mesh(p.geometry, p.material));
      if (hasOutline(p.material)) p.group.add(new THREE.Mesh(p.geometry, OUTLINE_MAT));
    }
    rig.root.rotation.y = yaw;
    scene.add(rig.root);
    rig.root.updateMatrixWorld(true);
    const target = focusGroup(rig) ?? rig.root;
    const box = new THREE.Box3();
    if (target === rig.root) box.setFromObject(rig.root);
    else target.traverse(o => { if (o instanceof THREE.Mesh && o.material !== OUTLINE_MAT && o.parent === target) box.expandByObject(o); });
    const cw = cell, ch = Math.round(cell * 1.25);
    const cam = new THREE.PerspectiveCamera(30, cw / ch, 0.05, 200);
    const c = box.getCenter(new THREE.Vector3()), s = box.getSize(new THREE.Vector3());
    const r = (s.length() / 2) / Math.sin(THREE.MathUtils.degToRad(15)) * (Number(q.get("zoom") ?? 1)) * 0.92;
    cam.position.set(c.x + r * Number(q.get("side") ?? 0), c.y + r * pitch, c.z + r);
    cam.lookAt(c);
    const x = col * cw, y = H - (row + 1) * ch;
    renderer.setViewport(x, y, cw, ch); renderer.setScissor(x, y, cw, ch);
    renderer.render(scene, cam);
  });
});
(window as unknown as { done: boolean }).done = true;
