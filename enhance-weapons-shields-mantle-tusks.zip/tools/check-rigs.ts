// Sanity check for generated geometry: every baked part must be finite and every bone bucket must have merged.
import { buildUnitRig } from "../src/game/rigs";
import { DEPLOY } from "../src/game/units";
let bad = 0;
const origError = console.error;
console.error = (...a: unknown[]) => { bad++; origError(...a); };
for (const k of DEPLOY) for (const t of [0, 1] as const) {
  const r = buildUnitRig(k, t);
  for (const p of r.parts) {
    const pos = p.geometry.attributes.position.array;
    for (let i = 0; i < pos.length; i++) if (!Number.isFinite(pos[i])) { console.log("non-finite vertex in", k); bad++; break; }
  }
}
console.log(bad ? `FAILED (${bad})` : "all rigs clean");
