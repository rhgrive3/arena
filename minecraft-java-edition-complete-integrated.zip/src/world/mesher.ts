import { BLOCKS, ID } from '../game/data';
import { isSlabBlock, localFaceForState, type Face } from '../game/blockState';
import { modelBoxes, TORCH16, LEVER_BASE16, LEVER_STICK16, BUTTON16 } from './shapes';
import { MIN_Y, HEIGHT } from './terrain';

export interface MeshData {
  position: Float32Array;
  normal: Float32Array;
  uv: Float32Array;
  color: Float32Array;
  tile: Float32Array;
  wind: Float32Array;
  light: Float32Array;
  index: Uint32Array;
}

const AO_LUT = new Float32Array([1.0, 0.81, 0.65, 0.50]);
const SEAM = 0.002;
const STRIDE_Y = 324; // 18 * 18

// Precomputed O(1) lookup tables by block ID (lazily synced)
const MAX_IDS = 1024;
const LUT_FULL = new Uint8Array(MAX_IDS);
const LUT_OPAQUE = new Uint8Array(MAX_IDS);
const LUT_SLAB = new Uint8Array(MAX_IDS);
const LUT_LIGHT = new Uint8Array(MAX_IDS);
const LUT_TRANSPARENT = new Uint8Array(MAX_IDS);
const LUT_TINT_TOP = new Uint8Array(MAX_IDS);
const LUT_TINT_ALL = new Uint8Array(MAX_IDS);
const LUT_WIND = new Uint8Array(MAX_IDS);
let lutBuiltCount = -1;

function ensureLuts() {
  if (lutBuiltCount === BLOCKS.length) return;
  lutBuiltCount = BLOCKS.length;
  for (let i = 0; i < BLOCKS.length && i < MAX_IDS; i++) {
    const def = BLOCKS[i];
    if (!def) continue;
    const slab = isSlabBlock(def);
    const customSub = def.name === 'hopper' || def.name === 'composter' || def.name === 'cauldron' || def.name === 'repeater' || def.name === 'comparator' || def.name === 'decorated_pot' || def.name === 'frosted_ice' || def.name === 'suspicious_sand' || def.name === 'suspicious_gravel';
    LUT_SLAB[i] = slab ? 1 : 0;
    LUT_FULL[i] = def.shape === 'cube' && !customSub ? 1 : 0;
    LUT_TRANSPARENT[i] = def.transparent || customSub ? 1 : 0;
    LUT_OPAQUE[i] = i > 0 && !def.transparent && !customSub ? 1 : 0;
    LUT_LIGHT[i] = def.light ? Math.min(15, def.light) : 0;
    LUT_TINT_TOP[i] = def.name === 'grass_block' ? 1 : 0;
    LUT_TINT_ALL[i] = (def.name === 'oak_leaves' || def.name === 'jungle_leaves' || def.name === 'acacia_leaves' || def.name === 'dark_oak_leaves' || def.name === 'mangrove_leaves') ? 1 : 0;
    LUT_WIND[i] = def.pattern === 'leaves' ? 1 : 0;
  }
}

// Module-level reusable buffers (zero GC per chunk inside Worker)
const lightSky = new Uint8Array(18 * 18 * HEIGHT);
const lightBlk = new Uint8Array(18 * 18 * HEIGHT);
const bfsQueue = new Int32Array(18 * 18 * HEIGHT * 2);

class MeshBuf {
  p: Float32Array;
  n: Float32Array;
  uv: Float32Array;
  c: Float32Array;
  t: Float32Array;
  w: Float32Array;
  l: Float32Array;
  i: Uint32Array;
  vCount = 0;
  iCount = 0;
  capV: number;
  capI: number;

  reset() {
    this.vCount = 0;
    this.iCount = 0;
  }

  constructor(capV = 16384, capI = 24576) {
    this.capV = capV;
    this.capI = capI;
    this.p = new Float32Array(capV * 3);
    this.n = new Float32Array(capV * 3);
    this.uv = new Float32Array(capV * 2);
    this.c = new Float32Array(capV * 3);
    this.t = new Float32Array(capV);
    this.w = new Float32Array(capV);
    this.l = new Float32Array(capV * 2);
    this.i = new Uint32Array(capI);
  }

  private ensureV(add: number) {
    if (this.vCount + add <= this.capV) return;
    const next = Math.max(this.capV * 2, this.vCount + add);
    const grow = (src: Float32Array, mult: number) => {
      const dst = new Float32Array(next * mult);
      dst.set(src);
      return dst;
    };
    this.p = grow(this.p, 3);
    this.n = grow(this.n, 3);
    this.uv = grow(this.uv, 2);
    this.c = grow(this.c, 3);
    this.t = grow(this.t, 1);
    this.w = grow(this.w, 1);
    this.l = grow(this.l, 2);
    this.capV = next;
  }

  private ensureI(add: number) {
    if (this.iCount + add <= this.capI) return;
    const next = Math.max(this.capI * 2, this.iCount + add);
    const dst = new Uint32Array(next);
    dst.set(this.i);
    this.i = dst;
    this.capI = next;
  }

  pushQuad(
    x0: number, y0: number, z0: number,
    x1: number, y1: number, z1: number,
    x2: number, y2: number, z2: number,
    x3: number, y3: number, z3: number,
    nx: number, ny: number, nz: number,
    u: number, v: number, tile: number,
    ao0: number, ao1: number, ao2: number, ao3: number,
    sky0: number, sky1: number, sky2: number, sky3: number,
    blk0: number, blk1: number, blk2: number, blk3: number,
    wind: number, flip: boolean,
    r: number, g: number, b: number,
    rot90: boolean, rev: boolean,
  ) {
    this.ensureV(4);
    this.ensureI(6);
    const start = this.vCount;
    const pOff = start * 3, uvOff = start * 2, lOff = start * 2;

    this.p[pOff] = x0; this.p[pOff + 1] = y0; this.p[pOff + 2] = z0;
    this.p[pOff + 3] = x1; this.p[pOff + 4] = y1; this.p[pOff + 5] = z1;
    this.p[pOff + 6] = x2; this.p[pOff + 7] = y2; this.p[pOff + 8] = z2;
    this.p[pOff + 9] = x3; this.p[pOff + 10] = y3; this.p[pOff + 11] = z3;

    this.n[pOff] = nx; this.n[pOff + 1] = ny; this.n[pOff + 2] = nz;
    this.n[pOff + 3] = nx; this.n[pOff + 4] = ny; this.n[pOff + 5] = nz;
    this.n[pOff + 6] = nx; this.n[pOff + 7] = ny; this.n[pOff + 8] = nz;
    this.n[pOff + 9] = nx; this.n[pOff + 10] = ny; this.n[pOff + 11] = nz;

    this.t[start] = tile; this.t[start + 1] = tile; this.t[start + 2] = tile; this.t[start + 3] = tile;
    this.w[start] = wind; this.w[start + 1] = wind; this.w[start + 2] = wind; this.w[start + 3] = wind;

    if (rot90) {
      if (rev) {
        this.uv[uvOff] = v; this.uv[uvOff + 1] = 0;
        this.uv[uvOff + 2] = v; this.uv[uvOff + 3] = u;
        this.uv[uvOff + 4] = 0; this.uv[uvOff + 5] = u;
        this.uv[uvOff + 6] = 0; this.uv[uvOff + 7] = 0;
      } else {
        // +X faces: mirror U so textures read left-to-right when seen from outside.
        this.uv[uvOff] = v; this.uv[uvOff + 1] = 0;
        this.uv[uvOff + 2] = v; this.uv[uvOff + 3] = u;
        this.uv[uvOff + 4] = 0; this.uv[uvOff + 5] = u;
        this.uv[uvOff + 6] = 0; this.uv[uvOff + 7] = 0;
      }
    } else if (rev) {
      // -Z (and bottom) faces arrive in reversed vertex order: keep V pointing up so side textures are not upside down.
      this.uv[uvOff] = u; this.uv[uvOff + 1] = v;
      this.uv[uvOff + 2] = 0; this.uv[uvOff + 3] = v;
      this.uv[uvOff + 4] = 0; this.uv[uvOff + 5] = 0;
      this.uv[uvOff + 6] = u; this.uv[uvOff + 7] = 0;
    } else {
      this.uv[uvOff] = 0; this.uv[uvOff + 1] = 0;
      this.uv[uvOff + 2] = u; this.uv[uvOff + 3] = 0;
      this.uv[uvOff + 4] = u; this.uv[uvOff + 5] = v;
      this.uv[uvOff + 6] = 0; this.uv[uvOff + 7] = v;
    }

    const l0 = AO_LUT[ao0], l1 = AO_LUT[ao1], l2 = AO_LUT[ao2], l3 = AO_LUT[ao3];
    this.c[pOff] = l0 * r; this.c[pOff + 1] = l0 * g; this.c[pOff + 2] = l0 * b;
    this.c[pOff + 3] = l1 * r; this.c[pOff + 4] = l1 * g; this.c[pOff + 5] = l1 * b;
    this.c[pOff + 6] = l2 * r; this.c[pOff + 7] = l2 * g; this.c[pOff + 8] = l2 * b;
    this.c[pOff + 9] = l3 * r; this.c[pOff + 10] = l3 * g; this.c[pOff + 11] = l3 * b;

    this.l[lOff] = sky0; this.l[lOff + 1] = blk0;
    this.l[lOff + 2] = sky1; this.l[lOff + 3] = blk1;
    this.l[lOff + 4] = sky2; this.l[lOff + 5] = blk2;
    this.l[lOff + 6] = sky3; this.l[lOff + 7] = blk3;

    const ii = this.iCount;
    if (flip) {
      this.i[ii] = start; this.i[ii + 1] = start + 1; this.i[ii + 2] = start + 3;
      this.i[ii + 3] = start + 1; this.i[ii + 4] = start + 2; this.i[ii + 3 + 2] = start + 3;
    } else {
      this.i[ii] = start; this.i[ii + 1] = start + 1; this.i[ii + 2] = start + 2;
      this.i[ii + 3] = start; this.i[ii + 4] = start + 2; this.i[ii + 5] = start + 3;
    }

    this.vCount += 4;
    this.iCount += 6;
  }

  /** Overrides the UVs of the quad pushed last (vertex 0 → (ua, va), 1 → (ub, va), 2 → (ub, vb), 3 → (ua, vb)) so a box face shows exactly its own part of the tile. */
  uvRect(ua: number, va: number, ub: number, vb: number) {
    // Inset towards the middle of the range (ranges may be reversed to flip the image) so sampling never wraps into a neighbouring texel.
    const o = (this.vCount - 4) * 2, eu = ub >= ua ? 0.002 : -0.002, ev = vb >= va ? 0.002 : -0.002;
    const a = ua + eu, b = ub - eu, c = va + ev, d = vb - ev;
    this.uv[o] = a; this.uv[o + 1] = c;
    this.uv[o + 2] = b; this.uv[o + 3] = c;
    this.uv[o + 4] = b; this.uv[o + 5] = d;
    this.uv[o + 6] = a; this.uv[o + 7] = d;
  }

  pack(): MeshData {
    return {
      position: this.p.subarray(0, this.vCount * 3).slice(),
      normal: this.n.subarray(0, this.vCount * 3).slice(),
      uv: this.uv.subarray(0, this.vCount * 2).slice(),
      color: this.c.subarray(0, this.vCount * 3).slice(),
      tile: this.t.subarray(0, this.vCount).slice(),
      wind: this.w.subarray(0, this.vCount).slice(),
      light: this.l.subarray(0, this.vCount * 2).slice(),
      index: this.i.subarray(0, this.iCount).slice(),
    };
  }
}

function computeLights(padded: Uint16Array, maxY: number) {
  const minY = MIN_Y | 0;
  const maxH = HEIGHT | 0;
  const maxLocalY = Math.min(maxH - 1, (maxY | 0) - minY + 2);
  const clearTop = Math.min(lightSky.length, (maxLocalY + 3) * STRIDE_Y);
  const waterId = ID.water | 0;
  lightSky.fill(15, (maxLocalY + 1) * STRIDE_Y, clearTop);
  lightBlk.fill(0, 0, clearTop);

  let blkHead = 0, blkTail = 0;
  const totalCap = bfsQueue.length;
  const skyStart = totalCap >> 1;
  let skyHead = skyStart, skyTail = skyStart;

  for (let z = 0; z < 18; z++) {
    for (let x = 0; x < 18; x++) {
      let sky = 15;
      const colBase = z * 18 + x;
      for (let ly = maxLocalY; ly >= 0; ly--) {
        const idx = ly * STRIDE_Y + colBase;
        const cell = padded[idx];
        if (cell !== 0) {
          const id = cell & 4095;
          const em = LUT_LIGHT[id];
          if (em !== 0) {
            lightBlk[idx] = em;
            if (blkTail < skyStart) bfsQueue[blkTail++] = x | (z << 5) | (ly << 10);
          }
          if (LUT_OPAQUE[id] === 1 && (LUT_FULL[id] === 1 || (LUT_SLAB[id] === 1 && ((cell >>> 12) & 15) === 2))) {
            sky = 0;
          } else if (id === waterId || LUT_WIND[id] === 1) {
            sky = sky > 2 ? sky - 2 : 0;
          }
        }
        lightSky[idx] = sky;
      }
    }
  }

  for (let ly = maxLocalY; ly >= 0; ly--) {
    const yOff = ly * STRIDE_Y;
    for (let z = 1; z < 17; z++) {
      const zOff = yOff + z * 18;
      for (let x = 1; x < 17; x++) {
        const idx = zOff + x;
        const s = lightSky[idx];
        if (s > 1) {
          if (lightSky[idx - 1] + 1 < s || lightSky[idx + 1] + 1 < s || lightSky[idx - 18] + 1 < s || lightSky[idx + 18] + 1 < s) {
            if (skyTail < totalCap) bfsQueue[skyTail++] = x | (z << 5) | (ly << 10);
          }
        }
      }
    }
  }

  while (skyHead < skyTail) {
    const packed = bfsQueue[skyHead++];
    const x = packed & 31, z = (packed >> 5) & 31, ly = packed >> 10;
    const idx = ly * STRIDE_Y + z * 18 + x;
    const cur = lightSky[idx];
    if (cur <= 1) continue;

    // 6-neighbor unrolled propagation
    if (x > 0) {
      const ni = idx - 1, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - (cid === waterId || LUT_WIND[cid] === 1 ? 2 : 1);
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = (x - 1) | (z << 5) | (ly << 10); }
      }
    }
    if (x < 17) {
      const ni = idx + 1, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - (cid === waterId || LUT_WIND[cid] === 1 ? 2 : 1);
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = (x + 1) | (z << 5) | (ly << 10); }
      }
    }
    if (z > 0) {
      const ni = idx - 18, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - (cid === waterId || LUT_WIND[cid] === 1 ? 2 : 1);
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = x | ((z - 1) << 5) | (ly << 10); }
      }
    }
    if (z < 17) {
      const ni = idx + 18, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - (cid === waterId || LUT_WIND[cid] === 1 ? 2 : 1);
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = x | ((z + 1) << 5) | (ly << 10); }
      }
    }
    if (ly > 0) {
      const ni = idx - STRIDE_Y, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - (cid === waterId || LUT_WIND[cid] === 1 ? 2 : 1);
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = x | (z << 5) | ((ly - 1) << 10); }
      }
    }
    if (ly < maxLocalY) {
      const ni = idx + STRIDE_Y, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0) {
        const next = cur - (cid === waterId || LUT_WIND[cid] === 1 ? 2 : 1);
        if (next > lightSky[ni]) { lightSky[ni] = next; if (next > 1 && skyTail < totalCap) bfsQueue[skyTail++] = x | (z << 5) | ((ly + 1) << 10); }
      }
    }
  }

  while (blkHead < blkTail) {
    const packed = bfsQueue[blkHead++];
    const x = packed & 31, z = (packed >> 5) & 31, ly = packed >> 10;
    const idx = ly * STRIDE_Y + z * 18 + x;
    const next = lightBlk[idx] - 1;
    if (next <= 0) continue;

    if (x > 0) {
      const ni = idx - 1, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = (x - 1) | (z << 5) | (ly << 10); }
    }
    if (x < 17) {
      const ni = idx + 1, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = (x + 1) | (z << 5) | (ly << 10); }
    }
    if (z > 0) {
      const ni = idx - 18, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = x | ((z - 1) << 5) | (ly << 10); }
    }
    if (z < 17) {
      const ni = idx + 18, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = x | ((z + 1) << 5) | (ly << 10); }
    }
    if (ly > 0) {
      const ni = idx - STRIDE_Y, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = x | (z << 5) | ((ly - 1) << 10); }
    }
    if (ly < maxLocalY) {
      const ni = idx + STRIDE_Y, cid = padded[ni] & 4095;
      if (LUT_OPAQUE[cid] === 0 && next > lightBlk[ni]) { lightBlk[ni] = next; if (next > 1 && blkTail < skyStart) bfsQueue[blkTail++] = x | (z << 5) | ((ly + 1) << 10); }
    }
  }
}

const isFull = (cell: number) => {
  const id = cell & 4095;
  return LUT_FULL[id] === 1 || (LUT_SLAB[id] === 1 && ((cell >>> 12) & 15) === 2);
};
const isOpq = (cell: number) => LUT_OPAQUE[cell & 4095] === 1 && isFull(cell);

function getCellAt(padded: Uint16Array, dimsY: number, x: number, ly: number, z: number) {
  if (ly < 0 || ly >= dimsY) return 0;
  return padded[ly * STRIDE_Y + (z + 1) * 18 + (x + 1)];
}

function lightIdx(x: number, ly: number, z: number) {
  const cy = ly < 0 ? 0 : ly >= HEIGHT ? HEIGHT - 1 : ly;
  return cy * STRIDE_Y + (z + 1) * 18 + (x + 1);
}

function aoFor(s1: number, s2: number, c: number) {
  const a = isOpq(s1), b = isOpq(s2);
  return a && b ? 3 : (a ? 1 : 0) + (b ? 1 : 0) + (isOpq(c) ? 1 : 0);
}

// Reusable mask buffers for Greedy Meshing
const maskBuf = new Int32Array(HEIGHT * 16);
const waterMaskBuf = new Int32Array(HEIGHT * 16);
const reusableOut = new MeshBuf(16384, 24576);
const reusableWater = new MeshBuf(4096, 6144);

function cornerDepthAt(padded: Uint16Array, dimsY: number, waterId: number, lavaId: number, vx: number, vy: number, vz: number) {
  let sum = 0;
  for (let dz = -1; dz <= 0; dz++) {
    const z = vz + dz;
    for (let dx = -1; dx <= 0; dx++) {
      const x = vx + dx;
      let d = 0;
      for (let k = 1; k <= 6; k++) {
        const c = getCellAt(padded, dimsY, x, vy - k, z) & 4095;
        if (c === waterId || c === lavaId) d++;
        else break;
      }
      sum += d;
    }
  }
  const avg = sum * 0.25;
  return avg > 6 ? 1 : avg / 6;
}

function shoreAt(padded: Uint16Array, dimsY: number, waterId: number, lavaId: number, vx: number, vy: number, vz: number) {
  for (let dz = -1; dz <= 0; dz++) {
    for (let dx = -1; dx <= 0; dx++) {
      const c = getCellAt(padded, dimsY, vx + dx, vy - 1, vz + dz) & 4095;
      if (c !== 0 && c !== waterId && c !== lavaId) return 1;
    }
  }
  return 0;
}

function meshGreedy(padded: Uint16Array, dimsY: number, tiles: number[][], tint: Float32Array | undefined, out: MeshBuf, water: MeshBuf) {
  const minY = MIN_Y | 0;
  const waterId = ID.water | 0;
  const lavaId = ID.lava | 0;
  const endGatewayId = ID.end_gateway | 0;
  const blocks = BLOCKS;

  for (let d = 0; d < 3; d++) {
    const u = (d + 1) % 3, v = (d + 2) % 3;
    const dLen = d === 1 ? dimsY : 16;
    const duLen = u === 1 ? dimsY : 16;
    const dvLen = v === 1 ? dimsY : 16;
    const mask = maskBuf;
    const waterMask = waterMaskBuf;

    for (let slice = -1; slice < dLen; slice++) {
      if (d === 1 && (slice < 0 || slice >= dimsY - 1)) continue;

      let n = 0;
      let hasAnyFace = false;

      for (let j = 0; j < dvLen; j++) {
        for (let i = 0; i < duLen; i++, n++) {
          const ax = d === 0 ? slice : u === 0 ? i : j;
          const ay = d === 1 ? slice : u === 1 ? i : j;
          const az = d === 2 ? slice : u === 2 ? i : j;

          const bx = d === 0 ? slice + 1 : ax;
          const by = d === 1 ? slice + 1 : ay;
          const bz = d === 2 ? slice + 1 : az;

          const a = getCellAt(padded, dimsY, ax, ay, az);
          const b = getCellAt(padded, dimsY, bx, by, bz);

          const aId = a & 4095, bId = b & 4095;
          const aFull = isFull(a) && aId !== endGatewayId;
          const bFull = isFull(b) && bId !== endGatewayId;
          const aWater = aId === waterId || aId === lavaId;
          const bWater = bId === waterId || bId === lavaId;

          let mVal = 0;
          if (aFull !== bFull) {
            if (aFull && slice >= 0) mVal = a;
            else if (bFull && slice < dLen - 1) mVal = -b;
          } else if (aFull && bFull) {
            const aTr = LUT_TRANSPARENT[aId] === 1;
            const bTr = LUT_TRANSPARENT[bId] === 1;
            if (aTr !== bTr) {
              if (!aTr && slice >= 0) mVal = a;
              else if (!bTr && slice < dLen - 1) mVal = -b;
            } else if (aTr && aId !== bId && slice >= 0) {
              mVal = a;
            }
          }
          mask[n] = mVal;

          let wVal = 0;
          // Render top surface and underwater side boundaries against glass/transparent blocks
          if (aWater !== bWater) {
            if (d === 1) {
              if (aWater && !bFull && slice >= 0) {
                const top = getCellAt(padded, dimsY, ax, ay + 1, az) & 4095;
                wVal = a | (top === 0 ? 0x400 : 0);
              } else if (bWater && !aFull && slice < dLen - 1) {
                wVal = -b;
              }
            } else {
              if (aWater && !bFull && slice >= 0) wVal = a;
              else if (bWater && !aFull && slice < dLen - 1) wVal = -b;
            }
          }
          waterMask[n] = wVal;

          if (mVal !== 0 || wVal !== 0) hasAnyFace = true;
        }
      }

      if (!hasAnyFace) continue;

      n = 0;
      for (let j = 0; j < dvLen; j++) {
        for (let i = 0; i < duLen; ) {
          const m = mask[n], wm = waterMask[n];
          const val = m !== 0 ? m : wm;
          if (!val) { i++; n++; continue; }

          const isWaterQuad = m === 0;
          const sign = val > 0 ? 1 : -1;
          const cell = Math.abs(val) & ~0x400;
          const id = cell & 4095, state = (cell >>> 12) & 15;
          const sliceCoord = sign > 0 ? slice : slice + 1;

          const computeKey = (ii: number, jj: number) => {
            const x = d === 0 ? sliceCoord : u === 0 ? ii : jj;
            const y = d === 1 ? sliceCoord : u === 1 ? ii : jj;
            const z = d === 2 ? sliceCoord : u === 2 ? ii : jj;

            const airD = slice + (sign > 0 ? 1 : 0);
            const lx = d === 0 ? airD : u === 0 ? ii : jj;
            const ly = d === 1 ? airD : u === 1 ? ii : jj;
            const lz = d === 2 ? airD : u === 2 ? ii : jj;
            const lIdx = lightIdx(lx, ly, lz);
            const lk = isWaterQuad ? (wm > 0 && (wm & 0x400) !== 0 ? 1 : 0) : (lightSky[lIdx] << 4) | lightBlk[lIdx];

            if (isWaterQuad) return { ao0: 0, ao1: 0, ao2: 0, ao3: 0, key: lk };

            const fnx = d === 0 ? sign : 0, fny = d === 1 ? sign : 0, fnz = d === 2 ? sign : 0;
            const ux = u === 0 ? 1 : 0, uy = u === 1 ? 1 : 0, uz = u === 2 ? 1 : 0;
            const vx = v === 0 ? 1 : 0, vy = v === 1 ? 1 : 0, vz = v === 2 ? 1 : 0;
            const fx = x + fnx, fy = y + fny, fz = z + fnz;

            const s_u0 = getCellAt(padded, dimsY, fx - ux, fy - uy, fz - uz);
            const s_u1 = getCellAt(padded, dimsY, fx + ux, fy + uy, fz + uz);
            const s_v0 = getCellAt(padded, dimsY, fx - vx, fy - vy, fz - vz);
            const s_v1 = getCellAt(padded, dimsY, fx + vx, fy + vy, fz + vz);

            const ao0 = aoFor(s_u0, s_v0, getCellAt(padded, dimsY, fx - ux - vx, fy - uy - vy, fz - uz - vz));
            const ao1 = aoFor(s_u1, s_v0, getCellAt(padded, dimsY, fx + ux - vx, fy + uy - vy, fz + uz - vz));
            const ao2 = aoFor(s_u1, s_v1, getCellAt(padded, dimsY, fx + ux + vx, fy + uy + vy, fz + uz + vz));
            const ao3 = aoFor(s_u0, s_v1, getCellAt(padded, dimsY, fx - ux + vx, fy - uy + vy, fz - uz + vz));

            return { ao0, ao1, ao2, ao3, key: (ao0 | (ao1 << 2) | (ao2 << 4) | (ao3 << 6)) | (lk << 8) };
          };

          const { ao0, ao1, ao2, ao3, key: aoKey } = computeKey(i, j);
          const activeMask = isWaterQuad ? waterMask : mask;
          const noMerge = (!isWaterQuad && (LUT_TINT_TOP[id] === 1 || LUT_TINT_ALL[id] === 1)) || (isWaterQuad && (state & 7) !== 0);
          let w = 1, h = 1;
          if (!noMerge) {
            while (i + w < duLen && activeMask[n + w] === val && computeKey(i + w, j).key === aoKey) w++;
            outer: for (; j + h < dvLen; h++) {
              for (let k = 0; k < w; k++) {
                if (activeMask[n + k + h * duLen] !== val || computeKey(i + k, j + h).key !== aoKey) break outer;
              }
            }
          }

          const fld = isWaterQuad ? state & 7 : 0;
          const p0 = d === 0 ? slice + 1 : u === 0 ? i : j;
          const p1 = d === 1 ? slice + 1 : u === 1 ? i : j;
          const p2 = d === 2 ? slice + 1 : u === 2 ? i : j;

          const u0 = u === 0 ? w : 0, u1 = u === 1 ? w : 0, u2 = u === 2 ? w : 0;
          const v0 = v === 0 ? h : 0, v1 = v === 1 ? h : 0, v2 = v === 2 ? h : 0;

          const lift = isWaterQuad && d === 1 && sign > 0 && !fld ? -0.1 : 0;
          const bp0 = p0, bp1 = p1 + lift, bp2 = p2;

          const sdu = isWaterQuad ? 0 : SEAM, sdv = isWaterQuad ? 0 : SEAM;
          const su0 = u === 0 ? sdu : 0, su1 = u === 1 ? sdu : 0, su2 = u === 2 ? sdu : 0;
          const sv0 = v === 0 ? sdv : 0, sv1 = v === 1 ? sdv : 0, sv2 = v === 2 ? sdv : 0;

          const vx0 = bp0 - su0 - sv0, vx1 = bp0 + u0 + su0 - sv0, vx2 = bp0 + u0 + su0 + v0 + sv0, vx3 = bp0 - su0 + v0 + sv0;
          let vy0 = bp1 + minY - su1 - sv1, vy1 = bp1 + u1 + minY + su1 - sv1, vy2 = bp1 + u1 + v1 + minY + su1 + sv1, vy3 = bp1 + v1 + minY - su1 + sv1;
          const vz0 = bp2 - su2 - sv2, vz1 = bp2 + u2 + su2 - sv2, vz2 = bp2 + u2 + su2 + v2 + sv2, vz3 = bp2 - su2 + v2 + sv2;

          if (isWaterQuad && d === 1 && sign > 0) {
            // Flowing fluid sits lower the further it is from its source (vanilla: height = (8 - distance) / 9).
            const dr = fld ? fld / 9 : 0.12;
            vy0 -= dr; vy1 -= dr; vy2 -= dr; vy3 -= dr;
          } else if (isWaterQuad && fld && d !== 1) {
            const dr = fld / 9, top = Math.max(vy0, vy1, vy2, vy3);
            if (vy0 === top) vy0 -= dr;
            if (vy1 === top) vy1 -= dr;
            if (vy2 === top) vy2 -= dr;
            if (vy3 === top) vy3 -= dr;
          }

          let s0 = 0, s1 = 0, s2 = 0, s3 = 0, b0 = 1, b1 = 1, b2 = 1, b3 = 1;
          if (isWaterQuad) {
            if (wm > 0 && (wm & 0x400) !== 0) {
              s0 = shoreAt(padded, dimsY, waterId, lavaId, vx0, slice, vz0);
              s1 = shoreAt(padded, dimsY, waterId, lavaId, vx1, slice, vz1);
              s2 = shoreAt(padded, dimsY, waterId, lavaId, vx2, slice, vz2);
              s3 = shoreAt(padded, dimsY, waterId, lavaId, vx3, slice, vz3);
              b0 = cornerDepthAt(padded, dimsY, waterId, lavaId, vx0, slice, vz0);
              b1 = cornerDepthAt(padded, dimsY, waterId, lavaId, vx1, slice, vz1);
              b2 = cornerDepthAt(padded, dimsY, waterId, lavaId, vx2, slice, vz2);
              b3 = cornerDepthAt(padded, dimsY, waterId, lavaId, vx3, slice, vz3);
            }
          } else {
            const airD = slice + (sign > 0 ? 1 : 0);
            const li0 = lightIdx(d === 0 ? airD : u === 0 ? i : j, d === 1 ? airD : u === 1 ? i : j, d === 2 ? airD : u === 2 ? i : j);
            const li1 = lightIdx(d === 0 ? airD : u === 0 ? i + w - 1 : j, d === 1 ? airD : u === 1 ? i + w - 1 : j, d === 2 ? airD : u === 2 ? i + w - 1 : j);
            const li2 = lightIdx(d === 0 ? airD : u === 0 ? i + w - 1 : j + h - 1, d === 1 ? airD : u === 1 ? i + w - 1 : j + h - 1, d === 2 ? airD : u === 2 ? i + w - 1 : j + h - 1);
            const li3 = lightIdx(d === 0 ? airD : u === 0 ? i : j + h - 1, d === 1 ? airD : u === 1 ? i : j + h - 1, d === 2 ? airD : u === 2 ? i : j + h - 1);
            s0 = lightSky[li0] / 15; b0 = lightBlk[li0] / 15;
            s1 = lightSky[li1] / 15; b1 = lightBlk[li1] / 15;
            s2 = lightSky[li2] / 15; b2 = lightBlk[li2] / 15;
            s3 = lightSky[li3] / 15; b3 = lightBlk[li3] / 15;
          }

          const def = blocks[id];
          const tinted = !isWaterQuad && ((LUT_TINT_TOP[id] === 1 && d === 1 && sign > 0) || LUT_TINT_ALL[id] === 1);
          let r = 1, g = 1, b = 1;
          if (tinted) {
            if (tint) {
              const cx = vx0 < 0 ? 0 : vx0 > 15 ? 15 : vx0 | 0;
              const cz = vz0 < 0 ? 0 : vz0 > 15 ? 15 : vz0 | 0;
              const ti = (cz * 16 + cx) * 3;
              r = tint[ti]; g = tint[ti + 1]; b = tint[ti + 2];
            } else {
              r = 0.88; g = 1.25; b = 0.60;
            }
          }

          const worldFace = (d * 2 + (sign > 0 ? 0 : 1)) as Face;
          const tile = isWaterQuad ? (id === lavaId ? 1 : 0) : tiles[id][localFaceForState(def, state, worldFace)];
          const nx = d === 0 ? sign : 0, ny = d === 1 ? sign : 0, nz = d === 2 ? sign : 0;
          const wind = LUT_WIND[id] === 1 ? 0.13 : 0;
          const targetBuf = isWaterQuad ? water : out;

          if (sign < 0) {
            targetBuf.pushQuad(
              vx3, vy3, vz3, vx2, vy2, vz2, vx1, vy1, vz1, vx0, vy0, vz0,
              nx, ny, nz, w, h, tile,
              ao3, ao2, ao1, ao0,
              s3, s2, s1, s0,
              b3, b2, b1, b0,
              wind, ao3 + ao1 > ao2 + ao0, r, g, b, d === 0, true,
            );
          } else {
            targetBuf.pushQuad(
              vx0, vy0, vz0, vx1, vy1, vz1, vx2, vy2, vz2, vx3, vy3, vz3,
              nx, ny, nz, w, h, tile,
              ao0, ao1, ao2, ao3,
              s0, s1, s2, s3,
              b0, b1, b2, b3,
              wind, ao0 + ao2 > ao1 + ao3, r, g, b, d === 0, false,
            );
          }

          for (let dy = 0; dy < h; dy++) {
            const row = (j + dy) * duLen + i;
            for (let dx = 0; dx < w; dx++) {
              mask[row + dx] = 0;
              waterMask[row + dx] = 0;
            }
          }
          i += w;
        }
      }
    }
  }
}

const CN = new Float64Array(24);
const FQ = [4, 5, 7, 6, 1, 0, 2, 3, 6, 7, 3, 2, 0, 1, 5, 4, 5, 1, 3, 7, 0, 4, 6, 2];
const FNRM = [0, 0, 1, 0, 0, -1, 0, 1, 0, 0, -1, 0, 1, 0, 0, -1, 0, 0];
const STICK_UP = [7, 0, 7, 9, 10, 9], STICK_DOWN = [7, 10, 7, 9, 0, 9], DT = [0, 0, 0, 0, 16, 0];

const emitBox = (bx: number, by: number, bz: number, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, tile: number, sky: number, blk: number, tex?: readonly number[], mirror = false, end = -1, sdx = 0, sdz = 0) => {
  for (let i = 0; i < 8; i++) {
    const top = (i >> 1) & 1, sh = end === top;
    CN[i * 3] = bx + ((i & 1 ? x1 : x0) + (sh ? sdx : 0)) / 16;
    CN[i * 3 + 1] = by + (top ? y1 : y0) / 16;
    CN[i * 3 + 2] = bz + ((i & 4 ? z1 : z0) + (sh ? sdz : 0)) / 16;
  }
  const ux0 = (tex ? tex[0] : x0) / 16, v0 = (tex ? tex[1] : y0) / 16, uz0 = (tex ? tex[2] : z0) / 16;
  const ux1 = (tex ? tex[3] : x1) / 16, v1 = (tex ? tex[4] : y1) / 16, uz1 = (tex ? tex[5] : z1) / 16;
  for (let f = 0; f < 6; f++) {
    const a = FQ[f * 4] * 3, b = FQ[f * 4] !== undefined ? FQ[f * 4 + 1] * 3 : 0, c = FQ[f * 4 + 2] * 3, d = FQ[f * 4 + 3] * 3;
    reusableOut.pushQuad(CN[a], CN[a + 1], CN[a + 2], CN[b], CN[b + 1], CN[b + 2], CN[c], CN[c + 1], CN[c + 2], CN[d], CN[d + 1], CN[d + 2], FNRM[f * 3], FNRM[f * 3 + 1], FNRM[f * 3 + 2], 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
    if (f === 0) reusableOut.uvRect(ux0, v0, ux1, v1);
    else if (f === 1) { if (mirror) reusableOut.uvRect(ux1, v0, ux0, v1); else reusableOut.uvRect(1 - ux1, v0, 1 - ux0, v1); }
    else if (f === 2) reusableOut.uvRect(ux0, 1 - uz1, ux1, 1 - uz0);
    else if (f === 3) reusableOut.uvRect(ux0, uz0, ux1, uz1);
    else if (f === 4) { if (mirror) reusableOut.uvRect(uz1, v0, uz0, v1); else reusableOut.uvRect(1 - uz1, v0, 1 - uz0, v1); }
    else reusableOut.uvRect(uz0, v0, uz1, v1);
  }
};

function meshSubBlocks(padded: Uint16Array, dimsY: number, tiles: number[][], tint: Float32Array | undefined, out: MeshBuf) {
  const minY = MIN_Y | 0;
  const blocks = BLOCKS;
  const endGatewayId = ID.end_gateway | 0;

  for (let ly = 0; ly < dimsY; ly++) {
    const y = ly + minY;
    const yOff = ly * STRIDE_Y;
    for (let z = 0; z < 16; z++) {
      const zOff = yOff + (z + 1) * 18 + 1;
      for (let x = 0; x < 16; x++) {
        const cell = padded[zOff + x];
        if (cell === 0) continue;
        const id = cell & 4095, b = blocks[id];
        if (!b || (isFull(cell) && id !== endGatewayId) || b.shape === 'water') continue;
        const state = (cell >>> 12) & 15;
        const lIdx = zOff + x;
        const sky = lightSky[lIdx] / 15;
        const blk = LUT_LIGHT[id] !== 0 ? 1 : lightBlk[lIdx] / 15;

        let r = 1, g = 1, bl = 1;
        if (tint && (b.name === 'short_grass' || b.name === 'fern' || b.name === 'tall_grass' || b.name === 'large_fern' || b.name === 'jungle_fern' || b.name === 'lily_pad' || b.name === 'sugar_cane' || b.name === 'vine')) {
          const ti = (z * 16 + x) * 3;
          r = tint[ti]; g = tint[ti + 1]; bl = tint[ti + 2];
        }

        if (b.shape === 'cross') {
          const tile = tiles[id][0];
          const crop = b.name === 'wheat_crop' || b.name === 'carrots' || b.name === 'potatoes' || b.name === 'beetroots' || b.name === 'nether_wart' || b.name === 'melon_stem' || b.name === 'pumpkin_stem';
          const maxSt = b.name === 'beetroots' || b.name === 'nether_wart' ? 3 : 7;
          const progress = crop ? Math.min(1, (state & 7) / maxSt) : 1;
          if (crop && progress < 1 && b.name !== 'nether_wart') { r = 0.55 + progress * 0.35; g = 1; bl = 0.65; }
          const grow = crop ? 0.2 + 0.8 * progress : 1;
          const xA = x + 0.24, xB = x + 0.76, zA = z + 0.24, zB = z + 0.76, yT = y + 0.78 * grow;
          out.pushQuad(xA, y, zA, xB, y, zB, xB, yT, zB, xA, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
          out.pushQuad(xA, yT, zA, xB, yT, zB, xB, y, zB, xA, y, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
          out.pushQuad(xB, y, zA, xA, y, zB, xA, yT, zB, xB, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
          out.pushQuad(xB, yT, zA, xA, yT, zB, xA, y, zB, xB, y, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
        } else if (b.shape === 'lily') {
          const tile = tiles[id][0];
          out.pushQuad(x + 0.06, y + 0.03, z + 0.94, x + 0.94, y + 0.03, z + 0.94, x + 0.94, y + 0.03, z + 0.06, x + 0.06, y + 0.03, z + 0.06, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
          out.pushQuad(x + 0.06, y + 0.03, z + 0.06, x + 0.94, y + 0.03, z + 0.06, x + 0.94, y + 0.03, z + 0.94, x + 0.06, y + 0.03, z + 0.94, 0, -1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
        } else if (b.shape === 'cactus') {
          const ts = tiles[id][0], e = 0.0625;
          const below = ly > 0 ? padded[lIdx - STRIDE_Y] & 4095 : 0, above = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
          out.pushQuad(x, y, z + 1 - e, x + 1, y, z + 1 - e, x + 1, y + 1, z + 1 - e, x, y + 1, z + 1 - e, 0, 0, 1, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          out.pushQuad(x + 1, y, z + e, x, y, z + e, x, y + 1, z + e, x + 1, y + 1, z + e, 0, 0, -1, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          out.pushQuad(x + 1 - e, y, z + 1, x + 1 - e, y, z, x + 1 - e, y + 1, z, x + 1 - e, y + 1, z + 1, 1, 0, 0, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          out.pushQuad(x + e, y, z, x + e, y, z + 1, x + e, y + 1, z + 1, x + e, y + 1, z, -1, 0, 0, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          if (above !== id) { out.pushQuad(x, y + 1, z + 1, x + 1, y + 1, z + 1, x + 1, y + 1, z, x, y + 1, z, 0, 1, 0, 1, 1, tiles[id][2], 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1); }
          if (below !== id) { out.pushQuad(x, y, z, x + 1, y, z, x + 1, y, z + 1, x, y, z + 1, 0, -1, 0, 1, 1, tiles[id][3], 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1); }
        } else if (b.shape === 'door') {
          const below = ly > 0 ? padded[lIdx - STRIDE_Y] : 0;
          const upper = (state & 4) !== 0 || ((below & 4095) === id && ((below >>> 12) & 4) === 0);
          const open = (state & 8) !== 0, f = state & 3, e = open ? (f + 3) & 3 : f;
          const flip = open ? f >= 2 : f === 0 || f === 3;
          const x0 = e === 3 ? 13 : 0, x1 = e === 1 ? 3 : 16, z0 = e === 2 ? 13 : 0, z1 = e === 0 ? 3 : 16;
          DT[0] = flip ? 16 - x0 : x0; DT[3] = flip ? 16 - x1 : x1; DT[2] = flip ? 16 - z0 : z0; DT[5] = flip ? 16 - z1 : z1;
          const doorTile = upper ? tiles[id][2] : tiles[id][0];
          emitBox(x, y, z, x0, 0, z0, x1, 16, z1, doorTile, sky, blk, DT, true);
          // 3D protruding door handle/knob on the lower half & raised lock rail
          const handleTile = tiles[b.name === 'iron_door' ? ID.iron_block : ID.gold_block]?.[0] ?? doorTile;
          if (!upper) {
            if (e === 0 || e === 2) {
              const hx0 = flip ? 2 : 12, hx1 = hx0 + 2;
              const hz0 = e === 2 ? 12.2 : -0.4, hz1 = e === 2 ? 16.4 : 3.8;
              emitBox(x, y, z, hx0, 13.5, hz0, hx1, 15.2, hz1, handleTile, sky, blk);
            } else {
              const hz0 = flip ? 2 : 12, hz1 = hz0 + 2;
              const hx0 = e === 3 ? 12.2 : -0.4, hx1 = e === 3 ? 16.4 : 3.8;
              emitBox(x, y, z, hx0, 13.5, hz0, hx1, 15.2, hz1, handleTile, sky, blk);
            }
          }
        } else if (b.shape === 'fence') {
          const wall = b.name.endsWith('_wall'), tile = tiles[id][0];
          const joins = (c: number) => { if (!c) return false; const nb = blocks[c & 4095]; return !!nb && (nb.shape === 'fence' ? nb.name.endsWith('_wall') === wall : isOpq(c)); };
          const cn = joins(getCellAt(padded, dimsY, x, ly, z - 1)), cs = joins(getCellAt(padded, dimsY, x, ly, z + 1)), cw = joins(getCellAt(padded, dimsY, x - 1, ly, z)), ce = joins(getCellAt(padded, dimsY, x + 1, ly, z));
          if (wall) {
            emitBox(x, y, z, 4, 0, 4, 12, 16, 12, tile, sky, blk);
            if (cn) emitBox(x, y, z, 5, 0, 0, 11, 14, 4, tile, sky, blk);
            if (cs) emitBox(x, y, z, 5, 0, 12, 11, 14, 16, tile, sky, blk);
            if (cw) emitBox(x, y, z, 0, 0, 5, 4, 14, 11, tile, sky, blk);
            if (ce) emitBox(x, y, z, 12, 0, 5, 16, 14, 11, tile, sky, blk);
          } else {
            emitBox(x, y, z, 6, 0, 6, 10, 16, 10, tile, sky, blk);
            for (let bar = 6; bar <= 12; bar += 6) {
              if (cn) emitBox(x, y, z, 7, bar, 0, 9, bar + 3, 6, tile, sky, blk);
              if (cs) emitBox(x, y, z, 7, bar, 10, 9, bar + 3, 16, tile, sky, blk);
              if (cw) emitBox(x, y, z, 0, bar, 7, 6, bar + 3, 9, tile, sky, blk);
              if (ce) emitBox(x, y, z, 10, bar, 7, 16, bar + 3, 9, tile, sky, blk);
            }
          }
        } else if (b.name === 'bed') {
          const head = (state & 4) !== 0, outer = head ? state & 3 : ((state & 3) + 2) & 3, side = head ? tiles[id][1] : tiles[id][0];
          emitBox(x, y, z, 0, 3, 0, 16, 8.9, 16, side, sky, blk);
          emitBox(x, y, z, 0, 8.9, 0, 16, 9, 16, head ? tiles[id][2] : tiles[id][3], sky, blk);
          for (let k = 0; k < 2; k++) {
            const lx = outer === 0 ? 13 : outer === 2 ? 0 : k * 13, lz = outer === 1 ? 13 : outer === 3 ? 0 : k * 13;
            emitBox(x, y, z, lx, 0, lz, lx + 3, 3, lz + 3, side, sky, blk);
          }
        } else if (b.name === 'hopper') {
          const hopTile = tiles[ID.anvil]?.[0] ?? tiles[id][0];
          const inTile = tiles[ID.cauldron]?.[0] ?? hopTile;
          // Hollow top funnel walls + floor + middle chamber + directional spout
          emitBox(x, y, z, 0, 10, 0, 16, 16, 2, hopTile, sky, blk);
          emitBox(x, y, z, 0, 10, 14, 16, 16, 16, hopTile, sky, blk);
          emitBox(x, y, z, 0, 10, 2, 2, 16, 14, hopTile, sky, blk);
          emitBox(x, y, z, 14, 10, 2, 16, 16, 14, hopTile, sky, blk);
          emitBox(x, y, z, 2, 10, 2, 14, 11, 14, inTile, sky, blk);
          emitBox(x, y, z, 4, 4, 4, 12, 10, 12, hopTile, sky, blk);
          const dir = state & 7;
          if (dir === 0) emitBox(x, y, z, 12, 4, 6, 16, 8, 10, hopTile, sky, blk);
          else if (dir === 1) emitBox(x, y, z, 6, 4, 12, 10, 8, 16, hopTile, sky, blk);
          else if (dir === 2) emitBox(x, y, z, 0, 4, 6, 4, 8, 10, hopTile, sky, blk);
          else if (dir === 3) emitBox(x, y, z, 6, 4, 0, 10, 8, 4, hopTile, sky, blk);
          else emitBox(x, y, z, 6, 0, 6, 10, 4, 10, hopTile, sky, blk);
        } else if (b.name === 'composter') {
          const woodTile = tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          emitBox(x, y, z, 0, 0, 0, 16, 16, 2, woodTile, sky, blk);
          emitBox(x, y, z, 0, 0, 14, 16, 16, 16, woodTile, sky, blk);
          emitBox(x, y, z, 0, 0, 2, 2, 16, 14, woodTile, sky, blk);
          emitBox(x, y, z, 14, 0, 2, 16, 16, 14, woodTile, sky, blk);
          emitBox(x, y, z, 2, 0, 2, 14, 2, 14, woodTile, sky, blk);
          if (state > 0) {
            const fillH = Math.min(15, 2 + Math.min(8, state) * 1.6);
            const fillTile = state >= 8 ? (tiles[ID.bone_block]?.[2] ?? woodTile) : (tiles[ID.podzol]?.[2] ?? tiles[ID.dirt]?.[0] ?? woodTile);
            emitBox(x, y, z, 2, 2, 2, 14, fillH, 14, fillTile, sky, blk);
          }
        } else if (b.name === 'cauldron') {
          const ironTile = tiles[ID.anvil]?.[0] ?? tiles[id][0];
          emitBox(x, y, z, 0, 3, 0, 16, 16, 2, ironTile, sky, blk);
          emitBox(x, y, z, 0, 3, 14, 16, 16, 16, ironTile, sky, blk);
          emitBox(x, y, z, 0, 3, 2, 2, 16, 14, ironTile, sky, blk);
          emitBox(x, y, z, 14, 3, 2, 16, 16, 14, ironTile, sky, blk);
          emitBox(x, y, z, 2, 3, 2, 14, 4, 14, ironTile, sky, blk);
          for (const [fx, fz] of [[0, 0], [13, 0], [0, 13], [13, 13]]) {
            emitBox(x, y, z, fx, 0, fz, fx + 3, 3, fz + 3, ironTile, sky, blk);
          }
          // Dynamic internal liquid mesh: state 1..3 = water levels (7.5 / 11.0 / 14.5), state >= 4 = animated lava surface
          if (state >= 1 && state <= 3) {
            const liqY = state === 1 ? 7.5 : state === 2 ? 11.0 : 14.5;
            const waterTile = tiles[ID.water]?.[0] ?? ironTile;
            emitBox(x, y, z, 2, 4, 2, 14, liqY - 0.15, 14, waterTile, sky, blk);
            const wy = y + liqY / 16, x0 = x + 2 / 16, x1 = x + 14 / 16, z0 = z + 2 / 16, z1 = z + 14 / 16;
            reusableWater.pushQuad(x0, wy, z0, x0, wy, z1, x1, wy, z1, x1, wy, z0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0.4, 0.4, 0.4, 0.4, 0, false, 1, 1, 1, false, false);
          } else if (state >= 4) {
            const lavaTile = tiles[ID.lava]?.[0] ?? ironTile;
            emitBox(x, y, z, 2, 4, 2, 14, 14.35, 14, lavaTile, sky, 1);
            const wy = y + 14.5 / 16, x0 = x + 2 / 16, x1 = x + 14 / 16, z0 = z + 2 / 16, z1 = z + 14 / 16;
            reusableWater.pushQuad(x0, wy, z0, x0, wy, z1, x1, wy, z1, x1, wy, z0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, false, 1, 1, 1, false, false);
          }
        } else if (b.name === 'repeater' || b.name === 'comparator') {
          const slabTile = tiles[ID.smooth_stone]?.[0] ?? tiles[id][0];
          const torchTile = tiles[ID.redstone_torch]?.[0] ?? tiles[id][0];
          const bedrockTile = tiles[ID.bedrock]?.[0] ?? slabTile;
          emitBox(x, y, z, 0, 0, 0, 16, 2, 16, slabTile, sky, blk);
          const dir = state & 3, delay = (state >> 2) & 3;
          // Front miniature torch near output edge
          const fx0 = dir === 0 ? 12 : dir === 2 ? 2 : 7, fx1 = fx0 + 2;
          const fz0 = dir === 1 ? 12 : dir === 3 ? 2 : 7, fz1 = fz0 + 2;
          emitBox(x, y, z, fx0, 2, fz0, fx1, 7, fz1, torchTile, sky, blk);
          if (b.name === 'repeater') {
            // Check if locked by a side repeater/comparator pointing into this repeater
            const checkSide = (sdx: number, sdz: number, reqDir: number): boolean => {
              const sc = getCellAt(padded, dimsY, x + sdx, ly, z + sdz), sid = sc & 4095, sst = (sc >>> 12) & 15;
              if (sid !== ID.repeater && sid !== ID.comparator) return false;
              if ((sst & 3) !== reqDir) return false;
              const bx = x + sdx * 2, bz = z + sdz * 2, bc = getCellAt(padded, dimsY, bx, ly, bz), bid = bc & 4095, bst = (bc >>> 12) & 15;
              return bid === ID.redstone_block || bid === ID.redstone_torch || (bid === ID.lever && (bst & 8) !== 0) || (bid === ID.repeater) || (bid === ID.redstone_wire && bst > 0);
            };
            const locked = (dir === 0 || dir === 2)
              ? (checkSide(0, -1, 1) || checkSide(0, 1, 3))
              : (checkSide(-1, 0, 0) || checkSide(1, 0, 2));
            const off = 9 - delay * 2;
            if (locked) {
              // Locked state: cross-wise Bedrock Bar replaces the movable delay torch
              if (dir === 0 || dir === 2) {
                const bx0 = dir === 0 ? off : 14 - off;
                emitBox(x, y, z, bx0, 2, 2, bx0 + 2, 4.5, 14, bedrockTile, sky, blk);
              } else {
                const bz0 = dir === 1 ? off : 14 - off;
                emitBox(x, y, z, 2, 2, bz0, 14, 4.5, bz0 + 2, bedrockTile, sky, blk);
              }
            } else {
              const rx0 = dir === 0 ? off : dir === 2 ? 14 - off : 7;
              const rz0 = dir === 1 ? off : dir === 3 ? 14 - off : 7;
              emitBox(x, y, z, rx0, 2, rz0, rx0 + 2, 7, rz0 + 2, torchTile, sky, blk);
            }
          } else {
            // Comparator: two rear torches
            if (dir === 0 || dir === 2) {
              const rx = dir === 0 ? 3 : 11;
              emitBox(x, y, z, rx, 2, 3, rx + 2, 6, 5, torchTile, sky, blk);
              emitBox(x, y, z, rx, 2, 11, rx + 2, 6, 13, torchTile, sky, blk);
            } else {
              const rz = dir === 1 ? 3 : 11;
              emitBox(x, y, z, 3, 2, rz, 5, 6, rz + 2, torchTile, sky, blk);
              emitBox(x, y, z, 11, 2, rz, 13, 6, rz + 2, torchTile, sky, blk);
            }
          }
        } else if (b.name === 'decorated_pot') {
          const potTile = tiles[id][0];
          emitBox(x, y, z, 1, 0, 1, 15, 14, 15, potTile, sky, blk);
          emitBox(x, y, z, 4, 14, 4, 12, 15, 12, potTile, sky, blk);
          emitBox(x, y, z, 3, 15, 3, 13, 16, 13, potTile, sky, blk);
        } else if (b.name === 'frosted_ice' || b.name === 'suspicious_sand' || b.name === 'suspicious_gravel') {
          const stTile = tiles[id]?.[6 + (state & 3)] ?? tiles[id][0];
          emitBox(x, y, z, 0, 0, 0, 16, 16, 16, stTile, sky, blk);
        } else if (b.name === 'stonecutter') {
          const stoneTile = tiles[ID.smooth_stone]?.[0] ?? tiles[id][0];
          const sawTile = tiles[ID.iron_block]?.[0] ?? tiles[id][0];
          emitBox(x, y, z, 0, 0, 0, 16, 9, 16, stoneTile, sky, blk);
          emitBox(x, y, z, 2, 9, 7.4, 14, 14, 8.6, sawTile, sky, blk);
          emitBox(x, y, z, 4, 14, 7.4, 12, 15.5, 8.6, sawTile, sky, blk);
        } else if (b.name === 'grindstone') {
          const stoneTile = tiles[ID.smooth_stone]?.[0] ?? tiles[id][0];
          const woodTile = tiles[ID.dark_oak_planks]?.[0] ?? tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          emitBox(x, y, z, 2, 0, 6, 4, 7, 10, woodTile, sky, blk);
          emitBox(x, y, z, 12, 0, 6, 14, 7, 10, woodTile, sky, blk);
          emitBox(x, y, z, 1.5, 6, 5, 4, 11, 11, woodTile, sky, blk);
          emitBox(x, y, z, 12, 6, 5, 14.5, 11, 11, woodTile, sky, blk);
          emitBox(x, y, z, 4, 4, 2, 12, 16, 14, stoneTile, sky, blk);
        } else if (b.name === 'lectern') {
          const plankTile = tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          const shelfTile = tiles[ID.bookshelf]?.[4] ?? plankTile;
          const redTile = tiles[ID.red_wool]?.[0] ?? plankTile;
          const pageTile = tiles[ID.quartz_block]?.[0] ?? tiles[ID.white_wool]?.[0] ?? plankTile;
          // Base slab + central pedestal post + stepped slanted desk + open book with pages
          emitBox(x, y, z, 0, 0, 0, 16, 2, 16, plankTile, sky, blk);
          emitBox(x, y, z, 4, 2, 4, 12, 11, 12, shelfTile, sky, blk);
          emitBox(x, y, z, 1, 10, 1, 15, 12.5, 6, plankTile, sky, blk);
          emitBox(x, y, z, 1, 11.5, 5, 15, 14, 11, plankTile, sky, blk);
          emitBox(x, y, z, 1, 13, 10, 15, 15.5, 15, plankTile, sky, blk);
          // Open book cover & pages on top of the slanted desk
          emitBox(x, y, z, 2.5, 12.6, 3, 13.5, 13.6, 9, redTile, sky, blk);
          emitBox(x, y, z, 3, 13.4, 3.5, 7.6, 14.4, 8.5, pageTile, sky, blk);
          emitBox(x, y, z, 8.4, 13.4, 3.5, 13, 14.4, 8.5, pageTile, sky, blk);
        } else if (b.name === 'bell') {
          const stoneTile = tiles[ID.stone_bricks]?.[0] ?? tiles[ID.stone]?.[0] ?? tiles[id][0];
          const woodTile = tiles[ID.dark_oak_planks]?.[0] ?? tiles[ID.oak_planks]?.[0] ?? tiles[id][0];
          const goldTile = tiles[ID.gold_block]?.[0] ?? tiles[id][0];
          // Two side support pillars + top wooden crossbar + hanging golden bell body + flared lower rim + clapper
          emitBox(x, y, z, 1, 0, 6, 3, 15, 10, stoneTile, sky, blk);
          emitBox(x, y, z, 13, 0, 6, 15, 15, 10, stoneTile, sky, blk);
          emitBox(x, y, z, 1, 13, 6.5, 15, 15, 9.5, woodTile, sky, blk);
          emitBox(x, y, z, 7, 11.5, 7, 9, 13, 9, goldTile, sky, blk);
          emitBox(x, y, z, 5, 5, 5, 11, 11.5, 11, goldTile, sky, blk);
          emitBox(x, y, z, 4, 3, 4, 12, 5, 12, goldTile, sky, blk);
          emitBox(x, y, z, 7.2, 1.8, 7.2, 8.8, 3, 8.8, goldTile, sky, blk);
        } else if (b.shape === 'brewing_stand' || b.name === 'brewing_stand') {
          const cobbleTile = tiles[ID.cobblestone]?.[0] ?? tiles[id][0];
          const rodTile = tiles[ID.gold_block]?.[0] ?? tiles[id][0];
          const bottleTile = tiles[ID.red_stained_glass]?.[0] ?? tiles[ID.glass]?.[0] ?? tiles[id][0];
          // 3 distinct cobblestone base plates
          emitBox(x, y, z, 1, 0, 9, 7, 2, 15, cobbleTile, sky, blk);
          emitBox(x, y, z, 9, 0, 9, 15, 2, 15, cobbleTile, sky, blk);
          emitBox(x, y, z, 5, 0, 1, 11, 2, 7, cobbleTile, sky, blk);
          // Central vertical blaze rod + collar + 3 bottle arms + 3 potion bottles
          emitBox(x, y, z, 7, 0, 7, 9, 14.5, 9, rodTile, sky, blk);
          emitBox(x, y, z, 6.4, 10.5, 6.4, 9.6, 12, 9.6, rodTile, sky, blk);
          emitBox(x, y, z, 4, 8, 11, 7, 9, 12.2, rodTile, sky, blk);
          emitBox(x, y, z, 9, 8, 11, 12, 9, 12.2, rodTile, sky, blk);
          emitBox(x, y, z, 7.4, 8, 4, 8.6, 9, 7, rodTile, sky, blk);
          emitBox(x, y, z, 3, 2, 10.5, 5.5, 7, 13, bottleTile, sky, blk);
          emitBox(x, y, z, 10.5, 2, 10.5, 13, 7, 13, bottleTile, sky, blk);
          emitBox(x, y, z, 6.8, 2, 2.8, 9.2, 7, 5.2, bottleTile, sky, blk);
        } else if (b.shape === 'anvil' || b.name === 'anvil') {
          const anvilTile = tiles[id][0];
          const rotX = (state & 1) !== 0;
          const dmg = (state >> 2) & 3;
          emitBox(x, y, z, 2, 0, 2, 14, 4, 14, anvilTile, sky, blk);
          if (rotX) {
            emitBox(x, y, z, 3, 4, 4, 13, 5, 12, anvilTile, sky, blk);
            emitBox(x, y, z, 4, 5, 6, 12, 10, 10, anvilTile, sky, blk);
            if (dmg === 0) {
              emitBox(x, y, z, 0, 10, 3, 16, 16, 13, anvilTile, sky, blk);
            } else if (dmg === 1) {
              emitBox(x, y, z, 0, 10, 3, 12, 16, 13, anvilTile, sky, blk);
              emitBox(x, y, z, 12, 10, 4, 16, 15, 12, anvilTile, sky, blk);
            } else {
              emitBox(x, y, z, 2, 10, 3, 11, 16, 13, anvilTile, sky, blk);
              emitBox(x, y, z, 0, 10, 5, 2, 14, 11, anvilTile, sky, blk);
              emitBox(x, y, z, 11, 10, 4, 15, 14.5, 12, anvilTile, sky, blk);
            }
          } else {
            emitBox(x, y, z, 4, 4, 3, 12, 5, 13, anvilTile, sky, blk);
            emitBox(x, y, z, 6, 5, 4, 10, 10, 12, anvilTile, sky, blk);
            if (dmg === 0) {
              emitBox(x, y, z, 3, 10, 0, 13, 16, 16, anvilTile, sky, blk);
            } else if (dmg === 1) {
              emitBox(x, y, z, 3, 10, 0, 13, 16, 12, anvilTile, sky, blk);
              emitBox(x, y, z, 4, 10, 12, 12, 15, 16, anvilTile, sky, blk);
            } else {
              emitBox(x, y, z, 3, 10, 2, 13, 16, 11, anvilTile, sky, blk);
              emitBox(x, y, z, 5, 10, 0, 11, 14, 2, anvilTile, sky, blk);
              emitBox(x, y, z, 4, 10, 11, 12, 14.5, 15, anvilTile, sky, blk);
            }
          }
        } else if (b.name === 'chain') {
          const chainTile = tiles[ID.anvil]?.[0] ?? tiles[id][0];
          // 4 alternating interlocked 3D chain links along Y
          emitBox(x, y, z, 6.5, 0, 7.2, 9.5, 4.2, 8.8, chainTile, sky, blk);
          emitBox(x, y, z, 7.2, 3.8, 6.5, 8.8, 8.2, 9.5, chainTile, sky, blk);
          emitBox(x, y, z, 6.5, 7.8, 7.2, 9.5, 12.2, 8.8, chainTile, sky, blk);
          emitBox(x, y, z, 7.2, 11.8, 6.5, 8.8, 16, 9.5, chainTile, sky, blk);
        } else if (b.shape === 'lantern') {
          const sideTile = tiles[id][0], topTile = tiles[id][2];
          const chainTile = tiles[ID.anvil]?.[0] ?? topTile;
          emitBox(x, y, z, 4.8, 0, 4.8, 11.2, 1.2, 11.2, topTile, sky, blk);
          emitBox(x, y, z, 5, 1.2, 5, 11, 6.8, 11, sideTile, sky, 1);
          emitBox(x, y, z, 4.8, 6.5, 4.8, 11.2, 7.5, 11.2, topTile, sky, blk);
          emitBox(x, y, z, 6, 7.5, 6, 10, 9.2, 10, topTile, sky, blk);
          emitBox(x, y, z, 7, 9.2, 7.3, 9, 11.2, 8.7, chainTile, sky, blk);
          const aboveId = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
          if (aboveId > 0) {
            emitBox(x, y, z, 7.3, 10.8, 7, 8.7, 16, 9, chainTile, sky, blk);
          }
        } else if (b.shape === 'end_portal' || b.shape === 'end_gateway') {
          const tile = tiles[id][0];
          if (b.shape === 'end_gateway') {
            emitBox(x, y, z, 0.5, 0.5, 0.5, 15.5, 15.5, 15.5, tile, 1, 1);
          } else {
            emitBox(x, y, z, 0, 11, 0, 16, 12, 16, tile, 1, 1);
          }
        } else if (b.shape === 'end_portal_frame') {
          emitBox(x, y, z, 0, 0, 0, 16, 13, 16, tiles[id][2], sky, blk);
          if (state & 4) {
            emitBox(x, y, z, 5, 13, 5, 11, 16, 11, tiles[ID.emerald_ore]?.[0] ?? tiles[id][2], sky, 1);
          }
        } else if (b.shape === 'end_rod') {
          emitBox(x, y, z, 5, 0, 5, 11, 2, 11, tiles[ID.purpur_block]?.[0] ?? tiles[id][0], sky, 1);
          emitBox(x, y, z, 6.5, 2, 6.5, 9.5, 16, 9.5, tiles[ID.quartz_block]?.[0] ?? tiles[id][0], sky, 1);
        } else if (b.shape === 'dragon_egg') {
          const tile = tiles[id][0];
          emitBox(x, y, z, 3, 0, 3, 13, 4, 13, tile, sky, blk);
          emitBox(x, y, z, 2, 4, 2, 14, 11, 14, tile, sky, blk);
          emitBox(x, y, z, 4, 11, 4, 12, 15, 12, tile, sky, blk);
          emitBox(x, y, z, 6, 15, 6, 10, 16, 10, tile, sky, blk);
        } else if (b.shape === 'pane' && (b.name.endsWith('glass_pane') || b.name === 'iron_bars')) {
          const tile = tiles[id][0], isBars = b.name === 'iron_bars';
          const joins = (c: number) => { if (!c) return false; const nb = blocks[c & 4095]; return !!nb && (isBars ? (nb.name === 'iron_bars' || isOpq(c)) : (nb.name.endsWith('glass_pane') || nb.pattern === 'glass' || isOpq(c))); };
          let cn = joins(getCellAt(padded, dimsY, x, ly, z - 1)), cs = joins(getCellAt(padded, dimsY, x, ly, z + 1)), cw = joins(getCellAt(padded, dimsY, x - 1, ly, z)), ce = joins(getCellAt(padded, dimsY, x + 1, ly, z));
          if (!cn && !cs && !cw && !ce) { if (state & 1) { cw = true; ce = true; } else { cn = true; cs = true; } }
          emitBox(x, y, z, 7, 0, 7, 9, 16, 9, tile, sky, blk);
          if (cn) emitBox(x, y, z, 7, 0, 0, 9, 16, 7, tile, sky, blk);
          if (cs) emitBox(x, y, z, 7, 0, 9, 9, 16, 16, tile, sky, blk);
          if (cw) emitBox(x, y, z, 0, 0, 7, 7, 16, 9, tile, sky, blk);
          if (ce) emitBox(x, y, z, 9, 0, 7, 16, 16, 9, tile, sky, blk);
        } else if (b.shape === 'torch' && b.name !== 'lantern' && b.name !== 'soul_lantern' && b.name !== 'brewing_stand') {
          const at = state & 7, on = (state & 8) !== 0;
          if (b.name === 'lever') {
            const bb = LEVER_BASE16[at] ?? LEVER_BASE16[0], sk = (LEVER_STICK16[at] ?? LEVER_STICK16[0])[on ? 1 : 0];
            emitBox(x, y, z, bb[0], bb[1], bb[2], bb[3], bb[4], bb[5], tiles[id][3], sky, blk);
            emitBox(x, y, z, sk[0], sk[1], sk[2], sk[3], sk[4], sk[5], tiles[id][0], sky, blk, sk[6] === 1 ? STICK_UP : STICK_DOWN, false, sk[6], sk[7], sk[8]);
          } else if (b.name.endsWith('_button')) {
            const bb = BUTTON16[at] ?? BUTTON16[0];
            let x0 = bb[0], y0 = bb[1], z0 = bb[2], x1 = bb[3], y1 = bb[4], z1 = bb[5];
            if (on) { if (at === 1) x1 = 1; else if (at === 2) x0 = 15; else if (at === 3) z1 = 1; else if (at === 4) z0 = 15; else if (at === 5) y0 = 15; else y1 = 1; }
            emitBox(x, y, z, x0, y0, z0, x1, y0 === y1 ? y1 + 1 : y1, z1, tiles[id][0], sky, blk);
          } else {
            const tb = TORCH16[at] ?? TORCH16[0];
            emitBox(x, y, z, tb[0], tb[1], tb[2], tb[3], tb[4], tb[5], tiles[id][0], sky, blk, STICK_UP, false, tb[6], tb[7], tb[8]);
          }
        } else {
          const boxes = modelBoxes(b, state);
          for (const box of boxes) {
            const [bx0, by0, bz0, bx1, by1, bz1] = box;
            const x0 = x + bx0, y0 = y + by0, z0 = z + bz0, x1 = x + bx1, y1 = y + by1, z1 = z + bz1;
            const t0 = tiles[id][localFaceForState(b, state, 4)];
            const t1 = tiles[id][localFaceForState(b, state, 5)];
            const t2 = tiles[id][localFaceForState(b, state, 2)];
            const t3 = tiles[id][localFaceForState(b, state, 3)];
            const t4 = tiles[id][localFaceForState(b, state, 0)];
            const t5 = tiles[id][localFaceForState(b, state, 1)];
            const uLen = bx1 - bx0, vLen = by1 - by0, wLen = bz1 - bz0;
            out.pushQuad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1, uLen, vLen, t0, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bx0, by0, bx1, by1);
            out.pushQuad(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0, 0, -1, uLen, vLen, t1, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(1 - bx1, by0, 1 - bx0, by1);
            out.pushQuad(x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0, 1, 0, uLen, wLen, t2, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bx0, 1 - bz1, bx1, 1 - bz0);
            out.pushQuad(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0, uLen, wLen, t3, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bx0, bz0, bx1, bz1);
            out.pushQuad(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, 1, 0, 0, wLen, vLen, t4, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(1 - bz1, by0, 1 - bz0, by1);
            out.pushQuad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1, 0, 0, wLen, vLen, t5, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
            out.uvRect(bz0, by0, bz1, by1);
          }
        }
      }
    }
  }
}

export function meshChunk(padded: Uint16Array, maxY: number, tiles: number[][], tint?: Float32Array): { solid: MeshData; water: MeshData } {
  ensureLuts();
  computeLights(padded, maxY);

  const dimsY = Math.min(HEIGHT | 0, (maxY | 0) - (MIN_Y | 0));
  reusableOut.reset();
  reusableWater.reset();

  meshGreedy(padded, dimsY, tiles, tint, reusableOut, reusableWater);
  meshSubBlocks(padded, dimsY, tiles, tint, reusableOut);

  return { solid: reusableOut.pack(), water: reusableWater.pack() };
}
