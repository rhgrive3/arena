// Underground generation helpers modelled on Minecraft Java Edition 1.18+ (NoiseBasedAquifer, OreVeinifier, cave biome parameters).
//
//  * Aquifers   – the world is split into 16x12x16 cells, each with a randomly jittered centre. Every cave block belongs to the
//                 cell whose centre is nearest, and every cell owns a fluid level (quantised to 3 blocks inside 40-block layers),
//                 so caves contain separate, locally flat lakes instead of one global water table. Below y=-54 the global
//                 fluid is lava (lava level of the overworld); cells below y=-10 may hold lava aquifers.
//  * Ore veins  – `ore_veininess` picks the vein type (copper: y 0..50, iron: y -60..-8) and the blob where veins exist,
//                 `vein_ridged` carves thin gaps, `vein_gap` punches random holes. Veins are filled with granite (copper) / tuff (iron),
//                 10–30 % of it is ore, 2 % raw ore blocks. Deepslate ore variants are used inside deepslate.
//  * Cave biomes – lush caves, dripstone caves and the deep dark are decided from humidity / continentalness / erosion *and* a 3D noise,
//                 so they form vertical pockets (stacked, layered distribution) rather than infinite columns.
import { ID } from '../game/data';

export interface NoiseSrc {
  n2(x: number, z: number): number;
  n3(x: number, y: number, z: number): number;
  fbm(x: number, z: number, octaves?: number): number;
}

export const SEA_LEVEL = 63;
export const MIN_WORLD_Y = -64;
const B = ID as Record<string, number | undefined>;

function hash3(x: number, y: number, z: number, seed: number): number {
  let h = Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul((y | 0) + 0x632be5ab, 1274126177) ^ seed;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

interface AquiferCell { x: number; y: number; z: number; level: number; lava: boolean }

export const VEIN_THRESHOLD = 0.52;

export class Underground {
  private cells = new Map<number, AquiferCell>();

  constructor(private n: NoiseSrc, private seed: number, private surface: (x: number, z: number) => number) {}

  // ------------------------------------------------------------------ aquifers
  private cell(cx: number, cy: number, cz: number): AquiferCell {
    const key = ((cx + 4096) * 8192 + (cz + 4096)) * 64 + (cy + 8);
    let c = this.cells.get(key);
    if (c) return c;
    const s = this.seed;
    const X = cx * 16 + 5 + Math.floor(hash3(cx, cy, cz, s + 11) * 10);
    const Y = cy * 12 + 1 + Math.floor(hash3(cx, cy, cz, s + 12) * 9);
    const Z = cz * 16 + 5 + Math.floor(hash3(cx, cy, cz, s + 13) * 10);
    const surf = this.surface(X, Z);
    let level = -Infinity, lava = false;
    if (Y > surf - 6) {
      // Near / above the surface the only fluid is the sea itself (cave mouths opening under the ocean floor).
      level = surf < SEA_LEVEL ? SEA_LEVEL : -Infinity;
    } else {
      const flood = this.n.n3(X * 0.011 + 13.7, Y * 0.0125, Z * 0.011 - 4.1);
      if (flood > 0.5 && Y < SEA_LEVEL - 4) {
        // "Flooded" aquifers are filled right up to the global sea level (or just below the ceiling of the terrain).
        level = Math.min(SEA_LEVEL, surf - 8);
      } else {
        const spread = this.n.n3(X * 0.0125 + 77.0, Math.floor((Y + 64) / 40) * 3.1, Z * 0.0125 - 21.0);
        const layerBase = Math.floor((Y + 64) / 40) * 40 - 64;
        level = Math.min(SEA_LEVEL, layerBase + 6 + Math.floor((spread * 20) / 3) * 3);
        if (Y < -8 && this.n.n3(X * 0.02 + 5.5, Y * 0.02, Z * 0.02 - 9.1) > 0.28) lava = true;
      }
    }
    c = { x: X, y: Y, z: Z, level, lava };
    if (this.cells.size > 24000) this.cells.clear();
    this.cells.set(key, c);
    return c;
  }

  /** Aquifer fluid (water/lava block id) that occupies a *carved* cave voxel, or 0 when the voxel stays air. */
  fluidAt(x: number, y: number, z: number): number {
    const ix = Math.floor((x - 5) / 16), iy = Math.floor((y - 1) / 12), iz = Math.floor((z - 5) / 16);
    let best = Infinity, pick: AquiferCell | null = null;
    for (let k = 0; k < 8; k++) {
      const c = this.cell(ix + (k & 1), iy + ((k >> 1) & 1), iz + (k >> 2));
      const dx = c.x - x, dy = c.y - y, dz = c.z - z, d = dx * dx + dy * dy + dz * dz;
      if (d < best) { best = d; pick = c; }
    }
    if (!pick || y > pick.level) return 0;
    return pick.lava ? ID.lava : ID.water;
  }

  // ------------------------------------------------------------------ ore veins
  /** Smooth vein selector. Positive = copper veins, negative = iron veins. Only |value| >= VEIN_THRESHOLD hosts a vein. */
  veinToggle(x: number, y: number, z: number): number {
    return this.n.n3(x * 0.013 + 31.3, y * 0.0135 + 7.7, z * 0.013 - 12.9);
  }

  /** Vein-type window test shared by the cheap pre-filter in terrain generation. */
  veinActive(toggle: number, y: number): boolean {
    const copper = toggle > 0;
    const min = copper ? 0 : -60, max = copper ? 50 : -8;
    if (y < min || y > max) return false;
    const roundoff = -0.2 * (1 - Math.min(20, Math.min(max - y, y - min)) / 20);
    return Math.abs(toggle) + roundoff >= VEIN_THRESHOLD;
  }

  /**
   * Block to place for a vein voxel, or 0 to keep the host rock.
   * `deep` is true when the host block is deepslate (use deepslate ore variants).
   */
  vein(x: number, y: number, z: number, toggle: number, deep: boolean): number {
    if (!this.veinActive(toggle, y)) return 0;
    const copper = toggle > 0;
    const min = copper ? 0 : -60, max = copper ? 50 : -8;
    const roundoff = -0.2 * (1 - Math.min(20, Math.min(max - y, y - min)) / 20);
    const strength = Math.abs(toggle) + roundoff;
    if (hash3(x, y, z, this.seed + 401) > 0.7) return 0;
    const a = Math.abs(this.n.n3(x * 0.075 + 3.1, y * 0.075 + 9.4, z * 0.075 - 5.3));
    const b = Math.abs(this.n.n3(x * 0.075 - 41.7, y * 0.075 + 2.2, z * 0.075 + 17.9));
    if (Math.max(a, b) < 0.09) return 0; // thin ridged gaps between the vein sheets
    const richness = 0.1 + 0.2 * Math.min(1, Math.max(0, (strength - VEIN_THRESHOLD) / 0.2));
    if (hash3(x, y, z, this.seed + 402) < richness && this.n.n3(x * 0.4 + 8.2, y * 0.4, z * 0.4 - 3.3) > -0.36) {
      if (hash3(x, y, z, this.seed + 403) < 0.02) return (copper ? B.raw_copper_block : B.raw_iron_block) ?? (copper ? ID.copper_ore : ID.iron_ore);
      const ore = copper ? (deep ? B.deepslate_copper_ore : B.copper_ore) : (deep ? B.deepslate_iron_ore : B.iron_ore);
      return ore ?? (copper ? ID.copper_ore : ID.iron_ore);
    }
    return (copper ? B.granite : B.tuff) ?? 0;
  }

  // ------------------------------------------------------------------ cave biomes (3D)
  /**
   * Underground biome at a voxel, or null for ordinary caves.
   * E/H/C are the column's erosion / humidity / continentalness, `surf` the surface height.
   */
  caveBiomeAt(x: number, y: number, z: number, E: number, H: number, C: number, surf: number): 'deep_dark' | 'lush_caves' | 'dripstone_caves' | null {
    if (y > 56 || y > surf - 8) return null;
    const n = this.n;
    // Deep dark: deep below low-erosion terrain; the ceiling of the pocket undulates with the 3D noise.
    if (y < 6) {
      const dd = n.n3(x * 0.011 + 910, y * 0.028, z * 0.011 + 620);
      if (y < dd * 10 + 2) {
        const bonus = Math.max(0, Math.min(0.6, -E - 0.12)) * 0.9;
        if (E < -0.1 && dd + bonus > 0.2) return 'deep_dark';
        if (dd > 0.64) return 'deep_dark';
      }
    }
    if (H > 0.2) {
      const ll = n.n3(x * 0.013 + 500, y * 0.024, z * 0.013 - 320);
      if (ll + Math.max(0, H - 0.25) * 1.3 > 0.4) return 'lush_caves';
    }
    if (C > 0.3) {
      const dp = n.n3(x * 0.014 - 700, y * 0.022, z * 0.014 + 260);
      if (dp + Math.max(0, C - 0.3) * 1.2 > 0.42) return 'dripstone_caves';
    }
    // Rare isolated pockets anywhere underground
    const rare = n.n3(x * 0.016 + 120, y * 0.03, z * 0.016 - 80);
    if (rare > 0.72) return y < 0 ? 'deep_dark' : 'lush_caves';
    if (rare < -0.72) return 'dripstone_caves';
    return null;
  }
}
