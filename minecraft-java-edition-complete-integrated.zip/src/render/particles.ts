import * as THREE from 'three';
import { BLOCKS, ID } from '../game/data';
import type { Stack } from '../game/types';
import { getTileTexture } from '../textures/atlas';
import { bannerColorOf, bannerShieldCanvas, type BannerLayer } from '../systems/banners';

interface Particle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  gravity: number;
  life: number;
  max: number;
  rotSpeed: number;
}

interface Drop {
  mesh: THREE.Mesh;
  name: string;
  count: number;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  baseY: number;
}

export class ParticleSystem {
  particles: Particle[] = [];
  drops: Drop[] = [];
  geometry = new THREE.BoxGeometry(1, 1, 1);
  materials = new Map<string, THREE.MeshLambertMaterial>();
  dropMaterials = new Map<string, THREE.MeshLambertMaterial>();
  private pool: THREE.Mesh[] = [];

  constructor(public scene: THREE.Scene) {}

  material(color: string) {
    let m = this.materials.get(color);
    if (!m) {
      m = new THREE.MeshLambertMaterial({ color });
      this.materials.set(color, m);
    }
    return m;
  }

  dropMaterial(name: string, fallbackColor: string, stack?: Stack) {
    if (stack && (stack.patterns?.length || stack.bannerBase) && (name === 'shield' || name.endsWith('_banner'))) {
      const base = stack.bannerBase ?? bannerColorOf(name);
      const key = `bannerdrop:${name}:${base}:${(stack.patterns ?? []).map(l => l.p + ':' + l.c).join(',')}`;
      let m = this.dropMaterials.get(key);
      if (!m) {
        const cv = bannerShieldCanvas(base, stack.patterns as BannerLayer[] | undefined, name === 'shield');
        const tex = new THREE.CanvasTexture(cv);
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        tex.colorSpace = THREE.SRGBColorSpace;
        m = new THREE.MeshLambertMaterial({ map: tex });
        this.dropMaterials.set(key, m);
      }
      return m;
    }
    let m = this.dropMaterials.get(name);
    if (!m) {
      try {
        const tex = getTileTexture(name);
        m = new THREE.MeshLambertMaterial({ map: tex, transparent: true, alphaTest: 0.35 });
      } catch {
        m = this.material(fallbackColor);
      }
      this.dropMaterials.set(name, m);
    }
    return m;
  }

  private acquire(mat: THREE.Material) {
    const m = this.pool.pop();
    if (m) {
      m.material = mat;
      m.visible = true;
      return m;
    }
    return new THREE.Mesh(this.geometry, mat);
  }

  private release(m: THREE.Mesh) {
    m.visible = false;
    if (this.pool.length < 220) this.pool.push(m);
    else this.scene.remove(m);
  }

  burst(p: THREE.Vector3, color: string, count = 10, power = 3, gravity = 12) {
    const mat = this.material(color);
    for (let i = 0; i < count && this.particles.length < 180; i++) {
      const mesh = this.acquire(mat);
      mesh.position.set(p.x + (Math.random() - 0.5) * 0.65, p.y + (Math.random() - 0.5) * 0.65, p.z + (Math.random() - 0.5) * 0.65);
      const s = 0.06 + Math.random() * 0.08;
      mesh.scale.setScalar(s);
      mesh.rotation.set(Math.random() * 3, Math.random() * 3, 0);
      if (!mesh.parent) this.scene.add(mesh);
      const life = 0.32 + Math.random() * 0.45;
      this.particles.push({
        mesh,
        vx: (Math.random() - 0.5) * power,
        vy: Math.random() * power * 0.9,
        vz: (Math.random() - 0.5) * power,
        gravity,
        life,
        max: life,
        rotSpeed: 2 + Math.random() * 4,
      });
    }
  }

  spark(p: THREE.Vector3, color: string, count = 8) {
    this.burst(p, color, count, 2.2, -1.8);
  }

  /**
   * Bubble Column particles:
   * - 'up' (Soul Sand): fast-rising cyan/white buoyancy bubbles
   * - 'down' (Magma Block): downward spiraling vortex bubbles
   */
  bubbleColumn(x: number, y: number, z: number, mode: 'up' | 'down', elapsed = 0) {
    const mat = this.material(mode === 'up' ? '#b8f4ff' : '#7ad6f0');
    const count = 2;
    for (let i = 0; i < count && this.particles.length < 180; i++) {
      const mesh = this.acquire(mat);
      const a = elapsed * 6.5 + i * Math.PI + Math.random() * 0.6;
      const r = mode === 'down' ? 0.28 : 0.18 + Math.random() * 0.18;
      mesh.position.set(x + 0.5 + Math.cos(a) * r, y + (mode === 'up' ? 0.15 : 0.85), z + 0.5 + Math.sin(a) * r);
      mesh.scale.setScalar(0.055 + Math.random() * 0.035);
      mesh.rotation.set(0, a, 0);
      if (!mesh.parent) this.scene.add(mesh);
      const life = 0.45 + Math.random() * 0.25;
      this.particles.push({
        mesh,
        vx: mode === 'down' ? -Math.sin(a) * 1.4 : (Math.random() - 0.5) * 0.35,
        vy: mode === 'up' ? 4.2 + Math.random() * 1.4 : -3.4 - Math.random() * 1.1,
        vz: mode === 'down' ? Math.cos(a) * 1.4 : (Math.random() - 0.5) * 0.35,
        gravity: mode === 'up' ? -2.5 : 2.5,
        life,
        max: life,
        rotSpeed: mode === 'down' ? 7 : 3,
      });
    }
  }

  /** Mouth food/drink crumb particles emitted every 4 ticks while eating/drinking. */
  crumbs(origin: THREE.Vector3, dir: THREE.Vector3, color: string, count = 5) {
    const mat = this.material(color);
    for (let i = 0; i < count && this.particles.length < 180; i++) {
      const mesh = this.acquire(mat);
      mesh.position.set(
        origin.x + dir.x * 0.45 + (Math.random() - 0.5) * 0.22,
        origin.y - 0.18 + dir.y * 0.35 + (Math.random() - 0.5) * 0.14,
        origin.z + dir.z * 0.45 + (Math.random() - 0.5) * 0.22,
      );
      mesh.scale.setScalar(0.045 + Math.random() * 0.035);
      mesh.rotation.set(Math.random() * 3, Math.random() * 3, 0);
      if (!mesh.parent) this.scene.add(mesh);
      const life = 0.28 + Math.random() * 0.22;
      this.particles.push({
        mesh,
        vx: dir.x * 0.8 + (Math.random() - 0.5) * 1.4,
        vy: 0.6 + Math.random() * 0.9,
        vz: dir.z * 0.8 + (Math.random() - 0.5) * 1.4,
        gravity: 9.5,
        life,
        max: life,
        rotSpeed: 4 + Math.random() * 4,
      });
    }
  }

  /** Sand/gravel flaking dust emitted when brushing Suspicious Sand or Suspicious Gravel. */
  brushDust(x: number, y: number, z: number, color: string, count = 12) {
    this.burst(new THREE.Vector3(x + 0.5, y + 0.55, z + 0.5), color, count, 1.9, 6.5);
  }

  drop(p: THREE.Vector3, name: string, count: number, color: string, stack?: Stack) {
    const hasBannerMeta = !!(stack && (stack.patterns?.length || stack.bannerBase));
    if (!hasBannerMeta) {
      for (let i = 0; i < this.drops.length; i++) {
        const ex = this.drops[i];
        if (ex.name === name && ex.count + count <= 64 && ex.mesh.position.distanceToSquared(p) < 0.75) {
          ex.count += count;
          return;
        }
      }
    }
    if (this.drops.length > 80) {
      this.release(this.drops[0].mesh);
      this.drops.shift();
    }
    const isBannerLike = hasBannerMeta && (name === 'shield' || name.endsWith('_banner'));
    const isBlock = !isBannerLike && ID[name] !== undefined && BLOCKS[ID[name]]?.shape === 'cube';
    const mesh = this.acquire(this.dropMaterial(name, color, stack));
    mesh.position.copy(p);
    mesh.rotation.set(0, 0, 0);
    if (isBannerLike) mesh.scale.set(0.24, 0.42, 0.06);
    else if (isBlock) mesh.scale.set(0.24, 0.24, 0.24);
    else mesh.scale.set(0.26, 0.26, 0.05);
    if (!mesh.parent) this.scene.add(mesh);
    this.drops.push({
      mesh,
      name,
      count,
      vx: (Math.random() - 0.5) * 2.2,
      vy: 3.1,
      vz: (Math.random() - 0.5) * 2.2,
      age: 0,
      baseY: p.y,
    });
  }

  /** Removes (one of) the nearest resting drop within `r` that `accept` likes — used by mobs that pick up armour / weapons. */
  takeNear(p: THREE.Vector3, r: number, accept: (name: string) => boolean): { name: string; count: number } | null {
    let bi = -1, bd = r * r;
    for (let i = 0; i < this.drops.length; i++) {
      const d = this.drops[i];
      if (d.age < 0.7) continue;
      const dd = d.mesh.position.distanceToSquared(p);
      if (dd < bd && accept(d.name)) { bd = dd; bi = i; }
    }
    if (bi < 0) return null;
    const d = this.drops[bi], name = d.name;
    if (d.count > 1) d.count--;
    else { this.release(d.mesh); const last = this.drops.length - 1; if (bi !== last) this.drops[bi] = this.drops[last]; this.drops.pop(); }
    return { name, count: 1 };
  }

  update(
    dt: number,
    floor: (x: number, y: number, z: number) => number,
    pickup: (name: string, count: number, position: THREE.Vector3) => boolean,
    playerPos?: THREE.Vector3,
  ) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.release(p.mesh);
        const last = this.particles.length - 1;
        if (i !== last) this.particles[i] = this.particles[last];
        this.particles.pop();
        continue;
      }
      p.vy -= p.gravity * dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      p.mesh.rotation.x += dt * p.rotSpeed;
      p.mesh.rotation.y += dt * p.rotSpeed * 0.6;
      const scaleDecay = Math.max(0.1, 1 - dt * 0.85);
      p.mesh.scale.multiplyScalar(scaleDecay);
    }

    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.age += dt;
      d.vy -= 12 * dt;

      // Magnetic pull toward nearby player after 0.6s
      if (playerPos && d.age > 0.6) {
        const dx = playerPos.x - d.mesh.position.x;
        const dy = playerPos.y + 0.6 - d.mesh.position.y;
        const dz = playerPos.z - d.mesh.position.z;
        const dist = Math.hypot(dx, dy, dz);
        if (dist < 2.6 && dist > 0.05) {
          const pull = (1 - dist / 2.6) * 9 * dt;
          d.mesh.position.x += (dx / dist) * pull;
          d.mesh.position.y += (dy / dist) * pull;
          d.mesh.position.z += (dz / dist) * pull;
        }
      }

      const nx = d.mesh.position.x + d.vx * dt;
      const ny = d.mesh.position.y + d.vy * dt;
      const nz = d.mesh.position.z + d.vz * dt;
      const below = floor(nx, ny - 0.14, nz);
      if (below > 0 && below !== ID.water) {
        d.vy = 0;
        d.vx *= 0.78;
        d.vz *= 0.78;
        d.baseY = Math.floor(ny - 0.14) + 1.15;
        d.mesh.position.set(nx, d.baseY + Math.sin(d.age * 3.2) * 0.055, nz);
      } else {
        d.mesh.position.set(nx, ny, nz);
      }
      d.mesh.rotation.y += dt * 1.9;

      if ((d.age > 0.7 && pickup(d.name, d.count, d.mesh.position)) || d.age > 300) {
        this.release(d.mesh);
        const last = this.drops.length - 1;
        if (i !== last) this.drops[i] = this.drops[last];
        this.drops.pop();
      }
    }
  }

  clear() {
    for (const p of this.particles) this.release(p.mesh);
    for (const d of this.drops) this.release(d.mesh);
    this.particles = [];
    this.drops = [];
  }

  dispose() {
    this.clear();
    for (const m of this.pool) this.scene.remove(m);
    this.pool = [];
    this.geometry.dispose();
    this.materials.forEach(m => m.dispose());
    this.dropMaterials.forEach(m => m.dispose());
  }
}
