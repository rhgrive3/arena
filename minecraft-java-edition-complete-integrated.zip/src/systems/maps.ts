// Explorer maps: 128×128 colour grids that fill in while the holder walks (Java's MapItem.update / MapItemSavedData).
// Each pixel stores (paletteIndex + 1) << 2 | brightness, brightness following MapColor.Brightness (LOWEST 135, LOW 180, NORMAL 220, HIGH 255).
export const MAP_SIZE = 128;
const BRIGHT = [180, 220, 255, 135];            // LOW, NORMAL, HIGH, LOWEST — the index is the 2-bit shade stored in the pixel
const LOW = 0, NORMAL = 1, HIGH = 2;

export interface MapData {
  id: number; dim: string; cx: number; cz: number; scale: number; locked: boolean;
  pal: string[]; px: Uint8Array; step: number; version: number;
}
export interface MapSample { color: string; y: number; water?: boolean; depth?: number }

/** Java: a fresh map covers 128·2^scale blocks, aligned to a grid so neighbouring maps tile. */
export function newMap(id: number, dim: string, x: number, z: number, scale = 0): MapData {
  const span = MAP_SIZE * (1 << scale), gx = Math.floor((x + 64) / span), gz = Math.floor((z + 64) / span);
  return { id, dim, cx: gx * span + span / 2 - 64, cz: gz * span + span / 2 - 64, scale, locked: false, pal: [], px: new Uint8Array(MAP_SIZE * MAP_SIZE), step: 0, version: 0 };
}
const palIndex = (m: MapData, color: string): number => {
  let i = m.pal.indexOf(color);
  if (i < 0) { if (m.pal.length >= 63) return 0; i = m.pal.push(color) - 1; }
  return i;
};
const setPixel = (m: MapData, x: number, y: number, color: string, shade: number): boolean => {
  const v = ((palIndex(m, color) + 1) << 2) | shade, o = y * MAP_SIZE + x;
  if (m.px[o] === v) return false;
  m.px[o] = v; m.version++;
  return true;
};
export const isExplored = (m: MapData, x: number, y: number) => m.px[y * MAP_SIZE + x] !== 0;
export const exploredCount = (m: MapData) => { let n = 0; for (let i = 0; i < m.px.length; i++) if (m.px[i]) n++; return n; };

/**
 * One tick of map painting around the holder. Like Java only 1/16 of the columns is repainted per call, so a full sweep takes
 * 16 calls. `sample(x, z)` returns the top-most map-coloured block of a world column (or null when it isn't loaded).
 * `limit` caps the painted radius in blocks (the "loaded chunks" of this world). Nether maps (ceiling dimensions) show Java's
 * dirt/stone noise instead of terrain, with half the radius.
 */
export function updateMap(m: MapData, px: number, pz: number, sample: (x: number, z: number) => MapSample | null, limit = 128): boolean {
  if (m.locked) return false;
  const k = 1 << m.scale, ceiling = m.dim === 'nether';
  const l = Math.floor((px - m.cx) / k) + 64, i1 = Math.floor((pz - m.cz) / k) + 64;
  let j1 = Math.min(MAP_SIZE / k, Math.max(2, Math.floor(limit / k)));
  if (ceiling) j1 = Math.max(2, Math.floor(j1 / 2));
  m.step++;
  let changed = false, flag = false;
  for (let c = l - j1 + 1; c < l + j1; c++) {
    if (!((c & 15) === (m.step & 15) || flag)) continue;
    flag = false;
    let d0 = 0;
    for (let r = i1 - j1 - 1; r < i1 + j1; r++) {
      if (c < 0 || r < -1 || c >= MAP_SIZE || r >= MAP_SIZE) continue;
      const dx = c - l, dz = r - i1, outer = dx * dx + dz * dz > (j1 - 2) * (j1 - 2);
      const wx = (Math.floor(m.cx / k) + c - 64) * k, wz = (Math.floor(m.cz / k) + r - 64) * k;
      let color = '', depth = 0, avgY = 0, water = false;
      if (ceiling) {
        let h = wx + wz * 231871; h = (Math.imul(h, h) * 31287121 + h * 11) | 0;
        color = ((h >> 20) & 1) === 0 ? '#976d4d' : '#707070'; avgY = 100;
      } else {
        const tally = new Map<string, number>();
        let n = 0;
        for (let a = 0; a < k; a++) for (let b = 0; b < k; b++) {
          const s = sample(wx + a, wz + b);
          if (!s) continue;
          n++; avgY += s.y; tally.set(s.color, (tally.get(s.color) ?? 0) + 1);
          if (s.water) { depth += s.depth ?? 1; water = true; }
        }
        if (!n) { d0 = avgY; continue; }
        avgY /= n; depth /= n;
        let best = 0;
        for (const [col, cnt] of tally) if (cnt > best) { best = cnt; color = col; }
        water = color === '#4040ff';
      }
      let shade = NORMAL;
      if (water) { const d2 = depth * 0.1 + ((c + r) & 1) * 0.2; shade = d2 < 0.5 ? HIGH : d2 > 0.9 ? LOW : NORMAL; }
      else { const d4 = ((avgY - d0) * 4) / (k + 4) + (((c + r) & 1) - 0.5) * 0.4; shade = d4 > 0.6 ? HIGH : d4 < -0.6 ? LOW : NORMAL; }
      d0 = avgY;
      if (r >= 0 && dx * dx + dz * dz < j1 * j1 && (!outer || ((c + r) & 1) !== 0)) { if (setPixel(m, c, r, color, shade)) { changed = true; flag = true; } }
    }
  }
  return changed;
}
/** RGBA bytes for the whole map (unexplored pixels are transparent). */
export function mapRGBA(m: MapData, out = new Uint8ClampedArray(MAP_SIZE * MAP_SIZE * 4)): Uint8ClampedArray {
  const rgb = m.pal.map(h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]);
  for (let i = 0; i < m.px.length; i++) {
    const v = m.px[i], o = i * 4;
    if (!v) { out[o] = out[o + 1] = out[o + 2] = out[o + 3] = 0; continue; }
    const c = rgb[(v >> 2) - 1] ?? [127, 127, 127], b = BRIGHT[v & 3] / 255;
    out[o] = c[0] * b; out[o + 1] = c[1] * b; out[o + 2] = c[2] * b; out[o + 3] = 255;
  }
  return out;
}
/** Cartography "zoom out": a new map, one scale larger, centred like a fresh map and keeping what was already drawn. */
export function zoomedOut(old: MapData, id: number): MapData {
  const m = newMap(id, old.dim, old.cx, old.cz, Math.min(4, old.scale + 1));
  m.pal = [...old.pal];
  const k = 1 << old.scale, nk = 1 << m.scale;
  for (let y = 0; y < MAP_SIZE; y++) for (let x = 0; x < MAP_SIZE; x++) {
    const v = old.px[y * MAP_SIZE + x];
    if (!v) continue;
    const wx = (Math.floor(old.cx / k) + x - 64) * k, wz = (Math.floor(old.cz / k) + y - 64) * k;
    const nx = Math.floor(wx / nk) - Math.floor(m.cx / nk) + 64, nz = Math.floor(wz / nk) - Math.floor(m.cz / nk) + 64;
    if (nx >= 0 && nx < MAP_SIZE && nz >= 0 && nz < MAP_SIZE) m.px[nz * MAP_SIZE + nx] = v;
  }
  return m;
}
export function lockedCopy(old: MapData, id: number): MapData {
  return { ...old, id, locked: true, pal: [...old.pal], px: old.px.slice(), step: 0, version: 0 };
}
export function serializeMap(m: MapData) {
  let bin = '';
  for (let i = 0; i < m.px.length; i += 8192) bin += String.fromCharCode(...m.px.subarray(i, i + 8192));
  return { id: m.id, dim: m.dim, cx: m.cx, cz: m.cz, scale: m.scale, locked: m.locked, pal: m.pal, px: typeof btoa === 'function' ? btoa(bin) : Buffer.from(bin, 'binary').toString('base64') };
}
export type MapSave = ReturnType<typeof serializeMap>;
export function deserializeMap(s: MapSave): MapData {
  const bin = typeof atob === 'function' ? atob(s.px) : Buffer.from(s.px, 'base64').toString('binary'), px = new Uint8Array(MAP_SIZE * MAP_SIZE);
  for (let i = 0; i < px.length && i < bin.length; i++) px[i] = bin.charCodeAt(i);
  return { id: s.id, dim: s.dim, cx: s.cx, cz: s.cz, scale: s.scale, locked: s.locked, pal: s.pal, px, step: 0, version: 1 };
}
/** Marker position of a world coordinate in map pixels (null when outside the map). */
export function mapMarker(m: MapData, x: number, z: number): [number, number] | null {
  const k = 1 << m.scale, mx = (x - m.cx) / k + 64, mz = (z - m.cz) / k + 64;
  return mx >= 0 && mx < MAP_SIZE && mz >= 0 && mz < MAP_SIZE ? [mx, mz] : null;
}
