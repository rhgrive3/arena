import type { Stack } from '../game/types';
import { resolve } from '../game/data';
import { matchGrid } from './crafting';

export function insertStack(slots: (Stack | null)[], stack: Stack, disabled = 0, allowed?: number[]): boolean {
  const max = resolve(stack.name)?.stack ?? 64;
  const compatible = (s: Stack) =>
    s.name === stack.name &&
    s.label === stack.label &&
    JSON.stringify(s.ench) === JSON.stringify(stack.ench) &&
    s.durability === stack.durability;
  const canUse = (i: number) => !(disabled & (1 << i)) && (!allowed || allowed.includes(i));
  const i = slots.findIndex((s, idx) => canUse(idx) && s && compatible(s) && s.count + stack.count <= max);
  if (i >= 0) {
    slots[i]!.count += stack.count;
    return true;
  }
  const empty = slots.findIndex((s, idx) => !s && canUse(idx));
  if (empty < 0 || stack.count > max) return false;
  slots[empty] = { ...stack };
  return true;
}

export function transferOne(
  source: (Stack | null)[],
  destination: (Stack | null)[],
  disabled = 0,
  balanced = false,
  fromSideOrAllowed?: boolean | number[],
  allowedSrc?: number[],
): boolean {
  if (source === destination) return false;
  const srcIndices = allowedSrc ?? (source.length === 3 && destination.length === 5 ? [2] : source.map((_, i) => i));
  let srcIdx = -1;
  for (const idx of srcIndices) {
    if (source[idx]) { srcIdx = idx; break; }
  }
  if (srcIdx < 0) return false;
  const allowedDest: number[] | undefined = Array.isArray(fromSideOrAllowed)
    ? fromSideOrAllowed
    : destination.length === 3 && !balanced
    ? [fromSideOrAllowed ? 1 : 0]
    : undefined;
  const stack = source[srcIdx]!;
  if (balanced) {
    const max = resolve(stack.name)?.stack ?? 64;
    const candidates = destination
      .map((s, j) => ({ s, j }))
      .filter(({ s, j }) => !(disabled & (1 << j)) && (!allowedDest || allowedDest.includes(j)) && (!s || (s.name === stack.name && s.count < max)))
      .sort((a, b) => (a.s?.count ?? 0) - (b.s?.count ?? 0));
    if (!candidates.length) return false;
    const dest = candidates[0].j;
    if (destination[dest]) destination[dest]!.count++;
    else destination[dest] = { ...stack, count: 1 };
  } else if (!insertStack(destination, { ...stack, count: 1 }, disabled, allowedDest)) {
    return false;
  }
  stack.count--;
  if (stack.count <= 0) source[srcIdx] = null;
  return true;
}

export function findCrafterRecipe(slots: (Stack | null)[], disabled = 0) {
  return matchGrid(slots.slice(0, 9).map(s => s?.name ?? null), disabled) ?? undefined;
}
