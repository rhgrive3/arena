#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
for s in test-fidelity test-survival test-redstone test-redstone2 test-farming test-mobs test-living-world verify-biomes test-behaviors test-realism test-graphics-ui test-tricky-trials test-gameplay test-vanilla-plus; do
  echo "=== $s ==="
  npx esbuild "scripts/$s.ts" --bundle --platform=node --external:three --outfile="/tmp/mc-$s.cjs" --log-level=error
  node "/tmp/mc-$s.cjs"
done
