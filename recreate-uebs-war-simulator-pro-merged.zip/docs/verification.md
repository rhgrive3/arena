# 動作確認・検証手順

## 実行方法

```sh
npm install
npm run dev
npx tsc --noEmit
npx tsx --test tests/simulation.test.ts tests/units.test.ts tests/rendering.test.ts tests/refinements.test.ts tests/effects.test.ts
npx playwright install --with-deps chromium
npm run build
TEST_PRODUCTION=1 npx playwright test
```

## 確認対象

- `tests/refinements.test.ts`: 正面盾防御とブロックイベント、側背面1.3倍ダメージ、王の鼓舞オーラ（近接・射撃+30%実ダメージ適用）、重騎兵の初撃突撃ボーナス（最大1.5倍）、吸血鬼の実ダメージ上限に応じたHP吸収、呪術師・氷の術師の移動・溜め・クールダウン減速、聖騎士の前進と複数味方の範囲回復、1クリック自動編成と一括取り消し、4種の戦術陣形（方陣・横陣・楔陣・散開）、個体別撃破・与ダメージ計測とMVP選出、両軍編成と全消去、各章の地形障害物判定と自動迂回。
- `tests/simulation.test.ts`: 固定予算、50体上限、全31兵種の命中・索敵、配置・取り消し、1x/2x/4x倍速一致、一時停止、再開始。
- `tests/units.test.ts`: 5勢力・全31兵種の編成・全20ステージ解放順、無策な単一兵種スパムに対する難易度ガード、戦術的な混成部隊による全20ステージ攻略検証、致死ダメージ時の死体吹っ飛び物理。
- `tests/rendering.test.ts`: 全31兵種の骨格、頂点カラー、インスタンス描画、騎兵の向き、4章すべての3D戦場環境構築とリソース解放。
- `tests/effects.test.ts`: 指向性ヒット火花、多層爆発エフェクト、分岐雷撃、血飛沫と地面血痕、InstancedMeshによるドローコール上限維持。
- `tests/browser.spec.ts`: PC・タッチ操作、カメラモード（左半分移動・右半分回転）、ピンチズーム、長押し範囲選択およびワンタップ範囲選択ボタン、カスタム戦の両軍配置・全消去・戦場マップ切替、横スクロールとモバイル・ランドスケープ表示。
