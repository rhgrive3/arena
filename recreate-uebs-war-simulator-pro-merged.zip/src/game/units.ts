import * as THREE from "three";

// Original unit roster. Designs and stats are this project's own.

export type UnitKind =
  // kingdom
  | "spear" | "guardian" | "archer" | "crossbow" | "swordsman" | "halberdier" | "knight" | "paladin" | "king"
  // warband
  | "orc" | "berserker" | "javelin" | "bomber" | "shaman" | "troll" | "giant" | "pirate"
  // mystic
  | "elf" | "monk" | "assassin" | "mage" | "frost" | "cleric" | "zeus"
  // undead
  | "zombie" | "skeleton" | "bonearcher" | "vampire"
  // machines
  | "robot" | "tank" | "railgun";
export type TeamId = 0 | 1;
export type Faction = "kingdom" | "warband" | "mystic" | "undead" | "machine";
export type ProjectileStyle = "arrow" | "quarrel" | "bolt" | "bomb" | "javelin" | "pistol" | "cannon" | "rail";

export interface UnitDef {
  kind: UnitKind;
  faction: Faction;
  name: string;
  en: string;
  role: string;
  cost: number;
  hp: number;
  dmg: number;
  range: number;
  speed: number;
  windup: number;
  cooldown: number;
  aggro: number;
  ranged: boolean;
  radius: number;
  height: number;
  armor: number;
  /** Extra damage reduction when struck from the front. */
  shield?: number;
  /** Knockback this unit delivers. */
  impact: number;
  /** Resistance to being knocked around. */
  mass: number;
  projSpeed?: number;
  proj?: ProjectileStyle;
  aoe?: number;
  cleave?: number;
  heal?: number;
  healRange?: number;
  hunter?: boolean;
  rage?: boolean;
  slow?: number;
  lifesteal?: number;
  regen?: number;
  /** Aura buff: +damage% applied to allies within range. */
  buff?: number;
  buffRange?: number;
  /** Chain lightning: jumps to nearby extra enemies. */
  chain?: number;
  /** Pierces the first N targets it hits. */
  pierce?: number;
  /** Summons a temporary fighting drone on deploy. */
  drone?: number;
  desc: string;
  icon: string;
}

const D = (u: UnitDef) => u;

export const DEFS: Record<UnitKind, UnitDef> = {
  spear: D({ kind: "spear", faction: "kingdom", name: "槍兵", en: "SPEARMAN", role: "前衛", cost: 50, hp: 130, dmg: 14, range: 3.2,
    speed: 4.0, windup: 0.6, cooldown: 0.55, aggro: 16, ranged: false, radius: 0.52, height: 2.3, armor: 0, impact: 2.8, mass: 1.0,
    desc: "長い槍で先手を取る基本歩兵。", icon: "spear" }),
  guardian: D({ kind: "guardian", faction: "kingdom", name: "盾兵", en: "SHIELD GUARD", role: "壁", cost: 70, hp: 200, dmg: 9, range: 2.6,
    speed: 3.4, windup: 0.7, cooldown: 0.75, aggro: 14, ranged: false, radius: 0.6, height: 2.4, armor: 0.35, shield: 0.25, impact: 3.2, mass: 1.6,
    desc: "大盾で正面の矢や斬撃を受け止める。", icon: "shield" }),
  archer: D({ kind: "archer", faction: "kingdom", name: "弓兵", en: "ARCHER", role: "射撃", cost: 75, hp: 85, dmg: 16, range: 20,
    speed: 3.6, windup: 0.9, cooldown: 0.7, aggro: 22, ranged: true, radius: 0.5, height: 2.3, armor: 0, impact: 1.2, mass: 0.9,
    projSpeed: 26, proj: "arrow",
    desc: "味方の後ろから弓で援護する。", icon: "bow" }),
  crossbow: D({ kind: "crossbow", faction: "kingdom", name: "弩兵", en: "CROSSBOWMAN", role: "重射撃", cost: 95, hp: 95, dmg: 34, range: 24,
    speed: 3.2, windup: 1.5, cooldown: 1.4, aggro: 24, ranged: true, radius: 0.54, height: 2.3, armor: 0.05, impact: 3.6, mass: 1.0,
    projSpeed: 46, proj: "quarrel",
    desc: "装填は遅いが、弾速と貫通力が高い。", icon: "crossbow" }),
  swordsman: D({ kind: "swordsman", faction: "kingdom", name: "剣士", en: "SWORDSMAN", role: "近接", cost: 65, hp: 145, dmg: 16, range: 2.4,
    speed: 4.5, windup: 0.45, cooldown: 0.45, aggro: 17, ranged: false, radius: 0.54, height: 2.3, armor: 0.1, shield: 0.15, impact: 3.4, mass: 1.1,
    desc: "小盾を持ち、素早い斬撃で押す。", icon: "sword" }),
  halberdier: D({ kind: "halberdier", faction: "kingdom", name: "戟兵", en: "HALBERDIER", role: "対騎兵", cost: 85, hp: 165, dmg: 23, range: 3.8,
    speed: 3.8, windup: 0.75, cooldown: 0.8, aggro: 17, ranged: false, radius: 0.56, height: 2.4, armor: 0.15, impact: 6.4, mass: 1.4,
    desc: "長い斧槍で騎兵や巨漢を食い止める。", icon: "halberd" }),
  knight: D({ kind: "knight", faction: "kingdom", name: "重騎兵", en: "HEAVY CAVALRY", role: "突撃", cost: 200, hp: 380, dmg: 62, range: 3.7,
    speed: 6.8, windup: 0.2, cooldown: 1.2, aggro: 22, ranged: false, radius: 1.05, height: 3.1, armor: 0.22, impact: 11.5, mass: 3.2,
    desc: "助走に応じて初撃が強化される重騎兵。突撃こそ本領。", icon: "horse" }),
  paladin: D({ kind: "paladin", faction: "kingdom", name: "聖騎士", en: "PALADIN", role: "英雄", cost: 225, hp: 480, dmg: 45, range: 2.9,
    speed: 4.4, windup: 0.78, cooldown: 0.9, aggro: 18, ranged: false, radius: 0.72, height: 2.7, armor: 0.35, shield: 0.2, impact: 9.5, mass: 2.2,
    heal: 13, healRange: 6.5,
    desc: "前線で戦いながら、少量の回復を周囲に撒き散らす。", icon: "paladin" }),
  king: D({ kind: "king", faction: "kingdom", name: "王", en: "THE KING", role: "指揮官", cost: 300, hp: 620, dmg: 40, range: 3.0,
    speed: 3.9, windup: 0.85, cooldown: 1.0, aggro: 16, ranged: false, radius: 0.82, height: 3.0, armor: 0.3, shield: 0.2, impact: 10.0, mass: 2.6,
    buff: 0.3, buffRange: 11,
    desc: "王の威光で周囲の味方が30%強く戦う。", icon: "crown" }),

  orc: D({ kind: "orc", faction: "warband", name: "オーク戦士", en: "ORC WARRIOR", role: "前衛", cost: 60, hp: 200, dmg: 22, range: 2.7,
    speed: 4.3, windup: 0.75, cooldown: 0.6, aggro: 16, ranged: false, radius: 0.66, height: 2.7, armor: 0, impact: 5.2, mass: 1.6,
    desc: "タフな体格と大斧で力押しする。", icon: "axe" }),
  berserker: D({ kind: "berserker", faction: "warband", name: "狂戦士", en: "BERSERKER", role: "速攻", cost: 80, hp: 155, dmg: 17, range: 2.5,
    speed: 5.4, windup: 0.42, cooldown: 0.34, aggro: 18, ranged: false, radius: 0.58, height: 2.5, armor: 0, impact: 4.2, mass: 1.2, rage: true,
    desc: "体力が減るほど攻撃が速くなる。", icon: "axes" }),
  javelin: D({ kind: "javelin", faction: "warband", name: "投槍兵", en: "JAVELINEER", role: "投擲", cost: 70, hp: 105, dmg: 30, range: 15,
    speed: 4.2, windup: 1.0, cooldown: 1.5, aggro: 20, ranged: true, radius: 0.54, height: 2.4, armor: 0, impact: 5.8, mass: 1.0,
    projSpeed: 20, proj: "javelin",
    desc: "重い投げ槍で敵の体勢を崩す。", icon: "javelin" }),
  bomber: D({ kind: "bomber", faction: "warband", name: "爆弾兵", en: "BOMBER", role: "範囲", cost: 110, hp: 80, dmg: 42, range: 16,
    speed: 3.6, windup: 1.1, cooldown: 1.9, aggro: 20, ranged: true, radius: 0.52, height: 2.3, armor: 0, impact: 9.2, mass: 0.9,
    projSpeed: 15, proj: "bomb", aoe: 3.4,
    desc: "爆弾を放り、密集した敵を吹き飛ばす。", icon: "bomb" }),
  shaman: D({ kind: "shaman", faction: "warband", name: "呪術師", en: "SHAMAN", role: "呪い", cost: 120, hp: 100, dmg: 20, range: 17,
    speed: 3.4, windup: 1.2, cooldown: 1.1, aggro: 20, ranged: true, radius: 0.52, height: 2.5, armor: 0, impact: 3.0, mass: 0.9,
    projSpeed: 19, proj: "bolt", aoe: 2.4, slow: 2.5,
    desc: "呪いの弾で敵の移動と攻撃を鈍らせる。", icon: "shaman" }),
  troll: D({ kind: "troll", faction: "warband", name: "トロール", en: "TROLL", role: "再生", cost: 250, hp: 580, dmg: 46, range: 3.4,
    speed: 3.2, windup: 1.2, cooldown: 1.25, aggro: 18, ranged: false, radius: 0.9, height: 4.2, armor: 0.1, impact: 11.0, mass: 5.0, regen: 8,
    cleave: 2.5,
    desc: "受けた傷が自動で再生し続ける巨体。", icon: "fist" }),
  giant: D({ kind: "giant", faction: "warband", name: "巨人", en: "GIANT", role: "超重量", cost: 280, hp: 920, dmg: 70, range: 3.8,
    speed: 3.0, windup: 1.3, cooldown: 1.4, aggro: 18, ranged: false, radius: 0.95, height: 4.6, armor: 0.15, impact: 16.0, mass: 7.0, cleave: 3.2,
    desc: "大棍棒で周辺の敵ごと叩き飛ばす。", icon: "giant" }),
  pirate: D({ kind: "pirate", faction: "warband", name: "海賊", en: "PIRATE", role: "銃砲", cost: 130, hp: 150, dmg: 38, range: 15,
    speed: 4.1, windup: 0.7, cooldown: 1.0, aggro: 20, ranged: true, radius: 0.56, height: 2.4, armor: 0.05, impact: 4.5, mass: 1.0,
    projSpeed: 38, proj: "pistol",
    desc: "火縄銃で中距離を狙撃する。", icon: "pirate" }),

  elf: D({ kind: "elf", faction: "mystic", name: "エルフ狩人", en: "ELVEN HUNTRESS", role: "長射程", cost: 90, hp: 75, dmg: 15, range: 26,
    speed: 4.8, windup: 0.8, cooldown: 0.55, aggro: 24, ranged: true, radius: 0.48, height: 2.3, armor: 0, impact: 1.2, mass: 0.8,
    projSpeed: 36, proj: "arrow",
    desc: "遠距離から素早く矢を連射する。", icon: "leafbow" }),
  monk: D({ kind: "monk", faction: "mystic", name: "修道武僧", en: "MONK", role: "拳闘", cost: 75, hp: 150, dmg: 15, range: 2.3,
    speed: 5.0, windup: 0.35, cooldown: 0.4, aggro: 17, ranged: false, radius: 0.52, height: 2.4, armor: 0, impact: 4.0, mass: 1.1,
    desc: "素早い連撃で敵を押し返す武道家。", icon: "fist" }),
  assassin: D({ kind: "assassin", faction: "mystic", name: "影の刺客", en: "SHADOW BLADE", role: "暗殺", cost: 85, hp: 80, dmg: 32, range: 2.4,
    speed: 7.4, windup: 0.32, cooldown: 0.6, aggro: 36, ranged: false, radius: 0.48, height: 2.2, armor: 0, impact: 3.0, mass: 0.8, hunter: true,
    desc: "高速で裏へ回り、射手や術師を狙う。", icon: "dagger" }),
  mage: D({ kind: "mage", faction: "mystic", name: "魔術師", en: "WIZARD", role: "範囲魔法", cost: 135, hp: 75, dmg: 25, range: 18,
    speed: 3.2, windup: 1.35, cooldown: 1.05, aggro: 20, ranged: true, radius: 0.52, height: 2.9, armor: 0, impact: 3.4, mass: 0.9,
    projSpeed: 22, proj: "bolt", aoe: 2.6,
    desc: "追尾する魔弾で着弾点の敵をまとめて焼く。", icon: "orb" }),
  frost: D({ kind: "frost", faction: "mystic", name: "氷の術師", en: "FROST WEAVER", role: "足止め", cost: 130, hp: 90, dmg: 18, range: 19,
    speed: 3.2, windup: 1.0, cooldown: 1.0, aggro: 20, ranged: true, radius: 0.52, height: 2.8, armor: 0, impact: 2.0, mass: 0.9,
    projSpeed: 24, proj: "bolt", aoe: 2.4, slow: 3.2,
    desc: "氷の魔弾で敵の足を止める。", icon: "frost" }),
  cleric: D({ kind: "cleric", faction: "mystic", name: "僧侶", en: "CLERIC", role: "回復", cost: 100, hp: 100, dmg: 5, range: 2.4,
    speed: 3.8, windup: 0.8, cooldown: 0.9, aggro: 14, ranged: false, radius: 0.52, height: 2.5, armor: 0, impact: 1.0, mass: 0.9,
    heal: 32, healRange: 11,
    desc: "後方に控え、負傷した味方を回復する。", icon: "cross" }),
  zeus: D({ kind: "zeus", faction: "mystic", name: "ゼウス", en: "ZEUS", role: "雷神", cost: 500, hp: 420, dmg: 118, range: 23,
    speed: 3.4, windup: 1.05, cooldown: 1.35, aggro: 22, ranged: true, radius: 0.82, height: 3.5, armor: 0.18, impact: 8.5, mass: 1.8,
    projSpeed: 70, proj: "bolt", aoe: 3.6, chain: 5,
    desc: "雷霆の槍を投げ、雷が次々と敵を走る。", icon: "zeus" }),

  robot: D({ kind: "robot", faction: "machine", name: "戦闘ロボット", en: "BATTLE ROBOT", role: "機械近接", cost: 150, hp: 420, dmg: 30, range: 2.5,
    speed: 4.6, windup: 0.55, cooldown: 0.6, aggro: 18, ranged: false, radius: 0.62, height: 2.6, armor: 0.3, impact: 6.5, mass: 2.4,
    desc: "鋼鉄の躯体で突進する。守りは堅いが打撃は並。", icon: "robot" }),
  tank: D({ kind: "tank", faction: "machine", name: "戦車", en: "TANK", role: "重砲", cost: 340, hp: 1150, dmg: 95, range: 17,
    speed: 2.4, windup: 1.6, cooldown: 2.2, aggro: 18, ranged: true, radius: 1.05, height: 2.8, armor: 0.4, impact: 14.0, mass: 8.0,
    projSpeed: 26, proj: "cannon", aoe: 3.6, pierce: 1,
    desc: "大砲で直線上を薙ぎ払う。装甲の厚さは並の攻撃では通用しない。", icon: "tank" }),
  railgun: D({ kind: "railgun", faction: "machine", name: "レールガン", en: "RAILGUN", role: "超射程", cost: 260, hp: 180, dmg: 120, range: 30,
    speed: 2.9, windup: 2.0, cooldown: 2.4, aggro: 24, ranged: true, radius: 0.6, height: 2.4, armor: 0.05, impact: 8.0, mass: 2.0,
    projSpeed: 85, proj: "rail", pierce: 3,
    desc: "超長射程の貫通砲。装填に時間がかかるが、列を射抜く。", icon: "railgun" }),

  zombie: D({ kind: "zombie", faction: "undead", name: "ゾンビ", en: "ZOMBIE", role: "物量", cost: 20, hp: 65, dmg: 8, range: 2.0,
    speed: 2.4, windup: 0.85, cooldown: 0.7, aggro: 13, ranged: false, radius: 0.52, height: 2.2, armor: 0, impact: 1.4, mass: 0.9,
    desc: "足は遅いが、安く数を並べられる。", icon: "skull" }),
  skeleton: D({ kind: "skeleton", faction: "undead", name: "スケルトン", en: "SKELETON", role: "軽歩兵", cost: 30, hp: 75, dmg: 11, range: 2.6,
    speed: 3.8, windup: 0.55, cooldown: 0.6, aggro: 15, ranged: false, radius: 0.5, height: 2.4, armor: 0, impact: 2.0, mass: 0.6,
    desc: "軽く吹き飛びやすいが、数で戦える骨の剣士。", icon: "bone" }),
  bonearcher: D({ kind: "bonearcher", faction: "undead", name: "骨弓兵", en: "BONE ARCHER", role: "射撃", cost: 55, hp: 70, dmg: 13, range: 18,
    speed: 3.4, windup: 1.0, cooldown: 0.8, aggro: 21, ranged: true, radius: 0.5, height: 2.4, armor: 0, impact: 1.0, mass: 0.6,
    projSpeed: 24, proj: "arrow",
    desc: "安いコストで揃えられる骸骨の射手。", icon: "boneshot" }),
  vampire: D({ kind: "vampire", faction: "undead", name: "吸血鬼", en: "VAMPIRE", role: "英雄", cost: 180, hp: 360, dmg: 38, range: 2.6,
    speed: 5.6, windup: 0.5, cooldown: 0.55, aggro: 20, ranged: false, radius: 0.58, height: 2.5, armor: 0.15, impact: 6.0, mass: 1.2, lifesteal: 0.45,
    desc: "与えたダメージの一部を吸収し続ける。", icon: "vampire" }),
};

/** Pierce count for a unit kind (how many bodies a shot passes through). */
export function pierceFor(kind: UnitKind): number {
  return DEFS[kind].pierce ?? 0;
}

export interface FactionInfo { id: Faction; name: string; en: string; color: string; units: UnitKind[] }
export const FACTIONS: FactionInfo[] = [
  { id: "kingdom", name: "王国軍", en: "KINGDOM", color: "#6aa7f5", units: ["spear", "guardian", "archer", "swordsman", "crossbow", "halberdier", "knight", "paladin", "king"] },
  { id: "warband", name: "蛮族", en: "WARBAND", color: "#e48a4a", units: ["orc", "berserker", "javelin", "bomber", "shaman", "troll", "giant", "pirate"] },
  { id: "mystic", name: "神秘", en: "MYSTIC", color: "#b58cff", units: ["elf", "monk", "assassin", "mage", "frost", "cleric", "zeus"] },
  { id: "undead", name: "不死", en: "UNDEAD", color: "#9fc27a", units: ["zombie", "skeleton", "bonearcher", "vampire"] },
  { id: "machine", name: "機械", en: "MACHINE", color: "#8fa2b8", units: ["robot", "tank", "railgun"] },
];
export const FACTION_UNITS: Record<Faction, UnitKind[]> = Object.fromEntries(FACTIONS.map(f => [f.id, f.units])) as Record<Faction, UnitKind[]>;
export const DEPLOY: UnitKind[] = FACTIONS.flatMap(f => f.units);
export const ALL_KINDS: UnitKind[] = DEPLOY;

export const TEAM_COLORS = [0x3f7fd6, 0xd0453a];
export const TEAM_COLORS_CSS = ["#5f9bea", "#e8604f"];
export const START_GOLD = 600;
export const GOLD_CAP = 3000;
export const SANDBOX_BUDGET = 3000;
export const MAX_PER_TEAM = 50;
export const MAX_TOTAL = 100;
export const FIELD = { x: 78, z: 52 };

/* ============ shared geometry & materials ============ */

export const GEO = {
  box: new THREE.BoxGeometry(1, 1, 1),
  sph: new THREE.SphereGeometry(1, 12, 9),
  cyl: new THREE.CylinderGeometry(1, 1, 1, 10),
  cone: new THREE.ConeGeometry(1, 1, 10),
  quadCone: new THREE.ConeGeometry(1, 1, 4),
  dome: new THREE.SphereGeometry(1, 14, 7, 0, Math.PI * 2, 0, Math.PI / 2),
  tor: new THREE.TorusGeometry(1, 0.11, 6, 14, Math.PI),
  ring: new THREE.TorusGeometry(1, 0.06, 6, 20),
};

const matCache = new Map<string, THREE.MeshStandardMaterial>();
export function M(color: number, rough = 0.85, metal = 0.08): THREE.MeshStandardMaterial {
  const key = `${color}|${rough}|${metal}`;
  let m = matCache.get(key);
  if (!m) {
    m = new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
    matCache.set(key, m);
  }
  return m;
}
