// Smoke test for the v11 player systems (survival.ts / magic.ts) against a minimal mock engine. Run with esbuild + node.
import * as THREE from 'three';
import '../src/game/content';
import { ID, resolve } from '../src/game/data';
import * as SV from '../src/game/survival';
import * as V from '../src/game/vanilla';
import { STONECUT } from '../src/systems/crafting';
import { EXTRA_LOOT } from '../src/world/structures';

let pass = 0, fail = 0;
const ok = (name: string, cond: boolean, info: unknown = '') => { if (cond) pass++; else fail++; console.log((cond ? 'PASS  ' : 'FAIL  ') + name + (cond ? '' : '  → ' + JSON.stringify(info))); };
const shots: any[] = [], screens: string[] = [];
const mob = { species: 'zombie', group: { position: new THREE.Vector3(2, 64, 0) }, hp: 100 };
const stores: Record<string, { edits: Map<string, number>; editsByChunk: Map<string, Map<string, number>> }> = { overworld: { edits: new Map(), editsByChunk: new Map() }, nether: { edits: new Map(), editsByChunk: new Map() } };
function make(): any {
  const e: any = {
    meta: { mode: 'survival', difficulty: 'normal', seed: '1', id: 'x' }, hotbar: Array(9).fill(null), inventory: Array(27).fill(null), armor: [null, null, null, null], offhand: null,
    effects: {}, absorption: 0, health: 20, hunger: 20, xp: 0, lastLevel: 0, selected: 0, elapsed: 100, attackAt: -10, swingHeld: false, useTime: 0, useItemName: '', blocking: false, enchantSeed: 5, portalLock: false,
    levitationTimer: 0, dead: false, grounded: true, gliding: false, elytraEquipped: false, handDip: 0, hitFlash: 0, weather: 'clear', dimension: 'overworld', statistics: {}, containers: {}, furnaces: {}, stationKey: '0,64,0', portalCharge: 0,
    position: new THREE.Vector3(0, 64, 0), velocity: new THREE.Vector3(), camera: new THREE.PerspectiveCamera(), input: { useHeld: false, crouch: false, run: false }, target: null, dragonDefeated: false,
    edits: stores.overworld.edits, editsByChunk: stores.overworld.editsByChunk, terrain: { seed: 1, height: () => 70 },
    onToast() {}, onScreen(s: string) { screens.push(s); }, pause() {}, achievement() {}, audio: null,
    particles: { burst() {}, drop() {}, spark() {} }, environment: { triggerLightning() {} },
    getBlock: (x: number, _y: number, z: number) => (Math.max(Math.abs(x), Math.abs(z)) === 2 ? ID.bookshelf : 0), setBlock: () => true, collides: () => false,
    countItem(n: string) { return [...this.hotbar, ...this.inventory].reduce((c: number, s: any) => c + (s?.name === n ? s.count : 0), 0); },
    removeItem(n: string, c: number) { if (this.countItem(n) < c) return false; for (const arr of [this.hotbar, this.inventory]) for (let i = 0; i < arr.length; i++) { const s = arr[i]; if (s?.name === n) { const k = Math.min(c, s.count); s.count -= k; c -= k; if (s.count <= 0) arr[i] = null; if (!c) return true; } } return true; },
    addItem(n: string, c: number) { for (const arr of [this.hotbar, this.inventory]) for (let i = 0; i < arr.length; i++) { if (arr[i]?.name === n && arr[i].count + c <= (resolve(n)?.stack ?? 64)) { arr[i].count += c; return true; } } for (const arr of [this.hotbar, this.inventory]) for (let i = 0; i < arr.length; i++) if (!arr[i]) { arr[i] = { name: n, count: c }; return true; } return false; },
    consumeSelected() { const s = this.hotbar[this.selected]; if (s) { s.count--; if (s.count <= 0) this.hotbar[this.selected] = null; } },
    addXp(n: number) { n = SV.mend(this, n); this.xp += n; },
    changeDimension(d: string) { this.dimension = d; this.edits = stores[d].edits; this.editsByChunk = stores[d].editsByChunk; },
    mobs: { looting: 0, lastHit: null as any, mobs: [mob], hit(_o: any, _d: any, dmg: number) { this.lastHit = mob; mob.hp -= dmg; return true; }, hurtNear() { return 1; }, extraDamage(_m: any, d: number) { mob.hp -= d; }, nearestHostile() { return mob; }, shootPlayerArrow(...a: any[]) { shots.push(['arrow', ...a]); }, launchProjectile(...a: any[]) { shots.push(a); }, host: {}, clear() {}, populate() {}, crystals: [] },
  };
  return e;
}
const run = (e: any, sec: number, dt = 0.05) => { for (let t = 0; t < sec; t += dt) { e.elapsed += dt; SV.tick(e, dt); } };

// 1. armor slots, points, wear
let e = make();
for (const [i, n] of ['diamond_helmet', 'diamond_chestplate', 'diamond_leggings', 'diamond_boots'].entries()) { e.selected = i; e.hotbar[i] = { name: n, count: 1 }; SV.useItem(e, e.hotbar[i], resolve(n)); }
ok('right-click equips armor into the four slots', e.armor.every((s: any) => s) && e.hotbar.slice(0, 4).every((s: any) => !s), e.armor);
ok('full diamond gives 20 armor points', SV.armorPoints(e) === 20, SV.armorPoints(e));
SV.hurt(e, 10, 'mob');
ok('armor absorbs most of a 10 dmg hit', e.health > 16 && e.health < 20, e.health);
ok('armor loses durability when hit', e.armor.every((s: any) => s.durability < resolve(s.name)!.durability!), e.armor.map((s: any) => s.durability));
ok('non-armor cannot go into an armor slot', (e.hotbar[5] = { name: 'dirt', count: 3 }) && !SV.swapSlots(e, 5, 36));
ok('fall damage ignores armor', (() => { e.health = 20; SV.fallDamage(e, 13); return e.health === 10; })(), e.health);

// 2. shield
e = make(); e.offhand = { name: 'shield', count: 1 }; e.input.useHeld = true; e.input.yaw = 0; SV.useItem(e, e.offhand, resolve('shield'), 'off'); run(e, 0.4);
SV.hurt(e, 8, 'mob', false, { from: new THREE.Vector3(0, 64, -3) });   // attacker straight ahead (the player looks down -Z at yaw 0)
ok('raised off-hand shield blocks mob damage and wears down (1 + floor(8))', e.blocking && e.health === 20 && e.offhand.durability === 336 - 9, [e.blocking, e.health, e.offhand]);
SV.hurt(e, 4, 'fall'); ok('shield does not block fall damage', e.health === 16, e.health);
ok('blocking slows movement', SV.speedFactor(e) < 0.5);

// 3. status effects
e = make(); SV.addEffect(e, 'poison', 30, 0); e.hunger = 10; run(e, 30);   // food 10: no natural regeneration, no starvation
ok('poison ticks down to 1 HP but never kills', e.health >= 0.99 && e.health <= 1.01 && !e.dead, e.health);
SV.addEffect(e, 'regeneration', 10, 1); run(e, 10); ok('regeneration II heals', e.health > 7, e.health);
SV.addEffect(e, 'speed', 60, 1); ok('speed II → +40%', Math.abs(SV.speedFactor(e) - 1.4) < 1e-6, SV.speedFactor(e));
SV.addEffect(e, 'instant_health', 0, 1); ok('instant health heals immediately', e.health > 14, e.health);
SV.addEffect(e, 'fire_resistance', 60, 0); const hp = e.health; SV.hurt(e, 4, 'fire'); ok('fire resistance negates fire', e.health === hp);
SV.addEffect(e, 'absorption', 60, 0); SV.hurt(e, 3, 'magic'); ok('absorption hearts soak damage first', e.health === hp && e.absorption === 1, [e.health, e.absorption]);
e.hotbar[0] = { name: 'milk_bucket', count: 1 }; SV.useItem(e, e.hotbar[0], resolve('milk_bucket')); ok('milk clears effects', Object.keys(e.effects).length === 0 && e.hotbar[0].name === 'bucket');
ok('HUD lists active effects', (SV.addEffect(e, 'night_vision', 60, 0), SV.hud(e).effects.length === 1));

// 4. melee cooldown, sharpness, mace
e = make(); mob.hp = 100; e.hotbar[0] = { name: 'diamond_sword', count: 1, ench: { sharpness: 5, looting: 3, unbreaking: 3 } };
ok('fully charged sword hit lands (7 + sharpness 3)', SV.tryAttack(e, e.hotbar[0], resolve('diamond_sword')) && 100 - mob.hp === 10, 100 - mob.hp);
ok('looting level is passed to the mob manager', e.mobs.looting === 3);
ok('cooldown resets after the swing', SV.attackCharge(e) < 0.05);
e.swingHeld = false; e.elapsed += 0.2; mob.hp = 100; SV.tryAttack(e, e.hotbar[0], resolve('diamond_sword'));
ok('spam click is much weaker', 100 - mob.hp <= 4 && 100 - mob.hp >= 1, 100 - mob.hp);
e.elapsed += 0.2; ok('holding the button does not re-swing until charged', !SV.tryAttack(e, e.hotbar[0], resolve('diamond_sword')));
e = make(); mob.hp = 100; e.hotbar[0] = { name: 'mace', count: 1 }; e.grounded = false; e.velocity.y = -9; e.fallTop = 74; e.position.y = 64;
SV.tryAttack(e, e.hotbar[0], resolve('mace')); ok('mace smash scales with fall distance and cancels the fall', 100 - mob.hp >= 30 && e.fallTop === 64, [100 - mob.hp, e.fallTop]);

// 5. bow charge, crossbow, trident
e = make(); shots.length = 0; e.hotbar[0] = { name: 'bow', count: 1, ench: { power: 2 } }; e.inventory[0] = { name: 'arrow', count: 5 }; e.input.useHeld = true;
SV.useItem(e, e.hotbar[0], resolve('bow')); run(e, 1.2); ok('bow draws while the button is held', SV.hud(e).useCharge === 1 && shots.length === 0);
e.input.useHeld = false; run(e, 0.1); ok('releasing fires one charged arrow and uses ammo', shots.length === 1 && shots[0][4] >= 9 && e.inventory[0].count === 4, shots[0]?.slice(3));
shots.length = 0; e.input.useHeld = true; SV.useItem(e, e.hotbar[0], resolve('bow')); run(e, 0.25); e.input.useHeld = false; run(e, 0.1);
ok('a short draw is a weak, slow shot', shots.length === 1 && shots[0][4] <= 5 && shots[0][3] < 20, shots[0]?.slice(3));
e = make(); shots.length = 0; e.hotbar[0] = { name: 'crossbow', count: 1, ench: { multishot: 1 } }; e.offhand = { name: 'arrow', count: 2 }; e.input.useHeld = true;
SV.useItem(e, e.hotbar[0], resolve('crossbow')); run(e, 1.4); ok('crossbow loads after 1.25 s using off-hand arrows', e.hotbar[0].loaded === true && e.offhand.count === 1);
SV.useItem(e, e.hotbar[0], resolve('crossbow')); ok('loaded crossbow fires (multishot = 3 bolts)', shots.length === 3 && !e.hotbar[0].loaded);
e = make(); shots.length = 0; e.hotbar[0] = { name: 'trident', count: 1, ench: { loyalty: 3 } }; e.input.useHeld = true; SV.useItem(e, e.hotbar[0], resolve('trident')); run(e, 0.7); e.input.useHeld = false; run(e, 0.1);
ok('trident is thrown', shots.length === 1 && shots[0][0] === 'trident' && !e.hotbar[0]);
shots[0][5].onEnd(new THREE.Vector3(5, 64, 0)); run(e, 1.5); ok('loyalty returns the trident with its enchantments', e.hotbar[0]?.name === 'trident' && e.hotbar[0].ench.loyalty === 3, e.hotbar[0]);

// 6. potions & totem
e = make(); e.hotbar[0] = { name: 'potion_swiftness_strong', count: 1 }; SV.useItem(e, e.hotbar[0], resolve('potion_swiftness_strong'));
ok('drinking a potion applies its effect and leaves a bottle', e.effects.speed?.amp === 1 && e.hotbar[0].name === 'glass_bottle');
e = make(); e.offhand = { name: 'totem_of_undying', count: 1 }; SV.hurt(e, 500, 'mob'); ok('totem of undying prevents death', !e.dead && e.health === 1 && !e.offhand && !!e.effects.regeneration);
SV.hurt(e, 500, 'mob'); ok('without a totem the player dies', e.dead && screens.includes('death'));

// 7. enchanting table, anvil, grindstone, smithing, stonecutter
e = make(); e.hotbar[0] = { name: 'diamond_pickaxe', count: 1 }; e.inventory[0] = { name: 'lapis_lazuli', count: 3 }; e.xp = V.xpForLevel(30);
ok('15 bookshelves are detected', SV.bookshelves(e) === 15, SV.bookshelves(e));
const offers = SV.enchantOffers(e, 0); ok('three offers, the best needs level 30', offers.length === 3 && offers[2].level === 30, offers);
ok('enchanting spends 3 levels + 3 lapis and enchants the tool', SV.doEnchant(e, 0, 2) && !!e.hotbar[0].ench && SV.level(e) === 27 && !e.inventory[0], [e.hotbar[0], e.xp, e.inventory[0]]);
ok('an enchanted item gets no further offers', SV.enchantOffers(e, 0).length === 0);
e.hotbar[1] = { name: 'enchanted_book', count: 1, ench: { mending: 1, sharpness: 3 } };
const pre = SV.anvilPreview(e, 0, 1, 'Excavator'); ok('anvil merges only compatible book enchantments and renames', !!pre && pre.result.ench!.mending === 1 && !pre.result.ench!.sharpness && pre.result.label === 'Excavator', pre);
const lvBefore = SV.level(e); ok('anvil consumes the book and levels', SV.doAnvil(e, 0, 1, 'Excavator') && !e.hotbar[1] && SV.level(e) === lvBefore - pre!.cost && e.hotbar[0].ench.mending === 1);
e.hotbar[0].durability = 100; e.addXp(40); ok('mending repairs with XP', e.hotbar[0].durability === 180, e.hotbar[0].durability);
ok('silk touch / fortune hook returns drops', SV.drops(e, resolve('diamond_ore') as any, resolve('diamond_pickaxe'), { name: 'diamond_pickaxe', count: 1, ench: { silk_touch: 1 } }, 0)[0].name === 'diamond_ore');
const xp0 = e.xp; ok('grindstone strips enchantments for XP', SV.doGrind(e, 0, -1) && !e.hotbar[0].ench && e.xp > xp0);
e = make(); e.hotbar[0] = { name: 'netherite_upgrade', count: 1 }; e.hotbar[1] = { name: 'diamond_sword', count: 1, ench: { sharpness: 4 }, durability: 1000 }; e.hotbar[2] = { name: 'netherite_ingot', count: 2 };
ok('smithing upgrades diamond → netherite keeping enchantments', SV.doSmith(e, 0, 1, 2) && e.hotbar[1].name === 'netherite_sword' && e.hotbar[1].ench.sharpness === 4 && !e.hotbar[0] && e.hotbar[2].count === 1, e.hotbar.slice(0, 3));
e.hotbar[3] = { name: 'stone', count: 4 }; const cutTo = STONECUT.stone?.find(o => o.result.endsWith('_slab'))?.result ?? STONECUT.stone?.[0].result;
ok('stonecutter cuts a whole stack', !!cutTo && SV.doStonecut(e, 3, cutTo!, true) && !e.hotbar[3] && e.countItem(cutTo!) >= 4, [cutTo, e.countItem(cutTo ?? '')]);

// 8. brewing
e = make(); const slots: any[] = [{ name: 'water_bottle', count: 1 }, { name: 'water_bottle', count: 1 }, null, { name: 'nether_wart', count: 1 }, { name: 'blaze_powder', count: 1 }], st = { burn: 0, progress: 0 };
for (let i = 0; i < 205; i++) SV.brewTick(e, st, slots, 0.05);
ok('water + nether wart → awkward potion (uses fuel)', slots[0].name === 'awkward_potion' && slots[1].name === 'awkward_potion' && !slots[3] && !slots[4] && st.burn === 19, [slots, st]);
slots[3] = { name: 'golden_carrot', count: 1 }; for (let i = 0; i < 205; i++) SV.brewTick(e, st, slots, 0.05);
slots[3] = { name: 'fermented_spider_eye', count: 1 }; for (let i = 0; i < 205; i++) SV.brewTick(e, st, slots, 0.05);
slots[3] = { name: 'gunpowder', count: 1 }; for (let i = 0; i < 205; i++) SV.brewTick(e, st, slots, 0.05);
ok('night vision → invisibility → splash chain', slots[0].name === 'splash_invisibility', slots[0]);

// 9. nether portal 1:8 linking
e = make(); e.position.set(800.5, 70, -400.5); SV.netherTravel(e);
ok('overworld → nether divides coordinates by 8', e.dimension === 'nether' && Math.floor(e.position.x) === 100 && Math.floor(e.position.z) === -51 && e.portalLock, e.position.toArray());
ok('a portal frame is written at the destination', [...e.edits.values()].filter(c => (c & 1023) === ID.portal).length === 6 && [...e.edits.values()].filter(c => (c & 1023) === ID.obsidian).length >= 10);
e.position.set(101.5, e.position.y, -50.5); SV.netherTravel(e);
ok('nether → overworld multiplies by 8 and builds the return portal', e.dimension === 'overworld' && Math.abs(e.position.x - 812.5) < 0.01 && Math.abs(e.position.z + 403.5) < 0.01 && [...e.edits.values()].filter(c => (c & 1023) === ID.portal).length === 6, e.position.toArray());
e.position.set(820, 70, -390); SV.netherTravel(e);
ok('a second trip links to the existing nether portal', Math.abs(e.position.x - 101) <= 1 && Math.floor(e.position.z) === -51 && [...e.edits.values()].filter(c => (c & 1023) === ID.portal).length === 6, e.position.toArray());

// 10. loot tables, commands, legacy lift
e = make();
ok('every structure loot table rolls valid items', (Object.keys(EXTRA_LOOT) as any[]).every(k => { const s = SV.rollLoot(e, k, 1, 2, 3).filter(Boolean); return s.length > 0 && s.every(x => !!resolve(x!.name) && x!.count > 0); }));
ok('every loot table entry is a real item', Object.values(EXTRA_LOOT).every(t => t.items.every(i => !!resolve(i[0]))), Object.values(EXTRA_LOOT).flatMap(t => t.items.filter(i => !resolve(i[0])).map(i => i[0])));
e.hotbar[0] = { name: 'iron_sword', count: 1 };
ok('/effect, /enchant and /xp commands', SV.command(e, 'effect', ['give', 'night_vision', '60']).startsWith('Applied') && SV.command(e, 'enchant', ['fire_aspect', '2']).startsWith('Applied') && e.hotbar[0].ench.fire_aspect === 2 && SV.command(e, 'xp', ['5L']).startsWith('Level 5'));
const store = { edits: new Map([['1,26,2', 7]]), containers: { '1,26,2': [] }, furnaces: {} }; SV.liftLegacyOverworld(store);
ok('legacy worlds are lifted by 43 blocks', store.edits.has('1,69,2') && '1,69,2' in store.containers);
console.log(`\n${pass}/${pass + fail} survival checks passed`);
if (fail) process.exit(1);
