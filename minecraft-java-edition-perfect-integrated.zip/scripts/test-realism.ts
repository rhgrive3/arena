import assert from 'node:assert/strict';
import '../src/game/content';
import { ID } from '../src/game/data';
import { Fluids } from '../src/systems/fluids';
import { Terrain, MIN_Y, HEIGHT } from '../src/world/terrain';

/*
 * Realism checks for Minecraft Java Edition parity: dynamic fluids (flow / source conversion / water+lava contact),
 * aquifers, 3D ore veins, 3D cave biomes and the vanilla-style biome zoomer.
 */
let passed = 0, failed = 0;
function test(name: string, fn: () => void) {
  try { fn(); passed++; console.log('PASS  ' + name); } catch (e) { failed++; console.log('FAIL  ' + name + '\n      ' + (e as Error).message.split('\n')[0]); }
}

// ------------------------------------------------------------------ fluid world harness
function makeWorld(dim = 'overworld') {
  const cells = new Map<string, number>();
  const k = (x: number, y: number, z: number) => `${x},${y},${z}`;
  const world = {
    cells,
    getCell: (x: number, y: number, z: number) => (Math.abs(x) > 40 || Math.abs(z) > 40 || y > 40 ? -1 : y < 0 ? ID.stone : (cells.get(k(x, y, z)) ?? (y === 0 ? ID.stone : 0))),
    setBlock: (x: number, y: number, z: number, id: number, state = 0) => { cells.set(k(x, y, z), id === 0 ? 0 : id | (state << 12)); fluids.onBlockChanged(x, y, z); return true; },
    dimension: () => dim,
    sound: () => {},
  };
  const fluids: Fluids = new Fluids(world);
  const id = (x: number, y: number, z: number) => world.getCell(x, y, z) & 4095;
  const st = (x: number, y: number, z: number) => (world.getCell(x, y, z) >>> 12) & 15;
  const run = (seconds: number) => { for (let t = 0; t < seconds; t += 0.05) fluids.update(0.05, 1000, 100000); };
  return { world, fluids, id, st, run };
}

test('water source spreads exactly 7 blocks on flat ground with falling levels 1..7', () => {
  const w = makeWorld();
  w.world.setBlock(0, 1, 0, ID.water, 0);
  w.run(10);
  for (let d = 1; d <= 7; d++) { assert.equal(w.id(d, 1, 0), ID.water, 'water at distance ' + d); assert.equal(w.st(d, 1, 0), d, 'level at ' + d); }
  assert.equal(w.id(8, 1, 0), 0, 'nothing beyond 7');
  assert.equal(w.id(3, 1, 3), ID.water, 'diagonal region filled'); // |3|+|3| = 6 <= 7
  assert.equal(w.id(5, 1, 5), 0, 'diagonal distance 10 stays dry');
});

test('water falls straight down as a falling column and spreads at the bottom', () => {
  const w = makeWorld();
  w.world.setBlock(0, 6, 0, ID.water, 0);
  w.run(10);
  for (let y = 1; y <= 5; y++) { assert.equal(w.id(0, y, 0), ID.water, 'column y' + y); assert.equal(w.st(0, y, 0) & 8, 8, 'falling flag y' + y); }
  assert.equal(w.id(1, 1, 0), ID.water, 'spreads at the floor');
  assert.equal(w.id(1, 6, 0), ID.water, 'source also spreads at its own level (it sits on air so it falls first, then sideways when floor reached)');
});

test('two adjacent sources create an infinite water source (vanilla)', () => {
  const w = makeWorld();
  w.world.setBlock(0, 1, 0, ID.water, 0); w.world.setBlock(2, 1, 0, ID.water, 0);
  w.run(10);
  assert.equal(w.id(1, 1, 0), ID.water); assert.equal(w.st(1, 1, 0), 0, 'gap became a source');
  // Lava never converts
  const l = makeWorld();
  l.world.setBlock(0, 1, 0, ID.lava, 0); l.world.setBlock(2, 1, 0, ID.lava, 0);
  l.run(20);
  assert.notEqual(l.st(1, 1, 0), 0, 'lava gap stays flowing');
});

test('removing the source drains the flowing water completely', () => {
  const w = makeWorld();
  w.world.setBlock(0, 1, 0, ID.water, 0);
  w.run(10);
  assert.equal(w.id(7, 1, 0), ID.water);
  w.world.setBlock(0, 1, 0, 0);
  w.run(30);
  for (let d = 0; d <= 8; d++) assert.equal(w.id(d, 1, 0), 0, 'dry at ' + d);
});

test('lava is slower and reaches only 3 blocks in the overworld (7 in the Nether)', () => {
  const w = makeWorld();
  w.world.setBlock(0, 1, 0, ID.lava, 0);
  w.run(1.0);
  assert.equal(w.id(1, 1, 0), 0, 'lava has not spread after 1 second (30 tick delay)');
  w.run(15);
  assert.equal(w.id(3, 1, 0), ID.lava); assert.equal(w.st(3, 1, 0), 6);
  assert.equal(w.id(4, 1, 0), 0);
  const n = makeWorld('nether');
  n.world.setBlock(0, 1, 0, ID.lava, 0);
  n.run(15);
  assert.equal(n.id(7, 1, 0), ID.lava, 'nether lava flows 7 blocks');
});

test('water touching a lava source makes obsidian, touching flowing lava makes cobblestone', () => {
  const w = makeWorld();
  w.world.setBlock(0, 1, 0, ID.lava, 0);
  w.world.setBlock(1, 1, 0, ID.water, 0);
  w.run(2);
  assert.equal(w.id(0, 1, 0), ID.obsidian, 'source lava + water = obsidian');
  const f = makeWorld();
  f.world.setBlock(0, 1, 0, ID.lava, 0);
  f.run(15);               // flowing lava ring built
  f.world.setBlock(3, 2, 0, ID.water, 0); // water source dropping onto flowing lava (state 6)
  f.run(10);
  assert.ok([ID.cobblestone, ID.obsidian].includes(f.id(3, 1, 0)), 'flowing lava turned into stone-like block, got ' + f.id(3, 1, 0));
  assert.equal(f.id(3, 1, 0), ID.cobblestone);
});

test('lava flowing down into water produces stone', () => {
  const w = makeWorld();
  w.world.setBlock(0, 1, 0, ID.water, 0);       // water sits on the floor
  w.world.setBlock(0, 2, 0, ID.lava, 0);        // lava source right above it: it flows down and the water cell becomes stone (LavaFluid.spreadTo)
  w.run(3);
  assert.equal(w.id(0, 1, 0), ID.stone);
  const x = makeWorld();
  x.world.setBlock(0, 1, 0, ID.water, 0);
  x.world.setBlock(3, 2, 0, ID.lava, 0);        // lava drops, then flows towards the water pool
  x.run(40);
  const stone = [...x.world.cells.values()].filter(c => [ID.stone, ID.cobblestone, ID.obsidian].includes(c & 4095)).length;
  assert.ok(stone > 0, 'some stone-like blocks formed where the fluids met');
});

test('fluid prefers the direction of the nearest hole (slope search)', () => {
  const w = makeWorld();
  // hole in the floor 2 blocks east of the source, another much further west
  w.world.setBlock(2, 0, 0, 0); w.world.setBlock(-5, 0, 0, 0);
  w.world.setBlock(0, 1, 0, ID.water, 0);
  w.run(8);
  assert.equal(w.id(1, 1, 0), ID.water, 'east flows towards the hole');
  assert.equal(w.id(-1, 1, 0), 0, 'west is not flooded: the hole is out of search range');
});

test('flowing water washes away plants and torches', () => {
  const w = makeWorld();
  w.world.setBlock(1, 1, 0, ID.short_grass ?? ID.poppy, 0);
  w.world.setBlock(0, 1, 0, ID.water, 0);
  w.run(3);
  assert.equal(w.id(1, 1, 0), ID.water);
});

// ------------------------------------------------------------------ world generation
const terrain = new Terrain('849281');
const chunks = [] as { data: Uint16Array; cx: number; cz: number }[];
for (let cz = 0; cz < 10; cz++) for (let cx = 0; cx < 10; cx++) chunks.push({ data: terrain.generate(20 + cx, 20 + cz).data, cx: 20 + cx, cz: 20 + cz });
const at = (d: Uint16Array, x: number, y: number, z: number) => (x < 0 || x > 15 || z < 0 || z > 15 || y < MIN_Y || y >= MIN_Y + HEIGHT) ? -1 : d[(y - MIN_Y) * 256 + z * 16 + x] & 4095;

test('aquifers: caves contain local water lakes, never hanging walls, lava only deep', () => {
  let water = 0, contacts = 0, lavaHigh = 0;
  const levels = new Map<number, number>();
  for (const { data, cx, cz } of chunks) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
    const h = terrain.height(cx * 16 + x, cz * 16 + z);
    for (let y = MIN_Y + 3; y < Math.min(h - 8, 58); y++) {
      const id = at(data, x, y, z);
      if (id === ID.water) { water++; levels.set(y, (levels.get(y) ?? 0) + 1); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (at(data, x + dx, y, z + dz) === 0) contacts++; }
      if (id === ID.lava && y > -10) lavaHigh++;
    }
  }
  assert.ok(water > 2000, 'underground water voxels: ' + water);
  assert.equal(contacts, 0, 'water voxels touching cave air sideways: ' + contacts);
  assert.equal(lavaHigh, 0, 'lava above y=-10 in caves: ' + lavaHigh);
  assert.ok(levels.size > 15, 'many different local water levels: ' + levels.size);
});

test('ore veins: large granite (copper) and tuff (iron) bodies with embedded ore and raw blocks', () => {
  const c: Record<string, number> = {};
  for (const { data } of chunks) for (let i = 0; i < data.length; i++) { const id = data[i] & 4095; if (id === ID.granite || id === ID.tuff || id === ID.raw_iron_block || id === ID.raw_copper_block) c[id] = (c[id] ?? 0) + 1; }
  assert.ok((c[ID.granite] ?? 0) > 2000, 'granite voxels ' + c[ID.granite]);
  assert.ok((c[ID.tuff] ?? 0) > 2000, 'tuff voxels ' + c[ID.tuff]);
  assert.ok((c[ID.raw_copper_block] ?? 0) + (c[ID.raw_iron_block] ?? 0) > 5, 'raw ore blocks present');
  // Vein extent: find a connected granite blob larger than 300 voxels (flood fill in a chunk)
  let biggest = 0;
  for (const { data } of chunks.slice(0, 40)) {
    const seen = new Uint8Array(data.length);
    for (let i = 0; i < data.length; i++) {
      if (seen[i] || (data[i] & 4095) !== ID.granite) continue;
      let n = 0; const stack = [i]; seen[i] = 1;
      while (stack.length) {
        const p = stack.pop()!; n++;
        const x = p & 15, z = (p >> 4) & 15, y = p >> 8;
        for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
          const nx = x + dx, ny = y + dy, nz = z + dz;
          if (nx < 0 || nx > 15 || nz < 0 || nz > 15 || ny < 0 || ny >= HEIGHT) continue;
          const q = ny * 256 + nz * 16 + nx;
          if (!seen[q] && (data[q] & 4095) === ID.granite) { seen[q] = 1; stack.push(q); }
        }
      }
      if (n > biggest) biggest = n;
    }
  }
  assert.ok(biggest > 150, 'largest connected granite body in one chunk: ' + biggest);
  // Copper veins live at y 0..50, iron veins at y -60..-8
  let outOfRange = 0;
  for (const { data } of chunks) for (let y = MIN_Y; y < 120; y++) for (let k = 0; k < 256; k++) { const id = data[(y - MIN_Y) * 256 + k] & 4095; if (id === ID.raw_copper_block && (y < 0 || y > 50)) outOfRange++; if (id === ID.raw_iron_block && (y < -60 || y > -8)) outOfRange++; }
  assert.equal(outOfRange, 0, 'raw ore blocks outside their vanilla Y windows: ' + outOfRange);
});

test('3D cave biomes: lush / dripstone / deep dark form vertical pockets, deep dark only deep', () => {
  const census: Record<string, Set<number>> = {}; const cnt: Record<string, number> = {};
  for (let z = 0; z < 640; z += 8) for (let x = 0; x < 640; x += 8) for (let y = -60; y < 56; y += 4) {
    const b = terrain.caveBiome(320 + x, y, 320 + z); if (!b) continue;
    (census[b] ??= new Set()).add(y); cnt[b] = (cnt[b] ?? 0) + 1;
  }
  for (const b of ['lush_caves', 'dripstone_caves', 'deep_dark']) assert.ok((cnt[b] ?? 0) > 20, b + ' present: ' + cnt[b]);
  assert.ok(Math.max(...[...census.deep_dark]) <= 16, 'deep dark stays below y≈16');
  assert.ok(census.dripstone_caves.size > 6 && census.lush_caves.size > 3, 'pockets span multiple height bands');
  // Same (x,z), different y must be able to give different biomes (true 3D distribution)
  let mixed = 0;
  for (let z = 0; z < 640; z += 16) for (let x = 0; x < 640; x += 16) {
    const set = new Set<string>(); for (let y = -60; y < 56; y += 8) set.add(terrain.caveBiome(320 + x, y, 320 + z) ?? 'none');
    if (set.size >= 3) mixed++;
  }
  assert.ok(mixed > 10, 'columns containing 3+ different cave biomes at different depths: ' + mixed);
});

test('cave biome decoration appears in generated chunks (moss, dripstone, sculk)', () => {
  const c: Record<string, number> = {};
  for (const { data } of chunks) for (let i = 0; i < data.length; i++) { const id = data[i] & 4095; if (id === ID.moss_block || id === ID.dripstone_block || id === ID.sculk_block) c[id] = (c[id] ?? 0) + 1; }
  assert.ok((c[ID.dripstone_block] ?? 0) + (c[ID.moss_block] ?? 0) + (c[ID.sculk_block] ?? 0) > 500, JSON.stringify(c));
});

test('biome zoomer: each block takes the biome of the nearest jittered 4x4 quart cell (ragged vanilla borders)', () => {
  const g = terrain.gen; let ok = 0, n = 0, ragged = 0;
  for (let i = 0; i < 3000; i++) {
    const x = ((i * 7919) % 4000) - 2000, z = ((i * 104729) % 4000) - 2000, b = g.biomeAt(x, z);
    const qx = (x - 2) >> 2, qz = (z - 2) >> 2; let match = false;
    for (let dz = 0; dz <= 1; dz++) for (let dx = 0; dx <= 1; dx++) if (g.cellBiome((qx + dx) * 4 + 2, (qz + dz) * 4 + 2) === b) match = true;
    n++; if (match) ok++;
  }
  assert.equal(ok, n, 'biome is always one of the 4 candidate cell biomes');
  // Borders are not perfectly straight / smooth: along a scan line there are rows where biome flips back-and-forth within 8 blocks
  for (let z = -1500; z < 1500; z += 7) { let prev = g.biomeAt(-1500, z), flips = 0, last = -99; for (let x = -1499; x < 1500; x++) { const b = g.biomeAt(x, z); if (b !== prev) { if (x - last < 8) flips++; last = x; prev = b; } } if (flips) ragged++; }
  assert.ok(ragged > 5, 'rows with fuzzy flips: ' + ragged);
});

test('new/rare biomes appear in the world with their signature blocks', () => {
  const names = ['dark_forest', 'mangrove_swamp', 'ice_spikes', 'bamboo_jungle', 'old_growth_birch_forest', 'savanna_plateau', 'warm_ocean', 'lukewarm_ocean', 'deep_lukewarm_ocean', 'cold_ocean', 'frozen_ocean'];
  const found: Record<string, boolean> = {};
  for (const seed of ['849281', '1234', 'minecraft', '777']) {
    const t = new Terrain(seed);
    for (let z = -6000; z <= 6000; z += 160) for (let x = -6000; x <= 6000; x += 160) { const b = t.biome(x, z); if (names.includes(b)) found[b] = true; }
  }
  for (const n of names) assert.ok(found[n], n + ' generated');
});

console.log(`\n${passed}/${passed + failed} realism checks passed`);
if (failed) process.exit(1);
