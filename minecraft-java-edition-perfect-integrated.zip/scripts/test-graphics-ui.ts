import assert from 'node:assert/strict';
import * as THREE from 'three';
import '../src/game/content';
import { BLOCKS, ID, resolve } from '../src/game/data';
import { makeCell, blockId, blockState } from '../src/game/blockState';
import { tilesFor, atlasTiles } from '../src/textures/atlas';
import { meshChunk } from '../src/world/mesher';
import { MIN_Y, HEIGHT } from '../src/world/terrain';
import { Redstone } from '../src/systems/redstone';
import { RepeaterLockMeshes } from '../src/render/banners3d';
import { bannerShieldCanvas } from '../src/systems/banners';
import { ParticleSystem } from '../src/render/particles';
import { POTTERY_SHERDS, matchDecoratedPotRecipe, paintPotFace, DecoratedPotMeshes, pickArchaeologyLoot } from '../src/systems/pots';
import { TRIM_PATTERNS, TRIM_MATERIALS, isTrimTemplate, isTrimMaterial, isTrimmableArmor, trimmedArmorDataUrl } from '../src/systems/trims';
import { beaconPyramidTier, beaconRange, beaconDuration, BEACON_PRIMARY_POWERS, BeaconBeams } from '../src/systems/beacon';
import { newSignData, setSignLine, applySignItem, signSideForPlayer, SignMeshes } from '../src/systems/signs';
import { applyBannerToShield, RECIPES } from '../src/systems/crafting';
import { MobManager } from '../src/entities/mobs';
import * as SV from '../src/game/survival';

let passed = 0;
function check(name: string, cond: unknown) {
  assert.ok(cond, `Failed: ${name}`);
  passed++;
}

// ============================================================================
// 1. 3D Models & Dynamic Mesh Rendering
// ============================================================================
{
  const tiles = BLOCKS.map(b => tilesFor(b.id));
  const STRIDE_Y = 18 * 18;
  const padded = new Uint16Array(STRIDE_Y * HEIGHT);
  const setPadded = (x: number, y: number, z: number, id: number, st = 0) => {
    padded[(y - MIN_Y) * STRIDE_Y + (z + 1) * 18 + (x + 1)] = makeCell(id, st);
  };

  // 1a. Repeater locked state model (Bedrock Bar vs movable torch)
  setPadded(5, 64, 5, ID.repeater, 0); // facing +X
  const meshUnlocked = meshChunk(padded, 70, tiles);
  const bedrockTile = tiles[ID.bedrock][0];
  check('Unlocked repeater does not use bedrock bar tile', !meshUnlocked.solid.tile.includes(bedrockTile));

  // Lock from side: repeater at (5, 64, 4) facing +Z (dir=1) powered by redstone_block at (5, 64, 3)
  setPadded(5, 64, 4, ID.repeater, 1);
  setPadded(5, 64, 3, ID.redstone_block, 0);
  const meshLocked = meshChunk(padded, 70, tiles);
  check('Locked repeater in mesher binds bedrock bar tile across center', meshLocked.solid.tile.includes(bedrockTile));

  // Dynamic RepeaterLockMeshes sync with Redstone.lockedKeys()
  const scene = new THREE.Scene();
  const lockMeshes = new RepeaterLockMeshes(scene);
  const cells = new Map<string, number>();
  const rs = new Redstone({
    getCell: (x, y, z) => cells.get(`${x},${y},${z}`) ?? 0,
    setBlock: (x, y, z, id, st = 0) => { cells.set(`${x},${y},${z}`, makeCell(id, st)); return true; },
  });
  rs.set(5, 64, 5, ID.repeater, 0);
  rs.set(5, 64, 4, ID.repeater, 1);
  rs.set(5, 64, 3, ID.redstone_block, 0);
  for (let i = 0; i < 8; i++) rs.tick();
  check('Redstone solver marks side-powered repeater as locked', rs.isLocked(5, 64, 5));
  lockMeshes.sync(rs.lockedKeys(), (x, y, z) => blockState(cells.get(`${x},${y},${z}`) ?? 0));
  check('RepeaterLockMeshes spawns 3D bedrock lock bar mesh', lockMeshes.size === 1);

  // 1b. Cauldron dynamic liquid Y levels (1..3) and animated lava surface (state=4)
  padded.fill(0);
  const maxWaterY = (st: number) => {
    padded.fill(0);
    setPadded(4, 64, 4, ID.cauldron, st);
    const m = meshChunk(padded, 70, tiles);
    let maxY = -Infinity;
    for (let i = 1; i < m.water.position.length; i += 3) maxY = Math.max(maxY, m.water.position[i]);
    return { maxY, tile: m.water.tile[0], count: m.water.position.length };
  };
  const lv1 = maxWaterY(1), lv2 = maxWaterY(2), lv3 = maxWaterY(3), lvLava = maxWaterY(4);
  check('Cauldron level 1..3 water meshes have strictly increasing Y coordinates', lv1.maxY < lv2.maxY && lv2.maxY < lv3.maxY);
  check('Cauldron level 1..3 uses water shader tile (0)', lv1.tile === 0 && lv3.tile === 0);
  check('Cauldron lava (state 4) uses animated lava shader tile (1)', lvLava.tile === 1 && lvLava.count > 0);

  // 1c. Held Shield & Dropped Item Banner Pattern 3D Texture Synthesis
  const shieldStack = applyBannerToShield(
    { name: 'shield', count: 1 },
    { name: 'blue_banner', count: 1, patterns: [{ p: 'cross', c: 'yellow' }, { p: 'border', c: 'white' }] },
  );
  check('applyBannerToShield transfers bannerBase and patterns to shield', shieldStack?.bannerBase === 'blue' && shieldStack?.patterns?.length === 2);
  const shCanvas = bannerShieldCanvas('blue', shieldStack!.patterns, true);
  check('bannerShieldCanvas generates 24x44 composite texture canvas', shCanvas.width === 24 && shCanvas.height === 44);
  const ps = new ParticleSystem(scene);
  ps.drop(new THREE.Vector3(0, 65, 0), 'shield', 1, '#a07848', shieldStack!);
  check('Dropped patterned shield uses banner-proportioned 3D mesh and synthesized texture', ps.drops.length === 1 && Math.abs(ps.drops[0].mesh.scale.y - 0.42) < 0.01);

  // 1d. Decorated Pot 4-face Pottery Sherd dynamic texture binding
  check('18 Pottery Sherds registered', POTTERY_SHERDS.length === 18 && POTTERY_SHERDS.every(s => !!resolve(s.item)));
  const potRecipe = matchDecoratedPotRecipe([
    null, 'arms_up_pottery_sherd', null,
    'HOWL_pottery_sherd'.toLowerCase(), null, 'prize_pottery_sherd',
    null, 'brick', null,
  ]);
  check('matchDecoratedPotRecipe extracts 4 face sherds from diamond grid', potRecipe !== null && potRecipe[0] === 'arms_up_pottery_sherd' && potRecipe[3] === 'brick');
  const potMeshes = new DecoratedPotMeshes(scene);
  potMeshes.set('overworld:2,64,2', 2, 64, 2, potRecipe!);
  check('DecoratedPotMeshes binds 4 distinct face meshes around the pot', potMeshes.size === 1);
}

// ============================================================================
// 2. Shaders & Texture Overlays
// ============================================================================
{
  // 2a. Night Vision Shader on Mobs & Entities
  const scene = new THREE.Scene();
  const dummyHost: any = {
    terrain: { height: () => 64, biome: () => 'plains', caveBiome: () => null },
    position: new THREE.Vector3(0, 64, 0),
    camera: new THREE.PerspectiveCamera(),
    time: 0.75,
    dimension: 'overworld',
    dragonDefeated: false,
    getBlock: () => 0,
    damage: () => 'none',
    addItem: () => true,
    toast: () => {},
    sound: () => {},
    explode: () => {},
    teleport: () => {},
    openTrade: () => {},
    onDragonDefeated: () => {},
    onEnterGateway: () => {},
    levitate: () => {},
    particles: { burst: () => {}, drop: () => {} },
  };
  const mm = new MobManager(scene, dummyHost);
  const matSample = mm.mat('#668b4d');
  mm.applyNightVision(1.0);
  check('Night Vision sets full-bright emissive intensity on mob materials', matSample.emissiveIntensity > 0.8 && mm.nightVision === 1.0);
  mm.applyNightVision(0);
  check('Clearing Night Vision restores mob material emissiveIntensity to 0', matSample.emissiveIntensity === 0);

  // 2b. Frosted Ice (Thin Ice) progressive fracture tiles (0..3) & block light melting
  const fiTiles = tilesFor(ID.frosted_ice);
  check('Frosted Ice has 4 distinct progressive fracture stage tiles in atlas', fiTiles.length >= 10 && new Set(fiTiles.slice(6, 10)).size === 4);

  const worldBlocks = new Map<string, number>();
  const stubEng: any = {
    dimension: 'overworld',
    environment: { daylight: 0 }, // pitch black night
    getBlock: (x: number, y: number, z: number) => blockId(worldBlocks.get(`${x},${y},${z}`) ?? 0),
    getCell: (x: number, y: number, z: number) => worldBlocks.get(`${x},${y},${z}`) ?? 0,
    setBlock: (x: number, y: number, z: number, id: number, st = 0) => { worldBlocks.set(`${x},${y},${z}`, makeCell(id, st)); return true; },
  };
  worldBlocks.set('0,64,0', makeCell(ID.frosted_ice, 0));
  // Without torch at night, blockLightAt is 0 -> does not melt
  check('Block light is 0 in darkness without light blocks', SV.blockLightAt(stubEng, 0, 64, 0) === 0);
  // Place a torch (light 14) 1 block away -> blockLightAt = 13 > 11
  worldBlocks.set('1,64,0', makeCell(ID.torch, 0));
  const blkLight = SV.blockLightAt(stubEng, 0, 64, 0);
  check('Torch 1 block away provides blockLightAt = 13', blkLight >= 13);
  SV.frostTick(stubEng, 0, 64, 0);
  check('Frosted Ice melts/ages from 0 to 1 under artificial torch block light at night', blockState(worldBlocks.get('0,64,0')!) === 1);
  SV.frostTick(stubEng, 0, 64, 0);
  SV.frostTick(stubEng, 0, 64, 0);
  SV.frostTick(stubEng, 0, 64, 0);
  check('Frosted Ice melts back into water after stage 3', blockId(worldBlocks.get('0,64,0')!) === ID.water);

  // 2c. Armor Trims (16 templates × 10 materials)
  check('16 Armor Trim smithing templates registered', TRIM_PATTERNS.length === 16 && TRIM_PATTERNS.every(p => isTrimTemplate(`${p.id}_armor_trim_smithing_template`)));
  check('10 Armor Trim mineral materials registered', TRIM_MATERIALS.length === 10 && TRIM_MATERIALS.every(m => isTrimMaterial(m.item)));
  check('Armor Trim duplication recipes registered in RECIPES', RECIPES.some(r => r.id === 'dup_silence_trim' && r.count === 2));
  const trimEngine: any = {
    meta: { mode: 'survival' },
    hotbar: [
      { name: 'silence_armor_trim_smithing_template', count: 1 },
      { name: 'diamond_chestplate', count: 1, ench: { protection: 4 } },
      { name: 'amethyst_shard', count: 2 },
    ],
    inventory: Array(27).fill(null),
    armor: [null, null, null, null],
    offhand: null,
    audio: { play: () => {} },
  };
  const preview = SV.smithPreview(trimEngine, 0, 1, 2);
  check('smithPreview combines trim template + armor + material while preserving enchantments', preview?.trim?.pattern === 'silence' && preview?.trim?.material === 'amethyst' && preview?.ench?.protection === 4);
  SV.doSmith(trimEngine, 0, 1, 2);
  check('doSmith applies armor trim to gear slot and consumes 1 template & 1 material', trimEngine.hotbar[1]?.trim?.pattern === 'silence' && trimEngine.hotbar[0] === null && trimEngine.hotbar[2]?.count === 1);
  const trimUrl = trimmedArmorDataUrl('diamond_chestplate', trimEngine.hotbar[1].trim);
  check('trimmedArmorDataUrl generates multi-layer composite icon data URL', trimUrl.startsWith('data:image/png'));

  // 2d. Charged Creeper Aura Shader & Mob Head drop
  const creeper = mm.spawn('creeper', 10, 10, false, 64)!;
  const victim = mm.spawn('zombie', 11, 10, false, 64)!;
  check('strikeLightning charges nearby creeper and attaches aura ShaderMaterial mesh', mm.strikeLightning(new THREE.Vector3(10, 64, 10)) >= 1 && creeper.charged === true && !!creeper.aura);
  check('Charged creeper aura uses custom ShaderMaterial with uTime uniform', creeper.aura!.material === mm.chargedAuraMat && 'uTime' in mm.chargedAuraMat.uniforms);
  let explodedRadius = 0;
  const droppedItems: string[] = [];
  dummyHost.explode = (_p: THREE.Vector3, r: number) => { explodedRadius = r; };
  dummyHost.particles.drop = (_p: THREE.Vector3, name: string) => { droppedItems.push(name); };
  dummyHost.position.set(10.5, 64, 10.5);
  creeper.state = 'fuse';
  creeper.fuse = 1.6;
  mm.update(0.05, 0.2, false);
  check('Charged creeper explodes with double blast radius (6) and drops victim mob head', explodedRadius === 6 && droppedItems.includes('zombie_head') && victim.hp <= 0);
}

// ============================================================================
// 3. Particles, Animations & Sounds
// ============================================================================
{
  // 3a. Bubble Columns (Soul Sand upward lift & Magma Block downward whirlpool)
  const scene = new THREE.Scene();
  const ps = new ParticleSystem(scene);
  const wMap = new Map<string, number>();
  const bubEng: any = {
    position: new THREE.Vector3(0.5, 65, 0.5),
    velocity: new THREE.Vector3(0, 0, 0),
    oxygen: 10,
    elapsed: 1.0,
    getBlock: (x: number, y: number, z: number) => wMap.get(`${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`) ?? 0,
    particles: ps,
  };
  wMap.set('0,64,0', ID.soul_sand);
  wMap.set('0,65,0', ID.water);
  wMap.set('0,66,0', ID.water);
  check('Soul Sand under water creates upward bubble column', SV.bubbleColumnMode(bubEng, 0, 65, 0) === 'up');
  SV.bubbleColumnTick(bubEng, 0.1);
  check('Upward bubble column accelerates player upward, restores oxygen, and spawns bubble particles', bubEng.velocity.y > 0 && bubEng.oxygen > 10 && ps.particles.length > 0);

  wMap.set('0,64,0', ID.magma_block);
  bubEng.velocity.y = 0;
  check('Magma Block under water creates downward vortex bubble column', SV.bubbleColumnMode(bubEng, 0, 65, 0) === 'down');
  SV.bubbleColumnTick(bubEng, 0.1);
  check('Downward bubble column pulls player downward', bubEng.velocity.y < 0);

  // 3b. Eating & Drinking Animation (1.6s = 32 ticks / 0.8s = 16 ticks for dried_kelp), Chewing Sounds & Mouth Crumbs
  check('Regular food/drink eatDuration is 1.6s (32 ticks)', SV.eatDuration('apple') === 1.6 && SV.eatDuration('potion_swiftness') === 1.6);
  check('Dried kelp eatDuration is 0.8s (16 ticks)', SV.eatDuration('dried_kelp') === 0.8);

  const soundsPlayed: string[] = [];
  let crumbsCount = 0;
  const eatEng: any = {
    meta: { mode: 'survival', difficulty: 'normal' },
    position: new THREE.Vector3(0, 64, 0),
    velocity: new THREE.Vector3(),
    camera: new THREE.PerspectiveCamera(),
    input: { useHeld: true, move: { x: 0, z: 0 }, run: false, crouch: false },
    hotbar: [{ name: 'dried_kelp', count: 2 }, { name: 'apple', count: 2 }, ...Array(7).fill(null)],
    inventory: Array(27).fill(null),
    armor: [null, null, null, null],
    offhand: null,
    selected: 0,
    health: 20,
    hunger: 10,
    saturation: 2,
    exhaustion: 0,
    effects: {},
    absorption: 0,
    levitationTimer: 0,
    useItemName: '',
    useTime: 0,
    blocking: false,
    dead: false,
    grounded: true,
    flying: false,
    gliding: false,
    elapsed: 0,
    handDip: 0,
    maps: new Map(),
    beacons: new Map(),
    getBlock: () => 0,
    getCell: () => 0,
    setBlock: () => true,
    consumeSelected() { const s = this.hotbar[this.selected]; if (s) { s.count--; if (s.count <= 0) this.hotbar[this.selected] = null; } },
    audio: { play: (k: string) => soundsPlayed.push(k) },
    particles: {
      crumbs: (_o: THREE.Vector3, _d: THREE.Vector3, _c: string, n = 5) => { crumbsCount += n; },
      burst: () => {},
      drop: () => {},
    },
    mobs: { pick: () => null },
    onToast: () => {},
  };
  // Start eating dried_kelp (0.8s)
  const started = SV.useItem(eatEng, eatEng.hotbar[0], resolve('dried_kelp'), 'main');
  check('Holding right-click with dried_kelp starts continuous eating state', started && SV.isEating(eatEng) && eatEng.useItemName === 'dried_kelp');
  for (let i = 0; i < 4; i++) SV.tick(eatEng, 0.15); // 0.6s (< 0.8s): still eating, chewing sounds + crumbs emitted
  check('During eating (0.6s < 0.8s), item is not yet consumed and chewing sound + mouth crumbs fire', eatEng.hotbar[0].count === 2 && soundsPlayed.includes('eat') && crumbsCount > 0);
  SV.tick(eatEng, 0.25); // total 0.85s >= 0.8s -> finishes eating dried_kelp!
  check('After 0.8s (16 ticks), dried_kelp is consumed and hunger increases', eatEng.hotbar[0].count === 1 && eatEng.hunger === 11 && !SV.isEating(eatEng));

  // 3c. Suspicious Sand / Gravel Brushing (4 stages + dust particles + archaeology sherd excavation)
  const sTiles = tilesFor(ID.suspicious_sand);
  check('Suspicious Sand has 4 progressive brushing stage tiles in atlas', sTiles.length >= 10 && new Set(sTiles.slice(6, 10)).size === 4);
  const archCells = new Map<string, number>();
  archCells.set('3,64,3', makeCell(ID.suspicious_sand, 0));
  let dustCalls = 0;
  const excavatedDrops: string[] = [];
  const archEng: any = {
    meta: { mode: 'survival' },
    terrain: { seed: 12345 },
    elapsed: 10,
    hotbar: [{ name: 'brush', count: 1, durability: 64 }],
    selected: 0,
    armor: [null, null, null, null],
    offhand: null,
    getCell: (x: number, y: number, z: number) => archCells.get(`${x},${y},${z}`) ?? 0,
    getBlock: (x: number, y: number, z: number) => blockId(archCells.get(`${x},${y},${z}`) ?? 0),
    setBlock: (x: number, y: number, z: number, id: number, st = 0) => { archCells.set(`${x},${y},${z}`, makeCell(id, st)); return true; },
    audio: { play: (k: string) => soundsPlayed.push(k) },
    particles: {
      brushDust: () => { dustCalls++; },
      drop: (_p: THREE.Vector3, name: string) => { excavatedDrops.push(name); },
    },
    onToast: () => {},
  };
  const b1 = SV.brushBlock(archEng, 3, 64, 3);
  const b2 = SV.brushBlock(archEng, 3, 64, 3);
  const b3 = SV.brushBlock(archEng, 3, 64, 3);
  check('First 3 brush strokes advance suspicious_sand state 0 -> 1 -> 2 -> 3 with dust particles', b1?.stage === 1 && b2?.stage === 2 && b3?.stage === 3 && dustCalls === 3);
  const b4 = SV.brushBlock(archEng, 3, 64, 3);
  check('4th brush stroke excavates pottery sherd/relic and turns suspicious_sand into regular sand', b4?.completed === true && excavatedDrops.length === 1 && blockId(archCells.get('3,64,3')!) === ID.sand);
}

// ============================================================================
// 4. Dedicated GUI Screens & Backend Logic (Beacon & Signs)
// ============================================================================
{
  // 4a. Beacon Pyramid Tiers (1..4), Offering Slot, Effect Activation & 3D Beam
  const bMap = new Map<string, number>();
  const setB = (x: number, y: number, z: number, id: number) => bMap.set(`${x},${y},${z}`, id);
  setB(0, 70, 0, ID.beacon);
  // Build 1-layer (3x3) iron_block pyramid at y=69
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) setB(dx, 69, dz, ID.iron_block);
  check('3x3 mineral base gives Beacon Pyramid Tier 1 (range 20m, 11s)', beaconPyramidTier((x, y, z) => bMap.get(`${x},${y},${z}`) ?? 0, 0, 70, 0) === 1 && beaconRange(1) === 20 && beaconDuration(1) === 11);

  // Build layers 2 (5x5), 3 (7x7), 4 (9x9)
  for (let layer = 2; layer <= 4; layer++) {
    for (let dz = -layer; dz <= layer; dz++) for (let dx = -layer; dx <= layer; dx++) {
      setB(dx, 70 - layer, dz, layer === 4 ? ID.netherite_block : ID.gold_block);
    }
  }
  check('Full 4-layer (3x3..9x9) pyramid gives Tier 4 (range 50m, 17s)', beaconPyramidTier((x, y, z) => bMap.get(`${x},${y},${z}`) ?? 0, 0, 70, 0) === 4 && beaconRange(4) === 50 && beaconDuration(4) === 17);

  const beaconEng: any = {
    meta: { mode: 'survival' },
    dimension: 'overworld',
    stationKey: '0,70,0',
    position: new THREE.Vector3(0.5, 71, 0.5),
    hotbar: [{ name: 'diamond', count: 2 }, ...Array(8).fill(null)],
    inventory: Array(27).fill(null),
    armor: [null, null, null, null],
    offhand: null,
    effects: {},
    absorption: 0,
    levitationTimer: 0,
    beacons: new Map(),
    getBlock: (x: number, y: number, z: number) => bMap.get(`${x},${y},${z}`) ?? 0,
    audio: { play: () => {} },
  };
  const okBeacon = SV.activateBeacon(beaconEng, 'strength', 'regeneration', 0);
  check('activateBeacon consumes 1 offering item and grants Primary + Tier-4 Secondary effects', okBeacon && beaconEng.hotbar[0].count === 1 && !!beaconEng.effects.strength && !!beaconEng.effects.regeneration);

  const scene = new THREE.Scene();
  const beams = new BeaconBeams(scene);
  beams.set('overworld:0,70,0', 0, 70, 0, 'strength');
  beams.update(1.5);
  check('BeaconBeams spawns rotating 3D inner core + outer glow beam meshes', beams.size === 1);

  // 4b. Signs & Hanging Signs (Front & Back 4-line text, Dye, Glow Ink Sac, Honeycomb Waxing)
  const sd = newSignData('oak', false, 0);
  setSignLine(sd, 'front', 0, 'HELLO WORLD');
  setSignLine(sd, 'front', 1, 'LINE TWO');
  setSignLine(sd, 'back', 0, 'BACK SIDE');
  check('Sign stores independent 4-line text on front and back sides', sd.front.lines[0] === 'HELLO WORLD' && sd.back.lines[0] === 'BACK SIDE');
  check('Applying red_dye colors front sign text red', applySignItem(sd, 'front', 'red_dye') === 'dyed' && sd.front.color === '#b02e26');
  check('Applying glow_ink_sac enables glowing text on front side', applySignItem(sd, 'front', 'glow_ink_sac') === 'glow' && sd.front.glowing === true);
  check('Applying honeycomb waxes the sign and locks further edits', applySignItem(sd, 'front', 'honeycomb') === 'waxed' && sd.waxed === true);
  check('Waxed sign rejects subsequent dye or text changes', applySignItem(sd, 'front', 'blue_dye') === 'locked' && setSignLine(sd, 'front', 0, 'CHANGED') === false && sd.front.lines[0] === 'HELLO WORLD');
  check('signSideForPlayer detects front vs back based on player position relative to sign yaw', signSideForPlayer(0, 0, 0, 0.5, 2.5) === 'front' && signSideForPlayer(0, 0, 0, 0.5, -2.5) === 'back');

  const signMeshes = new SignMeshes(scene);
  signMeshes.set('overworld:0,65,0', 0, 65, 0, sd);
  check('SignMeshes builds 3D board + post + double-sided text planes in scene', signMeshes.size === 1);
}

console.log(`All ${passed} graphics, shader, 3D model & UI checks passed!`);
