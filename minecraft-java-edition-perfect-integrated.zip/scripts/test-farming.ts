import assert from 'node:assert/strict';
import { ID, BLOCKS } from '../src/game/data';
import '../src/game/content';
import { Farming, cropDrops, SEED_TO_CROP } from '../src/systems/farming';
import { findPath, groundAt } from '../src/entities/pathfinding';
import { NEW_SPECIES, TRADES, RAID_WAVES, BREED_FOOD } from '../src/entities/mobdata';

/*
 * Record 014 checks: farming (tilling, planting, hydration, growth, bone meal, drops, sapling → tree), A* pathfinding
 * (stairs, walls, drops, unreachable goals) and the mob data tables.
 */

const K = (x: number, y: number, z: number) => x + ',' + y + ',' + z;
class World {
  cells = new Map<string, number>();
  drops: string[] = [];
  getCell(x: number, y: number, z: number) { return this.cells.get(K(x, y, z)) ?? 0; }
  getBlock(x: number, y: number, z: number) { return this.getCell(x, y, z) & 4095; }
  setBlock(x: number, y: number, z: number, id: number, state = 0) { const c = id === 0 ? 0 : id | (state << 12); if ((this.cells.get(K(x, y, z)) ?? 0) === c) return false; if (c === 0) this.cells.delete(K(x, y, z)); else this.cells.set(K(x, y, z), c); return true; }
  drop(_x: number, _y: number, _z: number, name: string, count: number) { this.drops.push(name + 'x' + count); }
  particles() {}
  seed = 42;
  daylight() { return 1; }
  fill(x0: number, x1: number, y: number, z0: number, z1: number, id: number) { for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) this.setBlock(x, y, z, id); }
}
const make = () => { const w = new World(); w.fill(-8, 8, 0, -8, 8, ID.stone); w.fill(-8, 8, 1, -8, 8, ID.grass_block); return { w, f: new Farming(w) }; };
const results: { name: string; ok: boolean; note?: string }[] = [];
function test(name: string, fn: () => void) { try { fn(); results.push({ name, ok: true }); console.log('PASS  ' + name); } catch (e) { results.push({ name, ok: false, note: String((e as Error).message) }); console.log('FAIL  ' + name + '  — ' + (e as Error).message); } }

test('hoe tills grass into farmland, not stone', () => {
  const { w, f } = make();
  assert.equal(f.till(0, 1, 0), true); assert.equal(w.getBlock(0, 1, 0), ID.farmland);
  assert.equal(f.till(0, 0, 0), false, 'stone cannot be tilled (and has a block above)');
});
test('farmland is moist only with water within four blocks', () => {
  const { w, f } = make();
  f.till(0, 1, 0); assert.equal(w.getCell(0, 1, 0) >>> 12, 0, 'dry');
  w.setBlock(4, 1, 0, ID.water); f.till(1, 1, 0); assert.equal(w.getCell(1, 1, 0) >>> 12, 1, 'moist');
  w.setBlock(4, 1, 0, 0); w.setBlock(7, 1, 0, ID.water); f.till(2, 1, 0); assert.equal(w.getCell(2, 1, 0) >>> 12, 0, 'five blocks away is too far');
});
test('seeds plant only on farmland; nether wart only on soul sand', () => {
  const { w, f } = make();
  assert.equal(f.plant('wheat_seeds', 0, 1, 0), false, 'grass block');
  f.till(0, 1, 0);
  assert.equal(f.plant('wheat_seeds', 0, 1, 0), true); assert.equal(w.getBlock(0, 2, 0), ID.wheat_crop);
  assert.equal(f.plant('carrot', 0, 1, 0), false, 'occupied');
  f.till(1, 1, 0); assert.equal(f.plant('carrot', 1, 1, 0), true); assert.equal(w.getBlock(1, 2, 0), ID.carrots);
  assert.equal(f.plant('nether_wart', 1, 1, 0), false);
  w.setBlock(3, 1, 0, ID.soul_sand); assert.equal(f.plant('nether_wart', 3, 1, 0), true);
  for (const seed of Object.keys(SEED_TO_CROP)) assert.ok(ID[SEED_TO_CROP[seed]] !== undefined, seed + ' has a crop block');
});
test('crops grow with random ticks and moist farmland grows faster', () => {
  const grow = (wet: boolean) => {
    const { w, f } = make();
    if (wet) w.setBlock(2, 1, 0, ID.water);
    f.till(0, 1, 0); f.plant('wheat_seeds', 0, 1, 0);
    let t = 0;
    while ((w.getCell(0, 2, 0) >>> 12) < 7 && t < 100000) { f.tick(0.25); t += 0.25; }
    return t;
  };
  const dry = grow(false), wet = grow(true);
  assert.ok(wet < 100000 && dry < 100000, 'both reach maturity');
  const dryAvg = [grow(false), grow(false), grow(false), dry].reduce((a, b) => a + b) / 4, wetAvg = [grow(true), grow(true), grow(true), wet].reduce((a, b) => a + b) / 4;
  assert.ok(wetAvg < dryAvg, `moist (${wetAvg.toFixed(0)}s) faster than dry (${dryAvg.toFixed(0)}s)`);
});
test('bone meal advances crops and a crop without soil pops', () => {
  const { w, f } = make();
  f.till(0, 1, 0); f.plant('potato', 0, 1, 0);
  assert.equal(f.bonemeal(0, 2, 0), true);
  const st = w.getCell(0, 2, 0) >>> 12;
  assert.ok(st >= 2 && st <= 7, 'advanced 2-5 stages: ' + st);
  w.setBlock(0, 1, 0, ID.dirt); f.tick(0.25);
  assert.equal(w.getBlock(0, 2, 0), 0, 'popped');
  assert.ok(w.drops.some(d => d.startsWith('potato')), 'dropped potatoes');
});
test('crop drops: immature gives seeds, mature gives produce + seeds', () => {
  assert.deepEqual(cropDrops('wheat_crop', 2, () => 0.5), [{ name: 'wheat_seeds', count: 1 }]);
  const mature = cropDrops('wheat_crop', 7, () => 0.5);
  assert.equal(mature[0].name, 'wheat'); assert.equal(mature[1].name, 'wheat_seeds');
  assert.equal(cropDrops('beetroots', 7, () => 0.1)[0].name, 'beetroot');
  assert.equal(cropDrops('carrots', 7, () => 0.9)[0].count, 4);
});
test('sapling grows into a tree with logs and leaves', () => {
  const { w, f } = make();
  w.setBlock(0, 2, 0, ID.oak_sapling);
  assert.equal(f.growTree(0, 2, 0, ID.oak_sapling), true);
  let logs = 0, leaves = 0;
  for (const c of w.cells.values()) { const id = c & 4095; if (id === ID.oak_log) logs++; if (id === ID.oak_leaves) leaves++; }
  assert.ok(logs >= 4, 'trunk: ' + logs); assert.ok(leaves >= 20, 'canopy: ' + leaves);
  assert.notEqual(w.getBlock(0, 2, 0), ID.oak_sapling);
});
test('sugar cane grows to three blocks', () => {
  const { w, f } = make();
  w.setBlock(0, 1, 0, ID.sand); w.setBlock(1, 1, 0, ID.water); w.setBlock(0, 2, 0, ID.sugar_cane); f.register(0, 2, 0);
  for (let i = 0; i < 4000; i++) f.tick(0.25);
  assert.equal(w.getBlock(0, 3, 0), ID.sugar_cane); assert.equal(w.getBlock(0, 4, 0), ID.sugar_cane); assert.equal(w.getBlock(0, 5, 0), 0, 'stops at three');
});

// ---- pathfinding
test('A* climbs a staircase', () => {
  const w = new World(); w.fill(-2, 12, 0, -2, 2, ID.stone);
  for (let i = 1; i <= 4; i++) w.fill(2 + i, 10, i, -2, 2, ID.stone);
  const get = (x: number, y: number, z: number) => w.getBlock(x, y, z);
  const path = findPath(get, 0, 1, 0, 9, 5, 0);
  assert.ok(path && path.length >= 8, 'found'); assert.equal(Math.floor(path![path!.length - 1].x), 9); assert.equal(path![path!.length - 1].y, 5);
  for (let i = 1; i < path!.length; i++) assert.ok(path![i].y - path![i - 1].y <= 1, 'never climbs more than one block');
});
test('A* walks around a wall', () => {
  const w = new World(); w.fill(-6, 6, 0, -6, 6, ID.stone);
  for (let z = -4; z <= 4; z++) { w.setBlock(0, 1, z, ID.stone); w.setBlock(0, 2, z, ID.stone); }
  const get = (x: number, y: number, z: number) => w.getBlock(x, y, z);
  const path = findPath(get, -3, 1, 0, 3, 1, 0)!;
  assert.ok(path, 'found');
  assert.ok(path.some(p => Math.abs(p.z) >= 4.5), 'goes around the end of the wall');
  assert.ok(path.every(p => !(Math.floor(p.x) === 0 && Math.abs(p.z) < 4.5)), 'never passes through the wall');
});
test('A* avoids lava and returns the closest point when the goal is unreachable', () => {
  const w = new World(); w.fill(-6, 6, 0, -6, 6, ID.stone);
  for (let z = -6; z <= 6; z++) w.setBlock(0, 0, z, ID.lava);
  const get = (x: number, y: number, z: number) => w.getBlock(x, y, z);
  const path = findPath(get, -3, 1, 0, 3, 1, 0, 300);
  assert.ok(path, 'partial path');
  assert.ok(path!.every(p => Math.floor(p.x) !== 0), 'never steps onto lava');
  assert.equal(groundAt(get, 0, 1, 0), NaN as unknown as number);
  assert.equal(groundAt(get, 1, 1, 0), 1);
});

// ---- data tables
test('every new species has a drop item and sane stats; trades reference real items', () => {
  const names = new Set(BLOCKS.map(b => b.name));
  for (const [sp, info] of Object.entries(NEW_SPECIES)) { assert.ok(info.hp > 0 && info.speed >= 0, sp); assert.ok(info.drop[0].length > 0, sp); }
  assert.ok(Object.keys(NEW_SPECIES).length >= 30, 'at least 30 new species');
  for (const [prof, list] of Object.entries(TRADES)) for (const t of list) { assert.ok(t.level >= 1 && t.level <= 5, prof); assert.ok(t.n > 0 && t.count > 0, prof); }
  assert.equal(RAID_WAVES.length, 5);
  assert.ok(BREED_FOOD.cow.includes('wheat') && BREED_FOOD.pig.includes('carrot'));
  void names;
});

const passed = results.filter(r => r.ok).length;
console.log(`\n${passed}/${results.length} farming / pathfinding checks passed`);
if (passed !== results.length) process.exit(1);
