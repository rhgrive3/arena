// Java-Edition fidelity checks (record 015): shield geometry & axes, off-hand rules, hunger / saturation, XP curve, enchantments,
// invisibility / night vision, comparator readings, repeater locking, piston rules, maps, loom banners and books.
// Run with: scripts/run-tests.sh fidelity
import * as THREE from 'three';
import '../src/game/content';
import { ID, resolve } from '../src/game/data';
import { makeCell, blockState } from '../src/game/blockState';
import * as V from '../src/game/vanilla';
import * as SV from '../src/game/survival';
import { Redstone, type RedstoneHost } from '../src/systems/redstone';
import { MobManager } from '../src/entities/mobs';
import { newMap, updateMap, zoomedOut, lockedCopy, serializeMap, deserializeMap, exploredCount, MAP_SIZE } from '../src/systems/maps';
import { addLayer, paintBanner, DYE_HEX, BANNER_PATTERNS } from '../src/systems/banners';

let pass = 0, fail = 0;
const ok = (name: string, cond: boolean, info: unknown = '') => { if (cond) pass++; else fail++; console.log((cond ? 'PASS  ' : 'FAIL  ') + name + (cond ? '' : '  → ' + JSON.stringify(info))); };
const near = (a: number, b: number, eps = 1e-6) => Math.abs(a - b) <= eps;

// ------------------------------------------------------------------------------------------------ stub engine
const drops: [string, number][] = [];
const shots: unknown[][] = [];
const mobStub = { hurtNear() { return 0; }, nearestHostile() { return null; }, pick() { return null; }, shootPlayerArrow(...a: unknown[]) { shots.push(a); }, launchProjectile() {}, badOmen: false };
function make(): any {
  const world = new Map<string, number>();
  const e: any = {
    world, meta: { mode: 'survival', difficulty: 'normal', seed: '1', id: 't' }, hotbar: Array(9).fill(null), inventory: Array(27).fill(null), armor: [null, null, null, null], offhand: null,
    effects: {}, absorption: 0, health: 20, hunger: 20, saturation: 5, exhaustion: 0, foodTimer: 0, foodAcc: 0, foodPtick: 0, xp: 0, lastLevel: 0, selected: 0, elapsed: 100,
    shieldCdUntil: -1, blocking: false, useTime: 0, useItemName: '', attackAt: -10, swingHeld: false, handCtx: 'main', handDip: 0, hitFlash: 0, levitationTimer: 0,
    input: { useHeld: false, crouch: false, run: false, yaw: 0, pitch: 0 }, position: new THREE.Vector3(0, 64, 0), velocity: new THREE.Vector3(), camera: new THREE.PerspectiveCamera(),
    dead: false, grounded: true, flying: false, gliding: false, dimension: 'overworld', weather: 'clear', statistics: {}, containers: {}, stationKey: '', maps: new Map(), nextMapId: 1,
    lecternPages: {}, banners: new Map(), settings: { distance: 4 }, enchantSeed: 1, target: null, edits: new Map(),
    particles: { burst() {}, drop(_p: unknown, n: string, c: number) { drops.push([n, c]); } }, audio: null, environment: { daylight: 1, triggerLightning() {} }, mobs: mobStub,
    terrain: { height: () => 60 }, onToast() {}, onScreen() {}, pause() {}, achievement() {},
    getCell: (x: number, y: number, z: number) => world.get(`${x},${y},${z}`) ?? (y <= 60 ? ID.grass_block : 0),
    getBlock: (x: number, y: number, z: number) => e.getCell(Math.floor(x), Math.floor(y), Math.floor(z)) & 4095,
    setBlock: (x: number, y: number, z: number, id: number, st = 0) => { world.set(`${x},${y},${z}`, id === 0 ? 0 : makeCell(id, st)); return true; },
    collides: () => false,
    countItem(n: string) { return [...this.hotbar, ...this.inventory].reduce((c: number, s: any) => c + (s?.name === n ? s.count : 0), 0); },
    removeItem(n: string, c: number) { for (const arr of [this.hotbar, this.inventory]) for (let i = 0; i < arr.length; i++) { const s = arr[i]; if (s?.name === n) { const k = Math.min(c, s.count); s.count -= k; c -= k; if (s.count <= 0) arr[i] = null; if (!c) return true; } } return c <= 0; },
    addItem(n: string, c: number) { for (const arr of [this.hotbar, this.inventory]) for (let i = 0; i < arr.length; i++) if (!arr[i]) { arr[i] = { name: n, count: c }; return true; } return false; },
    consumeSelected() { const s = this.hotbar[this.selected]; if (s) { s.count--; if (s.count <= 0) this.hotbar[this.selected] = null; } },
    addXp(n: number) { this.xp += n; },
  };
  return e;
}
const run = (e: any, sec: number, dt = 0.05) => { for (let t = 0; t < sec - 1e-9; t += dt) { e.elapsed += dt; SV.tick(e, dt); } };
const front = new THREE.Vector3(0, 64, -3), behind = new THREE.Vector3(0, 64, 3), side = new THREE.Vector3(3, 64, 0);

// ================================================================================ 1. Experience
ok('XP totals: L5=55, L16=352, L17=394, L30=1395, L31=1507, L32=1628', [5, 16, 17, 30, 31, 32].map(V.xpForLevel).join() === '55,352,394,1395,1507,1628', [5, 16, 17, 30, 31, 32].map(V.xpForLevel));
ok('XP per level: 0→7, 15→37, 16→42, 30→112, 31→121', [0, 15, 16, 30, 31].map(V.xpToNext).join() === '7,37,42,112,121');
ok('level from XP is the inverse of the totals at every boundary', Array.from({ length: 80 }, (_, l) => V.levelFromXp(V.xpForLevel(l)) === l && (l === 0 || V.levelFromXp(V.xpForLevel(l) - 1) === l - 1)).every(Boolean));
ok('the old √ curve is gone (100 XP is level 7, not 10)', V.levelFromXp(100) === 7);
{ const e = make(); e.xp = V.xpForLevel(30) + 56; SV.spendLevels(e, 3); ok('spending 3 levels keeps the bar fraction (L30 half → L27 half)', SV.level(e) === 27 && near(V.xpProgress(e.xp), 56 / 112, 0.03), [SV.level(e), V.xpProgress(e.xp)]); }
ok('old saves (level² points) keep their level on migration', V.levelFromXp(V.migrateOldXp(900)) === 30 && V.levelFromXp(V.migrateOldXp(49)) === 7);
ok('death drops 7 XP per level, capped at 100', V.deathXp(V.xpForLevel(5)) === 35 && V.deathXp(V.xpForLevel(40)) === 100);

// ================================================================================ 2. Hunger / saturation
{
  const e = make(); e.hunger = 10; e.saturation = 0;
  SV.eatNow(e, ...V.foodValue('bread'));
  ok('bread: +5 food, +6 saturation (capped by food)', e.hunger === 15 && e.saturation === 6, [e.hunger, e.saturation]);
  e.hunger = 18; e.saturation = 0; SV.eatNow(e, ...V.foodValue('cooked_beef'));
  ok('steak at 18 food: food 20, saturation min(12.8, 20)', e.hunger === 20 && near(e.saturation, 12.8), [e.hunger, e.saturation]);
  ok('golden carrot has the biggest saturation (14.4) and honey the smallest per point', V.foodValue('golden_carrot')[1] === 14.4 && V.foodValue('honey_bottle')[1] === 1.2);
}
{
  const e = make(); e.hunger = 20; e.saturation = 5; SV.exhaust(e, 4.2); SV.hungerTick(e, 0.05);
  ok('exhaustion > 4 burns 1 saturation first (food untouched)', e.hunger === 20 && near(e.saturation, 4) && near(e.exhaustion, 0.2, 1e-6), [e.hunger, e.saturation, e.exhaustion]);
  e.saturation = 0; SV.exhaust(e, 4.1); SV.hungerTick(e, 0.05);
  ok('with 0 saturation exhaustion takes 1 food point', e.hunger === 19, e.hunger);
}
{
  const e = make(); e.health = 10; e.hunger = 20; e.saturation = 5;
  for (let i = 0; i < 20; i++) SV.hungerTick(e, 0.05);
  ok('fast regeneration (full food + saturation): heals min(sat,6)/6 every 10 ticks (5/6 + 4/6 = 1.5 HP in 1 s) and burns saturation', near(e.health, 11.5, 0.01) && near(e.saturation, 4, 0.01), [e.health, e.saturation]);
}
{
  const e = make(); e.health = 10; e.hunger = 18; e.saturation = 0;
  for (let i = 0; i < 79; i++) SV.hungerTick(e, 0.05);
  const before = e.health;
  SV.hungerTick(e, 0.05);
  const exhAfterHeal = e.exhaustion;
  SV.hungerTick(e, 0.05);
  ok('slow regeneration (food ≥ 18): +1 HP every 80 ticks, costing 6 exhaustion (→ −1 food)', before === 10 && e.health === 11 && near(exhAfterHeal, 6) && e.hunger === 17 && near(e.exhaustion, 2), [before, e.health, exhAfterHeal, e.hunger, e.exhaustion]);
  e.health = 10; e.hunger = 17;
  for (let i = 0; i < 200; i++) SV.hungerTick(e, 0.05);
  ok('food below 18: no natural regeneration', e.health === 10, e.health);
}
{
  const norm = make(); norm.health = 2; norm.hunger = 0; norm.saturation = 0;
  for (let i = 0; i < 80; i++) SV.hungerTick(norm, 0.05);
  const a = norm.health;
  for (let i = 0; i < 400; i++) SV.hungerTick(norm, 0.05);
  ok('starvation on Normal: −1 HP / 4 s but never below 1 HP', a === 1 && norm.health === 1 && !norm.dead, [a, norm.health]);
  const easy = make(); easy.meta.difficulty = 'easy'; easy.health = 10; easy.hunger = 0; easy.saturation = 0;
  for (let i = 0; i < 400; i++) SV.hungerTick(easy, 0.05);
  ok('starvation on Easy stops at 10 HP', easy.health === 10, easy.health);
  const hard = make(); hard.meta.difficulty = 'hard'; hard.health = 2; hard.hunger = 0; hard.saturation = 0;
  for (let i = 0; i < 400; i++) SV.hungerTick(hard, 0.05);
  ok('starvation on Hard kills', hard.dead === true);
  const peace = make(); peace.meta.difficulty = 'peaceful'; peace.health = 10; peace.hunger = 5;
  for (let i = 0; i < 40; i++) SV.hungerTick(peace, 0.05);
  ok('peaceful: +1 HP per second and food refills', peace.health === 12 && peace.hunger >= 9, [peace.health, peace.hunger]);
}
{
  const e = make(); e.input.run = true; e.hunger = 20;
  for (let i = 0; i <= 100; i++) { e.position.x = i * 0.1; SV.hungerTick(e, 0.05); }
  ok('sprinting costs 0.1 exhaustion per metre (10 m ≈ 1.0)', near(e.exhaustion + (5 - e.saturation) * 4, 1.0, 0.02), [e.exhaustion, e.saturation]);
  const w = make(); for (let x = 0; x <= 11; x++) w.world.set(`${x},64,0`, makeCell(ID.water, 0)); w.input.run = true; w.grounded = false;
  for (let i = 0; i <= 100; i++) { w.position.x = i * 0.1; SV.hungerTick(w, 0.05); }
  ok('swimming costs 0.01 per metre', near(w.exhaustion, 0.1, 0.02), w.exhaustion);
  const h = make(); SV.addEffect(h, 'hunger', 10, 1); run(h, 10);
  ok('Hunger II drains 0.005 × 2 levels exhaustion per tick (10 s ≈ 2.0)', near(h.exhaustion + (5 - h.saturation) * 4, 2.0, 0.1), [h.exhaustion, h.saturation]);
  ok('cannot sprint at ≤ 6 food', !V.canSprintWith(6) && V.canSprintWith(7));
  const c = make(); c.meta.mode = 'creative'; SV.exhaust(c, 10); ok('creative mode ignores exhaustion', c.exhaustion === 0);
}
{
  const e = make(); e.hotbar[0] = { name: 'stone_sword', count: 1 }; e.mobs = { ...mobStub, hit: () => true, lastHit: null, extraDamage() {} }; e.camera.position.set(0, 65.6, 0);
  const x0 = e.exhaustion; SV.tryAttack(e, e.hotbar[0], resolve('stone_sword')); ok('a landed attack costs 0.1 exhaustion', near(e.exhaustion - x0, 0.1), e.exhaustion);
}

// ================================================================================ 3. Shield
ok('shield arc: front blocked, behind not, exactly sideways not (180° half-plane)', V.attackerInFront(0, 0, 0, 0, -3) && !V.attackerInFront(0, 0, 0, 0, 3) && !V.attackerInFront(0, 0, 0, 3, 0) && V.attackerInFront(0, 0, 0, 3, -0.2));
ok('arc follows yaw (facing +X: attacker at +X is in front)', V.attackerInFront(-Math.PI / 2, 0, 0, 3, 0) && !V.attackerInFront(-Math.PI / 2, 0, 0, -3, 0));
ok('hit angle: front 0°, right +90°, left −90°, behind ±180°', near(V.hitAngle(0, 0, 0, 0, -3), 0, 1e-6) && near(V.hitAngle(0, 0, 0, 3, 0), 90, 1e-6) && near(V.hitAngle(0, 0, 0, -3, 0), -90, 1e-6) && near(Math.abs(V.hitAngle(0, 0, 0, 0, 3)), 180, 1e-6));
ok('shield wear: only hits ≥ 3 damage it, for 1 + floor(damage)', V.shieldWear(2.9) === 0 && V.shieldWear(3) === 4 && V.shieldWear(8) === 9);
function raised(hand: 'main' | 'off' = 'off') {
  const e = make(); const sh = { name: 'shield', count: 1 };
  if (hand === 'off') e.offhand = sh; else e.hotbar[0] = sh;
  e.input.useHeld = true; SV.useItem(e, sh, resolve('shield'), hand); return e;
}
{
  const e = raised(); run(e, 0.1);
  const r1 = SV.hurt(e, 5, 'mob', false, { from: front });
  ok('shield needs a 5-tick (0.25 s) warm-up: a hit at 0.1 s goes through', r1 === 'hit' && e.health < 20, [r1, e.health]);
  const f = raised(); run(f, 0.3);
  const hp = f.health, r2 = SV.hurt(f, 5, 'mob', false, { from: front });
  ok('after the warm-up a frontal melee hit is fully blocked (6 durability)', r2 === 'blocked' && f.health === hp && f.offhand.durability === 336 - 6, [r2, f.health, f.offhand]);
  SV.hurt(f, 2, 'mob', false, { from: front });
  ok('a blocked hit under 3 damage costs no durability', f.offhand.durability === 336 - 6, f.offhand.durability);
  ok('attacks from behind and from the side hit the player', SV.hurt(f, 4, 'mob', false, { from: behind }) === 'hit' && SV.hurt(f, 4, 'mob', false, { from: side }) === 'hit' && f.health < hp, f.health);
  ok('attacks without a position (potions, magic) and piercing arrows ignore the shield', SV.hurt(f, 1, 'mob') === 'hit' && SV.hurt(f, 3, 'projectile', false, { from: front, pierce: 1 }) === 'hit');
  const h0 = f.health; SV.hurt(f, 4, 'fall'); SV.hurt(f, 1, 'magic', true); SV.hurt(f, 2, 'drown');
  ok('fall, magic and drowning bypass the shield', f.health < h0);
  const g = raised('main'); run(g, 0.3); const gh = g.health;
  ok('arrows and explosions from the front are blocked (explosions entirely, Java ≥ 1.19.4)', SV.hurt(g, 6, 'projectile', false, { from: front }) === 'blocked' && SV.hurt(g, 10, 'explosion', false, { from: front }) === 'blocked' && g.health === gh);
  ok('an explosion behind the player hurts', SV.hurt(g, 10, 'explosion', false, { from: behind }) === 'hit');
  const k = raised('main'); run(k, 0.3);
  ok('no attacking while the shield is raised', SV.tryAttack(k, null, resolve('stone_sword')) === false);
}
{
  const e = raised(); run(e, 0.3);
  const r = SV.hurt(e, 7, 'mob', false, { from: front, axe: true });
  ok('an axe hit is blocked once and disables the shield for 5 s', r === 'blocked' && !e.blocking && near(SV.shieldCooldown(e), 5, 0.01), [r, e.blocking, SV.shieldCooldown(e)]);
  ok('while disabled, hits go through and the shield cannot be raised', SV.hurt(e, 4, 'mob', false, { from: front }) === 'hit' && (SV.useItem(e, e.offhand, resolve('shield'), 'off'), !e.blocking));
  run(e, 5.1); SV.useItem(e, e.offhand, resolve('shield'), 'off'); run(e, 0.3);
  ok('after 5 seconds the shield works again', SV.shieldReady(e) && SV.hurt(e, 4, 'mob', false, { from: front }) === 'blocked');
  const f = raised(); run(f, 0.1);
  SV.hurt(f, 7, 'mob', false, { from: front, axe: true });
  ok('an axe cannot disable a shield during its warm-up', SV.shieldCooldown(f) === 0);
  ok('warden / vindicator / piglin brute count as shield breakers', V.AXE_ATTACKERS.has('vindicator') && V.AXE_ATTACKERS.has('piglin_brute') && V.AXE_ATTACKERS.has('warden') && !V.AXE_ATTACKERS.has('zombie'));
}

// ================================================================================ 4. Off-hand rules
{
  const e = make(); e.hotbar[0] = { name: 'iron_sword', count: 1 }; e.offhand = { name: 'torch', count: 3 };
  const placed = () => { const h = e.hotbar[e.selected]; if (h?.name === 'torch' || h?.name === 'cobblestone') { h.count--; if (h.count <= 0) e.hotbar[e.selected] = null; return true; } return false; };
  SV.useBothHands(e, placed);
  ok('main hand passes (sword) → the off-hand torch is placed', e.offhand?.count === 2 && e.hotbar[0].name === 'iron_sword', [e.offhand, e.hotbar[0]]);
  e.hotbar[0] = { name: 'cobblestone', count: 5 }; SV.useBothHands(e, placed);
  ok('main hand acts first (cobblestone placed, torch untouched)', e.hotbar[0].count === 4 && e.offhand.count === 2);
  e.hotbar[0] = null; e.offhand = { name: 'torch', count: 1 }; SV.useBothHands(e, placed);
  ok('empty main hand: the off-hand stack is used up and the slot empties', e.offhand === null && e.hotbar[0] === null);
}
{
  const e = make(); e.hotbar[0] = { name: 'iron_sword', count: 1 }; e.offhand = { name: 'shield', count: 1 }; e.input.useHeld = true;
  SV.useBothHands(e, () => SV.useItem(e, e.hotbar[e.selected], resolve(e.hotbar[e.selected]?.name ?? ''), e.handCtx));
  run(e, 0.3);
  ok('sword in the main hand + shield in the off-hand → the shield is raised from the off-hand', e.blocking && SV.shieldReady(e) && e.hotbar[0].name === 'iron_sword' && e.offhand.name === 'shield');
  const f = make(); f.hotbar[0] = { name: 'bread', count: 1 }; f.offhand = { name: 'shield', count: 1 }; f.input.useHeld = true; f.hunger = 20;
  SV.useBothHands(f, () => { const h = f.hotbar[f.selected]; if (h?.name === 'bread') return f.hunger < 20; return SV.useItem(f, h, resolve(h?.name ?? ''), f.handCtx); });
  ok('food the player cannot eat (full hunger) passes to the off-hand shield', f.handCtx === 'main' && f.hotbar[0].name === 'bread' && !!(f as any).shieldRaise);
}
{
  const e = make(); e.hotbar[3] = { name: 'spectral_arrow', count: 4 }; e.inventory[0] = { name: 'arrow', count: 9 };
  ok('arrow choice follows inventory order, not arrow type', SV.findAmmo(e)?.name === 'spectral_arrow' && SV.findAmmo(e)?.slot === 3);
  e.offhand = { name: 'arrow', count: 2 };
  ok('an off-hand arrow stack is used before the inventory', SV.findAmmo(e)?.slot === 40);
  const b = make(); b.hotbar[0] = { name: 'bow', count: 1, ench: { infinity: 1 } }; b.inventory[0] = { name: 'arrow', count: 3 };
  SV.useItem(b, b.hotbar[0], resolve('bow'), 'main');
  ok('Infinity keeps normal arrows and the shot cannot be picked up again', b.inventory[0].count === 3 && (shots.at(-1)![4] as any).recover === undefined, shots.at(-1));
  const c = make(); c.hotbar[0] = { name: 'bow', count: 1, ench: { infinity: 1 } }; c.inventory[0] = { name: 'spectral_arrow', count: 3 };
  SV.useItem(c, c.hotbar[0], resolve('bow'), 'main');
  ok('Infinity does not save spectral arrows', c.inventory[0].count === 2);
  const d = make(); d.hotbar[0] = { name: 'bow', count: 1 }; d.inventory[0] = { name: 'arrow', count: 3 };
  SV.useItem(d, d.hotbar[0], resolve('bow'), 'main');
  ok('a normal shot consumes one arrow and can be recovered', d.inventory[0].count === 2 && (shots.at(-1)![4] as any).recover === 'arrow');
  const x = make(); x.hotbar[0] = { name: 'crossbow', count: 1, loaded: true, ench: { piercing: 3 } }; SV.useItem(x, x.hotbar[0], resolve('crossbow'), 'main');
  ok('a Piercing III crossbow fires an arrow with pierce 3', (shots.at(-1)![4] as any).pierce === 3, shots.at(-1));
  const t = make(); t.hotbar[0] = { name: 'bow', count: 1 }; t.offhand = { name: 'totem_of_undying', count: 1 }; SV.hurt(t, 500, 'mob'); ok('the totem works from the off-hand', !t.dead && t.offhand === null);
  const m = make(); m.hotbar[0] = { name: 'totem_of_undying', count: 1 }; SV.hurt(m, 500, 'mob'); ok('…and from the main hand', !m.dead && m.hotbar[0] === null);
}

// ================================================================================ 5. Enchantments & death
{
  const e = make();
  for (let x = -6; x <= 6; x++) for (let z = -6; z <= 6; z++) e.setBlock(x, 63, z, ID.water, 0);
  e.setBlock(2, 64, 0, ID.stone, 0);                                                      // a block above water at x=2 stops freezing there
  e.armor[3] = { name: 'diamond_boots', count: 1, ench: { frost_walker: 1 } };
  SV.frostWalker(e, 0.2);
  const ice = (x: number, z: number) => e.getBlock(x, 63, z) === ID.frosted_ice;
  ok('Frost Walker I freezes water under and around the walker (radius 3)', ice(0, 0) && ice(3, 0) && ice(0, -3) && !ice(4, 0) && !ice(3, 3), [ice(0, 0), ice(3, 0), ice(4, 0)]);
  ok('water covered by a block is not frozen', !ice(2, 0));
  const e2 = make(); for (let x = -6; x <= 6; x++) for (let z = -6; z <= 6; z++) e2.setBlock(x, 63, z, ID.water, 0);
  e2.armor[3] = { name: 'iron_boots', count: 1, ench: { frost_walker: 2 } }; SV.frostWalker(e2, 0.2);
  ok('Frost Walker II reaches radius 4', e2.getBlock(4, 63, 0) === ID.frosted_ice && e2.getBlock(5, 63, 0) !== ID.frosted_ice);
  e.armor[3] = null;
  const hasIce = () => [...e.world.values()].some((c: number) => (c & 4095) === ID.frosted_ice);
  let steps = 0; while (steps++ < 400 && hasIce()) { e.elapsed += 1.6; SV.frostWalker(e, 0.1); }
  ok('frosted ice ages 0‥3 and melts back into water in daylight', steps < 400 && e.getBlock(0, 63, 0) === ID.water, steps);
  const n = make(); n.environment.daylight = 0; n.setBlock(0, 63, 0, ID.water, 0); n.armor[3] = { name: 'iron_boots', count: 1, ench: { frost_walker: 1 } }; SV.frostWalker(n, 0.2);
  for (let i = 0; i < 100; i++) { n.elapsed += 2; SV.frostWalker(n, 0.1); }
  ok('in the dark frosted ice does not melt', n.getBlock(0, 63, 0) === ID.frosted_ice);
  const w = make(); w.setBlock(0, 63, 0, ID.water, 0); w.armor[3] = { name: 'iron_boots', count: 1 }; SV.frostWalker(w, 0.2);
  ok('without the enchantment nothing freezes', w.getBlock(0, 63, 0) === ID.water);
}
{
  const e = make(); e.xp = V.xpForLevel(10);
  e.hotbar[0] = { name: 'diamond_sword', count: 1, ench: { curse_of_vanishing: 1 } }; e.hotbar[1] = { name: 'cobblestone', count: 40 };
  e.armor[0] = { name: 'iron_helmet', count: 1, ench: { curse_of_vanishing: 1 } }; e.armor[1] = { name: 'iron_chestplate', count: 1 }; e.offhand = { name: 'torch', count: 8 };
  drops.length = 0;
  const r = SV.hurt(e, 500, 'mob');
  ok('lethal damage kills and drops the inventory', r === 'dead' && e.dead, r);
  ok('Curse of Vanishing items are destroyed, everything else is dropped', !drops.some(d => d[0] === 'diamond_sword' || d[0] === 'iron_helmet') && drops.some(d => d[0] === 'cobblestone' && d[1] === 40) && drops.some(d => d[0] === 'iron_chestplate') && drops.some(d => d[0] === 'torch' && d[1] === 8), drops);
  ok('death empties every slot and resets the XP bar, dropping 7 XP per level', e.hotbar.every((s: any) => !s) && e.armor.every((s: any) => !s) && !e.offhand && e.xp === 0 && drops.some(d => d[0] === 'xp_orb' && d[1] === 70), [e.xp, drops.filter(d => d[0] === 'xp_orb')]);
  const p = make(); SV.pickup(p, 'xp_orb', 70); ok('picked-up orbs add their XP back', p.xp === 70);
}

// ================================================================================ 6. Invisibility / night vision
ok('visibility: normal 1.0, sneaking 0.8, invisible & naked 0.07, invisible in full armour 0.7', V.visibilityPercent({ invisible: false, sneaking: false, armorPieces: 0 }) === 1 && V.visibilityPercent({ invisible: false, sneaking: true, armorPieces: 0 }) === 0.8 && near(V.visibilityPercent({ invisible: true, sneaking: false, armorPieces: 0 }), 0.07) && near(V.visibilityPercent({ invisible: true, sneaking: false, armorPieces: 4 }), 0.7));
ok('night vision: constant for 10+ s, flickers afterwards, off at 0; water fog extends', V.nightVisionScale(30) === 1 && V.nightVisionScale(0) === 0 && V.nightVisionScale(5) <= 1 && V.nightVisionScale(5) >= 0.4 && V.underwaterFog(1).far > 2 * V.underwaterFog(0).far && V.underwaterFog(0).far === 28);

// ================================================================================ 7. Mobs: detection range, piercing arrows, shield deflection
function mobWorld(vis = 1, blockedFrom = 999) {
  const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(70, 1, 0.1, 100);
  const seen: { dmg: number; proj: unknown }[] = [], dropped: [string, number][] = [];
  let result: 'blocked' | 'hit' = 'hit';
  const mobs: MobManager = new MobManager(scene, {
    terrain: { height: () => 73, biome: () => 'plains' } as never, position: new THREE.Vector3(0, 74, 6), camera, dimension: 'overworld',
    getBlock: (x: number) => (x >= blockedFrom ? 1 : 0), damage(n: number) { seen.push({ dmg: n, proj: mobs.attackProj }); return result; }, addItem: () => true, toast() {}, sound() {}, explode() {}, openTrade() {},
    visibility: () => vis, particles: { burst() {}, drop(_p: unknown, n: string, c: number) { dropped.push([n, c]); }, spark() {} } as never,
  });
  return { mobs, seen, dropped, setResult: (r: 'blocked' | 'hit') => { result = r; } };
}
{
  const a = mobWorld(1), z1 = a.mobs.spawn('zombie', 0, 0)!; (a.mobs as any).update(1 / 60, 1, false);
  const b = mobWorld(0.07), z2 = b.mobs.spawn('zombie', 0, 0)!; (b.mobs as any).update(1 / 60, 1, false);
  ok('a zombie 6 blocks away notices a normal player but not an invisible one (range 16 × 0.07 ≈ 1.1)', z1.state === 'chase' && z2.state !== 'chase', [z1.state, z2.state]);
}
{
  const w = mobWorld(); const zs = [0, 3, 6].map(x => w.mobs.spawn('zombie', x, 0)!);
  for (const z of zs) z.group.position.y = 73;
  const hp0 = zs.map(z => z.hp);
  w.mobs.shootPlayerArrow(new THREE.Vector3(-3, 73.9, 0), new THREE.Vector3(1, 0, 0), 30, 5, { pierce: 1, recover: 'arrow' });
  for (let i = 0; i < 60; i++) (w.mobs as any).updateProjectiles(1 / 60);
  const dmg = zs.map((z, i) => hp0[i] - z.hp);
  ok('Piercing I: the arrow passes through exactly two mobs (pierce + 1)', dmg[0] > 0 && dmg[1] > 0 && dmg[2] === 0, dmg);
  const w2 = mobWorld(); const z = w2.mobs.spawn('zombie', 0, 0)!; z.group.position.y = 73; const h0 = z.hp;
  w2.mobs.shootPlayerArrow(new THREE.Vector3(-3, 73.9, 0), new THREE.Vector3(1, 0, 0), 30, 5, { recover: 'arrow' });
  for (let i = 0; i < 40; i++) (w2.mobs as any).updateProjectiles(1 / 60);
  ok('a normal arrow stops in the first mob and is not recoverable', z.hp < h0 && w2.dropped.length === 0 && (w2.mobs as any).projectiles.length === 0);
  const w3 = mobWorld(1, 5); w3.mobs.shootPlayerArrow(new THREE.Vector3(0, 74, 0), new THREE.Vector3(1, 0, 0), 30, 5, { recover: 'arrow' });
  for (let i = 0; i < 40; i++) (w3.mobs as any).updateProjectiles(1 / 60);
  ok('an arrow that sticks in a block drops an arrow item to pick up', w3.dropped.some(d => d[0] === 'arrow'), w3.dropped);
  const w4 = mobWorld(1, 5); w4.mobs.shootPlayerArrow(new THREE.Vector3(0, 74, 0), new THREE.Vector3(1, 0, 0), 30, 5, {});
  for (let i = 0; i < 40; i++) (w4.mobs as any).updateProjectiles(1 / 60);
  ok('Infinity / creative arrows (no recover) leave nothing behind', w4.dropped.length === 0);
}
{
  const w = mobWorld(); w.mobs.launchProjectile('mob_arrow', new THREE.Vector3(0, 75.4, 5.5), new THREE.Vector3(0, 0, 1), 20, undefined, { damage: 3, pierce: 2 });
  (w.mobs as any).updateProjectiles(0.05);
  const pr: any = w.seen[0]?.proj;
  ok('the host sees which projectile hit (position + pierce) so the shield can judge it', !!pr && pr.pierce === 2 && pr.mesh.position.z > 5, w.seen.length);
  const d = mobWorld(); d.setResult('blocked'); d.mobs.launchProjectile('mob_arrow', new THREE.Vector3(0, 75.4, 5.5), new THREE.Vector3(0, 0, 1), 20, undefined, { damage: 3 });
  (d.mobs as any).updateProjectiles(0.05);
  const left = (d.mobs as any).projectiles[0];
  ok('a shield-blocked arrow is deflected: it keeps flying, reversed, as a player arrow', !!left && left.kind === 'player_arrow' && left.v.z < 0, left?.kind);
}

// ================================================================================ 8. Redstone: comparator, repeater lock, pistons
const K = (x: number, y: number, z: number) => x + ',' + y + ',' + z;
class World implements RedstoneHost {
  cells = new Map<string, number>(); fake: any = null; light = 15;
  getCell(x: number, y: number, z: number) { return this.cells.get(K(x, y, z)) ?? 0; }
  setBlock(x: number, y: number, z: number, id: number, state = 0) { const k = K(x, y, z), c = id === 0 ? 0 : id | (state << 12); if ((this.cells.get(k) ?? 0) === c) return false; if (c === 0) this.cells.delete(k); else this.cells.set(k, c); return true; }
  analogSignal(x: number, y: number, z: number) { return SV.analogSignal(this.fake, x, y, z); }
  daylight() { return this.light; }
}
function rs() {
  const w = new World(), r = new Redstone(w);
  w.fake = { getBlock: (x: number, y: number, z: number) => w.getCell(x, y, z) & 4095, getCell: (x: number, y: number, z: number) => w.getCell(x, y, z), containers: {} as Record<string, any>, lecternPages: {} as Record<string, number> };
  const put = (x: number, y: number, z: number, name: string, state = 0) => r.set(x, y, z, name === 'air' ? 0 : ID[name], state);
  const tick = (n = 6) => { for (let i = 0; i < n; i++) r.tick(); };
  const out = (x: number, y: number, z: number) => (r as any).compOut.get(K(x, y, z)) ?? 0;
  return { w, r, put, tick, out, fake: w.fake, cell: (x: number, y: number, z: number) => ({ id: w.getCell(x, y, z) & 4095, state: w.getCell(x, y, z) >>> 12 }) };
}
/** Comparator at x=1 facing +X, measuring the block at x=0 (directly behind it). */
function measure(name: string, state: number, setup?: (c: ReturnType<typeof rs>) => void) { const c = rs(); c.put(0, 1, 0, name, state); setup?.(c); c.put(1, 1, 0, 'comparator', 0); c.tick(); return c.out(1, 1, 0); }
ok('comparator reads cauldron water level 0‥3 and lava as 3', [0, 1, 2, 3, 4].map(s => measure('cauldron', s)).join() === '0,1,2,3,3', [0, 1, 2, 3, 4].map(s => measure('cauldron', s)));
ok('comparator reads composter fill stages 0‥8', [0, 1, 4, 7, 8].map(s => measure('composter', s)).join() === '0,1,4,7,8');
ok('comparator reads the disc in a jukebox (cat = 2, 5 = 15, empty = 0)', measure('jukebox', 0, c => { c.fake.containers['0,1,0'] = [{ name: 'music_disc_cat', count: 1 }]; }) === 2 && measure('jukebox', 0, c => { c.fake.containers['0,1,0'] = [{ name: 'music_disc_5', count: 1 }]; }) === 15 && measure('jukebox', 0) === 0);
ok('music discs map to 1‥15 (13=1 … 11=11 … 5=15) and all exist as items', V.DISC_SIGNAL.music_disc_13 === 1 && V.DISC_SIGNAL.music_disc_11 === 11 && V.DISC_SIGNAL.music_disc_5 === 15 && V.MUSIC_DISCS.every(d => resolve(d)));
{
  const book = { name: 'writable_book', count: 1, pages: ['a', 'b', 'c', 'd', 'e'] };
  const at = (page: number) => measure('lectern', 0, c => { c.fake.containers['0,1,0'] = [book]; c.fake.lecternPages['0,1,0'] = page; });
  ok('comparator reads the lectern page: 1 → 1, 3 of 5 → 8, 5 of 5 → 15', at(0) === 1 && at(2) === 8 && at(4) === 15, [at(0), at(2), at(4)]);
  ok('a one-page book reads 15; an empty lectern 0', V.lecternSignal(0, 1) === 15 && measure('lectern', 0) === 0);
}
ok('comparator reads an end portal frame with an eye (15) and without (0)', measure('end_portal_frame', 4) === 15 && measure('end_portal_frame', 0) === 0);
{
  const full = measure('chest', 0, c => { c.fake.containers['0,1,0'] = Array.from({ length: 27 }, () => ({ name: 'cobblestone', count: 64 })); });
  const one = measure('chest', 0, c => { c.fake.containers['0,1,0'] = [{ name: 'cobblestone', count: 1 }, ...Array(26).fill(null)]; });
  ok('inventory fullness: full chest 15, one item 1', full === 15 && one === 1, [full, one]);
  const c = rs(); c.put(-1, 1, 0, 'chest'); c.fake.containers['-1,1,0'] = Array.from({ length: 27 }, () => ({ name: 'cobblestone', count: 64 })); c.put(0, 1, 0, 'stone'); c.put(1, 1, 0, 'comparator', 0); c.tick();
  ok('a solid block between comparator and container lets it read through', c.out(1, 1, 0) === 15, c.out(1, 1, 0));
  const d = rs(); d.put(-1, 1, 0, 'chest'); d.fake.containers['-1,1,0'] = [{ name: 'cobblestone', count: 64 }]; d.put(0, 1, 0, 'glass'); d.put(1, 1, 0, 'comparator', 0); d.tick();
  ok('…but not through glass', d.out(1, 1, 0) === 0);
  const s = rs(); s.put(0, 1, 0, 'redstone_block'); s.put(1, 1, 0, 'comparator', 0); s.put(1, 1, 1, 'chest'); s.fake.containers['1,1,1'] = Array.from({ length: 27 }, () => ({ name: 'cobblestone', count: 64 })); s.tick();
  ok('side inputs only take redstone power, never container contents', s.out(1, 1, 0) === 15, s.out(1, 1, 0));
}
{
  // Repeater lock: target repeater at (2,1,0) facing +X; a powered repeater at (2,1,-1) facing +Z points into its side.
  const rep = (c: ReturnType<typeof rs>) => ((c.r as any).repOut.get(K(2, 1, 0)) ?? 0) > 0;
  const c = rs(); c.put(2, 1, 0, 'repeater', 0); c.put(2, 1, -1, 'repeater', 1); c.put(2, 1, -2, 'redstone_block'); c.tick(8);
  ok('a powered repeater facing the side locks the repeater', c.r.isLocked(2, 1, 0));
  c.put(1, 1, 0, 'redstone_block'); c.tick(10);
  ok('a locked repeater ignores its input (stays off)', !rep(c));
  c.put(2, 1, -2, 'air'); c.tick(12);
  ok('when the lock goes away the repeater catches up with its input', !c.r.isLocked(2, 1, 0) && rep(c));
  c.put(2, 1, -2, 'redstone_block'); c.tick(8); c.put(1, 1, 0, 'air'); c.tick(10);
  ok('a locked repeater holds its ON state after the input is removed', c.r.isLocked(2, 1, 0) && rep(c));
  c.put(2, 1, -2, 'air'); c.tick(12);
  ok('…and turns off once unlocked', !c.r.isLocked(2, 1, 0) && !rep(c));
  const d = rs(); d.put(2, 1, 0, 'repeater', 0); d.put(2, 1, -1, 'redstone_wire'); d.put(2, 1, -2, 'redstone_block'); d.tick(8);
  ok('plain redstone dust on the side does not lock (only repeaters / comparators do)', !d.r.isLocked(2, 1, 0));
}
{
  const pushes = (name: string) => { const c = rs(); c.put(0, 1, 0, 'piston', 0); c.put(-1, 1, 0, 'lever', 2); c.put(1, 1, 0, name); c.tick(2); c.put(-1, 1, 0, 'lever', 10); c.tick(4); return { head: c.cell(1, 1, 0).id === ID.piston_head, moved: c.cell(2, 1, 0).id === ID[name] }; };
  const stuck = ['chest', 'furnace', 'blast_furnace', 'smoker', 'barrel', 'hopper', 'dispenser', 'dropper', 'brewing_stand', 'lectern', 'jukebox', 'enchanting_table', 'obsidian', 'crying_obsidian', 'bedrock', 'beacon', 'ender_chest', 'anvil', 'grindstone', 'spawner', 'daylight_detector', 'crafter', 'trapped_chest', 'respawn_anchor', 'end_portal_frame'].filter(n => ID[n] !== undefined);
  const bad = stuck.filter(n => { const r = pushes(n); return r.head || r.moved; });
  ok(`blocks with block entities / hard-coded immovables never move (${stuck.length} checked)`, bad.length === 0, bad);
  const pm = pushes('stone'); ok('ordinary blocks still get pushed', pm.head && pm.moved, pm);
  if (ID.shulker_box !== undefined) { const c = rs(); c.put(0, 1, 0, 'piston', 0); c.put(-1, 1, 0, 'lever', 10); c.put(1, 1, 0, 'shulker_box'); c.tick(6); ok('shulker boxes break instead of moving', c.cell(1, 1, 0).id === ID.piston_head && c.cell(2, 1, 0).id !== ID.shulker_box); }
  const line = (n: number) => { const c = rs(); c.put(0, 1, 0, 'piston', 0); c.put(-1, 1, 0, 'lever', 10); for (let i = 1; i <= n; i++) c.put(i, 1, 0, 'stone'); c.tick(6); return c.cell(1, 1, 0).id === ID.piston_head; };
  ok('push limit stays 12 blocks (12 moves, 13 does not)', line(12) && !line(13));
}

// ================================================================================ 9. Maps
{
  const flat = (x: number, z: number) => { const lake = x >= 20 && x < 30 && z >= -10 && z < 10; return { color: lake ? '#4040ff' : '#7fb238', y: 63, water: lake, depth: 3 }; };
  const m = newMap(1, 'overworld', 0, 0, 0);
  ok('a fresh map is centred on a 128-block grid cell (x=100 → centre 128)', m.cx === 0 && newMap(2, 'overworld', 100, 0, 0).cx === 128);
  ok('scale-1 maps cover 256 blocks (grid 256, centre offset 64)', newMap(4, 'overworld', 0, 0, 1).cx === 64 && newMap(4, 'overworld', 0, 0, 1).cz === 64);
  let changed = 0; for (let i = 0; i < 16; i++) if (updateMap(m, 0, 0, flat, 64)) changed++;
  const n1 = exploredCount(m);
  ok('a fresh map fills in a disc (r = 64 blocks) around the player at once (changes cascade across columns like Java)', changed >= 1 && n1 > 11000 && n1 < MAP_SIZE * MAP_SIZE, [changed, n1]);
  ok('unexplored pixels outside the radius stay empty', m.px[0] === 0 && m.px[64 * MAP_SIZE + 64] !== 0);
  ok('water gets its own colour and depth shading', m.pal.includes('#4040ff') && m.pal.includes('#7fb238'));
  const before = exploredCount(m); for (let i = 0; i < 16; i++) updateMap(m, 50, 0, flat, 64);
  ok('moving to a new spot paints new ground (the map grows while you walk)', exploredCount(m) > before, [before, exploredCount(m)]);
  const nether = newMap(5, 'nether', 0, 0, 0); for (let i = 0; i < 16; i++) updateMap(nether, 0, 0, flat, 64);
  ok("nether maps show Java's dirt/stone noise instead of terrain, with half the radius", nether.pal.every(c => c === '#976d4d' || c === '#707070') && exploredCount(nether) > 1500 && exploredCount(nether) < n1, [nether.pal, exploredCount(nether)]);
  const lk = lockedCopy(m, 9); const lc = exploredCount(lk); for (let i = 0; i < 16; i++) updateMap(lk, 300, 300, flat, 64);
  ok('locked maps are copies that never change again', lk.locked && lk.id === 9 && exploredCount(lk) === lc);
  const z = zoomedOut(m, 10);
  ok('zooming out makes a new, larger-scale map that keeps what was drawn', z.scale === 1 && z.id === 10 && exploredCount(z) > 1000 && z.pal.includes('#4040ff'), [z.scale, exploredCount(z)]);
  const back = deserializeMap(serializeMap(m));
  ok('maps survive a save / load round trip', back.id === m.id && back.px.every((v, i) => v === m.px[i]) && back.pal.join() === m.pal.join());
}
{
  const e = make(); e.hotbar[0] = { name: 'map', count: 2 }; e.position.set(100, 64, 0);
  SV.useItem(e, e.hotbar[0], resolve('map'));
  const fm = e.hotbar.find((s: any) => s?.name === 'filled_map');
  ok('using an empty map turns one into a filled map centred like Java (x=100 → 128)', !!fm && e.maps.get(fm.mapId)?.cx === 128 && e.hotbar[0].count === 1 && e.hotbar[0].name === 'map', [fm, e.hotbar[0]]);
  const f = make(); f.hotbar[0] = { name: 'filled_map', count: 1, mapId: SV.newMapFor(f) }; f.inventory[0] = { name: 'filled_map', count: 1, mapId: SV.newMapFor(f) };
  f.selected = 0; run(f, 1.8); const a = exploredCount(f.maps.get(f.hotbar[0].mapId)), b = exploredCount(f.maps.get(f.inventory[0].mapId));
  ok('only the map in the selected slot is updated while walking (the one in the bag is not)', a > 5000 && b === 0, [a, b]);
  f.offhand = f.inventory[0]; f.inventory[0] = null; run(f, 1.8);
  ok('a map in the off-hand is updated too', exploredCount(f.maps.get(f.offhand.mapId)) > 5000);
  f.inventory[0] = { name: 'paper', count: 1 }; f.hotbar[1] = { ...f.hotbar[0] };
  const id0 = f.hotbar[0].mapId; ok('cartography: paper zooms out into a new map', SV.doCartography(f, 0, 9) && f.hotbar[0].mapId !== id0 && f.maps.get(f.hotbar[0].mapId).scale === 1 && f.hotbar[1].mapId === id0);
  f.inventory[0] = { name: 'glass_pane', count: 1 }; ok('cartography: a glass pane locks it', SV.doCartography(f, 0, 9) && f.maps.get(f.hotbar[0].mapId).locked);
  f.inventory[0] = { name: 'paper', count: 1 }; ok('locked maps cannot be zoomed', !SV.doCartography(f, 0, 9));
  f.inventory[0] = { name: 'map', count: 1 }; const cnt = f.hotbar.filter((s: any) => s).length + f.inventory.filter((s: any) => s).length;
  ok('an empty map duplicates (same map id)', SV.doCartography(f, 1, 9) && f.hotbar.filter((s: any) => s).length + f.inventory.filter((s: any) => s).length === cnt);
  const old = make(); old.hotbar[0] = { name: 'filled_map', count: 1, label: '200,-300|2|' }; const md = SV.mapOf(old, old.hotbar[0]);
  ok('legacy label maps are converted to real map data', !!md && old.hotbar[0].mapId === md!.id && md!.scale === 1 && !old.hotbar[0].label);
}

// ================================================================================ 10. Loom / banners
{
  const e = make(); e.hotbar[0] = { name: 'white_banner', count: 2 }; e.hotbar[1] = { name: 'red_dye', count: 10 };
  ok('loom adds a dyed layer (banner stack of 2 splits, dye consumed)', SV.doLoom(e, 0, 1, 'stripe_top') && e.hotbar[0].count === 1 && e.hotbar[1].count === 9 && e.countItem('white_banner') === 2 && e.inventory.concat(e.hotbar).some((s: any) => s?.patterns?.[0]?.p === 'stripe_top' && s.patterns[0].c === 'red'));
  const f = make(); f.hotbar[0] = { name: 'blue_banner', count: 1 }; f.hotbar[1] = { name: 'yellow_dye', count: 20 };
  ok('creeper charge needs its banner-pattern item', !SV.doLoom(f, 0, 1, 'creeper'));
  f.hotbar[2] = { name: 'creeper_banner_pattern', count: 1 };
  ok('with the pattern item it works and the item is NOT consumed (Java)', SV.doLoom(f, 0, 1, 'creeper', 2) && f.hotbar[2]?.count === 1 && f.hotbar[0].patterns.length === 1);
  for (const p of ['circle', 'cross', 'border', 'gradient', 'stripe_center']) SV.doLoom(f, 0, 1, p);
  ok('a banner holds at most six layers', f.hotbar[0].patterns.length === 6 && !SV.doLoom(f, 0, 1, 'rhombus'), f.hotbar[0].patterns.length);
  ok('layer order is kept bottom → top with each dye colour', f.hotbar[0].patterns.map((l: any) => l.p).join() === 'creeper,circle,cross,border,gradient,stripe_center' && f.hotbar[0].patterns.every((l: any) => l.c === 'yellow'));
  const g = make(); g.inventory[0] = { name: 'white_banner', count: 1, patterns: [{ p: 'circle', c: 'red' }] }; SV.addStack(g, { name: 'white_banner', count: 1 });
  ok('patterned banners do not stack with plain ones', g.inventory[0].count === 1 && g.countItem('white_banner') === 2);
  ok('addLayer validates dye and pattern ids', addLayer([], 'nope', 'red') === null && addLayer([], 'circle', 'nope') === null && addLayer([], 'circle', 'red')?.length === 1);
}
{
  // Render the layers through a recording canvas: base colour first, then each layer's mask in its own dye colour, in order.
  const log: string[] = [];
  const mkCtx = (tag: string): any => new Proxy({ canvas: { width: 20, height: 40 } } as any, { get: (t, k: string) => (k in t ? t[k] : (..._a: unknown[]) => { log.push(`${tag}:${k}`); return k === 'createLinearGradient' ? { addColorStop() {} } : undefined; }), set: (t, k: string, v) => { t[k] = v; if (k === 'fillStyle') log.push(`${tag}:fill=${v}`); return true; } });
  let n = 0;
  (globalThis as any).document = { createElement: () => { const tag = 'L' + n++; return { width: 0, height: 0, getContext: () => mkCtx(tag) }; } };
  paintBanner(mkCtx('main'), 'white', [{ p: 'stripe_top', c: 'red' }, { p: 'circle', c: 'blue' }, { p: 'half_vertical', c: 'lime' }], 2);
  const fills = log.filter(l => l.startsWith('main:fill=')).map(l => l.split('=')[1]);
  const layerFills = log.filter(l => /^L\d+:fill=/.test(l)).map(l => l.split('=')[1]);
  ok('banner base colour is painted first (white = ' + DYE_HEX.white + ')', fills[0] === DYE_HEX.white, fills);
  ok('each layer is drawn on its own canvas in its dye colour, in order (red → blue → lime)', layerFills.join() === [DYE_HEX.red, DYE_HEX.blue, DYE_HEX.lime].join(), layerFills);
  ok('and composited onto the banner in order (3 drawImage calls)', log.filter(l => l === 'main:drawImage').length === 3);
  ok(`${BANNER_PATTERNS.length} patterns are defined and every one draws without error`, BANNER_PATTERNS.every(p => { try { paintBanner(mkCtx('x'), 'black', [{ p: p.id, c: 'white' }]); return true; } catch { return false; } }));
}

// ================================================================================ 11. Books, lectern, cauldron
{
  const b: any = { name: 'writable_book', count: 1 };
  ok('a new book and quill has one blank page; pages can be added up to 100', SV.bookPages(b).length === 1 && (() => { while (SV.bookAddPage(b)); return b.pages.length === V.BOOK_MAX_PAGES; })());
  SV.bookEdit(b, 0, 'x'.repeat(2000)); ok('page text is capped at 1024 characters', b.pages[0].length === V.BOOK_MAX_PAGE_CHARS);
  SV.bookRemovePage(b, 5); ok('pages can be deleted (but never the last one)', b.pages.length === 99);
  const e = make(); const c: any = { name: 'writable_book', count: 1, pages: ['Once upon a time', 'The end'] };
  ok('signing needs a title', !SV.bookSign(e, c, '   ') && c.name === 'writable_book');
  ok('signing makes a written book (original) with the title cut to 15 chars', SV.bookSign(e, c, 'A very long title indeed') && c.name === 'written_book' && c.title === 'A very long tit' && c.gen === 0 && c.author === 'Player' && c.pages.length === 2, c);
  ok('a written book can no longer be edited', !SV.bookEdit(c, 0, 'hack') && c.pages[0] === 'Once upon a time');
  e.hotbar[0] = c; ok('copying needs a book and quill', !SV.bookCopy(e, c));
  e.inventory[0] = { name: 'writable_book', count: 2 };
  ok('copy: generation 1, consumes one book and quill', SV.bookCopy(e, c) && e.countItem('writable_book') === 1 && e.inventory.concat(e.hotbar).some((s: any) => s?.gen === 1 && s.pages.join() === c.pages.join()));
  const g1 = e.inventory.concat(e.hotbar).find((s: any) => s?.gen === 1); ok('a copy can be copied again (gen 2) but a copy of a copy cannot', SV.bookCopy(e, g1) && !V.canCopyBook(2) && V.canCopyBook(1));
  const lec = make(); lec.stationKey = '1,1,1'; lec.containers['1,1,1'] = [{ name: 'written_book', count: 1, pages: ['a', 'b', 'c'] }];
  SV.setLecternPage(lec, 9); ok('lectern page is clamped to the book and remembered per lectern', SV.lecternPage(lec) === 2 && lec.lecternPages['1,1,1'] === 2);
}
{
  const e = make(); e.hotbar[0] = { name: 'water_bucket', count: 1 }; e.setBlock(5, 61, 5, ID.cauldron, 0);
  const t = { x: 5, y: 61, z: 5 }; const st = () => blockState(e.getCell(5, 61, 5));
  ok('water bucket fills a cauldron to 3 and returns an empty bucket', SV.cauldronUse(e, t, e.hotbar[0]) && st() === 3 && e.hotbar[0].name === 'bucket');
  e.hotbar[0] = { name: 'glass_bottle', count: 3 }; SV.cauldronUse(e, t, e.hotbar[0]);
  ok('a glass bottle takes one layer (3 → 2) and becomes a water bottle', st() === 2 && e.inventory.concat(e.hotbar).some((s: any) => s?.name === 'water_bottle') && e.hotbar[0].count === 2);
  SV.cauldronUse(e, t, { name: 'water_bottle', count: 1 });
  ok('water bottles add layers up to 3, then do nothing', st() === 3 && !SV.cauldronUse(e, t, { name: 'water_bottle', count: 1 }));
  e.hotbar[0] = { name: 'bucket', count: 1 }; ok('a bucket empties a full cauldron into a water bucket', SV.cauldronUse(e, t, e.hotbar[0]) && st() === 0 && e.hotbar[0].name === 'water_bucket');
  e.hotbar[0] = { name: 'glass_bottle', count: 1 }; ok('an empty cauldron gives no water', !SV.cauldronUse(e, t, e.hotbar[0]));
  e.hotbar[0] = { name: 'lava_bucket', count: 1 }; SV.cauldronUse(e, t, e.hotbar[0]); ok('lava fills the cauldron (comparator reads 3)', st() === 4 && V.cauldronSignal(st()) === 3);
}

console.log(`\n${pass}/${pass + fail} fidelity checks passed`);
if (fail) process.exitCode = 1;
