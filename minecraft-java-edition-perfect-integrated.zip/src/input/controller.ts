import { stick, movement, look, clamp } from './math';
import type { Settings } from '../game/types';
export class InputController {
  keys=new Set<string>();stickX=0;stickForward=0;yaw=-.55;pitch=-.08;jump=false;sneak=false;sneakHeld=false;sprint=false;flying=false;breakHeld=false;useHeld=false;active=false;locked=false;
  private cleanups:(()=>void)[]=[];private lookPointer:number|null=null;private lastX=0;private lastY=0;private downAt=0;private moved=0;private touchBreaking=false;private lastJump=0;private padButtons:boolean[]=[];private padJump=false;private padBreak=false;private padSneak=false;
  /** Extra fingers on the canvas (the first one looks around): a quick tap with any of them is a `use`. */
  private tapPointers=new Map<number,{t:number;x:number;y:number;moved:number}>();
  constructor(public canvas:HTMLCanvasElement,public settings:Settings,public action:(name:string)=>void,public lookChanged:()=>void=()=>{}){
    const on=(target:EventTarget,event:string,fn:EventListener,options?:AddEventListenerOptions)=>{target.addEventListener(event,fn,options);this.cleanups.push(()=>target.removeEventListener(event,fn,options));};
    on(window,'keydown',((e:KeyboardEvent)=>{
      if((e.target as HTMLElement)?.matches('input,textarea,select'))return;
      if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Tab','F3','F5'].includes(e.code))e.preventDefault();
      if(e.code==='Escape'){this.action('escape');return;}
      if(e.code==='KeyE'&&!e.repeat){this.action(this.active?'inventory':'escape');return;}if(!this.active)return;if(e.code==='KeyT'||e.code==='Slash'){this.action(e.code==='Slash'?'slash':'chat');return;}
      if(e.code==='F3'&&!e.repeat){this.action('debug');return;}if(e.code==='F5'&&!e.repeat){this.action('perspective');return;}
      if(/^Digit[1-9]$/.test(e.code)){this.action('slot:'+(Number(e.code.slice(-1))-1));return;}
      if(e.code==='KeyQ'&&!e.repeat){this.action('drop');return;}if(e.code==='KeyF'&&!e.repeat){this.action('swap');return;}
      if(e.code==='Space'&&!e.repeat){const now=performance.now();if(now-this.lastJump<280)this.action('fly');this.lastJump=now;}
      this.keys.add(e.code);
    }) as EventListener);
    on(window,'keyup',((e:KeyboardEvent)=>{this.keys.delete(e.code);}) as EventListener);
    on(canvas,'pointerdown',((e:PointerEvent)=>{
      if(!this.active)return;e.preventDefault();canvas.setPointerCapture(e.pointerId);
      if(e.pointerType==='touch'){if(this.lookPointer!==null){this.tapPointers.set(e.pointerId,{t:e.timeStamp,x:e.clientX,y:e.clientY,moved:0});return;}this.lookPointer=e.pointerId;this.lastX=e.clientX;this.lastY=e.clientY;this.downAt=performance.now();this.moved=0;this.touchBreaking=false;}
      else if(e.button===0){this.breakHeld=true;if(!document.pointerLockElement)this.lock();this.lookPointer=e.pointerId;this.lastX=e.clientX;this.lastY=e.clientY;}
      else if(e.button===2){this.useHeld=true;this.action('use');}
    }) as EventListener);
    on(canvas,'pointermove',((e:PointerEvent)=>{
      if(!this.active)return;
      if(this.locked&&e.pointerType!=='touch'){if(Math.abs(e.movementX)<300&&Math.abs(e.movementY)<300)this.rotate(e.movementX,e.movementY);return;}
      if(e.pointerId!==this.lookPointer){const tp=this.tapPointers.get(e.pointerId);if(tp){tp.moved+=Math.abs(e.clientX-tp.x)+Math.abs(e.clientY-tp.y);tp.x=e.clientX;tp.y=e.clientY;}return;}const dx=e.clientX-this.lastX,dy=e.clientY-this.lastY;this.lastX=e.clientX;this.lastY=e.clientY;this.moved+=Math.abs(dx)+Math.abs(dy);this.rotate(dx,dy);
      if(this.moved>12)this.touchBreaking=false;
    }) as EventListener);
    const release=(e:PointerEvent)=>{
      const tp=this.tapPointers.get(e.pointerId);if(tp){this.tapPointers.delete(e.pointerId);if(e.type!=='pointercancel'&&e.timeStamp-tp.t<260&&tp.moved<14)this.action('use');}
      if(e.pointerType==='touch'&&e.pointerId===this.lookPointer){if(e.type!=='pointercancel'&&performance.now()-this.downAt<220&&this.moved<12)this.action('use');this.lookPointer=null;this.breakHeld=false;this.touchBreaking=false;}
      else if(e.pointerType!=='touch'){if(e.button===0)this.breakHeld=false;if(e.button===2)this.useHeld=false;this.lookPointer=null;}
      if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);
    };
    on(canvas,'pointerup',release as EventListener);on(canvas,'pointercancel',release as EventListener);
    on(canvas,'contextmenu',((e:Event)=>e.preventDefault()) as EventListener);
    on(canvas,'wheel',((e:WheelEvent)=>{if(this.active){e.preventDefault();this.action('slot:'+(e.deltaY>0?'next':'previous'));}}) as EventListener,{passive:false});
    on(document,'pointerlockchange',(()=>{this.locked=document.pointerLockElement===canvas;if(!this.locked)this.reset();}) as EventListener);
    on(window,'blur',(()=>this.reset()) as EventListener);on(document,'visibilitychange',(()=>{if(document.hidden)this.reset();}) as EventListener);
  }
  rotate(dx:number,dy:number){const next=look(this.yaw,this.pitch,dx,dy,.0025*this.settings.sensitivity,this.settings.invertX,this.settings.invertY);this.yaw=next.yaw;this.pitch=next.pitch;this.lookChanged();}
  setStick(dx:number,dy:number,radius=48){const s=stick(dx,dy,radius);this.stickX=s.x;this.stickForward=s.forward;if(Math.hypot(s.x,s.forward)>.94)this.sprint=true;else if(!this.keys.has('ControlLeft'))this.sprint=false;}
  lock(){if(this.settings.touch||!this.active)return;try{const p=this.canvas.requestPointerLock?.();if(p&&typeof p.catch==='function')p.catch(()=>{});}catch{this.locked=false;}}
  unlock(){if(document.pointerLockElement===this.canvas)document.exitPointerLock();this.reset();}
  reset(){this.keys.clear();this.stickX=0;this.stickForward=0;this.jump=false;this.sneak=false;this.sneakHeld=false;this.sprint=false;this.breakHeld=false;this.useHeld=false;this.lookPointer=null;this.touchBreaking=false;this.tapPointers.clear();}
  setActive(active:boolean){this.active=active;if(!active)this.unlock();}
  update(dt:number){
    if(!this.active)return;
    if(this.lookPointer!==null&&!this.locked&&performance.now()-this.downAt>240&&this.moved<12){this.breakHeld=true;this.touchBreaking=true;}
    const gp=navigator.getGamepads?.()[0];
    this.padJump=gp?.buttons[0]?.pressed??false;this.padBreak=gp?.buttons[7]?.pressed??false;this.padSneak=gp?.buttons[1]?.pressed??false;
    if(gp){const dead=(v:number)=>Math.abs(v)<.15?0:v;this.stickX=dead(gp.axes[0]);this.stickForward=-dead(gp.axes[1]);this.yaw-=dead(gp.axes[2])*dt*2*this.settings.sensitivity;this.pitch=clamp(this.pitch-dead(gp.axes[3])*dt*2,-1.553,1.553);
      gp.buttons.forEach((b,i)=>{if(b.pressed&&!this.padButtons[i]){if(i===5){this.useHeld=true;this.action('use');}if(i===9)this.action('escape');if(i===3)this.action('inventory');if(i===4)this.action('slot:previous');}if(!b.pressed&&this.padButtons[i]&&i===5)this.useHeld=false;this.padButtons[i]=b.pressed;});
    }
  }
  get move(){const keyboardX=+this.keys.has('KeyD')-+this.keys.has('KeyA')+ +this.keys.has('ArrowRight')-+this.keys.has('ArrowLeft'),keyboardF=+this.keys.has('KeyW')-+this.keys.has('KeyS')+ +this.keys.has('ArrowUp')-+this.keys.has('ArrowDown');const x=clamp(this.stickX+keyboardX,-1,1),f=clamp(this.stickForward+keyboardF,-1,1),length=Math.max(1,Math.hypot(x,f));return movement(x/length,f/length,this.yaw);}
  /** Sneaking: the touch latch (`sneak`), or any sneak key / button that is physically down. */
  get crouch(){return this.sneak||this.sneakHeld||this.padSneak||this.keys.has('ShiftLeft')||this.keys.has('ShiftRight');}
  /** Flying descent: only while a key / button is held down — a latched touch sneak never counts. */
  get descend(){return this.sneakHeld||this.padSneak||this.keys.has('ShiftLeft')||this.keys.has('ShiftRight');}
  get run(){return this.sprint||this.keys.has('ControlLeft');}
  get ascend(){return this.jump||this.keys.has('Space')||this.padJump;}
  get mining(){return this.breakHeld||this.padBreak||this.touchBreaking;}
  dispose(){this.unlock();this.cleanups.forEach(f=>f());this.cleanups=[];}
}
