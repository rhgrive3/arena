// Room-variant builders for the woodland mansion, the ancient city and the bastion remnant (Minecraft Wiki structure pages).
//  * Woodland mansion – three floors of irregular rooms: neighbouring cells merge at random into 1×1 / 1×2 rooms, rooms are
//    linked by random side doors, and each room draws a type (chest storage, illager jail, cat statue, flower garden, library,
//    bedroom, dining room, smithy, spider room, obsidian vault …).
//  * Ancient city – city centre with the reinforced-deepslate frame, the redstone laboratory hidden below it, two long
//    deepslate-brick colonnades, barracks with bunk beds and an ice box.
//  * Bastion remnant – four variants built differently: treasure room, hoglin stables, bridge and housing units.
import { type Put, type StructHost, bid, cell, fill, shell, hash2, hash3, mulberry, tag, bed, stairsUp, ladderOn, attachOn, doorOn, PANE_X, PANE_Z } from './common';

interface Site { x: number; y: number; z: number }

// ======================================================================================================================
// Woodland mansion
// ======================================================================================================================
export const MANSION_ROOM_TYPES = ['storage', 'jail', 'cat_statue', 'flower_garden', 'library', 'bedroom', 'dining', 'smithy', 'spider', 'obsidian', 'empty'] as const;
export type MansionRoomType = typeof MANSION_ROOM_TYPES[number];
export interface MansionRoom {
  floor: number; side: -1 | 1; cells: number;
  /** Interior bounds and walking level. */
  x0: number; x1: number; z0: number; z1: number; y: number;
  doorX: number; type: MansionRoomType;
  /** X of the side doors that link this room to the next one on the same floor and side. */
  link: number | null;
}
const CELL_START = [1, 9, 17, 25], CELL_END = [7, 15, 23, 29], CELL_DOOR = [4, 12, 20, 27];
const MANSIONS = new Map<string, MansionRoom[]>();

/** Deterministic room plan of the mansion at `p` (31×21 footprint, three floors, corridor along X). */
export function mansionLayout(seed: number, p: Site): MansionRoom[] {
  const key = seed + ':' + p.x + ',' + p.y + ',' + p.z, hit = MANSIONS.get(key);
  if (hit) return hit;
  const rnd = mulberry((Math.imul(seed | 0, 2654435761) ^ Math.imul(p.x, 40503) ^ Math.imul(p.z, 65599)) >>> 0), rooms: MansionRoom[] = [], X0 = p.x - 15;
  for (let floor = 0; floor < 3; floor++) for (const side of [-1, 1] as const) {
    for (let i = 0; i < 4;) {
      const cells = i < 3 && rnd() < 0.4 ? 2 : 1;
      rooms.push({
        floor, side, cells, x0: X0 + CELL_START[i], x1: X0 + CELL_END[i + cells - 1], z0: side < 0 ? p.z - 9 : p.z + 3, z1: side < 0 ? p.z - 3 : p.z + 9, y: p.y + floor * 5,
        doorX: X0 + CELL_DOOR[i], type: 'empty', link: i + cells < 4 && rnd() < 0.55 ? X0 + CELL_END[i + cells - 1] + 1 : null,
      });
      i += cells;
    }
  }
  // The signature rooms appear in every mansion; the others are drawn at random.
  const order = rooms.map((_, i) => i);
  for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
  const required: MansionRoomType[] = ['storage', 'jail', 'cat_statue', 'flower_garden'];
  order.forEach((ri, n) => { rooms[ri].type = n < required.length ? required[n] : MANSION_ROOM_TYPES[Math.floor(rnd() * MANSION_ROOM_TYPES.length)]; });
  if (MANSIONS.size > 32) MANSIONS.clear();
  MANSIONS.set(key, rooms);
  return rooms;
}

export function mansion(t: StructHost, put: Put, p: Site) {
  const cob = bid('cobblestone'), plank = bid('dark_oak_planks', 'oak_planks'), log = bid('dark_oak_log', 'oak_log'), birch = bid('birch_planks', 'oak_planks'), carpet = bid('red_carpet', 'air');
  const X0 = p.x - 15, X1 = p.x + 15, Z0 = p.z - 10, Z1 = p.z + 10, y = p.y, rooms = mansionLayout(t.seed, p), s = t.seed + 7400;
  const P = (x: number, yy: number, z: number, b: number) => put(x, yy, z, b, true);
  // Cross walls that survive (a merged room swallows the wall between its two cells).
  const merged = new Set<string>();
  for (const r of rooms) if (r.cells === 2) merged.add(r.floor + ':' + r.side + ':' + (r.x0 - X0 + 7));
  for (let z = Z0; z <= Z1; z++) for (let x = X0; x <= X1; x++) {
    for (let dy = 2; dy <= 8; dy++) P(x, y - dy, z, cob);
    const edgeX = x === X0 || x === X1, edgeZ = z === Z0 || z === Z1, dzc = z - p.z, dxc = x - X0, side = dzc > 0 ? 1 : -1;
    for (let k = 0; k < 3; k++) {
      const fy = y - 1 + k * 5;
      P(x, fy, z, k === 0 ? cob : plank);
      for (let dy = 1; dy <= 4; dy++) {
        let b = 0;
        if (edgeX || edgeZ) {
          const along = edgeX ? z - Z0 : dxc;
          b = (edgeX && edgeZ) || along % 5 === 0 ? log : (dy === 2 || dy === 3) && along % 5 !== 1 && along % 5 !== 4 ? cell('glass_pane', edgeZ ? PANE_X : PANE_Z, 'glass') : plank;
        } else if (Math.abs(dzc) === 2) b = birch;
        else if (Math.abs(dzc) > 2 && dxc % 8 === 0 && !merged.has(k + ':' + side + ':' + dxc)) b = birch;
        else if (Math.abs(dzc) <= 1) b = dy === 1 ? carpet : dy === 4 && dzc === 0 && dxc % 8 === 4 ? bid('lantern', 'torch') : 0;
        P(x, fy + dy, z, b);
      }
    }
    P(x, y + 14, z, plank);
  }
  for (let r = 0; r <= 11; r++) fill(put, X0 - 1, y + 15 + r, Z0 - 1 + r, X1 + 1, y + 15 + r, Z1 + 1 - r, r === 11 ? log : plank);
  // Grand entrance on the west end of the corridor.
  for (let dz = -1; dz <= 1; dz++) { for (let dy = 0; dy <= 2; dy++) P(X0, y + dy, p.z + dz, 0); P(X0 - 1, y - 1, p.z + dz, cob); }
  // Staircases in the corridor: ground → first floor on the south side, first → second on the north side.
  for (const [k, dxc0, dz] of [[0, 6, 1], [1, 14, -1]] as const) for (let i = 0; i < 5; i++) {
    const x = X0 + dxc0 + i, base = y + k * 5;
    for (let yy = base; yy < base + i; yy++) P(x, yy, p.z + dz, plank);
    P(x, base + i, p.z + dz, cell('dark_oak_stairs', stairsUp(1), 'oak_planks'));
    for (let yy = base + i + 1; yy <= base + 7; yy++) P(x, yy, p.z + dz, 0);
  }

  for (const r of rooms) {
    const near = p.z + r.side * 3, far = r.side < 0 ? r.z0 : r.z1, zc = p.z + r.side * 6, mid = (r.x0 + r.x1) >> 1, Y = r.y, toFar = r.side;
    const R = (x: number, dy: number, z: number, b: number) => P(x, Y + dy, z, b);
    for (let dy = 0; dy <= 1; dy++) { R(r.doorX, dy, p.z + r.side * 2, 0); if (r.link !== null) R(r.link, dy, zc, 0); }
    R(r.doorX, 2, near, cell('torch', attachOn(r.side > 0 ? 0 : 2)));
    const free = (x: number, z: number) => !(x === r.doorX && (z === near || z === near + toFar)) && !(z === zc && (x === r.x0 || x === r.x1));
    switch (r.type) {
      case 'storage': {
        let n = 0;
        for (let x = r.x0 + 1; x <= r.x1 - 1 && n < 4; x += 2, n++) { R(x, 0, far, bid('chest')); tag(t, x, Y, far, 'mansion_storage'); }
        R(r.x0, 0, far, bid('barrel', 'oak_planks')); R(r.x1, 0, far, plank); R(r.x1, 1, far, plank); R(r.x1, 0, far - toFar, bid('barrel', 'oak_planks'));
        break;
      }
      case 'jail': {
        const zb = far - toFar * 2;
        for (let x = r.x0; x <= r.x1; x++) {
          const rel = (x - r.x0) % 3;
          for (let dy = 0; dy <= 2; dy++) {
            if (rel === 2) { R(x, dy, far, cob); R(x, dy, far - toFar, cob); }
            R(x, dy, zb, rel === 0 && dy <= 1 ? cell('iron_door', doorOn(r.side > 0 ? 0 : 2) | (dy ? 4 : 0), 'iron_bars') : cell('iron_bars', PANE_X, 'cobblestone'));
          }
        }
        break;
      }
      case 'cat_statue': {
        const wool = bid('black_wool', 'white_wool');
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 0; dx++) for (let dy = 0; dy <= 1; dy++) R(mid + dx, dy, zc + dz, wool);   // body
        for (let dx = -1; dx <= 0; dx++) { R(mid + dx, 1, zc - toFar * 2, wool); R(mid + dx, 2, zc - toFar * 2, wool); R(mid + dx, 3, zc - toFar * 2, dx ? wool : 0); }
        R(mid, 3, zc - toFar * 2, wool);                                                                                                // ears
        R(mid - 1, 2, zc - toFar * 2, bid('lime_wool', 'white_wool'));                                                                  // eye
        for (let dy = 1; dy <= 3; dy++) R(mid, dy, zc + toFar * 2, wool);                                                                // tail
        break;
      }
      case 'flower_garden': {
        const flowers = ['poppy', 'dandelion', 'allium', 'azure_bluet', 'red_tulip', 'oxeye_daisy', 'blue_orchid'];
        for (let z = Math.min(near + toFar, far - toFar); z <= Math.max(near + toFar, far - toFar); z++) for (let x = r.x0 + 1; x <= r.x1 - 1; x++) {
          R(x, -1, z, bid('grass_block'));
          const h = hash3(x, Y, z, s);
          if (x === mid && z === zc) { R(x, 0, z, bid('oak_leaves')); R(x, 1, z, bid('oak_leaves')); }
          else if (h < 0.6) R(x, 0, z, bid(flowers[Math.floor(h / 0.6 * flowers.length)], 'poppy'));
        }
        break;
      }
      case 'library':
        for (let x = r.x0; x <= r.x1; x++) for (let dy = 0; dy <= 2; dy++) R(x, dy, far, bid('bookshelf', 'oak_planks'));
        R(mid, 0, zc, bid('lectern', 'bookshelf'));
        break;
      case 'bedroom':
        bed(put, r.x0, Y, far, 3);
        R(r.x1, 0, far, bid('bookshelf', 'oak_planks')); R(r.x1, 1, far, bid('bookshelf', 'oak_planks'));
        for (let dx = 0; dx <= 1; dx++) R(mid + dx, 0, zc, bid('white_carpet', 'air'));
        break;
      case 'dining':
        for (let dx = -1; dx <= 1; dx++) {
          R(mid + dx, 0, zc, bid('dark_oak_fence', 'oak_fence')); R(mid + dx, 1, zc, bid('brown_carpet', 'red_carpet'));
          R(mid + dx, 0, zc + 1, cell('dark_oak_stairs', stairsUp(2), 'oak_planks')); R(mid + dx, 0, zc - 1, cell('dark_oak_stairs', stairsUp(0), 'oak_planks'));
        }
        break;
      case 'smithy':
        R(mid - 1, 0, far, bid('furnace')); R(mid, 0, far, bid('blast_furnace', 'furnace')); R(mid + 1, 0, far, bid('anvil', 'iron_block'));
        R(r.x0, 0, far, bid('cauldron', 'cobblestone'));
        break;
      case 'spider':
        for (let z = r.z0; z <= r.z1; z++) for (let x = r.x0; x <= r.x1; x++) for (let dy = 0; dy <= 3; dy++) {
          if (free(x, z) && hash3(x, Y + dy, z, s + 3) < 0.22) R(x, dy, z, bid('cobweb', 'air'));
        }
        R(mid, 0, zc, bid('spawner', 'cobweb'));
        break;
      case 'obsidian':
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) for (let dy = 0; dy <= 2; dy++) R(mid + dx, dy, zc + dz, dx || dz || dy !== 1 ? bid('obsidian') : bid('diamond_block', 'obsidian'));
        break;
      default:
        for (let dx = -1; dx <= 1; dx++) R(mid + dx, 0, zc, bid('white_carpet', 'air'));
    }
  }
}

// ======================================================================================================================
// Ancient city
// ======================================================================================================================
/** Offsets (relative to the site) of the pieces the verification suite looks for. */
export const ANCIENT_CITY = {
  frame: { x0: -11, x1: 10, height: 8 },
  lab: { x0: -8, x1: 8, z0: -5, z1: 5, floor: -8, ceiling: -3 },
  corridors: [{ z: -14, x0: -32, x1: 32 }, { z: 14, x0: -32, x1: 32 }],
  barracks: [{ x0: -30, x1: -18, z0: -5, z1: 5 }, { x0: 18, x1: 30, z0: -5, z1: 5 }],
  iceBox: { x0: -2, x1: 2, z0: -27, z1: -23 },
};

export function ancientCity(t: StructHost, put: Put, p: Site) {
  const y = p.y, s = t.seed + 7600, P = (dx: number, yy: number, dz: number, b: number) => put(p.x + dx, yy, p.z + dz, b, true);
  const deep = bid('deepslate'), cobbled = bid('cobbled_deepslate', 'deepslate'), bricks = bid('deepslate_bricks', 'deepslate'), tiles = bid('deepslate_tiles', 'deepslate_bricks');
  const polished = bid('polished_deepslate', 'deepslate'), sculk = bid('sculk_block', 'deepslate'), reinforced = bid('reinforced_deepslate', 'obsidian'), lantern = bid('soul_lantern', 'lantern');
  const wool = bid('gray_wool', 'white_wool');
  const brick = (dx: number, yy: number, dz: number) => (hash3(dx, yy, dz, s + 1) < 0.18 ? cobbled : bricks);
  // 1. Cavern with a sculk-veined floor.
  for (let dz = -31; dz <= 31; dz++) for (let dx = -34; dx <= 34; dx++) {
    const e = (dx / 34) ** 2 + (dz / 31) ** 2;
    if (e >= 1) continue;
    const r = hash2(dx * 3 + 1, dz * 5 - 2, s);
    P(dx, y - 1, dz, r < 0.25 ? sculk : r < 0.4 ? cobbled : deep);
    for (let yy = y, top = y + Math.round(5 + 15 * (1 - e)); yy <= top; yy++) P(dx, yy, dz, 0);
  }
  // 2. City centre: tiled plaza and the reinforced-deepslate frame.
  const F = ANCIENT_CITY.frame;
  for (let dz = -5; dz <= 5; dz++) for (let dx = -13; dx <= 13; dx++) P(dx, y - 1, dz, Math.abs(dx) === 13 || Math.abs(dz) === 5 ? polished : dz >= 2 && dz <= 4 && Math.abs(dx) <= 3 ? wool : tiles);
  for (let dy = 0; dy < F.height; dy++) for (let dx = F.x0; dx <= F.x1; dx++) P(dx, y + dy, 0, dx === F.x0 || dx === F.x1 || dy === 0 || dy === F.height - 1 ? reinforced : 0);
  for (const [dx, dz] of [[-13, -5], [13, -5], [-13, 5], [13, 5]]) { P(dx, y, dz, polished); P(dx, y + 1, dz, polished); P(dx, y + 2, dz, lantern); }
  P(0, y, 3, bid('sculk_shrieker', 'sculk_sensor')); P(-4, y, 3, bid('sculk_sensor', 'air')); P(4, y, 3, bid('sculk_sensor', 'air'));
  P(-8, y, 2, bid('sculk_catalyst', 'air')); P(8, y, 2, bid('sculk_catalyst', 'air'));
  // 3. Redstone laboratory under the centre.
  const Lb = ANCIENT_CITY.lab, ly = y + Lb.floor + 1;
  for (let dz = Lb.z0; dz <= Lb.z1; dz++) for (let dx = Lb.x0; dx <= Lb.x1; dx++) {
    P(dx, y - 2, dz, bricks);
    for (let yy = y + Lb.floor; yy <= y + Lb.ceiling; yy++) {
      const edge = dx === Lb.x0 || dx === Lb.x1 || dz === Lb.z0 || dz === Lb.z1 || yy === y + Lb.floor || yy === y + Lb.ceiling;
      P(dx, yy, dz, edge ? tiles : 0);
    }
  }
  P(-6, ly, -3, cell('lever', 0)); for (let dx = -5; dx <= -3; dx++) P(dx, ly, -3, bid('redstone_wire', 'air'));
  P(-2, ly, -3, bid('unlit_redstone_lamp', 'redstone_lamp'));
  P(-6, ly, 0, bid('redstone_block', 'deepslate_tiles')); P(-5, ly, 0, cell('repeater', 0, 'air')); P(-4, ly, 0, bid('redstone_wire', 'air')); P(-3, ly, 0, cell('comparator', 0, 'air')); P(-2, ly, 0, bid('target', 'redstone_lamp'));
  P(3, ly, -3, cell('sticky_piston', 4, 'piston')); P(4, ly, -3, cell('lever', 0)); P(3, ly, -2, bid('redstone_wire', 'air'));
  P(5, ly, 0, bid('note_block', 'target')); P(6, ly, 1, bid('sculk_sensor', 'air')); P(6, ly, 0, bid('redstone_wire', 'air'));
  P(0, ly, -4, bid('lectern', 'bookshelf')); P(1, ly, -4, bid('chiseled_bookshelf', 'bookshelf')); P(-1, ly, -4, bid('chiseled_bookshelf', 'bookshelf'));
  P(6, ly, -3, bid('redstone_block', 'deepslate_tiles')); P(6, ly + 1, -3, bid('unlit_redstone_lamp', 'redstone_lamp'));
  P(-7, ly + 1, 3, cell('redstone_torch', attachOn(3), 'torch')); P(7, ly + 1, 3, cell('redstone_torch', attachOn(1), 'torch'));
  for (const [dx, dz] of [[-7, -4], [7, -4], [-7, 4], [7, 4]]) P(dx, ly + 3, dz, lantern);
  // Stairwell from the plaza (south side) down to the laboratory's iron door; the lever above the door opens it.
  for (let i = 1; i <= 6; i++) {
    for (let yy = y - 8; yy <= y - 1 - i; yy++) P(0, yy, 12 - i, polished);
    for (let yy = y - i; yy <= y + 2; yy++) P(0, yy, 12 - i, 0);
    for (const dx of [-1, 1]) for (let yy = y - 8; yy <= y - 1; yy++) P(dx, yy, 12 - i, bricks);
  }
  P(0, ly, 5, cell('iron_door', doorOn(2), 'air')); P(0, ly + 1, 5, cell('iron_door', doorOn(2) | 4, 'air'));
  P(0, ly + 2, 6, cell('lever', attachOn(0)));
  // 4. Long deepslate-brick colonnades.
  for (const c of ANCIENT_CITY.corridors) for (let dx = c.x0; dx <= c.x1; dx++) {
    for (let w = -2; w <= 2; w++) {
      const dz = c.z + w;
      P(dx, y - 1, dz, w === 0 ? wool : tiles);
      for (let yy = y; yy <= y + 4; yy++) P(dx, yy, dz, 0);
      if (Math.abs(w) === 2 && dx % 4 === 0) for (let yy = y; yy <= y + 3; yy++) P(dx, yy, dz, brick(dx, yy, dz));
      if (hash2(dx >> 1, c.z + w * 7, s + 2) >= 0.18) P(dx, y + 4, dz, Math.abs(w) === 2 ? brick(dx, y + 4, dz) : tiles);     // ruined gaps in the roof
    }
    if (((dx % 8) + 8) % 8 === 4) P(dx, y + 3, c.z, lantern);
  }
  P(-31, y, 14, bid('chest')); tag(t, p.x - 31, y, p.z + 14, 'ancient_city');
  P(31, y, -14, bid('chest')); tag(t, p.x + 31, y, p.z - 14, 'ancient_city');
  // 5. Barracks: bunk beds along both long walls, a chest and a skull at the far end.
  for (const b of ANCIENT_CITY.barracks) {
    const west = b.x0 < 0, doorX = west ? b.x1 : b.x0, endX = west ? b.x0 + 1 : b.x1 - 1;
    for (let dz = b.z0; dz <= b.z1; dz++) for (let dx = b.x0; dx <= b.x1; dx++) for (let yy = y - 1; yy <= y + 5; yy++) {
      const edge = dx === b.x0 || dx === b.x1 || dz === b.z0 || dz === b.z1;
      P(dx, yy, dz, yy === y - 1 ? tiles : yy === y + 5 ? tiles : edge ? brick(dx, yy, dz) : 0);
    }
    P(doorX, y, 0, 0); P(doorX, y + 1, 0, 0);
    for (let bx = b.x0 + 2; bx <= b.x1 - 2; bx += 3) {
      bed(put, p.x + bx, y, p.z - 3, 2); bed(put, p.x + bx, y, p.z + 3, 0);
      for (const dz of [-4, -3, 3, 4]) { P(bx, y + 2, dz, bid('dark_oak_planks', 'oak_planks')); P(bx, y + 3, dz, wool); }
      P(bx + 1, y, -4, bid('dark_oak_fence', 'oak_fence')); P(bx + 1, y + 1, -4, bid('dark_oak_fence', 'oak_fence'));
      P(bx + 1, y, 4, bid('dark_oak_fence', 'oak_fence')); P(bx + 1, y + 1, 4, bid('dark_oak_fence', 'oak_fence'));
    }
    P(endX, y, 0, bid('chest')); tag(t, p.x + endX, y, p.z, 'ancient_city');
    P(endX, y, -1, bid('skeleton_skull', 'bone_block')); P(endX, y, 1, bid('target', 'bone_block'));
    P((b.x0 + b.x1) >> 1, y + 4, 0, lantern);
  }
  // 6. Ice box.
  const I = ANCIENT_CITY.iceBox;
  for (let dz = I.z0; dz <= I.z1; dz++) for (let dx = I.x0; dx <= I.x1; dx++) for (let yy = y - 1; yy <= y + 3; yy++) {
    const edge = dx === I.x0 || dx === I.x1 || dz === I.z0 || dz === I.z1;
    P(dx, yy, dz, yy === y - 1 ? bid('packed_ice', 'ice') : yy === y + 3 ? tiles : edge ? (hash3(dx, yy, dz, s + 4) < 0.4 ? bid('packed_ice', 'ice') : bricks) : 0);
  }
  P(0, y, I.z1, 0); P(0, y + 1, I.z1, 0);
  P(0, y, -25, bid('chest')); tag(t, p.x, y, p.z - 25, 'ancient_city_ice_box');
  P(-1, y, -26, bid('blue_ice', 'packed_ice')); P(1, y, -26, bid('blue_ice', 'packed_ice'));
  // 7. Sculk growths on free floor cells.
  for (let dz = -30; dz <= 30; dz++) for (let dx = -33; dx <= 33; dx++) {
    if ((dx / 34) ** 2 + (dz / 31) ** 2 >= 0.95 || (Math.abs(dx) <= 1 && dz >= 5 && dz <= 12)) continue;
    const r = hash2(dx * 11 - 3, dz * 17 + 5, s + 5);
    if (r < 0.019) put(p.x + dx, y, p.z + dz, r < 0.012 ? bid('sculk_sensor', 'air') : r < 0.016 ? bid('sculk_shrieker', 'air') : bid('sculk_catalyst', 'air'), false);
  }
}

// ======================================================================================================================
// Bastion remnant
// ======================================================================================================================
export const BASTION_TYPES = ['treasure', 'hoglin_stable', 'bridge', 'housing'] as const;
export type BastionType = typeof BASTION_TYPES[number];
export const bastionType = (seed: number, x: number, z: number): BastionType => BASTION_TYPES[Math.floor(hash2(x, z, seed + 7700) * 4) & 3];
const BASTION_TABLE: Record<BastionType, string> = { treasure: 'bastion_treasure', hoglin_stable: 'bastion_hoglin_stable', bridge: 'bastion_bridge', housing: 'bastion_other' };

export function bastion(t: StructHost, put: Put, p: Site, force?: BastionType) {
  const type = force ?? bastionType(t.seed, p.x, p.z), y = p.y, s = t.seed + 7700, R = 14;
  const P = (dx: number, yy: number, dz: number, b: number) => put(p.x + dx, yy, p.z + dz, b, true);
  const pbb = bid('polished_blackstone_bricks', 'nether_bricks'), bs = bid('blackstone', 'nether_bricks'), gilded = bid('gilded_blackstone', 'gold_block'), basalt = bid('basalt', 'blackstone');
  const gold = bid('gold_block'), lantern = bid('lantern', 'glowstone'), lava = bid('lava');
  const wall = (dx: number, yy: number, dz: number) => { const r = hash3(dx, yy, dz, s); return r < 0.15 ? bs : r < 0.21 ? gilded : r < 0.3 ? bid('cracked_polished_blackstone_bricks', 'polished_blackstone_bricks') : pbb; };
  const chest = (dx: number, yy: number, dz: number) => { P(dx, yy, dz, bid('chest')); P(dx, yy + 1, dz, 0); tag(t, p.x + dx, yy, p.z + dz, BASTION_TABLE[type]); };
  const ring = (top: number, gate = true) => {
    for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++) {
      if (Math.abs(dx) !== R && Math.abs(dz) !== R) continue;
      const tower = Math.abs(dx) === R && Math.abs(dz) === R;
      for (let yy = y; yy <= y + top + (tower ? 2 : 0); yy++) P(dx, yy, dz, tower ? basalt : wall(dx, yy, dz));
      if (tower) P(dx, y + top + 3, dz, lantern);
      else if ((dx + dz) % 2 === 0) P(dx, y + top + 1, dz, wall(dx, y + top + 1, dz));                       // battlements
    }
    if (gate) for (let dx = -1; dx <= 1; dx++) for (let yy = y; yy <= y + 2; yy++) P(dx, yy, R, 0);
  };
  // Blackstone base and a clear volume above it.
  for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++) {
    for (let yy = y - 5; yy <= y - 1; yy++) P(dx, yy, dz, yy === y - 1 ? wall(dx, yy, dz) : bs);
    for (let yy = y; yy <= y + 12; yy++) P(dx, yy, dz, 0);
  }

  if (type === 'treasure') {
    // Walkway around a lava pit, four bridges to the central treasure platform with the magma cube spawner.
    ring(9);
    for (let dz = -9; dz <= 9; dz++) for (let dx = -9; dx <= 9; dx++) {
      const m = Math.max(Math.abs(dx), Math.abs(dz)), bridge = (dx === 0 || dz === 0) && m >= 3;
      if (m <= 2) { for (let yy = y - 4; yy <= y - 1; yy++) P(dx, yy, dz, m === 2 ? gilded : pbb); continue; }
      P(dx, y - 4, dz, bs); P(dx, y - 3, dz, lava); P(dx, y - 2, dz, 0);
      P(dx, y - 1, dz, bridge ? pbb : 0);
    }
    P(0, y, 0, bid('spawner', 'gold_block'));
    for (const [dx, dz] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) { P(dx, y, dz, gold); if ((dx + dz) !== 0) P(dx, y + 1, dz, gold); }
    P(0, y, 2, gold); P(0, y, -2, gold); P(0, y + 1, -2, gold);
    chest(2, y, 0); chest(-2, y, 0);
    for (const [dx, dz] of [[11, 11], [-11, 11], [11, -11], [-11, -11]]) { P(dx, y, dz, basalt); P(dx, y + 1, dz, basalt); P(dx, y + 2, dz, lantern); P(dx + Math.sign(-dx), y, dz, gold); }
  } else if (type === 'hoglin_stable') {
    // Roofed hall: a central aisle with five hoglin pens on each side.
    ring(6);
    for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++) if (hash2(dx, dz, s + 1) > 0.12) P(dx, y + 7, dz, Math.abs(dx) <= 1 ? pbb : bs);
    for (const sx of [-1, 1]) for (let k = 0; k < 5; k++) {
      const z0 = -12 + k * 5;
      for (let a = 2; a <= 13; a++) {
        for (let dz = z0; dz <= z0 + 3; dz++) if (a > 2) P(sx * a, y - 1, dz, hash2(sx * a, dz, s + 2) < 0.5 ? bid('soul_soil', 'soul_sand') : bid('crimson_nylium', 'netherrack'));
        if (k < 4) { P(sx * a, y, z0 + 4, wall(sx * a, y, z0 + 4)); P(sx * a, y + 1, z0 + 4, wall(sx * a, y + 1, z0 + 4)); }
      }
      for (let dz = z0; dz <= z0 + 3; dz++) if (dz !== z0 + 1 && dz !== z0 + 2) { P(sx * 2, y, dz, pbb); P(sx * 2, y + 1, dz, pbb); }
      P(sx * 2, y + 2, z0, bid('chain', 'iron_bars')); P(sx * 2, y + 2, z0 + 3, bid('chain', 'iron_bars'));
      P(sx * 13, y, z0, bid('hay_block', 'soul_sand'));
      P(sx * 8, y, z0 + 2, bid('crimson_fungus', 'air'));
    }
    chest(0, y, -13); chest(12, y, -11);
    P(1, y, -13, gold); P(-1, y, -13, gold);
    for (let dz = -10; dz <= 10; dz += 5) P(0, y + 6, dz, lantern);
  } else if (type === 'bridge') {
    // Two gate towers joined by a high bridge over a lava moat.
    for (let dz = -7; dz <= 7; dz++) for (let dx = -8; dx <= 8; dx++) P(dx, y - 1, dz, lava);
    for (const sz of [-1, 1]) {
      for (let a = 9; a <= 14; a++) for (let dx = -5; dx <= 5; dx++) for (let yy = y; yy <= y + 11; yy++) {
        const dz = sz * a, edge = Math.abs(dx) === 5 || a === 9 || a === 14;
        P(dx, yy, dz, yy === y + 5 || yy === y + 11 ? pbb : edge ? (Math.abs(dx) === 5 && (a === 9 || a === 14) ? basalt : wall(dx, yy, dz)) : 0);
      }
      for (let yy = y; yy <= y + 2; yy++) P(0, yy, sz * 14, 0);                                           // outer gate
      for (let yy = y + 6; yy <= y + 8; yy++) for (let dx = -1; dx <= 1; dx++) P(dx, yy, sz * 9, 0);      // door onto the bridge
      for (let yy = y; yy <= y + 5; yy++) P(4, yy, sz * 11, cell('ladder', ladderOn(1)));
      P(-4, y + 6, sz * 13, lantern);
    }
    for (let dz = -8; dz <= 8; dz++) for (let dx = -2; dx <= 2; dx++) {
      P(dx, y + 5, dz, Math.abs(dx) === 2 ? wall(dx, y + 5, dz) : pbb);
      if (Math.abs(dx) === 2 && dz % 2 === 0) P(dx, y + 6, dz, wall(dx, y + 6, dz));
      if (Math.abs(dx) === 2 && dz % 4 === 0) for (let yy = y - 1; yy <= y + 4; yy++) P(dx, yy, dz, basalt);
    }
    chest(0, y + 6, -12); P(1, y + 6, -12, gold); P(-1, y + 6, -12, gold); P(0, y + 6, -13, gilded);
    chest(0, y, 12);
  } else {
    // Housing units: four two-storey houses around a nether wart courtyard.
    ring(9);
    for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
      const m = Math.max(Math.abs(dx), Math.abs(dz));
      P(dx, y - 1, dz, m === 3 ? pbb : bid('soul_sand', 'netherrack'));
      if (m < 3) P(dx, y, dz, cell('nether_wart', Math.floor(hash2(dx, dz, s + 3) * 4), 'air'));
    }
    let n = 0;
    for (const sz of [-1, 1]) for (const sx of [-1, 1]) {
      for (let a = 5; a <= 12; a++) for (let b = 5; b <= 12; b++) for (let yy = y; yy <= y + 9; yy++) {
        const dx = sx * a, dz = sz * b, edge = a === 5 || a === 12 || b === 5 || b === 12;
        P(dx, yy, dz, yy === y + 4 || yy === y + 9 ? bs : edge ? wall(dx, yy, dz) : 0);
      }
      P(sx * 5, y, sz * 8, 0); P(sx * 5, y + 1, sz * 8, 0);
      for (let yy = y; yy <= y + 4; yy++) P(sx * 11, yy, sz * 11, cell('ladder', ladderOn(sx > 0 ? 1 : 3)));
      P(sx * 8, y + 3, sz * 8, lantern); P(sx * 8, y + 8, sz * 8, lantern);
      P(sx * 6, y + 5, sz * 6, gold);
      if (n++ % 2 === 0) chest(sx * 11, y, sz * 6); else chest(sx * 6, y + 5, sz * 11);
    }
  }
}

// Shared by tests: every mansion room type has a recogniser block.
export const MANSION_SIGNATURE: Record<MansionRoomType, string> = {
  storage: 'chest', jail: 'iron_bars', cat_statue: 'black_wool', flower_garden: 'grass_block', library: 'bookshelf', bedroom: 'bed',
  dining: 'dark_oak_stairs', smithy: 'blast_furnace', spider: 'spawner', obsidian: 'diamond_block', empty: 'white_carpet',
};
void shell;
