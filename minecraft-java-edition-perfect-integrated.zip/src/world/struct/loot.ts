// Room-level loot tables (Minecraft Wiki "Loot table" / each structure's "Loot" section, Java Edition 1.21).
// A generated chest is tagged with the table of the room it stands in; the engine rolls that table the first time it is opened.
// Weights are the Wiki weights; items this game does not register are skipped when rolling.
import type { StructHost } from './common';

/** [item, min, max, weight] */
export type LootEntry = [string, number, number, number];
export interface RoomLoot {
  /** Number of weighted rolls. */
  rolls: [number, number];
  items: LootEntry[];
  /** Extra pools: [item, min, max, chance 0..1] – rolled once each (guaranteed items use chance 1). */
  always?: LootEntry[];
  ja: string;
}

const WOODLAND_MANSION: LootEntry[] = [
  ['lead', 1, 1, 20], ['golden_apple', 1, 1, 15], ['enchanted_golden_apple', 1, 1, 2], ['music_disc_13', 1, 1, 15], ['music_disc_cat', 1, 1, 15],
  ['name_tag', 1, 1, 20], ['chainmail_chestplate', 1, 1, 10], ['diamond_hoe', 1, 1, 15], ['diamond_chestplate', 1, 1, 5], ['enchanted_book', 1, 1, 10],
  ['iron_ingot', 1, 4, 10], ['gold_ingot', 1, 4, 5], ['bread', 1, 1, 20], ['wheat', 1, 4, 20], ['bucket', 1, 1, 10], ['redstone', 1, 4, 15],
  ['coal', 1, 4, 15], ['melon_seeds', 2, 4, 10], ['pumpkin_seeds', 2, 4, 10], ['beetroot_seeds', 2, 4, 10], ['bone', 1, 8, 10], ['gunpowder', 1, 8, 10],
  ['rotten_flesh', 1, 8, 10], ['string', 1, 8, 10],
];

export const ROOM_LOOT: Record<string, RoomLoot> = {
  // ---- Stronghold: three separate tables (library / altar chest corridor / store room) ----
  stronghold_library: { ja: '要塞の図書館', rolls: [2, 10], items: [['book', 1, 3, 20], ['paper', 2, 7, 20], ['map', 1, 1, 1], ['compass', 1, 1, 1], ['enchanted_book', 1, 1, 10]], always: [['eye_armor_trim_smithing_template', 1, 1, 1]] },
  stronghold_corridor: { ja: '要塞の祭壇チェスト', rolls: [2, 3], items: [['ender_pearl', 1, 1, 10], ['diamond', 1, 3, 3], ['iron_ingot', 1, 5, 10], ['gold_ingot', 1, 3, 5], ['redstone', 4, 9, 5], ['bread', 1, 3, 15], ['apple', 1, 3, 15], ['iron_pickaxe', 1, 1, 5], ['iron_sword', 1, 1, 5], ['iron_chestplate', 1, 1, 5], ['iron_helmet', 1, 1, 5], ['iron_leggings', 1, 1, 5], ['iron_boots', 1, 1, 5], ['golden_apple', 1, 1, 1], ['saddle', 1, 1, 1], ['iron_horse_armor', 1, 1, 1], ['golden_horse_armor', 1, 1, 1], ['diamond_horse_armor', 1, 1, 1], ['music_disc_otherside', 1, 1, 1], ['enchanted_book', 1, 1, 1]], always: [['eye_armor_trim_smithing_template', 1, 1, 0.1]] },
  stronghold_crossing: { ja: '要塞の倉庫', rolls: [1, 4], items: [['iron_ingot', 1, 5, 10], ['gold_ingot', 1, 3, 5], ['redstone', 4, 9, 5], ['coal', 3, 8, 10], ['bread', 1, 3, 15], ['apple', 1, 3, 15], ['iron_pickaxe', 1, 1, 1], ['enchanted_book', 1, 1, 1]] },
  // ---- Desert pyramid: the four chests of the TNT chamber ----
  desert_pyramid: { ja: '砂漠の寺院 TNT 地下室', rolls: [6, 8], items: [['diamond', 1, 3, 5], ['iron_ingot', 1, 5, 15], ['gold_ingot', 2, 7, 15], ['emerald', 1, 3, 15], ['bone', 4, 6, 25], ['spider_eye', 1, 3, 25], ['rotten_flesh', 3, 7, 25], ['saddle', 1, 1, 20], ['golden_apple', 1, 1, 20], ['enchanted_golden_apple', 1, 1, 2], ['enchanted_book', 1, 1, 20], ['gunpowder', 1, 8, 10], ['string', 1, 8, 10], ['sand', 1, 8, 10]], always: [['dune_armor_trim_smithing_template', 2, 2, 0.143]] },
  // ---- Woodland mansion ----
  mansion_storage: { ja: '森の洋館の倉庫', rolls: [4, 7], items: WOODLAND_MANSION, always: [['vex_armor_trim_smithing_template', 1, 1, 0.5]] },
  // ---- Village (plains) ----
  village_weaponsmith: { ja: '村の武器鍛冶', rolls: [3, 8], items: [['diamond', 1, 3, 3], ['iron_ingot', 1, 5, 10], ['gold_ingot', 1, 3, 5], ['bread', 1, 3, 15], ['apple', 1, 3, 15], ['iron_pickaxe', 1, 1, 5], ['iron_sword', 1, 1, 5], ['iron_chestplate', 1, 1, 5], ['iron_helmet', 1, 1, 5], ['iron_leggings', 1, 1, 5], ['iron_boots', 1, 1, 5], ['obsidian', 3, 7, 5], ['oak_sapling', 3, 7, 5], ['saddle', 1, 1, 3], ['iron_horse_armor', 1, 1, 1], ['golden_horse_armor', 1, 1, 1], ['diamond_horse_armor', 1, 1, 1]] },
  village_temple: { ja: '村の教会', rolls: [3, 8], items: [['redstone', 1, 4, 2], ['bread', 1, 4, 7], ['rotten_flesh', 1, 4, 7], ['lapis_lazuli', 1, 4, 1], ['gold_ingot', 1, 4, 1], ['emerald', 1, 4, 1]] },
  village_plains_house: { ja: '平原の村の家', rolls: [3, 8], items: [['gold_nugget', 1, 3, 1], ['dandelion', 1, 1, 2], ['poppy', 1, 1, 1], ['potato', 1, 7, 10], ['bread', 1, 4, 10], ['apple', 1, 5, 10], ['book', 1, 1, 1], ['feather', 1, 1, 1], ['emerald', 1, 4, 2], ['oak_sapling', 1, 2, 5]] },
  // ---- Igloo basement ----
  igloo_chest: { ja: 'イグルーの地下室', rolls: [2, 8], items: [['apple', 1, 3, 15], ['coal', 1, 4, 15], ['gold_nugget', 1, 3, 10], ['stone_axe', 1, 1, 2], ['rotten_flesh', 1, 1, 10], ['emerald', 1, 1, 1], ['wheat', 2, 3, 10]], always: [['golden_apple', 1, 1, 1]] },
  // ---- Jungle temple ----
  jungle_temple: { ja: 'ジャングルの寺院', rolls: [2, 6], items: [['diamond', 1, 3, 3], ['iron_ingot', 1, 5, 10], ['gold_ingot', 2, 7, 15], ['bamboo', 1, 3, 15], ['emerald', 1, 3, 2], ['bone', 4, 6, 20], ['rotten_flesh', 3, 7, 16], ['saddle', 1, 1, 3], ['iron_horse_armor', 1, 1, 1], ['golden_horse_armor', 1, 1, 1], ['diamond_horse_armor', 1, 1, 1], ['enchanted_book', 1, 1, 1]], always: [['wild_armor_trim_smithing_template', 2, 2, 0.333]] },
  jungle_temple_dispenser: { ja: 'ジャングルの寺院のディスペンサー', rolls: [1, 2], items: [['arrow', 2, 7, 30]] },
  // ---- End city / end ship ----
  end_city_treasure: { ja: 'エンドシティの財宝', rolls: [2, 6], items: [['diamond', 2, 7, 5], ['iron_ingot', 4, 8, 10], ['gold_ingot', 2, 7, 15], ['emerald', 2, 6, 2], ['beetroot_seeds', 1, 10, 5], ['saddle', 1, 1, 3], ['iron_horse_armor', 1, 1, 1], ['golden_horse_armor', 1, 1, 1], ['diamond_horse_armor', 1, 1, 1], ['diamond_sword', 1, 1, 3], ['diamond_boots', 1, 1, 3], ['diamond_chestplate', 1, 1, 3], ['diamond_leggings', 1, 1, 3], ['diamond_helmet', 1, 1, 3], ['diamond_pickaxe', 1, 1, 3], ['diamond_shovel', 1, 1, 3], ['iron_sword', 1, 1, 3], ['iron_boots', 1, 1, 3], ['iron_chestplate', 1, 1, 3], ['iron_leggings', 1, 1, 3], ['iron_helmet', 1, 1, 3], ['iron_pickaxe', 1, 1, 3], ['iron_shovel', 1, 1, 3]], always: [['spire_armor_trim_smithing_template', 1, 1, 0.067]] },
  // ---- Bastion remnant: one table per variant ----
  bastion_treasure: { ja: '砦の遺跡の宝物庫', rolls: [3, 4], items: [['netherite_ingot', 1, 1, 15], ['ancient_debris', 1, 1, 10], ['netherite_scrap', 1, 1, 8], ['ancient_debris', 2, 2, 4], ['diamond_sword', 1, 1, 6], ['diamond_chestplate', 1, 1, 6], ['diamond_helmet', 1, 1, 6], ['diamond_leggings', 1, 1, 6], ['diamond_boots', 1, 1, 6], ['diamond', 2, 6, 5], ['enchanted_golden_apple', 1, 1, 2], ['spectral_arrow', 12, 25, 1], ['gold_block', 2, 5, 1], ['iron_block', 2, 5, 1], ['gold_ingot', 3, 9, 1], ['iron_ingot', 3, 9, 1], ['crying_obsidian', 3, 5, 1], ['quartz', 8, 23, 1], ['gilded_blackstone', 5, 15, 1], ['magma_cream', 3, 8, 1]], always: [['netherite_upgrade', 1, 1, 1], ['snout_armor_trim_smithing_template', 1, 1, 0.083]] },
  bastion_hoglin_stable: { ja: '砦の遺跡のホグリン厩舎', rolls: [4, 5], items: [['diamond_shovel', 1, 1, 15], ['diamond_pickaxe', 1, 1, 12], ['netherite_scrap', 1, 1, 8], ['ancient_debris', 1, 1, 12], ['ancient_debris', 2, 2, 5], ['saddle', 1, 1, 12], ['gold_block', 2, 4, 16], ['golden_carrot', 8, 17, 10], ['golden_apple', 1, 1, 10], ['golden_axe', 1, 1, 1], ['crying_obsidian', 1, 5, 1], ['glowstone', 3, 6, 1], ['gilded_blackstone', 2, 5, 1], ['soul_sand', 2, 7, 1], ['crimson_nylium', 2, 7, 1], ['gold_nugget', 2, 8, 1], ['leather', 1, 3, 1], ['arrow', 5, 17, 1], ['string', 3, 8, 1], ['porkchop', 2, 5, 1], ['cooked_porkchop', 2, 5, 1], ['crimson_fungus', 2, 7, 1], ['crimson_roots', 2, 7, 1]], always: [['netherite_upgrade', 1, 1, 0.1], ['snout_armor_trim_smithing_template', 1, 1, 0.083]] },
  bastion_bridge: { ja: '砦の遺跡の橋', rolls: [3, 6], items: [['crossbow', 1, 1, 1], ['spectral_arrow', 10, 28, 1], ['gilded_blackstone', 8, 12, 1], ['crying_obsidian', 3, 8, 1], ['gold_block', 1, 1, 1], ['gold_ingot', 4, 9, 1], ['iron_ingot', 4, 9, 1], ['golden_sword', 1, 1, 1], ['golden_chestplate', 1, 1, 1], ['golden_helmet', 1, 1, 1], ['golden_leggings', 1, 1, 1], ['golden_boots', 1, 1, 1], ['golden_axe', 1, 1, 1], ['string', 1, 6, 1], ['leather', 1, 3, 1], ['arrow', 5, 17, 1], ['iron_nugget', 2, 6, 1], ['gold_nugget', 2, 6, 1]], always: [['lodestone', 1, 1, 1], ['netherite_upgrade', 1, 1, 0.1], ['snout_armor_trim_smithing_template', 1, 1, 0.083]] },
  bastion_other: { ja: '砦の遺跡の住居', rolls: [5, 6], items: [['diamond_pickaxe', 1, 1, 6], ['diamond_shovel', 1, 1, 6], ['crossbow', 1, 1, 6], ['ancient_debris', 1, 1, 12], ['netherite_scrap', 1, 1, 4], ['spectral_arrow', 10, 22, 10], ['piglin_banner_pattern', 1, 1, 9], ['music_disc_pigstep', 1, 1, 5], ['golden_carrot', 6, 17, 12], ['golden_apple', 1, 1, 9], ['enchanted_book', 1, 1, 10], ['iron_sword', 1, 1, 2], ['iron_block', 1, 1, 2], ['golden_boots', 1, 1, 1], ['golden_axe', 1, 1, 1], ['gold_block', 1, 1, 2], ['gold_ingot', 1, 6, 2], ['iron_ingot', 1, 6, 2], ['golden_sword', 1, 1, 1], ['crying_obsidian', 1, 5, 2], ['gilded_blackstone', 1, 5, 2], ['chain', 2, 10, 1], ['magma_cream', 2, 6, 2], ['bone_block', 3, 6, 1], ['iron_nugget', 2, 8, 1], ['obsidian', 4, 6, 1], ['gold_nugget', 2, 8, 1], ['string', 4, 6, 1], ['arrow', 5, 17, 2], ['cooked_porkchop', 1, 1, 1]], always: [['netherite_upgrade', 1, 1, 0.1], ['snout_armor_trim_smithing_template', 1, 1, 0.083]] },
  // ---- Ancient city ----
  ancient_city: { ja: '古代都市', rolls: [5, 10], items: [['enchanted_golden_apple', 1, 2, 1], ['music_disc_otherside', 1, 1, 1], ['compass', 1, 1, 2], ['sculk_catalyst', 1, 2, 2], ['name_tag', 1, 1, 2], ['diamond_hoe', 1, 1, 2], ['lead', 1, 1, 2], ['diamond_horse_armor', 1, 1, 2], ['saddle', 1, 1, 2], ['music_disc_13', 1, 1, 2], ['music_disc_cat', 1, 1, 2], ['diamond_leggings', 1, 1, 2], ['enchanted_book', 1, 1, 3], ['sculk', 4, 14, 3], ['sculk_sensor', 1, 3, 3], ['candle', 1, 4, 3], ['amethyst_shard', 1, 15, 3], ['experience_bottle', 1, 3, 3], ['glow_berries', 1, 15, 3], ['iron_leggings', 1, 1, 3], ['echo_shard', 1, 3, 4], ['disc_fragment', 1, 3, 4], ['potion_regeneration_strong', 1, 3, 5], ['book', 3, 10, 5], ['bone', 1, 15, 5], ['soul_torch', 1, 15, 5], ['coal', 6, 15, 7]], always: [['ward_armor_trim_smithing_template', 1, 1, 0.05], ['silence_armor_trim_smithing_template', 1, 1, 0.012]] },
  ancient_city_ice_box: { ja: '古代都市の氷室', rolls: [4, 10], items: [['suspicious_stew', 2, 6, 1], ['golden_carrot', 1, 10, 1], ['baked_potato', 1, 10, 1], ['packed_ice', 2, 6, 2], ['snowball', 2, 6, 4]] },
};

/** Fixed contents of generated block entities that are not chests (slot → stack). */
export const FIXED_CONTENTS: Record<string, { size: number; slots: [number, string, number][]; ja: string }> = {
  /** End ship: the brewing stand holds two Instant Health II potions. */
  end_ship_brewing: { ja: 'エンドシップの醸造台（治癒 II ×2）', size: 5, slots: [[0, 'potion_healing_strong', 1], [1, 'potion_healing_strong', 1]] },
  /** End ship: the item frame behind the treasure chests holds the elytra. */
  end_ship_elytra: { ja: 'エンドシップの額縁（エリトラ）', size: 1, slots: [[0, 'elytra', 1]] },
  /** Igloo basement: the brewing stand holds one Splash Potion of Weakness (for curing the zombie villager). */
  igloo_brewing: { ja: 'イグルー地下の醸造台（弱化のスプラッシュポーション）', size: 5, slots: [[0, 'splash_weakness', 1]] },
};

export interface LootStack { name: string; count: number }
/**
 * Rolls a room table. `rnd` is a seeded generator, `exists` filters items the registry does not know and `stackMax` caps counts.
 * Enchanting books/gear is left to the caller (the engine owns the enchantment registry).
 */
export function rollRoomLoot(table: RoomLoot, rnd: () => number, exists: (name: string) => boolean = () => true, stackMax: (name: string) => number = () => 64, size = 27): (LootStack | null)[] {
  const slots: (LootStack | null)[] = Array(size).fill(null);
  const place = (name: string, count: number) => {
    let slot = Math.floor(rnd() * size);
    for (let n = 0; n < size && slots[slot]; n++) slot = (slot + 1) % size;
    if (!slots[slot]) slots[slot] = { name, count: Math.max(1, Math.min(count, stackMax(name))) };
  };
  const items = table.items.filter(i => exists(i[0]));
  const total = items.reduce((s, i) => s + i[3], 0);
  const rolls = table.rolls[0] + Math.floor(rnd() * (table.rolls[1] - table.rolls[0] + 1));
  for (let n = 0; n < rolls && total > 0; n++) {
    let w = rnd() * total;
    const it = items.find(i => (w -= i[3]) <= 0) ?? items[0];
    place(it[0], it[1] + Math.floor(rnd() * (it[2] - it[1] + 1)));
  }
  for (const [name, min, max, chance] of table.always ?? []) {
    const hit = rnd() < chance, count = min + Math.floor(rnd() * (max - min + 1));
    if (hit && exists(name)) place(name, count);
  }
  return slots;
}

interface TagSource extends StructHost { generate?(cx: number, cz: number): unknown }
/**
 * Table tag of the generated block entity at (x, y, z), or null. Chunks meshed in the worker never ran the builders on the
 * main-thread terrain, so on a miss the owning chunk is generated once here (the builders then record every tag they place).
 */
export function lootTagAt(t: TagSource, x: number, y: number, z: number): string | null {
  const key = x + ',' + y + ',' + z;
  let v = t.structTags?.get(key);
  if (v === undefined && t.generate) {
    try { t.generate(Math.floor(x / 16), Math.floor(z / 16)); } catch { /* a chunk that cannot be generated has no loot */ }
    v = t.structTags?.get(key);
    if (v === undefined) (t.structTags ??= new Map()).set(key, v = '');
  }
  return v || null;
}
