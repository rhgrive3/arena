// Stronghold (Minecraft Wiki "Stronghold" – structure pieces). Like vanilla it grows from a spiral staircase: every exit of a
// placed piece asks for a new piece chosen by weight (corridor 40, turns, prison hall, room crossing, stairs, chest corridor,
// library, portal room), which is kept only if its bounding box does not collide with what is already there. The portal room
// (one per stronghold) and the libraries (at most two) only appear a few pieces away from the start.
import { makeCell } from '../../game/blockState';
import { type Put, type StructHost, DX, DZ, bid, cell, hash2, hash3, mulberry, tag, stoneBrick, stairsUp, ladderOn, attachOn, doorOn, PANE_X, PANE_Z } from './common';

export type PieceType = 'start' | 'corridor' | 'turn' | 'prison' | 'crossing' | 'stairs' | 'spiral' | 'chest_corridor' | 'library' | 'portal_room';
interface Exit { lx: number; ly: number; lz: number; turn: number }
interface Def { w: number; h: number; l: number; ex: number; ey: number; exits: Exit[]; weight: number; max: number; minDepth: number }
/** Local frame: lx across (0..w-1), ly up (0 = floor block), lz along the travel direction; the entry is centred on (ex, ey, 0). */
const DEFS: Record<PieceType, Def> = {
  start: { w: 5, h: 11, l: 5, ex: 2, ey: 6, exits: [{ lx: 2, ly: 0, lz: 5, turn: 0 }], weight: 0, max: 1, minDepth: 0 },
  corridor: { w: 5, h: 5, l: 7, ex: 2, ey: 0, exits: [{ lx: 2, ly: 0, lz: 7, turn: 0 }, { lx: -1, ly: 0, lz: 3, turn: 3 }, { lx: 5, ly: 0, lz: 3, turn: 1 }], weight: 40, max: 99, minDepth: 0 },
  turn: { w: 5, h: 5, l: 5, ex: 2, ey: 0, exits: [{ lx: -1, ly: 0, lz: 2, turn: 3 }, { lx: 5, ly: 0, lz: 2, turn: 1 }], weight: 30, max: 99, minDepth: 0 },
  prison: { w: 9, h: 5, l: 11, ex: 2, ey: 0, exits: [{ lx: 2, ly: 0, lz: 11, turn: 0 }], weight: 8, max: 4, minDepth: 1 },
  crossing: { w: 11, h: 7, l: 11, ex: 5, ey: 0, exits: [{ lx: 5, ly: 0, lz: 11, turn: 0 }, { lx: -1, ly: 0, lz: 5, turn: 3 }, { lx: 11, ly: 0, lz: 5, turn: 1 }], weight: 12, max: 5, minDepth: 0 },
  stairs: { w: 5, h: 11, l: 8, ex: 2, ey: 6, exits: [{ lx: 2, ly: 0, lz: 8, turn: 0 }], weight: 5, max: 3, minDepth: 1 },
  spiral: { w: 5, h: 11, l: 5, ex: 2, ey: 6, exits: [{ lx: 2, ly: 0, lz: 5, turn: 0 }], weight: 5, max: 3, minDepth: 1 },
  chest_corridor: { w: 5, h: 5, l: 7, ex: 2, ey: 0, exits: [{ lx: 2, ly: 0, lz: 7, turn: 0 }], weight: 6, max: 4, minDepth: 1 },
  library: { w: 14, h: 11, l: 15, ex: 6, ey: 0, exits: [], weight: 10, max: 2, minDepth: 3 },
  portal_room: { w: 11, h: 8, l: 16, ex: 5, ey: 0, exits: [], weight: 20, max: 1, minDepth: 4 },
};

export interface Piece {
  type: PieceType; d: number; ax: number; ay: number; az: number; depth: number; variant: number;
  /** Entry: 0 open arch, 1 wooden door, 2 iron-bar grate. */
  door: number;
  /** [x0, y0, z0, x1, y1, z1] inclusive. */
  box: [number, number, number, number, number, number];
  /** Which exits lead to another piece (the others stay walled up). */
  open: boolean[];
}
export interface StrongholdLayout { cx: number; cz: number; pieces: Piece[]; portal: [number, number, number] | null }

export const STRONGHOLD_RADIUS = 58;
/** Walking level of the corridors that leave the starting staircase. */
export const STRONGHOLD_Y = 31;
const MAX_PIECES = 46, MIN_Y = 6;

const world = (p: { type: PieceType; d: number; ax: number; ay: number; az: number }, lx: number, ly: number, lz: number): [number, number, number] => {
  const def = DEFS[p.type], r = (p.d + 1) & 3;
  return [p.ax + DX[r] * (lx - def.ex) + DX[p.d] * lz, p.ay + ly - def.ey, p.az + DZ[r] * (lx - def.ex) + DZ[p.d] * lz];
};
function boxOf(p: { type: PieceType; d: number; ax: number; ay: number; az: number }): Piece['box'] {
  const def = DEFS[p.type], a = world(p, 0, 0, 0), b = world(p, def.w - 1, def.h - 1, def.l - 1);
  return [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.min(a[2], b[2]), Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.max(a[2], b[2])];
}
const overlaps = (a: Piece['box'], b: Piece['box']) => a[0] <= b[3] && a[3] >= b[0] && a[1] <= b[4] && a[4] >= b[1] && a[2] <= b[5] && a[5] >= b[2];

function generate(seed: number, cx: number, cz: number): StrongholdLayout {
  const rnd = mulberry(seed), pieces: Piece[] = [], counts: Partial<Record<PieceType, number>> = {};
  const d0 = Math.floor(rnd() * 4);
  const start: Piece = { type: 'start', d: d0, ax: cx - DX[d0] * 2, ay: STRONGHOLD_Y + 5, az: cz - DZ[d0] * 2, depth: 0, variant: 0, door: 0, box: [0, 0, 0, 0, 0, 0], open: [false] };
  start.box = boxOf(start);
  pieces.push(start);
  interface Pending { parent: Piece; exit: number; depth: number }
  const queue: Pending[] = [{ parent: start, exit: 0, depth: 1 }];
  let portal: StrongholdLayout['portal'] = null;
  while (queue.length && pieces.length < MAX_PIECES) {
    const q = queue.splice(Math.floor(rnd() * queue.length), 1)[0], e = DEFS[q.parent.type].exits[q.exit];
    const [ax, ay, az] = world(q.parent, e.lx, e.ly, e.lz), d = (q.parent.d + e.turn) & 3;
    const pool = (Object.keys(DEFS) as PieceType[]).filter(k => DEFS[k].weight > 0 && (counts[k] ?? 0) < DEFS[k].max && q.depth >= DEFS[k].minDepth && !(k === q.parent.type && k !== 'corridor'));
    // The portal room and the first library are tried first once they are allowed, so every stronghold has them.
    const forced: PieceType[] = [];
    if (pool.includes('portal_room')) forced.push('portal_room');
    if (pool.includes('library') && !counts.library) forced.push('library');
    for (let tries = 0; tries < 8 && (forced.length || pool.length); tries++) {
      let type: PieceType;
      if (forced.length) { type = forced.shift()!; pool.splice(pool.indexOf(type), 1); }
      else {
        let w = rnd() * pool.reduce((s, k) => s + DEFS[k].weight, 0), i = 0;
        while (i < pool.length - 1 && (w -= DEFS[pool[i]].weight) > 0) i++;
        type = pool.splice(i, 1)[0];
      }
      const def = DEFS[type], piece: Piece = { type, d, ax, ay, az, depth: q.depth, variant: Math.floor(rnd() * 8), door: type === 'portal_room' ? 2 : Math.floor(rnd() * 3), box: [0, 0, 0, 0, 0, 0], open: def.exits.map(() => false) };
      piece.box = boxOf(piece);
      const b = piece.box;
      if (b[1] < MIN_Y || Math.max(Math.abs(b[0] - cx), Math.abs(b[3] - cx), Math.abs(b[2] - cz), Math.abs(b[5] - cz)) > STRONGHOLD_RADIUS) continue;
      if (pieces.some(o => overlaps(b, o.box))) continue;
      pieces.push(piece);
      counts[type] = (counts[type] ?? 0) + 1;
      q.parent.open[q.exit] = true;
      if (type === 'portal_room') portal = world(piece, 5, 2, 10);
      def.exits.forEach((_, i) => {
        if (type === 'turn' && i !== (piece.variant & 1)) return;
        if (type === 'corridor' && i > 0 && rnd() > 0.35) return;
        queue.push({ parent: piece, exit: i, depth: q.depth + 1 });
      });
      break;
    }
  }
  return { cx, cz, pieces, portal };
}

const LAYOUTS = new Map<string, StrongholdLayout>();
/** Layout of the stronghold whose starting staircase is at (cx, cz). Deterministic for a seed. */
export function strongholdLayout(seed: number, cx: number, cz: number): StrongholdLayout {
  const key = seed + ':' + cx + ',' + cz, hit = LAYOUTS.get(key);
  if (hit) return hit;
  let best: StrongholdLayout | null = null, bestScore = -1;
  for (let attempt = 0; attempt < 40; attempt++) {
    const L = generate((Math.imul(seed | 0, 31) ^ Math.imul(cx, 7919) ^ Math.imul(cz, 104729)) + attempt * 977, cx, cz);
    const has = (k: PieceType) => L.pieces.some(p => p.type === k);
    const score = (L.portal ? 100 : 0) + (has('library') ? 20 : 0) + (has('prison') ? 20 : 0) + (has('chest_corridor') ? 5 : 0) + (has('crossing') ? 5 : 0) + Math.min(20, L.pieces.length);
    if (score > bestScore) { best = L; bestScore = score; }
    if (score >= 165) break;
  }
  if (LAYOUTS.size > 16) LAYOUTS.clear();
  LAYOUTS.set(key, best!);
  return best!;
}

const FRAME_RING: [number, number, number][] = [[-1, -2, 0], [0, -2, 0], [1, -2, 0], [2, -1, 1], [2, 0, 1], [2, 1, 1], [1, 2, 2], [0, 2, 2], [-1, 2, 2], [-2, 1, 3], [-2, 0, 3], [-2, -1, 3]];
const SPIRAL_RING: [number, number][] = [[2, 1], [3, 1], [3, 2], [3, 3], [2, 3], [1, 3], [1, 2], [1, 1]];

function buildPiece(t: StructHost, put: Put, p: Piece) {
  const def = DEFS[p.type], d = p.d, right = (d + 1) & 3, back = (d + 2) & 3, left = (d + 3) & 3, brick = stoneBrick(t.seed + 3301);
  const S = (lx: number, ly: number, lz: number, block: number) => { const [x, y, z] = world(p, lx, ly, lz); put(x, y, z, block, true); };
  const SB = (lx: number, ly: number, lz: number) => { const [x, y, z] = world(p, lx, ly, lz); put(x, y, z, brick(x, y, z), true); };
  const T = (lx: number, ly: number, lz: number, table: string) => { const [x, y, z] = world(p, lx, ly, lz); put(x, y, z, bid('chest'), true); tag(t, x, y, z, table); };
  const rnd = (lx: number, ly: number, lz: number, salt = 0) => { const [x, y, z] = world(p, lx, ly, lz); return hash3(x, y, z, t.seed + 3307 + salt); };
  /** Iron bars running along the local X axis (across) or the local Z axis (along). */
  const barsAcross = cell('iron_bars', d % 2 === 0 ? PANE_X : PANE_Z), barsAlong = cell('iron_bars', d % 2 === 0 ? PANE_Z : PANE_X);
  const torchOn = (w: number) => cell('torch', attachOn(w));
  const solid = p.type === 'stairs' || p.type === 'spiral' || p.type === 'start';
  for (let ly = 0; ly < def.h; ly++) for (let lz = 0; lz < def.l; lz++) for (let lx = 0; lx < def.w; lx++) {
    const edge = lx === 0 || lx === def.w - 1 || ly === 0 || ly === def.h - 1 || lz === 0 || lz === def.l - 1;
    if (edge || solid) SB(lx, ly, lz); else S(lx, ly, lz, 0);
  }

  switch (p.type) {
    case 'corridor':
      S(1, 2, 1, torchOn(left)); S(3, 2, 5, torchOn(right));
      break;
    case 'turn':
      S(2, 2, 3, torchOn(d));
      break;
    case 'chest_corridor':
      SB(2, 1, 3);
      T(2, 2, 3, 'stronghold_corridor');
      for (const [lx, lz] of [[1, 3], [3, 3], [2, 2], [2, 4]]) S(lx, 1, lz, bid('stone_brick_slab', 'stone_bricks'));
      S(1, 2, 1, torchOn(left)); S(3, 2, 5, torchOn(right));
      break;
    case 'prison':
      // Walkway on the entry side, two cells behind an iron-bar wall with iron doors.
      for (let lz = 1; lz <= 9; lz++) for (let ly = 1; ly <= 3; ly++) S(4, ly, lz, barsAlong);
      for (let lx = 5; lx <= 7; lx++) for (let ly = 1; ly <= 3; ly++) S(lx, ly, 5, barsAcross);
      for (const lz of [3, 7]) { S(4, 1, lz, cell('iron_door', doorOn(right), 'iron_bars')); S(4, 2, lz, cell('iron_door', doorOn(right) | 4, 'iron_bars')); }
      S(1, 2, 5, torchOn(left));
      S(7, 3, 1, bid('cobweb', 'air')); S(7, 3, 9, bid('cobweb', 'air'));
      break;
    case 'crossing': {
      const v = p.variant % 4;
      if (v === 0) {                                                   // pillar with torches
        for (let ly = 1; ly <= 5; ly++) SB(5, ly, 5);
        S(4, 3, 5, torchOn(right)); S(6, 3, 5, torchOn(left)); S(5, 3, 4, torchOn(d)); S(5, 3, 6, torchOn(back));
      } else if (v === 1) {                                            // fountain
        for (let lz = 4; lz <= 6; lz++) for (let lx = 4; lx <= 6; lx++) if (lx === 5 && lz === 5) S(lx, 1, lz, bid('water')); else SB(lx, 1, lz);
        S(1, 3, 1, torchOn(left)); S(9, 3, 9, torchOn(right));
      } else if (v === 2) {                                            // store room: plank dais with the chest
        for (let lz = 7; lz <= 9; lz++) for (let lx = 1; lx <= 3; lx++) S(lx, 1, lz, bid('oak_planks'));
        T(2, 2, 8, 'stronghold_crossing');
        S(1, 2, 9, bid('oak_planks')); S(1, 3, 9, bid('torch'));
        S(3, 2, 9, bid('oak_fence', 'oak_planks'));
        S(9, 3, 1, torchOn(right));
      } else {
        for (const [lx, lz] of [[1, 1], [9, 1], [1, 9], [9, 9]]) if (rnd(lx, 5, lz) < 0.7) S(lx, 5, lz, bid('cobweb', 'air'));
        S(5, 3, 1, torchOn(back));
      }
      break;
    }
    case 'stairs':
      for (let k = 1; k <= 6; k++) for (let lx = 1; lx <= 3; lx++) {
        S(lx, 7 - k, k, cell('stone_brick_stairs', stairsUp(back), 'stone_bricks'));
        for (let ly = 8 - k; ly <= 10 - k; ly++) S(lx, ly, k, 0);
      }
      break;
    case 'start':
    case 'spiral':
      for (let ly = 1; ly <= 9; ly++) for (let lz = 1; lz <= 3; lz++) for (let lx = 1; lx <= 3; lx++) if (lx !== 2 || lz !== 2) S(lx, ly, lz, 0);
      SB(2, 6, 1);                                                     // landing behind the upper door
      for (let j = 1; j <= 11; j++) {                                  // half-block steps winding down around the newel
        const [lx, lz] = SPIRAL_RING[j % 8];
        S(lx, j % 2 ? (13 - j) / 2 : 6 - j / 2, lz, cell('stone_brick_slab', j % 2 ? 0 : 1, 'stone_bricks'));
      }
      S(1, 8, 1, torchOn(left));
      break;
    case 'library': {
      const shelf = bid('bookshelf', 'oak_planks'), planks = bid('oak_planks'), fence = bid('oak_fence', 'oak_planks'), web = bid('cobweb', 'air');
      // Cobwebs first so shelves, planks and the ladder take precedence.
      for (const ly of [4, 9]) for (let lz = 1; lz <= 13; lz++) for (let lx = 1; lx <= 12; lx++) {
        if ((lx <= 2 || lx >= 11 || lz <= 2 || lz >= 12) && rnd(lx, ly, lz, 5) < 0.14) S(lx, ly, lz, web);
      }
      for (const [lx, ly, lz] of [[2, 9, 2], [11, 9, 2], [2, 9, 12], [11, 9, 12], [5, 4, 12], [8, 4, 1]]) S(lx, ly, lz, web);
      // Ground floor: shelves against the side walls and free-standing shelf rows.
      for (let lz = 1; lz <= 13; lz += 2) for (let ly = 1; ly <= 4; ly++) { S(1, ly, lz, shelf); S(12, ly, lz, shelf); }
      for (const lz of [3, 7, 11]) for (let ly = 1; ly <= 3; ly++) for (const lx of [3, 4, 9, 10]) S(lx, ly, lz, shelf);
      // Gallery (second floor): plank ring with a fence railing, shelves on the outer walls.
      for (let lz = 1; lz <= 13; lz++) for (let lx = 1; lx <= 12; lx++) {
        const ring = lx <= 3 || lx >= 10 || lz <= 2 || lz >= 11;
        if (!ring) continue;
        S(lx, 5, lz, planks);
        const inner = ((lx === 3 || lx === 10) && lz >= 2 && lz <= 11) || ((lz === 2 || lz === 11) && lx >= 3 && lx <= 10);
        if (inner) S(lx, 6, lz, fence);
      }
      for (let lz = 1; lz <= 13; lz += 2) for (let ly = 6; ly <= 8; ly++) { S(1, ly, lz, shelf); S(12, ly, lz, shelf); }
      for (let lx = 3; lx <= 9; lx += 2) for (let ly = 6; ly <= 8; ly++) S(lx, ly, 13, shelf);
      for (let ly = 1; ly <= 5; ly++) S(12, ly, 13, cell('ladder', ladderOn(d)));
      for (let ly = 6; ly <= 8; ly++) S(12, ly, 13, 0);
      // Chandelier: fence cross with four torches.
      S(6, 9, 7, fence); S(6, 8, 7, fence);
      for (const [lx, lz] of [[5, 7], [7, 7], [6, 6], [6, 8]]) { S(lx, 8, lz, fence); S(lx, 9, lz, bid('torch')); }
      T(6, 1, 13, 'stronghold_library');
      S(6, 2, 13, 0);
      T(1, 6, 6, 'stronghold_library');
      S(1, 7, 6, 0);
      break;
    }
    case 'portal_room': {
      for (let lz = 1; lz <= 14; lz++) {
        for (const lx of [1, 9]) if (lz >= 2 && lz <= 13) S(lx, 1, lz, bid('lava')); else SB(lx, 1, lz);
        SB(2, 1, lz); SB(8, 1, lz);
      }
      for (const lz of [4, 5, 9, 10]) for (const ly of [3, 4]) { S(0, ly, lz, barsAlong); S(10, ly, lz, barsAlong); }
      for (let lx = 3; lx <= 7; lx++) S(lx, 1, 7, cell('stone_brick_stairs', stairsUp(d), 'stone_bricks'));
      for (let lz = 8; lz <= 12; lz++) for (let lx = 3; lx <= 7; lx++) {
        if (lx >= 4 && lx <= 6 && lz >= 9 && lz <= 11) S(lx, 1, lz, bid('lava')); else SB(lx, 1, lz);
      }
      S(5, 2, 7, bid('spawner', 'iron_bars'));                           // silverfish spawner on the steps
      const [px, py, pz] = world(p, 5, 2, 10), frame = bid('end_portal_frame', 'stone_bricks');
      FRAME_RING.forEach(([dx, dz, facing], i) => {
        const eye = hash2(px + i * 17, pz - i * 29, t.seed + 3311) < 0.1 && i !== 0;      // 10 % per frame, never a finished portal
        put(px + dx, py, pz + dz, makeCell(frame, facing | (eye ? 4 : 0)), true);
      });
      S(3, 4, 1, torchOn(back)); S(7, 4, 1, torchOn(back));
      break;
    }
  }

  // Entry: a 3×3 opening, optionally closed by a wooden door or an iron-bar grate.
  if (p.type !== 'start') {
    for (let ly = def.ey + 1; ly <= def.ey + 3; ly++) for (let lx = def.ex - 1; lx <= def.ex + 1; lx++) {
      const centre = lx === def.ex && ly <= def.ey + 2;
      if (p.door === 0 || (centre && p.door === 2)) S(lx, ly, 0, 0);
      else if (p.door === 2) S(lx, ly, 0, barsAcross);
      else if (centre) S(lx, ly, 0, cell('oak_door', doorOn(back) | (ly === def.ey + 2 ? 4 : 0)));
    }
  }
  def.exits.forEach((e, i) => {
    if (!p.open[i]) return;
    for (let ly = e.ly + 1; ly <= e.ly + 3; ly++) for (let k = -1; k <= 1; k++) {
      if (e.turn === 0) S(e.lx + k, ly, e.lz - 1, 0);
      else S(e.turn === 3 ? e.lx + 1 : e.lx - 1, ly, e.lz + k, 0);
    }
  });
}

/** Writes the stronghold around (cx, cz); with (ox, oz) only the pieces touching that chunk are built. */
export function buildStronghold(t: StructHost, put: Put, cx: number, cz: number, ox?: number, oz?: number) {
  const L = strongholdLayout(t.seed, cx, cz);
  for (const p of L.pieces) {
    if (ox !== undefined && oz !== undefined && (p.box[3] < ox - 1 || p.box[0] > ox + 17 || p.box[5] < oz - 1 || p.box[2] > oz + 17)) continue;
    buildPiece(t, put, p);
  }
  return L;
}
