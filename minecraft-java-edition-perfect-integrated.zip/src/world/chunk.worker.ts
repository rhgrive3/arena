import { Terrain } from "./terrain";
import { meshChunk, type MeshData } from "./mesher";

let terrain: Terrain | undefined, seed = "", dimension = "";
let tiles: number[][] | undefined;

const transfers = (m: MeshData) => [m.position.buffer, m.normal.buffer, m.uv.buffer, m.color.buffer, m.tile.buffer, m.wind.buffer, m.light.buffer, m.index.buffer];

function emptyMesh(): MeshData {
  return {
    position: new Float32Array(0),
    normal: new Float32Array(0),
    uv: new Float32Array(0),
    color: new Float32Array(0),
    tile: new Float32Array(0),
    wind: new Float32Array(0),
    light: new Float32Array(0),
    index: new Uint32Array(0),
  };
}

function extendY(m: MeshData, range: [number, number]) {
  const p = m.position;
  for (let i = 1; i < p.length; i += 3) {
    const y = p[i];
    if (y < range[0]) range[0] = y;
    if (y > range[1]) range[1] = y;
  }
}

self.onmessage = (event: MessageEvent) => {
  const m = event.data;
  try {
    if (m.tiles) tiles = m.tiles;
    if (!tiles) throw new Error("tile table missing");
    if (!terrain || seed !== m.seed || dimension !== m.dimension) {
      terrain = new Terrain(m.seed, m.dimension);
      seed = m.seed;
      dimension = m.dimension;
    }
    const generated = terrain.generate(m.cx, m.cz, m.edits, m.structures);
    if (m.sideOnly) {
      const solid = emptyMesh(), water = emptyMesh();
      const response = {
        type: "chunk", key: m.key, cx: m.cx, cz: m.cz, version: m.version, epoch: m.epoch,
        sideOnly: true, genMaxY: generated.maxY, data: generated.data.buffer,
        solid, water, minY: 0, maxY: generated.maxY
      };
      self.postMessage(response, [generated.data.buffer] as any);
      return;
    }
    const solidMesh = meshChunk(generated.padded, generated.maxY, tiles, generated.tint);
    const range: [number, number] = [Infinity, -Infinity];
    extendY(solidMesh.solid, range);
    extendY(solidMesh.water, range);
    if (range[0] > range[1]) { range[0] = 0; range[1] = 0; }
    const response = {
      type: "chunk", key: m.key, cx: m.cx, cz: m.cz, version: m.version, epoch: m.epoch,
      genMaxY: generated.maxY, data: generated.data.buffer,
      solid: solidMesh.solid, water: solidMesh.water,
      minY: range[0], maxY: range[1]
    };
    self.postMessage(response, [generated.data.buffer, ...transfers(solidMesh.solid), ...transfers(solidMesh.water)] as any);
  } catch (error) {
    self.postMessage({ type: "error", key: m.key, epoch: m.epoch, message: String(error) });
  }
};
