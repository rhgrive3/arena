import { rollPiglinBarter, ominousBottleStack } from '../systems/vanillaPlus';
import { MobBehaviors, Behaviors, armorFactor, type BehaviorCtx, type MobX } from './behaviors';
import type { GameEvents } from '../game/events';
import { SEA as SEA_LEVEL, endPillars, type Terrain } from '../world/terrain';
import * as THREE from 'three';
import { BLOCKS, ID, resolve } from '../game/data';
import { random } from '../input/math';
import type { BossInfo } from '../game/types';
import {
  NEW_SPECIES, BREED_FOOD, TAME_FOOD, RIDE_TAME, SADDLEABLE, LEASHABLE, RIDE,
  JOB_SITES, TRADES, TRADER_OFFERS, LEVEL_XP, LEVEL_JA, LEVEL_NAMES, PROFESSION_JA,
  BARTER, RAID_WAVES, type Profession, type Offer,
} from './mobdata';
import { findPath, groundAt, type PathPoint } from './pathfinding';
import {
  newVillager, getTradeOffers, addTradeXp, updateJob, restockVillager, tickVillager, wanderingTrader,
  type VillagerData,
} from './villagers';

export type Species =
  | 'cow' | 'pig' | 'sheep' | 'chicken' | 'zombie' | 'skeleton' | 'creeper' | 'spider'
  | 'enderman' | 'villager' | 'wolf' | 'cat' | 'horse' | 'iron_golem' | 'fish' | 'dolphin'
  | 'blaze' | 'ghast' | 'wither' | 'dragon' | 'warden' | 'slime' | 'magma_cube' | 'pillager'
  | 'witch' | 'bee' | 'fox' | 'rabbit' | 'squid' | 'turtle' | 'shulker'
  // Record 014 (48 new species -> 79 total)
  | 'piglin' | 'piglin_brute' | 'zombified_piglin' | 'hoglin' | 'zoglin' | 'strider' | 'wither_skeleton'
  | 'vindicator' | 'evoker' | 'vex' | 'ravager'
  | 'drowned' | 'husk' | 'zombie_villager' | 'stray' | 'bogged' | 'phantom'
  | 'cave_spider' | 'silverfish' | 'endermite' | 'breeze'
  | 'guardian' | 'elder_guardian' | 'salmon' | 'tropical_fish' | 'pufferfish' | 'glow_squid' | 'axolotl' | 'tadpole'
  | 'panda' | 'polar_bear' | 'llama' | 'parrot' | 'goat' | 'frog' | 'camel' | 'donkey' | 'mule'
  | 'skeleton_horse' | 'zombie_horse' | 'mooshroom' | 'armadillo' | 'sniffer' | 'ocelot' | 'snow_golem'
  | 'wandering_trader' | 'allay' | 'bat';

export const SPECIES: Species[] = [
  'cow', 'pig', 'sheep', 'chicken', 'zombie', 'skeleton', 'creeper', 'spider',
  'enderman', 'villager', 'wolf', 'cat', 'horse', 'iron_golem', 'fish', 'dolphin',
  'blaze', 'ghast', 'wither', 'dragon', 'warden', 'slime', 'magma_cube', 'pillager',
  'witch', 'bee', 'fox', 'rabbit', 'squid', 'turtle', 'shulker',
  ...(Object.keys(NEW_SPECIES) as Species[]),
];

export interface DriveInput { move: { x: number; z: number }; yaw: number; run: boolean; ascend: boolean }

export interface MobSave {
  id?: number;
  raidMember?: boolean;
  species: Species;
  position: [number, number, number];
  hp: number;
  baby: boolean;
  age?: number;
  grow?: number;
  tamed: boolean;
  saddled: boolean;
  sitting: boolean;
  leashed: boolean;
  leashPos?: [number, number, number] | null;
  wool: boolean;
  breedCooldown: number;
  love: number;
  profession?: Profession;
  level?: number;
  xp?: number;
  villager?: VillagerData;
  charged?: boolean;
  /** Behaviour-pass state (charged creeper, carried block, hive, home beach, wolf armor…) — see Behaviors.saveExtra. */
  extra?: Record<string, unknown>;
}

export interface RaidState {
  wave: number;
  total: number;
  alive: number;
  timer: number;
  delay: number;
  center: [number, number, number];
  members: number[];
}

export interface MobHost {
  terrain: Terrain;
  position: THREE.Vector3;
  camera: THREE.PerspectiveCamera;
  time: number;
  dimension: string;
  dragonDefeated: boolean;
  getBlock(x: number, y: number, z: number): number;
  getCell?(x: number, y: number, z: number): number;
  damage(n: number): 'none' | 'blocked' | 'hit' | 'dead' | void;
  /** Fraction of the normal detection range the player currently has (sneaking, invisibility). */
  visibility?(): number;
  addItem(n: string, c: number): boolean;
  addXp?(n: number): void;
  toast(j: string, e: string): void;
  sound(k: string, p?: { x: number; y: number; z: number }): void;
  explode(p: THREE.Vector3, r: number): void;
  teleport(x: number, y: number, z: number): void;
  openTrade(m?: Mob): void;
  onDragonDefeated(): void;
  onEnterGateway(): void;
  levitate(sec: number): void;
  /** Record 014 hooks */
  wearingGold?(): boolean;
  goldArmor?(): boolean;
  effect?(id: string, sec: number, amp?: number): void;
  insomnia?(): number;
  difficulty?(): string;
  consume?(item?: string, count?: number): boolean;
  playerMoving?(): boolean;
  sneaking?(): boolean;
  heldItem?(): string;
  onVibration?(x: number, y: number, z: number, strength: number): void;
  /** Dungeon / behaviour pass hooks — all optional so headless hosts can leave them out. */
  setBlock?(x: number, y: number, z: number, id: number, state?: number): boolean;
  getState?(x: number, y: number, z: number): number;
  raining?(): boolean;
  emit?<K extends keyof GameEvents>(type: K, payload: GameEvents[K]): void;
  growCrop?(x: number, y: number, z: number): boolean;
  nearestDrop?(name: string, x: number, y: number, z: number, r: number, avoid?: [number, number, number] | null): { x: number; y: number; z: number } | null;
  takeDrop?(name: string, x: number, y: number, z: number, r: number): number;
  onMobDeath?(m: Mob): void;
  wearHeld?(n: number): void;
  mapOffers?(m: Mob): Offer[];
  knockPlayer?(dx: number, dy: number, dz: number): void;
  particles: {
    burst(p: THREE.Vector3, c: string, n?: number, power?: number): void;
    spark?(p: THREE.Vector3, c: string, n?: number): void;
    drop(p: THREE.Vector3, n: string, c: number, col: string): void;
    takeNear?(p: THREE.Vector3, r: number, accept: (name: string) => boolean): { name: string; count: number } | null;
  };
}

export interface Mob {
  id: number;
  species: Species;
  group: THREE.Group;
  legs: THREE.Object3D[];
  limbs?: Limb[];
  walk?: number;
  swing?: number;
  lastX?: number;
  lastZ?: number;
  head: THREE.Object3D;
  woolCoat?: THREE.Object3D;
  collar?: THREE.Object3D;
  lid?: THREE.Object3D;
  jaw?: THREE.Object3D;
  tail?: THREE.Object3D;
  ears?: THREE.Object3D[];
  core?: THREE.Object3D;
  extras?: THREE.Object3D[];
  outfit?: THREE.Group;
  outfitKey?: string;
  baseLegY?: number;
  hp: number;
  maxHp: number;
  state: 'wander' | 'graze' | 'flee' | 'chase' | 'aim' | 'fuse' | 'teleport' | 'follow' | 'trade' | 'circle' | 'charge' | 'perch';
  phaseTimer: number;
  timer: number;
  attack: number;
  hurtTimer: number;
  dir: number;
  speed: number;
  target: THREE.Vector3;
  fuse: number;
  wool: boolean;
  tamed: boolean;
  love: number;
  egg: number;
  baby: boolean;
  // Record 014
  grow: number;
  age?: number;
  breedCooldown: number;
  saddled?: boolean;
  saddle?: THREE.Object3D;
  leashed: boolean;
  leashPos?: [number, number, number] | null;
  sitting: boolean;
  anger: number;
  path: PathPoint[] | null;
  pathAt: number;
  profession: Profession;
  level: number;
  xp: number;
  villager?: VillagerData;
  captain: boolean;
  raid: boolean;
  raidMember?: boolean;
  vy: number;
  lastNoise: THREE.Vector3 | null;
  tameTries: number;
  barter: number;
  zombify: number;
  special: number;
  rolledUp?: number;
  curing?: number;
  shearedHead?: boolean;
  charged?: boolean;
  aura?: THREE.Mesh;
  carried?: number;
  fx?: Record<string, number>;
  bonusArmor?: number;
  trial?: string;
  ominous?: boolean;
  hive?: [number, number, number] | null;
  flower?: [number, number, number] | null;
  nectar?: boolean;
  pollinating?: boolean;
  honeyReady?: boolean;
  inHive?: number;
  cropsGrown?: number;
  lastCrop?: string;
  home?: [number, number, number];
  pregnant?: boolean;
  digging?: boolean;
  digTimer?: number;
  digCooldown?: number;
  dug?: string[];
  wanted?: string;
  heldCount?: number;
  noteBlock?: [number, number, number] | null;
  noteTimer?: number;
  wolfArmor?: number;
  scuteTimer?: number;
  wasBaby?: boolean;
  maps?: Record<string, [number, number, number] | null>;
  bt?: number;
  bt2?: number;
  bt3?: number;
}

type LimbKind = 'leg' | 'arm' | 'wing' | 'spider' | 'tentacle';
interface Limb { node: THREE.Object3D; kind: LimbKind; phase: number; amp: number; baseX: number; baseY: number; baseZ: number; }
interface EndCrystal {
  group: THREE.Group;
  core: THREE.Mesh;
  shell: THREE.Mesh;
  pos: THREE.Vector3;
}
interface Projectile {
  kind: 'mob_arrow' | 'player_arrow' | 'ghast_fireball' | 'blaze_fireball' | 'dragon_fireball' | 'shulker_bullet' | 'ender_pearl' | 'ender_eye' | 'snowball' | 'trident' | 'potion' | 'wind_charge';
  mesh: THREE.Mesh;
  v: THREE.Vector3;
  life: number;
  damage: number;
  target?: THREE.Vector3;
  gravity?: number;
  onEnd?: (pos: THREE.Vector3) => void;
  flame?: boolean;
  punch?: number;
  effect?: [string, number];
  /** Extra mobs a Piercing arrow can still pass through, mobs it already hit, and the item it drops when it sticks in a block. */
  pierce?: number;
  hit?: Set<Mob>;
  recover?: string;
}
interface Arrow {
  mesh: THREE.Mesh;
  v: THREE.Vector3;
  life: number;
  fromPlayer: boolean;
  damage: number;
}

const passive = new Set<string>([
  'cow', 'pig', 'sheep', 'chicken', 'villager', 'wolf', 'cat', 'horse',
  'fish', 'dolphin', 'bee', 'fox', 'rabbit', 'squid', 'turtle',
  ...Object.keys(NEW_SPECIES).filter(k => NEW_SPECIES[k].passive),
]);
const neutral = new Set<string>(['zombified_piglin', 'polar_bear', 'llama', 'panda', 'goat', 'wolf', 'bee', 'dolphin', 'iron_golem']);
const flyers = new Set<string>(['bee', 'blaze', 'ghast', 'wither', 'vex', 'phantom', 'allay', 'parrot', 'bat', 'breeze']);
const swimmers = new Set<string>(['fish', 'salmon', 'tropical_fish', 'pufferfish', 'tadpole', 'dolphin', 'squid', 'glow_squid', 'guardian', 'elder_guardian', 'axolotl']);

const drops: Record<string, [string, number]> = {
  cow: ['raw_beef', 2], pig: ['porkchop', 2], sheep: ['white_wool', 1], chicken: ['chicken', 1],
  zombie: ['rotten_flesh', 2], skeleton: ['bone', 2], creeper: ['gunpowder', 2], spider: ['string', 2],
  enderman: ['ender_pearl', 1], villager: ['bread', 1], wolf: ['bone', 1], cat: ['string', 1],
  horse: ['leather', 2], iron_golem: ['iron_ingot', 3], fish: ['cod', 1], dolphin: ['cod', 1],
  blaze: ['blaze_rod', 1], ghast: ['ghast_tear', 1], wither: ['nether_star', 1], dragon: ['dragon_breath', 4],
  warden: ['sculk', 2], slime: ['slime_ball', 2], magma_cube: ['magma_cream', 2],
  pillager: ['arrow', 3], witch: ['redstone', 2], bee: ['honeycomb', 1],
  fox: ['leather', 1], rabbit: ['rabbit_hide', 1], squid: ['ink_sac', 2], turtle: ['scute', 1], shulker: ['shulker_shell', 1],
};
for (const [k, v] of Object.entries(NEW_SPECIES)) drops[k] = v.drop;

export class MobManager {
  mobs: Mob[] = [];
  nextId = 1;
  rnd = random(78123);
  materials = new Map<string, THREE.MeshLambertMaterial>();
  hurtMat = new THREE.MeshLambertMaterial({ color: '#e84a3c', emissive: '#6a120a' });
  box = new THREE.BoxGeometry(1, 1, 1);
  spawnTimer = 0;
  jobTimer = 0;
  arrows: Arrow[] = [];
  crystals: EndCrystal[] = [];
  projectiles: Projectile[] = [];
  emissiveMaterials = new Map<string, THREE.MeshBasicMaterial>();
  nightVision = 0;
  chargedAuraMat = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 } },
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    vertexShader: `varying vec2 vUv; varying vec3 vPos;
    void main() {
      vUv = uv;
      vPos = position;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }`,
    fragmentShader: `uniform float uTime; varying vec2 vUv; varying vec3 vPos;
    void main() {
      float wave1 = sin((vPos.y * 6.0 + vPos.x * 4.0) - uTime * 5.2);
      float wave2 = cos((vPos.z * 6.0 - vPos.y * 5.0) + uTime * 4.4);
      float arc = smoothstep(0.35, 0.95, abs(wave1 * wave2));
      vec3 col = mix(vec3(0.18, 0.62, 1.0), vec3(0.72, 0.96, 1.0), arc);
      float alpha = 0.22 + 0.42 * arc;
      gl_FragColor = vec4(col, alpha);
    }`,
  });

  /** Applies Night Vision full-bright emissive boost to all mob Lambert materials so entities in darkness are uniformly lit. */
  applyNightVision(nv: number) {
    const clamped = Math.max(0, Math.min(1, nv));
    if (Math.abs(clamped - this.nightVision) < 0.005) return;
    this.nightVision = clamped;
    for (const mat of this.materials.values()) {
      if (mat.emissive && typeof mat.emissive.copy === "function") mat.emissive.copy(mat.color);
      else (mat as any).emissive = mat.color.clone();
      mat.emissiveIntensity = clamped * 0.85;
    }
  }

  /** Converts a Creeper into a Charged Creeper surrounded by a rotating, pulsing blue energy shield shader. */
  chargeCreeper(m: Mob): boolean {
    if (m.species !== 'creeper') return false;
    m.charged = true;
    if (!m.aura) {
      const aura = new THREE.Mesh(this.box, this.chargedAuraMat);
      aura.position.set(0, 0.92, 0);
      aura.scale.set(0.76, 1.78, 0.72);
      aura.renderOrder = 3;
      m.group.add(aura);
      m.aura = aura;
    }
    return true;
  }

  /** Lightning strike handler: charges nearby creepers within 5 blocks (and transforms pigs/villagers). */
  strikeLightning(pos: THREE.Vector3): number {
    return this.behaviors.lightning(pos);
  }

  /** The mob (or projectile) whose attack is currently being resolved — lets the host work out the shield arc / axe / piercing. */
  attacker: Mob | null = null;
  attackProj: Projectile | null = null;
  beh!: MobBehaviors;
  /** Species behaviours of the dungeon / 1.21 pass (enderman, charged creeper, turtle, bee, allay, sniffer, armadillo, effects). */
  behaviors = new Behaviors(this);

  private _tmpA = new THREE.Vector3();
  private _tmpB = new THREE.Vector3();
  private _look = new THREE.Vector3();

  constructor(public scene: THREE.Scene, public host: MobHost) {
    this.beh = new MobBehaviors(this as unknown as BehaviorCtx);
    const baseDamage = host.damage.bind(host);
    host.damage = (n: number) => baseDamage(n > 0 && this.beh.curBonus ? n + this.beh.curBonus : n);
    this.populate();
  }

  mat(color: string) {
    let m = this.materials.get(color);
    if (!m) {
      m = new THREE.MeshLambertMaterial({ color });
      if (this.nightVision > 0) { m.emissive.copy(m.color); m.emissiveIntensity = this.nightVision * 0.85; }
      this.materials.set(color, m);
    }
    return m;
  }

  glowMat(color: string, opacity = 1) {
    const key = color + ':' + opacity;
    let m = this.emissiveMaterials.get(key);
    if (!m) {
      m = new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity });
      this.emissiveMaterials.set(key, m);
    }
    return m;
  }

  part(g: THREE.Object3D, color: string, x: number, y: number, z: number, w: number, h: number, d: number) {
    const m = new THREE.Mesh(this.box, this.mat(color));
    m.userData.baseMat = m.material;
    m.position.set(x, y, z);
    m.scale.set(w, h, d);
    m.castShadow = false;
    m.receiveShadow = true;
    g.add(m);
    return m;
  }

  glowPart(g: THREE.Object3D, color: string, x: number, y: number, z: number, w: number, h: number, d: number, opacity = 1) {
    const m = new THREE.Mesh(this.box, this.glowMat(color, opacity));
    m.userData.baseMat = m.material;
    m.position.set(x, y, z);
    m.scale.set(w, h, d);
    g.add(m);
    return m;
  }

  model(species: Species) {
    const g = new THREE.Group();
    const legs: THREE.Object3D[] = [];
    const wings: THREE.Object3D[] = [];
    const head = new THREE.Group();
    g.add(head);
    let woolCoat: THREE.Object3D | undefined;
    let collar: THREE.Object3D | undefined;
    let lid: THREE.Object3D | undefined;
    let jaw: THREE.Object3D | undefined;
    let tail: THREE.Object3D | undefined;
    let ears: THREE.Object3D[] | undefined;
    let core: THREE.Object3D | undefined;
    let extras: THREE.Object3D[] | undefined;
    let outfit: THREE.Group | undefined;
    let baseLegY: number | undefined;

    const eyes = (y: number, z: number, sep: number, color = '#171b17', sclera?: string, ew = 0.068, eh = 0.068) => {
      if (sclera) {
        this.part(head, sclera, -sep, y, z + 0.002, ew * 1.85, eh * 1.05, 0.022);
        this.part(head, sclera, sep, y, z + 0.002, ew * 1.85, eh * 1.05, 0.022);
      }
      const pShift = sclera ? ew * 0.36 : 0;
      this.part(head, color, -(sep + pShift), y, z - 0.004, ew, eh, 0.028);
      this.part(head, color, sep + pShift, y, z - 0.004, ew, eh, 0.028);
    };
    const quadLegs = (color: string, w: number, h: number, d: number, x: number, z: number, hoofColor?: string, upperCoatColor?: string) => {
      baseLegY = h;
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
        const pivot = new THREE.Group();
        pivot.position.set(sx * x, h, sz * z);
        this.part(pivot, color, 0, -h / 2, 0, w, h, d);
        if (upperCoatColor) {
          this.part(pivot, upperCoatColor, 0, -h * 0.26, 0, w * 1.28, h * 0.48, d * 1.28);
        }
        if (hoofColor) {
          this.part(pivot, hoofColor, 0, -h + 0.065, 0, w * 1.08, 0.13, d * 1.08);
        }
        g.add(pivot);
        legs.push(pivot);
      }
    };

    if (species === 'dragon') {
      // Ender Dragon: articulated 5-segment neck + 12-segment tail with vertebral spines, horned jawed head, 4 clawed legs, and dual-segment wings with gray bone struts & finger spars
      this.part(g, '#18141f', 0, 1.44, 0, 1.64, 1.32, 3.24);
      this.part(g, '#251f30', 0, 1.22, -0.30, 1.48, 0.96, 2.60); // Ribbed underbelly
      for (let i = 0; i < 6; i++) {
        this.part(g, '#4b3f5e', 0, 2.22, -1.35 + i * 0.56, 0.22, 0.38, 0.30); // Dorsal spine plates
      }
      // 5-segment articulated neck leading to head
      for (let i = 0; i < 5; i++) {
        const ny = 1.62 + i * 0.05, nz = -1.55 - i * 0.24;
        this.part(g, i % 2 ? '#1c1826' : '#231e30', 0, ny, nz, 0.68 - i * 0.03, 0.62 - i * 0.02, 0.36);
        this.part(g, '#4b3f5e', 0, ny + 0.36, nz, 0.14, 0.20, 0.18);
      }
      head.position.set(0, 1.88, -2.75);
      this.part(head, '#1e1928', 0, 0.04, 0, 1.02, 0.86, 1.18);
      this.part(head, '#262033', 0, 0.02, -0.84, 0.74, 0.34, 0.94); // Upper snout
      this.part(head, '#463b58', -0.22, 0.22, -1.08, 0.12, 0.12, 0.16); // Raised nostrils
      this.part(head, '#463b58', 0.22, 0.22, -1.08, 0.12, 0.12, 0.16);
      const dJaw = new THREE.Group();
      dJaw.position.set(0, -0.18, -0.42);
      this.part(dJaw, '#1a1524', 0, 0, -0.40, 0.68, 0.20, 0.88);
      this.part(dJaw, '#682c7d', 0, 0.08, -0.38, 0.54, 0.07, 0.74); // Purple inner mouth
      head.add(dJaw);
      jaw = dJaw;
      for (const sx of [-1, 1]) {
        const horn = this.part(head, '#4e4263', sx * 0.34, 0.56, 0.24, 0.18, 0.48, 0.44);
        horn.rotation.x = -0.28;
        this.part(head, '#685980', sx * 0.34, 0.78, 0.38, 0.14, 0.18, 0.22); // Horn tip
      }
      this.glowPart(head, '#f58cff', -0.32, 0.16, -0.58, 0.14, 0.10, 0.04);
      this.glowPart(head, '#d038ff', -0.32, 0.16, -0.59, 0.07, 0.08, 0.04);
      this.glowPart(head, '#f58cff', 0.32, 0.16, -0.58, 0.14, 0.10, 0.04);
      this.glowPart(head, '#d038ff', 0.32, 0.16, -0.59, 0.07, 0.08, 0.04);
      // 4 Dragon legs (2 smaller front limbs, 2 large hind legs with 3-clawed feet)
      for (const sx of [-1, 1]) {
        const fLeg = this.part(g, '#1e1928', sx * 0.82, 0.76, -0.88, 0.32, 0.86, 0.36);
        fLeg.rotation.x = 0.28;
        this.part(g, '#3d334d', sx * 0.82, 0.32, -0.98, 0.36, 0.14, 0.48);
        const hLeg = this.part(g, '#1c1726', sx * 0.88, 0.68, 0.92, 0.44, 1.18, 0.52);
        hLeg.rotation.x = -0.22;
        this.part(g, '#3d334d', sx * 0.88, 0.14, 0.78, 0.48, 0.18, 0.64);
      }
      const tGroup = new THREE.Group();
      tGroup.position.set(0, 1.38, 1.62);
      for (let i = 0; i < 9; i++) {
        this.part(tGroup, i % 2 ? '#18141f' : '#262033', 0, -i * 0.035, 0.32 + i * 0.60, 0.58 - i * 0.048, 0.52 - i * 0.04, 0.62);
        this.part(tGroup, '#4b3f5e', 0, 0.28 - i * 0.05, 0.32 + i * 0.60, 0.14, 0.24 - i * 0.015, 0.24);
      }
      g.add(tGroup);
      tail = tGroup;
      for (const side of [-1, 1]) {
        const wingPivot = new THREE.Group();
        wingPivot.position.set(side * 0.84, 1.88, -0.52);
        this.part(wingPivot, '#4e4461', side * 1.9, 0.10, -0.12, 3.8, 0.18, 0.24); // Leading bone strut
        this.part(wingPivot, '#625678', side * 3.6, 0.06, 0.08, 1.9, 0.14, 0.18); // Outer wing bone
        this.part(wingPivot, '#14101c', side * 2.2, -0.02, 0.86, 4.4, 0.05, 1.95); // Dark wing membrane
        // Wing finger struts across membrane
        for (const fx of [1.2, 2.4, 3.5]) {
          this.part(wingPivot, '#3b324d', side * fx, 0.02, 0.82, 0.10, 0.08, 1.85);
        }
        g.add(wingPivot);
        wings.push(wingPivot);
        legs.push(wingPivot);
      }
      g.scale.setScalar(1.35);
    } else if (species === 'shulker') {
      // Shulker: stationary bottom shell with stepped crenulated notches, inner yellow head, and rotating/lifting top shell lid
      this.part(g, '#734478', 0, 0.18, 0, 0.98, 0.36, 0.98);
      this.part(g, '#5e3562', 0, 0.03, 0, 0.92, 0.06, 0.92);
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
        this.part(g, '#7c4c80', sx * 0.35, 0.42, sz * 0.35, 0.28, 0.16, 0.28);
      }
      head.position.set(0, 0.44, 0);
      this.part(head, '#e8dcb8', 0, 0, 0, 0.46, 0.46, 0.46);
      this.part(head, '#d2c298', 0, -0.10, -0.235, 0.22, 0.10, 0.02);
      eyes(0.05, -0.24, 0.12, '#241c29', '#ffffff');
      const shulkerLid = new THREE.Group();
      shulkerLid.position.set(0, 0.64, 0);
      this.part(shulkerLid, '#9b679f', 0, 0.26, 0, 0.98, 0.52, 0.98);
      this.part(shulkerLid, '#b27eb6', 0, 0.52, 0, 0.88, 0.05, 0.88);
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
        this.part(shulkerLid, '#8c5990', sx * 0.35, -0.05, sz * 0.35, 0.28, 0.14, 0.28);
      }
      g.add(shulkerLid);
      lid = shulkerLid;
      wings.push(shulkerLid);
    } else if (species === 'iron_golem') {
      // Iron Golem: wide inverted-triangle chest with mossy vines & red poppy accents, narrow waist, tall head with red eyes & hanging nose, long swinging arms
      this.part(g, '#d4d2c0', 0, 1.62, 0, 1.12, 0.68, 0.62); // Massive upper torso (18x12x11 px ratio)
      this.part(g, '#c2c0ae', 0, 1.62, -0.315, 0.94, 0.54, 0.02); // Chest plate bevel
      this.part(g, '#a8a696', 0, 1.12, 0, 0.56, 0.34, 0.38); // Waist/pelvis (9x5x6 px ratio)
      // Mossy vine overlays & tiny poppy blossom on chest and left shoulder
      this.part(g, '#5d873b', -0.34, 1.64, -0.32, 0.22, 0.62, 0.03);
      this.part(g, '#76a34a', -0.22, 1.48, -0.325, 0.16, 0.32, 0.03);
      this.part(g, '#5d873b', -0.44, 1.97, 0, 0.24, 0.06, 0.58);
      this.part(g, '#d93829', -0.36, 1.76, -0.335, 0.08, 0.08, 0.03); // Red poppy flower accent on vine
      this.part(g, '#f2c838', -0.28, 1.56, -0.335, 0.06, 0.06, 0.03);
      head.position.set(0, 2.26, -0.06);
      this.part(head, '#d4d2c0', 0, 0, 0, 0.50, 0.62, 0.50);
      this.part(head, '#969484', 0, 0.14, -0.02, 0.52, 0.09, 0.52); // Heavy brow ridge
      this.glowPart(head, '#e02828', -0.13, 0.05, -0.26, 0.09, 0.07, 0.02);
      this.glowPart(head, '#e02828', 0.13, 0.05, -0.26, 0.09, 0.07, 0.02);
      this.part(head, '#b5b3a2', 0, -0.14, -0.29, 0.13, 0.28, 0.12); // Hanging golem nose
      for (const s of [-1, 1]) {
        const leg = new THREE.Group();
        leg.position.set(s * 0.25, 0.96, 0);
        this.part(leg, '#b8b6a4', 0, -0.48, 0, 0.34, 0.96, 0.30);
        this.part(leg, '#969484', 0, -0.90, -0.02, 0.36, 0.12, 0.34);
        if (s < 0) this.part(leg, '#5d873b', 0, -0.42, -0.155, 0.18, 0.48, 0.02);
        g.add(leg);
        legs.push(leg);

        const arm = new THREE.Group();
        arm.position.set(s * 0.72, 1.88, 0);
        this.part(arm, '#c8c6b4', 0, -0.64, 0, 0.26, 1.42, 0.32);
        this.part(arm, '#a8a696', 0, -1.26, 0, 0.28, 0.18, 0.34);
        if (s < 0) this.part(arm, '#6b9644', 0, -0.45, -0.165, 0.18, 0.65, 0.02);
        g.add(arm);
        legs.push(arm);
      }
    } else if (species === 'enderman') {
      // Enderman: 2.9-block tall slender frame, spindly limbs, glowing purple eyes, and hinged screaming skull/jaw
      this.part(g, '#16141c', 0, 1.88, 0, 0.48, 0.72, 0.24);
      this.part(g, '#211d29', 0, 1.92, -0.125, 0.34, 0.52, 0.02); // Subtle rib chest shading
      head.position.set(0, 2.48, 0);
      // Lower mandible & inner purple mouth cavity
      this.part(head, '#361442', 0, -0.04, 0, 0.42, 0.34, 0.42);
      this.part(head, '#16141c', 0, -0.18, 0, 0.48, 0.12, 0.48);
      for (const tx of [-0.14, 0, 0.14]) {
        this.part(head, '#16141c', tx, -0.06, -0.22, 0.05, 0.16, 0.05); // Jawbone teeth struts
      }
      this.part(head, '#16141c', -0.21, -0.02, -0.20, 0.06, 0.24, 0.08);
      this.part(head, '#16141c', 0.21, -0.02, -0.20, 0.06, 0.24, 0.08);
      // Upper cranium lifts up when screaming/chasing
      const upperSkull = new THREE.Group();
      this.part(upperSkull, '#16141c', 0, 0.04, 0, 0.50, 0.44, 0.50);
      this.glowPart(upperSkull, '#f5b0ff', -0.14, -0.04, -0.255, 0.15, 0.065, 0.02);
      this.glowPart(upperSkull, '#f5b0ff', 0.14, -0.04, -0.255, 0.15, 0.065, 0.02);
      this.glowPart(upperSkull, '#b026ed', -0.14, -0.04, -0.26, 0.065, 0.065, 0.02);
      this.glowPart(upperSkull, '#b026ed', 0.14, -0.04, -0.26, 0.065, 0.065, 0.02);
      head.add(upperSkull);
      jaw = upperSkull;
      for (const s of [-1, 1]) {
        const leg = new THREE.Group();
        leg.position.set(s * 0.13, 1.52, 0);
        this.part(leg, '#121018', 0, -0.76, 0, 0.12, 1.52, 0.12);
        g.add(leg);
        legs.push(leg);

        const arm = new THREE.Group();
        arm.position.set(s * 0.31, 2.20, 0);
        this.part(arm, '#121018', 0, -0.75, 0, 0.12, 1.50, 0.12);
        g.add(arm);
        legs.push(arm);
      }
    } else if (species === 'warden') {
      // Warden: hunched bipedal sculk monster, bone ribcage framing glowing soul heart core, blind head with pulsing tendril ears
      this.part(g, '#10242e', 0, 1.54, 0, 0.96, 1.16, 0.62);
      this.part(g, '#071218', 0, 1.56, -0.29, 0.56, 0.70, 0.08); // Chest cavity
      core = this.glowPart(g, '#3cf0ff', 0, 1.56, -0.28, 0.38, 0.50, 0.08, 0.96); // Glowing soul heart
      // Bone ribcage arches & spine
      for (const ry of [1.32, 1.50, 1.68, 1.84]) {
        this.part(g, '#d6d0b4', -0.25, ry, -0.32, 0.26, 0.08, 0.06);
        this.part(g, '#d6d0b4', 0.25, ry, -0.32, 0.26, 0.08, 0.06);
        this.part(g, '#c2bc9e', 0, ry, 0.32, 0.18, 0.09, 0.06); // Dorsal spine plates
      }
      this.part(g, '#183844', -0.54, 1.98, 0, 0.24, 0.28, 0.44);
      this.part(g, '#183844', 0.54, 1.98, 0, 0.24, 0.28, 0.44);
      head.position.set(0, 2.40, -0.12);
      this.part(head, '#122832', 0, 0, 0, 0.86, 0.76, 0.64);
      this.part(head, '#d2ccb0', 0, 0.25, -0.28, 0.72, 0.13, 0.12); // Bone brow plate
      this.part(head, '#061116', 0, -0.10, -0.33, 0.46, 0.30, 0.04); // Blind screaming mouth
      this.part(head, '#a8b89e', 0, 0.06, -0.33, 0.50, 0.06, 0.05); // Upper teeth ridge
      this.part(head, '#a8b89e', 0, -0.24, -0.33, 0.42, 0.05, 0.05); // Lower teeth ridge
      ears = [];
      for (const s of [-1, 1]) {
        const ear = new THREE.Group();
        ear.position.set(s * 0.43, 0.18, 0);
        this.part(ear, '#18404e', s * 0.18, 0.06, 0, 0.36, 0.18, 0.10);
        this.part(ear, '#1d5263', s * 0.36, 0.22, 0, 0.24, 0.26, 0.08);
        this.glowPart(ear, '#3cf0ff', s * 0.42, 0.32, 0, 0.14, 0.14, 0.08);
        this.glowPart(ear, '#28b8c8', s * 0.22, 0.16, -0.05, 0.12, 0.08, 0.03);
        head.add(ear);
        ears.push(ear);

        const leg = new THREE.Group();
        leg.position.set(s * 0.26, 0.96, 0);
        this.part(leg, '#0e2029', 0, -0.48, 0, 0.34, 0.96, 0.34);
        this.part(leg, '#d2ccb0', 0, -0.92, -0.14, 0.28, 0.08, 0.14);
        this.glowPart(leg, '#28b8c8', 0, -0.42, -0.175, 0.12, 0.28, 0.02);
        g.add(leg);
        legs.push(leg);

        const arm = new THREE.Group();
        arm.position.set(s * 0.65, 1.96, 0);
        this.part(arm, '#122832', 0, -0.63, 0, 0.34, 1.26, 0.34);
        this.part(arm, '#d2ccb0', s * 0.14, -0.50, 0, 0.08, 0.44, 0.24);
        this.part(arm, '#d2ccb0', 0, -1.20, -0.10, 0.28, 0.10, 0.18); // Knuckle claws
        this.glowPart(arm, '#3cf0ff', 0, -0.35, -0.175, 0.15, 0.38, 0.02);
        g.add(arm);
        legs.push(arm);
      }
    } else if (species === 'cow' || species === 'pig' || species === 'sheep' || species === 'wolf' || species === 'cat' || species === 'horse') {
      const horse = species === 'horse', small = species === 'cat' || species === 'wolf';
      const body = species === 'cow' ? '#523e2e' : species === 'pig' ? '#f0a69e' : species === 'sheep' ? '#e6c5b8' : species === 'wolf' ? '#d4d6ce' : species === 'cat' ? '#d89b52' : '#8b5a36';
      const h = horse ? 0.86 : small ? 0.48 : species === 'pig' ? 0.46 : 0.76;
      if (horse) {
        // Articulated Equine Rig: body, 4 hoofed legs with white stockings, angled neck + mane, elongated head + muzzle + bridle + ears, swishing tail
        this.part(g, body, 0, h + 0.28, 0, 0.68, 0.62, 1.34);
        this.part(g, '#734829', 0, h + 0.12, 0, 0.69, 0.22, 1.28); // Subtle flank shading
        head.position.set(0, h + 0.48, -0.54);
        this.part(head, body, 0, 0.20, -0.06, 0.28, 0.58, 0.32).rotation.x = 0.38; // Angled neck
        this.part(head, '#2e1d10', 0, 0.24, 0.11, 0.10, 0.58, 0.13).rotation.x = 0.38; // Dark mane
        this.part(head, body, 0, 0.46, -0.22, 0.34, 0.26, 0.42); // Cranium
        this.part(head, '#664024', 0, 0.40, -0.50, 0.26, 0.20, 0.30); // Muzzle
        this.part(head, '#f2efe6', 0, 0.48, -0.44, 0.10, 0.08, 0.26); // White blaze stripe on nose
        this.part(head, '#3d2516', 0, 0.42, -0.38, 0.28, 0.05, 0.05); // Noseband strap
        for (const sx of [-1, 1]) {
          this.part(head, body, sx * 0.12, 0.64, -0.10, 0.08, 0.18, 0.08);
          this.part(head, '#2e1d10', sx * 0.12, 0.71, -0.10, 0.06, 0.05, 0.06); // Ear tips
        }
        eyes(0.50, -0.32, 0.17, '#1a1612', '#ffffff');
        const hTail = new THREE.Group();
        hTail.position.set(0, h + 0.48, 0.67);
        const tm = this.part(hTail, '#2e1d10', 0, -0.32, 0.08, 0.15, 0.66, 0.15);
        tm.rotation.x = 0.32;
        g.add(hTail);
        tail = hTail;
        quadLegs(body, 0.18, h, 0.18, 0.23, 0.48, '#241c15');
      } else {
        const bw = small ? 0.38 : species === 'pig' ? 0.64 : 0.74;
        const bh = small ? 0.36 : species === 'pig' ? 0.52 : 0.64;
        const bd = small ? 0.82 : species === 'pig' ? 1.02 : 1.12;
        this.part(g, body, 0, h + (species === 'pig' ? 0.14 : 0), 0, bw, bh, bd);
        head.position.set(0, h + (species === 'pig' ? 0.22 : 0.18), small ? -0.44 : species === 'pig' ? -0.54 : -0.60);
        const hw = small ? 0.36 : species === 'sheep' ? 0.40 : 0.48;
        const hh = small ? 0.34 : species === 'sheep' ? 0.40 : 0.48;
        const hd = small ? 0.36 : species === 'cow' ? 0.40 : 0.48;
        this.part(head, body, 0, 0, 0, hw, hh, hd);

        if (species === 'pig') {
          // Vanilla Pig: 4x3x1 protruding 3D snout with dark nostrils, floppy ear tabs, and curly rear tail
          this.part(head, '#f5b5ae', 0, -0.06, -0.27, 0.26, 0.19, 0.10);
          this.part(head, '#6e322c', -0.07, -0.06, -0.325, 0.05, 0.06, 0.02);
          this.part(head, '#6e322c', 0.07, -0.06, -0.325, 0.05, 0.06, 0.02);
          this.part(head, '#e08e85', -0.25, 0.08, -0.04, 0.04, 0.16, 0.14); // Ear flaps
          this.part(head, '#e08e85', 0.25, 0.08, -0.04, 0.04, 0.16, 0.14);
          this.part(g, '#e08e85', 0, h + 0.20, 0.54, 0.08, 0.12, 0.08); // Curly pig tail
          eyes(0.06, -0.245, 0.16, '#171b17', '#ffffff');
          quadLegs(body, 0.22, h, 0.22, 0.19, 0.34, '#c77a72');
        } else if (species === 'cow') {
          // Vanilla Cow: brown hide with asymmetrical white patches, white blaze, broad muzzle, 2 side horns + ear tabs, pink udder + 4 teats
          this.part(head, '#d8d2c5', 0, -0.10, -0.22, 0.34, 0.20, 0.10); // Broad cow muzzle
          this.part(head, '#423124', -0.09, -0.08, -0.275, 0.05, 0.05, 0.02); // Nostrils
          this.part(head, '#423124', 0.09, -0.08, -0.275, 0.05, 0.05, 0.02);
          this.part(head, '#f0ede4', 0, 0.10, -0.205, 0.16, 0.20, 0.02); // Forehead blaze
          // White patches wrapping torso
          this.part(g, '#ebe8de', 0.375, h + 0.08, 0.14, 0.02, 0.38, 0.46);
          this.part(g, '#ebe8de', -0.375, h - 0.06, -0.20, 0.02, 0.32, 0.38);
          this.part(g, '#ebe8de', -0.375, h + 0.12, 0.28, 0.02, 0.24, 0.28);
          this.part(g, '#ebe8de', 0, h + 0.325, -0.14, 0.48, 0.02, 0.42);
          this.part(g, '#ebe8de', 0.12, h + 0.325, 0.28, 0.36, 0.02, 0.32);
          // Pink udder & 4 teats
          this.part(g, '#ebaca6', 0, h - 0.34, 0.22, 0.28, 0.09, 0.36);
          for (const tx of [-0.08, 0.08]) for (const tz of [0.12, 0.30]) {
            this.part(g, '#d98c86', tx, h - 0.40, tz, 0.04, 0.06, 0.04);
          }
          // Horns & ears
          for (const sx of [-1, 1]) {
            this.part(head, '#3d352e', sx * 0.27, 0.20, 0.04, 0.08, 0.22, 0.08);
            this.part(head, '#523e2e', sx * 0.27, 0.04, 0.04, 0.08, 0.08, 0.06);
          }
          eyes(0.06, -0.205, 0.16, '#171b17', '#ffffff');
          quadLegs('#463527', 0.22, h, 0.22, 0.23, 0.38, '#261d15');
        } else if (species === 'sheep') {
          // Vanilla Sheep: pinkish-beige face (`#e6c5b8`), fluffy wool cap, thick fleece body coat (`#f5f3ea`) that hides the inner body, and upper wool cuffs on all 4 legs
          this.part(head, '#d4ada0', 0, -0.09, -0.25, 0.22, 0.14, 0.06);
          this.part(head, '#f5f3ea', 0, 0.04, 0.04, 0.48, 0.42, 0.44); // Head wool hood
          woolCoat = new THREE.Group();
          this.part(woolCoat, '#f5f3ea', 0, h + 0.03, 0, 0.90, 0.78, 1.20); // Full outer fleece coat
          for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
            this.part(woolCoat, '#f0ede2', sx * 0.23, h - 0.36, sz * 0.36, 0.23, 0.30, 0.23); // Upper leg wool cuffs
          }
          g.add(woolCoat);
          eyes(0.05, -0.245, 0.13, '#171b17', '#ffffff');
          quadLegs('#d9b8aa', 0.18, h, 0.18, 0.23, 0.36, '#594a42');
        } else if (species === 'cat' || species === 'wolf') {
          if (species === 'wolf') {
            // Vanilla Wolf: bushy 8x6x7 neck ruff/mane, grey-white muzzle, dark nose, red collar, and bushy tail
            this.part(g, '#b8bab0', 0, h + 0.05, -0.24, 0.52, 0.48, 0.38); // Thick wolf mane
            this.part(g, '#e6e8e0', 0, h - 0.12, 0, 0.36, 0.16, 0.78); // Lighter underbelly
            this.part(head, '#e6e8e0', 0, -0.08, -0.26, 0.22, 0.16, 0.20); // Snout
            this.part(head, '#242424', 0, -0.03, -0.365, 0.08, 0.06, 0.04); // Black nose tip
            collar = this.part(g, '#e02e24', 0, h + 0.05, -0.38, 0.44, 0.42, 0.09);
            collar.visible = false;
            eyes(0.05, -0.185, 0.11, '#1c1c1c', '#ffffff');
          } else {
            // Vanilla Cat (Ginger Tabby): stripes, white paws & chest, pink nose, emerald eyes, and two-piece kinked tail
            this.part(g, '#b57732', 0, h + 0.185, 0.05, 0.39, 0.03, 0.64); // Dorsal tabby stripe
            this.part(g, '#f5f2eb', 0, h - 0.10, -0.28, 0.28, 0.20, 0.24); // White chest patch
            this.part(head, '#f5f2eb', 0, -0.08, -0.22, 0.20, 0.13, 0.12); // Muzzle
            this.part(head, '#e88b9c', 0, -0.05, -0.285, 0.07, 0.05, 0.03); // Pink cat nose
            eyes(0.05, -0.185, 0.11, '#32a852', '#f5f2eb');
          }
          this.part(head, body, -0.13, 0.23, 0.02, 0.10, 0.15, 0.07);
          this.part(head, body, 0.13, 0.23, 0.02, 0.10, 0.15, 0.07);
          const pTail = new THREE.Group();
          pTail.position.set(0, h + 0.10, 0.42);
          this.part(pTail, body, 0, 0, 0.22, species === 'wolf' ? 0.13 : 0.08, species === 'wolf' ? 0.13 : 0.08, 0.46);
          if (species === 'cat') {
            const tip = this.part(pTail, '#f5f2eb', 0, 0.06, 0.46, 0.075, 0.075, 0.20);
            tip.rotation.x = 0.35;
          }
          g.add(pTail);
          tail = pTail;
          quadLegs(body, 0.12, h, 0.12, 0.13, 0.29, species === 'cat' ? '#f5f2eb' : '#b8bab0');
        }
      }
    } else if (species === 'chicken') {
      // Vanilla Chicken: plump white body, tail feathers, red comb on top, wide yellow bill, red wattle, 2 yellow legs with 3-toed feet, 2 flapping wings
      this.part(g, '#f5f2e6', 0, 0.48, 0, 0.42, 0.40, 0.56);
      this.part(g, '#e8e4d5', 0, 0.56, 0.30, 0.26, 0.22, 0.14); // Tail feathers
      head.position.set(0, 0.80, -0.24);
      this.part(head, '#faf7eb', 0, 0, 0, 0.28, 0.36, 0.24);
      this.part(head, '#d93829', 0, 0.22, -0.01, 0.06, 0.12, 0.20); // Red comb on crown
      this.part(head, '#e8b438', 0, -0.02, -0.19, 0.26, 0.11, 0.16); // Wide yellow bill (4x2x2 px)
      this.part(head, '#d93829', 0, -0.14, -0.15, 0.12, 0.14, 0.10); // Red wattle under chin
      eyes(0.06, -0.125, 0.10, '#171b17');
      for (const sx of [-1, 1]) {
        const leg = new THREE.Group();
        leg.position.set(sx * 0.10, 0.28, 0.02);
        this.part(leg, '#e0a438', 0, -0.14, 0, 0.055, 0.28, 0.055);
        this.part(leg, '#e0a438', 0, -0.27, -0.05, 0.14, 0.025, 0.15); // Flat webbed/3-toed foot
        g.add(leg);
        legs.push(leg);
      }
      for (const sx of [-1, 1]) {
        const wing = new THREE.Group();
        wing.position.set(sx * 0.22, 0.54, 0);
        this.part(wing, '#ebe6d5', sx * 0.04, -0.06, 0, 0.07, 0.28, 0.40);
        g.add(wing);
        legs.push(wing);
      }
    } else if (species === 'creeper') {
      // Vanilla Creeper: 8x8x8 head with iconic pixel frown, 8x12x4 torso with mottled camouflage patches, and 4 offset legs at Front/Back (no arms)
      this.part(g, '#5ea445', 0, 0.84, 0, 0.50, 0.88, 0.26);
      this.part(g, '#4c8c36', -0.12, 0.96, -0.135, 0.18, 0.22, 0.02); // Camo leaf patches
      this.part(g, '#78bd5c', 0.13, 0.68, -0.135, 0.16, 0.24, 0.02);
      head.position.set(0, 1.54, 0);
      this.part(head, '#6cb851', 0, 0, 0, 0.54, 0.54, 0.54);
      this.part(head, '#52943b', 0.14, 0.16, -0.272, 0.14, 0.10, 0.015);
      // Iconic 8x8 pixel Creeper face (2x2 eyes, 2x3 nose bridge + 4x2 frown + 1x2 side mouth drops)
      this.part(head, '#162414', -0.13, 0.07, -0.276, 0.13, 0.13, 0.02);
      this.part(head, '#162414', 0.13, 0.07, -0.276, 0.13, 0.13, 0.02);
      this.part(head, '#162414', 0, -0.05, -0.276, 0.13, 0.13, 0.02);
      this.part(head, '#162414', 0, -0.13, -0.276, 0.26, 0.11, 0.02);
      this.part(head, '#162414', -0.10, -0.20, -0.276, 0.07, 0.09, 0.02);
      this.part(head, '#162414', 0.10, -0.20, -0.276, 0.07, 0.09, 0.02);
      quadLegs('#54963d', 0.24, 0.42, 0.24, 0.15, 0.23, '#2d4f20');
    } else if (species === 'spider') {
      // Spider: dark brown-black cephalothorax, large angled abdomen with red dorsal markings, chelicerae fangs, 8 red eyes, 8 splayed 2-jointed legs
      this.part(g, '#2e2522', 0, 0.44, -0.12, 0.44, 0.38, 0.48); // Cephalothorax
      const abd = this.part(g, '#382d28', 0, 0.52, 0.46, 0.70, 0.52, 0.82); // Abdomen
      abd.rotation.x = 0.14;
      this.part(g, '#5c2822', 0, 0.78, 0.42, 0.32, 0.04, 0.48); // Reddish dorsal spider marking
      head.position.set(0, 0.46, -0.46);
      this.part(head, '#261e1b', 0, 0, 0, 0.52, 0.44, 0.46);
      this.part(head, '#1c1513', -0.10, -0.14, -0.26, 0.09, 0.14, 0.10); // Chelicerae / fangs
      this.part(head, '#1c1513', 0.10, -0.14, -0.26, 0.09, 0.14, 0.10);
      this.glowPart(head, '#ff261b', -0.15, 0.06, -0.24, 0.08, 0.07, 0.02);
      this.glowPart(head, '#ff261b', 0.15, 0.06, -0.24, 0.08, 0.07, 0.02);
      this.glowPart(head, '#ff3b30', -0.07, 0.13, -0.24, 0.055, 0.055, 0.02);
      this.glowPart(head, '#ff3b30', 0.07, 0.13, -0.24, 0.055, 0.055, 0.02);
      this.glowPart(head, '#c91e14', -0.21, 0.12, -0.23, 0.045, 0.045, 0.02);
      this.glowPart(head, '#c91e14', 0.21, 0.12, -0.23, 0.045, 0.045, 0.02);
      for (const s of [-1, 1]) for (let i = 0; i < 4; i++) {
        const pivot = new THREE.Group();
        pivot.position.set(s * 0.25, 0.45, -0.32 + i * 0.21);
        const upper = this.part(pivot, '#362c27', s * 0.24, 0.09, 0, 0.50, 0.095, 0.095);
        upper.rotation.z = s * 0.34;
        const lower = this.part(pivot, '#241d19', s * 0.58, -0.11, 0, 0.54, 0.085, 0.085);
        lower.rotation.z = -s * 0.54;
        pivot.rotation.z = s * 0.22;
        g.add(pivot);
        legs.push(pivot);
      }
    } else if (species === 'blaze') {
      // Vanilla Blaze: glowing golden-amber head with dark brow + 3 counter-rotating rings of 4 floating blaze rods (12 rods total!)
      this.glowPart(g, '#ff9824', 0, 1.02, 0, 0.34, 0.68, 0.34, 0.82);
      head.position.set(0, 1.62, 0);
      this.part(head, '#e89624', 0, 0, 0, 0.50, 0.50, 0.50);
      this.part(head, '#7a340e', 0, 0.12, -0.255, 0.42, 0.06, 0.02); // Dark smoky brow
      this.glowPart(head, '#fff6a0', -0.13, 0.04, -0.258, 0.11, 0.07, 0.02);
      this.glowPart(head, '#fff6a0', 0.13, 0.04, -0.258, 0.11, 0.07, 0.02);
      this.part(head, '#5e2408', -0.11, 0.04, -0.262, 0.05, 0.06, 0.02);
      this.part(head, '#5e2408', 0.11, 0.04, -0.262, 0.05, 0.06, 0.02);
      extras = [];
      for (let i = 0; i < 12; i++) {
        const ring = Math.floor(i / 4); // 0: upper (r=0.56, y=1.34), 1: middle (r=0.40, y=0.90), 2: lower (r=0.24, y=0.46)
        const a = (i % 4) * (Math.PI / 2) + ring * 0.4;
        const r = ring === 0 ? 0.56 : ring === 1 ? 0.40 : 0.25;
        const ry = ring === 0 ? 1.34 : ring === 1 ? 0.90 : 0.46;
        const col = ring === 0 ? '#ffd24c' : ring === 1 ? '#ffa828' : '#e07616';
        const rod = this.glowPart(g, col, Math.cos(a) * r, ry, Math.sin(a) * r, 0.11, 0.52, 0.11);
        extras.push(rod);
      }
    } else if (species === 'ghast') {
      // Vanilla Ghast: huge pale cube with grey gill/tear streaks, closed/open red eyes, and 9 dangling tentacles of varied length
      this.part(g, '#f2f2f2', 0, 1.38, 0, 1.48, 1.48, 1.48);
      for (const sx of [-1, 1]) {
        this.part(g, '#d6d6d6', sx * 0.745, 1.48, -0.22, 0.02, 0.12, 0.42); // Side gill markings
        this.part(g, '#d6d6d6', sx * 0.745, 1.28, 0.10, 0.02, 0.12, 0.42);
      }
      head.position.set(0, 1.38, -0.745);
      this.part(head, '#bcbcbc', -0.34, 0.14, 0, 0.28, 0.07, 0.02); // Heavy grey brows
      this.part(head, '#bcbcbc', 0.34, 0.14, 0, 0.28, 0.07, 0.02);
      this.part(head, '#a62424', -0.34, 0.06, -0.008, 0.22, 0.07, 0.02); // Bloodshot red eyes
      this.part(head, '#a62424', 0.34, 0.06, -0.008, 0.22, 0.07, 0.02);
      this.part(head, '#c4c4c4', -0.34, -0.16, 0, 0.09, 0.32, 0.02); // Tear tracks
      this.part(head, '#c4c4c4', 0.34, -0.16, 0, 0.09, 0.32, 0.02);
      this.part(head, '#525252', 0, -0.28, -0.008, 0.30, 0.24, 0.02); // Wailing mouth
      const tLengths = [0.76, 0.94, 0.82, 0.98, 0.72, 0.90, 0.84, 0.96, 0.78];
      for (let i = 0; i < 9; i++) {
        const gx = ((i % 3) - 1) * 0.45, gz = (Math.floor(i / 3) - 1) * 0.45;
        const t = new THREE.Group();
        t.position.set(gx, 0.66, gz);
        const tl = tLengths[i];
        this.part(t, '#dcdcdc', 0, -tl / 2, 0, 0.14, tl, 0.14);
        g.add(t);
        legs.push(t);
      }
    } else if (species === 'wither') {
      // Wither: skeletal T-shoulder beam, central spine + 3 curved rib pairs + tail, central main skull + 2 side skulls with glowing blue-white eyes
      this.part(g, '#222228', 0, 1.64, 0, 1.54, 0.22, 0.22); // T-bar shoulders
      this.part(g, '#1c1c22', 0, 1.12, 0, 0.20, 1.00, 0.20); // Central spine
      for (const ry of [1.42, 1.18, 0.94]) {
        this.part(g, '#303038', 0, ry, -0.08, 0.82, 0.10, 0.30); // Ribs
        this.part(g, '#3d3d47', -0.38, ry, -0.20, 0.10, 0.10, 0.14);
        this.part(g, '#3d3d47', 0.38, ry, -0.20, 0.10, 0.10, 0.14);
      }
      const wTail = this.part(g, '#222228', 0, 0.54, 0.14, 0.16, 0.46, 0.16);
      wTail.rotation.x = 0.45;
      head.position.set(0, 2.00, 0);
      this.part(head, '#32323a', 0, 0, 0, 0.56, 0.56, 0.56);
      this.part(head, '#1c1c22', 0, -0.14, -0.285, 0.34, 0.10, 0.02); // Grimacing skull mouth
      this.glowPart(head, '#e8f6ff', -0.15, 0.04, -0.286, 0.13, 0.09, 0.02);
      this.glowPart(head, '#e8f6ff', 0.15, 0.04, -0.286, 0.13, 0.09, 0.02);
      extras = [];
      for (const s of [-1, 1]) {
        const sh = new THREE.Group();
        sh.position.set(s * 0.66, 1.84, 0);
        this.part(sh, '#2c2c34', 0, 0, 0, 0.42, 0.42, 0.42);
        this.part(sh, '#1c1c22', 0, -0.10, -0.215, 0.24, 0.07, 0.02);
        this.glowPart(sh, '#d8f0ff', -0.10, 0.03, -0.216, 0.09, 0.07, 0.02);
        this.glowPart(sh, '#d8f0ff', 0.10, 0.03, -0.216, 0.09, 0.07, 0.02);
        g.add(sh);
        extras.push(sh);
      }
    } else if (species === 'slime' || species === 'magma_cube') {
      if (species === 'slime') {
        // Vanilla Slime: translucent outer green gel cube (`#72c848` opacity 0.62) + solid inner dark green nucleus + eyes & mouth
        this.glowPart(g, '#76d14b', 0, 0.42, 0, 0.84, 0.84, 0.84, 0.58);
        this.part(g, '#4b8f29', 0, 0.40, 0.02, 0.52, 0.52, 0.52); // Inner nucleus
        head.position.set(0, 0.42, -0.425);
        this.part(head, '#1d3b12', -0.16, 0.09, 0, 0.12, 0.12, 0.04); // Right eye
        this.part(head, '#1d3b12', 0.16, 0.09, 0, 0.12, 0.12, 0.04);  // Left eye
        this.part(head, '#1d3b12', 0.04, -0.12, 0, 0.08, 0.08, 0.04); // Offset 1x1 slime mouth
      } else {
        // Vanilla Magma Cube: 8 horizontal dark crust slices around a glowing molten yellow-orange core + glowing eyes
        this.glowPart(g, '#ff7b1c', 0, 0.42, 0, 0.78, 0.78, 0.78); // Molten inner magma glow
        this.glowPart(g, '#ffd84a', 0, 0.42, 0, 0.50, 0.50, 0.50); // Bright yellow-orange core
        for (let i = 0; i < 8; i++) {
          const sy = 0.055 + i * 0.104;
          const col = i % 2 === 0 ? '#33140c' : '#471d12';
          this.part(g, col, 0, sy, 0, 0.84, 0.076, 0.84);
        }
        head.position.set(0, 0.42, -0.432);
        this.glowPart(head, '#fff068', -0.16, 0.09, 0, 0.13, 0.09, 0.03);
        this.glowPart(head, '#ff9824', -0.16, 0.09, -0.005, 0.06, 0.06, 0.03);
        this.glowPart(head, '#fff068', 0.16, 0.09, 0, 0.13, 0.09, 0.03);
        this.glowPart(head, '#ff9824', 0.16, 0.09, -0.005, 0.06, 0.06, 0.03);
      }
    } else if (species === 'bee') {
      // Vanilla Bee: 7x7x10 fuzzy yellow-and-brown striped cube, wraparound compound eyes, L-shaped antennae, stinger, 6 tiny hanging legs, translucent wings
      this.part(g, '#f2c629', 0, 0.36, 0, 0.46, 0.46, 0.64);
      this.part(g, '#2e2016', 0, 0.36, -0.02, 0.47, 0.47, 0.10);
      this.part(g, '#2e2016', 0, 0.36, 0.14, 0.47, 0.47, 0.10);
      this.part(g, '#2e2016', 0, 0.36, 0.27, 0.465, 0.465, 0.11);
      this.part(g, '#1e1610', 0, 0.34, 0.37, 0.05, 0.05, 0.12); // Stinger
      for (const lz of [-0.10, 0.04, 0.18]) for (const sx of [-1, 1]) {
        this.part(g, '#2e2016', sx * 0.14, 0.10, lz, 0.045, 0.10, 0.045); // 6 hanging bee legs
      }
      head.position.set(0, 0.36, -0.32);
      // Large dark wrap-around bee eyes with cyan highlight
      for (const sx of [-1, 1]) {
        this.part(head, '#181c24', sx * 0.16, -0.02, 0.04, 0.15, 0.22, 0.14);
        this.part(head, '#6be0f5', sx * 0.17, 0.05, -0.02, 0.05, 0.05, 0.03);
        this.part(head, '#241a12', sx * 0.11, 0.14, -0.08, 0.04, 0.12, 0.14); // Antennae
      }
      for (const sx of [-1, 1]) {
        const wing = new THREE.Group();
        wing.position.set(sx * 0.16, 0.60, -0.04);
        this.glowPart(wing, '#e8f6ff', sx * 0.15, 0, 0.04, 0.30, 0.02, 0.36, 0.72);
        g.add(wing);
        legs.push(wing);
      }
    } else if (species === 'fox' || species === 'rabbit') {
      if (species === 'fox') {
        // Vanilla Fox: low orange body, white chest/belly, wide head with white cheek tufts, pointed snout + black nose, black-tipped ears, dark paws, big white-tipped tail
        const col = '#de7426';
        this.part(g, col, 0, 0.35, 0, 0.38, 0.34, 0.66);
        this.part(g, '#f5f2eb', 0, 0.26, -0.08, 0.30, 0.18, 0.50); // White chest/belly
        head.position.set(0, 0.48, -0.36);
        this.part(head, col, 0, 0, 0, 0.46, 0.34, 0.36); // Wide 8x6x6 fox head
        this.part(head, '#f5f2eb', 0, -0.10, -0.01, 0.47, 0.13, 0.34); // White cheek fur
        this.part(head, col, 0, -0.06, -0.26, 0.22, 0.13, 0.22); // Snout
        this.part(head, '#f5f2eb', 0, -0.11, -0.25, 0.20, 0.05, 0.20); // White under-jaw
        this.part(head, '#1e1916', 0, -0.02, -0.37, 0.08, 0.06, 0.04); // Black nose tip
        for (const sx of [-1, 1]) {
          this.part(head, col, sx * 0.16, 0.23, 0.02, 0.12, 0.16, 0.06);
          this.part(head, '#241d18', sx * 0.16, 0.30, 0.02, 0.10, 0.06, 0.05); // Black ear tips
        }
        eyes(0.01, -0.185, 0.15, '#1c1c1c', '#ffffff');
        const fTail = new THREE.Group();
        fTail.position.set(0, 0.36, 0.33);
        this.part(fTail, col, 0, 0, 0.22, 0.24, 0.24, 0.44);
        this.part(fTail, '#f5f2eb', 0, 0, 0.49, 0.22, 0.22, 0.18); // Fluffy white tail tip
        g.add(fTail);
        tail = fTail;
        quadLegs('#241d18', 0.10, 0.25, 0.10, 0.12, 0.22);
      } else {
        // Vanilla Rabbit: forward-slanted body, long upright ears with pink inner channel, pink nose, cotton tail, hind haunches + front legs
        const col = '#c9bca8';
        const rBody = this.part(g, col, 0, 0.34, 0, 0.36, 0.32, 0.56);
        rBody.rotation.x = -0.26; // Classic rabbit forward-angled torso
        this.part(g, '#ede8df', 0, 0.24, -0.04, 0.28, 0.16, 0.44).rotation.x = -0.26;
        head.position.set(0, 0.52, -0.28);
        this.part(head, col, 0, 0, 0, 0.34, 0.30, 0.34);
        this.part(head, '#e89ba8', 0, -0.02, -0.175, 0.07, 0.06, 0.03); // Pink twitching nose
        for (const sx of [-1, 1]) {
          const ear = this.part(head, col, sx * 0.08, 0.29, 0.05, 0.10, 0.34, 0.05);
          ear.rotation.z = -sx * 0.08;
          this.part(head, '#dfa4ad', sx * 0.08, 0.28, 0.022, 0.05, 0.24, 0.02); // Inner pink ear
        }
        eyes(0.04, -0.172, 0.11, '#261e1a', '#ffffff');
        this.part(g, '#f7f5ef', 0, 0.36, 0.30, 0.15, 0.15, 0.14); // Fluffy cotton tail
        quadLegs(col, 0.10, 0.25, 0.12, 0.12, 0.19, '#ede8df');
      }
    } else if (species === 'squid' || species === 'turtle') {
      if (species === 'squid') {
        // Vanilla Squid: tall dark-blue mantle with top fin crown, large side-facing eyes, 8 long radially arranged tentacles
        const col = '#32486b';
        this.part(g, col, 0, 0.48, 0, 0.50, 0.68, 0.50);
        this.part(g, '#3f5982', 0, 0.84, 0, 0.54, 0.08, 0.54); // Mantle crown rim
        head.position.set(0, 0.36, -0.25);
        eyes(0.04, -0.01, 0.17, '#141c29', '#e8eef5');
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * Math.PI * 2;
          const t = new THREE.Group();
          t.position.set(Math.cos(a) * 0.20, 0.16, Math.sin(a) * 0.20);
          this.part(t, '#3d567d', 0, -0.28, 0, 0.085, 0.56, 0.085);
          g.add(t);
          legs.push(t);
        }
      } else {
        // Vanilla Sea Turtle: domed green scute carapace with patterned ridge, cream plastron belly, 4 flat wide flippers
        this.part(g, '#3d7d39', 0, 0.36, 0, 0.74, 0.26, 0.82); // Carapace shell
        this.part(g, '#4f9949', 0, 0.48, 0.02, 0.58, 0.08, 0.64); // Upper scute dome
        this.part(g, '#e0d0a0', 0, 0.22, 0, 0.66, 0.08, 0.74); // Cream plastron belly
        head.position.set(0, 0.34, -0.48);
        this.part(head, '#5ca154', 0, 0, 0, 0.32, 0.26, 0.32);
        eyes(0.03, -0.165, 0.12, '#162416', '#ffffff');
        quadLegs('#5ca154', 0.28, 0.14, 0.14, 0.38, 0.26);
      }
    } else if (species === 'fish' || species === 'dolphin') {
      if (species === 'fish') {
        // Vanilla Cod: olive-tan laterally compressed body, dorsal & anal fins, pectoral fins, forked caudal fin
        const col = '#b8946e';
        this.part(g, col, 0, 0.35, 0, 0.18, 0.28, 0.62);
        this.part(g, '#967654', 0, 0.46, 0, 0.185, 0.08, 0.58); // Darker dorsal back
        this.part(g, '#8a6b4a', 0, 0.54, 0.04, 0.04, 0.14, 0.28); // Dorsal fin
        this.part(g, '#8a6b4a', -0.11, 0.30, -0.10, 0.08, 0.08, 0.14); // Pectoral fins
        this.part(g, '#8a6b4a', 0.11, 0.30, -0.10, 0.08, 0.08, 0.14);
        head.position.set(0, 0.35, -0.34);
        this.part(head, '#a6835e', 0, 0, 0, 0.17, 0.24, 0.18);
        for (const sx of [-1, 1]) {
          this.part(head, '#ffffff', sx * 0.088, 0.03, -0.02, 0.015, 0.07, 0.07);
          this.part(head, '#141414', sx * 0.092, 0.03, -0.03, 0.015, 0.05, 0.05);
        }
        const fTail = new THREE.Group();
        fTail.position.set(0, 0.35, 0.31);
        this.part(fTail, '#8a6b4a', 0, 0, 0.14, 0.04, 0.28, 0.22);
        g.add(fTail);
        tail = fTail;
      } else {
        // Vanilla Dolphin: sleek blue-grey body with pale belly, bottle snout, curved dorsal fin, pectoral flippers, horizontal tail flukes
        const col = '#8aa6b8';
        this.part(g, col, 0, 0.36, 0, 0.46, 0.38, 0.98);
        this.part(g, '#dce6ed', 0, 0.22, 0, 0.42, 0.12, 0.92); // Pale belly
        this.part(g, '#7490a3', 0, 0.60, 0.06, 0.08, 0.24, 0.28).rotation.x = -0.28; // Dorsal fin
        for (const sx of [-1, 1]) {
          const fin = this.part(g, '#7490a3', sx * 0.28, 0.24, -0.18, 0.22, 0.06, 0.20);
          fin.rotation.z = -sx * 0.32;
        }
        head.position.set(0, 0.36, -0.54);
        this.part(head, col, 0, 0, 0, 0.38, 0.32, 0.30);
        this.part(head, col, 0, -0.08, -0.22, 0.18, 0.12, 0.22); // Bottle nose rostrum
        eyes(0.03, -0.10, 0.18, '#141c24');
        const fTail = new THREE.Group();
        fTail.position.set(0, 0.34, 0.49);
        this.part(fTail, col, 0, 0, 0.14, 0.24, 0.16, 0.28);
        this.part(fTail, '#7490a3', 0, 0, 0.34, 0.56, 0.06, 0.22); // Horizontal tail flukes
        g.add(fTail);
        tail = fTail;
      }
    } else if (NEW_SPECIES[species] && NEW_SPECIES[species].plan !== 'biped') {
      const planOut = this.buildPlan(species, g, head, legs, eyes, quadLegs);
      if (planOut.tail) tail = planOut.tail;
      if (planOut.extras) extras = planOut.extras;
      if (planOut.jaw) jaw = planOut.jaw;
      if (planOut.ears) ears = planOut.ears;
    } else {
      // Humanoids, Villagers, Illagers, Zombies, Skeletons, Piglins, Snow Golem
      const info = NEW_SPECIES[species];
      const sk = species === 'skeleton' || species === 'stray' || species === 'bogged' || species === 'wither_skeleton';
      const v = species === 'villager' || species === 'wandering_trader';
      const illager = species === 'pillager' || species === 'vindicator' || species === 'evoker' || species === 'witch';
      const crossedArms = v || species === 'witch' || species === 'evoker';
      const z = species === 'zombie' || species === 'husk' || species === 'drowned' || species === 'zombified_piglin' || species === 'zombie_villager';
      const skin = info ? info.skin : sk ? '#d8d7c8' : v ? '#bd926e' : species === 'witch' ? '#a89a82' : illager ? '#8e9694' : '#638f49';
      const shirt = info ? info.shirt : sk ? '#c9c9bb' : v ? '#8b6343' : species === 'witch' ? '#4e2f66' : species === 'pillager' ? '#4d3b31' : '#32969c';
      const pants = info ? info.pants : sk ? '#d0d0c2' : v ? '#5c4230' : species === 'witch' ? '#2e5936' : '#43477d';
      const scale = info ? info.scale : 1;

      g.scale.setScalar(scale);

      // Torso (skeletons have hollow ribcage & spine; villagers/illagers have long robes; zombies/husks/drowned have layered shirts)
      if (sk) {
        const bone = species === 'wither_skeleton' ? '#3d3b42' : species === 'bogged' ? '#96a882' : '#dedcd0';
        const darkBone = species === 'wither_skeleton' ? '#1c1c20' : '#b8b6a8';
        this.part(g, bone, 0, 1.34, 0, 0.50, 0.14, 0.24); // Clavicle / top rib bar
        this.part(g, darkBone, 0, 1.04, 0.06, 0.12, 0.56, 0.10); // Vertebral spine
        for (const ry of [1.20, 1.06, 0.92]) {
          this.part(g, bone, 0, ry, -0.02, 0.48, 0.07, 0.22); // 3 rib pairs
        }
        this.part(g, bone, 0, 0.76, 0, 0.48, 0.12, 0.24); // Pelvis
        if (species === 'stray') {
          this.part(g, '#6a828f', 0, 1.34, 0, 0.55, 0.16, 0.30); // Frost shoulder mantle
          this.part(g, '#546873', -0.18, 0.96, 0, 0.18, 0.56, 0.28); // Open tattered coat sides (shows ribs in center!)
          this.part(g, '#546873', 0.18, 0.96, 0, 0.18, 0.56, 0.28);
          this.part(g, '#546873', 0, 1.02, 0.13, 0.52, 0.64, 0.04); // Coat back
        } else if (species === 'bogged') {
          this.part(g, '#4e633b', -0.17, 1.04, 0, 0.18, 0.52, 0.27); // Mossy vine drapes leaving center ribs visible
          this.part(g, '#4e633b', 0.17, 1.10, 0, 0.18, 0.44, 0.27);
        }
      } else if (species === 'snow_golem') {
        // Snow Golem: 2 stacked snow blocks (bottom 12x12x12, middle 10x10x10) with coal buttons
        this.part(g, '#f2f7fa', 0, 0.38, 0, 0.74, 0.74, 0.74);
        this.part(g, '#f7fbff', 0, 1.04, 0, 0.60, 0.60, 0.60);
        for (const by of [0.88, 1.04, 1.20]) {
          this.part(g, '#222428', 0, by, -0.305, 0.065, 0.065, 0.02); // Coal buttons
        }
      } else {
        this.part(g, shirt, 0, 1.05, 0, 0.50, 0.72, 0.26);
        if (species === 'zombie') {
          this.part(g, '#297a80', 0, 1.32, -0.132, 0.28, 0.16, 0.02); // V-neck collar shading
        } else if (species === 'drowned') {
          // Drowned: teal-brown seaweed & prismarine chest encrustation
          this.part(g, '#3a665e', -0.12, 1.12, -0.135, 0.22, 0.48, 0.025);
          this.part(g, '#8a6b48', 0.12, 0.96, -0.135, 0.20, 0.36, 0.025);
        } else if (species === 'husk') {
          // Husk: tattered desert tunic hem & head cloth wrap
          this.part(g, '#6e5c3b', 0, 0.72, 0, 0.52, 0.16, 0.28);
        } else if (species === 'zombified_piglin') {
          // Zombified Piglin: exposed green-rotted ribcage on right side + gold belt loincloth
          this.part(g, '#5d8242', -0.12, 1.10, -0.134, 0.22, 0.44, 0.02);
          this.part(g, '#dedad0', -0.12, 1.16, -0.138, 0.18, 0.05, 0.02);
          this.part(g, '#dedad0', -0.12, 1.04, -0.138, 0.18, 0.05, 0.02);
        } else if (species === 'piglin') {
          // Piglin: dark brown leather doublet with golden belt & shoulder strap
          this.part(g, '#4f3524', 0, 1.05, 0, 0.52, 0.70, 0.28);
          this.part(g, '#f0c43e', 0, 0.76, 0, 0.53, 0.08, 0.29); // Gold belt
        } else if (species === 'piglin_brute') {
          this.part(g, '#2b1f1b', 0, 1.05, 0, 0.53, 0.72, 0.28);
          this.part(g, '#f0c43e', 0, 0.78, 0, 0.54, 0.10, 0.30);
          this.part(g, '#f0c43e', 0, 0.78, -0.155, 0.16, 0.14, 0.03); // Gold buckle
        }
        if (v || illager || species === 'zombie_villager') {
          // Long villager/illager robe coat extending over upper legs
          this.part(g, shirt, 0, 0.62, 0, 0.53, 0.44, 0.32);
          this.part(g, '#3d2d20', 0, 0.84, 0, 0.54, 0.07, 0.33); // Waist belt
          if (species === 'pillager') {
            this.part(g, '#2b221c', 0, 1.06, -0.145, 0.16, 0.48, 0.03); // Dark front tunic placket
            this.part(g, '#b8bdc2', 0, 0.84, -0.17, 0.12, 0.10, 0.03);  // Iron belt buckle
          } else if (species === 'vindicator') {
            this.part(g, '#1f2629', 0, 1.06, -0.145, 0.18, 0.52, 0.025); // Dark vest lapel
            this.part(g, '#5cb8a8', 0, 0.84, -0.17, 0.10, 0.10, 0.03);
          }
        }
      }

      head.position.set(0, species === 'snow_golem' ? 1.56 : 1.65, 0);
      const tallHead = v || illager || species === 'zombie_villager';
      if (species !== 'snow_golem') {
        this.part(head, species === 'wither_skeleton' ? '#3d3b42' : skin, 0, tallHead ? 0.05 : 0, 0, 0.50, tallHead ? 0.60 : 0.50, 0.50);
      }

      // Authentic facial features per humanoid species
      if (species === 'zombie' || species === 'husk') {
        this.part(head, species === 'husk' ? '#594a30' : '#3d5c2e', 0, 0.21, 0, 0.51, 0.09, 0.51); // Hair / brow cap
        if (species === 'husk') this.part(head, '#8a7648', 0, 0.14, 0, 0.52, 0.18, 0.52); // Desert head wrap
        eyes(0.02, -0.255, 0.13, '#141a12');
        this.part(head, '#294020', 0, -0.05, -0.255, 0.08, 0.06, 0.02); // Nose shadow
        this.part(head, '#1e2e18', 0, -0.14, -0.255, 0.22, 0.06, 0.02); // Zombie mouth
      } else if (species === 'drowned') {
        this.part(head, '#365e54', 0, 0.20, 0, 0.52, 0.12, 0.52); // Kelp crown
        this.glowPart(head, '#6ef2e8', -0.13, 0.02, -0.256, 0.11, 0.07, 0.02); // Glowing cyan drowned eyes
        this.glowPart(head, '#6ef2e8', 0.13, 0.02, -0.256, 0.11, 0.07, 0.02);
        this.glowPart(head, '#6ef2e8', 0, -0.13, -0.256, 0.16, 0.06, 0.02); // Glowing mouth
      } else if (sk) {
        // Skeleton / Stray / Bogged / Wither Skeleton skull face with dark eye sockets, nasal cavity & teeth row
        const socketCol = species === 'stray' ? '#d8f4ff' : '#18181b';
        this.part(head, '#18181b', -0.13, 0.03, -0.255, 0.13, 0.10, 0.02);
        this.part(head, '#18181b', 0.13, 0.03, -0.255, 0.13, 0.10, 0.02);
        if (species === 'stray') {
          this.glowPart(head, socketCol, -0.13, 0.03, -0.258, 0.07, 0.05, 0.02);
          this.glowPart(head, socketCol, 0.13, 0.03, -0.258, 0.07, 0.05, 0.02);
        }
        this.part(head, '#18181b', 0, -0.05, -0.255, 0.07, 0.07, 0.02); // Nasal cavity
        this.part(head, '#18181b', 0, -0.15, -0.255, 0.30, 0.06, 0.02); // Skull teeth line
        if (species === 'bogged') {
          this.part(head, '#526b38', 0, 0.16, 0, 0.52, 0.20, 0.52); // Mossy skull cap
          // Red & brown mushrooms sprouting on Bogged head
          this.part(head, '#ded8c8', -0.14, 0.28, -0.04, 0.06, 0.10, 0.06);
          this.part(head, '#c9382b', -0.14, 0.35, -0.04, 0.18, 0.08, 0.18);
          this.part(head, '#ded8c8', 0.15, 0.27, 0.08, 0.06, 0.08, 0.06);
          this.part(head, '#8a623e', 0.15, 0.33, 0.08, 0.16, 0.06, 0.16);
        }
      } else if (species === 'piglin' || species === 'piglin_brute' || species === 'zombified_piglin') {
        // Piglin / Brute / Zombified Piglin: 4x3x1 protruding snout, upward ivory tusks, floppy ears, white/zombie eyes
        const snoutCol = species === 'zombified_piglin' ? '#b88272' : '#f2b6a4';
        this.part(head, snoutCol, 0, -0.09, -0.29, 0.26, 0.16, 0.10); // Protruding pig snout
        this.part(head, '#5e3228', -0.07, -0.09, -0.345, 0.045, 0.06, 0.02); // Nostrils
        this.part(head, '#5e3228', 0.07, -0.09, -0.345, 0.045, 0.06, 0.02);
        this.part(head, '#faf4dc', -0.16, -0.10, -0.29, 0.055, 0.14, 0.055); // Ivory tusks flanking snout
        this.part(head, '#faf4dc', 0.16, -0.10, -0.29, 0.055, 0.14, 0.055);
        if (species === 'zombified_piglin') {
          this.part(head, '#5d8242', -0.13, 0.08, -0.255, 0.22, 0.24, 0.02); // Green zombie half-skull patch
          this.part(head, '#dedad0', -0.13, 0.16, -0.258, 0.18, 0.10, 0.02); // Exposed skull bone
        }
        eyes(0.04, -0.255, 0.14, species === 'zombified_piglin' ? '#241414' : '#ffffff', '#1c1412');
        ears = [];
        for (const s of [-1, 1]) {
          const ear = new THREE.Group();
          ear.position.set(s * 0.25, 0.12, 0);
          const ep = this.part(ear, s === -1 && species === 'zombified_piglin' ? '#5d8242' : skin, s * 0.05, -0.14, 0, 0.07, 0.30, 0.24);
          ep.rotation.z = -s * 0.18;
          head.add(ear);
          ears.push(ear);
        }
        if (species === 'piglin_brute') {
          this.part(g, '#f0c43e', -0.35, 1.24, 0, 0.22, 0.22, 0.30); // Gold pauldron on left arm
          this.part(head, '#8a5244', -0.13, 0.04, -0.26, 0.04, 0.18, 0.02); // Facial battle scar
        }
      } else if (species === 'snow_golem') {
        // Snow Golem: inner snow head with coal eyes/pebble grin + outer removable carved pumpkin helmet
        this.part(head, '#f5faff', 0, -0.02, 0, 0.44, 0.44, 0.44);
        this.part(head, '#1c1e22', -0.10, 0.04, -0.225, 0.06, 0.06, 0.02);
        this.part(head, '#1c1e22', 0.10, 0.04, -0.225, 0.06, 0.06, 0.02);
        const pumpkin = new THREE.Group();
        this.part(pumpkin, '#de7a22', 0, 0.02, 0, 0.58, 0.58, 0.58);
        this.part(pumpkin, '#c46616', 0, 0.02, -0.292, 0.38, 0.56, 0.015);
        this.part(pumpkin, '#4f6e2c', 0, 0.34, 0, 0.10, 0.08, 0.10); // Pumpkin stem
        this.part(pumpkin, '#2e1a06', -0.14, 0.07, -0.296, 0.12, 0.11, 0.02); // Carved jack-o-lantern eyes
        this.part(pumpkin, '#2e1a06', 0.14, 0.07, -0.296, 0.12, 0.11, 0.02);
        this.part(pumpkin, '#2e1a06', 0, -0.12, -0.296, 0.32, 0.09, 0.02); // Carved grin
        head.add(pumpkin);
        lid = pumpkin;
      } else {
        eyes(0.05, -0.255, 0.13, v ? '#2b9442' : species === 'zombie_villager' ? '#c92b2b' : illager ? '#24586b' : '#202820', '#f5f3eb');
      }

      if (tallHead) {
        // Prominent villager/illager monobrow and 3D hanging nose (2x4x2 px)
        const browCol = species === 'zombie_villager' ? '#2d4724' : illager ? '#363b3d' : '#593e29';
        this.part(head, browCol, 0, 0.14, -0.02, 0.52, 0.08, 0.52);
        this.part(head, skin, 0, -0.08, -0.31, 0.13, 0.26, 0.14);
      }
      if (species === 'witch') {
        // Crooked 4-tier conical witch hat & nose wart
        this.part(head, '#7a5848', 0.04, -0.14, -0.38, 0.055, 0.055, 0.055); // Wart on nose
        this.part(head, '#26202e', 0, 0.34, 0, 0.84, 0.06, 0.84); // Wide hat brim
        this.part(head, '#6e4294', 0, 0.40, 0, 0.54, 0.09, 0.54); // Purple hatband
        this.part(head, '#e0e4e6', 0, 0.40, -0.28, 0.14, 0.09, 0.03); // Silver buckle
        this.part(head, '#2e2738', 0, 0.50, 0, 0.48, 0.22, 0.48);
        const midCone = this.part(head, '#26202e', -0.04, 0.68, 0.03, 0.34, 0.22, 0.34);
        midCone.rotation.z = 0.15; midCone.rotation.x = -0.12;
        const tipCone = this.part(head, '#325838', -0.10, 0.84, 0.08, 0.18, 0.18, 0.18);
        tipCone.rotation.z = 0.28; tipCone.rotation.x = -0.22;
      }
      if (species === 'evoker') {
        this.part(g, '#e8be3e', -0.16, 0.94, -0.165, 0.08, 0.88, 0.025); // Gold robe trim
        this.part(g, '#e8be3e', 0.16, 0.94, -0.165, 0.08, 0.88, 0.025);
        this.part(g, '#e8be3e', 0, 1.36, -0.165, 0.40, 0.07, 0.025); // Gold collar trim
      }
      if (species === 'wandering_trader') {
        this.part(head, '#213a80', 0, 0.08, 0.01, 0.54, 0.64, 0.54); // Blue hood
        this.part(head, '#f0c43e', 0, 0.38, -0.26, 0.55, 0.07, 0.07); // Gold hood trim
        this.part(g, '#213a80', 0, 0.96, 0, 0.55, 0.88, 0.34);
        this.part(g, '#c9342b', 0, 1.18, -0.175, 0.38, 0.38, 0.025); // Red carpet mantle
        this.part(g, '#f0c43e', 0, 0.96, -0.178, 0.42, 0.06, 0.025);
      }

      outfit = new THREE.Group();
      g.add(outfit);

      for (const s of [-1, 1]) {
        const leg = new THREE.Group();
        leg.position.set(s * 0.13, 0.72, 0);
        if (species !== 'snow_golem') {
          this.part(leg, pants, 0, -0.36, 0, sk ? 0.12 : 0.22, 0.72, sk ? 0.12 : 0.22);
          if (!sk && !v && !illager) {
            this.part(leg, '#2e2b29', 0, -0.66, -0.01, 0.23, 0.12, 0.24); // Boots cuff
          }
        }
        g.add(leg);
        legs.push(leg);

        const arm = new THREE.Group();
        if (crossedArms) {
          // Villager / Wandering Trader / Witch / Evoker crossed-arms rig
          arm.position.set(s * 0.28, 1.34, -0.04);
          this.part(arm, shirt, 0, -0.20, 0, 0.20, 0.44, 0.20);
          if (s === -1) {
            // Connected horizontal crossed-forearm bar spanning across the chest
            this.part(arm, shirt, 0.28, -0.36, -0.02, 0.76, 0.20, 0.22);
            this.part(arm, skin, 0.28, -0.36, -0.03, 0.24, 0.16, 0.23);
          }
          arm.rotation.x = -0.75;
        } else {
          arm.position.set(s * (species === 'snow_golem' ? 0.34 : 0.36), species === 'snow_golem' ? 1.22 : 1.36, 0);
          const armCol = species === 'snow_golem' ? '#755332' : sk || z || species === 'piglin' || species === 'zombified_piglin' ? skin : shirt;
          const armW = species === 'snow_golem' ? 0.075 : sk ? 0.11 : 0.19;
          const armMesh = this.part(arm, armCol, 0, -0.32, 0, armW, 0.66, armW);
          if (species === 'snow_golem') {
            armMesh.rotation.z = s * 0.48;
            this.part(arm, '#755332', s * 0.16, -0.42, 0.06, 0.05, 0.22, 0.05).rotation.z = s * 0.85; // Twig branch offshoot
          } else if (!sk) {
            this.part(arm, skin, 0, -0.52, 0, 0.18, 0.24, 0.18);
          }
          if (z) arm.rotation.x = -1.25;
          else if (species === 'pillager') {
            arm.rotation.x = -0.85;
            arm.rotation.y = -s * 0.25;
            if (s === 1) {
              // 3D Crossbow held in hands
              this.part(arm, '#6b4a2c', -0.18, -0.56, -0.16, 0.10, 0.10, 0.48);
              this.part(arm, '#8a6640', -0.18, -0.56, -0.36, 0.54, 0.06, 0.08);
              this.part(arm, '#dcd8c8', -0.18, -0.56, -0.18, 0.50, 0.03, 0.03);
              this.part(arm, '#9ea6ab', -0.18, -0.53, -0.24, 0.04, 0.04, 0.32); // Loaded arrow shaft
            }
          } else if (species === 'vindicator' && s === 1) {
            // 3D Iron Battleaxe in right hand
            this.part(arm, '#7a5838', 0, -0.56, -0.22, 0.06, 0.10, 0.58);
            this.part(arm, '#c8d0d4', 0, -0.56, -0.44, 0.04, 0.34, 0.24);
            this.part(arm, '#eef4f6', 0, -0.56, -0.52, 0.05, 0.28, 0.06);
          } else if (species === 'drowned' && s === 1) {
            // 3D Prismarine Trident held in right hand
            this.part(arm, '#427d70', 0, -0.54, -0.26, 0.055, 0.92, 0.055).rotation.x = 0.78;
            this.part(arm, '#96f0e2', 0, -0.82, -0.52, 0.22, 0.06, 0.06).rotation.x = 0.78;
            for (const px of [-0.08, 0, 0.08]) {
              this.part(arm, '#b8fff5', px, -0.92, -0.62, 0.035, 0.18, 0.035).rotation.x = 0.78;
            }
          } else if (species === 'wither_skeleton' && s === 1) {
            this.part(arm, '#5c5e63', 0, -0.58, -0.28, 0.06, 0.74, 0.13).rotation.x = 0.85;
            this.part(arm, '#3e4044', 0, -0.42, -0.14, 0.08, 0.06, 0.24).rotation.x = 0.85; // Sword crossguard
          } else if (species === 'piglin_brute' && s === 1) {
            // Golden Battleaxe for Piglin Brute
            this.part(arm, '#7a5838', 0, -0.56, -0.22, 0.06, 0.10, 0.58);
            this.part(arm, '#f2c640', 0, -0.56, -0.44, 0.05, 0.36, 0.24);
            this.part(arm, '#fff09e', 0, -0.56, -0.52, 0.055, 0.28, 0.06);
          } else if ((species === 'piglin' || species === 'zombified_piglin') && s === 1) {
            // Golden Sword
            this.part(arm, '#f2c640', 0, -0.56, -0.24, 0.06, 0.60, 0.14).rotation.x = 0.85;
            this.part(arm, '#b8861e', 0, -0.42, -0.12, 0.08, 0.06, 0.22).rotation.x = 0.85;
          } else if (sk && s === 1) {
            // 3D Bow held in right hand
            this.part(arm, '#7d5a34', 0, -0.56, -0.18, 0.06, 0.56, 0.10);
            this.part(arm, '#dcd8c8', 0, -0.56, -0.12, 0.03, 0.54, 0.03);
          }
        }
        g.add(arm);
        legs.push(arm);
      }
    }

    const biped = species === 'zombie' || species === 'skeleton' || species === 'villager' || species === 'enderman' || species === 'iron_golem' || species === 'pillager' || species === 'witch' || species === 'warden' || NEW_SPECIES[species]?.plan === 'biped';
    const plan = NEW_SPECIES[species]?.plan;
    let saddle: THREE.Object3D | undefined;
    if (SADDLEABLE.has(species)) {
      const r = RIDE[species];
      const sg = new THREE.Group();
      const sy = (r?.seat ?? 1) - 0.18;
      this.part(sg, '#8c4f32', 0, sy, 0, species === 'pig' ? 0.52 : 0.64, 0.10, species === 'pig' ? 0.52 : 0.62);
      this.part(sg, '#6b3820', 0, sy + 0.07, -0.22, 0.34, 0.08, 0.12); // Pommel
      this.part(sg, '#6b3820', 0, sy + 0.08, 0.24, 0.42, 0.10, 0.12); // Cantle
      for (const sx of [-1, 1]) {
        this.part(sg, '#5e341e', sx * 0.34, sy - 0.18, 0, 0.04, 0.32, 0.08); // Stirrup strap
        this.part(sg, '#9da5a8', sx * 0.35, sy - 0.36, 0, 0.05, 0.08, 0.12); // Iron stirrup
      }
      sg.visible = false;
      g.add(sg);
      saddle = sg;
    }
    const limbs: Limb[] = legs.map((node, i) => {
      const baseX = node.rotation.x, baseY = node.rotation.y, baseZ = node.rotation.z;
      const make = (kind: LimbKind, phase: number, amp: number): Limb => ({ node, kind, phase, amp, baseX, baseY, baseZ });
      if (species === 'spider') return make('spider', (i < 4 ? [0, Math.PI, 0, Math.PI] : [Math.PI, 0, Math.PI, 0])[i % 4], 0.26);
      if (species === 'dragon') return make('wing', Math.PI * (i % 2), 0.45);
      if (species === 'chicken' || species === 'parrot') return i < 2 ? make('leg', Math.PI * i, 0.55) : make('wing', Math.PI * (i - 2), 0.4);
      if (species === 'bee') return make('wing', Math.PI * i, 0.5);
      if (species === 'squid' || species === 'glow_squid' || species === 'ghast') return make('tentacle', (i / Math.max(1, legs.length)) * Math.PI * 2, 0.25);
      if (plan === 'flyer') return make('wing', Math.PI * i, 0.6);
      if (plan === 'spider') return make('spider', (i < 4 ? [0, Math.PI, 0, Math.PI] : [Math.PI, 0, Math.PI, 0])[i % 4], 0.26);
      if (plan === 'strider' || plan === 'bird') return make('leg', Math.PI * i, 0.6);
      if (biped) return i % 2 === 0 ? make('leg', i === 0 ? 0 : Math.PI, 0.55) : make('arm', i === 1 ? Math.PI : 0, baseX < -0.5 ? 0.10 : 0.42);
      const quad = [0, Math.PI, Math.PI, 0];
      return make('leg', quad[i % 4], 0.52);
    });
    return { g, legs, head, woolCoat, collar, limbs, saddle, lid, jaw, tail, ears, core, extras, outfit, baseLegY };
  }

  private buildPlan(species: Species, g: THREE.Group, head: THREE.Group, legs: THREE.Object3D[], eyes: (y: number, z: number, sep: number, color?: string, sclera?: string, ew?: number, eh?: number) => void, quadLegs: (color: string, w: number, h: number, d: number, x: number, z: number, hoofColor?: string, upperCoatColor?: string) => void): { tail?: THREE.Object3D; extras?: THREE.Object3D[]; jaw?: THREE.Object3D; ears?: THREE.Object3D[] } {
    const info = NEW_SPECIES[species];
    const { skin, shirt, pants, plan } = info;
    let tail: THREE.Object3D | undefined;
    let extras: THREE.Object3D[] | undefined;
    let jaw: THREE.Object3D | undefined;
    let ears: THREE.Object3D[] | undefined;

    if (plan === 'quad') {
      const steed = species === 'donkey' || species === 'mule' || species === 'skeleton_horse' || species === 'zombie_horse';
      if (steed) {
        const h = 0.84;
        if (species === 'skeleton_horse') {
          // Skeleton Horse: exposed bone spine, open ribcage arches, pelvis, skeletal neck & skull
          this.part(g, '#e0ded0', 0, h + 0.48, 0, 0.18, 0.16, 1.28); // Dorsal spine
          this.part(g, '#e0ded0', 0, h + 0.30, -0.48, 0.62, 0.34, 0.28); // Ribbed shoulder
          this.part(g, '#e0ded0', 0, h + 0.32, 0.48, 0.60, 0.30, 0.28); // Pelvis
          for (const rz of [-0.24, -0.04, 0.16, 0.34]) {
            this.part(g, '#d2d0c2', 0, h + 0.26, rz, 0.64, 0.38, 0.08); // Rib arches
          }
        } else {
          this.part(g, skin, 0, h + 0.26, 0, 0.66, 0.58, 1.28);
          if (species === 'zombie_horse') {
            this.part(g, '#2e4f2e', -0.335, h + 0.28, 0.08, 0.02, 0.32, 0.48); // Exposed zombie rib patch
            this.part(g, '#d4d2c4', -0.34, h + 0.32, 0.08, 0.02, 0.06, 0.38);
            this.part(g, '#d4d2c4', -0.34, h + 0.22, 0.08, 0.02, 0.06, 0.38);
          }
        }
        head.position.set(0, h + 0.46, -0.52);
        this.part(head, skin, 0, 0.20, -0.06, species === 'skeleton_horse' ? 0.16 : 0.26, 0.54, species === 'skeleton_horse' ? 0.18 : 0.30).rotation.x = 0.38;
        if (species !== 'skeleton_horse') {
          this.part(head, pants, 0, 0.24, 0.10, 0.09, 0.54, 0.12).rotation.x = 0.38;
        }
        this.part(head, skin, 0, 0.44, -0.22, 0.32, 0.26, 0.40);
        this.part(head, shirt, 0, 0.38, -0.48, 0.24, 0.20, 0.28);
        const earH = species === 'donkey' || species === 'mule' ? 0.38 : 0.18;
        for (const sx of [-1, 1]) {
          const ear = this.part(head, pants, sx * 0.13, 0.62 + (earH - 0.18) * 0.45, -0.08, 0.08, earH, 0.08);
          ear.rotation.z = -sx * (species === 'donkey' || species === 'mule' ? 0.24 : 0.16);
        }
        if (species === 'donkey' || species === 'mule') {
          // Side pack chests with dark oak rim & iron latches on donkey/mule
          for (const sx of [-1, 1]) {
            this.part(g, '#9c6e34', sx * 0.40, h + 0.32, 0.16, 0.18, 0.34, 0.44);
            this.part(g, '#5e401c', sx * 0.405, h + 0.36, 0.16, 0.19, 0.05, 0.45);
            this.part(g, '#d8dce0', sx * 0.495, h + 0.35, 0.16, 0.02, 0.09, 0.07);
          }
        }
        eyes(0.48, -0.30, 0.16, species === 'skeleton_horse' ? '#1a1a1a' : '#171b17', species === 'skeleton_horse' ? undefined : '#ffffff');
        const sTail = new THREE.Group();
        sTail.position.set(0, h + 0.46, 0.64);
        this.part(sTail, pants, 0, -0.28, 0.06, species === 'skeleton_horse' ? 0.08 : 0.13, 0.58, species === 'skeleton_horse' ? 0.08 : 0.13).rotation.x = 0.32;
        g.add(sTail);
        tail = sTail;
        quadLegs(pants, species === 'skeleton_horse' ? 0.11 : 0.16, h, species === 'skeleton_horse' ? 0.11 : 0.16, 0.22, 0.46, '#2b221a');
      } else if (species === 'sniffer') {
        // Sniffer: 6 legs (3 pairs!), layered mossy green back + red sides + yellow-brown lower fringe, drooping ears, large yellow snout with dark nostrils
        const h = 0.64;
        this.part(g, '#963832', 0, h + 0.24, 0, 1.06, 0.78, 1.58); // Crimson-red sides
        this.part(g, '#5ea13a', 0, h + 0.58, 0.02, 1.10, 0.26, 1.54); // Lush mossy top shell
        this.part(g, '#7abf4e', 0, h + 0.71, 0.04, 0.92, 0.08, 1.36); // Upper moss ridge
        this.part(g, '#c48d3f', 0, h - 0.10, 0, 1.08, 0.18, 1.52); // Golden-brown lower belly fringe
        head.position.set(0, h + 0.24, -0.90);
        this.part(head, '#963832', 0, 0.02, 0, 0.58, 0.56, 0.54);
        this.part(head, '#e0ac48', 0, -0.06, -0.34, 0.48, 0.38, 0.34); // Large bulbous yellow beak/snout
        this.part(head, '#5e421c', -0.14, 0.04, -0.51, 0.08, 0.08, 0.03); // Nostrils
        this.part(head, '#5e421c', 0.14, 0.04, -0.51, 0.08, 0.08, 0.03);
        ears = [];
        for (const sx of [-1, 1]) {
          const ear = new THREE.Group();
          ear.position.set(sx * 0.32, 0.10, 0.02);
          this.part(ear, '#822e29', 0, -0.20, 0, 0.09, 0.46, 0.22); // Long drooping red ears
          head.add(ear);
          ears.push(ear);
        }
        eyes(0.12, -0.27, 0.21, '#1c1814', '#ffffff');
        for (const sx of [-1, 1]) for (const sz of [-0.52, 0, 0.52]) {
          const pivot = new THREE.Group();
          pivot.position.set(sx * 0.40, h, sz);
          this.part(pivot, '#5c4234', 0, -h / 2, 0, 0.22, h, 0.22);
          this.part(pivot, '#3d2b22', 0, -h + 0.06, -0.02, 0.24, 0.12, 0.25);
          g.add(pivot);
          legs.push(pivot);
        }
      } else if (species === 'camel') {
        // Camel: tall long legs (1.28), high-arched long neck, rounded snout, 2 side ears, prominent dorsal hump + saddle blanket
        const h = 1.26;
        this.part(g, skin, 0, h, 0, 0.84, 0.72, 1.42);
        this.part(g, shirt, 0, h + 0.50, 0.06, 0.54, 0.42, 0.64); // Dorsal camel hump
        head.position.set(0, h + 0.72, -0.68);
        this.part(head, skin, 0, -0.26, 0.18, 0.30, 0.72, 0.32).rotation.x = 0.22; // Tall curved camel neck
        this.part(head, skin, 0, 0.06, -0.02, 0.42, 0.38, 0.46); // Head cranium
        this.part(head, shirt, 0, 0.02, -0.34, 0.32, 0.24, 0.28); // Broad camel snout
        for (const sx of [-1, 1]) {
          const ear = this.part(head, shirt, sx * 0.23, 0.18, 0.06, 0.10, 0.16, 0.08);
          ear.rotation.z = -sx * 0.35;
        }
        eyes(0.10, -0.25, 0.17, '#1c1610', '#ffffff');
        const cTail = new THREE.Group();
        cTail.position.set(0, h + 0.18, 0.72);
        this.part(cTail, pants, 0, -0.26, 0.04, 0.10, 0.52, 0.10).rotation.x = 0.18;
        g.add(cTail);
        tail = cTail;
        quadLegs(pants, 0.18, h, 0.18, 0.28, 0.50, '#4a3822');
      } else if (species === 'llama') {
        // Llama: tall woolly upright neck, decorative woven carpet blanket on back, long snout, tall curved ears
        const h = 0.92;
        this.part(g, skin, 0, h, 0, 0.72, 0.66, 1.12);
        // Decorative woven blanket on back
        this.part(g, '#b83832', 0, h + 0.04, 0.04, 0.76, 0.52, 0.74);
        this.part(g, '#e8c244', 0, h - 0.18, 0.04, 0.77, 0.08, 0.75);
        this.part(g, '#2e5894', 0, h + 0.35, 0.04, 0.52, 0.03, 0.64);
        head.position.set(0, h + 0.62, -0.48);
        this.part(head, skin, 0, -0.24, 0.08, 0.34, 0.68, 0.32); // Long vertical woolly neck
        this.part(head, skin, 0, 0.08, -0.02, 0.40, 0.38, 0.40);
        this.part(head, '#b5a486', 0, 0.02, -0.28, 0.24, 0.20, 0.20); // Snout
        for (const sx of [-1, 1]) {
          this.part(head, skin, sx * 0.13, 0.34, 0.02, 0.10, 0.22, 0.08); // Upright llama ears
        }
        eyes(0.12, -0.22, 0.14, '#171b17', '#ffffff');
        quadLegs(pants, 0.18, h, 0.18, 0.23, 0.38, '#4a4034');
      } else if (species === 'ravager') {
        // Ravager: massive armored illager beast with heavy iron saddle/neck plates, chains, giant horned illager head + hinged lower jaw
        const h = 0.84;
        this.part(g, '#525c64', 0, h + 0.10, 0, 0.98, 0.88, 1.48);
        this.part(g, '#394046', 0, h + 0.26, -0.14, 1.04, 0.76, 0.76); // Heavy iron shoulder armor
        this.part(g, '#8c5230', 0, h + 0.56, 0.18, 0.76, 0.14, 0.68); // Raid saddle
        this.part(g, '#b8c0c4', 0, h + 0.26, -0.53, 0.84, 0.12, 0.06); // Iron chest chain bar
        head.position.set(0, h + 0.28, -0.84);
        this.part(head, '#5c666e', 0, 0.06, 0, 0.68, 0.64, 0.62);
        this.part(head, '#2c3236', 0, 0.26, -0.28, 0.70, 0.12, 0.14); // Heavy armored monobrow
        this.part(head, '#5c666e', 0, -0.08, -0.36, 0.18, 0.30, 0.16); // Large illager nose
        const rJaw = new THREE.Group();
        rJaw.position.set(0, -0.22, -0.02);
        this.part(rJaw, '#454d54', 0, 0, -0.12, 0.64, 0.16, 0.58);
        this.part(rJaw, '#e8e4d8', -0.22, 0.09, -0.34, 0.07, 0.10, 0.07); // Lower fangs
        this.part(rJaw, '#e8e4d8', 0.22, 0.09, -0.34, 0.07, 0.10, 0.07);
        head.add(rJaw);
        jaw = rJaw;
        for (const sx of [-1, 1]) {
          const horn = this.part(head, '#262b30', sx * 0.38, 0.22, -0.04, 0.14, 0.46, 0.18);
          horn.rotation.x = 0.42;
          horn.rotation.z = -sx * 0.18;
        }
        eyes(0.12, -0.315, 0.18, '#d93829', '#f5f2e8');
        quadLegs('#3a4248', 0.28, h, 0.28, 0.36, 0.50, '#1e2226');
      } else if (species === 'hoglin' || species === 'zoglin') {
        // Hoglin / Zoglin: forward-sloping hunched boar back, long angled snout, huge curved upward tusks, floppy ears, dark dorsal mane
        const h = 0.72;
        const bodyMesh = this.part(g, skin, 0, h + 0.08, 0, 0.84, 0.74, 1.32);
        bodyMesh.rotation.x = 0.14; // Sloping boar back
        this.part(g, species === 'zoglin' ? '#2c3d28' : '#2e2218', 0, h + 0.48, -0.08, 0.14, 0.22, 1.08).rotation.x = 0.14; // Dorsal mane ridge
        if (species === 'zoglin') {
          this.part(g, '#527848', -0.425, h + 0.12, 0.10, 0.02, 0.38, 0.52); // Rotted green zombie patches
        }
        head.position.set(0, h + 0.14, -0.72);
        const hHead = new THREE.Group();
        hHead.rotation.x = 0.42; // Steeply angled boar head
        this.part(hHead, skin, 0, 0, -0.12, 0.64, 0.36, 0.72);
        this.part(hHead, shirt, 0, -0.04, -0.44, 0.48, 0.24, 0.24); // Broad snout tip
        for (const sx of [-1, 1]) {
          this.part(hHead, '#faf4dc', sx * 0.28, 0.10, -0.32, 0.09, 0.36, 0.09); // Huge upward tusks
          this.part(hHead, shirt, sx * 0.36, 0.12, 0.08, 0.18, 0.08, 0.16).rotation.z = -sx * 0.35; // Boar ears
        }
        this.part(hHead, '#ffffff', -0.27, 0.16, -0.18, 0.10, 0.08, 0.10);
        this.part(hHead, '#1c1814', -0.29, 0.16, -0.20, 0.07, 0.06, 0.06);
        this.part(hHead, '#ffffff', 0.27, 0.16, -0.18, 0.10, 0.08, 0.10);
        this.part(hHead, '#1c1814', 0.29, 0.16, -0.20, 0.07, 0.06, 0.06);
        head.add(hHead);
        quadLegs(pants, 0.22, h, 0.22, 0.28, 0.42, '#261d16');
      } else if (species === 'panda' || species === 'polar_bear') {
        // Panda / Polar Bear: thick rotund bear body, rounded ears, short muzzle, black saddle band on Panda
        const h = 0.72;
        this.part(g, skin, 0, h + 0.06, 0, 0.88, 0.76, 1.24);
        if (species === 'panda') {
          this.part(g, '#1c1c1e', 0, h + 0.08, -0.24, 0.90, 0.77, 0.44); // Iconic black shoulder/chest saddle band
        } else {
          this.part(g, '#e6e6de', 0, h + 0.04, 0.24, 0.90, 0.74, 0.64); // Heavy Polar Bear hindquarter
        }
        head.position.set(0, h + 0.16, -0.68);
        this.part(head, skin, 0, 0, 0, 0.54, 0.48, 0.48);
        this.part(head, species === 'panda' ? '#f5f5f5' : '#deded4', 0, -0.10, -0.28, 0.28, 0.20, 0.18); // Muzzle
        this.part(head, '#1c1c1e', 0, -0.05, -0.375, 0.10, 0.07, 0.03); // Black bear nose
        for (const sx of [-1, 1]) {
          this.part(head, species === 'panda' ? '#1c1c1e' : skin, sx * 0.22, 0.26, 0.02, 0.15, 0.14, 0.08); // Round bear ears
          if (species === 'panda') {
            this.part(head, '#1c1c1e', sx * 0.15, 0.04, -0.245, 0.15, 0.14, 0.02); // Black eye patches
          }
        }
        eyes(0.05, -0.252, 0.15, '#171b17', '#ffffff');
        this.part(g, skin, 0, h + 0.10, 0.64, 0.16, 0.16, 0.12); // Stubby bear tail
        quadLegs(species === 'panda' ? '#1c1c1e' : pants, 0.24, h, 0.24, 0.28, 0.38, '#141416');
      } else if (species === 'goat') {
        // Vanilla Goat: shaggy coat with hanging beard, sloped nose bridge, 2 curved grey horns, lateral ears
        const h = 0.74;
        this.part(g, skin, 0, h, 0, 0.62, 0.64, 1.04);
        this.part(g, '#ebe6da', 0, h - 0.30, -0.12, 0.48, 0.14, 0.72); // Shaggy belly fringe
        head.position.set(0, h + 0.28, -0.52);
        const gHead = new THREE.Group();
        gHead.rotation.x = 0.28;
        this.part(gHead, skin, 0, 0, -0.08, 0.34, 0.42, 0.52); // Sloped goat head
        this.part(gHead, '#ebe6da', 0, -0.26, -0.14, 0.10, 0.24, 0.16); // Hanging goatee beard
        for (const sx of [-1, 1]) {
          this.part(gHead, '#4a423a', sx * 0.10, 0.34, 0.06, 0.09, 0.36, 0.10).rotation.x = -0.35; // Horns
          this.part(gHead, shirt, sx * 0.24, 0.08, 0.04, 0.16, 0.08, 0.08).rotation.z = -sx * 0.28; // Side ears
        }
        head.add(gHead);
        eyes(0.08, -0.28, 0.16, '#c4962c', '#ffffff');
        quadLegs(pants, 0.17, h, 0.17, 0.20, 0.34, '#36302a');
      } else if (species === 'armadillo') {
        // Vanilla Armadillo: banded pink-brown armored carapace scutes, small pointed head + ears, banded tail, 4 short legs
        const h = 0.32;
        this.part(g, '#b87d6e', 0, h + 0.12, 0, 0.56, 0.44, 0.76); // Main shell
        for (let i = 0; i < 4; i++) {
          this.part(g, i % 2 ? '#d49a8b' : '#9c6254', 0, h + 0.16, -0.24 + i * 0.16, 0.58, 0.40, 0.12); // Banded scute armor plates
        }
        head.position.set(0, h + 0.06, -0.46);
        this.part(head, '#cfa093', 0, 0, 0, 0.28, 0.26, 0.32).rotation.x = 0.24;
        this.part(head, '#8a5649', 0, 0.10, -0.02, 0.26, 0.06, 0.28).rotation.x = 0.24; // Head armor plate
        for (const sx of [-1, 1]) {
          this.part(head, '#cfa093', sx * 0.12, 0.18, 0.06, 0.07, 0.14, 0.06);
        }
        eyes(0.02, -0.15, 0.11, '#1c1614');
        const aTail = new THREE.Group();
        aTail.position.set(0, h + 0.02, 0.38);
        this.part(aTail, '#9c6254', 0, -0.04, 0.16, 0.12, 0.12, 0.34).rotation.x = -0.28;
        g.add(aTail);
        tail = aTail;
        quadLegs('#8a5649', 0.12, h, 0.12, 0.18, 0.22);
      } else if (species === 'ocelot') {
        // Vanilla Ocelot: sleek golden-yellow body with dark brown-black rosette spots, white muzzle, emerald eyes, two-piece tail
        const h = 0.48;
        this.part(g, '#ebb844', 0, h, 0, 0.38, 0.36, 0.84);
        // Leopard rosette spots along sides and back
        for (const [sx, sy, sz] of [[-0.195, h + 0.06, -0.18], [0.195, h + 0.04, -0.12], [-0.195, h - 0.02, 0.16], [0.195, h + 0.06, 0.20], [0, h + 0.185, 0]]) {
          this.part(g, '#4a2e14', sx, sy, sz, sx === 0 ? 0.18 : 0.02, sx === 0 ? 0.02 : 0.12, 0.18);
        }
        head.position.set(0, h + 0.18, -0.44);
        this.part(head, '#ebb844', 0, 0, 0, 0.36, 0.34, 0.36);
        this.part(head, '#f7f4eb', 0, -0.08, -0.22, 0.20, 0.13, 0.12);
        this.part(head, '#d47b88', 0, -0.05, -0.285, 0.07, 0.05, 0.03);
        for (const sx of [-1, 1]) {
          this.part(head, '#c9962c', sx * 0.13, 0.22, 0.02, 0.10, 0.14, 0.07);
        }
        eyes(0.05, -0.185, 0.11, '#32a852', '#f7f4eb');
        const oTail = new THREE.Group();
        oTail.position.set(0, h + 0.10, 0.42);
        this.part(oTail, '#ebb844', 0, 0, 0.22, 0.08, 0.08, 0.44);
        this.part(oTail, '#4a2e14', 0, 0.05, 0.44, 0.075, 0.075, 0.18).rotation.x = 0.32;
        g.add(oTail);
        tail = oTail;
        quadLegs('#ebb844', 0.12, h, 0.12, 0.13, 0.29, '#f7f4eb');
      } else {
        // Mooshroom: red mushroom-biome cow with white spots, 3D red mushrooms on back & head, horns, and pink udder
        const h = 0.76;
        this.part(g, '#a82822', 0, h, 0, 0.74, 0.64, 1.12);
        this.part(g, '#f0ede4', 0.375, h + 0.08, 0.14, 0.02, 0.36, 0.44);
        this.part(g, '#f0ede4', -0.375, h - 0.06, -0.20, 0.02, 0.30, 0.36);
        this.part(g, '#ebaca6', 0, h - 0.34, 0.22, 0.28, 0.09, 0.36); // Udder
        for (const [mx, mz] of [[-0.16, 0.18], [0.18, -0.14], [0.04, 0.36]]) {
          this.part(g, '#ebe6d8', mx, h + 0.40, mz, 0.08, 0.18, 0.08);
          this.part(g, '#c93028', mx, h + 0.52, mz, 0.26, 0.10, 0.26);
          this.part(g, '#f5f2ea', mx + 0.06, h + 0.575, mz - 0.04, 0.06, 0.02, 0.06);
        }
        head.position.set(0, h + 0.18, -0.60);
        this.part(head, '#a82822', 0, 0, 0, 0.48, 0.48, 0.40);
        this.part(head, '#d8d2c5', 0, -0.10, -0.22, 0.34, 0.20, 0.10);
        this.part(head, '#ebe6d8', 0.06, 0.30, 0.02, 0.07, 0.14, 0.07); // Head mushroom
        this.part(head, '#c93028', 0.06, 0.39, 0.02, 0.22, 0.09, 0.22);
        for (const sx of [-1, 1]) {
          this.part(head, '#3d352e', sx * 0.27, 0.20, 0.04, 0.08, 0.22, 0.08);
        }
        eyes(0.06, -0.205, 0.16, '#171b17', '#ffffff');
        quadLegs('#8c201b', 0.22, h, 0.22, 0.23, 0.38, '#261d15');
      }
    } else if (plan === 'spider') {
      // Cave Spider: dark venomous teal-blue arthropod with red eyes & 2-segment legs (scaled via info.scale = 0.7)
      this.part(g, '#163847', 0, 0.44, -0.10, 0.44, 0.36, 0.46);
      const abd = this.part(g, '#1c4658', 0, 0.50, 0.42, 0.68, 0.48, 0.78);
      abd.rotation.x = 0.14;
      this.part(g, '#102833', 0, 0.75, 0.40, 0.28, 0.04, 0.46);
      head.position.set(0, 0.45, -0.44);
      this.part(head, '#12303d', 0, 0, 0, 0.50, 0.40, 0.44);
      this.part(head, '#0c2029', -0.09, -0.13, -0.24, 0.08, 0.13, 0.09);
      this.part(head, '#0c2029', 0.09, -0.13, -0.24, 0.08, 0.13, 0.09);
      this.glowPart(head, '#ff261b', -0.14, 0.05, -0.23, 0.08, 0.07, 0.02);
      this.glowPart(head, '#ff261b', 0.14, 0.05, -0.23, 0.08, 0.07, 0.02);
      this.glowPart(head, '#ff3b30', -0.06, 0.12, -0.23, 0.05, 0.05, 0.02);
      this.glowPart(head, '#ff3b30', 0.06, 0.12, -0.23, 0.05, 0.05, 0.02);
      for (const sd of [-1, 1]) for (let i = 0; i < 4; i++) {
        const pivot = new THREE.Group();
        pivot.position.set(sd * 0.24, 0.45, -0.30 + i * 0.20);
        this.part(pivot, '#1a4254', sd * 0.22, 0.07, 0, 0.46, 0.085, 0.085).rotation.z = sd * 0.32;
        this.part(pivot, '#102833', sd * 0.54, -0.10, 0, 0.50, 0.075, 0.075).rotation.z = -sd * 0.52;
        pivot.rotation.z = sd * 0.22;
        g.add(pivot);
        legs.push(pivot);
      }
    } else if (plan === 'fish') {
      const guardian = species === 'guardian' || species === 'elder_guardian';
      const puffer = species === 'pufferfish';
      const tad = species === 'tadpole';
      if (guardian) {
        // Guardian / Elder Guardian: prismarine sea-mine body, large cyclops eye, 12 orange/elder spines, 3-segment tail + fin
        const bodyCol = species === 'elder_guardian' ? '#b8b4a6' : '#588276';
        const trimCol = species === 'elder_guardian' ? '#424a5e' : '#3a5950';
        const spineCol = species === 'elder_guardian' ? '#4a5268' : '#e07032';
        this.part(g, bodyCol, 0, 0.42, 0, 0.78, 0.78, 0.78);
        this.part(g, trimCol, 0, 0.82, 0, 0.62, 0.06, 0.62);
        this.part(g, trimCol, 0, 0.02, 0, 0.62, 0.06, 0.62);
        head.position.set(0, 0.42, -0.20);
        this.part(head, '#f7f4ec', 0, 0.02, -0.20, 0.34, 0.26, 0.03); // Large cyclops sclera
        this.glowPart(head, species === 'elder_guardian' ? '#e88258' : '#f26d29', 0, 0.02, -0.21, 0.14, 0.14, 0.03);
        this.part(head, '#2b1838', 0, 0.02, -0.218, 0.07, 0.07, 0.03); // Pupil
        const dirs = [
          [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0],
          [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
          [0, 1, 1], [0, -1, 1], [0, 1, -1], [0, -1, -1],
        ];
        for (const [dx, dy, dz] of dirs) {
          const sp = this.part(g, spineCol, dx * 0.43, 0.42 + dy * 0.43, dz * 0.43, 0.10, 0.34, 0.10);
          sp.rotation.z = -dx * 0.68;
          sp.rotation.x = dz * 0.68;
        }
        const gTail = new THREE.Group();
        gTail.position.set(0, 0.42, 0.40);
        this.part(gTail, bodyCol, 0, 0, 0.16, 0.26, 0.26, 0.30);
        this.part(gTail, spineCol, 0, 0.16, 0.16, 0.05, 0.10, 0.18);
        this.part(gTail, trimCol, 0, 0, 0.42, 0.18, 0.18, 0.26);
        this.part(gTail, spineCol, 0, 0, 0.68, 0.06, 0.46, 0.30);
        g.add(gTail);
        tail = gTail;
      } else if (puffer) {
        // Pufferfish: golden-yellow spiked sphere-cube with cream belly, blue/white eyes, pectoral fins, and 16 radially protruding spines
        this.part(g, '#e8bc29', 0, 0.36, 0, 0.50, 0.48, 0.50);
        this.part(g, '#f7f0c8', 0, 0.18, 0, 0.46, 0.14, 0.46); // Cream belly
        head.position.set(0, 0.38, -0.25);
        eyes(0.06, -0.01, 0.15, '#171b17', '#ffffff');
        this.part(head, '#7a5216', 0, -0.06, -0.01, 0.10, 0.06, 0.03);
        for (const sx of [-1, 1]) {
          this.part(g, '#c4961d', sx * 0.29, 0.36, -0.08, 0.10, 0.08, 0.14);
        }
        for (let i = 0; i < 14; i++) {
          const a = (i / 14) * Math.PI * 2;
          const sp = this.part(g, '#b88618', Math.cos(a) * 0.28, 0.36 + Math.sin(a * 2) * 0.20, Math.sin(a) * 0.28, 0.065, 0.065, 0.18);
          sp.rotation.y = a;
        }
      } else if (species === 'glow_squid') {
        // Glow Squid: deep teal shaded mantle with glowing cyan bioluminescent speckles, crown rim, eyes & tentacle tips
        this.part(g, '#1f6e6e', 0, 0.48, 0, 0.50, 0.68, 0.50);
        this.glowPart(g, '#66fff5', 0, 0.84, 0, 0.54, 0.08, 0.54);
        for (const [gx, gy, gz] of [[-0.255, 0.58, -0.08], [0.255, 0.44, 0.08], [0, 0.62, -0.255], [0.12, 0.38, -0.255]]) {
          this.glowPart(g, '#7afff5', gx, gy, gz, Math.abs(gx) > 0.2 ? 0.02 : 0.12, 0.12, Math.abs(gz) > 0.2 ? 0.02 : 0.12);
        }
        head.position.set(0, 0.36, -0.25);
        this.glowPart(head, '#a8fff9', -0.17, 0.04, -0.01, 0.12, 0.10, 0.03);
        this.glowPart(head, '#a8fff9', 0.17, 0.04, -0.01, 0.12, 0.10, 0.03);
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * Math.PI * 2;
          const t = new THREE.Group();
          t.position.set(Math.cos(a) * 0.20, 0.16, Math.sin(a) * 0.20);
          this.part(t, '#288f8c', 0, -0.20, 0, 0.085, 0.40, 0.085);
          this.glowPart(t, '#66fff5', 0, -0.48, 0, 0.08, 0.18, 0.08);
          g.add(t);
          legs.push(t);
        }
      } else if (species === 'axolotl') {
        // Axolotl: flat wide amphibian head + 6 bright pink external gill fronds (top & sides), dorsal fin crest, 4 splayed legs, long finned tail
        this.part(g, '#f5a6cd', 0, 0.26, 0, 0.38, 0.24, 0.64);
        this.part(g, '#e06ea8', 0, 0.40, 0.08, 0.04, 0.10, 0.48); // Dorsal fin ridge
        head.position.set(0, 0.28, -0.36);
        this.part(head, '#f7b2d4', 0, 0, 0, 0.44, 0.26, 0.34); // Wide flat salamander head
        for (const sd of [-1, 1]) {
          for (const [gy, gz, rotZ] of [[-0.04, 0.04, 0.15], [0.06, 0.04, 0.35], [0.16, 0.04, 0.65]]) {
            const gill = this.part(head, '#d93b88', sd * 0.25, gy, gz, 0.18, 0.055, 0.04);
            gill.rotation.z = sd * rotZ;
          }
        }
        eyes(0.03, -0.175, 0.14, '#1a1218');
        this.part(head, '#c95b90', 0, -0.05, -0.175, 0.14, 0.03, 0.02); // Cute smile
        const aTail = new THREE.Group();
        aTail.position.set(0, 0.26, 0.32);
        this.part(aTail, '#f5a6cd', 0, 0, 0.24, 0.08, 0.18, 0.48);
        this.part(aTail, '#e06ea8', 0, 0, 0.28, 0.04, 0.28, 0.52); // Translucent tail fin
        g.add(aTail);
        tail = aTail;
        quadLegs('#e88bb8', 0.08, 0.16, 0.08, 0.20, 0.20);
      } else if (tad) {
        // Tadpole: dark brown round head-body + long undulating paddle tail fin
        this.part(g, '#4f3d2b', 0, 0.28, -0.06, 0.26, 0.22, 0.30);
        head.position.set(0, 0.28, -0.21);
        eyes(0.05, -0.01, 0.09, '#12100e');
        const tTail = new THREE.Group();
        tTail.position.set(0, 0.28, 0.09);
        this.part(tTail, '#3b2d1f', 0, 0, 0.22, 0.05, 0.22, 0.44);
        g.add(tTail);
        tail = tTail;
      } else if (species === 'salmon') {
        // Vanilla Salmon: crimson-pink torso, olive-green head & dorsal back, two dorsal fins, pelvic fins, forked tail
        this.part(g, '#b84638', 0, 0.35, 0, 0.20, 0.32, 0.78);
        this.part(g, '#596b49', 0, 0.48, 0, 0.205, 0.09, 0.76); // Olive-green dorsal stripe
        this.part(g, '#4e5e40', 0, 0.58, -0.04, 0.04, 0.16, 0.24); // Main dorsal fin
        this.part(g, '#4e5e40', 0, 0.54, 0.26, 0.04, 0.10, 0.12);  // Adipose fin
        head.position.set(0, 0.35, -0.44);
        this.part(head, '#596b49', 0, 0, 0, 0.19, 0.26, 0.22);
        for (const sx of [-1, 1]) {
          this.part(head, '#ffffff', sx * 0.098, 0.03, -0.02, 0.015, 0.07, 0.07);
          this.part(head, '#141414', sx * 0.102, 0.03, -0.03, 0.015, 0.05, 0.05);
        }
        const sTail = new THREE.Group();
        sTail.position.set(0, 0.35, 0.39);
        this.part(sTail, '#4e5e40', 0, 0, 0.16, 0.04, 0.34, 0.26);
        g.add(sTail);
        tail = sTail;
      } else {
        // Tropical Fish (Clownfish): bright orange body with 3 vertical white bands, black fin trim, large tail fin
        this.part(g, '#f07424', 0, 0.35, 0, 0.18, 0.32, 0.56);
        for (const bz of [-0.16, 0.02, 0.20]) {
          this.part(g, '#f7f7f2', 0, 0.35, bz, 0.19, 0.325, 0.08); // White clownfish bands
        }
        this.part(g, '#f07424', 0, 0.55, 0.02, 0.04, 0.14, 0.34); // Dorsal fin
        head.position.set(0, 0.35, -0.30);
        this.part(head, '#f07424', 0, 0, 0, 0.17, 0.26, 0.14);
        for (const sx of [-1, 1]) {
          this.part(head, '#ffffff', sx * 0.088, 0.03, -0.01, 0.015, 0.07, 0.07);
          this.part(head, '#141414', sx * 0.092, 0.03, -0.02, 0.015, 0.05, 0.05);
        }
        const tfTail = new THREE.Group();
        tfTail.position.set(0, 0.35, 0.28);
        this.part(tfTail, '#f7f7f2', 0, 0, 0.14, 0.04, 0.30, 0.24);
        g.add(tfTail);
        tail = tfTail;
      }
    } else if (plan === 'bird') {
      // Scarlet Macaw Parrot: angled red body, tall multi-feather crest, white eye patch, curved black/yellow hooked beak, blue/yellow wings, 2 legs, tail
      const pBody = this.part(g, '#d92b24', 0, 0.42, 0, 0.26, 0.38, 0.30);
      pBody.rotation.x = 0.24;
      head.position.set(0, 0.68, -0.12);
      this.part(head, '#d92b24', 0, 0, 0, 0.22, 0.26, 0.24);
      this.part(head, '#d92b24', 0, 0.20, -0.02, 0.05, 0.18, 0.20).rotation.x = -0.25; // Tall feather crest
      this.part(head, '#f2c638', 0, 0.02, -0.16, 0.10, 0.10, 0.10); // Upper yellow mandible
      this.part(head, '#242424', 0, -0.05, -0.15, 0.09, 0.09, 0.09); // Lower dark beak
      eyes(0.05, -0.11, 0.112, '#171b17', '#ffffff');
      const pTail = this.part(g, '#f2c638', 0, 0.26, 0.22, 0.14, 0.06, 0.28);
      pTail.rotation.x = -0.42;
      for (const sx of [-1, 1]) {
        const leg = new THREE.Group();
        leg.position.set(sx * 0.07, 0.24, -0.02);
        this.part(leg, '#4a4a4a', 0, -0.12, 0, 0.04, 0.24, 0.04);
        g.add(leg);
        legs.push(leg);
      }
      for (const sx of [-1, 1]) {
        const w = new THREE.Group();
        w.position.set(sx * 0.14, 0.50, -0.02);
        this.part(w, '#2462cc', sx * 0.04, -0.06, 0.02, 0.06, 0.30, 0.22).rotation.x = 0.20;
        this.part(w, '#f2c638', sx * 0.045, 0.04, 0, 0.065, 0.10, 0.18).rotation.x = 0.20;
        g.add(w);
        legs.push(w);
      }
    } else if (plan === 'blob') {
      if (species === 'frog') {
        // Frog: wide flat box body (7x5x9 ratio), cream croaking vocal sac, two raised eye turrets on top of head, wide mouth line, webbed hind feet
        this.part(g, '#d9823b', 0, 0.24, 0, 0.56, 0.28, 0.62);
        this.part(g, '#f2dfb6', 0, 0.15, -0.06, 0.48, 0.12, 0.48); // Cream vocal sac / belly
        head.position.set(0, 0.34, -0.20);
        this.part(head, '#82461c', 0, -0.06, -0.12, 0.52, 0.03, 0.04); // Wide frog mouth line
        for (const sx of [-1, 1]) {
          this.part(head, '#d9823b', sx * 0.17, 0.08, -0.02, 0.15, 0.12, 0.16); // Raised eye turrets
          this.part(head, '#f5eb9d', sx * 0.17, 0.09, -0.102, 0.12, 0.08, 0.02);
          this.part(head, '#1c1612', sx * 0.17, 0.09, -0.108, 0.08, 0.04, 0.02); // Horizontal frog pupil
        }
        quadLegs('#b86828', 0.12, 0.18, 0.16, 0.30, 0.22, '#9e541c');
      } else if (species === 'silverfish') {
        // Silverfish: 7 tapering stone-grey segments + 3 wide bristly dorsal frills + tail cerci
        const widths = [0.22, 0.28, 0.38, 0.32, 0.24, 0.18, 0.12];
        const heights = [0.16, 0.22, 0.26, 0.22, 0.18, 0.14, 0.10];
        for (let i = 0; i < 7; i++) {
          const zPos = -0.38 + i * 0.14;
          this.part(g, i % 2 ? '#72787d' : '#8e959c', 0, heights[i] / 2 + 0.04, zPos, widths[i], heights[i], 0.15);
          if (i >= 1 && i <= 4) {
            this.part(g, '#b8c0c8', 0, heights[i] + 0.06, zPos, widths[i] * 1.65, 0.14, 0.04); // Fuzzy silverfish dorsal frills
          }
        }
        head.position.set(0, 0.14, -0.44);
        eyes(0.02, -0.02, 0.07, '#c8241e');
      } else {
        // Endermite: 4 compact deep-purple segments with glowing magenta eyes & ridge spines
        const widths = [0.26, 0.38, 0.28, 0.18];
        const heights = [0.20, 0.28, 0.22, 0.14];
        for (let i = 0; i < 4; i++) {
          const zPos = -0.24 + i * 0.16;
          this.part(g, i % 2 ? '#342442' : '#463159', 0, heights[i] / 2 + 0.04, zPos, widths[i], heights[i], 0.17);
          this.part(g, '#664882', 0, heights[i] + 0.05, zPos, 0.06, 0.06, 0.10);
        }
        head.position.set(0, 0.15, -0.32);
        this.glowPart(head, '#e042f5', -0.08, 0.02, -0.02, 0.06, 0.05, 0.02);
        this.glowPart(head, '#e042f5', 0.08, 0.02, -0.02, 0.06, 0.05, 0.02);
      }
    } else if (plan === 'flyer') {
      if (species === 'phantom') {
        // Phantom: flat undead manta-ray body with exposed bone ribs, wide skull head with glowing green eyes, 2-segment wings, long tail
        this.part(g, '#3d4c78', 0, 0.50, -0.06, 0.46, 0.22, 0.72);
        for (const rz of [-0.26, -0.06, 0.14]) {
          this.part(g, '#d2ccb8', 0, 0.52, rz, 0.50, 0.06, 0.08); // Exposed bone ribs
        }
        head.position.set(0, 0.48, -0.54);
        this.part(head, '#323f66', 0, 0, 0, 0.52, 0.22, 0.36);
        this.glowPart(head, '#7cf258', -0.16, 0.02, -0.185, 0.12, 0.06, 0.02);
        this.glowPart(head, '#7cf258', 0.16, 0.02, -0.185, 0.12, 0.06, 0.02);
        const pTail = new THREE.Group();
        pTail.position.set(0, 0.50, 0.30);
        this.part(pTail, '#323f66', 0, 0, 0.24, 0.24, 0.14, 0.48);
        this.part(pTail, '#242e4d', 0, -0.02, 0.68, 0.10, 0.08, 0.48);
        g.add(pTail);
        tail = pTail;
        for (const sx of [-1, 1]) {
          const w = new THREE.Group();
          w.position.set(sx * 0.24, 0.52, -0.06);
          this.part(w, '#46588a', sx * 0.46, 0, 0, 0.92, 0.06, 0.58);
          this.part(w, '#c8c2ae', sx * 0.46, 0.03, -0.26, 0.92, 0.05, 0.06); // Wing bone leading edge
          this.part(w, '#283354', sx * 1.24, -0.02, 0.06, 0.76, 0.04, 0.46); // Outer wing tip
          g.add(w);
          legs.push(w);
        }
      } else if (species === 'breeze') {
        // Breeze: Trial Chambers wind elemental — large 8x8x8 head with heavy slanted brows & glowing yellow eyes, floating core rod, 3 counter-rotating wind vortex rings
        this.glowPart(g, '#7ea2d8', 0, 0.56, 0, 0.22, 0.68, 0.22, 0.90); // Inner wind core rod
        head.position.set(0, 1.06, 0);
        this.part(head, '#9ebaf0', 0, 0, 0, 0.52, 0.52, 0.52);
        for (const sx of [-1, 1]) {
          const brow = this.part(head, '#526894', sx * 0.14, 0.13, -0.265, 0.24, 0.09, 0.04);
          brow.rotation.z = -sx * 0.22; // Heavy slanted Breeze eyebrows
        }
        this.glowPart(head, '#fff6a0', -0.14, 0.03, -0.265, 0.12, 0.08, 0.02);
        this.glowPart(head, '#fff6a0', 0.14, 0.03, -0.265, 0.12, 0.08, 0.02);
        extras = [];
        for (let i = 0; i < 3; i++) {
          const ring = new THREE.Group();
          ring.position.set(0, 0.26 + i * 0.25, 0);
          const rw = 0.44 + i * 0.16;
          const rh = 0.12;
          this.glowPart(ring, '#d8ecff', 0, 0, -rw / 2, rw, rh, 0.045, 0.65);
          this.glowPart(ring, '#d8ecff', 0, 0, rw / 2, rw, rh, 0.045, 0.65);
          this.glowPart(ring, '#d8ecff', -rw / 2, 0, 0, 0.045, rh, rw, 0.65);
          this.glowPart(ring, '#d8ecff', rw / 2, 0, 0, 0.045, rh, rw, 0.65);
          g.add(ring);
          extras.push(ring);
        }
        for (const sx of [-1, 1]) {
          const w = new THREE.Group();
          w.position.set(sx * 0.24, 0.66, 0);
          g.add(w);
          legs.push(w);
        }
      } else if (species === 'allay' || species === 'vex') {
        // Allay / Vex (1.19.3+ redesigned fairy model): oversized 5x5x5 head, wispy tapered torso (no legs), outstretched arms, glowing wings
        const col = species === 'allay' ? '#6be0fa' : '#8fa6c9';
        const darkCol = species === 'allay' ? '#3cb4e0' : '#5e769c';
        this.glowPart(g, col, 0, 0.56, 0, 0.34, 0.38, 0.24, 0.92); // Upper torso
        const wisp = this.glowPart(g, darkCol, 0, 0.30, 0.08, 0.24, 0.28, 0.18, 0.78); // Tapered lower wisp tail
        wisp.rotation.x = 0.35;
        head.position.set(0, 0.96, 0);
        this.glowPart(head, col, 0, 0, 0, 0.56, 0.56, 0.56, 0.96); // Cute oversized 5x5x5 head
        if (species === 'vex') {
          for (const sx of [-1, 1]) {
            this.part(head, '#3b4a68', sx * 0.14, 0.12, -0.285, 0.20, 0.06, 0.02).rotation.z = -sx * 0.28; // Angry Vex brow
            this.glowPart(head, '#ff5242', sx * 0.14, 0.03, -0.285, 0.12, 0.08, 0.02);
          }
          this.part(g, '#b8382e', 0, 0.58, -0.125, 0.22, 0.28, 0.02); // Red Vex charge mark
        } else {
          this.part(head, '#164e68', -0.13, 0.01, -0.285, 0.11, 0.16, 0.02); // Deep cyan-blue Allay eye socket
          this.glowPart(head, '#e8ffff', -0.13, 0.04, -0.29, 0.07, 0.08, 0.02);
          this.part(head, '#164e68', 0.13, 0.01, -0.285, 0.11, 0.16, 0.02);
          this.glowPart(head, '#e8ffff', 0.13, 0.04, -0.29, 0.07, 0.08, 0.02);
        }
        for (const sx of [-1, 1]) {
          this.glowPart(g, darkCol, sx * 0.24, 0.58, -0.10, 0.14, 0.34, 0.14).rotation.x = -0.55; // Little arms
          const w = new THREE.Group();
          w.position.set(sx * 0.14, 0.64, 0.12);
          this.glowPart(w, '#d8f6ff', sx * 0.34, 0.06, 0.10, 0.68, 0.32, 0.03, 0.72).rotation.y = -sx * 0.35;
          g.add(w);
          legs.push(w);
        }
        if (species === 'vex') {
          const sword = this.part(g, '#d0d6dc', 0.28, 0.54, -0.32, 0.06, 0.62, 0.10);
          sword.rotation.x = -1.05;
        }
      } else {
        // Bat (1.20.3+ redesigned model): compact furry brown body, huge oversized ears, tiny feet, wide leathery membrane wings
        this.part(g, '#423329', 0, 0.48, 0, 0.34, 0.44, 0.26);
        this.part(g, '#594638', 0, 0.52, -0.135, 0.26, 0.28, 0.02); // Chest fur
        head.position.set(0, 0.82, -0.02);
        this.part(head, '#4a3a2e', 0, 0, 0, 0.38, 0.34, 0.34);
        this.part(head, '#665040', 0, -0.04, -0.19, 0.16, 0.10, 0.06); // Bat snout
        for (const sx of [-1, 1]) {
          this.part(head, '#362820', sx * 0.18, 0.26, 0.02, 0.20, 0.28, 0.04); // Huge bat ears
          this.part(head, '#7a5c4a', sx * 0.18, 0.25, 0.005, 0.12, 0.18, 0.02);
        }
        eyes(0.03, -0.175, 0.11, '#1a1410');
        for (const sx of [-1, 1]) {
          const w = new THREE.Group();
          w.position.set(sx * 0.17, 0.54, 0);
          this.part(w, '#261c16', sx * 0.38, 0, 0, 0.76, 0.38, 0.03);
          this.part(w, '#1a120e', sx * 0.88, -0.04, 0, 0.42, 0.30, 0.03);
          g.add(w);
          legs.push(w);
        }
      }
    } else if (plan === 'strider') {
      // Strider: large 16x14x16 crimson lava-walker cube, frowning brow, drooping white hair bristles on both sides, 2 thick basalt-plated legs
      this.part(g, '#9c3232', 0, 1.24, 0, 0.90, 0.82, 0.90);
      this.part(g, '#7a2424', 0, 1.66, 0, 0.84, 0.05, 0.84);
      head.position.set(0, 1.32, -0.455);
      this.part(head, '#661c1c', 0, 0.10, 0, 0.62, 0.08, 0.03); // Heavy frowning brow
      this.part(head, '#521515', 0, -0.12, 0, 0.36, 0.06, 0.03); // Frowning mouth
      eyes(0.02, -0.01, 0.22, '#3d1414', '#f5d258');
      for (const sx of [-1, 1]) {
        for (let i = 0; i < 3; i++) {
          const bristle = this.part(g, '#ebe6dc', sx * 0.56, 1.54 - i * 0.15, -0.22 + i * 0.22, 0.34, 0.045, 0.06);
          bristle.rotation.z = -sx * 0.52;
        }
        const leg = new THREE.Group();
        leg.position.set(sx * 0.26, 0.86, 0);
        this.part(leg, '#4f2828', 0, -0.43, 0, 0.22, 0.86, 0.22);
        this.part(leg, '#362426', 0, -0.72, 0, 0.24, 0.28, 0.24); // Basalt-crusted lower leg
        g.add(leg);
        legs.push(leg);
      }
    }
    g.scale.setScalar(info.scale);
    return { tail, extras, jaw, ears };
  }

  private syncVillagerOutfit(m: Mob) {
    if (!m.outfit) return;
    const key = m.species + ":" + m.profession + ":" + (m.captain ? 1 : 0) + ":" + m.level;
    if (m.outfitKey === key) return;
    m.outfitKey = key;
    while (m.outfit.children.length > 0) m.outfit.remove(m.outfit.children[0]);

    // Raid Captain Ominous Banner on back/head
    if (m.captain) {
      this.part(m.outfit, '#6e5032', 0, 2.28, 0.18, 0.06, 1.15, 0.06); // Banner pole
      this.part(m.outfit, '#6e5032', 0, 2.82, 0.18, 0.46, 0.06, 0.06); // Crossbar
      this.part(m.outfit, '#4a5058', 0, 2.42, 0.21, 0.42, 0.76, 0.04); // Ominous slate cloth
      this.part(m.outfit, '#8d9492', 0, 2.48, 0.235, 0.22, 0.26, 0.02); // Illager emblem
    }

    if (m.species !== 'villager') return;
    const p = m.profession;
    if (p === 'farmer') {
      this.part(m.outfit, '#d8b448', 0, 1.98, 0, 0.78, 0.06, 0.78); // Straw hat brim
      this.part(m.outfit, '#e2c258', 0, 2.06, 0, 0.52, 0.14, 0.52); // Straw crown
      this.part(m.outfit, '#7a4424', 0, 2.01, 0, 0.54, 0.05, 0.54);
    } else if (p === 'librarian') {
      this.part(m.outfit, '#b8322c', 0, 2.02, 0, 0.56, 0.14, 0.56); // Red book cap
      this.part(m.outfit, '#f0d668', 0, 1.97, 0, 0.54, 0.05, 0.54); // Gold page trim
      this.part(m.outfit, '#2e2e2e', 0, 1.70, -0.265, 0.38, 0.08, 0.02); // Spectacles
    } else if (p === 'armorer') {
      this.part(m.outfit, '#9da5a8', 0, 1.88, -0.265, 0.48, 0.14, 0.04); // Welding visor
      this.part(m.outfit, '#586064', 0, 1.02, -0.155, 0.46, 0.58, 0.03); // Iron apron
    } else if (p === 'weaponsmith' || p === 'toolsmith') {
      this.part(m.outfit, '#1e1e1e', -0.13, 1.70, -0.265, 0.12, 0.10, 0.03); // Eyepatch
      this.part(m.outfit, '#3e342c', 0, 0.94, -0.155, 0.46, 0.68, 0.03); // Smithing apron
    } else if (p === 'cleric') {
      this.part(m.outfit, '#7a348c', 0, 0.98, 0, 0.54, 0.82, 0.34); // Purple cleric robe
      this.part(m.outfit, '#e8c444', 0, 1.24, -0.175, 0.34, 0.18, 0.02);
    } else if (p === 'butcher') {
      this.part(m.outfit, '#c43a2e', 0, 1.88, 0, 0.53, 0.07, 0.53); // Red headband
      this.part(m.outfit, '#f0eee6', 0, 0.92, -0.155, 0.46, 0.72, 0.03); // White butcher apron
    } else if (p === 'fletcher') {
      this.part(m.outfit, '#6e5034', 0, 2.00, 0, 0.54, 0.10, 0.54);
      this.part(m.outfit, '#f6f4ec', 0.24, 2.10, 0.02, 0.06, 0.22, 0.12); // Feather
    } else if (p === 'shepherd') {
      this.part(m.outfit, '#f2f0e6', 0, 1.08, 0, 0.54, 0.64, 0.33); // Wool vest
      this.part(m.outfit, '#7a5838', 0, 2.00, 0, 0.58, 0.09, 0.58);
    } else if (p === 'fisherman') {
      this.part(m.outfit, '#c49638', 0, 1.98, 0, 0.70, 0.07, 0.70);
    } else if (p === 'cartographer') {
      this.part(m.outfit, '#e8c444', 0.13, 1.70, -0.265, 0.12, 0.12, 0.03); // Golden monocle
    } else if (p === 'leatherworker' || p === 'mason') {
      this.part(m.outfit, p === 'leatherworker' ? '#8c4f32' : '#4a4e52', 0, 0.92, -0.155, 0.46, 0.72, 0.03);
    }
    // Badge gem on belt showing villager trade level (stone -> iron -> gold -> emerald -> diamond)
    if (m.level >= 1) {
      const badgeCol = m.level >= 5 ? '#58e0d8' : m.level === 4 ? '#38cf65' : m.level === 3 ? '#f2c842' : m.level === 2 ? '#d4d8d8' : '#8a8d86';
      this.part(m.outfit, badgeCol, 0.14, 0.84, -0.17, 0.08, 0.08, 0.03);
    }
  }

  private setHurtTint(m: Mob, hurt: boolean) {
    m.group.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        if (!mesh.userData.baseMat) mesh.userData.baseMat = mesh.material;
        mesh.material = hurt ? this.hurtMat : mesh.userData.baseMat;
      }
    });
  }

  spawn(species: Species, x: number, z: number, baby = false, exactY?: number) {
    if (!SPECIES.includes(species)) return undefined;
    const h = this.host.terrain.height(x, z);
    const y = exactY ?? (species === 'dragon' ? 40 : h + 1);
    if (swimmers.has(species)) {
      if (exactY === undefined && h >= SEA_LEVEL) return undefined;
    } else if (species !== 'dragon' && exactY === undefined && this.host.dimension === 'overworld' && y < SEA_LEVEL + 1) return undefined;

    const { g, legs, head, woolCoat, collar, limbs, saddle, lid, jaw, tail, ears, core, extras, outfit, baseLegY } = this.model(species);
    g.position.set(x, y, z);
    if (baby) g.scale.multiplyScalar(0.5);
    const info = NEW_SPECIES[species];
    this.scene.add(g);
    const maxHp =
      species === 'dragon' ? 200 :
      species === 'wither' ? 150 :
      species === 'warden' ? 500 :
      species === 'iron_golem' ? 100 :
      species === 'enderman' ? 40 :
      species === 'horse' ? 30 :
      species === 'shulker' ? 30 :
      species === 'pillager' ? 24 :
      species === 'witch' ? 26 :
      species === 'slime' || species === 'magma_cube' ? 16 :
      species === 'zombie' || species === 'skeleton' || species === 'creeper' ? 20 : info ? info.hp : 10;

    const m: Mob = {
      id: this.nextId++,
      species,
      group: g,
      legs,
      limbs,
      walk: Math.random() * Math.PI * 2,
      swing: 0,
      lastX: x,
      lastZ: z,
      head,
      woolCoat,
      collar,
      lid,
      jaw,
      tail,
      ears,
      core,
      extras,
      outfit,
      baseLegY,
      hp: maxHp,
      maxHp,
      state: species === 'dragon' ? 'circle' : 'wander',
      phaseTimer: 8 + this.rnd() * 6,
      timer: 1 + this.rnd() * 4,
      attack: 0,
      hurtTimer: 0,
      dir: this.rnd() * Math.PI * 2,
      speed: species === 'dragon' ? 9 : species === 'horse' ? 2.4 : species === 'shulker' ? 0 : species === 'chicken' ? 1.0 : info ? info.speed : 1.25,
      target: g.position.clone(),
      fuse: 0,
      wool: true,
      tamed: false,
      love: 0,
      egg: 20 + this.rnd() * 40,
      baby,
      grow: baby ? 120 : species === 'tadpole' ? 120 : 0,
      age: baby ? -120 : 0,
      breedCooldown: 0,
      saddled: undefined,
      saddle,
      leashed: false,
      leashPos: null,
      sitting: false,
      anger: 0,
      path: null,
      pathAt: 0,
      profession: 'none',
      level: 1,
      xp: 0,
      villager: species === 'villager' ? newVillager('unemployed') : species === 'wandering_trader' ? wanderingTrader(this.nextId * 977) : undefined,
      captain: false,
      raid: false,
      raidMember: false,
      vy: 0,
      lastNoise: null,
      tameTries: 0,
      barter: 0,
      zombify: (species === 'piglin' || species === 'piglin_brute' || species === 'hoglin') && this.host.dimension !== 'nether' ? 15 : 0,
      special: 0,
    };
    if (species === 'villager') {
      const prof = (['farmer', 'librarian', 'none', 'armorer', 'cleric', 'butcher', 'fletcher', 'none'] as Profession[])[Math.floor(this.rnd() * 8)];
      m.profession = prof;
      if (m.villager) m.villager.profession = prof === 'none' ? 'unemployed' : prof;
    }
    this.mobs.push(m);
    return m;
  }

  equipSaddle(m: Mob) {
    if (m.saddled) return;
    m.saddled = true;
    if (m.saddle) m.saddle.visible = true;
    else m.saddle = this.part(m.group, '#8c4f32', 0, m.species === 'horse' ? 1.25 : m.species === 'strider' ? 1.53 : 0.91, 0.08, 0.58, 0.12, 0.7);
  }

  clearSight(a: THREE.Vector3, b: THREE.Vector3) {
    const d = b.clone().sub(a), length = d.length();
    if (length <= 0.6) return true;
    d.normalize();
    for (let t = 0.3; t < length - 0.3; t += 0.3) {
      const p = a.clone().addScaledVector(d, t), id = this.host.getBlock(p.x, p.y, p.z);
      if (id > 0 && BLOCKS[id]?.solid) return false;
    }
    return true;
  }

  tieLeashes(x: number, y: number, z: number): number {
    let n = 0;
    for (const m of this.mobs) {
      if (m.leashed && !m.leashPos) {
        m.leashPos = [Math.floor(x), Math.floor(y), Math.floor(z)];
        n++;
      }
    }
    return n;
  }

  save(): MobSave[] {
    return this.mobs.map(m => ({
      id: m.id,
      raidMember: m.raidMember || m.raid,
      species: m.species,
      position: m.group.position.toArray() as [number, number, number],
      hp: m.hp,
      baby: m.baby,
      age: m.age ?? 0,
      grow: m.grow,
      tamed: m.tamed,
      saddled: !!m.saddled,
      sitting: !!m.sitting,
      leashed: !!m.leashed,
      leashPos: m.leashPos ?? null,
      wool: m.wool,
      breedCooldown: m.breedCooldown ?? 0,
      love: m.love,
      profession: m.profession,
      level: m.level,
      xp: m.xp,
      villager: m.villager ? structuredClone(m.villager) : undefined,
      charged: m.charged ? true : undefined,
      extra: this.behaviors.saveExtra(m),
    }));
  }

  load(data: MobSave[]) {
    this.clear();
    for (const s of data) {
      if (!SPECIES.includes(s.species) || !s.position.every(Number.isFinite)) continue;
      const m = this.spawn(s.species, s.position[0], s.position[2], s.baby, s.position[1]);
      if (!m) continue;
      m.id = s.id ?? m.id;
      this.nextId = Math.max(this.nextId, m.id + 1);
      m.raidMember = s.raidMember;
      m.raid = !!s.raidMember;
      Object.assign(m, {
        hp: Math.max(1, Math.min(m.maxHp, s.hp)),
        age: s.age,
        grow: s.grow ?? (s.baby ? 120 : 0),
        tamed: s.tamed,
        sitting: s.sitting,
        leashed: s.leashed,
        leashPos: s.leashPos ?? null,
        wool: s.wool,
        breedCooldown: s.breedCooldown,
        love: s.love,
        profession: s.profession ?? m.profession,
        level: s.level ?? m.level,
        xp: s.xp ?? m.xp,
        villager: s.villager ?? m.villager,
      });
      this.behaviors.loadExtra(m, s.extra);
      if (s.saddled) this.equipSaddle(m);
      if (s.charged || m.charged) this.chargeCreeper(m);
      if (m.collar) m.collar.visible = s.tamed;
      if (m.woolCoat) m.woolCoat.visible = s.wool;
    }
    if (this.host.dimension === 'end' && !this.host.dragonDefeated) {
      for (const p of endPillars()) this.spawnCrystal(p.x, p.h + 2, p.z);
    }
  }

  spawnCrystal(x: number, y: number, z: number) {
    const group = new THREE.Group();
    group.position.set(x + 0.5, y, z + 0.5);
    const base = new THREE.Mesh(this.box, this.mat('#352d42'));
    base.scale.set(0.85, 0.25, 0.85);
    base.position.y = 0.125;
    const core = new THREE.Mesh(this.box, this.glowMat('#eb52eb', 1));
    core.scale.set(0.6, 0.6, 0.6);
    core.position.y = 1.05;
    const shell = new THREE.Mesh(this.box, this.glowMat('#ffc9ff', 0.45));
    shell.scale.set(0.85, 0.85, 0.85);
    shell.position.y = 1.05;
    group.add(base, core, shell);
    this.scene.add(group);
    this.crystals.push({ group, core, shell, pos: group.position });
  }

  populate() {
    this.clear();
    if (this.host.dimension === 'overworld') {
      const p = this.host.position;
      const list: Species[] = ['cow', 'pig', 'sheep', 'chicken', 'cow', 'sheep', 'villager', 'villager', 'wolf', 'cat', 'horse', 'bee', 'rabbit', 'fox'];
      for (let i = 0; i < list.length; i++) {
        const a = i * 2.15, r = 6 + i * 1.55;
        this.spawn(list[i], p.x + Math.cos(a) * r, p.z + Math.sin(a) * r);
      }
      for (const [x, z] of [[15, 5], [19, -8], [5, 20]]) this.spawn('fish', x, z);
      const biome = this.host.terrain.biome(p.x, p.z);
      const extra: Species[] = biome.includes('jungle') ? ['panda', 'parrot', 'ocelot'] : biome.includes('snow') || biome.includes('frozen') ? ['polar_bear', 'snow_golem'] : biome.includes('savanna') ? ['llama', 'donkey', 'armadillo'] : biome.includes('desert') ? ['camel'] : biome.includes('swamp') ? ['frog', 'tadpole'] : biome === 'mushroom_fields' ? ['mooshroom', 'mooshroom'] : biome.includes('peaks') || biome.includes('slopes') || biome.includes('meadow') ? ['goat', 'goat'] : ['donkey'];
      extra.forEach((sp, i) => this.spawn(sp, p.x + Math.cos(i * 1.9 + 1) * 14, p.z + Math.sin(i * 1.9 + 1) * 14));
    } else if (this.host.dimension === 'nether') {
      for (const [sp, x, y, z] of [
        ['ghast', 18, 36, -15], ['ghast', -22, 39, 14],
        ['blaze', 35, 27, 35], ['blaze', 39, 27, 39], ['blaze', 34, 27, 41],
        ['wither_skeleton', 32, 27, 34], ['wither_skeleton', 38, 27, 36],
        ['magma_cube', 14, 26, 8], ['enderman', -14, 26, -12],
        ['piglin', 8, 26, 14], ['piglin', 11, 26, 16], ['hoglin', -8, 26, 18], ['zombified_piglin', 20, 26, 4], ['strider', 0, 32, 30],
      ] as [Species, number, number, number][]) {
        this.spawn(sp, x, z, false, y);
      }
    } else if (this.host.dimension === 'end') {
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        this.spawn('enderman', Math.cos(a) * 18, Math.sin(a) * 18, false, 28);
      }
      for (const [sx, sy, sz] of [[515, 28, 10], [523, 35, 16], [519, 49, 13], [534, 42, -10]]) {
        this.spawn('shulker', sx, sz, false, sy);
      }
      if (!this.host.dragonDefeated) {
        for (const pil of endPillars()) {
          this.spawnCrystal(pil.x, pil.h + 2, pil.z);
        }
        this.spawn('dragon', 0, 0, false, 44);
      }
    }
  }

  clear() {
    for (const m of this.mobs) this.scene.remove(m.group);
    for (const c of this.crystals) this.scene.remove(c.group);
    for (const p of this.projectiles) this.scene.remove(p.mesh);
    this.mobs = [];
    this.crystals = [];
    this.projectiles = [];
    this.riding = null;
    this.activeVillager = null;
    this.beh?.reset();
    this.tradingMob = null;
  }

  getBossInfo(): BossInfo | null {
    if (this.raid) return { name: `Raid – wave ${this.raid.wave}/${this.raid.total}`, ja: `襲撃 – 第${this.raid.wave}波 / ${this.raid.total}`, hp: this.raid.alive, maxHp: Math.max(1, this.raid.alive, 8), color: '#c03a2b' };
    const warden = this.mobs.find(m => m.species === 'warden' && m.anger >= 80);
    if (warden) return { name: 'Warden', ja: 'ウォーデン', hp: warden.hp, maxHp: warden.maxHp, color: '#1b6a7a' };
    const boss = this.mobs.find(m => m.species === 'dragon' || m.species === 'wither' || m.species === 'warden');
    if (!boss) return null;
    const jaMap: Record<string, string> = { dragon: 'エンダードラゴン', wither: 'ウィザー', warden: 'ウォーデン' };
    return {
      name: boss.species === 'dragon' ? 'Ender Dragon' : boss.species.replace(/_/g, ' '),
      ja: jaMap[boss.species] ?? boss.species,
      hp: Math.max(0, Math.ceil(boss.hp)),
      maxHp: boss.maxHp,
      color: boss.species === 'dragon' ? '#c864e8' : '#7b8098',
      crystals: boss.species === 'dragon' ? this.crystals.length : 0,
    };
  }

  bossInfo(): BossInfo | null {
    if (this.raid) return this.getBossInfo();
    const boss = this.mobs.find(m => (m.species === 'dragon' || m.species === 'wither' || m.species === 'warden') && m.group.position.distanceTo(this.host.position) < 120);
    if (!boss) return null;
    const jaMap: Record<string, string> = { dragon: 'エンダードラゴン', wither: 'ウィザー', warden: 'ウォーデン' };
    return {
      name: boss.species === 'dragon' ? 'Ender Dragon' : boss.species.replace(/_/g, ' '),
      ja: jaMap[boss.species] ?? boss.species,
      hp: Math.max(0, Math.ceil(boss.hp)),
      maxHp: boss.maxHp,
      color: boss.species === 'dragon' ? '#c864e8' : '#7b8098',
      crystals: boss.species === 'dragon' ? this.crystals.length : 0,
    };
  }

  destroyCrystal(idx: number) {
    const c = this.crystals[idx];
    if (!c) return;
    const pos = c.pos.clone().add(new THREE.Vector3(0, 1, 0));
    this.scene.remove(c.group);
    this.crystals.splice(idx, 1);
    this.host.explode(pos, 3);
    this.host.particles.burst(pos, '#eb52eb', 28, 7);
    this.host.toast('エンドクリスタルを破壊しました！', 'End Crystal destroyed!');
  }

  hit(origin: THREE.Vector3, dir: THREE.Vector3, damage: number, critical = false) {
    for (let i = 0; i < this.crystals.length; i++) {
      const cpos = this.crystals[i].pos.clone().add(new THREE.Vector3(0, 1, 0));
      const v = cpos.sub(origin);
      const d = v.length();
      if (d < 6 && v.normalize().dot(dir) > 0.9) {
        this.destroyCrystal(i);
        return true;
      }
    }
    for (const p of this.projectiles) {
      if (p.kind === 'ghast_fireball') {
        const v = p.mesh.position.clone().sub(origin);
        if (v.length() < 5 && v.normalize().dot(dir) > 0.88) {
          p.v.copy(dir).multiplyScalar(18);
          this.host.sound('stone', p.mesh.position);
          return true;
        }
      }
    }

    let best: Mob | null = null, bestD = 6;
    for (const m of this.mobs) {
      const centerH = m.species === 'dragon' ? 1.5 : 0.9;
      const v = m.group.position.clone().add(new THREE.Vector3(0, centerH, 0)).sub(origin);
      const d = v.length();
      const dot = v.normalize().dot(dir);
      const reach = m.species === 'dragon' ? 7 : 5;
      const cone = m.species === 'dragon' ? 0.86 : 0.93;
      if (d < Math.min(bestD, reach) && dot > cone) {
        best = m;
        bestD = d;
      }
    }
    if (!best) return false;
    this.lastHit = best;
    let finalDamage = this.behaviors.modifyDamage(best, critical ? Math.ceil(damage * 1.5) : damage, true);
    if (best.species === 'armadillo') {
      if ((best.rolledUp ?? 0) > 0) finalDamage = Math.max(1, Math.floor(finalDamage * 0.35));
      best.rolledUp = 6;
    }
    if (finalDamage > 0 && this.beh.armorOf(best) > 0) {
      finalDamage = Math.max(1, Math.round(finalDamage * armorFactor(this.beh.armorOf(best))));
    }
    best.hp -= finalDamage;
    this.host.sound('hurt:' + best.species, best.group.position);
    best.hurtTimer = 0.24;
    this.setHurtTint(best, true);
    if (best.species !== 'dragon' && best.species !== 'shulker') {
      best.state = passive.has(best.species) && !neutral.has(best.species) ? 'flee' : 'chase';
      best.timer = 4;
      best.group.position.addScaledVector(dir, 0.5);
      this.provoke(best);
    }
    const center = best.group.position.clone().add(new THREE.Vector3(0, 1, 0));
    if (!critical) this.host.particles.burst(center, best.species === 'dragon' ? '#d966ff' : '#b65343', 10);
    if (critical) {
      this.host.particles.crit?.(center, 16);
      this.host.sound('critical', best.group.position);
    } else {
      this.host.sound('hurt', best.group.position);
    }
    if (best.hp <= 0) this.kill(best);
    return true;
  }

  kill(m: Mob) {
    this.behaviors.onDeath(m);
    this.beh.onKill(m);
    this.host.sound('death:' + m.species, m.group.position);
    if (m === this.riding) this.riding = null;
    if (m === this.activeVillager) this.activeVillager = null;
    if (m === this.tradingMob) this.tradingMob = null;
    if (m.captain) {
      this.badOmen = true;
      this.host.effect?.('bad_omen', 600, 0);
      this.host.toast('不吉な予感…（村に近づくと襲撃が起きる）', 'Bad Omen… (a raid starts near a village)');
      this.host.particles.drop(m.group.position.clone().add(new THREE.Vector3(0, 0.5, 0)), 'ominous_banner', 1, '#5a5a6a');
      const ob = ominousBottleStack(1 + Math.floor(this.rnd() * 5));
      this.host.particles.drop(m.group.position.clone().add(new THREE.Vector3(0, 0.5, 0)), ob.name, 1, '#3d4f8a', ob);
    }
    if (m.leashed) this.host.particles.drop(m.group.position.clone(), 'lead', 1, '#a8875a');
    if (m.saddled) this.host.particles.drop(m.group.position.clone(), 'saddle', 1, '#8b6547');
    if (m.species === 'evoker' && (m.raid || m.raidMember)) this.host.particles.drop(m.group.position.clone(), 'emerald', 2, '#69bd7c');
    // Slime and magma cube split into two smaller slimes when defeated
    if ((m.species === 'slime' || m.species === 'magma_cube') && !m.baby && m.group.scale.x > 0.65 && this.mobs.length < 36) {
      for (const s of [-0.6, 0.6]) {
        const child = this.spawn(m.species, m.group.position.x + s, m.group.position.z + s, true, m.group.position.y);
        if (child) { child.hp = child.maxHp = 4; }
      }
    }
    const [name, count0] = drops[m.species] ?? ['string', 0];
    const count = count0 + (this.looting > 0 && count0 > 0 ? Math.floor(Math.random() * (this.looting + 1)) : 0);
    if (count > 0 && resolve(name)) {
      this.host.particles.drop(m.group.position.clone().add(new THREE.Vector3(0, 0.5, 0)), name, count, resolve(name)?.color || '#b88b65');
    }
    this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 0.8, 0)), m.species === 'dragon' ? '#e599ff' : '#d7d0b8', m.species === 'dragon' ? 60 : 18, m.species === 'dragon' ? 9 : 4);
    this.scene.remove(m.group);
    this.mobs = this.mobs.filter(x => x !== m);
    this.host.addXp?.(m.species === 'dragon' ? 100 : m.species === 'wither' ? 50 : passive.has(m.species) ? 3 : 6);
    if (m.species === 'dragon') {
      this.host.onDragonDefeated();
    }
  }

  private provoke(m: Mob) {
    if (m === this.riding) return;
    if (m.species === 'warden') { m.anger = 150; m.lastNoise = this.host.position.clone(); return; }
    const group = m.species === 'zombified_piglin' || m.species === 'piglin' || m.species === 'wolf' || m.species === 'bee' || m.species === 'polar_bear' || m.species === 'panda' || m.species === 'iron_golem' || m.species === 'llama' || m.species === 'goat';
    if (neutral.has(m.species) || m.species === 'piglin' || m.species === 'piglin_brute') {
      if (m.tamed) return;
      m.anger = 25;
      if (group) for (const o of this.mobs) if (o !== m && o.species === m.species && !o.tamed && o.group.position.distanceTo(m.group.position) < 16) { o.anger = 25; o.state = 'chase'; }
    }
    if (m.species === 'llama' && m.anger > 0) {
      this.launchProjectile('snowball', m.group.position.clone().add(new THREE.Vector3(0, 1.4, 0)), this.host.camera.position.clone().sub(m.group.position).normalize(), 12, undefined, { color: '#9fbf5a' });
    }
  }

  damageMob(m: Mob, damage: number, dir?: THREE.Vector3, critical = false) {
    if ((m as any).warmupTicks && (m as any).warmupTicks > 0) return;
    let finalDamage = this.behaviors.modifyDamage(m, critical ? Math.ceil(damage * 1.5) : damage, false);
    if (finalDamage > 0 && this.beh.armorOf(m) > 0) {
      finalDamage = Math.max(1, Math.round(finalDamage * armorFactor(this.beh.armorOf(m))));
    }
    this.host.sound('hurt:' + m.species, m.group.position);
    m.hp -= finalDamage;
    m.hurtTimer = 0.24;
    this.setHurtTint(m, true);
    if (m.species !== 'dragon' && m.species !== 'shulker') {
      m.state = passive.has(m.species) ? 'flee' : 'chase';
      m.timer = 4;
      if (dir) m.group.position.addScaledVector(dir, 0.5);
    }
    const center = m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0));
    this.host.particles.burst(center, m.species === 'dragon' ? '#d966ff' : '#c74c3c', critical ? 16 : 8);
    if (critical) this.host.particles.crit?.(center, 12);
    this.host.sound(critical ? 'critical' : 'hurt', m.group.position);
    if (m.species === 'wither') (m as any).witherArmor = m.hp <= m.maxHp * 0.5;
    if (m.hp <= 0) this.kill(m);
  }

  activeVillager: Mob | null = null;
  tradingMob: Mob | null = null;
  riding: Mob | null = null;
  heroTimer = 0;
  badOmen = false;
  raid: RaidState | null = null;
  private leashLine: THREE.LineSegments | null = null;
  private playerSpeed = 0;
  private lastPlayerPos = new THREE.Vector3();
  private leashGeo = new THREE.BufferGeometry();

  pick(origin: THREE.Vector3, dir: THREE.Vector3, reach = 4.6): Mob | null {
    let best: Mob | null = null, bestD = reach;
    for (const m of this.mobs) {
      if (m === this.riding) continue;
      const center = m.group.position.clone().add(new THREE.Vector3(0, 0.8 * m.group.scale.y, 0));
      const v = center.clone().sub(origin);
      const d = v.length();
      if (d > bestD || v.normalize().dot(dir) < 0.88 || !this.clearSight(origin, center)) continue;
      best = m; bestD = d;
    }
    return best;
  }

  interact(origin: THREE.Vector3, dir: THREE.Vector3, item: string, crouching = false): boolean | 'consume' {
    const m = this.pick(origin, dir);
    if (!m) return false;
    const sp = m.species, pos = m.group.position;
    const consume = (): true => {
      this.host.consume?.(item, 1);
      return true;
    };
    const hearts = () => this.host.particles.burst(pos.clone().add(new THREE.Vector3(0, 1.3 * m.group.scale.y, 0)), '#d85b65', 8, 1);
    const smoke = () => this.host.particles.burst(pos.clone().add(new THREE.Vector3(0, 1.0, 0)), '#777777', 8, 1);
    const special = this.behaviors.interact(m, item);
    if (special !== null) return special === 'consume' ? consume() : special;

    // Villager / Wandering Trader trading
    if (sp === 'villager' || sp === 'wandering_trader') {
      if (m.baby) return true;
      this.activeVillager = m;
      this.tradingMob = m;
      m.state = 'trade'; m.timer = 6;
      this.host.openTrade(m);
      return true;
    }
    // Zombie Villager curing with Golden Apple
    if (sp === 'zombie_villager' && (item === 'golden_apple' || item === 'enchanted_golden_apple')) {
      this.replaceSpecies(m, 'villager');
      m.profession = 'farmer';
      m.villager = newVillager('farmer');
      this.host.toast('村人ゾンビを治療しました！', 'Cured Zombie Villager!');
      this.host.sound('levelup', pos);
      return consume();
    }
    // Leads: attach / detach
    if (item === 'lead' && LEASHABLE.has(sp)) {
      if (m.leashed) {
        m.leashed = false; m.leashPos = null;
        this.host.addItem('lead', 1);
        this.host.sound('wood', pos);
        return true;
      }
      m.leashed = true; m.leashPos = null; m.sitting = false;
      this.host.sound('wood', pos);
      return consume();
    }
    if (m.leashed && item !== 'lead') {
      m.leashed = false; m.leashPos = null;
      this.host.addItem('lead', 1);
      this.host.sound('wood', pos);
      return true;
    }
    // Piglins barter for gold ingots (120 ticks = 6.0s for adult piglins)
    if (sp === 'piglin' && item === 'gold_ingot' && !m.baby) {
      m.barter = 6.0; m.state = 'graze'; m.timer = 6.5; m.anger = 0;
      this.host.sound('xp', pos);
      return consume();
    }
    // Taming with food (wolves, cats, ocelots, parrots) before breeding
    const tame = TAME_FOOD[sp];
    if (tame && !m.tamed && tame.items.includes(item)) {
      if (this.rnd() < 0.45) this.tame(m); else smoke();
      return consume();
    }
    // Breeding food & pet healing
    const food = BREED_FOOD[sp];
    if (food && food.includes(item)) {
      if (m.baby) {
        m.grow = Math.max(0, m.grow - 12);
        if (m.age !== undefined) m.age = Math.min(0, m.age * 0.9);
        hearts();
        return consume();
      }
      if (m.tamed && m.hp < m.maxHp && (sp === 'wolf' || sp === 'cat')) {
        m.hp = Math.min(m.maxHp, m.hp + 4);
        hearts();
        return consume();
      }
      if (RIDE_TAME.has(sp) && !m.tamed) {
        m.tameTries++; hearts();
        if (this.rnd() < 0.35 * m.tameTries) this.tame(m);
        return consume();
      }
      if (m.breedCooldown > 0 || m.love > 0) return false;
      if ((sp === 'wolf' || sp === 'cat') && !m.tamed) return false;
      m.love = 30; m.state = 'follow'; m.sitting = false; hearts();
      this.host.sound('eat', pos);
      return consume();
    }
    // Tadpole fed slime_ball grows faster into a frog
    if (sp === 'tadpole' && item === 'slime_ball') {
      m.grow = Math.max(0, m.grow - 30);
      if (m.grow <= 0) this.replaceSpecies(m, 'frog');
      else hearts();
      return consume();
    }
    // Saddles
    if (item === 'saddle' && SADDLEABLE.has(sp) && !m.baby) {
      if (RIDE_TAME.has(sp) && !m.tamed) {
        this.host.toast('空の手で、先に馬を手懐けましょう', 'Tame the horse with an empty hand first');
        return true;
      }
      if (!m.saddled) {
        this.equipSaddle(m);
        this.host.sound('wood', pos);
        return consume();
      }
      this.mount(m);
      return true;
    }
    // Milking / stew / shearing / scute brushing
    if ((sp === 'cow' || sp === 'mooshroom' || sp === 'goat') && item === 'bucket') {
      this.host.addItem('milk_bucket', 1);
      this.host.sound('water', pos);
      return consume();
    }
    if (sp === 'mooshroom' && item === 'bowl') {
      this.host.addItem('mushroom_stew', 1);
      return consume();
    }
    if (sp === 'mooshroom' && item === 'shears') {
      this.replaceSpecies(m, 'cow');
      this.host.particles.drop(pos.clone(), 'red_mushroom', 5, '#c43a2e');
      return true;
    }
    if (sp === 'sheep' && item === 'shears' && m.wool) {
      m.wool = false; if (m.woolCoat) m.woolCoat.visible = false;
      this.host.addItem('white_wool', 1 + Math.floor(this.rnd() * 3));
      this.host.sound('grass', pos);
      return true;
    }
    if (sp === 'bogged' && item === 'shears' && !m.shearedHead) {
      m.shearedHead = true;
      this.host.particles.drop(pos.clone(), 'red_mushroom', 2, '#c43a2e');
      this.host.sound('grass', pos);
      return true;
    }
    if (sp === 'armadillo' && (item === 'shears' || item === 'stick')) {
      this.host.particles.drop(pos.clone().add(new THREE.Vector3(0, 0.4, 0)), 'scute', 1, '#b07a6a');
      this.host.sound('wood', pos);
      return true;
    }
    if (sp === 'snow_golem' && item === 'shears' && !m.shearedHead) {
      m.shearedHead = true;
      this.host.particles.drop(pos.clone().add(new THREE.Vector3(0, 1.5, 0)), 'carved_pumpkin', 1, '#d87a22');
      return true;
    }
    // Tamed pets sit / stand
    if (m.tamed && (sp === 'wolf' || sp === 'cat' || sp === 'parrot' || sp === 'ocelot')) {
      m.sitting = !m.sitting;
      m.state = m.sitting ? 'graze' : 'follow';
      this.host.toast(m.sitting ? 'おすわり' : 'ついてくる', m.sitting ? 'Sitting' : 'Following');
      return true;
    }
    // Untamed horse/steed taming with empty hand, or mounting saddled mounts
    if (!crouching && (SADDLEABLE.has(sp) || RIDE_TAME.has(sp)) && !m.baby) {
      if (RIDE_TAME.has(sp) && !m.tamed) {
        m.tameTries++;
        if (this.rnd() < 0.35 + m.tameTries * 0.15) {
          this.tame(m);
        } else {
          smoke();
          this.host.toast('振り落とされた！もう一度乗ってみよう', 'Bucked off! Try again');
        }
        return true;
      }
      if ((sp === 'pig' || sp === 'strider') && !m.saddled) return false;
      this.mount(m);
      return true;
    }
    if (sp === 'allay' && item) { m.tamed = true; hearts(); return true; }
    return false;
  }

  private tame(m: Mob) {
    m.tamed = true; m.state = 'follow'; m.sitting = false; m.anger = 0;
    if (m.collar) m.collar.visible = true;
    this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0)), '#e84a5f', 14, 1.5);
    const ja = NEW_SPECIES[m.species]?.ja ?? ({ wolf: 'オオカミ', cat: 'ネコ', horse: 'ウマ' } as Record<string, string>)[m.species] ?? m.species;
    this.host.toast(`${ja}が懐きました！`, `${m.species.replace(/_/g, ' ')} tamed!`);
  }

  replaceSpecies(m: Mob, to: Species) {
    const { g, legs, head, woolCoat, collar, limbs, saddle, lid, jaw, tail, ears, core, extras, outfit, baseLegY } = this.model(to);
    g.position.copy(m.group.position); g.rotation.y = m.group.rotation.y; g.scale.copy(m.group.scale);
    this.scene.remove(m.group); this.scene.add(g);
    m.group = g; m.legs = legs; m.head = head; m.woolCoat = woolCoat; m.collar = collar; m.limbs = limbs; m.saddle = saddle; m.lid = lid; m.jaw = jaw; m.tail = tail; m.ears = ears; m.core = core; m.extras = extras; m.outfit = outfit; m.outfitKey = undefined; m.baseLegY = baseLegY; m.species = to; m.zombify = 0;
    m.maxHp = NEW_SPECIES[to]?.hp ?? m.maxHp; m.hp = Math.min(m.hp, m.maxHp);
    this.host.particles.burst(g.position.clone().add(new THREE.Vector3(0, 1, 0)), '#9bd36a', 12, 1);
  }

  // ------------------------------------------------------------------ riding

  mount(m: Mob) {
    this.riding = m; m.state = 'wander'; m.sitting = false; m.leashed = false; m.leashPos = null;
    if (RIDE_TAME.has(m.species) && !m.tamed) m.special = 2 + this.rnd() * 3;
    this.host.sound('wood', m.group.position);
  }

  dismount(): THREE.Vector3 | null {
    const m = this.riding; if (!m) return null;
    this.riding = null;
    const out = m.group.position.clone(); out.x += Math.cos(m.dir) * 1.0; out.z -= Math.sin(m.dir) * 1.0; out.y += 0.2;
    return out;
  }

  drive(dt: number, input: DriveInput, holdingCarrot: boolean): THREE.Vector3 | null {
    const m = this.riding; if (!m) return null;
    const r = RIDE[m.species] ?? { seat: 1.2, speed: 0, jump: 0 };
    const controllable = m.species === 'pig' || m.species === 'strider' ? holdingCarrot : m.tamed;
    const fwd = -(input.move.x * Math.sin(input.yaw) + input.move.z * Math.cos(input.yaw));
    const strafe = input.move.x * Math.cos(input.yaw) - input.move.z * Math.sin(input.yaw);
    let move = 0;
    if (controllable && (Math.abs(fwd) > 0.1 || Math.abs(strafe) > 0.1)) {
      m.dir = Math.atan2(-input.move.x, -input.move.z);
      move = r.speed * (input.run ? 1 : 0.7) * Math.min(1, Math.hypot(fwd, strafe));
    } else if (!controllable && m.species !== 'pig' && m.species !== 'strider') {
      if (m.timer <= 0) { m.timer = 1 + this.rnd() * 2; m.dir = this.rnd() * 6.28; }
      move = m.speed;
      m.special -= dt;
      if (m.special <= 0) {
        m.tameTries++;
        if (this.rnd() < 0.2 + m.tameTries * 0.15) { this.tame(m); }
        else {
          this.riding = null;
          this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 1.2, 0)), '#777777', 8, 1);
          this.host.toast('振り落とされた！', 'Bucked off!');
          return null;
        }
      }
    }
    if (input.ascend && r.jump > 0 && m.vy === 0 && controllable) { m.vy = 7 * r.jump * 0.7; }
    this.walk(m, move, dt, true);
    m.group.rotation.y = m.dir;
    const seatY = r.seat * m.group.scale.y;
    return new THREE.Vector3(m.group.position.x, m.group.position.y + seatY + 0.5 - 1.62 + 0.25, m.group.position.z);
  }

  // ------------------------------------------------------------------ villagers & raids

  tradeOffers(): Offer[] {
    const m = this.activeVillager ?? this.tradingMob;
    if (!m) return [];
    if (m.species === 'wandering_trader') return TRADER_OFFERS;
    const discount = this.heroTimer > 0 ? 0.7 : 1;
    if (m.villager) {
      m.villager.profession = m.profession === 'none' ? 'unemployed' : m.profession;
      m.villager.level = m.level;
      m.villager.xp = m.xp;
    }
    const list = [...(TRADES[m.profession] ?? []), ...(this.host.mapOffers?.(m) ?? [])];
    return list.filter(o => o.level <= m.level).map(o => {
      const demandAdd = m.villager?.demand?.[o.id] ?? 0;
      const baseCost = Math.max(1, o.n + demandAdd);
      const finalN = o.give === 'emerald' ? Math.max(1, Math.round(baseCost * discount)) : baseCost;
      return { ...o, n: finalN, cost: finalN };
    });
  }

  tradeTitle(): { ja: string; en: string } {
    const m = this.activeVillager ?? this.tradingMob;
    if (!m) return { ja: '取引', en: 'Trade' };
    if (m.species === 'wandering_trader') return { ja: '行商人', en: 'WANDERING TRADER' };
    return { ja: `${PROFESSION_JA[m.profession]} · ${LEVEL_JA[m.level]}`, en: `${m.profession.toUpperCase()} · ${LEVEL_NAMES[m.level].toUpperCase()}` };
  }

  recordTrade(offer: Offer) {
    const m = this.activeVillager ?? this.tradingMob;
    if (!m || m.species !== 'villager') return;
    m.xp += offer.xp;
    if (m.villager) {
      addTradeXp(m.villager, { ...offer, uses: m.villager.uses[offer.id] ?? 0, max: offer.maxUses, demand: 0 });
    }
    if (m.level < 5 && m.xp >= LEVEL_XP[m.level + 1]) {
      m.level++;
      if (m.villager) m.villager.level = m.level;
      this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 1.8, 0)), '#8ad4ff', 14, 1.5);
      this.host.toast(`村人が${LEVEL_JA[m.level]}にレベルアップしました`, `Villager is now ${LEVEL_NAMES[m.level]}`);
    }
  }

  private tickJobs(m: Mob) {
    if (m.baby) return;
    if (m.profession !== 'none' && m.profession !== 'unemployed') return;
    const p = m.group.position, bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z);
    for (let i = 0; i < 40; i++) {
      const x = bx + Math.floor((this.rnd() - 0.5) * 16), y = by + Math.floor((this.rnd() - 0.5) * 6), z = bz + Math.floor((this.rnd() - 0.5) * 16);
      const name = BLOCKS[this.host.getBlock(x, y, z)]?.name;
      const job: Profession | undefined = name ? JOB_SITES[name] : undefined;
      if (!job) continue;
      if (this.mobs.some(o => o !== m && o.species === 'villager' && o.profession === job && o.group.position.distanceTo(new THREE.Vector3(x, y, z)) < 8)) continue;
      m.profession = job; m.level = 1; m.xp = 0;
      if (m.villager) { m.villager.profession = job; m.villager.job = { x, y, z }; m.villager.level = 1; m.villager.xp = 0; }
      this.host.particles.burst(p.clone().add(new THREE.Vector3(0, 1.8, 0)), '#8ad4ff', 10, 1);
      this.host.toast(`村人が${PROFESSION_JA[job]}になりました`, `A villager became a ${job}`);
      return;
    }
  }

  startRaid(center?: THREE.Vector3): boolean {
    if (this.raid) return false;
    let cVec = center;
    if (!cVec) {
      const village = this.mobs.find(m => m.species === 'villager' && m.group.position.distanceTo(this.host.position) < 40);
      if (!village) return false;
      cVec = village.group.position;
    }
    const d = this.host.difficulty?.();
    const total = !d ? 3 : d === 'easy' ? 3 : d === 'hard' ? 7 : 5;
    this.raid = {
      wave: 0,
      total,
      alive: 0,
      timer: 4,
      delay: 4,
      center: [cVec.x, cVec.y, cVec.z],
      members: [],
    };
    this.badOmen = false;
    this.host.toast('襲撃が始まった！', 'Raid incoming!');
    this.host.sound('thunder');
    return true;
  }

  private tickRaid(dt: number, peaceful: boolean) {
    const r = this.raid; if (!r) return;
    if (peaceful) { this.raid = null; return; }
    const activeRaiders = this.mobs.filter(m => m.raid || m.raidMember || r.members.includes(m.id));
    r.alive = activeRaiders.length;
    r.members = activeRaiders.map(m => m.id);
    if (r.alive > 0) { r.timer = 4; r.delay = 4; return; }
    r.timer -= dt;
    r.delay = r.timer;
    if (r.timer > 0) return;
    if (r.wave >= r.total) {
      this.raid = null;
      this.heroTimer = 600;
      this.host.effect?.('hero_of_the_village', 600, 0);
      this.host.addItem('emerald', 5);
      this.host.toast('襲撃を撃退した！ 村の英雄（取引割引）', 'Raid defeated! Hero of the Village');
      this.host.addXp?.(30);
      return;
    }
    r.wave++;
    r.timer = 4;
    r.delay = 4;
    r.members = [];
    const [cx, , cz] = r.center;
    if (!this.host.difficulty && r.total === 3) {
      const table: Species[] = r.wave === 1 ? ['pillager', 'pillager', 'vindicator'] : r.wave === 2 ? ['pillager', 'vindicator', 'vindicator', 'ravager'] : ['evoker', 'pillager', 'vindicator', 'ravager', 'witch'];
      table.forEach((sp, i) => {
        const a = i * 1.2 + r.wave, x = cx + Math.cos(a) * 18, z = cz + Math.sin(a) * 18;
        const m = this.spawn(sp, x, z, false, this.host.terrain.height(x, z) + 1);
        if (m) { m.raid = true; m.raidMember = true; m.state = 'chase'; if (i === 0 && sp === 'pillager') m.captain = true; r.members.push(m.id); }
      });
    } else {
      const wave = RAID_WAVES[Math.min(RAID_WAVES.length - 1, r.wave - 1)];
      const a0 = this.rnd() * 6.28;
      let i = 0;
      for (const [sp, n] of Object.entries(wave)) for (let k = 0; k < n; k++) {
        const a = a0 + (i++) * 0.35, dist = 22 + this.rnd() * 6;
        const rx = cx + Math.cos(a) * dist, rz = cz + Math.sin(a) * dist;
        const m = this.spawn(sp as Species, rx, rz, false, this.host.terrain.height(rx, rz) + 1);
        if (m) { m.raid = true; m.raidMember = true; m.state = 'chase'; if (i === 1 && sp === 'pillager') m.captain = true; r.members.push(m.id); }
      }
    }
    r.alive = r.members.length;
    this.host.toast(`襲撃 第${r.wave}/${r.total}波`, `Raid wave ${r.wave}/${r.total}`);
    this.host.sound('thunder');
  }

  noise(x: number, y: number, z: number, strength = 1) {
    this.host.onVibration?.(x, y, z, strength);
    for (const m of this.mobs) {
      if (m.species !== 'warden') continue;
      const d = m.group.position.distanceTo(new THREE.Vector3(x, y, z));
      if (d > 16) continue;
      m.anger = Math.min(150, m.anger + 35 * strength);
      m.lastNoise = new THREE.Vector3(x, y, z);
      m.timer = Math.min(m.timer, 0.3);
    }
  }

  vibrate(p: THREE.Vector3) {
    this.noise(p.x, p.y, p.z, 1);
  }

  summonWarden(x: number, y: number, z: number) {
    if (this.mobs.some(m => m.species === 'warden' && m.group.position.distanceTo(new THREE.Vector3(x, y, z)) < 48)) return;
    const a = this.rnd() * 6.28, m = this.spawn('warden', x + Math.cos(a) * 5, z + Math.sin(a) * 5, false, y);
    if (m) {
      m.anger = 60; m.special = 3;
      this.host.particles.burst(m.group.position.clone(), '#0f4a58', 40, 4);
      this.host.sound('thunder');
      this.host.toast('ウォーデンが現れた…', 'The Warden emerges…');
    }
  }

  lastHit: Mob | null = null;
  looting = 0;

  hurtNear(pos: THREE.Vector3, r: number, damage: number, exclude?: Mob | null) {
    let n = 0;
    for (const m of [...this.mobs]) { if (m === exclude || m.group.position.distanceTo(pos) > r) continue; this.damageMob(m, damage); n++; }
    return n;
  }

  extraDamage(m: Mob, damage: number) { if (damage > 0 && this.mobs.includes(m)) this.damageMob(m, damage); }
  isHostile(m: Mob) { return !passive.has(m.species) && !m.tamed; }

  nearestHostile(pos: THREE.Vector3, r: number): Mob | null {
    let best: Mob | null = null, bestD = r;
    for (const m of this.mobs) { if (passive.has(m.species)) continue; const d = m.group.position.distanceTo(pos); if (d < bestD) { bestD = d; best = m; } }
    return best;
  }

  shoot(m: Mob) {
    const from = m.group.position.clone().add(new THREE.Vector3(0, m.species === 'dragon' ? 1.8 : 1.4, 0));
    if (!this.clearSight(from, this.host.camera.position)) return;
    const kind = m.species === 'ghast' || m.species === 'wither' ? 'ghast_fireball'
      : m.species === 'blaze' ? 'blaze_fireball'
      : m.species === 'dragon' ? 'dragon_fireball'
      : m.species === 'shulker' ? 'shulker_bullet'
      : m.species === 'breeze' ? 'wind_charge'
      : 'mob_arrow';
    const effect: [string, number] | undefined = m.species === 'stray' ? ['slowness', 15] : m.species === 'bogged' ? ['poison', 5] : undefined;
    this.launchProjectile(
      kind,
      from,
      this.host.camera.position.clone().sub(from).normalize(),
      kind === 'mob_arrow' || kind === 'wind_charge' ? 14 : kind === 'dragon_fireball' ? 12 : 9,
      undefined,
      { effect },
    );
    this.host.sound('bow', m.group.position);
  }

  shootPlayerArrow(origin: THREE.Vector3, dir: THREE.Vector3, speed = 26, damage = 7, extra: { flame?: boolean; punch?: number; pierce?: number; recover?: string } = {}) {
    this.launchProjectile('player_arrow', origin.clone().addScaledVector(dir, 0.7), dir, speed, undefined, { damage, gravity: 6, ...extra });
    this.host.sound('bow');
  }

  update(dt: number, daylight: number, peaceful: boolean) {
    const now = performance.now();
    this.timeline += dt;
    this.chargedAuraMat.uniforms.uTime.value = this.timeline;
    this.updateCrystals(dt);
    this.updateProjectiles(dt);
    this.beh.update(dt);
    this.jobTimer += dt;
    if (this.jobTimer > 4) {
      this.jobTimer = 0;
      const occupied = new Set<string>();
      for (const m of this.mobs) {
        if (m.villager) {
          updateJob(m.villager, this.host, m.group.position, occupied);
          if (m.villager.profession !== 'unemployed' && m.villager.profession !== 'none') m.profession = m.villager.profession;
        }
      }
    }

    this.spawnTimer += dt;
    if (this.spawnTimer > 8 && this.mobs.length < 24) {
      this.spawnTimer = 0;
      const a = this.rnd() * 6.28, r = 18 + this.rnd() * 15;
      const x = this.host.position.x + Math.cos(a) * r, z = this.host.position.z + Math.sin(a) * r;
      const biome = this.host.terrain.biome(x, z);
      if (this.host.dimension === 'overworld') {
        if (biome !== 'mushroom_fields' && !peaceful && daylight < 0.25) {
          const h = this.host.terrain.height(x, z);
          let list: Species[] = ['zombie', 'skeleton', 'creeper', 'spider', 'enderman', 'zombie_villager', 'breeze'];
          if (biome.includes('desert')) list = ['husk', 'husk', 'skeleton', 'creeper', 'spider'];
          else if (biome.includes('snow') || biome.includes('frozen') || biome.includes('ice')) list = ['stray', 'stray', 'zombie', 'creeper', 'spider'];
          else if (biome.includes('swamp')) list = ['bogged', 'slime', 'witch', 'zombie', 'creeper'];
          if (h < SEA_LEVEL - 1) list = ['drowned', 'drowned', 'squid', 'glow_squid', 'salmon', 'tropical_fish', 'pufferfish'];
          if (biome.includes('ocean') && h < SEA_LEVEL - 12 && this.rnd() < 0.2) list = ['guardian'];
          if ((this.host.insomnia?.() ?? 0) > 180 && this.rnd() < 0.3) this.spawn('phantom', x, z, false, this.host.position.y + 18 + this.rnd() * 6);
          else {
            const sp = list[Math.floor(this.rnd() * list.length)];
            if (swimmers.has(sp) || sp === 'drowned') this.spawn(sp, x, z, false, h + 1 < SEA_LEVEL ? h + 1 : undefined);
            else this.spawn(sp, x, z);
          }
        } else if (biome !== 'mushroom_fields' && !peaceful && daylight >= 0.25 && this.rnd() < 0.05 && !this.raid) {
          for (let i = 0; i < 4; i++) { const m = this.spawn(i === 3 ? 'vindicator' : 'pillager', x + i, z + (i % 2)); if (m && i === 0) m.captain = true; }
        } else if (daylight >= 0.4 && this.mobs.filter(m => passive.has(m.species)).length < 14) {
          const table: Record<string, Species[]> = {
            jungle: ['parrot', 'panda', 'ocelot', 'chicken'],
            snowy: ['polar_bear', 'rabbit', 'fox', 'snow_golem'],
            frozen: ['polar_bear', 'snow_golem'],
            savanna: ['llama', 'donkey', 'armadillo', 'horse', 'cow'],
            desert: ['camel', 'rabbit'],
            swamp: ['frog', 'tadpole', 'slime'],
            mushroom_fields: ['mooshroom'],
            peaks: ['goat'],
            slopes: ['goat'],
            meadow: ['sheep', 'donkey', 'mule', 'rabbit'],
            plains: ['horse', 'donkey', 'mule', 'cow', 'sheep', 'pig'],
            taiga: ['fox', 'wolf', 'rabbit'],
            forest: ['cow', 'pig', 'sheep', 'chicken', 'wolf'],
          };
          const k = Object.keys(table).find(k => biome.includes(k)) ?? 'forest';
          const list = table[k];
          if (this.rnd() < 0.02) this.spawn('wandering_trader', x, z);
          else this.spawn(list[Math.floor(this.rnd() * list.length)], x, z);
        }
      } else if (this.host.dimension === 'nether' && !peaceful) {
        const table: Record<string, Species[]> = {
          nether_wastes: ['ghast', 'magma_cube', 'enderman', 'zombified_piglin', 'zombified_piglin', 'piglin', 'strider'],
          soul_sand_valley: ['skeleton', 'wither_skeleton', 'ghast', 'enderman', 'strider'],
          crimson_forest: ['piglin', 'piglin', 'hoglin', 'hoglin', 'zombified_piglin', 'piglin_brute'],
          warped_forest: ['enderman', 'strider'],
          basalt_deltas: ['ghast', 'magma_cube', 'strider'],
        };
        const list = table[biome] ?? ['magma_cube'];
        this.spawn(list[Math.floor(this.rnd() * list.length)], x, z);
      }
    }

    const currentDay = Math.floor((this.timeline + (this.host.time ?? 0) * 1200) / 240);
    for (let idx = this.mobs.length - 1; idx >= 0; idx--) {
      const m = this.mobs[idx];
      const hostile = !passive.has(m.species) && m.species !== 'iron_golem';
      if (hostile && this.host.dimension === 'overworld' && this.host.terrain.biome(m.group.position.x, m.group.position.z) === 'mushroom_fields') {
        this.scene.remove(m.group);
        this.mobs.splice(idx, 1);
        continue;
      }
      if (peaceful && hostile) {
        this.scene.remove(m.group);
        this.mobs.splice(idx, 1);
        continue;
      }

      if (m.hurtTimer > 0) {
        m.hurtTimer -= dt;
        if (m.hurtTimer <= 0) this.setHurtTint(m, false);
      }

      m.timer -= dt;
      m.attack -= dt;
      m.love = Math.max(0, m.love - dt);
      m.breedCooldown = Math.max(0, m.breedCooldown - dt);
      if (m.rolledUp && m.rolledUp > 0) m.rolledUp = Math.max(0, m.rolledUp - dt);

      const baseScale = NEW_SPECIES[m.species]?.scale ?? (m.species === 'enderman' ? 1.45 : m.species === 'iron_golem' ? 1.3 : 1);
      if (m.baby) {
        if (m.age !== undefined && m.age < 0) {
          m.age = Math.min(0, m.age + dt);
          m.grow = Math.max(0, -m.age);
          if (m.age >= 0) {
            m.baby = false;
            m.grow = 0;
            m.group.scale.setScalar(baseScale);
          }
        } else {
          m.grow -= dt;
          const sc = 0.5 + 0.5 * (1 - Math.max(0, m.grow) / 120);
          m.group.scale.setScalar(sc * baseScale);
          if (m.grow <= 0) {
            m.baby = false;
            m.group.scale.setScalar(baseScale);
          }
        }
      } else if (m.species === 'tadpole' && m.grow > 0) {
        m.grow -= dt;
        if (m.grow <= 0) this.replaceSpecies(m, 'frog');
      }

      if (m.zombify > 0 && this.host.dimension !== 'nether') {
        m.zombify -= dt;
        if (m.zombify <= 0) this.replaceSpecies(m, m.species === 'hoglin' ? 'zoglin' : 'zombified_piglin');
      }
      this.beh.curBonus = this.beh.bonusOf(m);
      if (m.species === 'villager') {
        if (this.beh.sleepTick(m, dt, daylight)) continue;
        this.beh.panicTick(m, dt);
        m.special -= dt;
        if (m.special <= 0) { m.special = 6 + this.rnd() * 4; this.tickJobs(m); }
        if (m.villager && daylight > 0.3) {
          restockVillager(m.villager, currentDay);
          tickVillager(m.villager, dt);
        }
      }
      if (this.beh.canLoot(m)) this.beh.lootTick(m, dt);
      if (m === this.riding) continue;

      this.attacker = m;
      const tx = this.host.position.x - m.group.position.x;
      const ty = this.host.position.y - m.group.position.y;
      const tz = this.host.position.z - m.group.position.z;
      const dist = Math.hypot(tx, ty, tz);

      // Undead burn in sunlight (unless in water)
      const burns = m.species === 'zombie' || m.species === 'skeleton' || NEW_SPECIES[m.species]?.burnsInSun;
      if (this.host.dimension === 'overworld' && daylight > 0.58 && burns && this.host.getBlock(m.group.position.x, m.group.position.y, m.group.position.z) !== ID.water) {
        if (m.attack <= 0 && m.hurtTimer <= 0) {
          this._tmpB.copy(m.group.position); this._tmpB.y += 1.4;
          this.host.particles.spark?.(this._tmpB, '#ff9436', 4);
          m.hp -= 2;
          m.hurtTimer = 0.2;
          this.setHurtTint(m, true);
          m.attack = 1.6;
          if (m.hp <= 0) { this.kill(m); continue; }
        }
      }

      let move = 0;

      if (this.behaviors.pre(m, dt, daylight)) {
        if (this.mobs[idx] === m) {
          m.group.rotation.y = m.dir;
          if (dist > 95 && !m.tamed && !m.leashed) { this.scene.remove(m.group); this.mobs.splice(idx, 1); }
        } else idx = Math.min(idx, this.mobs.length);
        continue;
      }

      if (m.species === 'dragon') {
        m.phaseTimer -= dt;
        if (m.phaseTimer <= 0) {
          if (m.state === 'circle') { m.state = 'charge'; m.phaseTimer = 3.5; }
          else if (m.state === 'charge') { m.state = 'perch'; m.phaseTimer = 6; }
          else { m.state = 'circle'; m.phaseTimer = 9 + this.rnd() * 5; }
        }
        const center = m.state === 'perch';
        const targetX = center ? 0 : Math.cos(now * 0.0004 + m.id) * 18;
        const targetZ = center ? 0 : Math.sin(now * 0.0004 + m.id) * 18;
        const targetY = center ? 31 : m.state === 'charge' ? this.host.position.y + 4 : 36 + Math.sin(now * 0.001) * 3;
        const tx2 = m.state === 'charge' ? this.host.position.x : targetX;
        const tz2 = m.state === 'charge' ? this.host.position.z : targetZ;
        const vx = tx2 - m.group.position.x, vz = tz2 - m.group.position.z;
        m.dir = Math.atan2(-vx, -vz);
        const speed = m.state === 'charge' ? 1.9 : m.state === 'perch' ? 1.4 : 0.75;
        m.group.position.x += vx * dt * speed;
        m.group.position.z += vz * dt * speed;
        m.group.position.y += (targetY - m.group.position.y) * Math.min(1, dt * (m.state === 'charge' ? 2.5 : 1.2));
        m.group.rotation.y = m.dir;
        if (!peaceful && m.attack <= 0 && dist < 26 && m.state !== 'perch') { this.shoot(m); m.attack = m.state === 'charge' ? 2.2 : 4; }
        if (!peaceful && m.state === 'perch' && dist < 4.5 && m.attack <= 0) { this.host.damage(6); m.attack = 1.5; }
        if (this.crystals.length && m.hp < m.maxHp) m.hp = Math.min(m.maxHp, m.hp + dt * 1.5);
        continue;
      }

      if (m.species === 'shulker') {
        m.dir = Math.atan2(-tx, -tz);
        const open = Math.sin(this.timeline * 1.1 + m.id) > 0.15;
        if (m.lid) {
          const targetLift = open ? 0.84 : 0.48;
          m.lid.position.y += (targetLift - m.lid.position.y) * Math.min(1, dt * 6);
          if (Math.abs(targetLift - m.lid.position.y) > 0.03) m.lid.rotation.y += dt * 3.2;
          else m.lid.rotation.y *= Math.max(0, 1 - dt * 6);
        }
        if (!peaceful && open && dist < 18 && m.attack <= 0) { this.shoot(m); m.attack = 2.6; }
        continue;
      }

      if (swimmers.has(m.species) || m.species === 'turtle') {
        m.dir += Math.sin(m.timer) * dt * 0.4;
        move = m.speed * 0.85;
        if (m.species === 'pufferfish') {
          const nearPlayer = !peaceful && dist < 3.5;
          m.group.scale.setScalar(baseScale * (nearPlayer ? 1.65 : 1));
          if (nearPlayer && m.attack <= 0) {
            this.host.damage(1);
            this.host.effect?.('poison', 7, 0);
            m.attack = 1.5;
          }
        }
      } else if (m.species === 'bee' || m.species === 'blaze' || m.species === 'ghast' || m.species === 'wither' || m.species === 'bat') {
        m.dir += Math.sin(m.timer * 1.4) * dt * 0.6;
        move = 1.1;
        const baseY = this.host.terrain.height(m.group.position.x, m.group.position.z) + (m.species === 'wither' ? 3.5 : 2.3);
        m.group.position.y += (baseY + Math.sin(now * 0.004 + m.id) * 0.35 - m.group.position.y) * Math.min(1, dt * 4);
        if (!peaceful && (m.species === 'blaze' || m.species === 'ghast' || m.species === 'wither') && dist < (m.species === 'ghast' || m.species === 'wither' ? 26 : 18)) {
          m.dir = Math.atan2(-tx, -tz);
          if (m.attack <= 0) { this.shoot(m); m.attack = m.species === 'ghast' ? 3.2 : 2.2; }
        }
      } else if (m.species === 'creeper' && dist < 12 && !peaceful) {
        m.state = dist < 2.8 ? 'fuse' : 'chase';
        if (m.state === 'fuse') {
          if (m.fuse === 0) this.host.sound('fuse', m.group.position);
          m.fuse += dt;
          const s = 1 + m.fuse * 0.2 + Math.sin(m.fuse * 26) * 0.05;
          m.group.scale.set(s, s, s);
          if (m.fuse > 1.5) {
            this.behaviors.creeperExplode(m);
            this.scene.remove(m.group);
            this.mobs = this.mobs.filter(x => x !== m);
            idx = Math.min(idx, this.mobs.length);
            continue;
          }
        } else {
          m.fuse = Math.max(0, m.fuse - dt);
          m.group.scale.set(1, 1, 1);
          m.dir = Math.atan2(-tx, -tz);
          move = 1.6;
        }
      } else if (m.species === 'skeleton' && dist < 16 * (this.host.visibility?.() ?? 1) && !peaceful) {
        m.state = 'aim';
        m.dir = Math.atan2(-tx, -tz);
        move = dist < 6 ? -1 : dist > 10 ? 1 : 0;
        if (m.attack <= 0) { this.shoot(m); m.attack = 2.2; }
      } else if ((m.species === 'zombie' || m.species === 'zombie_villager' || m.species === 'spider') && dist < 16 * (this.host.visibility?.() ?? 1) && !peaceful) {
        m.state = 'chase';
        m.dir = Math.atan2(-tx, -tz);
        move = m.species === 'spider' ? 2.4 : 1.65;
        if (dist < 1.6 && m.attack <= 0) { this.host.damage(3); m.attack = 1.0; }
      } else if (m.species === 'enderman') {
        this.host.camera.getWorldDirection(this._look);
        if (dist > 0 && (tx * this._look.x + ty * this._look.y + tz * this._look.z) / dist > 0.985 && dist < 22) m.state = 'teleport';
        if (m.state === 'teleport' && m.timer <= 0) {
          const a = this.rnd() * 6.28;
          m.group.position.x = this.host.position.x + Math.cos(a) * 6;
          m.group.position.z = this.host.position.z + Math.sin(a) * 6;
          m.timer = 3;
          this.host.particles.burst(m.group.position, '#a780cf', 18);
          m.state = 'chase';
        }
        if (m.state === 'chase') {
          m.dir = Math.atan2(-tx, -tz); move = 2.5;
          if (dist < 1.6 && m.attack <= 0) { this.host.damage(5); m.attack = 1; }
        }
      } else if (m.species === 'iron_golem') {
        const enemy = this.mobs.find(x => x !== m && !passive.has(x.species) && x.species !== 'iron_golem' && x.group.position.distanceTo(m.group.position) < 10);
        if (enemy) {
          const vx = enemy.group.position.x - m.group.position.x, vz = enemy.group.position.z - m.group.position.z;
          m.dir = Math.atan2(-vx, -vz); move = 1.5; m.state = 'chase';
          if (Math.hypot(vx, vz) < 2 && m.attack <= 0) { enemy.hp -= 15; m.attack = 1; if (enemy.hp <= 0) this.kill(enemy); }
        }
      }

      const special = this.specialAI(m, dt, dist, tx, ty, tz, peaceful, daylight);
      if (special !== null) move = special;

      // Tamed wolves defend their owner by attacking lastHit or nearby hostiles
      if (m.species === 'wolf' && m.tamed && !m.sitting) {
        const foe = (this.lastHit && this.lastHit !== m && this.mobs.includes(this.lastHit) && !this.lastHit.tamed && this.lastHit.group.position.distanceTo(m.group.position) < 16)
          ? this.lastHit
          : null;
        if (foe) {
          const fp = foe.group.position, d = fp.distanceTo(m.group.position);
          m.state = 'chase';
          m.dir = Math.atan2(-(fp.x - m.group.position.x), -(fp.z - m.group.position.z));
          move = m.speed * 2.1;
          if (d < 1.7 && m.attack <= 0) { m.attack = 1.0; this.damageMob(foe, 4); }
        }
      }

      // Snow Golem throws snowballs at hostile mobs
      if (m.species === 'snow_golem') {
        const foe = this.mobs.find(x => x !== m && !passive.has(x.species) && x.group.position.distanceTo(m.group.position) < 12);
        if (foe) {
          const fp = foe.group.position;
          m.dir = Math.atan2(-(fp.x - m.group.position.x), -(fp.z - m.group.position.z));
          if (m.attack <= 0) {
            m.attack = 1.5;
            const from = m.group.position.clone().add(new THREE.Vector3(0, 1.4, 0));
            this.launchProjectile('snowball', from, fp.clone().add(new THREE.Vector3(0, 0.9, 0)).sub(from).normalize(), 14);
            this.host.sound('bow', m.group.position);
          }
        }
      }

      if (m.state === 'wander' || m.state === 'graze' || m.state === 'follow') {
        const pet = m.species === 'wolf' || m.species === 'cat' || m.species === 'parrot' || m.species === 'ocelot' || m.species === 'allay';
        const anchor = m.leashPos ? new THREE.Vector3(m.leashPos[0] + 0.5, m.leashPos[1], m.leashPos[2] + 0.5) : this.host.position;
        const anchorDist = m.group.position.distanceTo(anchor);
        if (m.sitting) {
          m.state = 'graze';
          move = 0;
        } else if (m.tamed && pet && !m.leashed) {
          m.state = 'follow';
          if (dist > 14) {
            m.group.position.set(this.host.position.x + 1.5, this.host.position.y, this.host.position.z + 1.5);
            m.path = null;
          }
        } else if (m.leashed && anchorDist > 5) {
          m.state = 'follow';
        } else if (m.timer <= 0 || (m.state === 'follow' && m.love <= 0 && !m.tamed && !m.leashed)) {
          m.timer = 2 + this.rnd() * 5;
          m.dir = this.rnd() * 6.28;
          m.state = this.rnd() < 0.35 ? 'graze' : 'wander';
        }
        if (!m.sitting) {
          move = m.state === 'graze' ? 0 : m.speed;
          if (m.state === 'follow') {
            const dx = anchor.x - m.group.position.x, dz = anchor.z - m.group.position.z;
            if (anchorDist > 3) {
              m.dir = Math.atan2(-dx, -dz);
              move = m.speed * (m.leashed ? 1.8 : 1.4);
            } else {
              move = 0;
            }
          }
        }
        if (m.leashed && anchorDist > 12) {
          if (m.leashPos) {
            m.leashed = false; m.leashPos = null;
            this.host.particles.drop(m.group.position.clone(), 'lead', 1, '#a8875a');
          } else {
            m.group.position.x = this.host.position.x + tx * -0.4;
            m.group.position.z = this.host.position.z + tz * -0.4;
            m.path = null;
          }
        }
      }
      if (m.state === 'flee') { move = m.speed * 2.4; if (m.timer <= 0) m.state = 'wander'; }
      if (m.rolledUp && m.rolledUp > 0) move = 0;

      // Animals in love walk towards a nearby mate and breed when close
      if (m.love > 0 && !m.baby) {
        const mate = this.mobs.find(x => x !== m && x.species === m.species && x.love > 0 && !x.baby && x.group.position.distanceTo(m.group.position) < 12);
        if (mate) {
          const md = mate.group.position.distanceTo(m.group.position);
          if (md < 3) {
            m.love = 0; mate.love = 0; m.breedCooldown = 300; mate.breedCooldown = 300; m.state = 'wander'; mate.state = 'wander';
            const child = m.species === 'turtle' ? null : this.spawn(m.species, m.group.position.x + 1, m.group.position.z, true, m.group.position.y);
            if (m.species === 'turtle') m.pregnant = true;
            if (child && m.species === 'villager') child.profession = 'none';
            this.host.addXp?.(1 + Math.floor(this.rnd() * 7));
            this._tmpB.copy(m.group.position); this._tmpB.y += 1;
            this.host.particles.burst(this._tmpB, '#e47b83', 12, 1);
          } else {
            m.state = 'follow';
            m.dir = Math.atan2(-(mate.group.position.x - m.group.position.x), -(mate.group.position.z - m.group.position.z));
            move = m.speed * 1.25;
          }
        }
      }

      if (move > 0 && (m.state === 'chase' || m.state === 'follow') && !flyers.has(m.species) && !swimmers.has(m.species)) {
        const goal = m.species === 'warden' && m.anger < 80 && m.lastNoise ? m.lastNoise : this.host.position;
        if (!this.beh.approachClimb(m, goal)) this.steer(m, goal);
      }
      this.walk(m, move, dt, false);

      m.group.rotation.y = m.dir;

      if (m.species === 'chicken') {
        m.egg -= dt;
        if (m.egg <= 0) { m.egg = 30; this.host.particles.drop(m.group.position.clone(), 'egg', 1, '#e6dfcb'); }
      }
      if (m.species === 'sheep' && !m.wool && m.timer > 10) {
        m.wool = true;
        if (m.woolCoat) m.woolCoat.visible = true;
      }
      if (dist > 95 && !m.tamed && !m.leashed && !m.raid && !m.raidMember && !(m as MobX).structure && !(m as MobX).gear) {
        this.scene.remove(m.group);
        this.mobs.splice(idx, 1);
      }
    }
    this.beh.curBonus = 0;

    this.animateMobs(dt, now);
    this.heroTimer = Math.max(0, this.heroTimer - dt);
    this.tickRaid(dt, peaceful);
    if (this.badOmen && !this.raid && this.mobs.some(m => m.species === 'villager' && m.group.position.distanceTo(this.host.position) < 24)) {
      this.startRaid(this.host.position);
    }
    this.playerSpeed = dt > 0 ? this.host.position.distanceTo(this.lastPlayerPos) / dt : 0;
    this.lastPlayerPos.copy(this.host.position);

    const pts: THREE.Vector3[] = [];
    for (const m of this.mobs) {
      if (m.leashed) {
        const start = m.leashPos
          ? new THREE.Vector3(m.leashPos[0] + 0.5, m.leashPos[1] + 0.5, m.leashPos[2] + 0.5)
          : this.host.camera.position.clone().add(new THREE.Vector3(0, -0.4, 0));
        pts.push(start, m.group.position.clone().add(new THREE.Vector3(0, 0.8 * m.group.scale.y, 0)));
      }
    }
    if (pts.length) {
      if (!this.leashLine) {
        this.leashLine = new THREE.LineSegments(this.leashGeo, new THREE.LineBasicMaterial({ color: '#8a6b3f' }));
        this.scene.add(this.leashLine);
      }
      this.leashGeo.setFromPoints(pts);
      this.leashGeo.computeBoundingSphere();
    } else if (this.leashLine) {
      this.scene.remove(this.leashLine);
      this.leashLine = null;
    }

    for (let i = this.arrows.length - 1; i >= 0; i--) {
      const a = this.arrows[i];
      a.life -= dt;
      a.v.y -= 8.5 * dt;
      a.mesh.position.addScaledVector(a.v, dt);
      this._tmpA.copy(a.mesh.position).add(a.v);
      a.mesh.lookAt(this._tmpA);

      if (!a.fromPlayer) {
        if (a.mesh.position.distanceTo(this.host.camera.position) < 0.85) {
          this.host.damage(a.damage);
          a.life = 0;
        }
      } else {
        for (const m of this.mobs) {
          this._tmpB.copy(m.group.position);
          this._tmpB.y += m.species === 'dragon' ? 1.5 : 0.9;
          if (a.mesh.position.distanceTo(this._tmpB) < (m.species === 'dragon' ? 2.2 : 1.05)) {
            if (this.behaviors.dodgeProjectile(m)) continue;
            this.damageMob(m, a.damage, this._tmpA.copy(a.v).normalize(), true);
            a.life = 0;
            break;
          }
        }
      }

      if (a.life <= 0 || this.host.getBlock(a.mesh.position.x, a.mesh.position.y, a.mesh.position.z) > 0) {
        this.scene.remove(a.mesh);
        this.arrows.splice(i, 1);
      }
    }
  }

  private getBlockFor(m: Mob) {
    const strider = m.species === 'strider';
    return (x: number, y: number, z: number) => {
      const id = this.host.getBlock(x, y, z);
      return strider && id === ID.lava ? ID.stone : id;
    };
  }

  private steer(m: Mob, goal: THREE.Vector3) {
    const p = m.group.position, get = this.getBlockFor(m);
    if (!m.path || this.timeline - m.pathAt > 0.8) {
      m.pathAt = this.timeline;
      const ax = p.x - Math.sin(m.dir) * 1.1, az = p.z - Math.cos(m.dir) * 1.1;
      const gy = groundAt(get, Math.floor(ax), Math.floor(p.y + 0.01), Math.floor(az), 3);
      const blocked = Number.isNaN(gy) || gy - p.y > 1.2 || Math.abs(goal.y - p.y) > 1.5;
      m.path = blocked && p.distanceTo(goal) < 40 ? findPath(get, p.x, p.y, p.z, goal.x, goal.y, goal.z, 550) : null;
    }
    if (m.path && m.path.length) {
      const wp = m.path[0], dx = wp.x - p.x, dz = wp.z - p.z, hd = Math.hypot(dx, dz);
      if (hd < 0.35 && Math.abs(wp.y - p.y) < 1.2) m.path.shift();
      else {
        m.dir = Math.atan2(-dx, -dz);
        if (wp.y > p.y + 0.6 && m.vy === 0 && hd < 0.9) m.vy = 7;
      }
    }
  }

  /** 3D aquatic swimming in real water columns, preventing fish from clipping underground. */
  private swim(m: Mob, move: number, dt: number) {
    const p = m.group.position, isWater = (x: number, y: number, z: number) => this.host.getBlock(x, y, z) === ID.water;
    const nx = p.x - Math.sin(m.dir) * move * dt, nz = p.z - Math.cos(m.dir) * move * dt;
    if (!isWater(p.x, p.y, p.z) && !isWater(p.x, p.y - 0.6, p.z)) {
      if (this.host.getBlock(nx, p.y, nz) <= 0) { p.x = nx; p.z = nz; }
      if (this.host.dimension === 'overworld' && p.y > SEA_LEVEL - 1 && this.host.terrain.height(p.x, p.z) < SEA_LEVEL - 1) {
        p.y = Math.max(SEA_LEVEL - 1.5, p.y - 3 * dt);
      }
      return;
    }
    let ny = p.y + Math.sin(m.timer * 0.9 + m.id * 1.7) * 0.5 * dt;
    if (!isWater(p.x, ny + 0.5, p.z)) ny = p.y - 0.8 * dt;
    if (!isWater(p.x, ny - 0.3, p.z) && isWater(p.x, ny + 0.3, p.z)) ny = p.y + 0.6 * dt;
    if (isWater(nx, ny, nz)) {
      p.x = nx; p.z = nz; p.y = ny;
    } else {
      m.dir += Math.PI * (0.5 + this.rnd() * 0.5);
    }
  }

  walk(m: Mob, move: number, dt: number, ridden: boolean) {
    if (this.beh.climb(m, move, dt)) return;
    const p = m.group.position, sp = m.species;
    if (flyers.has(sp)) {
      if (move) {
        const nx = p.x - Math.sin(m.dir) * move * dt, nz = p.z - Math.cos(m.dir) * move * dt;
        if (this.host.getBlock(nx, p.y + 0.3, nz) <= 0) { p.x = nx; p.z = nz; } else m.dir += Math.PI * 0.5;
      }
      return;
    }
    if (swimmers.has(sp)) {
      if (move) this.swim(m, move, dt);
      return;
    }
    const get = this.getBlockFor(m);
    if (m.vy !== 0) { p.y += m.vy * dt; m.vy -= 24 * dt; }
    const nx = move ? p.x - Math.sin(m.dir) * move * dt : p.x, nz = move ? p.z - Math.cos(m.dir) * move * dt : p.z;
    const gy = groundAt(get, Math.floor(nx), Math.floor(p.y + 0.01), Math.floor(nz), 4);
    if (Number.isNaN(gy)) {
      if (move) { m.dir += Math.PI * 0.5 + (this.rnd() - 0.5); m.path = null; }
      if (m.vy === 0 && groundAt(get, Math.floor(p.x), Math.floor(p.y + 0.01), Math.floor(p.z), 4) !== p.y) m.vy = -0.01;
      return;
    }
    const climb = gy - p.y;
    if (climb > 1.15 && m.vy <= 0) {
      if (climb <= 2.2 && (ridden || m.state === 'chase' || m.state === 'follow') && m.vy === 0) m.vy = 7.2;
      else if (move) { m.dir += Math.PI * 0.5 + (this.rnd() - 0.5); m.path = null; }
      return;
    }
    if (climb < -3.2 && !ridden) {
      if (move) { m.dir += Math.PI * 0.5 + (this.rnd() - 0.5); m.path = null; }
      return;
    }
    const water = get(Math.floor(nx), Math.floor(gy), Math.floor(nz)) === ID.water || get(Math.floor(nx), Math.floor(gy) - 1, Math.floor(nz)) === ID.water;
    if (water && !ridden && sp !== 'drowned' && sp !== 'frog' && sp !== 'polar_bear' && sp !== 'turtle' && m.state !== 'follow' && m.state !== 'chase') {
      m.dir += Math.PI * 0.5; m.path = null;
      return;
    }
    p.x = nx; p.z = nz;
    if (m.vy > 0) return;
    if (m.vy < 0) { if (p.y <= gy) { p.y = gy; m.vy = 0; } return; }
    if (p.y > gy + 0.6) { m.vy = -0.01; return; }
    p.y += (gy - p.y) * Math.min(1, dt * 10);
  }

  private specialAI(m: Mob, dt: number, dist: number, tx: number, ty: number, tz: number, peaceful: boolean, daylight: number): number | null {
    const sp = m.species, p = m.group.position, host = this.host, vis = host.visibility?.() ?? 1;
    void ty;
    const face = () => { m.dir = Math.atan2(-tx, -tz); };
    const melee = (range: number, dmg: number, speed: number, cd = 1.1, onHit?: () => void) => {
      if (peaceful || dist > range * vis) { if (m.state === 'chase') m.state = 'wander'; return null; }
      m.state = 'chase'; face();
      if (dist < 1.9 * Math.max(1, m.group.scale.x) && m.attack <= 0) { host.damage(dmg); m.attack = cd; onHit?.(); }
      return speed;
    };
    const ranged = (range: number, cd: number) => {
      if (peaceful || dist > range * vis) { if (m.state === 'aim') m.state = 'wander'; return null; }
      m.state = 'aim'; face();
      if (m.attack <= 0) { this.shoot(m); m.attack = cd; }
      return dist < 6 ? -1 : dist > 10 ? 1 : 0;
    };
    m.anger = Math.max(0, m.anger - dt);
    switch (sp) {
      case 'husk': return melee(16, 3, 1.5, 1.1, () => host.effect?.('hunger', 7));
      case 'drowned': return melee(16, 3, host.getBlock(p.x, p.y, p.z) === ID.water ? 2.4 : 1.4);
      case 'wither_skeleton': return melee(18, 8, 1.7, 1.0, () => host.effect?.('wither', 8));
      case 'vindicator': return melee(18, 7, 1.9);
      case 'piglin_brute': return melee(18, 10, 1.5, 1.3);
      case 'piglin': {
        if (m.barter > 0) {
          m.barter -= dt; face();
          if (m.barter <= 0) {
            const reward = rollPiglinBarter(this.rnd);
            host.particles.drop(p.clone().add(new THREE.Vector3(0, 1, 0)), reward.name, reward.count, resolve(reward.name)?.color ?? '#c9b98a', reward);
          }
          return 0;
        }
        if ((host.wearingGold?.() || host.goldArmor?.()) && m.anger <= 0) return null;
        return melee(16, 5, 1.6);
      }
      case 'zombified_piglin': return m.anger > 0 ? melee(24, 8, 1.7) : null;
      case 'hoglin': case 'zoglin': return melee(14, 6, 1.8, 1.2, () => { host.levitate(0.15); });
      case 'ravager': return melee(22, 12, 2.0, 1.6);
      case 'silverfish': return melee(10, 1, 2.4, 0.7);
      case 'endermite': return melee(10, 2, 2.0, 0.8);
      case 'cave_spider': return melee(14, 2, 2.6, 1.0, () => host.effect?.('poison', 7));
      case 'slime': case 'magma_cube': {
        if (peaceful || dist > 14) return null;
        m.special -= dt;
        if (m.special < -0.5) m.special = 0.9 + this.rnd() * 0.5;
        const hop = m.special < 0;
        const base = NEW_SPECIES[sp]?.scale ?? (m.baby ? 0.5 : 1);
        m.group.scale.y = base * (hop ? 1.15 : 0.85);
        const s = melee(14, sp === 'slime' ? 2 : 3, 2.1, 1.2);
        return hop ? s : 0;
      }
      case 'breeze': {
        if (peaceful || dist > 18) return null;
        m.state = 'aim'; face();
        const baseY = host.terrain.height(p.x, p.z) + 2.0 + Math.abs(Math.sin(this.timeline * 2.5 + m.id)) * 1.8;
        p.y += (baseY - p.y) * Math.min(1, dt * 4);
        if (m.attack <= 0) { this.shoot(m); m.attack = 2.0; }
        return dist < 5 ? -2.0 : dist > 10 ? 2.2 : 0.8;
      }
      case 'polar_bear': case 'panda': return m.anger > 0 ? melee(20, 6, 1.6) : null;
      case 'goat': {
        if (m.anger > 0) return melee(16, 2, 3.0, 2.5, () => { m.anger = 0; });
        if (dist < 9 && m.attack <= 0 && this.rnd() < dt * 0.03) { m.anger = 4; }
        return null;
      }
      case 'llama': {
        if (m.anger > 0 && dist < 12 && m.attack <= 0) {
          face();
          this.launchProjectile('snowball', p.clone().add(new THREE.Vector3(0, 1.4, 0)), host.camera.position.clone().sub(p).normalize(), 12, undefined, { color: '#9fbf5a' });
          m.attack = 2;
        }
        return null;
      }
      case 'stray': case 'bogged': case 'pillager': return ranged(18, sp === 'pillager' ? 3 : 2.2);
      case 'witch': {
        if (peaceful || dist > 12) return null;
        m.state = 'aim'; face();
        if (m.attack <= 0) {
          m.attack = 3.2;
          const from = p.clone().add(new THREE.Vector3(0, 1.5, 0));
          this.launchProjectile('potion', from, host.camera.position.clone().sub(from).normalize(), 11, undefined, {
            color: '#8a4a9a',
            gravity: 6,
            onEnd: (at) => {
              if (at.distanceTo(host.position) < 3) {
                host.damage(2);
                host.effect?.(this.rnd() < 0.5 ? 'poison' : 'slowness', 6);
              }
            },
          });
        }
        return dist < 5 ? -1 : 0.6;
      }
      case 'evoker': {
        if (peaceful || dist > 16) return null;
        m.state = 'aim'; face();
        m.special -= dt;
        if (m.special <= 0) {
          m.special = 11;
          for (let i = 0; i < 3; i++) {
            const v = this.spawn('vex', p.x + (this.rnd() - 0.5) * 2, p.z + (this.rnd() - 0.5) * 2, false, p.y + 1.5);
            if (v) { v.raid = m.raid; v.raidMember = m.raidMember; v.fuse = 0; }
          }
          host.particles.burst(p.clone().add(new THREE.Vector3(0, 1.5, 0)), '#cfd4ff', 16, 2);
        } else if (dist < 6 && m.attack <= 0) {
          m.attack = 4; host.damage(6);
          host.particles.burst(host.position.clone(), '#5a4a3a', 12, 1.5);
        }
        return dist < 6 ? -1.2 : dist > 10 ? 1 : 0;
      }
      case 'vex': {
        m.fuse += dt; if (m.fuse > 45) { m.hp = 0; this.kill(m); return 0; }
        if (peaceful) return null;
        p.y += ((host.position.y + 1.2) - p.y) * Math.min(1, dt * 3);
        return melee(30, 5, 3.2, 1.0) ?? 1;
      }
      case 'phantom': {
        if (daylight > 0.6 && this.rnd() < dt * 0.5) { this.setHurtTint(m, true); m.hurtTimer = 0.2; }
        m.special -= dt;
        if (m.special <= -2.5) m.special = 6;
        if (m.special > 0) {
          const a = this.timeline * 0.9 + m.id;
          const gx = host.position.x + Math.cos(a) * 10, gz = host.position.z + Math.sin(a) * 10, gy = host.position.y + 14;
          m.dir = Math.atan2(-(gx - p.x), -(gz - p.z));
          p.y += (gy - p.y) * Math.min(1, dt * 1.5);
          m.state = 'circle';
          return 5;
        }
        m.state = 'charge'; face();
        p.y += ((host.position.y + 1) - p.y) * Math.min(1, dt * 2.5);
        if (dist < 1.6 && m.attack <= 0 && !peaceful) { host.damage(2); m.attack = 1.5; m.special = 6; }
        return 9;
      }
      case 'guardian': case 'elder_guardian': {
        if (peaceful || dist > 14) { m.special = 0; return null; }
        m.state = 'aim'; face();
        m.special += dt;
        host.particles.spark?.(p.clone().lerp(host.camera.position, Math.min(1, m.special / 2.5)), '#9fe8ff', 1);
        if (m.special >= 2.5) {
          m.special = 0;
          host.damage(sp === 'guardian' ? 6 : 8);
          if (sp === 'elder_guardian') host.effect?.('mining_fatigue', 60, 2);
        }
        return 0.4;
      }
      case 'warden': {
        const sneaky = host.sneaking?.() ?? false;
        (m as any).darkTimer = ((m as any).darkTimer ?? 0) - dt;
        if (!peaceful && dist <= 20 && (m as any).darkTimer <= 0) {
          (m as any).darkTimer = 6;
          host.effect?.('darkness', 12, 0);
        }
        const moving = host.playerMoving ? host.playerMoving() : this.playerSpeed > 1.6;
        if (dist < 16 && moving && !sneaky) {
          const loud = this.playerSpeed > 5 ? 35 : 28;
          m.anger = Math.min(150, m.anger + loud * dt);
          m.lastNoise = host.position.clone();
        }
        if (dist < 2.5 && !sneaky) { m.anger = 150; m.lastNoise = host.position.clone(); }
        m.fuse = m.anger > 0 ? 0 : m.fuse + dt;
        if (m.fuse > 60) {
          host.particles.burst(p.clone(), '#0f4a58', 30, 3);
          this.scene.remove(m.group);
          this.mobs.splice(this.mobs.indexOf(m), 1);
          return 0;
        }
        if (peaceful) return null;
        if (m.anger >= 80) {
          m.state = 'chase'; face();
          if (dist < 2.8 && m.attack <= 0) { host.damage(30); m.attack = 1.2; host.sound('explosion', p); }
          m.special -= dt;
          if (dist >= 4 && dist <= 15 && m.special <= 0 && m.attack <= 0) {
            m.special = 5; host.damage(10); host.sound('explosion', p);
            for (let i = 0; i < 10; i++) host.particles.spark?.(p.clone().add(new THREE.Vector3(0, 1.8, 0)).lerp(host.camera.position, i / 10), '#2fd0e0', 2);
          }
          return 1.9;
        }
        if (m.lastNoise && m.anger > 10) {
          const dx = m.lastNoise.x - p.x, dz = m.lastNoise.z - p.z;
          if (Math.hypot(dx, dz) < 1.5) { m.lastNoise = null; return 0; }
          m.state = 'chase'; m.dir = Math.atan2(-dx, -dz);
          return 1.2;
        }
        if (m.state === 'chase') m.state = 'wander';
        return null;
      }
      case 'strider': {
        if (host.getBlock(p.x, p.y - 0.5, p.z) !== ID.lava && host.getBlock(p.x, p.y - 1, p.z) !== ID.lava) m.group.scale.x = 0.95 + Math.sin(this.timeline * 30) * 0.04;
        else m.group.scale.x = 1;
        return null;
      }
      case 'frog': { if (m.vy === 0 && m.state === 'wander' && this.rnd() < dt * 0.4) m.vy = 5; return null; }
      case 'parrot': case 'allay': {
        p.y += ((groundAt(this.getBlockFor(m), Math.floor(p.x), Math.floor(p.y + 0.5), Math.floor(p.z), 3) || p.y) + (sp === 'allay' ? 1.3 : 0.1) - p.y) * Math.min(1, dt * 4);
        return null;
      }
      case 'wolf': { if (!m.tamed && m.anger > 0) return melee(16, 4, 2.0); return null; }
      case 'bee': { if (m.anger > 0) return melee(12, 2, 1.4, 1.5, () => { host.effect?.('poison', 5); m.anger = 0; }); return null; }
    }
    return null;
  }

  private animateMobs(dt: number, now: number) {
    const px = this.host.position.x, py = this.host.position.y + 1.5, pz = this.host.position.z;
    const norm = (a: number) => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; };
    for (const m of this.mobs) {
      if (m.outfit) this.syncVillagerOutfit(m);
      if (m.charged && m.aura) {
        m.aura.rotation.y = this.timeline * 1.8;
        const pulse = 1 + Math.sin(this.timeline * 6.5) * 0.045;
        m.aura.scale.set(0.76 * pulse, 1.78 * pulse, 0.72 * pulse);
      }
      const gx = m.group.position.x, gz = m.group.position.z;
      const speed = dt > 0 ? Math.hypot(gx - (m.lastX ?? gx), gz - (m.lastZ ?? gz)) / dt : 0;
      m.lastX = gx; m.lastZ = gz;
      const wants = m.sitting ? 0 : Math.max(0, Math.min(1, speed / 1.1));
      m.swing = (m.swing ?? 0) + (wants - (m.swing ?? 0)) * Math.min(1, dt * 9);
      const swing = m.swing ?? 0;
      if (speed > 0.05 && !m.sitting) m.walk = (m.walk ?? 0) + dt * (3.4 + Math.min(5, speed) * 2.4);
      const walk = m.walk ?? 0;
      const limbs = m.limbs ?? [];
      for (let li = 0; li < limbs.length; li++) {
        const limb = limbs[li];
        const n = limb.node;
        if (m.sitting && limb.kind === 'leg' && limbs.length === 4) {
          // Vanilla sitting pose for tamed Wolf / Cat / Ocelot: hind legs fold forward and lower
          const isHind = li === 1 || li === 3;
          n.rotation.x = isHind ? -1.25 : 0.15;
          if (m.baseLegY !== undefined) n.position.y = isHind ? m.baseLegY * 0.45 : m.baseLegY;
          continue;
        }
        if (m.baseLegY !== undefined && limb.kind === 'leg' && limbs.length === 4) {
          n.position.y = m.baseLegY;
        }
        if (limb.kind === 'spider') {
          n.rotation.y = limb.baseY + Math.sin(walk + limb.phase) * limb.amp * swing;
          n.rotation.z = limb.baseZ + Math.cos(walk + limb.phase) * limb.amp * 0.8 * swing;
        } else if (limb.kind === 'wing') {
          const flying = m.species === 'dragon' || m.species === 'bee' || m.species === 'ghast' || flyers.has(m.species);
          n.rotation.z = limb.baseZ + Math.sin(now * 0.02 + limb.phase) * limb.amp * (flying ? 1 : 0.25 + swing * 0.75);
        } else if (limb.kind === 'tentacle') {
          n.rotation.x = Math.sin(now * 0.0018 + limb.phase) * 0.24;
          n.rotation.z = Math.cos(now * 0.0014 + limb.phase) * 0.18;
        } else if (limb.kind === 'arm') {
          if (m.species === 'iron_golem' && m.attack > 0.5) {
            n.rotation.x = -1.55 * Math.sin(Math.min(1, (m.attack - 0.5) * 2) * Math.PI);
          } else if (m.species === 'vindicator' && m.state === 'chase' && li === 3) {
            n.rotation.x = -1.5 + Math.sin(walk) * 0.15;
          } else if (m.species === 'evoker' && m.state === 'aim') {
            n.rotation.x = -1.5 + Math.sin(now * 0.01 + limb.phase) * 0.15;
          } else {
            n.rotation.x = limb.baseX + Math.sin(walk + limb.phase) * limb.amp * swing;
          }
        } else {
          n.rotation.x = limb.baseX + Math.sin(walk + limb.phase) * limb.amp * swing;
        }
      }

      // Special Secondary Rig Animations (Enderman Jaw, Tail Wag, Warden Tendrils & Heart, Blaze Orbiting Rods)
      if (m.jaw) {
        if (m.species === 'enderman') {
          const scream = m.state === 'chase' || m.state === 'teleport';
          const targetY = scream ? 0.22 : 0;
          m.jaw.position.y += (targetY - m.jaw.position.y) * Math.min(1, dt * 10);
          m.head.position.x = scream ? Math.sin(now * 0.09) * 0.025 : 0;
        } else if (m.species === 'dragon') {
          m.jaw.rotation.x = 0.12 + Math.sin(now * 0.004) * 0.10;
        }
      }
      if (m.tail) {
        if (swimmers.has(m.species)) {
          m.tail.rotation.y = Math.sin(now * 0.012 + m.id) * 0.35;
        } else if (m.species === 'wolf') {
          m.tail.rotation.x = m.sitting ? 0.35 : m.tamed ? -0.25 + (1 - m.hp / m.maxHp) * 0.55 : 0.35;
          m.tail.rotation.y = Math.sin(now * 0.008 + m.id) * (m.tamed ? 0.25 : 0.08);
        } else if (m.species === 'fox' && m.state === 'graze' && speed < 0.05) {
          // Curled-up sleeping fox wraps its fluffy tail forward
          m.tail.rotation.y = 1.45;
          m.tail.rotation.x = -0.15;
        } else {
          m.tail.rotation.x = m.sitting ? 0.35 : 0;
          m.tail.rotation.y = Math.sin(now * 0.004 + m.id) * 0.18;
        }
      }
      if (m.ears && m.ears.length === 2) {
        const rate = m.species === 'warden' ? (0.004 + (m.anger / 150) * 0.018) : (0.003 + swing * 0.012);
        const amp = m.species === 'warden' ? (0.08 + (m.anger / 150) * 0.22) : (0.08 + swing * 0.18);
        m.ears[0].rotation.z = Math.sin(now * rate + m.id) * amp;
        m.ears[1].rotation.z = -Math.sin(now * rate + m.id) * amp;
      }
      if (m.core && m.species === 'warden') {
        const beat = 0.75 + 0.25 * Math.sin(now * (0.005 + (m.anger / 150) * 0.02));
        m.core.scale.set(0.36 * beat, 0.48 * beat, 0.08);
      }
      if (m.species === 'snow_golem' && m.lid) {
        m.lid.visible = !m.shearedHead;
      }
      if (m.extras) {
        if (m.species === 'blaze') {
          for (let i = 0; i < m.extras.length; i++) {
            const ring = Math.floor(i / 4);
            const dir = ring === 0 ? 0.0026 : ring === 1 ? -0.0038 : 0.0048;
            const a = (i % 4) * (Math.PI / 2) + ring * 0.4 + now * dir;
            const r = ring === 0 ? 0.56 : ring === 1 ? 0.40 : 0.25;
            const ry = ring === 0 ? 1.34 : ring === 1 ? 0.90 : 0.46;
            m.extras[i].position.set(Math.cos(a) * r, ry + Math.sin(now * 0.005 + i) * 0.06, Math.sin(a) * r);
          }
        } else if (m.species === 'breeze') {
          for (let i = 0; i < m.extras.length; i++) {
            m.extras[i].rotation.y = now * (i % 2 === 0 ? 0.009 : -0.012);
          }
        }
      }

      const h = m.head;
      const wantYaw = Math.atan2(-(px - gx), -(pz - gz)) - m.dir;
      const near = Math.hypot(px - gx, pz - gz) < 9;
      const targetYaw = near ? Math.max(-0.9, Math.min(0.9, norm(wantYaw))) : Math.sin(now * 0.0012 + m.id) * 0.12;
      const targetPitch = m.state === 'graze' && !m.sitting ? 0.55 + Math.sin(now * 0.0025 + m.id) * 0.08 : near ? Math.max(-0.35, Math.min(0.35, -(py - (m.group.position.y + 1.4)) * 0.2)) : Math.sin(now * 0.0017 + m.id) * 0.04;
      h.rotation.y += (targetYaw - h.rotation.y) * Math.min(1, dt * 5);
      h.rotation.x += (targetPitch - h.rotation.x) * Math.min(1, dt * 5);
    }
    this.attacker = null;
  }

  launchProjectile(
    kind: Projectile['kind'],
    origin: THREE.Vector3,
    dir: THREE.Vector3,
    speed: number,
    target?: THREE.Vector3,
    extra?: { damage?: number; gravity?: number; color?: string; onEnd?: (pos: THREE.Vector3) => void; flame?: boolean; punch?: number; effect?: [string, number]; pierce?: number; recover?: string },
  ) {
    const color = kind === 'ender_eye' ? '#59d98a' : kind === 'ender_pearl' ? '#2f8f83' : kind === 'snowball' ? '#f2f8ff'
      : kind === 'wind_charge' ? '#b8d8ff'
      : kind === 'shulker_bullet' ? '#c9b6e8' : kind.includes('fireball') ? '#ff8a2a' : '#d8d0b5';
    const glow = kind === 'ender_eye' || kind === 'shulker_bullet' || kind === 'wind_charge' || kind.includes('fireball');
    const mesh = new THREE.Mesh(this.box, glow ? this.glowMat(color, 1) : this.mat(extra?.color ?? color));
    const size = kind.includes('fireball') ? 0.32 : kind === 'wind_charge' ? 0.26 : kind === 'shulker_bullet' ? 0.16 : 0.14;
    mesh.scale.setScalar(size);
    mesh.position.copy(origin);
    this.scene.add(mesh);
    this.projectiles.push({
      kind,
      mesh,
      v: dir.clone().normalize().multiplyScalar(speed),
      life: 8,
      damage: extra?.damage ?? (kind === 'snowball' ? 0 : kind === 'wind_charge' ? 2 : kind.includes('fireball') ? 6 : kind === 'shulker_bullet' ? 4 : 3),
      target: target?.clone(),
      gravity: extra?.gravity,
      onEnd: extra?.onEnd,
      flame: extra?.flame,
      punch: extra?.punch,
      effect: extra?.effect,
      pierce: extra?.pierce,
      recover: extra?.recover,
    });
  }

  private _playerHead = new THREE.Vector3();

  private updateProjectiles(dt: number) {
    if (this.projectiles.length === 0) return;
    const playerHead = this._playerHead.set(this.host.position.x, this.host.position.y + 1.4, this.host.position.z);
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      if (p.kind === 'ender_eye' && p.target) {
        this._tmpA.copy(p.target).sub(p.mesh.position).normalize().multiplyScalar(7);
        p.v.lerp(this._tmpA, Math.min(1, dt * 2));
        if (p.mesh.position.distanceTo(p.target) < 6) p.life = Math.min(p.life, 0.2);
      }
      if (p.kind.includes('fireball') || p.kind === 'shulker_bullet') p.v.y -= 1.2 * dt;
      if (p.gravity) p.v.y -= p.gravity * dt;
      p.mesh.position.addScaledVector(p.v, dt);
      p.mesh.rotation.x += dt * 3; p.mesh.rotation.y += dt * 2;
      if (p.kind === 'ender_eye' || p.kind === 'shulker_bullet' || p.kind === 'wind_charge') {
        this.host.particles.spark?.(p.mesh.position.clone(), p.kind === 'ender_eye' ? '#7af0a6' : p.kind === 'wind_charge' ? '#d8eaff' : '#d9c8f5', 1);
      }
      const blocked = this.host.getBlock(p.mesh.position.x, p.mesh.position.y, p.mesh.position.z) > 0;
      const hitPlayer = p.mesh.position.distanceTo(playerHead) < 0.7;
      let done = p.life <= 0;
      if (p.kind === 'shulker_bullet' || p.kind.includes('fireball') || p.kind === 'mob_arrow' || p.kind === 'wind_charge') {
        if (hitPlayer) {
          this.attackProj = p;
          let deflected = false;
          if (p.kind === 'shulker_bullet') { if (this.host.damage(p.damage) !== 'blocked') this.host.levitate(9); }
          else if (p.kind === 'wind_charge') {
            this.host.damage(p.damage);
            this.host.levitate(0.35);
            this.host.particles.burst(p.mesh.position.clone(), '#d8eaff', 20, 4);
          } else if (p.kind.includes('fireball')) {
            this.host.damage(p.damage);
            this.host.explode(p.mesh.position.clone(), p.kind === 'ghast_fireball' ? 2 : 1);
          } else {
            const res = this.host.damage(p.damage);
            if (res === 'blocked') {          // a raised shield deflects the arrow: it bounces off and can still hit other mobs
              p.kind = 'player_arrow'; p.v.multiplyScalar(-0.35); p.v.y = Math.abs(p.v.y) + 1.5; p.life = 3; p.damage = Math.max(1, p.damage * 0.5); p.effect = undefined;
              deflected = true;
            } else if (p.effect) this.host.effect?.(p.effect[0], p.effect[1], 0);
          }
          this.attackProj = null;
          if (!deflected) done = true;
        }
        if (!done) for (const m of this.mobs) {
          if (passive.has(m.species)) continue;
          const c = m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0));
          if (p.mesh.position.distanceTo(c) > 1.1) continue;
          this.damageMob(m, p.damage, p.v.clone().normalize(), true);
          done = true; break;
        }
      } else if (p.kind === 'snowball' || p.kind === 'ender_pearl' || p.kind === 'player_arrow' || p.kind === 'trident' || p.kind === 'potion') {
        for (const m of this.mobs) {
          if (p.hit?.has(m)) continue;
          const c = m.group.position.clone().add(new THREE.Vector3(0, m.species === 'dragon' ? 1.5 : 0.9, 0));
          if (p.mesh.position.distanceTo(c) > (m.species === 'dragon' ? 2 : 1.05)) continue;
          if ((p.kind === 'player_arrow' || p.kind === 'trident' || p.kind === 'snowball') && (this.behaviors.dodgeProjectile(m) || (m.species === 'wither' && ((m as any).witherArmor || m.hp <= m.maxHp * 0.5)))) { done = true; break; }
          if (p.kind === 'ender_pearl') {
            this.host.teleport(p.mesh.position.x, p.mesh.position.y + 1, p.mesh.position.z);
            this.host.sound('portal', p.mesh.position);
          } else {
            const snowDmg = p.kind === 'snowball' && m.species === 'blaze' ? 3 : 1;
            this.damageMob(m, p.kind === 'player_arrow' || p.kind === 'trident' ? (p.damage || 7) : p.kind === 'potion' ? 0 : snowDmg, p.v.clone().normalize(), p.kind === 'player_arrow');
            if (p.flame && this.mobs.includes(m)) this.damageMob(m, 3);
            if (p.punch && this.mobs.includes(m)) m.group.position.addScaledVector(p.v.clone().setY(0).normalize(), p.punch * 0.8);
          }
          if (p.kind === 'player_arrow' && (p.pierce ?? 0) > 0) { p.pierce = (p.pierce ?? 0) - 1; (p.hit ??= new Set()).add(m); continue; }   // Piercing: keeps flying through pierce + 1 mobs
          done = true; break;
        }
      }
      if (blocked && p.recover && p.kind === 'player_arrow') {   // arrows that stick in a block can be picked up again (not Infinity / creative ones)
        this.host.particles.drop(p.mesh.position.clone().addScaledVector(p.v.clone().normalize(), -0.6).add(new THREE.Vector3(0, 0.15, 0)), p.recover, 1, '#d8d0b5');
      }
      if (blocked || (hitPlayer && p.kind === 'ender_pearl')) {
        if (p.kind === 'ender_pearl') {
          this.host.teleport(p.mesh.position.x, p.mesh.position.y + 1, p.mesh.position.z);
          this.host.sound('portal', p.mesh.position);
        } else if (p.kind.includes('fireball')) {
          this.host.explode(p.mesh.position.clone(), 2);
        } else if (p.kind === 'wind_charge') {
          this.host.particles.burst(p.mesh.position.clone(), '#d8eaff', 20, 4);
        }
        done = true;
      }
      if (done) {
        p.onEnd?.(p.mesh.position.clone());
        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
      }
    }
  }

  private updateCrystals(dt: number) {
    if (this.crystals.length === 0) return;
    const dragon = this.mobs.find(m => m.species === 'dragon');
    for (const c of this.crystals) {
      c.shell.rotation.y += dt * 1.6;
      c.core.rotation.y -= dt * 2.4;
      c.group.position.y = c.pos.y + Math.sin(this.timeline * 2 + c.pos.x) * 0.12;
      if (dragon && this.crystals.length && dragon.group.position.distanceTo(c.group.position) < 24) {
        dragon.hp = Math.min(dragon.maxHp, dragon.hp + dt * 4);
        if (Math.random() < dt * 8) {
          this.host.particles.spark?.(c.group.position.clone().add(new THREE.Vector3(0, 1.1, 0)), '#f28bff', 1);
        }
      }
    }
  }

  timeline = 0;

  dispose() {
    this.clear();
    this.box.dispose();
    this.hurtMat.dispose();
    this.materials.forEach(m => m.dispose());
    this.emissiveMaterials.forEach(m => m.dispose());
  }
}
