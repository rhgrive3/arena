// Canvas creation is independent of the atlas to keep content registration acyclic.
export type DrawCanvas = HTMLCanvasElement | OffscreenCanvas;
export type Context2D = CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D;
export function canvas(w: number, h = w): DrawCanvas {
  if (typeof document !== 'undefined') {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    // Atlas construction reads thousands of tiny tiles; CPU-backed canvases avoid GPU readback stalls.
    c.getContext('2d', { willReadFrequently: true });
    return c;
  }
  if (typeof OffscreenCanvas !== 'undefined') {
    const c = new OffscreenCanvas(w, h);
    c.getContext('2d', { willReadFrequently: true });
    return c;
  }
  const buf = new Uint8ClampedArray(w * h * 4);
  const ctx: any = {
    fillStyle: '#000000',
    strokeStyle: '#000000',
    lineWidth: 1,
    globalAlpha: 1,
    fillRect(x: number, y: number, rw: number, rh: number) {
      let r = 128, g = 128, b = 128, a = Math.round((this.globalAlpha ?? 1) * 255);
      const s = String(this.fillStyle || '');
      if (s.startsWith('#') && s.length >= 7) {
        r = parseInt(s.slice(1, 3), 16) || 0;
        g = parseInt(s.slice(3, 5), 16) || 0;
        b = parseInt(s.slice(5, 7), 16) || 0;
      } else if (s.startsWith('rgb')) {
        const m = s.match(/[\d.]+/g);
        if (m && m.length >= 3) {
          r = Number(m[0]); g = Number(m[1]); b = Number(m[2]);
          if (m.length >= 4) a = Math.round(Number(m[3]) * 255);
        }
      }
      const x0 = Math.max(0, Math.floor(x)), y0 = Math.max(0, Math.floor(y));
      const x1 = Math.min(w, Math.floor(x + rw)), y1 = Math.min(h, Math.floor(y + rh));
      for (let py = y0; py < y1; py++) {
        for (let px = x0; px < x1; px++) {
          const idx = (py * w + px) * 4;
          buf[idx] = r; buf[idx + 1] = g; buf[idx + 2] = b; buf[idx + 3] = a;
        }
      }
    },
    clearRect(x: number, y: number, rw: number, rh: number) {
      const x0 = Math.max(0, Math.floor(x)), y0 = Math.max(0, Math.floor(y));
      const x1 = Math.min(w, Math.floor(x + rw)), y1 = Math.min(h, Math.floor(y + rh));
      for (let py = y0; py < y1; py++) {
        for (let px = x0; px < x1; px++) {
          const idx = (py * w + px) * 4;
          buf[idx] = 0; buf[idx + 1] = 0; buf[idx + 2] = 0; buf[idx + 3] = 0;
        }
      }
    },
    createImageData(iw: number, ih: number) { return { data: new Uint8ClampedArray(iw * ih * 4), width: iw, height: ih }; },
    putImageData(img: { data: Uint8ClampedArray }, dx: number, dy: number) {
      if (dx === 0 && dy === 0 && img.data.length === buf.length) buf.set(img.data);
    },
    getImageData(sx = 0, sy = 0, sw = w, sh = h) {
      if (sx === 0 && sy === 0 && sw === w && sh === h) return { data: new Uint8ClampedArray(buf), width: sw, height: sh };
      const out = new Uint8ClampedArray(sw * sh * 4);
      for (let py = 0; py < sh; py++) {
        for (let px = 0; px < sw; px++) {
          const si = ((sy + py) * w + (sx + px)) * 4;
          const di = (py * sw + px) * 4;
          out[di] = buf[si]; out[di + 1] = buf[si + 1]; out[di + 2] = buf[si + 2]; out[di + 3] = buf[si + 3];
        }
      }
      return { data: out, width: sw, height: sh };
    },
    globalCompositeOperation: "source-over",
    font: "9px monospace",
    textAlign: "left",
    save() {},
    restore() {},
    translate() {},
    scale() {},
    drawImage() {},
    beginPath() {},
    closePath() {},
    moveTo() {},
    lineTo() {},
    bezierCurveTo() {},
    stroke() {}, strokeRect() {},
    arc() {},
    fill() {},
    fillText() {},
    createLinearGradient() { return { addColorStop() {} }; },
    createRadialGradient() { return { addColorStop() {} }; },
  };
  return {
    width: w,
    height: h,
    getContext: () => ctx,
    toDataURL: () => "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
  } as unknown as DrawCanvas;
}

