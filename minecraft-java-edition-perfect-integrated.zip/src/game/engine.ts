import {
  DEFAULT_GAMERULES, type Gamerules, trySummonMultiblock, isWearingGoldArmor,
  findNearestLightningRod, deoxidizeCopperAround, computeRailState, SPYGLASS_FOV_SCALE,
} from '../systems/vanillaPlus';
import { MUSIC_DISCS } from './extras';
import * as THREE from 'three';
import ChunkWorker from '../world/chunk.worker?worker&inline';
import { Terrain, MIN_Y, HEIGHT, blockIndex, END_GATEWAY_MAIN, END_OUTER_ARRIVAL } from '../world/terrain';
import { BLOCKS, ID, resolve } from './data';
import { blockId, blockState, isAttachable, isSlabBlock, makeCell, stateForPlacement } from './blockState';
import { collisionBoxes, intersectsBox, selectionBoxes } from '../world/shapes';
import { traceVoxelRay } from '../world/raycast';
import { tilesFor, atlasTiles, handTileCanvas, blockFaceCanvases } from '../textures/atlas';
import type { MeshData } from '../world/mesher';
import { InputController } from '../input/controller';
import { Environment } from '../render/environment';
import {
  DEFAULT_SETTINGS, EMPTY_SNAPSHOT,
  type Settings, type WorldMeta, type WorldSave, type GameSnapshot, type Stack, type Dimension, type Screen,
} from './types';
import { clamp } from '../input/math';
import type { ProceduralAudio } from '../audio/sound';
import './content';
import { ParticleSystem, animateWorldTick, entityFxBox, hexToRgb, FX_TICK, type RGB } from '../render/particles';
import { MobManager, type Species } from '../entities/mobs';
import { Simulation } from '../systems/simulation';
import { Redstone } from '../systems/redstone';
import { RECIPES, SMELTING, FUEL, canCraft, recipeCounts } from '../systems/crafting';
import { blockDrops, blockExperience, miningTime } from '../systems/mining';
import * as SV from './survival';
import { extraLootTable } from '../world/structures';
import { Farming, SEED_TO_CROP, isCrop, isTillable } from '../systems/farming';
import { Fishing } from '../systems/fishing';
import { VehicleManager, isCartKind, type VehicleSave, type Vehicle } from '../entities/vehicles';
import { Gameplay, ENDER_KEY, type GameplayHost, type EntityView } from '../systems/gameplay';
import type { GameEventType } from '../systems/events';
import { potionEffects, EFFECTS } from '../systems/magic';
import { itemsFromNbt, itemsToNbt } from './nbt';
import { playerUUID, pullEnderItems, pushEnderItems } from './enderSync';
import { World121, type W121Save } from './world121';
import type { Offer } from '../entities/mobdata';
import { mapSpecOf, mapStack } from '../systems/explorerMap';
import { PistonAnimator } from '../render/pistons';
import * as V from './vanilla';
import type { MapData } from '../systems/maps';
import { BannerMeshes, RepeaterLockMeshes } from '../render/banners3d';
import { bannerShieldCanvas, bannerColorOf, type BannerLayer } from '../systems/banners';
import { SignMeshes, newSignData, applySignItem, signSideForPlayer, type SignData } from '../systems/signs';
import { BeaconBeams, beaconPyramidTier } from '../systems/beacon';
import { DecoratedPotMeshes, DEFAULT_SHERDS } from '../systems/pots';
import { insertStack, transferOne, findCrafterRecipe } from '../systems/automation';
import type { MobSave, RaidState } from '../entities/mobs';

interface Chunk {
  cx: number;
  cz: number;
  data: Uint16Array;
  solid: THREE.Mesh;
  water: THREE.Mesh;
  version: number;
  /** Vertical extent of the meshes (world Y), for the per-frame box culling. */
  minY: number;
  maxY: number;
  hasSolid: boolean;
  hasWater: boolean;
}
interface Target {
  x: number;
  y: number;
  z: number;
  id: number;
  normal: THREE.Vector3;
  distance: number;
}
interface WorkerSlot {
  worker: Worker;
  busy: boolean;
  key?: string;
  epoch?: number;
  /** The tile table is posted to a worker only once. */
  tilesSent?: boolean;
}
interface DimensionStore {
  edits: Map<string, number>;
  containers: Record<string, (Stack | null)[]>;
  furnaces: Record<string, { burn: number; progress: number }>;
}

const HELD_LIGHT_ITEMS = new Set(['torch', 'lantern', 'glowstone', 'shroomlight', 'crying_obsidian', 'end_rod', 'sea_lantern', 'lava_bucket', 'redstone_lamp', 'end_portal', 'end_gateway', 'fire']);

// Loot for chests that came with the world (vanilla-style tables): [item, min, max, weight].
const LOOT: Record<string, { rolls: [number, number]; items: [string, number, number, number][] }> = {
  village: { rolls: [3, 8], items: [['bread', 1, 4, 15], ['apple', 1, 5, 15], ['potato', 1, 7, 10], ['carrot', 4, 8, 10], ['wheat', 1, 7, 8], ['wheat_seeds', 1, 5, 8], ['oak_sapling', 1, 2, 5], ['coal', 1, 4, 6], ['stick', 1, 3, 6], ['iron_ingot', 1, 3, 3], ['emerald', 1, 4, 2], ['dandelion', 1, 1, 2], ['poppy', 1, 1, 2]] },
  dungeon: { rolls: [6, 11], items: [['bone', 1, 8, 10], ['rotten_flesh', 1, 8, 10], ['gunpowder', 1, 8, 10], ['string', 1, 8, 10], ['wheat', 1, 4, 20], ['bread', 1, 1, 20], ['coal', 1, 4, 15], ['redstone', 1, 4, 15], ['iron_ingot', 1, 4, 10], ['gold_ingot', 1, 4, 5], ['bucket', 1, 1, 10], ['saddle', 1, 1, 20], ['golden_apple', 1, 1, 15], ['wheat_seeds', 2, 4, 10], ['diamond', 1, 1, 2]] },
  temple: { rolls: [5, 9], items: [['diamond', 1, 3, 5], ['iron_ingot', 1, 5, 15], ['gold_ingot', 2, 7, 15], ['emerald', 1, 3, 15], ['bone', 4, 6, 25], ['rotten_flesh', 3, 7, 25], ['gunpowder', 1, 8, 10], ['string', 1, 8, 10], ['sand', 1, 8, 10], ['saddle', 1, 1, 20], ['golden_apple', 1, 1, 20]] },
  fortress: { rolls: [3, 6], items: [['diamond', 1, 3, 5], ['iron_ingot', 1, 5, 5], ['gold_ingot', 1, 3, 15], ['blaze_rod', 2, 4, 12], ['golden_sword', 1, 1, 5], ['saddle', 1, 1, 10], ['flint_and_steel', 1, 1, 5], ['nether_wart', 3, 7, 5], ['obsidian', 2, 4, 2]] },
};

export const DEFAULT_WORLD: WorldMeta = {
  id: 'greenwood',
  name: 'はじまりの森',
  seed: '849281',
  mode: 'creative',
  difficulty: 'normal',
  hardcore: false,
  structures: true,
  bonus: true,
  cheats: true,
  created: Date.now(),
  updated: Date.now(),
  playTime: 0,
};

export class Engine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(58, 1, 0.05, 480);
  environment: Environment;
  input: InputController;
  terrain = new Terrain(DEFAULT_WORLD.seed);

  chunks = new Map<string, Chunk>();
  workers: WorkerSlot[] = [];
  queue: string[] = [];
  queued = new Set<string>();
  pending = new Set<string>();
  versions = new Map<string, number>();
  edits = new Map<string, number>();
  editsByChunk = new Map<string, Map<string, number>>();
  uploadQueue: { m: any }[] = [];
  tiles = BLOCKS.map(b => tilesFor(b.id));

  settings: Settings = { ...DEFAULT_SETTINGS };
  meta: WorldMeta = { ...DEFAULT_WORLD };
  dimension: Dimension = 'overworld';
  position = new THREE.Vector3(-11, 28, 27);
  velocity = new THREE.Vector3();
  // record 014
  farming!: Farming;
  fishing!: Fishing;
  vehicles!: VehicleManager;
  pistonAnimations!: PistonAnimator;
  entityStores: Partial<Record<Dimension, { mobs: MobSave[]; vehicles: VehicleSave[]; badOmen?: boolean; raid?: RaidState }>> = {};
  crafterDisabled: Record<string, number> = {};
  gamerules: Gamerules = { ...DEFAULT_GAMERULES };
  lightningRods = new Set<string>();
  netherRespawn: { x: number; y: number; z: number; anchor: [number, number, number] } | null = null;
  /** Trial spawners, vaults, beacons, conduits, archaeology, explorer maps and their event bus. */
  w121!: World121;
  lastSleepAt = 0;
  dismountCooldown = 0;
  shrieks = new Map<string, number>();
  active = false;
  ready = false;
  grounded = false;
  flying = false;
  gliding = false;
  elytraEquipped = false;
  sleeping = false;
  sleepTimer = 0;
  portalCharge = 0;
  levitationTimer = 0;
  dragonDefeated = false;
  time = 0.2;
  elapsed = 0;
  selected = 0;
  weather: 'clear' | 'rain' | 'storm' = 'clear';
  weatherTimer = 25;
  hotbar: (Stack | null)[] = [];
  inventory: (Stack | null)[] = Array(27).fill(null);
  health = 20;
  hunger = 20;
  oxygen = 20;
  xp = 0;
  /** Java hunger model: `hunger` is the food level, plus hidden saturation and exhaustion. */
  saturation = 5; exhaustion = 0; foodTimer = 0; foodAcc = 0; foodPtick = 0;
  /** Shields are unusable until this game time (axe hit → +5 s). */
  shieldCdUntil = -1;
  lastHit: { angle: number; t: number } | null = null;
  maps = new Map<number, MapData>(); nextMapId = 1;
  lecternPages: Record<string, number> = {};
  /** Which hand the current right-click is acting for (the off-hand is tried only when the main hand passes). */
  handCtx: 'main' | 'off' = 'main';
  banners = new Map<string, { base: string; layers: { p: string; c: string }[]; yaw: number }>();
  private bannerMeshes: BannerMeshes | null = null;
  private get bm(): BannerMeshes { return (this.bannerMeshes ??= new BannerMeshes(this.scene)); }
  private bannerDim = '';
  signs = new Map<string, SignData>();
  signSide: 'front' | 'back' = 'front';
  private signMeshes: SignMeshes | null = null;
  private get sm(): SignMeshes { return (this.signMeshes ??= new SignMeshes(this.scene)); }
  beacons = new Map<string, { primary: string; secondary?: string }>();
  private beaconBeams: BeaconBeams | null = null;
  private get bb(): BeaconBeams { return (this.beaconBeams ??= new BeaconBeams(this.scene)); }
  pots = new Map<string, [string, string, string, string]>();
  private potMeshes: DecoratedPotMeshes | null = null;
  private get pm(): DecoratedPotMeshes { return (this.potMeshes ??= new DecoratedPotMeshes(this.scene)); }
  private lockMeshes: RepeaterLockMeshes | null = null;
  private get lm(): RepeaterLockMeshes { return (this.lockMeshes ??= new RepeaterLockMeshes(this.scene)); }
  private thirdPersonShield: THREE.Mesh | null = null;
  /** Worn armor: helmet, chestplate (or elytra), leggings, boots. */
  armor: (Stack | null)[] = [null, null, null, null];
  offhand: Stack | null = null;
  effects: Record<string, { t: number; amp: number }> = {};
  absorption = 0;
  attackAt = -10;
  swingHeld = false;
  useTime = 0;
  useItemName = '';
  blocking = false;
  enchantSeed = 1;
  portalLock = false;
  lastLevel = 0;
  statistics: Record<string, number> = {};
  achievements: string[] = [];
  containers: Record<string, (Stack | null)[]> = {};
  target: Target | null = null;
  breaking = 0;
  breakKey = '';
  breakCooldown = 0;
  debug = false;
  dead = false;
  thirdPerson = false;

  outline: THREE.LineSegments;
  crack: THREE.Mesh;
  crackMaterials: THREE.MeshBasicMaterial[] = [];
  hand: THREE.Mesh;
  handMaterial: THREE.MeshLambertMaterial;
  handFaceMaterials: THREE.MeshLambertMaterial[] = [];
  handTextures = new Map<string, THREE.CanvasTexture>();
  lastHand = '';
  handDip = 0;
  hitFlash = 0;

  // Articulated 3D Steve model for F5 Third-Person mode
  playerModel: THREE.Group;
  playerHead: THREE.Group;
  playerLegs: THREE.Object3D[] = [];
  playerArms: THREE.Object3D[] = [];

  private raf = 0;
  private last = 0;
  private snapshotAt = 0;
  private streamAt = -10;
  private focus = '';
  private disposed = false;
  private frameCount = 0;
  private fps = 60;
  private fpsAt = 0;
  private pendingPlay = false;
  private worldEpoch = 0;
  private biomeKey = '';
  private currentBiome = 'plains';
  private dimensionStores: Partial<Record<Dimension, DimensionStore>> = {};
  private stationsInMenu = false;
  private stationCursor = 0;
  audio: ProceduralAudio | null = null;
  private stepAt = 0;
  private hitAt = 0;
  particles!: ParticleSystem;
  mobs!: MobManager;
  simulation!: Simulation;
  stationKey = '';
  furnaces: Record<string, { burn: number; progress: number }> = {};
  explosionQueue: [number, number, number][] = [];
  respawnPoint: [number, number, number] | null = null;
  private plate: [number, number, number] | null = null;
  private hazardAt = 0;
  private basePixelRatio = 1;
  private renderScale = 1;
  private lastScaleCheck = 0;
  private lightningTimer = 14;
  private fallTop = 0;
  private resizeObserver: ResizeObserver;
  private lastShadow = 0;
  private lastShadowPos = new THREE.Vector3();
  private fallbackNotified = false;
  private autoSaveAt = 0;
  private listeners: (() => void)[] = [];
  /** Chunks outside the render ring but inside the simulation ring: only block data, no meshes (redstone reads/writes them). */
  private sideChunks = new Map<string, Chunk>();
  redstone!: Redstone;
  /** Record 016: environment physics, block entities and sensors. Publishes render flags and events (gameplay.events). */
  gameplay!: Gameplay;
  private eyeNow = 1.62;
  private enderEpoch = 0;
  private redstoneTimer = 0;
  private redstoneWrites = 0;
  private _dir = new THREE.Vector3();
  private _camTarget = new THREE.Vector3();
  private _frustum = new THREE.Frustum();
  private _viewProj = new THREE.Matrix4();
  private _cullBox = new THREE.Box3();
  /** Last chunk returned by getCell: block queries cluster in one chunk, so this skips the string key and map lookup. */
  private _cellChunk: Chunk | null = null;
  private _cellCx = 0;
  private _cellCz = 0;
  private _supportPos = new THREE.Vector3();
  private _simVec = new THREE.Vector3();

  constructor(
    public canvas: HTMLCanvasElement,
    public onSnapshot: (s: GameSnapshot) => void,
    public onScreen: (s: Screen) => void,
    public onToast: (ja: string, en: string) => void,
    public onSave: (save: WorldSave) => void,
  ) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.25));
    this.basePixelRatio = this.renderer.getPixelRatio();
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.shadowMap.autoUpdate = false;

    this.environment = new Environment(this.scene, this.renderer, this.settings);
    this.environment.attachWorld({
      surfaceAt: (x, z) => this.visualSurfaceAt(x, z),
      biomeAt: (x, z) => this.terrain.biome(x, z),
    });
    this.input = new InputController(canvas, this.settings, a => this.action(a));
    this.particles = new ParticleSystem(this.scene);
    this.pistonAnimations = new PistonAnimator(this.scene);
    this.simulation = new Simulation({
      getBlock: (x, y, z) => this.getBlock(x, y, z),
      getCell: (x, y, z) => this.getCell(x, y, z),
      dimension: () => this.dimension,
      setBlock: (x, y, z, id, state = 0) => this.setBlock(x, y, z, id, state),
      explode: (p, r) => this.explode(p, r),
      toast: (j, e) => this.onToast(j, e),
      sound: (k, p) => this.audio?.play(k, p),
      toggleDoor: (x, y, z, open) => this.toggleDoor(x, y, z, open),
    });

    // Redstone runs on its own 20 Hz tick with a pure state machine (see systems/redstone.ts). The adapter below connects
    // it to the live world: signal levels read cells, outputs write blocks, and mechanisms reuse the door/container/audio APIs.
    this.redstone = new Redstone({
      getCell: (x, y, z) => this.getCell(x, y, z),
      setBlock: (x, y, z, id, state = 0) => { this.redstoneWrites++; try { return this.setBlock(x, y, z, id, state); } finally { this.redstoneWrites--; } },
      containerSignal: (x, y, z) => this.containerSignal(x, y, z),
      analogSignal: (x, y, z) => this.analogSignal(x, y, z),
      comparatorOverride: (x, y, z) => this.gameplay.comparatorOverride(x, y, z),
      sensorBack: (x, y, z) => this.gameplay.sensorBack(x, y, z),
      eject: (x, y, z, dir, kind) => this.ejectFrom(x, y, z, dir, kind),
      transfer: (x, y, z, dir) => this.hopperTransfer(x, y, z, dir),
      door: (x, y, z, open) => this.toggleDoor(x, y, z, open),
      ignite: (x, y, z) => { this.simulation.enqueue(x, y, z, ID.tnt); this.onToast('TNTに点火しました', 'TNT primed'); },
      daylight: () => this.dimension === 'overworld' ? this.environment.daylight * (this.weather === 'clear' ? 1 : 0.6) : this.dimension === 'nether' ? 0 : 1,
      craft: (x, y, z, dir) => this.crafterFire(x, y, z, dir),
      moveBlocks: (moves, duration) => this.pistonAnimations.start(moves, duration),
      pushEntities: (moves, dir, slimeBounce) => this.pushEntitiesByPiston(moves, dir, slimeBounce),
      crushed: (x, y, z, cell) => { const d = BLOCKS[blockId(cell)]; if (d && this.meta.mode !== 'creative') for (const drop of blockDrops(d, undefined, blockState(cell))) this.particles.drop(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), drop.name, drop.count, resolve(drop.name)?.color ?? d.color); },
      sound: (kind, x, y, z) => {
        if (kind === 'note') this.mobs?.behaviors.noteBlockPlayed(Math.floor(x as number), Math.floor(y as number), Math.floor(z as number));
        const map: Record<string, string> = { click: 'chest', note: 'xp', piston: 'door', ignite: 'fuse' };
        this.audio?.play(map[kind] ?? 'stone', { x, y, z });
      },
    });

    this.mobs = new MobManager(this.scene, {
      terrain: this.terrain,
      position: this.position,
      camera: this.camera,
      get time() { return 0; },
      dimension: this.dimension,
      dragonDefeated: this.dragonDefeated,
      getBlock: (x, y, z) => this.getBlock(x, y, z),
      getCell: (x: number, y: number, z: number) => this.getCell(x, y, z),
      damage: n => {
        // The mob manager tells us who is attacking so the shield can check its 180° arc, axes and piercing arrows.
        const m = this.mobs.attacker, pr = this.mobs.attackProj;
        const atk: SV.Attacker | undefined = pr ? { from: pr.mesh.position.clone(), pierce: pr.pierce ?? 0 } : m ? { from: m.group.position.clone(), axe: V.AXE_ATTACKERS.has(m.species) } : undefined;
        return this.damage(n, pr ? 'projectile' : 'mob', atk);
      },
      visibility: () => V.visibilityPercent({ invisible: SV.has(this, 'invisibility'), sneaking: this.input.crouch, armorPieces: this.armor.filter(Boolean).length }),
      addItem: (n, c) => this.addItem(n, c),
      addXp: n => this.addXp(n),
      toast: (j, e) => this.onToast(j, e),
      sound: (k, p) => this.audio?.play(k, p),
      explode: (p, r) => this.explode(p, r),
      teleport: (x, y, z) => this.teleport(x, y, z),
      openTrade: () => { this.pause(true); this.onScreen('trade'); },
      onDragonDefeated: () => this.handleDragonDefeated(),
      onEnterGateway: () => this.handleGatewayTravel(),
      levitate: sec => { if (sec >= 1) this.onToast('シュルカーの弾で浮遊しています！', 'Levitating!'); this.levitationTimer = Math.max(this.levitationTimer, sec); },
      goldArmor: () => this.armor.some(a => a?.name.startsWith('golden_')),
      effect: (id, sec, amp = 0) => { SV.addEffect(this, id, sec, amp); },
      insomnia: () => this.meta.playTime - this.lastSleepAt,
      difficulty: () => this.meta.difficulty,
      consume: () => {
        if (this.meta.mode !== 'creative') {
          if (this.hotbar[this.selected]?.name === 'bucket') this.hotbar[this.selected] = null;
          else this.consumeSelected();
        }
        return true;
      },
      playerMoving: () => this.grounded && Math.hypot(this.input.move.x, this.input.move.z) > 0.1,
      sneaking: () => this.input.crouch,
      wearingGold: () => isWearingGoldArmor(this.armor),
      heldItem: () => this.hotbar[this.selected]?.name ?? '',
      onVibration: (vx, vy, vz, strength) => this.triggerSculkSensors(vx, vy, vz, strength),
      onProjectileHit: (kind, p, v) => { this.gameplay.projectileHit(kind, p.x, p.y, p.z, v.x, v.y, v.z); },
      particles: this.particles,
    });

    this.w121 = new World121(this);

    this.farming = new Farming({
      getCell: (x, y, z) => this.getCell(x, y, z),
      setBlock: (x, y, z, id, state = 0) => this.setBlock(x, y, z, id, state),
      drop: (x, y, z, name, count) => this.particles.drop(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), name, count, resolve(name)?.color ?? '#8a8'),
      // Bone meal / sapling growth: Java's green `happy_villager` glints (15 inside the block) instead of coloured cubes.
      particles: (x, y, z, _color, n) => this.particles.happyVillager(x - 0.5, y - 0.5, z - 0.5, n >= 20 ? 30 : 15, n >= 20 ? 1 : 0.5, 1),
      cropGrew: (x, y, z) => this.particles.happyVillager(x, y, z, 3, 0.5, 0.6),
      get seed() { return 0; },
      daylight: () => this.environment.daylight,
      raining: () => this.weather !== 'clear' && this.dimension === 'overworld',
    });
    Object.defineProperty(this.mobs.host, 'time', { get: () => this.time });
    Object.defineProperty(this.farming.host, 'seed', { get: () => this.terrain.seed | 0 });
    this.fishing = new Fishing(this.scene, {
      getBlock: (x, y, z) => this.getBlock(x, y, z),
      particles: this.particles,
      sound: (k, p) => this.audio?.play(k, p),
      raining: () => this.weather !== 'clear',
    });
    this.vehicles = new VehicleManager(this.scene, {
      getCell: (x, y, z) => this.getCell(x, y, z),
      getBlock: (x, y, z) => this.getBlock(x, y, z),
      setBlock: (x, y, z, id, state = 0) => this.setBlock(x, y, z, id, state),
      drop: (x, y, z, name, count) => this.particles.drop(new THREE.Vector3(x, y, z), name, count, resolve(name)?.color ?? '#aaa'),
      dropStack: (x, y, z, stack) => this.dropStack(x, y, z, stack),
      containerAt: (x, y, z) => this.containerAt(x, y, z),
      takeDrop: (x, y, z) => this.takeDropNear(x, y, z),
      explode: (x, y, z, power) => this.explode(new THREE.Vector3(x, y, z), Math.round(power)),
      emit: (type, detail) => this.gameplay.events.emit(type as GameEventType, detail),
      sound: (k, p) => this.audio?.play(k, p),
    });

    this.gameplay = this.createGameplay();

    this.outline = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(1.006, 1.006, 1.006)),
      new THREE.LineBasicMaterial({ color: '#1a2419', transparent: true, opacity: 0.85 }),
    );
    this.outline.visible = false;
    this.scene.add(this.outline);

    const cracks = atlasTiles().filter(t => t.name.startsWith('crack_'));
    this.crackMaterials = cracks.map(t => {
      const texture = new THREE.CanvasTexture(t.canvas as HTMLCanvasElement);
      texture.magFilter = THREE.NearestFilter;
      return new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 });
    });
    this.crack = new THREE.Mesh(new THREE.BoxGeometry(1.009, 1.009, 1.009), this.crackMaterials[0]);
    this.crack.visible = false;
    this.scene.add(this.crack);

    this.handMaterial = new THREE.MeshLambertMaterial({ color: '#b49b6b', alphaTest: 0.35 });
    this.handFaceMaterials = Array.from({ length: 6 }, () => new THREE.MeshLambertMaterial({ color: '#c99c7b' }));
    this.hand = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.28, 0.28), this.handFaceMaterials);
    this.hand.position.set(0.42, -0.34, -0.62);
    this.hand.rotation.set(0.2, -0.5, 0.1);
    this.hand.visible = false;
    this.camera.add(this.hand);
    this.scene.add(this.camera);

    // Build articulated Steve model for Third-Person view (F5)
    this.playerModel = new THREE.Group();
    this.playerHead = new THREE.Group();
    const box = new THREE.BoxGeometry(1, 1, 1);
    const mkPart = (parent: THREE.Object3D, col: string, x: number, y: number, z: number, w: number, h: number, d: number) => {
      const m = new THREE.Mesh(box, new THREE.MeshLambertMaterial({ color: col }));
      m.position.set(x, y, z);
      m.scale.set(w, h, d);
      m.castShadow = true;
      m.receiveShadow = true;
      parent.add(m);
      return m;
    };
    mkPart(this.playerModel, '#2fa8b0', 0, 1.08, 0, 0.5, 0.72, 0.26); // Torso
    this.playerHead.position.set(0, 1.65, 0);
    mkPart(this.playerHead, '#c99c7b', 0, 0, 0, 0.46, 0.46, 0.46); // Head
    mkPart(this.playerHead, '#4b3322', 0, 0.16, 0.02, 0.48, 0.16, 0.48); // Hair
    mkPart(this.playerHead, '#2c4c8a', -0.1, 0.02, -0.235, 0.08, 0.07, 0.02); // Eyes
    mkPart(this.playerHead, '#2c4c8a', 0.1, 0.02, -0.235, 0.08, 0.07, 0.02);
    this.playerModel.add(this.playerHead);
    for (const s of [-1, 1]) {
      const leg = new THREE.Group(); leg.position.set(s * 0.13, 0.72, 0);
      mkPart(leg, '#3e4691', 0, -0.36, 0, 0.22, 0.72, 0.24);
      this.playerModel.add(leg);
      this.playerLegs.push(leg);

      const arm = new THREE.Group(); arm.position.set(s * 0.36, 1.38, 0);
      mkPart(arm, '#2fa8b0', 0, -0.12, 0, 0.2, 0.26, 0.22);
      mkPart(arm, '#c99c7b', 0, -0.42, 0, 0.19, 0.42, 0.2);
      this.playerModel.add(arm);
      this.playerArms.push(arm);
    }
    this.playerModel.visible = false;
    this.scene.add(this.playerModel);

    const count = Math.min(4, Math.max(2, (navigator.hardwareConcurrency || 4) - 1));
    for (let i = 0; i < count; i++) {
      const worker = new ChunkWorker();
      const slot: WorkerSlot = { worker, busy: false };
      worker.onmessage = e => this.receive(e.data, slot);
      worker.onerror = () => {
        slot.busy = false;
        if (slot.epoch === this.worldEpoch && slot.key) {
          this.pending.delete(slot.key);
          this.invalidate(slot.key);
        }
        this.onToast('地形生成を再試行しています', 'Retrying terrain generation');
        this.streamAt = -10;
      };
      this.workers.push(slot);
    }

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(canvas);
    this.resize();

    const save = () => { if (this.active) this.save(); };
    window.addEventListener('blur', save);
    document.addEventListener('visibilitychange', save);
    this.listeners.push(
      () => window.removeEventListener('blur', save),
      () => document.removeEventListener('visibilitychange', save),
    );

    this.defaultInventory();
    this.raf = requestAnimationFrame(this.frame);
  }

  resize() {
    const w = this.canvas.clientWidth || innerWidth, h = this.canvas.clientHeight || innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  setSettings(settings: Settings) {
    this.settings = { ...settings };
    this.input.settings = this.settings;
    this.basePixelRatio = Math.min(devicePixelRatio, settings.quality === 'low' ? 1 : settings.quality === 'medium' ? 1.1 : settings.quality === 'ultra' ? 1.7 : 1.25);
    this.renderScale = 1;
    this.renderer.setPixelRatio(this.basePixelRatio);
    this.renderer.shadowMap.enabled = settings.quality !== 'low';
    this.environment.markShadow();
    this.camera.fov = this.active ? settings.fov : 58;
    this.camera.updateProjectionMatrix();
    this.streamAt = -10;
    this.resize();
  }

  defaultInventory() {
    const names = this.meta.mode === 'creative'
      ? ['grass_block', 'oak_log', 'oak_planks', 'stone_bricks', 'glass', 'oak_leaves', 'torch', 'crafting_table', 'water_bucket']
      : ['wooden_pickaxe', 'wooden_sword', 'oak_log', 'oak_planks', 'torch', 'apple', 'crafting_table', 'cobblestone', 'bucket'];
    this.hotbar = names.map(name => ({
      name,
      count: this.meta.mode === 'creative' ? 64 : name === 'apple' ? 8 : resolve(name)?.stack === 1 ? 1 : 32,
    }));
    this.inventory = Array(27).fill(null);
    if (this.meta.bonus && this.meta.mode !== 'creative') {
      this.inventory[0] = { name: 'bread', count: 8 };
      this.inventory[1] = { name: 'coal', count: 8 };
      this.inventory[2] = { name: 'wheat_seeds', count: 8 };
    }
  }

  private rebuildEditBuckets() {
    this.editsByChunk.clear();
    for (const [key, cell] of this.edits) {
      const [x, , z] = key.split(',').map(Number);
      const cKey = Math.floor(x / 16) + ',' + Math.floor(z / 16);
      let bucket = this.editsByChunk.get(cKey);
      if (!bucket) { bucket = new Map(); this.editsByChunk.set(cKey, bucket); }
      bucket.set(key, cell);
    }
  }

  start(meta: WorldMeta, save?: WorldSave) {
    this.active = false;
    this.pendingPlay = true;
    this.ready = false;
    this.meta = { ...meta };
    this.dimension = save?.dimension ?? 'overworld';
    this.dimensionStores = {};
    for (const dimension of ['overworld', 'nether', 'end'] as const) {
      const state = save?.dimensions?.[dimension];
      const legacy = save && !save.dimensions && dimension === this.dimension;
      this.dimensionStores[dimension] = {
        edits: new Map(state?.edits ?? (legacy ? save.edits : [])),
        containers: state?.containers ?? (legacy ? save.containers ?? {} : {}),
        furnaces: state?.furnaces ?? (legacy ? save.furnaces ?? {} : {}),
      };
    }
    if (save && ((save.meta as any)?.gen ?? (meta as any).gen ?? 0) < 3 && this.dimensionStores.overworld) SV.liftLegacyOverworld(this.dimensionStores.overworld);
    this.attachDimensionStore(this.dimension);
    this.terrain = new Terrain(meta.seed, this.dimension);
    this.mobs.host.terrain = this.terrain;
    this.mobs.host.dimension = this.dimension;
    this.dragonDefeated = save?.dragonDefeated ?? false;
    this.elytraEquipped = save?.elytraEquipped ?? false;
    this.mobs.host.dragonDefeated = this.dragonDefeated;
    this.mobs.clear();
    this.particles.clear();
    this.simulation.clear();
    this.respawnPoint = save?.respawnPoint ?? null;
    this.clearChunks();
    this.time = save?.time ?? 0.2;
    // Worlds saved before terrain generation v2 would leave the player inside the new landscape: restart those at the spawn point.
    // Terrain generation v4 (multi-noise): worlds from older generators restart at the new spawn point.
    // Terrain generation v5 (vanilla biome table, new terrain shaping): same rule again.
    const legacyTerrain = !!save && (save.meta as any)?.gen !== 5 && (meta as any).gen !== 5;
    (this.meta as any).gen = 5;
    if (legacyTerrain) this.respawnPoint = null;
    this.entityStores = save?.entities ? structuredClone(save.entities) : {};
    this.crafterDisabled = { ...(save?.crafterDisabled ?? {}) };
    if (save?.randomTickSpeed !== undefined) this.farming.speed = save.randomTickSpeed;
    this.position.set(...(save && !legacyTerrain ? save.position : this.terrain.spawnPosition(1.05)));
    this.restoreEntities();
    this.velocity.set(0, 0, 0);
    this.input.yaw = save && !legacyTerrain ? save.yaw : this.terrain.spawnYaw();
    this.input.pitch = save?.pitch ?? -0.08;
    this.health = save?.health ?? 20;
    this.hunger = save?.hunger ?? 20;
    this.xp = save?.xp ?? 0;
    this.lastLevel = Math.floor(Math.sqrt(this.xp));
    this.statistics = save?.statistics ?? {};
    this.achievements = save?.achievements ?? [];
    this.selected = save?.selected ?? 0;
    this.flying = false;
    this.gliding = false;
    this.sleeping = false;
    this.portalCharge = 0;
    this.levitationTimer = 0;
    this.dead = false;
    this.oxygen = 20;
    this.defaultInventory();
    if (save) {
      this.hotbar = save.hotbar;
      this.inventory = save.inventory;
    }
    SV.loadPlayer(this, save);
    this.w121.load(save?.w121 as W121Save | undefined, this.dimension);
    this.gameplay.load(save?.gameplay);
    this.syncEnderChest(!save);
    this.signs = new Map(Object.entries(save?.signs ?? {}));
    this.beacons = new Map(Object.entries(save?.beacons ?? {}));
    this.pots = new Map(Object.entries(save?.pots ?? {}));
    this.bannerDim = '';
    this.focus = '';
    this.streamAt = -10;
    this.autoSaveAt = this.elapsed;
    this.camera.fov = this.settings.fov;
    this.camera.updateProjectionMatrix();
    this.onScreen('loading');
  }

  private attachDimensionStore(dimension: Dimension) {
    const store = (this.dimensionStores[dimension] ??= { edits: new Map(), containers: {}, furnaces: {} });
    this.edits = store.edits;
    this.containers = store.containers;
    this.furnaces = store.furnaces;
    this.rebuildEditBuckets();
  }

  activate() {
    if (!this.ready) return;
    this.stationsInMenu = false;
    this.active = true;
    this.gameplay.screenClosed();
    if (this.stationKey && this.stationKey.includes(',')) {
      const [sx, sy, sz] = this.stationKey.split(',').map(Number);
      if (Number.isFinite(sx) && this.getBlock(sx, sy, sz) === ID.trapped_chest) {
        this.setBlock(sx, sy, sz, ID.trapped_chest, 0);
      }
    }
    this.input.setActive(true);
    this.hand.visible = !this.thirdPerson;
    this.playerModel.visible = this.thirdPerson;
    this.environment.markShadow();
  }

  pause(keepStationsRunning = false) {
    this.stationsInMenu = keepStationsRunning;
    this.active = false;
    this.input.setActive(false);
    this.hand.visible = false;
    this.playerModel.visible = false;
    this.outline.visible = false;
    this.crack.visible = false;
  }

  title() {
    this.save();
    this.pendingPlay = false;
    this.pause();
    this.meta = { ...DEFAULT_WORLD };
    this.terrain = new Terrain(DEFAULT_WORLD.seed);
    this.dimension = 'overworld';
    this.mobs.host.terrain = this.terrain;
    this.mobs.host.dimension = this.dimension;
    this.mobs.clear();
    this.mobs.populate();
    this.particles.clear();
    this.simulation.clear();
    this.clearChunks();
    this.dimensionStores = {};
    this.attachDimensionStore('overworld');
    this.focus = '';
    this.streamAt = -10;
    this.ready = false;
    this.time = 0.2;
    this.camera.fov = 58;
    this.camera.updateProjectionMatrix();
  }

  clearChunks() {
    this.pistonAnimations?.clear();
    this.signMeshes?.clear();
    this.beaconBeams?.clear();
    this.potMeshes?.clear();
    this.lockMeshes?.clear();
    this.vehicles?.clear();
    this.fishing?.remove();
    this.farming?.growing.clear();
    this.worldEpoch++;
    for (const c of this.chunks.values()) this.disposeChunk(c);
    // Ring chunks own meshes too: without this they stayed in the scene (and in getCell) after a world or dimension change.
    for (const c of [...this.sideChunks.values()]) this.disposeChunk(c);
    this.sideChunks.clear();
    this._cellChunk = null;
    this.redstone?.active.clear();
    this.chunks.clear();
    this.queue = [];
    this.queued.clear();
    this.pending.clear();
    this.uploadQueue = [];
    this.versions.clear();
  }

  disposeChunk(c: Chunk, remount = false) {
    if (this._cellChunk === c) this._cellChunk = null;
    if (!remount) {
      this.redstone?.unloadChunk(c.cx, c.cz);
      this.farming?.unloadChunk(c.cx, c.cz);
    }
    this.sideChunks.delete(c.cx + ',' + c.cz);
    if (c.solid) {
      this.scene.remove(c.solid);
      c.solid.geometry.dispose();
    }
    if (c.water) {
      this.scene.remove(c.water);
      c.water.geometry.dispose();
    }
  }

  action(action: string) {
    if (action === 'escape') {
      if (this.dead) return;
      if (this.active) { this.pause(); this.onScreen('pause'); }
      else this.onScreen('escape');
      return;
    }
    if (!this.active) return;
    if (action === 'inventory') { this.pause(true); this.onScreen('inventory'); }
    else if (action === 'screenshot') this.captureScreenshot();
    else if (action === 'chat' || action === 'slash') { this.pause(true); this.onScreen('chat'); }
    else if (action === 'debug') this.debug = !this.debug;
    else if (action === 'perspective') {
      this.thirdPerson = !this.thirdPerson;
      this.hand.visible = !this.thirdPerson;
      this.playerModel.visible = this.thirdPerson;
    }
    else if (action === 'fly' && this.meta.mode === 'creative') {
      this.flying = !this.flying;
      this.velocity.y = 0;
      this.input.sneak = false;
      this.onToast(this.flying ? '飛行モード' : '歩行モード', this.flying ? 'Flight enabled' : 'Flight disabled');
    }
    else if (action.startsWith('slot:')) {
      const s = action.slice(5);
      this.select(s === 'next' ? (this.selected + 1) % 9 : s === 'previous' ? (this.selected + 8) % 9 : Number(s));
    }
    else if (action === 'use') this.use();
    else if (action === 'drop') this.dropSelected();
    else if (action === 'swap') { if (SV.swapSlots(this, this.selected, 40)) this.handDip = 0.2; }
  }


  captureScreenshot() {
    try {
      this.renderer.render(this.scene, this.camera);
      const image = this.canvas.toDataURL('image/png');
      if (image.length < 2000) throw new Error('Empty screenshot');
      const link = document.createElement('a');
      link.href = image;
      link.download = `minecraft-${this.meta.seed}-${new Date().toISOString().replace(/[:.]/g, '-')}.png`;
      document.body.append(link);
      link.click();
      link.remove();
      this.onToast('スクリーンショットを保存しました', 'Screenshot saved');
      return true;
    } catch {
      this.onToast('画像を保存できませんでした', 'Could not save screenshot');
      return false;
    }
  }

  select(slot: number) {
    const next = clamp(slot, 0, 8);
    if (next !== this.selected) this.handDip = 0.25;
    this.selected = next;
    this.breaking = 0;
  }

  getCell(x: number, y: number, z: number) {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    if (y < MIN_Y) return ID.bedrock;
    if (y >= MIN_Y + HEIGHT) return 0;
    // The 3x3 chunk neighbourhood is guaranteed loaded around the player, so redstone next to a border still reads across it.
    const cx = x >> 4, cz = z >> 4;
    let chunk = this._cellChunk;
    if (chunk === null || cx !== this._cellCx || cz !== this._cellCz) {
      const key = cx + ',' + cz;
      chunk = this.chunks.get(key) ?? this.sideChunks.get(key) ?? null;
      if (!chunk) {
        if (!this.pending.has(key) && !this.queued.has(key)) this.invalidate(key);
        return -1;
      }
      this._cellChunk = chunk; this._cellCx = cx; this._cellCz = cz;
    }
    return chunk.data[(y - MIN_Y) * 256 + ((z & 15) << 4) + (x & 15)];
  }

  getBlock(x: number, y: number, z: number) { return blockId(this.getCell(x, y, z)); }

  private weatherSurfaces = new Map<string, { time: number; y: number; solid: boolean }>();

  /** Visual queries never schedule chunks, generate terrain or change block state. */
  visualCell(x: number, y: number, z: number) {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    if (y < MIN_Y || y >= MIN_Y + HEIGHT) return -1;
    const chunk = this.chunks.get((x >> 4) + ',' + (z >> 4)) ?? this.sideChunks.get((x >> 4) + ',' + (z >> 4));
    return chunk ? chunk.data[(y - MIN_Y) * 256 + ((z & 15) << 4) + (x & 15)] : -1;
  }

  visualSurfaceAt(x: number, z: number) {
    x = Math.floor(x); z = Math.floor(z);
    const key = `${this.worldEpoch}:${this.dimension}:${x}:${z}`;
    const cached = this.weatherSurfaces.get(key);
    if (cached && this.elapsed - cached.time < 0.5) return cached;
    const chunk = this.chunks.get((x >> 4) + ',' + (z >> 4)) ?? this.sideChunks.get((x >> 4) + ',' + (z >> 4));
    if (!chunk) return null;
    const column = ((z & 15) << 4) + (x & 15);
    for (let y = HEIGHT - 1; y >= 0; y--) {
      const id = blockId(chunk.data[y * 256 + column]);
      if (BLOCKS[id]?.solid || id === ID.water || id === ID.lava) {
        const surface = { time: this.elapsed, y: y + MIN_Y + 1, solid: !!BLOCKS[id]?.solid };
        if (this.weatherSurfaces.size > 2048) this.weatherSurfaces.clear();
        this.weatherSurfaces.set(key, surface);
        return surface;
      }
    }
    return null;
  }

  setBlock(x: number, y: number, z: number, id: number, state = 0) {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    if (y < MIN_Y || y >= MIN_Y + HEIGHT || !BLOCKS[id] || !Number.isInteger(state) || state < 0 || state > 15) return false;
    const cx = Math.floor(x / 16), cz = Math.floor(z / 16), cKey = cx + ',' + cz;
    const chunk = this.chunks.get(cKey) ?? this.sideChunks.get(cKey);
    if (!chunk) return false;
    if (this.sideChunks.get(cKey) === chunk) this.invalidate(cKey);
    const lx = x - cx * 16, lz = z - cz * 16, index = blockIndex(lx, y, lz), previous = chunk.data[index], cell = makeCell(id, state);
    if (previous === cell) return false;
    const previousId = blockId(previous), key = `${x},${y},${z}`;
    if (previousId !== id) this.gameplay?.beforeReplace(x, y, z, previousId, blockState(previous), id);
    if (previousId === ID.jukebox && id !== ID.jukebox) {
      this.audio?.stopDisc(key);
      const dst = blockState(previous);
      if (!this.containers[key]?.[0] && dst > 0 && MUSIC_DISCS[dst - 1]) {
        this.particles.drop(new THREE.Vector3(x + 0.5, y + 0.6, z + 0.5), MUSIC_DISCS[dst - 1].name, 1, MUSIC_DISCS[dst - 1].color);
      }
    }
    // A generated brewing stand / dispenser / item frame that was never opened still drops what the structure put in it.
    if (previousId !== id && (previousId === ID.item_frame || previousId === ID.brewing_stand || previousId === ID.dispenser)) this.seedNatural(x, y, z);
    if (previousId !== id && [ID.decorated_pot, ID.chest, ID.barrel, ID.shulker_box, ID.furnace, ID.blast_furnace, ID.smoker, ID.brewing_stand, ID.lectern, ID.hopper, ID.dropper, ID.dispenser, ID.crafter, ID.item_frame].includes(previousId)) {
      for (const stack of this.containers[key] ?? []) {
        if (stack) this.particles.drop(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), stack.name, stack.count, resolve(stack.name)?.color ?? '#aaa');
      }
      delete this.containers[key];
      delete this.furnaces[key];
      delete this.crafterDisabled[this.dimension + ':' + key];
    }
    chunk.data[index] = cell;
    if (id === ID.lightning_rod) this.lightningRods.add(key);
    else if (previousId === ID.lightning_rod) this.lightningRods.delete(key);
    this.w121?.onSetBlock(x, y, z, id, previousId);
    this.edits.set(key, cell);
    let bucket = this.editsByChunk.get(cKey);
    if (!bucket) { bucket = new Map(); this.editsByChunk.set(cKey, bucket); }
    bucket.set(key, cell);

    const dxs = lx === 0 ? [-1, 0] : lx === 15 ? [0, 1] : [0];
    const dzs = lz === 0 ? [-1, 0] : lz === 15 ? [0, 1] : [0];
    for (const dz of dzs) for (const dx of dxs) {
      const neighbor = (cx + dx) + ',' + (cz + dz);
      if (this.chunks.has(neighbor) || this.pending.has(neighbor)) this.invalidate(neighbor);
    }
    this.simulation.notify(x, y, z, id);
    this.redstone?.register(x, y, z);
    this.farming?.register(x, y, z);
    if ((previousId === ID.farmland || previousId === ID.farmland_moist) && id !== ID.farmland && id !== ID.farmland_moist && isCrop(this.getBlock(x, y + 1, z))) { const c = this.getCell(x, y + 1, z); this.setBlock(x, y + 1, z, 0); for (const d of blockDrops(BLOCKS[blockId(c)], undefined, blockState(c))) this.particles.drop(new THREE.Vector3(x + 0.5, y + 1.5, z + 0.5), d.name, d.count, '#8a8'); }
    if (this.redstoneWrites === 0) this.redstone?.blockChanged(x, y, z);
    if (previousId !== id) this.gameplay?.afterReplace(x, y, z, previousId, id);
    this.environment.markShadow();
    return true;
  }

  private _ambAt = 0;
  private _amb = { dim: 'overworld', biome: 'plains', y: 64, surface: 64, cave: null as string | null, night: false, underwater: false, raining: false };
  /** Feeds the environment (biome, depth, cave biome, time of day) to the ambient sound layers; terrain queries are throttled to 2 Hz. */
  ambientTick(daylight: number) {
    if (!this.audio) return;
    const now = performance.now();
    if (now - this._ambAt > 500) {
      this._ambAt = now;
      const x = Math.floor(this.position.x), y = Math.floor(this.position.y), z = Math.floor(this.position.z);
      const e = this._amb;
      e.dim = this.dimension; e.y = this.position.y;
      e.biome = this.terrain.biome(x, z);
      e.surface = this.dimension === 'overworld' ? this.terrain.height(x, z) : 0;
      e.cave = this.dimension === 'overworld' ? this.terrain.caveBiome(x, y, z) : null;
      e.underwater = this.getBlock(this.camera.position.x, this.camera.position.y, this.camera.position.z) === ID.water;
      e.raining = (this as unknown as { raining?: boolean }).raining === true;
    }
    this._amb.night = daylight < 0.25;
    this.audio.ambient(this._amb);
  }

  invalidate(key: string) {
    this.versions.set(key, (this.versions.get(key) ?? 0) + 1);
    if (!this.queued.has(key)) { this.queue.unshift(key); this.queued.add(key); }
  }

  stream() {
    const p = this.pendingPlay || this.active || this.meta.id !== 'greenwood' ? this.position : new THREE.Vector3(0, 24, 0);
    const cx = Math.floor(p.x / 16), cz = Math.floor(p.z / 16), radius = this.settings.distance;
    const focus = cx + ',' + cz + ',' + radius + ',' + this.dimension;
    if (focus === this.focus) return;
    this.focus = focus;

    const fx = -Math.sin(this.input.yaw), fz = -Math.cos(this.input.yaw);
    const desired: { key: string; d: number }[] = [];
    for (let z = -radius; z <= radius; z++) {
      for (let x = -radius; x <= radius; x++) {
        if (x * x + z * z > (radius + 0.5) ** 2) continue;
        const key = (cx + x) + ',' + (cz + z);
        const dist = x * x + z * z;
        const dot = dist > 0 ? (x * fx + z * fz) / Math.sqrt(dist) : 1;
        desired.push({ key, d: dist - dot * 2.5 });
      }
    }
    desired.sort((a, b) => a.d - b.d);
    this._cellChunk = null;
    for (const { key } of desired) {
      if (this.chunks.has(key)) continue;
      // A ring chunk that came into range already has its data and meshes: promote it instead of generating it a second time.
      const ring = this.sideChunks.get(key);
      if (ring) {
        if (ring.solid) {
          this.sideChunks.delete(key);
          this.chunks.set(key, ring);
          this.redstone?.scanChunk(ring.data, ring.cx, ring.cz, HEIGHT, MIN_Y, Math.ceil(ring.maxY) + 2);
          this.farming?.scanChunk(ring.data, ring.cx, ring.cz, HEIGHT, MIN_Y, Math.ceil(ring.maxY) + 2);
          continue;
        }
      }
      if (!this.queued.has(key) && !this.pending.has(key)) {
        this.queue.push(key);
        this.queued.add(key);
      }
    }

    // One extra ring of block data (no meshes) so machines straddling a chunk border always read real blocks.
    // The ring is a true ring (one chunk wide). It used to be the corners of a square, which lie beyond the unload distance below:
    // those chunks were generated, dropped and generated again every time the player crossed a chunk border.
    for (let z = -radius - 2; z <= radius + 2; z++) for (let x = -radius - 2; x <= radius + 2; x++) {
      const ringDist = Math.hypot(x, z);
      if (ringDist <= radius + 0.5 || ringDist > radius + 1.5) continue;
      const key = (cx + x) + ',' + (cz + z);
      if (!this.chunks.has(key) && !this.sideChunks.has(key) && !this.queued.has(key) && !this.pending.has(key)) {
        this.queue.push(key);
        this.queued.add(key);
      }
    }
    for (const [key, c] of this.chunks) {
      if (Math.hypot(c.cx - cx, c.cz - cz) > radius + 2) {
        this.disposeChunk(c);
        this.chunks.delete(key);
      }
    }
    for (const [key, c] of this.sideChunks) {
      if (Math.hypot(c.cx - cx, c.cz - cz) > radius + 2) {
        // disposeChunk also removes the meshes from the scene and frees their buffers (they used to be left behind).
        this.disposeChunk(c);
        this.sideChunks.delete(key);
      }
    }
    this.queue = this.queue.filter(key => {
      const sep = key.indexOf(',');
      const x = Number(key.slice(0, sep)), z = Number(key.slice(sep + 1));
      if (Math.hypot(x - cx, z - cz) > radius + 2) { this.queued.delete(key); return false; }
      return true;
    });
  }

  dispatch() {
    for (const slot of this.workers) {
      if (slot.busy || !this.queue.length) continue;
      const next = this.queue.findIndex(key => !this.pending.has(key));
      if (next < 0) continue;
      const [key] = this.queue.splice(next, 1);
      this.queued.delete(key);
      const sep = key.indexOf(',');
      const cx = Number(key.slice(0, sep)), cz = Number(key.slice(sep + 1));
      const version = this.versions.get(key) ?? 0;
      slot.busy = true; slot.key = key; slot.epoch = this.worldEpoch;
      this.pending.add(key);

      // O(1) lookup across the 3x3 chunk neighborhood
      const edits: [string, number][] = [];
      for (let dz = -1; dz <= 1; dz++) {
        for (let dx = -1; dx <= 1; dx++) {
          const bucket = this.editsByChunk.get((cx + dx) + ',' + (cz + dz));
          if (bucket) for (const entry of bucket) edits.push(entry);
        }
      }

      slot.worker.postMessage({
        key, cx, cz, version, epoch: this.worldEpoch,
        seed: this.meta.seed, dimension: this.dimension, edits,
        structures: this.meta.structures, tiles: slot.tilesSent ? undefined : this.tiles,
      });
      slot.tilesSent = true;
    }
  }

  geometry(m: MeshData, minY = 0, maxY = 0) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(m.position, 3));
    g.setAttribute('normal', new THREE.BufferAttribute(m.normal, 3));
    g.setAttribute('uv', new THREE.BufferAttribute(m.uv, 2));
    g.setAttribute('color', new THREE.BufferAttribute(m.color, 3));
    g.setAttribute('tile', new THREE.BufferAttribute(m.tile, 1));
    g.setAttribute('wind', new THREE.BufferAttribute(m.wind, 1));
    g.setAttribute('aLight', new THREE.BufferAttribute(m.light, 2));
    g.setIndex(new THREE.BufferAttribute(m.index, 1));
    // Bounds come from the worker, so the main thread never walks the vertices.
    const half = (maxY - minY) * 0.5;
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(8, minY + half, 8), Math.hypot(12, half + 1));
    return g;
  }

  receive(m: any, slot: WorkerSlot) {
    slot.busy = false;
    if (this.disposed || m.epoch !== this.worldEpoch) return;
    this.pending.delete(m.key);
    if (m.type === 'error') {
      this.invalidate(m.key);
      this.onToast('チャンクを再生成しています', 'Regenerating chunk');
      return;
    }
    if ((this.versions.get(m.key) ?? 0) !== m.version) {
      if (!this.queued.has(m.key)) { this.queue.unshift(m.key); this.queued.add(m.key); }
      return;
    }
    if (!this.ready) {
      this.mountChunk(m);
    } else {
      this.uploadQueue.push({ m });
    }
  }

  private mountChunk(m: any) {
    if ((this.versions.get(m.key) ?? 0) !== m.version) return;
    if (this._cellChunk && this._cellCx === m.cx && this._cellCz === m.cz) this._cellChunk = null;
    const usePosition = this.pendingPlay || this.active || this.meta.id !== 'greenwood';
    const pcx8 = usePosition ? Math.floor(this.position.x / 16) : 0;
    const pcz8 = usePosition ? Math.floor(this.position.z / 16) : 0;
    const side = !this.chunks.has(m.key) && Math.hypot(m.cx - pcx8, m.cz - pcz8) > this.settings.distance + 0.5;
    const old = this.chunks.get(m.key);
    if (old) this.disposeChunk(old, true);
    const sideOld = this.sideChunks.get(m.key);
    if (sideOld) {
      this.disposeChunk(sideOld, true);
      this.sideChunks.delete(m.key);
    }
    const chunkData = new Uint16Array(m.data);
    this.w121?.scanChunk(chunkData, m.cx, m.cz);
    const minY: number = Number.isFinite(m.minY) ? m.minY : MIN_Y;
    const maxY: number = Number.isFinite(m.maxY) ? m.maxY : MIN_Y + HEIGHT;
    const hasSolid = m.solid.index.length > 0, hasWater = m.water.index.length > 0;
    const solid = new THREE.Mesh(this.geometry(m.solid, minY, maxY), this.environment.failed ? this.environment.fallback : this.environment.material);
    const water = new THREE.Mesh(this.geometry(m.water, minY, maxY), this.environment.water);
    solid.position.set(m.cx * 16, 0, m.cz * 16);
    water.position.copy(solid.position);
    solid.matrixAutoUpdate = false; solid.updateMatrix();
    water.matrixAutoUpdate = false; water.updateMatrix();
    solid.frustumCulled = false; water.frustumCulled = false;
    solid.visible = !side && hasSolid;
    water.visible = !side && hasWater;
    solid.customDepthMaterial = this.environment.depthMaterial;
    solid.castShadow = false;
    solid.receiveShadow = true;
    water.renderOrder = 2;
    this.scene.add(solid);
    if (hasWater) this.scene.add(water);
    const chunk: Chunk = { cx: m.cx, cz: m.cz, data: chunkData, solid, water, version: m.version, minY, maxY, hasSolid, hasWater };
    if (side) {
      this.sideChunks.set(m.key, chunk);
      return;
    }
    this.chunks.set(m.key, chunk);
    this.redstone?.scanChunk(chunk.data, m.cx, m.cz, HEIGHT, MIN_Y, m.genMaxY);
    this.farming?.scanChunk(chunk.data, m.cx, m.cz, HEIGHT, MIN_Y, m.genMaxY);
  }

  private cullChunks() {
    const cam = this.camera;
    cam.updateMatrixWorld();
    this._frustum.setFromProjectionMatrix(this._viewProj.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
    const shadowFrame = this.renderer.shadowMap.enabled && this.renderer.shadowMap.needsUpdate;
    const usePos = this.pendingPlay || this.active || this.meta.id !== 'greenwood';
    const pcx = usePos ? Math.floor(this.position.x / 16) : 0, pcz = usePos ? Math.floor(this.position.z / 16) : 0, box = this._cullBox, frustum = this._frustum;
    for (const c of this.chunks.values()) {
      const x0 = c.cx * 16, z0 = c.cz * 16;
      box.min.set(x0 - 0.5, c.minY - 0.5, z0 - 0.5);
      box.max.set(x0 + 16.5, c.maxY + 0.5, z0 + 16.5);
      const dcx = c.cx - pcx, dcz = c.cz - pcz, caster = dcx * dcx + dcz * dcz <= 4;
      const seen = frustum.intersectsBox(box) || (shadowFrame && caster);
      c.solid.castShadow = caster;
      c.solid.visible = seen && c.hasSolid;
      c.water.visible = seen && c.hasWater;
    }
    for (const c of this.sideChunks.values()) {
      c.solid.castShadow = false;
      c.solid.visible = false;
      c.water.visible = false;
    }
  }

  /** Player box against the world. The height follows the pose: 1.8 standing, 1.5 sneaking, 0.6 crawling / swimming. */
  collides(p: THREE.Vector3, height = this.gameplay ? this.gameplay.height() : (this.input.crouch && !this.flying ? 1.5 : 1.8)) {
    const minX = p.x - 0.29, maxX = p.x + 0.29, minY = p.y + 0.001, maxY = p.y + height - 0.001, minZ = p.z - 0.29, maxZ = p.z + 0.29;
    for (let y = Math.floor(minY); y <= Math.floor(maxY); y++) {
      for (let z = Math.floor(minZ); z <= Math.floor(maxZ); z++) {
        for (let x = Math.floor(minX); x <= Math.floor(maxX); x++) {
          const cell = this.getCell(x, y, z), id = blockId(cell);
          if (id === -1) return true;
          const def = BLOCKS[id];
          if (id === ID.scaffolding || id === ID.powder_snow) {
            if (this.gameplay.specialCollision(id, blockState(cell), x, y, z, minX, minY, minZ, maxX, maxY, maxZ)) return true;
            continue;
          }
          if (!def?.solid) continue;
          for (const box of collisionBoxes(def, blockState(cell))) {
            if (intersectsBox(x, y, z, minX, minY, minZ, maxX, maxY, maxZ, box)) return true;
          }
        }
      }
    }
    return false;
  }

  supported(p: THREE.Vector3) {
    return this.collides(this._supportPos.set(p.x, p.y - 0.08, p.z));
  }

  physics(dt: number) {
    if (this.sleeping) return;
    const input = this.input, move = input.move;
    // Riding a vehicle or a mob: the mount moves, the player follows its seat (sneak to dismount).
    const drive = { move, yaw: input.yaw, run: input.run, ascend: input.ascend };
    const heldRideItem = this.hotbar[this.selected]?.name;
    const carrot = heldRideItem === 'carrot_on_a_stick' || heldRideItem === 'warped_fungus_on_a_stick';
    const seat = this.vehicles.update(dt, this.vehicles.riding ? drive : null) ?? (this.mobs.riding ? this.mobs.drive(dt, drive, carrot) : null);
    if (seat) {
      this.position.copy(seat);
      this.velocity.set(0, 0, 0); this.grounded = true; this.gliding = false; this.fallTop = seat.y;
      if (input.crouch && this.dismountCooldown <= 0) {
        const out = this.vehicles.riding ? this.vehicles.dismount() : this.mobs.dismount();
        if (out) this.position.copy(out);
        this.dismountCooldown = 0.6;
      }
      this.placeCamera(dt, Math.hypot(move.x, move.z) > 0.1, false);
      return;
    }
    if (this.mobs.riding === null && this.vehicles.riding === null && this.dismountCooldown > 0.59) this.dismountCooldown = 0.59;
    const water = this.gameplay.isWater(this.position.x, this.position.y + 0.6, this.position.z);
    const spectator = this.meta.mode === 'spectator';
    this.gameplay.beginPhysics(water, Math.hypot(move.x, move.z) > 0.1, h => !this.collides(this.position, h));
    const onLadder = ID.ladder !== undefined && (this.getBlock(this.position.x, this.position.y + 0.2, this.position.z) === ID.ladder || this.getBlock(this.position.x, this.position.y + 1.2, this.position.z) === ID.ladder);

    if (this.grounded || water || this.flying || onLadder) this.gliding = false;
    // Allow mid-air Space press to initiate Elytra glide
    if (this.elytraEquipped && !this.grounded && !water && !this.flying && !onLadder && this.velocity.y < -2.5 && input.ascend) {
      this.gliding = true;
    }

    if (this.gliding) {
      this.camera.getWorldDirection(this._dir);
      const horizSpeed = Math.hypot(this.velocity.x, this.velocity.z);
      const pitchFactor = -Math.sin(this.input.pitch); // positive when diving
      const targetSpeed = clamp(horizSpeed + pitchFactor * 16 * dt + 2 * dt, 7, 26);
      const fx = -Math.sin(this.input.yaw), fz = -Math.cos(this.input.yaw);
      this.velocity.x = fx * targetSpeed;
      this.velocity.z = fz * targetSpeed;
      this.velocity.y = clamp(this._dir.y * targetSpeed * 0.85 - 1.2, -16, 10);
      this.fallTop = this.position.y;
    }

    let speed = this.flying ? (input.run ? 15.5 : 9) : water ? 2.9 : input.crouch ? 1.65 : input.run && (this.meta.mode === 'creative' || V.canSprintWith(this.hunger)) ? 6.6 : 4.35;
    if (spectator) speed = 13;
    else if (!this.flying) speed = this.gameplay.adjustSpeed(speed * SV.speedFactor(this), water);

    if (!this.gliding) {
      if (this.flying || spectator) {
        this.velocity.y = (+input.ascend - +input.descend) * speed;
      } else if (this.levitationTimer > 0) {
        this.levitationTimer -= dt;
        this.velocity.y = 2.6;
        this.fallTop = this.position.y;
      } else if (water) {
        this.velocity.y += (-3 - this.velocity.y * 3) * dt;
        if (input.ascend) this.velocity.y = 3.6;
        this.fallTop = this.position.y;
      } else if (onLadder) {
        // Ladders: climb by walking into them or jumping, hold still while sneaking, otherwise slide down slowly. No fall damage.
        this.velocity.y = input.ascend || Math.hypot(move.x, move.z) > 0.1 ? 2.35 : input.crouch ? 0 : -2.2;
        this.fallTop = this.position.y;
      } else {
        this.velocity.y -= 24 * dt;
        if (SV.has(this, 'slow_falling') && this.velocity.y < -1.8) { this.velocity.y = -1.8; this.fallTop = this.position.y; }
        if (input.ascend && this.grounded) {
          this.velocity.y = 8.25 + SV.jumpBoost(this);
          if (!this.flying) SV.exhaust(this, input.run && V.canSprintWith(this.hunger) ? 0.2 : 0.05);   // sprint-jump 0.2, jump 0.05
          this.grounded = false;
        }
      }
    }

    if (!this.gliding && !this.flying && !spectator && this.levitationTimer <= 0) {
      this.velocity.y = this.gameplay.adjustVertical(this.velocity.y, dt, water, onLadder);
      if (this.gameplay.noFall) this.fallTop = this.position.y;
    }

    const oldX = this.position.x, oldY = this.position.y, oldZ = this.position.z;
    const wasGrounded = this.grounded;
    this.grounded = false;
    const vxMove = this.gliding ? this.velocity.x : move.x * speed;
    const vzMove = this.gliding ? this.velocity.z : move.z * speed;

    for (const [axis, delta] of [['x', vxMove * dt], ['z', vzMove * dt]] as const) {
      const prev = this.position[axis];
      this.position[axis] += delta;
      if (!spectator && this.collides(this.position)) {
        let stepped = false;
        if (wasGrounded && !input.crouch && !this.flying && !this.gliding) {
          this.position.y += 0.6;
          if (!this.collides(this.position)) stepped = true;
          else this.position.y -= 0.6;
        }
        if (!stepped) {
          this.position[axis] = prev;
          if (this.gliding) this.gliding = false;
        }
      }
      if (input.crouch && !this.flying && !spectator && wasGrounded && !this.supported(this.position)) {
        this.position[axis] = prev;
      }
    }

    const py = this.position.y, verticalMove = this.velocity.y * dt;
    this.position.y += verticalMove;
    if (!spectator && this.collides(this.position)) {
      let safe = 0, blocked = 1;
      for (let i = 0; i < 12; i++) {
        const mid = (safe + blocked) / 2;
        this.position.y = py + verticalMove * mid;
        if (this.collides(this.position)) blocked = mid;
        else safe = mid;
      }
      this.position.y = py + verticalMove * safe;
      if (this.velocity.y < 0) {
        const landedOn = this.getBlock(this.position.x, this.position.y - 0.1, this.position.z);
        const fall = this.fallTop - this.position.y;
        if (landedOn === ID.slime_block && !this.input.crouch && this.velocity.y < -1.5) {
          this.velocity.y = Math.min(18, -this.velocity.y * 0.85);
          this.grounded = false;
          this.fallTop = this.position.y;
        } else {
          this.grounded = true;
          if (fall > 1.0 && !water && !this.flying && !this.gliding && !onLadder && !this.input.crouch) {
            this.farming.trample(this.position.x, this.position.y - 0.1, this.position.z);
          }
          if (fall > 3.5 && landedOn !== ID.slime_block && landedOn !== ID.hay_block && !water && !this.flying && !this.gliding && !onLadder && !this.gameplay.noFall) SV.fallDamage(this, fall);
          this.gameplay.landed(fall);
          this.gliding = false;
          this.fallTop = this.position.y;
          this.velocity.y = 0;
        }
      } else {
        this.velocity.y = 0;
      }
    }

    if (this.grounded || this.flying || water || this.gliding || onLadder || this.gameplay.noFall) this.fallTop = this.position.y;
    else this.fallTop = Math.max(this.fallTop, this.position.y);

    if (this.position.y < MIN_Y - 10) {
      if (this.meta.mode === 'creative') { this.position.y = 130; this.velocity.y = 0; }
      else this.damage(20, 'void');
    }

    // Check Portal / End Portal / End Gateway / Hazards
    const blockAtFeet = this.getBlock(this.position.x, this.position.y + 0.5, this.position.z);
    const blockAtBody = this.getBlock(this.position.x, this.position.y + 1.1, this.position.z);
    if (this.portalLock && blockAtFeet >= 0 && blockAtFeet !== ID.portal && blockAtBody !== ID.portal) this.portalLock = false;
    if (this.portalLock) {
      this.portalCharge = 0;
    } else if (blockAtFeet === ID.portal || blockAtBody === ID.portal) {
      this.portalCharge += dt / 1.2;
      if (this.portalCharge >= 1) {
        this.portalCharge = 0;
        this.audio?.play('portal');
        this.travelNetherPortal();
        return;
      }
    } else if (blockAtFeet === ID.end_portal || blockAtBody === ID.end_portal) {
      this.audio?.play('portal');
      this.enterEndPortal();
      return;
    } else if (blockAtFeet === ID.end_gateway || blockAtBody === ID.end_gateway) {
      this.audio?.play('portal');
      this.handleGatewayTravel();
      return;
    } else {
      this.portalCharge = Math.max(0, this.portalCharge - dt * 2);
    }

    // Cactus, Lava & Fire damage
    if (!spectator && this.meta.mode !== 'creative' && this.elapsed - this.hazardAt > 0.55) {
      const nearCactus = [
        this.getBlock(this.position.x + 0.35, this.position.y + 0.5, this.position.z),
        this.getBlock(this.position.x - 0.35, this.position.y + 0.5, this.position.z),
        this.getBlock(this.position.x, this.position.y + 0.5, this.position.z + 0.35),
        this.getBlock(this.position.x, this.position.y + 0.5, this.position.z - 0.35),
      ].includes(ID.cactus);
      if (nearCactus) { this.hazardAt = this.elapsed; this.damage(1, 'contact'); }
      else if (blockAtFeet === ID.lava || blockAtFeet === ID.fire || blockAtBody === ID.lava) { this.hazardAt = this.elapsed; this.damage(4, 'fire'); }
    }

    const stepDist = Math.hypot(this.position.x - oldX, this.position.y - oldY, this.position.z - oldZ);
    if (wasGrounded && stepDist > 0.01) {
      this.statistics.distance_walked = (this.statistics.distance_walked ?? 0) + stepDist;
      const stepInterval = input.run ? 0.28 : 0.38;
      if (this.elapsed - this.stepAt > stepInterval) {
        this.stepAt = this.elapsed;
        this.gameplay.vibrate(water ? 'swim' : 'step', this.position.x, this.position.y, this.position.z, { sneaking: input.crouch });
        const ground = BLOCKS[this.getBlock(this.position.x, this.position.y - 0.1, this.position.z)];
        this.audio?.play(
          water ? 'water' :
          ground?.pattern === 'sand' || ground?.pattern === 'gravel' ? 'sand' :
          ground?.tool === 'pickaxe' ? 'stone' :
          ground?.tool === 'axe' ? 'wood' : 'grass',
        );
      }
    }

    this.placeCamera(dt, Math.hypot(move.x, move.z) > 0.1, water);
  }

  /** Eye height, FOV kick and third-person camera / player model. */
  placeCamera(dt: number, isMoving: boolean, water: boolean) {
    // Java Edition dynamic FOV
    const eyeBlock = this.getBlock(this.position.x, this.position.y + 1.5, this.position.z);
    this.environment.updateFov(this.camera, this.settings.fov, {
      sprinting: input.run && isMoving && !input.crouch && (this.meta.mode === 'creative' || V.canSprintWith(this.hunger)),
      flying: this.flying,
      speed: SV.amp(this, 'speed'),
      slowness: SV.amp(this, 'slowness'),
      bowTicks: this.useItemName === 'bow' && this.useTime > 0 ? this.useTime * 20 : 0,
      submerged: eyeBlock === ID.water || eyeBlock === ID.lava,
      scope: this.useItemName === 'spyglass' && this.input.useHeld ? SPYGLASS_FOV_SCALE : 0,
    }, dt);

    const input = this.input, move = input.move;
    void water;
    // Smooth sprint/underwater FOV kick
    const eyeUnderwater = this.getBlock(this.position.x, this.position.y + 1.5, this.position.z) === ID.water;
    const targetFov = this.settings.fov + (input.run && isMoving ? 7 : 0) - (eyeUnderwater ? 7 : 0);
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 10);
      this.camera.updateProjectionMatrix();
    }

    // Eye & third-person camera placement
    this.eyeNow += (this.gameplay.eyeHeight() - this.eyeNow) * Math.min(1, dt * 14);
    const eyeY = this.position.y + this.eyeNow +
      (this.settings.bobbing && this.grounded && !this.thirdPerson ? Math.sin(this.elapsed * 11) * Math.min(0.035, move.x ** 2 + move.z ** 2) * 0.035 : 0);

    if (this.thirdPerson) {
      const cosPitch = Math.cos(this.input.pitch);
      this._dir.set(-Math.sin(this.input.yaw) * cosPitch, Math.sin(this.input.pitch), -Math.cos(this.input.yaw) * cosPitch);
      this._camTarget.set(this.position.x, eyeY, this.position.z);
      const backHit = traceVoxelRay([this._camTarget.x, this._camTarget.y, this._camTarget.z], [-this._dir.x, -this._dir.y, -this._dir.z], 4.2, (x, y, z) => {
        const b = this.getBlock(x, y, z);
        return b > 0 && BLOCKS[b]?.solid ? b : 0;
      });
      const pull = backHit ? Math.max(0.6, backHit.distance - 0.25) : 4.2;
      this.camera.position.copy(this._camTarget).addScaledVector(this._dir, -pull);

      // Animate Steve player model
      this.playerModel.visible = true;
      this.playerModel.position.copy(this.position);
      this.playerModel.rotation.y = this.input.yaw;
      this.playerModel.rotation.x = this.gliding ? -Math.PI / 2.3 + this.input.pitch * 0.45 : 0;
      this.playerHead.rotation.x = this.gliding ? 0.5 : this.input.pitch;
      const walkSwing = isMoving && this.grounded ? Math.sin(this.elapsed * (input.run ? 14 : 10)) * 0.65 : 0;
      this.playerLegs[0].rotation.x = walkSwing;
      this.playerLegs[1].rotation.x = -walkSwing;
      this.playerArms[0].rotation.x = -walkSwing;
      this.playerArms[1].rotation.x = walkSwing - (this.input.mining ? Math.abs(Math.sin(this.elapsed * 16)) * 1.1 : 0);
    } else {
      this.playerModel.visible = false;
      this.camera.position.set(this.position.x, eyeY, this.position.z);
    }
  }

  raycast(): Target | null {
    const origin = this.camera.position, cosPitch = Math.cos(this.input.pitch);
    const reach = this.meta.mode === 'creative' ? 5.6 : 4.6;
    const hit = traceVoxelRay(
      [origin.x, origin.y, origin.z],
      [-Math.sin(this.input.yaw) * cosPitch, Math.sin(this.input.pitch), -Math.cos(this.input.yaw) * cosPitch],
      reach,
      (x, y, z) => this.getCell(x, y, z),
    );
    return hit ? { ...hit, normal: new THREE.Vector3(hit.normal.x, hit.normal.y, hit.normal.z) } : null;
  }

  private updateOutline() {
    if (!this.target) {
      this.outline.visible = false;
      return;
    }
    const t = this.target;
    const cell = this.getCell(t.x, t.y, t.z);
    const def = BLOCKS[t.id];
    const boxes = def ? selectionBoxes(def, blockState(cell)) : null;
    if (boxes && boxes.length > 0) {
      const [x0, y0, z0, x1, y1, z1] = boxes[0];
      this.outline.scale.set((x1 - x0) + 0.008, (y1 - y0) + 0.008, (z1 - z0) + 0.008);
      this.outline.position.set(t.x + (x0 + x1) * 0.5, t.y + (y0 + y1) * 0.5, t.z + (z0 + z1) * 0.5);
    } else {
      this.outline.scale.set(1, 1, 1);
      this.outline.position.set(t.x + 0.5, t.y + 0.5, t.z + 0.5);
    }
    this.outline.visible = true;
  }

  mining(dt: number) {
    this.breakCooldown = Math.max(0, this.breakCooldown - dt);
    this.target = this.raycast();
    this.updateOutline();
    this.crack.visible = false;

    if (!this.input.mining || this.meta.mode === 'spectator' || this.meta.mode === 'adventure') {
      this.breaking = 0;
      this.swingHeld = false;
      return;
    }

    const held = this.hotbar[this.selected], tool = held ? resolve(held.name) : undefined;

    // Vehicles can be broken with a few hits (drops the item).
    if (!this.swingHeld) {
      this.camera.getWorldDirection(this._dir);
      const v = this.vehicles.pick(this.camera.position, this._dir);
      if (v) { this.vehicles.hit(v); this.swingHeld = true; this.handDip = 0.2; this.audio?.play('wood', v.pos); this.breaking = 0; return; }
    }
    // Mob attack runs FIRST: cooldown-scaled damage, crits, sweeps and weapon enchantments live in survival.ts.
    if (SV.tryAttack(this, held ?? null, tool)) {
      this.breaking = 0;
      return;
    }

    if (!this.target || this.breakCooldown > 0) {
      this.breaking = 0;
      return;
    }

    if (this.meta.mode === 'creative' && tool?.tool === 'sword') return;

    const t = this.target, b = BLOCKS[t.id];
    if (!Number.isFinite(b.hardness)) return;

    if (this.elapsed - this.hitAt > 0.25) {
      this.hitAt = this.elapsed;
      this.audio?.play(
        b.pattern === 'glass' ? 'glass' :
        b.pattern === 'sand' || b.pattern === 'gravel' ? 'sand' :
        b.tool === 'pickaxe' ? 'stone' : 'wood',
        t,
      );
    }

    const key = `${t.x},${t.y},${t.z}:${this.selected}:${held?.name ?? ''}`;
    if (key !== this.breakKey) { this.breakKey = key; this.breaking = 0; }

    const underwater = this.getBlock(this.camera.position.x, this.camera.position.y, this.camera.position.z) === ID.water;
    const duration = this.meta.mode === 'creative' ? 0 : miningTime(b, tool, this.grounded, underwater) * SV.miningFactor(this, held ?? null, underwater);
    this.breaking += duration === 0 ? 1 : dt / duration;

    if (this.breaking >= 1) {
      this.particles.burst(new THREE.Vector3(t.x + 0.5, t.y + 0.5, t.z + 0.5), b.color, 18);
      if (this.meta.mode !== 'creative') {
        if (t.id !== ID.shulker_box) for (const drop of SV.drops(this, b, tool, held ?? null, blockState(this.getCell(t.x, t.y, t.z)))) {
          this.particles.drop(new THREE.Vector3(t.x + 0.5, t.y + 0.5, t.z + 0.5), drop.name, drop.count, resolve(drop.name)?.color ?? b.color);
        }
        if (held && tool?.durability && b.hardness > 0) SV.wear(this, 'main', 1);
      }
      const brokenState = blockState(this.getCell(t.x, t.y, t.z));
      if (t.id === ID.obsidian) this.shatterAdjacentPortal(t.x, t.y, t.z);
      this.setBlock(t.x, t.y, t.z, 0);
      this.mobs.noise(t.x, t.y, t.z, 1);
      this.afterBreak(t.x, t.y, t.z, b, brokenState);
      this.gameplay.broken(t.x, t.y, t.z, b, brokenState, held?.name ?? '');
      this.audio?.play(b.pattern === 'glass' ? 'glass' : b.tool === 'pickaxe' ? 'stone' : b.tool === 'axe' ? 'wood' : 'grass', t);
      SV.exhaust(this, 0.005);
      this.statistics.blocks_mined = (this.statistics.blocks_mined ?? 0) + 1;
      if (this.meta.mode !== 'creative') {
        const xpGain = blockExperience(b, tool);
        if (xpGain > 0) this.addXp(xpGain);
      }
      this.breaking = 0;
      this.breakCooldown = this.meta.mode === 'creative' ? 0.22 : duration === 0 ? 0 : 0.25;
      this.achievement('mine');
    } else if (this.meta.mode !== 'creative') {
      this.crack.visible = true;
      this.crack.position.set(t.x + 0.5, t.y + 0.5, t.z + 0.5);
      this.crack.material = this.crackMaterials[Math.min(9, Math.floor(this.breaking * 10))];
    }
  }


  private shatterAdjacentPortal(x: number, y: number, z: number) {
    for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
      if (this.getBlock(x + dx, y + dy, z + dz) === ID.portal) {
        const q = [[x + dx, y + dy, z + dz]];
        const seen = new Set<string>();
        while (q.length && seen.size < 120) {
          const [px, py, pz] = q.pop()!;
          const k = `${px},${py},${pz}`;
          if (seen.has(k) || this.getBlock(px, py, pz) !== ID.portal) continue;
          seen.add(k);
          this.setBlock(px, py, pz, 0);
          for (const [nx, ny, nz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
            q.push([px + nx, py + ny, pz + nz]);
          }
        }
      }
    }
  }

  private tryLightNetherPortal(x: number, y: number, z: number): boolean {
    if (this.dimension === 'end') return false;
    for (const axis of ['x', 'z'] as const) {
      const step = (dx: number, dy: number): [number, number, number] => axis === 'x' ? [x + dx, y + dy, z] : [x, y + dy, z + dx];
      const visited = new Set<string>();
      const queue: [number, number][] = [[0, 0]];
      const inside: [number, number, number][] = [];
      let valid = true;
      while (queue.length) {
        const [u, v] = queue.pop()!;
        if (Math.abs(u) > 9 || Math.abs(v) > 9) { valid = false; break; }
        const k = `${u},${v}`;
        if (visited.has(k)) continue;
        visited.add(k);
        const [wx, wy, wz] = step(u, v);
        const id = this.getBlock(wx, wy, wz);
        if (id === ID.obsidian) continue;
        if (id === 0 || id === ID.fire) {
          inside.push([wx, wy, wz]);
          queue.push([u + 1, v], [u - 1, v], [u, v + 1], [u, v - 1]);
        } else { valid = false; break; }
      }
      if (valid && inside.length >= 6 && inside.length <= 64) {
        for (const [px, py, pz] of inside) this.setBlock(px, py, pz, ID.portal);
        this.audio?.play('portal', { x, y, z });
        this.particles.burst(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), '#b866ff', 28, 4);
        this.achievement('nether');
        this.onToast('ネザーポータルが開きました！', 'Nether Portal ignited!');
        return true;
      }
    }
    return false;
  }

  private checkActivateEndPortal(cx: number, cy: number, cz: number) {
    for (let oy = -1; oy <= 1; oy++) for (let oz = -4; oz <= 4; oz++) for (let ox = -4; ox <= 4; ox++) {
      const rx = cx + ox, ry = cy + oy, rz = cz + oz;
      let ok = true;
      const ringOffsets = [
        [-1, -2], [0, -2], [1, -2],
        [2, -1], [2, 0], [2, 1],
        [1, 2], [0, 2], [-1, 2],
        [-2, 1], [-2, 0], [-2, -1],
      ];
      for (const [dx, dz] of ringOffsets) {
        const cell = this.getCell(rx + dx, ry, rz + dz);
        if (blockId(cell) !== ID.end_portal_frame || (blockState(cell) & 4) === 0) { ok = false; break; }
      }
      if (ok) {
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
          this.setBlock(rx + dx, ry, rz + dz, ID.end_portal);
        }
        this.audio?.play('portal', { x: rx, y: ry, z: rz });
        this.particles.burst(new THREE.Vector3(rx + 0.5, ry + 1, rz + 0.5), '#55f2c4', 40, 6);
        this.onToast('エンドポータルが開通しました！', 'The End Portal is open!');
        return;
      }
    }
  }

  private travelNetherPortal() {
    SV.netherTravel(this);
  }

  private enterEndPortal() {
    if (this.dimension === 'end') {
      this.changeDimension('overworld');
      const p = this.respawnPoint ?? this.terrain.spawnPosition(2);
      this.position.set(p[0], p[1], p[2]);
      this.pause();
      this.onScreen('credits');
      return;
    }
    this.changeDimension('end');
    this.position.set(0.5, 30.5, 42.5);
    this.achievement('end');
  }

  handleDragonDefeated() {
    this.dragonDefeated = true;
    this.mobs.host.dragonDefeated = true;
    this.addXp(500);
    this.achievement('dragon');
    this.onToast('エンダードラゴンを討伐しました！エンドゲートウェイが出現！', 'Ender Dragon defeated! End Gateway opened!');
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dz === 0) continue;
      this.setBlock(dx, 28, dz, ID.end_portal);
    }
    this.setBlock(0, 32, 0, ID.dragon_egg);
    const [gx, gy, gz] = END_GATEWAY_MAIN;
    this.setBlock(gx, gy, gz, ID.end_gateway);
    this.save();
  }

  handleGatewayTravel() {
    if (this.dimension !== 'end') return;
    if (this.position.distanceTo(new THREE.Vector3(...END_GATEWAY_MAIN)) < 20) {
      this.teleport(END_OUTER_ARRIVAL[0], END_OUTER_ARRIVAL[1], END_OUTER_ARRIVAL[2]);
      this.onToast('エンドの外周島（エンドシティ）へ転移しました！', 'Warped to Outer End Islands & End City!');
    } else {
      this.teleport(42, 30, 0);
      this.onToast('エンド本島へ戻りました', 'Returned to Main End Island');
    }
  }

  /**
   * Right-click, Java style: the main hand acts first; only when it passes (nothing placed, used or opened) is the off-hand tried.
   * The off-hand attempt swaps the two stacks around the shared handling code, so placing blocks, eating, buckets, bows, shields and
   * books all work from the off-hand with exactly the same rules and consumption.
   */
  use() {
    if (this.dead) return;
    SV.useBothHands(this, () => this.useInHand());
  }

  /** One hand's right-click: returns true when this hand's item / the targeted block consumed the click (Java: not PASS). */
  private useInHand(): boolean {
    if (this.dead) return true;
    this.target = this.raycast();
    const held = this.hotbar[this.selected], def = held ? resolve(held.name) : undefined;
    this.camera.getWorldDirection(this._dir);
    if (this.w121.use(this.target, held ?? null)) { this.handDip = Math.max(this.handDip, 0.14); return true; }
    if (this.target) {
      const tt = this.target, hit = this.camera.position.clone().addScaledVector(this._dir, tt.distance);
      if (this.gameplay.interact(tt, held ?? null, hit)) { this.handDip = 0.18; return true; }
    }
    if (SV.useItem(this, held ?? null, def, this.handCtx)) return true;
    if (this.useExtras(held ?? null)) return true;

    // Equip / Toggle Elytra
    if (held?.name === 'elytra') {
      this.elytraEquipped = !this.elytraEquipped;
      this.onToast(this.elytraEquipped ? 'エリトラを装備しました！' : 'エリトラを外しました', this.elytraEquipped ? 'Elytra equipped!' : 'Elytra unequipped');
      this.audio?.play('wood');
      this.handDip = 0.18;
      return true;
    }

    // Firework rocket boost while gliding!
    if (held?.name === 'firework_rocket' && this.gliding) {
      this.velocity.copy(this._dir).multiplyScalar(26);
      this.particles.burst(this.position.clone().add(new THREE.Vector3(0, 1, 0)), '#ff7052', 20, 6);
      this.audio?.play('explosion');
      this.handDip = 0.2;
      if (this.meta.mode !== 'creative') this.consumeSelected();
      return true;
    }

    // Snowball / Ender Pearl throwing
    if (held?.name === 'ender_pearl' || held?.name === 'snowball') {
      this.mobs.launchProjectile(held.name, this.camera.position.clone().addScaledVector(this._dir, 0.7), this._dir, 20);
      this.audio?.play('bow');
      this.handDip = 0.2;
      if (this.meta.mode !== 'creative') this.consumeSelected();
      return true;
    }

    // Eye of Ender (insert into frame OR throw toward Stronghold!)
    if (held?.name === 'ender_eye') {
      if (this.target && this.target.id === ID.end_portal_frame) {
        const cell = this.getCell(this.target.x, this.target.y, this.target.z);
        const state = blockState(cell);
        if ((state & 4) === 0) {
          this.setBlock(this.target.x, this.target.y, this.target.z, ID.end_portal_frame, state | 4);
          this.audio?.play('stone', this.target);
          this.particles.burst(new THREE.Vector3(this.target.x + 0.5, this.target.y + 1, this.target.z + 0.5), '#5ef577', 14, 3);
          this.handDip = 0.2;
          if (this.meta.mode !== 'creative') this.consumeSelected();
          this.checkActivateEndPortal(this.target.x, this.target.y, this.target.z);
          return true;
        }
      }
      const [shx, shz] = this.terrain.strongholdPos();
      const targetPos = new THREE.Vector3(shx, this.camera.position.y + 6, shz);
      this.mobs.launchProjectile('ender_eye', this.camera.position.clone().addScaledVector(this._dir, 0.8), targetPos.clone().sub(this.camera.position), 7, targetPos);
      this.audio?.play('bow');
      this.handDip = 0.2;
      if (this.meta.mode !== 'creative') this.consumeSelected();
      return true;
    }

    if (def?.food && held) {
      if (this.hunger >= 20 && this.meta.mode !== 'creative' && held.name !== 'golden_apple' && held.name !== 'enchanted_golden_apple' && held.name !== 'honey_bottle' && held.name !== 'chorus_fruit') return false;
      return SV.completeEat(this, held, def, this.handCtx);
    }

    if (held?.name === 'bow') {
      if (this.meta.mode === 'creative' || this.removeItem('arrow', 1)) {
        this.mobs.shootPlayerArrow(this.camera.position, this._dir);
        this.handDip = 0.2;
      } else {
        this.onToast('矢がありません', 'Out of arrows');
      }
      return true;
    }

    this.camera.getWorldDirection(this._dir);
    if (held?.name === 'glass_bottle' && this.mobs.beh?.collectBreath(this.camera.position, this._dir)) {
      if (this.meta.mode !== 'creative') { held.count -= 1; if (held.count <= 0) this.hotbar[this.selected] = null; }
      this.addItem('dragon_breath', 1);
      this.handDip = 0.18;
      return true;
    }
    {
      const r = this.mobs.interact(this.camera.position, this._dir, held?.name ?? '', this.input.crouch);
      if (r) {
        this.handDip = 0.18;
        if (this.mobs.riding) { this.dismountCooldown = 0.6; this.achievement('ride'); }
        return true;
      }
    }

    const t = this.target;
    if (!t) return false;

    // Bucket fluid scooping
    if (held?.name === 'bucket') {
      const fx = t.x + t.normal.x, fy = t.y + t.normal.y, fz = t.z + t.normal.z;
      const fluidId = this.getBlock(fx, fy, fz);
      if (fluidId === ID.water || fluidId === ID.lava) {
        this.setBlock(fx, fy, fz, 0);
        this.hotbar[this.selected] = { name: fluidId === ID.lava ? 'lava_bucket' : 'water_bucket', count: 1 };
        this.audio?.play('water', { x: fx, y: fy, z: fz });
        return true;
      }
    }

    if (!(this.input.crouch && (this.hotbar[this.selected] || this.offhand))) {   // Java: sneaking with an item in either hand skips the block's own use
      this.stationKey = `${t.x},${t.y},${t.z}`;
      if (t.id === ID.brewing_stand || t.id === ID.dispenser || t.id === ID.item_frame) this.seedNatural(t.x, t.y, t.z);
      if (t.id === ID.item_frame) return this.useItemFrame(t.x, t.y, t.z);
      if (BLOCKS[t.id]?.name.endsWith('_sign')) {
        return this.interactSign(t.x, t.y, t.z, BLOCKS[t.id].name, held ?? null);
      }
      if (SV.openStation(this, t)) return true;
      if (t.id === ID.crafting_table) { this.pause(true); this.onScreen('workbench'); return true; }
      if ([ID.furnace, ID.blast_furnace, ID.smoker].includes(t.id)) {
        this.containers[this.stationKey] ??= [null, null, null];
        this.furnaces[this.stationKey] ??= { burn: 0, progress: 0 };
        this.pause(true);
        this.onScreen('furnace');
        return true;
      }
      if (t.id === ID.chest || t.id === ID.trapped_chest || t.id === ID.barrel || t.id === ID.shulker_box) {
        const above = BLOCKS[this.getBlock(t.x, t.y + 1, t.z)];
        if ((t.id === ID.chest || t.id === ID.trapped_chest) && above?.solid && !above.transparent && above.shape === 'cube') {
          this.onToast('チェストの上がふさがっています', 'The chest is blocked');
          return true;
        }
        this.containers[this.stationKey] ??= t.id === ID.chest ? this.lootFor(t.x, t.y, t.z) : Array(27).fill(null);
        if (t.id === ID.trapped_chest) this.setBlock(t.x, t.y, t.z, ID.trapped_chest, 1);
        this.audio?.play('chest', t); this.gameplay.vibrate('container_open', t.x + 0.5, t.y + 0.5, t.z + 0.5);
        this.pause(true);
        this.onScreen('container');
        return true;
      }
      if (t.id === ID.lever || BLOCKS[t.id].name.endsWith('_button')) {
        if (this.redstone.press(t.x, t.y, t.z)) this.audio?.play('click', t);
        return true;
      }
const tdef = BLOCKS[t.id];
      if (tdef.shape === 'fence' && this.mobs.tieLeashes(t.x, t.y, t.z) > 0) {
        this.audio?.play('wood', t);
        this.handDip = 0.16;
        return true;
      }
      if (t.id === ID.hopper || t.id === ID.dropper || t.id === ID.dispenser) {
        this.containerAt(t.x, t.y, t.z);
        this.audio?.play('chest', t); this.gameplay.vibrate('container_open', t.x + 0.5, t.y + 0.5, t.z + 0.5);
        this.pause(true);
        this.onScreen('container');
        return true;
      }
      // Iron doors only answer to redstone, like vanilla.
      if (tdef.shape === 'door' && tdef.name !== 'iron_door') { this.toggleDoor(t.x, t.y, t.z); return true; }
      if (tdef.shape === 'trapdoor') {
        this.setBlock(t.x, t.y, t.z, t.id, blockState(this.getCell(t.x, t.y, t.z)) ^ 8);
        this.audio?.play('door', t);
        return true;
      }
      if (tdef.name.startsWith('open_') && tdef.name.endsWith('_door')) {
        // "Open door" blocks from older saves turn back into a normal closed door.
        const to = ID[tdef.name.slice(5)];
        if (to !== undefined) for (const dy of [0, 1, -1]) {
          const cell = this.getCell(t.x, t.y + dy, t.z);
          if (blockId(cell) === t.id) this.setBlock(t.x, t.y + dy, t.z, to, blockState(cell) & 1);
        }
        this.audio?.play('door', t);
        return true;
      }
      if (t.id === ID.bed) {
        if (this.dimension !== 'overworld') {
          const bedState = blockState(this.getCell(t.x, t.y, t.z));
          this.setBlock(t.x, t.y, t.z, 0);
          this.afterBreak(t.x, t.y, t.z, BLOCKS[t.id], bedState);
          this.explode(new THREE.Vector3(t.x + 0.5, t.y + 0.5, t.z + 0.5), 5);
          this.onToast('ネザー・エンドではベッドは爆発します！', 'Intentional Game Design!');
          return true;
        }
        this.respawnPoint = [t.x + 0.5, t.y + 0.7, t.z + 0.5];
        if (this.time < 0.05 || this.time > 0.45 || this.weather === 'storm') {
          this.sleeping = true;
          this.sleepTimer = 1.6;
          this.onToast('おやすみなさい…', 'Sleeping through the night…');
        } else {
          this.onToast('リスポーン地点を設定しました（夜か雷雨のときに眠れます）', 'Respawn point set (sleep at night or during storms)');
        }
        return true;
      }
      if (t.id === ID.portal) { this.audio?.play('portal'); this.travelNetherPortal(); return true; }
      if (t.id === ID.end_portal) { this.audio?.play('portal'); this.enterEndPortal(); return true; }
      if (t.id === ID.end_gateway) { this.audio?.play('portal'); this.handleGatewayTravel(); return true; }
    }

    if (!held) return false;

    // Flint & Steel ignites Nether Portals, TNT, or fires!
    if (held.name === 'flint_and_steel') {
      if (t.id === ID.tnt) { this.simulation.enqueue(t.x, t.y, t.z, ID.tnt); return true; }
      const fx = t.x + t.normal.x, fy = t.y + t.normal.y, fz = t.z + t.normal.z;
      if (!this.tryLightNetherPortal(fx, fy, fz)) {
        if (t.id === ID.obsidian) {
          for (let dy = 1; dy <= 3; dy++) for (let dx = -1; dx <= 1; dx++) {
            if (this.getBlock(t.x + dx, t.y + dy, t.z) === 0) this.setBlock(t.x + dx, t.y + dy, t.z, ID.portal);
          }
          this.audio?.play('portal', t);
          this.achievement('nether');
          this.onToast('ネザーポータルが開きました！', 'Nether Portal ignited!');
        } else {
          if (this.getBlock(fx, fy, fz) === 0) this.setBlock(fx, fy, fz, ID.fire);
          this.audio?.play('stone', { x: fx, y: fy, z: fz });
        }
      }
      this.handDip = 0.18;
      return true;
    }

    // Place End Crystal on Obsidian/Bedrock
    if (held.name === 'end_crystal') {
      if (t.id === ID.obsidian || t.id === ID.bedrock) {
        this.mobs.spawnCrystal(t.x, t.y + 1, t.z);
        SV.checkDragonRespawn(this);
        this.audio?.play('place', t);
        this.handDip = 0.18;
        if (this.meta.mode !== 'creative') this.consumeSelected();
      }
      return true;
    }
    let name = held.name;
    const isBucketFluid = name === 'water_bucket' || name === 'lava_bucket';
    if (name === 'water_bucket') name = 'water';
    else if (name === 'lava_bucket') name = 'lava';
    else if (name === 'string') name = 'tripwire';
    const id = ID[name];
    if (id === undefined) return false;

    const placedDef = BLOCKS[id], p = this.position;
    if (id === t.id && isSlabBlock(placedDef)) {
      const current = blockState(this.getCell(t.x, t.y, t.z));
      const canCombine = (current === 0 && t.normal.y === 1) || (current === 1 && t.normal.y === -1);
      if (canCombine) {
        for (const box of collisionBoxes(placedDef, 2)) {
          if (intersectsBox(t.x, t.y, t.z, p.x - 0.3, p.y, p.z - 0.3, p.x + 0.3, p.y + 1.8, p.z + 0.3, box)) return true;
        }
        if (this.setBlock(t.x, t.y, t.z, id, 2)) {
          this.statistics.blocks_placed = (this.statistics.blocks_placed ?? 0) + 1;
          this.audio?.play('place', t);
          this.handDip = 0.16;
          if (this.meta.mode !== 'creative') this.consumeSelected();
          this.achievement('place');
        }
        return true;
      }
    }

    const x = t.x + t.normal.x, y = t.y + t.normal.y, z = t.z + t.normal.z;
    if (y >= MIN_Y + HEIGHT || y < MIN_Y) return true;
    const existing = this.getBlock(x, y, z);
    if (existing < 0 || (existing > 0 && BLOCKS[existing]?.solid)) return true;

    const hitY = this.camera.position.y + Math.sin(this.input.pitch) * t.distance - t.y;
    const state = stateForPlacement(placedDef, this.input.yaw, t.normal, hitY, this.input.pitch);
    if (state < 0) return true;
    if (placedDef.shape === 'door') {
      // A door is two blocks tall and needs a solid block to stand on.
      const aboveId = this.getBlock(x, y + 1, z);
      if (y + 1 >= MIN_Y + HEIGHT || aboveId < 0 || (aboveId > 0 && BLOCKS[aboveId]?.solid) || !BLOCKS[this.getBlock(x, y - 1, z)]?.solid) return true;
    }
    let bedHead: [number, number, number] | null = null;
    if (placedDef.name === 'bed') {
      // A bed needs a second free cell for its head.
      const hx = x + [1, 0, -1, 0][state & 3], hz = z + [0, 1, 0, -1][state & 3], hid = this.getBlock(hx, y, hz);
      if (hid < 0 || (hid > 0 && BLOCKS[hid]?.solid)) return true;
      bedHead = [hx, y, hz];
    }
    for (const box of collisionBoxes(placedDef, state)) {
      if (intersectsBox(x, y, z, p.x - 0.3, p.y, p.z - 0.3, p.x + 0.3, p.y + 1.8, p.z + 0.3, box)) return true;
    }

    if (this.setBlock(x, y, z, id, state)) {
      this.mobs.noise(x, y, z, 0.6);
      this.gameplay.placed(x, y, z, id, state, held, existing);
      if (id === ID.rail) {
        const isR = (rx: number, ry: number, rz: number) => {
          const rid = this.getBlock(rx, ry, rz);
          return rid === ID.rail || rid === ID.powered_rail || rid === ID.detector_rail || rid === ID.activator_rail;
        };
        this.setBlock(x, y, z, ID.rail, computeRailState(isR, x, y, z, false));
      }
      const summoned = trySummonMultiblock((bx, by, bz) => this.getBlock(bx, by, bz), (bx, by, bz, bid, bst = 0) => this.setBlock(bx, by, bz, bid, bst), x, y, z);
      if (summoned) {
        const sm = this.mobs.spawn(summoned.species, summoned.x, summoned.z, false, summoned.y);
        if (sm && summoned.warmupTicks) (sm as any).warmupTicks = summoned.warmupTicks;
      }
      if (placedDef.name.endsWith('_banner') && held.patterns?.length) this.registerBanner(x, y, z, held.name, held.patterns);
      if (placedDef.name === 'decorated_pot') this.registerPot(x, y, z, held.sherds ?? DEFAULT_SHERDS);
      if (placedDef.name === 'beacon') { this.beacons.set(`${this.dimension}:${x},${y},${z}`, { primary: 'speed' }); this.syncBeacons(); }
      if (placedDef.name.endsWith('_sign')) {
        const sKey = `${this.dimension}:${x},${y},${z}`;
        const sd = newSignData(this.input.yaw, placedDef.name.includes('hanging'), placedDef.name.startsWith('spruce') ? 'spruce' : 'oak');
        this.signs.set(sKey, sd);
        this.syncSign(sKey);
        this.stationKey = `${x},${y},${z}`;
        this.signSide = 'front';
        this.pause(true);
        this.onScreen('sign');
      }
      if (bedHead) this.setBlock(bedHead[0], bedHead[1], bedHead[2], id, state | 4);
      if (placedDef.shape === 'door') this.setBlock(x, y + 1, z, id, state | 4);
      this.statistics.blocks_placed = (this.statistics.blocks_placed ?? 0) + 1;
      this.audio?.play(id === ID.water || id === ID.lava ? 'water' : placedDef.tool === 'pickaxe' ? 'stone' : 'place', { x, y, z });
      this.handDip = 0.16;
      if (this.meta.mode !== 'creative') {
        if (isBucketFluid) this.hotbar[this.selected] = { name: 'bucket', count: 1 };
        else this.consumeSelected();
      }
      this.achievement('place');
    }
    return true;
  }

  /**
   * Record 014 right-click handling: fishing rods, hoes, bone meal, seeds, vehicles, daylight-detector inversion, the crafter,
   * and the bell. Returns true when the click was consumed.
   */
  private useExtras(held: Stack | null): boolean {
    const name = held?.name ?? '', t = this.target, creative = this.meta.mode === 'creative';
    const consume = () => { if (!creative) this.consumeSelected(); };
    if (name === 'wind_charge') {
      this.mobs.launchProjectile('wind_charge', this.camera.position.clone().addScaledVector(this._dir, 0.7), this._dir, 22);
      this.audio?.play('bow');
      this.handDip = 0.2;
      consume();
      return true;
    }
    if (name === 'fishing_rod') {
      const luck = held?.ench?.luck_of_the_sea ?? 0, lure = held?.ench?.lure ?? 0;
      if (this.fishing.active) {
        const res = this.fishing.reel(luck);
        this.handDip = 0.2;
        if (res) {
          if (res.caught) {
            const cs = res.caught.stack;
            if (cs.ench || cs.durability !== undefined) SV.rememberDrop(this, cs);
            this.particles.drop(this.camera.position.clone().addScaledVector(this._dir, 1.2), cs.name, cs.count, resolve(cs.name)?.color ?? '#8ab');
            this.addXp(res.xp);
            this.statistics.fish_caught = (this.statistics.fish_caught ?? 0) + 1;
            this.achievement('fish');
          } else if (res.hookedMob) {
            const pull = this.position.clone().sub(res.hookedMob.group.position).multiplyScalar(0.45);
            res.hookedMob.group.position.add(pull);
            res.hookedMob.vy = 4.5;
          }
          if (!creative && res.wear > 0) SV.wear(this, 'main', res.wear);
        }
      } else {
        this.fishing.cast(this.camera.position, this._dir, lure);
        this.handDip = 0.2;
      }
      return true;
    }
    // Vehicles: mount the one in front of the player.
    const vehicle = this.vehicles.pick(this.camera.position, this._dir);
    if (vehicle && !this.input.crouch && vehicle.kind !== 'minecart' && vehicle.kind !== 'boat') return this.useCartVariant(vehicle, held);
    if (vehicle && !this.input.crouch) { this.vehicles.mount(vehicle); this.dismountCooldown = 0.6; this.achievement('ride'); return true; }
    if (!t) return false;
    if (name.endsWith('_hoe')) {
      if (isTillable(t.id) && t.normal.y >= 0 && this.farming.till(t.x, t.y, t.z)) { this.audio?.play('grass', t); this.handDip = 0.18; if (!creative) SV.wear(this, 'main', 1); return true; }
      if (t.id === ID.rooted_dirt) { this.setBlock(t.x, t.y, t.z, ID.dirt); this.particles.drop(new THREE.Vector3(t.x + 0.5, t.y + 1.2, t.z + 0.5), 'hanging_roots', 1, '#9e7254'); return true; }
    }
    if (name === 'bone_meal') {
      if (this.farming.bonemeal(t.x, t.y, t.z)) { this.audio?.play('grass', t); this.handDip = 0.18; consume(); return true; }
    }
    if (SEED_TO_CROP[name]) {
      if (t.normal.y > 0 && this.farming.plant(name, t.x, t.y, t.z)) { this.audio?.play('grass', t); this.handDip = 0.16; consume(); this.achievement('farm'); return true; }
      if (name === 'carrot' || name === 'potato') return false; // otherwise eaten
      return t.id === ID.farmland;
    }
    if (name !== 'minecart' && isCartKind(name)) {
      if (this.vehicles.place(name, t.x, t.y, t.z)) { this.handDip = 0.16; consume(); this.gameplay.vibrate('entity_place', t.x + 0.5, t.y + 0.5, t.z + 0.5); }
      return true;
    }
    if (name === 'minecart' || name === 'boat') {
      const x = t.x + (name === 'boat' ? t.normal.x : 0), y = t.y + (name === 'boat' ? Math.max(0, t.normal.y) : 0), z = t.z + (name === 'boat' ? t.normal.z : 0);
      if (this.vehicles.place(name, x, y, z)) { this.handDip = 0.16; consume(); return true; }
      if (name === 'boat' && this.vehicles.place('boat', t.x, t.y, t.z)) { this.handDip = 0.16; consume(); return true; }
      return name === 'minecart';
    }
    if (!this.input.crouch) {
      if (t.id === ID.jukebox) return this.useJukebox(t.x, t.y, t.z, held);
      if (t.id === ID.daylight_detector || t.id === ID.inverted_daylight_detector) {
        this.setBlock(t.x, t.y, t.z, t.id === ID.daylight_detector ? ID.inverted_daylight_detector : ID.daylight_detector, 0);
        this.audio?.play('click', t);
        return true;
      }
      if (t.id === ID.crafter) {
        this.stationKey = `${t.x},${t.y},${t.z}`;
        this.containers[this.stationKey] ??= Array(9).fill(null);
        this.audio?.play('chest', t); this.gameplay.vibrate('container_open', t.x + 0.5, t.y + 0.5, t.z + 0.5); this.pause(true); this.onScreen('crafter');
        return true;
      }
      if (t.id === ID.bell) {
        this.audio?.play('note', t);
        this.mobs.noise(t.x, t.y, t.z, 2);
        for (const m of this.mobs.mobs) if ((m.raid || m.raidMember) && m.group.position.distanceTo(this.position) < 32) this.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 1.5, 0)), '#ffffff', 6, 1);
        return true;
      }
      if (t.id === ID.composter) {
        const res = this.farming.compost(t.x, t.y, t.z, held?.name ?? null);
        if (res === 'collected') {
          this.particles.drop(new THREE.Vector3(t.x + 0.5, t.y + 1.2, t.z + 0.5), 'bone_meal', 1, '#e8e8e0');
          this.audio?.play('grass', t);
          return true;
        }
        if (res === 'added' || res === 'full') {
          consume();
          this.particles.burst(new THREE.Vector3(t.x + 0.5, t.y + 1, t.z + 0.5), '#9bd36a', 6, 1);
          this.audio?.play('grass', t);
          return true;
        }
        if ((res as string) === 'wasted' || (res as string) === 'missed') {
          consume();
          this.audio?.play('grass', t);
          return true;
        }
      }
    }
    return false;
  }

  /** Crafter: on a redstone pulse, craft the recipe laid out in its 3x3 grid and drop the result in front. */
  crafterMask(key: string) { return this.crafterDisabled[this.dimension + ':' + key] ?? 0; }
  toggleCrafterSlot(index: number) {
    if (index < 0 || index > 8 || this.containers[this.stationKey]?.[index]) return;
    this.crafterDisabled[this.dimension + ':' + this.stationKey] = this.crafterMask(this.stationKey) ^ (1 << index);
  }
  private containerAt(x: number, y: number, z: number): (Stack | null)[] | null {
    const id = this.getBlock(x, y, z), key = `${x},${y},${z}`;
    if (![ID.chest, ID.barrel, ID.shulker_box, ID.hopper, ID.dropper, ID.dispenser, ID.crafter, ID.furnace, ID.blast_furnace, ID.smoker, ID.brewing_stand].includes(id)) return null;
    if ([ID.furnace, ID.blast_furnace, ID.smoker].includes(id)) {
      this.furnaces[key] ??= { burn: 0, progress: 0 };
      return this.containers[key] ??= [null, null, null];
    }
    if (id === ID.brewing_stand) {
      this.furnaces[key] ??= { burn: 0, progress: 0 };
      return this.containers[key] ??= [null, null, null, null, null];
    }
    return this.containers[key] ??= id === ID.chest ? this.lootFor(x, y, z) : Array(id === ID.hopper ? 5 : [ID.crafter, ID.dispenser, ID.dropper].includes(id) ? 9 : 27).fill(null);
  }
  autoCraft(x: number, y: number, z: number, dir: number) { return this.crafterFire(x, y, z, dir); }
  private crafterFire(x: number, y: number, z: number, dir: number): boolean {
    const key = `${x},${y},${z}`, slots = this.containerAt(x, y, z);
    if (!slots || this.getBlock(x, y, z) !== ID.crafter) return false;
    const mask = this.crafterMask(key);
    const recipe = findCrafterRecipe(slots, mask);
    if (!recipe) return false;
    for (let i = 0; i < 9; i++) {
      if (!(mask & (1 << i)) && slots[i]) {
        slots[i]!.count--;
        if (slots[i]!.count <= 0) slots[i] = null;
      }
    }
    const f = [[1, 0, 0], [0, 0, 1], [-1, 0, 0], [0, 0, -1], [0, 1, 0], [0, -1, 0]][dir] ?? [1, 0, 0];
    const tx = x + f[0], ty = y + f[1], tz = z + f[2], dest = this.containerAt(tx, ty, tz);
    const stack = { name: recipe.result, count: recipe.count };
    if (!dest || !insertStack(dest, stack, this.getBlock(tx, ty, tz) === ID.crafter ? this.crafterMask(`${tx},${ty},${tz}`) : 0)) {
      this.particles.drop(new THREE.Vector3(x + 0.5 + f[0] * 0.7, y + 0.5 + f[1] * 0.7, z + 0.5 + f[2] * 0.7), stack.name, stack.count, resolve(stack.name)?.color ?? '#aaa');
    }
    this.audio?.play('click', { x, y, z });
    this.statistics.automated_crafts = (this.statistics.automated_crafts ?? 0) + 1;
    return true;
  }

  /** Opens or closes both halves of the door at x,y,z (state bit 3). `force` sets a definite state (redstone). */
  toggleDoor(x: number, y: number, z: number, force?: boolean) {
    const cell = this.getCell(x, y, z), id = blockId(cell), def = BLOCKS[id];
    if (!def) return;
    if (def.shape === 'trapdoor') {
      const st = blockState(cell), open = force ?? !(st & 8);
      if (((st & 8) !== 0) !== open) { this.setBlock(x, y, z, id, open ? st | 8 : st & 7); this.audio?.play('door', { x, y, z }); }
      return;
    }
    if (def.shape !== 'door') return;
    const st = blockState(cell), open = force ?? (st & 8) === 0;
    if (((st & 8) !== 0) === open) return;
    const below = this.getCell(x, y - 1, z);
    const dy = st & 4 ? -1 : blockId(this.getCell(x, y + 1, z)) === id ? 1 : blockId(below) === id && !(blockState(below) & 4) ? -1 : 0;
    for (const o of dy ? [0, dy] : [0]) {
      const c = this.getCell(x, y + o, z);
      if (blockId(c) === id) this.setBlock(x, y + o, z, id, open ? blockState(c) | 8 : blockState(c) & 7);
    }
    this.audio?.play('door', { x, y, z });
  }

  /** Pressure plates: pressed while the player stands on them, which powers the block below. */
  private updateButtons() {
    const fx = Math.floor(this.position.x), fy = Math.floor(this.position.y + 0.05), fz = Math.floor(this.position.z);
    const id = this.getBlock(fx, fy, fz), def = BLOCKS[id];
    const on = !!def && def.name.endsWith('_pressure_plate') && this.grounded;
    if (this.plate && (!on || this.plate[0] !== fx || this.plate[1] !== fy || this.plate[2] !== fz)) {
      this.redstone.setPlate(this.plate[0], this.plate[1], this.plate[2], false);
      this.plate = null;
    }
    this.redstone.setPlate(fx, fy, fz, on);
    if (on) this.plate = [fx, fy, fz];
  }

  /** After a block is broken: remove the other half of a door and everything that stood on it or was mounted on it. */
  private afterBreak(x: number, y: number, z: number, def: (typeof BLOCKS)[number], state: number) {
    if (def.name.endsWith('_banner')) this.onBannerBroken(x, y, z);
    if (def.name.endsWith('_sign')) {
      const k = `${this.dimension}:${x},${y},${z}`;
      this.signs.delete(k);
      this.sm.remove(k);
    }
    if (def.name === 'decorated_pot') {
      const k = `${this.dimension}:${x},${y},${z}`, sh = this.pots.get(k);
      if (sh) {
        this.pots.delete(k);
        this.pm.remove(k);
        if (this.meta.mode !== 'creative') SV.rememberDrop(this, { name: 'decorated_pot', count: 1, sherds: sh });
      }
    }
    if (def.name === 'beacon') {
      const k = `${this.dimension}:${x},${y},${z}`;
      this.beacons.delete(k);
      this.bb.remove(k);
    }
    if (def.name === 'jukebox') {
      const k = `${x},${y},${z}`, d = this.containers[k]?.[0];
      if (d) this.particles.drop(new THREE.Vector3(x + 0.5, y + 0.6, z + 0.5), d.name, 1, resolve(d.name)?.color ?? '#26262b');
      delete this.containers[k];
    }
    if (def.name === 'bed') {
      const k = state & 4 ? -1 : 1, ox = x + [1, 0, -1, 0][state & 3] * k, oz = z + [0, 1, 0, -1][state & 3] * k;
      if (this.getBlock(ox, y, oz) === def.id) this.setBlock(ox, y, oz, 0);
    }
    if (def.shape === 'door') {
      const dy = state & 4 ? -1 : 1;
      if (this.getBlock(x, y + dy, z) === def.id) this.setBlock(x, y + dy, z, 0);
      else if (!(state & 4) && this.getBlock(x, y - 1, z) === def.id) this.setBlock(x, y - 1, z, 0);
    }
    const pop = (px: number, py: number, pz: number) => {
      const cell = this.getCell(px, py, pz), d = BLOCKS[blockId(cell)], st = blockState(cell);
      if (!d) return;
      if (this.meta.mode !== 'creative' && !(d.shape === 'door' && st & 4)) {
        for (const drop of blockDrops(d, undefined, st)) this.particles.drop(new THREE.Vector3(px + 0.5, py + 0.5, pz + 0.5), drop.name, drop.count, resolve(drop.name)?.color ?? d.color);
      }
      this.setBlock(px, py, pz, 0);
    };
    for (let yy = y + 1; yy < y + 16; yy++) {
      const cell = this.getCell(x, yy, z), id = blockId(cell), d = BLOCKS[id];
      if (id <= 0 || !d) break;
      const standing = d.shape === 'cross' || d.shape === 'lily' || d.shape === 'cactus' || d.shape === 'door' || (d.shape === 'torch' && (!isAttachable(d) || (blockState(cell) & 7) === 0))
        || d.name === 'redstone_wire' || d.name === 'repeater' || d.name === 'comparator' || d.name.endsWith('rail') || d.name.endsWith('_pressure_plate') || d.name.endsWith('_carpet');
      if (!standing) break;
      pop(x, yy, z);
      if (d.shape !== 'cactus' && d.shape !== 'door' && d.name !== 'sugar_cane') break;
    }
    for (const [dx, dy, dz, at, edge] of [[1, 0, 0, 1, 1], [-1, 0, 0, 2, 3], [0, 0, 1, 3, 0], [0, 0, -1, 4, 2], [0, -1, 0, 5, -1]]) {
      const cell = this.getCell(x + dx, y + dy, z + dz), d = BLOCKS[blockId(cell)];
      if (!d || d.id <= 0) continue;
      if ((isAttachable(d) && (blockState(cell) & 7) === at) || (d.name === 'ladder' && (blockState(cell) & 3) === edge)) pop(x + dx, y + dy, z + dz);
    }
  }

  /** The first time a chest that came with the world is opened it is filled from a loot table, like vanilla structure chests. Player-placed chests start empty. */
  private lootFor(x: number, y: number, z: number): (Stack | null)[] {
    const slots: (Stack | null)[] = Array(27).fill(null);
    if (this.edits.has(`${x},${y},${z}`)) return slots;
    const extraKind = extraLootTable(this.terrain, x, y, z);
    if (extraKind) return SV.rollLoot(this, extraKind, x, y, z);
    if (this.dimension === 'end' && x > 525 && y > 35) {
      // End Ship Treasure Chest!
      slots[11] = { name: 'elytra', count: 1 };
      slots[13] = { name: 'diamond', count: 8 };
      slots[15] = { name: 'emerald', count: 12 };
      slots[4] = { name: 'diamond_sword', count: 1 };
      slots[22] = { name: 'firework_rocket', count: 16 };
      return slots;
    }
    if (this.dimension === 'end') {
      slots[2] = { name: 'diamond', count: 6 };
      slots[10] = { name: 'iron_ingot', count: 14 };
      slots[14] = { name: 'ender_pearl', count: 4 };
      slots[18] = { name: 'golden_apple', count: 2 };
      return slots;
    }
    if (this.dimension === 'overworld' && y <= 44) {
      const [shx, shz] = this.terrain.strongholdPos();
      if (Math.hypot(x - shx, z - shz) < 28) {
        slots[4] = { name: 'ender_pearl', count: 4 };
        slots[9] = { name: 'ender_eye', count: 2 };
        slots[12] = { name: 'iron_ingot', count: 10 };
        slots[14] = { name: 'apple', count: 5 };
        slots[21] = { name: 'diamond', count: 3 };
        return slots;
      }
    }
    let table = LOOT.village;
    if (this.dimension === 'nether') table = LOOT.fortress;
    else {
      let spawner = false;
      for (let dy = -1; dy <= 1 && !spawner; dy++) for (let dz = -4; dz <= 4 && !spawner; dz++) for (let dx = -4; dx <= 4; dx++) {
        if (this.getBlock(x + dx, y + dy, z + dz) === ID.spawner) { spawner = true; break; }
      }
      if (spawner) table = LOOT.dungeon;
      else if (ID.blue_terracotta !== undefined && this.getBlock(x, y - 1, z) === ID.blue_terracotta) table = LOOT.temple;
    }
    let h = (Math.imul(x, 73856093) ^ Math.imul(y, 19349663) ^ Math.imul(z, 83492791) ^ this.terrain.seed) >>> 0;
    const rnd = () => { h = (Math.imul(h ^ (h >>> 15), 2246822519) + 0x9e3779b9) >>> 0; return ((h ^ (h >>> 13)) >>> 0) / 4294967296; };
    const total = table.items.reduce((sum, it) => sum + it[3], 0);
    const rolls = table.rolls[0] + Math.floor(rnd() * (table.rolls[1] - table.rolls[0] + 1));
    for (let i = 0; i < rolls; i++) {
      let pick = rnd() * total, item = table.items[0];
      for (const it of table.items) { pick -= it[3]; if (pick <= 0) { item = it; break; } }
      const slot = Math.floor(rnd() * 27);
      if (slots[slot] || !resolve(item[0])) continue;
      slots[slot] = { name: item[0], count: item[1] + Math.floor(rnd() * (item[2] - item[1] + 1)) };
    }
    return slots;
  }

  /**
   * Comparator reading of a block. Inventories read their fullness; the cauldron (water level), jukebox (disc number), composter
   * (fill stage), lectern (open page), end portal frame (eye) and respawn anchor (charges) read their own state. null = no analog output.
   */
  analogSignal(x: number, y: number, z: number): number | null {
    const special = this.gameplay?.comparatorOverride(x, y, z) ?? -1;
    if (special >= 0) return special;
    const id = this.getBlock(x, y, z);
    if (id === ID.lit_copper_bulb) return 15;
    if (id === ID.copper_bulb && (blockState(this.getCell(x, y, z)) & 8)) return 15;
    if (id === ID.crafter) {
      const key = `${x},${y},${z}`, slots = this.containers[key], mask = this.crafterMask(key);
      return Array.from({ length: 9 }, (_, i) => (slots?.[i] || (mask & (1 << i)) ? 1 : 0)).reduce((a: number, b: number) => a + b, 0);
    }
    return SV.analogSignal(this, x, y, z);
  }
  containerSignal(x: number, y: number, z: number): number { return this.analogSignal(x, y, z) ?? 0; }

  /** Jukebox: a disc goes in with right-click (its number is what comparators read), an empty hand takes it back out. */
  private useJukebox(x: number, y: number, z: number, held: Stack | null): boolean {
    const key = `${x},${y},${z}`, slots = (this.containers[key] ??= [null]), disc = slots[0], jState = blockState(this.getCell(x, y, z));
    if (disc || jState > 0) {
      slots[0] = null;
      this.audio?.stopDisc(key);
      if (disc) this.particles.drop(new THREE.Vector3(x + 0.5, y + 1.1, z + 0.5), disc.name, 1, resolve(disc.name)?.color ?? '#26262b');
      this.setBlock(x, y, z, ID.jukebox, 0);
      this.audio?.play('click', { x, y, z }); this.handDip = 0.16;
      this.onToast('レコードを取り出しました', 'Disc ejected');
      return true;
    }
    if (held && held.name.startsWith('music_disc_')) {
      const n = held.name, sig = V.DISC_SIGNAL[n] ?? 1;
      slots[0] = { name: n, count: 1 };
      this.setBlock(x, y, z, ID.jukebox, sig);
      if (this.meta.mode !== 'creative') this.consumeSelected();
      this.audio?.play('jukebox_insert', { x, y, z });
      this.audio?.playDisc(key, n, { x: x + 0.5, y: y + 0.5, z: z + 0.5 });
      this.handDip = 0.18;
      this.onToast(`♪ ${resolve(n)?.ja ?? n}（コンパレーター出力 ${sig}）`, `Now playing ${n.replace('music_disc_', '')} (comparator ${sig})`);
      return true;
    }
    return false;
  }

  // ---- Banners with loom patterns ------------------------------------------------------------------------------------------
  private registerBanner(x: number, y: number, z: number, name: string, layers: { p: string; c: string }[]) {
    const k = `${this.dimension}:${x},${y},${z}`;
    this.banners.set(k, { base: name.replace(/_banner$/, ''), layers: layers.map(l => ({ ...l })), yaw: this.input.yaw });
    this.syncBanner(k);
  }
  private syncBanner(k: string) {
    const b = this.banners.get(k);
    if (!b) return;
    const [dim, c] = k.split(':');
    if (dim !== this.dimension) return;
    const [x, y, z] = c.split(',').map(Number);
    this.bm.set(k, x, y, z, b.base, b.layers as BannerLayer[], b.yaw);
  }
  syncBanners() { this.bm.clear(); for (const k of this.banners.keys()) this.syncBanner(k); }
  private bannerCheck() {
    if (this.bannerDim !== this.dimension || (this.banners.size && !this.bm.size) || (this.signs.size && !this.sm.size) || (this.pots.size && !this.pm.size)) {
      this.bannerDim = this.dimension;
      this.syncBanners();
      this.syncSigns();
      this.syncPots();
      this.syncBeacons();
    }
    this.bb.update(this.elapsed);
    this.lm.sync(this.redstone.lockedKeys(), (x, y, z) => blockState(this.getCell(x, y, z)));
  }
  /** The dropped banner keeps its pattern layers (the pickup code matches remembered stacks by name). */
  private onBannerBroken(x: number, y: number, z: number) {
    const k = `${this.dimension}:${x},${y},${z}`, b = this.banners.get(k);
    if (!b) return;
    this.banners.delete(k);
    this.bm.remove(k);
    if (this.meta.mode !== 'creative') SV.rememberDrop(this, { name: `${b.base}_banner`, count: 1, patterns: b.layers });
  }

  // ---- Signs & Hanging Signs (front/back 4-line text, dye color, glow ink sac, honeycomb wax) ------------------------------
  private interactSign(x: number, y: number, z: number, blockName: string, held: Stack | null): boolean {
    const k = `${this.dimension}:${x},${y},${z}`;
    let sd = this.signs.get(k);
    if (!sd) {
      sd = newSignData(this.input.yaw, blockName.includes('hanging'), blockName.startsWith('spruce') ? 'spruce' : 'oak');
      this.signs.set(k, sd);
    }
    const side = signSideForPlayer(this.position.x, this.position.z, x, z, sd.yaw);
    if (held) {
      const act = applySignItem(sd, side, held.name);
      if (act === 'locked') {
        this.onToast('ハニカムでコーティングされているため変更できません', 'This sign is waxed and cannot be modified');
        return true;
      }
      if (act === 'waxed' || act === 'dyed' || act === 'glow' || act === 'unglow') {
        this.syncSign(k);
        if (this.meta.mode !== 'creative') this.consumeSelected();
        this.audio?.play(act === 'waxed' ? 'wood' : 'water', { x, y, z });
        this.handDip = 0.16;
        const msg: Record<string, [string, string]> = {
          waxed: ['看板にハニカムを塗って編集ロックしました', 'Sign waxed — text locked'],
          dyed: ['看板の文字色を変更しました', 'Sign text dyed'],
          glow: ['輝くイカスミで看板の文字を発光させました', 'Sign text now glows in the dark'],
          unglow: ['イカスミで看板の発光を消しました', 'Removed sign glow'],
        };
        this.onToast(msg[act][0], msg[act][1]);
        return true;
      }
    }
    if (sd.waxed) {
      this.onToast('この看板はハニカムでロックされています', 'This sign is waxed');
      return true;
    }
    this.stationKey = `${x},${y},${z}`;
    this.signSide = side;
    this.syncSign(k);
    this.audio?.play('wood', { x, y, z });
    this.pause(true);
    this.onScreen('sign');
    return true;
  }

  syncSign(k: string) {
    const sd = this.signs.get(k);
    if (!sd) return;
    const [dim, c] = k.split(':');
    if (dim !== this.dimension) return;
    const [x, y, z] = c.split(',').map(Number);
    this.sm.set(k, x, y, z, sd);
  }

  syncSigns() {
    this.sm.clear();
    for (const k of this.signs.keys()) this.syncSign(k);
  }

  // ---- Decorated Pots (4-face dynamic sherd textures) ----------------------------------------------------------------------
  registerPot(x: number, y: number, z: number, sherds: [string, string, string, string]) {
    const k = `${this.dimension}:${x},${y},${z}`;
    this.pots.set(k, [...sherds] as [string, string, string, string]);
    this.syncPot(k);
  }

  syncPot(k: string) {
    const sh = this.pots.get(k);
    if (!sh) return;
    const [dim, c] = k.split(':');
    if (dim !== this.dimension) return;
    const [x, y, z] = c.split(',').map(Number);
    this.pm.set(k, x, y, z, sh);
  }

  syncPots() {
    this.pm.clear();
    for (const k of this.pots.keys()) this.syncPot(k);
  }

  // ---- Beacons (3D skyward beam + pyramid validation) ----------------------------------------------------------------------
  syncBeacons() {
    for (const [k, cfg] of [...this.beacons.entries()]) {
      const [dim, c] = k.split(':');
      if (dim !== this.dimension) { this.bb.remove(k); continue; }
      const [x, y, z] = c.split(',').map(Number);
      if (this.getBlock(x, y, z) !== ID.beacon) { this.bb.remove(k); continue; }
      const tier = beaconPyramidTier((bx, by, bz) => this.getBlock(bx, by, bz), x, y, z);
      if (tier > 0) this.bb.set(k, x, y, z, cfg.primary);
      else this.bb.remove(k);
    }
  }

  private stackFrom(x: number, y: number, z: number): Stack | null {
    const key = `${x},${y},${z}`, slots = this.containers[key] ??= Array(9).fill(null);
    for (let i = 0; i < slots.length; i++) {
      const s = slots[i];
      if (!s) continue;
      s.count--;
      if (s.count <= 0) slots[i] = null;
      return { ...s, count: 1 };
    }
    return null;
  }

  /** Dispensers and droppers: droppers pass the item into a container they face, dispensers use bone meal/arrows/buckets or eject. */
  private ejectFrom(x: number, y: number, z: number, dir: number, kind: 'dispenser' | 'dropper'): boolean {
    const stack = this.stackFrom(x, y, z);
    if (!stack) return false;
    const f = [[1, 0, 0], [0, 0, 1], [-1, 0, 0], [0, 0, -1], [0, 1, 0], [0, -1, 0]][dir] ?? [1, 0, 0];
    const tx = x + f[0], ty = y + f[1], tz = z + f[2];
    if (kind === 'dropper') {
      const slots = this.containerAt(tx, ty, tz);
      if (slots) {
        if (insertStack(slots, stack, this.getBlock(tx, ty, tz) === ID.crafter ? this.crafterMask(`${tx},${ty},${tz}`) : 0)) return true;
        insertStack(this.containers[`${x},${y},${z}`], stack);
        return false;
      }
    }
    if (kind === 'dispenser') {
      const targetId = this.getBlock(tx, ty, tz), targetCell = this.getCell(tx, ty, tz), targetSt = blockState(targetCell);
      if (stack.name === 'bone_meal') {
        if (this.farming.bonemeal(tx, ty, tz)) return true;
        insertStack(this.containers[`${x},${y},${z}`], stack);
        return false;
      }
      if (stack.name === 'shears') {
        const sheep = this.mobs.mobs.find(m => m.species === 'sheep' && m.wool && Math.floor(m.group.position.x) === tx && Math.floor(m.group.position.z) === tz && Math.abs(m.group.position.y - ty) < 2);
        if (sheep) {
          sheep.wool = false; if (sheep.woolCoat) sheep.woolCoat.visible = false;
          this.particles.drop(new THREE.Vector3(tx + 0.5, ty + 0.5, tz + 0.5), 'white_wool', 1 + Math.floor(Math.random() * 3), '#f2f2f2');
          const maxD = resolve('shears')?.durability ?? 238, nextD = (stack.durability ?? maxD) - 1;
          if (nextD > 0) insertStack(this.containers[`${x},${y},${z}`], { ...stack, durability: nextD });
          return true;
        }
        if ((targetId === ID.bee_nest || targetId === ID.beehive) && (targetSt & 7) >= 5) {
          this.setBlock(tx, ty, tz, targetId, targetSt & ~7);
          this.particles.drop(new THREE.Vector3(tx + 0.5, ty + 0.5, tz + 0.5), 'honeycomb', 3, '#e8c832');
          const maxD = resolve('shears')?.durability ?? 238, nextD = (stack.durability ?? maxD) - 1;
          if (nextD > 0) insertStack(this.containers[`${x},${y},${z}`], { ...stack, durability: nextD });
          return true;
        }
        insertStack(this.containers[`${x},${y},${z}`], stack);
        return false;
      }
      if (stack.name === 'glass_bottle') {
        if (targetId === ID.water && targetSt === 0) {
          const out: Stack = { name: 'water_bottle', count: 1 };
          if (!insertStack(this.containers[`${x},${y},${z}`], out)) this.particles.drop(new THREE.Vector3(tx + 0.5, ty + 0.5, tz + 0.5), out.name, 1, '#4f7ad8');
          return true;
        }
        if ((targetId === ID.bee_nest || targetId === ID.beehive) && (targetSt & 7) >= 5) {
          this.setBlock(tx, ty, tz, targetId, targetSt & ~7);
          const out: Stack = { name: 'honey_bottle', count: 1 };
          if (!insertStack(this.containers[`${x},${y},${z}`], out)) this.particles.drop(new THREE.Vector3(tx + 0.5, ty + 0.5, tz + 0.5), out.name, 1, '#e8a832');
          return true;
        }
      }
      if (stack.name === 'glowstone' && targetId === ID.respawn_anchor && (targetSt & 7) < 4) {
        this.setBlock(tx, ty, tz, ID.respawn_anchor, (targetSt & 7) + 1);
        return true;
      }
      if (stack.name === 'flint_and_steel' || stack.name === 'fire_charge') {
        const keepTool = () => {
          if (stack.name === 'flint_and_steel') {
            const maxD = resolve('flint_and_steel')?.durability ?? 64, nextD = (stack.durability ?? maxD) - 1;
            if (nextD > 0) insertStack(this.containers[`${x},${y},${z}`], { ...stack, durability: nextD });
          }
        };
        if (targetId === ID.tnt) { this.simulation.enqueue(tx, ty, tz, ID.tnt); keepTool(); return true; }
        if (targetId === ID.unlit_campfire) { this.setBlock(tx, ty, tz, ID.campfire, 0); keepTool(); return true; }
        if (targetId === 0) {
          if (!this.tryLightNetherPortal(tx, ty, tz) && ID.fire !== undefined) this.setBlock(tx, ty, tz, ID.fire, 0);
          keepTool();
          return true;
        }
      }
      if (stack.name === 'water_bucket' || stack.name === 'lava_bucket' || stack.name === 'powder_snow_bucket') {
        const blockIdToPlace = stack.name === 'water_bucket' ? ID.water : stack.name === 'lava_bucket' ? ID.lava : ID.powder_snow;
        if (targetId === 0 && blockIdToPlace !== undefined) {
          this.setBlock(tx, ty, tz, blockIdToPlace, 0);
          insertStack(this.containers[`${x},${y},${z}`], { name: 'bucket', count: 1 });
          return true;
        }
      }
      if (stack.name === 'bucket' && (targetId === ID.water || targetId === ID.lava || targetId === ID.powder_snow) && targetSt === 0) {
        this.setBlock(tx, ty, tz, 0, 0);
        const filled = targetId === ID.water ? 'water_bucket' : targetId === ID.lava ? 'lava_bucket' : 'powder_snow_bucket';
        insertStack(this.containers[`${x},${y},${z}`], { name: filled, count: 1 });
        return true;
      }
      if (stack.name === 'boat' || stack.name === 'minecart' || isCartKind(stack.name)) {
        if (this.vehicles.place(stack.name as any, tx, ty, tz)) return true;
      }
      if (stack.name === 'arrow' || stack.name === 'spectral_arrow') {
        this.mobs.shootPlayerArrow(new THREE.Vector3(tx + 0.5, ty + 0.5, tz + 0.5), new THREE.Vector3(...f), 18, 5);
        return true;
      }
      if (stack.name === 'snowball' || stack.name === 'wind_charge') {
        this.mobs.launchProjectile(stack.name, new THREE.Vector3(tx + 0.5, ty + 0.5, tz + 0.5), new THREE.Vector3(...f), 16);
        return true;
      }
      if (stack.name === 'tnt') {
        this.simulation.enqueue(tx, ty, tz, ID.tnt);
        return true;
      }
      if ((stack.name === 'shulker_box' || stack.name.endsWith('_shulker_box')) && targetId === 0 && ID.shulker_box !== undefined) {
        this.setBlock(tx, ty, tz, ID.shulker_box, dir);
        const slots = Array.from({ length: 27 }, () => null) as (Stack | null)[];
        if (stack.items) for (let i = 0; i < Math.min(27, stack.items.length); i++) slots[i] = stack.items[i] ? { ...stack.items[i]! } : null;
        this.containers[`${tx},${ty},${tz}`] = slots;
        return true;
      }
    }
    this.particles.drop(new THREE.Vector3(tx + 0.5, ty + 0.5, tz + 0.5), stack.name, 1, resolve(stack.name)?.color ?? '#ccc');
    return true;
  }

  /** Hoppers pull one item from the container above (or dropped items above) and push into the container they face. */
  private pushEntitiesByPiston(moves: { x: number; y: number; z: number; dx: number; dy: number; dz: number; cell: number }[], dir: readonly [number, number, number], slimeBounce: boolean) {
    for (const m of moves) {
      const bid = blockId(m.cell);
      const tx = m.x + m.dx, ty = m.y + m.dy, tz = m.z + m.dz;
      const inBox = (px: number, py: number, pz: number) =>
        Math.abs(px - (tx + 0.5)) < 0.85 && Math.abs(pz - (tz + 0.5)) < 0.85 && py >= ty - 0.5 && py <= ty + 1.8;
      const onHoney = bid === ID.honey_block && Math.abs(this.position.x - (m.x + 0.5)) < 0.75 && Math.abs(this.position.z - (m.z + 0.5)) < 0.75 && this.position.y >= m.y + 0.8 && this.position.y <= m.y + 2.1;
      if (inBox(this.position.x, this.position.y, this.position.z) || onHoney) {
        this.position.x += dir[0];
        this.position.y += dir[1];
        this.position.z += dir[2];
        if (slimeBounce && bid === ID.slime_block) {
          if (dir[1] > 0) { this.velocity.y = Math.max(this.velocity.y, 10); this.grounded = false; }
          else { this.position.x += dir[0] * 1.5; this.position.z += dir[2] * 1.5; }
        }
      }
      for (const v of this.vehicles?.vehicles ?? []) {
        if (inBox(v.pos.x, v.pos.y, v.pos.z)) {
          v.pos.x += dir[0]; v.pos.y += dir[1]; v.pos.z += dir[2];
          if (slimeBounce && bid === ID.slime_block && dir[1] > 0) v.vel.y = Math.max(v.vel.y, 8);
        }
      }
    }
  }

  private hopperTransfer(x: number, y: number, z: number, dir: number): boolean {
    const own = this.containerAt(x, y, z);
    if (!own) return false;
    const f = [[1, 0, 0], [0, 0, 1], [-1, 0, 0], [0, 0, -1], [0, 1, 0], [0, -1, 0]][dir] ?? [0, -1, 0];
    const tx = x + f[0], ty = y + f[1], tz = z + f[2];
    const targetBlock = this.getBlock(tx, ty, tz);
    const aboveBlock = this.getBlock(x, y + 1, z);
    const cartDest = this.vehicles?.vehicles.find(v => v.items && Math.floor(v.pos.x) === tx && Math.floor(v.pos.z) === tz && Math.abs(v.pos.y - ty) < 1.2)?.items ?? null;
    const cartSource = this.vehicles?.vehicles.find(v => v.items && Math.floor(v.pos.x) === x && Math.floor(v.pos.z) === z && Math.abs(v.pos.y - (y + 1)) < 1.2)?.items ?? null;
    const destination = this.containerAt(tx, ty, tz) ?? cartDest;
    const source = this.containerAt(x, y + 1, z) ?? cartSource;
    const crafter = targetBlock === ID.crafter;
    const forbidShulker = targetBlock === ID.shulker_box;
    const fromSide = dir !== 4 && dir !== 5;
    let pushed = destination ? transferOne(own, destination, crafter ? this.crafterMask(`${tx},${ty},${tz}`) : 0, crafter, fromSide, undefined, forbidShulker) : false;
    if (!pushed && targetBlock === ID.composter) {
      const cst = blockState(this.getCell(tx, ty, tz)) & 15;
      if (cst < 7) {
        const idx = own.findIndex(s => s && s.count > 0 && this.farming.compost(tx, ty, tz, s.name) !== null);
        if (idx >= 0) {
          own[idx]!.count--;
          if (own[idx]!.count <= 0) own[idx] = null;
          const next = Math.min(8, cst + 1);
          this.setBlock(tx, ty, tz, ID.composter, next === 7 ? 8 : next);
          pushed = true;
        }
      }
    }
    let pulled = source ? transferOne(source, own, 0, false, false) : false;
    if (!pulled && aboveBlock === ID.composter) {
      const cst = blockState(this.getCell(x, y + 1, z)) & 15;
      if (cst >= 7 && insertStack(own, { name: 'bone_meal', count: 1 })) {
        this.setBlock(x, y + 1, z, ID.composter, 0);
        pulled = true;
      }
    }
    if (!source) {
      const dropsList = (this.particles as any).drops as { mesh: THREE.Mesh; name: string; count: number }[] | undefined;
      if (dropsList) {
        const i = dropsList.findIndex(d => Math.abs(d.mesh.position.x - x - 0.5) < 0.75 && Math.abs(d.mesh.position.z - z - 0.5) < 0.75 && d.mesh.position.y >= y + 0.25 && d.mesh.position.y <= y + 2);
        if (i >= 0) {
          const drop = dropsList[i];
          if (insertStack(own, { name: drop.name, count: 1 })) {
            pulled = true;
            drop.count--;
            if (drop.count <= 0) { this.scene.remove(drop.mesh); dropsList.splice(i, 1); }
          }
        }
      }
    }
    return pushed || pulled;
  }

  // ---- Record 016 adapters ------------------------------------------------------------------------------------------------
  /** Drops an item entity that keeps its NBT (shulker contents, repair cost, dye colour) until it is picked up. */
  dropStack(x: number, y: number, z: number, stack: Stack) {
    SV.rememberDrop(this, stack);
    this.particles.drop(new THREE.Vector3(x, y, z), stack.name, stack.count, resolve(stack.name)?.color ?? '#aaa');
  }

  private takeDropNear(x: number, y: number, z: number): Stack | null {
    const list = (this.particles as any).drops as { mesh: THREE.Mesh; name: string; count: number }[] | undefined;
    if (!list) return null;
    const i = list.findIndex(d => Math.abs(d.mesh.position.x - x) < 1 && Math.abs(d.mesh.position.z - z) < 1 && d.mesh.position.y >= y - 0.25 && d.mesh.position.y <= y + 1.75);
    if (i < 0) return null;
    const d = list[i];
    this.scene.remove(d.mesh);
    list.splice(i, 1);
    return { name: d.name, count: d.count };
  }

  private gameplayEntities(): EntityView[] {
    const out: EntityView[] = [];
    const free = (x: number, y: number, z: number) => !BLOCKS[this.getBlock(x, y, z)]?.solid;
    for (const m of this.mobs.mobs) {
      const p = m.group.position;
      out.push({ x: p.x, y: p.y, z: p.z, kind: 'mob', push: dy => { if (free(p.x, p.y + dy + (dy > 0 ? 1 : 0), p.z)) { p.y += dy; if (dy > 0 && (m as any).vy < 0) (m as any).vy = 0; } } });
    }
    const drops = (this.particles as any).drops as { mesh: THREE.Mesh }[] | undefined;
    for (const d of drops ?? []) {
      const p = d.mesh.position;
      out.push({ x: p.x, y: p.y, z: p.z, kind: 'item', push: dy => { if (free(p.x, p.y + dy, p.z)) p.y += dy; } });
    }
    for (const v of this.vehicles.vehicles) out.push({ x: v.pos.x, y: v.pos.y, z: v.pos.z, kind: 'vehicle' });
    return out;
  }

  private createGameplay(): Gameplay {
    const g = new Gameplay(this as unknown as GameplayHost, {
      rsSet: (x, y, z, id, state) => this.redstone.setExternal(x, y, z, id, state),
      rsInput: (x, y, z, toward) => this.redstone.inputAt(x, y, z, toward),
      rsPositions: () => this.redstone.active,
      drop: (x, y, z, stack) => this.dropStack(x, y, z, stack),
      give: stack => SV.addStack(this, stack),
      sound: (k, p) => this.audio?.play(k, p),
      toast: (j, e) => this.onToast(j, e),
      damage: (n, source) => { this.damage(n, source); },
      finishConsume: stack => this.finishConsume(stack),
      openContainer: k => { this.stationKey = k; this.pause(true); this.onScreen('container'); },
      consumeHeld: () => { if (this.meta.mode !== 'creative') this.consumeSelected(); },
      wearHeld: n => { if (this.meta.mode !== 'creative') SV.wear(this, 'main', n); },
      entities: () => this.gameplayEntities(),
      skyVisible: (x, y, z) => {
        for (let yy = y; yy < MIN_Y + HEIGHT; yy++) { const b = this.getBlock(x, yy, z); if (b > 0 && BLOCKS[b]?.solid) return false; }
        return true;
      },
      snowing: (x, z) => /snow|frozen|ice|grove/.test(String(this.terrain.biome(x, z))),
      randomTickSpeed: () => this.farming.speed,
      random: Math.random,
      cookResult: name => { const r = SMELTING[name]?.result; return r && resolve(r)?.food ? r : null; },
    });
    g.events.on('ender_chest_close', () => this.pushEnderChest());
    return g;
  }

  /** A meal or drink was finished (the button was held for the full use time). */
  private finishConsume(stack: Stack) {
    const name = stack.name, potion = potionEffects(name);
    if (potion && !potion.splash) for (const [id, sec, a] of potion.effects) SV.addEffect(this, id, sec, a);
    else if (name === 'milk_bucket') { SV.clearEffects(this); this.mobs.badOmen = false; }
    else SV.foodEffects(this, name);
    if (name === 'chorus_fruit') {
      const rx = this.position.x + (Math.random() - 0.5) * 14, rz = this.position.z + (Math.random() - 0.5) * 14;
      this.teleport(rx, this.terrain.height(rx, rz) + 1.1, rz);
      this.gameplay.vibrate('teleport', rx, this.position.y, rz);
    }
    this.audio?.play('eat');
    this.handDip = 0.22;
  }

  /** Right-click on a chest / hopper / furnace / TNT minecart. */
  private useCartVariant(v: Vehicle, held: Stack | null): boolean {
    const name = held?.name ?? '';
    if ((v.kind === 'chest_minecart' || v.kind === 'hopper_minecart') && v.items) {
      const key = 'vehicle:' + v.id;
      this.gameplay.bindContainer(key, v.items);
      this.stationKey = key;
      this.audio?.play('chest', v.pos);
      this.gameplay.vibrate('container_open', v.pos.x, v.pos.y, v.pos.z);
      this.pause(true);
      this.onScreen('container');
    } else if (v.kind === 'furnace_minecart') {
      if (name === 'coal' || name === 'charcoal') {
        if (this.vehicles.addFuel(v, this.position.x, this.position.z)) { if (this.meta.mode !== 'creative') this.consumeSelected(); this.audio?.play('fuse', v.pos); this.handDip = 0.16; }
      } else this.onToast('石炭か木炭を入れると走り出します（残り燃料 ' + Math.ceil(v.fuel / 20) + ' 秒）', 'Feed it coal or charcoal (' + Math.ceil(v.fuel / 20) + 's of fuel left)');
    } else if (v.kind === 'tnt_minecart') {
      if (name === 'flint_and_steel' && this.vehicles.prime(v)) { if (this.meta.mode !== 'creative') SV.wear(this, 'main', 1); this.gameplay.vibrate('prime_fuse', v.pos.x, v.pos.y, v.pos.z); }
    }
    return true;
  }

  /** Ender chest: the server row for this player UUID wins when it is newer than what the local save holds. */
  private syncEnderChest(fresh = false) {
    const uuid = playerUUID(), world = this.meta.id, epoch = ++this.enderEpoch;
    this.gameplay.playerUUID = uuid;
    if (!world) return;
    if (fresh) { this.gameplay.enderUpdatedAt = Date.now(); this.gameplay.enderDirty = true; this.pushEnderChest(); return; }
    pullEnderItems(uuid, world).then(res => {
      if (!res || epoch !== this.enderEpoch || this.meta.id !== world) return;
      if (res.updatedAt > this.gameplay.enderUpdatedAt) this.gameplay.setEnderItems(itemsFromNbt(res.EnderItems, 27), res.updatedAt);
      else if (this.gameplay.enderUpdatedAt > res.updatedAt) { this.gameplay.enderDirty = true; this.pushEnderChest(); }
    });
  }
  private pushEnderChest() {
    const g = this.gameplay;
    if (!g.enderDirty || !this.meta.id) return;
    g.enderDirty = false;
    pushEnderItems(g.playerUUID, this.meta.id, itemsToNbt(g.enderItems)).then(at => { if (at) g.enderUpdatedAt = Math.max(g.enderUpdatedAt, at); else g.enderDirty = true; });
  }
  /** Numeric block id for a block name (undefined when unknown) — for tools, tests and the renderer. */
  blockIdOf(name: string): number | undefined { return ID[name]; }
  /** The ender chest container key (the same inventory behind every ender chest block). */
  get enderKey() { return ENDER_KEY; }

  countItem(name: string) {
    return [...this.hotbar, ...this.inventory].reduce((n, s) => n + (s?.name === name ? s.count : 0), 0);
  }

  removeItem(name: string, count: number) {
    if (this.countItem(name) < count) return false;
    for (const arr of [this.hotbar, this.inventory]) {
      for (let i = 0; i < arr.length; i++) {
        const s = arr[i];
        if (s?.name === name) {
          const n = Math.min(count, s.count);
          s.count -= n; count -= n;
          if (s.count <= 0) arr[i] = null;
          if (!count) return true;
        }
      }
    }
    return true;
  }

  command(text: string) {
    const [cmd, ...args] = text.trim().replace(/^\//, '').split(/\s+/);
    if (!text.startsWith('/')) return 'Steve: ' + text;
    switch (cmd) {
      case 'help':
        return '/effect give <effect> [sec] [amp] · /enchant <id> [lvl] · /xp <n|nL> · /clear · /locate mineshaft|shipwreck|monument|mansion|outpost|ancient_city|bastion · ' + '/give <item> [count] · /tp <x> <y> <z> · /time day|night|<0–1> · /weather clear|rain|storm · /gamemode survival|creative|adventure|spectator · /setblock <x> <y> <z> <block> · /dimension overworld|nether|end · /summon <mob> · /locate <stronghold|endcity|village|dungeon|pyramid|fortress|biome> · /seed';
      case 'locate': {
        const what = (args[0] === 'structure' || args[0] === 'biome' ? args[1] : args[0]) ?? '';
        const hit = what ? this.terrain.locate(what.replace(/^minecraft:/, ''), this.position.x, this.position.z) : null;
        if (!hit) return 'Could not find "' + what + '" nearby. Try: stronghold, endcity, village, dungeon, pyramid, fortress or a biome name';
        return `The nearest ${what} is at ${hit[0]}, ${hit[1]}, ${hit[2]} (${Math.round(Math.hypot(hit[0] - this.position.x, hit[2] - this.position.z))} blocks away)`;
      }
      case 'seed': return this.meta.seed;
      case 'weather':
        if (args[0] === 'clear' || args[0] === 'rain' || args[0] === 'storm') {
          this.weather = args[0]; this.weatherTimer = 90;
          return 'Weather set to ' + args[0];
        }
        return 'Usage: /weather clear|rain|storm';
      case 'summon': {
        const species = args[0]?.replace(/^minecraft:/, '') as Species;
        if (this.mobs.spawn(species, this.position.x + 3, this.position.z + 3, false, this.position.y)) return 'Summoned ' + species;
        return 'Cannot spawn here';
      }
      case 'raid': {
        if (this.meta.difficulty === 'peaceful') return 'Raids require a non-peaceful difficulty';
        if (args[0] === 'stop') { this.mobs.raid = null; return 'Raid stopped'; }
        this.mobs.startRaid(this.position);
        return 'Raid started';
      }
      case 'gamerule': {
        if (args[0] === 'randomTickSpeed') {
          if (args[1] !== undefined) this.farming.speed = Math.max(0, Math.min(4096, Number(args[1]) || 0));
          return `randomTickSpeed = ${this.farming.speed}`;
        }
        return 'Usage: /gamerule randomTickSpeed <0-4096>';
      }
      case 'mobs': {
        const counts: Record<string, number> = {};
        for (const m of this.mobs.mobs) counts[m.species] = (counts[m.species] ?? 0) + 1;
        return `${this.mobs.mobs.length} mobs: ` + Object.entries(counts).map(([k, v]) => `${k}×${v}`).join(', ');
      }
      case 'time': {
        const v = args[0] === 'day' ? 0.2 : args[0] === 'night' ? 0.72 : Number(args[0]);
        if (!Number.isFinite(v)) return 'Usage: /time day|night|0–1';
        this.time = ((v % 1) + 1) % 1;
        return 'Time set to ' + this.time.toFixed(2);
      }
      case 'gamemode':
        if (['creative', 'survival', 'adventure', 'spectator'].includes(args[0])) {
          this.meta.mode = args[0] as any;
          return 'Game mode: ' + args[0];
        }
        return 'Unknown game mode';
      case 'give': {
        const n = Math.min(640, Math.max(1, Number(args[1]) || 1));
        if (!resolve(args[0])) return 'Unknown item: ' + args[0];
        return this.addItem(args[0], n) ? 'Given ' + n + ' ' + args[0] : 'Inventory full';
      }
      case 'tp': {
        const p = args.map(Number);
        if (p.length !== 3 || !p.every(Number.isFinite)) return 'Usage: /tp x y z';
        this.teleport(p[0], p[1], p[2]);
        return 'Teleported to ' + p.join(', ');
      }
      case 'setblock': {
        const p = args.slice(0, 3).map(Number), id = ID[args[3]];
        if (p.length !== 3 || !p.every(Number.isFinite) || id === undefined) return 'Usage: /setblock x y z block_id';
        return this.setBlock(p[0], p[1], p[2], id) ? 'Block placed' : 'Chunk not loaded';
      }
      case 'dimension':
        if (['overworld', 'nether', 'end'].includes(args[0])) {
          this.changeDimension(args[0] as Dimension);
          return 'Traveling to ' + args[0];
        }
        return 'Unknown dimension';
      case 'effect': case 'enchant': case 'xp': case 'clear': case 'kill':
        return SV.command(this, cmd, args);
      default: return 'Unknown command. /help';
    }
  }

  consumeSelected() {
    const s = this.hotbar[this.selected];
    if (s) { s.count--; if (s.count <= 0) this.hotbar[this.selected] = null; }
  }

  addItem(name: string, count: number) {
    const def = resolve(name);
    if (!def || !Number.isInteger(count) || count <= 0) return false;
    const max = def.stack, slots = [...this.hotbar, ...this.inventory];
    const capacity = slots.reduce((sum, slot) => sum + (!slot ? max : slot.name === name ? Math.max(0, max - slot.count) : 0), 0);
    if (capacity < count) return false;
    let remaining = count;
    for (const slot of slots) {
      if (slot?.name === name && slot.count < max) {
        const n = Math.min(max - slot.count, remaining);
        slot.count += n; remaining -= n;
        if (!remaining) return true;
      }
    }
    for (const arr of [this.hotbar, this.inventory]) {
      for (let i = 0; i < arr.length; i++) {
        if (!arr[i]) {
          const n = Math.min(max, remaining);
          arr[i] = { name, count: n }; remaining -= n;
          if (!remaining) return true;
        }
      }
    }
    return true;
  }

  addXp(n: number) {
    if (n <= 0) return;
    n = SV.mend(this, n);
    if (n <= 0) return;
    this.xp += n;
    const lvl = V.levelFromXp(this.xp);
    if (lvl > this.lastLevel) {
      this.lastLevel = lvl;
      this.audio?.play('levelup');
      this.onToast(`レベル ${lvl} に到達！`, `Level ${lvl} reached!`);
    }
  }

  private computeArmor(): number {
    return SV.armorPoints(this);
  }

  dropSelected() {
    const s = this.hotbar[this.selected];
    if (!s) return;
    this.camera.getWorldDirection(this._dir);
    this.particles.drop(this.camera.position.clone().addScaledVector(this._dir, 1.5), s.name, 1, resolve(s.name)?.color ?? '#aaa', s);
    SV.rememberDrop(this, s);
    this.statistics.dropped = (this.statistics.dropped ?? 0) + 1;
    s.count--;
    if (s.count <= 0) this.hotbar[this.selected] = null;
  }

  craftRecipe(id: string, table: boolean, all = false) {
    const r = RECIPES.find(x => x.id === id);
    if (!r) return false;
    let crafted = false;
    const loops = all ? 64 : 1;
    for (let i = 0; i < loops; i++) {
      if (!canCraft(r, recipeCounts([...this.hotbar, ...this.inventory]), this.meta.mode === 'creative', table)) break;
      const backup = this.hotbar.map(s => (s ? { ...s } : null));
      const backupInv = this.inventory.map(s => (s ? { ...s } : null));
      if (this.meta.mode !== 'creative') {
        for (const [n, c] of Object.entries(r.ingredients)) this.removeItem(n, c);
      }
      if (!this.addItem(r.result, r.count)) {
        this.hotbar = backup;
        this.inventory = backupInv;
        break;
      }
      crafted = true;
      if (this.meta.mode === 'creative') break;
    }
    if (crafted) {
      this.achievement('craft');
      this.audio?.play('wood');
    }
    return crafted;
  }

  trade(give: string, cost: number, result: string, count: number, ench?: Record<string, number>) {
    const backup = this.hotbar.map(s => (s ? { ...s } : null));
    const backupInv = this.inventory.map(s => (s ? { ...s } : null));
    const ok = this.removeItem(give, cost) && (ench ? SV.addStack(this, { name: result, count, ench }) : this.addItem(result, count));
    if (ok) { this.addXp(3); this.villagerHappy(); return true; }
    this.hotbar = backup;
    this.inventory = backupInv;
    return false;
  }

  /** Buys a villager offer. Explorer maps carry their target, so they are handed over as a stack with map data. */
  tradeOffer(tr: Offer): boolean {
    if (tr.pending) return false;
    const spec = tr.map ? mapSpecOf(tr.get) : undefined;
    if (!tr.map || !spec) return this.trade(tr.give, tr.n, tr.get, tr.count, tr.ench);
    if (!this.removeItem(tr.give, tr.n)) return false;
    if (!SV.addStack(this, mapStack(spec, tr.map.x, tr.map.z))) { this.addItem(tr.give, tr.n); return false; }
    this.addXp(3);
    return true;
  }

  updateStations(dt: number) {
    const keys = Object.keys(this.furnaces), count = Math.min(8, keys.length);
    if (!count) return;
    const elapsed = dt * Math.max(1, keys.length / count);
    for (let i = 0; i < count; i++) {
      const key = keys[(this.stationCursor + i) % keys.length];
      const state = this.furnaces[key], slots = this.containers[key];
      if (state && slots?.length === 5) { SV.brewTick(this, state, slots, elapsed); continue; }
      if (!state || !slots || slots.length !== 3) continue;
      const input = slots[0], fuel = slots[1], output = slots[2];
      const recipe = input ? SMELTING[input.name] : undefined;
      state.burn = Math.max(0, state.burn - elapsed);
      if (recipe && (!output || (output.name === recipe.result && output.count < 64))) {
        if (state.burn <= 0 && fuel && FUEL[fuel.name]) {
          state.burn = FUEL[fuel.name];
          fuel.count--;
          if (fuel.count <= 0) slots[1] = fuel.name === 'lava_bucket' ? { name: 'bucket', count: 1 } : null;
        }
        if (state.burn > 0) {
          state.progress += elapsed / recipe.time;
          if (state.progress >= 1) {
            state.progress = 0;
            input!.count--;
            if (input!.count <= 0) slots[0] = null;
            if (output) output.count++;
            else slots[2] = { name: recipe.result, count: 1 };
            this.audio?.play('stone');
          }
        }
      } else {
        state.progress = 0;
      }
    }
    this.stationCursor = (this.stationCursor + count) % keys.length;
  }

  explode(p: THREE.Vector3, r: number) {
    this.audio?.play('explosion', p);
    this.gameplay.vibrate('explode', p.x, p.y, p.z);
    this.particles.burst(p, '#e8c28a', 40, 8);
    this.particles.burst(p, '#6b675c', 30, 5);
    const d = p.distanceTo(this.position);
    if (d < r * 2) this.damage(Math.ceil((r * 2 - d) * 2), 'explosion', { from: p.clone() });
    for (let y = -r; y <= r; y++) for (let z = -r; z <= r; z++) for (let x = -r; x <= r; x++) {
      if (x * x + y * y + z * z <= r * r) this.explosionQueue.push([p.x + x, p.y + y, p.z + z]);
    }
  }

  swapSlots(a: number, b: number) {
    return SV.swapSlots(this, a, b);
  }

  toggleElytra() { SV.toggleElytra(this); }

  give(name: string, count = 64) {
    const def = resolve(name);
    if (!def) return false;
    const ok = this.addItem(name, count);
    this.onToast(def.ja + ' × ' + count, def.name + ' × ' + count);
    return ok;
  }

  achievement(id: string) {
    if (!this.achievements.includes(id)) {
      this.achievements.push(id);
      const names: Record<string, string> = {
        mine: 'はじまりの一歩',
        place: '建築の時間',
        craft: 'ものづくりの達人',
        nether: 'さらなる深みへ（ネザー）',
        fish: '釣り日和',
        farm: '種をまく時',
        ride: '乗り物に乗って',
        end: 'おしまい？（ジ・エンド）',
        dragon: 'エンドの解放（エンドラ討伐）',
        enchant: 'エンチャントの使い手',
        brew: '町のお薬屋さん',
      };
      this.onToast('進捗達成: ' + (names[id] ?? id), 'Advancement: ' + id);
    }
  }

  damage(amount: number, source = 'generic', atk?: SV.Attacker): SV.HurtResult {
    const res = SV.hurt(this, amount, source, false, atk);
    if (amount > 0) this.gameplay?.vibrate('entity_damage', this.position.x, this.position.y + 1, this.position.z);
    return res;
  }

  respawn() {
    SV.clearEffects(this);
    this.health = 20;
    this.hunger = 20; this.saturation = 5; this.exhaustion = 0; this.foodTimer = 0; this.lastHit = null; this.shieldCdUntil = -1;
    this.dead = false;
    this.gliding = false;
    this.levitationTimer = 0;
    if (this.dimension !== 'overworld') this.changeDimension('overworld');
    const p = this.respawnPoint ?? this.terrain.spawnPosition(2);
    this.position.set(p[0], p[1], p[2]);
    this.velocity.set(0, 0, 0);
    this.fallTop = this.position.y;
  }

  teleport(x: number, y: number, z: number) {
    this.position.set(x, y, z);
    this.velocity.set(0, 0, 0);
    this.fallTop = y;
    this.focus = '';
  }

  private stashEntities() {
    this.entityStores[this.dimension] = {
      mobs: this.mobs.save(),
      vehicles: this.vehicles.save(),
      badOmen: this.mobs.badOmen,
      raid: this.mobs.raid ? structuredClone(this.mobs.raid) : undefined,
    };
  }
  private restoreEntities() {
    const data = this.entityStores[this.dimension];
    if (data) {
      this.mobs.load(data.mobs ?? []);
      this.vehicles.load(data.vehicles ?? []);
      this.mobs.badOmen = !!data.badOmen;
      this.mobs.raid = data.raid ?? null;
    } else {
      this.mobs.populate();
      this.mobs.badOmen = false;
    }
  }
  shriekerWarnings = 0;
  private triggerSculkSensors(vx: number, vy: number, vz: number, _strength: number) {
    this.gameplay?.vibrate('step', vx, vy, vz);
    if (ID.sculk_shrieker !== undefined && this.gamerules.doWardenSpawning) {
      const bx = Math.floor(vx), by = Math.floor(vy), bz = Math.floor(vz);
      for (let dy = -4; dy <= 4; dy++) for (let dz = -8; dz <= 8; dz++) for (let dx = -8; dx <= 8; dx++) {
        if (this.getBlock(bx + dx, by + dy, bz + dz) === ID.sculk_shrieker) {
          this.shriekerWarnings++;
          SV.addEffect(this, 'darkness', 12, 0);
          if (this.shriekerWarnings >= 4) {
            this.shriekerWarnings = 0;
            this.mobs.summonWarden(bx + dx, by + dy + 1, bz + dz);
          }
          break;
        }
      }
    }
    if (ID.sculk_sensor === undefined) return;
    const bx = Math.floor(vx), by = Math.floor(vy), bz = Math.floor(vz);
    for (let dy = -4; dy <= 4; dy++) for (let dz = -8; dz <= 8; dz++) for (let dx = -8; dx <= 8; dx++) {
      if (dx * dx + dy * dy + dz * dz > 64) continue;
      const sx = bx + dx, sy = by + dy, sz = bz + dz;
      const cell = this.getCell(sx, sy, sz);
      if (blockId(cell) === ID.sculk_sensor && blockState(cell) === 0) {
        this.setBlock(sx, sy, sz, ID.sculk_sensor, 15);
        this.redstone.register(sx, sy, sz);
      }
    }
  }

  changeDimension(dimension: Dimension) {
    if (dimension === this.dimension) return;
    this.redstone.flush();
    this.pistonAnimations.clear();
    this.stashEntities();
    this.dimensionStores[this.dimension] = { edits: this.edits, containers: this.containers, furnaces: this.furnaces };
    this.dimension = dimension;
    this.w121.enter(dimension);
    this.attachDimensionStore(dimension);
    this.terrain = new Terrain(this.meta.seed, dimension);
    this.mobs.host.terrain = this.terrain;
    this.mobs.host.dimension = dimension;
    this.mobs.clear();
    this.particles.clear();
    this.simulation.clear();
    this.clearChunks();
    const spawnY = dimension === 'end' ? Math.max(24, this.terrain.height(0, 8) + 2) : this.terrain.height(0, 8) + 2;
    if (dimension !== 'end') this.position.set(...this.terrain.spawnPosition(2));
    else this.position.set(0, spawnY, 8);
    this.restoreEntities();
    this.velocity.set(0, 0, 0);
    this.gliding = false;
    this.portalCharge = 0;
    this.levitationTimer = 0;
    this.ready = false;
    this.focus = '';
    this.streamAt = -10;
    this.environment.markShadow();
  }

  snapshot(): WorldSave {
    this.redstone.flush();
    this.pistonAnimations.clear();
    this.stashEntities();
    this.dimensionStores[this.dimension] = { edits: this.edits, containers: this.containers, furnaces: this.furnaces };
    const dimensions: NonNullable<WorldSave['dimensions']> = {};
    for (const dimension of ['overworld', 'nether', 'end'] as const) {
      const store = this.dimensionStores[dimension];
      if (store) dimensions[dimension] = { edits: [...store.edits], containers: store.containers, furnaces: store.furnaces };
    }
    return {
      meta: { ...this.meta, updated: Date.now() },
      position: this.position.toArray() as [number, number, number],
      yaw: this.input.yaw,
      pitch: this.input.pitch,
      time: this.time,
      dimension: this.dimension,
      edits: [...this.edits],
      inventory: this.inventory,
      hotbar: this.hotbar,
      health: this.health,
      hunger: this.hunger,
      xp: this.xp,
      selected: this.selected,
      statistics: this.statistics,
      achievements: this.achievements,
      containers: this.containers,
      furnaces: this.furnaces,
      dimensions,
      respawnPoint: this.respawnPoint,
      dragonDefeated: this.dragonDefeated,
      elytraEquipped: this.elytraEquipped,
      entities: structuredClone(this.entityStores),
      crafterDisabled: { ...this.crafterDisabled },
      banners: Object.fromEntries(this.banners),
      signs: Object.fromEntries(this.signs),
      beacons: Object.fromEntries(this.beacons),
      pots: Object.fromEntries(this.pots),
      randomTickSpeed: this.farming.speed,
      w121: this.w121.save(),
      gameplay: this.gameplay.save(),
      ...SV.savePlayer(this),
    };
  }

  save() { if (this.meta.id) { this.onSave(this.snapshot()); this.pushEnderChest(); } }

  private frame = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.frame);
    const dt = Math.min(0.04, this.last ? (now - this.last) / 1000 : 0.016);
    this.last = now;
    if (this.previewPaused) { this.last = now; return; }
    this.elapsed += dt;
    this.frameCount++;
    if (this.hitFlash > 0) this.hitFlash = Math.max(0, this.hitFlash - dt);

    if (now - this.fpsAt > 1000) {
      this.fps = Math.round((this.frameCount * 1000) / (now - this.fpsAt));
      this.frameCount = 0;
      this.fpsAt = now;
      if (this.active && this.ready && this.settings.adaptiveResolution && this.queue.length === 0 && this.pending.size === 0 && now - this.lastScaleCheck > 4000) {
        this.lastScaleCheck = now;
        const next = this.fps < 43 ? Math.max(0.68, this.renderScale - 0.12) : this.fps > 57 ? Math.min(1, this.renderScale + 0.05) : this.renderScale;
        if (Math.abs(next - this.renderScale) > 0.01) {
          this.renderScale = next;
          this.renderer.setPixelRatio(this.basePixelRatio * this.renderScale);
          this.resize();
        }
      }
    }

    if (this.elapsed - this.streamAt > 0.65) {
      this.streamAt = this.elapsed;
      this.stream();
    }
    this.dispatch();

    // Amortized chunk geometry upload (max 2 chunks/frame during active gameplay so FPS stays locked!)
    let uploaded = 0;
    const maxUploads = this.uploadQueue.length > 8 ? 3 : 2;
    while (this.uploadQueue.length > 0 && uploaded < maxUploads) {
      const item = this.uploadQueue.shift()!;
      this.mountChunk(item.m);
      if (!item.m.sideOnly) uploaded++;
    }

    if (!this.ready) {
      const usePosition = this.pendingPlay || this.active;
      const cx = Math.floor((usePosition ? this.position.x : 0) / 16);
      const cz = Math.floor((usePosition ? this.position.z : 0) / 16);
      let near = 0;
      for (let z = -1; z <= 1; z++) for (let x = -1; x <= 1; x++) if (this.chunks.has((cx + x) + ',' + (cz + z))) near++;
      if (near === 9) {
        this.ready = true;
        if (this.pendingPlay) {
          this.pendingPlay = false;
          this.activate();
        } else if (!this.active && !this.input.active) {
          this.panoramaCamera();
        }
      }
    }

    if (this.active && this.ready) {
      this.input.update(dt);
      if (this.sleeping) {
        this.sleepTimer -= dt;
        if (this.sleepTimer <= 0) {
          this.sleeping = false;
          this.lastSleepAt = this.meta.playTime;
          this.time = 0.08;
          this.weather = 'clear';
          this.weatherTimer = 90;
          this.health = Math.min(20, this.health + 4);
          this.onToast('朝になりました', 'Good morning!');
        }
      }
      this.time = (this.time + dt / 1200) % 1;
      this.meta.playTime += dt;

      this.weatherTimer -= dt;
      if (this.weatherTimer <= 0 && this.dimension === 'overworld') {
        this.weatherTimer = 45 + Math.random() * 80;
        this.weather = this.weather === 'clear' ? (Math.random() < 0.2 ? 'storm' : 'rain') : 'clear';
        if (this.weather === 'clear') this.onToast('雨が上がりました', 'The rain has stopped');
        else this.onToast(this.weather === 'storm' ? '雷雨が近づいています' : '雨が降り始めました', this.weather === 'storm' ? 'A thunderstorm is rolling in' : 'It has started raining');
      }
      if (this.weather === 'storm' && this.dimension === 'overworld') {
        this.lightningTimer -= dt;
        if (this.lightningTimer <= 0) {
          this.lightningTimer = 7 + Math.random() * 14;
          this.environment.triggerLightning();
          const rodCoords = [...this.lightningRods].map(k => k.split(',').map(Number) as [number, number, number]);
          const rod = findNearestLightningRod(rodCoords, this.position.x, this.position.z);
          if (rod) {
            this.redstone.triggerLightningRod(rod[0], rod[1], rod[2], 8);
            deoxidizeCopperAround((bx, by, bz) => this.getCell(bx, by, bz), (bx, by, bz, bid, bst = 0) => this.setBlock(bx, by, bz, bid, bst), rod[0], rod[1] - 1, rod[2]);
          } else {
            this.mobs.strikeLightning(this.position);
          }
          this.audio?.play('thunder');
          this.w121.lightning();
        }
      }

      this.physics(dt);
      this.camera.rotation.order = 'YXZ';
      const eatShakeX = SV.isEating(this) ? Math.cos(this.elapsed * 28) * 0.008 : 0;
      const eatShakeZ = SV.isEating(this) ? Math.sin(this.elapsed * 32) * 0.011 : 0;
      this.camera.rotation.set(this.input.pitch + eatShakeX, this.input.yaw, eatShakeZ);
// Dynamic FOV handled via Environment.updateFov
      this.mining(dt);
      this.updateHand(dt);
      this.simulation.update(dt, (x, y, z) => this._simVec.set(x, y, z));
      this.updateButtons();
      this.updateStations(dt);
      SV.tick(this, dt);
      this.gameplay.update(dt);
      this.bannerCheck();
      this.ambientTick(this.environment.daylight);
      this.mobs.update(dt, this.environment.daylight, this.meta.difficulty === 'peaceful');
      this.farming.tick(dt);
      this.w121.update(dt);
      this.dismountCooldown = Math.max(0, this.dismountCooldown - dt);
      if (this.fishing.active) {
        this.camera.getWorldDirection(this._dir);
        const tip = this.camera.position.clone().addScaledVector(this._dir, 0.9); tip.y -= 0.25; tip.x += Math.cos(this.input.yaw) * 0.35; tip.z -= Math.sin(this.input.yaw) * 0.35;
        this.fishing.update(dt, tip, () => this.mobs.mobs);
        if (this.hotbar[this.selected]?.name !== 'fishing_rod') this.fishing.remove();
      }
      // Sculk shriekers: the third shriek within a short time summons the warden.
      if (ID.sculk_shrieker !== undefined && this.getBlock(this.position.x, this.position.y - 0.2, this.position.z) === ID.sculk_shrieker) {
        const k = `${Math.floor(this.position.x)},${Math.floor(this.position.y - 0.2)},${Math.floor(this.position.z)}`;
        if (this.elapsed - (this.shrieks.get(k + ':t') ?? -10) > 6) {
          const n = (this.shrieks.get(k) ?? 0) + 1;
          this.shrieks.set(k, n); this.shrieks.set(k + ':t', this.elapsed);
          this.audio?.play('thunder'); SV.addEffect(this, 'darkness', 12);
          this.onToast(`スカルクシュリーカーが叫んだ（${n}/3）`, `Sculk shrieker (${n}/3)`);
          if (n >= 3) { this.shrieks.set(k, 0); this.mobs.summonWarden(this.position.x, this.position.y, this.position.z); }
        }
      }

      if (this.meta.mode === 'survival' || this.meta.mode === 'adventure') {
        const under = this.gameplay.isWater(this.camera.position.x, this.camera.position.y, this.camera.position.z);
        this.oxygen = under ? Math.max(0, this.oxygen - dt * SV.oxygenRate(this)) : Math.min(20, this.oxygen + dt * 3);
        if (this.oxygen <= 0 && under) SV.drown(this, dt);
      }

      let burstCount = 0;
      while (this.explosionQueue.length && burstCount++ < 10) {
        const [x, y, z] = this.explosionQueue.shift()!, id = this.getBlock(x, y, z);
        if (id > 0 && id !== ID.bedrock) this.setBlock(x, y, z, 0);
      }
      if (this.elapsed - this.autoSaveAt > 30) {
        this.autoSaveAt = this.elapsed;
        this.save();
      }
    } else if (!this.input.active && !this.active && this.meta.id === 'greenwood' && !this.dead) {
      this.panoramaCamera();
    }

    if (!this.active && this.stationsInMenu) this.updateStations(dt);

    const biomeKey = `${this.meta.seed},${this.dimension},${Math.floor(this.position.x / 4)},${Math.floor(this.position.z / 4)},${Math.floor(this.position.y / 8)}`;
    if (biomeKey !== this.biomeKey) {
      this.biomeKey = biomeKey;
      this.currentBiome = this.terrain.caveBiome(this.position.x, this.position.y, this.position.z) ?? this.terrain.biome(this.position.x, this.position.z);
    }

    this.tickFx(dt);
    this.particles.update(
      dt,
      (x, y, z) => this.getBlock(x, y, z),
      (n, c, p) => {
        if (this.position.distanceTo(p) < 2.2 && SV.pickup(this, n, c)) {
          this.audio?.play('xp');
          return true;
        }
        return false;
      },
      this.position,
    );
    if (!this.active && this.ready && this.meta.id === 'greenwood') this.mobs.update(dt, 0.8, true);

    const heldName = this.hotbar[this.selected]?.name ?? '';
    const heldLight = this.active && (HELD_LIGHT_ITEMS.has(heldName) || HELD_LIGHT_ITEMS.has(this.offhand?.name ?? '')) ? (heldName === 'lava_bucket' ? 0.95 : 0.85) : 0;
    const underwater = this.getBlock(this.camera.position.x, this.camera.position.y, this.camera.position.z) === ID.water;
    const moonPhase = Math.floor((this.meta.playTime / 240) % 8);
    if ((this.active || this.stationsInMenu) && this.redstone.active.size) {
      this.redstoneTimer += dt;
      while (this.redstoneTimer >= 0.05) { this.redstoneTimer -= 0.05; this.redstone.tick(); }
    }
    this.pistonAnimations.update(dt);
    const nightVision = V.nightVisionScale(SV.has(this, 'night_vision') ? this.effects.night_vision.t : 0);   // Java: whole-world brightening, flickers in the last 10 s
    this.mobs.applyNightVision(nightVision);
    this.environment.update(this.elapsed, this.time, this.camera, this.dimension, this.settings, this.weather, this.currentBiome, moonPhase, heldLight, underwater, nightVision, this.surfaceBiome);

    if (this.environment.failed) {
      for (const c of this.chunks.values()) c.solid.material = this.environment.fallback;
      if (!this.fallbackNotified) {
        this.fallbackNotified = true;
        this.onToast('セーフ描画モードに切り替えました', 'Safe rendering mode enabled');
      }
    }

    if (this.elapsed - this.lastShadow > 3.5 || this.position.distanceTo(this.lastShadowPos) > 4) {
      this.lastShadow = this.elapsed;
      this.lastShadowPos.copy(this.position);
      this.environment.markShadow();
    }

    this.cullChunks();
    this.renderer.render(this.scene, this.camera);
    this.audio?.listener(this.camera.position.x, this.camera.position.y, this.camera.position.z, this.input.yaw);

    if (now - this.snapshotAt > 110) {
      this.snapshotAt = now;
      this.onSnapshot({
        ...EMPTY_SNAPSHOT,
        ready: this.ready,
        progress: Math.min(1, this.chunks.size / ((this.settings.distance * 2 + 1) ** 2 * 0.78)),
        x: this.position.x, y: this.position.y, z: this.position.z,
        yaw: this.input.yaw, pitch: this.input.pitch,
        fps: this.fps, chunks: this.chunks.size,
        biome: this.currentBiome, dimension: this.dimension,
        health: this.health, hunger: this.hunger, oxygen: this.oxygen,
        xp: this.xp, level: V.levelFromXp(this.xp),
        armor: this.computeArmor(),
        time: this.time, selected: this.selected,
        hotbar: this.hotbar.map(s => (s ? { ...s } : null)),
        inventory: this.inventory.map(s => (s ? { ...s } : null)),
        target: this.target ? BLOCKS[this.target.id].name : '',
        breaking: this.breaking, mode: this.meta.mode, flying: this.flying,
        gliding: this.gliding, elytraEquipped: this.elytraEquipped,
        sleeping: this.sleeping, portalCharge: this.portalCharge,
        underwater,
        raining: this.weather !== 'clear', thundering: this.weather === 'storm',
        moonPhase, weather: this.weather, debug: this.debug,
        statistics: { ...this.statistics }, achievements: [...this.achievements],
        dead: this.dead, containers: this.containers,
        boss: this.mobs.getBossInfo(),
        ...(() => {
          const bi = this.mobs.bossInfo();
          return {
            bossName: bi?.name ?? '',
            bossHp: bi?.hp ?? 0,
            bossMaxHp: bi?.maxHp ?? 200,
            crystals: bi?.crystals ?? 0,
          };
        })(),
        dragonDefeated: this.dragonDefeated,
        hitFlash: this.hitFlash,
        ...this.gameplay.hud(),
        ...SV.hud(this),
        using: this.gameplay.hud().using ?? (SV.isEating(this) ? { name: this.useItemName, kind: SV.isDrinkItem(this.useItemName) ? 'drink' : 'food', progress: Math.min(1, this.useTime / SV.eatDuration(this.useItemName)) } : null),
      });
    }
  };

  private getCanvasTex(key: string, canvasEl?: HTMLCanvasElement | OffscreenCanvas) {
    let tex = this.handTextures.get(key);
    if (!tex && canvasEl) {
      tex = new THREE.CanvasTexture(canvasEl as HTMLCanvasElement);
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter;
      tex.colorSpace = THREE.SRGBColorSpace;
      this.handTextures.set(key, tex);
    }
    return tex ?? null;
  }

  updateHand(dt = 0.016) {
    const held = this.hotbar[this.selected], name = held?.name ?? 'hand';
    const patSig = held ? `${held.bannerBase ?? ''}:${(held.patterns ?? []).map(l => l.p + ':' + l.c).join(',')}` : '';
    const handKey = `${name}|${patSig}`;
    if (handKey !== this.lastHand) {
      this.lastHand = handKey;
      if (held) {
        const isBannerShield = (name === 'shield' || name.endsWith('_banner')) && (held.patterns?.length || held.bannerBase);
        const faces = !isBannerShield ? blockFaceCanvases(name) : null;
        const bDef = ID[name] !== undefined ? BLOCKS[ID[name]] : undefined;
        const flatInHand = bDef && (bDef.shape === 'cross' || bDef.shape === 'torch' || bDef.shape === 'door' || bDef.shape === 'lily' || bDef.shape === 'pane' || bDef.shape === 'end_rod' || (bDef.shape === 'lantern' && bDef.name !== 'bell') || bDef.shape === 'brewing_stand');
        const isBlock = !!faces && !!bDef && !flatInHand && !isBannerShield;
        if (isBannerShield) {
          const base = held.bannerBase ?? bannerColorOf(name);
          const cv = bannerShieldCanvas(base, held.patterns as BannerLayer[] | undefined, name === 'shield');
          const tex = this.getCanvasTex(`bshield:${handKey}`, cv);
          for (const mat of this.handFaceMaterials) {
            mat.map = tex;
            mat.color.set('#ffffff');
            mat.transparent = false;
            mat.alphaTest = 0;
            mat.needsUpdate = true;
          }
          this.hand.scale.set(0.68, 1.18, 0.16);
          if (!this.thirdPersonShield && this.playerArms[0]) {
            this.thirdPersonShield = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.58, 0.06), this.handFaceMaterials[0]);
            this.thirdPersonShield.position.set(-0.18, -0.36, -0.18);
            this.playerArms[0].add(this.thirdPersonShield);
          }
          if (this.thirdPersonShield) {
            this.thirdPersonShield.material = this.handFaceMaterials[0];
            this.thirdPersonShield.visible = true;
          }
        } else if (isBlock && faces && bDef) {
          if (this.thirdPersonShield) this.thirdPersonShield.visible = false;
          for (let i = 0; i < 6; i++) {
            const mat = this.handFaceMaterials[i];
            mat.map = this.getCanvasTex(`${name}:f${i}`, faces[i]);
            mat.color.set('#ffffff');
            mat.transparent = !!bDef.transparent;
            mat.alphaTest = bDef.transparent ? 0.25 : 0;
            mat.needsUpdate = true;
          }
          const isSlab = BLOCKS[ID[name]]?.shape === 'slab' || BLOCKS[ID[name]]?.shape === 'bed';
          this.hand.scale.set(1, isSlab ? 0.55 : 1, 1);
        } else {
          if (this.thirdPersonShield) this.thirdPersonShield.visible = false;
          const tex = this.getCanvasTex(`${name}:item`, handTileCanvas(name));
          for (const mat of this.handFaceMaterials) {
            mat.map = tex;
            mat.color.set('#ffffff');
            mat.transparent = true;
            mat.alphaTest = 0.3;
            mat.needsUpdate = true;
          }
          this.hand.scale.set(0.95, 0.95, 0.14);
        }
      } else {
        if (this.thirdPersonShield) this.thirdPersonShield.visible = false;
        for (const mat of this.handFaceMaterials) {
          mat.map = null;
          mat.color.set('#c99c7b');
          mat.transparent = false;
          mat.alphaTest = 0;
          mat.needsUpdate = true;
        }
        this.hand.scale.set(0.5, 0.5, 1.3);
      }
    }

    this.handDip = Math.max(0, this.handDip - dt * 1.4);
    const walkBob = this.grounded ? Math.sin(this.elapsed * 10) * Math.min(0.025, Math.hypot(this.input.move.x, this.input.move.z) * 0.025) : 0;
    const swing = this.input.mining ? Math.sin(this.elapsed * 16) * 0.18 : 0;
    const eating = SV.isEating(this);
    const eatBob = eating ? Math.abs(Math.sin(this.elapsed * 28)) * 0.11 : 0;
    this.hand.position.x = eating ? 0.22 : this.blocking ? 0.26 : 0.42;
    this.hand.position.y = -0.34 + swing + walkBob + eatBob - this.handDip * 0.5;
    this.hand.rotation.x = 0.2 + swing * 1.5 - this.handDip * 1.1 + (eating ? 0.35 + Math.sin(this.elapsed * 28) * 0.18 : 0);
    this.hand.rotation.z = -swing * 0.65 + (eating ? 0.32 : 0);
    this.hand.visible = !this.thirdPerson;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.resizeObserver.disconnect();
    this.listeners.forEach(f => f());
    this.input.dispose();
    this.workers.forEach(s => s.worker.terminate());
    this.clearChunks();
    this.environment.dispose();
    this.outline.geometry.dispose();
    (this.outline.material as THREE.Material).dispose();
    this.crack.geometry.dispose();
    this.crackMaterials.forEach(m => { m.map?.dispose(); m.dispose(); });
    this.hand.geometry.dispose();
    this.handMaterial.dispose();
    this.handTextures.forEach(t => t.dispose());
    this.handFaceMaterials.forEach(m => m.dispose());
    this.particles.dispose();
    this.mobs.dispose();
    this.renderer.dispose();
  }

  seedNatural(x: number, y: number, z: number) { SV.seedNatural(this, x, y, z); }
  useItemFrame(x: number, y: number, z: number): boolean { return SV.useItemFrame(this, x, y, z); }


  private panoramaAt = -Infinity;
  private panoramaEyeY = 100;
  private panoramaLookY = 70;
  private panoramaCamera() {
    const a = 0.56 + Math.sin(this.elapsed * 0.017) * 0.13;
    const x = Math.sin(a) * 72 - 7, z = Math.cos(a) * 72 - 18;
    if (this.elapsed - this.panoramaAt > 2) {
      this.panoramaAt = this.elapsed;
      this.panoramaLookY = Math.max(64, this.terrain.height(-8, -24)) + 2;
      this.panoramaEyeY = Math.max(this.panoramaLookY + 26, this.terrain.height(x, z) + 20);
    }
    this.camera.position.set(x, this.panoramaEyeY, z);
    this.camera.lookAt(-8, this.panoramaLookY, -24);
  }


  previewPaused = false;
  private surfaceBiome = 'plains';
  private fxAcc = 0;

  /** Green glints around the villager the player just traded with (Java: entity event 14, `happy_villager`). */
  private villagerHappy() {
    let best: (typeof this.mobs.mobs)[number] | null = null, bd = 64;
    for (const m of this.mobs.mobs) {
      if (m.species !== 'villager' && (m.species as string) !== 'wandering_trader') continue;
      const d = m.group.position.distanceToSquared(this.position);
      if (d < bd) { bd = d; best = m; }
    }
    if (best) this.particles.happyVillagerAround(entityFxBox(best.group, best.head));
  }

  private tickFx(dt: number) {
    const cam = this.camera.position;
    const light = this.dimension === 'overworld' ? 0.3 + 0.7 * this.environment.daylight * (this.weather === 'clear' ? 1 : 0.75) : this.dimension === 'nether' ? 0.6 : 0.7;
    this.particles.setView(this.camera, this.renderer.domElement.height, light);
    if (!this.ready) return;
    this.fxAcc = Math.min(this.fxAcc + dt, FX_TICK * 3);
    while (this.fxAcc >= FX_TICK) {
      this.fxAcc -= FX_TICK;
      animateWorldTick(this.particles.fx, this, cam.x, cam.y, cam.z, {
        rain: this.dimension === 'overworld' && this.weather !== 'clear' && this.environment.precipitation === 'rain' ? 1 : 0,
        sound: (kind, x, y, z) => { if (kind === 'lava_pop' && Math.abs(x - cam.x) + Math.abs(z - cam.z) < 14) this.audio?.play('water', { x, y, z }); },
      });
      for (const m of this.mobs.mobs) {
        const enderman = m.species === 'enderman', fx = m.fx;
        if (!enderman && !fx) continue;
        const mp = m.group.position, dx = mp.x - cam.x, dz = mp.z - cam.z;
        if (dx * dx + dz * dz > 1024) continue;
        const box = entityFxBox(m.group, m.head);
        if (enderman) this.particles.endermanPortal(box);
        if (fx) {
          const cols = this.effectColors(Object.keys(fx));
          if (cols.length) this.particles.mobSpell(box, cols, { time: this.elapsed + m.id * 0.37 });
        }
      }
      if (this.active && !this.dead) {
        const own = this.effectColors(Object.keys(this.effects).filter(id => this.effects[id].t > 0));
        if (own.length) this.particles.mobSpell({ x: this.position.x, y: this.position.y, z: this.position.z, w: 0.6, h: 1.8 }, own, { time: this.elapsed, invisible: SV.has(this, 'invisibility') });
      }
    }
  }

  private effectColorCache = new Map<string, RGB>();
  private effectColors(ids: string[]): RGB[] {
    const out: RGB[] = [];
    for (const id of ids) {
      let c = this.effectColorCache.get(id);
      if (!c) { const def = EFFECTS[id]; if (!def) continue; c = hexToRgb(def.color); this.effectColorCache.set(id, c); }
      out.push(c);
    }
    return out;
  }

}
