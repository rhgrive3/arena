import type { BlockDef } from './data';

// A cell keeps its block ID in the low 12 bits and its state in the high 4.
// Old saves contain plain IDs and therefore naturally decode to state zero.
export const BLOCK_ID_MASK = 0x0fff;
export const STATE_SHIFT = 12;
export type Facing = 0 | 1 | 2 | 3;
export type Face = 0 | 1 | 2 | 3 | 4 | 5;
export const FACING_FACES: readonly Face[] = [4, 1, 5, 0];

export function blockId(cell: number): number {
  return cell < 0 ? cell : cell & BLOCK_ID_MASK;
}

export function blockState(cell: number): number {
  return cell < 0 ? 0 : (cell >>> STATE_SHIFT) & 15;
}

export function makeCell(id: number, state = 0): number {
  if (!Number.isInteger(id) || id < 0 || id > BLOCK_ID_MASK || !Number.isInteger(state) || state < 0 || state > 15) {
    throw new RangeError('Invalid block ID or block state');
  }
  return id === 0 ? 0 : id | (state << STATE_SHIFT);
}

// The camera looks along -Z at yaw 0; the opening faces the player.
export function facingForYaw(yaw: number): Facing {
  return ((Math.round(-yaw / (Math.PI / 2)) % 4 + 4) % 4) as Facing;
}

export function isHorizontalFacing(name: string): boolean {
  const block = name.replace(/^open_/, '');
  return block === 'chest' || block === 'barrel' || block === 'furnace' || block === 'blast_furnace' || block === 'smoker' ||
    block === 'piston' || block === 'sticky_piston' || block === 'observer' || block === 'dropper' || block === 'dispenser' ||
    block === 'end_portal_frame' || block === 'dragon_head' || block === 'ender_chest' || block === 'chiseled_bookshelf';
}

/**
 * Redstone components whose state is a direction in the redstone engine's order: 0 +X, 1 +Z, 2 -X, 3 -Z, 4 up, 5 down.
 * (They used to be drawn with the chest/furnace rotation, a quarter turn away from the direction they actually act in.)
 */
export function isDirectional(name: string): boolean {
  return name === 'piston' || name === 'sticky_piston' || name === 'observer' || name === 'dropper' || name === 'dispenser' || name === 'crafter' || name === 'hopper';
}

export function isAxisBlock(name: string): boolean {
  return name.endsWith('_log') || name === 'purpur_pillar' || name === 'quartz_pillar' || name === 'bone_block' || name === 'basalt' || name === 'hay_block';
}

export function isSlabBlock(def: BlockDef): boolean {
  return def.shape === 'slab' && def.name.endsWith('_slab');
}

export function isAttachable(def: BlockDef): boolean {
  return def.shape === 'torch' && def.name !== 'lantern' && def.name !== 'brewing_stand' && def.name !== 'end_rod';
}

export function isUpperPlacement(normal: { y:number }, hitY: number): boolean {
  return normal.y < 0 || (normal.y === 0 && hitY > .5);
}

export function stateForPlacement(def: BlockDef, yaw: number, normal: { x: number; y: number; z: number }, hitY = 0, pitch = 0): number {
  if (isDirectional(def.name)) {
    // Hoppers point into the block they were placed against (down when placed on top of something).
    if (def.name === 'hopper') return normal.y !== 0 ? 5 : normal.x > 0 ? 2 : normal.x < 0 ? 0 : normal.z > 0 ? 3 : 1;
    const f = facingForYaw(yaw);
    // Observers look where the player looks; pistons, dispensers, droppers and crafters face the player. Steep angles give up/down.
    if (def.name === 'observer') return pitch < -0.87 ? 5 : pitch > 0.87 ? 4 : (f + 3) % 4;
    return pitch < -0.87 ? 4 : pitch > 0.87 ? 5 : (f + 1) % 4;
  }
  if (isHorizontalFacing(def.name)) return facingForYaw(yaw);
  if (isAxisBlock(def.name)) return normal.x !== 0 ? 1 : normal.z !== 0 ? 2 : 0;
  if (isSlabBlock(def)) return isUpperPlacement(normal,hitY) ? 1 : 0;
  if (def.shape === 'stairs') return facingForYaw(yaw) | (isUpperPlacement(normal,hitY) ? 4 : 0);
  // Doors stand on the edge of the cell nearest to the player, trapdoors hinge on the far edge (see shapes.ts for the bit layout).
  if (def.shape === 'door') return [2, 1, 0, 3][facingForYaw(yaw)];
  if (def.shape === 'trapdoor') return [0, 3, 2, 1][facingForYaw(yaw)] | (isUpperPlacement(normal, hitY) ? 4 : 0);
  // Beds: bits 0-1 = direction from the foot to the head (+X, +Z, -X, -Z), bit 2 = head half. The head goes away from the player.
  if (def.name === 'bed') return [3, 0, 1, 2][facingForYaw(yaw)];
  // Ladders lie flat against the wall that was clicked (state = edge of the cell, as for doors).
  if (def.name === 'ladder') return normal.y !== 0 ? -1 : normal.x > 0 ? 1 : normal.x < 0 ? 3 : normal.z > 0 ? 0 : 2;
  // Torches, levers and buttons attach to the face that was clicked; -1 means "cannot be placed there" (torches never hang from ceilings).
  if (def.name === 'tripwire_hook' && normal.y !== 0) return -1;      // hooks only hang on walls
  if (isAttachable(def)) {
    if (normal.y > 0) return 0;
    if (normal.y < 0) return def.name === 'lever' || def.name.endsWith('_button') ? 5 : -1;
    return normal.x > 0 ? 1 : normal.x < 0 ? 2 : normal.z > 0 ? 3 : 4;
  }
  if (def.shape === 'pane' && (def.name.endsWith('glass_pane') || def.name === 'iron_bars')) return (facingForYaw(yaw) & 1) ^ 1;
  return 0;
}

// faceTile describes an unrotated block whose front is on +Z.
export function localFaceForState(def: BlockDef, state: number, worldFace: Face): Face {
  if (isAxisBlock(def.name)) {
    const axis = state & 3;
    if (axis === 1) return worldFace < 2 ? 2 : 0;
    if (axis === 2) return worldFace >= 4 ? 2 : 0;
    return worldFace;
  }
  if (isDirectional(def.name) && def.name !== 'hopper') {
    const front = ([0, 4, 1, 5, 2, 3] as Face[])[state & 7] ?? 4;
    if (worldFace === front) return 4;
    if (worldFace === (front ^ 1)) return 5;
    if (front === 2 || front === 3) return 0;
    return worldFace === 2 || worldFace === 3 ? worldFace : 0;
  }
  if (!isHorizontalFacing(def.name) || worldFace === 2 || worldFace === 3) return worldFace;
  const worldIndex = FACING_FACES.indexOf(worldFace);
  return FACING_FACES[(worldIndex - (state & 3) + 4) % 4];
}
