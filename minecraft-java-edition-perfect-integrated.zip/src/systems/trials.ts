// Trial spawners & vaults (1.21). Pure game logic: no three.js, no DOM — the engine supplies a small host (see game/world121.ts)
// and the headless tests supply a stub. Nothing here scans the world: only blocks that were registered (chunk scan / placement)
// are ticked, at 4 Hz, so the cost is O(registered spawners) and independent of render distance.
import type { SpawnerKind } from '../world/dungeons';
import type { GameEvents, SpawnerPhase, VaultPhase } from '../game/events';

export const TRIAL_COOLDOWN_SEC = 30 * 60;
export const PLAYER_RANGE = 14;
export const SPAWN_RANGE = 4;
export const SPAWN_INTERVAL = 2;
export const EJECT_INTERVAL = 1.5;
export const VAULT_RANGE = 4.5;
export const TICK = 0.25;

export interface SpawnerConfig { species: string[]; total: number; totalPer: number; simultaneous: number; simultaneousPer: number }
/** Vanilla numbers: base amount + an increment for every additional player that has been detected. */
export const SPAWNER_CONFIG: Record<SpawnerKind, SpawnerConfig> = {
  melee: { species: ['zombie', 'husk', 'spider'], total: 6, totalPer: 2, simultaneous: 3, simultaneousPer: 0.5 },
  small_melee: { species: ['slime', 'cave_spider', 'silverfish'], total: 6, totalPer: 2, simultaneous: 3, simultaneousPer: 0.5 },
  ranged: { species: ['skeleton', 'stray', 'bogged'], total: 6, totalPer: 2, simultaneous: 3, simultaneousPer: 0.5 },
  breeze: { species: ['breeze'], total: 2, totalPer: 1, simultaneous: 1, simultaneousPer: 0.5 },
};
export const OMINOUS_CONFIG: Partial<Record<SpawnerKind, Partial<SpawnerConfig>>> = { breeze: { total: 4, simultaneous: 2 } };
const KINDS: SpawnerKind[] = ['melee', 'ranged', 'small_melee', 'breeze'];

/** Difficulty scaling: how many mobs the trial needs in total and how many may be alive at once for `players` participants. */
export function scaling(kind: SpawnerKind, players: number, ominous = false) {
  const c = { ...SPAWNER_CONFIG[kind], ...(ominous ? OMINOUS_CONFIG[kind] : undefined) }, extra = Math.max(0, players - 1);
  return { total: Math.floor(c.total + c.totalPer * extra), simultaneous: Math.max(1, Math.floor(c.simultaneous + c.simultaneousPer * extra)) };
}
const mix = (x: number, y: number, z: number, seed: number) => {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 1103515245) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return (h ^ (h >>> 16)) >>> 0;
};
/** What a spawner at this position summons (stable for a given world seed, so it never has to be stored at generation time). */
export function spawnerProfile(x: number, y: number, z: number, seed: number, kind?: SpawnerKind) {
  const h = mix(x, y, z, seed), k = kind ?? KINDS[h % KINDS.length], list = SPAWNER_CONFIG[k].species;
  return { kind: k, species: list[(h >>> 8) % list.length] };
}

export interface Reward { item: string; count: number; ench?: Record<string, number> }
type LootEntry = [string, number, number, number];
const SPAWNER_CONSUMABLES: LootEntry[] = [['cooked_chicken', 1, 1, 3], ['bread', 1, 3, 3], ['baked_potato', 1, 3, 2], ['potion_regeneration', 1, 1, 1], ['potion_swiftness', 1, 1, 1], ['emerald', 1, 2, 2]];
const OMINOUS_CONSUMABLES: LootEntry[] = [['cooked_beef', 1, 1, 3], ['baked_potato', 1, 3, 3], ['golden_carrot', 1, 2, 2], ['potion_regeneration', 1, 1, 1], ['potion_strength', 1, 1, 1], ['emerald', 2, 4, 2], ['wind_charge', 4, 8, 2]];
export const VAULT_LOOT: LootEntry[] = [['emerald', 2, 4, 10], ['arrow', 2, 8, 10], ['iron_ingot', 1, 4, 8], ['wind_charge', 1, 3, 8], ['honey_bottle', 1, 2, 6], ['ominous_bottle', 1, 2, 4], ['shield', 1, 1, 3], ['bow', 1, 1, 3], ['diamond', 1, 2, 2], ['golden_carrot', 1, 2, 4], ['enchanted_book', 1, 1, 3], ['crossbow', 1, 1, 3], ['iron_axe', 1, 1, 2], ['iron_chestplate', 1, 1, 2], ['golden_apple', 1, 1, 2], ['diamond_axe', 1, 1, 1], ['diamond_chestplate', 1, 1, 1], ['trident', 1, 1, 1]];
export const OMINOUS_VAULT_LOOT: LootEntry[] = [['emerald', 4, 10, 10], ['wind_charge', 8, 12, 8], ['diamond', 2, 3, 6], ['ominous_bottle', 1, 1, 5], ['emerald_block', 1, 1, 4], ['iron_block', 1, 1, 4], ['crossbow', 1, 1, 3], ['golden_apple', 1, 1, 4], ['diamond_axe', 1, 1, 3], ['diamond_chestplate', 1, 1, 3], ['enchanted_book', 1, 1, 5], ['enchanted_golden_apple', 1, 1, 2], ['heavy_core', 1, 1, 2]];
const BOOKS: [string, number][] = [['sharpness', 3], ['protection', 3], ['unbreaking', 3], ['efficiency', 3], ['power', 3], ['knockback', 2]];
const MACE_BOOKS: [string, number][] = [['density', 3], ['breach', 3], ['wind_burst', 1]];

function roll(table: LootEntry[], rng: () => number, ominous: boolean): Reward {
  let total = 0;
  for (const e of table) total += e[3];
  let r = rng() * total, pick = table[table.length - 1];
  for (const e of table) { r -= e[3]; if (r < 0) { pick = e; break; } }
  const reward: Reward = { item: pick[0], count: pick[1] + Math.floor(rng() * (pick[2] - pick[1] + 1)) };
  if (pick[0] === 'enchanted_book') {
    const list = ominous ? MACE_BOOKS : BOOKS, [id, max] = list[Math.floor(rng() * list.length)];
    reward.ench = { [id]: 1 + Math.floor(rng() * max) };
  }
  return reward;
}
/** One reward per participating player: a key half of the time (30 % ominous key), otherwise supplies. */
export function rollSpawnerReward(ominous: boolean, rng: () => number): Reward {
  if (ominous) return rng() < 0.3 ? { item: 'ominous_trial_key', count: 1 } : roll(OMINOUS_CONSUMABLES, rng, true);
  return rng() < 0.5 ? { item: 'trial_key', count: 1 } : roll(SPAWNER_CONSUMABLES, rng, false);
}
export function rollVault(ominous: boolean, rng: () => number): Reward[] {
  const out: Reward[] = [], n = (ominous ? 3 : 2) + Math.floor(rng() * 2);
  for (let i = 0; i < n; i++) {
    const r = roll(ominous ? OMINOUS_VAULT_LOOT : VAULT_LOOT, rng, ominous);
    if (r.item === 'heavy_core' && out.some(o => o.item === 'heavy_core')) { i--; continue; }
    out.push(r);
  }
  return out;
}

export interface TrialSpawner {
  x: number; y: number; z: number;
  kind: SpawnerKind; species: string;
  phase: SpawnerPhase; ominous: boolean;
  /** UUIDs of every player detected during the current trial — drives the scaling and gets one reward each. */
  players: string[];
  spawned: number; killed: number; alive: number[];
  nextSpawn: number; cooldownUntil: number;
  queue: Reward[]; nextEject: number;
}
export interface Vault {
  x: number; y: number; z: number; ominous: boolean; phase: VaultPhase;
  /** UUIDs that have already looted this vault — each player can unlock a vault exactly once. */
  rewarded: string[];
  queue: Reward[]; nextEject: number;
}
export interface TrialPlayer { id: string; /** level of Bad Omen / Trial Omen, 0 when the player has neither */ omen: number }
export interface TrialHost {
  /** Persistent world clock in seconds (survives save / load, so cooldowns do too). */
  now(): number;
  rng(): number;
  /** null = the chunk is not loaded (state is left untouched). */
  blockAt(x: number, y: number, z: number): 'spawner' | 'vault' | 'ominous_vault' | 'other' | null;
  setPhase(x: number, y: number, z: number, state: number): void;
  playersNear(x: number, y: number, z: number, r: number): TrialPlayer[];
  spawn(species: string, x: number, y: number, z: number, ominous: boolean, key: string): number | null;
  alive(id: number): boolean;
  remove(id: number): void;
  eject(x: number, y: number, z: number, reward: Reward, from: 'spawner' | 'vault', ominous: boolean): void;
  /** Bad Omen was consumed to turn a spawner ominous (the engine converts it into Trial Omen). */
  omenUsed?(player: string): void;
  emit?<K extends keyof GameEvents>(type: K, payload: GameEvents[K]): void;
}
export interface TrialSave { spawners: TrialSpawner[]; vaults: Vault[] }
export type UnlockResult = { ok: true; consume: string } | { ok: false; reason: 'already' | 'wrong_key' | 'no_key' | 'busy' | 'missing' };

const PHASE_STATE: Record<SpawnerPhase, number> = { inactive: 0, waiting: 1, active: 2, ejecting: 3, cooldown: 4 };
const VAULT_STATE: Record<VaultPhase, number> = { inactive: 0, active: 1, unlocking: 2, ejecting: 3 };
export const spawnerCellState = (phase: SpawnerPhase, ominous: boolean) => PHASE_STATE[phase] + (ominous ? 8 : 0);
const keyOf = (x: number, y: number, z: number) => `${x},${y},${z}`;

export class TrialSystem {
  spawners = new Map<string, TrialSpawner>();
  vaults = new Map<string, Vault>();
  private owners = new Map<number, string>();
  private acc = 0;

  constructor(public host: TrialHost) {}

  registerSpawner(x: number, y: number, z: number, kind: SpawnerKind, species: string): TrialSpawner {
    const key = keyOf(x, y, z), cur = this.spawners.get(key);
    if (cur) return cur;
    const s: TrialSpawner = { x, y, z, kind, species, phase: 'inactive', ominous: false, players: [], spawned: 0, killed: 0, alive: [], nextSpawn: 0, cooldownUntil: 0, queue: [], nextEject: 0 };
    this.spawners.set(key, s);
    return s;
  }
  registerVault(x: number, y: number, z: number, ominous: boolean): Vault {
    const key = keyOf(x, y, z), cur = this.vaults.get(key);
    if (cur) return cur;
    const v: Vault = { x, y, z, ominous, phase: 'inactive', rewarded: [], queue: [], nextEject: 0 };
    this.vaults.set(key, v);
    return v;
  }
  /** The block was broken / replaced. */
  remove(x: number, y: number, z: number) {
    const key = keyOf(x, y, z), s = this.spawners.get(key);
    if (s) for (const id of s.alive) this.owners.delete(id);
    this.spawners.delete(key);
    this.vaults.delete(key);
  }
  spawnerAt(x: number, y: number, z: number) { return this.spawners.get(keyOf(x, y, z)); }
  vaultAt(x: number, y: number, z: number) { return this.vaults.get(keyOf(x, y, z)); }

  /** Called by the mob manager whenever a mob dies; only mobs summoned by a spawner count towards its trial. */
  onMobDeath(id: number) {
    const key = this.owners.get(id);
    if (key === undefined) return;
    this.owners.delete(id);
    const s = this.spawners.get(key);
    if (!s) return;
    const i = s.alive.indexOf(id);
    if (i >= 0) { s.alive.splice(i, 1); s.killed++; }
  }

  update(dt: number) {
    this.acc += dt;
    if (this.acc < TICK) return;
    this.acc = 0;
    for (const s of this.spawners.values()) this.tickSpawner(s);
    for (const v of this.vaults.values()) this.tickVault(v);
  }

  private setPhase(s: TrialSpawner, phase: SpawnerPhase) {
    s.phase = phase;
    this.host.setPhase(s.x, s.y, s.z, spawnerCellState(phase, s.ominous));
    this.host.emit?.('trial_spawner_state', { x: s.x, y: s.y, z: s.z, phase, ominous: s.ominous, players: s.players.length });
  }
  private resetTrial(s: TrialSpawner, now: number) {
    for (const id of s.alive) { this.owners.delete(id); this.host.remove(id); }
    s.alive = []; s.spawned = 0; s.killed = 0; s.nextSpawn = now + SPAWN_INTERVAL;
  }

  private tickSpawner(s: TrialSpawner) {
    const here = this.host.blockAt(s.x, s.y, s.z), now = this.host.now();
    if (here === null) return;
    if (here !== 'spawner') { this.remove(s.x, s.y, s.z); return; }
    if (s.phase === 'cooldown') {
      if (now >= s.cooldownUntil) { s.ominous = false; s.players = []; this.setPhase(s, 'inactive'); }
      return;
    }
    if (s.phase === 'ejecting') {
      if (now < s.nextEject) return;
      const reward = s.queue.shift();
      if (reward) {
        this.host.eject(s.x, s.y, s.z, reward, 'spawner', s.ominous);
        this.host.emit?.('trial_spawner_eject', { x: s.x, y: s.y, z: s.z, item: reward.item, count: reward.count, ominous: s.ominous });
        s.nextEject = now + EJECT_INTERVAL;
      }
      if (!s.queue.length) { s.cooldownUntil = now + TRIAL_COOLDOWN_SEC; this.setPhase(s, 'cooldown'); }
      return;
    }
    const near = this.host.playersNear(s.x + 0.5, s.y + 0.5, s.z + 0.5, PLAYER_RANGE);
    if (s.phase !== 'active') {
      if (!near.length) { if (s.phase !== 'waiting') this.setPhase(s, 'waiting'); return; }
      s.players = []; s.alive = []; s.spawned = 0; s.killed = 0; s.nextSpawn = now + SPAWN_INTERVAL;
      for (const p of near) s.players.push(p.id);
      this.setPhase(s, 'active');
    }
    let grew = false;
    for (const p of near) if (!s.players.includes(p.id)) { s.players.push(p.id); grew = true; }
    const omen = near.find(p => p.omen > 0);
    if (omen && !s.ominous) {                                           // Bad Omen → the running trial restarts as an ominous one
      s.ominous = true;
      this.resetTrial(s, now);
      this.host.omenUsed?.(omen.id);
      this.setPhase(s, 'active');
    } else if (grew) this.host.emit?.('trial_spawner_state', { x: s.x, y: s.y, z: s.z, phase: s.phase, ominous: s.ominous, players: s.players.length });
    // Mobs that vanished without dying (despawn, unload) are summoned again.
    s.alive = s.alive.filter(id => {
      if (this.host.alive(id)) return true;
      this.owners.delete(id);
      s.spawned = Math.max(0, s.spawned - 1);
      return false;
    });
    const { total, simultaneous } = scaling(s.kind, s.players.length, s.ominous);
    if (s.killed >= total) {
      s.queue = s.players.map(() => rollSpawnerReward(s.ominous, () => this.host.rng()));
      s.nextEject = now + EJECT_INTERVAL;
      this.setPhase(s, 'ejecting');
      return;
    }
    if (s.spawned < total && s.alive.length < simultaneous && now >= s.nextSpawn) {
      const key = keyOf(s.x, s.y, s.z);
      for (let attempt = 0; attempt < 6; attempt++) {
        const a = this.host.rng() * Math.PI * 2, d = 1.5 + this.host.rng() * (SPAWN_RANGE - 1.5);
        const id = this.host.spawn(s.species, s.x + 0.5 + Math.cos(a) * d, s.y, s.z + 0.5 + Math.sin(a) * d, s.ominous, key);
        if (id === null) continue;
        s.alive.push(id); s.spawned++; s.nextSpawn = now + SPAWN_INTERVAL;
        this.owners.set(id, key);
        this.host.emit?.('trial_spawner_spawn', { x: s.x, y: s.y, z: s.z, species: s.species, mobId: id, ominous: s.ominous });
        break;
      }
    }
  }

  private setVault(v: Vault, phase: VaultPhase) {
    if (v.phase === phase) return;
    v.phase = phase;
    this.host.setPhase(v.x, v.y, v.z, VAULT_STATE[phase]);
    this.host.emit?.('vault_state', { x: v.x, y: v.y, z: v.z, phase, ominous: v.ominous });
  }
  private tickVault(v: Vault) {
    const here = this.host.blockAt(v.x, v.y, v.z), now = this.host.now();
    if (here === null) return;
    if (here !== (v.ominous ? 'ominous_vault' : 'vault')) { this.remove(v.x, v.y, v.z); return; }
    if (v.phase === 'unlocking' || v.phase === 'ejecting') {
      if (now < v.nextEject) return;
      const reward = v.queue.shift();
      if (reward) {
        this.setVault(v, 'ejecting');
        this.host.eject(v.x, v.y, v.z, reward, 'vault', v.ominous);
        this.host.emit?.('vault_eject', { x: v.x, y: v.y, z: v.z, item: reward.item, count: reward.count, ominous: v.ominous });
        v.nextEject = now + 1;
        return;
      }
    }
    const fresh = this.host.playersNear(v.x + 0.5, v.y + 0.5, v.z + 0.5, VAULT_RANGE).some(p => !v.rewarded.includes(p.id));
    this.setVault(v, fresh ? 'active' : 'inactive');
  }

  /** A player uses `held` on the vault. On success the caller must consume one `consume` item from the player's hand. */
  tryUnlock(x: number, y: number, z: number, player: string, held: string | undefined): UnlockResult {
    const v = this.vaults.get(keyOf(x, y, z));
    if (!v) return { ok: false, reason: 'missing' };
    const deny = (reason: 'already' | 'wrong_key' | 'no_key' | 'busy'): UnlockResult => {
      this.host.emit?.('vault_denied', { x, y, z, reason, player });
      return { ok: false, reason };
    };
    if (v.rewarded.includes(player)) return deny('already');
    if (v.phase === 'unlocking' || v.phase === 'ejecting') return deny('busy');
    const need = v.ominous ? 'ominous_trial_key' : 'trial_key';
    if (held !== need) return deny(held === 'trial_key' || held === 'ominous_trial_key' ? 'wrong_key' : 'no_key');
    v.rewarded.push(player);
    v.queue = rollVault(v.ominous, () => this.host.rng());
    v.nextEject = this.host.now() + 1;
    this.setVault(v, 'unlocking');
    return { ok: true, consume: need };
  }

  save(): TrialSave {
    return { spawners: [...this.spawners.values()].map(s => ({ ...s, players: [...s.players], alive: [...s.alive], queue: [...s.queue] })), vaults: [...this.vaults.values()].map(v => ({ ...v, rewarded: [...v.rewarded], queue: [...v.queue] })) };
  }
  load(data?: TrialSave | null) {
    this.spawners.clear(); this.vaults.clear(); this.owners.clear();
    for (const s of data?.spawners ?? []) {
      const key = keyOf(s.x, s.y, s.z);
      this.spawners.set(key, { ...s, players: [...(s.players ?? [])], alive: [...(s.alive ?? [])], queue: [...(s.queue ?? [])] });
      for (const id of s.alive ?? []) this.owners.set(id, key);
    }
    for (const v of data?.vaults ?? []) this.vaults.set(keyOf(v.x, v.y, v.z), { ...v, rewarded: [...(v.rewarded ?? [])], queue: [...(v.queue ?? [])] });
  }
}
