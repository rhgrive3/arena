// Dynamic fluid simulation following Minecraft Java Edition's FlowingFluid / LavaFluid rules.
//
// Cell state (4 bits): bits 0-2 = distance from the source (0 = source block, water 1..7, overworld lava 2/4/6), bit 3 = falling.
// A flowing cell's "amount" is 8 - distance (falling fluid counts as 8).
//   * Water: tick delay 5 ticks, drop-off 1 (reaches 7 blocks), slope search distance 4, two adjacent sources over a floor create a new source.
//   * Lava : tick delay 30 ticks (10 in the Nether), drop-off 2 (3 blocks, 7 in the Nether), slope search 2 (4 in the Nether), no infinite lava.
//   * Fluids fall straight down first and only spread sideways when they cannot fall (or are a source), preferring the direction of the
//     nearest hole within the slope search distance.
//   * Lava touching water (above or beside it) becomes obsidian (source) or cobblestone (flowing); lava flowing down into water makes stone;
//     lava above soul soil next to blue ice makes basalt.
import { BLOCKS, ID } from '../game/data';

export interface FluidHost {
  getCell(x: number, y: number, z: number): number;
  setBlock(x: number, y: number, z: number, id: number, state?: number): boolean;
  dimension?(): string;
  sound?(kind: string, p?: { x: number; y: number; z: number }): void;
}

const DIRS: readonly [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const NEIGHBORS: readonly [number, number, number][] = [[0, 0, 0], [1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

export function isFluid(id: number): boolean { return id === ID.water || id === ID.lava; }

/** Blocks a fluid simply washes away when it flows into them (plants, torches, snow layers, wire ...). */
export function isReplaceable(id: number): boolean {
  if (id === 0) return true;
  const d = BLOCKS[id];
  if (!d || d.solid) return false;
  return d.shape === 'cross' || d.name === 'snow_layer' || d.name === 'torch' || d.name === 'redstone_wire' || d.name === 'fire' || d.name === 'lily_pad';
}

export class Fluids {
  private due = new Map<number, { x: number; y: number; z: number; t: number }>();
  private time = 0;
  private reacting = 0;
  /** Number of fluid cells changed since creation (diagnostics / tests). */
  changes = 0;

  constructor(private host: FluidHost) {}

  private nether() { return this.host.dimension?.() === 'nether'; }
  /** Unique integer key (< 2^52 for |x|,|z| < 1,048,576 so doubles stay exact). */
  private key(x: number, y: number, z: number) { return ((x + 1048576) * 2097152 + (z + 1048576)) * 512 + (y + 64); }
  private delay(id: number) { return id === ID.water ? 0.25 : this.nether() ? 0.5 : 1.5; }
  private drop(id: number) { return id === ID.water ? 1 : this.nether() ? 1 : 2; }
  private slope(id: number) { return id === ID.water ? 4 : this.nether() ? 4 : 2; }

  get pending() { return this.due.size; }
  clear() { this.due.clear(); }

  schedule(x: number, y: number, z: number, delay?: number) {
    const k = this.key(x, y, z);
    if (this.due.has(k) || this.due.size > 40000) return;
    const cell = this.host.getCell(x, y, z);
    if (cell < 0) return;
    const id = cell & 4095;
    if (!isFluid(id)) return;
    this.due.set(k, { x, y, z, t: this.time + (delay ?? this.delay(id)) });
  }

  /** Call after any block change: fluids in / next to the changed cell wake up and lava reacts with water immediately. */
  onBlockChanged(x: number, y: number, z: number) {
    for (const [dx, dy, dz] of NEIGHBORS) {
      const nx = x + dx, ny = y + dy, nz = z + dz, cell = this.host.getCell(nx, ny, nz);
      if (cell < 0) continue;
      const id = cell & 4095;
      if (!isFluid(id)) continue;
      if (id === ID.lava && this.reacting < 8) { this.reacting++; try { if (this.lavaReact(nx, ny, nz, cell)) continue; } finally { this.reacting--; } }
      this.schedule(nx, ny, nz);
    }
  }

  update(dt: number, budgetMs = 3, maxCells = 200) {
    this.time += dt;
    if (!this.due.size) return;
    const start = performance.now();
    let n = 0;
    for (const [k, e] of this.due) {
      if (e.t > this.time) continue;
      this.due.delete(k);
      this.tick(e.x, e.y, e.z);
      if (++n >= maxCells || performance.now() - start > budgetMs) break;
    }
  }

  // ---------------------------------------------------------------------------------------------------------- core
  /** Vanilla canPassThrough: air / replaceable blocks and *flowing* cells of the same fluid, but never a source of it. */
  private passable(cell: number, id: number) {
    if (cell < 0) return false;
    const cid = cell & 4095;
    return isReplaceable(cid) || (cid === id && ((cell >>> 12) & 15) !== 0);
  }

  /** Replace-or-react placement of `id` at a target cell that is air / replaceable. */
  private place(x: number, y: number, z: number, id: number, state: number) {
    this.changes++;
    this.host.setBlock(x, y, z, id, state);
  }

  /** Vanilla getNewLiquid: the state this flowing cell should have given its surroundings, or -1 when it should dry up. */
  computeNew(id: number, x: number, y: number, z: number): number {
    let best = 0, sources = 0;
    for (const [dx, dz] of DIRS) {
      const c = this.host.getCell(x + dx, y, z + dz);
      if (c < 0 || (c & 4095) !== id) continue;
      const st = (c >>> 12) & 15;
      if (st === 0) sources++;
      const amount = st & 8 ? 8 : 8 - (st & 7);
      if (amount > best) best = amount;
    }
    if (id === ID.water && sources >= 2) {
      const below = this.host.getCell(x, y - 1, z);
      if (below >= 0) {
        const bid = below & 4095;
        if ((BLOCKS[bid]?.solid && !isReplaceable(bid)) || (bid === id && ((below >>> 12) & 15) === 0)) return 0; // new infinite source
      }
    }
    const above = this.host.getCell(x, y + 1, z);
    if (above >= 0 && (above & 4095) === id) return 8; // falling column
    const amount = best - this.drop(id);
    if (amount <= 0) return -1;
    return 8 - amount;
  }

  /** Lava reacts with adjacent water. Returns true when the lava cell was turned into stone. */
  private lavaReact(x: number, y: number, z: number, cell: number): boolean {
    const state = (cell >>> 12) & 15;
    const below = this.host.getCell(x, y - 1, z) & 4095;
    for (const [dx, dy, dz] of [[0, 1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, -1, 0]] as const) {
      const c = this.host.getCell(x + dx, y + dy, z + dz);
      if (c < 0) continue;
      if (dy === -1) continue;
      if ((c & 4095) === ID.water) {
        this.changes++;
        this.host.setBlock(x, y, z, state === 0 ? ID.obsidian : ID.cobblestone, 0);
        this.host.sound?.('fizz', { x, y, z });
        return true;
      }
      if (below === ID.soul_soil && ID.blue_ice !== undefined && (c & 4095) === ID.blue_ice && ID.basalt !== undefined) {
        this.changes++;
        this.host.setBlock(x, y, z, ID.basalt, 0);
        this.host.sound?.('fizz', { x, y, z });
        return true;
      }
    }
    return false;
  }

  /** Vanilla isWaterHole: the cell below accepts the fluid (air, replaceable, or already the same fluid). */
  private holeBelow(id: number, x: number, y: number, z: number) {
    const c = this.host.getCell(x, y - 1, z);
    return c >= 0 && (isReplaceable(c & 4095) || (c & 4095) === id);
  }

  /** Distance (in blocks) to the nearest hole reachable within the slope search distance (vanilla getSlopeDistance). */
  private slopeDistance(id: number, x: number, y: number, z: number, depth: number, fromDx: number, fromDz: number): number {
    let best = 1000;
    for (const [dx, dz] of DIRS) {
      if (dx === -fromDx && dz === -fromDz) continue;
      const nx = x + dx, nz = z + dz;
      if (!this.passable(this.host.getCell(nx, y, nz), id)) continue;
      if (this.holeBelow(id, nx, y, nz)) return depth;
      if (depth < this.slope(id)) {
        const j = this.slopeDistance(id, nx, y, nz, depth + 1, dx, dz);
        if (j < best) best = j;
      }
    }
    return best;
  }

  private tick(x: number, y: number, z: number) {
    const cell = this.host.getCell(x, y, z);
    if (cell < 0) return;
    const id = cell & 4095;
    if (!isFluid(id)) return;
    let state = (cell >>> 12) & 15;
    if (id === ID.lava && this.lavaReact(x, y, z, cell)) return;

    if (state !== 0) {
      const ns = this.computeNew(id, x, y, z);
      if (ns === -1) { this.changes++; this.host.setBlock(x, y, z, 0); return; }
      if (ns !== state) {
        this.changes++;
        this.host.setBlock(x, y, z, id, ns);
        // setBlock re-enters onBlockChanged which re-schedules this cell; fall through only when the new state keeps spreading
        state = ns;
      }
    }
    this.spread(id, x, y, z, state);
  }

  private spread(id: number, x: number, y: number, z: number, state: number) {
    const belowCell = this.host.getCell(x, y - 1, z);
    if (belowCell < 0) return;
    const bid = belowCell & 4095;
    if (isReplaceable(bid)) {
      this.place(x, y - 1, z, id, 8);
      return;
    }
    if (isFluid(bid) && bid !== id) {
      // lava running down into water becomes stone; water falling onto lava turns it to obsidian / cobblestone (via the lava's own reaction)
      if (id === ID.lava) { this.changes++; this.host.setBlock(x, y - 1, z, ID.stone, 0); this.host.sound?.('fizz', { x, y, z }); }
      else this.schedule(x, y - 1, z, 0.05);
      return;
    }
    const source = state === 0;
    if (!source && bid === id) return; // flowing fluid on top of the same fluid: no sideways spreading (waterfall landing in a lake)
    const falling = (state & 8) !== 0;
    const amount = falling ? 7 : 8 - (state & 7) - this.drop(id);
    if (amount <= 0) return;

    // Prefer the direction(s) leading to the closest hole; with no hole in range, flow in every direction.
    let bestDist = 1000;
    const picks: [number, number][] = [];
    for (const [dx, dz] of DIRS) {
      const nx = x + dx, nz = z + dz, nc = this.host.getCell(nx, y, nz);
      if (!this.passable(nc, id)) continue;
      const d = this.holeBelow(id, nx, y, nz) ? 0 : this.slopeDistance(id, nx, y, nz, 1, dx, dz);
      if (d < bestDist) { bestDist = d; picks.length = 0; }
      if (d <= bestDist) picks.push([dx, dz]);
    }
    for (const [dx, dz] of picks) {
      const nx = x + dx, nz = z + dz, nc = this.host.getCell(nx, y, nz);
      if (nc < 0) continue;
      if (!isReplaceable(nc & 4095)) { if ((nc & 4095) === id) this.schedule(nx, y, nz); continue; } // flowing cells update on their own tick
      const ns = this.computeNew(id, nx, y, nz);
      if (ns === -1) continue;
      this.place(nx, y, nz, id, ns);
    }
  }
}
