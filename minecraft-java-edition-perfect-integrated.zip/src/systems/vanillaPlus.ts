// Record 018: Wiki-Verified Vanilla Java Edition (1.21) Mechanics Extension
// Covers:
//  1. Copper 4-stage oxidation (64/1125 precheck, 4-block Manhattan scan, ((c+1)/(b+1))^2 * 0.75/1.0), Honeycomb waxing, Axe scraping & Lightning deoxidation
//  2. Lightning Rod (128-block radius diversion in Java Edition, 8-tick redstone signal 15, attached-block strong power, copper deoxidation)
//  3. Respawn Anchor (0..4 glowstone charges, comparator 0/3/7/11/15, Nether respawn point, Overworld/End power-5 explosion) & Lodestone Compass binding
//  4. Budding Amethyst & 4-stage Amethyst Cluster growth (20% per random tick on 1 of 6 faces, Pickaxe/Fortune/Silk Touch shard yields) + 3-layer Geode generator
//  5. Multiblock Summoning Rituals (Snow Golem 2 snow + pumpkin, Iron Golem 4 iron T-shape + pumpkin, Wither 4 soul sand/soil + 3 skulls, 220-tick warmup, Wither Armor <50% HP, Nether Star drop)
//  6. Piglin Bartering (120-tick gold ingot admiration, official weighted loot table), Gold Armor neutrality, container/gold-mine aggravation & 300-tick Overworld/End zombification
//  7. Sculk Shrieker (per-player warning 1..4, Darkness) & Warden Anger (0..150, roar/pursuit at >=80, Darkness aura 20m every 6s, Sonic Boom 1.7s charge / 10 armor-piercing damage)
//  8. 1.21 Ominous Bottle (I–V) -> Bad Omen (60m) -> Raid Omen (30s in villages) / Trial Omen (15m * level near trial spawners)
//  9. Dispenser full behavior table (shears sheep/beehive, bottle water/honey, bone meal, flint & steel / fire charge, glowstone -> anchor, armor equip, boat/minecart placement), Rail curve auto-connect & T-junction redstone flip, Trapped Chest viewer signal
// 10. Suspicious Stew flower effect table, Bundle (64 weight units mixed storage), Spyglass (1/10 FOV zoom), Chorus Flower branching growth (age 0..5) & arrow harvest
// 11. Gamerules (`keepInventory`, `doDaylightCycle`, `doWeatherCycle`, `mobGriefing`, `doFireTick`, `naturalRegeneration`, `doWardenSpawning`) & `/gamerule`, `/setblock`, `/fill`, `/clone`, `/summon` with `~` / `^` and `@p` / `@e` selectors

import { BLOCKS, ID, resolve } from '../game/data';
import { blockId, blockState, makeCell } from '../game/blockState';
import type { Dimension, Stack } from '../game/types';

// ======================================================================================================================
// 1. Copper Oxidation, Waxing, Scraping & Lightning Deoxidation (Wiki: Block of Copper § Oxidation)
// ======================================================================================================================
export const COPPER_CHAINS: readonly (readonly [string, string, string, string])[] = [
  ['copper_block', 'exposed_copper', 'weathered_copper', 'oxidized_copper'],
  ['cut_copper', 'exposed_cut_copper', 'weathered_cut_copper', 'oxidized_cut_copper'],
  ['chiseled_copper', 'exposed_chiseled_copper', 'weathered_chiseled_copper', 'oxidized_chiseled_copper'],
];

/** Pre-check probability per random tick in Java Edition: 64 / 1125 (~0.0568889). */
export const COPPER_OXIDATION_PRECHECK = 64 / 1125;
/** Bit flag in blockState marking that a copper block has been waxed with Honeycomb. */
export const COPPER_WAX_BIT = 8;

export function copperInfo(blockName: string): { chainIndex: number; stage: number; chain: readonly [string, string, string, string] } | null {
  for (let i = 0; i < COPPER_CHAINS.length; i++) {
    const idx = COPPER_CHAINS[i].indexOf(blockName);
    if (idx >= 0) return { chainIndex: i, stage: idx, chain: COPPER_CHAINS[i] };
  }
  return null;
}

export function isWaxedCopper(cell: number): boolean {
  const name = BLOCKS[blockId(cell)]?.name ?? '';
  return copperInfo(name) !== null && (blockState(cell) & COPPER_WAX_BIT) !== 0;
}

/**
 * Runs one Java Edition random-tick oxidation step for the copper block at (x, y, z).
 * Wiki formula:
 *  - Pre-check probability 64/1125 (can be bypassed in tests with `skipPrecheck = true`).
 *  - Scans all non-waxed copper blocks within Manhattan distance <= 4:
 *    - If any has a strictly lower oxidation stage, oxidation is aborted.
 *    - Let `b` = count of other non-waxed copper blocks within Manhattan distance 4,
 *      and `c` = count of those with strictly higher oxidation stage.
 *    - Probability = ((c + 1) / (b + 1))^2 * (stage === 0 ? 0.75 : 1.0).
 */
export function tickCopperOxidation(
  getCell: (x: number, y: number, z: number) => number,
  setBlock: (x: number, y: number, z: number, id: number, state?: number) => boolean,
  x: number, y: number, z: number,
  rng: () => number = Math.random,
  skipPrecheck = false,
): boolean {
  const cell = getCell(x, y, z), id = blockId(cell), st = blockState(cell);
  if (id <= 0 || (st & COPPER_WAX_BIT) !== 0) return false;
  const info = copperInfo(BLOCKS[id]?.name ?? '');
  if (!info || info.stage >= 3) return false;
  if (!skipPrecheck && rng() >= COPPER_OXIDATION_PRECHECK) return false;

  let b = 0, c = 0;
  for (let dy = -4; dy <= 4; dy++) {
    for (let dz = -4; dz <= 4; dz++) {
      for (let dx = -4; dx <= 4; dx++) {
        const dist = Math.abs(dx) + Math.abs(dy) + Math.abs(dz);
        if (dist === 0 || dist > 4) continue;
        const nc = getCell(x + dx, y + dy, z + dz), nid = blockId(nc), nst = blockState(nc);
        if (nid <= 0 || (nst & COPPER_WAX_BIT) !== 0) continue;
        const ninfo = copperInfo(BLOCKS[nid]?.name ?? '');
        if (!ninfo) continue;
        if (ninfo.stage < info.stage) return false; // lower-stage neighbor prevents oxidation
        b++;
        if (ninfo.stage > info.stage) c++;
      }
    }
  }
  const mult = info.stage === 0 ? 0.75 : 1.0;
  const ratio = (c + 1) / (b + 1);
  const chance = ratio * ratio * mult;
  if (rng() < chance) {
    const nextId = ID[info.chain[info.stage + 1]];
    if (nextId !== undefined) return setBlock(x, y, z, nextId, st & ~COPPER_WAX_BIT);
  }
  return false;
}

/** Applies Honeycomb to wax a copper block (returns false if not copper or already waxed). */
export function waxCopper(
  getCell: (x: number, y: number, z: number) => number,
  setBlock: (x: number, y: number, z: number, id: number, state?: number) => boolean,
  x: number, y: number, z: number,
): boolean {
  const cell = getCell(x, y, z), id = blockId(cell), st = blockState(cell);
  if (id <= 0 || (st & COPPER_WAX_BIT) !== 0) return false;
  if (!copperInfo(BLOCKS[id]?.name ?? '')) return false;
  return setBlock(x, y, z, id, st | COPPER_WAX_BIT);
}

/** Uses an Axe on a copper block: removes wax first ('unwaxed'), or steps oxidation back by 1 stage ('scraped'). */
export function scrapeCopper(
  getCell: (x: number, y: number, z: number) => number,
  setBlock: (x: number, y: number, z: number, id: number, state?: number) => boolean,
  x: number, y: number, z: number,
): 'unwaxed' | 'scraped' | null {
  const cell = getCell(x, y, z), id = blockId(cell), st = blockState(cell);
  if (id <= 0) return null;
  const info = copperInfo(BLOCKS[id]?.name ?? '');
  if (!info) return null;
  if (st & COPPER_WAX_BIT) {
    setBlock(x, y, z, id, st & ~COPPER_WAX_BIT);
    return 'unwaxed';
  }
  if (info.stage > 0) {
    const prevId = ID[info.chain[info.stage - 1]];
    if (prevId !== undefined) {
      setBlock(x, y, z, prevId, st);
      return 'scraped';
    }
  }
  return null;
}

/** Lightning strike deoxidizes the hit unwaxed copper block completely and steps back nearby unwaxed copper blocks. */
export function deoxidizeCopperAround(
  getCell: (x: number, y: number, z: number) => number,
  setBlock: (x: number, y: number, z: number, id: number, state?: number) => boolean,
  x: number, y: number, z: number,
): number {
  let cleaned = 0;
  for (let dy = -2; dy <= 2; dy++) {
    for (let dz = -2; dz <= 2; dz++) {
      for (let dx = -2; dx <= 2; dx++) {
        const dist = Math.abs(dx) + Math.abs(dy) + Math.abs(dz);
        if (dist > 3) continue;
        const cx = x + dx, cy = y + dy, cz = z + dz;
        const cell = getCell(cx, cy, cz), id = blockId(cell), st = blockState(cell);
        if (id <= 0 || (st & COPPER_WAX_BIT) !== 0) continue;
        const info = copperInfo(BLOCKS[id]?.name ?? '');
        if (!info || info.stage === 0) continue;
        const targetStage = dist === 0 ? 0 : Math.max(0, info.stage - 1);
        const nextId = ID[info.chain[targetStage]];
        if (nextId !== undefined && setBlock(cx, cy, cz, nextId, st)) cleaned++;
      }
    }
  }
  return cleaned;
}

// ======================================================================================================================
// 2. Lightning Rod (Wiki: Lightning Rod — 128-block radius in Java Edition, 8-game-tick signal 15)
// ======================================================================================================================
export const LIGHTNING_ROD_RADIUS = 128;
export const LIGHTNING_ROD_PULSE_TICKS = 8;

export function findNearestLightningRod(
  rods: Iterable<[number, number, number]>,
  x: number, z: number,
  radius = LIGHTNING_ROD_RADIUS,
): [number, number, number] | null {
  let best: [number, number, number] | null = null, bestD2 = radius * radius;
  for (const [rx, ry, rz] of rods) {
    const dx = rx - x, dz = rz - z, d2 = dx * dx + dz * dz;
    if (d2 <= bestD2) {
      bestD2 = d2;
      best = [rx, ry, rz];
    }
  }
  return best;
}

// ======================================================================================================================
// 3. Respawn Anchor & Lodestone (Wiki: Respawn Anchor, Lodestone)
// ======================================================================================================================
export const RESPAWN_ANCHOR_MAX_CHARGES = 4;
/** Comparator output for Respawn Anchor charges 0..4: 0, 3, 7, 11, 15. */
export const RESPAWN_ANCHOR_SIGNALS = [0, 3, 7, 11, 15] as const;

export function bindLodestoneCompass(compass: Stack, dim: Dimension, x: number, y: number, z: number): Stack {
  return {
    ...compass,
    count: 1,
    label: `Lodestone (${dim}:${x},${y},${z})`,
    tag: { ...(compass.tag ?? {}), LodestoneDimension: dim, LodestonePos: [x, y, z], LodestoneTracked: true },
  };
}

export function lodestoneTargetOf(s: Stack | null | undefined): { dim: string; x: number; y: number; z: number } | null {
  if (!s || s.name !== 'compass' || !s.tag) return null;
  const dim = s.tag.LodestoneDimension as string | undefined;
  const pos = s.tag.LodestonePos as number[] | undefined;
  if (!dim || !Array.isArray(pos) || pos.length < 3) return null;
  return { dim, x: pos[0], y: pos[1], z: pos[2] };
}

// ======================================================================================================================
// 4. Budding Amethyst & 4-Stage Amethyst Cluster Growth (Wiki: Amethyst Cluster — 20% chance per random tick)
// ======================================================================================================================
export const AMETHYST_STAGES = ['small_amethyst_bud', 'medium_amethyst_bud', 'large_amethyst_bud', 'amethyst_cluster'] as const;
export const BUDDING_AMETHYST_CHANCE = 0.2;
const FACES6: readonly [number, number, number][] = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

export function tickBuddingAmethyst(
  getCell: (x: number, y: number, z: number) => number,
  setBlock: (x: number, y: number, z: number, id: number, state?: number) => boolean,
  x: number, y: number, z: number,
  rng: () => number = Math.random,
): boolean {
  if (blockId(getCell(x, y, z)) !== ID.budding_amethyst) return false;
  if (rng() >= BUDDING_AMETHYST_CHANCE) return false;
  const faceIdx = Math.min(5, Math.floor(rng() * 6));
  const [dx, dy, dz] = FACES6[faceIdx];
  const tx = x + dx, ty = y + dy, tz = z + dz;
  const cell = getCell(tx, ty, tz), tid = blockId(cell), tst = blockState(cell);
  const waterlogged = tid === ID.water && tst === 0 ? 8 : (tst & 8);
  if (tid === 0 || (tid === ID.water && tst === 0)) {
    const smallId = ID.small_amethyst_bud;
    return smallId !== undefined ? setBlock(tx, ty, tz, smallId, faceIdx | waterlogged) : false;
  }
  const tname = BLOCKS[tid]?.name ?? '';
  const stageIdx = (AMETHYST_STAGES as readonly string[]).indexOf(tname);
  if (stageIdx >= 0 && stageIdx < 3) {
    const nextId = ID[AMETHYST_STAGES[stageIdx + 1]];
    return nextId !== undefined ? setBlock(tx, ty, tz, nextId, tst) : false;
  }
  return false;
}

/**
 * Wiki-accurate drops for Budding Amethyst, Amethyst Buds, and Amethyst Clusters:
 *  - `budding_amethyst`: never drops anything (even with Silk Touch).
 *  - `small_amethyst_bud` / `medium_amethyst_bud` / `large_amethyst_bud`: drops itself with Silk Touch, otherwise nothing.
 *  - `amethyst_cluster`: drops itself with Silk Touch; otherwise 4 `amethyst_shard` when mined with a pickaxe (2 without pickaxe),
 *    multiplied by Fortune (up to 8/12/16 shards for Fortune I/II/III).
 */
export function amethystDrops(
  blockName: string,
  isPickaxe: boolean,
  silkTouch: boolean,
  fortune = 0,
  rng: () => number = Math.random,
): { name: string; count: number }[] {
  if (blockName === 'budding_amethyst') return [];
  if (blockName === 'small_amethyst_bud' || blockName === 'medium_amethyst_bud' || blockName === 'large_amethyst_bud') {
    return silkTouch ? [{ name: blockName, count: 1 }] : [];
  }
  if (blockName === 'amethyst_cluster') {
    if (silkTouch) return [{ name: 'amethyst_cluster', count: 1 }];
    const base = isPickaxe ? 4 : 2;
    if (fortune <= 0 || !isPickaxe) return [{ name: 'amethyst_shard', count: base }];
    // Wiki: Fortune I..III behaves like ore multiplier: 1/(fortune+2) chance each for 2x..((fortune+1)x), else 1x
    const i = Math.max(0, Math.floor(rng() * (fortune + 2)) - 1);
    const mult = i + 1;
    return [{ name: 'amethyst_shard', count: base * mult }];
  }
  return [];
}

/** Generates a 3-layer spherical Amethyst Geode (`basalt` outer -> `calcite` middle -> `amethyst_block` + `budding_amethyst` inner). */
export function generateAmethystGeode(
  setBlock: (x: number, y: number, z: number, id: number, state?: number) => void,
  cx: number, cy: number, cz: number,
  radius = 5,
  rng: () => number = Math.random,
): { buddingCount: number } {
  let buddingCount = 0;
  const rOut = radius, rMid = radius - 1, rIn = radius - 2, rAir = radius - 3;
  for (let dy = -rOut; dy <= rOut; dy++) {
    for (let dz = -rOut; dz <= rOut; dz++) {
      for (let dx = -rOut; dx <= rOut; dx++) {
        const d = Math.hypot(dx, dy, dz);
        if (d > rOut + 0.25) continue;
        const x = cx + dx, y = cy + dy, z = cz + dz;
        if (d <= rAir) {
          setBlock(x, y, z, 0, 0);
        } else if (d <= rIn) {
          const isBudding = rng() < 0.085 || (dx === 0 && dy === -rIn + 1 && dz === 0);
          setBlock(x, y, z, isBudding ? ID.budding_amethyst : ID.amethyst_block, 0);
          if (isBudding) buddingCount++;
        } else if (d <= rMid) {
          setBlock(x, y, z, ID.calcite, 0);
        } else {
          setBlock(x, y, z, ID.basalt, 0);
        }
      }
    }
  }
  return { buddingCount };
}

// ======================================================================================================================
// 5. Multiblock Summoning Rituals (Snow Golem, Iron Golem, Wither Boss)
// ======================================================================================================================
export interface SummonResult {
  species: 'snow_golem' | 'iron_golem' | 'wither';
  x: number;
  y: number;
  z: number;
  playerCreated: boolean;
  warmupTicks?: number;
}

export function trySummonMultiblock(
  getBlock: (x: number, y: number, z: number) => number,
  setBlock: (x: number, y: number, z: number, id: number, state?: number) => boolean,
  x: number, y: number, z: number,
): SummonResult | null {
  const topId = getBlock(x, y, z);
  const topName = BLOCKS[topId]?.name ?? '';
  const isPumpkin = topName === 'carved_pumpkin' || topName === 'pumpkin' || topName === 'jack_o_lantern';

  if (isPumpkin) {
    // 1. Snow Golem: 2 snow_block directly below
    if (getBlock(x, y - 1, z) === ID.snow_block && getBlock(x, y - 2, z) === ID.snow_block) {
      setBlock(x, y, z, 0);
      setBlock(x, y - 1, z, 0);
      setBlock(x, y - 2, z, 0);
      return { species: 'snow_golem', x: x + 0.5, y: y - 2, z: z + 0.5, playerCreated: true };
    }
    // 2. Iron Golem: T-shape of 4 iron_block below
    if (getBlock(x, y - 1, z) === ID.iron_block && getBlock(x, y - 2, z) === ID.iron_block) {
      const armsX = getBlock(x - 1, y - 1, z) === ID.iron_block && getBlock(x + 1, y - 1, z) === ID.iron_block;
      const armsZ = getBlock(x, y - 1, z - 1) === ID.iron_block && getBlock(x, y - 1, z + 1) === ID.iron_block;
      if (armsX || armsZ) {
        setBlock(x, y, z, 0);
        setBlock(x, y - 1, z, 0);
        setBlock(x, y - 2, z, 0);
        if (armsX) { setBlock(x - 1, y - 1, z, 0); setBlock(x + 1, y - 1, z, 0); }
        else { setBlock(x, y - 1, z - 1, 0); setBlock(x, y - 1, z + 1, 0); }
        return { species: 'iron_golem', x: x + 0.5, y: y - 2, z: z + 0.5, playerCreated: true };
      }
    }
  }

  // 3. Wither: 3 wither_skeleton_skull in a line + T-shape of 4 soul_sand / soul_soil below
  if (topName === 'wither_skeleton_skull') {
    const isSoul = (bx: number, by: number, bz: number) => {
      const bid = getBlock(bx, by, bz);
      return bid === ID.soul_sand || bid === ID.soul_soil;
    };
    const isSkull = (bx: number, by: number, bz: number) => getBlock(bx, by, bz) === ID.wither_skeleton_skull;
    for (const axis of ['x', 'z'] as const) {
      for (const offset of [-1, 0, 1]) {
        const cx = axis === 'x' ? x + offset : x;
        const cz = axis === 'z' ? z + offset : z;
        const dx = axis === 'x' ? 1 : 0;
        const dz = axis === 'z' ? 1 : 0;
        if (
          isSkull(cx - dx, y, cz - dz) &&
          isSkull(cx, y, cz) &&
          isSkull(cx + dx, y, cz + dz) &&
          isSoul(cx, y - 1, cz) &&
          isSoul(cx, y - 2, cz) &&
          isSoul(cx - dx, y - 1, cz - dz) &&
          isSoul(cx + dx, y - 1, cz + dz)
        ) {
          setBlock(cx - dx, y, cz - dz, 0);
          setBlock(cx, y, cz, 0);
          setBlock(cx + dx, y, cz + dz, 0);
          setBlock(cx - dx, y - 1, cz - dz, 0);
          setBlock(cx, y - 1, cz, 0);
          setBlock(cx + dx, y - 1, cz + dz, 0);
          setBlock(cx, y - 2, cz, 0);
          return { species: 'wither', x: cx + 0.5, y: y - 2, z: cz + 0.5, playerCreated: false, warmupTicks: 220 };
        }
      }
    }
  }
  return null;
}

// ======================================================================================================================
// 6. Piglin Bartering, Gold Armor Neutrality & 300-Tick Zombification (Wiki: Piglin, Bartering)
// ======================================================================================================================
export const PIGLIN_BARTER_TICKS = 120;   // 6 seconds admiring gold_ingot
export const PIGLIN_ZOMBIFY_TICKS = 300;  // 15 seconds in Overworld/End

export interface BarterEntry {
  name: string;
  min: number;
  max: number;
  weight: number;
  ench?: Record<string, number>;
}

/** Official Java Edition Piglin bartering table (total weight 459). */
export const PIGLIN_BARTER_TABLE: readonly BarterEntry[] = [
  { name: 'enchanted_book', min: 1, max: 1, weight: 5, ench: { soul_speed: 2 } },
  { name: 'iron_boots', min: 1, max: 1, weight: 8, ench: { soul_speed: 2 } },
  { name: 'potion_fire_resistance', min: 1, max: 1, weight: 8 },
  { name: 'splash_fire_resistance', min: 1, max: 1, weight: 8 },
  { name: 'water_bottle', min: 1, max: 1, weight: 10 },
  { name: 'iron_nugget', min: 10, max: 36, weight: 10 },
  { name: 'ender_pearl', min: 2, max: 4, weight: 10 },
  { name: 'string', min: 3, max: 9, weight: 20 },
  { name: 'quartz', min: 5, max: 12, weight: 20 },
  { name: 'obsidian', min: 1, max: 1, weight: 40 },
  { name: 'crying_obsidian', min: 1, max: 3, weight: 40 },
  { name: 'fire_charge', min: 1, max: 1, weight: 40 },
  { name: 'leather', min: 2, max: 4, weight: 40 },
  { name: 'soul_sand', min: 2, max: 8, weight: 40 },
  { name: 'nether_brick', min: 2, max: 8, weight: 40 },
  { name: 'spectral_arrow', min: 6, max: 12, weight: 40 },
  { name: 'gravel', min: 8, max: 16, weight: 40 },
];

export function isWearingGoldArmor(armor: readonly (Stack | null | undefined)[]): boolean {
  return armor.some(s => !!s && /^golden_(helmet|chestplate|leggings|boots)$/.test(s.name));
}

export function rollPiglinBarter(rng: () => number = Math.random): Stack {
  const total = PIGLIN_BARTER_TABLE.reduce((acc, e) => acc + e.weight, 0);
  let r = rng() * total;
  for (const e of PIGLIN_BARTER_TABLE) {
    r -= e.weight;
    if (r <= 0) {
      const count = e.min === e.max ? e.min : e.min + Math.floor(rng() * (e.max - e.min + 1));
      const itemName = resolve(e.name) ? e.name : 'ender_pearl';
      return { name: itemName, count, ...(e.ench ? { ench: { ...e.ench } } : {}) };
    }
  }
  return { name: 'ender_pearl', count: 2 };
}

// ======================================================================================================================
// 7. Sculk Shrieker (Warning 1..4) & Warden Anger (0..150) + Sonic Boom (Wiki: Warden, Sculk Shrieker)
// ======================================================================================================================
export const SHRIEKER_WARNING_MAX = 4;
export const WARDEN_EMERGE_TICKS = 134;   // 6.7 seconds emerging from ground
export const WARDEN_ANGER_PURSUE = 80;    // Roars and pursues target at >= 80 anger
export const WARDEN_ANGER_MAX = 150;
export const WARDEN_SONIC_CHARGE_TICKS = 34; // 1.7 seconds charge
export const WARDEN_SONIC_DAMAGE = 10;    // Pierces armor, shields and blocks; reduced only by Resistance

export function wardenSonicDamage(resistanceLevel = 0): number {
  return Math.max(0, WARDEN_SONIC_DAMAGE * (1 - 0.2 * Math.max(0, Math.min(5, resistanceLevel))));
}

// ======================================================================================================================
// 8. 1.21 Ominous Bottle (I–V) -> Bad Omen -> Raid Omen (30s) / Trial Omen (15m * level)
// ======================================================================================================================
export const OMINOUS_BOTTLE_DURATION = 3600; // 60 minutes of Bad Omen
export const RAID_OMEN_DURATION = 30;        // 30 seconds before Raid starts
export const TRIAL_OMEN_BASE_DURATION = 900; // 15 minutes per Bad Omen level

export function ominousBottleStack(level = 1): Stack {
  const lv = Math.max(1, Math.min(5, Math.floor(level)));
  return {
    name: 'ominous_bottle',
    count: 1,
    label: `Ominous Bottle ${['I', 'II', 'III', 'IV', 'V'][lv - 1]}`,
    tag: { ominous_bottle_amplifier: lv - 1 },
  };
}

export function ominousBottleAmplifier(stack: Stack): number {
  const raw = stack.tag?.ominous_bottle_amplifier;
  return typeof raw === 'number' ? Math.max(0, Math.min(4, Math.floor(raw))) : 0;
}

// ======================================================================================================================
// 9. Rail Curve Auto-Connect & T-Junction Redstone Flip, Trapped Chest (Wiki: Rail, Trapped Chest)
// ======================================================================================================================
/**
 * Rail states:
 *  0 = north_south, 1 = east_west,
 *  2 = ascending_east, 3 = ascending_west, 4 = ascending_north, 5 = ascending_south,
 *  6 = south_east, 7 = south_west, 8 = north_west, 9 = north_east
 */
export function computeRailState(
  isRailAt: (x: number, y: number, z: number) => boolean,
  x: number, y: number, z: number,
  powered = false,
): number {
  const n = isRailAt(x, y, z - 1) || isRailAt(x, y + 1, z - 1) || isRailAt(x, y - 1, z - 1);
  const s = isRailAt(x, y, z + 1) || isRailAt(x, y + 1, z + 1) || isRailAt(x, y - 1, z + 1);
  const w = isRailAt(x - 1, y, z) || isRailAt(x - 1, y + 1, z) || isRailAt(x - 1, y - 1, z);
  const e = isRailAt(x + 1, y, z) || isRailAt(x + 1, y + 1, z) || isRailAt(x + 1, y - 1, z);

  // Slopes if a neighbor is 1 block higher
  if (isRailAt(x + 1, y + 1, z)) return 2;
  if (isRailAt(x - 1, y + 1, z)) return 3;
  if (isRailAt(x, y + 1, z - 1)) return 4;
  if (isRailAt(x, y + 1, z + 1)) return 5;

  // T-junctions (3 neighbors): redstone power flips the curve!
  const count = (n ? 1 : 0) + (s ? 1 : 0) + (w ? 1 : 0) + (e ? 1 : 0);
  if (count === 3) {
    if (!n) return powered ? 7 : 6; // S + E + W -> SE (6) unpowered, SW (7) powered
    if (!s) return powered ? 8 : 9; // N + E + W -> NE (9) unpowered, NW (8) powered
    if (!w) return powered ? 9 : 6; // N + S + E -> SE (6) unpowered, NE (9) powered
    if (!e) return powered ? 8 : 7; // N + S + W -> SW (7) unpowered, NW (8) powered
  }

  // 2-neighbor corners
  if (s && e && !n && !w) return 6; // SE
  if (s && w && !n && !e) return 7; // SW
  if (n && w && !s && !e) return 8; // NW
  if (n && e && !s && !w) return 9; // NE

  if ((w || e) && !n && !s) return 1; // EW
  return 0; // NS
}

// ======================================================================================================================
// 10. Suspicious Stew, Bundle (64 Weight Units), Spyglass & Chorus Flower (Wiki: Suspicious Stew, Bundle, Chorus Flower)
// ======================================================================================================================
/** Exact Java Edition flower -> [effectId, durationSeconds, amplifier] mapping from Minecraft Wiki. */
export const SUSPICIOUS_STEW_FLOWERS: Readonly<Record<string, readonly [string, number, number]>> = {
  allium: ['fire_resistance', 4, 0],
  azure_bluet: ['blindness', 8, 0],
  blue_orchid: ['saturation', 0.35, 0],
  dandelion: ['saturation', 0.35, 0],
  cornflower: ['jump_boost', 6, 0],
  lily_of_the_valley: ['poison', 12, 0],
  oxeye_daisy: ['regeneration', 8, 0],
  poppy: ['night_vision', 5, 0],
  torchflower: ['night_vision', 5, 0],
  red_tulip: ['weakness', 9, 0],
  orange_tulip: ['weakness', 9, 0],
  white_tulip: ['weakness', 9, 0],
  pink_tulip: ['weakness', 9, 0],
  wither_rose: ['wither', 8, 0],
};

export function craftSuspiciousStew(flowerName: string): Stack | null {
  const spec = SUSPICIOUS_STEW_FLOWERS[flowerName];
  if (!spec) return null;
  const [effect, duration, amplifier] = spec;
  return {
    name: 'suspicious_stew',
    count: 1,
    tag: { flower: flowerName, effects: [{ id: effect, duration, amplifier }] },
  };
}

export function suspiciousStewEffect(stack: Stack): { id: string; duration: number; amplifier: number } | null {
  const list = stack.tag?.effects as { id: string; duration: number; amplifier?: number }[] | undefined;
  if (Array.isArray(list) && list.length > 0) {
    return { id: list[0].id, duration: list[0].duration, amplifier: list[0].amplifier ?? 0 };
  }
  const flower = stack.tag?.flower as string | undefined;
  if (flower && SUSPICIOUS_STEW_FLOWERS[flower]) {
    const [id, duration, amplifier] = SUSPICIOUS_STEW_FLOWERS[flower];
    return { id, duration, amplifier };
  }
  return { id: 'regeneration', duration: 8, amplifier: 0 };
}

export const BUNDLE_MAX_WEIGHT = 64;

export function bundleItemWeight(itemName: string): number {
  if (/shulker_box$/.test(itemName)) return Infinity; // Shulker boxes cannot be placed inside a bundle
  if (itemName === 'bundle') return 4;               // Empty nested bundle costs 4 weight (up to 16 empty bundles)
  const maxStack = resolve(itemName)?.stack ?? 64;
  return Math.max(1, Math.floor(64 / Math.max(1, maxStack)));
}

export function bundleContents(bundle: Stack): Stack[] {
  const raw = bundle.tag?.BundleItems as Stack[] | undefined;
  return Array.isArray(raw) ? raw.map(s => ({ ...s })) : [];
}

export function bundleWeight(bundle: Stack): number {
  return bundleContents(bundle).reduce((sum, s) => sum + bundleItemWeight(s.name) * s.count, 0);
}

/** Inserts as many items from `incoming` as fit into `bundle` (up to 64 weight units). Mutates both stacks in place. */
export function bundleInsert(bundle: Stack, incoming: Stack): number {
  if (bundle.name !== 'bundle' || incoming.count <= 0) return 0;
  if (incoming.name === 'bundle' && bundleWeight(incoming) > 0) return 0; // Only empty bundles can nest
  const unitWeight = bundleItemWeight(incoming.name);
  if (!Number.isFinite(unitWeight)) return 0;
  const currentWeight = bundleWeight(bundle);
  const canFit = Math.floor((BUNDLE_MAX_WEIGHT - currentWeight) / unitWeight);
  const take = Math.min(incoming.count, Math.max(0, canFit));
  if (take <= 0) return 0;
  const items = bundleContents(bundle);
  const existing = items.find(s => s.name === incoming.name && !s.ench && !s.tag && s.durability === undefined);
  if (existing && !incoming.ench && !incoming.tag && incoming.durability === undefined) {
    existing.count += take;
  } else {
    items.push({ ...incoming, count: take });
  }
  bundle.tag = { ...(bundle.tag ?? {}), BundleItems: items };
  incoming.count -= take;
  return take;
}

/** Empties all stored items from `bundle` and returns them. */
export function bundleDropAll(bundle: Stack): Stack[] {
  const items = bundleContents(bundle);
  if (bundle.tag) {
    bundle.tag = { ...bundle.tag };
    delete bundle.tag.BundleItems;
    if (!Object.keys(bundle.tag).length) delete bundle.tag;
  }
  return items;
}

/** Spyglass FOV multiplier (1/10 of normal FOV per Wiki). */
export const SPYGLASS_FOV_SCALE = 0.1;

/**
 * Chorus Flower growth on random tick (Wiki: Chorus Flower):
 *  - Ages 0..4 grow; age 5 is dead/mature.
 *  - Must have air above `(x, y + 1, z)`.
 *  - Grows upward into `chorus_plant` at `(x, y, z)` and places `chorus_flower` at `(x, y + 1, z)` (or branches horizontally).
 */
export function tickChorusFlower(
  getCell: (x: number, y: number, z: number) => number,
  setBlock: (x: number, y: number, z: number, id: number, state?: number) => boolean,
  x: number, y: number, z: number,
  rng: () => number = Math.random,
): boolean {
  const cell = getCell(x, y, z), id = blockId(cell), age = blockState(cell) & 7;
  if (id !== ID.chorus_flower || age >= 5) return false;
  if (blockId(getCell(x, y + 1, z)) !== 0) return false;
  const below = blockId(getCell(x, y - 1, z));
  if (below !== ID.end_stone && below !== ID.chorus_plant) return false;

  // Count stem height below
  let stem = 0;
  while (stem < 5 && blockId(getCell(x, y - 1 - stem, z)) === ID.chorus_plant) stem++;

  if (stem < 4 && rng() < 0.65) {
    // Grow straight up
    setBlock(x, y, z, ID.chorus_plant, 0);
    setBlock(x, y + 1, z, ID.chorus_flower, age);
    return true;
  }
  // Branch horizontally (1..4 branches) if age < 4
  if (age < 4) {
    const dirs: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    let branched = false;
    for (const [dx, dz] of dirs) {
      if (rng() < 0.5 && blockId(getCell(x + dx, y, z + dz)) === 0 && blockId(getCell(x + dx, y - 1, z + dz)) === 0) {
        setBlock(x + dx, y, z + dz, ID.chorus_flower, age + 1);
        branched = true;
      }
    }
    if (branched) {
      setBlock(x, y, z, ID.chorus_plant, 0);
      return true;
    }
  }
  // Mature to dead chorus flower (age 5)
  setBlock(x, y, z, ID.chorus_flower, 5);
  return true;
}

// ======================================================================================================================
// 11. Gamerules & Coordinate / Selector Parser (`/gamerule`, `/setblock`, `/fill`, `/clone`, `/summon`)
// ======================================================================================================================
export interface Gamerules {
  keepInventory: boolean;
  doDaylightCycle: boolean;
  doWeatherCycle: boolean;
  mobGriefing: boolean;
  doFireTick: boolean;
  naturalRegeneration: boolean;
  doWardenSpawning: boolean;
}

export const DEFAULT_GAMERULES: Gamerules = {
  keepInventory: false,
  doDaylightCycle: true,
  doWeatherCycle: true,
  mobGriefing: true,
  doFireTick: true,
  naturalRegeneration: true,
  doWardenSpawning: true,
};

/** Parses absolute, relative (`~`, `~5`), or local (`^`, `^2`) coordinates against player pose. */
export function parseCoords(
  tokens: readonly string[],
  origin: { x: number; y: number; z: number; yaw?: number; pitch?: number },
): [number, number, number] | null {
  if (tokens.length < 3) return null;
  const [tx, ty, tz] = tokens;
  if (tx.startsWith('^') || ty.startsWith('^') || tz.startsWith('^')) {
    const lx = Number(tx.slice(1) || '0'), ly = Number(ty.slice(1) || '0'), lz = Number(tz.slice(1) || '0');
    if ([lx, ly, lz].some(Number.isNaN)) return null;
    const yaw = origin.yaw ?? 0, pitch = origin.pitch ?? 0;
    const cp = Math.cos(pitch), sp = Math.sin(pitch), cy = Math.cos(yaw), sy = Math.sin(yaw);
    // Forward vector along look direction (-sin(yaw)*cos(pitch), sin(pitch), -cos(yaw)*cos(pitch))
    const fx = -sy * cp, fy = sp, fz = -cy * cp;
    const rx = cy, rz = -sy;
    const ux = -sy * -sp, uy = cp, uz = -cy * -sp;
    return [
      Math.floor(origin.x + rx * lx + ux * ly + fx * lz),
      Math.floor(origin.y + uy * ly + fy * lz),
      Math.floor(origin.z + rz * lx + uz * ly + fz * lz),
    ];
  }
  const one = (tok: string, base: number): number => {
    if (tok.startsWith('~')) {
      const off = tok.length === 1 ? 0 : Number(tok.slice(1));
      return Number.isNaN(off) ? NaN : Math.floor(base + off);
    }
    const v = Number(tok);
    return Number.isNaN(v) ? NaN : Math.floor(v);
  };
  const x = one(tx, origin.x), y = one(ty, origin.y), z = one(tz, origin.z);
  return [x, y, z].some(Number.isNaN) ? null : [x, y, z];
}

export function parseSelector(
  sel: string,
): { target: 'p' | 's' | 'a' | 'e'; type?: string; maxDistance?: number } | null {
  const m = /^@([psae])(?:\[([^\]]*)\])?$/.exec(sel.trim());
  if (!m) return null;
  const out: { target: 'p' | 's' | 'a' | 'e'; type?: string; maxDistance?: number } = { target: m[1] as 'p' | 's' | 'a' | 'e' };
  if (m[2]) {
    for (const part of m[2].split(',')) {
      const [k, v] = part.split('=').map(s => s.trim());
      if (k === 'type' && v) out.type = v.replace(/^minecraft:/, '');
      if (k === 'distance' && v) {
        const dm = /(?:\.\.)?(\d+(?:\.\d+)?)$/.exec(v);
        if (dm) out.maxDistance = Number(dm[1]);
      }
    }
  }
  return out;
}
