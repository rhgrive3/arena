// Enchantments, status effects, potions and brewing — pure data + logic (no engine access) so it can be unit-tested.
import { resolve } from '../game/data';
import { POTION_BASES } from '../game/content';
import type { Stack } from '../game/types';
import { TRIM_PATTERNS, TRIM_MATERIALS } from './trims';
import { ANVIL_LEVEL_CAP, nextRepairCost, repairCostOf } from '../game/nbt';

export interface EnchDef { id: string; ja: string; en: string; max: number; on: string[]; weight: number; treasure?: boolean; curse?: boolean; excl?: string; }
const E = (id: string, ja: string, en: string, max: number, on: string[], weight: number, extra: Partial<EnchDef> = {}): EnchDef => ({ id, ja, en, max, on, weight, ...extra });
export const ENCHANTS: EnchDef[] = [
  E('protection', 'ダメージ軽減', 'Protection', 4, ['armor'], 10, { excl: 'prot' }),
  E('fire_protection', '火炎耐性', 'Fire Protection', 4, ['armor'], 5, { excl: 'prot' }),
  E('blast_protection', '爆発耐性', 'Blast Protection', 4, ['armor'], 2, { excl: 'prot' }),
  E('projectile_protection', '飛び道具耐性', 'Projectile Protection', 4, ['armor'], 5, { excl: 'prot' }),
  E('feather_falling', '落下耐性', 'Feather Falling', 4, ['boots'], 5),
  E('respiration', '水中呼吸', 'Respiration', 3, ['helmet'], 2),
  E('aqua_affinity', '水中採掘', 'Aqua Affinity', 1, ['helmet'], 2),
  E('thorns', '棘の鎧', 'Thorns', 3, ['armor'], 1),
  E('depth_strider', '水中歩行', 'Depth Strider', 3, ['boots'], 2, { excl: 'boots' }),
  E('frost_walker', '氷渡り', 'Frost Walker', 2, ['boots'], 2, { treasure: true, excl: 'boots' }),
  E('swift_sneak', 'スニーク速度上昇', 'Swift Sneak', 3, ['leggings'], 1, { treasure: true }),
  E('soul_speed', 'ソウルスピード', 'Soul Speed', 3, ['boots'], 1, { treasure: true }),
  E('sharpness', 'ダメージ増加', 'Sharpness', 5, ['sword', 'axe'], 10, { excl: 'dmg' }),
  E('smite', 'アンデッド特効', 'Smite', 5, ['sword', 'axe', 'mace'], 5, { excl: 'dmg' }),
  E('bane_of_arthropods', '虫特効', 'Bane of Arthropods', 5, ['sword', 'axe', 'mace'], 5, { excl: 'dmg' }),
  E('knockback', 'ノックバック', 'Knockback', 2, ['sword'], 5),
  E('fire_aspect', '火属性', 'Fire Aspect', 2, ['sword', 'mace'], 2),
  E('looting', 'ドロップ増加', 'Looting', 3, ['sword'], 2),
  E('sweeping_edge', '範囲ダメージ増加', 'Sweeping Edge', 3, ['sword'], 2),
  E('efficiency', '効率強化', 'Efficiency', 5, ['digger', 'shears'], 10),
  E('silk_touch', 'シルクタッチ', 'Silk Touch', 1, ['digger'], 1, { excl: 'drop' }),
  E('fortune', '幸運', 'Fortune', 3, ['digger'], 2, { excl: 'drop' }),
  E('unbreaking', '耐久力', 'Unbreaking', 3, ['breakable'], 5),
  E('mending', '修繕', 'Mending', 1, ['breakable'], 2, { treasure: true, excl: 'inf' }),
  E('power', '射撃ダメージ増加', 'Power', 5, ['bow'], 10),
  E('punch', 'パンチ', 'Punch', 2, ['bow'], 2),
  E('flame', 'フレイム', 'Flame', 1, ['bow'], 2),
  E('infinity', '無限', 'Infinity', 1, ['bow'], 1, { excl: 'inf' }),
  E('multishot', '拡散', 'Multishot', 1, ['crossbow'], 2, { excl: 'xbow' }),
  E('piercing', '貫通', 'Piercing', 4, ['crossbow'], 10, { excl: 'xbow' }),
  E('quick_charge', '高速装填', 'Quick Charge', 3, ['crossbow'], 5),
  E('loyalty', '忠誠', 'Loyalty', 3, ['trident'], 5, { excl: 'trident' }),
  E('riptide', '激流', 'Riptide', 3, ['trident'], 2, { excl: 'trident' }),
  E('impaling', '水生特効', 'Impaling', 5, ['trident'], 2),
  E('channeling', '召雷', 'Channeling', 1, ['trident'], 1),
  E('density', '密度', 'Density', 5, ['mace'], 5, { excl: 'dmg' }),
  E('breach', '防具貫通', 'Breach', 4, ['mace'], 2, { excl: 'dmg' }),
  E('wind_burst', 'ウィンドバースト', 'Wind Burst', 3, ['mace'], 2, { treasure: true }),
  E('luck_of_the_sea', '宝釣り', 'Luck of the Sea', 3, ['fishing_rod'], 2),
  E('lure', '入れ食い', 'Lure', 3, ['fishing_rod'], 2),
  E('curse_of_vanishing', '消滅の呪い', 'Curse of Vanishing', 1, ['breakable'], 1, { treasure: true, curse: true }),
  E('curse_of_binding', '束縛の呪い', 'Curse of Binding', 1, ['armor'], 1, { treasure: true, curse: true }),
];
export const ENCHANT_BY_ID: Record<string, EnchDef> = Object.fromEntries(ENCHANTS.map(e => [e.id, e]));

/** Categories an item belongs to (sword, digger, armor, breakable, ...) — drives which enchantments fit. */
export function itemKinds(name: string): string[] {
  const k: string[] = [], def = resolve(name);
  const m = /_(sword|pickaxe|axe|shovel|hoe|helmet|chestplate|leggings|boots)$/.exec(name);
  if (m) {
    k.push(m[1]);
    if (['pickaxe', 'axe', 'shovel', 'hoe'].includes(m[1])) k.push('digger');
    if (['helmet', 'chestplate', 'leggings', 'boots'].includes(m[1])) k.push('armor');
  }
  if (['bow', 'crossbow', 'trident', 'mace', 'shield', 'elytra', 'fishing_rod', 'shears', 'flint_and_steel'].includes(name)) k.push(name);
  if (def?.durability || name === 'elytra') k.push('breakable');
  if (name === 'book' || name === 'enchanted_book') k.push('book');
  return k;
}
/** 0 helmet · 1 chestplate/elytra · 2 leggings · 3 boots · -1 not wearable. */
export function armorSlotOf(name: string): number {
  if (name.endsWith('_helmet')) return 0;
  if (name.endsWith('_chestplate') || name === 'elytra') return 1;
  if (name.endsWith('_leggings')) return 2;
  if (name.endsWith('_boots')) return 3;
  return -1;
}
export const canApply = (e: EnchDef, name: string) => { const kinds = itemKinds(name); return kinds.includes('book') || e.on.some(o => kinds.includes(o)); };
export const lvl = (s: Stack | null | undefined, id: string) => s?.ench?.[id] ?? 0;
export const roman = (n: number) => ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'][n] ?? String(n);
export function enchLabel(id: string, level: number, ja: boolean) { const d = ENCHANT_BY_ID[id]; return d ? (ja ? d.ja : d.en) + (d.max > 1 ? ' ' + roman(level) : '') : id; }
export function describeStack(s: Stack, ja = true): string {
  const def = resolve(s.name);
  const lines = [(s.label ? '“' + s.label + '” ' : '') + (def ? `${def.ja} / ${def.name}` : s.name)];
  for (const [id, l] of Object.entries(s.ench ?? {})) lines.push('✦ ' + enchLabel(id, l, ja));
  if (s.trim) {
    const p = TRIM_PATTERNS.find(x => x.id === s.trim!.pattern);
    const m = TRIM_MATERIALS.find(x => x.id === s.trim!.material);
    lines.push('❖ ' + (ja ? `${p?.ja ?? s.trim.pattern}の装飾 (${m?.ja ?? s.trim.material})` : `${p?.en ?? s.trim.pattern} Trim (${m?.en ?? s.trim.material})`));
  }
  const p = potionEffects(s.name);
  if (p) for (const [id, sec, amp] of p.effects) lines.push('⚗ ' + (ja ? EFFECTS[id]?.ja : EFFECTS[id]?.en) + (amp ? ' ' + roman(amp + 1) : '') + (sec ? ` (${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')})` : ''));
  if (def?.durability && s.durability !== undefined) lines.push(`${Math.max(0, Math.ceil(s.durability))} / ${def.durability}`);
  if (s.bannerBase) lines.push('⚑ ' + s.bannerBase.replace(/_/g, ' ') + ' banner');
  if (s.patterns?.length) for (const l of s.patterns) lines.push('▰ ' + l.c.replace(/_/g, ' ') + ' ' + l.p.replace(/_/g, ' '));
  if (s.sherds?.length) lines.push('🏺 ' + s.sherds.map(sh => sh.replace(/_pottery_sherd$/, '')).join(' · '));
  if (s.mapId !== undefined) lines.push('Map #' + s.mapId);
  if (s.name === 'written_book') lines.push((s.title ? '“' + s.title + '” ' : '') + (s.author ? '— ' + s.author : '') + ` (${['Original', 'Copy of original', 'Copy of a copy', 'Tattered'][s.gen ?? 0] ?? ''})`);
  else if (s.name === 'writable_book' && s.pages?.length) lines.push(`${s.pages.length} page(s)`);
  return lines.join('\n');
}

export function hashStr(s: string) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
export function rng(seed: number) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

export interface EnchantOption { cost: number; level: number; list: [string, number][]; }
function rollEnchants(name: string, level: number, r: () => number): [string, number][] {
  const pool = ENCHANTS.filter(e => !e.treasure && canApply(e, name));
  if (!pool.length) return [];
  let power = Math.max(1, Math.round((level + 1 + Math.floor(r() * 5) + Math.floor(r() * 5)) * (0.85 + r() * 0.3)));
  const out: [string, number][] = [];
  const pickOne = () => {
    const cands = pool.filter(e => !out.some(([id]) => id === e.id || (!!e.excl && ENCHANT_BY_ID[id].excl === e.excl)));
    if (!cands.length) return false;
    let roll = r() * cands.reduce((s, e) => s + e.weight, 0);
    for (const e of cands) {
      roll -= e.weight;
      if (roll <= 0) { out.push([e.id, Math.max(1, Math.min(e.max, Math.ceil(e.max * Math.min(1, power / 30) * (0.7 + r() * 0.5))))]); return true; }
    }
    return false;
  };
  pickOne();
  while (r() < (power + 1) / 50 && out.length < 4) { if (!pickOne()) break; power = Math.floor(power / 2); }
  return out;
}
/** Vanilla-style table: three offers whose level requirements grow with the number of bookshelves (max 15 → level 30). */
export function enchantOptions(name: string, shelves: number, seed: number): EnchantOption[] {
  const kinds = itemKinds(name);
  if (name === 'enchanted_book' || (!kinds.includes('breakable') && name !== 'book')) return [];
  const b = Math.max(0, Math.min(15, shelves)), h = hashStr(name), r = rng(seed * 31 + h);
  const base = 1 + Math.floor(r() * 8) + (b >> 1) + Math.floor(r() * (b + 1));
  const req = [Math.max(1, Math.floor(base / 3)), Math.floor((base * 2) / 3) + 1, Math.max(base, b * 2)];
  return req.map((level, i) => ({ cost: i + 1, level, list: rollEnchants(name, level, rng(seed * 131 + i * 17 + h)) })).filter(o => o.list.length > 0);
}
export function applyEnchants(stack: Stack, list: [string, number][]): Stack {
  const ench = { ...(stack.ench ?? {}) };
  for (const [id, l] of list) ench[id] = Math.max(ench[id] ?? 0, l);
  return stack.name === 'book' ? { name: 'enchanted_book', count: 1, ench } : { ...stack, ench };
}

export function repairMaterial(name: string): string | null {
  if (name === 'elytra') return 'phantom_membrane';
  if (name === 'shield') return 'planks';
  if (name === 'turtle_helmet') return 'scute';
  if (name === 'trident' || name === 'bow' || name === 'crossbow') return null;
  if (name === 'mace') return 'breeze_rod';
  const tier = name.split('_')[0];
  return ({ wooden: 'planks', stone: 'cobblestone', iron: 'iron_ingot', golden: 'gold_ingot', diamond: 'diamond', netherite: 'netherite_ingot', leather: 'leather', chainmail: 'iron_ingot', copper: 'copper_ingot' } as Record<string, string>)[tier] ?? null;
}

/** `cost` already includes the prior work penalty of both inputs; `tooExpensive` = 40 levels or more (survival refuses it). */
export interface AnvilResult { result: Stack; cost: number; useRight: number; tooExpensive: boolean; penalty: number; priorWork: number; }
/** Anvil: repair with material, merge two items, apply an enchanted book and/or rename. Returns null when nothing would change. */
export function anvilCombine(left: Stack | null, right: Stack | null, rename = ''): AnvilResult | null {
  if (!left) return null;
  const def = resolve(left.name);
  if (!def) return null;
  const out: Stack = { ...left, ench: left.ench ? { ...left.ench } : undefined };
  let cost = 0, useRight = 0, changed = false;
  const max = def.durability ?? 0;
  if (right) {
    const mat = repairMaterial(left.name);
    if (max && mat && (right.name === mat || (mat === 'planks' && right.name.endsWith('_planks')))) {
      let d = left.durability ?? max;
      if (d >= max) return null;
      while (d < max && useRight < right.count && useRight < 4) { d = Math.min(max, d + Math.ceil(max / 4)); useRight++; cost++; }
      out.durability = d; changed = true;
    } else if (right.name === 'enchanted_book' || (right.name === left.name && max > 0)) {
      useRight = 1;
      if (right.name === left.name) {
        const cur = left.durability ?? max;
        if (cur < max) { out.durability = Math.min(max, cur + (right.durability ?? max) + Math.floor(max * 0.12)); cost += 2; changed = true; }
      }
      for (const [id, l] of Object.entries(right.ench ?? {})) {
        const e = ENCHANT_BY_ID[id];
        if (!e || !canApply(e, left.name)) continue;
        const ench = (out.ench ??= {});
        if (Object.keys(ench).some(o => o !== id && !!e.excl && ENCHANT_BY_ID[o]?.excl === e.excl)) { cost++; continue; }
        const have = ench[id] ?? 0, next = have === l ? Math.min(e.max, l + 1) : Math.max(have, l);
        if (next !== have) changed = true;
        ench[id] = next;
        const rarity = e.weight >= 10 ? 1 : e.weight >= 5 ? 2 : e.weight >= 2 ? 3 : 4;
        cost += Math.max(1, (next * rarity) >> (right.name === 'enchanted_book' ? 1 : 0));
      }
    } else return null;
  }
  const label = rename.trim().slice(0, 35);
  if (label && label !== (left.label ?? '')) { out.label = label; cost += 1; changed = true; }
  if (!changed) return null;
  if (out.ench && !Object.keys(out.ench).length) delete out.ench;
  // Prior work penalty: each earlier anvil operation makes the item dearer to work on again — RepairCost holds 2^n - 1.
  const leftPenalty = left.repairCost ?? repairCostOf(left), rightPenalty = right && useRight ? (right.repairCost ?? repairCostOf(right)) : 0;
  let total = Math.max(1, cost) + leftPenalty + rightPenalty;
  if (!right) total = Math.min(total, ANVIL_LEVEL_CAP - 1);
  else {
    const nextRc = nextRepairCost(Math.max(leftPenalty, rightPenalty));
    out.tag = { ...(out.tag ?? {}), RepairCost: nextRc };
    out.repairCost = nextRc;
  }
  const penalty = leftPenalty + rightPenalty;
  return { result: out, cost: total, useRight, tooExpensive: total >= ANVIL_LEVEL_CAP, penalty, priorWork: penalty };
}
/** Grindstone: strips non-curse enchantments (refunding XP) and can merge two damaged copies. */
export function grindstone(a: Stack | null, b: Stack | null): { result: Stack; xp: number } | null {
  const strip = (s: Stack): [Stack, number] => {
    let xp = 0; const keep: Record<string, number> = {};
    for (const [id, l] of Object.entries(s.ench ?? {})) { if (ENCHANT_BY_ID[id]?.curse) keep[id] = l; else xp += l * (ENCHANT_BY_ID[id]?.weight >= 5 ? 2 : 4); }
    const out: Stack = s.name === 'enchanted_book' && !Object.keys(keep).length ? { name: 'book', count: 1 } : { ...s };
    if (Object.keys(keep).length) out.ench = keep; else delete out.ench;
    if (out.tag?.RepairCost !== undefined) {
      out.tag = { ...out.tag };
      delete out.tag.RepairCost;
      if (!Object.keys(out.tag).length) delete out.tag;
    }
    delete out.repairCost;
    return [out, xp];
  };
  if (a && b) {
    if (a.name !== b.name) return null;
    const max = resolve(a.name)?.durability;
    if (!max) return null;
    const [sa, xa] = strip(a), [, xb] = strip(b);
    sa.durability = Math.min(max, (a.durability ?? max) + (b.durability ?? max) + Math.floor(max * 0.05));
    return { result: sa, xp: xa + xb };
  }
  const s = a ?? b;
  if (!s || !s.ench || !Object.keys(s.ench).some(id => !ENCHANT_BY_ID[id]?.curse)) return null;
  const [out, xp] = strip(s);
  return { result: out, xp };
}

// ---- Status effects -----------------------------------------------------------------------------------------------------
export interface EffectDef { id: string; ja: string; en: string; color: string; bad?: boolean; }
const F = (id: string, ja: string, en: string, color: string, bad = false): [string, EffectDef] => [id, { id, ja, en, color, bad }];
export const EFFECTS: Record<string, EffectDef> = Object.fromEntries([
  F('speed', '移動速度上昇', 'Speed', '#7cafc6'), F('slowness', '移動速度低下', 'Slowness', '#5a6c81', true), F('haste', '採掘速度上昇', 'Haste', '#d9c043'), F('mining_fatigue', '採掘速度低下', 'Mining Fatigue', '#4a4217', true),
  F('strength', '攻撃力上昇', 'Strength', '#932423'), F('weakness', '弱体化', 'Weakness', '#484d48', true), F('jump_boost', '跳躍力上昇', 'Jump Boost', '#22c94c'), F('regeneration', '再生能力', 'Regeneration', '#cd5cab'),
  F('resistance', '耐性', 'Resistance', '#99453a'), F('fire_resistance', '火炎耐性', 'Fire Resistance', '#e49a3a'), F('water_breathing', '水中呼吸', 'Water Breathing', '#2e5299'), F('invisibility', '透明化', 'Invisibility', '#7f8392'),
  F('blindness', '盲目', 'Blindness', '#1f1f23', true), F('night_vision', '暗視', 'Night Vision', '#3a3ad0'), F('hunger', '空腹', 'Hunger', '#587653', true), F('poison', '毒', 'Poison', '#4e9331', true), F('wither', '衰弱', 'Wither', '#352a27', true),
  F('absorption', '衝撃吸収', 'Absorption', '#2552a5'), F('saturation', '満腹度回復', 'Saturation', '#f82423'), F('levitation', '浮遊', 'Levitation', '#ceffff', true), F('slow_falling', '低速落下', 'Slow Falling', '#d8d9c0'),
  F('darkness', '暗闇', 'Darkness', '#292721', true), F('nausea', '吐き気', 'Nausea', '#551d4a', true), F('instant_health', '即時回復', 'Instant Health', '#f82423'), F('instant_damage', '即時ダメージ', 'Instant Damage', '#430a09', true),
  F('wind_charged', '風チャージ', 'Wind Charged', '#bdc9ff', true), F('infested', '虫食い', 'Infested', '#8c9b8c', true), F('oozing', '滲出', 'Oozing', '#99ffa3', true), F('weaving', '機織り', 'Weaving', '#78695a', true),
  F('bad_omen', '不吉な予感', 'Bad Omen', '#0b6138', true), F('raid_omen', '襲撃の凶兆', 'Raid Omen', '#de4058', true), F('trial_omen', '試練の予兆', 'Trial Omen', '#16a6a6', true), F('conduit_power', 'コンジットパワー', 'Conduit Power', '#1dc2d1'), F('hero_of_the_village', '村の英雄', 'Hero of the Village', '#44ff44'), F('glowing', '発光', 'Glowing', '#94a061'),
]);
type PE = [string, number, number];
const P: Record<string, { base: PE[]; long?: PE[]; strong?: PE[] }> = {
  wind_charged: { base: [['wind_charged', 180, 0]] }, infested: { base: [['infested', 180, 0]] }, oozing: { base: [['oozing', 180, 0]] }, weaving: { base: [['weaving', 180, 0]] },
  swiftness: { base: [['speed', 180, 0]], long: [['speed', 480, 0]], strong: [['speed', 90, 1]] },
  slowness: { base: [['slowness', 90, 0]], long: [['slowness', 240, 0]], strong: [['slowness', 20, 3]] },
  strength: { base: [['strength', 180, 0]], long: [['strength', 480, 0]], strong: [['strength', 90, 1]] },
  healing: { base: [['instant_health', 0, 0]], strong: [['instant_health', 0, 1]] },
  harming: { base: [['instant_damage', 0, 0]], strong: [['instant_damage', 0, 1]] },
  poison: { base: [['poison', 45, 0]], long: [['poison', 90, 0]], strong: [['poison', 21, 1]] },
  regeneration: { base: [['regeneration', 45, 0]], long: [['regeneration', 90, 0]], strong: [['regeneration', 22, 1]] },
  fire_resistance: { base: [['fire_resistance', 180, 0]], long: [['fire_resistance', 480, 0]] },
  water_breathing: { base: [['water_breathing', 180, 0]], long: [['water_breathing', 480, 0]] },
  night_vision: { base: [['night_vision', 180, 0]], long: [['night_vision', 480, 0]] },
  invisibility: { base: [['invisibility', 180, 0]], long: [['invisibility', 480, 0]] },
  leaping: { base: [['jump_boost', 180, 0]], long: [['jump_boost', 480, 0]], strong: [['jump_boost', 90, 1]] },
  slow_falling: { base: [['slow_falling', 90, 0]], long: [['slow_falling', 240, 0]] },
  weakness: { base: [['weakness', 90, 0]], long: [['weakness', 240, 0]] },
  turtle_master: { base: [['slowness', 20, 3], ['resistance', 20, 2]], long: [['slowness', 40, 3], ['resistance', 40, 2]], strong: [['slowness', 20, 5], ['resistance', 20, 3]] },
};
const POTION_RE = /^(potion|splash)_(.+?)(_long|_strong)?$/;
export function potionEffects(name: string): { effects: PE[]; splash: boolean } | null {
  const m = POTION_RE.exec(name);
  if (!m || !P[m[2]]) return null;
  const set = P[m[2]], list = m[3] === '_long' ? set.long : m[3] === '_strong' ? set.strong : set.base;
  if (!list) return null;
  const splash = m[1] === 'splash';
  return { effects: list.map(([id, sec, amp]) => [id, splash ? Math.round(sec * 0.75) : sec, amp] as PE), splash };
}

// ---- Brewing ------------------------------------------------------------------------------------------------------------
const BREW_BASE: Record<string, string> = { breeze_rod: 'wind_charged', stone: 'infested', slime_block: 'oozing', cobweb: 'weaving', sugar: 'swiftness', rabbit_foot: 'leaping', blaze_powder: 'strength', glistering_melon_slice: 'healing', spider_eye: 'poison', ghast_tear: 'regeneration', magma_cream: 'fire_resistance', pufferfish: 'water_breathing', golden_carrot: 'night_vision', phantom_membrane: 'slow_falling', turtle_helmet: 'turtle_master' };
const CORRUPT: Record<string, string> = { swiftness: 'slowness', leaping: 'slowness', healing: 'harming', poison: 'harming', night_vision: 'invisibility' };
export const BREW_INGREDIENTS = new Set([...Object.keys(BREW_BASE), 'nether_wart', 'redstone', 'glowstone_dust', 'gunpowder', 'fermented_spider_eye']);
export const isBottle = (name: string) => name === 'water_bottle' || name === 'potion' || name.endsWith('_potion') || POTION_RE.test(name) && !!POTION_BASES[POTION_RE.exec(name)![2]];
export function brewResult(bottle: string, ing: string): string | null {
  if (bottle === 'water_bottle' || bottle === 'potion') {
    if (ing === 'nether_wart') return 'awkward_potion';
    if (ing === 'fermented_spider_eye') return 'potion_weakness';
    if (ing === 'redstone') return 'mundane_potion';
    if (ing === 'glowstone_dust') return 'thick_potion';
    if (BREW_BASE[ing]) return 'mundane_potion';
    return null;
  }
  if (bottle === 'awkward_potion') return BREW_BASE[ing] ? 'potion_' + BREW_BASE[ing] : null;
  const m = POTION_RE.exec(bottle);
  if (!m) return null;
  const [, kind, family, mod = ''] = m, set = P[family];
  if (!set) return null;
  if (ing === 'gunpowder') return kind === 'potion' ? 'splash_' + family + mod : null;
  if (ing === 'redstone' && !mod && set.long) return `${kind}_${family}_long`;
  if (ing === 'glowstone_dust' && !mod && set.strong) return `${kind}_${family}_strong`;
  if (ing === 'fermented_spider_eye' && CORRUPT[family]) {
    const out = CORRUPT[family], outSet = P[out];
    const nextMod = mod === '_long' && outSet.long ? '_long' : mod === '_strong' && outSet.strong ? '_strong' : '';
    return `${kind}_${out}${nextMod}`;
  }
  return null;
}
