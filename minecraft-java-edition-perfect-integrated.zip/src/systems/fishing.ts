import * as THREE from 'three';
import { ID, resolve } from '../game/data';
import type { Stack } from '../game/types';

/*
 * Unified Fishing System (Record 014 Perfected).
 *
 * Features:
 *  - Arcing bobber with gravity, water surface floating, rain & Lure wait-time reduction (5-30s, -5s/Lure, -20% in rain)
 *  - Wake particles approaching the bobber 2s before the bite, 1.5s bite window with bobber dip & splash
 *  - Vanilla 5x4x5 open-water check for Treasure eligibility (in small pools treasure converts to fish)
 *  - Luck of the Sea category shifting, worn durability on Junk gear, random enchantments on Treasure bows/rods/books
 *  - Vanilla Mob Hooking: bobber in flight can hook a mob; reeling in pulls the hooked mob towards the player (3 durability wear)
 *  - Ground reel costs 2 durability, water reel costs 1 durability
 */

export interface FishHost {
  scene?: THREE.Scene;
  getBlock(x: number, y: number, z: number): number;
  particles: {
    burst(p: THREE.Vector3, c: string, n?: number, power?: number): void;
    drop?(p: THREE.Vector3, n: string, c: number, col: string): void;
  };
  sound(k: string, p?: { x: number; y: number; z: number }): void;
  raining?(): boolean;
  enchant?(item: string, rnd: () => number): Record<string, number> | undefined;
  /** Optional mob hook check: returns a mob entity at `pos` if hit in flight. */
  hookMob?(pos: THREE.Vector3): { group?: THREE.Group; pos?: THREE.Vector3; velocity?: THREE.Vector3 } | null;
  /** Pulls a hooked mob towards `origin`. */
  pullMob?(mob: any, origin: THREE.Vector3): void;
}
export type FishingHost = FishHost;
export type LootKind = 'fish' | 'junk' | 'treasure';
export type BobberMesh = THREE.Mesh & {
  state?: 'flying' | 'floating' | 'biting' | 'grounded' | 'hooked';
  hookedMob?: any;
};

const FISH: [string, number][] = [['cod', 60], ['salmon', 25], ['tropical_fish', 2], ['pufferfish', 13]];
const JUNK: [string, number][] = [
  ['lily_pad', 17], ['leather_boots', 10], ['leather', 10], ['bone', 10], ['string', 5],
  ['fishing_rod', 2], ['bowl', 10], ['stick', 5], ['ink_sac', 1], ['rotten_flesh', 10], ['bamboo', 10],
];
const TREASURE: [string, number][] = [
  ['bow', 1], ['enchanted_book', 1], ['fishing_rod', 1], ['name_tag', 1], ['nautilus_shell', 1], ['saddle', 1],
];

export function lootChances(luck: number): Record<LootKind, number> {
  const l = Math.max(0, Math.min(3, luck));
  const treasure = 0.05 + 0.021 * l;
  const junk = Math.max(0, 0.1 - 0.0195 * l);
  return { treasure, junk, fish: 1 - treasure - junk };
}

function weighted(table: [string, number][], rng: () => number): string {
  const usable = table.filter(([n]) => !!resolve(n));
  const list = usable.length ? usable : table;
  let r = rng() * list.reduce((a, b) => a + b[1], 0);
  for (const [n, w] of list) {
    r -= w;
    if (r <= 0) return n;
  }
  return list[0][0];
}

export function rollLoot(
  luck: number,
  openWater = true,
  rng: () => number = Math.random,
  enchant?: FishHost['enchant'],
): { kind: LootKind; stack: Stack } {
  const c = lootChances(luck), r = rng();
  let kind: LootKind = r < c.treasure ? 'treasure' : r < c.treasure + c.junk ? 'junk' : 'fish';
  if (kind === 'treasure' && !openWater) kind = 'fish';
  const name = weighted(kind === 'fish' ? FISH : kind === 'junk' ? JUNK : TREASURE, rng);
  const stack: Stack = { name, count: 1 };
  const max = resolve(name)?.durability;
  if (kind === 'junk' && max) stack.durability = Math.max(1, Math.floor(max * (0.1 + rng() * 0.8)));
  if (kind === 'treasure' && (name === 'bow' || name === 'fishing_rod' || name === 'enchanted_book')) {
    const ench = enchant?.(name, rng);
    if (ench && Object.keys(ench).length) stack.ench = ench;
  }
  return { kind, stack };
}

export function fishingLoot(random: () => number = Math.random, luck = 0, openWater = true): string {
  return rollLoot(luck, openWater, random).stack.name;
}

export class Fishing {
  bobber: BobberMesh | null = null;
  hookedMob: any = null;
  lastWear = 1;
  lastStack: Stack | null = null;
  lastKind: LootKind | null = null;
  private vel = new THREE.Vector3();
  private floating = false;
  private grounded = false;
  private open = true;
  private wait = 0;
  private bite = 0;
  private lure = 0;
  private age = 0;
  private baseY = 0;
  private line: THREE.Line | null = null;
  private lineGeo = new THREE.BufferGeometry();
  public scene: THREE.Scene;
  public host: FishHost;
  private rng: () => number;

  constructor(sceneOrHost: THREE.Scene | FishHost, hostOrRng?: FishHost | (() => number), rng: () => number = Math.random) {
    if ('getBlock' in sceneOrHost) {
      this.host = sceneOrHost;
      this.scene = sceneOrHost.scene!;
      this.rng = typeof hostOrRng === 'function' ? hostOrRng : rng;
    } else {
      this.scene = sceneOrHost;
      this.host = hostOrRng as FishHost;
      this.rng = rng;
    }
  }

  get active() { return !!this.bobber; }
  get biting() { return this.bite > 0; }
  get phase(): 'casting' | 'waiting' | 'bite' | 'landed' | 'hooked' | undefined {
    if (!this.bobber) return undefined;
    if (this.hookedMob) return 'hooked';
    if (this.bite > 0) return 'bite';
    if (this.grounded) return 'landed';
    if (this.floating) return 'waiting';
    return 'casting';
  }

  /** 5x4x5 around the bobber must be water (lower two layers) and air/water/lily_pad (upper two) for treasure. */
  openWater(p: THREE.Vector3): boolean {
    const bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z);
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        for (let dy = -1; dy <= 0; dy++) {
          if (this.host.getBlock(bx + dx, by + dy, bz + dz) !== ID.water) return false;
        }
        for (let dy = 1; dy <= 2; dy++) {
          const id = this.host.getBlock(bx + dx, by + dy, bz + dz);
          if (id !== 0 && id !== ID.water && id !== ID.lily_pad) return false;
        }
      }
    }
    return true;
  }

  cast(origin: THREE.Vector3, dir: THREE.Vector3, lure = 0) {
    this.remove();
    const m: BobberMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.18, 0.18),
      new THREE.MeshLambertMaterial({ color: '#d93b2b' }),
    );
    m.position.copy(origin).addScaledVector(dir, 0.6);
    m.state = 'flying';
    m.hookedMob = null;
    this.scene.add(m);
    this.bobber = m;
    this.hookedMob = null;
    this.vel.copy(dir).multiplyScalar(14);
    this.vel.y += 2.5;
    this.floating = false;
    this.grounded = false;
    this.open = true;
    this.wait = 0;
    this.bite = 0;
    this.age = 0;
    this.lure = lure;
    this.line = new THREE.Line(this.lineGeo, new THREE.LineBasicMaterial({ color: '#d4d0bd' }));
    this.line.frustumCulled = false;
    this.scene.add(this.line);
    this.host.sound('bow');
  }

  cancel() { this.remove(); }

  reel(luck = 0, playerOrigin?: THREE.Vector3): { caught: { kind: LootKind; stack: Stack } | null; wear: number; xp: number; from: THREE.Vector3; hooked: boolean; hookedMob: any } | null {
    if (!this.bobber) return null;
    const from = this.bobber.position.clone();
    const wasBite = this.bite > 0;
    const wasGround = this.grounded;
    const wasFloating = this.floating;
    const hooked = this.hookedMob;
    const open = this.open;
    this.remove();

    if (hooked) {
      if (playerOrigin) {
        if (this.host.pullMob) this.host.pullMob(hooked, playerOrigin);
        else {
          const targetPos = hooked.pos ?? hooked.group?.position;
          if (targetPos) {
            const pull = playerOrigin.clone().sub(targetPos).multiplyScalar(0.45);
            targetPos.add(pull);
            targetPos.y += 0.4;
            if (hooked.group && hooked.pos) hooked.group.position.copy(hooked.pos);
          }
        }
      }
      this.lastWear = 3;
      this.lastStack = null;
      this.lastKind = null;
      return { caught: null, wear: 3, xp: 0, from, hooked: true, hookedMob: hooked };
    }

    if (wasBite) {
      const rolled = rollLoot(luck, open, this.rng, this.host.enchant);
      const xp = 1 + Math.floor(this.rng() * 6);
      this.host.particles.burst(from, '#9fd3ee', 12, 2.2);
      this.host.sound('water', from);
      this.lastWear = 1;
      this.lastStack = rolled.stack;
      this.lastKind = rolled.kind;
      return { caught: rolled, wear: 1, xp, from, hooked: false, hookedMob: null };
    }

    const wear = wasGround ? 2 : wasFloating ? 1 : 0;
    this.lastWear = wear;
    this.lastStack = null;
    this.lastKind = null;
    return { caught: null, wear, xp: 0, from, hooked: false, hookedMob: null };
  }

  /** Cast or reel. Returns the caught item name (or '' when nothing was caught, null when cast). */
  use(origin: THREE.Vector3, dir: THREE.Vector3, luck = 0, lure = 0): string | null {
    if (this.bobber) {
      const res = this.reel(luck, origin);
      return res?.caught ? res.caught.stack.name : '';
    }
    this.cast(origin, dir, lure);
    return null;
  }

  remove() {
    if (this.bobber) this.scene.remove(this.bobber);
    if (this.line) this.scene.remove(this.line);
    this.bobber = null;
    this.line = null;
    this.hookedMob = null;
    this.floating = false;
    this.grounded = false;
    this.bite = 0;
  }

  private waitTime(lure: number) {
    const rainFactor = this.host.raining?.() ? 0.8 : 1;
    return Math.max(1.2, (5 + this.rng() * 25) * rainFactor - lure * 5);
  }

  private findMobAt(pos: THREE.Vector3, mobs?: () => any[]): any {
    const viaHost = this.host.hookMob?.(pos);
    if (viaHost) return viaHost;
    if (!mobs) return null;
    for (const m of mobs()) {
      const mp = m.pos ?? m.group?.position;
      if (!mp) continue;
      if (Math.hypot(pos.x - mp.x, pos.z - mp.z) < 0.9 && pos.y >= mp.y - 0.4 && pos.y <= mp.y + 1.9) {
        return m;
      }
    }
    return null;
  }

  update(dt: number, rodTip: THREE.Vector3, mobs?: () => any[]) {
    const b = this.bobber;
    if (!b) return;
    this.age += dt;
    if (this.hookedMob) {
      const mp = this.hookedMob.pos ?? this.hookedMob.group?.position;
      if (mp) {
        b.position.copy(mp);
        b.position.y += 0.8;
      }
      b.state = 'hooked';
      b.hookedMob = this.hookedMob;
    } else if (!this.floating) {
      this.vel.y -= 16 * dt;
      b.position.addScaledVector(this.vel, dt);
      const hitMob = this.findMobAt(b.position, mobs);
      if (hitMob) {
        this.hookedMob = hitMob;
        b.state = 'hooked';
        b.hookedMob = hitMob;
        this.vel.set(0, 0, 0);
        this.host.sound('hurt', b.position);
      } else {
        const id = this.host.getBlock(b.position.x, b.position.y, b.position.z);
        if (id === ID.water) {
          this.floating = true;
          this.grounded = false;
          b.state = 'floating';
          let wy = Math.floor(b.position.y) + 0.85;
          while (this.host.getBlock(b.position.x, wy + 0.5, b.position.z) === ID.water) wy += 1;
          this.baseY = wy;
          b.position.y = wy;
          this.open = this.openWater(b.position);
          this.wait = this.waitTime(this.lure);
          this.host.particles.burst(b.position, '#bfe4f5', 8, 1.5);
          this.host.sound('water', b.position);
        } else if (id > 0 || b.position.distanceTo(rodTip) > 40) {
          this.vel.set(0, 0, 0);
          if (id > 0) b.position.y = Math.ceil(b.position.y) + 0.1;
          this.floating = true;
          this.grounded = true;
          b.state = 'grounded';
          this.wait = Infinity;
        }
      }
    } else if (!this.grounded) {
      if (this.bite > 0) {
        this.bite -= dt;
        b.state = 'biting';
        b.position.y = this.baseY - 0.25 + Math.sin(this.bite * 20) * 0.08;
        if (this.bite <= 0) {
          this.wait = this.waitTime(this.lure);
          b.position.y = this.baseY;
          b.state = 'floating';
        }
      } else if (Number.isFinite(this.wait)) {
        this.wait -= dt;
        b.state = 'floating';
        b.position.y = this.baseY + Math.sin(this.age * 3) * 0.03;
        if (this.wait < 2.0 && this.rng() < dt * 6) {
          const a = this.age * 1.2, r = Math.max(0.2, this.wait) * 1.2;
          this.host.particles.burst(new THREE.Vector3(b.position.x + Math.cos(a) * r, this.baseY, b.position.z + Math.sin(a) * r), '#c8e8f5', 2, 0.5);
        }
        if (this.wait <= 0) {
          this.bite = 1.6;
          b.state = 'biting';
          this.host.particles.burst(b.position, '#a8d8f0', 14, 2.5);
          this.host.sound('water', b.position);
        }
      }
    }
    if (b.position.distanceTo(rodTip) > 38) {
      this.remove();
      return;
    }
    if (this.line) {
      this.lineGeo.setFromPoints([rodTip, b.position]);
      this.lineGeo.computeBoundingSphere();
    }
  }

  dispose() { this.remove(); }
}
