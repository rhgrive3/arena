// Banner patterns: Java layers a base colour with up to six dyed patterns (loom), each drawn as a mask over the 20×40 cloth.
// The same renderer feeds the loom preview, inventory icons, held banners/shields, dropped items, and placed banners.
import { canvas } from '../textures/atlas';

export interface BannerLayer { p: string; c: string }
export const BANNER_W = 20, BANNER_H = 40, MAX_BANNER_LAYERS = 6;

const makeCanvas = (w: number, h: number): HTMLCanvasElement => canvas(w, h) as unknown as HTMLCanvasElement;

export const DYE_HEX: Record<string, string> = {
  white: '#f9fffe', orange: '#f9801d', magenta: '#c74ebd', light_blue: '#3ab3da', yellow: '#fed83d', lime: '#80c71f', pink: '#f38baa', gray: '#474f52',
  light_gray: '#9d9d97', cyan: '#169c9c', purple: '#8932b8', blue: '#3c44aa', brown: '#835432', green: '#5e7c16', red: '#b02e26', black: '#1d1d21',
};
export interface PatternDef { id: string; ja: string; en: string; item?: string }
/** Patterns the loom offers; the ones with `item` additionally need that banner-pattern item in the loom (as in Java). */
export const BANNER_PATTERNS: PatternDef[] = [
  { id: 'stripe_bottom', ja: '下端の帯', en: 'Base' }, { id: 'stripe_top', ja: '上端の帯', en: 'Chief' },
  { id: 'stripe_left', ja: '左端の帯', en: 'Pale Dexter' }, { id: 'stripe_right', ja: '右端の帯', en: 'Pale Sinister' },
  { id: 'stripe_center', ja: '縦の帯', en: 'Pale' }, { id: 'stripe_middle', ja: '横の帯', en: 'Fess' },
  { id: 'stripe_downright', ja: '右下がり斜帯', en: 'Bend' }, { id: 'stripe_downleft', ja: '左下がり斜帯', en: 'Bend Sinister' },
  { id: 'small_stripes', ja: '細い縦縞', en: 'Paly' }, { id: 'cross', ja: '斜め十字', en: 'Saltire' }, { id: 'straight_cross', ja: '十字', en: 'Cross' },
  { id: 'triangle_bottom', ja: '下の三角', en: 'Inverted Chevron' }, { id: 'triangle_top', ja: '上の三角', en: 'Chevron' },
  { id: 'triangles_bottom', ja: '下の波形', en: 'Base Indented' }, { id: 'triangles_top', ja: '上の波形', en: 'Chief Indented' },
  { id: 'diagonal_left', ja: '左上の斜め割り', en: 'Per Bend Sinister' }, { id: 'diagonal_right', ja: '右下の斜め割り', en: 'Per Bend Sinister Inverted' },
  { id: 'diagonal_up_left', ja: '左下の斜め割り', en: 'Per Bend Inverted' }, { id: 'diagonal_up_right', ja: '右上の斜め割り', en: 'Per Bend' },
  { id: 'circle', ja: '円', en: 'Roundel' }, { id: 'rhombus', ja: 'ひし形', en: 'Lozenge' },
  { id: 'half_vertical', ja: '左半分', en: 'Per Pale' }, { id: 'half_vertical_right', ja: '右半分', en: 'Per Pale Inverted' },
  { id: 'half_horizontal', ja: '上半分', en: 'Per Fess' }, { id: 'half_horizontal_bottom', ja: '下半分', en: 'Per Fess Inverted' },
  { id: 'border', ja: '縁取り', en: 'Bordure' }, { id: 'gradient', ja: 'グラデーション', en: 'Gradient' }, { id: 'gradient_up', ja: '下からのグラデ', en: 'Base Gradient' },
  { id: 'bricks', ja: 'レンガ模様', en: 'Field Masoned', item: 'field_masoned_banner_pattern' },
  { id: 'curly_border', ja: '波縁', en: 'Bordure Indented', item: 'bordure_indented_banner_pattern' },
  { id: 'creeper', ja: 'クリーパー', en: 'Creeper Charge', item: 'creeper_banner_pattern' },
  { id: 'skull', ja: 'ドクロ', en: 'Skull Charge', item: 'skull_banner_pattern' },
  { id: 'flower', ja: '花', en: 'Flower Charge', item: 'flower_banner_pattern' },
  { id: 'mojang', ja: 'Mojang', en: 'Thing', item: 'mojang_banner_pattern' },
  { id: 'globe', ja: '地球', en: 'Globe', item: 'globe_banner_pattern' },
  { id: 'piglin', ja: 'ピグリン', en: 'Snout', item: 'piglin_banner_pattern' },
];
export const patternDef = (id: string) => BANNER_PATTERNS.find(p => p.id === id);
export const PATTERN_ITEMS = BANNER_PATTERNS.filter(p => p.item).map(p => [p.item!, p.ja] as const);
export const bannerColorOf = (name: string) => name.replace(/_banner$/, '');
/** Appends a layer if the loom rules allow it (max six patterns, special patterns need their item). */
export function addLayer(layers: BannerLayer[] | undefined, pattern: string, dye: string, haveItem?: string): BannerLayer[] | null {
  const def = patternDef(pattern), cur = layers ?? [];
  if (!def || cur.length >= MAX_BANNER_LAYERS || !DYE_HEX[dye]) return null;
  if (def.item && haveItem !== def.item) return null;
  return [...cur, { p: pattern, c: dye }];
}
export function describeLayers(layers?: BannerLayer[]): string {
  return (layers ?? []).map(l => `${l.c.replace(/_/g, ' ')} ${patternDef(l.p)?.en ?? l.p}`).join(' / ');
}

type Ctx = CanvasRenderingContext2D;
const poly = (c: Ctx, pts: number[][]) => { c.beginPath(); pts.forEach(([x, y], i) => (i ? c.lineTo(x, y) : c.moveTo(x, y))); c.closePath(); c.fill(); };
const R = (c: Ctx, x: number, y: number, w: number, h: number) => c.fillRect(x, y, w, h);
const PIX = (c: Ctx, ox: number, oy: number, rows: string[], s = 1) => rows.forEach((row, y) => [...row].forEach((v, x) => { if (v === '1') c.fillRect(ox + x * s, oy + y * s, s, s); }));
/** Draws one pattern mask in the current fill colour on the 20×40 grid. */
export function drawPattern(c: Ctx, id: string, color: string) {
  c.fillStyle = color;
  switch (id) {
    case 'stripe_bottom': R(c, 0, 32, 20, 8); break;
    case 'stripe_top': R(c, 0, 0, 20, 8); break;
    case 'stripe_left': R(c, 0, 0, 5, 40); break;
    case 'stripe_right': R(c, 15, 0, 5, 40); break;
    case 'stripe_center': R(c, 7, 0, 6, 40); break;
    case 'stripe_middle': R(c, 0, 16, 20, 8); break;
    case 'stripe_downright': poly(c, [[0, 0], [7, 0], [20, 30], [20, 40], [13, 40], [0, 10]]); break;
    case 'stripe_downleft': poly(c, [[20, 0], [13, 0], [0, 30], [0, 40], [7, 40], [20, 10]]); break;
    case 'small_stripes': for (const x of [2, 6, 10, 14]) R(c, x, 0, 2, 26); break;
    case 'cross': poly(c, [[0, 0], [6, 0], [20, 32], [20, 40], [14, 40], [0, 8]]); poly(c, [[20, 0], [14, 0], [0, 32], [0, 40], [6, 40], [20, 8]]); break;
    case 'straight_cross': R(c, 7, 0, 6, 40); R(c, 0, 14, 20, 7); break;
    case 'triangle_bottom': poly(c, [[0, 40], [10, 26], [20, 40]]); break;
    case 'triangle_top': poly(c, [[0, 0], [10, 14], [20, 0]]); break;
    case 'triangles_bottom': poly(c, [[0, 40], [5, 32], [10, 40]]); poly(c, [[10, 40], [15, 32], [20, 40]]); poly(c, [[5, 40], [10, 34], [15, 40]]); break;
    case 'triangles_top': poly(c, [[0, 0], [5, 8], [10, 0]]); poly(c, [[10, 0], [15, 8], [20, 0]]); break;
    case 'diagonal_left': poly(c, [[0, 0], [20, 0], [0, 40]]); break;
    case 'diagonal_up_right': poly(c, [[20, 0], [20, 40], [0, 0]]); break;
    case 'diagonal_up_left': poly(c, [[0, 0], [0, 40], [20, 40]]); break;
    case 'diagonal_right': poly(c, [[20, 0], [20, 40], [0, 40]]); break;
    case 'circle': c.beginPath(); c.arc(10, 20, 6, 0, Math.PI * 2); c.fill(); break;
    case 'rhombus': poly(c, [[10, 8], [19, 20], [10, 32], [1, 20]]); break;
    case 'half_vertical': R(c, 0, 0, 10, 40); break;
    case 'half_vertical_right': R(c, 10, 0, 10, 40); break;
    case 'half_horizontal': R(c, 0, 0, 20, 20); break;
    case 'half_horizontal_bottom': R(c, 0, 20, 20, 20); break;
    case 'border': R(c, 0, 0, 20, 2); R(c, 0, 38, 20, 2); R(c, 0, 0, 2, 40); R(c, 18, 0, 2, 40); break;
    case 'curly_border': for (let i = 0; i < 20; i += 4) { R(c, i, 0, 2, 3); R(c, i + 2, 37, 2, 3); } for (let j = 0; j < 40; j += 4) { R(c, 0, j, 3, 2); R(c, 17, j + 2, 3, 2); } R(c, 0, 0, 20, 1); R(c, 0, 39, 20, 1); R(c, 0, 0, 1, 40); R(c, 19, 0, 1, 40); break;
    case 'gradient': { const g = c.createLinearGradient(0, 0, 0, BANNER_H); g.addColorStop(0, color); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; R(c, 0, 0, 20, 40); break; }
    case 'gradient_up': { const g = c.createLinearGradient(0, BANNER_H, 0, 0); g.addColorStop(0, color); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; R(c, 0, 0, 20, 40); break; }
    case 'bricks': for (let r = 0; r < 8; r++) { R(c, 0, r * 5 + 4, 20, 1); for (let x = (r & 1) * 5 + 4; x < 20; x += 10) R(c, x, r * 5, 1, 5); } break;
    case 'creeper': PIX(c, 4, 10, ['11001100', '11001100', '00111100', '00111100', '01111110', '01100110', '01100110'], 1.5); break;
    case 'skull': PIX(c, 4, 10, ['01111110', '11111111', '11011011', '11111111', '01111110', '01011010', '01011010'], 1.5); break;
    case 'flower': c.beginPath(); c.arc(10, 14, 2.5, 0, 7); c.arc(10, 22, 2.5, 0, 7); c.arc(6, 18, 2.5, 0, 7); c.arc(14, 18, 2.5, 0, 7); c.fill(); R(c, 9, 24, 2, 8); break;
    case 'mojang': PIX(c, 3, 14, ['1000001', '1100011', '1010101', '1001001', '1000001'], 2); break;
    case 'globe': c.strokeStyle = color; c.lineWidth = 1.3; c.beginPath(); c.arc(10, 20, 7, 0, 7); c.moveTo(3, 20); c.lineTo(17, 20); c.moveTo(10, 13); c.bezierCurveTo(5, 17, 5, 23, 10, 27); c.moveTo(10, 13); c.bezierCurveTo(15, 17, 15, 23, 10, 27); c.stroke(); break;
    case 'piglin': R(c, 5, 15, 10, 8); c.globalCompositeOperation = 'destination-out'; R(c, 7, 17, 2, 4); R(c, 11, 17, 2, 4); c.globalCompositeOperation = 'source-over'; break;
    default: R(c, 0, 0, 20, 40);
  }
}
/** Paints base colour + every layer (bottom → top) onto a 20×40 area at (ox, oy) scaled by `s`. */
export function paintBanner(c: Ctx, base: string, layers: BannerLayer[] | undefined, s = 1, ox = 0, oy = 0) {
  c.save();
  c.translate(ox, oy); c.scale(s, s);
  c.fillStyle = DYE_HEX[base] ?? '#ffffff';
  c.fillRect(0, 0, BANNER_W, BANNER_H);
  for (const l of layers ?? []) {
    // Each layer is drawn on its own transparent canvas so destructive blending (piglin snout) cannot erase lower layers.
    const tmp = makeCanvas(BANNER_W, BANNER_H);
    const t = tmp.getContext('2d')!;
    drawPattern(t, l.p, DYE_HEX[l.c] ?? '#ffffff');
    c.drawImage(tmp, 0, 0);
  }
  c.restore();
}
const urlCache = new Map<string, string>();
/** PNG data URL of a banner (20×40 × scale) with a pole-less cloth and dark outline; cached per colour/layer combination. */
export function bannerDataUrl(base: string, layers?: BannerLayer[], scale = 2): string {
  const key = `${base}|${(layers ?? []).map(l => l.p + ':' + l.c).join(',')}|${scale}`;
  let url = urlCache.get(key);
  if (!url) {
    const cv = makeCanvas(BANNER_W * scale + 4, BANNER_H * scale + 4);
    const c = cv.getContext('2d')!;
    c.fillStyle = '#2b2118'; c.fillRect(1, 1, cv.width - 2, cv.height - 2);
    paintBanner(c, base, layers, scale, 2, 2);
    url = cv.toDataURL();
    urlCache.set(key, url);
    if (urlCache.size > 300) urlCache.delete(urlCache.keys().next().value as string);
  }
  return url;
}

const shieldCanvasCache = new Map<string, HTMLCanvasElement>();
/** Synthesizes a 24×44 shield canvas with wooden/iron rim and layered banner pattern inside (cached). */
export function bannerShieldCanvas(base: string, layers?: BannerLayer[], isShield = true): HTMLCanvasElement {
  const key = `${isShield ? 'sh' : 'bn'}:${base}|${(layers ?? []).map(l => l.p + ':' + l.c).join(',')}`;
  let cv = shieldCanvasCache.get(key);
  if (!cv) {
    cv = makeCanvas(24, 44);
    const c = cv.getContext('2d')!;
    if (isShield) {
      // Wooden backing + iron studs & rim
      c.fillStyle = '#5c4128';
      c.fillRect(0, 0, 24, 44);
      c.fillStyle = '#8b939b';
      c.fillRect(0, 0, 24, 2);
      c.fillRect(0, 42, 24, 2);
      c.fillRect(0, 0, 2, 44);
      c.fillRect(22, 0, 2, 44);
    } else {
      c.fillStyle = '#3b2b1a';
      c.fillRect(0, 0, 24, 44);
    }
    paintBanner(c, base, layers, 1, 2, 2);
    if (isShield) {
      // Iron rivets on corners
      c.fillStyle = '#c8d0d8';
      for (const [rx, ry] of [[2, 2], [20, 2], [2, 40], [20, 40], [2, 20], [20, 20]]) c.fillRect(rx, ry, 2, 2);
    }
    shieldCanvasCache.set(key, cv);
    if (shieldCanvasCache.size > 200) shieldCanvasCache.delete(shieldCanvasCache.keys().next().value as string);
  }
  return cv;
}
