import { useRef, useState, type CSSProperties, type PointerEvent } from 'react';
import { ArrowUp, Pickaxe, Plus, ChevronsDown, Feather, MousePointer2 } from 'lucide-react';
import type { Engine } from '../game/engine';

/*
 * Touch controls. Every control owns exactly one pointer (pointer capture), so any number of fingers work at once:
 * one thumb on the stick, another looking around on the canvas, and more on jump / mine / use / sneak / the hotbar.
 */
type ButtonEvent = PointerEvent<HTMLButtonElement>;

export function TouchControls({ engine, size, creative }: { engine: Engine; size: number; creative: boolean }) {
  const base = useRef<HTMLDivElement>(null), stickPointer = useRef<number | null>(null), sneakDownAt = useRef(0);
  const [thumb, setThumb] = useState({ x: 0, y: 0 }), [, refresh] = useState(0);
  const input = engine.input, flying = engine.flying;

  const moveStick = (e: PointerEvent) => {
    if (stickPointer.current !== e.pointerId || !base.current) return;
    const r = base.current.getBoundingClientRect(), dx = e.clientX - r.left - r.width / 2, dy = e.clientY - r.top - r.height / 2;
    const max = r.width * 0.34, len = Math.max(max, Math.hypot(dx, dy));
    setThumb({ x: dx / len * max, y: dy / len * max });
    input.setStick(dx, dy, max);
  };
  const releaseStick = (e: PointerEvent) => {
    if (stickPointer.current !== e.pointerId) return;
    stickPointer.current = null;
    setThumb({ x: 0, y: 0 });
    input.setStick(0, 0);
    if (base.current?.hasPointerCapture(e.pointerId)) base.current.releasePointerCapture(e.pointerId);
  };

  /** A button that is "down" exactly as long as its own finger is: other fingers elsewhere never interrupt it. */
  const hold = (on: (e: ButtonEvent) => void, off: (e: ButtonEvent) => void) => ({
    onPointerDown: (e: ButtonEvent) => {
      e.stopPropagation(); e.preventDefault();
      try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* capture is a nicety, not a requirement */ }
      on(e);
    },
    onPointerUp: (e: ButtonEvent) => { e.stopPropagation(); off(e); },
    onPointerCancel: (e: ButtonEvent) => off(e),
    onLostPointerCapture: (e: ButtonEvent) => off(e),
    onContextMenu: (e: { preventDefault(): void }) => e.preventDefault(),
  });

  // Press length is measured with the events' own timestamps, so a dropped frame cannot turn a tap into a long press.
  const sneakOn = (e: ButtonEvent) => { sneakDownAt.current = e.timeStamp || performance.now(); input.sneakHeld = true; refresh(n => n + 1); };
  const sneakOff = (e: ButtonEvent) => {
    if (!sneakDownAt.current) return;
    const quickTap = (e.timeStamp || performance.now()) - sneakDownAt.current < 280;
    sneakDownAt.current = 0;
    input.sneakHeld = false;
    // Flying: descend strictly while the button is held, nothing latches. Walking: a quick tap toggles sneak, a long press is momentary.
    if (engine.flying) input.sneak = false;
    else if (quickTap) input.sneak = !input.sneak;
    refresh(n => n + 1);
  };
  const sneakActive = input.sneakHeld || (!flying && input.sneak);

  return (
    <div className="touch-controls" style={{ '--touch-scale': size } as CSSProperties}>
      <div
        className="joystick"
        ref={base}
        onPointerDown={e => {
          e.stopPropagation(); e.preventDefault();
          if (stickPointer.current !== null) return;
          stickPointer.current = e.pointerId;
          e.currentTarget.setPointerCapture(e.pointerId);
          moveStick(e);
        }}
        onPointerMove={moveStick}
        onPointerUp={releaseStick}
        onPointerCancel={releaseStick}
      >
        <span className="joystick-axis horizontal" /><span className="joystick-axis vertical" />
        <div className="joystick-thumb" style={{ transform: `translate(${thumb.x}px,${thumb.y}px)` }}><span /></div>
        <small>MOVE</small>
      </div>
      <div className="touch-actions">
        <button className="touch-action jump" aria-label={flying ? '上昇' : 'ジャンプ'} {...hold(() => { input.jump = true; }, () => { input.jump = false; })}>
          <ArrowUp size={27} /><span>{flying ? '上昇' : 'ジャンプ'}</span>
        </button>
        <button className="touch-action mine" aria-label="長押しで採掘" {...hold(() => { input.breakHeld = true; }, () => { input.breakHeld = false; })}>
          <Pickaxe size={23} /><span>採掘</span>
        </button>
        <button className="touch-action place" aria-label="設置・使用（長押しで食べる・飲む）" {...hold(() => { input.useHeld = true; engine.use(); }, () => { input.useHeld = false; })}>
          <Plus size={25} /><span>置く</span>
        </button>
        <button className={`touch-action sneak ${sneakActive ? 'active' : ''}`} aria-label={flying ? '押している間だけ下降' : 'スニーク（タップで切替・長押しで一時）'} {...hold(sneakOn, sneakOff)}>
          <ChevronsDown size={22} /><span>{flying ? '下降' : 'スニーク'}</span>
        </button>
        {creative && (
          <button className={`touch-action fly ${flying ? 'active' : ''}`} aria-label="飛行切替" onPointerDown={e => { e.stopPropagation(); e.preventDefault(); engine.action('fly'); refresh(n => n + 1); }}>
            <Feather size={21} /><span>飛行</span>
          </button>
        )}
      </div>
      <div className="touch-look-hint"><MousePointer2 size={13} /> ドラッグで視点移動</div>
    </div>
  );
}
