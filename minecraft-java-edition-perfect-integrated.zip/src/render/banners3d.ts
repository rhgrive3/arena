import { canvas as makeAtlasCanvas } from "../textures/atlas";
import * as THREE from 'three';
import { paintBanner, BANNER_W, BANNER_H, type BannerLayer } from '../systems/banners';
import { getTileTexture } from '../textures/atlas';

/**
 * Placed banners that carry loom patterns: a double-sided cloth plane textured with the real layered pattern (base colour + up to six
 * dyed layers), standing on top of the banner block. Plain banners keep using the ordinary block model.
 */
export class BannerMeshes {
  private meshes = new Map<string, THREE.Mesh>();
  constructor(private scene: THREE.Scene) {}
  set(key: string, x: number, y: number, z: number, base: string, layers: BannerLayer[], yaw: number) {
    this.remove(key);
    const cv = makeAtlasCanvas(BANNER_W * 3, BANNER_H * 3) as unknown as HTMLCanvasElement;
    paintBanner(cv.getContext('2d')!, base, layers, 3);
    const tex = new THREE.CanvasTexture(cv);
    tex.magFilter = THREE.NearestFilter; tex.colorSpace = THREE.SRGBColorSpace;
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 1.8), new THREE.MeshLambertMaterial({ map: tex, side: THREE.DoubleSide }));
    mesh.position.set(x + 0.5, y + 0.95, z + 0.5);
    mesh.rotation.y = yaw;
    this.scene.add(mesh);
    this.meshes.set(key, mesh);
  }
  remove(key: string) {
    const m = this.meshes.get(key);
    if (!m) return;
    this.scene.remove(m);
    (m.material as THREE.MeshLambertMaterial).map?.dispose();
    (m.material as THREE.Material).dispose(); m.geometry.dispose();
    this.meshes.delete(key);
  }
  clear() { for (const k of [...this.meshes.keys()]) this.remove(k); }
  get size() { return this.meshes.size; }
}

/**
 * Dynamic 3D Bedrock Lock Bar renderer for repeaters locked by a side repeater/comparator.
 * Uses a single shared geometry and material across all locked repeaters to avoid extra texture/shader allocations.
 */
export class RepeaterLockMeshes {
  private meshes = new Map<string, THREE.Mesh>();
  private geo = new THREE.BoxGeometry(0.14, 0.16, 0.76);
  private mat: THREE.MeshLambertMaterial | null = null;

  constructor(private scene: THREE.Scene) {}

  private getMat(): THREE.MeshLambertMaterial {
    if (!this.mat) {
      try {
        this.mat = new THREE.MeshLambertMaterial({ map: getTileTexture('bedrock') });
      } catch {
        this.mat = new THREE.MeshLambertMaterial({ color: '#3b3b3b' });
      }
    }
    return this.mat;
  }

  sync(lockedKeys: Iterable<string>, getState: (x: number, y: number, z: number) => number) {
    const active = new Set<string>();
    for (const k of lockedKeys) {
      active.add(k);
      const [x, y, z] = k.split(',').map(Number);
      const state = getState(x, y, z);
      const dir = state & 3, delay = (state >> 2) & 3;
      const off = (9 - delay * 2) / 16;
      let m = this.meshes.get(k);
      if (!m) {
        m = new THREE.Mesh(this.geo, this.getMat());
        this.scene.add(m);
        this.meshes.set(k, m);
      }
      if (dir === 0 || dir === 2) {
        const bx = dir === 0 ? off + 1 / 16 : 1 - (off + 1 / 16);
        m.position.set(x + bx, y + 0.21, z + 0.5);
        m.rotation.y = 0;
      } else {
        const bz = dir === 1 ? off + 1 / 16 : 1 - (off + 1 / 16);
        m.position.set(x + 0.5, y + 0.21, z + bz);
        m.rotation.y = Math.PI / 2;
      }
    }
    for (const [k, m] of [...this.meshes.entries()]) {
      if (!active.has(k)) {
        this.scene.remove(m);
        this.meshes.delete(k);
      }
    }
  }

  clear() {
    for (const m of this.meshes.values()) this.scene.remove(m);
    this.meshes.clear();
  }

  get size() { return this.meshes.size; }
}
