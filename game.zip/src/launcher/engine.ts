/* ──────────────────────────────────────────────────────────────
   Composition engine

   ゲーム名を「左右のガイドと下の罫線にインクの端まで接する」ように組む。
   1. 計測   … 字幅軸(wdth)ごとの送り幅を SVG で、サイドベアリングと
               天地のインク範囲を Canvas で測る。
   2. 求解   … 全タイトルに共通の字幅(62–125)と字間(0–0.12em)を、
               ブロックが幅も高さも使い切る値に二分探索で合わせる。
               余白が大きいときは長い名前から 2 行に折り返す。
               1 列で揃えきれない横長の画面では 2 列に組み替える。
   3. 吸着   … 行の高さを 8px グリッドに丸め、罫線をグリッド線に重ねる。
   ────────────────────────────────────────────────────────────── */

/** SVG user units per em. */
export const EM = 100;

const U = 8; // grid unit (px)
const WDTH_MIN = 62;
const WDTH_MAX = 125;
const WDTH_STEP = 3;
const TRACK_MAX = 0.12; // em
const LINE_GAP = 0.1; // em, between lines of a wrapped title
const DESC_EPS = 0.035; // em, below this a descent is only overshoot
const INK_SIZES = [256, 251, 241, 233, 227, 211, 199, 191]; // canvas measuring sizes (px)
const MIN_INK = 30; // px, smallest average title height before the page scrolls
const LEGIBLE = 34; // px, below this a title is being crushed by its neighbours
const TINY = 18; // px, a single line this small is always wrapped

const STRETCH = [
  ["extra-condensed", 62.5],
  ["condensed", 75],
  ["semi-condensed", 87.5],
  ["normal", 100],
  ["semi-expanded", 112.5],
  ["expanded", 125],
] as const;

/* ── types ─────────────────────────────────────────────────── */

interface InkBox {
  left: number;
  right: number;
  asc: number;
  desc: number;
}

interface LineMetric {
  text: string;
  node: SVGTextElement;
  gaps: number; // letter gaps (code points − 1)
  lastIdx: number; // UTF-16 index of the last character
  last: number[]; // x of the last character's origin, per wdth sample (em)
  lsb: number[]; // left bearing of the first glyph, per stretch stop (em)
  inkR: number[]; // ink right edge of the last glyph from its origin (em)
  asc: number; // ink ascent (em)
  desc: number; // ink descent (em)
}

type Variant = LineMetric[];

export interface Metrics {
  probe: SVGSVGElement;
  /** title → variant (0: one line, 1: wrapped) → lines */
  titles: Variant[][];
}

export interface Env {
  W: number;
  H: number;
  sat: number;
  sar: number;
  sab: number;
  sal: number;
}

export interface RowView {
  h: number;
  pl: number;
  pr: number;
  tw: number;
  th: number;
  vb: string;
  lines: { text: string; x: number; y: number }[];
}

export interface Composition {
  cols: number;
  ml: number;
  mr: number;
  head: number;
  meta: number;
  listH: number;
  colW: number[];
  guides: number[];
  divider: number | null;
  wdth: number;
  trk: number;
  rows: RowView[];
}

interface Geo {
  iw: number;
  ih: number;
  top: number;
  pos: { x: number; y: number }[];
}

interface Fit {
  p: number;
  wdth: number;
  trk: number;
  block: number;
  cap: number;
  /** true when the tallest titles are held down instead of the axes moving */
  held: boolean;
  geos: Geo[];
  heights: number[];
  total: number;
}

interface Frame {
  cols: number;
  ml: number;
  mr: number;
  gutter: number;
  cw: number;
  head: number;
  meta: number;
  air: number;
  listH: number;
  budget: number;
  cap: number;
}

interface Draft {
  f: Frame;
  choice: number[];
  fit: Fit;
  score: number;
}

interface Settled {
  comp: Composition;
  /** some title does not reach the guides */
  loose: boolean;
  score: number;
}

/* ── measuring ─────────────────────────────────────────────── */

function setAxes(el: SVGSVGElement, wdth: number, trk: number) {
  el.style.setProperty("--wdth", wdth.toFixed(3));
  el.style.setProperty("--trk", trk.toFixed(4));
}

function startOfLast(m: LineMetric): number {
  if (m.lastIdx <= 0) return 0;
  try {
    return m.node.getStartPositionOfChar(m.lastIdx).x / EM;
  } catch {
    try {
      return m.node.getSubStringLength(0, m.lastIdx) / EM;
    } catch {
      return 0;
    }
  }
}

const inkCache = new Map<string, InkBox>();

/**
 * Ink bounds of a string, in em, relative to its origin and baseline.
 *
 * Engines may report these rounded outward to whole pixels (and far more
 * coarsely above 256px), so the string is measured at several sizes and the
 * innermost value of each edge is kept: the tightest bound available.
 */
function ink(ctx: CanvasRenderingContext2D, text: string, keyword: string, family: string): InkBox {
  const key = `${keyword}\u0001${family}\u0001${text}`;
  const hit = inkCache.get(key);
  if (hit) return hit;
  const box: InkBox = { left: -Infinity, right: Infinity, asc: Infinity, desc: Infinity };
  for (const size of INK_SIZES) {
    ctx.font = `900 ${keyword} ${size}px ${family}`;
    const m = ctx.measureText(text);
    box.left = Math.max(box.left, -m.actualBoundingBoxLeft / size);
    box.right = Math.min(box.right, m.actualBoundingBoxRight / size);
    box.asc = Math.min(box.asc, m.actualBoundingBoxAscent / size);
    box.desc = Math.min(box.desc, m.actualBoundingBoxDescent / size);
  }
  inkCache.set(key, box);
  return box;
}

/**
 * Measure every candidate line once. `probe` must contain one <text> per
 * line, in title → variant → line order, styled exactly like the real titles.
 */
export function buildMetrics(probe: SVGSVGElement, titles: string[][][]): Metrics {
  const nodes = Array.from(probe.querySelectorAll("text"));
  const family = nodes[0] ? getComputedStyle(nodes[0]).fontFamily : "sans-serif";
  const ctx = document.createElement("canvas").getContext("2d");
  inkCache.clear();
  // Does the canvas follow the width axis through font-stretch keywords?
  let honored = false;
  if (ctx) {
    ctx.font = `900 extra-condensed 200px ${family}`;
    const narrow = ctx.measureText("HHHH").width;
    ctx.font = `900 expanded 200px ${family}`;
    honored = ctx.measureText("HHHH").width > narrow * 1.2;
  }
  let k = 0;

  const out = titles.map((variants) =>
    variants.map((lines) =>
      lines.map((text): LineMetric => {
        const node = nodes[k++];
        const cps = Array.from(text);
        const first = cps[0] ?? "";
        const end = cps[cps.length - 1] ?? "";
        const m: LineMetric = {
          text,
          node,
          gaps: Math.max(0, cps.length - 1),
          lastIdx: text.length - end.length,
          last: [],
          lsb: [],
          inkR: [],
          asc: 0.7,
          desc: 0,
        };
        if (ctx) {
          for (const [keyword] of STRETCH) {
            // Without width support the normal-width bearings are scaled below.
            m.lsb.push(ink(ctx, first, honored ? keyword : "normal", family).left);
            m.inkR.push(ink(ctx, end, honored ? keyword : "normal", family).right);
          }
          const v = ink(ctx, text, "normal", family);
          if (v.asc > 0.2 && Number.isFinite(v.desc)) {
            m.asc = v.asc;
            m.desc = v.desc;
          }
        }
        if (m.lsb.length !== STRETCH.length || m.lsb.some((n) => !Number.isFinite(n))) {
          m.lsb = STRETCH.map(() => 0);
        }
        return m;
      }),
    ),
  );

  const all = out.flat(2);
  for (let x = WDTH_MIN; x <= WDTH_MAX; x += WDTH_STEP) {
    setAxes(probe, x, 0);
    for (const m of all) m.last.push(startOfLast(m));
  }
  // The canvas ignored the width axis: glyphs widen about in proportion to
  // their advance, so scale the normal-width bearings by the measured advance.
  if (ctx && !honored) {
    const adv = (m: LineMetric, from: number, len: number) => {
      try {
        return len > 0 ? m.node.getSubStringLength(from, len) : 0;
      } catch {
        return 0;
      }
    };
    const ends = (m: LineMetric) => {
      const firstLen = Array.from(m.text)[0]?.length ?? 0;
      return [adv(m, 0, firstLen), adv(m, m.lastIdx, m.text.length - m.lastIdx)];
    };
    setAxes(probe, 100, 0);
    const base = all.map(ends);
    STRETCH.forEach(([, x], s) => {
      setAxes(probe, x, 0);
      all.forEach((m, i) => {
        const [a, b] = ends(m);
        if (base[i][0] > 0 && a > 0) m.lsb[s] *= a / base[i][0];
        if (base[i][1] > 0 && b > 0) m.inkR[s] *= b / base[i][1];
      });
    });
  }
  // No usable ink data → fall back to the advance of the last glyph.
  for (const m of all) {
    if (m.inkR.length !== STRETCH.length || m.inkR.some((n) => !Number.isFinite(n) || n <= 0)) {
      let adv = 0.6;
      try {
        adv = m.node.getSubStringLength(m.lastIdx, m.text.length - m.lastIdx) / EM;
      } catch {
        /* keep default */
      }
      m.inkR = STRETCH.map(() => adv);
    }
  }
  return { probe, titles: out };
}

/* ── interpolation ─────────────────────────────────────────── */

function atWdth(arr: number[], x: number): number {
  if (arr.length < 2) return arr[0] ?? 0;
  const t = Math.min(Math.max((x - WDTH_MIN) / WDTH_STEP, 0), arr.length - 1);
  const i = Math.min(Math.floor(t), arr.length - 2);
  return arr[i] + (arr[i + 1] - arr[i]) * (t - i);
}

function atStretch(arr: number[], x: number): number {
  if (x <= STRETCH[0][1]) return arr[0];
  for (let i = 1; i < STRETCH.length; i++) {
    if (x <= STRETCH[i][1]) {
      const a = STRETCH[i - 1][1];
      const b = STRETCH[i][1];
      return arr[i - 1] + ((arr[i] - arr[i - 1]) * (x - a)) / (b - a);
    }
  }
  return arr[arr.length - 1];
}

/* ── geometry of one title (em units) ──────────────────────── */

function geometry(v: Variant, wdth: number, trk: number, exact?: number[]): Geo {
  let iw = 0;
  let y = 0;
  const pos = v.map((ln, j) => {
    const last = exact ? exact[j] : atWdth(ln.last, wdth) + ln.gaps * trk;
    const lsb = atStretch(ln.lsb, wdth);
    iw = Math.max(iw, last + atStretch(ln.inkR, wdth) - lsb);
    if (j > 0) {
      const prev = v[j - 1];
      y += (prev.desc > DESC_EPS ? prev.desc : 0) + LINE_GAP + ln.asc;
    }
    return { x: -lsb, y };
  });
  const tail = v[v.length - 1];
  const top = v[0].asc;
  const ih = top + y + (tail.desc > DESC_EPS ? tail.desc : 0);
  return { iw: Math.max(iw, 0.05), ih: Math.max(ih, 0.05), top, pos };
}

/* ── solving ───────────────────────────────────────────────── */

/** One parameter drives both axes: 0→1 widens the face, 1→2 opens the tracking. */
function axes(p: number) {
  return p <= 1
    ? { wdth: WDTH_MIN + (WDTH_MAX - WDTH_MIN) * p, trk: 0 }
    : { wdth: WDTH_MAX, trk: (p - 1) * TRACK_MAX };
}

const sum = (xs: number[]) => xs.reduce((a, b) => a + b, 0);

/** Height of the stack: rows of `cols` titles, each row as tall as its tallest. */
function stack(heights: number[], cols: number): number {
  let total = 0;
  for (let i = 0; i < heights.length; i += cols) total += Math.max(...heights.slice(i, i + cols));
  return total;
}

/** Every title as wide as the block; the axes move until the stack fits. */
function fit(vs: Variant[], f: Frame): Fit {
  const at = (p: number, block: number): Fit => {
    const { wdth, trk } = axes(p);
    const geos = vs.map((v) => geometry(v, wdth, trk));
    const heights = geos.map((g) => Math.min((block * g.ih) / g.iw, f.cap));
    return { p, wdth, trk, block, cap: f.cap, held: false, geos, heights, total: stack(heights, f.cols) };
  };

  // Width-bound: fully condensed and still room to spare.
  let r = at(0, f.cw);
  if (r.total <= f.budget) return r;

  // Height-bound: fully expanded and still too tall → narrow the block.
  r = at(2, f.cw);
  if (r.total > f.budget) {
    let lo = 0;
    let hi = f.cw;
    for (let i = 0; i < 26; i++) {
      const mid = (lo + hi) / 2;
      if (at(2, mid).total > f.budget) hi = mid;
      else lo = mid;
    }
    return at(2, lo);
  }

  // In between: the block fills width and height exactly.
  let lo = 0;
  let hi = 2;
  for (let i = 0; i < 26; i++) {
    const mid = (lo + hi) / 2;
    if (at(mid, f.cw).total > f.budget) lo = mid;
    else hi = mid;
  }
  return at(hi, f.cw);
}

/**
 * Fully condensed, and the tallest titles held down to a common height.
 * The fairest split when a few very short names would crush the long ones:
 * long names keep the full width, short ones stop growing.
 */
function hold(vs: Variant[], f: Frame): Fit {
  const { wdth, trk } = axes(0);
  const geos = vs.map((v) => geometry(v, wdth, trk));
  const raw = geos.map((g) => (f.cw * g.ih) / g.iw);
  const at = (cap: number) => raw.map((h) => Math.min(h, cap));
  let lo = Math.max(f.cap, 1);
  if (stack(at(lo), f.cols) > f.budget) {
    let hi = lo;
    lo = 0;
    for (let i = 0; i < 26; i++) {
      const mid = (lo + hi) / 2;
      if (stack(at(mid), f.cols) > f.budget) hi = mid;
      else lo = mid;
    }
  }
  const heights = at(lo);
  return { p: 0, wdth, trk, block: f.cw, cap: lo, held: true, geos, heights, total: stack(heights, f.cols) };
}

/**
 * Choose which titles wrap onto two lines.
 *
 * Every combination is tried (there are only a handful) and the one whose
 * smallest title comes out largest wins — as long as the block stays flush,
 * needs no extra tracking, and no wrapped title towers over all the others.
 * Wrapping is there to balance the stack, never to crown a new giant.
 */
function plan(m: Metrics, f: Frame): { choice: number[]; fit: Fit } {
  const n = m.titles.length;
  const pick = (c: number[]) => m.titles.map((t, i) => t[c[i]]);
  const none = m.titles.map(() => 0);
  const base = fit(pick(none), f);

  // A single line too small to read is always wrapped.
  const forced = none.map((_, i) => (m.titles[i].length > 1 && base.heights[i] < TINY ? 1 : 0));
  const free = none
    .map((_, i) => i)
    .filter((i) => m.titles[i].length > 1 && !forced[i])
    .sort((a, b) => base.heights[a] - base.heights[b])
    .slice(0, 5);

  const masks = Array.from({ length: 1 << free.length }, (_, mask) => mask);
  const bits = (mask: number) => free.filter((_, b) => mask & (1 << b)).length;
  masks.sort((a, b) => bits(a) - bits(b));

  let choice = forced;
  let best = sum(forced) > 0 ? fit(pick(forced), f) : base;
  let bestMin = Math.min(...best.heights);
  for (const mask of masks) {
    if (mask === 0) continue;
    const c = forced.slice();
    free.forEach((i, b) => {
      if (mask & (1 << b)) c[i] = 1;
    });
    const ft = fit(pick(c), f);
    if (ft.block < f.cw - 0.5 || ft.p > Math.max(1, base.p + 1e-6)) continue;
    const towers = free.some(
      (i) => c[i] === 1 && n > 1 && ft.heights[i] > 1.25 * Math.max(...ft.heights.filter((_, j) => j !== i)),
    );
    if (towers) continue;
    // More wraps must earn their keep: the smallest title has to gain 8%.
    const min = Math.min(...ft.heights);
    if (min > bestMin * 1.08) {
      choice = c;
      best = ft;
      bestMin = min;
    }
  }

  // The block had to shrink and a title became too small to read: hold the
  // tall ones down instead, and wrap only what legibility demands.
  if (best.block < f.cw - 0.5 && bestMin < LEGIBLE) {
    const must = m.titles.map(() => 0);
    let alt = hold(pick(must), f);
    m.titles.forEach((t, i) => {
      if (t.length > 1 && alt.heights[i] < TINY) must[i] = 1;
    });
    alt = hold(pick(must), f);
    if (Math.min(...alt.heights) > bestMin) return { choice: must, fit: alt };
  }
  return { choice, fit: best };
}

/* ── frame ─────────────────────────────────────────────────── */

function frame(env: Env, n: number, cols: number): Frame {
  const { W, H } = env;
  const base = W < 480 ? 16 : W < 960 ? 24 : W < 1600 ? 32 : 40;
  const padL = Math.max(base, env.sal + 8);
  const padR = Math.max(base, env.sar + 8);
  const gutter = cols > 1 ? base : 0;

  // Content width per cell is a whole number of grid units.
  const inner = W - padL - padR - 2 * gutter * (cols - 1);
  const cw = Math.max(U * 8, Math.floor(inner / (U * cols)) * U);
  const rem = Math.max(0, inner - cw * cols);
  const ml = padL + Math.floor(rem / 2);
  const mr = padR + rem - Math.floor(rem / 2);

  const roomy = W >= 720 && H >= 560;
  const head = 5 * U;
  const meta = roomy ? 5 * U : 4 * U;
  // pause between the meta line and the type
  const air = roomy ? (H >= 960 ? 4 * U : 3 * U) : H >= 520 ? 2 * U : U;
  const foot = (W >= 720 ? 3 * U : 2 * U) + env.sab;

  const rowsN = Math.ceil(n / cols);
  const fixed = rowsN * (meta + air);
  const minList = Math.ceil((fixed + rowsN * MIN_INK) / U) * U;
  const listH = Math.max(minList, Math.floor((H - env.sat - head - foot) / U) * U);
  const budget = listH - fixed;
  const cap = budget * (rowsN > 2 ? 0.46 : rowsN === 2 ? 0.62 : 1);

  return { cols, ml, mr, gutter, cw, head, meta, air, listH, budget, cap };
}

const area = (heights: number[], geos: Geo[]) => sum(heights.map((h, i) => (h * h * geos[i].iw) / geos[i].ih));

function draft(m: Metrics, env: Env, cols: number): Draft {
  const f = frame(env, m.titles.length, cols);
  const { choice, fit: ft } = plan(m, f);
  return { f, choice, fit: ft, score: area(ft.heights, ft.geos) };
}

/* ── settle: exact measurement and grid snapping ───────────── */

const r3 = (n: number) => Math.round(n * 1000) / 1000;

function settle(m: Metrics, env: Env, d: Draft): Settled {
  const { f, choice } = d;
  const n = m.titles.length;
  const vs = m.titles.map((t, i) => t[choice[i]]);

  // Snap row heights to the grid. When rounding overflows, the type is not
  // scaled down (that would pull it off the guides): the fit is solved again
  // for a slightly smaller height, so the block stays flush.
  let ft = d.fit;
  let geos: Geo[] = [];
  let heights: number[] = [];
  let rowH: number[] = [];
  let budget = f.budget;
  let narrow = false;
  let block = f.cw;
  for (let pass = 0; pass < 8; pass++) {
    if (pass > 0) ft = ft.held ? hold(vs, { ...f, budget }) : fit(vs, { ...f, budget });
    // Re-measure at the chosen axes so every edge lands exactly.
    setAxes(m.probe, ft.wdth, ft.trk);
    geos = vs.map((v) => geometry(v, ft.wdth, ft.trk, v.map(startOfLast)));
    // Height-bound (the block is narrower than the guides): end it on a grid line.
    narrow = ft.block < f.cw - 0.5;
    block = narrow ? Math.max(U, Math.floor(ft.block / U) * U) : f.cw;
    heights = geos.map((g) => Math.min((block * g.ih) / g.iw, ft.cap));
    if (narrow) {
      const total = stack(heights, f.cols);
      if (total > budget) heights = heights.map((h) => (h * budget) / total);
    }
    rowH = [];
    for (let i = 0; i < n; i += f.cols) {
      const tallest = Math.max(...heights.slice(i, i + f.cols));
      rowH.push(Math.ceil((f.meta + f.air + tallest) / U - 1e-6) * U);
    }
    const over = sum(rowH) - f.listH;
    if (over <= 0 || budget - over < MIN_INK) break;
    budget -= over;
  }

  // Hand the leftover grid units back as air, one row at a time.
  let spare = Math.round((f.listH - sum(rowH)) / U);
  for (let i = 0; spare > 0; i = (i + 1) % rowH.length, spare--) rowH[i] += U;

  const rows = vs.map((v, i): RowView => {
    const g = geos[i];
    const col = i % f.cols;
    const th = heights[i];
    return {
      h: rowH[Math.floor(i / f.cols)],
      pl: col === 0 ? f.ml : f.gutter,
      pr: col === f.cols - 1 ? f.mr : f.gutter,
      tw: r3((th * g.iw) / g.ih),
      th: r3(th),
      vb: `0 ${r3(-g.top * EM)} ${r3(g.iw * EM)} ${r3(g.ih * EM)}`,
      lines: v.map((ln, j) => ({ text: ln.text, x: r3(g.pos[j].x * EM), y: r3(g.pos[j].y * EM) })),
    };
  });

  const split = f.ml + f.cw + f.gutter;
  const comp: Composition = {
    cols: f.cols,
    ml: f.ml,
    mr: f.mr,
    head: f.head,
    meta: f.meta,
    listH: sum(rowH),
    colW: f.cols === 1 ? [env.W] : [split, env.W - split],
    guides:
      f.cols === 1
        ? // a third guide marks where a height-bound block ends
          [f.ml, f.ml + f.cw, ...(narrow ? [f.ml + block] : [])]
        : [f.ml, f.ml + f.cw, split + f.gutter, split + f.gutter + f.cw],
    divider: f.cols === 1 ? null : split,
    wdth: ft.wdth,
    trk: ft.trk,
    rows,
  };
  return { comp, loose: narrow || ft.held, score: area(heights, geos) };
}

/* ── public ────────────────────────────────────────────────── */

export function compose(m: Metrics, env: Env): Composition {
  const n = m.titles.length;
  // One column whenever it can be set flush between the guides. When the
  // window is too wide for that, the titles go two-up instead of floating.
  const one = settle(m, env, draft(m, env, 1));
  if (n >= 2 && n % 2 === 0 && env.W >= 600) {
    const d2 = draft(m, env, 2);
    if (one.loose || d2.score > one.score * 1.25) {
      const two = settle(m, env, d2);
      if (one.loose ? !two.loose || two.score > one.score : two.score > one.score * 1.25) return two.comp;
    }
  }
  return one.comp;
}

export function readEnv(sheet: HTMLElement, probe: HTMLElement): Env {
  const cs = getComputedStyle(probe);
  const px = (v: string) => parseFloat(v) || 0;
  return {
    W: sheet.clientWidth || document.documentElement.clientWidth,
    H: probe.offsetHeight || window.innerHeight,
    sat: px(cs.paddingTop),
    sar: px(cs.paddingRight),
    sab: px(cs.paddingBottom),
    sal: px(cs.paddingLeft),
  };
}

export async function whenFontsReady(node: Element, sample: string): Promise<void> {
  const fonts = document.fonts;
  if (!fonts || typeof fonts.load !== "function") return;
  const display = getComputedStyle(node).fontFamily;
  const mono = getComputedStyle(document.documentElement).getPropertyValue("--font-mono").trim() || "monospace";
  await Promise.race([
    Promise.allSettled([
      fonts.load(`900 64px ${display}`, sample),
      fonts.load(`400 12px ${mono}`, "INDEX 0123456789"),
    ]),
    new Promise((resolve) => window.setTimeout(resolve, 1500)),
  ]);
}
