/* ──────────────────────────────────────────────────────────────
   Line-break candidates for a title.

   Returns the variants the composition engine may choose from:
     [[one line]]                … cannot be wrapped
     [[one line], [line, line]]  … may wrap when the screen has room
     [[line, line, …]]           … "\n" in the title: fixed by hand
   ────────────────────────────────────────────────────────────── */

const CJK = /[\u3000-\u30ff\u3400-\u9fff\uf900-\ufaff\uff00-\uffef]/;
const NARROW = /[IJ1.,:;!'’\-]/;
const PARTICLE = /^(の|は|が|を|に|で|と|も|へ|や|か|な|ね|よ|から|まで|より|には|では|とは|って)$/;
const NO_LINE_START = /^[ぁぃぅぇぉっゃゅょゎァィゥェォッャュョヮー・、。,.!?!?…〜~)\])」』】0-90-9]/;

const count = (s: string) => Array.from(s).length;

/** Rough visual width, good enough to find the most balanced break. */
function weight(s: string): number {
  let w = 0;
  for (const ch of s) w += CJK.test(ch) ? 2 : ch === " " ? 0.5 : NARROW.test(ch) ? 0.6 : 1;
  return w;
}

interface SegmenterLike {
  segment(input: string): Iterable<{ segment: string }>;
}
type SegmenterCtor = new (locale: string, options: { granularity: "word" }) => SegmenterLike;

/** Japanese has no spaces: split on word boundaries, keeping particles attached. */
function words(text: string): string[] {
  const Segmenter = (Intl as unknown as { Segmenter?: SegmenterCtor }).Segmenter;
  if (!Segmenter) return [text];
  const out: string[] = [];
  for (const { segment } of new Segmenter("ja", { granularity: "word" }).segment(text)) {
    if (out.length > 0 && (PARTICLE.test(segment) || NO_LINE_START.test(segment))) {
      out[out.length - 1] += segment;
    } else {
      out.push(segment);
    }
  }
  return out;
}

function balanced(text: string): string[] | null {
  const cands: [string, string][] = [];

  if (text.includes(" ")) {
    for (let i = text.indexOf(" "); i >= 0; i = text.indexOf(" ", i + 1)) {
      cands.push([text.slice(0, i).trim(), text.slice(i + 1).trim()]);
    }
  } else if (CJK.test(text) && count(text) >= 6) {
    const parts = words(text);
    let head = "";
    for (let i = 0; i < parts.length - 1; i++) {
      head += parts[i];
      cands.push([head, text.slice(head.length)]);
    }
  }

  let best: string[] | null = null;
  let bestScore = Infinity;
  for (const [a, b] of cands) {
    // Never strand a fragment ("9", "II") on its own line.
    if (count(a) < (CJK.test(a) ? 2 : 3) || count(b) < (CJK.test(b) ? 2 : 3)) continue;
    const wa = weight(a);
    const wb = weight(b);
    const score = Math.max(wa, wb) + (wb > wa ? 0.01 : 0);
    if (score < bestScore) {
      bestScore = score;
      best = [a, b];
    }
  }
  return best;
}

export function variantsOf(raw: string): string[][] {
  const text = String(raw ?? "")
    .replace(/[ \t\u3000]+/g, " ")
    .trim();
  if (!text) return [["—"]];

  if (text.includes("\n")) {
    const lines = text
      .split(/\n+/)
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 3);
    return [lines.length ? lines : ["—"]];
  }

  const two = balanced(text);
  return two ? [[text], two] : [[text]];
}
