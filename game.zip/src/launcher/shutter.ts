/* ──────────────────────────────────────────────────────────────
   Shutter — a plate revealed through a clip that opens outward from
   a point (the pointer) and closes back onto a point.

   The clip is driven by two custom properties, so CSS owns the timing
   and an interrupted movement simply continues from where it is.
   ────────────────────────────────────────────────────────────── */

const clamp = (n: number) => Math.min(1, Math.max(0, n));

export class Shutter {
  private el: HTMLElement;
  private closeMs: number;
  private open = false;
  private resting = true;
  private timer = 0;

  constructor(el: HTMLElement, closeMs: number) {
    this.el = el;
    this.closeMs = closeMs;
  }

  /** Open from x (0–1 across the plate). */
  show(x: number) {
    if (this.open) return;
    this.open = true;
    window.clearTimeout(this.timer);
    const el = this.el;
    if (this.resting) {
      // Fully closed: move the (zero-width) slit under the pointer first.
      el.style.transition = "none";
      this.span(x, x);
      void el.offsetWidth;
      el.style.transition = "";
    }
    this.resting = false;
    el.setAttribute("data-on", "");
    this.span(0, 1);
  }

  /** Close onto x (0–1 across the plate). */
  hide(x: number) {
    if (!this.open) return;
    this.open = false;
    this.el.removeAttribute("data-on");
    this.span(x, x);
    this.timer = window.setTimeout(() => {
      if (!this.open) this.resting = true;
    }, this.closeMs + 80);
  }

  /** Close immediately, without motion. */
  reset() {
    window.clearTimeout(this.timer);
    const el = this.el;
    this.open = false;
    this.resting = true;
    el.removeAttribute("data-on");
    el.style.transition = "none";
    this.span(0, 0);
    void el.offsetWidth;
    el.style.transition = "";
  }

  dispose() {
    window.clearTimeout(this.timer);
  }

  private span(from: number, to: number) {
    this.el.style.setProperty("--cl", `${(clamp(from) * 100).toFixed(3)}%`);
    this.el.style.setProperty("--cr", `${((1 - clamp(to)) * 100).toFixed(3)}%`);
  }
}
