import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, FocusEvent, MouseEvent, PointerEvent, Ref } from "react";
import {
  buildMetrics,
  compose,
  readEnv,
  whenFontsReady,
  type Composition,
  type Metrics,
  type RowView,
} from "./engine";
import { Shutter } from "./shutter";
import Loader from "./Loader";
import { variantsOf } from "./wrap";

export interface Game {
  title: string;
  url: string;
  status?: string;
}

type Tone = "live" | "beta" | "wip" | "off" | "plain";

const TONES: Record<string, Tone> = { LIVE: "live", BETA: "beta", WIP: "wip", OFF: "off" };

const ARMED_CLOSE_MS = 420;
const FIRED_CLOSE_MS = 460;

const pad = (n: number, len = 2) => String(n).padStart(len, "0");

/* ── small parts ───────────────────────────────────────────── */

/** Status lamp: an 8px square with one corner cut. */
function Led({ tone }: { tone: Tone }) {
  return (
    <svg className={`led led--${tone}`} viewBox="0 0 8 8" aria-hidden focusable="false">
      {tone === "live" || tone === "plain" ? (
        <path d="M0 0H5.5L8 2.5V8H0Z" fill="currentColor" />
      ) : (
        <>
          <path d="M.5 .5H5.3L7.5 2.7V7.5H.5Z" fill="none" stroke="currentColor" />
          {tone === "beta" && <path d="M0 0L8 8H0Z" fill="currentColor" />}
          {tone === "off" && <path d="M1.2 6.8L6.4 1.6" fill="none" stroke="currentColor" />}
        </>
      )}
    </svg>
  );
}

function Arrow() {
  return (
    <svg className="meta__go" viewBox="0 0 10 10" aria-hidden focusable="false">
      <path d="M1.2 8.8L8.3 1.7M2.6 1.7H8.3V7.4" fill="none" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}

interface PlateProps {
  kind: "base" | "armed" | "fired";
  no: string;
  status: string;
  tone: Tone;
  view: RowView;
  ref?: Ref<HTMLSpanElement>;
}

/** One layer of a row. The three layers are identical in layout, so a clip
    moving across the upper ones inverts the row with a knife edge. */
function Plate({ kind, no, status, tone, view, ref }: PlateProps) {
  return (
    <span ref={ref} className={`plate plate--${kind}`} aria-hidden>
      <span className="meta">
        <span className="meta__idx">{no}</span>
        <span className="meta__stat">
          {kind === "base" ? (
            status && (
              <>
                <Led tone={tone} />
                <span>{status}</span>
              </>
            )
          ) : (
            <span>OPEN</span>
          )}
        </span>
        <Arrow />
      </span>
      <span className="slot" style={{ height: view.th }}>
        <svg
          className="ttl"
          viewBox={view.vb}
          width={view.tw}
          height={view.th}
          preserveAspectRatio="xMinYMax meet"
          focusable="false"
        >
          {view.lines.map((line, j) => (
            <text key={j} x={line.x} y={line.y}>
              {line.text}
            </text>
          ))}
        </svg>
      </span>
    </span>
  );
}

/* ── row ───────────────────────────────────────────────────── */

interface RowProps {
  game: Game;
  index: number;
  view: RowView;
  launching: boolean;
  onArm: (index: number, active: boolean) => void;
  onLaunch: (index: number) => void;
}

function Row({ game, index, view, launching, onArm, onLaunch }: RowProps) {
  const armedRef = useRef<HTMLSpanElement>(null);
  const firedRef = useRef<HTMLSpanElement>(null);
  const st = useRef({
    armed: null as Shutter | null,
    fired: null as Shutter | null,
    hover: false,
    focus: false,
    down: false,
    live: false,
    x: 0,
    t1: 0,
    t2: 0,
  });

  useEffect(() => {
    const s = st.current;
    if (armedRef.current) s.armed = new Shutter(armedRef.current, ARMED_CLOSE_MS);
    if (firedRef.current) s.fired = new Shutter(firedRef.current, FIRED_CLOSE_MS);

    // Coming back with the browser's Back button: start clean.
    const onPageShow = (e: PageTransitionEvent) => {
      if (!e.persisted) return;
      window.clearTimeout(s.t1);
      window.clearTimeout(s.t2);
      s.hover = s.focus = s.down = s.live = false;
      s.armed?.reset();
      s.fired?.reset();
      onArm(index, false);
    };
    window.addEventListener("pageshow", onPageShow);
    return () => {
      window.removeEventListener("pageshow", onPageShow);
      window.clearTimeout(s.t1);
      window.clearTimeout(s.t2);
      s.armed?.dispose();
      s.fired?.dispose();
    };
  }, [index, onArm]);

  const sync = () => {
    const s = st.current;
    onArm(index, s.hover || s.focus || s.down || s.live);
  };

  // Loader closed (cancelled, or back from the next page): release the press.
  useEffect(() => {
    const s = st.current;
    if (launching || !s.live) return;
    window.clearTimeout(s.t1);
    window.clearTimeout(s.t2);
    s.live = false;
    s.fired?.hide(1);
    sync();
  }, [launching]);

  const at = (e: { clientX: number; currentTarget: Element }) => {
    const r = e.currentTarget.getBoundingClientRect();
    return r.width > 0 ? (e.clientX - r.left) / r.width : 0;
  };

  /* Hover (mouse / pen) → ink plate opens from where the pointer came in. */
  const onPointerEnter = (e: PointerEvent<HTMLAnchorElement>) => {
    if (e.pointerType === "touch") return;
    const s = st.current;
    s.hover = true;
    s.armed?.show(at(e));
    sync();
  };

  const onPointerLeave = (e: PointerEvent<HTMLAnchorElement>) => {
    if (e.pointerType === "touch") return;
    const s = st.current;
    const x = at(e);
    s.hover = false;
    if (!s.focus) s.armed?.hide(x);
    if (s.down) {
      s.down = false;
      if (!s.live) s.fired?.hide(x);
    }
    sync();
  };

  /* Press (any pointer) → vermilion plate opens from under the finger. */
  const onPointerDown = (e: PointerEvent<HTMLAnchorElement>) => {
    if (e.button !== 0 || !e.isPrimary) return;
    const s = st.current;
    window.clearTimeout(s.t2);
    s.down = true;
    s.x = at(e);
    s.fired?.show(s.x);
    sync();
  };

  const onPointerUp = (e: PointerEvent<HTMLAnchorElement>) => {
    const s = st.current;
    if (!s.down) return;
    s.down = false;
    const x = at(e);
    // A click normally follows at once and takes over; if it does not
    // (the finger slid away), let go.
    s.t2 = window.setTimeout(() => {
      if (!s.live) s.fired?.hide(x);
      sync();
    }, 90);
  };

  const onPointerCancel = () => {
    const s = st.current;
    if (!s.down) return;
    s.down = false;
    if (!s.live) s.fired?.hide(s.x);
    sync();
  };

  const onClick = (e: MouseEvent<HTMLAnchorElement>) => {
    const s = st.current;
    window.clearTimeout(s.t1);
    window.clearTimeout(s.t2);
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
      // New tab or window: the browser opens the link; only the press is shown.
      s.live = true;
      s.fired?.show(at(e));
      sync();
      s.t1 = window.setTimeout(() => {
        s.live = false;
        s.fired?.hide(1);
        sync();
      }, 760);
      return;
    }
    // Plain press: hand over to the loader, which performs the redirect.
    e.preventDefault();
    s.live = true;
    s.fired?.show(e.detail === 0 ? 0 : at(e));
    sync();
    onLaunch(index);
  };

  /* Keyboard focus → ink plate wipes in from the left, out to the right. */
  const onFocus = (e: FocusEvent<HTMLAnchorElement>) => {
    let visible = true;
    try {
      visible = e.currentTarget.matches(":focus-visible");
    } catch {
      /* older engines: treat every focus as visible */
    }
    if (!visible) return;
    const s = st.current;
    s.focus = true;
    s.armed?.show(0);
    sync();
  };

  const onBlur = () => {
    const s = st.current;
    if (!s.focus) return;
    s.focus = false;
    if (!s.hover) s.armed?.hide(1);
    sync();
  };

  const no = pad(index + 1);
  const status = (game.status ?? "").trim();
  const tone = TONES[status.toUpperCase()] ?? "plain";
  const name = game.title.replace(/\s+/g, " ").trim();
  const plate = { no, status, tone, view };

  return (
    <li
      className="row"
      style={
        {
          height: view.h,
          "--pl": `${view.pl}px`,
          "--pr": `${view.pr}px`,
          "--i": index,
        } as CSSProperties
      }
    >
      <a
        className="cell"
        href={game.url || "#"}
        aria-label={status ? `${no} ${name}(${status})` : `${no} ${name}`}
        draggable={false}
        onPointerEnter={onPointerEnter}
        onPointerLeave={onPointerLeave}
        onPointerDown={onPointerDown}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerCancel}
        onClick={onClick}
        onFocus={onFocus}
        onBlur={onBlur}
      >
        <span className="rule" />
        <Plate kind="base" {...plate} />
        <Plate kind="armed" ref={armedRef} {...plate} />
        <Plate kind="fired" ref={firedRef} {...plate} />
      </a>
    </li>
  );
}

/* ── launcher ──────────────────────────────────────────────── */

interface LauncherProps {
  games: Game[];
  /** Tiny label at the top-left of the sheet. */
  label?: string;
}

export default function Launcher({ games, label = "INDEX" }: LauncherProps) {
  const sheetRef = useRef<HTMLDivElement>(null);
  const envRef = useRef<HTMLDivElement>(null);
  const probeRef = useRef<SVGSVGElement>(null);
  const listRef = useRef<HTMLOListElement>(null);
  const colsRef = useRef(1);

  const [comp, setComp] = useState<Composition | null>(null);
  const [sel, setSel] = useState(0);
  const [launch, setLaunch] = useState<number | null>(null);
  const launchRef = useRef<number | null>(null);

  const titleKey = games.map((g) => g.title).join("\u0001");
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const variants = useMemo(() => games.map((g) => variantsOf(g.title)), [titleKey]);

  /* Measure once the fonts are in, then recompose on every size change. */
  useLayoutEffect(() => {
    const sheet = sheetRef.current;
    const env = envRef.current;
    const probe = probeRef.current;
    if (!sheet || !env || !probe) return;

    let alive = true;
    let raf = 0;
    let metrics: Metrics | null = null;

    const run = () => {
      raf = 0;
      if (!alive || !metrics) return;
      const next = compose(metrics, readEnv(sheet, env));
      colsRef.current = next.cols;
      setComp(next);
    };
    const queue = () => {
      if (!raf) raf = requestAnimationFrame(run);
    };
    const measure = () => {
      if (!alive) return;
      metrics = buildMetrics(probe, variants);
      run();
    };

    const sample = variants.flat(2).join("");
    whenFontsReady(probe.querySelector("text") ?? probe, sample).then(measure);

    const ro = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(queue);
    ro?.observe(sheet);
    ro?.observe(env);
    window.addEventListener("resize", queue);
    window.addEventListener("orientationchange", queue);
    const fonts = document.fonts;
    fonts?.addEventListener?.("loadingdone", measure);

    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      ro?.disconnect();
      window.removeEventListener("resize", queue);
      window.removeEventListener("orientationchange", queue);
      fonts?.removeEventListener?.("loadingdone", measure);
    };
  }, [variants]);

  /* Keys: 1–9 launch directly, arrows / Home / End move the selection. */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey) return;
      if (launchRef.current !== null) return; // the loader owns the keyboard
      const links = Array.from(listRef.current?.querySelectorAll<HTMLAnchorElement>("a.cell") ?? []);
      if (!links.length) return;
      const cur = links.indexOf(document.activeElement as HTMLAnchorElement);
      const last = links.length - 1;
      const cols = colsRef.current;
      let next: number;
      switch (e.key) {
        case "ArrowDown":
          next = cur < 0 ? 0 : Math.min(last, cur + cols);
          break;
        case "ArrowUp":
          next = cur < 0 ? last : Math.max(0, cur - cols);
          break;
        case "ArrowRight":
          next = cur < 0 ? 0 : Math.min(last, cur + 1);
          break;
        case "ArrowLeft":
          next = cur < 0 ? last : Math.max(0, cur - 1);
          break;
        case "Home":
          next = 0;
          break;
        case "End":
          next = last;
          break;
        default: {
          const target = /^[1-9]$/.test(e.key) ? links[Number(e.key) - 1] : undefined;
          if (target && !e.repeat) {
            e.preventDefault();
            target.focus();
            target.click();
          }
          return;
        }
      }
      e.preventDefault();
      links[next]?.focus();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const onArm = useCallback((index: number, active: boolean) => {
    setSel((prev) => (active ? index + 1 : prev === index + 1 ? 0 : prev));
  }, []);

  const onLaunch = useCallback((index: number) => {
    launchRef.current = index;
    setLaunch(index);
  }, []);

  const onCancel = useCallback(() => {
    launchRef.current = null;
    setLaunch(null);
  }, []);

  // Back button restores the page from the cache: close any open loader.
  useEffect(() => {
    const onShow = (e: PageTransitionEvent) => {
      if (e.persisted) onCancel();
    };
    window.addEventListener("pageshow", onShow);
    return () => window.removeEventListener("pageshow", onShow);
  }, [onCancel]);

  const vars = comp
    ? ({
        "--ml": `${comp.ml}px`,
        "--mr": `${comp.mr}px`,
        "--head": `${comp.head}px`,
        "--meta": `${comp.meta}px`,
        "--wdth": comp.wdth.toFixed(3),
        "--trk": comp.trk.toFixed(4),
      } as CSSProperties)
    : undefined;

  return (
    <div ref={sheetRef} className="sheet" style={vars}>
      <h1 className="sr-only">ゲームを選ぶ</h1>
      <div ref={envRef} className="env" aria-hidden />

      {comp?.guides.map((x, i) => (
        <i key={i} className="guide" style={{ left: `calc(${x}px - var(--hair))` }} aria-hidden />
      ))}

      <div className="strip" aria-hidden>
        <span className="strip__l">
          <svg className="mark" viewBox="0 0 8 8" focusable="false">
            <path d="M0 0H5L8 3V8H0Z" fill="currentColor" />
          </svg>
          <span>{label}</span>
        </span>
        <span className="strip__r">
          <span className="ro ro--wide">
            WDTH<b>{comp ? pad(Math.round(comp.wdth), 3) : "---"}</b>
          </span>
          <span className="ro ro--wide">
            TRK<b>{comp ? pad(Math.round(comp.trk * 1000), 3) : "---"}</b>
          </span>
          <span className="ro ro--sel" data-on={sel > 0 ? "" : undefined}>
            SEL
            <b>
              <span key={sel} className="tick">
                {pad(sel)}
              </span>
              /{pad(games.length)}
            </b>
          </span>
        </span>
      </div>

      <nav aria-label="ゲーム一覧">
        {comp && (
          <div className="stack">
            <ol
              ref={listRef}
              className="list"
              style={{ gridTemplateColumns: comp.colW.map((w) => `${w}px`).join(" ") }}
            >
              {games.map((game, i) => (
                <Row
                  key={i}
                  game={game}
                  index={i}
                  view={comp.rows[i]}
                  launching={launch === i}
                  onArm={onArm}
                  onLaunch={onLaunch}
                />
              ))}
            </ol>
            {comp.divider !== null && <i className="vrule" style={{ left: comp.divider - 1 }} aria-hidden />}
            <i
              className="rule rule--end"
              style={{ "--pl": `${comp.ml}px`, "--pr": `${comp.mr}px`, "--i": games.length } as CSSProperties}
              aria-hidden
            />
          </div>
        )}
      </nav>

      {launch !== null && games[launch] && (
        <Loader
          key={launch}
          game={games[launch]}
          no={pad(launch + 1)}
          total={games.length}
          onCancel={onCancel}
        />
      )}

      {/* Measuring bench: never visible, styled exactly like the titles. */}
      <svg ref={probeRef} className="probe" aria-hidden focusable="false">
        {variants.flat(2).map((line, i) => (
          <text key={i} x={0} y={0}>
            {line}
          </text>
        ))}
      </svg>
    </div>
  );
}
