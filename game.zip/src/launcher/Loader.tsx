import { useEffect, useState } from "react";
import type { Game } from "./Launcher";

/* ──────────────────────────────────────────────────────────────
   Loader — a vermilion plate takes the sheet, the bar runs, and the
   browser is sent on to the game's address when it reaches the end.

   RUN   : time for the bar to reach 100%
   HOLD  : time READY stays on screen before the redirect
   MISSING: how long "LINK NOT SET" stays when no address is given
   ────────────────────────────────────────────────────────────── */

const RUN = 2100;
const HOLD = 420;
const MISSING = 1400;

/** Piecewise bar: a quick start, two visible stalls, and a last push. */
const STOPS: ReadonlyArray<readonly [number, number]> = [
  [0, 0],
  [0.26, 29],
  [0.4, 33],
  [0.64, 68],
  [0.78, 74],
  [0.92, 95],
  [1, 100],
];

const LOG: ReadonlyArray<readonly [string, number]> = [
  ["Resolve route", 14],
  ["Handshake", 36],
  ["Fetch assets", 60],
  ["Verify", 84],
  ["Enter", 100],
];

const TICKS = [0, 25, 50, 75, 100];

function curve(k: number): number {
  for (let i = 1; i < STOPS.length; i++) {
    const [x1, y1] = STOPS[i];
    const [x0, y0] = STOPS[i - 1];
    if (k <= x1) return y0 + ((y1 - y0) * (k - x0)) / (x1 - x0);
  }
  return 100;
}

interface LoaderProps {
  game: Game;
  no: string;
  total: number;
  onCancel: () => void;
}

export default function Loader({ game, no, total, onCancel }: LoaderProps) {
  const [pct, setPct] = useState(0);
  const [phase, setPhase] = useState<"run" | "ready" | "missing">("run");

  const href = (game.url ?? "").trim();
  const missing = !href || href === "#";
  const name = game.title.replace(/\s+/g, " ").trim();
  const long = name.length > 12;

  useEffect(() => {
    let raf = 0;
    let timer = 0;
    const t0 = performance.now();

    const tick = (now: number) => {
      const k = Math.min(1, (now - t0) / RUN);
      setPct(Math.floor(curve(k)));
      if (k < 1) {
        raf = requestAnimationFrame(tick);
        return;
      }
      setPct(100);
      if (missing) {
        setPhase("missing");
        timer = window.setTimeout(onCancel, MISSING);
      } else {
        setPhase("ready");
        timer = window.setTimeout(() => {
          window.location.assign(href);
        }, HOLD);
      }
    };

    raf = requestAnimationFrame(tick);

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onCancel();
      }
    };
    window.addEventListener("keydown", onKey);

    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(timer);
      window.removeEventListener("keydown", onKey);
    };
  }, [href, missing, onCancel]);

  const status =
    phase === "ready" ? "Ready" : phase === "missing" ? "Link not set" : pct >= 100 ? "Check" : "Loading";

  return (
    <div className="ld" role="dialog" aria-modal="true" aria-label={`${name} を開いています`} tabIndex={-1}>
      <div className="ld__wipe" aria-hidden />

      <div className="ld__frame">
        <header className="ld__strip">
          <span className="ld__l">
            <svg className="mark" viewBox="0 0 8 8" aria-hidden focusable="false">
              <path d="M0 0H5L8 3V8H0Z" fill="currentColor" />
            </svg>
            <span>Loading</span>
          </span>
          <span className="ld__r">
            {no} / {String(total).padStart(2, "0")}
          </span>
        </header>

        <div className="ld__stage">
          <div className="ld__head">
            <p className="ld__label">Opening route → {no}</p>
            <div className="ld__mask">
              <h2 className="ld__title" data-long={long ? "" : undefined}>
                {name}
              </h2>
            </div>
          </div>

          <ol className="ld__log" aria-hidden>
            {LOG.map(([label, at]) => (
              <li key={label} data-on={pct >= at ? "" : undefined}>
                <span>{label}</span>
                <span className="ld__lead" />
                <span>{pct >= at ? "OK" : "--"}</span>
              </li>
            ))}
          </ol>

          <div className="ld__foot">
            <div className="ld__meter">
              <span className="ld__bar" style={{ transform: `scaleX(${pct / 100})` }} />
              {TICKS.map((t) => (
                <span key={t} className="ld__tick" style={{ left: `${t}%` }} />
              ))}
            </div>
            <div className="ld__row">
              <span className="ld__pct" aria-live="polite">
                {String(pct).padStart(3, "0")}
                <small>%</small>
              </span>
              <span className="ld__status" data-ready={phase !== "run" ? "" : undefined}>
                {status}
              </span>
            </div>
          </div>
        </div>

        <button type="button" className="ld__cancel" onClick={onCancel} autoFocus>
          <span>Cancel</span>
          <kbd>ESC</kbd>
        </button>
      </div>
    </div>
  );
}
