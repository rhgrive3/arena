import Launcher, { type Game } from "./launcher/Launcher";

/* ──────────────────────────────────────────────────────────────
   GAMES — 表示内容はこの配列だけで決まります。ここを書き換えてください。

   title  : ゲーム名。英字でも日本語でも可。
            長さに合わせて文字サイズ・字幅・折り返しは自動で組まれます。
            折り返し位置を固定したいときは "\n" を入れます(例: "PAPER MOON\nRALLY")。
   url    : 押したときの飛び先。
   status : "LIVE" | "BETA" | "WIP" | "OFF"
            (それ以外の文字列を書いた場合も、そのまま表示されます)

   番号(01, 02, …)は並び順から自動で振られます。
   ────────────────────────────────────────────────────────────── */
const GAMES: Game[] = [
  { title: "Nyanko", url: "#", status: "LIVE" },
  { title: "Splatoon", url: "#", status: "LIVE" },
  { title: "Epic BS", url: "#", status: "BETA" },
  { title: "Minecraft", url: "#", status: "WIP" },
];

export default function App() {
  return <Launcher games={GAMES} />;
}
