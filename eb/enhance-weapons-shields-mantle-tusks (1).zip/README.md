# Epic Battle Simulator

A Japanese-language 3D tactical battle simulator built with React, Vite, Three.js, Tailwind CSS v4 and Motion.

The original game engine, 43 deployable unit types, six battlefields and 30 campaign missions are preserved. The interface adds an original cinematic title screen, a campaign browser, a searchable 3D armory, a guided deployment workflow, independent army resets, paid-unit refunds, persistent settings and battle reports.

Original source: [rhgrive3/arena, epic-battle-simulator.zip](https://github.com/rhgrive3/arena/blob/ccr-8f471149-epo70v/epic-battle-simulator.zip).

## Development

```sh
npm install
npm run dev
```

## Verification

```sh
npm run build
npx tsc --noEmit
npx tsx --test tests/simulation.test.ts tests/units.test.ts tests/rendering.test.ts tests/refinements.test.ts tests/effects.test.ts tests/rules.test.ts tests/outland.test.ts tests/deployment-ui.test.ts
npx playwright install --with-deps chromium
npx playwright test
```

The exhaustive campaign balance suite is available separately in `tests/balance.test.ts` and may take several minutes.

## Project Structure

- `src/App.tsx`: title screen, campaign selection, armory, settings and field manual.
- `src/components/GameScreen.tsx`: deployment, combat, pause and results UI.
- `src/components/UnitPortrait.tsx`: portraits and an interactive viewer of the actual game models.
- `src/game/`: original combat, rendering, campaign, terrain and procedural audio systems.
- `src/index.css`: responsive visual system and reduced-motion support.
- `tests/ui.spec.ts`: browser-level interaction and responsive checks.

3D gameplay requires WebGL 2. Game progress and settings are stored locally in the browser. Audio is off by default and can be enabled from the header or settings.
## Character wardrobe

Unit costumes live in `src/game/wardrobe.ts` (`dressUp`, `dressRider`, `detailTorso`, `detailHead`) and are built from the shared sculpting kit in `src/game/rig-kit.ts`. Every piece is authored in the local space of a bone (torso, upper arm, thigh, shin or head) so it follows the animation, and `addFace()` in `rigs.ts` is never touched: head accessories only occupy the crown, the sides and the back of the head.

Verification helpers:

```sh
npx tsx tools/rig-stats.ts                 # baked parts / vertices / triangles per unit
npx tsx tools/render-sheet.ts out/ [kinds]  # software-rendered front / 3-4 / side / back / walk / attack sheets per faction
ZOOM=2 npx tsx tools/render-sheet.ts out/ paladin,king
```

## Armory (weapons and shields)

Headgear lives in `src/game/headgear.ts`: each helmet or hat is modelled on a real piece (spangenhelm,
Imperial Gallic legionary helmet, sallet, comb morion, kettle hat, burgonet, bascinet, Corinthian and Thracian
helmets, suji-bachi kabuto, crown, mitre, hoods, tricorne, turban, eboshi, wizard's hat, a berserker's wolf pelt,
a shaman's ram skull, a siege sapper's helmet, and proper hair and beards for the troll, giant, zombie, vampire and monk) and built from lathed
shells, flanges and swept crests and feathers.

Weapons, shields, the royal mantle and the mammoth tusks are generated as real geometry in `src/game/armory.ts`
(lathed hilts and hafts, bevelled and tapered blades, wedge-ground axe heads, dished and curved shields with
heraldry, swept bows and tusks). `src/game/weapons.ts` equips every humanoid from that kit. Everything is still
authored in a bone's local space and bakes into the same vertex-coloured batches, so draw calls are unchanged.

```sh
npx tsx tools/check-rigs.ts   # every rig builds, merges and has finite geometry
# WebGL close-ups with the real materials (dev server running on :5173):
#   /tools/preview/index.html?kinds=king,knight&views=0,1.57,3.14&focus=hand&pose=attack&cell=360
```
