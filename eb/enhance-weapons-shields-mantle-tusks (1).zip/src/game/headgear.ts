import * as THREE from "three";
import { GEO, M } from "./units";
import { chargeOutline, finish, frame, headShell, latheZ, put, slab, stud, sweep, torus } from "./armory";
import {
  B, BRASS, GOLD, LEATHER_DARK, PI, STEEL_DARK, STEEL_LIGHT, boneMat, cloth, dark, gildMat, gold, hide, horn, ironMat,
  lacquer, light, plateMat, silk, steel, waxLeather, wool, type HumanKind,
} from "./rig-kit";

/* ============================================================
   Headgear modelled on real pieces: spangenhelm, Imperial Gallic
   legionary helmet, sallet, comb morion, kettle hat, burgonet,
   bascinet, Corinthian helmet, suji-bachi kabuto, crowns, hoods,
   a tricorne, an eboshi and a proper wizard's hat.
   Head space: the skull is ~0.26 wide and ~0.275 tall around the
   origin, the brows sit at y ≈ 0.08 and the face looks down +Z.
   ============================================================ */

type G = THREE.Object3D;
type Mat = THREE.Material;
type V2 = [number, number];
type V3 = [number, number, number];
const smooth = (a: number, b: number, x: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/* ---------------- lathe kit (around +Y, seam at the back) ---------------- */

interface LatheO { seg?: number; phi0?: number; phiLen?: number; sz?: number; sx?: number; warp?: (v: THREE.Vector3) => void; flat?: boolean }
/** Revolves a profile [r, y] around +Y. Walk the profile with the solid on the left (bottom→top along an outside wall). */
function latheY(profile: V2[], o: LatheO = {}): THREE.BufferGeometry {
  const full = o.phiLen === undefined;
  const g = new THREE.LatheGeometry(profile.map(([r, y]) => new THREE.Vector2(Math.max(0, r), y)), o.seg ?? 28, full ? PI : (o.phi0 ?? 0), full ? PI * 2 : o.phiLen);
  if (o.sx || o.sz) g.scale(o.sx ?? 1, 1, o.sz ?? 1);
  if (o.warp) {
    const p = g.attributes.position as THREE.BufferAttribute, v = new THREE.Vector3();
    for (let i = 0; i < p.count; i++) { v.fromBufferAttribute(p, i); o.warp(v); p.setXYZ(i, v.x, v.y, v.z); }
  }
  g.deleteAttribute("normal");
  const merged = mergeSeam(g);
  merged.computeVertexNormals();
  return finish(merged, !!o.flat);
}
/** Welds the duplicated seam vertices of a full lathe so the back of a helmet shades without a crease. */
function mergeSeam(g: THREE.BufferGeometry): THREE.BufferGeometry {
  const p = g.attributes.position as THREE.BufferAttribute, ix = g.index!;
  const key = (i: number) => `${p.getX(i).toFixed(5)},${p.getY(i).toFixed(5)},${p.getZ(i).toFixed(5)}`;
  const first = new Map<string, number>(), remap: number[] = [];
  for (let i = 0; i < p.count; i++) { const k = key(i); if (!first.has(k)) first.set(k, i); remap.push(first.get(k)!); }
  for (let t = 0; t < ix.count; t++) ix.setX(t, remap[ix.getX(t)]);
  return g;
}
/** Thin shell: an outer profile (bottom→top) and an inner one offset inward, joined at the rim. */
function shellProfile(outer: V2[], th: number): V2[] {
  const inner = outer.map(([r, y]) => [Math.max(0, r - th), y - th * 0.6] as V2).reverse();
  const top = inner[0];
  return [[0, top[1]], ...inner.slice(1), outer[0], ...outer];
}
/** A flat band (brim, flange, lame) from a centre-line path walked outward along its top face. */
function ribbon(path: V2[], th: number): V2[] {
  const top = [...path].reverse();
  const bottom = path.map(([r, y]) => [r, y - th] as V2);
  return [...top, ...bottom, top[0]];
}
/** Raised hoop band: r0 → r1 thick, y0 → y1 tall. */
const bandProfile = (r0: number, r1: number, y0: number, y1: number): V2[] => [[r1, y0], [r1, y1], [r0, y1], [r0, y0], [r1, y0]];

/** Studs around a circle of radius r at height y, facing outward. */
function rivets(g: G, mat: Mat, r: number, y: number, n: number, size = 0.016, phi0 = 0, phi1 = PI * 2, sz = 1) {
  const closed = Math.abs(phi1 - phi0 - PI * 2) < 1e-6;
  for (let i = 0; i < n; i++) {
    const a = phi0 + (phi1 - phi0) * (closed ? i / n : n === 1 ? 0.5 : i / (n - 1));
    stud(g, mat, size, Math.sin(a) * r, y, Math.cos(a) * r * sz, 0.6, 0, a);
  }
}
/** A rib running over the skull at azimuth phi, following an outer profile. */
function meridian(g: G, mat: Mat, outer: V2[], phi: number, r: number, o: { lift?: number; sz?: number; from?: number; to?: number } = {}) {
  const lift = o.lift ?? 0.008, sz = o.sz ?? 1;
  const pts = outer.slice(o.from ?? 0, o.to ?? outer.length).map(([rr, y]) => [Math.sin(phi) * (rr + lift), y + lift * 0.5, Math.cos(phi) * (rr + lift) * sz] as V3);
  put(g, sweep(pts, () => r, { seg: 16, radial: 5, squash: 0.55 }), mat);
}
/** Curved feather: a flattened leaf swept along a path, with a darker quill. `wide` is the vane plane's in-plane axis. */
function feather(g: G, pts: V3[], w: number, mat: Mat, wide: V3, quill?: Mat) {
  put(g, sweep(pts, t => w * Math.pow(Math.sin(PI * Math.min(1, t * 1.05 + 0.04)), 0.6) + 0.004, { seg: 18, radial: 6, squash: 0.14, wide }), mat);
  if (quill) put(g, sweep(pts, t => 0.008 * (1 - t * 0.7), { seg: 12, radial: 4 }), quill);
}
/** Horsehair crest standing on the skull, front to back, with a tail. */
function crest(g: G, pts: V3[], h: number, mat: Mat, tip?: Mat) {
  put(g, sweep(pts, t => h * (0.5 + 0.5 * Math.sin(PI * Math.min(1, t * 1.2))) * (1 - 0.35 * t), { seg: 30, radial: 8, squash: 0.3, wide: [0, 1, 0] }), mat);
  if (tip) put(g, sweep(pts.map(([x, y, z]) => [x, y + h * 0.42, z] as V3), t => h * 0.32 * Math.sin(PI * t), { seg: 22, radial: 6, squash: 0.36, wide: [0, 1, 0] }), tip);
}

/* ---------------- shared skull profiles ---------------- */

const ROUND: V2[] = [[0.3, 0.07], [0.305, 0.15], [0.29, 0.24], [0.245, 0.32], [0.17, 0.37], [0.08, 0.395], [0, 0.4]];
const CONICAL: V2[] = [[0.292, 0.075], [0.297, 0.13], [0.282, 0.22], [0.242, 0.32], [0.172, 0.42], [0.092, 0.5], [0.022, 0.55], [0, 0.56]];
const GOTHIC: V2[] = [[0.29, 0.1], [0.296, 0.17], [0.272, 0.27], [0.215, 0.36], [0.125, 0.43], [0.035, 0.465], [0, 0.47]];

/* ---------------- the pieces ---------------- */

export interface HeadCtx { tc: number; tcd: number; tcl: number; skin: number }

/** Norman spangenhelm: a conical riveted framework with a nasal, a mail drape and a dyed horsetail from the finial. */
function spangenhelm(g: G, c: HeadCtx) {
  const st = steel(0xa3acba), br = gold(BRASS);
  put(g, latheY(shellProfile(CONICAL, 0.022), { sz: 1.06 }), st);
  put(g, latheY(bandProfile(0.29, 0.31, 0.06, 0.135), { sz: 1.06 }), br);
  rivets(g, steel(STEEL_DARK), 0.312, 0.1, 12, 0.014, 0, PI * 2, 1.06);
  for (const a of [PI / 4, 3 * PI / 4, -PI / 4, -3 * PI / 4]) {
    meridian(g, br, CONICAL, a, 0.018, { sz: 1.06, from: 1 });
    for (let k = 0; k < 3; k++) { const [r, y] = CONICAL[2 + k]; stud(g, steel(STEEL_DARK), 0.012, Math.sin(a) * (r + 0.02), y, Math.cos(a) * (r + 0.02) * 1.06, 0.6, 0, a); }
  }
  // Nasal bar riveted to the brow band, standing proud of the nose.
  put(g, slab([[-0.034, 0.13], [0.034, 0.13], [0.026, -0.02], [0.02, -0.09], [-0.02, -0.09], [-0.026, -0.02]], 0.022, { orient: "front", bevel: 0.006 }), st, 0, 0, 0.33, -0.12, 0, 0);
  stud(g, steel(STEEL_DARK), 0.012, 0, 0.1, 0.345, 0.6);
  put(g, latheY([[0, 0.53], [0.03, 0.54], [0.035, 0.575], [0.02, 0.6], [0, 0.61]], { seg: 10 }), br);
  put(g, sweep([[0, 0.6, -0.02], [0, 0.66, -0.12], [0, 0.6, -0.28], [0, 0.44, -0.4], [0.01, 0.2, -0.46], [0.02, 0.0, -0.46]], t => 0.05 * (1 - t * 0.55) + 0.012 * Math.sin(t * 24), { seg: 28, radial: 7, squash: 0.55, wide: [1, 0, 0] }), cloth(c.tc));
}

/** Imperial Gallic legionary helmet: brow guard, wide neck guard, hinged cheek pieces and a team-coloured crest. */
function legionary(g: G, c: HeadCtx) {
  const st = plateMat(0xc6ced9), br = gold(BRASS);
  put(g, latheY(shellProfile(ROUND, 0.022), { sz: 1.06 }), st);
  put(g, latheY(ribbon([[0.3, 0.145], [0.34, 0.14]], 0.03), { phi0: -1.35, phiLen: 2.7, sz: 1.08 }), br);
  put(g, latheY(ribbon([[0.29, 0.1], [0.34, 0.03], [0.42, -0.03], [0.45, -0.035]], 0.022), { phi0: PI / 2 + 0.35, phiLen: PI - 0.7, sz: 1.06 }), st);
  put(g, latheY(bandProfile(0.43, 0.455, -0.06, -0.025), { phi0: PI / 2 + 0.35, phiLen: PI - 0.7, sz: 1.06 }), br);
  // Embossed eyebrows over the brow guard.
  for (const s of [-1, 1]) put(g, sweep([[s * 0.04, 0.2, 0.32], [s * 0.13, 0.215, 0.29], [s * 0.22, 0.2, 0.22]], t => 0.012 * Math.sin(PI * t) + 0.004, { seg: 10, radial: 4 }), br);
  for (const s of [-1, 1]) {
    frame(g, [s * 0.3, 0.07, 0.03], [0, s * 0.28, 0], f => {
      put(f, slab([[0.17, 0.0], [0.19, -0.1], [0.15, -0.22], [0.07, -0.29], [-0.04, -0.25], [-0.07, -0.08], [-0.05, 0.0]], 0.026, { bevel: 0.007 }), st);
      put(f, sweep([[0, 0.0, 0.17], [0, -0.1, 0.19], [0, -0.22, 0.15], [0, -0.29, 0.07], [0, -0.25, -0.04]], () => 0.01, { seg: 14, radial: 4 }), br, s * 0.016, 0, 0);
      stud(f, br, 0.03, s * 0.02, -0.12, 0.06, 0.6, 0, s * PI / 2);
    });
    stud(g, br, 0.022, s * 0.315, 0.08, 0.05, 0.6, 0, s * PI / 2);
  }
  put(g, latheY([[0, 0.37], [0.05, 0.37], [0.045, 0.43], [0, 0.44]], { seg: 10 }), br);
  crest(g, [[0, 0.42, 0.25], [0, 0.55, 0.13], [0, 0.58, -0.04], [0, 0.53, -0.21], [0, 0.4, -0.33], [0, 0.26, -0.38]], 0.12, cloth(c.tc), cloth(c.tcl));
}

/** Gothic sallet: a ridged skull sweeping into a long tail, a slight flare over the brow and a feathered plume. */
function sallet(g: G, c: HeadCtx) {
  const st = plateMat(0xc0c8d4), br = gold(BRASS);
  put(g, latheY(shellProfile(ROUND, 0.022), { sz: 1.08 }), st);
  put(g, latheY(ribbon([[0.29, 0.09], [0.34, 0.02], [0.42, -0.05], [0.5, -0.09]], 0.022), { phi0: PI / 2 + 0.15, phiLen: PI - 0.3, sz: 1.3 }), st);
  put(g, latheY(ribbon([[0.295, 0.085], [0.335, 0.07]], 0.02), { phi0: -PI / 2 - 0.15, phiLen: PI + 0.3, sz: 1.08 }), st);
  put(g, sweep([[0, 0.15, 0.335], [0, 0.3, 0.27], [0, 0.4, 0.05], [0, 0.39, -0.12], [0, 0.3, -0.3], [0, 0.1, -0.44], [0, -0.04, -0.6]], () => 0.016, { seg: 30, radial: 5, squash: 0.6 }), steel(STEEL_LIGHT));
  rivets(g, br, 0.3, 0.12, 9, 0.014, -2.2, 2.2, 1.08);
  put(g, latheZ([[0, -0.05], [0.022, -0.05], [0.02, 0.05], [0, 0.05]], 6), br, 0, 0.36, -0.2, -0.9, 0, 0);
  feather(g, [[0, 0.37, -0.2], [0.02, 0.56, -0.3], [0.04, 0.64, -0.52], [0.05, 0.54, -0.74]], 0.09, cloth(c.tc), [0, 1, 0], cloth(c.tcd));
  feather(g, [[0.04, 0.37, -0.2], [0.09, 0.5, -0.3], [0.13, 0.54, -0.5], [0.15, 0.46, -0.62]], 0.07, cloth(0xf6f3ea), [0, 1, 0]);
  feather(g, [[-0.04, 0.37, -0.2], [-0.09, 0.5, -0.3], [-0.13, 0.54, -0.5], [-0.15, 0.46, -0.62]], 0.07, cloth(0xf6f3ea), [0, 1, 0]);
}

/** Comb morion: a tall comb, a boat-shaped brim rising to points front and back, brass rivets and a side plume. */
function morion(g: G, c: HeadCtx) {
  const st = plateMat(0xb9c2ce), br = gold(BRASS);
  const sk: V2[] = [[0.285, 0.07], [0.29, 0.15], [0.27, 0.24], [0.22, 0.31], [0.14, 0.355], [0.06, 0.37], [0, 0.372]];
  put(g, latheY(shellProfile(sk, 0.02), { sz: 1.12 }), st);
  const comb: V2[] = [];
  for (let i = 0; i <= 14; i++) { const a = (i / 14) * PI; comb.push([Math.cos(a) * 0.3, 0.26 + Math.sin(a) * 0.27]); }
  put(g, slab(comb, 0.03, { bevel: 0.008 }), st);
  put(g, sweep(comb.slice(1, -1).map(([z, y]) => [0, y + 0.006, z * 1.01] as V3), () => 0.012, { seg: 28, radial: 4 }), br);
  put(g, latheY(ribbon([[0.285, 0.08], [0.35, 0.065], [0.44, 0.06], [0.48, 0.07]], 0.018), {
    sz: 1.12, seg: 40,
    warp: v => { const r = Math.hypot(v.x, v.z / 1.12); const t = smooth(0.285, 0.48, r); v.y += 0.22 * Math.pow(v.z / 0.54, 2) * t; },
  }), st);
  put(g, sweep(Array.from({ length: 33 }, (_, i) => { const a = i / 32 * PI * 2; const z = Math.cos(a) * 0.48 * 1.12; return [Math.sin(a) * 0.48, 0.07 + 0.22 * Math.pow(z / 0.54, 2) + 0.004, z] as V3; }).slice(0, 32), () => 0.012, { closed: true, seg: 64, radial: 4 }), br);
  rivets(g, br, 0.29, 0.11, 12, 0.016, 0, PI * 2, 1.12);
  put(g, latheZ([[0, -0.04], [0.02, -0.04], [0.02, 0.04], [0, 0.04]], 6), br, 0.27, 0.16, -0.05, -0.5, 0, -0.3);
  feather(g, [[0.27, 0.18, -0.06], [0.33, 0.36, -0.16], [0.35, 0.46, -0.36], [0.32, 0.38, -0.56]], 0.085, cloth(c.tc), [0, 1, 0], cloth(c.tcd));
  feather(g, [[0.28, 0.17, -0.04], [0.38, 0.3, -0.12], [0.44, 0.34, -0.32]], 0.065, cloth(c.tcl), [0, 1, 0]);
}

/** Kettle hat: a ridged gothic skull on a broad sloping brim with a rolled edge. */
function kettle(g: G, o: { metal: Mat; trim: Mat; rust?: boolean }) {
  put(g, latheY(shellProfile(GOTHIC, 0.02), { sz: 1.04 }), o.metal);
  put(g, latheY(ribbon([[0.285, 0.115], [0.36, 0.075], [0.44, 0.035], [0.47, 0.025]], 0.016), { sz: 1.04, seg: 36,
    warp: o.rust ? v => { v.y += 0.02 * Math.sin(Math.atan2(v.x, v.z) * 3 + 1) * smooth(0.3, 0.47, Math.hypot(v.x, v.z)); } : undefined }), o.metal);
  put(g, torus(0.47, 0.013, 40), o.trim, 0, 0.022, 0, PI / 2, 0, 0);
  (g.children[g.children.length - 1] as THREE.Mesh).scale.set(1, 1.04, 1);
  put(g, sweep([[0, 0.17, 0.31], [0, 0.32, 0.23], [0, 0.45, 0.06], [0, 0.465, -0.04], [0, 0.4, -0.2], [0, 0.22, -0.3]], () => 0.014, { seg: 24, radial: 5, squash: 0.6 }), o.trim);
  rivets(g, o.trim, 0.296, 0.14, 10, 0.014, 0, PI * 2, 1.04);
}

/** Burgonet: an open helm with a gilded comb, a peak over the eyes, hinged cheek plates and a tall plume. */
function burgonet(g: G, c: HeadCtx) {
  const st = plateMat(0xe8ebf0), gd = gildMat();
  put(g, latheY(shellProfile(ROUND, 0.022), { sz: 1.06 }), st);
  const comb: V2[] = [];
  for (let i = 0; i <= 12; i++) { const a = 0.15 + (i / 12) * (PI - 0.3); comb.push([Math.cos(a) * 0.32, 0.3 + Math.sin(a) * 0.15]); }
  put(g, slab(comb, 0.026, { bevel: 0.007 }), st);
  put(g, sweep(comb.map(([z, y]) => [0, y + 0.005, z] as V3), () => 0.012, { seg: 24, radial: 4 }), gd);
  put(g, latheY(ribbon([[0.295, 0.11], [0.35, 0.1], [0.41, 0.095]], 0.018), { phi0: -1.15, phiLen: 2.3, sz: 1.08 }), st);
  put(g, latheY(bandProfile(0.4, 0.42, 0.075, 0.1), { phi0: -1.15, phiLen: 2.3, sz: 1.08 }), gd);
  put(g, latheY(ribbon([[0.29, 0.09], [0.35, 0.02], [0.41, -0.02]], 0.02), { phi0: PI / 2 + 0.5, phiLen: PI - 1.0, sz: 1.06 }), st);
  put(g, latheY(bandProfile(0.3, 0.315, 0.1, 0.14), { sz: 1.06 }), gd);
  for (const s of [-1, 1]) {
    frame(g, [s * 0.3, 0.08, 0.02], [0, s * 0.3, 0], f => {
      put(f, slab([[0.16, 0.0], [0.17, -0.12], [0.12, -0.24], [0.04, -0.28], [-0.05, -0.2], [-0.06, 0.0]], 0.024, { bevel: 0.007 }), st);
      put(f, sweep([[0, 0, 0.16], [0, -0.12, 0.17], [0, -0.24, 0.12], [0, -0.28, 0.04], [0, -0.2, -0.05]], () => 0.01, { seg: 14, radial: 4 }), gd, s * 0.014, 0, 0);
      stud(f, gd, 0.028, s * 0.018, -0.12, 0.05, 0.6, 0, s * PI / 2);
    });
    // Gilt scrolls on the skull.
    put(g, sweep([[s * 0.26, 0.17, 0.16], [s * 0.28, 0.24, 0.02], [s * 0.24, 0.29, -0.12], [s * 0.2, 0.26, -0.2]], t => 0.009 * (1 - t * 0.5), { seg: 12, radial: 4 }), gd);
  }
  put(g, latheZ([[0, -0.05], [0.024, -0.05], [0.024, 0.05], [0, 0.05]], 6), gd, 0, 0.36, -0.22, -0.7, 0, 0);
  feather(g, [[0, 0.38, -0.22], [0, 0.62, -0.24], [0, 0.76, -0.4], [0, 0.66, -0.62]], 0.1, cloth(0xf6f3ea), [0, 1, 0], cloth(0xd8d2c0));
  feather(g, [[0.04, 0.37, -0.22], [0.09, 0.56, -0.3], [0.13, 0.62, -0.5], [0.14, 0.52, -0.64]], 0.08, cloth(c.tc), [0, 1, 0]);
  feather(g, [[-0.04, 0.37, -0.22], [-0.09, 0.56, -0.3], [-0.13, 0.62, -0.5], [-0.14, 0.52, -0.64]], 0.08, cloth(c.tc), [0, 1, 0]);
}

/** Royal crown over a velvet cap: ermine band, jewelled circlet, fleurons, pearled arches, orb and cross. */
function crown(g: G) {
  const gd = gildMat(), pearl = M(0xf6f1e6, 0.3, 0.1);
  put(g, latheY([[0, 0.12], [0.27, 0.12], [0.272, 0.2], [0.25, 0.3], [0.19, 0.38], [0.1, 0.42], [0, 0.43]]), silk(0x8a1c28));
  put(g, torus(0.305, 0.045, 36), wool(0xf7f4eb), 0, 0.1, 0, PI / 2, 0, 0);
  for (let i = 0; i < 14; i++) { const a = (i / 14) * PI * 2; stud(g, B(0x1c1816), 0.014, Math.sin(a) * 0.35, 0.1 + (i % 2 ? 0.015 : -0.012), Math.cos(a) * 0.35, 0.6, 0, a); }
  put(g, latheY(bandProfile(0.3, 0.318, 0.13, 0.215)), gd);
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * PI * 2;
    stud(g, B(i % 2 ? 0x2a6ad8 : 0xd0283a), i % 2 ? 0.024 : 0.028, Math.sin(a) * 0.322, 0.172, Math.cos(a) * 0.322, 0.7, 0, a);
    for (const y of [0.138, 0.207]) for (const d of [-0.12, 0.12]) stud(g, pearl, 0.009, Math.sin(a + d) * 0.32, y, Math.cos(a + d) * 0.32, 0.8, 0, a + d);
  }
  const fleur = chargeOutline("fleur");
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * PI * 2;
    frame(g, [Math.sin(a) * 0.31, 0.3, Math.cos(a) * 0.31], [0, a, 0], f => {
      for (const o of fleur) put(f, slab(o.map(([u, v]) => [u * 0.085, v * 0.085] as V2), 0.022, { orient: "front", bevel: 0.005 }), gd);
    });
    const b = a + PI / 4;
    frame(g, [Math.sin(b) * 0.31, 0.215, Math.cos(b) * 0.31], [0, b, 0], f => {
      put(f, slab([[-0.04, 0], [0.04, 0], [0.012, 0.08], [0, 0.1], [-0.012, 0.08]], 0.02, { orient: "front", bevel: 0.004 }), gd);
      stud(f, pearl, 0.02, 0, 0.11, 0, 1);
    });
  }
  for (const a of [0, PI / 2]) {
    const pts: V3[] = [];
    for (let i = 0; i <= 12; i++) {
      const t = i / 12, ang = lerp(-PI / 2, PI / 2, t);
      const r = Math.cos(ang) * 0.3, y = 0.215 + Math.sin(Math.abs(ang) < PI / 2 ? (PI / 2 - Math.abs(ang)) : 0) * 0.26 * 1;
      pts.push([Math.sin(a) * r * Math.sign(ang || 1) * (ang < 0 ? -1 : 1) * (ang < 0 ? -1 : 1), y, Math.cos(a) * r * (ang < 0 ? -1 : 1)]);
    }
    const arch: V3[] = [];
    for (let i = 0; i <= 14; i++) {
      const t = i / 14, th = lerp(-PI / 2, PI / 2, t);
      const r = 0.3 * Math.sin(th), y = 0.215 + 0.27 * Math.cos(th) * (1 - 0.15 * Math.cos(th));
      arch.push([Math.sin(a) * r, y, Math.cos(a) * r]);
    }
    put(g, sweep(arch, () => 0.02, { seg: 30, radial: 6, squash: 0.6 }), gd);
    for (let i = 2; i <= 12; i += 2) { const p = arch[i]; stud(g, pearl, 0.013, p[0] * 1.06, p[1] + 0.02, p[2] * 1.06, 1); }
    void pts;
  }
  put(g, GEO.sph, gd, 0, 0.52, 0, 0, 0, 0, 0.055);
  put(g, torus(0.056, 0.008, 14), gold(), 0, 0.52, 0, PI / 2, 0, 0);
  put(g, slab([[-0.014, 0.56], [0.014, 0.56], [0.014, 0.68], [-0.014, 0.68]], 0.02, { orient: "front", bevel: 0.004 }), gd);
  put(g, slab([[-0.045, 0.615], [0.045, 0.615], [0.045, 0.64], [-0.045, 0.64]], 0.02, { orient: "front", bevel: 0.004 }), gd);
}

/** Bascinet: a skull drawn up into a rearward point, a mail aventail around the face and shoulders, and a plume. Used by the mounted knight. */
export function bascinet(g: G, c: HeadCtx) {
  const st = plateMat(0xc0c8d4), br = gold(BRASS);
  const sk: V2[] = [[0.3, 0.06], [0.305, 0.14], [0.29, 0.24], [0.245, 0.33], [0.17, 0.42], [0.08, 0.49], [0, 0.52]];
  put(g, latheY(shellProfile(sk, 0.022), { sz: 1.06, warp: v => { v.z -= 0.32 * Math.max(0, v.y - 0.16); } }), st);
  put(g, latheY(ribbon([[0.3, 0.075], [0.34, -0.06], [0.36, -0.2], [0.42, -0.32]], 0.02), { phi0: 0.8, phiLen: PI * 2 - 1.6, sz: 1.04 }), ironMat(0x6a7078));
  for (let k = 0; k < 4; k++) put(g, latheY(bandProfile(0.338 + k * 0.016, 0.348 + k * 0.016, -0.04 - k * 0.07, -0.03 - k * 0.07), { phi0: 0.8, phiLen: PI * 2 - 1.6, sz: 1.04 }), ironMat(0x4e545c));
  put(g, latheY(bandProfile(0.415, 0.432, -0.34, -0.31), { phi0: 0.8, phiLen: PI * 2 - 1.6, sz: 1.04 }), br);
  rivets(g, br, 0.306, 0.1, 12, 0.014, 0, PI * 2, 1.06);
  // Brass-edged brow and a pair of rosettes where a visor would hang.
  put(g, latheY(bandProfile(0.304, 0.316, 0.06, 0.09), { sz: 1.06 }), br);
  for (const s of [-1, 1]) { stud(g, br, 0.032, s * 0.31, 0.07, 0.02, 0.6, 0, s * PI / 2); stud(g, steel(STEEL_DARK), 0.014, s * 0.33, 0.07, 0.02, 0.6, 0, s * PI / 2); }
  feather(g, [[0, 0.43, -0.22], [0.02, 0.62, -0.32], [0.03, 0.68, -0.54], [0.04, 0.56, -0.74]], 0.09, cloth(c.tc), [0, 1, 0], cloth(c.tcd));
  feather(g, [[0.04, 0.42, -0.22], [0.09, 0.56, -0.32], [0.12, 0.58, -0.52]], 0.065, cloth(0xf6f3ea), [0, 1, 0]);
}

/** Bycocket: a felt hat with a beaked front brim, the back turned up, a hat band and a long feather. */
function bycocket(g: G, c: HeadCtx) {
  const felt = M(dark(c.tc, 0.62), 0.92, 0.0);
  put(g, latheY([[0, 0.08], [0.29, 0.08], [0.3, 0.15], [0.28, 0.25], [0.22, 0.32], [0.12, 0.36], [0, 0.37]], { sz: 1.12 }), felt);
  put(g, latheY(ribbon([[0.29, 0.1], [0.38, 0.09], [0.47, 0.08]], 0.018), {
    seg: 40, sz: 1.12,
    warp: v => {
      const r = Math.hypot(v.x, v.z / 1.12), t = smooth(0.29, 0.47, r), back = smooth(0.0, 0.6, -v.z / 0.5);
      // Back half folds up against the crown; the front draws out into a peak.
      v.y += t * back * 0.24;
      const pull = 1 - 0.45 * t * back;
      v.x *= pull; v.z *= pull;
      const front = Math.max(0, v.z) / 0.53;
      v.z *= 1 + 0.32 * t * Math.pow(front, 3);
      v.y -= 0.03 * t * front;
    },
  }), felt);
  put(g, latheY(bandProfile(0.296, 0.308, 0.09, 0.15), { sz: 1.12 }), waxLeather(0x3a2c1c));
  stud(g, gold(BRASS), 0.022, 0.29, 0.12, 0.12, 0.6, 0, 1.2);
  feather(g, [[0.27, 0.13, 0.1], [0.34, 0.32, 0.02], [0.35, 0.52, -0.16], [0.28, 0.6, -0.4]], 0.07, cloth(c.tcl), [0, 1, 0], cloth(c.tcd));
}

/** Wizard's hat: a broad, softly drooping brim and a tall crumpled cone whose tip folds back. */
function wizardHat(g: G, hat: Mat, band: Mat, o: { frost?: boolean; gem: number }) {
  put(g, latheY(ribbon([[0.26, 0.18], [0.38, 0.165], [0.52, 0.135], [0.6, 0.12]], 0.02), {
    seg: 44,
    warp: v => {
      const r = Math.hypot(v.x, v.z), t = smooth(0.26, 0.6, r), a = Math.atan2(v.x, v.z);
      v.y += -0.05 * t * t + 0.035 * Math.sin(3 * a + 0.7) * Math.pow(t, 1.5);
    },
  }), hat);
  const spine: V3[] = [[0, 0.15, 0], [0, 0.42, -0.02], [0.01, 0.64, -0.07], [0.02, 0.8, -0.18], [0.01, 0.85, -0.32], [0, 0.8, -0.42]];
  put(g, sweep(spine, t => (0.272 * Math.pow(1 - t, 1.15) + 0.012) * (1 + 0.05 * Math.sin(t * 19)), { seg: 44, radial: 16, cap: false }), hat);
  put(g, latheY(bandProfile(0.262, 0.282, 0.17, 0.24)), band);
  put(g, slab([[-0.045, 0.165], [0.045, 0.165], [0.045, 0.245], [-0.045, 0.245]], 0.02, { orient: "front", bevel: 0.005, holes: [[[-0.025, 0.185], [-0.025, 0.225], [0.025, 0.225], [0.025, 0.185]]] }), band, 0, 0, 0.285);
  stud(g, B(o.gem), 0.018, 0, 0.205, 0.298, 0.7);
  const star: V2[] = [];
  for (let i = 0; i < 10; i++) { const a = PI / 2 + i * PI / 5, r = i % 2 ? 0.4 : 1; star.push([Math.cos(a) * r, Math.sin(a) * r]); }
  for (const [x, y, z, ry, s] of [[0.14, 0.38, 0.17, 0.7, 0.035], [-0.1, 0.52, 0.12, -0.6, 0.028], [0.05, 0.66, 0.05, 0.3, 0.022]] as [number, number, number, number, number][]) {
    put(g, slab(star.map(([u, v]) => [u * s, v * s] as V2), 0.01, { orient: "front", bevel: 0.002 }), o.frost ? B(0xdff4ff) : gildMat(), x, y, z, -0.25, ry, 0);
  }
  if (o.frost) {
    put(g, torus(0.47, 0.045, 36), hide(0xeef3f8), 0, 0.15, 0, PI / 2, 0, 0);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * PI * 2 + 0.3;
      const m = put(g, latheZ([[0, 0], [0.03, 0.04], [0.025, 0.14], [0, 0.2]], 4, true), B(0xbfe8ff), Math.sin(a) * 0.32, 0.22, Math.cos(a) * 0.32);
      m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(Math.sin(a) * 0.4, 1, Math.cos(a) * 0.4).normalize());
    }
    stud(g, B(0xdff4ff), 0.035, 0, 0.8, -0.43, 1);
  } else {
    for (let i = 0; i < 2; i++) stud(g, B(o.gem), 0.014, -0.45 + i * 0.05, 0.1 - i * 0.06, 0.2 + i * 0.03, 1);
    put(g, sweep([[-0.44, 0.15, 0.18], [-0.44, 0.12, 0.19], [-0.42, 0.04, 0.23]], () => 0.005, { seg: 6, radial: 4 }), gildMat());
  }
}

/** Bishop's mitre: two pointed panels, gold orphreys, a cross and lappets falling behind. */
function mitre(g: G) {
  const silkW = silk(0xf6f1e4), gd = gildMat();
  const outline: V2[] = [[-0.27, 0.1], [0.27, 0.1], [0.27, 0.42], [0.22, 0.55], [0.12, 0.66], [0, 0.72], [-0.12, 0.66], [-0.22, 0.55], [-0.27, 0.42]];
  for (const back of [false, true]) {
    frame(g, [0, 0, 0], [0, back ? PI : 0, 0], f => {
      const bend = (x: number) => 0.1 + 0.16 * Math.sqrt(Math.max(0, 1 - (x / 0.3) ** 2));
      const mk = (o: V2[], d: number, lift: number) => {
        const geo = slab(o, d, { orient: "front", bevel: 0.004 });
        const p = geo.attributes.position as THREE.BufferAttribute;
        for (let i = 0; i < p.count; i++) p.setZ(i, p.getZ(i) + bend(p.getX(i)) + lift);
        geo.computeVertexNormals();
        return geo;
      };
      const dense: V2[] = [];
      for (let i = 0; i < outline.length; i++) {
        const a = outline[i], b = outline[(i + 1) % outline.length];
        for (let k = 0; k < 4; k++) dense.push([lerp(a[0], b[0], k / 4), lerp(a[1], b[1], k / 4)]);
      }
      put(f, mk(dense, 0.02, 0), silkW);
      const strip = (pts: V2[]) => { const d: V2[] = []; for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length]; for (let k = 0; k < 6; k++) d.push([lerp(a[0], b[0], k / 6), lerp(a[1], b[1], k / 6)]); } put(f, mk(d, 0.012, 0.012), gd); };
      strip([[-0.04, 0.1], [0.04, 0.1], [0.04, 0.68], [-0.04, 0.68]]);
      strip([[-0.27, 0.1], [0.27, 0.1], [0.27, 0.17], [-0.27, 0.17]]);
      if (!back) {
        strip([[-0.12, 0.4], [0.12, 0.4], [0.12, 0.45], [-0.12, 0.45]]);
        stud(f, B(0xd0283a), 0.022, 0, 0.425, bend(0) + 0.026, 0.6);
      }
    });
  }
  put(g, latheY(bandProfile(0.28, 0.296, 0.08, 0.14)), gd);
  for (const s of [-1, 1]) {
    put(g, slab([[-0.035, 0.0], [0.035, 0.0], [0.035, -0.42], [-0.035, -0.42]], 0.012, { orient: "front", bevel: 0.003 }), silkW, s * 0.08, 0.1, -0.29, 0.12, PI, 0);
    put(g, slab([[-0.035, -0.4], [0.035, -0.4], [0.035, -0.44], [-0.035, -0.44]], 0.016, { orient: "front", bevel: 0.003 }), gd, s * 0.08, 0.1, -0.292, 0.12, PI, 0);
  }
}

/** Cloth hood: a rounded crown with a soft peak, open around the face, its cowl draping over the shoulders. */
function hood(g: G, cl: Mat, o: { peak?: number; edge?: Mat; tight?: boolean; rags?: Mat; tail?: boolean } = {}) {
  const pk = o.peak ?? 0.12, w = o.tight ? -0.012 : 0.012;
  const crown: V2[] = [[0.3 + w, 0.1], [0.315 + w, 0.16], [0.3 + w, 0.24], [0.255 + w, 0.31], [0.18 + w, 0.36], [0.09, 0.385], [0, 0.39]];
  put(g, latheY(shellProfile(crown, 0.024), {
    sz: 1.07, seg: 32,
    warp: v => {
      // Pull the crown back into a soft point behind the head.
      const up = smooth(0.15, 0.39, v.y), back = smooth(-0.1, -0.3, v.z);
      v.z -= pk * up * up * (0.5 + 0.5 * back) * 1.3; v.y += pk * 0.5 * up * up * back;
      // The front edge rolls forward a little to shade the brow.
      if (v.z > 0.15 && v.y < 0.2) v.z += 0.035 * (1 - smooth(0.12, 0.2, v.y));
    },
  }), cl);
  // Cowl: hugs the cheeks, nips in at the neck, then spreads over the shoulders.
  const cowl: V2[] = [[0.3 + w, 0.2], [0.318 + w, 0.08], [0.31 + w, -0.06], [0.3 + w, -0.17], [0.33 + w, -0.26], [0.39 + w, -0.36], [0.43 + w, -0.48]];
  const open = o.tight ? 0.62 : 0.7;
  const drape = (v: THREE.Vector3) => {
    // Nip in behind the neck, then spread sideways over the shoulders rather than into a cylinder.
    const neck = smooth(0.05, -0.2, v.y) * (1 - smooth(-0.22, -0.4, v.y)), sh = smooth(-0.18, -0.46, v.y);
    if (v.z < 0) v.z *= 1 - 0.2 * neck - 0.18 * sh;
    v.x *= 1 + 0.32 * sh;
  };
  put(g, latheY(ribbon(cowl.map(([r, y]) => [r, y] as V2), 0.022).reverse(), { phi0: open, phiLen: PI * 2 - open * 2, sz: 1.07, seg: 32, warp: drape }), cl);
  // Rolled edge around the face opening, in the same cloth.
  const edge = o.edge ?? cl;
  for (const s of [-1, 1]) {
    const a = s * open;
    put(g, sweep(cowl.slice(0, 6).map(([r, y]) => { const v = new THREE.Vector3(Math.sin(a) * (r + 0.004), y, Math.cos(a) * (r + 0.004) * 1.07); drape(v); return [v.x, v.y, v.z] as V3; }), () => 0.02, { seg: 14, radial: 5 }), edge);
  }
  put(g, sweep(Array.from({ length: 11 }, (_, i) => { const a = lerp(-open, open, i / 10); return [Math.sin(a) * 0.33, 0.13 + 0.02 * Math.cos(a * 2.2), Math.cos(a) * 0.37 + 0.02] as V3; }), () => 0.022, { seg: 18, radial: 5 }), edge);
  if (o.tail) put(g, sweep([[0, 0.3, -0.3], [0.02, 0.18, -0.4], [0.05, -0.02, -0.44], [0.08, -0.22, -0.42], [0.1, -0.42, -0.38]], t => 0.07 * (1 - t * 0.8), { seg: 20, radial: 7, squash: 0.6, wide: [1, 0, 0] }), cl);
  if (o.rags) for (let i = 0; i < 9; i++) {
    const a = PI + (i - 4) * 0.36;
    const p = new THREE.Vector3(Math.sin(a) * 0.43, -0.48, Math.cos(a) * 0.46); drape(p);
    const m = put(g, latheZ([[0, 0], [0.05, 0.02], [0, 0.16]], 4, true), o.rags, p.x, p.y, p.z);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(Math.sin(a) * 0.3, -1, Math.cos(a) * 0.3).normalize());
  }
}

/** Corinthian helmet: crown, eye slots, cheek plates closing to a narrow mouth slot, nasal, and a stilted crest. */
function corinthian(g: G, c: HeadCtx) {
  const bz = gold(0xb8873a), bzL = gold(0xd2a455);
  const sk: V2[] = [[0.3, 0.07], [0.31, 0.15], [0.29, 0.24], [0.245, 0.33], [0.15, 0.39], [0.06, 0.41], [0, 0.412]];
  put(g, latheY(shellProfile(sk, 0.02), { sz: 1.08 }), bz);
  put(g, latheY(bandProfile(0.29, 0.31, -0.035, 0.08), { phi0: 1.0, phiLen: PI * 2 - 2.0, sz: 1.08 }), bz);
  const low: V2[] = [[0.27, -0.33], [0.31, -0.2], [0.315, -0.1], [0.31, -0.03], [0.29, -0.03], [0.295, -0.1], [0.29, -0.2], [0.25, -0.33], [0.27, -0.33]];
  put(g, latheY(low, { phi0: 0.36, phiLen: PI * 2 - 0.72, sz: 1.12 }), bz);
  // The eye slots are cut between the brow and the cheek plates; a nasal runs down between them.
  put(g, slab([[-0.035, 0.09], [0.035, 0.09], [0.026, -0.06], [0.03, -0.1], [-0.03, -0.1], [-0.026, -0.06]], 0.024, { orient: "front", bevel: 0.006 }), bz, 0, 0, 0.335, -0.06, 0, 0);
  for (const s of [-1, 1]) put(g, sweep([[s * 0.03, 0.12, 0.33], [s * 0.12, 0.135, 0.31], [s * 0.21, 0.11, 0.25]], t => 0.012 * Math.sin(PI * t) + 0.005, { seg: 10, radial: 4 }), bzL);
  put(g, latheY(bandProfile(0.312, 0.322, 0.075, 0.095), { sz: 1.08 }), bzL);
  // Crest holder and a horsehair crest arched over the skull.
  put(g, latheY([[0, 0.39], [0.03, 0.39], [0.022, 0.5], [0.04, 0.52], [0, 0.53]], { seg: 8 }), bzL);
  crest(g, [[0, 0.52, 0.32], [0, 0.66, 0.17], [0, 0.7, -0.02], [0, 0.66, -0.22], [0, 0.52, -0.38], [0, 0.3, -0.46], [0, 0.08, -0.46]], 0.15, cloth(c.tc), cloth(c.tcl));
}

/** Suji-bachi kabuto: a ribbed bowl, a stepped and laced neck guard, turned-back wings, a peak and a gold crescent. */
function kabuto(g: G, c: HeadCtx) {
  const lac = lacquer(0x221c22), gd = gildMat();
  const bowl: V2[] = [[0.305, 0.11], [0.31, 0.17], [0.292, 0.26], [0.245, 0.34], [0.165, 0.4], [0.075, 0.43], [0, 0.435]];
  put(g, latheY(shellProfile(bowl, 0.022)), lac);
  for (let i = 0; i < 16; i++) meridian(g, lacquer(0x332a33), bowl, (i / 16) * PI * 2, 0.011, { lift: 0.004, from: 1, to: 6 });
  put(g, torus(0.07, 0.012, 16), gd, 0, 0.43, 0, PI / 2, 0, 0);
  put(g, latheY(bandProfile(0.305, 0.322, 0.1, 0.14)), gd);
  // Shikoro: four lames stepping down and out around the back and sides, each with a laced edge.
  for (let k = 0; k < 4; k++) {
    const y = 0.11 - k * 0.075, r0 = 0.31 + k * 0.035;
    put(g, latheY(ribbon([[r0, y], [r0 + 0.07, y - 0.06]], 0.024), { phi0: 1.05, phiLen: PI * 2 - 2.1 }), lac);
    put(g, latheY(bandProfile(r0 + 0.066, r0 + 0.08, y - 0.088, y - 0.068), { phi0: 1.05, phiLen: PI * 2 - 2.1 }), cloth(c.tc));
  }
  // Fukigaeshi: the top lames turned back beside the face.
  for (const s of [-1, 1]) frame(g, [s * 0.33, 0.1, 0.1], [0, s * 0.55, s * 0.15], f => {
    put(f, slab([[0.0, 0.05], [0.12, 0.06], [0.14, -0.05], [0.0, -0.12]], 0.03, { bevel: 0.008 }), lac);
    put(f, sweep([[0, 0.05, 0.0], [0, 0.06, 0.12], [0, -0.05, 0.14], [0, -0.12, 0.0]], () => 0.01, { seg: 10, radial: 4 }), gd, s * 0.016, 0, 0);
    stud(f, gd, 0.026, s * 0.02, -0.02, 0.07, 0.6, 0, s * PI / 2);
  });
  // Mabizashi: the peak, shading the brow but clear of the eyes.
  put(g, latheY(ribbon([[0.3, 0.135], [0.36, 0.13], [0.4, 0.14]], 0.018), { phi0: -1.0, phiLen: 2.0 }), lac);
  put(g, latheY(bandProfile(0.39, 0.405, 0.115, 0.14), { phi0: -1.0, phiLen: 2.0 }), gd);
  // Kuwagata: twin gilded horns rising from a holder with the team crest.
  const horn2: V2[] = [];
  for (let i = 0; i <= 12; i++) { const t = i / 12, a = lerp(-0.2, PI + 0.2, t); horn2.push([Math.cos(a) * 0.24, 0.3 + Math.sin(a) * 0.34 * (0.6 + 0.4 * Math.sin(a))]); }
  const inner = horn2.map(([x, y]) => [x * 0.86, y + 0.02] as V2).reverse();
  for (const half of [horn2.slice(0, 7), horn2.slice(6)]) {
    void half;
  }
  const hornShape: V2[] = [];
  for (let i = 0; i <= 16; i++) { const t = i / 16, a = lerp(-0.05, PI + 0.05, t); hornShape.push([Math.cos(a) * 0.31, 0.2 + Math.sin(a) * 0.46]); }
  for (let i = 16; i >= 0; i--) { const t = i / 16, a = lerp(-0.05, PI + 0.05, t); const thick = 0.03 + 0.03 * Math.sin(PI * t); hornShape.push([Math.cos(a) * (0.31 - thick), 0.2 + Math.sin(a) * (0.46 - thick * 1.6)]); }
  void inner;
  frame(g, [0, 0.07, 0.33], [-0.18, 0, 0], f => {
    // Cut the crescent at the top: two horns, not a ring.
    const left = hornShape.filter(([x]) => x <= -0.05), right = hornShape.filter(([x]) => x >= 0.05);
    for (const h of [left, right]) if (h.length > 3) put(f, slab(h, 0.016, { orient: "front", bevel: 0.004 }), gd);
    put(f, latheZ([[0, -0.02], [0.06, -0.02], [0.065, 0.0], [0.06, 0.02], [0, 0.02]], 14), gd, 0, 0.17, 0);
    put(f, latheZ([[0, 0.0], [0.04, 0.0], [0.04, 0.012], [0, 0.012]], 12), cloth(c.tc), 0, 0.17, 0.02);
  });
}

/** Spangenhelm-shaped winged helm for the valkyrie: bright skull, gold brow and nasal, feathered wings. */
function wingedHelm(g: G) {
  const st = plateMat(0xdfe5ee), gd = gildMat(), wht = M(0xf6f3ea, 0.75);
  put(g, latheY(shellProfile(ROUND, 0.02), { sz: 1.05 }), st);
  put(g, latheY(bandProfile(0.3, 0.318, 0.065, 0.14), { sz: 1.05 }), gd);
  rivets(g, steel(STEEL_DARK), 0.32, 0.1, 12, 0.013, 0, PI * 2, 1.05);
  put(g, sweep([[0, 0.15, 0.33], [0, 0.32, 0.26], [0, 0.4, 0.04], [0, 0.38, -0.14], [0, 0.26, -0.3]], () => 0.014, { seg: 20, radial: 5 }), gd);
  put(g, slab([[-0.03, 0.14], [0.03, 0.14], [0.022, -0.02], [0.016, -0.08], [-0.016, -0.08], [-0.022, -0.02]], 0.02, { orient: "front", bevel: 0.005 }), gd, 0, 0, 0.33, -0.12, 0, 0);
  for (const s of [-1, 1]) {
    stud(g, gd, 0.04, s * 0.3, 0.2, 0.0, 0.7, 0, s * PI / 2);
    for (let i = 0; i < 6; i++) {
      const a = 0.2 + i * 0.2, len = 0.32 + i * 0.045;
      const dir = new THREE.Vector3(s * 0.35, Math.cos(a), -Math.sin(a) * 1.0).normalize();
      const base = new THREE.Vector3(s * 0.31, 0.2, -0.02);
      const mid = base.clone().addScaledVector(dir, len * 0.55).add(new THREE.Vector3(s * 0.04, 0, 0));
      const end = base.clone().addScaledVector(dir, len);
      feather(g, [[base.x, base.y, base.z], [mid.x, mid.y, mid.z], [end.x, end.y, end.z]], 0.045 + i * 0.004, i % 2 ? M(0xe8e4d8, 0.75) : wht, [s, 0, 0]);
    }
  }
}

/** Tricorne with gold lace, a skull badge and an ostrich plume. */
function tricorne(g: G) {
  const felt = waxLeather(0x241c28), gd = gildMat();
  put(g, latheY([[0, 0.1], [0.29, 0.1], [0.3, 0.16], [0.28, 0.26], [0.2, 0.33], [0, 0.35]], { sz: 1.04 }), felt);
  const R0 = 0.28, R1 = 0.58;
  const fold = (v: THREE.Vector3) => {
    const r = Math.hypot(v.x, v.z), a = Math.atan2(v.x, v.z), t = smooth(R0, R1, r);
    const u = (1 - Math.cos(3 * a)) / 2;
    const nr = R0 + (r - R0) * (1 - 0.78 * u);
    v.x *= nr / r; v.z *= nr / r;
    v.y += t * u * 0.27 - t * (1 - u) * 0.02;
  };
  put(g, latheY(ribbon([[R0, 0.125], [0.42, 0.115], [R1, 0.105]], 0.02), { seg: 60, warp: fold }), felt);
  const edge: V3[] = [];
  for (let i = 0; i < 60; i++) { const a = (i / 60) * PI * 2, v = new THREE.Vector3(Math.sin(a) * R1, 0.11, Math.cos(a) * R1); fold(v); edge.push([v.x, v.y, v.z]); }
  put(g, sweep(edge, () => 0.013, { closed: true, seg: 120, radial: 4 }), gd);
  const a = -PI / 3;
  frame(g, [Math.sin(a) * 0.36, 0.25, Math.cos(a) * 0.36], [-0.15, a, 0], f => {
    for (const o of chargeOutline("skull")) put(f, slab(o.map(([u, v]) => [u * 0.05, v * 0.05] as V2), 0.012, { orient: "front", bevel: 0.003 }), boneMat());
    for (const s of [-1, 1]) stud(f, B(0x14100c), 0.012, s * 0.017, 0.012, 0.01, 0.5);
    for (const s of [-1, 1]) put(f, slab([[-0.075, -0.012], [0.075, -0.012], [0.075, 0.012], [-0.075, 0.012]], 0.01, { orient: "front", bevel: 0.003 }), boneMat(), 0, -0.05, -0.004, 0, 0, s * 0.6);
  });
  feather(g, [[-0.2, 0.22, 0.14], [-0.34, 0.33, 0.0], [-0.36, 0.38, -0.2], [-0.24, 0.36, -0.36]], 0.07, M(0xf6f1e6, 0.85), [0, 1, 0]);
}

/** Crude iron helm with riveted straps and a pair of great curving horns. */
function hornedHelm(g: G) {
  const ir = ironMat(0x4a4e55), dk = ironMat(0x33363c);
  const sk: V2[] = [[0.3, 0.1], [0.305, 0.17], [0.28, 0.25], [0.22, 0.31], [0.12, 0.345], [0.05, 0.355], [0, 0.356]];
  put(g, latheY(shellProfile(sk, 0.022), { sz: 1.08, flat: true, warp: v => { v.y += 0.008 * Math.sin(v.x * 30) * Math.sin(v.z * 26); } }), ir);
  put(g, latheY(bandProfile(0.298, 0.322, 0.09, 0.16), { sz: 1.08, flat: true }), dk);
  for (const a of [0, PI / 2, PI, -PI / 2]) meridian(g, dk, sk, a, 0.02, { sz: 1.08, from: 1 });
  rivets(g, steel(0x8b939f), 0.326, 0.125, 10, 0.02, 0, PI * 2, 1.08);
  put(g, latheY([[0, 0.34], [0.05, 0.34], [0.02, 0.42], [0, 0.46]], { seg: 6 }), steel(0x8b939f));
  for (const s of [-1, 1]) {
    const pts: V3[] = [[s * 0.26, 0.2, 0.0], [s * 0.42, 0.25, 0.03], [s * 0.54, 0.37, 0.07], [s * 0.58, 0.54, 0.13], [s * 0.52, 0.66, 0.22]];
    put(g, sweep(pts, t => 0.075 * Math.pow(1 - t, 0.85) + 0.01, { seg: 24, radial: 9 }), horn(0xd8ceb0));
    const curve = new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p)), false, "centripetal");
    for (const t of [0.12, 0.22]) {
      const P = curve.getPointAt(t), T = curve.getTangentAt(t);
      const m = put(g, torus(0.075 * Math.pow(1 - t, 0.85) + 0.012, 0.014, 14), dk, P.x, P.y, P.z);
      m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), T);
    }
    const P = curve.getPointAt(0.82), T = curve.getTangentAt(0.82);
    const tip = put(g, latheZ([[0, 0], [0.026, 0], [0.018, 0.06], [0, 0.14]], 6, true), horn(0x5a4a38), P.x, P.y, P.z);
    tip.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), T);
  }
}

/** Turban: a cloth crown wound with crossing folds, a jewelled brooch and an aigrette. */
function turban(g: G) {
  const c1 = cloth(0xefe6cc), c2 = cloth(0xd9cfae);
  put(g, latheY([[0, 0.05], [0.3, 0.05], [0.33, 0.13], [0.33, 0.22], [0.28, 0.31], [0.17, 0.38], [0, 0.4]], { sz: 1.05 }), c1);
  for (let k = 0; k < 6; k++) {
    const y0 = 0.1 + k * 0.045, tilt = (k % 2 ? 1 : -1) * 0.05, off = k * 0.9, R = 0.335 - Math.max(0, k - 2) * 0.03;
    const loop: V3[] = [];
    for (let i = 0; i < 20; i++) { const a = (i / 20) * PI * 2; loop.push([Math.sin(a) * R, y0 + tilt * Math.cos(a + off), Math.cos(a) * R * 1.05]); }
    put(g, sweep(loop, () => 0.042, { closed: true, seg: 40, radial: 6, squash: 0.6 }), k % 2 ? c2 : c1);
  }
  put(g, latheZ([[0, -0.01], [0.06, -0.01], [0.065, 0.01], [0.05, 0.025], [0, 0.03]], 14), gildMat(), 0, 0.2, 0.33);
  stud(g, B(0x3fd08a), 0.04, 0, 0.2, 0.36, 0.8);
  for (let i = 0; i < 6; i++) { const a = (i / 6) * PI * 2; stud(g, M(0xf6f1e6, 0.3, 0.1), 0.012, Math.cos(a) * 0.062, 0.2 + Math.sin(a) * 0.062, 0.355, 1); }
  feather(g, [[0, 0.24, 0.33], [0.02, 0.4, 0.3], [0.04, 0.56, 0.22], [0.02, 0.64, 0.1]], 0.045, M(0xf6f1e6, 0.8), [1, 0, 0]);
}

/** Tate-eboshi: the tall lacquered court cap, creased and leaning back, tied under the chin. */
function eboshi(g: G) {
  const lac = lacquer(0x17161c);
  put(g, latheY([[0, 0.12], [0.3, 0.12], [0.3, 0.2], [0.26, 0.32], [0.22, 0.46], [0.16, 0.6], [0.09, 0.7], [0, 0.74]], {
    sx: 0.6, sz: 0.9, warp: v => { const up = Math.max(0, v.y - 0.2); v.z -= 0.45 * up * up; v.z += 0.018 * Math.sin(v.y * 22) * smooth(0.25, 0.6, v.y); v.x *= 1 + 0.6 * Math.max(0, 0.18 - v.y) / 0.12 * smooth(0.0, 0.18, v.y); },
  }), lac);
  put(g, latheY([[0, 0.07], [0.285, 0.07], [0.29, 0.14], [0.25, 0.22], [0, 0.24]]), lacquer(0x22202a));
  for (const s of [-1, 1]) put(g, sweep([[s * 0.27, 0.07, 0.06], [s * 0.28, -0.08, 0.1], [s * 0.2, -0.24, 0.16], [s * 0.08, -0.3, 0.2]], () => 0.009, { seg: 10, radial: 4 }), cloth(0xf4f1e6));
  stud(g, B(0x5fbf8a), 0.026, 0, 0.32, -0.27, 0.8, 0, PI);
}

/** Knitted watch cap with a turned-up ribbed cuff and a pompom. */
function watchCap(g: G, c: HeadCtx) {
  const knit = cloth(c.tc), cuff = cloth(c.tcd);
  put(g, latheY([[0, 0.08], [0.29, 0.08], [0.3, 0.16], [0.285, 0.26], [0.23, 0.34], [0.14, 0.4], [0.06, 0.425], [0, 0.43]], { sz: 1.04 }), knit);
  const rib: V2[] = [[0.29, 0.02], [0.315, 0.02]];
  for (let i = 0; i <= 8; i++) rib.push([0.315 + (i % 2 ? 0.008 : 0), 0.025 + i * 0.016]);
  rib.push([0.29, 0.155], [0.29, 0.02]);
  put(g, latheY(rib, { sz: 1.04, seg: 32 }), cuff);
  for (let i = 0; i < 7; i++) { const a = (i / 7) * PI * 2; put(g, GEO.sph, cloth(c.tcl), Math.sin(a) * 0.04, 0.47 + (i % 2) * 0.02, Math.cos(a) * 0.04, 0, 0, 0, 0.055); }
  put(g, GEO.sph, cloth(c.tcl), 0, 0.5, 0, 0, 0, 0, 0.06);
}

/** Leather flying cap with brass-rimmed goggles pushed up on the brow. */
function aviator(g: G, c: HeadCtx) {
  const lea = hide(0x6a4a30);
  put(g, latheY([[0, -0.02], [0.3, -0.02], [0.305, 0.08], [0.29, 0.2], [0.24, 0.29], [0.14, 0.35], [0, 0.37]], { sz: 1.06, warp: v => { if (v.y < 0.13) { const f = Math.pow(Math.max(0, v.z) / 0.32, 2); v.y = lerp(v.y, 0.13, f); } } }), lea);
  put(g, sweep([[0, 0.12, 0.31], [0, 0.3, 0.24], [0, 0.37, 0.0], [0, 0.3, -0.25], [0, 0.1, -0.33]], () => 0.01, { seg: 18, radial: 4 }), hide(0x4a3220));
  put(g, latheY(bandProfile(0.3, 0.318, 0.11, 0.155), { phi0: -1.0, phiLen: 2.0, sz: 1.06 }), cloth(c.tc));
  for (const s of [-1, 1]) {
    const v = latheZ([[0, -0.03], [0.085, -0.03], [0.09, 0.02], [0.078, 0.05], [0, 0.05]], 16);
    put(g, v, gold(0xb9803a), s * 0.1, 0.23, 0.26, -0.55, s * 0.25, 0);
    put(g, latheZ([[0, 0.0], [0.07, 0.0], [0, 0.012]], 16), B(0xbfe6f2), s * 0.1, 0.23 + 0.026, 0.26 + 0.04, -0.55, s * 0.25, 0);
  }
  put(g, slab([[-0.02, -0.015], [0.02, -0.015], [0.02, 0.015], [-0.02, 0.015]], 0.03, { orient: "front", bevel: 0.004 }), hide(0x2a2016), 0, 0.24, 0.29, -0.55, 0, 0);
}

/** Elven circlet: a silver band dipping to a leaf-set gem, with leaves sweeping back from the temples. */
function circlet(g: G) {
  const sv = plateMat(0xe2e6ea), leafM = M(0x4fc27a, 0.5, 0.1);
  const loop: V3[] = [];
  for (let i = 0; i < 24; i++) { const a = (i / 24) * PI * 2; loop.push([Math.sin(a) * 0.3, 0.13 + 0.03 * Math.cos(a) - 0.035 * Math.pow(Math.max(0, Math.cos(a)), 8), Math.cos(a) * 0.31]); }
  put(g, sweep(loop, () => 0.012, { closed: true, seg: 48, radial: 5 }), sv);
  put(g, slab([[0, 0.07], [0.035, 0.03], [0.03, -0.02], [0, -0.05], [-0.03, -0.02], [-0.035, 0.03]], 0.016, { orient: "front", bevel: 0.004 }), sv, 0, 0.1, 0.305);
  stud(g, B(0x3fd08a), 0.022, 0, 0.11, 0.316, 0.7);
  const leaf: V2[] = [[0, 0], [0.04, 0.025], [0.1, 0.03], [0.15, 0.0], [0.1, -0.02], [0.04, -0.015]];
  for (const s of [-1, 1]) for (let k = 0; k < 3; k++) {
    put(g, slab(leaf.map(([u, v]) => [u * (1 - k * 0.15), v] as V2), 0.008, { bevel: 0.002 }), k === 1 ? sv : leafM, s * 0.3, 0.14 + k * 0.025, 0.05 - k * 0.02, -0.3 - k * 0.25, s * 0.15, 0);
  }
}

/** Laurel wreath of gold with lightning rays rising behind it. */
function laurel(g: G) {
  const gd = gildMat();
  const loop: V3[] = [];
  for (let i = 0; i < 24; i++) { const a = (i / 24) * PI * 2; loop.push([Math.sin(a) * 0.31, 0.13, Math.cos(a) * 0.32]); }
  put(g, sweep(loop, () => 0.012, { closed: true, seg: 48, radial: 4 }), gd);
  const leaf: V2[] = [[0, 0], [0.03, 0.02], [0.08, 0.022], [0.12, 0.0], [0.08, -0.016], [0.03, -0.014]];
  for (let i = 0; i < 18; i++) {
    const a = PI * 0.28 + (i / 17) * PI * 1.44, side = i % 2 ? 1 : -1;
    put(g, slab(leaf, 0.008, { bevel: 0.002 }), gd, Math.sin(a) * 0.32, 0.13 + side * 0.02, Math.cos(a) * 0.33, side * 0.5, a + PI / 2, 0);
  }
  const bolt: V2[] = [[-0.03, 0], [0.03, 0], [0.012, 0.09], [0.05, 0.09], [-0.01, 0.24], [0.004, 0.13], [-0.036, 0.13]];
  for (let i = 0; i < 5; i++) {
    const a = PI + (i - 2) * 0.5;
    frame(g, [Math.sin(a) * 0.29, 0.17, Math.cos(a) * 0.3], [-0.25 * Math.cos(a), a, 0], f => put(f, slab(bolt.map(([u, v]) => [u * 1.3, v * (1.2 + (i % 2) * 0.4)] as V2), 0.02, { orient: "front", bevel: 0.004 }), gd));
  }
  put(g, slab([[0, 0.07], [0.05, 0.0], [0, -0.05], [-0.05, 0.0]], 0.02, { orient: "front", bevel: 0.005 }), gd, 0, 0.14, 0.32);
  stud(g, B(0x9fd8ff), 0.026, 0, 0.14, 0.335, 0.7);
}

/** Thracian helmet: a bronze Phrygian skull curling forward, a brow peak, cheek plates and side feathers. */
function thracian(g: G, c: HeadCtx) {
  const bz = gold(0xa87a36), bzL = gold(0xd2a455);
  const sk: V2[] = [[0.298, 0.07], [0.303, 0.15], [0.288, 0.25], [0.252, 0.34], [0.195, 0.43], [0.125, 0.5], [0.055, 0.55], [0, 0.565]];
  put(g, latheY(shellProfile(sk, 0.022), { sz: 1.06, warp: v => { const t = Math.max(0, v.y - 0.3) / 0.27; v.z += 0.12 * t * t; } }), bz);
  put(g, sweep([[0, 0.17, 0.33], [0, 0.34, 0.29], [0, 0.5, 0.2], [0, 0.57, 0.08], [0, 0.55, -0.06], [0, 0.42, -0.24]], () => 0.016, { seg: 22, radial: 5 }), bzL);
  put(g, latheY(ribbon([[0.3, 0.115], [0.36, 0.1], [0.4, 0.105]], 0.018), { phi0: -1.2, phiLen: 2.4, sz: 1.08 }), bz);
  put(g, latheY(bandProfile(0.302, 0.316, 0.085, 0.12), { sz: 1.06 }), bzL);
  put(g, latheY(ribbon([[0.29, 0.09], [0.34, 0.03], [0.39, 0.0]], 0.02), { phi0: PI / 2 + 0.5, phiLen: PI - 1.0, sz: 1.06 }), bz);
  for (const s of [-1, 1]) {
    frame(g, [s * 0.3, 0.09, 0.03], [0, s * 0.3, 0], f => {
      put(f, slab([[0.16, 0.0], [0.18, -0.1], [0.13, -0.22], [0.05, -0.27], [-0.04, -0.2], [-0.06, 0.0]], 0.024, { bevel: 0.007 }), bz);
      for (let k = 0; k < 3; k++) stud(f, bzL, 0.014, s * 0.015, -0.05 - k * 0.06, 0.1 - k * 0.04, 0.6, 0, s * PI / 2);
    });
    put(g, latheZ([[0, -0.04], [0.018, -0.04], [0.018, 0.04], [0, 0.04]], 6), bzL, s * 0.31, 0.2, -0.04, -1.2, 0, -s * 0.3);
    feather(g, [[s * 0.31, 0.22, -0.05], [s * 0.36, 0.42, -0.08], [s * 0.38, 0.58, -0.18], [s * 0.34, 0.66, -0.32]], 0.06, cloth(s > 0 ? c.tc : 0xf4efe2), [0, 0, 1], cloth(0x2a2016));
  }
}

/** Ninja zukin: hood bound tight, a face cloth up to the eyes, a team headband with tails and a forehead plate. */
function zukin(g: G, c: HeadCtx) {
  const cl = cloth(0x1d2028);
  hood(g, cl, { peak: 0.0, tight: true });
  put(g, headShell(9, 15, 1, 9, 0.02, 0.0), cl);
  put(g, latheY(bandProfile(0.33, 0.345, 0.12, 0.19), { sz: 1.06 }), cloth(c.tc));
  put(g, slab([[-0.1, -0.03], [0.1, -0.03], [0.1, 0.03], [-0.1, 0.03]], 0.014, { orient: "front", bevel: 0.004 }), steel(STEEL_DARK), 0, 0.155, 0.365);
  for (const s of [-1, 1]) put(g, sweep([[s * 0.03, 0.15, -0.36], [s * 0.08, 0.06, -0.42], [s * 0.12, -0.12, -0.44], [s * 0.15, -0.3, -0.42]], t => 0.03 * (1 - t * 0.4), { seg: 12, radial: 5, squash: 0.3, wide: [1, 0, 0] }), cloth(c.tc));
}

/* ---------------- warband, undead and the rest ---------------- */

/** Loose strands of hair or fur: each root grows along a direction and droops. */
function strands(g: G, mat: Mat, roots: V3[], dirs: V3[], len: number, r: number, droop = 0.4) {
  roots.forEach((p, i) => {
    const d = new THREE.Vector3(...dirs[i % dirs.length]).normalize();
    const pts: V3[] = [];
    for (let k = 0; k <= 3; k++) { const t = k / 3; pts.push([p[0] + d.x * len * t, p[1] + d.y * len * t - droop * len * t * t, p[2] + d.z * len * t]); }
    put(g, sweep(pts, t => r * (1 - t * 0.85), { seg: 8, radial: 5 }), mat);
  });
}

/** Berserker's wolf pelt: the wolf's head worn over the skull, ears up, fangs over the brow, the hide falling to the shoulders. */
function wolfPelt(g: G, c: HeadCtx) {
  const fur = hide(0x6e665c), furD = hide(0x4c463e), furL = hide(0x8e867a);
  const crown: V2[] = [[0.31, 0.06], [0.325, 0.15], [0.31, 0.25], [0.26, 0.34], [0.17, 0.4], [0.07, 0.43], [0, 0.435]];
  put(g, latheY(shellProfile(crown, 0.03), { sz: 1.08, warp: v => { if (v.y < 0.12) v.y += 0.025 * Math.sin(Math.atan2(v.x, v.z) * 9); } }), fur);
  // The wolf's muzzle juts over the brow; its nose, fangs and eyes sit above the wearer's own.
  const snout = latheZ([[0.17, 0.0], [0.165, 0.07], [0.13, 0.16], [0.09, 0.25], [0.055, 0.3], [0, 0.31]], 14);
  snout.scale(1, 0.62, 1);
  put(g, snout, fur, 0, 0.27, 0.12, 0.28, 0, 0);
  put(g, GEO.sph, B(0x14100c), 0, 0.2, 0.42, 0, 0, 0, 0.035);
  put(g, slab([[-0.11, 0.0], [0.11, 0.0], [0.09, -0.03], [-0.09, -0.03]], 0.12, { orient: "flat", bevel: 0.01 }), furD, 0, 0.19, 0.3, -0.28, 0, 0);
  for (const s of [-1, 1]) {
    put(g, latheY([[0, 0], [0.015, 0.0], [0, 0.07]], { seg: 5 }), horn(0xf1ead4), s * 0.07, 0.19, 0.36, PI, 0, s * 0.1);
    stud(g, B(0x14100c), 0.03, s * 0.1, 0.33, 0.25, 0.6, -0.2, s * 0.5);
    stud(g, B(0xe0a030), 0.012, s * 0.11, 0.336, 0.268, 0.6, -0.2, s * 0.5);
    put(g, latheY([[0, 0], [0.08, 0.0], [0.05, 0.1], [0, 0.17]], { seg: 6, sz: 0.45 }), fur, s * 0.17, 0.38, 0.0, -0.25, 0, -s * 0.35);
    put(g, latheY([[0, 0], [0.05, 0.0], [0, 0.12]], { seg: 6, sz: 0.4 }), hide(0xc9a090), s * 0.17, 0.39, 0.02, -0.25, 0, -s * 0.35);
    // Forepaws knotted over the chest.
    put(g, sweep([[s * 0.3, 0.05, 0.0], [s * 0.36, -0.15, 0.05], [s * 0.26, -0.33, 0.2], [s * 0.1, -0.42, 0.25]], t => 0.06 * (1 - t * 0.35), { seg: 14, radial: 6 }), furL);
    for (let k = -1; k <= 1; k++) put(g, latheY([[0, 0], [0.01, 0], [0, 0.04]], { seg: 4 }), horn(0x2a2420), s * 0.08 + k * 0.02, -0.46, 0.27, PI - 0.4, 0, 0);
  }
  put(g, GEO.cape, fur, 0, -0.12, -0.27, 0.12, 0, 0, 1);
  (g.children[g.children.length - 1] as THREE.Mesh).scale.set(0.62, 0.62, 0.06);
  strands(g, furD, [[-0.15, 0.28, -0.22], [0, 0.32, -0.25], [0.15, 0.28, -0.22], [-0.2, 0.16, -0.27], [0.2, 0.16, -0.27]], [[0, -0.2, -1]], 0.18, 0.04, 0.6);
  // Braided beard.
  for (const s of [-1, 1]) {
    const pts: V3[] = [[s * 0.06, -0.2, 0.24], [s * 0.07, -0.32, 0.25], [s * 0.06, -0.44, 0.23]];
    put(g, sweep(pts, t => 0.045 * (1 - t * 0.4), { seg: 10, radial: 6 }), hide(0x8a5a32));
    for (const t of [0.35, 0.75]) put(g, torus(0.042 * (1 - t * 0.4), 0.012, 10), gold(BRASS), s * 0.065, -0.2 - t * 0.24, 0.245, PI / 2, 0, 0);
  }
  put(g, GEO.soft, hide(0x8a5a32), 0, -0.2, 0.2, 0, 0, 0, 1);
  (g.children[g.children.length - 1] as THREE.Mesh).scale.set(0.3, 0.12, 0.14);
  void c;
}

/** Shaman's ram-skull headdress: a bleached skull over the crown with empty sockets, great curled horns and a fan of feathers. */
function ramSkull(g: G) {
  const bone = boneMat(0xd8ccaa), boneD = boneMat(0xb5a888), hornM = horn(0xa8987a);
  put(g, latheY(shellProfile([[0.3, 0.1], [0.31, 0.18], [0.29, 0.27], [0.24, 0.34], [0.15, 0.39], [0.06, 0.41], [0, 0.412]], 0.024), { sz: 1.1 }), bone);
  const snout = latheZ([[0.13, 0.0], [0.13, 0.08], [0.1, 0.18], [0.07, 0.24], [0, 0.26]], 12);
  snout.scale(1, 0.75, 1);
  put(g, snout, bone, 0, 0.27, 0.25, 0.32, 0, 0);
  put(g, GEO.sph, B(0x0c0a08), 0, 0.2, 0.49, 0, 0, 0, 0.02);
  for (const s of [-1, 1]) {
    stud(g, B(0x0c0a08), 0.032, s * 0.13, 0.3, 0.28, 0.5, -0.3, s * 0.45);
    stud(g, B(0x9fff6a), 0.01, s * 0.13, 0.3, 0.295, 0.5, -0.3, s * 0.45);
    // Spiral horn curling back, down and forward round the ear.
    const pts: V3[] = [];
    for (let i = 0; i <= 14; i++) {
      const t = i / 14, a = -0.2 + t * PI * 1.65, R = 0.2 * (1 - t * 0.55);
      pts.push([s * (0.29 + t * 0.14), 0.08 + Math.cos(a) * R, -0.02 - Math.sin(a) * R]);
    }
    put(g, sweep(pts, t => 0.07 * (1 - t * 0.75) + 0.01, { seg: 36, radial: 8 }), hornM);
    const curve = new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p)), false, "centripetal");
    for (let k = 1; k < 9; k++) {
      const t = k / 10, P = curve.getPointAt(t), T = curve.getTangentAt(t);
      const m = put(g, torus(0.07 * (1 - t * 0.75) + 0.012, 0.008, 10), boneD, P.x, P.y, P.z);
      m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), T);
    }
  }
  for (let k = 0; k < 4; k++) stud(g, boneD, 0.016, -0.045 + k * 0.03, 0.16, 0.44, 0.6, 0.5, 0);
  const cols = [0xd8402a, 0xe8d8b0, 0x2f4a3a, 0xe8c050, 0xe8d8b0, 0xd8402a, 0x2f4a3a];
  for (let i = 0; i < 7; i++) {
    const a = (i - 3) * 0.32;
    feather(g, [[Math.sin(a) * 0.1, 0.3, -0.24], [Math.sin(a) * 0.22, 0.48, -0.32], [Math.sin(a) * 0.32, 0.62, -0.36]], 0.045, cloth(cols[i]), [Math.cos(a), 0, Math.sin(a) * 0.3], cloth(0x2a2016));
  }
}

/** Troll: a heavy mossy mane, a beetling brow, a gold ring through the nose. */
function trollHead(g: G, skin: number) {
  const hair = M(0x34442a, 0.92);
  const roots: V3[] = [], dirs: V3[] = [];
  for (let i = 0; i < 11; i++) { const a = PI + (i - 5) * 0.26; roots.push([Math.sin(a) * 0.2, 0.3 - Math.abs(i - 5) * 0.012, Math.cos(a) * 0.2]); dirs.push([Math.sin(a) * 0.6, 0.35, Math.cos(a) * 0.7 - 0.2]); }
  for (let i = 0; i < 5; i++) { roots.push([(i - 2) * 0.07, 0.3, 0.05]); dirs.push([(i - 2) * 0.3, 0.6, -0.5]); }
  strands(g, hair, roots, dirs, 0.32, 0.05, 0.9);
  put(g, GEO.soft, M(dark(skin, 0.9), 0.6), 0, 0.11, 0.2, 0, 0, 0, 1);
  (g.children[g.children.length - 1] as THREE.Mesh).scale.set(0.46, 0.09, 0.14);
  put(g, torus(0.035, 0.009, 12), gildMat(), 0, -0.11, 0.315, 0.3, 0, 0);
  for (let i = 0; i < 3; i++) stud(g, boneMat(), 0.02, 0.2 - i * 0.03, 0.2 + i * 0.05, 0.2, 1);
}

/** Giant: a shaggy mane bound with a leather band, a topknot, and a great bushy beard. */
function giantHead(g: G) {
  const hair = M(0x4a3420, 0.92), band = waxLeather(0x5a3e24);
  const roots: V3[] = [], dirs: V3[] = [];
  for (let i = 0; i < 13; i++) { const a = PI + (i - 6) * 0.24; roots.push([Math.sin(a) * 0.24, 0.25, Math.cos(a) * 0.24]); dirs.push([Math.sin(a) * 0.5, -0.2, Math.cos(a) * 0.6 - 0.15]); }
  strands(g, hair, roots, dirs, 0.34, 0.055, 0.5);
  put(g, latheY([[0, 0.12], [0.29, 0.12], [0.3, 0.2], [0.27, 0.29], [0.18, 0.35], [0, 0.37]], { sz: 1.05, warp: v => { v.y += 0.012 * Math.sin(v.x * 40); } }), hair);
  put(g, latheY(bandProfile(0.3, 0.318, 0.12, 0.18), { sz: 1.05 }), band);
  for (let i = 0; i < 5; i++) { const a = (i - 2) * 0.35; put(g, latheY([[0, 0], [0.018, 0], [0, 0.07]], { seg: 5 }), boneMat(), Math.sin(a) * 0.32, 0.13, Math.cos(a) * 0.33, PI, 0, 0); }
  put(g, GEO.sph, hair, 0, 0.42, -0.06, 0, 0, 0, 0.1);
  put(g, torus(0.07, 0.018, 12), band, 0, 0.36, -0.05, PI / 2, 0, 0);
  put(g, latheY([[0, 0], [0.012, 0], [0, 0.3]], { seg: 5 }), boneMat(), -0.15, 0.42, -0.06, 0, 0, PI / 2);
  // Beard: tapering locks from the jaw, longest in the middle.
  for (let i = 0; i < 9; i++) {
    const x = (i - 4) * 0.055, l = 0.28 - Math.abs(i - 4) * 0.025;
    put(g, sweep([[x, -0.12, 0.24 - Math.abs(x) * 0.6], [x * 1.1, -0.12 - l * 0.5, 0.27 - Math.abs(x) * 0.6], [x * 0.9, -0.12 - l, 0.22 - Math.abs(x) * 0.5]], t => 0.05 * (1 - t * 0.7), { seg: 10, radial: 5 }), hair);
  }
  put(g, GEO.soft, hair, 0, -0.13, 0.22, 0, 0, 0, 1);
  (g.children[g.children.length - 1] as THREE.Mesh).scale.set(0.42, 0.12, 0.14);
}

/** Zombie: wisps of hair, a stitched scalp wound and an arrow it never noticed. */
function zombieHead(g: G) {
  const roots: V3[] = [[0.1, 0.27, 0.05], [0.16, 0.24, -0.08], [-0.05, 0.28, -0.1], [-0.18, 0.2, -0.12], [0.02, 0.26, -0.2]];
  strands(g, M(0x3a3224, 0.9), roots, [[0.3, 0.4, -0.6], [0.6, 0.2, -0.5], [-0.3, 0.3, -0.7], [-0.6, 0.1, -0.5], [0, 0.2, -1]], 0.18, 0.02, 0.8);
  put(g, slab([[-0.1, -0.012], [0.1, -0.012], [0.1, 0.012], [-0.1, 0.012]], 0.02, { orient: "front", bevel: 0.004 }), B(0x3a1a14), -0.06, 0.26, 0.12, -1.1, 0.4, 0.2);
  for (let k = 0; k < 5; k++) put(g, slab([[-0.004, -0.03], [0.004, -0.03], [0.004, 0.03], [-0.004, 0.03]], 0.012, { orient: "front", bevel: 0 }), B(0x14100c), -0.14 + k * 0.04, 0.265 - k * 0.006, 0.1 + k * 0.012, -1.1, 0.4, 0.2);
  // Arrow through the skull: shaft out of one side, fletching, and the head out of the other.
  put(g, latheZ([[0, -0.36], [0.014, -0.36], [0.014, 0.36], [0, 0.36]], 6), M(0xb69250, 0.7), 0, 0.16, -0.02, 0, PI / 2 + 0.15, 0.2);
  for (let i = 0; i < 3; i++) put(g, slab([[0.0, 0], [0.12, 0], [0.1, 0.035], [0.02, 0.04]], 0.006, { bevel: 0 }), cloth(0xe8e0c8), -0.3, 0.16 + 0.04 * Math.cos(i * 2.1) - 0.04, -0.06 + 0.04 * Math.sin(i * 2.1), i * 2.1, PI / 2 + 0.15 + PI, 0.2);
  put(g, latheZ([[0, 0], [0.03, 0.0], [0, 0.1]], 4, true), ironMat(0x5a5048), 0.36, 0.23, 0.04, 0, PI / 2 + 0.15, 0.2);
}

/** Vampire: hair slicked back from a sharp widow's peak, swept into long strands at the nape. */
function vampireHair(g: G) {
  const hairM = silk(0x141018);
  put(g, latheY(shellProfile([[0.285, 0.0], [0.3, 0.12], [0.288, 0.22], [0.245, 0.31], [0.165, 0.37], [0.07, 0.395], [0, 0.4]], 0.02), {
    sz: 1.06,
    warp: v => {
      if (v.y < 0.2 && v.z > 0) {
        const front = Math.max(0, v.z) / 0.3;
        const peak = Math.exp(-((v.x / 0.07) ** 2));
        // Lift the hairline off the forehead, except for the sharp peak in the middle and the sideburns.
        const side = smooth(0.18, 0.28, Math.abs(v.x));
        const target = lerp(0.16, 0.06, peak) * (1 - side) + 0.0 * side;
        if (v.y < target) v.y = lerp(v.y, target, front);
      }
    },
  }), hairM);
  // Combed ridges running back over the crown and lying flat at the nape.
  for (let i = 0; i < 5; i++) {
    const x = (i - 2) * 0.085;
    put(g, sweep([[x * 0.5, 0.25, 0.22], [x * 0.85, 0.385, 0.04], [x, 0.34, -0.19], [x * 1.05, 0.16, -0.31], [x * 1.1, -0.04, -0.3]], t => 0.03 * (1 - t * 0.5), { seg: 18, radial: 6, squash: 0.35, wide: [1, 0, 0] }), hairM);
  }
}

/** Siege sapper's helmet: a heavy iron pot with a riveted brow plate, a team band and a little brass lantern. */
function sapperHelm(g: G, c: HeadCtx) {
  const ir = ironMat(0x55595f), br = gold(BRASS);
  const sk: V2[] = [[0.31, 0.07], [0.318, 0.15], [0.302, 0.26], [0.252, 0.35], [0.155, 0.41], [0.06, 0.43], [0, 0.432]];
  put(g, latheY(shellProfile(sk, 0.03), { sz: 1.05 }), ir);
  put(g, latheY(ribbon([[0.31, 0.11], [0.37, 0.095], [0.4, 0.09]], 0.03), { phi0: -1.1, phiLen: 2.2, sz: 1.05 }), ir);
  put(g, latheY(ribbon([[0.3, 0.09], [0.36, 0.04], [0.42, 0.01]], 0.024), { phi0: PI / 2 + 0.4, phiLen: PI - 0.8, sz: 1.05 }), ir);
  put(g, latheY(bandProfile(0.312, 0.33, 0.12, 0.18), { sz: 1.05 }), cloth(c.tc));
  for (const a of [PI / 2, -PI / 2, PI]) meridian(g, ironMat(0x3c3f44), sk, a, 0.022, { sz: 1.05, from: 2 });
  rivets(g, br, 0.322, 0.1, 12, 0.016, 0, PI * 2, 1.05);
  for (const s of [-1, 1]) frame(g, [s * 0.31, 0.04, 0.0], [0, s * 0.15, 0], f => put(f, slab([[0.12, 0.04], [0.12, -0.14], [0.02, -0.2], [-0.1, -0.14], [-0.1, 0.04]], 0.024, { bevel: 0.006 }), ir));
  put(g, latheY([[0, 0.0], [0.045, 0.0], [0.05, 0.03], [0.04, 0.09], [0.02, 0.11], [0, 0.11]], { seg: 10 }), br, 0, 0.18, 0.34);
  put(g, GEO.sph, B(0xffd27a), 0, 0.225, 0.365, 0, 0, 0, 0.032);
  put(g, latheZ([[0, 0.0], [0.03, 0.0], [0.03, 0.015], [0, 0.015]], 10), B(0xfff2c0), 0, 0.225, 0.39);
}

/** Warrior monk: incense marks on the shaved crown and a knotted headband with streaming tails. */
function monkHead(g: G, c: HeadCtx) {
  for (let r = 0; r < 2; r++) for (let k = 0; k < 3; k++) stud(g, B(0x8a5a3a), 0.014, (k - 1) * 0.06, 0.26 - r * 0.015, -0.02 - r * 0.07, 0.4, -PI / 2 + 0.3, 0);
  put(g, latheY(bandProfile(0.238, 0.262, 0.1, 0.16), { sz: 1.04, warp: v => { const r = Math.hypot(v.x, v.z); const want = 0.262 * Math.sqrt(Math.max(0, 1 - (v.y / 0.275) ** 2)) + (r > 0.25 ? 0.02 : 0.004); const k = want / Math.max(1e-4, r); v.x *= k; v.z *= k; } }), cloth(c.tc));
  put(g, GEO.sph, cloth(c.tc), 0, 0.13, -0.27, 0, 0, 0, 0.045);
  for (const s of [-1, 1]) put(g, sweep([[s * 0.02, 0.13, -0.28], [s * 0.08, 0.06, -0.38], [s * 0.12, -0.08, -0.4], [s * 0.16, -0.24, -0.36]], t => 0.028 * (1 - t * 0.3), { seg: 12, radial: 5, squash: 0.3, wide: [1, 0, 0] }), cloth(c.tc));
}

/* ---------------- dispatcher ---------------- */

/** Builds the headgear of `kind` on its head bone. Returns how far it rises above the skull (for name tags), or null if the kind keeps its own. */
export function wearHeadgear(kind: HumanKind, head: G, c: HeadCtx): number | null {
  switch (kind) {
    case "spear": spangenhelm(head, c); return 0.3;
    case "guardian": legionary(head, c); return 0.3;
    case "swordsman": sallet(head, c); return 0.2;
    case "halberdier": morion(head, c); return 0.3;
    case "crossbow": kettle(head, { metal: plateMat(0xa3acba), trim: steel(STEEL_DARK) }); return 0.2;
    case "skeleton": kettle(head, { metal: ironMat(0x6b5444), trim: ironMat(0x4a3a30), rust: true }); return 0.2;
    case "paladin": burgonet(head, c); return 0.35;
    case "king": crown(head); return 0.4;
    case "archer": bycocket(head, c); return 0.2;
    case "mage": wizardHat(head, M(c.tcd, 0.9), gildMat(), { gem: c.tc === 0 ? 0xd9a8ff : 0xd9a8ff }); return 0.55;
    case "frost": wizardHat(head, M(0x3a5f8f, 0.9), plateMat(0xd8e6f2), { frost: true, gem: 0x9fe0ff }); return 0.55;
    case "cleric": mitre(head); return 0.45;
    case "assassin":
      hood(head, cloth(0x24262e), { peak: 0.03, edge: cloth(0x1b1c22), tail: true });
      put(head, headShell(10, 15, 1, 9, 0.018, 0.02), cloth(0x1b1c22));
      return 0.2;
    case "necromancer":
      hood(head, cloth(0x2c2238), { peak: 0.26, edge: cloth(0x1c1626) });
      for (let i = 0; i < 5; i++) {
        const a = (i - 2) * 0.32;
        put(head, latheY([[0, 0], [0.026, 0.0], [0.014, 0.08], [0, 0.15 + (i === 2 ? 0.08 : 0)]], { seg: 6 }), boneMat(), Math.sin(a) * 0.33, 0.24, Math.cos(a) * 0.36, -0.3 * Math.cos(a), 0, 0.3 * Math.sin(a));
      }
      return 0.4;
    case "bonearcher": hood(head, cloth(c.tcd), { peak: 0.16, rags: cloth(dark(c.tcd, 0.6)) }); return 0.25;
    case "ninja": zukin(head, c); return 0.15;
    case "hoplite": corinthian(head, c); return 0.45;
    case "samurai": kabuto(head, c); return 0.4;
    case "valkyrie": wingedHelm(head); return 0.45;
    case "pirate": tricorne(head); return 0.25;
    case "orc": hornedHelm(head); return 0.35;
    case "snakearcher": turban(head); return 0.3;
    case "fanbearer": eboshi(head); return 0.55;
    case "harpooner": watchCap(head, c); return 0.25;
    case "bomber": aviator(head, c); return 0.15;
    case "elf": circlet(head); return null;
    case "zeus": laurel(head); return null;
    case "javelin": thracian(head, c); return 0.35;
    case "berserker": wolfPelt(head, c); return 0.3;
    case "shaman": ramSkull(head); return 0.4;
    case "troll": trollHead(head, c.skin); return null;
    case "giant": giantHead(head); return 0.15;
    case "zombie": zombieHead(head); return null;
    case "vampire": vampireHair(head); return null;
    case "sapper": sapperHelm(head, c); return 0.2;
    case "monk": monkHead(head, c); return null;
  }
  return null;
}
void IRON_UNUSED;
function IRON_UNUSED() { return [GOLD, LEATHER_DARK, STEEL_LIGHT, light, gold] as const; }
