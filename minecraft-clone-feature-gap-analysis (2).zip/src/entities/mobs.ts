import { SEA as SEA_LEVEL } from '../world/terrain';
import * as THREE from 'three';
import { endPillars, type Terrain } from '../world/terrain';
import { ID, resolve } from '../game/data';
import { random } from '../input/math';
import type { BossInfo } from '../game/types';

export type Species =
  | 'cow' | 'pig' | 'sheep' | 'chicken' | 'zombie' | 'skeleton' | 'creeper' | 'spider'
  | 'enderman' | 'villager' | 'wolf' | 'cat' | 'horse' | 'iron_golem' | 'fish' | 'dolphin'
  | 'blaze' | 'ghast' | 'wither' | 'dragon' | 'warden' | 'slime' | 'magma_cube' | 'pillager'
  | 'witch' | 'bee' | 'fox' | 'rabbit' | 'squid' | 'turtle' | 'shulker';

export interface MobHost {
  terrain: Terrain;
  position: THREE.Vector3;
  camera: THREE.PerspectiveCamera;
  time: number;
  dimension: string;
  dragonDefeated: boolean;
  getBlock(x: number, y: number, z: number): number;
  damage(n: number): void;
  addItem(n: string, c: number): boolean;
  addXp?(n: number): void;
  toast(j: string, e: string): void;
  sound(k: string, p?: { x: number; y: number; z: number }): void;
  explode(p: THREE.Vector3, r: number): void;
  teleport(x: number, y: number, z: number): void;
  openTrade(): void;
  onDragonDefeated(): void;
  onEnterGateway(): void;
  levitate(sec: number): void;
  particles: {
    burst(p: THREE.Vector3, c: string, n?: number, power?: number): void;
    spark?(p: THREE.Vector3, c: string, n?: number): void;
    drop(p: THREE.Vector3, n: string, c: number, col: string): void;
  };
}

interface Mob {
  id: number;
  species: Species;
  group: THREE.Group;
  legs: THREE.Object3D[];
  /** Walk cycle metadata per limb (pivot, stride phase, amplitude) plus its resting rotation. */
  limbs?: Limb[];
  walk?: number;
  swing?: number;
  lastX?: number;
  lastZ?: number;
  head: THREE.Object3D;
  woolCoat?: THREE.Object3D;
  collar?: THREE.Object3D;
  hp: number;
  maxHp: number;
  state: 'wander' | 'graze' | 'flee' | 'chase' | 'aim' | 'fuse' | 'teleport' | 'follow' | 'trade' | 'circle' | 'charge' | 'perch';
  phaseTimer: number;
  timer: number;
  attack: number;
  hurtTimer: number;
  dir: number;
  speed: number;
  target: THREE.Vector3;
  fuse: number;
  wool: boolean;
  tamed: boolean;
  love: number;
  egg: number;
  baby: boolean;
}

type LimbKind = 'leg' | 'arm' | 'wing' | 'spider' | 'tentacle';
interface Limb { node: THREE.Object3D; kind: LimbKind; phase: number; amp: number; baseX: number; baseY: number; baseZ: number; }
interface EndCrystal {
  group: THREE.Group;
  core: THREE.Mesh;
  shell: THREE.Mesh;
  pos: THREE.Vector3;
}
interface Projectile {
  kind: 'mob_arrow' | 'player_arrow' | 'ghast_fireball' | 'blaze_fireball' | 'dragon_fireball' | 'shulker_bullet' | 'ender_pearl' | 'ender_eye' | 'snowball' | 'trident' | 'potion';
  mesh: THREE.Mesh;
  v: THREE.Vector3;
  life: number;
  damage: number;
  target?: THREE.Vector3;
  gravity?: number;
  onEnd?: (pos: THREE.Vector3) => void;
  flame?: boolean;
  punch?: number;
}
interface Arrow {
  mesh: THREE.Mesh;
  v: THREE.Vector3;
  life: number;
  fromPlayer: boolean;
  damage: number;
}

const passive = new Set([
  'cow', 'pig', 'sheep', 'chicken', 'villager', 'wolf', 'cat', 'horse',
  'fish', 'dolphin', 'bee', 'fox', 'rabbit', 'squid', 'turtle',
]);

const drops: Record<Species, [string, number]> = {
  cow: ['raw_beef', 2], pig: ['porkchop', 2], sheep: ['white_wool', 1], chicken: ['feather', 2],
  zombie: ['rotten_flesh', 2], skeleton: ['bone', 2], creeper: ['gunpowder', 2], spider: ['string', 2],
  enderman: ['ender_pearl', 1], villager: ['bread', 1], wolf: ['bone', 1], cat: ['string', 1],
  horse: ['leather', 2], iron_golem: ['iron_ingot', 3], fish: ['cod', 1], dolphin: ['cod', 1],
  blaze: ['blaze_rod', 1], ghast: ['ghast_tear', 1], wither: ['nether_star', 1], dragon: ['dragon_breath', 4],
  warden: ['sculk', 2], slime: ['slime_ball', 2], magma_cube: ['magma_cream', 2],
  pillager: ['arrow', 3], witch: ['redstone', 2], bee: ['honeycomb', 1],
  fox: ['leather', 1], rabbit: ['rabbit_hide', 1], squid: ['ink_sac', 2], turtle: ['scute', 1], shulker: ['shulker_shell', 1],
};

export class MobManager {
  mobs: Mob[] = [];
  nextId = 1;
  rnd = random(78123);
  materials = new Map<string, THREE.MeshLambertMaterial>();
  hurtMat = new THREE.MeshLambertMaterial({ color: '#e84a3c', emissive: '#6a120a' });
  box = new THREE.BoxGeometry(1, 1, 1);
  spawnTimer = 0;
  arrows: Arrow[] = [];
  crystals: EndCrystal[] = [];
  projectiles: Projectile[] = [];
  emissiveMaterials = new Map<string, THREE.MeshBasicMaterial>();

  private _tmpA = new THREE.Vector3();
  private _tmpB = new THREE.Vector3();
  private _look = new THREE.Vector3();

  constructor(public scene: THREE.Scene, public host: MobHost) {
    this.populate();
  }

  mat(color: string) {
    let m = this.materials.get(color);
    if (!m) {
      m = new THREE.MeshLambertMaterial({ color });
      this.materials.set(color, m);
    }
    return m;
  }

  glowMat(color: string, opacity = 1) {
    const key = color + ':' + opacity;
    let m = this.emissiveMaterials.get(key);
    if (!m) {
      m = new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity });
      this.emissiveMaterials.set(key, m);
    }
    return m;
  }

  part(g: THREE.Object3D, color: string, x: number, y: number, z: number, w: number, h: number, d: number) {
    const m = new THREE.Mesh(this.box, this.mat(color));
    m.userData.baseMat = m.material;
    m.position.set(x, y, z);
    m.scale.set(w, h, d);
    m.castShadow = false;
    m.receiveShadow = true;
    g.add(m);
    return m;
  }

  model(species: Species) {
    const g = new THREE.Group();
    const legs: THREE.Object3D[] = [];
    const wings: THREE.Object3D[] = [];
    const head = new THREE.Group();
    g.add(head);
    let woolCoat: THREE.Object3D | undefined;
    let collar: THREE.Object3D | undefined;

    const eyes = (y: number, z: number, sep: number, color = '#171b17') => {
      this.part(head, color, -sep, y, z, 0.07, 0.07, 0.025);
      this.part(head, color, sep, y, z, 0.07, 0.07, 0.025);
    };
    const quadLegs = (color: string, w: number, h: number, d: number, x: number, z: number) => {
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
        const pivot = new THREE.Group();
        pivot.position.set(sx * x, h, sz * z);
        this.part(pivot, color, 0, -h / 2, 0, w, h, d);
        g.add(pivot);
        legs.push(pivot);
      }
    };

    if (species === 'dragon') {
      // Articulated Ender Dragon
      this.part(g, '#18141f', 0, 1.4, 0, 1.6, 1.3, 3.2);
      // Spine ridges
      for (let i = 0; i < 4; i++) this.part(g, '#3d334d', 0, 2.2, -1.0 + i * 0.75, 0.25, 0.35, 0.3);
      // Neck & Head
      head.position.set(0, 1.85, -2.3);
      this.part(g, '#1c1826', 0, 1.65, -1.8, 0.7, 0.7, 1.0);
      this.part(head, '#1e1928', 0, 0, 0, 1.0, 0.9, 1.2);
      this.part(head, '#241e30', 0, -0.1, -0.8, 0.75, 0.45, 0.9); // Snout
      this.part(head, '#3f3452', -0.35, 0.55, 0.25, 0.16, 0.4, 0.35); // Horns
      this.part(head, '#3f3452', 0.35, 0.55, 0.25, 0.16, 0.4, 0.35);
      eyes(0.15, -0.62, 0.3, '#e05cff');
      // Segmented Tail
      for (let i = 0; i < 6; i++) {
        this.part(g, i % 2 ? '#18141f' : '#262033', 0, 1.35 - i * 0.04, 1.8 + i * 0.7, 0.55 - i * 0.06, 0.5 - i * 0.05, 0.72);
      }
      // Flapping Wings
      for (const side of [-1, 1]) {
        const wingPivot = new THREE.Group();
        wingPivot.position.set(side * 0.85, 1.8, -0.5);
        this.part(wingPivot, '#2e273d', side * 1.9, 0.1, 0, 3.8, 0.18, 0.22);
        this.part(wingPivot, '#120e1a', side * 2.1, -0.02, 0.85, 4.0, 0.06, 1.8);
        g.add(wingPivot);
        wings.push(wingPivot);
      }
      g.scale.setScalar(1.35);
    } else if (species === 'shulker') {
      // Shulker shell & inner head
      this.part(g, '#7c4c80', 0, 0.22, 0, 0.95, 0.44, 0.95);
      head.position.set(0, 0.58, 0);
      this.part(head, '#e8dcb8', 0, 0, 0, 0.52, 0.5, 0.52);
      eyes(0.05, -0.27, 0.14, '#241c29');
      const lid = new THREE.Group();
      lid.position.set(0, 0.72, 0);
      this.part(lid, '#9b679f', 0, 0.2, 0, 0.95, 0.48, 0.95);
      g.add(lid);
      wings.push(lid);
    } else if (species === 'cow' || species === 'pig' || species === 'sheep' || species === 'wolf' || species === 'cat' || species === 'horse') {
      const horse = species === 'horse', small = species === 'cat' || species === 'wolf';
      const body = species === 'cow' ? '#665344' : species === 'pig' ? '#d99b91' : species === 'sheep' ? '#e4e2d4' : species === 'wolf' ? '#c5c7bd' : species === 'cat' ? '#bd8c54' : '#8b6747';
      const h = horse ? 1.15 : small ? 0.48 : 0.78;
      this.part(g, body, 0, h, 0, small ? 0.42 : 0.72, small ? 0.4 : 0.65, horse ? 1.35 : 1.05);
      head.position.set(0, h + (horse ? 0.55 : 0.2), -0.6);
      this.part(head, body, 0, 0, 0, 0.43, horse ? 0.65 : 0.43, 0.48);
      this.part(head, species === 'pig' ? '#c4837c' : species === 'cow' ? '#b7a38b' : '#b9a58b', 0, -0.1, -0.28, 0.3, 0.18, 0.13);
      if (species === 'pig') {
        this.part(head, '#8c4e47', -0.07, -0.1, -0.35, 0.05, 0.08, 0.02);
        this.part(head, '#8c4e47', 0.07, -0.1, -0.35, 0.05, 0.08, 0.02);
      }
      eyes(0.07, -0.25, 0.14);
      if (species === 'cow') {
        this.part(g, '#dedbd0', 0.365, h + 0.05, 0.1, 0.02, 0.35, 0.4);
        this.part(g, '#dedbd0', -0.365, h - 0.1, -0.25, 0.02, 0.28, 0.3);
        this.part(head, '#d9d1b8', -0.22, 0.27, 0, 0.1, 0.18, 0.1);
        this.part(head, '#d9d1b8', 0.22, 0.27, 0, 0.1, 0.18, 0.1);
      }
      if (species === 'sheep') {
        woolCoat = this.part(g, '#f2f0e6', 0, h + 0.02, 0, 0.84, 0.78, 1.12);
      }
      if (species === 'cat' || species === 'wolf') {
        this.part(head, body, -0.15, 0.27, 0, 0.12, 0.2, 0.1);
        this.part(head, body, 0.15, 0.27, 0, 0.12, 0.2, 0.1);
        this.part(g, body, 0, h + 0.1, 0.65, 0.12, 0.12, 0.5);
        if (species === 'wolf') {
          collar = this.part(g, '#d64538', 0, h + 0.06, -0.36, 0.46, 0.44, 0.12);
          collar.visible = false;
        }
      }
      if (species === 'horse') {
        this.part(g, '#463b30', 0, h + 0.45, -0.45, 0.16, 0.6, 0.3);
        this.part(g, '#463b30', 0, h, 0.8, 0.14, 0.6, 0.14);
      }
      quadLegs(species === 'cow' ? '#514638' : body, small ? 0.13 : 0.18, h, small ? 0.13 : 0.18, small ? 0.15 : 0.26, horse ? 0.48 : 0.34);
    } else if (species === 'chicken') {
      this.part(g, '#eee9d9', 0, 0.48, 0, 0.4, 0.42, 0.55);
      head.position.set(0, 0.82, -0.22);
      this.part(head, '#f3efdf', 0, 0, 0, 0.3, 0.32, 0.3);
      this.part(head, '#e6b344', 0, -0.05, -0.22, 0.22, 0.1, 0.16);
      this.part(head, '#c94b3c', 0, -0.2, -0.18, 0.12, 0.16, 0.1);
      eyes(0.05, -0.16, 0.1);
      // Two thin legs on the hip pivots, plus wings that rotate at the shoulder.
      for (const sx of [-1, 1]) {
        const leg = new THREE.Group();
        leg.position.set(sx * 0.09, 0.28, 0);
        this.part(leg, '#cf9c43', 0, -0.14, 0, 0.055, 0.28, 0.055);
        g.add(leg);
        legs.push(leg);
      }
      for (const sx of [-1, 1]) {
        const wing = new THREE.Group();
        wing.position.set(sx * 0.2, 0.52, 0);
        this.part(wing, '#ded8c7', sx * 0.13, 0, 0, 0.26, 0.06, 0.34);
        g.add(wing);
        legs.push(wing);
      }
    } else if (species === 'creeper') {
      this.part(g, '#6b9b4d', 0, 0.85, 0, 0.5, 0.9, 0.35);
      head.position.set(0, 1.55, 0);
      this.part(head, '#76a957', 0, 0, 0, 0.62, 0.62, 0.62);
      this.part(head, '#233323', 0, -0.08, -0.32, 0.16, 0.18, 0.02);
      this.part(head, '#233323', -0.12, -0.02, -0.32, 0.15, 0.13, 0.02);
      this.part(head, '#233323', 0.12, -0.02, -0.32, 0.15, 0.13, 0.02);
      this.part(head, '#233323', 0, -0.2, -0.32, 0.34, 0.12, 0.02);
      quadLegs('#5d8743', 0.2, 0.4, 0.24, 0.17, 0.18);
    } else if (species === 'spider') {
      this.part(g, '#3b302b', 0, 0.45, 0.2, 0.8, 0.42, 0.9);
      head.position.set(0, 0.45, -0.5);
      this.part(head, '#302724', 0, 0, 0, 0.55, 0.38, 0.5);
      eyes(0.05, -0.26, 0.15, '#d44732');
      for (const s of [-1, 1]) for (let i = 0; i < 4; i++) {
        const pivot = new THREE.Group();
        pivot.position.set(s * 0.4, 0.45, -0.35 + i * 0.25);
        this.part(pivot, '#342b26', s * 0.45, 0, 0, 0.9, 0.1, 0.1);
        pivot.rotation.z = s * 0.25;
        g.add(pivot);
        legs.push(pivot);
      }
    } else if (species === 'blaze') {
      this.part(g, '#e8a832', 0, 0.9, 0, 0.5, 0.8, 0.5);
      head.position.set(0, 1.6, 0);
      this.part(head, '#f0b840', 0, 0, 0, 0.5, 0.5, 0.5);
      eyes(0.05, -0.26, 0.13, '#7a4a12');
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * 6.28;
        this.part(g, '#d89a28', Math.cos(a) * 0.4, 0.6 + Math.sin(i) * 0.3, Math.sin(a) * 0.4, 0.15, 0.5, 0.15);
      }
    } else if (species === 'ghast') {
      this.part(g, '#e8e8e8', 0, 1.2, 0, 1.2, 1.2, 1.2);
      head.position.set(0, 1.2, -0.6);
      this.part(head, '#f0f0f0', 0, 0, 0, 0.8, 0.8, 0.8);
      eyes(0.1, -0.4, 0.2, '#5a5a5a');
      this.part(head, '#5a5a5a', 0, -0.2, -0.41, 0.3, 0.15, 0.02);
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * 6.28;
        this.part(g, '#d8d8d8', Math.cos(a) * 0.7, 0.3, Math.sin(a) * 0.7, 0.12, 0.6, 0.12);
      }
    } else if (species === 'wither') {
      this.part(g, '#2a2a2a', 0, 1.1, 0, 0.6, 0.9, 0.6);
      head.position.set(0, 1.8, 0);
      this.part(head, '#3a3a3a', 0, 0, 0, 0.6, 0.6, 0.6);
      eyes(0.05, -0.3, 0.15, '#c8c8c8');
      this.part(g, '#1a1a1a', -0.5, 1.3, 0, 0.2, 0.7, 0.2);
      this.part(g, '#1a1a1a', 0.5, 1.3, 0, 0.2, 0.7, 0.2);
      quadLegs('#2a2a2a', 0.18, 0.6, 0.18, 0.18, 0.18);
    } else if (species === 'warden') {
      this.part(g, '#2a3a4a', 0, 1.2, 0, 0.9, 1.0, 0.7);
      head.position.set(0, 2.0, -0.3);
      this.part(head, '#3a4a5a', 0, 0, 0, 0.7, 0.7, 0.7);
      eyes(0.1, -0.35, 0.2, '#4ac8c8');
      this.part(g, '#1a2a3a', 0, 1.8, -0.5, 0.2, 0.8, 0.2);
      quadLegs('#2a3a4a', 0.25, 0.9, 0.25, 0.3, 0.3);
    } else if (species === 'slime' || species === 'magma_cube') {
      const col = species === 'slime' ? '#7ac74f' : '#c85a20';
      this.part(g, col, 0, 0.4, 0, 0.8, 0.8, 0.8);
      head.position.set(0, 0.4, -0.4);
      this.part(head, col, 0, 0, 0, 0.6, 0.6, 0.6);
      eyes(0.05, -0.3, 0.15, '#2a2a2a');
    } else if (species === 'pillager' || species === 'witch') {
      const skin = '#ba9472', shirt = species === 'pillager' ? '#5a4a3a' : '#4a3a6a';
      this.part(g, shirt, 0, 1.05, 0, 0.52, 0.7, 0.3);
      head.position.set(0, 1.65, 0);
      this.part(head, skin, 0, 0, 0, 0.5, 0.5, 0.5);
      eyes(0.05, -0.26, 0.13, '#202820');
      if (species === 'witch') {
        this.part(head, '#3a2a4a', 0, 0.35, 0, 0.6, 0.15, 0.6);
        this.part(g, '#3a2a4a', 0, 1.05, -0.28, 0.65, 0.22, 0.2);
      }
      for (const s of [-1, 1]) {
        const leg = new THREE.Group(); leg.position.set(s * 0.14, 0.7, 0);
        this.part(leg, '#4a3a2a', 0, -0.35, 0, 0.22, 0.7, 0.23); g.add(leg); legs.push(leg);
        const arm = new THREE.Group(); arm.position.set(s * 0.37, 1.35, 0);
        this.part(arm, skin, 0, -0.32, 0, 0.17, 0.65, 0.18); g.add(arm); legs.push(arm);
      }
    } else if (species === 'bee') {
      this.part(g, '#e8c832', 0, 0.3, 0, 0.4, 0.3, 0.5);
      head.position.set(0, 0.3, -0.3);
      this.part(head, '#e8c832', 0, 0, 0, 0.3, 0.3, 0.3);
      eyes(0.05, -0.15, 0.1, '#2a2a2a');
      this.part(g, '#2a2a2a', 0, 0.3, 0, 0.42, 0.1, 0.3);
      for (const sx of [-1, 1]) {
        const wing = new THREE.Group();
        wing.position.set(sx * 0.15, 0.48, 0);
        this.part(wing, '#ffffff', sx * 0.1, 0, 0, 0.2, 0.03, 0.3);
        g.add(wing);
        legs.push(wing);
      }
    } else if (species === 'fox' || species === 'rabbit') {
      const col = species === 'fox' ? '#c87a3a' : '#d8d8d8';
      this.part(g, col, 0, 0.35, 0, 0.4, 0.35, 0.6);
      head.position.set(0, 0.55, -0.35);
      this.part(head, col, 0, 0, 0, 0.35, 0.35, 0.35);
      eyes(0.05, -0.18, 0.12, '#2a2a2a');
      if (species === 'fox') {
        this.part(head, col, -0.12, 0.22, 0, 0.1, 0.2, 0.08);
        this.part(head, col, 0.12, 0.22, 0, 0.1, 0.2, 0.08);
      } else {
        this.part(head, col, -0.1, 0.3, 0, 0.08, 0.3, 0.05);
        this.part(head, col, 0.1, 0.3, 0, 0.08, 0.3, 0.05);
      }
      quadLegs(col, 0.08, 0.25, 0.08, 0.12, 0.18);
    } else if (species === 'squid' || species === 'turtle') {
      const col = species === 'squid' ? '#4a4a8a' : '#6a9a5a';
      this.part(g, col, 0, 0.4, 0, 0.5, 0.6, 0.7);
      head.position.set(0, 0.4, -0.35);
      this.part(head, col, 0, 0, 0, 0.4, 0.4, 0.4);
      eyes(0.05, -0.2, 0.12, '#ffffff');
      if (species === 'squid') for (let i = 0; i < 6; i++) { const a = (i / 6) * 6.28; const t = new THREE.Group(); t.position.set(Math.cos(a) * 0.25, 0.2, Math.sin(a) * 0.25); this.part(t, col, 0, -0.15, 0, 0.08, 0.3, 0.08); g.add(t); legs.push(t); }
      else quadLegs(col, 0.1, 0.2, 0.1, 0.15, 0.2);
    } else if (species === 'fish' || species === 'dolphin') {
      const col = species === 'fish' ? '#6fa6a3' : '#829fae';
      this.part(g, col, 0, 0.35, 0, 0.32, 0.32, 0.8);
      head.position.set(0, 0.35, -0.4);
      this.part(head, col, 0, 0, 0, 0.28, 0.28, 0.3);
      eyes(0.05, -0.16, 0.1);
      this.part(g, col, 0, 0.35, 0.55, 0.08, 0.4, 0.3);
      this.part(g, col, 0, 0.58, 0.05, 0.08, 0.25, 0.3);
    } else {
      const sk = species === 'skeleton', en = species === 'enderman', v = species === 'villager', golem = species === 'iron_golem', z = species === 'zombie';
      const skin = sk ? '#d5d4c5' : en ? '#292630' : v ? '#ba9472' : golem ? '#c3c2ad' : '#668b4d';
      const shirt = sk ? '#c9c9bb' : en ? '#24222b' : v ? '#8b6547' : golem ? '#b4b6a2' : '#3f8d91';
      const pants = sk ? '#d0d0c2' : en ? '#211f29' : v ? '#6f513c' : golem ? '#969d88' : '#555b83';
      const scale = en ? 1.45 : golem ? 1.3 : 1;
      g.scale.setScalar(scale);
      this.part(g, shirt, 0, 1.05, 0, golem ? 0.85 : 0.52, 0.7, 0.3);
      head.position.set(0, 1.65, 0);
      this.part(head, skin, 0, 0, 0, 0.5, 0.5, 0.5);
      eyes(0.05, -0.26, 0.13, en ? '#b78ce0' : '#202820');
      if (v) { this.part(head, '#9b7757', 0, -0.08, -0.34, 0.14, 0.28, 0.2); this.part(head, '#6d5138', 0, 0.25, -0.26, 0.52, 0.12, 0.12); this.part(g, '#a47b53', 0, 1.05, -0.28, 0.65, 0.22, 0.2); }
      if (golem) { this.part(head, '#7c8b54', 0, -0.16, -0.27, 0.2, 0.14, 0.04); this.part(g, '#6e8a46', -0.44, 1.15, 0, 0.12, 0.45, 0.32); }
      for (const s of [-1, 1]) {
        const leg = new THREE.Group(); leg.position.set(s * 0.14, 0.7, 0); this.part(leg, pants, 0, -0.35, 0, en ? 0.13 : 0.22, 0.7, en ? 0.13 : 0.23); g.add(leg); legs.push(leg);
        const arm = new THREE.Group(); arm.position.set(s * (golem ? 0.57 : 0.37), 1.35, 0); this.part(arm, skin, 0, -0.32, 0, golem ? 0.24 : 0.17, golem ? 0.9 : 0.65, 0.18);
        if (z || en) arm.rotation.x = -1.2;
        g.add(arm); legs.push(arm);
      }
      if (sk) { this.part(g, '#7d6949', 0.45, 1.05, -0.3, 0.06, 0.8, 0.08); this.part(g, '#c9c4ad', 0.45, 1.05, -0.35, 0.04, 0.9, 0.02); }
    }
    // Limb rig: which entries of `legs` are legs, arms, wings, spider legs or tentacles, and the stride phase of each.
    const biped = species === 'zombie' || species === 'skeleton' || species === 'villager' || species === 'enderman' || species === 'iron_golem' || species === 'pillager' || species === 'witch';
    const limbs: Limb[] = legs.map((node, i) => {
      const baseX = node.rotation.x, baseY = node.rotation.y, baseZ = node.rotation.z;
      const make = (kind: LimbKind, phase: number, amp: number): Limb => ({ node, kind, phase, amp, baseX, baseY, baseZ });
      if (species === 'spider') return make('spider', (i < 4 ? [0, Math.PI, 0, Math.PI] : [Math.PI, 0, Math.PI, 0])[i % 4], 0.26);
      if (species === 'dragon') return make('wing', Math.PI * (i % 2), 0.45);
      if (species === 'chicken') return i < 2 ? make('leg', Math.PI * i, 0.55) : make('wing', Math.PI * (i - 2), 0.4);
      if (species === 'bee') return make('wing', Math.PI * i, 0.5);
      if (species === 'squid') return make('tentacle', (i / Math.max(1, legs.length)) * Math.PI * 2, 0.25);
      if (biped) return i % 2 === 0 ? make('leg', i === 0 ? 0 : Math.PI, 0.55) : make('arm', i === 1 ? Math.PI : 0, baseX < -0.5 ? 0.12 : 0.42);
      const quad = [0, Math.PI, Math.PI, 0];
      return make('leg', quad[i % 4], 0.52);
    });
    return { g, legs, head, woolCoat, collar, limbs };
  }

  private setHurtTint(m: Mob, hurt: boolean) {
    m.group.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        if (!mesh.userData.baseMat) mesh.userData.baseMat = mesh.material;
        mesh.material = hurt ? this.hurtMat : mesh.userData.baseMat;
      }
    });
  }

  spawn(species: Species, x: number, z: number, baby = false, exactY?: number) {
    const h = this.host.terrain.height(x, z);
    const y = exactY ?? (species === 'dragon' ? 40 : h + 1);
    if (species === 'fish' || species === 'dolphin' || species === 'squid') {
      if (h >= SEA_LEVEL) return;
    } else if (species !== 'dragon' && this.host.dimension === 'overworld' && y < SEA_LEVEL + 1) return;

    const { g, legs, head, woolCoat, collar, limbs } = this.model(species);
    g.position.set(x, y, z);
    if (baby) g.scale.multiplyScalar(0.5);
    this.scene.add(g);
    const maxHp =
      species === 'dragon' ? 200 :
      species === 'wither' ? 150 :
      species === 'iron_golem' ? 100 :
      species === 'warden' ? 120 :
      species === 'enderman' ? 40 :
      species === 'horse' ? 30 :
      species === 'shulker' ? 30 : species === 'zombie' || species === 'skeleton' || species === 'creeper' ? 20 : 10;

    const m: Mob = {
      id: this.nextId++,
      species,
      group: g,
      legs,
      limbs,
      walk: Math.random() * Math.PI * 2,
      swing: 0,
      lastX: x,
      lastZ: z,
      head,
      woolCoat,
      collar,
      hp: maxHp,
      maxHp,
      state: species === 'dragon' ? 'circle' : 'wander',
      phaseTimer: 8 + this.rnd() * 6,
      timer: 1 + this.rnd() * 4,
      attack: 0,
      hurtTimer: 0,
      dir: this.rnd() * Math.PI * 2,
      speed: species === 'dragon' ? 9 : species === 'horse' ? 2.4 : species === 'shulker' ? 0 : species === 'chicken' ? 1.0 : 1.25,
      target: g.position.clone(),
      fuse: 0,
      wool: true,
      tamed: false,
      love: 0,
      egg: 20 + this.rnd() * 40,
      baby,
    };
    this.mobs.push(m);
    return m;
  }

  spawnCrystal(x: number, y: number, z: number) {
    const group = new THREE.Group();
    group.position.set(x + 0.5, y, z + 0.5);
    const base = new THREE.Mesh(this.box, this.mat('#352d42'));
    base.scale.set(0.85, 0.25, 0.85);
    base.position.y = 0.125;
    const core = new THREE.Mesh(this.box, this.glowMat('#eb52eb', 1));
    core.scale.set(0.6, 0.6, 0.6);
    core.position.y = 1.05;
    const shell = new THREE.Mesh(this.box, this.glowMat('#ffc9ff', 0.45));
    shell.scale.set(0.85, 0.85, 0.85);
    shell.position.y = 1.05;
    group.add(base, core, shell);
    this.scene.add(group);
    this.crystals.push({ group, core, shell, pos: group.position });
  }

  populate() {
    this.clear();
    if (this.host.dimension === 'overworld') {
      const p = this.host.position;
      const list: Species[] = ['cow', 'pig', 'sheep', 'chicken', 'cow', 'sheep', 'villager', 'villager', 'wolf', 'cat', 'horse', 'bee', 'rabbit', 'fox'];
      for (let i = 0; i < list.length; i++) {
        const a = i * 2.15, r = 6 + i * 1.55;
        this.spawn(list[i], p.x + Math.cos(a) * r, p.z + Math.sin(a) * r);
      }
      for (const [x, z] of [[15, 5], [19, -8], [5, 20]]) this.spawn('fish', x, z);
    } else if (this.host.dimension === 'nether') {
      for (const [sp, x, y, z] of [
        ['ghast', 18, 36, -15], ['ghast', -22, 39, 14],
        ['blaze', 35, 27, 35], ['blaze', 39, 27, 39], ['blaze', 34, 27, 41],
        ['magma_cube', 14, 26, 8], ['enderman', -14, 26, -12],
      ] as [Species, number, number, number][]) {
        this.spawn(sp, x, z, false, y);
      }
    } else if (this.host.dimension === 'end') {
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        this.spawn('enderman', Math.cos(a) * 18, Math.sin(a) * 18, false, 28);
      }
      // End City Shulkers
      for (const [sx, sy, sz] of [[515, 28, 10], [523, 35, 16], [519, 49, 13], [534, 42, -10]]) {
        this.spawn('shulker', sx, sz, false, sy);
      }
      if (!this.host.dragonDefeated) {
        for (const pil of endPillars()) {
          this.spawnCrystal(pil.x, pil.h + 2, pil.z);
        }
        this.spawn('dragon', 0, 0, false, 44);
      }
    }
  }

  clear() {
    for (const m of this.mobs) this.scene.remove(m.group);
    for (const c of this.crystals) this.scene.remove(c.group);
    for (const p of this.projectiles) this.scene.remove(p.mesh);
    this.mobs = [];
    this.crystals = [];
    this.projectiles = [];
  }

  getBossInfo(): BossInfo | null {
    const boss = this.mobs.find(m => m.species === 'dragon' || m.species === 'wither' || m.species === 'warden');
    if (!boss) return null;
    const jaMap: Record<string, string> = { dragon: 'エンダードラゴン', wither: 'ウィザー', warden: 'ウォーデン' };
    return {
      name: boss.species === 'dragon' ? 'Ender Dragon' : boss.species.replace(/_/g, ' '),
      ja: jaMap[boss.species] ?? boss.species,
      hp: Math.max(0, Math.ceil(boss.hp)),
      maxHp: boss.maxHp,
      color: boss.species === 'dragon' ? '#c864e8' : '#7b8098',
      crystals: boss.species === 'dragon' ? this.crystals.length : 0,
    };
  }

  /** Boss bar data (Ender Dragon, Wither or Warden) including the number of live End Crystals. */
  bossInfo(): BossInfo | null {
    const boss = this.mobs.find(m => (m.species === 'dragon' || m.species === 'wither' || m.species === 'warden') && m.group.position.distanceTo(this.host.position) < 120);
    if (!boss) return null;
    const jaMap: Record<string, string> = { dragon: 'エンダードラゴン', wither: 'ウィザー', warden: 'ウォーデン' };
    return {
      name: boss.species === 'dragon' ? 'Ender Dragon' : boss.species.replace(/_/g, ' '),
      ja: jaMap[boss.species] ?? boss.species,
      hp: Math.max(0, Math.ceil(boss.hp)),
      maxHp: boss.maxHp,
      color: boss.species === 'dragon' ? '#c864e8' : '#7b8098',
      crystals: boss.species === 'dragon' ? this.crystals.length : 0,
    };
  }

  destroyCrystal(idx: number) {
    const c = this.crystals[idx];
    if (!c) return;
    const pos = c.pos.clone().add(new THREE.Vector3(0, 1, 0));
    this.scene.remove(c.group);
    this.crystals.splice(idx, 1);
    this.host.explode(pos, 3);
    this.host.particles.burst(pos, '#eb52eb', 28, 7);
    this.host.toast('エンドクリスタルを破壊しました！', 'End Crystal destroyed!');
  }

  hit(origin: THREE.Vector3, dir: THREE.Vector3, damage: number, critical = false) {
    // Check End Crystals first
    for (let i = 0; i < this.crystals.length; i++) {
      const cpos = this.crystals[i].pos.clone().add(new THREE.Vector3(0, 1, 0));
      const v = cpos.sub(origin);
      const d = v.length();
      if (d < 6 && v.normalize().dot(dir) > 0.9) {
        this.destroyCrystal(i);
        return true;
      }
    }
    // Check Ghast fireball deflection
    for (const p of this.projectiles) {
      if (p.kind === 'ghast_fireball') {
        const v = p.mesh.position.clone().sub(origin);
        if (v.length() < 5 && v.normalize().dot(dir) > 0.88) {
          p.v.copy(dir).multiplyScalar(18);
          this.host.sound('stone', p.mesh.position);
          return true;
        }
      }
    }

    let best: Mob | null = null, bestD = 6;
    for (const m of this.mobs) {
      const centerH = m.species === 'dragon' ? 1.5 : 0.9;
      const v = m.group.position.clone().add(new THREE.Vector3(0, centerH, 0)).sub(origin);
      const d = v.length();
      const dot = v.normalize().dot(dir);
      const reach = m.species === 'dragon' ? 7 : 5;
      const cone = m.species === 'dragon' ? 0.86 : 0.93;
      if (d < Math.min(bestD, reach) && dot > cone) {
        best = m;
        bestD = d;
      }
    }
    if (!best) return false;
    this.lastHit = best;
    const finalDamage = critical ? Math.ceil(damage * 1.5) : damage;
    best.hp -= finalDamage;
    best.hurtTimer = 0.24;
    this.setHurtTint(best, true);
    if (best.species !== 'dragon' && best.species !== 'shulker') {
      best.state = passive.has(best.species) ? 'flee' : 'chase';
      best.timer = 4;
      best.group.position.addScaledVector(dir, 0.5);
    }
    const center = best.group.position.clone().add(new THREE.Vector3(0, 1, 0));
    this.host.particles.burst(center, best.species === 'dragon' ? '#d966ff' : '#b65343', critical ? 16 : 10);
    if (critical) {
      this.host.particles.spark?.(center, '#ffd866', 10);
      this.host.sound('critical', best.group.position);
    } else {
      this.host.sound('hurt', best.group.position);
    }
    if (best.hp <= 0) this.kill(best);
    return true;
  }

  kill(m: Mob) {
    const [name, count0] = drops[m.species];
    const count = count0 + (this.looting > 0 && count0 > 0 ? Math.floor(Math.random() * (this.looting + 1)) : 0);
    this.host.particles.drop(m.group.position.clone().add(new THREE.Vector3(0, 0.5, 0)), name, count, resolve(name)?.color || '#b88b65');
    this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 0.8, 0)), m.species === 'dragon' ? '#e599ff' : '#d7d0b8', m.species === 'dragon' ? 60 : 18, m.species === 'dragon' ? 9 : 4);
    this.scene.remove(m.group);
    this.mobs = this.mobs.filter(x => x !== m);
    this.host.addXp?.(m.species === 'dragon' ? 100 : m.species === 'wither' ? 50 : passive.has(m.species) ? 3 : 6);
    if (m.species === 'dragon') {
      this.host.onDragonDefeated();
    }
  }

  /** Applies damage to one mob with feedback (used by mob-vs-mob fights and projectiles). */
  private damageMob(m: Mob, damage: number, dir?: THREE.Vector3, critical = false) {
    const finalDamage = critical ? Math.ceil(damage * 1.5) : damage;
    m.hp -= finalDamage;
    m.hurtTimer = 0.24;
    this.setHurtTint(m, true);
    if (m.species !== 'dragon' && m.species !== 'shulker') {
      m.state = passive.has(m.species) ? 'flee' : 'chase';
      m.timer = 4;
      if (dir) m.group.position.addScaledVector(dir, 0.5);
    }
    const center = m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0));
    this.host.particles.burst(center, m.species === 'dragon' ? '#d966ff' : '#c74c3c', critical ? 16 : 8);
    this.host.sound(critical ? 'critical' : 'hurt', m.group.position);
    if (m.hp <= 0) this.kill(m);
  }

  interact(origin: THREE.Vector3, dir: THREE.Vector3, item: string) {
    for (const m of this.mobs) {
      const v = m.group.position.clone().add(new THREE.Vector3(0, 0.8, 0)).sub(origin);
      if (v.length() > 4 || v.normalize().dot(dir) < 0.9) continue;
      if (m.species === 'villager') { this.host.openTrade(); return true; }
      if ((m.species === 'cow' || m.species === 'sheep' || m.species === 'pig' || m.species === 'chicken' || m.species === 'wolf') && item === 'wheat') {
        m.love = 30; m.state = 'follow';
        this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 1.3, 0)), '#d85b65', 6, 1);
        return true;
      }
      if (m.species === 'wolf' && item === 'bone' && !m.tamed) {
        m.tamed = true;
        m.state = 'follow';
        if (m.collar) m.collar.visible = true;
        this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0)), '#e84a5f', 12, 1.5);
        this.host.toast('オオカミが懐きました！', 'Wolf tamed!');
        return true;
      }
      if (m.species === 'cow' && item === 'bucket') { this.host.addItem('milk_bucket', 1); return true; }
      if (m.species === 'sheep' && item === 'shears' && m.wool) {
        m.wool = false;
        if (m.woolCoat) m.woolCoat.visible = false;
        this.host.addItem('white_wool', 2);
        this.host.sound('grass', m.group.position);
        return true;
      }
      if (m.species === 'horse') {
        m.state = 'follow';
        m.tamed = true;
        this.host.toast('馬を手なずけました', 'Horse tamed');
        return true;
      }
    }
    return false;
  }

  lastHit: Mob | null = null;
  /** Looting level of the weapon that lands the next kill (extra drops). */
  looting = 0;
  /** Damages every mob within r of pos (sweep attacks, splash potions, thorns). Returns the number of mobs hit. */
  hurtNear(pos: THREE.Vector3, r: number, damage: number, exclude?: Mob | null) {
    let n = 0;
    for (const m of [...this.mobs]) { if (m === exclude || m.group.position.distanceTo(pos) > r) continue; this.damageMob(m, damage); n++; }
    return n;
  }
  extraDamage(m: Mob, damage: number) { if (damage > 0 && this.mobs.includes(m)) this.damageMob(m, damage); }
  nearestHostile(pos: THREE.Vector3, r: number): Mob | null {
    let best: Mob | null = null, bestD = r;
    for (const m of this.mobs) { if (passive.has(m.species)) continue; const d = m.group.position.distanceTo(pos); if (d < bestD) { bestD = d; best = m; } }
    return best;
  }

  shoot(m: Mob) {
    // Each shooter uses its vanilla projectile so the projectile itself can be dodged or deflected.
    const kind = m.species === 'ghast' ? 'ghast_fireball' : m.species === 'blaze' ? 'blaze_fireball' : m.species === 'dragon' ? 'dragon_fireball' : m.species === 'shulker' ? 'shulker_bullet' : 'mob_arrow';
    const from = m.group.position.clone().add(new THREE.Vector3(0, m.species === 'dragon' ? 1.8 : 1.4, 0));
    this.launchProjectile(kind, from, this.host.camera.position.clone().sub(from).normalize(), kind === 'mob_arrow' ? 14 : kind === 'dragon_fireball' ? 12 : 9);
    this.host.sound('bow', m.group.position);
  }

  shootPlayerArrow(origin: THREE.Vector3, dir: THREE.Vector3, speed = 26, damage = 7, extra: { flame?: boolean; punch?: number } = {}) {
    this.launchProjectile('player_arrow', origin.clone().addScaledVector(dir, 0.7), dir, speed, undefined, { damage, gravity: 6, ...extra });
    this.host.sound('bow');
  }

  update(dt: number, daylight: number, peaceful: boolean) {
    const now = performance.now();
    this.timeline += dt;
    this.updateCrystals(dt);
    this.updateProjectiles(dt);
    this.spawnTimer += dt;
    if (this.spawnTimer > 8 && this.mobs.length < 24) {
      this.spawnTimer = 0;
      const a = this.rnd() * 6.28, r = 18 + this.rnd() * 15;
      const x = this.host.position.x + Math.cos(a) * r, z = this.host.position.z + Math.sin(a) * r;
      const biome = this.host.terrain.biome(x, z);
      if (this.host.dimension === 'overworld') {
        // Wiki: no hostile mobs spawn in mushroom fields, at any light level.
        if (biome !== 'mushroom_fields' && !peaceful && daylight < 0.25) this.spawn((['zombie', 'skeleton', 'creeper', 'spider', 'enderman'] as Species[])[Math.floor(this.rnd() * 5)], x, z);
      } else if (this.host.dimension === 'nether' && !peaceful) {
        const table: Record<string, Species[]> = {
          nether_wastes: ['ghast', 'magma_cube', 'enderman', 'pig'],
          soul_sand_valley: ['skeleton', 'ghast', 'enderman'],
          crimson_forest: ['enderman'],
          warped_forest: ['enderman'],
          basalt_deltas: ['ghast', 'magma_cube'],
        };
        const list = table[biome] ?? ['magma_cube'];
        this.spawn(list[Math.floor(this.rnd() * list.length)], x, z);
      }
    }

    for (let idx = this.mobs.length - 1; idx >= 0; idx--) {
      const m = this.mobs[idx];
      const hostile = !passive.has(m.species) && m.species !== 'iron_golem';
      // Wiki: mushroom fields are the one overworld biome where hostile mobs never appear; despawn any that wander in.
      if (hostile && this.host.dimension === 'overworld' && this.host.terrain.biome(m.group.position.x, m.group.position.z) === 'mushroom_fields') {
        this.scene.remove(m.group);
        this.mobs.splice(idx, 1);
        continue;
      }
      if (peaceful && hostile) {
        this.scene.remove(m.group);
        this.mobs.splice(idx, 1);
        continue;
      }

      if (m.hurtTimer > 0) {
        m.hurtTimer -= dt;
        if (m.hurtTimer <= 0) this.setHurtTint(m, false);
      }

      m.timer -= dt;
      m.attack -= dt;
      m.love = Math.max(0, m.love - dt);

      const tx = this.host.position.x - m.group.position.x;
      const ty = this.host.position.y - m.group.position.y;
      const tz = this.host.position.z - m.group.position.z;
      const dist = Math.hypot(tx, ty, tz);

      // Undead burn in sunlight
      if (this.host.dimension === 'overworld' && daylight > 0.58 && (m.species === 'zombie' || m.species === 'skeleton')) {
        if (m.attack <= 0 && m.hurtTimer <= 0) {
          this._tmpB.copy(m.group.position); this._tmpB.y += 1.4;
          this.host.particles.spark?.(this._tmpB, '#ff9436', 4);
          m.hp -= 2;
          m.hurtTimer = 0.2;
          this.setHurtTint(m, true);
          m.attack = 1.6;
          if (m.hp <= 0) { this.kill(m); continue; }
        }
      }

      let move = 0;

      if (m.species === 'dragon') {
        // Three phases like the vanilla fight: circle the central island, dive at the player, then perch in the middle.
        m.phaseTimer -= dt;
        if (m.phaseTimer <= 0) {
          if (m.state === 'circle') { m.state = 'charge'; m.phaseTimer = 3.5; }
          else if (m.state === 'charge') { m.state = 'perch'; m.phaseTimer = 6; }
          else { m.state = 'circle'; m.phaseTimer = 9 + this.rnd() * 5; }
        }
        const center = m.state === 'perch';
        const targetX = center ? 0 : Math.cos(now * 0.0004 + m.id) * 18;
        const targetZ = center ? 0 : Math.sin(now * 0.0004 + m.id) * 18;
        const targetY = center ? 31 : m.state === 'charge' ? this.host.position.y + 4 : 36 + Math.sin(now * 0.001) * 3;
        const tx2 = m.state === 'charge' ? this.host.position.x : targetX;
        const tz2 = m.state === 'charge' ? this.host.position.z : targetZ;
        const vx = tx2 - m.group.position.x, vz = tz2 - m.group.position.z;
        m.dir = Math.atan2(-vx, -vz);
        const speed = m.state === 'charge' ? 1.9 : m.state === 'perch' ? 1.4 : 0.75;
        m.group.position.x += vx * dt * speed;
        m.group.position.z += vz * dt * speed;
        m.group.position.y += (targetY - m.group.position.y) * Math.min(1, dt * (m.state === 'charge' ? 2.5 : 1.2));
        m.group.rotation.y = m.dir;
        if (!peaceful && m.attack <= 0 && dist < 26 && m.state !== 'perch') { this.shoot(m); m.attack = m.state === 'charge' ? 2.2 : 4; }
        if (!peaceful && m.state === 'perch' && dist < 4.5 && m.attack <= 0) { this.host.damage(6); m.attack = 1.5; }
        // Crystals heal the dragon, so the fight becomes easier once they are broken.
        if (this.crystals.length && m.hp < m.maxHp) m.hp = Math.min(m.maxHp, m.hp + dt * 1.5);
        continue;
      }

      if (m.species === 'shulker') {
        // Shulkers stay glued to their block, open their shell and fire homing bullets.
        m.group.position.y += Math.sin(this.timeline * 1.6 + m.id) * dt * 0.15;
        m.dir = Math.atan2(-tx, -tz);
        m.group.rotation.y = m.dir;
        const open = Math.sin(this.timeline * 1.1 + m.id) > 0.2;
        m.group.scale.y = open ? 1 : 0.75;
        if (!peaceful && open && dist < 18 && m.attack <= 0) { this.shoot(m); m.attack = 2.6; }
        continue;
      }

      if (m.species === 'fish' || m.species === 'dolphin' || m.species === 'squid' || m.species === 'turtle') {
        m.dir += Math.sin(m.timer) * dt * 0.4;
        move = 0.7;
        if (m.species !== 'turtle') m.group.position.y = 19.4 + Math.sin(m.timer * 2 + m.id) * 0.15;
      } else if (m.species === 'bee' || m.species === 'blaze' || m.species === 'ghast') {
        m.dir += Math.sin(m.timer * 1.4) * dt * 0.6;
        move = 1.1;
        const baseY = this.host.terrain.height(m.group.position.x, m.group.position.z) + 2.3;
        m.group.position.y += (baseY + Math.sin(now * 0.004 + m.id) * 0.35 - m.group.position.y) * Math.min(1, dt * 4);
      } else if (m.species === 'creeper' && dist < 12 && !peaceful) {
        m.state = dist < 2.8 ? 'fuse' : 'chase';
        if (m.state === 'fuse') {
          if (m.fuse === 0) this.host.sound('fuse', m.group.position);
          m.fuse += dt;
          const s = 1 + m.fuse * 0.2 + Math.sin(m.fuse * 26) * 0.05;
          m.group.scale.set(s, s, s);
          if (m.fuse > 1.5) {
            this.host.explode(m.group.position.clone(), 3);
            this.scene.remove(m.group);
            this.mobs.splice(idx, 1);
            continue;
          }
        } else {
          m.fuse = Math.max(0, m.fuse - dt);
          m.group.scale.set(1, 1, 1);
          m.dir = Math.atan2(-tx, -tz);
          move = 1.6;
        }
      } else if (m.species === 'skeleton' && dist < 16 && !peaceful) {
        m.state = 'aim';
        m.dir = Math.atan2(-tx, -tz);
        move = dist < 6 ? -1 : dist > 10 ? 1 : 0;
        if (m.attack <= 0) { this.shoot(m); m.attack = 2.2; }
      } else if ((m.species === 'zombie' || m.species === 'spider') && dist < 16 && !peaceful) {
        m.state = 'chase';
        m.dir = Math.atan2(-tx, -tz);
        move = m.species === 'spider' ? 2.4 : 1.65;
        if (dist < 1.6 && m.attack <= 0) { this.host.damage(3); m.attack = 1.0; }
      } else if (m.species === 'enderman') {
        this.host.camera.getWorldDirection(this._look);
        if (dist > 0 && (tx * this._look.x + ty * this._look.y + tz * this._look.z) / dist > 0.985 && dist < 22) m.state = 'teleport';
        if (m.state === 'teleport' && m.timer <= 0) {
          const a = this.rnd() * 6.28;
          m.group.position.x = this.host.position.x + Math.cos(a) * 6;
          m.group.position.z = this.host.position.z + Math.sin(a) * 6;
          m.timer = 3;
          this.host.particles.burst(m.group.position, '#a780cf', 18);
          m.state = 'chase';
        }
        if (m.state === 'chase') {
          m.dir = Math.atan2(-tx, -tz); move = 2.5;
          if (dist < 1.6 && m.attack <= 0) { this.host.damage(5); m.attack = 1; }
        }
      } else if (m.species === 'iron_golem') {
        const enemy = this.mobs.find(x => !passive.has(x.species) && x.group.position.distanceTo(m.group.position) < 8);
        if (enemy) {
          const vx = enemy.group.position.x - m.group.position.x, vz = enemy.group.position.z - m.group.position.z;
          m.dir = Math.atan2(-vx, -vz); move = 1.5;
          if (Math.hypot(vx, vz) < 2 && m.attack <= 0) { enemy.hp -= 15; m.attack = 1; if (enemy.hp <= 0) this.kill(enemy); }
        }
      }

      if (m.state === 'wander' || m.state === 'graze' || m.state === 'follow') {
        if (m.tamed && m.species === 'wolf') m.state = 'follow';
        else if (m.timer <= 0) { m.timer = 2 + this.rnd() * 5; m.dir = this.rnd() * 6.28; m.state = this.rnd() < 0.35 ? 'graze' : 'wander'; }
        move = m.state === 'graze' ? 0 : m.speed;
        if (m.state === 'follow' && dist > 3) { m.dir = Math.atan2(-tx, -tz); move = m.speed * 1.4; }
      }
      if (m.state === 'flee') { move = m.speed * 2.4; if (m.timer <= 0) m.state = 'wander'; }

      if (move) {
        const nx = m.group.position.x - Math.sin(m.dir) * move * dt, nz = m.group.position.z - Math.cos(m.dir) * move * dt;
        let y = this.host.terrain.height(nx, nz) + 1;
        const block = this.host.getBlock(nx, y, nz);
        if (block > 0 && block !== ID.water) y++;
        if (Math.abs(y - m.group.position.y) < 1.8 && this.host.getBlock(nx, y, nz) !== ID.water && this.host.getBlock(nx, y - 1, nz) !== ID.lava) {
          m.group.position.x = nx; m.group.position.z = nz;
          if (m.species !== 'bee' && m.species !== 'blaze' && m.species !== 'ghast') m.group.position.y += (y - m.group.position.y) * Math.min(1, dt * 10);
        } else {
          m.dir += Math.PI * 0.5;
        }
      }

      m.group.rotation.y = m.dir;

      if (m.species === 'chicken') {
        m.egg -= dt;
        if (m.egg <= 0) { m.egg = 30; this.host.particles.drop(m.group.position.clone(), 'egg', 1, '#e6dfcb'); }
      }
      if (m.species === 'sheep' && !m.wool && m.timer > 10) {
        m.wool = true;
        if (m.woolCoat) m.woolCoat.visible = true;
      }
      if (m.love > 0 && dist < 5) {
        const mate = this.mobs.find(x => x !== m && x.species === m.species && x.love > 0 && x.group.position.distanceTo(m.group.position) < 3);
        if (mate) {
          m.love = 0; mate.love = 0;
          this.spawn(m.species, m.group.position.x + 1, m.group.position.z, true);
          this._tmpB.copy(m.group.position); this._tmpB.y += 1;
          this.host.particles.burst(this._tmpB, '#e47b83', 12, 1);
        }
      }
      if (dist > 95) {
        this.scene.remove(m.group);
        this.mobs.splice(idx, 1);
      }
    }

    this.animateMobs(dt, now);

    for (let i = this.arrows.length - 1; i >= 0; i--) {
      const a = this.arrows[i];
      a.life -= dt;
      a.v.y -= 8.5 * dt;
      a.mesh.position.addScaledVector(a.v, dt);
      this._tmpA.copy(a.mesh.position).add(a.v);
      a.mesh.lookAt(this._tmpA);

      if (!a.fromPlayer) {
        if (a.mesh.position.distanceTo(this.host.camera.position) < 0.85) {
          this.host.damage(a.damage);
          a.life = 0;
        }
      } else {
        for (const m of this.mobs) {
          this._tmpB.copy(m.group.position);
          this._tmpB.y += m.species === 'dragon' ? 1.5 : 0.9;
          if (a.mesh.position.distanceTo(this._tmpB) < (m.species === 'dragon' ? 2.2 : 1.05)) {
            this.damageMob(m, a.damage, this._tmpA.copy(a.v).normalize(), true);
            a.life = 0;
            break;
          }
        }
      }

      if (a.life <= 0 || this.host.getBlock(a.mesh.position.x, a.mesh.position.y, a.mesh.position.z) > 0) {
        this.scene.remove(a.mesh);
        this.arrows.splice(i, 1);
      }
    }
  }

  /**
   * Walk-cycle animation. Phase advances with the distance actually travelled (not wall-clock time), so the feet match the ground
   * speed and stop dead when the mob stops; amplitude eases in and out. Quadrupeds use diagonal pairs, bipeds opposite arm/leg,
   * spiders an alternating tetrapod, birds two legs with flapping wings. The head looks at the player when close, grazing animals
   * lower it, and every mob has a faint idle sway instead of freezing.
   */
  private animateMobs(dt: number, now: number) {
    const px = this.host.position.x, py = this.host.position.y + 1.5, pz = this.host.position.z;
    const norm = (a: number) => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; };
    for (const m of this.mobs) {
      const gx = m.group.position.x, gz = m.group.position.z;
      const speed = dt > 0 ? Math.hypot(gx - (m.lastX ?? gx), gz - (m.lastZ ?? gz)) / dt : 0;
      m.lastX = gx; m.lastZ = gz;
      const wants = Math.max(0, Math.min(1, speed / 1.1));
      m.swing = (m.swing ?? 0) + (wants - (m.swing ?? 0)) * Math.min(1, dt * 9);
      const swing = m.swing ?? 0;
      if (speed > 0.05) m.walk = (m.walk ?? 0) + dt * (3.4 + Math.min(5, speed) * 2.4);
      const walk = m.walk ?? 0;
      for (const limb of m.limbs ?? []) {
        const n = limb.node;
        if (limb.kind === 'spider') {
          // Legs sweep forward/back and lift on alternate steps; the resting splay is preserved.
          n.rotation.y = limb.baseY + Math.sin(walk + limb.phase) * limb.amp * swing;
          n.rotation.z = limb.baseZ + Math.cos(walk + limb.phase) * limb.amp * 0.8 * swing;
        } else if (limb.kind === 'wing') {
          const flying = m.species === 'dragon' || m.species === 'bee' || m.species === 'ghast';
          n.rotation.z = limb.baseZ + Math.sin(now * 0.02 + limb.phase) * limb.amp * (flying ? 1 : 0.25 + swing * 0.75);
        } else if (limb.kind === 'tentacle') {
          n.rotation.x = Math.sin(now * 0.0016 + limb.phase) * 0.22;
          n.rotation.z = Math.cos(now * 0.0013 + limb.phase) * 0.18;
        } else {
          n.rotation.x = limb.baseX + Math.sin(walk + limb.phase) * limb.amp * swing;
        }
      }
      // Head: track the player when nearby, otherwise sway; grazers lower their muzzle.
      const h = m.head;
      const wantYaw = Math.atan2(-(px - gx), -(pz - gz)) - m.dir;
      const near = Math.hypot(px - gx, pz - gz) < 9;
      const targetYaw = near ? Math.max(-0.9, Math.min(0.9, norm(wantYaw))) : Math.sin(now * 0.0012 + m.id) * 0.12;
      const targetPitch = m.state === 'graze' ? 0.55 + Math.sin(now * 0.0025 + m.id) * 0.08 : near ? Math.max(-0.35, Math.min(0.35, -(py - (m.group.position.y + 1.4)) * 0.2)) : Math.sin(now * 0.0017 + m.id) * 0.04;
      h.rotation.y += (targetYaw - h.rotation.y) * Math.min(1, dt * 5);
      h.rotation.x += (targetPitch - h.rotation.x) * Math.min(1, dt * 5);
    }
  }

  /** Player-thrown items: snowballs, ender pearls and eyes, plus boss/mob projectiles. */
  launchProjectile(kind: 'snowball' | 'ender_pearl' | 'ender_eye' | 'dragon_fireball' | 'shulker_bullet' | 'ghast_fireball' | 'blaze_fireball' | 'mob_arrow' | 'player_arrow' | 'trident' | 'potion', origin: THREE.Vector3, dir: THREE.Vector3, speed: number, target?: THREE.Vector3, extra?: { damage?: number; gravity?: number; color?: string; onEnd?: (pos: THREE.Vector3) => void; flame?: boolean; punch?: number }) {
    const color = kind === 'ender_eye' ? '#59d98a' : kind === 'ender_pearl' ? '#2f8f83' : kind === 'snowball' ? '#f2f8ff'
      : kind === 'shulker_bullet' ? '#c9b6e8' : kind.includes('fireball') ? '#ff8a2a' : '#d8d0b5';
    const glow = kind === 'ender_eye' || kind === 'shulker_bullet' || kind.includes('fireball');
    const mesh = new THREE.Mesh(this.box, glow ? this.glowMat(color, 1) : this.mat(extra?.color ?? color));
    const size = kind.includes('fireball') ? 0.32 : kind === 'shulker_bullet' ? 0.16 : 0.14;
    mesh.scale.setScalar(size);
    mesh.position.copy(origin);
    this.scene.add(mesh);
    this.projectiles.push({ kind, mesh, v: dir.clone().normalize().multiplyScalar(speed), life: 8, damage: extra?.damage ?? (kind === 'snowball' ? 0 : kind.includes('fireball') ? 6 : kind === 'shulker_bullet' ? 4 : 0), target: target?.clone(), gravity: extra?.gravity, onEnd: extra?.onEnd, flame: extra?.flame, punch: extra?.punch });
  }

  private updateProjectiles(dt: number) {
    const playerHead = this.host.position.clone().add(new THREE.Vector3(0, 1.4, 0));
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      if (p.kind === 'ender_eye' && p.target) {
        // Eyes of Ender drift towards the stronghold and die after a short flight.
        this._tmpA.copy(p.target).sub(p.mesh.position).normalize().multiplyScalar(7);
        p.v.lerp(this._tmpA, Math.min(1, dt * 2));
        if (p.mesh.position.distanceTo(p.target) < 6) p.life = Math.min(p.life, 0.2);
      }
      if (p.kind.includes('fireball') || p.kind === 'shulker_bullet') p.v.y -= 1.2 * dt;
      if (p.gravity) p.v.y -= p.gravity * dt;
      p.mesh.position.addScaledVector(p.v, dt);
      p.mesh.rotation.x += dt * 3; p.mesh.rotation.y += dt * 2;
      if (p.kind === 'ender_eye' || p.kind === 'shulker_bullet') this.host.particles.spark?.(p.mesh.position.clone(), p.kind === 'ender_eye' ? '#7af0a6' : '#d9c8f5', 1);
      const blocked = this.host.getBlock(p.mesh.position.x, p.mesh.position.y, p.mesh.position.z) > 0;
      const hitPlayer = p.mesh.position.distanceTo(playerHead) < 0.7;
      let done = p.life <= 0;
      if (p.kind === 'shulker_bullet' || p.kind.includes('fireball') || p.kind === 'mob_arrow') {
        if (hitPlayer) {
          if (p.kind === 'shulker_bullet') this.host.levitate(9);
          else if (p.kind.includes('fireball')) { this.host.damage(p.damage); this.host.explode(p.mesh.position.clone(), p.kind === 'ghast_fireball' ? 2 : 1); }
          else this.host.damage(p.damage);
          done = true;
        }
        if (!done) for (const m of this.mobs) {
          if (passive.has(m.species)) continue;
          const c = m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0));
          if (p.mesh.position.distanceTo(c) > 1.1) continue;
          this.damageMob(m, p.damage, p.v.clone().normalize(), true);
          done = true; break;
        }
      } else if (p.kind === 'snowball' || p.kind === 'ender_pearl' || p.kind === 'player_arrow' || p.kind === 'trident' || p.kind === 'potion') {
        // Player projectiles hit hostile and passive mobs alike.
        for (const m of this.mobs) {
          const c = m.group.position.clone().add(new THREE.Vector3(0, m.species === 'dragon' ? 1.5 : 0.9, 0));
          if (p.mesh.position.distanceTo(c) > (m.species === 'dragon' ? 2 : 1.05)) continue;
          if (p.kind === 'ender_pearl') { this.host.teleport(p.mesh.position.x, p.mesh.position.y + 1, p.mesh.position.z); this.host.sound('portal', p.mesh.position); }
          else {
            this.damageMob(m, p.kind === 'player_arrow' || p.kind === 'trident' ? (p.damage || 7) : p.kind === 'potion' ? 0 : 1, p.v.clone().normalize(), p.kind === 'player_arrow');
            if (p.flame && this.mobs.includes(m)) this.damageMob(m, 3);
            if (p.punch && this.mobs.includes(m)) m.group.position.addScaledVector(p.v.clone().setY(0).normalize(), p.punch * 0.8);
          }
          done = true; break;
        }
      }
      if (blocked || (hitPlayer && p.kind === 'ender_pearl')) {
        if (p.kind === 'ender_pearl') { this.host.teleport(p.mesh.position.x, p.mesh.position.y + 1, p.mesh.position.z); this.host.sound('portal', p.mesh.position); }
        else if (p.kind.includes('fireball')) this.host.explode(p.mesh.position.clone(), 2);
        done = true;
      }
      if (done) { p.onEnd?.(p.mesh.position.clone()); this.scene.remove(p.mesh); this.projectiles.splice(i, 1); }
    }
  }

  /** End Crystals bob and spin; the dragon heals while one of its crystals is alive nearby. */
  private updateCrystals(dt: number) {
    const dragon = this.mobs.find(m => m.species === 'dragon');
    for (const c of this.crystals) {
      c.shell.rotation.y += dt * 1.6;
      c.core.rotation.y -= dt * 2.4;
      c.group.position.y = c.pos.y + Math.sin(this.timeline * 2 + c.pos.x) * 0.12;
      if (dragon && this.crystals.length && dragon.group.position.distanceTo(c.group.position) < 24) {
        dragon.hp = Math.min(dragon.maxHp, dragon.hp + dt * 4);
        if (Math.random() < dt * 8) {
          const a = this.host.particles;
          a.spark?.(c.group.position.clone().add(new THREE.Vector3(0, 1.1, 0)), '#f28bff', 1);
        }
      }
    }
  }

  private timeline = 0;

  dispose() {
    this.clear();
    this.box.dispose();
    this.hurtMat.dispose();
    this.materials.forEach(m => m.dispose());
    this.emissiveMaterials.forEach(m => m.dispose());
  }
}
