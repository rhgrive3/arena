import * as THREE from 'three';
import { BLOCKS, ID } from '../game/data';
import { getTileTexture } from '../textures/atlas';

interface Particle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  gravity: number;
  life: number;
  max: number;
  rotSpeed: number;
}

interface Drop {
  mesh: THREE.Mesh;
  name: string;
  count: number;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  baseY: number;
}

export class ParticleSystem {
  particles: Particle[] = [];
  drops: Drop[] = [];
  geometry = new THREE.BoxGeometry(1, 1, 1);
  materials = new Map<string, THREE.MeshLambertMaterial>();
  dropMaterials = new Map<string, THREE.MeshLambertMaterial>();
  private pool: THREE.Mesh[] = [];

  constructor(public scene: THREE.Scene) {}

  material(color: string) {
    let m = this.materials.get(color);
    if (!m) {
      m = new THREE.MeshLambertMaterial({ color });
      this.materials.set(color, m);
    }
    return m;
  }

  dropMaterial(name: string, fallbackColor: string) {
    let m = this.dropMaterials.get(name);
    if (!m) {
      try {
        const tex = getTileTexture(name);
        m = new THREE.MeshLambertMaterial({ map: tex, transparent: true, alphaTest: 0.35 });
      } catch {
        m = this.material(fallbackColor);
      }
      this.dropMaterials.set(name, m);
    }
    return m;
  }

  private acquire(mat: THREE.Material) {
    const m = this.pool.pop();
    if (m) {
      m.material = mat;
      m.visible = true;
      return m;
    }
    return new THREE.Mesh(this.geometry, mat);
  }

  private release(m: THREE.Mesh) {
    m.visible = false;
    if (this.pool.length < 220) this.pool.push(m);
    else this.scene.remove(m);
  }

  burst(p: THREE.Vector3, color: string, count = 10, power = 3, gravity = 12) {
    const mat = this.material(color);
    for (let i = 0; i < count && this.particles.length < 180; i++) {
      const mesh = this.acquire(mat);
      mesh.position.set(p.x + (Math.random() - 0.5) * 0.65, p.y + (Math.random() - 0.5) * 0.65, p.z + (Math.random() - 0.5) * 0.65);
      const s = 0.06 + Math.random() * 0.08;
      mesh.scale.setScalar(s);
      mesh.rotation.set(Math.random() * 3, Math.random() * 3, 0);
      if (!mesh.parent) this.scene.add(mesh);
      const life = 0.32 + Math.random() * 0.45;
      this.particles.push({
        mesh,
        vx: (Math.random() - 0.5) * power,
        vy: Math.random() * power * 0.9,
        vz: (Math.random() - 0.5) * power,
        gravity,
        life,
        max: life,
        rotSpeed: 2 + Math.random() * 4,
      });
    }
  }

  spark(p: THREE.Vector3, color: string, count = 8) {
    this.burst(p, color, count, 2.2, -1.8);
  }

  drop(p: THREE.Vector3, name: string, count: number, color: string) {
    if (this.drops.length > 80) {
      this.scene.remove(this.drops[0].mesh);
      this.drops.shift();
    }
    const isBlock = ID[name] !== undefined && BLOCKS[ID[name]]?.shape === 'cube';
    const mesh = new THREE.Mesh(this.geometry, this.dropMaterial(name, color));
    mesh.position.copy(p);
    if (isBlock) mesh.scale.set(0.24, 0.24, 0.24);
    else mesh.scale.set(0.26, 0.26, 0.05);
    this.scene.add(mesh);
    this.drops.push({
      mesh,
      name,
      count,
      vx: (Math.random() - 0.5) * 2.2,
      vy: 3.1,
      vz: (Math.random() - 0.5) * 2.2,
      age: 0,
      baseY: p.y,
    });
  }

  update(
    dt: number,
    floor: (x: number, y: number, z: number) => number,
    pickup: (name: string, count: number, position: THREE.Vector3) => boolean,
    playerPos?: THREE.Vector3,
  ) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.release(p.mesh);
        this.particles.splice(i, 1);
        continue;
      }
      p.vy -= p.gravity * dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      p.mesh.rotation.x += dt * p.rotSpeed;
      p.mesh.rotation.y += dt * p.rotSpeed * 0.6;
      const scaleDecay = Math.max(0.1, 1 - dt * 0.85);
      p.mesh.scale.multiplyScalar(scaleDecay);
    }

    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.age += dt;
      d.vy -= 12 * dt;

      // Magnetic pull toward nearby player after 0.6s
      if (playerPos && d.age > 0.6) {
        const dx = playerPos.x - d.mesh.position.x;
        const dy = playerPos.y + 0.6 - d.mesh.position.y;
        const dz = playerPos.z - d.mesh.position.z;
        const dist = Math.hypot(dx, dy, dz);
        if (dist < 2.6 && dist > 0.05) {
          const pull = (1 - dist / 2.6) * 9 * dt;
          d.mesh.position.x += (dx / dist) * pull;
          d.mesh.position.y += (dy / dist) * pull;
          d.mesh.position.z += (dz / dist) * pull;
        }
      }

      const nx = d.mesh.position.x + d.vx * dt;
      const ny = d.mesh.position.y + d.vy * dt;
      const nz = d.mesh.position.z + d.vz * dt;
      const below = floor(nx, ny - 0.14, nz);
      if (below > 0 && below !== ID.water) {
        d.vy = 0;
        d.vx *= 0.78;
        d.vz *= 0.78;
        d.baseY = Math.floor(ny - 0.14) + 1.15;
        d.mesh.position.set(nx, d.baseY + Math.sin(d.age * 3.2) * 0.055, nz);
      } else {
        d.mesh.position.set(nx, ny, nz);
      }
      d.mesh.rotation.y += dt * 1.9;

      if (d.age > 0.7 && pickup(d.name, d.count, d.mesh.position)) {
        this.scene.remove(d.mesh);
        this.drops.splice(i, 1);
      } else if (d.age > 300) {
        this.scene.remove(d.mesh);
        this.drops.splice(i, 1);
      }
    }
  }

  clear() {
    for (const p of this.particles) this.release(p.mesh);
    for (const d of this.drops) this.scene.remove(d.mesh);
    this.particles = [];
    this.drops = [];
  }

  dispose() {
    this.clear();
    for (const m of this.pool) this.scene.remove(m);
    this.pool = [];
    this.geometry.dispose();
    this.materials.forEach(m => m.dispose());
    this.dropMaterials.forEach(m => m.dispose());
  }
}
