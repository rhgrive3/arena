import type { Settings } from '../game/types';

export class ProceduralAudio {
  context: AudioContext | null = null;
  master: GainNode | null = null;
  delay: DelayNode | null = null;
  delayGain: GainNode | null = null;
  noise: AudioBuffer | null = null;
  musicTimer: ReturnType<typeof setInterval> | null = null;
  settings: Settings;
  step = 0;

  constructor(settings: Settings) {
    this.settings = settings;
  }

  resume() {
    try {
      if (!this.context) {
        this.context = new AudioContext();
        this.master = this.context.createGain();
        this.master.connect(this.context.destination);

        // Soft ambient echo bus for music & chimes
        this.delay = this.context.createDelay(1.0);
        this.delay.delayTime.value = 0.36;
        this.delayGain = this.context.createGain();
        this.delayGain.gain.value = 0.28;
        this.delay.connect(this.delayGain);
        this.delayGain.connect(this.delay);
        this.delayGain.connect(this.master);

        const length = this.context.sampleRate * 2;
        this.noise = this.context.createBuffer(1, length, this.context.sampleRate);
        const data = this.noise.getChannelData(0);
        let brown = 0;
        for (let i = 0; i < length; i++) {
          brown = (brown + Math.random() * 0.04 - 0.02) / 1.02;
          data[i] = brown * 3 + (Math.random() * 2 - 1) * 0.25;
        }
        this.configure(this.settings);
        this.musicTimer = setInterval(() => {
          if (this.settings.music && !this.settings.muted && this.context?.state === 'running') {
            this.chord();
          }
        }, 7200);
      }
      if (this.context.state === 'suspended') this.context.resume().catch(() => {});
    } catch {}
  }

  configure(s: Settings) {
    this.settings = s;
    if (this.master && this.context) {
      this.master.gain.setTargetAtTime(s.muted ? 0 : s.volume * 0.52, this.context.currentTime, 0.08);
    }
  }

  private tone(freq: number, dur: number, vol: number, type: OscillatorType = 'sine', endFreq?: number, useDelay = false, delaySec = 0) {
    const c = this.context;
    if (!c || !this.master || this.settings.muted || c.state !== 'running') return;
    const now = c.currentTime + delaySec;
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (endFreq !== undefined) osc.frequency.exponentialRampToValueAtTime(Math.max(30, endFreq), now + dur);
    g.gain.setValueAtTime(0.0001, now);
    g.gain.linearRampToValueAtTime(vol, now + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    osc.connect(g);
    g.connect(this.master);
    if (useDelay && this.delay) g.connect(this.delay);
    osc.start(now);
    osc.stop(now + dur + 0.02);
    osc.onended = () => { osc.disconnect(); g.disconnect(); };
  }

  play(kind: string, position?: { x: number; y: number; z: number }) {
    const c = this.context;
    if (!c || !this.master || this.settings.muted || c.state !== 'running') return;

    if (kind === 'xp') {
      const pitch = 680 + Math.random() * 240;
      this.tone(pitch, 0.14, 0.14, 'sine', pitch * 1.25, true);
      return;
    }
    if (kind === 'levelup') {
      this.tone(523.25, 0.22, 0.16, 'triangle', undefined, true, 0);
      this.tone(659.25, 0.22, 0.16, 'triangle', undefined, true, 0.09);
      this.tone(783.99, 0.28, 0.18, 'triangle', undefined, true, 0.18);
      this.tone(1046.5, 0.45, 0.20, 'triangle', undefined, true, 0.27);
      return;
    }
    if (kind === 'glass') {
      this.tone(2400 + Math.random() * 600, 0.12, 0.18, 'triangle', 1200);
      this.tone(3100 + Math.random() * 700, 0.09, 0.14, 'sine', 1800, false, 0.02);
      return;
    }
    if (kind === 'bow') {
      this.tone(420, 0.14, 0.18, 'triangle', 160);
      return;
    }
    if (kind === 'critical') {
      this.tone(520, 0.11, 0.22, 'sawtooth', 880);
      return;
    }
    if (kind === 'portal') {
      this.tone(220, 0.9, 0.12, 'sine', 330, true);
      this.tone(330, 0.9, 0.1, 'triangle', 495, true, 0.12);
      return;
    }
    if (kind === 'chest' || kind === 'door') {
      this.tone(kind === 'chest' ? 160 : 240, 0.12, 0.15, 'triangle', kind === 'chest' ? 210 : 180);
      return;
    }
    if (kind === 'eat') {
      for (let i = 0; i < 3; i++) this.tone(240 + Math.random() * 90, 0.06, 0.12, 'sawtooth', 140, false, i * 0.09);
      return;
    }
    if (kind === 'fuse') {
      this.tone(1800, 0.4, 0.09, 'sawtooth', 2600);
      return;
    }
    if (kind === 'thunder') {
      kind = 'explosion';
    }

    const now = c.currentTime;
    const source = c.createBufferSource();
    const filter = c.createBiquadFilter();
    const gain = c.createGain();
    source.buffer = this.noise;
    source.playbackRate.value = 0.8 + Math.random() * 0.4;

    let duration = 0.13, volume = 0.35, freq = 900;
    if (kind === 'grass' || kind === 'step') { duration = 0.11; volume = 0.24; freq = 650 + Math.random() * 580; filter.type = 'lowpass'; }
    else if (kind === 'sand') { duration = 0.12; volume = 0.22; freq = 1400 + Math.random() * 400; filter.type = 'highpass'; }
    else if (kind === 'stone' || kind === 'mine') { duration = 0.1; volume = 0.46; freq = 1850; filter.type = 'bandpass'; }
    else if (kind === 'wood' || kind === 'place') { duration = 0.14; volume = 0.42; freq = 480; filter.type = 'lowpass'; }
    else if (kind === 'water') { duration = 0.42; volume = 0.32; freq = 2200; filter.type = 'bandpass'; }
    else if (kind === 'explosion') { duration = 1.35; volume = 0.88; freq = 155; filter.type = 'lowpass'; }
    else if (kind === 'click') { duration = 0.05; volume = 0.2; freq = 1400; filter.type = 'bandpass'; }
    else if (kind === 'hurt') { duration = 0.2; volume = 0.42; freq = 360; filter.type = 'lowpass'; }
    else { duration = 0.22; volume = 0.22; freq = 750; filter.type = 'bandpass'; }

    filter.frequency.setValueAtTime(freq, now);
    filter.frequency.exponentialRampToValueAtTime(Math.max(60, freq * 0.35), now + duration);
    filter.Q.value = 0.7;
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(volume, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    source.connect(filter);
    filter.connect(gain);

    let panner: PannerNode | null = null;
    if (position) {
      panner = c.createPanner();
      panner.panningModel = 'HRTF';
      panner.distanceModel = 'inverse';
      panner.refDistance = 3;
      panner.maxDistance = 42;
      panner.positionX.value = position.x;
      panner.positionY.value = position.y;
      panner.positionZ.value = position.z;
      gain.connect(panner);
      panner.connect(this.master);
    } else {
      gain.connect(this.master);
    }

    source.start(now, Math.random() * 0.5);
    source.stop(now + duration + 0.03);
    source.onended = () => {
      source.disconnect();
      filter.disconnect();
      gain.disconnect();
      panner?.disconnect();
    };

    if (kind === 'wood' || kind === 'place' || kind === 'stone') {
      for (let i = 0; i < 2; i++) {
        const click = c.createBufferSource();
        const g = c.createGain();
        click.buffer = this.noise;
        g.gain.setValueAtTime(volume * 0.2, now + i * 0.025);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.025 + 0.024);
        click.connect(g);
        g.connect(this.master);
        click.start(now + i * 0.025, 0.7);
        click.stop(now + i * 0.025 + 0.03);
        click.onended = () => { click.disconnect(); g.disconnect(); };
      }
    }
  }

  chord() {
    const c = this.context;
    if (!c || !this.master) return;
    // C418-inspired warm suspended & major7 ambient voicings
    const progressions = [
      [130.81, 196.0, 246.94, 329.63], // Cmaj7
      [110.0, 164.81, 220.0, 293.66],  // Am11
      [87.31, 130.81, 174.61, 261.63], // Fmaj7
      [98.0, 146.83, 196.0, 293.66],   // Gsus4
      [146.83, 220.0, 261.63, 392.0],  // Dm11
      [130.81, 164.81, 246.94, 392.0], // Cmaj9
    ];
    const notes = progressions[this.step++ % progressions.length];
    notes.forEach((freq, i) => {
      const osc = c.createOscillator();
      const gain = c.createGain();
      const filter = c.createBiquadFilter();
      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.value = freq;
      osc.detune.value = i % 2 ? 3 : -3;
      filter.type = 'lowpass';
      filter.frequency.value = 620;
      const start = c.currentTime + i * 0.55;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.022, start + 1.4);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 6.2);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.master!);
      if (this.delay && i > 0) gain.connect(this.delay);
      osc.start(start);
      osc.stop(start + 6.3);
      osc.onended = () => { osc.disconnect(); filter.disconnect(); gain.disconnect(); };
    });
  }

  listener(x: number, y: number, z: number, yaw: number) {
    const l = this.context?.listener;
    if (!l) return;
    if (l.positionX) {
      l.positionX.value = x;
      l.positionY.value = y;
      l.positionZ.value = z;
      l.forwardX.value = -Math.sin(yaw);
      l.forwardY.value = 0;
      l.forwardZ.value = -Math.cos(yaw);
      l.upX.value = 0;
      l.upY.value = 1;
      l.upZ.value = 0;
    }
  }

  dispose() {
    if (this.musicTimer) clearInterval(this.musicTimer);
    this.context?.close().catch(() => {});
    this.context = null;
  }
}
