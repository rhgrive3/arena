import { BLOCKS, ID } from '../game/data';

/*
 * Redstone engine.
 *
 * The world is a grid of cells: id in the low 12 bits, state in the high 4 bits. The engine keeps the set of redstone-relevant
 * positions it has seen and re-solves the network a fixed number of times per tick, which makes behaviour deterministic (and
 * therefore testable) without depending on block-update ordering. Signal levels follow the vanilla model closely enough for
 * the usual circuits: dust loses one level per block, levers/buttons/plates strongly power the block they are attached to,
 * torches invert the block they hang on, repeaters are one-way with a 2-8 tick delay, comparators compare/subtract analogue
 * levels (including container fill), pistons push up to twelve blocks and sticky pistons pull one back.
 *
 * Component state layout (4 bits):
 *  - lever / button / pressure plate: bits 0-2 attachment (0 floor, 1 +X, 2 -X, 3 +Z, 4 -Z, 5 ceiling), bit 3 on/pressed.
 *  - redstone torch (lit id = redstone_torch, unlit id = unlit_redstone_torch): bits 0-2 attachment.
 *  - repeater: bits 0-1 output direction (+X, +Z, -X, -Z), bits 2-3 delay index (1-4 redstone ticks).
 *  - comparator: bits 0-1 output direction, bit 2 subtract mode.
 *  - piston / sticky piston / dispenser / dropper / hopper / observer: bits 0-2 facing (+X, +Z, -X, -Z, up, down); piston bit 3 extended.
 *  - daylight detector / target: state is the emitted signal (0-15).
 *  - powered rail: bit 0 powered.
 */

export interface RedstoneHost {
  getCell(x: number, y: number, z: number): number;
  setBlock(x: number, y: number, z: number, id: number, state?: number): boolean;
  /** Analogue signal of a container (comparator reading), 0-15. */
  containerSignal?(x: number, y: number, z: number): number;
  /** Dispenser/dropper fires one item towards dir. Return true when something was ejected. */
  eject?(x: number, y: number, z: number, dir: number, kind: 'dispenser' | 'dropper'): boolean;
  /** Hopper moves one item towards dir. */
  transfer?(x: number, y: number, z: number, dir: number): boolean;
  door?(x: number, y: number, z: number, open: boolean): void;
  ignite?(x: number, y: number, z: number): void;
  sound?(kind: string, x: number, y: number, z: number): void;
}

type Pos = readonly [number, number, number];
const DIRS: readonly Pos[] = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
/** Facing order used by most components: 0 +X, 1 +Z, 2 -X, 3 -Z, 4 up, 5 down. */
const FACE: readonly Pos[] = [[1, 0, 0], [0, 0, 1], [-1, 0, 0], [0, 0, -1], [0, 1, 0], [0, -1, 0]];
const key = (x: number, y: number, z: number) => x + ',' + y + ',' + z;
const idOf = (cell: number) => cell < 0 ? -1 : cell & 4095;
const stOf = (cell: number) => cell < 0 ? 0 : (cell >>> 12) & 15;
const parse = (k: string): Pos => k.split(',').map(Number) as unknown as Pos;

const isWire = (id: number) => id === ID.redstone_wire;
const isLever = (id: number) => id === ID.lever;
const isButton = (id: number) => !!BLOCKS[id] && /_button$/.test(nameOf(id));
const isPlate = (id: number) => !!BLOCKS[id] && /_pressure_plate$/.test(nameOf(id));
const isTorch = (id: number) => id === ID.redstone_torch || id === ID.unlit_redstone_torch;
const isRepeater = (id: number) => id === ID.repeater;
const isComparator = (id: number) => id === ID.comparator;
const isPiston = (id: number) => id === ID.piston || id === ID.sticky_piston;
const isLamp = (id: number) => id === ID.redstone_lamp || id === ID.unlit_redstone_lamp;
const isDoor = (id: number) => !!BLOCKS[id] && (nameOf(id).endsWith('_door') || nameOf(id).endsWith('_trapdoor'));
const isEmitter = (id: number) => id === ID.dispenser || id === ID.dropper;
let names: string[] | null = null;
const nameOf = (id: number) => { if (!names) { names = []; for (const n in ID) names[ID[n]] = n; } return names[id] ?? ''; };
const isAttachable = (id: number) => isLever(id) || isButton(id) || isTorch(id);
const isRedstone = (id: number) =>
  isWire(id) || isAttachable(id) || isPlate(id) || isRepeater(id) || isComparator(id) || isPiston(id) ||
  isLamp(id) || isDoor(id) || isEmitter(id) || id === ID.observer || id === ID.hopper || id === ID.daylight_detector ||
  id === ID.target || id === ID.tnt || id === ID.note_block || id === ID.rail || id === ID.powered_rail || id === ID.redstone_block;

/** The block a lever, button or torch is attached to. */
function supportOf(x: number, y: number, z: number, state: number): Pos {
  const a = state & 7;
  return a === 0 ? [x, y - 1, z] : a === 1 ? [x - 1, y, z] : a === 2 ? [x + 1, y, z] : a === 3 ? [x, y, z - 1] : a === 4 ? [x, y, z + 1] : [x, y + 1, z];
}

export class Redstone {
  /** All positions currently holding a redstone component or dust. */
  readonly active = new Set<string>();
  private observers = new Map<string, { face: number; last: string }>();
  private pulses = new Map<string, number>();
  private repOut = new Map<string, number>();
  private repTimers = new Map<string, number>();
  private compOut = new Map<string, number>();
  private lit = new Set<string>();
  private edges = new Map<string, boolean>();
  private ignited = new Set<string>();
  private warned = new Set<string>();
  private writeDepth = 0;
  private pending = new Set<string>();
  ticks = 0;
  /** Cumulative number of components that changed state, useful for diagnostics/tests. */
  changes = 0;

  constructor(public host: RedstoneHost) {}

  // ------------------------------------------------------------------ world bookkeeping

  at(x: number, y: number, z: number) {
    const cell = this.host.getCell(x, y, z);
    return { cell, id: idOf(cell), state: stOf(cell) };
  }

  register(x: number, y: number, z: number) {
    const id = idOf(this.host.getCell(x, y, z));
    if (isRedstone(id)) {
      this.active.add(key(x, y, z));
      if (id === ID.observer) {
        const st = stOf(this.host.getCell(x, y, z)), seen = this.front(x, y, z, st);
        this.observers.set(key(x, y, z), { face: st & 7, last: this.snapshot(seen) });
      }
    } else {
      this.active.delete(key(x, y, z));
      this.observers.delete(key(x, y, z));
      this.repOut.delete(key(x, y, z));
      this.repTimers.delete(key(x, y, z));
      this.compOut.delete(key(x, y, z));
      this.pulses.delete(key(x, y, z));
      this.edges.delete(key(x, y, z));
      this.ignited.delete(key(x, y, z));
    }
    this.pending.add(key(x, y, z));
  }

  /** Index every redstone block of a freshly loaded chunk (16 x HEIGHT x 16). */
  scanChunk(data: Uint16Array, cx: number, cz: number, height: number, minY: number) {
    for (let ly = 0; ly < height; ly++) for (let z = 0; z < 16; z++) {
      const row = ly * 256 + z * 16;
      for (let x = 0; x < 16; x++) {
        const id = data[row + x] & 4095;
        if (!isRedstone(id)) continue;
        const wx = cx * 16 + x, wy = ly + minY, wz = cz * 16 + z;
        this.active.add(key(wx, wy, wz));
        if (id === ID.observer) {
          const st = (data[row + x] >>> 12) & 15, f = this.front(wx, wy, wz, st);
          this.observers.set(key(wx, wy, wz), { face: st & 7, last: this.snapshot(f) });
        }
      }
    }
  }

  unloadChunk(cx: number, cz: number) {
    const x0 = cx * 16, z0 = cz * 16;
    for (const k of [...this.active]) {
      const [x, , z] = parse(k);
      if (x >= x0 && x < x0 + 16 && z >= z0 && z < z0 + 16) {
        this.active.delete(k);
        this.observers.delete(k);
        this.repOut.delete(k);
        this.repTimers.delete(k);
        this.compOut.delete(k);
        this.pulses.delete(k);
        this.edges.delete(k);
      }
    }
  }

  /** Called for every block edit. Observers facing the changed cell emit a pulse. */
  blockChanged(x: number, y: number, z: number) {
    this.pending.add(key(x, y, z));
    for (const [k, o] of this.observers) {
      const [ox, oy, oz] = parse(k), f = FACE[o.face];
      if (ox + f[0] === x && oy + f[1] === y && oz + f[2] === z) this.pulses.set(k, 2);
    }
  }

  private snapshot(p: { cell: number }) { return p.cell < 0 ? 'void' : String(p.cell); }
  private front(x: number, y: number, z: number, state: number): { cell: number } {
    const f = FACE[state & 7];
    return { cell: this.host.getCell(x + f[0], y + f[1], z + f[2]) };
  }
  private back(x: number, y: number, z: number, state: number): Pos {
    // Repeaters and comparators only use the two low bits for their horizontal direction.
    const f = FACE[state & 3];
    return [x - f[0], y - f[1], z - f[2]];
  }
  private side(x: number, y: number, z: number, state: number, side: number): Pos {
    const f = FACE[state & 3];
    return side ? [x - f[2], y, z + f[0]] : [x + f[2], y, z - f[0]];
  }

  /** Writes a block and keeps the registry in sync. Re-entrant writes are allowed; only notifications are deferred. */
  set(x: number, y: number, z: number, id: number, state = 0) {
    this.writeDepth++;
    let changed = false;
    try { changed = this.host.setBlock(x, y, z, id, state); }
    finally { this.writeDepth--; }
    if (changed) {
      this.register(x, y, z);
      this.blockChanged(x, y, z);
      this.changes++;
    }
    return changed;
  }

  // ------------------------------------------------------------------ solving

  private solver(): { wire: Map<string, number>; powered: Map<string, Set<string>> } {
    const wire = new Map<string, number>();
    // Strong power given to blocks (for components reading power), and the solid subset that can carry power into dust.
    const powered = new Map<string, Set<string>>();
    const strong = new Set<string>();
    const addPower = (p: Pos, source: string, carry = false) => { const k = key(p[0], p[1], p[2]); let set = powered.get(k); if (!set) powered.set(k, set = new Set()); set.add(source); if (carry) strong.add(k); };
    const solid = (x: number, y: number, z: number) => { const id = idOf(this.host.getCell(x, y, z)); const d = BLOCKS[id]; return !!d && id > 0 && !d.transparent && d.shape === 'cube'; };

    for (let pass = 0; pass < 4; pass++) {
      wire.clear();
      powered.clear();
      strong.clear();
      const seeds: [string, number][] = [];
      const pushWire = (x: number, y: number, z: number, level: number) => {
        const id = idOf(this.host.getCell(x, y, z));
        if (!isWire(id)) return;
        const k = key(x, y, z), cur = wire.get(k) ?? 0;
        if (level > cur) { wire.set(k, Math.min(15, level)); seeds.push([k, Math.min(15, level)]); }
      };

      for (const k of this.active) {
        const [x, y, z] = parse(k), { id, state } = this.at(x, y, z);
        if (isWire(id)) continue;
        let strength = 0;
        if (isLever(id) && state & 8) strength = 15;
        else if (isButton(id) && state & 8) strength = 15;
        else if (isPlate(id) && state & 8) strength = 15;
        else if (id === ID.redstone_block) strength = 15;
        else if (id === ID.daylight_detector) strength = state & 15;
        else if (id === ID.target) strength = state & 15;
        else if (isRepeater(id)) strength = this.repOut.get(k) ?? 0;
        else if (isComparator(id)) strength = this.compOut.get(k) ?? 0;
        else if (isTorch(id) && this.lit.has(k)) strength = id === ID.redstone_torch ? 15 : 0;
        else if (id === ID.observer && (this.pulses.get(k) ?? 0) > 0) strength = 15;
        if (!strength) continue;

        if (isAttachable(id) || isPlate(id)) {
          const sup = supportOf(x, y, z, state);
          addPower(sup, k, true);
          // A lit torch also powers the block above it, a wall torch the block it faces.
          if (isTorch(id)) {
            const above: Pos = [x, y + 1, z];
            addPower(above, k, solid(above[0], above[1], above[2]));
            addPower([x, y, z + 0], k, false);
            pushWire(above[0], above[1], above[2], 15);
          }
          // Components power their attachment block and any dust directly beside them; other blocks are not powered.
          for (const d of DIRS) pushWire(x + d[0], y + d[1], z + d[2], 15);
        } else if (isRepeater(id) || isComparator(id)) {
          const f = FACE[state & 3];
          const out: Pos = [x + f[0], y + f[1], z + f[2]];
          pushWire(out[0], out[1], out[2], strength);
          addPower(out, k, solid(out[0], out[1], out[2]));
        } else if (id === ID.redstone_block) {
          for (const d of DIRS) {
            const p: Pos = [x + d[0], y + d[1], z + d[2]];
            pushWire(p[0], p[1], p[2], 15);
            if (solid(p[0], p[1], p[2])) addPower(p, k, true);
          }
        } else if (id === ID.daylight_detector || id === ID.target || id === ID.observer) {
          for (const d of DIRS) { pushWire(x + d[0], y + d[1], z + d[2], strength); if (solid(x + d[0], y + d[1], z + d[2])) addPower([x + d[0], y + d[1], z + d[2]], k, true); }
          if (id === ID.observer) {
            const f = FACE[state & 7], b: Pos = [x - f[0], y - f[1], z - f[2]];
            addPower(b, k, solid(b[0], b[1], b[2]));
            pushWire(b[0], b[1], b[2], 15);
          }
        }
      }

      // Dust lying on or beside a strongly powered block receives 15.
      for (const bk of strong) {
        const [bx, by, bz] = parse(bk);
        for (const d of DIRS) pushWire(bx + d[0], by + d[1], bz + d[2], 15);
      }

      // Breadth-first relaxation of dust signals.
      for (let head = 0; head < seeds.length; head++) {
        const [k, level] = seeds[head];
        if (level <= 1) continue;
        const [x, y, z] = parse(k);
        for (const d of DIRS) {
          const nx = x + d[0], ny = y + d[1], nz = z + d[2];
          if (!isWire(idOf(this.host.getCell(nx, ny, nz)))) continue;
          const nk = key(nx, ny, nz), cur = wire.get(nk) ?? 0;
          if (cur < level - 1) { wire.set(nk, level - 1); seeds.push([nk, level - 1]); }
        }
      }

      // Dust weakly powers the solid block it lies on/next to, so mechanisms next to that block react.
      for (const [k, level] of wire) {
        const [x, y, z] = parse(k);
        for (const d of DIRS) {
          const p: Pos = [x + d[0], y + d[1], z + d[2]];
          if (solid(p[0], p[1], p[2])) addPower(p, 'w:' + k, true);
        }
        void level;
      }

      // Torches invert the block they are attached to. Iterate so torch chains settle.
      let changed = false;
      for (const k of this.active) {
        const [x, y, z] = parse(k), { id, state } = this.at(x, y, z);
        if (!isTorch(id)) continue;
        const sup = supportOf(x, y, z, state), sk = key(sup[0], sup[1], sup[2]);
        const others = powered.get(sk);
        const isPowered = !!others && [...others].some(s => s !== k && !s.startsWith('w:') || (s.startsWith('w:') && s !== 'w:' + k));
        const shouldLight = !isPowered;
        if (shouldLight && !this.lit.has(k)) { this.lit.add(k); changed = true; }
        else if (!shouldLight && this.lit.has(k)) { this.lit.delete(k); changed = true; }
      }
      if (!changed && pass > 1) break;
    }
    return { wire, powered };
  }

  private powerOf(wire: Map<string, number>, powered: Map<string, Set<string>>, x: number, y: number, z: number): number {
    let best = wire.get(key(x, y, z)) ?? 0;
    const d = DIRS.map(o => [x + o[0], y + o[1], z + o[2]] as Pos).concat([[x, y, z]]);
    for (const p of d) {
      best = Math.max(best, wire.get(key(p[0], p[1], p[2])) ?? 0);
      if (powered.has(key(p[0], p[1], p[2]))) best = Math.max(best, 15);
    }
    return best;
  }

  /** Runs one redstone tick. Call this every game tick; it is cheap for small circuits. */
  tick() {
    this.ticks++;
    const { wire, powered } = this.solver();
    const power = (p: Pos) => this.powerOf(wire, powered, p[0], p[1], p[2]);
    const setEdge = (k: string, on: boolean) => {
      const prev = this.edges.get(k) ?? false;
      this.edges.set(k, on);
      return on && !prev;
    };

    for (const k of [...this.active]) {
      const [x, y, z] = parse(k), { id, state } = this.at(x, y, z);
      if (id < 0) { this.active.delete(k); continue; }
      if (isWire(id)) {
        const level = wire.get(k) ?? 0;
        if (state !== level) this.set(x, y, z, id, level);
        continue;
      }
      if (isTorch(id)) {
        const wantLit = this.lit.has(k), wantId = wantLit ? ID.redstone_torch : ID.unlit_redstone_torch;
        if (id !== wantId) this.set(x, y, z, wantId, state);
        continue;
      }
      if (isRepeater(id)) {
        const dir = state & 3, f = FACE[dir], b = this.back(x, y, z, state), out = this.repOut.get(k) ?? 0;
        const input = Math.max(
          power(b),
          isWire(idOf(this.host.getCell(b[0], b[1], b[2]))) ? 0 : 0,
          this.directBehind(b),
        );
        // Repeaters lock when another diode points into their side; then timers freeze.
        const s1 = this.side(x, y, z, state, 1), s2 = this.side(x, y, z, state, 0);
        const locked = this.pointingIn(s1, [x, y, z]) || this.pointingIn(s2, [x, y, z]);
        const want = input > 0 ? 15 : 0;
        if (want !== out && !locked) {
          const delay = 2 + ((state >> 2) & 3) * 2;
          const timer = this.repTimers.get(k) ?? -1;
          if (timer < 0) this.repTimers.set(k, this.ticks + delay);
          else if (this.ticks >= timer) {
            this.repTimers.delete(k);
            this.repOut.set(k, want);
            this.changes++;
            const fp: Pos = [x + f[0], y + f[1], z + f[2]];
            this.host.sound?.('click', fp[0], fp[1], fp[2]);
          }
        } else if (want === out) this.repTimers.delete(k);
        continue;
      }
      if (isComparator(id)) {
        const b = this.back(x, y, z, state);
        const container = this.host.containerSignal?.(b[0], b[1], b[2]) ?? 0;
        const input = Math.max(this.directBehind(b), container, power(b));
        const s1 = this.side(x, y, z, state, 1), s2 = this.side(x, y, z, state, 0);
        const side = Math.max(this.directBehind(s1), this.directBehind(s2), power(s1), power(s2), this.host.containerSignal?.(s1[0], s1[1], s1[2]) ?? 0, this.host.containerSignal?.(s2[0], s2[1], s2[2]) ?? 0);
        const out = state & 4 ? Math.max(0, input - side) : input >= side ? input : 0;
        if ((this.compOut.get(k) ?? 0) !== out) { this.compOut.set(k, out); this.changes++; }
        continue;
      }
      if (isLamp(id)) {
        const on = power([x, y, z]) > 0;
        const want = on ? ID.redstone_lamp : ID.unlit_redstone_lamp;
        if (id !== want) this.set(x, y, z, want, state);
        continue;
      }
      if (isPiston(id)) {
        const on = power([x, y, z]) > 0, extended = (state & 8) !== 0;
        if (on && !extended) { if (this.extendPiston(x, y, z, state)) this.set(x, y, z, id, state | 8); }
        else if (!on && extended) { this.retractPiston(x, y, z, id, state); this.set(x, y, z, id, state & 7); }
        continue;
      }
      if (isDoor(id)) {
        const on = power([x, y, z]) > 0;
        if ((this.edges.get(k) ?? false) !== on) { this.edges.set(k, on); this.host.door?.(x, y, z, on); }
        continue;
      }
      if (isEmitter(id)) {
        const on = power([x, y, z]) > 0;
        if (setEdge(k, on)) {
          const face = state & 7;
          this.host.eject?.(x, y, z, face, id === ID.dispenser ? 'dispenser' : 'dropper');
          this.host.sound?.('click', x, y, z);
        }
        continue;
      }
      if (id === ID.hopper) {
        if (power([x, y, z]) === 0) this.host.transfer?.(x, y, z, state & 7);
        continue;
      }
      if (id === ID.note_block) { if (setEdge(k, power([x, y, z]) > 0)) this.host.sound?.('note', x, y, z); continue; }
      if (id === ID.tnt) {
        if (power([x, y, z]) > 0 && !this.ignited.has(k)) { this.ignited.add(k); this.host.ignite?.(x, y, z); }
        continue;
      }
      if (id === ID.powered_rail) {
        const on = power([x, y, z]) > 0;
        if ((state & 1) !== (on ? 1 : 0)) this.set(x, y, z, id, on ? state | 1 : state & 14);
        continue;
      }
      if (isPlate(id)) {
        if (setEdge(k, power([x, y, z]) > 0)) this.host.sound?.('click', x, y, z);
      }
    }

    // Observers: fire a two-tick pulse when the block they watch changes; they need no neighbours to detect it.
    for (const [k, o] of this.observers) {
      const [x, y, z] = parse(k), f = FACE[o.face], seen = this.snapshot({ cell: this.host.getCell(x + f[0], y + f[1], z + f[2]) });
      if (seen !== o.last) { o.last = seen; this.pulses.set(k, 2); }
      const pulse = (this.pulses.get(k) ?? 0);
      if (pulse > 0) this.pulses.set(k, pulse - 1);
    }
    this.pending.clear();
  }

  private directBehind(p: Pos): number {
    const { id, state } = this.at(p[0], p[1], p[2]);
    if (id < 0) return 0;
    if ((isLever(id) || isButton(id) || isPlate(id)) && state & 8) return 15;
    if (id === ID.redstone_block) return 15;
    if (id === ID.daylight_detector || id === ID.target) return state & 15;
    if (id === ID.redstone_torch) return 15;
    return 0;
  }

  /** True when a diode at side points into the given cell (used for repeater locking). */
  private pointingIn(side: Pos, target: readonly [number, number, number]): boolean {
    const { id, state } = this.at(side[0], side[1], side[2]);
    if (!isRepeater(id) && !isComparator(id)) return false;
    const f = FACE[state & 3];
    return side[0] + f[0] === target[0] && side[1] + f[1] === target[1] && side[2] + f[2] === target[2] && (this.repOut.get(key(side[0], side[1], side[2])) ?? this.compOut.get(key(side[0], side[1], side[2])) ?? 0) > 0;
  }

  // ------------------------------------------------------------------ pistons

  private immovable(id: number): boolean {
    if (id <= 0) return false;
    const n = nameOf(id);
    return id === ID.bedrock || id === ID.obsidian || id === ID.spawner || id === ID.chest || id === ID.furnace ||
      id === ID.blast_furnace || id === ID.smoker || id === ID.barrel || id === ID.hopper || n === 'enchanting_table' ||
      id === ID.piston || id === ID.sticky_piston || id === ID.end_portal;
  }

  private extendPiston(x: number, y: number, z: number, state: number): boolean {
    const f = FACE[state & 7];
    const blocks: { x: number; y: number; z: number; cell: number }[] = [];
    for (let i = 1; i <= 13; i++) {
      const bx = x + f[0] * i, by = y + f[1] * i, bz = z + f[2] * i;
      const cell = this.host.getCell(bx, by, bz), bid = idOf(cell);
      if (bid === 0) {
        if (blocks.length > 12) return false;
        // Move the collected line one step forward, farthest first.
        for (let j = blocks.length - 1; j >= 0; j--) {
          const b = blocks[j];
          if (this.immovable(idOf(b.cell)) || b.cell < 0) return false;
          this.set(b.x, b.y, b.z, 0);
          this.set(b.x + f[0], b.y + f[1], b.z + f[2], idOf(b.cell), stOf(b.cell));
        }
        this.host.sound?.('piston', x, y, z);
        return true;
      }
      if (this.immovable(bid) || blocks.length >= 12) return false;
      blocks.push({ x: bx, y: by, z: bz, cell });
    }
    return false;
  }

  private retractPiston(x: number, y: number, z: number, id: number, state: number) {
    if (id !== ID.sticky_piston) return;
    const f = FACE[state & 7];
    const from = { x: x + f[0] * 2, y: y + f[1] * 2, z: z + f[2] * 2 };
    const into = { x: x + f[0], y: y + f[1], z: z + f[2] };
    const cell = this.host.getCell(from.x, from.y, from.z);
    if (cell > 0 && !this.immovable(idOf(cell)) && idOf(this.host.getCell(into.x, into.y, into.z)) === 0) {
      this.set(from.x, from.y, from.z, 0);
      this.set(into.x, into.y, into.z, idOf(cell), stOf(cell));
    }
    this.host.sound?.('piston', x, y, z);
  }

  // ------------------------------------------------------------------ player input

  /** Flip a lever or press a button. Buttons stay pressed for two redstone ticks (vanilla wooden button). */
  press(x: number, y: number, z: number) {
    const { id, state } = this.at(x, y, z);
    if (isLever(id)) { this.set(x, y, z, id, state ^ 8); this.host.sound?.('click', x, y, z); return true; }
    if (isButton(id)) {
      if (state & 8) return false;
      this.set(x, y, z, id, state | 8);
      this.host.sound?.('click', x, y, z);
      setTimeout(() => { const now = this.at(x, y, z); if (isButton(now.id) && now.state & 8) this.set(x, y, z, now.id, now.state & 7); }, 1500);
      return true;
    }
    return false;
  }

  setPlate(x: number, y: number, z: number, pressed: boolean) {
    const { id, state } = this.at(x, y, z);
    if (!isPlate(id)) return;
    const want = pressed ? state | 8 : state & 7;
    if (state !== want) this.set(x, y, z, id, want);
  }

  /** Nearest redstone-relevant position to a coordinate, for diagnostics. */
  nearest(x: number, y: number, z: number): string[] {
    return [...this.active].sort((a, b) => {
      const [ax, ay, az] = parse(a), [bx, by, bz] = parse(b);
      return Math.hypot(ax - x, ay - y, az - z) - Math.hypot(bx - x, by - y, bz - z);
    }).slice(0, 12);
  }

  /** Only used by the debug overlay. */
  get warningCount() { return this.warned.size; }
}
