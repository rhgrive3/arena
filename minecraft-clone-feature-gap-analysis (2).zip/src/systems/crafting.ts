import { DYES } from '../game/content';

export interface Recipe {
  id: string;
  result: string;
  count: number;
  ingredients: Record<string, number>;
  grid: (string | null)[][];
  station: 'inventory' | 'crafting_table';
  category: string;
}

export const RECIPES: Recipe[] = [];

function recipe(
  id: string,
  result: string,
  count: number,
  rows: string[],
  key: Record<string, string>,
  station: 'inventory' | 'crafting_table' = 'inventory',
  category = 'building',
) {
  const ingredients: Record<string, number> = {};
  const grid = rows.map(r =>
    [...r].map(c => {
      if (c === ' ') return null;
      const name = key[c];
      if (!name) throw new Error('Unknown recipe key ' + c);
      ingredients[name] = (ingredients[name] || 0) + 1;
      return name;
    }),
  );
  RECIPES.push({ id, result, count, ingredients, grid, station, category });
}

recipe('oak_planks', 'oak_planks', 4, ['L'], { L: 'oak_log' });
recipe('birch_planks', 'birch_planks', 4, ['L'], { L: 'birch_log' });
for (const wood of ['spruce', 'jungle', 'acacia', 'dark_oak', 'cherry', 'mangrove', 'pale_oak', 'crimson', 'warped', 'poplar']) {
  recipe(wood + '_planks', wood + '_planks', 4, ['L'], { L: wood + '_log' });
}

recipe('stick', 'stick', 4, ['P', 'P'], { P: 'oak_planks' });
recipe('crafting_table', 'crafting_table', 1, ['PP', 'PP'], { P: 'oak_planks' }, 'inventory', 'utility');
recipe('furnace', 'furnace', 1, ['CCC', 'C C', 'CCC'], { C: 'cobblestone' }, 'crafting_table', 'utility');
recipe('chest', 'chest', 1, ['PPP', 'P P', 'PPP'], { P: 'oak_planks' }, 'crafting_table', 'utility');
recipe('barrel', 'barrel', 1, ['PSP', 'P P', 'PSP'], { P: 'oak_planks', S: 'oak_slab' }, 'crafting_table', 'utility');
recipe('bed', 'bed', 1, ['WWW', 'PPP'], { W: 'white_wool', P: 'oak_planks' }, 'crafting_table', 'utility');
recipe('torch', 'torch', 4, ['C', 'S'], { C: 'coal', S: 'stick' }, 'inventory', 'utility');
recipe('torch_charcoal', 'torch', 4, ['C', 'S'], { C: 'charcoal', S: 'stick' }, 'inventory', 'utility');
recipe('lantern', 'lantern', 1, ['III', 'ITI', 'III'], { I: 'iron_ingot', T: 'torch' }, 'crafting_table', 'utility');
recipe('ladder', 'ladder', 3, ['S S', 'SSS', 'S S'], { S: 'stick' }, 'crafting_table', 'utility');
recipe('oak_door', 'oak_door', 3, ['PP', 'PP', 'PP'], { P: 'oak_planks' }, 'crafting_table', 'building');
recipe('stone_bricks', 'stone_bricks', 4, ['SS', 'SS'], { S: 'stone' });
recipe('sandstone', 'sandstone', 1, ['SS', 'SS'], { S: 'sand' });
recipe('cut_sandstone', 'cut_sandstone', 4, ['SS', 'SS'], { S: 'sandstone' });
recipe('end_stone_bricks', 'end_stone_bricks', 4, ['EE', 'EE'], { E: 'end_stone' });
recipe('purpur_block', 'purpur_block', 4, ['CC', 'CC'], { C: 'popped_chorus_fruit' });
recipe('end_rod', 'end_rod', 4, ['B', 'C'], { B: 'blaze_rod', C: 'popped_chorus_fruit' }, 'inventory', 'utility');
recipe('glass_pane', 'glass_pane', 16, ['GGG', 'GGG'], { G: 'glass' }, 'crafting_table');
recipe('iron_bars', 'iron_bars', 16, ['III', 'III'], { I: 'iron_ingot' }, 'crafting_table');
recipe('bookshelf', 'bookshelf', 1, ['PPP', 'BBB', 'PPP'], { P: 'oak_planks', B: 'book' }, 'crafting_table', 'utility');
recipe('enchanting_table', 'enchanting_table', 1, [' B ', 'DOD', 'OOO'], { B: 'book', D: 'diamond', O: 'obsidian' }, 'crafting_table', 'utility');
recipe('anvil', 'anvil', 1, ['III', ' I ', 'III'], { I: 'iron_ingot' }, 'crafting_table', 'utility');
recipe('paper', 'paper', 3, ['SSS'], { S: 'sugar_cane' }, 'crafting_table', 'materials');
recipe('book', 'book', 1, ['PP', 'PL'], { P: 'paper', L: 'leather' }, 'inventory', 'materials');
recipe('bread', 'bread', 1, ['WWW'], { W: 'wheat' }, 'crafting_table', 'food');
recipe('golden_apple', 'golden_apple', 1, ['GGG', 'GAG', 'GGG'], { G: 'gold_ingot', A: 'apple' }, 'crafting_table', 'food');
recipe('cookie', 'cookie', 8, ['WCW'], { W: 'wheat', C: 'coal' }, 'crafting_table', 'food');

// Tools, weapons, utility gear & Progression to Nether / The End / End City
recipe('flint_and_steel', 'flint_and_steel', 1, ['I ', ' F'], { I: 'iron_ingot', F: 'flint' }, 'inventory', 'tools');
recipe('bucket', 'bucket', 1, ['I I', ' I '], { I: 'iron_ingot' }, 'crafting_table', 'tools');
recipe('shears', 'shears', 1, [' I', 'I '], { I: 'iron_ingot' }, 'inventory', 'tools');
recipe('bow', 'bow', 1, [' ST', 'S T', ' ST'], { S: 'stick', T: 'string' }, 'crafting_table', 'tools');
recipe('arrow', 'arrow', 4, ['F', 'S', 'E'], { F: 'flint', S: 'stick', E: 'feather' }, 'crafting_table', 'tools');
recipe('compass', 'compass', 1, [' I ', 'IRI', ' I '], { I: 'iron_ingot', R: 'redstone' }, 'crafting_table', 'tools');
recipe('clock', 'clock', 1, [' G ', 'GRG', ' G '], { G: 'gold_ingot', R: 'redstone' }, 'crafting_table', 'tools');
recipe('blaze_powder', 'blaze_powder', 2, ['B'], { B: 'blaze_rod' }, 'inventory', 'materials');
recipe('ender_eye', 'ender_eye', 1, ['PB'], { P: 'ender_pearl', B: 'blaze_powder' }, 'inventory', 'tools');
recipe('end_crystal', 'end_crystal', 1, ['GGG', 'GEG', 'GTG'], { G: 'glass', E: 'ender_eye', T: 'ghast_tear' }, 'crafting_table', 'tools');
recipe('shulker_box', 'shulker_box', 1, ['S', 'C', 'S'], { S: 'shulker_shell', C: 'chest' }, 'crafting_table', 'utility');
recipe('firework_rocket', 'firework_rocket', 3, ['P', 'G'], { P: 'paper', G: 'gunpowder' }, 'inventory', 'tools');
recipe('netherite_ingot', 'netherite_ingot', 1, ['SSS', 'SGG', 'GG '], { S: 'netherite_scrap', G: 'gold_ingot' }, 'crafting_table', 'materials');

// Redstone
recipe('lever', 'lever', 1, ['S', 'C'], { S: 'stick', C: 'cobblestone' }, 'inventory', 'redstone');
recipe('tnt', 'tnt', 1, ['GSG', 'SGS', 'GSG'], { G: 'gunpowder', S: 'sand' }, 'crafting_table', 'redstone');
recipe('redstone_lamp', 'redstone_lamp', 1, [' R ', 'RGR', ' R '], { R: 'redstone', G: 'glowstone' }, 'crafting_table', 'redstone');
recipe('piston', 'piston', 1, ['PPP', 'CIC', 'CRC'], { P: 'oak_planks', C: 'cobblestone', I: 'iron_ingot', R: 'redstone' }, 'crafting_table', 'redstone');
recipe('sticky_piston', 'sticky_piston', 1, ['S', 'P'], { S: 'slime_ball', P: 'piston' }, 'inventory', 'redstone');
recipe('note_block', 'note_block', 1, ['PPP', 'PRP', 'PPP'], { P: 'oak_planks', R: 'redstone' }, 'crafting_table', 'redstone');

for (const wood of ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak', 'cherry']) {
  const material = wood + '_planks';
  recipe(wood + '_slab', wood + '_slab', 6, ['MMM'], { M: material }, 'crafting_table');
  recipe(wood + '_stairs', wood + '_stairs', 4, ['M  ', 'MM ', 'MMM'], { M: material }, 'crafting_table');
}
for (const color of Object.keys(DYES)) {
  for (const material of ['wool', 'concrete']) {
    const base = color + '_' + material;
    recipe(base + '_slab', base + '_slab', 6, ['MMM'], { M: base }, 'crafting_table');
    recipe(base + '_stairs', base + '_stairs', 4, ['M  ', 'MM ', 'MMM'], { M: base }, 'crafting_table');
  }
}

const tiers: Record<string, string> = {
  wooden: 'oak_planks',
  stone: 'cobblestone',
  iron: 'iron_ingot',
  golden: 'gold_ingot',
  diamond: 'diamond',
};

for (const [tier, mat] of Object.entries(tiers)) {
  const k = { M: mat, S: 'stick' };
  recipe(tier + '_pickaxe', tier + '_pickaxe', 1, ['MMM', ' S ', ' S '], k, 'crafting_table', 'tools');
  recipe(tier + '_axe', tier + '_axe', 1, ['MM', 'MS', ' S'], k, 'crafting_table', 'tools');
  recipe(tier + '_shovel', tier + '_shovel', 1, ['M', 'S', 'S'], k, 'crafting_table', 'tools');
  recipe(tier + '_sword', tier + '_sword', 1, ['M', 'M', 'S'], k, 'crafting_table', 'tools');
  recipe(tier + '_hoe', tier + '_hoe', 1, ['MM', ' S', ' S'], k, 'crafting_table', 'tools');
}

for (const [tier, mat] of Object.entries({ iron: 'iron_ingot', golden: 'gold_ingot', diamond: 'diamond' })) {
  const k = { M: mat };
  recipe(tier + '_helmet', tier + '_helmet', 1, ['MMM', 'M M'], k, 'crafting_table', 'tools');
  recipe(tier + '_chestplate', tier + '_chestplate', 1, ['M M', 'MMM', 'MMM'], k, 'crafting_table', 'tools');
  recipe(tier + '_leggings', tier + '_leggings', 1, ['MMM', 'M M', 'M M'], k, 'crafting_table', 'tools');
  recipe(tier + '_boots', tier + '_boots', 1, ['M M', 'M M'], k, 'crafting_table', 'tools');
}

for (const type of ['pickaxe', 'axe', 'shovel', 'sword', 'helmet', 'chestplate', 'leggings', 'boots']) {
  recipe('netherite_' + type, 'netherite_' + type, 1, ['DN'], { D: 'diamond_' + type, N: 'netherite_ingot' }, 'crafting_table', 'tools');
}

export const SMELTING: Record<string, { result: string; time: number }> = {
  iron_ore: { result: 'iron_ingot', time: 8 },
  deepslate_iron_ore: { result: 'iron_ingot', time: 8 },
  raw_iron: { result: 'iron_ingot', time: 8 },
  gold_ore: { result: 'gold_ingot', time: 8 },
  deepslate_gold_ore: { result: 'gold_ingot', time: 8 },
  nether_gold_ore: { result: 'gold_ingot', time: 8 },
  raw_gold: { result: 'gold_ingot', time: 8 },
  ancient_debris: { result: 'netherite_scrap', time: 12 },
  sand: { result: 'glass', time: 8 },
  red_sand: { result: 'glass', time: 8 },
  cobblestone: { result: 'stone', time: 8 },
  netherrack: { result: 'nether_bricks', time: 8 },
  chorus_fruit: { result: 'popped_chorus_fruit', time: 8 },
  raw_beef: { result: 'cooked_beef', time: 7 },
  porkchop: { result: 'cooked_porkchop', time: 7 },
  mutton: { result: 'cooked_mutton', time: 7 },
  potato: { result: 'baked_potato', time: 7 },
  cod: { result: 'cooked_cod', time: 7 },
  salmon: { result: 'cooked_salmon', time: 7 },
  oak_log: { result: 'charcoal', time: 8 },
  birch_log: { result: 'charcoal', time: 8 },
  spruce_log: { result: 'charcoal', time: 8 },
  cherry_log: { result: 'charcoal', time: 8 },
};

export const FUEL: Record<string, number> = {
  coal: 80,
  charcoal: 80,
  blaze_rod: 120,
  lava_bucket: 1000,
  oak_planks: 15,
  birch_planks: 15,
  spruce_planks: 15,
  oak_log: 15,
  birch_log: 15,
  spruce_log: 15,
  stick: 5,
  crafting_table: 15,
  chest: 15,
};

export function recipeCounts(stacks: ( { name: string; count: number } | null )[]) {
  const counts: Record<string, number> = {};
  for (const s of stacks) if (s) counts[s.name] = (counts[s.name] || 0) + s.count;
  return counts;
}

export function canCraft(recipe: Recipe, counts: Record<string, number>, creative: boolean, workbench: boolean) {
  if (!workbench && recipe.station === 'crafting_table' && !creative) return false;
  if (creative) return true;
  return Object.entries(recipe.ingredients).every(([name, need]) => (counts[name] || 0) >= need);
}

// ===== v11 recipes: full wood sets, storage blocks, stone families, dyes, redstone parts, workstations, gear ============
import { resolve as _res, BLOCKS as _BLOCKS, ID as _ID } from '../game/data';
const R = (id: string, result: string, count: number, rows: string[], key: Record<string, string>, category = 'building') => {
  if (!_res(result) || RECIPES.some(r => r.id === id) || Object.values(key).some(v => !_res(v))) return;
  const small = rows.length <= 2 && rows.every(r => r.length <= 2);
  recipe(id, result, count, rows, key, small ? 'inventory' : 'crafting_table', category);
};
const WOODS = ['oak', 'birch', 'spruce', 'jungle', 'acacia', 'dark_oak', 'cherry', 'mangrove', 'pale_oak', 'crimson', 'warped', 'poplar'];
for (const w of WOODS) {
  const P = { P: w + '_planks' }, PS = { P: w + '_planks', S: 'stick' };
  R(w + '_stick', 'stick', 4, ['P', 'P'], P, 'materials');
  R(w + '_crafting_table', 'crafting_table', 1, ['PP', 'PP'], P, 'utility');
  R(w + '_chest', 'chest', 1, ['PPP', 'P P', 'PPP'], P, 'utility');
  R(w + '_slab', w + '_slab', 6, ['PPP'], P);
  R(w + '_stairs', w + '_stairs', 4, ['P  ', 'PP ', 'PPP'], P);
  R(w + '_fence', w + '_fence', 3, ['PSP', 'PSP'], PS);
  R(w + '_door', w + '_door', 3, ['PP', 'PP', 'PP'], P);
  R(w + '_trapdoor', w + '_trapdoor', 2, ['PPP', 'PPP'], P);
  R(w + '_pressure_plate', w + '_pressure_plate', 1, ['PP'], P, 'redstone');
  R(w + '_button', w + '_button', 1, ['P'], P, 'redstone');
  R(w + '_bowl', 'bowl', 4, ['P P', ' P '], P, 'materials');
  R(w + '_shield', 'shield', 1, ['PIP', 'PPP', ' P '], { P: w + '_planks', I: 'iron_ingot' }, 'tools');
  R(w + '_bookshelf', 'bookshelf', 1, ['PPP', 'BBB', 'PPP'], { P: w + '_planks', B: 'book' }, 'utility');
  R(w + '_sign', 'sign', 3, ['PPP', 'PPP', ' S '], PS, 'utility');
  R(w + '_boat', 'boat', 1, ['P P', 'PPP'], P, 'tools');
}
for (const [blockName, itemName] of [['coal_block', 'coal'], ['iron_block', 'iron_ingot'], ['gold_block', 'gold_ingot'], ['diamond_block', 'diamond'], ['emerald_block', 'emerald'], ['lapis_block', 'lapis_lazuli'], ['copper_block', 'copper_ingot'], ['netherite_block', 'netherite_ingot'], ['redstone_block', 'redstone'], ['hay_block', 'wheat'], ['bone_block', 'bone_meal'], ['slime_block', 'slime_ball'], ['iron_ingot', 'iron_nugget'], ['gold_ingot', 'gold_nugget'], ['melon', 'melon_slice'], ['packed_ice', 'ice'], ['prismarine_bricks', 'prismarine_shard']]) {
  R(blockName + '_pack', blockName, 1, ['XXX', 'XXX', 'XXX'], { X: itemName }, 'materials');
  if (!['melon', 'packed_ice', 'prismarine_bricks'].includes(blockName)) R(blockName + '_unpack', itemName, 9, ['X'], { X: blockName }, 'materials');
}
for (const [res, n, src] of [['polished_granite', 4, 'granite'], ['polished_diorite', 4, 'diorite'], ['polished_andesite', 4, 'andesite'], ['polished_deepslate', 4, 'cobbled_deepslate'], ['deepslate_bricks', 4, 'polished_deepslate'], ['deepslate_tiles', 4, 'deepslate_bricks'], ['polished_blackstone', 4, 'blackstone'], ['polished_blackstone_bricks', 4, 'polished_blackstone'], ['prismarine', 1, 'prismarine_shard'], ['quartz_block', 1, 'quartz'], ['quartz_bricks', 4, 'quartz_block'], ['amethyst_block', 1, 'amethyst_shard'], ['glowstone', 1, 'glowstone_dust'], ['snow_block', 1, 'snowball'], ['clay', 1, 'clay_ball'], ['bricks', 1, 'brick'], ['nether_bricks', 1, 'nether_brick'], ['magma_block', 1, 'magma_cream'], ['mud_bricks', 4, 'packed_mud'], ['cut_copper', 4, 'copper_block'], ['honey_block', 1, 'honey_bottle'], ['white_wool', 1, 'string'], ['smooth_sandstone', 4, 'cut_sandstone'], ['red_sandstone', 1, 'red_sand']] as const)
  R(res + '_2x2', res, n, ['XX', 'XX'], { X: src });
const MISC: [string, string, number, string[], Record<string, string>, string][] = [
  ['dark_prismarine', 'dark_prismarine', 1, ['XXX', 'XIX', 'XXX'], { X: 'prismarine_shard', I: 'ink_sac' }, 'building'],
  ['sea_lantern', 'sea_lantern', 1, ['SCS', 'CCC', 'SCS'], { S: 'prismarine_shard', C: 'prismarine_crystals' }, 'building'],
  ['mossy_cobblestone', 'mossy_cobblestone', 1, ['CV'], { C: 'cobblestone', V: 'vine' }, 'building'],
  ['mossy_stone_bricks', 'mossy_stone_bricks', 1, ['CV'], { C: 'stone_bricks', V: 'vine' }, 'building'],
  ['chiseled_stone_bricks', 'chiseled_stone_bricks', 1, ['S', 'S'], { S: 'stone_brick_slab' }, 'building'],
  ['coarse_dirt', 'coarse_dirt', 4, ['DG', 'GD'], { D: 'dirt', G: 'gravel' }, 'building'],
  ['packed_mud', 'packed_mud', 1, ['MW'], { M: 'mud', W: 'wheat' }, 'building'],
  ['red_nether_bricks', 'red_nether_bricks', 1, ['NW', 'WN'], { N: 'nether_brick', W: 'nether_wart' }, 'building'],
  ['snow_layer', 'snow_layer', 6, ['SSS'], { S: 'snow_block' }, 'building'],
  ['moss_carpet', 'moss_carpet', 3, ['MM'], { M: 'moss_block' }, 'building'],
  ['tinted_glass', 'tinted_glass', 2, [' A ', 'AGA', ' A '], { A: 'amethyst_shard', G: 'glass' }, 'building'],
  ['iron_door', 'iron_door', 3, ['II', 'II', 'II'], { I: 'iron_ingot' }, 'building'],
  ['chain', 'chain', 1, ['N', 'I', 'N'], { N: 'iron_nugget', I: 'iron_ingot' }, 'building'],
  ['bone_meal', 'bone_meal', 3, ['B'], { B: 'bone' }, 'materials'],
  ['sugar', 'sugar', 1, ['S'], { S: 'sugar_cane' }, 'materials'],
  ['fermented_spider_eye', 'fermented_spider_eye', 1, ['ES', 'M '], { E: 'spider_eye', S: 'sugar', M: 'brown_mushroom' }, 'materials'],
  ['glistering_melon_slice', 'glistering_melon_slice', 1, ['NNN', 'NMN', 'NNN'], { N: 'gold_nugget', M: 'melon_slice' }, 'materials'],
  ['magma_cream', 'magma_cream', 1, ['BS'], { B: 'blaze_powder', S: 'slime_ball' }, 'materials'],
  ['glass_bottle', 'glass_bottle', 3, ['G G', ' G '], { G: 'glass' }, 'materials'],
  ['netherite_upgrade', 'netherite_upgrade', 2, ['DTD', 'DND', 'DDD'], { D: 'diamond', T: 'netherite_upgrade', N: 'netherrack' }, 'materials'],
  ['golden_carrot', 'golden_carrot', 1, ['NNN', 'NCN', 'NNN'], { N: 'gold_nugget', C: 'carrot' }, 'food'],
  ['enchanted_golden_apple', 'enchanted_golden_apple', 1, ['GGG', 'GAG', 'GGG'], { G: 'gold_block', A: 'apple' }, 'food'],
  ['mushroom_stew', 'mushroom_stew', 1, ['RB', 'W '], { R: 'red_mushroom', B: 'brown_mushroom', W: 'bowl' }, 'food'],
  ['rabbit_stew', 'rabbit_stew', 1, [' R ', 'CPM', ' B '], { R: 'cooked_rabbit', C: 'carrot', P: 'baked_potato', M: 'brown_mushroom', B: 'bowl' }, 'food'],
  ['beetroot_soup', 'beetroot_soup', 1, ['BBB', 'BBB', ' W '], { B: 'beetroot', W: 'bowl' }, 'food'],
  ['pumpkin_pie', 'pumpkin_pie', 1, ['PS', 'E '], { P: 'pumpkin', S: 'sugar', E: 'egg' }, 'food'],
  ['honey_bottle', 'honey_bottle', 4, ['BB', 'BB'], { B: 'glass_bottle' }, 'food'],
  ['brewing_stand', 'brewing_stand', 1, [' B ', 'CCC'], { B: 'blaze_rod', C: 'cobblestone' }, 'utility'],
  ['cauldron', 'cauldron', 1, ['I I', 'I I', 'III'], { I: 'iron_ingot' }, 'utility'],
  ['smithing_table', 'smithing_table', 1, ['II', 'PP', 'PP'], { I: 'iron_ingot', P: 'oak_planks' }, 'utility'],
  ['cartography_table', 'cartography_table', 1, ['AA', 'PP', 'PP'], { A: 'paper', P: 'oak_planks' }, 'utility'],
  ['fletching_table', 'fletching_table', 1, ['FF', 'PP', 'PP'], { F: 'flint', P: 'oak_planks' }, 'utility'],
  ['loom', 'loom', 1, ['SS', 'PP'], { S: 'string', P: 'oak_planks' }, 'utility'],
  ['lectern', 'lectern', 1, ['SSS', ' B ', ' S '], { S: 'oak_slab', B: 'bookshelf' }, 'utility'],
  ['stonecutter', 'stonecutter', 1, [' I ', 'SSS'], { I: 'iron_ingot', S: 'stone' }, 'utility'],
  ['grindstone', 'grindstone', 1, ['TST', 'P P'], { T: 'stick', S: 'stone', P: 'oak_planks' }, 'utility'],
  ['blast_furnace', 'blast_furnace', 1, ['III', 'IFI', 'SSS'], { I: 'iron_ingot', F: 'furnace', S: 'smooth_stone' }, 'utility'],
  ['smoker', 'smoker', 1, [' L ', 'LFL', ' L '], { L: 'oak_log', F: 'furnace' }, 'utility'],
  ['anvil_blocks', 'anvil', 1, ['BBB', ' I ', 'III'], { B: 'iron_block', I: 'iron_ingot' }, 'utility'],
  ['soul_torch', 'soul_torch', 4, ['C', 'S', 'O'], { C: 'coal', S: 'stick', O: 'soul_sand' }, 'utility'],
  ['soul_lantern', 'soul_lantern', 1, ['NNN', 'NTN', 'NNN'], { N: 'iron_nugget', T: 'soul_torch' }, 'utility'],
  ['painting', 'painting', 1, ['SSS', 'SWS', 'SSS'], { S: 'stick', W: 'white_wool' }, 'utility'],
  ['item_frame', 'item_frame', 1, ['SSS', 'SLS', 'SSS'], { S: 'stick', L: 'leather' }, 'utility'],
  ['crossbow', 'crossbow', 1, ['SIS', 'TST', ' S '], { S: 'stick', I: 'iron_ingot', T: 'string' }, 'tools'],
  ['mace', 'mace', 1, ['H', 'B'], { H: 'heavy_core', B: 'breeze_rod' }, 'tools'],
  ['turtle_helmet', 'turtle_helmet', 1, ['SSS', 'S S'], { S: 'scute' }, 'tools'],
  ['spectral_arrow', 'spectral_arrow', 2, [' G ', 'GAG', ' G '], { G: 'glowstone_dust', A: 'arrow' }, 'tools'],
  ['fishing_rod', 'fishing_rod', 1, ['  S', ' ST', 'S T'], { S: 'stick', T: 'string' }, 'tools'],
  ['spyglass', 'spyglass', 1, ['A', 'C', 'C'], { A: 'amethyst_shard', C: 'copper_ingot' }, 'tools'],
  ['lead', 'lead', 2, ['SS ', 'SB ', '  S'], { S: 'string', B: 'slime_ball' }, 'tools'],
  ['map', 'map', 1, ['PPP', 'PCP', 'PPP'], { P: 'paper', C: 'compass' }, 'tools'],
  ['writable_book', 'writable_book', 1, ['BI', 'F '], { B: 'book', I: 'ink_sac', F: 'feather' }, 'tools'],
  ['minecart', 'minecart', 1, ['I I', 'III'], { I: 'iron_ingot' }, 'tools'],
  ['repeater', 'repeater', 1, ['TRT', 'SSS'], { T: 'redstone_torch', R: 'redstone', S: 'stone' }, 'redstone'],
  ['comparator', 'comparator', 1, [' T ', 'TQT', 'SSS'], { T: 'redstone_torch', Q: 'quartz', S: 'stone' }, 'redstone'],
  ['redstone_torch', 'redstone_torch', 1, ['R', 'S'], { R: 'redstone', S: 'stick' }, 'redstone'],
  ['observer', 'observer', 1, ['CCC', 'RRQ', 'CCC'], { C: 'cobblestone', R: 'redstone', Q: 'quartz' }, 'redstone'],
  ['hopper', 'hopper', 1, ['I I', 'ICI', ' I '], { I: 'iron_ingot', C: 'chest' }, 'redstone'],
  ['dropper', 'dropper', 1, ['CCC', 'C C', 'CRC'], { C: 'cobblestone', R: 'redstone' }, 'redstone'],
  ['dispenser', 'dispenser', 1, ['CCC', 'CBC', 'CRC'], { C: 'cobblestone', B: 'bow', R: 'redstone' }, 'redstone'],
  ['rail', 'rail', 16, ['I I', 'ISI', 'I I'], { I: 'iron_ingot', S: 'stick' }, 'redstone'],
  ['powered_rail', 'powered_rail', 6, ['G G', 'GSG', 'GRG'], { G: 'gold_ingot', S: 'stick', R: 'redstone' }, 'redstone'],
  ['daylight_detector', 'daylight_detector', 1, ['GGG', 'QQQ', 'SSS'], { G: 'glass', Q: 'quartz', S: 'oak_slab' }, 'redstone'],
  ['target', 'target', 1, [' R ', 'RHR', ' R '], { R: 'redstone', H: 'hay_block' }, 'redstone'],
];
for (const [id, result, count, rows, key, cat] of MISC) R(id, result, count, rows, key, cat);
const ARMOR_ROWS: Record<string, string[]> = { helmet: ['MMM', 'M M'], chestplate: ['M M', 'MMM', 'MMM'], leggings: ['MMM', 'M M', 'M M'], boots: ['M M', 'M M'] };
for (const [tier, mat] of [['leather', 'leather'], ['copper', 'copper_ingot']]) for (const [type, rows] of Object.entries(ARMOR_ROWS)) R(tier + '_' + type, tier + '_' + type, 1, rows, { M: mat }, 'tools');
{
  const k = { M: 'copper_ingot', S: 'stick' };
  R('copper_pickaxe', 'copper_pickaxe', 1, ['MMM', ' S ', ' S '], k, 'tools'); R('copper_axe', 'copper_axe', 1, ['MM', 'MS', ' S'], k, 'tools');
  R('copper_shovel', 'copper_shovel', 1, ['M', 'S', 'S'], k, 'tools'); R('copper_sword', 'copper_sword', 1, ['M', 'M', 'S'], k, 'tools'); R('copper_hoe', 'copper_hoe', 1, ['MM', ' S', ' S'], k, 'tools');
}
const DYE_SRC: Record<string, string[]> = { red: ['poppy', 'beetroot'], yellow: ['dandelion', 'torchflower'], blue: ['cornflower', 'lapis_lazuli'], light_blue: ['blue_orchid'], white: ['bone_meal', 'lily_of_the_valley'], orange: ['orange_tulip'], pink: ['pink_tulip', 'pink_petals'], light_gray: ['azure_bluet', 'oxeye_daisy', 'white_tulip'], magenta: ['allium'], black: ['ink_sac'], brown: ['cocoa_beans'], cyan: ['pitcher_plant'] };
for (const [color, list] of Object.entries(DYE_SRC)) for (const src of list) R(color + '_dye_from_' + src, color + '_dye', 1, ['X'], { X: src }, 'materials');
for (const [out, a, b] of [['orange', 'red', 'yellow'], ['purple', 'red', 'blue'], ['cyan', 'blue', 'green'], ['gray', 'black', 'white'], ['light_gray', 'gray', 'white'], ['pink', 'red', 'white'], ['lime', 'green', 'white'], ['light_blue', 'blue', 'white'], ['magenta', 'purple', 'pink']]) R(out + '_dye_mix', out + '_dye', 2, ['AB'], { A: a + '_dye', B: b + '_dye' }, 'materials');
for (const color of Object.keys(DYES)) {
  const D = color + '_dye';
  if (color !== 'white') R(color + '_wool_dye', color + '_wool', 1, ['WD'], { W: 'white_wool', D }, 'decorations');
  R(color + '_carpet', color + '_carpet', 3, ['WW'], { W: color + '_wool' }, 'decorations');
  R(color + '_stained_glass', color + '_stained_glass', 8, ['GGG', 'GDG', 'GGG'], { G: 'glass', D });
  R(color + '_terracotta', color + '_terracotta', 8, ['TTT', 'TDT', 'TTT'], { T: 'terracotta', D });
  R(color + '_concrete', color + '_concrete', 8, ['SGS', 'GDG', 'SGS'], { S: 'sand', G: 'gravel', D });
  R(color + '_banner', color + '_banner', 1, ['WWW', 'WWW', ' S '], { W: color + '_wool', S: 'stick' }, 'decorations');
}

/** Stonecutter: one input block → a choice of outputs (no waste, like vanilla). */
export const STONECUT: Record<string, { result: string; count: number }[]> = {};
const cut = (from: string, result: string, count = 1) => {
  if (_ID[from] === undefined || _ID[result] === undefined || from === result) return;
  const list = (STONECUT[from] ??= []);
  if (!list.some(o => o.result === result)) list.push({ result, count });
};
for (const b of [..._BLOCKS]) {
  const m = /^(.*)_(stairs|slab|wall)$/.exec(b.name);
  if (!m || b.tool !== 'pickaxe') continue;
  const base = [m[1], m[1] + 's', m[1] + '_block'].find(n => _ID[n] !== undefined && n !== b.name);
  if (!base) continue;
  if (m[2] === 'stairs') R(b.name, b.name, 4, ['M  ', 'MM ', 'MMM'], { M: base });
  else if (m[2] === 'slab') R(b.name, b.name, 6, ['MMM'], { M: base });
  else R(b.name, b.name, 6, ['MMM', 'MMM'], { M: base });
  cut(base, b.name, m[2] === 'slab' ? 2 : 1);
}
for (const [from, ...outs] of [['stone', 'stone_bricks', 'chiseled_stone_bricks'], ['stone_bricks', 'chiseled_stone_bricks'], ['granite', 'polished_granite'], ['diorite', 'polished_diorite'], ['andesite', 'polished_andesite'], ['cobbled_deepslate', 'polished_deepslate', 'deepslate_bricks', 'deepslate_tiles', 'chiseled_deepslate'], ['polished_deepslate', 'deepslate_bricks', 'deepslate_tiles'], ['deepslate_bricks', 'deepslate_tiles'], ['blackstone', 'polished_blackstone', 'polished_blackstone_bricks', 'chiseled_polished_blackstone'], ['polished_blackstone', 'polished_blackstone_bricks', 'chiseled_polished_blackstone'], ['sandstone', 'cut_sandstone', 'chiseled_sandstone'], ['quartz_block', 'quartz_bricks'], ['prismarine', 'prismarine_bricks'], ['end_stone', 'end_stone_bricks'], ['copper_block', 'cut_copper'], ['purpur_block', 'purpur_pillar'], ['basalt', 'smooth_basalt']]) for (const o of outs) cut(from, o, o === 'cut_copper' ? 4 : 1);
for (const [from, via] of [['stone', 'stone_bricks'], ['end_stone', 'end_stone_bricks'], ['quartz_block', 'quartz_bricks']]) for (const o of STONECUT[via] ?? []) cut(from, o.result, o.count);

/** Smithing table: template + base gear + material. Enchantments and wear carry over to the result. */
export const SMITHING: { template: string; base: string; addition: string; result: string }[] = [];
for (const type of ['sword', 'pickaxe', 'axe', 'shovel', 'hoe', 'helmet', 'chestplate', 'leggings', 'boots']) if (_res('netherite_' + type) && _res('diamond_' + type)) SMITHING.push({ template: 'netherite_upgrade', base: 'diamond_' + type, addition: 'netherite_ingot', result: 'netherite_' + type });
for (let i = RECIPES.length - 1; i >= 0; i--) if (/^netherite_(pickaxe|axe|shovel|sword|helmet|chestplate|leggings|boots)$/.test(RECIPES[i].id)) RECIPES.splice(i, 1);

const smelt = (from: string, result: string, time = 8) => { if (_res(from) && _res(result) && !SMELTING[from]) SMELTING[from] = { result, time }; };
const ORE_OUT: Record<string, string> = { coal: 'coal', iron: 'iron_ingot', copper: 'copper_ingot', gold: 'gold_ingot', diamond: 'diamond', emerald: 'emerald', lapis: 'lapis_lazuli', redstone: 'redstone' };
for (const [o, out] of Object.entries(ORE_OUT)) for (const p of ['', 'deepslate_']) smelt(p + o + '_ore', out);
for (const [a, b, t] of [['raw_copper', 'copper_ingot', 8], ['nether_quartz_ore', 'quartz', 8], ['clay_ball', 'brick', 8], ['clay', 'terracotta', 8], ['stone', 'smooth_stone', 8], ['sandstone', 'smooth_sandstone', 8], ['cobbled_deepslate', 'deepslate', 8], ['kelp', 'dried_kelp', 7], ['cactus', 'green_dye', 8], ['wet_sponge', 'sponge', 8], ['rabbit', 'cooked_rabbit', 7], ['stone_bricks', 'cracked_stone_bricks', 8], ['quartz_block', 'smooth_quartz', 8], ['basalt', 'smooth_basalt', 8], ['sea_pickle', 'lime_dye', 8], ['nether_bricks', 'cracked_nether_bricks', 8]] as const) smelt(a, b, t);
for (const w of WOODS) { smelt(w + '_log', 'charcoal'); for (const s of ['_planks', '_log', '_slab', '_stairs', '_fence', '_door', '_trapdoor', '_pressure_plate', '_button']) if (_res(w + s) && !FUEL[w + s]) FUEL[w + s] = s === '_button' ? 5 : 15; }
Object.assign(FUEL, { coal_block: 800, bookshelf: 15, bowl: 5, bamboo: 2.5, ladder: 15, barrel: 15, loom: 15, lectern: 15, smithing_table: 15, cartography_table: 15, fletching_table: 15, dried_kelp: 10, ...FUEL });
