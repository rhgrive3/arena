import { Terrain } from './terrain';
import { meshChunk, type MeshData } from './mesher';
let terrain:Terrain|undefined,seed='',dimension='';
const transfers=(m:MeshData)=>[m.position.buffer,m.normal.buffer,m.uv.buffer,m.color.buffer,m.tile.buffer,m.wind.buffer,m.light.buffer,m.index.buffer];
self.onmessage=(event:MessageEvent)=>{
  const m=event.data;
  try{
    if(!terrain||seed!==m.seed||dimension!==m.dimension){terrain=new Terrain(m.seed,m.dimension);seed=m.seed;dimension=m.dimension;}
    const generated=terrain.generate(m.cx,m.cz,m.edits,m.structures),solidMesh=meshChunk(generated.padded,generated.maxY,m.tiles,generated.tint);
    const response={type:'chunk',key:m.key,cx:m.cx,cz:m.cz,version:m.version,epoch:m.epoch,data:generated.data.buffer,solid:solidMesh.solid,water:solidMesh.water};
    self.postMessage(response,[generated.data.buffer,...transfers(solidMesh.solid),...transfers(solidMesh.water)] as any);
  }catch(error){self.postMessage({type:'error',key:m.key,epoch:m.epoch,message:String(error)});}
};
