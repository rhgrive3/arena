import { BLOCKS } from '../game/data';
import { blockId, blockState } from '../game/blockState';
import { selectionBoxes, type Bounds } from './shapes';

export interface VoxelHit {
  x: number; y: number; z: number; id: number;
  distance: number; normal: { x: number; y: number; z: number };
}

function intersectRayBox(
  origin: readonly number[], direction: readonly number[],
  x: number, y: number, z: number, box: Bounds, reach: number,
): { distance: number; axis: number; sign: number } | null {
  const block=[x,y,z];
  let near=-Infinity, far=Infinity, axis=-1, sign=0;
  for(let i=0;i<3;i++){
    const lo=block[i]+box[i], hi=block[i]+box[i+3], o=origin[i], d=direction[i];
    if(Math.abs(d)<1e-10){if(o<lo||o>hi)return null;continue;}
    const a=(lo-o)/d,b=(hi-o)/d,entry=Math.min(a,b),exit=Math.max(a,b);
    if(entry>near){near=entry;axis=i;sign=d>0?-1:1;}
    far=Math.min(far,exit);
    if(near>far)return null;
  }
  if(far<0||near>reach)return null;
  return {distance:Math.max(0,near),axis,sign};
}

// Amanatides-Woo voxel traversal visits each crossed cell once instead of
// allocating hundreds of temporary vectors per frame.
export function traceVoxelRay(
  origin: readonly [number,number,number], direction: readonly [number,number,number], reach: number,
  getCell: (x:number,y:number,z:number)=>number,
): VoxelHit | null {
  if(!Number.isFinite(reach)||reach<=0||direction.every(v=>Math.abs(v)<1e-10))return null;
  const cell=[Math.floor(origin[0]),Math.floor(origin[1]),Math.floor(origin[2])];
  const step=direction.map(v=>v>0?1:v<0?-1:0);
  const delta=direction.map(v=>v===0?Infinity:Math.abs(1/v));
  const boundary=direction.map((v,i)=>v===0?Infinity:((step[i]>0?cell[i]+1:cell[i])-origin[i])/v);
  let entered=0;
  for(let visited=0;visited<128 && entered<=reach;visited++){
    const [x,y,z]=cell,block=getCell(x,y,z),id=blockId(block),def=BLOCKS[id];
    if(id>0&&def){
      let best: ReturnType<typeof intersectRayBox>=null;
      for(const box of selectionBoxes(def,blockState(block))){
        const hit=intersectRayBox(origin,direction,x,y,z,box,reach);
        if(hit&&hit.distance+1e-8>=entered&&(!best||hit.distance<best.distance))best=hit;
      }
      if(best){
        const normal={x:0,y:0,z:0};
        if(best.axis===0)normal.x=best.sign;else if(best.axis===1)normal.y=best.sign;else if(best.axis===2)normal.z=best.sign;
        return {x,y,z,id,distance:best.distance,normal};
      }
    }
    const axis=boundary[0]<=boundary[1]&&boundary[0]<=boundary[2]?0:boundary[1]<=boundary[2]?1:2;
    entered=boundary[axis];
    if(!Number.isFinite(entered))break;
    cell[axis]+=step[axis];boundary[axis]+=delta[axis];
  }
  return null;
}