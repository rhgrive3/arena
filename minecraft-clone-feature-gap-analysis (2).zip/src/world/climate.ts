// Overworld shape and biomes (v12) — a compact re-implementation of Minecraft's multi-noise terrain.
//
// Five independent, domain-warped noise fields are turned into *uniformly distributed* parameters in [-1, 1]
// (so thresholds are literally area fractions):
//   continentalness C  open ocean … coast … deep inland        erosion E       mountainous … flat
//   weirdness W → peaks & valleys PV                           temperature T   humidity H
// Height is a monotone spline of C (shelf, beach, lowland) plus hills / mountains driven by E and PV, rivers and lakes
// carved with smooth masks. Biomes come from the same parameters (temperature × humidity table for the "middle"
// biomes, plus coasts, oceans, rivers, mountains and a few special cases), so shapes and biomes always agree.
import type { Noise } from './terrain';

const SIGMA = [0, 0.1431, 0.1603, 0.1637, 0.1649];       // measured std-dev of Noise.fbm for 1…4 octaves
const uni = (z: number) => Math.tanh(0.7978845608 * (z + 0.044715 * z * z * z));   // Gaussian CDF ×2 − 1
const sm = (a: number, b: number, x: number) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const clamp = (x: number, a: number, b: number) => (x < a ? a : x > b ? b : x);

/** Monotone cubic (Fritsch–Carlson) interpolation — smooth, never overshoots between control points. */
function spline(pts: [number, number][]) {
  const n = pts.length, xs = pts.map(p => p[0]), ys = pts.map(p => p[1]), d: number[] = [], m: number[] = new Array(n).fill(0);
  for (let i = 0; i < n - 1; i++) d[i] = (ys[i + 1] - ys[i]) / (xs[i + 1] - xs[i]);
  m[0] = d[0]; m[n - 1] = d[n - 2];
  for (let i = 1; i < n - 1; i++) m[i] = d[i - 1] * d[i] <= 0 ? 0 : (d[i - 1] + d[i]) / 2;
  for (let i = 0; i < n - 1; i++) {
    if (d[i] === 0) { m[i] = m[i + 1] = 0; continue; }
    const a = m[i] / d[i], b = m[i + 1] / d[i], s = a * a + b * b;
    if (s > 9) { const tau = 3 / Math.sqrt(s); m[i] = tau * a * d[i]; m[i + 1] = tau * b * d[i]; }
  }
  return (x: number) => {
    if (x <= xs[0]) return ys[0];
    if (x >= xs[n - 1]) return ys[n - 1];
    let i = 0;
    while (x > xs[i + 1]) i++;
    const h = xs[i + 1] - xs[i], t = (x - xs[i]) / h, t2 = t * t, t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * ys[i] + (t3 - 2 * t2 + t) * h * m[i] + (-2 * t3 + 3 * t2) * ys[i + 1] + (t3 - t2) * h * m[i + 1];
  };
}
/** Height of the land/sea floor (relative to sea level) as a function of continentalness. */
const SHAPE = spline([[-1, -42], [-0.88, -35], [-0.76, -26], [-0.62, -16], [-0.5, -7], [-0.43, -0.6], [-0.37, 2.2], [-0.28, 4.2], [-0.1, 6.5], [0.25, 11], [1, 19]]);

export interface Column {
  /** Final surface height (top solid block). */
  h: number;
  c: number; e: number; pv: number; t: number; hu: number;
  /** Temperature after the altitude lapse (high land is colder). */
  te: number;
  river: number; lake: number; swamp: number; island: number; mtn: number;
  /** Independent variation noises in [-1, 1] used for biome variants. */
  bad: number; cherry: number; weird: number;
}

export class OverworldClimate {
  private keyX = new Int32Array(8192).fill(0x7fffffff);
  private keyZ = new Int32Array(8192);
  private vals: (Column | undefined)[] = new Array(8192);
  /** Noise-space shift chosen per seed so the world origin (starter village) lies on a natural temperate plain. */
  private ox = 0; private oz = 0; private ready = false;
  constructor(private n: Noise, readonly sea: number, private seed = 0) {}

  private init() {
    this.ready = true;
    const PLAINISH = new Set(['plains', 'forest', 'birch_forest', 'flower_forest', 'meadow']);
    const pts: [number, number][] = [[5, 10]];
    for (const r of [45, 90]) for (let k = 0; k < 8; k++) pts.push([5 + Math.cos((k * Math.PI) / 4) * r, 10 + Math.sin((k * Math.PI) / 4) * r]);
    const hash = (i: number, s: number) => { let h = Math.imul(i, 374761393) ^ Math.imul(s, 668265263) ^ this.seed; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
    let best = -1, bx = 0, bz = 0;
    for (let i = 0; i < 6000; i++) {
      this.ox = i === 0 ? 0 : (hash(i, 1) * 2 - 1) * 60000; this.oz = i === 0 ? 0 : (hash(i, 2) * 2 - 1) * 60000;
      let score = 0, lo = 999, hi = -999;
      for (const [x, z] of pts) {
        const s = this.compute(x, z);
        if (!PLAINISH.has(this.biome(s)) || s.river > 0.01 || s.lake > 0.01) { if (score === 0 && x === 5) break; continue; }
        score++; lo = Math.min(lo, s.h); hi = Math.max(hi, s.h);
      }
      const ok = score === pts.length && hi - lo <= 9 && lo >= this.sea + 3;
      if (score > best - (ok ? 0 : 0) && (ok || score > best)) { best = ok ? 99 : score; bx = this.ox; bz = this.oz; }
      if (ok) break;
    }
    this.ox = bx; this.oz = bz;
    this.keyX.fill(0x7fffffff);
  }

  private U(x: number, z: number, scale: number, oct: number, ox: number, oz: number) { return uni(this.n.fbm(x / scale + ox, z / scale + oz, oct) / SIGMA[oct]); }
  /** Symmetric noise, roughly within ±1 (≈ ±2.2σ). */
  private G(x: number, z: number, scale: number, oct: number, ox: number, oz: number) { return clamp(this.n.fbm(x / scale + ox, z / scale + oz, oct) / SIGMA[oct] / 2.2, -1, 1); }

  column(x: number, z: number): Column {
    if (!this.ready) this.init();
    x = Math.floor(x); z = Math.floor(z);
    const slot = ((Math.imul(x, 73856093) ^ Math.imul(z, 19349663)) >>> 0) & 8191;
    if (this.keyX[slot] === x && this.keyZ[slot] === z) return this.vals[slot]!;
    const col = this.compute(x, z);
    this.keyX[slot] = x; this.keyZ[slot] = z; this.vals[slot] = col;
    return col;
  }

  private compute(x: number, z: number): Column {
    const n = this.n, sea = this.sea, rx = x, rz = z;
    x += this.ox; z += this.oz;
    // Domain warp: bends all continental-scale fields so coastlines and borders are never straight or blobby.
    const wx = x + n.n2(x / 260 + 11, z / 260 - 7) * 80, wz = z + n.n2(x / 260 - 31, z / 260 + 17) * 80;
    let c = this.U(wx, wz, 1400, 4, 31, 31), e = this.U(wx, wz, 950, 3, 77, -40), w = this.U(wx, wz, 700, 3, -60, 25);
    let t = this.U(wx, wz, 1050, 3, 210, 210), hu = this.U(wx, wz, 820, 3, -190, -190);

    // Hills and roughness fade out around the starter village so its hand-built houses sit on near-level ground.
    const ds = Math.hypot(rx - 5, rz - 10), flat = 1 - 0.8 * (1 - sm(30, 110, ds));

    const pvRaw = 1 - Math.abs(3 * Math.abs(w) - 2), pv01 = sm(-0.35, 0.9, pvRaw);
    const inland = sm(-0.45, -0.2, c);
    const mtn = sm(-0.12, -0.62, e) * inland;

    // ---- height ---------------------------------------------------------------------------------------------------
    let d = SHAPE(c);
    d += this.G(wx, wz, 120, 3, 5, 5) * ((3 + 13 * sm(0.5, -0.4, e)) * inland + 1.2 * (1 - inland)) * flat;          // rolling hills
    d += this.G(x, z, 26, 2, 90, 90) * (0.9 + 2.4 * mtn) * flat;                                                     // surface roughness
    d += mtn * (10 + 88 * Math.pow(pv01, 1.5)) * (0.88 + 0.24 * this.G(wx, wz, 240, 2, 3, 9));                // mountains & peaks
    if (d > 100) d = 100 + (d - 100) * 0.55;                                                                  // soft ceiling (≈ y 175)

    // mushroom islands: rare blobs that rise out of deep ocean
    const island = sm(0.9, 0.99, this.U(x, z, 330, 2, 400, -400)) * sm(-0.6, -0.8, c);
    if (island > 0) { const target = -16 + 27 * Math.pow(island, 0.7); if (target > d) d += (target - d) * sm(0, 0.3, island); }

    // swamps: low, flat, waterlogged ground near sea level
    const swamp = sm(0.42, 0.56, hu) * sm(-0.55, -0.4, t) * (1 - sm(0.5, 0.65, t)) * sm(0.1, 0.35, e) * sm(-0.42, -0.3, c) * (1 - sm(-0.1, 0.1, c)) * (1 - island);
    if (swamp > 0) d += (0.4 + 1.4 * this.G(x, z, 40, 2, 20, 20) - d) * swamp;

    // rivers: zero-crossings of a meandering noise, fading out at the coast, on high ground and near spawn
    // distance (in blocks) to the nearest zero-crossing = |value| / |gradient|, so river width does not depend on how flat the noise is
    const rv = n.fbm(wx / 640 + 5, wz / 640 - 5, 3) / SIGMA[3], rgx = n.fbm((wx + 6) / 640 + 5, wz / 640 - 5, 3) / SIGMA[3] - rv, rgz = n.fbm(wx / 640 + 5, (wz + 6) / 640 - 5, 3) / SIGMA[3] - rv;
    const rdist = Math.abs(rv) / Math.max(0.004, Math.hypot(rgx, rgz) / 6);
    let river = 1 - sm(4, 26, rdist);
    river *= sm(-0.5, -0.32, c) * sm(40, 110, ds) * (1 - sm(10, 17, d));
    river = sm(0.12, 0.9, river);
    if (river > 0.001) { const bed = -3.2 - 1.2 * Math.abs(this.G(x, z, 60, 1, 8, 8)); if (d > bed) d += (bed - d) * river; }

    // lakes: shallow pools in low, flat, non-desert ground
    let lake = sm(0.35, 0.8, sm(0.6, 0.92, this.G(x, z, 110, 3, 200, 300)) * sm(6, 2.5, d) * sm(-0.3, -0.15, c)) * sm(40, 110, ds) * (1 - sm(0.2, 0.5, mtn)) * (1 - sm(0.55, 0.75, t)) * (1 - swamp);
    if (lake > 0.001 && d > -2.8) d += (-2.8 - d) * lake; else lake = 0;

    const h = Math.floor(sea + d + 0.5);
    const te = t - Math.max(0, h - sea - 37) * 0.009;
    return { h, c, e, pv: pvRaw, t, hu, te, river, lake, swamp, island, mtn, bad: this.U(x, z, 520, 2, 600, 100), cherry: this.U(x, z, 430, 2, -300, 700), weird: w };
  }

  /** Biome of a column (same ids as BIOME_LABELS). */
  biome(s: Column): string {
    const sea = this.sea, up = s.h - sea, te = s.te;
    if (s.island > 0.35 && s.h >= sea - 2) return 'mushroom_fields';
    if (s.h < sea - 1) {
      if (s.river > 0.25 && s.c > -0.46) return te < -0.6 ? 'frozen_river' : 'river';
      if (!(s.lake > 0.2 && s.c > -0.4)) {
        if (s.swamp > 0.5) return 'swamp';
        if (te < -0.6) return 'frozen_ocean';
        return s.h < sea - 25 ? 'deep_ocean' : 'ocean';
      }
    }
    if (s.c < -0.3 && s.h <= sea + 4 && s.h >= sea - 1) return s.e < -0.45 ? 'stony_shore' : te < -0.6 ? 'snowy_beach' : 'beach';
    if (s.mtn > 0.28 && up >= 20) {
      if (up >= 88) return te < -0.2 ? 'frozen_peaks' : 'stony_peaks';
      if (up >= 52) return te < -0.15 ? 'snowy_slopes' : 'windswept_hills';
      if (te < -0.5) return 'grove';
      if (up >= 30 && s.e < -0.45) return 'windswept_hills';
    }
    if (s.mtn > 0.1 && up >= 16 && up < 60) {
      if (te < -0.5) return up >= 24 ? 'grove' : 'snowy_plains';
      if (te < 0.5) return s.cherry > 0.55 ? 'cherry_grove' : 'meadow';
    }
    if (s.swamp > 0.5) return 'swamp';
    const T = te < -0.6 ? 0 : te < -0.2 ? 1 : te < 0.2 ? 2 : te < 0.6 ? 3 : 4;
    const H = s.hu < -0.6 ? 0 : s.hu < -0.2 ? 1 : s.hu < 0.2 ? 2 : s.hu < 0.6 ? 3 : 4;
    switch (T) {
      case 0: return ['snowy_plains', 'snowy_plains', 'snowy_plains', 'snowy_taiga', 'taiga'][H];
      case 1: return ['plains', 'plains', 'forest', 'taiga', 'taiga'][H];
      case 2: return H === 0 ? (s.weird > 0.35 ? 'flower_forest' : 'plains') : ['', 'plains', 'forest', 'birch_forest', 'dark_forest'][H];
      case 3: return ['savanna', 'savanna', 'forest', 'jungle', 'jungle'][H];
      default: return s.bad > 0.3 && s.hu < 0.4 ? 'badlands' : 'desert';
    }
  }
}
