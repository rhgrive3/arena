// Renders biome + shaded height maps of the overworld to /tmp/tt/<name>_{biome,height}.png and prints terrain statistics.
// Usage: npx esbuild scripts/terrain-map.ts --bundle --platform=node --format=esm --outfile=/tmp/map.mjs && node /tmp/map.mjs <seed> <cx> <cz> <span> <name>
import '../src/game/content';
import { Terrain, SEA } from '../src/world/terrain';
import { writePNG } from './png';
const COL: Record<string, string> = { ocean: '2f5fc4', deep_ocean: '1b3a8a', frozen_ocean: '9fb7e8', river: '4a86e8', frozen_river: 'bcd2f5', beach: 'ead9a0', snowy_beach: 'f0ecd8', stony_shore: '8d8d86', plains: '8fc45a', forest: '3f8a2e', birch_forest: '7fb85a', flower_forest: 'd68ad0', dark_forest: '1f4a1c', meadow: 'b6df7a', cherry_grove: 'f4a8c8', taiga: '2f6a52', snowy_taiga: '6f9f90', snowy_plains: 'f2f6f8', grove: 'c8e0d8', snowy_slopes: 'ffffff', frozen_peaks: 'dfeaf5', stony_peaks: 'a0a09a', windswept_hills: '7c8a74', desert: 'e6d27a', badlands: 'c8642e', savanna: 'bdb23c', jungle: '1f8f1f', swamp: '5a6a3a', mushroom_fields: 'a060a0' };
const rgb = (h: string) => [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
const [seed = '849281', cx = '0', cz = '0', span = '4096', name = 'a'] = process.argv.slice(2);
const t = new Terrain(seed), N = 768, step = Number(span) / N, X0 = Number(cx) - Number(span) / 2, Z0 = Number(cz) - Number(span) / 2;
const bio = new Uint8Array(N * N * 3), hgt = new Uint8Array(N * N * 3), cnt: Record<string, number> = {};
let steep3 = 0, steep6 = 0, steep10 = 0, tot = 0, maxd = 0, land = 0, deep = 0, ocean = 0, maxh = 0;
for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
  const x = Math.floor(X0 + i * step), z = Math.floor(Z0 + j * step), s = t.ow.column(x, z), b = t.ow.biome(s), h = s.h;
  cnt[b] = (cnt[b] ?? 0) + 1; maxh = Math.max(maxh, h);
  const c = rgb(COL[b] ?? 'ff00ff'), l = j > 0 ? (h - t.height(x, z - 3)) : 0, sh = 1 + Math.max(-0.35, Math.min(0.35, l * 0.05));
  bio.set(c.map(v => Math.min(255, v * sh)), (j * N + i) * 3);
  const g = h < SEA ? [30, 60 + Math.max(0, 100 - (SEA - h) * 3), 200 - Math.min(120, (SEA - h) * 3)] : (() => { const k = (h - SEA) / 120; return [Math.min(255, 60 + k * 400 * sh), Math.min(255, 140 + k * 200 * sh - k * k * 100), Math.min(255, 50 + k * 300)]; })();
  hgt.set(g.map(v => Math.max(0, Math.min(255, v * (h < SEA ? 1 : sh)))), (j * N + i) * 3);
  if (h < SEA) { ocean++; if (h < SEA - 25) deep++; } else land++;
  const d = Math.max(Math.abs(t.height(x + 1, z) - h), Math.abs(t.height(x, z + 1) - h)); tot++; if (d >= 3) steep3++; if (d >= 6) steep6++; if (d >= 10) steep10++; maxd = Math.max(maxd, d);
}
writePNG(`/tmp/tt/${name}_biome.png`, N, N, bio); writePNG(`/tmp/tt/${name}_height.png`, N, N, hgt);
console.log(`seed ${seed} span ${span}: water ${(ocean / tot * 100).toFixed(1)}% deepOcean ${(deep / tot * 100).toFixed(1)}% maxH ${maxh} | neighbour step >=3: ${(steep3 / tot * 100).toFixed(2)}%  >=6: ${(steep6 / tot * 100).toFixed(3)}%  >=10: ${(steep10 / tot * 100).toFixed(3)}%  max ${maxd}`);
console.log(Object.entries(cnt).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${(v / tot * 100).toFixed(1)}`).join(' · '));
