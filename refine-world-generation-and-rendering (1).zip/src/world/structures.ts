// Extra structures (v11): mineshaft, shipwreck, ocean monument, woodland mansion, pillager outpost, ancient city, bastion remnant.
// Every structure is a pure function of the world seed and is written chunk-by-chunk through `put` (which clips to the chunk).
import { ID } from '../game/data';
import type { Terrain } from './terrain';

export type Put = (x: number, y: number, z: number, id: number, replace?: boolean) => void;
export type ExtraKind = 'mineshaft' | 'shipwreck' | 'monument' | 'mansion' | 'outpost' | 'ancient_city' | 'bastion';
export interface Placed { kind: ExtraKind; x: number; y: number; z: number; }
interface Spec { kind: ExtraKind; region: number; chance: number; salt: number; radius: number; dim: 'overworld' | 'nether'; }

const SEA = 63;
const B = ID as Record<string, number | undefined>;
const id = (name: string, fallback = 'stone'): number => B[name] ?? B[fallback] ?? 1;
const hash = (x: number, z: number, seed: number) => {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
const hash3 = (x: number, y: number, z: number, seed: number) => hash(x + y * 131, z - y * 71, seed);
const fill = (put: Put, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, block: number, replace = true) => {
  for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) put(x, y, z, block, replace);
};

const SPECS: Spec[] = [
  { kind: 'mineshaft', region: 96, chance: 0.6, salt: 7001, radius: 30, dim: 'overworld' },
  { kind: 'shipwreck', region: 112, chance: 0.7, salt: 7002, radius: 12, dim: 'overworld' },
  { kind: 'monument', region: 224, chance: 0.8, salt: 7003, radius: 21, dim: 'overworld' },
  { kind: 'mansion', region: 288, chance: 0.7, salt: 7004, radius: 17, dim: 'overworld' },
  { kind: 'outpost', region: 208, chance: 0.7, salt: 7005, radius: 10, dim: 'overworld' },
  { kind: 'ancient_city', region: 240, chance: 0.7, salt: 7006, radius: 35, dim: 'overworld' },
  { kind: 'bastion', region: 176, chance: 0.7, salt: 7007, radius: 14, dim: 'nether' },
];
const ALIASES: Record<string, ExtraKind> = { mineshaft: 'mineshaft', shipwreck: 'shipwreck', monument: 'monument', ocean_monument: 'monument', mansion: 'mansion', woodland_mansion: 'mansion', outpost: 'outpost', pillager_outpost: 'outpost', ancient_city: 'ancient_city', ancientcity: 'ancient_city', bastion: 'bastion', bastion_remnant: 'bastion' };
export const EXTRA_KINDS = Object.keys(ALIASES);

function validate(t: Terrain, kind: ExtraKind, x: number, z: number): Placed | null {
  const h = t.height(x, z), nearSpawn = Math.hypot(x + 11, z - 27);
  const spread = (r: number) => Math.max(...[[r, 0], [-r, 0], [0, r], [0, -r], [r, r], [-r, -r]].map(([dx, dz]) => Math.abs(t.height(x + dx, z + dz) - h)));
  switch (kind) {
    case 'mineshaft': return h > SEA + 3 ? { kind, x, z, y: Math.max(-30, Math.min(38, h - 26 - Math.floor(hash(x, z, t.seed + 71) * 24))) } : null;
    case 'shipwreck': return h < SEA - 5 && h > SEA - 34 ? { kind, x, z, y: h + 1 } : null;
    case 'monument': {
      if (h > SEA - 12) return null;
      for (const [dx, dz] of [[14, 14], [-14, 14], [14, -14], [-14, -14]]) if (t.height(x + dx, z + dz) > SEA - 7) return null;
      return { kind, x, z, y: h + 1 };
    }
    case 'mansion': {
      if (h < SEA + 3 || h > 115 || nearSpawn < 140 || spread(13) > 8) return null;
      if (!['dark_forest', 'old_growth_birch_forest', 'forest'].includes(t.biomeAt(x, z, h))) return null;
      return { kind, x, z, y: h + 1 };
    }
    case 'outpost': {
      if (h < SEA + 2 || h > 165 || nearSpawn < 150 || spread(6) > 6) return null;
      if (!['plains', 'sunflower_plains', 'savanna', 'savanna_plateau', 'desert', 'taiga', 'snowy_taiga', 'meadow', 'snowy_plains', 'cherry_grove', 'grove', 'snowy_slopes', 'jagged_peaks', 'frozen_peaks', 'stony_peaks', 'badlands'].includes(t.biomeAt(x, z, h))) return null;
      return { kind, x, z, y: h + 1 };
    }
    case 'ancient_city': return h > SEA + 6 && nearSpawn > 120 ? { kind, x, z, y: -51 } : null;
    case 'bastion': return h >= 20 && h <= 40 && Math.hypot(x, z) > 90 ? { kind, x, z, y: h + 1 } : null;
  }
}
const cache = new WeakMap<Terrain, Map<string, Placed | null>>();
function site(t: Terrain, s: Spec, rx: number, rz: number): Placed | null {
  if (t.dimension !== s.dim) return null;
  let m = cache.get(t);
  if (!m) { m = new Map(); cache.set(t, m); }
  const key = s.kind + ':' + rx + ',' + rz, hit = m.get(key);
  if (hit !== undefined) return hit;
  let out: Placed | null = null;
  if (hash(rx, rz, t.seed + s.salt) < s.chance) {
    const margin = s.radius + 6, span = s.region - margin * 2;
    if (s.kind === 'monument') {
      // Deep water is rare, so scan the region on a coarse grid and try the deepest spot instead of rolling random positions.
      let bx = 0, bz = 0, bh = Infinity;
      for (let gz = margin; gz <= s.region - margin; gz += 16) for (let gx = margin; gx <= s.region - margin; gx += 16) {
        const x = rx * s.region + gx, z = rz * s.region + gz, h = t.height(x, z);
        if (h < bh) { bh = h; bx = x; bz = z; }
      }
      if (bh < Infinity) out = validate(t, s.kind, bx, bz);
    } else for (let attempt = 0; attempt < (s.kind === 'mansion' ? 32 : 16) && !out; attempt++) {
      const x = rx * s.region + margin + Math.floor(hash(rx, rz, t.seed + s.salt + 1 + attempt * 2) * span);
      const z = rz * s.region + margin + Math.floor(hash(rx, rz, t.seed + s.salt + 2 + attempt * 2) * span);
      out = validate(t, s.kind, x, z);
    }
  }
  m.set(key, out);
  return out;
}

function mineshaft(t: Terrain, put: Put, p: Placed) {
  const planks = id('oak_planks'), fence = id('oak_fence', 'oak_planks'), rail = id('rail', 'air'), web = id('cobweb', 'air'), chest = id('chest'), s = t.seed + 7100, y = p.y;
  const corridor = (x0: number, z0: number, dx: number, dz: number, len: number) => {
    for (let i = 0; i <= len; i++) {
      const cx = x0 + dx * i, cz = z0 + dz * i, support = i % 4 === 2;
      for (let w = -1; w <= 1; w++) {
        const x = cx + (dz ? w : 0), z = cz + (dx ? w : 0);
        put(x, y - 1, z, planks, false);
        for (let dy = 0; dy <= 2; dy++) put(x, y + dy, z, 0, true);
        if (support) { if (w !== 0) { put(x, y, z, fence, true); put(x, y + 1, z, fence, true); } put(x, y + 2, z, planks, true); }
        else if (w !== 0 && hash3(x, y, z, s) < 0.05) put(x, y + 2, z, web, true);
        else if (w !== 0 && hash3(x, y, z, s + 1) < 0.014) put(x, y, z, chest, true);
      }
      if (hash(cx, cz, s + 2) < 0.6) put(cx, y, cz, rail, true);
    }
  };
  fill(put, p.x - 4, y, p.z - 4, p.x + 4, y + 4, p.z + 4, 0);
  fill(put, p.x - 4, y - 1, p.z - 4, p.x + 4, y - 1, p.z + 4, planks, false);
  corridor(p.x - 28, p.z, 1, 0, 56);
  for (let k = 0; k < 5; k++) {
    const bx = p.x - 24 + k * 12, len = 8 + Math.floor(hash(bx, p.z, s + 5) * 20);
    if (hash(bx, p.z, s + 6) < 0.85) corridor(bx, p.z, 0, 1, len);
    if (hash(bx, p.z, s + 7) < 0.85) corridor(bx, p.z, 0, -1, Math.min(28, len + 4));
  }
  corridor(p.x - 14, p.z + 14, 1, 0, 28);
  put(p.x + 3, y, p.z + 3, chest, true);
}

function shipwreck(t: Terrain, put: Put, p: Placed) {
  const planks = id('spruce_planks', 'oak_planks'), log = id('spruce_log', 'oak_log'), dark = id('dark_oak_planks', 'oak_planks'), chest = id('chest'), s = t.seed + 7200, y = p.y;
  for (let i = -8; i <= 8; i++) {
    const half = Math.abs(i) >= 7 ? 0 : Math.abs(i) >= 5 ? 1 : 2;
    for (let w = -half; w <= half; w++) {
      const x = p.x + i, z = p.z + w, edge = Math.abs(w) === half;
      put(x, y, z, dark, true);
      if (edge || Math.abs(i) >= 7) { put(x, y + 1, z, planks, true); if (hash3(x, y, z, s) < 0.8) put(x, y + 2, z, planks, true); }
      if (half > 0 && hash(x, z, s + 1) < 0.55) put(x, y + 3, z, planks, true);
    }
  }
  for (let dy = 1; dy <= 9; dy++) put(p.x, y + dy, p.z, log, true);
  for (let w = -2; w <= 2; w++) put(p.x, y + 8, p.z + w, log, true);
  fill(put, p.x - 6, y + 3, p.z - 1, p.x - 4, y + 5, p.z + 1, planks);
  put(p.x - 5, y + 1, p.z, chest, true);
  put(p.x + 4, y + 1, p.z, chest, true);
}

function monument(t: Terrain, put: Put, p: Placed) {
  const pb = id('prismarine_bricks', 'prismarine'), pr = id('prismarine'), dp = id('dark_prismarine', 'prismarine'), lan = id('sea_lantern', 'glowstone'), water = id('water'), gold = id('gold_block'), sponge = id('wet_sponge', 'sponge'), s = t.seed + 7300;
  const tiers = Math.max(3, Math.min(5, Math.floor((SEA - 2 - p.y) / 3)));      // shallower seas get a lower roof so it stays submerged
  for (let k = 0; k < tiers; k++) {
    const half = 20 - k * 4, y0 = p.y + k * 3;
    for (let z = -half; z <= half; z++) for (let x = -half; x <= half; x++) {
      const edge = Math.abs(x) === half || Math.abs(z) === half, wx = p.x + x, wz = p.z + z, mat = hash(wx, wz, s + k) < 0.3 ? pr : pb;
      put(wx, y0, wz, mat, true);
      for (let dy = 1; dy <= 2; dy++) put(wx, y0 + dy, wz, edge ? (dy === 1 && ((x + z) & 3) === 0 ? lan : mat) : water, true);
      put(wx, y0 + 3, wz, edge ? dp : mat, true);
    }
    if (k > 0) { const hx = p.x + (k < 4 ? 6 : 2); fill(put, hx, y0, p.z - 1, hx + 1, y0, p.z + 1, water); }
  }
  fill(put, p.x - 1, p.y + 1, p.z - 20, p.x + 1, p.y + 2, p.z - 20, water);               // entrance
  for (let dz = -2; dz <= 1; dz++) for (let dx = -2; dx <= 1; dx++) for (let dy = 1; dy <= 2; dy++)   // treasure core
    put(p.x + dx, p.y + dy, p.z + dz, dx >= -1 && dx <= 0 && dz >= -1 && dz <= 0 ? gold : dp, true);
  for (let dz = 0; dz < 3; dz++) for (let dx = 0; dx < 3; dx++) if (hash(dx, dz, s + 9) < 0.75) put(p.x + 9 + dx, p.y + 4, p.z + 9 + dz, sponge, true);
  put(p.x - 6, p.y + 7, p.z - 6, id('chest'), true);
  for (const [cx, cz] of [[20, 20], [-20, 20], [20, -20], [-20, -20]]) { for (let dy = 4; dy <= 8; dy++) put(p.x + cx, p.y + dy, p.z + cz, pb, true); put(p.x + cx, p.y + 9, p.z + cz, lan, true); }
}

function mansion(t: Terrain, put: Put, p: Placed) {
  const cob = id('cobblestone'), plank = id('dark_oak_planks', 'oak_planks'), log = id('dark_oak_log', 'oak_log'), birch = id('birch_planks', 'oak_planks'), pane = id('glass_pane', 'glass'), carpet = id('red_carpet', 'air'), wool = id('white_wool'), shelf = id('bookshelf'), chest = id('chest'), lantern = id('lantern', 'torch'), torch = id('torch'), ladder = id('ladder'), s = t.seed + 7400;
  const X0 = p.x - 15, X1 = p.x + 15, Z0 = p.z - 10, Z1 = p.z + 10, y = p.y;
  for (let z = Z0; z <= Z1; z++) for (let x = X0; x <= X1; x++) {
    for (let dy = 2; dy <= 8; dy++) put(x, y - dy, z, cob, true);
    const edgeX = x === X0 || x === X1, edgeZ = z === Z0 || z === Z1, dzc = z - p.z, dxc = x - X0, side = dzc > 0 ? 1 : -1;
    const room = Math.floor(dxc / 8), cx = X0 + room * 8 + 4, cz = p.z + side * 6;
    for (let k = 0; k < 3; k++) {
      const fy = y - 1 + k * 5, kind = Math.floor(hash(room * 2 + side, k, s) * 5);
      put(x, fy, z, k === 0 ? cob : plank, true);
      for (let dy = 1; dy <= 4; dy++) {
        let b = 0;
        if (edgeX || edgeZ) {
          const along = edgeX ? z - Z0 : dxc;
          b = (edgeX && edgeZ) || along % 5 === 0 ? log : (dy === 2 || dy === 3) && along % 5 !== 1 && along % 5 !== 4 ? pane : plank;
        } else {
          const corridorWall = Math.abs(dzc) === 2, cross = Math.abs(dzc) > 2 && dxc % 8 === 0, door = corridorWall && dxc % 8 === 4 && dy <= 2;
          if ((corridorWall || cross) && !door) b = birch;
          else if (kind === 0 && z === (side > 0 ? Z1 - 1 : Z0 + 1) && dxc % 8 >= 2 && dxc % 8 <= 6 && dy <= 3) b = shelf;
          else if (dy === 1) {
            if (Math.abs(dzc) <= 1) b = dzc === 0 && dxc % 8 === 0 ? lantern : carpet;
            else if (x === cx && z === cz) b = kind === 1 || kind === 4 ? chest : kind === 2 ? wool : 0;
            else if (x === cx + 1 && z === cz && kind === 2) b = wool;
            else if (x === cx + 2 && z === cz + side * 2) b = torch;
            else if (kind === 4 && x === cx - 2 && z === cz) b = id('lapis_block', 'gold_block');
          }
        }
        put(x, fy + dy, z, b, true);
      }
    }
    put(x, y + 14, z, plank, true);
  }
  for (let r = 0; r <= 11; r++) fill(put, X0 - 1, y + 15 + r, Z0 - 1 + r, X1 + 1, y + 15 + r, Z1 + 1 - r, r === 11 ? log : plank);   // pitched roof
  for (let dy = 0; dy <= 2; dy++) { put(p.x + 1, y + dy, Z0, 0, true); put(p.x + 2, y + dy, Z0, 0, true); }                       // front door
  for (let dy = 0; dy <= 10; dy++) put(X1 - 1, y + dy, p.z + 1, ladder, true);                                                   // ladder through all floors
}

function outpost(t: Terrain, put: Put, p: Placed) {
  const log = id('dark_oak_log', 'oak_log'), plank = id('dark_oak_planks', 'oak_planks'), cob = id('cobblestone'), birch = id('birch_planks', 'oak_planks'), fence = id('dark_oak_fence', 'oak_fence'), y = p.y;
  for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
    const edge = Math.abs(dx) === 3 || Math.abs(dz) === 3, corner = Math.abs(dx) === 3 && Math.abs(dz) === 3, x = p.x + dx, z = p.z + dz;
    for (let dy = 1; dy <= 6; dy++) put(x, y - dy, z, cob, true);
    for (let dy = 0; dy <= 14; dy++) {
      let b = 0;
      if (corner) b = log;
      else if (edge) b = dy < 5 ? cob : dy % 5 === 2 && (dx === 0 || dz === 0) ? 0 : birch;
      else if (dy % 5 === 4) b = plank;
      put(x, y + dy, z, b, true);
    }
  }
  put(p.x, y, p.z - 3, 0, true); put(p.x, y + 1, p.z - 3, 0, true);
  for (let dy = 0; dy <= 15; dy++) put(p.x, y + dy, p.z + 2, id('ladder'), true);
  for (let dz = -4; dz <= 4; dz++) for (let dx = -4; dx <= 4; dx++) {
    const rim = Math.abs(dx) === 4 || Math.abs(dz) === 4, corner = Math.abs(dx) === 4 && Math.abs(dz) === 4, x = p.x + dx, z = p.z + dz;
    if (!(dx === 0 && dz === 2)) put(x, y + 15, z, plank, true);
    for (let dy = 16; dy <= 18; dy++) put(x, y + dy, z, corner ? log : rim && dy === 16 ? fence : 0, true);
    put(x, y + 19, z, plank, true);
    if (Math.abs(dx) <= 2 && Math.abs(dz) <= 2) put(x, y + 20, z, plank, true);
  }
  put(p.x - 2, y + 16, p.z - 2, id('chest'), true);
  put(p.x + 2, y + 16, p.z - 2, id('torch'), true);
  put(p.x, y + 17, p.z - 5, id('white_banner', 'white_wool'), true);
  const gy = (x: number, z: number) => t.height(x, z) + 1;
  { const cx = p.x + 7, cz = p.z + 5, g = gy(cx, cz); for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) { const rim = dx !== 0 || dz !== 0; for (let dy = 0; dy <= 2; dy++) if (rim) put(cx + dx, g + dy, cz + dz, fence, true); put(cx + dx, g + 3, cz + dz, plank, true); } }
  { const cx = p.x - 7, cz = p.z + 4, g = gy(cx, cz); for (let dx = 0; dx <= 2; dx++) { put(cx + dx, g, cz, log, true); put(cx + dx, g, cz + 1, log, true); if (dx < 2) put(cx + dx, g + 1, cz, log, true); } }
  { const cx = p.x - 6, cz = p.z - 6, g = gy(cx, cz); put(cx, g, cz, fence, true); put(cx, g + 1, cz, id('target', 'hay_block'), true); }
}

function ancientCity(t: Terrain, put: Put, p: Placed) {
  const tiles = id('deepslate_tiles', 'deepslate'), bricks = id('deepslate_bricks', 'deepslate'), cobbled = id('cobbled_deepslate', 'deepslate'), polished = id('polished_deepslate', 'deepslate'), reinforced = id('reinforced_deepslate', 'obsidian');
  const sculk = id('sculk_block', 'deepslate'), sensor = id('sculk_sensor', 'air'), shrieker = id('sculk_shrieker', 'air'), catalyst = id('sculk_catalyst', 'deepslate'), lantern = id('soul_lantern', 'lantern'), fence = id('dark_oak_fence', 'oak_fence'), wool = id('gray_wool', 'white_wool'), chest = id('chest'), ice = id('packed_ice', 'ice'), deep = id('deepslate');
  const s = t.seed + 7600, y = p.y, RX = 34, RZ = 26;
  for (let dz = -RZ; dz <= RZ; dz++) for (let dx = -RX; dx <= RX; dx++) {
    const d = (dx * dx) / (RX * RX) + (dz * dz) / (RZ * RZ);
    if (d > 1) continue;
    const x = p.x + dx, z = p.z + dz, top = Math.max(3, Math.round(15 * Math.sqrt(1 - d))), r = hash(x, z, s);
    put(x, y - 2, z, deep, true);
    for (let dy = 0; dy < top; dy++) put(x, y + dy, z, 0, true);
    put(x, y + top, z, r < 0.5 ? sculk : deep, true);
    const onX = Math.abs(dz) <= 2, onZ = Math.abs(dx) <= 2;
    if (onX || onZ) put(x, y - 1, z, (onX && Math.abs(dz) === 2) || (onZ && Math.abs(dx) === 2) ? polished : r < 0.3 ? wool : bricks, true);
    else {
      put(x, y - 1, z, r < 0.45 ? sculk : r < 0.75 ? tiles : cobbled, true);
      if (r < 0.012) put(x, y, z, sensor, true);
      else if (r < 0.018) put(x, y, z, shrieker, true);
      else if (r < 0.026) put(x, y - 1, z, catalyst, true);
    }
    if ((onX && Math.abs(dz) === 3 && ((dx % 8) + 8) % 8 === 4) || (onZ && Math.abs(dx) === 3 && ((dz % 8) + 8) % 8 === 4)) { put(x, y, z, fence, true); put(x, y + 1, z, fence, true); put(x, y + 2, z, lantern, true); }
  }
  for (let dx = -10; dx <= 10; dx++) for (let dy = 0; dy <= 8; dy++) {                       // the great reinforced-deepslate frame
    if (Math.abs(dx) >= 9 || dy === 0 || dy >= 7) put(p.x + dx, y + dy, p.z - 9, reinforced, true);
    if (hash(dx, dy, s + 3) < 0.7) put(p.x + dx, y + dy, p.z - 10, bricks, true);
  }
  for (const [px, pz] of [[-24, -8], [24, -8], [-24, 8], [24, 8], [-10, 18], [10, 18], [-10, -20], [10, -20]])
    for (let dy = 0; dy <= 12; dy++) for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) put(p.x + px + dx, y + dy, p.z + pz + dz, dy % 4 === 3 ? polished : bricks, true);
  [[-16, -14], [16, -14], [-16, 13], [16, 13]].forEach(([hx, hz], n) => {
    const cx = p.x + hx, cz = p.z + hz;
    for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
      const edge = Math.abs(dx) === 3 || Math.abs(dz) === 3;
      put(cx + dx, y - 1, cz + dz, tiles, true);
      for (let dy = 0; dy <= 4; dy++) {
        const gap = hash3(cx + dx, y + dy, cz + dz, s + 5) < 0.22 + dy * 0.08 || (dx === 0 && dz === (hz > 0 ? -3 : 3) && dy <= 1);
        put(cx + dx, y + dy, cz + dz, edge && !gap ? (dy === 0 ? cobbled : bricks) : 0, true);
      }
    }
    if (n === 0) { fill(put, cx - 1, y, cz - 1, cx + 1, y + 2, cz + 1, ice); put(cx, y + 1, cz, chest, true); put(cx, y + 2, cz, 0, true); }
    else put(cx - 1, y, cz, chest, true);
    put(cx + 2, y, cz + 2, fence, true); put(cx + 2, y + 1, cz + 2, lantern, true);
  });
}

function bastion(t: Terrain, put: Put, p: Placed) {
  const bs = id('blackstone'), pbb = id('polished_blackstone_bricks', 'blackstone'), gilded = id('gilded_blackstone', 'blackstone'), gold = id('gold_block'), basalt = id('basalt', 'blackstone'), lava = id('lava'), chest = id('chest'), chain = id('chain', 'air'), lantern = id('lantern', 'glowstone'), magma = id('magma_block', 'netherrack');
  const s = t.seed + 7700, y = p.y, H = 12, R = 12;
  for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++) {
    const x = p.x + dx, z = p.z + dz, ax = Math.abs(dx), az = Math.abs(dz), ring = Math.max(ax, az);
    for (let dy = 2; dy <= 7; dy++) put(x, y - dy, z, bs, true);
    put(x, y - 1, z, ring >= 3 && ring <= 4 && dx !== 0 && dz !== 0 ? lava : hash(x, z, s + 1) < 0.08 ? magma : hash(x, z, s + 2) < 0.1 ? gilded : bs, true);
    const gate = (ax <= 1 || az <= 1) && ring >= R - 1;
    for (let dy = 0; dy <= H + 5; dy++) {
      let b = 0;
      if (ax >= R - 1 && az >= R - 1) b = dy <= H + 5 ? basalt : 0;                                   // corner towers
      else if (ring >= R - 1) {
        const r = hash3(x, y + dy, z, s);
        if (dy <= H || (dy === H + 1 && ring === R && ((ax + az) & 1) === 0)) b = r < 0.06 ? gilded : r < 0.22 ? bs : pbb;
        if ((gate && dy <= 3) || (r > 0.975 && dy > 4 && dy < H)) b = 0;
      } else if (dy === 6 && ring >= R - 5) b = pbb;                                                  // gallery
      else if (ring <= 2 && dy === 0) b = bs;                                                         // treasure pedestal
      else if (ring <= 1 && dy === 1) b = gold;
      else if (ring === 0 && dy === 2) b = gold;
      put(x, y + dy, z, b, true);
    }
  }
  for (let i = 0; i <= 5; i++) { put(p.x - 9 + i, y + i, p.z + R - 2, pbb, true); for (let dy = i + 1; dy <= i + 3; dy++) put(p.x - 9 + i, y + dy, p.z + R - 2, 0, true); }
  for (const [cx, cz] of [[7, 7], [-7, 7], [7, -7], [-7, -7]]) { put(p.x + cx, y + 5, p.z + cz, chain, true); put(p.x + cx, y + 4, p.z + cz, lantern, true); }
  put(p.x + 6, y, p.z + 6, chest, true); put(p.x - 8, y, p.z + 8, chest, true); put(p.x - 9, y + 7, p.z - 9, chest, true);
}

const BUILDERS: Record<ExtraKind, (t: Terrain, put: Put, p: Placed) => void> = { mineshaft, shipwreck, monument, mansion, outpost, ancient_city: ancientCity, bastion };

/** Writes every extra structure that intersects the chunk at (ox, oz). */
export function placeExtraStructures(t: Terrain, put: Put, ox: number, oz: number) {
  for (const s of SPECS) {
    if (s.dim !== t.dimension) continue;
    for (let rz = Math.floor((oz - 1) / s.region); rz <= Math.floor((oz + 17) / s.region); rz++) for (let rx = Math.floor((ox - 1) / s.region); rx <= Math.floor((ox + 17) / s.region); rx++) {
      const p = site(t, s, rx, rz);
      if (!p || p.x + s.radius < ox - 1 || p.x - s.radius > ox + 17 || p.z + s.radius < oz - 1 || p.z - s.radius > oz + 17) continue;
      BUILDERS[s.kind](t, put, p);
    }
  }
}
/** Which structure (if any) owns a naturally generated chest at this position — used to pick its loot table. */
export function extraLootTable(t: Terrain, x: number, y: number, z: number): ExtraKind | null {
  for (const s of SPECS) {
    const p = site(t, s, Math.floor(x / s.region), Math.floor(z / s.region));
    if (p && Math.abs(x - p.x) <= s.radius && Math.abs(z - p.z) <= s.radius && y >= p.y - 8 && y <= p.y + 30) return s.kind;
  }
  return null;
}
export function locateExtra(t: Terrain, what: string, px: number, pz: number): [number, number, number] | null {
  const kind = ALIASES[what], s = SPECS.find(k => k.kind === kind);
  if (!s || s.dim !== t.dimension) return null;
  const crx = Math.floor(px / s.region), crz = Math.floor(pz / s.region);
  let best: [number, number, number] | null = null, bestD = Infinity;
  for (let dz = -10; dz <= 10; dz++) for (let dx = -10; dx <= 10; dx++) {
    const p = site(t, s, crx + dx, crz + dz);
    if (!p) continue;
    const d = Math.hypot(p.x - px, p.z - pz);
    if (d < bestD) { bestD = d; best = [p.x, p.y, p.z]; }
  }
  return best;
}
type Loot = { rolls: [number, number]; items: [string, number, number, number][] };
export const EXTRA_LOOT: Record<ExtraKind, Loot> = {
  mineshaft: { rolls: [4, 8], items: [['rail', 4, 8, 20], ['torch', 1, 16, 15], ['coal', 3, 8, 10], ['iron_ingot', 1, 5, 10], ['redstone', 4, 9, 5], ['lapis_lazuli', 4, 9, 5], ['gold_ingot', 1, 3, 5], ['diamond', 1, 2, 3], ['bread', 1, 3, 15], ['name_tag', 1, 1, 8], ['golden_apple', 1, 1, 5], ['enchanted_book', 1, 1, 4], ['iron_pickaxe', 1, 1, 5], ['glow_berries', 3, 6, 10], ['melon_slice', 2, 4, 8]] },
  shipwreck: { rolls: [4, 9], items: [['iron_ingot', 1, 5, 18], ['gold_ingot', 1, 5, 10], ['emerald', 1, 5, 10], ['diamond', 1, 1, 3], ['lapis_lazuli', 1, 10, 8], ['paper', 1, 12, 8], ['map', 1, 1, 6], ['compass', 1, 1, 4], ['wheat', 8, 21, 8], ['carrot', 4, 8, 7], ['rotten_flesh', 5, 24, 5], ['gunpowder', 1, 5, 3], ['leather_chestplate', 1, 1, 3], ['experience_bottle', 1, 1, 5], ['heart_of_the_sea', 1, 1, 2], ['nautilus_shell', 1, 1, 3]] },
  monument: { rolls: [5, 8], items: [['prismarine_shard', 4, 12, 20], ['prismarine_crystals', 2, 8, 15], ['sponge', 1, 3, 10], ['gold_ingot', 2, 6, 10], ['heart_of_the_sea', 1, 1, 3], ['trident', 1, 1, 3], ['nautilus_shell', 1, 2, 6], ['potion_water_breathing', 1, 1, 6], ['cod', 2, 6, 10]] },
  mansion: { rolls: [5, 9], items: [['totem_of_undying', 1, 1, 5], ['diamond', 1, 3, 5], ['diamond_chestplate', 1, 1, 2], ['enchanted_book', 1, 1, 10], ['golden_apple', 1, 1, 10], ['enchanted_golden_apple', 1, 1, 1], ['lead', 1, 1, 12], ['name_tag', 1, 1, 12], ['iron_ingot', 1, 4, 10], ['gold_ingot', 1, 4, 5], ['redstone', 1, 4, 10], ['bread', 1, 1, 15], ['wheat', 1, 4, 15], ['coal', 1, 4, 10], ['bone', 1, 8, 10], ['gunpowder', 1, 8, 10], ['string', 1, 8, 10], ['emerald', 1, 4, 6]] },
  outpost: { rolls: [4, 7], items: [['crossbow', 1, 1, 12], ['wheat', 3, 5, 14], ['potato', 2, 5, 10], ['carrot', 3, 5, 10], ['dark_oak_log', 2, 3, 10], ['experience_bottle', 1, 1, 10], ['string', 1, 6, 8], ['arrow', 2, 7, 12], ['iron_ingot', 1, 3, 6], ['enchanted_book', 1, 1, 4], ['shield', 1, 1, 5], ['emerald', 1, 3, 5]] },
  ancient_city: { rolls: [5, 10], items: [['echo_shard', 1, 3, 12], ['disc_fragment', 1, 3, 8], ['enchanted_book', 1, 1, 12], ['enchanted_golden_apple', 1, 2, 3], ['sculk_catalyst', 1, 2, 6], ['sculk_sensor', 1, 3, 6], ['diamond_leggings', 1, 1, 3], ['diamond_hoe', 1, 1, 3], ['iron_leggings', 1, 1, 4], ['experience_bottle', 1, 3, 8], ['amethyst_shard', 1, 15, 8], ['glow_berries', 1, 15, 8], ['coal', 6, 15, 12], ['bone', 1, 15, 10], ['soul_torch', 1, 15, 10], ['book', 3, 10, 10], ['potion_regeneration', 1, 1, 8], ['lead', 1, 1, 4], ['name_tag', 1, 1, 4], ['saddle', 1, 1, 4], ['compass', 1, 1, 4]] },
  bastion: { rolls: [5, 9], items: [['gold_ingot', 2, 9, 15], ['gold_block', 1, 2, 8], ['golden_sword', 1, 1, 6], ['golden_helmet', 1, 1, 5], ['crossbow', 1, 1, 8], ['iron_ingot', 1, 6, 10], ['netherite_scrap', 1, 1, 4], ['ancient_debris', 1, 1, 4], ['netherite_upgrade', 1, 1, 6], ['diamond_sword', 1, 1, 3], ['diamond_pickaxe', 1, 1, 3], ['obsidian', 3, 6, 10], ['crying_obsidian', 1, 5, 8], ['gilded_blackstone', 2, 5, 10], ['magma_cream', 1, 3, 8], ['arrow', 5, 17, 10], ['spectral_arrow', 5, 12, 8], ['string', 1, 6, 8], ['enchanted_golden_apple', 1, 1, 1], ['chain', 2, 10, 8], ['cooked_porkchop', 1, 5, 10], ['netherite_ingot', 1, 1, 1]] },
};
