import { Terrain } from './terrain';
import { meshChunk, type MeshData } from './mesher';

let terrain: Terrain | undefined, seed = '', dimension = '';
/** Tile table: sent once per worker with its first request, then reused. */
let tiles: number[][] | undefined;

const transfers = (m: MeshData) => [m.position.buffer, m.normal.buffer, m.uv.buffer, m.color.buffer, m.tile.buffer, m.wind.buffer, m.light.buffer, m.index.buffer];

/** Widens [lo, hi] to the vertical extent of a mesh, so the main thread can cull the chunk with a tight box without touching the vertices. */
function extendY(m: MeshData, range: [number, number]) {
  const p = m.position;
  for (let i = 1; i < p.length; i += 3) {
    const y = p[i];
    if (y < range[0]) range[0] = y;
    if (y > range[1]) range[1] = y;
  }
}

self.onmessage = (event: MessageEvent) => {
  const m = event.data;
  try {
    if (m.tiles) tiles = m.tiles;
    if (!tiles) throw new Error('tile table missing');
    if (!terrain || seed !== m.seed || dimension !== m.dimension) { terrain = new Terrain(m.seed, m.dimension); seed = m.seed; dimension = m.dimension; }
    const generated = terrain.generate(m.cx, m.cz, m.edits, m.structures);
    const mesh = meshChunk(generated.padded, generated.maxY, tiles, generated.tint);
    const range: [number, number] = [Infinity, -Infinity];
    extendY(mesh.solid, range);
    extendY(mesh.water, range);
    if (range[0] > range[1]) { range[0] = 0; range[1] = 0; }
    const response = { type: 'chunk', key: m.key, cx: m.cx, cz: m.cz, version: m.version, epoch: m.epoch, data: generated.data.buffer, solid: mesh.solid, water: mesh.water, minY: range[0], maxY: range[1] };
    self.postMessage(response, [generated.data.buffer, ...transfers(mesh.solid), ...transfers(mesh.water)] as any);
  } catch (error) { self.postMessage({ type: 'error', key: m.key, epoch: m.epoch, message: String(error) }); }
};
