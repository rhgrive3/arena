import { BLOCKS, ID } from '../game/data';
import { isSlabBlock, localFaceForState, type Face } from '../game/blockState';
import { modelBoxes, TORCH16, LEVER_BASE16, LEVER_STICK16, BUTTON16 } from './shapes';
import { MIN_Y, HEIGHT } from './terrain';

export interface MeshData {
  position: Float32Array;
  normal: Float32Array;
  uv: Float32Array;
  color: Float32Array;
  tile: Float32Array;
  wind: Float32Array;
  light: Float32Array;
  index: Uint32Array;
}

const AO_LUT = [1.0, 0.81, 0.65, 0.50];
/** How far (in blocks) each merged solid quad is grown to hide T-junction gaps: 1/500 block, about 1/30 of a texel. */
const SEAM = 0.002;
const STRIDE_Y = 324; // 18 * 18

// Precomputed O(1) lookup tables by block ID (lazily synced)
const MAX_IDS = 512;
const LUT_FULL = new Uint8Array(MAX_IDS);
const LUT_OPAQUE = new Uint8Array(MAX_IDS);
const LUT_SLAB = new Uint8Array(MAX_IDS);
const LUT_LIGHT = new Uint8Array(MAX_IDS);
const LUT_TRANSPARENT = new Uint8Array(MAX_IDS);
const LUT_TINT_TOP = new Uint8Array(MAX_IDS);
const LUT_TINT_ALL = new Uint8Array(MAX_IDS);
const LUT_WIND = new Uint8Array(MAX_IDS);
let lutBuiltCount = -1;

function ensureLuts() {
  if (lutBuiltCount === BLOCKS.length) return;
  lutBuiltCount = BLOCKS.length;
  for (let i = 0; i < BLOCKS.length && i < MAX_IDS; i++) {
    const def = BLOCKS[i];
    if (!def) continue;
    const slab = isSlabBlock(def);
    LUT_SLAB[i] = slab ? 1 : 0;
    LUT_FULL[i] = def.shape === 'cube' ? 1 : 0;
    LUT_TRANSPARENT[i] = def.transparent ? 1 : 0;
    LUT_OPAQUE[i] = i > 0 && !def.transparent ? 1 : 0;
    LUT_LIGHT[i] = def.light ? Math.min(15, def.light) : 0;
    LUT_TINT_TOP[i] = def.pattern === 'grass' ? 1 : 0;
    LUT_TINT_ALL[i] = def.pattern === 'leaves' ? 1 : 0;
    LUT_WIND[i] = def.pattern === 'leaves' ? 1 : 0;
  }
}

// Module-level reusable buffers (zero GC per chunk inside Worker)
const lightSky = new Uint8Array(18 * 18 * HEIGHT);
const lightBlk = new Uint8Array(18 * 18 * HEIGHT);
const bfsQueue = new Int32Array(18 * 18 * HEIGHT * 2);

class MeshBuf {
  p: Float32Array;
  n: Float32Array;
  uv: Float32Array;
  c: Float32Array;
  t: Float32Array;
  w: Float32Array;
  l: Float32Array;
  i: Uint32Array;
  vCount = 0;
  iCount = 0;
  capV: number;
  capI: number;

  constructor(capV = 2048, capI = 3072) {
    this.capV = capV;
    this.capI = capI;
    this.p = new Float32Array(capV * 3);
    this.n = new Float32Array(capV * 3);
    this.uv = new Float32Array(capV * 2);
    this.c = new Float32Array(capV * 3);
    this.t = new Float32Array(capV);
    this.w = new Float32Array(capV);
    this.l = new Float32Array(capV * 2);
    this.i = new Uint32Array(capI);
  }

  private ensureV(add: number) {
    if (this.vCount + add <= this.capV) return;
    const next = Math.max(this.capV * 2, this.vCount + add);
    const grow = (src: Float32Array, mult: number) => {
      const dst = new Float32Array(next * mult);
      dst.set(src);
      return dst;
    };
    this.p = grow(this.p, 3);
    this.n = grow(this.n, 3);
    this.uv = grow(this.uv, 2);
    this.c = grow(this.c, 3);
    this.t = grow(this.t, 1);
    this.w = grow(this.w, 1);
    this.l = grow(this.l, 2);
    this.capV = next;
  }

  private ensureI(add: number) {
    if (this.iCount + add <= this.capI) return;
    const next = Math.max(this.capI * 2, this.iCount + add);
    const dst = new Uint32Array(next);
    dst.set(this.i);
    this.i = dst;
    this.capI = next;
  }

  pushQuad(
    x0: number, y0: number, z0: number,
    x1: number, y1: number, z1: number,
    x2: number, y2: number, z2: number,
    x3: number, y3: number, z3: number,
    nx: number, ny: number, nz: number,
    u: number, v: number, tile: number,
    ao0: number, ao1: number, ao2: number, ao3: number,
    sky0: number, sky1: number, sky2: number, sky3: number,
    blk0: number, blk1: number, blk2: number, blk3: number,
    wind: number, flip: boolean,
    r: number, g: number, b: number,
    rot90: boolean, rev: boolean,
  ) {
    this.ensureV(4);
    this.ensureI(6);
    const start = this.vCount;
    const pOff = start * 3, uvOff = start * 2, lOff = start * 2;

    this.p[pOff] = x0; this.p[pOff + 1] = y0; this.p[pOff + 2] = z0;
    this.p[pOff + 3] = x1; this.p[pOff + 4] = y1; this.p[pOff + 5] = z1;
    this.p[pOff + 6] = x2; this.p[pOff + 7] = y2; this.p[pOff + 8] = z2;
    this.p[pOff + 9] = x3; this.p[pOff + 10] = y3; this.p[pOff + 11] = z3;

    this.n[pOff] = nx; this.n[pOff + 1] = ny; this.n[pOff + 2] = nz;
    this.n[pOff + 3] = nx; this.n[pOff + 4] = ny; this.n[pOff + 5] = nz;
    this.n[pOff + 6] = nx; this.n[pOff + 7] = ny; this.n[pOff + 8] = nz;
    this.n[pOff + 9] = nx; this.n[pOff + 10] = ny; this.n[pOff + 11] = nz;

    this.t[start] = tile; this.t[start + 1] = tile; this.t[start + 2] = tile; this.t[start + 3] = tile;
    this.w[start] = wind; this.w[start + 1] = wind; this.w[start + 2] = wind; this.w[start + 3] = wind;

    if (rot90) {
      if (rev) {
        this.uv[uvOff] = v; this.uv[uvOff + 1] = 0;
        this.uv[uvOff + 2] = v; this.uv[uvOff + 3] = u;
        this.uv[uvOff + 4] = 0; this.uv[uvOff + 5] = u;
        this.uv[uvOff + 6] = 0; this.uv[uvOff + 7] = 0;
      } else {
        // +X faces: mirror U so textures read left-to-right when seen from outside.
        this.uv[uvOff] = v; this.uv[uvOff + 1] = 0;
        this.uv[uvOff + 2] = v; this.uv[uvOff + 3] = u;
        this.uv[uvOff + 4] = 0; this.uv[uvOff + 5] = u;
        this.uv[uvOff + 6] = 0; this.uv[uvOff + 7] = 0;
      }
    } else if (rev) {
      // -Z (and bottom) faces arrive in reversed vertex order: keep V pointing up so side textures are not upside down.
      this.uv[uvOff] = u; this.uv[uvOff + 1] = v;
      this.uv[uvOff + 2] = 0; this.uv[uvOff + 3] = v;
      this.uv[uvOff + 4] = 0; this.uv[uvOff + 5] = 0;
      this.uv[uvOff + 6] = u; this.uv[uvOff + 7] = 0;
    } else {
      this.uv[uvOff] = 0; this.uv[uvOff + 1] = 0;
      this.uv[uvOff + 2] = u; this.uv[uvOff + 3] = 0;
      this.uv[uvOff + 4] = u; this.uv[uvOff + 5] = v;
      this.uv[uvOff + 6] = 0; this.uv[uvOff + 7] = v;
    }

    const l0 = AO_LUT[ao0], l1 = AO_LUT[ao1], l2 = AO_LUT[ao2], l3 = AO_LUT[ao3];
    this.c[pOff] = l0 * r; this.c[pOff + 1] = l0 * g; this.c[pOff + 2] = l0 * b;
    this.c[pOff + 3] = l1 * r; this.c[pOff + 4] = l1 * g; this.c[pOff + 5] = l1 * b;
    this.c[pOff + 6] = l2 * r; this.c[pOff + 7] = l2 * g; this.c[pOff + 8] = l2 * b;
    this.c[pOff + 9] = l3 * r; this.c[pOff + 10] = l3 * g; this.c[pOff + 11] = l3 * b;

    this.l[lOff] = sky0; this.l[lOff + 1] = blk0;
    this.l[lOff + 2] = sky1; this.l[lOff + 3] = blk1;
    this.l[lOff + 4] = sky2; this.l[lOff + 5] = blk2;
    this.l[lOff + 6] = sky3; this.l[lOff + 7] = blk3;

    const ii = this.iCount;
    if (flip) {
      this.i[ii] = start; this.i[ii + 1] = start + 1; this.i[ii + 2] = start + 3;
      this.i[ii + 3] = start + 1; this.i[ii + 4] = start + 2; this.i[ii + 5] = start + 3;
    } else {
      this.i[ii] = start; this.i[ii + 1] = start + 1; this.i[ii + 2] = start + 2;
      this.i[ii + 3] = start; this.i[ii + 4] = start + 2; this.i[ii + 5] = start + 3;
    }

    this.vCount += 4;
    this.iCount += 6;
  }

  /** Overrides the UVs of the quad pushed last (vertex 0 → (ua, va), 1 → (ub, va), 2 → (ub, vb), 3 → (ua, vb)) so a box face shows exactly its own part of the tile. */
  uvRect(ua: number, va: number, ub: number, vb: number) {
    // Inset towards the middle of the range (ranges may be reversed to flip the image) so sampling never wraps into a neighbouring texel.
    const o = (this.vCount - 4) * 2, eu = ub >= ua ? 0.002 : -0.002, ev = vb >= va ? 0.002 : -0.002;
    const a = ua + eu, b = ub - eu, c = va + ev, d = vb - ev;
    this.uv[o] = a; this.uv[o + 1] = c;
    this.uv[o + 2] = b; this.uv[o + 3] = c;
    this.uv[o + 4] = b; this.uv[o + 5] = d;
    this.uv[o + 6] = a; this.uv[o + 7] = d;
  }

  pack(): MeshData {
    return {
      position: this.p.subarray(0, this.vCount * 3).slice(),
      normal: this.n.subarray(0, this.vCount * 3).slice(),
      uv: this.uv.subarray(0, this.vCount * 2).slice(),
      color: this.c.subarray(0, this.vCount * 3).slice(),
      tile: this.t.subarray(0, this.vCount).slice(),
      wind: this.w.subarray(0, this.vCount).slice(),
      light: this.l.subarray(0, this.vCount * 2).slice(),
      index: this.i.subarray(0, this.iCount).slice(),
    };
  }
}

function computeLights(padded: Uint16Array, maxY: number) {
  const maxLocalY = Math.min(HEIGHT - 1, maxY - MIN_Y + 2);
  const waterId = ID.water;
  lightSky.fill(15);
  lightBlk.fill(0);

  let blkHead = 0, blkTail = 0;
  const totalCap = bfsQueue.length;
  const skyStart = totalCap >> 1;
  let skyHead = skyStart, skyTail = skyStart;

  // 1) Top-down column scan + emissive seeding (packed coords: x | (z << 5) | (ly << 10))
  for (let z = 0; z < 18; z++) {
    for (let x = 0; x < 18; x++) {
      let sky = 15;
      const colBase = z * 18 + x;
      for (let ly = maxLocalY; ly >= 0; ly--) {
        const idx = ly * STRIDE_Y + colBase;
        const cell = padded[idx];
        if (cell) {
          const id = cell & 4095;
          const em = LUT_LIGHT[id];
          if (em) {
            lightBlk[idx] = em;
            if (blkTail < skyStart) bfsQueue[blkTail++] = x | (z << 5) | (ly << 10);
          }
          if (LUT_OPAQUE[id] && (LUT_FULL[id] || (LUT_SLAB[id] && ((cell >>> 12) & 15) === 2))) {
            sky = 0;
          } else if (id === waterId || LUT_WIND[id]) {
            sky = sky > 2 ? sky - 2 : 0;
          }
        }
        lightSky[idx] = sky;
      }
    }
  }

  // Seed sky light spill into overhangs/caves
  for (let ly = 1; ly <= maxLocalY; ly++) {
    const yOff = ly * STRIDE_Y;
    for (let z = 1; z < 17; z++) {
      const zOff = yOff + z * 18;
      for (let x = 1; x < 17; x++) {
        const idx = zOff + x;
        const s = lightSky[idx];
        if (s > 1) {
          const sm1 = s - 1;
          if (
            lightSky[idx - 1] < sm1 ||
            lightSky[idx + 1] < sm1 ||
            lightSky[idx - 18] < sm1 ||
            lightSky[idx + 18] < sm1 ||
            lightSky[idx - STRIDE_Y] < sm1
          ) {
            if (skyTail < totalCap) bfsQueue[skyTail++] = x | (z << 5) | (ly << 10);
          }
        }
      }
    }
  }

  // Light enters every cell that is not a full cube: doors, stairs, slabs, fences and torches are lit by the air around them
  // instead of rendering black under a roof or inside a wall.
  const canPass = (cell: number) => {
    if (!cell) return true;
    const id = cell & 4095;
    if (LUT_TRANSPARENT[id] === 1) return true;
    return LUT_FULL[id] === 0 && !(LUT_SLAB[id] === 1 && ((cell >>> 12) & 15) === 2);
  };

  // Block light BFS (division-free)
  while (blkHead < blkTail) {
    const packed = bfsQueue[blkHead++];
    const x = packed & 31;
    const z = (packed >>> 5) & 31;
    const ly = packed >>> 10;
    const idx = ly * STRIDE_Y + z * 18 + x;
    const val = lightBlk[idx];
    if (val <= 1) continue;
    const nextVal = val - 1;

    if (x > 0) { const ni = idx - 1; if (lightBlk[ni] < nextVal && canPass(padded[ni])) { lightBlk[ni] = nextVal; if (blkTail < skyStart) bfsQueue[blkTail++] = (x - 1) | (z << 5) | (ly << 10); } }
    if (x < 17) { const ni = idx + 1; if (lightBlk[ni] < nextVal && canPass(padded[ni])) { lightBlk[ni] = nextVal; if (blkTail < skyStart) bfsQueue[blkTail++] = (x + 1) | (z << 5) | (ly << 10); } }
    if (z > 0) { const ni = idx - 18; if (lightBlk[ni] < nextVal && canPass(padded[ni])) { lightBlk[ni] = nextVal; if (blkTail < skyStart) bfsQueue[blkTail++] = x | ((z - 1) << 5) | (ly << 10); } }
    if (z < 17) { const ni = idx + 18; if (lightBlk[ni] < nextVal && canPass(padded[ni])) { lightBlk[ni] = nextVal; if (blkTail < skyStart) bfsQueue[blkTail++] = x | ((z + 1) << 5) | (ly << 10); } }
    if (ly > 0) { const ni = idx - STRIDE_Y; if (lightBlk[ni] < nextVal && canPass(padded[ni])) { lightBlk[ni] = nextVal; if (blkTail < skyStart) bfsQueue[blkTail++] = x | (z << 5) | ((ly - 1) << 10); } }
    if (ly < maxLocalY) { const ni = idx + STRIDE_Y; if (lightBlk[ni] < nextVal && canPass(padded[ni])) { lightBlk[ni] = nextVal; if (blkTail < skyStart) bfsQueue[blkTail++] = x | (z << 5) | ((ly + 1) << 10); } }
  }

  // Sky light BFS (division-free)
  while (skyHead < skyTail) {
    const packed = bfsQueue[skyHead++];
    const x = packed & 31;
    const z = (packed >>> 5) & 31;
    const ly = packed >>> 10;
    const idx = ly * STRIDE_Y + z * 18 + x;
    const val = lightSky[idx];
    if (val <= 1) continue;
    const nextVal = val - 1;

    if (x > 0) { const ni = idx - 1; if (lightSky[ni] < nextVal && canPass(padded[ni])) { lightSky[ni] = nextVal; if (skyTail < totalCap) bfsQueue[skyTail++] = (x - 1) | (z << 5) | (ly << 10); } }
    if (x < 17) { const ni = idx + 1; if (lightSky[ni] < nextVal && canPass(padded[ni])) { lightSky[ni] = nextVal; if (skyTail < totalCap) bfsQueue[skyTail++] = (x + 1) | (z << 5) | (ly << 10); } }
    if (z > 0) { const ni = idx - 18; if (lightSky[ni] < nextVal && canPass(padded[ni])) { lightSky[ni] = nextVal; if (skyTail < totalCap) bfsQueue[skyTail++] = x | ((z - 1) << 5) | (ly << 10); } }
    if (z < 17) { const ni = idx + 18; if (lightSky[ni] < nextVal && canPass(padded[ni])) { lightSky[ni] = nextVal; if (skyTail < totalCap) bfsQueue[skyTail++] = x | ((z + 1) << 5) | (ly << 10); } }
    if (ly > 0) { const ni = idx - STRIDE_Y; if (lightSky[ni] < nextVal && canPass(padded[ni])) { lightSky[ni] = nextVal; if (skyTail < totalCap) bfsQueue[skyTail++] = x | (z << 5) | ((ly - 1) << 10); } }
    if (ly < maxLocalY) { const ni = idx + STRIDE_Y; if (lightSky[ni] < nextVal && canPass(padded[ni])) { lightSky[ni] = nextVal; if (skyTail < totalCap) bfsQueue[skyTail++] = x | (z << 5) | ((ly + 1) << 10); } }
  }
}

export function meshChunk(padded: Uint16Array, maxY: number, tiles: number[][], tint?: Float32Array): { solid: MeshData; water: MeshData } {
  ensureLuts();
  computeLights(padded, maxY);

  const dimsY = Math.min(HEIGHT, maxY - MIN_Y);
  const dims = [16, dimsY, 16];
  const waterId = ID.water, lavaId = ID.lava, endGatewayId = ID.end_gateway;

  const get = (x: number, y: number, z: number) =>
    y < 0 || y >= dimsY || x < -1 || x > 16 || z < -1 || z > 16
      ? 0
      : padded[y * STRIDE_Y + (z + 1) * 18 + x + 1];

  const isFull = (cell: number) => {
    if (!cell) return false;
    const id = cell & 4095;
    return LUT_FULL[id] === 1 || (LUT_SLAB[id] === 1 && ((cell >>> 12) & 15) === 2);
  };
  const isOpq = (cell: number) => {
    if (!cell) return false;
    const id = cell & 4095;
    return LUT_OPAQUE[id] === 1 && (LUT_FULL[id] === 1 || (LUT_SLAB[id] === 1 && ((cell >>> 12) & 15) === 2));
  };

  const lightIdx = (x: number, ly: number, z: number) => {
    const cx = x < -1 ? -1 : x > 16 ? 16 : x;
    const cz = z < -1 ? -1 : z > 16 ? 16 : z;
    const cy = ly < 0 ? 0 : ly >= HEIGHT ? HEIGHT - 1 : ly;
    return cy * STRIDE_Y + (cz + 1) * 18 + cx + 1;
  };

  // Water surface depth, used by the water shader for colour, transparency and the shoreline.
  // It is evaluated per vertex from the four columns around that corner, so it is continuous across quads and chunk borders.
  const isFluid = (c: number) => { const i = c & 4095; return c !== 0 && (i === waterId || i === lavaId); };
  const wdepth = (x: number, ly: number, z: number) => {
    if (!isFluid(get(x, ly, z))) return 0;
    if (isFluid(get(x, ly + 1, z))) return 6;
    let c = 1;
    while (c < 6 && isFluid(get(x, ly - c, z))) c++;
    return c;
  };
  const deepAround = (x: number, ly: number, z: number) => {
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (wdepth(x + dx, ly, z + dz) < 6) return false;
    return true;
  };
  // Fraction of the four columns around a corner that are not water: 0 in open water, about 0.5 along a straight shoreline.
  const shoreAt = (vx: number, ly: number, vz: number) => ((wdepth(vx - 1, ly, vz - 1) === 0 ? 1 : 0) + (wdepth(vx, ly, vz - 1) === 0 ? 1 : 0) + (wdepth(vx - 1, ly, vz) === 0 ? 1 : 0) + (wdepth(vx, ly, vz) === 0 ? 1 : 0)) / 4;
  const cornerDepth = (vx: number, ly: number, vz: number) => (wdepth(vx - 1, ly, vz - 1) + wdepth(vx, ly, vz - 1) + wdepth(vx - 1, ly, vz) + wdepth(vx, ly, vz)) / 24;

  const out = new MeshBuf(2048, 3072);
  const water = new MeshBuf(512, 768);
  const p = [0, 0, 0];
  const step = [0, 0, 0];
  const mask = new Int32Array(16 * Math.max(16, dimsY));
  const waterMask = new Int16Array(16 * Math.max(16, dimsY));

  for (let d = 0; d < 3; d++) {
    const u = (d + 1) % 3, v = (d + 2) % 3;
    step[0] = 0; step[1] = 0; step[2] = 0; step[d] = 1;
    const duLen = dims[u], dvLen = dims[v];

    for (let slice = -1; slice < dims[d]; slice++) {
      mask.fill(0, 0, duLen * dvLen);
      waterMask.fill(0, 0, duLen * dvLen);

      for (let j = 0; j < dvLen; j++) {
        for (let i = 0; i < duLen; i++) {
          p[d] = slice; p[u] = i; p[v] = j;
          const cellA = get(p[0], p[1], p[2]);
          const cellB = get(p[0] + step[0], p[1] + step[1], p[2] + step[2]);
          if (cellA === cellB) continue;

          const a = cellA & 4095, b = cellB & 4095;
          const aid = a && isFull(cellA) ? a : 0;
          const bid = b && isFull(cellB) ? b : 0;
          let id = 0, sign = 1;
          if (aid && !isOpq(cellB) && !(a === b && LUT_TRANSPARENT[a])) id = a;
          else if (bid && !isOpq(cellA) && a !== b) { id = b; sign = -1; }

          if (id && id !== waterId && id !== lavaId && id !== endGatewayId) {
            const q0 = p[0] + (sign > 0 && d === 0 ? 1 : 0);
            const q1 = p[1] + (sign > 0 && d === 1 ? 1 : 0);
            const q2 = p[2] + (sign > 0 && d === 2 ? 1 : 0);

            const lIdx = lightIdx(p[0] + (sign > 0 ? step[0] : 0), p[1] + (sign > 0 ? step[1] : 0), p[2] + (sign > 0 ? step[2] : 0));
            const skyVal = lightSky[lIdx] >> 2;
            const blkVal = lightBlk[lIdx] >> 2;

            let ao0 = 0, ao1 = 0, ao2 = 0, ao3 = 0;
            for (let cIdx = 0; cIdx < 4; cIdx++) {
              const cu = cIdx === 1 || cIdx === 2 ? 1 : 0;
              const cv = cIdx >= 2 ? 1 : 0;
              const du = cu ? 1 : -1, dv = cv ? 1 : -1;
              const s1x = q0 + (u === 0 ? du : 0), s1y = q1 + (u === 1 ? du : 0), s1z = q2 + (u === 2 ? du : 0);
              const s2x = q0 + (v === 0 ? dv : 0), s2y = q1 + (v === 1 ? dv : 0), s2z = q2 + (v === 2 ? dv : 0);
              const cx = q0 + (u === 0 ? du : 0) + (v === 0 ? dv : 0);
              const cy = q1 + (u === 1 ? du : 0) + (v === 1 ? dv : 0);
              const cz = q2 + (u === 2 ? du : 0) + (v === 2 ? dv : 0);
              const a1 = isOpq(get(s1x, s1y, s1z)) ? 1 : 0;
              const a2 = isOpq(get(s2x, s2y, s2z)) ? 1 : 0;
              const ac = isOpq(get(cx, cy, cz)) ? 1 : 0;
              const val = a1 && a2 ? 3 : a1 + a2 + ac;
              if (cIdx === 0) ao0 = val; else if (cIdx === 1) ao1 = val; else if (cIdx === 2) ao2 = val; else ao3 = val;
            }
            const state = ((sign > 0 ? cellA : cellB) >>> 12) & 15;
            mask[j * duLen + i] =
              id |
              (ao0 << 12) | (ao1 << 14) | (ao2 << 16) | (ao3 << 18) |
              (sign < 0 ? 1 << 20 : 0) |
              (state << 21) |
              (skyVal << 25) |
              (blkVal << 27);
          }

          // Shallow surface cells (bit 0x400) stay 1x1 so their per-vertex depth is exact; open deep water still merges greedily.
          if ((a === waterId || a === lavaId) && b === 0) waterMask[j * duLen + i] = d === 1 && a === waterId && !deepAround(p[0], p[1], p[2]) ? a | 0x400 : a;
          else if ((b === waterId || b === lavaId) && a === 0) waterMask[j * duLen + i] = -b;
        }
      }

      for (let j = 0; j < dvLen; j++) {
        for (let i = 0; i < duLen;) {
          const key = mask[j * duLen + i], wm = waterMask[j * duLen + i];
          if (!key && !wm) { i++; continue; }
          let w = 1, h = 1;
          if (key) {
            while (i + w < duLen && mask[j * duLen + i + w] === key) w++;
            outer: while (j + h < dvLen) {
              const row = (j + h) * duLen + i;
              for (let k = 0; k < w; k++) if (mask[row + k] !== key) break outer;
              h++;
            }
          } else if (!(wm > 0 && (wm & 0x400))) {
            while (i + w < duLen && waterMask[j * duLen + i + w] === wm && !mask[j * duLen + i + w]) w++;
            outerWater: while (j + h < dvLen) {
              const row = (j + h) * duLen + i;
              for (let k = 0; k < w; k++) if (waterMask[row + k] !== wm || mask[row + k]) break outerWater;
              h++;
            }
          }

          const id = key ? key & 4095 : Math.abs(wm) & 0x3ff;
          const sign = key ? (key & (1 << 20) ? -1 : 1) : (wm > 0 ? 1 : -1);
          const ao0 = key ? (key >> 12) & 3 : 0;
          const ao1 = key ? (key >> 14) & 3 : 0;
          const ao2 = key ? (key >> 16) & 3 : 0;
          const ao3 = key ? (key >> 18) & 3 : 0;
          const state = key ? (key >>> 21) & 15 : 0;

          const bp0 = d === 0 ? slice + 1 : (u === 0 ? i : j);
          const bp1 = d === 1 ? slice + 1 : (u === 1 ? i : j);
          const bp2 = d === 2 ? slice + 1 : (u === 2 ? i : j);
          const u0 = u === 0 ? w : 0, u1 = u === 1 ? w : 0, u2 = u === 2 ? w : 0;
          const v0 = v === 0 ? h : 0, v1 = v === 1 ? h : 0, v2 = v === 2 ? h : 0;

          const vx0 = bp0, vx1 = bp0 + u0, vx2 = bp0 + u0 + v0, vx3 = bp0 + v0;
          let vy0 = bp1 + MIN_Y, vy1 = bp1 + u1 + MIN_Y, vy2 = bp1 + u1 + v1 + MIN_Y, vy3 = bp1 + v1 + MIN_Y;
          const vz0 = bp2, vz1 = bp2 + u2, vz2 = bp2 + u2 + v2, vz3 = bp2 + v2;

          if (wm && d === 1 && sign > 0) {
            vy0 -= 0.12; vy1 -= 0.12; vy2 -= 0.12; vy3 -= 0.12;
          }

          let s0: number, s1: number, s2: number, s3: number, b0: number, b1: number, b2: number, b3: number;
          if (wm) {
            s0 = 0; s1 = 0; s2 = 0; s3 = 0;
            if (wm > 0 && (wm & 0x400)) {
              s0 = shoreAt(vx0, slice, vz0); s1 = shoreAt(vx1, slice, vz1); s2 = shoreAt(vx2, slice, vz2); s3 = shoreAt(vx3, slice, vz3);
              b0 = cornerDepth(vx0, slice, vz0); b1 = cornerDepth(vx1, slice, vz1);
              b2 = cornerDepth(vx2, slice, vz2); b3 = cornerDepth(vx3, slice, vz3);
            } else { b0 = 1; b1 = 1; b2 = 1; b3 = 1; }
          } else {
            const airD = slice + (sign > 0 ? 1 : 0);
            const li0 = lightIdx(d === 0 ? airD : u === 0 ? i : j, d === 1 ? airD : u === 1 ? i : j, d === 2 ? airD : u === 2 ? i : j);
            const li1 = lightIdx(d === 0 ? airD : u === 0 ? i + w - 1 : j, d === 1 ? airD : u === 1 ? i + w - 1 : j, d === 2 ? airD : u === 2 ? i + w - 1 : j);
            const li2 = lightIdx(d === 0 ? airD : u === 0 ? i + w - 1 : j + h - 1, d === 1 ? airD : u === 1 ? i + w - 1 : j + h - 1, d === 2 ? airD : u === 2 ? i + w - 1 : j + h - 1);
            const li3 = lightIdx(d === 0 ? airD : u === 0 ? i : j + h - 1, d === 1 ? airD : u === 1 ? i : j + h - 1, d === 2 ? airD : u === 2 ? i : j + h - 1);
            s0 = lightSky[li0] / 15; b0 = lightBlk[li0] / 15;
            s1 = lightSky[li1] / 15; b1 = lightBlk[li1] / 15;
            s2 = lightSky[li2] / 15; b2 = lightBlk[li2] / 15;
            s3 = lightSky[li3] / 15; b3 = lightBlk[li3] / 15;
          }

          const def = BLOCKS[id];
          const tinted = !wm && ((LUT_TINT_TOP[id] === 1 && d === 1 && sign > 0) || LUT_TINT_ALL[id] === 1);
          let r = 1, g = 1, b = 1;
          if (tinted && tint) {
            const cx = vx0 < 0 ? 0 : vx0 > 15 ? 15 : vx0 | 0;
            const cz = vz0 < 0 ? 0 : vz0 > 15 ? 15 : vz0 | 0;
            const ti = (cz * 16 + cx) * 3;
            r = tint[ti]; g = tint[ti + 1]; b = tint[ti + 2];
          }

          const worldFace = (d * 2 + (sign > 0 ? 0 : 1)) as Face;
          const tile = wm ? (id === lavaId ? 1 : 0) : tiles[id][localFaceForState(def, state, worldFace)];
          const nx = d === 0 ? sign : 0, ny = d === 1 ? sign : 0, nz = d === 2 ? sign : 0;
          const wind = LUT_WIND[id] ? 0.13 : 0;

          // Merged quads of different sizes meet in T-junctions, where rasterisation leaves single-pixel gaps that sparkle while the
          // camera moves. Growing each solid quad by a hair inside its own plane makes neighbours overlap and closes them.
          // (Water is translucent, so overlapping would show as seams: it is left exact.)
          const seam = wm ? 0 : SEAM;
          const eux = u === 0 ? seam : 0, euy = u === 1 ? seam : 0, euz = u === 2 ? seam : 0;
          const evx = v === 0 ? seam : 0, evy = v === 1 ? seam : 0, evz = v === 2 ? seam : 0;
          const qx0 = vx0 - eux - evx, qy0 = vy0 - euy - evy, qz0 = vz0 - euz - evz;
          const qx1 = vx1 + eux - evx, qy1 = vy1 + euy - evy, qz1 = vz1 + euz - evz;
          const qx2 = vx2 + eux + evx, qy2 = vy2 + euy + evy, qz2 = vz2 + euz + evz;
          const qx3 = vx3 - eux + evx, qy3 = vy3 - euy + evy, qz3 = vz3 - euz + evz;

          if (sign < 0) {
            (wm ? water : out).pushQuad(
              qx3, qy3, qz3, qx2, qy2, qz2, qx1, qy1, qz1, qx0, qy0, qz0,
              nx, ny, nz, w, h, tile,
              ao3, ao2, ao1, ao0,
              s3, s2, s1, s0,
              b3, b2, b1, b0,
              wind, ao3 + ao1 > ao2 + ao0, r, g, b, d === 0, true,
            );
          } else {
            (wm ? water : out).pushQuad(
              qx0, qy0, qz0, qx1, qy1, qz1, qx2, qy2, qz2, qx3, qy3, qz3,
              nx, ny, nz, w, h, tile,
              ao0, ao1, ao2, ao3,
              s0, s1, s2, s3,
              b0, b1, b2, b3,
              wind, ao0 + ao2 > ao1 + ao3, r, g, b, d === 0, false,
            );
          }

          for (let dy = 0; dy < h; dy++) {
            const row = (j + dy) * duLen + i;
            for (let dx = 0; dx < w; dx++) {
              mask[row + dx] = 0;
              waterMask[row + dx] = 0;
            }
          }
          i += w;
        }
      }
    }
  }

  // ---- box models for non-cube blocks ----
  const CN = new Float64Array(24);
  const FQ = [4, 5, 7, 6, 1, 0, 2, 3, 6, 7, 3, 2, 0, 1, 5, 4, 5, 1, 3, 7, 0, 4, 6, 2];
  const FNRM = [0, 0, 1, 0, 0, -1, 0, 1, 0, 0, -1, 0, 1, 0, 0, -1, 0, 0];
  const STICK_UP = [7, 0, 7, 9, 10, 9], STICK_DOWN = [7, 10, 7, 9, 0, 9], DT = [0, 0, 0, 0, 16, 0];
  /**
   * Emits a box given in sixteenths of a block. `tex` is the box (also in sixteenths) whose position picks the texels; it defaults to the
   * box itself, which is the vanilla "texture follows position" mapping, and reversed ranges flip the image. `mirror` puts the same image
   * on both sides of a thin panel (doors). `end` 0/1 shifts the bottom/top face by (sdx, sdz) sixteenths for leaning sticks.
   */
  const emitBox = (bx: number, by: number, bz: number, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, tile: number, sky: number, blk: number, tex?: readonly number[], mirror = false, end = -1, sdx = 0, sdz = 0) => {
    for (let i = 0; i < 8; i++) {
      const top = (i >> 1) & 1, sh = end === top;
      CN[i * 3] = bx + ((i & 1 ? x1 : x0) + (sh ? sdx : 0)) / 16;
      CN[i * 3 + 1] = by + (top ? y1 : y0) / 16;
      CN[i * 3 + 2] = bz + ((i & 4 ? z1 : z0) + (sh ? sdz : 0)) / 16;
    }
    const ux0 = (tex ? tex[0] : x0) / 16, v0 = (tex ? tex[1] : y0) / 16, uz0 = (tex ? tex[2] : z0) / 16;
    const ux1 = (tex ? tex[3] : x1) / 16, v1 = (tex ? tex[4] : y1) / 16, uz1 = (tex ? tex[5] : z1) / 16;
    for (let f = 0; f < 6; f++) {
      const a = FQ[f * 4] * 3, b = FQ[f * 4 + 1] * 3, c = FQ[f * 4 + 2] * 3, d = FQ[f * 4 + 3] * 3;
      out.pushQuad(CN[a], CN[a + 1], CN[a + 2], CN[b], CN[b + 1], CN[b + 2], CN[c], CN[c + 1], CN[c + 2], CN[d], CN[d + 1], CN[d + 2], FNRM[f * 3], FNRM[f * 3 + 1], FNRM[f * 3 + 2], 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false);
      if (f === 0) out.uvRect(ux0, v0, ux1, v1);
      else if (f === 1) { if (mirror) out.uvRect(ux1, v0, ux0, v1); else out.uvRect(1 - ux1, v0, 1 - ux0, v1); }
      else if (f === 2) out.uvRect(ux0, 1 - uz1, ux1, 1 - uz0);
      else if (f === 3) out.uvRect(ux0, uz0, ux1, uz1);
      else if (f === 4) { if (mirror) out.uvRect(uz1, v0, uz0, v1); else out.uvRect(1 - uz1, v0, 1 - uz0, v1); }
      else out.uvRect(uz0, v0, uz1, v1);
    }
  };

  for (let ly = 0; ly < dimsY; ly++) {
    const y = ly + MIN_Y;
    const yOff = ly * STRIDE_Y;
    for (let z = 0; z < 16; z++) {
      const zOff = yOff + (z + 1) * 18 + 1;
      for (let x = 0; x < 16; x++) {
        const cell = padded[zOff + x];
        if (!cell) continue;
        const id = cell & 4095, b = BLOCKS[id];
        if (!b || (isFull(cell) && id !== endGatewayId) || b.shape === 'water') continue;
        const state = (cell >>> 12) & 15;
        const lIdx = zOff + x;
        const sky = lightSky[lIdx] / 15;
        const blk = LUT_LIGHT[id] ? 1 : lightBlk[lIdx] / 15;

        let r = 1, g = 1, bl = 1;
        if (tint && (b.name === 'short_grass' || b.name === 'fern' || b.name === 'lily_pad')) {
          const ti = (z * 16 + x) * 3;
          r = tint[ti]; g = tint[ti + 1]; bl = tint[ti + 2];
        }

        if (b.shape === 'cross') {
          const tile = tiles[id][0];
          const xA = x + 0.24, xB = x + 0.76, zA = z + 0.24, zB = z + 0.76, yT = y + 0.78;
          out.pushQuad(xA, y, zA, xB, y, zB, xB, yT, zB, xA, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
          out.pushQuad(xA, yT, zA, xB, yT, zB, xB, y, zB, xA, y, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
          out.pushQuad(xB, y, zA, xA, y, zB, xA, yT, zB, xB, yT, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
          out.pushQuad(xB, yT, zA, xA, yT, zB, xA, y, zB, xB, y, zA, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0.7, false, r, g, bl, false, false);
        } else if (b.shape === 'lily') {
          const tile = tiles[id][0];
          out.pushQuad(x + 0.06, y + 0.03, z + 0.94, x + 0.94, y + 0.03, z + 0.94, x + 0.94, y + 0.03, z + 0.06, x + 0.06, y + 0.03, z + 0.06, 0, 1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
          out.pushQuad(x + 0.06, y + 0.03, z + 0.06, x + 0.94, y + 0.03, z + 0.06, x + 0.94, y + 0.03, z + 0.94, x + 0.06, y + 0.03, z + 0.94, 0, -1, 0, 1, 1, tile, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, r, g, bl, false, false);
        } else if (b.shape === 'cactus') {
          // Vanilla cactus model: full-size side planes inset by one pixel (edge columns of the texture are the spines), full top/bottom.
          const ts = tiles[id][0], e = 0.0625;
          const below = ly > 0 ? padded[lIdx - STRIDE_Y] & 4095 : 0, above = ly + 1 < dimsY ? padded[lIdx + STRIDE_Y] & 4095 : 0;
          out.pushQuad(x, y, z + 1 - e, x + 1, y, z + 1 - e, x + 1, y + 1, z + 1 - e, x, y + 1, z + 1 - e, 0, 0, 1, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          out.pushQuad(x + 1, y, z + e, x, y, z + e, x, y + 1, z + e, x + 1, y + 1, z + e, 0, 0, -1, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          out.pushQuad(x + 1 - e, y, z + 1, x + 1 - e, y, z, x + 1 - e, y + 1, z, x + 1 - e, y + 1, z + 1, 1, 0, 0, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          out.pushQuad(x + e, y, z, x + e, y, z + 1, x + e, y + 1, z + 1, x + e, y + 1, z, -1, 0, 0, 1, 1, ts, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1);
          if (above !== id) { out.pushQuad(x, y + 1, z + 1, x + 1, y + 1, z + 1, x + 1, y + 1, z, x, y + 1, z, 0, 1, 0, 1, 1, tiles[id][2], 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1); }
          if (below !== id) { out.pushQuad(x, y, z, x + 1, y, z, x + 1, y, z + 1, x, y, z + 1, 0, -1, 0, 1, 1, tiles[id][3], 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(0, 0, 1, 1); }
        } else if (b.shape === 'door') {
          // Two-block door: 3px leaf on one edge of the cell, swinging on a left hinge. The same image shows on both sides, flipped so
          // that hinges and handle stay on the same physical edge whichever side and position the door is seen in.
          const below = ly > 0 ? padded[lIdx - STRIDE_Y] : 0;
          const upper = (state & 4) !== 0 || ((below & 4095) === id && ((below >>> 12) & 4) === 0);
          const open = (state & 8) !== 0, f = state & 3, e = open ? (f + 3) & 3 : f;
          const flip = open ? f >= 2 : f === 0 || f === 3;
          const x0 = e === 3 ? 13 : 0, x1 = e === 1 ? 3 : 16, z0 = e === 2 ? 13 : 0, z1 = e === 0 ? 3 : 16;
          DT[0] = flip ? 16 - x0 : x0; DT[3] = flip ? 16 - x1 : x1; DT[2] = flip ? 16 - z0 : z0; DT[5] = flip ? 16 - z1 : z1;
          emitBox(x, y, z, x0, 0, z0, x1, 16, z1, upper ? tiles[id][2] : tiles[id][0], sky, blk, DT, true);
        } else if (b.shape === 'fence') {
          // Fences and walls: a post plus arms only towards neighbours they connect to (same kind, or any full opaque block).
          const wall = b.name.endsWith('_wall'), tile = tiles[id][0];
          const joins = (c: number) => { if (!c) return false; const nb = BLOCKS[c & 4095]; return !!nb && (nb.shape === 'fence' ? nb.name.endsWith('_wall') === wall : isOpq(c)); };
          const cn = joins(get(x, ly, z - 1)), cs = joins(get(x, ly, z + 1)), cw = joins(get(x - 1, ly, z)), ce = joins(get(x + 1, ly, z));
          if (wall) {
            emitBox(x, y, z, 4, 0, 4, 12, 16, 12, tile, sky, blk);
            if (cn) emitBox(x, y, z, 5, 0, 0, 11, 14, 4, tile, sky, blk);
            if (cs) emitBox(x, y, z, 5, 0, 12, 11, 14, 16, tile, sky, blk);
            if (cw) emitBox(x, y, z, 0, 0, 5, 4, 14, 11, tile, sky, blk);
            if (ce) emitBox(x, y, z, 12, 0, 5, 16, 14, 11, tile, sky, blk);
          } else {
            emitBox(x, y, z, 6, 0, 6, 10, 16, 10, tile, sky, blk);
            for (let bar = 6; bar <= 12; bar += 6) {
              if (cn) emitBox(x, y, z, 7, bar, 0, 9, bar + 3, 6, tile, sky, blk);
              if (cs) emitBox(x, y, z, 7, bar, 10, 9, bar + 3, 16, tile, sky, blk);
              if (cw) emitBox(x, y, z, 0, bar, 7, 6, bar + 3, 9, tile, sky, blk);
              if (ce) emitBox(x, y, z, 10, bar, 7, 16, bar + 3, 9, tile, sky, blk);
            }
          }
        } else if (b.name === 'bed') {
          // Bed half: 6px mattress on a frame with two legs at its outer end (state bits 0-1 = direction to the head, bit 2 = head half).
          const head = (state & 4) !== 0, outer = head ? state & 3 : ((state & 3) + 2) & 3, side = head ? tiles[id][1] : tiles[id][0];
          emitBox(x, y, z, 0, 3, 0, 16, 8.9, 16, side, sky, blk);
          emitBox(x, y, z, 0, 8.9, 0, 16, 9, 16, head ? tiles[id][2] : tiles[id][3], sky, blk);
          for (let k = 0; k < 2; k++) {
            const lx = outer === 0 ? 13 : outer === 2 ? 0 : k * 13, lz = outer === 1 ? 13 : outer === 3 ? 0 : k * 13;
            emitBox(x, y, z, lx, 0, lz, lx + 3, 3, lz + 3, side, sky, blk);
          }
        } else if (b.shape === 'end_portal' || b.shape === 'end_gateway') {
          const tile = tiles[id][0];
          if (b.shape === 'end_gateway') {
            emitBox(x, y, z, 0.5, 0.5, 0.5, 15.5, 15.5, 15.5, tile, 1, 1);
          } else {
            emitBox(x, y, z, 0, 11, 0, 16, 12, 16, tile, 1, 1);
          }
        } else if (b.shape === 'end_portal_frame') {
          emitBox(x, y, z, 0, 0, 0, 16, 13, 16, tiles[id][2], sky, blk);
          if (state & 4) {
            emitBox(x, y, z, 5, 13, 5, 11, 16, 11, tiles[ID.emerald_ore]?.[0] ?? tiles[id][2], sky, 1);
          }
        } else if (b.shape === 'end_rod') {
          emitBox(x, y, z, 5, 0, 5, 11, 2, 11, tiles[ID.purpur_block]?.[0] ?? tiles[id][0], sky, 1);
          emitBox(x, y, z, 6.5, 2, 6.5, 9.5, 16, 9.5, tiles[ID.quartz_block]?.[0] ?? tiles[id][0], sky, 1);
        } else if (b.shape === 'dragon_egg') {
          const tile = tiles[id][0];
          emitBox(x, y, z, 3, 0, 3, 13, 4, 13, tile, sky, blk);
          emitBox(x, y, z, 2, 4, 2, 14, 11, 14, tile, sky, blk);
          emitBox(x, y, z, 4, 11, 4, 12, 15, 12, tile, sky, blk);
          emitBox(x, y, z, 6, 15, 6, 10, 16, 10, tile, sky, blk);
        } else if (b.shape === 'pane' && (b.name.endsWith('glass_pane') || b.name === 'iron_bars')) {
          // Glass panes & iron bars: a thin post with arms towards panes, bars, glass and full opaque blocks.
          const tile = tiles[id][0], isBars = b.name === 'iron_bars';
          const joins = (c: number) => { if (!c) return false; const nb = BLOCKS[c & 4095]; return !!nb && (isBars ? (nb.name === 'iron_bars' || isOpq(c)) : (nb.name.endsWith('glass_pane') || nb.pattern === 'glass' || isOpq(c))); };
          let cn = joins(get(x, ly, z - 1)), cs = joins(get(x, ly, z + 1)), cw = joins(get(x - 1, ly, z)), ce = joins(get(x + 1, ly, z));
          if (!cn && !cs && !cw && !ce) { if (state & 1) { cw = true; ce = true; } else { cn = true; cs = true; } }
          emitBox(x, y, z, 7, 0, 7, 9, 16, 9, tile, sky, blk);
          if (cn) emitBox(x, y, z, 7, 0, 0, 9, 16, 7, tile, sky, blk);
          if (cs) emitBox(x, y, z, 7, 0, 9, 9, 16, 16, tile, sky, blk);
          if (cw) emitBox(x, y, z, 0, 0, 7, 7, 16, 9, tile, sky, blk);
          if (ce) emitBox(x, y, z, 9, 0, 7, 16, 16, 9, tile, sky, blk);
        } else if (b.shape === 'torch' && b.name !== 'lantern' && b.name !== 'brewing_stand') {
          // Torch, lever and buttons: attached to the floor, a wall or the ceiling (state bits 0-2); bit 3 = lever on / button pressed.
          const at = state & 7, on = (state & 8) !== 0;
          if (b.name === 'lever') {
            const bb = LEVER_BASE16[at] ?? LEVER_BASE16[0], sk = (LEVER_STICK16[at] ?? LEVER_STICK16[0])[on ? 1 : 0];
            emitBox(x, y, z, bb[0], bb[1], bb[2], bb[3], bb[4], bb[5], tiles[id][3], sky, blk);
            emitBox(x, y, z, sk[0], sk[1], sk[2], sk[3], sk[4], sk[5], tiles[id][0], sky, blk, sk[6] === 1 ? STICK_UP : STICK_DOWN, false, sk[6], sk[7], sk[8]);
          } else if (b.name.endsWith('_button')) {
            const bb = BUTTON16[at] ?? BUTTON16[0];
            let x0 = bb[0], y0 = bb[1], z0 = bb[2], x1 = bb[3], y1 = bb[4], z1 = bb[5];
            if (on) { if (at === 1) x1 = 1; else if (at === 2) x0 = 15; else if (at === 3) z1 = 1; else if (at === 4) z0 = 15; else if (at === 5) y0 = 15; else y1 = 1; }
            emitBox(x, y, z, x0, y0, z0, x1, y1, z1, tiles[id][0], sky, blk);
          } else {
            const tb = TORCH16[at] ?? TORCH16[0];
            emitBox(x, y, z, tb[0], tb[1], tb[2], tb[3], tb[4], tb[5], tiles[id][0], sky, blk, STICK_UP, false, tb[6], tb[7], tb[8]);
          }
        } else {
          const boxes = modelBoxes(b, state);
          for (const box of boxes) {
            const [bx0, by0, bz0, bx1, by1, bz1] = box;
            const x0 = x + bx0, y0 = y + by0, z0 = z + bz0, x1 = x + bx1, y1 = y + by1, z1 = z + bz1;
            const t0 = tiles[id][localFaceForState(b, state, 4)];
            const t1 = tiles[id][localFaceForState(b, state, 5)];
            const t2 = tiles[id][localFaceForState(b, state, 2)];
            const t3 = tiles[id][localFaceForState(b, state, 3)];
            const t4 = tiles[id][localFaceForState(b, state, 0)];
            const t5 = tiles[id][localFaceForState(b, state, 1)];
            out.pushQuad(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1, 1, 1, t0, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(bx0, by0, bx1, by1);
            out.pushQuad(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0, 0, -1, 1, 1, t1, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(1 - bx1, by0, 1 - bx0, by1);
            out.pushQuad(x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0, 1, 0, 1, 1, t2, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(bx0, 1 - bz1, bx1, 1 - bz0);
            out.pushQuad(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0, 1, 1, t3, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(bx0, bz0, bx1, bz1);
            out.pushQuad(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, 1, 0, 0, 1, 1, t4, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(1 - bz1, by0, 1 - bz0, by1);
            out.pushQuad(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1, 0, 0, 1, 1, t5, 0, 0, 0, 0, sky, sky, sky, sky, blk, blk, blk, blk, 0, false, 1, 1, 1, false, false); out.uvRect(bz0, by0, bz1, by1);
          }
        }
      }
    }
  }

  return { solid: out.pack(), water: water.pack() };
}
