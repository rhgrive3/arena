import * as THREE from 'three';
import { makeAtlasTexture, makeAtlasDataArray, atlasCanvas, canvas } from '../textures/atlas';
import { random } from '../input/math';
import type { Settings, Dimension } from '../game/types';

export class Environment {
  atlas = makeAtlasTexture();
  /** Every block tile as its own mip-mapped layer: repeats natively across merged quads and stays stable when minified. */
  atlasArray = makeAtlasDataArray();
  /** Shadow pass material for chunks: alpha-tests against the same tile layers as the colour pass. */
  depthMaterial: THREE.MeshDepthMaterial;
  material: THREE.MeshLambertMaterial;
  fallback: THREE.MeshLambertMaterial;
  water: THREE.ShaderMaterial;
  sky: THREE.Mesh;
  skyMaterial: THREE.ShaderMaterial;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  sunSprite: THREE.Mesh;
  moon: THREE.Mesh;
  moonMat: THREE.MeshBasicMaterial;
  glow: THREE.Sprite;
  stars: THREE.Points;
  clouds: THREE.InstancedMesh;
  cloudMat: THREE.MeshLambertMaterial;
  rays: THREE.Group;
  rain: THREE.Points;
  rainMat: THREE.ShaderMaterial;
  ambientParticles: THREE.Points;
  ambientMat: THREE.ShaderMaterial;
  weather: 'clear' | 'rain' | 'storm' = 'clear';
  lightning = 0;

  uniforms = {
    uTime: { value: 0 },
    uAtlasSize: { value: new THREE.Vector2(atlasCanvas.width, atlasCanvas.height) },
    uDay: { value: 1 },
    uDim: { value: 0 },
    uRain: { value: 0 },
    uHeldLight: { value: new THREE.Vector4(0, 0, 0, 0) },
    uAtlasArr: { value: this.atlasArray as THREE.Texture },
  };
  waterUniforms = {
    uTime: { value: 0 },
    uSun: { value: new THREE.Vector3(-0.5, 0.8, 0.3) },
    uFog: { value: new THREE.Color('#bbd8d8') },
    uNear: { value: 52 },
    uFar: { value: 120 },
    uDay: { value: 1 },
    uSkyTop: { value: new THREE.Color('#5eaee0') },
    uSkyHorizon: { value: new THREE.Color('#cce4dc') },
    uUnderwater: { value: 0 },
  };

  failed = false;
  daylight = 1;
  private lastMoonPhase = -1;
  private moonTexs: THREE.CanvasTexture[] = [];

  // Reusable scratch objects (zero per-frame allocations)
  private _sunDir = new THREE.Vector3();
  private _target = new THREE.Vector3();
  private _lightRight = new THREE.Vector3();
  private _lightUp = new THREE.Vector3();
  private _worldUp = new THREE.Vector3(0, 1, 0);
  private _top = new THREE.Color();
  private _horizon = new THREE.Color();
  private _cNightTop = new THREE.Color('#0b152a');
  private _cDayTop = new THREE.Color('#5eaee0');
  private _cNightHor = new THREE.Color('#1c2a40');
  private _cDayHor = new THREE.Color('#cce4dc');
  private _cSunset = new THREE.Color('#f09d62');
  private _cNetherTop = new THREE.Color('#421c1a');
  private _cNetherHor = new THREE.Color('#8f3e28');
  private _cEndTop = new THREE.Color('#141020');
  private _cEndHor = new THREE.Color('#352845');
  private _cSunDay = new THREE.Color('#fff1d4');
  private _cSunTwil = new THREE.Color('#ff9452');
  private _cCloudDay = new THREE.Color('#fffef5');
  private _cCloudTwil = new THREE.Color('#ffbfa0');
  private _cCloudNight = new THREE.Color('#3f4f6e');
  private _cCloudStorm = new THREE.Color('#5a6778');

  constructor(public scene: THREE.Scene, public renderer: THREE.WebGLRenderer, settings: Settings) {
    this.material = new THREE.MeshLambertMaterial({
      map: this.atlas,
      vertexColors: true,
      side: THREE.FrontSide,
    });
    this.fallback = new THREE.MeshLambertMaterial({ vertexColors: true });

    this.material.onBeforeCompile = (shader) => {
      Object.assign(shader.uniforms, this.uniforms);
      shader.vertexShader =
        'attribute float tile; attribute float wind; attribute vec2 aLight; varying float vTile; varying vec2 vLight; varying vec3 vWorldPos; uniform float uTime;\n' +
        shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace(
        '#include <uv_vertex>',
        '#include <uv_vertex>\nvTile = tile;\nvLight = aLight;',
      );
      shader.vertexShader = shader.vertexShader.replace(
        '#include <begin_vertex>',
        '#include <begin_vertex>\nif (wind > 0.0) { vec2 windPos = (modelMatrix * vec4(position, 1.0)).xz; transformed.x += sin(windPos.y * 0.8 + uTime * 1.45) * wind * 0.08; transformed.z += cos(windPos.x * 0.75 + uTime * 1.1) * wind * 0.055; }',
      );
      shader.vertexShader = shader.vertexShader.replace(
        '#include <project_vertex>',
        '#include <project_vertex>\nvWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;',
      );

      shader.fragmentShader =
        'varying float vTile; varying vec2 vLight; varying vec3 vWorldPos; uniform highp sampler2DArray uAtlasArr; uniform float uTime; uniform float uDay; uniform float uDim; uniform float uRain; uniform vec4 uHeldLight;\n' +
        shader.fragmentShader;
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <map_fragment>',
        `vec3 atlasUVW = vec3(vMapUv.x, 1.0 - vMapUv.y, floor(vTile + 0.5));
        vec4 sampledDiffuseColor = texture(uAtlasArr, atlasUVW);
        vec2 texelDx = dFdx(vMapUv) * 16.0;
        vec2 texelDy = dFdy(vMapUv) * 16.0;
        float texLod = clamp(0.5 * log2(max(dot(texelDx, texelDx), dot(texelDy, texelDy)) + 0.000001), 0.0, 3.0);
        if (sampledDiffuseColor.a < mix(0.35, 0.18, texLod / 3.0)) discard;
        sampledDiffuseColor.a = 1.0;
        if (uRain > 0.01) sampledDiffuseColor.rgb *= mix(1.0, 0.88, uRain);
        diffuseColor *= sampledDiffuseColor;`,
      );
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <lights_fragment_end>',
        `#include <lights_fragment_end>
        float skyMask = uDim > 0.5 ? 0.42 : clamp(pow(vLight.x, 1.15), 0.0, 1.0);
        float dayLevel = uDim > 0.5 ? 0.55 : mix(0.14, 1.0, uDay);
        float flicker = 0.94 + 0.06 * sin(uTime * 7.5 + vWorldPos.x * 1.7 + vWorldPos.z * 2.3);
        float heldDist = length(vWorldPos - uHeldLight.xyz);
        float heldGlow = uHeldLight.w * pow(clamp(1.0 - heldDist / 11.0, 0.0, 1.0), 1.7);
        float blockVal = max(pow(vLight.y, 1.2) * flicker, heldGlow);
        reflectedLight.directDiffuse *= skyMask;
        float caveMin = uDim > 1.5 ? 0.22 : uDim > 0.5 ? 0.42 : 0.055;
        reflectedLight.indirectDiffuse *= max(skyMask * dayLevel, caveMin);
        totalEmissiveRadiance += diffuseColor.rgb * vec3(1.05, 0.72, 0.36) * blockVal * 1.15;`,
      );
    };
    this.material.customProgramCacheKey = () => 'voxel-array-v6';

    // Shadows: without this, three.js alpha-tests the shadow pass against `map` using the raw quad UVs, which punches random holes in shadows.
    // Same settings as three.js' own shadow depth material (default packing: r187 reads shadows from the depth texture).
    this.depthMaterial = new THREE.MeshDepthMaterial();
    this.depthMaterial.onBeforeCompile = (shader) => {
      shader.uniforms.uAtlasArr = this.uniforms.uAtlasArr;
      shader.vertexShader = 'attribute float tile; varying float vTile; varying vec2 vAtlasUv;\n' +
        shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvTile = tile;\nvAtlasUv = uv;');
      shader.fragmentShader = 'uniform highp sampler2DArray uAtlasArr; varying float vTile; varying vec2 vAtlasUv;\n' +
        shader.fragmentShader.replace('#include <map_fragment>', 'if (texture(uAtlasArr, vec3(vAtlasUv.x, 1.0 - vAtlasUv.y, floor(vTile + 0.5))).a < 0.35) discard;');
    };
    this.depthMaterial.customProgramCacheKey = () => 'voxel-depth-v1';

    renderer.debug.checkShaderErrors = true;
    renderer.debug.onShaderError = (...args: any[]) => {
      this.failed = true;
      const program = args[1];
      const message = program?.diagnostics?.fragmentShader?.log || 'Shader compilation fallback';
      console.warn('[Shader safety fallback]', message);
    };

    // Water: one continuous surface. Colour and transparency follow the per-vertex depth from the mesher (clear over the
    // shallows, deep blue offshore), the sky is reflected with a Fresnel term, ripples are a sum of directional waves in
    // world space (so they line up across chunks) and fade with distance to avoid shimmer.
    this.water = new THREE.ShaderMaterial({
      uniforms: this.waterUniforms,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      vertexShader: `attribute float tile; attribute vec2 aLight; uniform float uTime;
      varying float vFluid; varying vec3 vWorld; varying vec3 vNormal; varying float vDepth; varying float vShore; varying float vTop;
      void main(){
        vec4 world = modelMatrix * vec4(position, 1.0);
        vTop = step(0.5, normal.y);
        world.y += vTop * (sin(world.x * 0.55 + uTime * 1.1) + sin(world.z * 0.63 - uTime * 0.9)) * (tile > 0.5 ? 0.008 : 0.016);
        vWorld = world.xyz;
        vNormal = normalize(mat3(modelMatrix) * normal);
        vFluid = tile;
        vDepth = aLight.y;
        vShore = aLight.x;
        gl_Position = projectionMatrix * viewMatrix * world;
      }`,
      fragmentShader: `uniform float uTime; uniform float uDay; uniform float uUnderwater; uniform float uNear; uniform float uFar;
      uniform vec3 uSun; uniform vec3 uFog; uniform vec3 uSkyTop; uniform vec3 uSkyHorizon;
      varying float vFluid; varying vec3 vWorld; varying vec3 vNormal; varying float vDepth; varying float vShore; varying float vTop;
      float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float vnoise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y); }
      void main(){
        vec3 toCam = cameraPosition - vWorld;
        float dist = length(toCam);
        vec3 view = toCam / dist;
        float fog = smoothstep(uNear, uFar, dist);
        float t = uTime;
        vec2 wp = vWorld.xz;
        if (vFluid > 0.5) {
          vec2 lp = floor(wp * 16.0) / 16.0;  // snap to the 16px block grid so lava keeps a pixel-art look
          float flow = vnoise(lp * 0.55 + vec2(t * 0.05, -t * 0.04)) * 0.65 + vnoise(lp * 1.7 - vec2(t * 0.08, t * 0.06)) * 0.35;
          vec3 col = mix(vec3(0.62, 0.11, 0.01), vec3(1.0, 0.56, 0.07), smoothstep(0.25, 0.75, flow));
          col += vec3(1.0, 0.72, 0.25) * smoothstep(0.72, 0.95, flow) * 0.7;
          gl_FragColor = vec4(mix(col, uFog, fog * 0.6), 1.0);
        } else {
          vec2 g = vec2(0.0);
          g += vec2(0.92, 0.39) * cos(dot(wp, vec2(0.92, 0.39)) * 0.9 + t * 1.2) * 0.050;
          g += vec2(-0.45, 0.89) * cos(dot(wp, vec2(-0.45, 0.89)) * 1.7 - t * 1.6) * 0.036;
          g += vec2(0.31, -0.95) * cos(dot(wp, vec2(0.31, -0.95)) * 3.1 + t * 2.2) * 0.026;
          g += vec2(-0.80, -0.60) * cos(dot(wp, vec2(-0.80, -0.60)) * 5.3 - t * 2.9) * 0.016;
          g /= 1.0 + dist * 0.035;
          vec3 n = vTop > 0.5 ? normalize(vec3(-g.x, 1.0, -g.y)) : normalize(vNormal);
          bool below = !gl_FrontFacing;
          if (below) n = -n;
          float ndv = max(dot(view, n), 0.0);
          float fres = min(0.8, 0.02 + 0.98 * pow(1.0 - ndv, 5.0));
          vec3 r = reflect(-view, n);
          r.y = abs(r.y);
          vec3 sky = mix(uSkyHorizon, uSkyTop, pow(clamp(r.y, 0.0, 1.0), 0.32));
          float sd = max(dot(r, normalize(uSun)), 0.0);
          sky += vec3(1.0, 0.93, 0.78) * (pow(sd, 900.0) * 6.0 + pow(sd, 60.0) * 0.22) * step(0.0, uSun.y) * uDay;
          float lightK = mix(0.16, 1.0, uDay);
          float dk = smoothstep(0.05, 0.9, vDepth);
          vec3 body = mix(vec3(0.07, 0.42, 0.50), vec3(0.012, 0.15, 0.30), dk) * lightK;
          vec3 col = mix(body, sky, fres);
          float alpha = mix(mix(0.6, 0.9, dk), 1.0, fres);
          // Thin, broken foam line only where the surface actually touches land.
          float foam = smoothstep(0.22, 0.5, vShore) * smoothstep(0.3, 0.72, vnoise(wp * 2.6 + vec2(t * 0.22, -t * 0.16))) * 0.45 * vTop;
          col = mix(col, vec3(0.93, 0.97, 1.0) * lightK, foam);
          alpha = max(alpha, foam);
          if (below) { col = mix(vec3(0.03, 0.2, 0.3) * lightK, sky, 0.35); alpha = 0.75; }
          if (uUnderwater > 0.5) fog = min(1.0, fog * 1.6 + 0.15);
          gl_FragColor = vec4(mix(col, uFog, fog), alpha);
        }
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
    });

    this.skyMaterial = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uTop: { value: new THREE.Color('#5eaee0') },
        uHorizon: { value: new THREE.Color('#cce4dc') },
        uSunset: { value: new THREE.Color('#f09d62') },
        uSun: { value: new THREE.Vector3(-0.5, 0.8, 0.3) },
        uDay: { value: 1 },
        uTwilight: { value: 0 },
      },
      vertexShader: 'varying vec3 vDirection; void main(){ vDirection = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: `varying vec3 vDirection; uniform vec3 uTop; uniform vec3 uHorizon; uniform vec3 uSunset; uniform vec3 uSun; uniform float uDay; uniform float uTwilight;
      void main(){
        vec3 d = normalize(vDirection);
        float h = pow(max(d.y, 0.0), 0.5);
        vec3 baseHorizon = mix(uHorizon, uSunset, uTwilight * 0.72);
        vec3 col = mix(baseHorizon, uTop, h);
        float s = max(dot(d, normalize(uSun)), 0.0);
        col += mix(vec3(1.0, 0.78, 0.44), vec3(1.0, 0.46, 0.22), uTwilight) * pow(s, 32.0) * (0.24 + uTwilight * 0.38);
        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
    });

    this.sky = new THREE.Mesh(new THREE.SphereGeometry(380, 20, 14), this.skyMaterial);
    this.sky.renderOrder = -100;
    scene.add(this.sky);

    this.sun = new THREE.DirectionalLight('#fff1d4', 2.2);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(settings.quality === 'ultra' ? 2048 : 1024, settings.quality === 'ultra' ? 2048 : 1024);
    Object.assign(this.sun.shadow.camera, { left: -54, right: 54, top: 54, bottom: -54, near: 1, far: 190 });
    this.sun.shadow.bias = -0.0018;
    this.sun.shadow.normalBias = 0.18;
    this.sun.shadow.radius = 2;
    scene.add(this.sun, this.sun.target);

    this.hemi = new THREE.HemisphereLight('#d7ebff', '#7b7c4e', 1.45);
    scene.add(this.hemi);

    const sunCanvas = canvas(16);
    const sctx = sunCanvas.getContext('2d') as CanvasRenderingContext2D;
    sctx.fillStyle = '#fff5ce';
    sctx.fillRect(0, 0, 16, 16);
    sctx.fillStyle = '#ffffff';
    sctx.fillRect(3, 3, 10, 10);
    const sunTex = new THREE.CanvasTexture(sunCanvas as HTMLCanvasElement);
    sunTex.magFilter = THREE.NearestFilter;
    sunTex.colorSpace = THREE.SRGBColorSpace;

    // Pre-generate 8 moon phase textures
    for (let phase = 0; phase < 8; phase++) {
      const mc = canvas(16);
      const mctx = mc.getContext('2d') as CanvasRenderingContext2D;
      mctx.fillStyle = '#182235';
      mctx.fillRect(0, 0, 16, 16);
      mctx.fillStyle = '#e2eae6';
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const lit =
            phase === 0 ? true :
            phase === 1 ? x < 12 :
            phase === 2 ? x < 8 :
            phase === 3 ? x < 4 :
            phase === 4 ? false :
            phase === 5 ? x >= 12 :
            phase === 6 ? x >= 8 :
            x >= 4;
          if (lit) mctx.fillRect(x, y, 1, 1);
        }
      }
      mctx.fillStyle = 'rgba(130, 148, 152, 0.55)';
      mctx.fillRect(3, 3, 4, 4);
      mctx.fillRect(10, 8, 3, 5);
      mctx.fillRect(4, 12, 3, 2);
      const mt = new THREE.CanvasTexture(mc as HTMLCanvasElement);
      mt.magFilter = THREE.NearestFilter;
      mt.colorSpace = THREE.SRGBColorSpace;
      this.moonTexs.push(mt);
    }

    this.sunSprite = new THREE.Mesh(
      new THREE.PlaneGeometry(14, 14),
      new THREE.MeshBasicMaterial({ map: sunTex, fog: false, toneMapped: false }),
    );
    this.moonMat = new THREE.MeshBasicMaterial({ map: this.moonTexs[0], fog: false, toneMapped: false });
    this.moon = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), this.moonMat);
    scene.add(this.sunSprite, this.moon);

    const glowCanvas = canvas(64);
    const gc = glowCanvas.getContext('2d') as CanvasRenderingContext2D;
    const gradient = gc.createRadialGradient(32, 32, 0, 32, 32, 32);
    gradient.addColorStop(0, 'rgba(255,238,171,.62)');
    gradient.addColorStop(0.22, 'rgba(255,226,153,.22)');
    gradient.addColorStop(1, 'rgba(255,220,130,0)');
    gc.fillStyle = gradient;
    gc.fillRect(0, 0, 64, 64);
    this.glow = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: new THREE.CanvasTexture(glowCanvas as HTMLCanvasElement),
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        fog: false,
      }),
    );
    this.glow.scale.set(78, 78, 1);
    scene.add(this.glow);

    const rnd = random(9841);
    const starPositions: number[] = [];
    for (let i = 0; i < 750; i++) {
      const a = rnd() * Math.PI * 2;
      const y = rnd() * 2 - 1;
      const r = Math.sqrt(1 - y * y);
      starPositions.push(Math.cos(a) * r * 300, y * 300, Math.sin(a) * r * 300);
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.Float32BufferAttribute(starPositions, 3));
    this.stars = new THREE.Points(
      sg,
      new THREE.PointsMaterial({
        color: '#e5f1ff',
        size: 1.35,
        sizeAttenuation: false,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        fog: false,
      }),
    );
    scene.add(this.stars);

    this.cloudMat = new THREE.MeshLambertMaterial({ color: '#fffef5', transparent: true, opacity: 0.9 });
    this.clouds = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), this.cloudMat, 70);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < 70; i++) {
      const group = Math.floor(i / 5);
      dummy.position.set(
        (group % 5) * 62 - 140 + rand(rnd, 16),
        192 + Math.floor(group / 5) * 3.5 + rand(rnd, 1.5),
        Math.floor(group / 5) * 76 - 150 + rand(rnd, 14),
      );
      dummy.scale.set(10 + rnd() * 14, 1.8 + rnd() * 2, 8 + rnd() * 11);
      dummy.updateMatrix();
      this.clouds.setMatrixAt(i, dummy.matrix);
    }
    this.clouds.instanceMatrix.needsUpdate = true;
    scene.add(this.clouds);

    this.rays = new THREE.Group();
    const rayMat = new THREE.MeshBasicMaterial({
      color: '#fff0c5',
      transparent: true,
      opacity: 0.008,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
    });
    for (let i = 0; i < 3; i++) {
      const ray = new THREE.Mesh(new THREE.PlaneGeometry(2.5 + i * 0.7, 90), rayMat);
      ray.position.set(-16 + i * 16, 40, -30 - i * 8);
      ray.rotation.z = -0.45;
      this.rays.add(ray);
    }
    scene.add(this.rays);

    const rainGeo = new THREE.BufferGeometry();
    const drops: number[] = [];
    const speeds: number[] = [];
    for (let i = 0; i < 650; i++) {
      drops.push((Math.random() - 0.5) * 84, Math.random() * 48, (Math.random() - 0.5) * 84);
      speeds.push(20 + Math.random() * 8);
    }
    rainGeo.setAttribute('position', new THREE.Float32BufferAttribute(drops, 3));
    rainGeo.setAttribute('aSpeed', new THREE.Float32BufferAttribute(speeds, 1));
    this.rainMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uOpacity: { value: 0 }, uColor: { value: new THREE.Color('#bcd7ee') } },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute float aSpeed; uniform float uTime; void main(){ vec3 p = position; p.y = mod(p.y - uTime * aSpeed, 48.0); vec4 mv = modelViewMatrix * vec4(p, 1.0); gl_PointSize = clamp(44.0 / max(1.0, -mv.z), 1.5, 4.2); gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform float uOpacity; uniform vec3 uColor; void main(){ gl_FragColor = vec4(uColor, uOpacity); }`,
    });
    this.rain = new THREE.Points(rainGeo, this.rainMat);
    this.rain.frustumCulled = false;
    scene.add(this.rain);

    const ambGeo = new THREE.BufferGeometry();
    const ambPos: number[] = [];
    const ambPhase: number[] = [];
    for (let i = 0; i < 180; i++) {
      ambPos.push((Math.random() - 0.5) * 56, Math.random() * 18, (Math.random() - 0.5) * 56);
      ambPhase.push(Math.random() * 6.283);
    }
    ambGeo.setAttribute('position', new THREE.Float32BufferAttribute(ambPos, 3));
    ambGeo.setAttribute('aPhase', new THREE.Float32BufferAttribute(ambPhase, 1));
    this.ambientMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uColor: { value: new THREE.Color('#f6b8cc') }, uOpacity: { value: 0.7 }, uFall: { value: 0.6 } },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute float aPhase; uniform float uTime; uniform float uFall; varying float vGlow;
      void main(){ vec3 p = position; p.y = mod(p.y - uTime * uFall + sin(uTime * 0.7 + aPhase) * 1.2, 18.0); p.x += sin(uTime * 0.9 + aPhase) * 1.4; p.z += cos(uTime * 0.8 + aPhase * 1.3) * 1.4; vGlow = 0.6 + 0.4 * sin(uTime * 2.5 + aPhase * 2.0); vec4 mv = modelViewMatrix * vec4(p, 1.0); gl_PointSize = clamp(50.0 / max(1.0, -mv.z), 2.0, 5.5); gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform float uOpacity; uniform vec3 uColor; varying float vGlow; void main(){ vec2 c = gl_PointCoord - 0.5; if(dot(c,c) > 0.25) discard; gl_FragColor = vec4(uColor * vGlow, uOpacity); }`,
    });
    this.ambientParticles = new THREE.Points(ambGeo, this.ambientMat);
    this.ambientParticles.frustumCulled = false;
    scene.add(this.ambientParticles);

    scene.fog = new THREE.Fog('#cce4dc', 52, 120);
  }

  markShadow() {
    this.renderer.shadowMap.needsUpdate = true;
  }

  triggerLightning() {
    this.lightning = 1.0;
  }

  update(
    elapsed: number,
    time: number,
    camera: THREE.Camera,
    dimension: Dimension,
    settings: Settings,
    weather: 'clear' | 'rain' | 'storm' = 'clear',
    biome = 'plains',
    moonPhase = 0,
    heldLightIntensity = 0,
    underwater = false,
  ) {
    this.weather = weather;
    this.lightning = Math.max(0, this.lightning - 0.08);
    this.uniforms.uTime.value = elapsed;
    this.waterUniforms.uTime.value = elapsed;
    this.rainMat.uniforms.uTime.value = elapsed;
    this.ambientMat.uniforms.uTime.value = elapsed;
    this.uniforms.uDim.value = dimension === 'nether' ? 1 : dimension === 'end' ? 2 : 0;
    this.uniforms.uRain.value = dimension === 'overworld' && weather !== 'clear' ? (weather === 'storm' ? 1 : 0.7) : 0;
    this.uniforms.uHeldLight.value.set(camera.position.x, camera.position.y, camera.position.z, heldLightIntensity);

    if (this.failed) this.material.visible = false;

    const angle = time * Math.PI * 2;
    const sinA = Math.sin(angle);
    const day = Math.max(0, sinA);
    const rainDim = weather === 'storm' ? 0.55 : weather === 'rain' ? 0.78 : 1.0;
    const effDay = Math.min(1, day * rainDim + this.lightning * 0.85);
    const twilight = dimension === 'overworld' ? Math.max(0, 1 - Math.abs(sinA) * 3.2) : 0;
    this._sunDir.set(-0.6, sinA, Math.cos(angle) * 0.55).normalize();
    this.daylight = day;
    this.uniforms.uDay.value = effDay;
    this.waterUniforms.uDay.value = effDay;

    if (moonPhase !== this.lastMoonPhase) {
      this.lastMoonPhase = moonPhase;
      this.moonMat.map = this.moonTexs[((moonPhase % 8) + 8) % 8];
      this.moonMat.needsUpdate = true;
    }

    const p = camera.position;
    this.sky.position.copy(p);
    this.stars.position.copy(p);
    (this.stars.material as THREE.PointsMaterial).opacity =
      dimension === 'end' ? 0.55 : dimension === 'overworld' ? Math.pow(1 - day, 3) * (weather === 'clear' ? 0.92 : 0.15) : 0;

    // The shadow frustum follows the camera in whole shadow-map texels (measured in light space), so shadow edges do not crawl
    // when the map is re-rendered after the player moves.
    const shadowTexel = 108 / this.sun.shadow.mapSize.x;
    this._lightRight.crossVectors(this._worldUp, this._sunDir);
    if (this._lightRight.lengthSq() < 1e-6) this._lightRight.set(1, 0, 0);
    this._lightRight.normalize();
    this._lightUp.crossVectors(this._sunDir, this._lightRight).normalize();
    this._target.set(p.x, 18, p.z);
    const snapA = Math.round(this._target.dot(this._lightRight) / shadowTexel) * shadowTexel;
    const snapB = Math.round(this._target.dot(this._lightUp) / shadowTexel) * shadowTexel;
    const snapC = this._target.dot(this._sunDir);
    this._target.set(0, 0, 0).addScaledVector(this._lightRight, snapA).addScaledVector(this._lightUp, snapB).addScaledVector(this._sunDir, snapC);
    this.sun.target.position.copy(this._target);
    this.sun.position.copy(this._target).addScaledVector(this._sunDir, 100);
    this.sun.intensity = dimension === 'overworld' ? (0.12 + effDay * 2.05) : dimension === 'nether' ? 0.45 : 0.65;
    this.sun.color.copy(this._cSunDay).lerp(this._cSunTwil, twilight * 0.75);
    this.hemi.intensity = dimension === 'overworld' ? (0.35 + effDay * 1.2) : dimension === 'nether' ? 0.95 : 0.85;

    this.sunSprite.position.copy(p).addScaledVector(this._sunDir, 260);
    this.sunSprite.lookAt(p);
    this.moon.position.copy(p).addScaledVector(this._sunDir, -260);
    this.moon.lookAt(p);
    this.glow.position.copy(this.sunSprite.position);
    this.sunSprite.visible = dimension === 'overworld' && day > 0.02;
    this.glow.visible = dimension === 'overworld' && day > 0.02 && weather === 'clear';
    this.moon.visible = dimension === 'overworld' && day < 0.25;

    if (dimension === 'nether') {
      if (biome === 'warped_forest') {
        this._top.set('#11292e');
        this._horizon.set('#23646e');
      } else if (biome === 'soul_sand_valley') {
        this._top.set('#14282e');
        this._horizon.set('#255866');
      } else if (biome === 'basalt_deltas') {
        this._top.set('#2b292e');
        this._horizon.set('#59555e');
      } else if (biome === 'crimson_forest') {
        this._top.set('#471111');
        this._horizon.set('#8f2020');
      } else {
        this._top.copy(this._cNetherTop);
        this._horizon.copy(this._cNetherHor);
      }
    } else if (dimension === 'end') {
      this._top.copy(this._cEndTop);
      this._horizon.copy(this._cEndHor);
    } else {
      this._top.copy(this._cNightTop).lerp(this._cDayTop, effDay);
      this._horizon.copy(this._cNightHor).lerp(this._cDayHor, effDay);
      if (twilight > 0.01 && weather === 'clear') this._horizon.lerp(this._cSunset, twilight * 0.55);
      if (this.lightning > 0.05) {
        this._top.lerp(this._cCloudDay, this.lightning * 0.5);
        this._horizon.lerp(this._cCloudDay, this.lightning * 0.6);
      }
    }

    this.skyMaterial.uniforms.uTop.value.copy(this._top);
    this.skyMaterial.uniforms.uHorizon.value.copy(this._horizon);
    this.skyMaterial.uniforms.uSun.value.copy(this._sunDir);
    this.skyMaterial.uniforms.uDay.value = effDay;
    this.skyMaterial.uniforms.uTwilight.value = twilight;

    const fog = this.scene.fog as THREE.Fog;
    if (underwater) {
      fog.color.set('#145a6e');
      fog.near = 2;
      fog.far = 28;
    } else {
      fog.color.copy(this._horizon);
      fog.near = settings.distance * 16 * 0.56;
      fog.far = settings.distance * 16 * 1.35;
    }
    this.waterUniforms.uFog.value.copy(fog.color);
    this.waterUniforms.uSun.value.copy(this._sunDir);
    this.waterUniforms.uNear.value = fog.near;
    this.waterUniforms.uFar.value = fog.far;
    this.waterUniforms.uSkyTop.value.copy(this._top);
    this.waterUniforms.uSkyHorizon.value.copy(this._horizon);
    this.waterUniforms.uUnderwater.value = underwater ? 1 : 0;

    this.clouds.position.x = Math.sin(elapsed * 0.006) * 20;
    this.clouds.visible = dimension === 'overworld';
    this.cloudMat.color.copy(this._cCloudNight).lerp(this._cCloudDay, day);
    if (twilight > 0.05) this.cloudMat.color.lerp(this._cCloudTwil, twilight * 0.65);
    if (weather !== 'clear') this.cloudMat.color.lerp(this._cCloudStorm, 0.55);

    this.rays.visible = settings.bloom && dimension === 'overworld' && day > 0.2 && weather === 'clear' && !underwater;
    this.rain.visible = dimension === 'overworld' && weather !== 'clear';
    this.rainMat.uniforms.uOpacity.value = weather === 'storm' ? 0.65 : weather === 'rain' ? 0.44 : 0;
    this.rain.position.set(Math.round(p.x / 16) * 16, 16, Math.round(p.z / 16) * 16);

    this.ambientParticles.position.set(p.x, Math.max(18, p.y - 4), p.z);
    if (dimension === 'nether') {
      this.ambientParticles.visible = true;
      const pCol = biome === 'warped_forest' ? '#4de8d6' : biome === 'soul_sand_valley' ? '#63d8f2' : biome === 'basalt_deltas' ? '#b8b4bd' : biome === 'crimson_forest' ? '#ff5252' : '#ff9e44';
      this.ambientMat.uniforms.uColor.value.set(pCol);
      this.ambientMat.uniforms.uOpacity.value = 0.68;
      this.ambientMat.uniforms.uFall.value = -0.5;
    } else if (dimension === 'end') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#b87cff');
      this.ambientMat.uniforms.uOpacity.value = 0.55;
      this.ambientMat.uniforms.uFall.value = -0.2;
    } else if (biome === 'cherry_grove') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#f8bfd2');
      this.ambientMat.uniforms.uOpacity.value = 0.85;
      this.ambientMat.uniforms.uFall.value = 0.85;
    } else if (biome === 'desert' || biome === 'badlands') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#dfc68a');
      this.ambientMat.uniforms.uOpacity.value = 0.35;
      this.ambientMat.uniforms.uFall.value = 0.15;
    } else if (day < 0.35 && (biome === 'swamp' || biome === 'forest' || biome === 'flower_forest' || biome === 'plains')) {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#d8f56c');
      this.ambientMat.uniforms.uOpacity.value = 0.85;
      this.ambientMat.uniforms.uFall.value = 0.05;
    } else if (biome === 'forest' || biome === 'flower_forest' || biome === 'jungle') {
      this.ambientParticles.visible = true;
      this.ambientMat.uniforms.uColor.value.set('#e9f2c4');
      this.ambientMat.uniforms.uOpacity.value = 0.38;
      this.ambientMat.uniforms.uFall.value = 0.18;
    } else {
      this.ambientParticles.visible = false;
    }
  }

  dispose() {
    this.atlas.dispose();
    this.atlasArray.dispose();
    this.depthMaterial.dispose();
    this.material.dispose();
    this.fallback.dispose();
    this.water.dispose();
    this.skyMaterial.dispose();
    this.rainMat.dispose();
    this.ambientMat.dispose();
    for (const mt of this.moonTexs) mt.dispose();
    for (const obj of [this.sky, this.sunSprite, this.moon, this.stars, this.clouds, this.rain, this.ambientParticles] as Array<
      THREE.Object3D & { geometry: THREE.BufferGeometry; material: THREE.Material & { map?: THREE.Texture } }
    >) {
      obj.geometry.dispose();
      obj.material.map?.dispose();
      obj.material.dispose();
    }
    this.glow.material.map?.dispose();
    this.glow.material.dispose();
    this.sun.shadow.map?.dispose();
  }
}

function rand(r: () => number, n: number) {
  return (r() - 0.5) * n;
}
