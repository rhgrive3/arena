import * as THREE from 'three';
import ChunkWorker from '../world/chunk.worker?worker&inline';
import { Terrain, MIN_Y, HEIGHT, blockIndex, END_GATEWAY_MAIN, END_OUTER_ARRIVAL } from '../world/terrain';
import { BLOCKS, ID, resolve } from './data';
import { blockId, blockState, isAttachable, isSlabBlock, makeCell, stateForPlacement } from './blockState';
import { collisionBoxes, intersectsBox, selectionBoxes } from '../world/shapes';
import { traceVoxelRay } from '../world/raycast';
import { tilesFor, atlasTiles, handTileCanvas, blockFaceCanvases } from '../textures/atlas';
import type { MeshData } from '../world/mesher';
import { InputController } from '../input/controller';
import { Environment } from '../render/environment';
import {
  DEFAULT_SETTINGS, EMPTY_SNAPSHOT,
  type Settings, type WorldMeta, type WorldSave, type GameSnapshot, type Stack, type Dimension, type Screen,
} from './types';
import { clamp } from '../input/math';
import type { ProceduralAudio } from '../audio/sound';
import './content';
import { ParticleSystem } from '../render/particles';
import { MobManager, type Species } from '../entities/mobs';
import { Simulation } from '../systems/simulation';
import { Redstone } from '../systems/redstone';
import { RECIPES, SMELTING, FUEL, canCraft, recipeCounts } from '../systems/crafting';
import { blockDrops, blockExperience, miningTime } from '../systems/mining';
import * as SV from './survival';
import { extraLootTable } from '../world/structures';

interface Chunk {
  cx: number;
  cz: number;
  data: Uint16Array;
  solid: THREE.Mesh;
  water: THREE.Mesh;
  version: number;
  /** Vertical extent of the meshes (world Y), for the per-frame box culling. */
  minY: number;
  maxY: number;
  hasSolid: boolean;
  hasWater: boolean;
}
interface Target {
  x: number;
  y: number;
  z: number;
  id: number;
  normal: THREE.Vector3;
  distance: number;
}
interface WorkerSlot {
  worker: Worker;
  busy: boolean;
  key?: string;
  epoch?: number;
  /** The tile table is posted to a worker only once. */
  tilesSent?: boolean;
}
interface DimensionStore {
  edits: Map<string, number>;
  containers: Record<string, (Stack | null)[]>;
  furnaces: Record<string, { burn: number; progress: number }>;
}

const HELD_LIGHT_ITEMS = new Set(['torch', 'lantern', 'glowstone', 'shroomlight', 'crying_obsidian', 'end_rod', 'sea_lantern', 'lava_bucket', 'redstone_lamp', 'end_portal', 'end_gateway', 'fire']);

// Loot for chests that came with the world (vanilla-style tables): [item, min, max, weight].
const LOOT: Record<string, { rolls: [number, number]; items: [string, number, number, number][] }> = {
  village: { rolls: [3, 8], items: [['bread', 1, 4, 15], ['apple', 1, 5, 15], ['potato', 1, 7, 10], ['carrot', 4, 8, 10], ['wheat', 1, 7, 8], ['wheat_seeds', 1, 5, 8], ['oak_sapling', 1, 2, 5], ['coal', 1, 4, 6], ['stick', 1, 3, 6], ['iron_ingot', 1, 3, 3], ['emerald', 1, 4, 2], ['dandelion', 1, 1, 2], ['poppy', 1, 1, 2]] },
  dungeon: { rolls: [6, 11], items: [['bone', 1, 8, 10], ['rotten_flesh', 1, 8, 10], ['gunpowder', 1, 8, 10], ['string', 1, 8, 10], ['wheat', 1, 4, 20], ['bread', 1, 1, 20], ['coal', 1, 4, 15], ['redstone', 1, 4, 15], ['iron_ingot', 1, 4, 10], ['gold_ingot', 1, 4, 5], ['bucket', 1, 1, 10], ['saddle', 1, 1, 20], ['golden_apple', 1, 1, 15], ['wheat_seeds', 2, 4, 10], ['diamond', 1, 1, 2]] },
  temple: { rolls: [5, 9], items: [['diamond', 1, 3, 5], ['iron_ingot', 1, 5, 15], ['gold_ingot', 2, 7, 15], ['emerald', 1, 3, 15], ['bone', 4, 6, 25], ['rotten_flesh', 3, 7, 25], ['gunpowder', 1, 8, 10], ['string', 1, 8, 10], ['sand', 1, 8, 10], ['saddle', 1, 1, 20], ['golden_apple', 1, 1, 20]] },
  fortress: { rolls: [3, 6], items: [['diamond', 1, 3, 5], ['iron_ingot', 1, 5, 5], ['gold_ingot', 1, 3, 15], ['blaze_rod', 2, 4, 12], ['golden_sword', 1, 1, 5], ['saddle', 1, 1, 10], ['flint_and_steel', 1, 1, 5], ['nether_wart', 3, 7, 5], ['obsidian', 2, 4, 2]] },
};

export const DEFAULT_WORLD: WorldMeta = {
  id: 'greenwood',
  name: 'はじまりの森',
  seed: '849281',
  mode: 'creative',
  difficulty: 'normal',
  hardcore: false,
  structures: true,
  bonus: true,
  cheats: true,
  created: Date.now(),
  updated: Date.now(),
  playTime: 0,
};

export class Engine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(58, 1, 0.05, 480);
  environment: Environment;
  input: InputController;
  terrain = new Terrain(DEFAULT_WORLD.seed);

  chunks = new Map<string, Chunk>();
  workers: WorkerSlot[] = [];
  queue: string[] = [];
  queued = new Set<string>();
  pending = new Set<string>();
  versions = new Map<string, number>();
  edits = new Map<string, number>();
  editsByChunk = new Map<string, Map<string, number>>();
  uploadQueue: { m: any }[] = [];
  tiles = BLOCKS.map(b => tilesFor(b.id));

  settings: Settings = { ...DEFAULT_SETTINGS };
  meta: WorldMeta = { ...DEFAULT_WORLD };
  dimension: Dimension = 'overworld';
  position = new THREE.Vector3(-11, 28, 27);
  velocity = new THREE.Vector3();
  active = false;
  ready = false;
  grounded = false;
  flying = false;
  gliding = false;
  elytraEquipped = false;
  sleeping = false;
  sleepTimer = 0;
  portalCharge = 0;
  levitationTimer = 0;
  dragonDefeated = false;
  time = 0.2;
  elapsed = 0;
  selected = 0;
  weather: 'clear' | 'rain' | 'storm' = 'clear';
  weatherTimer = 25;
  hotbar: (Stack | null)[] = [];
  inventory: (Stack | null)[] = Array(27).fill(null);
  health = 20;
  hunger = 20;
  oxygen = 20;
  xp = 0;
  /** Worn armor: helmet, chestplate (or elytra), leggings, boots. */
  armor: (Stack | null)[] = [null, null, null, null];
  offhand: Stack | null = null;
  effects: Record<string, { t: number; amp: number }> = {};
  absorption = 0;
  attackAt = -10;
  swingHeld = false;
  useTime = 0;
  useItemName = '';
  blocking = false;
  enchantSeed = 1;
  portalLock = false;
  lastLevel = 0;
  statistics: Record<string, number> = {};
  achievements: string[] = [];
  containers: Record<string, (Stack | null)[]> = {};
  target: Target | null = null;
  breaking = 0;
  breakKey = '';
  breakCooldown = 0;
  debug = false;
  dead = false;
  thirdPerson = false;

  outline: THREE.LineSegments;
  crack: THREE.Mesh;
  crackMaterials: THREE.MeshBasicMaterial[] = [];
  hand: THREE.Mesh;
  handMaterial: THREE.MeshLambertMaterial;
  handFaceMaterials: THREE.MeshLambertMaterial[] = [];
  handTextures = new Map<string, THREE.CanvasTexture>();
  lastHand = '';
  handDip = 0;
  hitFlash = 0;

  // Articulated 3D Steve model for F5 Third-Person mode
  playerModel: THREE.Group;
  playerHead: THREE.Group;
  playerLegs: THREE.Object3D[] = [];
  playerArms: THREE.Object3D[] = [];

  private raf = 0;
  private last = 0;
  private snapshotAt = 0;
  private streamAt = -10;
  private focus = '';
  private disposed = false;
  private frameCount = 0;
  private fps = 60;
  private fpsAt = 0;
  private pendingPlay = false;
  private worldEpoch = 0;
  private biomeKey = '';
  private currentBiome = 'plains';
  private dimensionStores: Partial<Record<Dimension, DimensionStore>> = {};
  private stationsInMenu = false;
  private stationCursor = 0;
  audio: ProceduralAudio | null = null;
  private stepAt = 0;
  private hitAt = 0;
  particles!: ParticleSystem;
  mobs!: MobManager;
  simulation!: Simulation;
  stationKey = '';
  furnaces: Record<string, { burn: number; progress: number }> = {};
  explosionQueue: [number, number, number][] = [];
  respawnPoint: [number, number, number] | null = null;
  private plate: [number, number, number] | null = null;
  private survivalTick = 0;
  private hazardAt = 0;
  private basePixelRatio = 1;
  private renderScale = 1;
  private lastScaleCheck = 0;
  private lightningTimer = 14;
  private fallTop = 0;
  private resizeObserver: ResizeObserver;
  private lastShadow = 0;
  private lastShadowPos = new THREE.Vector3();
  private fallbackNotified = false;
  private autoSaveAt = 0;
  private listeners: (() => void)[] = [];
  /** Chunks outside the render ring but inside the simulation ring: only block data, no meshes (redstone reads/writes them). */
  private sideChunks = new Map<string, Chunk>();
  redstone!: Redstone;
  private redstoneTimer = 0;
  private redstoneWrites = 0;
  private _dir = new THREE.Vector3();
  private _camTarget = new THREE.Vector3();
  private _frustum = new THREE.Frustum();
  private _viewProj = new THREE.Matrix4();
  private _cullBox = new THREE.Box3();
  /** Last chunk returned by getCell: block queries cluster in one chunk, so this skips the string key and map lookup. */
  private _cellChunk: Chunk | null = null;
  private _cellCx = 0;
  private _cellCz = 0;

  constructor(
    public canvas: HTMLCanvasElement,
    public onSnapshot: (s: GameSnapshot) => void,
    public onScreen: (s: Screen) => void,
    public onToast: (ja: string, en: string) => void,
    public onSave: (save: WorldSave) => void,
  ) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.25));
    this.basePixelRatio = this.renderer.getPixelRatio();
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.shadowMap.autoUpdate = false;

    this.environment = new Environment(this.scene, this.renderer, this.settings);
    this.input = new InputController(canvas, this.settings, a => this.action(a));
    this.particles = new ParticleSystem(this.scene);
    this.simulation = new Simulation({
      getBlock: (x, y, z) => this.getBlock(x, y, z),
      setBlock: (x, y, z, id) => this.setBlock(x, y, z, id),
      explode: (p, r) => this.explode(p, r),
      toast: (j, e) => this.onToast(j, e),
      sound: (k, p) => this.audio?.play(k, p),
      toggleDoor: (x, y, z, open) => this.toggleDoor(x, y, z, open),
    });

    // Redstone runs on its own 20 Hz tick with a pure state machine (see systems/redstone.ts). The adapter below connects
    // it to the live world: signal levels read cells, outputs write blocks, and mechanisms reuse the door/container/audio APIs.
    this.redstone = new Redstone({
      getCell: (x, y, z) => this.getCell(x, y, z),
      setBlock: (x, y, z, id, state = 0) => { this.redstoneWrites++; try { return this.setBlock(x, y, z, id, state); } finally { this.redstoneWrites--; } },
      containerSignal: (x, y, z) => this.containerSignal(x, y, z),
      eject: (x, y, z, dir, kind) => this.ejectFrom(x, y, z, dir, kind),
      transfer: (x, y, z, dir) => this.hopperTransfer(x, y, z, dir),
      door: (x, y, z, open) => this.toggleDoor(x, y, z, open),
      ignite: (x, y, z) => { this.simulation.enqueue(x, y, z, ID.tnt); this.onToast('TNTに点火しました', 'TNT primed'); },
      sound: (kind, x, y, z) => {
        const map: Record<string, string> = { click: 'chest', note: 'xp', piston: 'door', ignite: 'fuse' };
        this.audio?.play(map[kind] ?? 'stone', { x, y, z });
      },
    });

    this.mobs = new MobManager(this.scene, {
      terrain: this.terrain,
      position: this.position,
      camera: this.camera,
      get time() { return 0; },
      dimension: this.dimension,
      dragonDefeated: this.dragonDefeated,
      getBlock: (x, y, z) => this.getBlock(x, y, z),
      damage: n => this.damage(n, 'mob'),
      addItem: (n, c) => this.addItem(n, c),
      addXp: n => this.addXp(n),
      toast: (j, e) => this.onToast(j, e),
      sound: (k, p) => this.audio?.play(k, p),
      explode: (p, r) => this.explode(p, r),
      teleport: (x, y, z) => this.teleport(x, y, z),
      openTrade: () => { this.pause(true); this.onScreen('trade'); },
      onDragonDefeated: () => this.handleDragonDefeated(),
      onEnterGateway: () => this.handleGatewayTravel(),
      levitate: sec => { this.levitationTimer = Math.max(this.levitationTimer, sec); this.onToast('シュルカーの弾で浮遊しています！', 'Levitating!'); },
      particles: this.particles,
    });

    this.outline = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(1.006, 1.006, 1.006)),
      new THREE.LineBasicMaterial({ color: '#1a2419', transparent: true, opacity: 0.85 }),
    );
    this.outline.visible = false;
    this.scene.add(this.outline);

    const cracks = atlasTiles().filter(t => t.name.startsWith('crack_'));
    this.crackMaterials = cracks.map(t => {
      const texture = new THREE.CanvasTexture(t.canvas as HTMLCanvasElement);
      texture.magFilter = THREE.NearestFilter;
      return new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 });
    });
    this.crack = new THREE.Mesh(new THREE.BoxGeometry(1.009, 1.009, 1.009), this.crackMaterials[0]);
    this.crack.visible = false;
    this.scene.add(this.crack);

    this.handMaterial = new THREE.MeshLambertMaterial({ color: '#b49b6b', alphaTest: 0.35 });
    this.handFaceMaterials = Array.from({ length: 6 }, () => new THREE.MeshLambertMaterial({ color: '#c99c7b' }));
    this.hand = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.28, 0.28), this.handFaceMaterials);
    this.hand.position.set(0.42, -0.34, -0.62);
    this.hand.rotation.set(0.2, -0.5, 0.1);
    this.hand.visible = false;
    this.camera.add(this.hand);
    this.scene.add(this.camera);

    // Build articulated Steve model for Third-Person view (F5)
    this.playerModel = new THREE.Group();
    this.playerHead = new THREE.Group();
    const box = new THREE.BoxGeometry(1, 1, 1);
    const mkPart = (parent: THREE.Object3D, col: string, x: number, y: number, z: number, w: number, h: number, d: number) => {
      const m = new THREE.Mesh(box, new THREE.MeshLambertMaterial({ color: col }));
      m.position.set(x, y, z);
      m.scale.set(w, h, d);
      m.castShadow = true;
      m.receiveShadow = true;
      parent.add(m);
      return m;
    };
    mkPart(this.playerModel, '#2fa8b0', 0, 1.08, 0, 0.5, 0.72, 0.26); // Torso
    this.playerHead.position.set(0, 1.65, 0);
    mkPart(this.playerHead, '#c99c7b', 0, 0, 0, 0.46, 0.46, 0.46); // Head
    mkPart(this.playerHead, '#4b3322', 0, 0.16, 0.02, 0.48, 0.16, 0.48); // Hair
    mkPart(this.playerHead, '#2c4c8a', -0.1, 0.02, -0.235, 0.08, 0.07, 0.02); // Eyes
    mkPart(this.playerHead, '#2c4c8a', 0.1, 0.02, -0.235, 0.08, 0.07, 0.02);
    this.playerModel.add(this.playerHead);
    for (const s of [-1, 1]) {
      const leg = new THREE.Group(); leg.position.set(s * 0.13, 0.72, 0);
      mkPart(leg, '#3e4691', 0, -0.36, 0, 0.22, 0.72, 0.24);
      this.playerModel.add(leg);
      this.playerLegs.push(leg);

      const arm = new THREE.Group(); arm.position.set(s * 0.36, 1.38, 0);
      mkPart(arm, '#2fa8b0', 0, -0.12, 0, 0.2, 0.26, 0.22);
      mkPart(arm, '#c99c7b', 0, -0.42, 0, 0.19, 0.42, 0.2);
      this.playerModel.add(arm);
      this.playerArms.push(arm);
    }
    this.playerModel.visible = false;
    this.scene.add(this.playerModel);

    const count = Math.min(4, Math.max(2, (navigator.hardwareConcurrency || 4) - 1));
    for (let i = 0; i < count; i++) {
      const worker = new ChunkWorker();
      const slot: WorkerSlot = { worker, busy: false };
      worker.onmessage = e => this.receive(e.data, slot);
      worker.onerror = () => {
        slot.busy = false;
        if (slot.epoch === this.worldEpoch && slot.key) {
          this.pending.delete(slot.key);
          this.invalidate(slot.key);
        }
        this.onToast('地形生成を再試行しています', 'Retrying terrain generation');
        this.streamAt = -10;
      };
      this.workers.push(slot);
    }

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(canvas);
    this.resize();

    const save = () => { if (this.active) this.save(); };
    window.addEventListener('blur', save);
    document.addEventListener('visibilitychange', save);
    this.listeners.push(
      () => window.removeEventListener('blur', save),
      () => document.removeEventListener('visibilitychange', save),
    );

    this.defaultInventory();
    this.raf = requestAnimationFrame(this.frame);
  }

  resize() {
    const w = this.canvas.clientWidth || innerWidth, h = this.canvas.clientHeight || innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  setSettings(settings: Settings) {
    this.settings = { ...settings };
    this.input.settings = this.settings;
    this.basePixelRatio = Math.min(devicePixelRatio, settings.quality === 'low' ? 1 : settings.quality === 'medium' ? 1.1 : settings.quality === 'ultra' ? 1.7 : 1.25);
    this.renderScale = 1;
    this.renderer.setPixelRatio(this.basePixelRatio);
    this.renderer.shadowMap.enabled = settings.quality !== 'low';
    this.environment.markShadow();
    this.camera.fov = this.active ? settings.fov : 58;
    this.camera.updateProjectionMatrix();
    this.streamAt = -10;
    this.resize();
  }

  defaultInventory() {
    const names = this.meta.mode === 'creative'
      ? ['grass_block', 'oak_log', 'oak_planks', 'stone_bricks', 'glass', 'oak_leaves', 'torch', 'crafting_table', 'water_bucket']
      : ['wooden_pickaxe', 'wooden_sword', 'oak_log', 'oak_planks', 'torch', 'apple', 'crafting_table', 'cobblestone', 'bucket'];
    this.hotbar = names.map(name => ({
      name,
      count: this.meta.mode === 'creative' ? 64 : name === 'apple' ? 8 : resolve(name)?.stack === 1 ? 1 : 32,
    }));
    this.inventory = Array(27).fill(null);
    if (this.meta.bonus && this.meta.mode !== 'creative') {
      this.inventory[0] = { name: 'bread', count: 8 };
      this.inventory[1] = { name: 'coal', count: 8 };
      this.inventory[2] = { name: 'wheat_seeds', count: 8 };
    }
  }

  private rebuildEditBuckets() {
    this.editsByChunk.clear();
    for (const [key, cell] of this.edits) {
      const [x, , z] = key.split(',').map(Number);
      const cKey = Math.floor(x / 16) + ',' + Math.floor(z / 16);
      let bucket = this.editsByChunk.get(cKey);
      if (!bucket) { bucket = new Map(); this.editsByChunk.set(cKey, bucket); }
      bucket.set(key, cell);
    }
  }

  start(meta: WorldMeta, save?: WorldSave) {
    this.active = false;
    this.pendingPlay = true;
    this.ready = false;
    this.meta = { ...meta };
    this.dimension = save?.dimension ?? 'overworld';
    this.dimensionStores = {};
    for (const dimension of ['overworld', 'nether', 'end'] as const) {
      const state = save?.dimensions?.[dimension];
      const legacy = save && !save.dimensions && dimension === this.dimension;
      this.dimensionStores[dimension] = {
        edits: new Map(state?.edits ?? (legacy ? save.edits : [])),
        containers: state?.containers ?? (legacy ? save.containers ?? {} : {}),
        furnaces: state?.furnaces ?? (legacy ? save.furnaces ?? {} : {}),
      };
    }
    if (save && ((save.meta as any)?.gen ?? (meta as any).gen ?? 0) < 3 && this.dimensionStores.overworld) SV.liftLegacyOverworld(this.dimensionStores.overworld);
    this.attachDimensionStore(this.dimension);
    this.terrain = new Terrain(meta.seed, this.dimension);
    this.mobs.host.terrain = this.terrain;
    this.mobs.host.dimension = this.dimension;
    this.dragonDefeated = save?.dragonDefeated ?? false;
    this.elytraEquipped = save?.elytraEquipped ?? false;
    this.mobs.host.dragonDefeated = this.dragonDefeated;
    this.mobs.clear();
    this.particles.clear();
    this.simulation.clear();
    this.respawnPoint = save?.respawnPoint ?? null;
    this.clearChunks();
    this.time = save?.time ?? 0.2;
    // Worlds saved before terrain generation v2 would leave the player inside the new landscape: restart those at the spawn point.
    // Terrain generation v4 (multi-noise): worlds from older generators restart at the new spawn point.
    // Terrain generation v5 (vanilla biome table, new terrain shaping): same rule again.
    const legacyTerrain = !!save && (save.meta as any)?.gen !== 5 && (meta as any).gen !== 5;
    (this.meta as any).gen = 5;
    if (legacyTerrain) this.respawnPoint = null;
    this.position.set(...(save && !legacyTerrain ? save.position : this.terrain.spawnPosition(1.05)));
    this.mobs.populate();
    this.velocity.set(0, 0, 0);
    this.input.yaw = save && !legacyTerrain ? save.yaw : this.terrain.spawnYaw();
    this.input.pitch = save?.pitch ?? -0.08;
    this.health = save?.health ?? 20;
    this.hunger = save?.hunger ?? 20;
    this.xp = save?.xp ?? 0;
    this.lastLevel = Math.floor(Math.sqrt(this.xp));
    this.statistics = save?.statistics ?? {};
    this.achievements = save?.achievements ?? [];
    this.selected = save?.selected ?? 0;
    this.flying = false;
    this.gliding = false;
    this.sleeping = false;
    this.portalCharge = 0;
    this.levitationTimer = 0;
    this.dead = false;
    this.oxygen = 20;
    this.defaultInventory();
    if (save) {
      this.hotbar = save.hotbar;
      this.inventory = save.inventory;
    }
    SV.loadPlayer(this, save);
    this.focus = '';
    this.streamAt = -10;
    this.autoSaveAt = this.elapsed;
    this.camera.fov = this.settings.fov;
    this.camera.updateProjectionMatrix();
    this.onScreen('loading');
  }

  private attachDimensionStore(dimension: Dimension) {
    const store = (this.dimensionStores[dimension] ??= { edits: new Map(), containers: {}, furnaces: {} });
    this.edits = store.edits;
    this.containers = store.containers;
    this.furnaces = store.furnaces;
    this.rebuildEditBuckets();
  }

  activate() {
    if (!this.ready) return;
    this.stationsInMenu = false;
    this.active = true;
    this.input.setActive(true);
    this.hand.visible = !this.thirdPerson;
    this.playerModel.visible = this.thirdPerson;
    this.environment.markShadow();
  }

  pause(keepStationsRunning = false) {
    this.stationsInMenu = keepStationsRunning;
    this.active = false;
    this.input.setActive(false);
    this.hand.visible = false;
    this.playerModel.visible = false;
    this.outline.visible = false;
    this.crack.visible = false;
  }

  title() {
    this.save();
    this.pendingPlay = false;
    this.pause();
    this.meta = { ...DEFAULT_WORLD };
    this.terrain = new Terrain(DEFAULT_WORLD.seed);
    this.dimension = 'overworld';
    this.mobs.host.terrain = this.terrain;
    this.mobs.host.dimension = this.dimension;
    this.mobs.clear();
    this.mobs.populate();
    this.particles.clear();
    this.simulation.clear();
    this.clearChunks();
    this.dimensionStores = {};
    this.attachDimensionStore('overworld');
    this.focus = '';
    this.streamAt = -10;
    this.ready = false;
    this.time = 0.2;
    this.camera.fov = 58;
    this.camera.updateProjectionMatrix();
  }

  clearChunks() {
    this.worldEpoch++;
    for (const c of this.chunks.values()) this.disposeChunk(c);
    // Ring chunks own meshes too: without this they stayed in the scene (and in getCell) after a world or dimension change.
    for (const c of [...this.sideChunks.values()]) this.disposeChunk(c);
    this.sideChunks.clear();
    this._cellChunk = null;
    this.redstone?.active.clear();
    this.chunks.clear();
    this.queue = [];
    this.queued.clear();
    this.pending.clear();
    this.uploadQueue = [];
    this.versions.clear();
  }

  disposeChunk(c: Chunk) {
    if (this._cellChunk === c) this._cellChunk = null;
    this.redstone?.unloadChunk(c.cx, c.cz);
    for (const [k, side] of this.sideChunks) if (side === c) this.sideChunks.delete(k);
    this.scene.remove(c.solid, c.water);
    c.solid.geometry.dispose();
    c.water.geometry.dispose();
  }

  action(action: string) {
    if (action === 'escape') {
      if (this.dead) return;
      if (this.active) { this.pause(); this.onScreen('pause'); }
      else this.onScreen('escape');
      return;
    }
    if (!this.active) return;
    if (action === 'inventory') { this.pause(true); this.onScreen('inventory'); }
    else if (action === 'screenshot') this.captureScreenshot();
    else if (action === 'chat' || action === 'slash') { this.pause(true); this.onScreen('chat'); }
    else if (action === 'debug') this.debug = !this.debug;
    else if (action === 'perspective') {
      this.thirdPerson = !this.thirdPerson;
      this.hand.visible = !this.thirdPerson;
      this.playerModel.visible = this.thirdPerson;
    }
    else if (action === 'fly' && this.meta.mode === 'creative') {
      this.flying = !this.flying;
      this.velocity.y = 0;
      this.onToast(this.flying ? '飛行モード' : '歩行モード', this.flying ? 'Flight enabled' : 'Flight disabled');
    }
    else if (action.startsWith('slot:')) {
      const s = action.slice(5);
      this.select(s === 'next' ? (this.selected + 1) % 9 : s === 'previous' ? (this.selected + 8) % 9 : Number(s));
    }
    else if (action === 'use') this.use();
    else if (action === 'drop') this.dropSelected();
    else if (action === 'swap') { if (SV.swapSlots(this, this.selected, 40)) this.handDip = 0.2; }
  }


  captureScreenshot() {
    try {
      this.renderer.render(this.scene, this.camera);
      const image = this.canvas.toDataURL('image/png');
      if (image.length < 2000) throw new Error('Empty screenshot');
      const link = document.createElement('a');
      link.href = image;
      link.download = `minecraft-${this.meta.seed}-${new Date().toISOString().replace(/[:.]/g, '-')}.png`;
      document.body.append(link);
      link.click();
      link.remove();
      this.onToast('スクリーンショットを保存しました', 'Screenshot saved');
      return true;
    } catch {
      this.onToast('画像を保存できませんでした', 'Could not save screenshot');
      return false;
    }
  }

  select(slot: number) {
    const next = clamp(slot, 0, 8);
    if (next !== this.selected) this.handDip = 0.25;
    this.selected = next;
    this.breaking = 0;
  }

  getCell(x: number, y: number, z: number) {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    if (y < MIN_Y) return ID.bedrock;
    if (y >= MIN_Y + HEIGHT) return 0;
    // The 3x3 chunk neighbourhood is guaranteed loaded around the player, so redstone next to a border still reads across it.
    const cx = x >> 4, cz = z >> 4;
    let chunk = this._cellChunk;
    if (chunk === null || cx !== this._cellCx || cz !== this._cellCz) {
      const key = cx + ',' + cz;
      chunk = this.chunks.get(key) ?? this.sideChunks.get(key) ?? null;
      if (!chunk) {
        if (!this.pending.has(key) && !this.queued.has(key)) this.invalidate(key);
        return -1;
      }
      this._cellChunk = chunk; this._cellCx = cx; this._cellCz = cz;
    }
    return chunk.data[(y - MIN_Y) * 256 + ((z & 15) << 4) + (x & 15)];
  }

  getBlock(x: number, y: number, z: number) { return blockId(this.getCell(x, y, z)); }

  setBlock(x: number, y: number, z: number, id: number, state = 0) {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    if (y < MIN_Y || y >= MIN_Y + HEIGHT || !BLOCKS[id] || !Number.isInteger(state) || state < 0 || state > 15) return false;
    const cx = Math.floor(x / 16), cz = Math.floor(z / 16), cKey = cx + ',' + cz;
    const chunk = this.chunks.get(cKey) ?? this.sideChunks.get(cKey);
    if (!chunk) return false;
    if (this.sideChunks.get(cKey) === chunk) this.invalidate(cKey);
    const lx = x - cx * 16, lz = z - cz * 16, index = blockIndex(lx, y, lz), previous = chunk.data[index], cell = makeCell(id, state);
    if (previous === cell) return false;
    const previousId = blockId(previous), key = `${x},${y},${z}`;
    if (previousId !== id && [ID.chest, ID.barrel, ID.shulker_box, ID.furnace, ID.blast_furnace, ID.smoker, ID.brewing_stand, ID.lectern].includes(previousId)) {
      for (const stack of this.containers[key] ?? []) {
        if (stack) this.particles.drop(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), stack.name, stack.count, resolve(stack.name)?.color ?? '#aaa');
      }
      delete this.containers[key];
      delete this.furnaces[key];
    }
    chunk.data[index] = cell;
    this.edits.set(key, cell);
    let bucket = this.editsByChunk.get(cKey);
    if (!bucket) { bucket = new Map(); this.editsByChunk.set(cKey, bucket); }
    bucket.set(key, cell);

    const dxs = lx === 0 ? [-1, 0] : lx === 15 ? [0, 1] : [0];
    const dzs = lz === 0 ? [-1, 0] : lz === 15 ? [0, 1] : [0];
    for (const dz of dzs) for (const dx of dxs) {
      const neighbor = (cx + dx) + ',' + (cz + dz);
      if (this.chunks.has(neighbor) || this.pending.has(neighbor)) this.invalidate(neighbor);
    }
    this.simulation.notify(x, y, z, id);
    this.redstone?.register(x, y, z);
    if (this.redstoneWrites === 0) this.redstone?.blockChanged(x, y, z);
    this.environment.markShadow();
    return true;
  }

  invalidate(key: string) {
    this.versions.set(key, (this.versions.get(key) ?? 0) + 1);
    if (!this.queued.has(key)) { this.queue.unshift(key); this.queued.add(key); }
  }

  stream() {
    const p = this.pendingPlay || this.active || this.ready ? this.position : new THREE.Vector3(0, 24, 0);
    const cx = Math.floor(p.x / 16), cz = Math.floor(p.z / 16), radius = this.settings.distance;
    const focus = cx + ',' + cz + ',' + radius + ',' + this.dimension;
    if (focus === this.focus) return;
    this.focus = focus;

    const fx = -Math.sin(this.input.yaw), fz = -Math.cos(this.input.yaw);
    const desired: { key: string; d: number }[] = [];
    for (let z = -radius; z <= radius; z++) {
      for (let x = -radius; x <= radius; x++) {
        if (x * x + z * z > (radius + 0.5) ** 2) continue;
        const key = (cx + x) + ',' + (cz + z);
        const dist = x * x + z * z;
        const dot = dist > 0 ? (x * fx + z * fz) / Math.sqrt(dist) : 1;
        desired.push({ key, d: dist - dot * 2.5 });
      }
    }
    desired.sort((a, b) => a.d - b.d);
    this._cellChunk = null;
    for (const { key } of desired) {
      if (this.chunks.has(key)) continue;
      // A ring chunk that came into range already has its data and meshes: promote it instead of generating it a second time.
      const ring = this.sideChunks.get(key);
      if (ring) {
        this.sideChunks.delete(key);
        this.chunks.set(key, ring);
        this.redstone?.scanChunk(ring.data, ring.cx, ring.cz, HEIGHT, MIN_Y);
        continue;
      }
      if (!this.queued.has(key) && !this.pending.has(key)) {
        this.queue.push(key);
        this.queued.add(key);
      }
    }

    // One extra ring of block data (no meshes) so machines straddling a chunk border always read real blocks.
    // The ring is a true ring (one chunk wide). It used to be the corners of a square, which lie beyond the unload distance below:
    // those chunks were generated, dropped and generated again every time the player crossed a chunk border.
    for (let z = -radius - 2; z <= radius + 2; z++) for (let x = -radius - 2; x <= radius + 2; x++) {
      const ringDist = Math.hypot(x, z);
      if (ringDist <= radius + 0.5 || ringDist > radius + 1.5) continue;
      const key = (cx + x) + ',' + (cz + z);
      if (!this.chunks.has(key) && !this.sideChunks.has(key) && !this.queued.has(key) && !this.pending.has(key)) {
        this.queue.push(key);
        this.queued.add(key);
      }
    }
    for (const [key, c] of this.chunks) {
      if (Math.hypot(c.cx - cx, c.cz - cz) > radius + 2) {
        this.disposeChunk(c);
        this.chunks.delete(key);
      }
    }
    for (const [key, c] of this.sideChunks) {
      if (Math.hypot(c.cx - cx, c.cz - cz) > radius + 2) {
        // disposeChunk also removes the meshes from the scene and frees their buffers (they used to be left behind).
        this.disposeChunk(c);
        this.sideChunks.delete(key);
      }
    }
    this.queue = this.queue.filter(key => {
      const sep = key.indexOf(',');
      const x = Number(key.slice(0, sep)), z = Number(key.slice(sep + 1));
      if (Math.hypot(x - cx, z - cz) > radius + 2) { this.queued.delete(key); return false; }
      return true;
    });
  }

  dispatch() {
    for (const slot of this.workers) {
      if (slot.busy || !this.queue.length) continue;
      const next = this.queue.findIndex(key => !this.pending.has(key));
      if (next < 0) continue;
      const [key] = this.queue.splice(next, 1);
      this.queued.delete(key);
      const sep = key.indexOf(',');
      const cx = Number(key.slice(0, sep)), cz = Number(key.slice(sep + 1));
      const version = this.versions.get(key) ?? 0;
      slot.busy = true; slot.key = key; slot.epoch = this.worldEpoch;
      this.pending.add(key);

      // O(1) lookup across the 3x3 chunk neighborhood
      const edits: [string, number][] = [];
      for (let dz = -1; dz <= 1; dz++) {
        for (let dx = -1; dx <= 1; dx++) {
          const bucket = this.editsByChunk.get((cx + dx) + ',' + (cz + dz));
          if (bucket) for (const entry of bucket) edits.push(entry);
        }
      }

      slot.worker.postMessage({
        key, cx, cz, version, epoch: this.worldEpoch,
        seed: this.meta.seed, dimension: this.dimension, edits,
        structures: this.meta.structures, tiles: slot.tilesSent ? undefined : this.tiles,
      });
      slot.tilesSent = true;
    }
  }

  geometry(m: MeshData, minY = 0, maxY = 0) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(m.position, 3));
    g.setAttribute('normal', new THREE.BufferAttribute(m.normal, 3));
    g.setAttribute('uv', new THREE.BufferAttribute(m.uv, 2));
    g.setAttribute('color', new THREE.BufferAttribute(m.color, 3));
    g.setAttribute('tile', new THREE.BufferAttribute(m.tile, 1));
    g.setAttribute('wind', new THREE.BufferAttribute(m.wind, 1));
    g.setAttribute('aLight', new THREE.BufferAttribute(m.light, 2));
    g.setIndex(new THREE.BufferAttribute(m.index, 1));
    // Bounds come from the worker, so the main thread never walks the vertices.
    const half = (maxY - minY) * 0.5;
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(8, minY + half, 8), Math.hypot(12, half + 1));
    return g;
  }

  receive(m: any, slot: WorkerSlot) {
    slot.busy = false;
    if (this.disposed || m.epoch !== this.worldEpoch) return;
    this.pending.delete(m.key);
    if (m.type === 'error') {
      this.invalidate(m.key);
      this.onToast('チャンクを再生成しています', 'Regenerating chunk');
      return;
    }
    if ((this.versions.get(m.key) ?? 0) !== m.version) {
      if (!this.queued.has(m.key)) { this.queue.unshift(m.key); this.queued.add(m.key); }
      return;
    }
    if (!this.ready) {
      this.mountChunk(m);
    } else {
      this.uploadQueue.push({ m });
    }
  }

  private mountChunk(m: any) {
    if ((this.versions.get(m.key) ?? 0) !== m.version) return;
    const pcx8 = Math.floor(this.position.x / 16), pcz8 = Math.floor(this.position.z / 16);
    const side = !this.chunks.has(m.key) && Math.hypot(m.cx - pcx8, m.cz - pcz8) > this.settings.distance + 0.5;
    const old = this.chunks.get(m.key);
    if (old) this.disposeChunk(old);
    const sideOld = this.sideChunks.get(m.key);
    if (sideOld) this.disposeChunk(sideOld);   // also removes its meshes: a replaced ring chunk used to stay in the scene forever
    this._cellChunk = null;
    const minY: number = Number.isFinite(m.minY) ? m.minY : MIN_Y, maxY: number = Number.isFinite(m.maxY) ? m.maxY : MIN_Y + HEIGHT;
    const hasSolid = m.solid.index.length > 0, hasWater = m.water.index.length > 0;
    const solid = new THREE.Mesh(this.geometry(m.solid, minY, maxY), this.environment.failed ? this.environment.fallback : this.environment.material);
    const water = new THREE.Mesh(this.geometry(m.water, minY, maxY), this.environment.water);
    solid.position.set(m.cx * 16, 0, m.cz * 16);
    water.position.copy(solid.position);
    solid.matrixAutoUpdate = false; solid.updateMatrix();
    water.matrixAutoUpdate = false; water.updateMatrix();
    // Visibility and shadow casting are decided every frame in cullChunks() (they used to be fixed at mount time, so shadows
    // disappeared once the player walked away from where a chunk was first loaded). Empty meshes are never drawn.
    solid.frustumCulled = false; water.frustumCulled = false;
    solid.visible = hasSolid; water.visible = hasWater;
    solid.customDepthMaterial = this.environment.depthMaterial;
    solid.castShadow = false;
    solid.receiveShadow = true;
    water.renderOrder = 2;
    this.scene.add(solid, water);
    const chunk: Chunk = { cx: m.cx, cz: m.cz, data: new Uint16Array(m.data), solid, water, version: m.version, minY, maxY, hasSolid, hasWater };
    if (side) {
      this.sideChunks.set(m.key, chunk);
      return;
    }
    this.chunks.set(m.key, chunk);
    this.redstone?.scanChunk(chunk.data, m.cx, m.cz, HEIGHT, MIN_Y);
  }

  /**
   * Per-frame visibility. A chunk is a tall thin column, so its bounding sphere (what three.js tests) is far larger than the chunk and
   * lets most off-screen chunks through; a box test against the view frustum is tight. On a frame that re-renders the shadow map the
   * shadow casters stay visible even when off-screen, because three.js skips invisible objects in the shadow pass.
   */
  private cullChunks() {
    const cam = this.camera;
    cam.updateMatrixWorld();
    this._frustum.setFromProjectionMatrix(this._viewProj.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
    const shadowFrame = this.renderer.shadowMap.enabled && this.renderer.shadowMap.needsUpdate;
    const pcx = Math.floor(this.position.x / 16), pcz = Math.floor(this.position.z / 16), box = this._cullBox, frustum = this._frustum;
    const apply = (c: Chunk) => {
      const x0 = c.cx * 16, z0 = c.cz * 16;
      box.min.set(x0 - 0.5, c.minY - 0.5, z0 - 0.5);
      box.max.set(x0 + 16.5, c.maxY + 0.5, z0 + 16.5);
      const caster = Math.hypot(c.cx - pcx, c.cz - pcz) <= 2;
      const seen = frustum.intersectsBox(box) || (shadowFrame && caster);
      c.solid.castShadow = caster;
      c.solid.visible = seen && c.hasSolid;
      c.water.visible = seen && c.hasWater;
    };
    for (const c of this.chunks.values()) apply(c);
    for (const c of this.sideChunks.values()) apply(c);
  }

  collides(p: THREE.Vector3) {
    const height = this.input.crouch && !this.flying ? 1.5 : 1.8;
    const minX = p.x - 0.29, maxX = p.x + 0.29, minY = p.y + 0.001, maxY = p.y + height - 0.001, minZ = p.z - 0.29, maxZ = p.z + 0.29;
    for (let y = Math.floor(minY); y <= Math.floor(maxY); y++) {
      for (let z = Math.floor(minZ); z <= Math.floor(maxZ); z++) {
        for (let x = Math.floor(minX); x <= Math.floor(maxX); x++) {
          const cell = this.getCell(x, y, z), id = blockId(cell);
          if (id === -1) return true;
          const def = BLOCKS[id];
          if (!def?.solid) continue;
          for (const box of collisionBoxes(def, blockState(cell))) {
            if (intersectsBox(x, y, z, minX, minY, minZ, maxX, maxY, maxZ, box)) return true;
          }
        }
      }
    }
    return false;
  }

  supported(p: THREE.Vector3) {
    return this.collides(new THREE.Vector3(p.x, p.y - 0.08, p.z));
  }

  physics(dt: number) {
    if (this.sleeping) return;
    const input = this.input, move = input.move;
    const water = this.getBlock(this.position.x, this.position.y + 0.6, this.position.z) === ID.water;
    const spectator = this.meta.mode === 'spectator';
    const onLadder = ID.ladder !== undefined && (this.getBlock(this.position.x, this.position.y + 0.2, this.position.z) === ID.ladder || this.getBlock(this.position.x, this.position.y + 1.2, this.position.z) === ID.ladder);

    if (this.grounded || water || this.flying || onLadder) this.gliding = false;
    // Allow mid-air Space press to initiate Elytra glide
    if (this.elytraEquipped && !this.grounded && !water && !this.flying && !onLadder && this.velocity.y < -2.5 && input.ascend) {
      this.gliding = true;
    }

    if (this.gliding) {
      this.camera.getWorldDirection(this._dir);
      const horizSpeed = Math.hypot(this.velocity.x, this.velocity.z);
      const pitchFactor = -Math.sin(this.input.pitch); // positive when diving
      const targetSpeed = clamp(horizSpeed + pitchFactor * 16 * dt + 2 * dt, 7, 26);
      const fx = -Math.sin(this.input.yaw), fz = -Math.cos(this.input.yaw);
      this.velocity.x = fx * targetSpeed;
      this.velocity.z = fz * targetSpeed;
      this.velocity.y = clamp(this._dir.y * targetSpeed * 0.85 - 1.2, -16, 10);
      this.fallTop = this.position.y;
    }

    let speed = this.flying ? (input.run ? 15.5 : 9) : water ? 2.9 : input.crouch ? 1.65 : input.run ? 6.6 : 4.35;
    if (spectator) speed = 13;
    else if (!this.flying) speed *= SV.speedFactor(this);

    if (!this.gliding) {
      if (this.flying || spectator) {
        this.velocity.y = (+input.ascend - +input.crouch) * speed;
      } else if (this.levitationTimer > 0) {
        this.levitationTimer -= dt;
        this.velocity.y = 2.6;
        this.fallTop = this.position.y;
      } else if (water) {
        this.velocity.y += (-3 - this.velocity.y * 3) * dt;
        if (input.ascend) this.velocity.y = 3.6;
        this.fallTop = this.position.y;
      } else if (onLadder) {
        // Ladders: climb by walking into them or jumping, hold still while sneaking, otherwise slide down slowly. No fall damage.
        this.velocity.y = input.ascend || Math.hypot(move.x, move.z) > 0.1 ? 2.35 : input.crouch ? 0 : -2.2;
        this.fallTop = this.position.y;
      } else {
        this.velocity.y -= 24 * dt;
        if (SV.has(this, 'slow_falling') && this.velocity.y < -1.8) { this.velocity.y = -1.8; this.fallTop = this.position.y; }
        if (input.ascend && this.grounded) {
          this.velocity.y = 8.25 + SV.jumpBoost(this);
          this.grounded = false;
        }
      }
    }

    const oldX = this.position.x, oldY = this.position.y, oldZ = this.position.z;
    const wasGrounded = this.grounded;
    this.grounded = false;
    const vxMove = this.gliding ? this.velocity.x : move.x * speed;
    const vzMove = this.gliding ? this.velocity.z : move.z * speed;

    for (const [axis, delta] of [['x', vxMove * dt], ['z', vzMove * dt]] as const) {
      const prev = this.position[axis];
      this.position[axis] += delta;
      if (!spectator && this.collides(this.position)) {
        let stepped = false;
        if (wasGrounded && !input.crouch && !this.flying && !this.gliding) {
          this.position.y += 0.6;
          if (!this.collides(this.position)) stepped = true;
          else this.position.y -= 0.6;
        }
        if (!stepped) {
          this.position[axis] = prev;
          if (this.gliding) this.gliding = false;
        }
      }
      if (input.crouch && !this.flying && !spectator && wasGrounded && !this.supported(this.position)) {
        this.position[axis] = prev;
      }
    }

    const py = this.position.y, verticalMove = this.velocity.y * dt;
    this.position.y += verticalMove;
    if (!spectator && this.collides(this.position)) {
      let safe = 0, blocked = 1;
      for (let i = 0; i < 12; i++) {
        const mid = (safe + blocked) / 2;
        this.position.y = py + verticalMove * mid;
        if (this.collides(this.position)) blocked = mid;
        else safe = mid;
      }
      this.position.y = py + verticalMove * safe;
      if (this.velocity.y < 0) {
        this.grounded = true;
        const fall = this.fallTop - this.position.y;
        if (fall > 3.5 && !water && !this.flying && !this.gliding && !onLadder) SV.fallDamage(this, fall);
        this.gliding = false;
        this.fallTop = this.position.y;
      }
      this.velocity.y = 0;
    }

    if (this.grounded || this.flying || water || this.gliding || onLadder) this.fallTop = this.position.y;
    else this.fallTop = Math.max(this.fallTop, this.position.y);

    if (this.position.y < MIN_Y - 10) {
      if (this.meta.mode === 'creative') { this.position.y = 130; this.velocity.y = 0; }
      else this.damage(20, 'void');
    }

    // Check Portal / End Portal / End Gateway / Hazards
    const blockAtFeet = this.getBlock(this.position.x, this.position.y + 0.5, this.position.z);
    const blockAtBody = this.getBlock(this.position.x, this.position.y + 1.1, this.position.z);
    if (this.portalLock && blockAtFeet >= 0 && blockAtFeet !== ID.portal && blockAtBody !== ID.portal) this.portalLock = false;
    if (this.portalLock) {
      this.portalCharge = 0;
    } else if (blockAtFeet === ID.portal || blockAtBody === ID.portal) {
      this.portalCharge += dt / 1.2;
      if (this.portalCharge >= 1) {
        this.portalCharge = 0;
        this.audio?.play('portal');
        this.travelNetherPortal();
        return;
      }
    } else if (blockAtFeet === ID.end_portal || blockAtBody === ID.end_portal) {
      this.audio?.play('portal');
      this.enterEndPortal();
      return;
    } else if (blockAtFeet === ID.end_gateway || blockAtBody === ID.end_gateway) {
      this.audio?.play('portal');
      this.handleGatewayTravel();
      return;
    } else {
      this.portalCharge = Math.max(0, this.portalCharge - dt * 2);
    }

    // Cactus, Lava & Fire damage
    if (!spectator && this.meta.mode !== 'creative' && this.elapsed - this.hazardAt > 0.55) {
      const nearCactus = [
        this.getBlock(this.position.x + 0.35, this.position.y + 0.5, this.position.z),
        this.getBlock(this.position.x - 0.35, this.position.y + 0.5, this.position.z),
        this.getBlock(this.position.x, this.position.y + 0.5, this.position.z + 0.35),
        this.getBlock(this.position.x, this.position.y + 0.5, this.position.z - 0.35),
      ].includes(ID.cactus);
      if (nearCactus) { this.hazardAt = this.elapsed; this.damage(1, 'contact'); }
      else if (blockAtFeet === ID.lava || blockAtFeet === ID.fire || blockAtBody === ID.lava) { this.hazardAt = this.elapsed; this.damage(4, 'fire'); }
    }

    const stepDist = Math.hypot(this.position.x - oldX, this.position.y - oldY, this.position.z - oldZ);
    if (wasGrounded && stepDist > 0.01) {
      this.statistics.distance_walked = (this.statistics.distance_walked ?? 0) + stepDist;
      const stepInterval = input.run ? 0.28 : 0.38;
      if (this.elapsed - this.stepAt > stepInterval) {
        this.stepAt = this.elapsed;
        const ground = BLOCKS[this.getBlock(this.position.x, this.position.y - 0.1, this.position.z)];
        this.audio?.play(
          water ? 'water' :
          ground?.pattern === 'sand' || ground?.pattern === 'gravel' ? 'sand' :
          ground?.tool === 'pickaxe' ? 'stone' :
          ground?.tool === 'axe' ? 'wood' : 'grass',
        );
      }
    }

    // Smooth sprint/underwater FOV kick
    const eyeUnderwater = this.getBlock(this.position.x, this.position.y + 1.5, this.position.z) === ID.water;
    const isMoving = Math.hypot(move.x, move.z) > 0.1;
    const targetFov = this.settings.fov + (input.run && isMoving ? 7 : 0) - (eyeUnderwater ? 7 : 0);
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 10);
      this.camera.updateProjectionMatrix();
    }

    // Eye & third-person camera placement
    const eyeY = this.position.y + (input.crouch ? 1.42 : 1.62) +
      (this.settings.bobbing && this.grounded && !this.thirdPerson ? Math.sin(this.elapsed * 11) * Math.min(0.035, move.x ** 2 + move.z ** 2) * 0.035 : 0);

    if (this.thirdPerson) {
      const cosPitch = Math.cos(this.input.pitch);
      this._dir.set(-Math.sin(this.input.yaw) * cosPitch, Math.sin(this.input.pitch), -Math.cos(this.input.yaw) * cosPitch);
      this._camTarget.set(this.position.x, eyeY, this.position.z);
      const backHit = traceVoxelRay([this._camTarget.x, this._camTarget.y, this._camTarget.z], [-this._dir.x, -this._dir.y, -this._dir.z], 4.2, (x, y, z) => {
        const b = this.getBlock(x, y, z);
        return b > 0 && BLOCKS[b]?.solid ? b : 0;
      });
      const pull = backHit ? Math.max(0.6, backHit.distance - 0.25) : 4.2;
      this.camera.position.copy(this._camTarget).addScaledVector(this._dir, -pull);

      // Animate Steve player model
      this.playerModel.visible = true;
      this.playerModel.position.copy(this.position);
      this.playerModel.rotation.y = this.input.yaw;
      this.playerModel.rotation.x = this.gliding ? -Math.PI / 2.3 + this.input.pitch * 0.45 : 0;
      this.playerHead.rotation.x = this.gliding ? 0.5 : this.input.pitch;
      const walkSwing = isMoving && this.grounded ? Math.sin(this.elapsed * (input.run ? 14 : 10)) * 0.65 : 0;
      this.playerLegs[0].rotation.x = walkSwing;
      this.playerLegs[1].rotation.x = -walkSwing;
      this.playerArms[0].rotation.x = -walkSwing;
      this.playerArms[1].rotation.x = walkSwing - (this.input.mining ? Math.abs(Math.sin(this.elapsed * 16)) * 1.1 : 0);
    } else {
      this.playerModel.visible = false;
      this.camera.position.set(this.position.x, eyeY, this.position.z);
    }
  }

  raycast(): Target | null {
    const origin = this.camera.position, cosPitch = Math.cos(this.input.pitch);
    const reach = this.meta.mode === 'creative' ? 5.6 : 4.6;
    const hit = traceVoxelRay(
      [origin.x, origin.y, origin.z],
      [-Math.sin(this.input.yaw) * cosPitch, Math.sin(this.input.pitch), -Math.cos(this.input.yaw) * cosPitch],
      reach,
      (x, y, z) => this.getCell(x, y, z),
    );
    return hit ? { ...hit, normal: new THREE.Vector3(hit.normal.x, hit.normal.y, hit.normal.z) } : null;
  }

  private updateOutline() {
    if (!this.target) {
      this.outline.visible = false;
      return;
    }
    const t = this.target;
    const cell = this.getCell(t.x, t.y, t.z);
    const def = BLOCKS[t.id];
    const boxes = def ? selectionBoxes(def, blockState(cell)) : null;
    if (boxes && boxes.length > 0) {
      const [x0, y0, z0, x1, y1, z1] = boxes[0];
      this.outline.scale.set((x1 - x0) + 0.008, (y1 - y0) + 0.008, (z1 - z0) + 0.008);
      this.outline.position.set(t.x + (x0 + x1) * 0.5, t.y + (y0 + y1) * 0.5, t.z + (z0 + z1) * 0.5);
    } else {
      this.outline.scale.set(1, 1, 1);
      this.outline.position.set(t.x + 0.5, t.y + 0.5, t.z + 0.5);
    }
    this.outline.visible = true;
  }

  mining(dt: number) {
    this.breakCooldown = Math.max(0, this.breakCooldown - dt);
    this.target = this.raycast();
    this.updateOutline();
    this.crack.visible = false;

    if (!this.input.mining || this.meta.mode === 'spectator' || this.meta.mode === 'adventure') {
      this.breaking = 0;
      this.swingHeld = false;
      return;
    }

    const held = this.hotbar[this.selected], tool = held ? resolve(held.name) : undefined;

    // Mob attack runs FIRST: cooldown-scaled damage, crits, sweeps and weapon enchantments live in survival.ts.
    if (SV.tryAttack(this, held ?? null, tool)) {
      this.breaking = 0;
      return;
    }

    if (!this.target || this.breakCooldown > 0) {
      this.breaking = 0;
      return;
    }

    if (this.meta.mode === 'creative' && tool?.tool === 'sword') return;

    const t = this.target, b = BLOCKS[t.id];
    if (!Number.isFinite(b.hardness)) return;

    if (this.elapsed - this.hitAt > 0.25) {
      this.hitAt = this.elapsed;
      this.audio?.play(
        b.pattern === 'glass' ? 'glass' :
        b.pattern === 'sand' || b.pattern === 'gravel' ? 'sand' :
        b.tool === 'pickaxe' ? 'stone' : 'wood',
        t,
      );
    }

    const key = `${t.x},${t.y},${t.z}:${this.selected}:${held?.name ?? ''}`;
    if (key !== this.breakKey) { this.breakKey = key; this.breaking = 0; }

    const underwater = this.getBlock(this.camera.position.x, this.camera.position.y, this.camera.position.z) === ID.water;
    const duration = this.meta.mode === 'creative' ? 0 : miningTime(b, tool, this.grounded, underwater) * SV.miningFactor(this, held ?? null, underwater);
    this.breaking += duration === 0 ? 1 : dt / duration;

    if (this.breaking >= 1) {
      this.particles.burst(new THREE.Vector3(t.x + 0.5, t.y + 0.5, t.z + 0.5), b.color, 18);
      if (this.meta.mode !== 'creative') {
        for (const drop of SV.drops(this, b, tool, held ?? null, blockState(this.getCell(t.x, t.y, t.z)))) {
          this.particles.drop(new THREE.Vector3(t.x + 0.5, t.y + 0.5, t.z + 0.5), drop.name, drop.count, resolve(drop.name)?.color ?? b.color);
        }
        if (held && tool?.durability && b.hardness > 0) SV.wear(this, 'main', 1);
      }
      const brokenState = blockState(this.getCell(t.x, t.y, t.z));
      if (t.id === ID.obsidian) this.shatterAdjacentPortal(t.x, t.y, t.z);
      this.setBlock(t.x, t.y, t.z, 0);
      this.afterBreak(t.x, t.y, t.z, b, brokenState);
      this.audio?.play(b.pattern === 'glass' ? 'glass' : b.tool === 'pickaxe' ? 'stone' : b.tool === 'axe' ? 'wood' : 'grass', t);
      this.statistics.blocks_mined = (this.statistics.blocks_mined ?? 0) + 1;
      if (this.meta.mode !== 'creative') {
        const xpGain = blockExperience(b, tool);
        if (xpGain > 0) this.addXp(xpGain);
      }
      this.breaking = 0;
      this.breakCooldown = this.meta.mode === 'creative' ? 0.22 : duration === 0 ? 0 : 0.25;
      this.achievement('mine');
    } else if (this.meta.mode !== 'creative') {
      this.crack.visible = true;
      this.crack.position.set(t.x + 0.5, t.y + 0.5, t.z + 0.5);
      this.crack.material = this.crackMaterials[Math.min(9, Math.floor(this.breaking * 10))];
    }
  }


  private shatterAdjacentPortal(x: number, y: number, z: number) {
    for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
      if (this.getBlock(x + dx, y + dy, z + dz) === ID.portal) {
        const q = [[x + dx, y + dy, z + dz]];
        const seen = new Set<string>();
        while (q.length && seen.size < 120) {
          const [px, py, pz] = q.pop()!;
          const k = `${px},${py},${pz}`;
          if (seen.has(k) || this.getBlock(px, py, pz) !== ID.portal) continue;
          seen.add(k);
          this.setBlock(px, py, pz, 0);
          for (const [nx, ny, nz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
            q.push([px + nx, py + ny, pz + nz]);
          }
        }
      }
    }
  }

  private tryLightNetherPortal(x: number, y: number, z: number): boolean {
    if (this.dimension === 'end') return false;
    for (const axis of ['x', 'z'] as const) {
      const step = (dx: number, dy: number): [number, number, number] => axis === 'x' ? [x + dx, y + dy, z] : [x, y + dy, z + dx];
      const visited = new Set<string>();
      const queue: [number, number][] = [[0, 0]];
      const inside: [number, number, number][] = [];
      let valid = true;
      while (queue.length) {
        const [u, v] = queue.pop()!;
        if (Math.abs(u) > 9 || Math.abs(v) > 9) { valid = false; break; }
        const k = `${u},${v}`;
        if (visited.has(k)) continue;
        visited.add(k);
        const [wx, wy, wz] = step(u, v);
        const id = this.getBlock(wx, wy, wz);
        if (id === ID.obsidian) continue;
        if (id === 0 || id === ID.fire) {
          inside.push([wx, wy, wz]);
          queue.push([u + 1, v], [u - 1, v], [u, v + 1], [u, v - 1]);
        } else { valid = false; break; }
      }
      if (valid && inside.length >= 6 && inside.length <= 64) {
        for (const [px, py, pz] of inside) this.setBlock(px, py, pz, ID.portal);
        this.audio?.play('portal', { x, y, z });
        this.particles.burst(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), '#b866ff', 28, 4);
        this.achievement('nether');
        this.onToast('ネザーポータルが開きました！', 'Nether Portal ignited!');
        return true;
      }
    }
    return false;
  }

  private checkActivateEndPortal(cx: number, cy: number, cz: number) {
    for (let oy = -1; oy <= 1; oy++) for (let oz = -4; oz <= 4; oz++) for (let ox = -4; ox <= 4; ox++) {
      const rx = cx + ox, ry = cy + oy, rz = cz + oz;
      let ok = true;
      const ringOffsets = [
        [-1, -2], [0, -2], [1, -2],
        [2, -1], [2, 0], [2, 1],
        [1, 2], [0, 2], [-1, 2],
        [-2, 1], [-2, 0], [-2, -1],
      ];
      for (const [dx, dz] of ringOffsets) {
        const cell = this.getCell(rx + dx, ry, rz + dz);
        if (blockId(cell) !== ID.end_portal_frame || (blockState(cell) & 4) === 0) { ok = false; break; }
      }
      if (ok) {
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
          this.setBlock(rx + dx, ry, rz + dz, ID.end_portal);
        }
        this.audio?.play('portal', { x: rx, y: ry, z: rz });
        this.particles.burst(new THREE.Vector3(rx + 0.5, ry + 1, rz + 0.5), '#55f2c4', 40, 6);
        this.onToast('エンドポータルが開通しました！', 'The End Portal is open!');
        return;
      }
    }
  }

  private travelNetherPortal() {
    SV.netherTravel(this);
  }

  private enterEndPortal() {
    if (this.dimension === 'end') {
      this.changeDimension('overworld');
      const p = this.respawnPoint ?? this.terrain.spawnPosition(2);
      this.position.set(p[0], p[1], p[2]);
      this.pause();
      this.onScreen('credits');
      return;
    }
    this.changeDimension('end');
    this.position.set(0.5, 30.5, 42.5);
    this.achievement('end');
  }

  handleDragonDefeated() {
    this.dragonDefeated = true;
    this.mobs.host.dragonDefeated = true;
    this.addXp(500);
    this.achievement('dragon');
    this.onToast('エンダードラゴンを討伐しました！エンドゲートウェイが出現！', 'Ender Dragon defeated! End Gateway opened!');
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dz === 0) continue;
      this.setBlock(dx, 28, dz, ID.end_portal);
    }
    this.setBlock(0, 32, 0, ID.dragon_egg);
    const [gx, gy, gz] = END_GATEWAY_MAIN;
    this.setBlock(gx, gy, gz, ID.end_gateway);
    this.save();
  }

  handleGatewayTravel() {
    if (this.dimension !== 'end') return;
    if (this.position.distanceTo(new THREE.Vector3(...END_GATEWAY_MAIN)) < 20) {
      this.teleport(END_OUTER_ARRIVAL[0], END_OUTER_ARRIVAL[1], END_OUTER_ARRIVAL[2]);
      this.onToast('エンドの外周島（エンドシティ）へ転移しました！', 'Warped to Outer End Islands & End City!');
    } else {
      this.teleport(42, 30, 0);
      this.onToast('エンド本島へ戻りました', 'Returned to Main End Island');
    }
  }

  use() {
    if (this.dead) return;
    this.target = this.raycast();
    const held = this.hotbar[this.selected], def = held ? resolve(held.name) : undefined;
    this.camera.getWorldDirection(this._dir);
    if (SV.useItem(this, held ?? null, def)) return;

    // Equip / Toggle Elytra
    if (held?.name === 'elytra') {
      this.elytraEquipped = !this.elytraEquipped;
      this.onToast(this.elytraEquipped ? 'エリトラを装備しました！' : 'エリトラを外しました', this.elytraEquipped ? 'Elytra equipped!' : 'Elytra unequipped');
      this.audio?.play('wood');
      this.handDip = 0.18;
      return;
    }

    // Firework rocket boost while gliding!
    if (held?.name === 'firework_rocket' && this.gliding) {
      this.velocity.copy(this._dir).multiplyScalar(26);
      this.particles.burst(this.position.clone().add(new THREE.Vector3(0, 1, 0)), '#ff7052', 20, 6);
      this.audio?.play('explosion');
      this.handDip = 0.2;
      if (this.meta.mode !== 'creative') this.consumeSelected();
      return;
    }

    // Snowball / Ender Pearl throwing
    if (held?.name === 'ender_pearl' || held?.name === 'snowball') {
      this.mobs.launchProjectile(held.name, this.camera.position.clone().addScaledVector(this._dir, 0.7), this._dir, 20);
      this.audio?.play('bow');
      this.handDip = 0.2;
      if (this.meta.mode !== 'creative') this.consumeSelected();
      return;
    }

    // Eye of Ender (insert into frame OR throw toward Stronghold!)
    if (held?.name === 'ender_eye') {
      if (this.target && this.target.id === ID.end_portal_frame) {
        const cell = this.getCell(this.target.x, this.target.y, this.target.z);
        const state = blockState(cell);
        if ((state & 4) === 0) {
          this.setBlock(this.target.x, this.target.y, this.target.z, ID.end_portal_frame, state | 4);
          this.audio?.play('stone', this.target);
          this.particles.burst(new THREE.Vector3(this.target.x + 0.5, this.target.y + 1, this.target.z + 0.5), '#5ef577', 14, 3);
          this.handDip = 0.2;
          if (this.meta.mode !== 'creative') this.consumeSelected();
          this.checkActivateEndPortal(this.target.x, this.target.y, this.target.z);
          return;
        }
      }
      const [shx, shz] = this.terrain.strongholdPos();
      const targetPos = new THREE.Vector3(shx, this.camera.position.y + 6, shz);
      this.mobs.launchProjectile('ender_eye', this.camera.position.clone().addScaledVector(this._dir, 0.8), targetPos.clone().sub(this.camera.position), 7, targetPos);
      this.audio?.play('bow');
      this.handDip = 0.2;
      if (this.meta.mode !== 'creative') this.consumeSelected();
      return;
    }

    if (def?.food) {
      if (this.hunger >= 20 && this.meta.mode !== 'creative' && held?.name !== 'golden_apple' && held?.name !== 'enchanted_golden_apple' && held?.name !== 'honey_bottle' && held?.name !== 'chorus_fruit') return;
      this.hunger = Math.min(20, this.hunger + def.food);
      this.health = Math.min(20, this.health + (held?.name === 'golden_apple' ? 6 : 2));
      this.audio?.play('eat');
      this.handDip = 0.22;
      if (held?.name === 'chorus_fruit') {
        const rx = this.position.x + (Math.random() - 0.5) * 14, rz = this.position.z + (Math.random() - 0.5) * 14;
        this.teleport(rx, this.terrain.height(rx, rz) + 1.1, rz);
      }
      if (this.meta.mode !== 'creative') this.consumeSelected();
      return;
    }

    if (held?.name === 'bow') {
      if (this.meta.mode === 'creative' || this.removeItem('arrow', 1)) {
        this.mobs.shootPlayerArrow(this.camera.position, this._dir);
        this.handDip = 0.2;
      } else {
        this.onToast('矢がありません', 'Out of arrows');
      }
      return;
    }

    this.camera.getWorldDirection(this._dir);
    if (held && ['wheat', 'bone', 'bucket', 'shears'].includes(held.name) && this.mobs.interact(this.camera.position, this._dir, held.name)) {
      return;
    }

    const t = this.target;
    if (!t) return;

    // Bucket fluid scooping
    if (held?.name === 'bucket') {
      const fx = t.x + t.normal.x, fy = t.y + t.normal.y, fz = t.z + t.normal.z;
      const fluidId = this.getBlock(fx, fy, fz);
      if (fluidId === ID.water || fluidId === ID.lava) {
        this.setBlock(fx, fy, fz, 0);
        this.hotbar[this.selected] = { name: fluidId === ID.lava ? 'lava_bucket' : 'water_bucket', count: 1 };
        this.audio?.play('water', { x: fx, y: fy, z: fz });
        return;
      }
    }

    if (!this.input.crouch) {
      this.stationKey = `${t.x},${t.y},${t.z}`;
      if (SV.openStation(this, t)) return;
      if (t.id === ID.crafting_table) { this.pause(true); this.onScreen('workbench'); return; }
      if ([ID.furnace, ID.blast_furnace, ID.smoker].includes(t.id)) {
        this.containers[this.stationKey] ??= [null, null, null];
        this.furnaces[this.stationKey] ??= { burn: 0, progress: 0 };
        this.pause(true);
        this.onScreen('furnace');
        return;
      }
      if (t.id === ID.chest || t.id === ID.barrel || t.id === ID.shulker_box) {
        const above = BLOCKS[this.getBlock(t.x, t.y + 1, t.z)];
        if (t.id === ID.chest && above?.solid && !above.transparent && above.shape === 'cube') {
          this.onToast('チェストの上がふさがっています', 'The chest is blocked');
          return;
        }
        this.containers[this.stationKey] ??= t.id === ID.chest ? this.lootFor(t.x, t.y, t.z) : Array(27).fill(null);
        this.audio?.play('chest', t);
        this.pause(true);
        this.onScreen('container');
        return;
      }
      if (t.id === ID.lever || BLOCKS[t.id].name.endsWith('_button')) {
        if (this.redstone.press(t.x, t.y, t.z)) this.audio?.play('click', t);
        return;
      }
const tdef = BLOCKS[t.id];
      // Iron doors only answer to redstone, like vanilla.
      if (tdef.shape === 'door' && tdef.name !== 'iron_door') { this.toggleDoor(t.x, t.y, t.z); return; }
      if (tdef.shape === 'trapdoor') {
        this.setBlock(t.x, t.y, t.z, t.id, blockState(this.getCell(t.x, t.y, t.z)) ^ 8);
        this.audio?.play('door', t);
        return;
      }
      if (tdef.name.startsWith('open_') && tdef.name.endsWith('_door')) {
        // "Open door" blocks from older saves turn back into a normal closed door.
        const to = ID[tdef.name.slice(5)];
        if (to !== undefined) for (const dy of [0, 1, -1]) {
          const cell = this.getCell(t.x, t.y + dy, t.z);
          if (blockId(cell) === t.id) this.setBlock(t.x, t.y + dy, t.z, to, blockState(cell) & 1);
        }
        this.audio?.play('door', t);
        return;
      }
      if (t.id === ID.bed) {
        if (this.dimension !== 'overworld') {
          const bedState = blockState(this.getCell(t.x, t.y, t.z));
          this.setBlock(t.x, t.y, t.z, 0);
          this.afterBreak(t.x, t.y, t.z, BLOCKS[t.id], bedState);
          this.explode(new THREE.Vector3(t.x + 0.5, t.y + 0.5, t.z + 0.5), 5);
          this.onToast('ネザー・エンドではベッドは爆発します！', 'Intentional Game Design!');
          return;
        }
        this.respawnPoint = [t.x + 0.5, t.y + 0.7, t.z + 0.5];
        if (this.time < 0.05 || this.time > 0.45 || this.weather === 'storm') {
          this.sleeping = true;
          this.sleepTimer = 1.6;
          this.onToast('おやすみなさい…', 'Sleeping through the night…');
        } else {
          this.onToast('リスポーン地点を設定しました（夜か雷雨のときに眠れます）', 'Respawn point set (sleep at night or during storms)');
        }
        return;
      }
      if (t.id === ID.portal) { this.audio?.play('portal'); this.travelNetherPortal(); return; }
      if (t.id === ID.end_portal) { this.audio?.play('portal'); this.enterEndPortal(); return; }
      if (t.id === ID.end_gateway) { this.audio?.play('portal'); this.handleGatewayTravel(); return; }
    }

    if (!held) return;

    // Flint & Steel ignites Nether Portals, TNT, or fires!
    if (held.name === 'flint_and_steel') {
      if (t.id === ID.tnt) { this.simulation.enqueue(t.x, t.y, t.z, ID.tnt); return; }
      const fx = t.x + t.normal.x, fy = t.y + t.normal.y, fz = t.z + t.normal.z;
      if (!this.tryLightNetherPortal(fx, fy, fz)) {
        if (t.id === ID.obsidian) {
          for (let dy = 1; dy <= 3; dy++) for (let dx = -1; dx <= 1; dx++) {
            if (this.getBlock(t.x + dx, t.y + dy, t.z) === 0) this.setBlock(t.x + dx, t.y + dy, t.z, ID.portal);
          }
          this.audio?.play('portal', t);
          this.achievement('nether');
          this.onToast('ネザーポータルが開きました！', 'Nether Portal ignited!');
        } else {
          if (this.getBlock(fx, fy, fz) === 0) this.setBlock(fx, fy, fz, ID.fire);
          this.audio?.play('stone', { x: fx, y: fy, z: fz });
        }
      }
      this.handDip = 0.18;
      return;
    }

    // Place End Crystal on Obsidian/Bedrock
    if (held.name === 'end_crystal') {
      if (t.id === ID.obsidian || t.id === ID.bedrock) {
        this.mobs.spawnCrystal(t.x, t.y + 1, t.z);
        SV.checkDragonRespawn(this);
        this.audio?.play('place', t);
        this.handDip = 0.18;
        if (this.meta.mode !== 'creative') this.consumeSelected();
      }
      return;
    }
    let name = held.name;
    const isBucketFluid = name === 'water_bucket' || name === 'lava_bucket';
    if (name === 'water_bucket') name = 'water';
    else if (name === 'lava_bucket') name = 'lava';
    const id = ID[name];
    if (id === undefined) return;

    const placedDef = BLOCKS[id], p = this.position;
    if (id === t.id && isSlabBlock(placedDef)) {
      const current = blockState(this.getCell(t.x, t.y, t.z));
      const canCombine = (current === 0 && t.normal.y === 1) || (current === 1 && t.normal.y === -1);
      if (canCombine) {
        for (const box of collisionBoxes(placedDef, 2)) {
          if (intersectsBox(t.x, t.y, t.z, p.x - 0.3, p.y, p.z - 0.3, p.x + 0.3, p.y + 1.8, p.z + 0.3, box)) return;
        }
        if (this.setBlock(t.x, t.y, t.z, id, 2)) {
          this.statistics.blocks_placed = (this.statistics.blocks_placed ?? 0) + 1;
          this.audio?.play('place', t);
          this.handDip = 0.16;
          if (this.meta.mode !== 'creative') this.consumeSelected();
          this.achievement('place');
        }
        return;
      }
    }

    const x = t.x + t.normal.x, y = t.y + t.normal.y, z = t.z + t.normal.z;
    if (y >= MIN_Y + HEIGHT || y < MIN_Y) return;
    const existing = this.getBlock(x, y, z);
    if (existing < 0 || (existing > 0 && BLOCKS[existing]?.solid)) return;

    const hitY = this.camera.position.y + Math.sin(this.input.pitch) * t.distance - t.y;
    const state = stateForPlacement(placedDef, this.input.yaw, t.normal, hitY);
    if (state < 0) return;
    if (placedDef.shape === 'door') {
      // A door is two blocks tall and needs a solid block to stand on.
      const aboveId = this.getBlock(x, y + 1, z);
      if (y + 1 >= MIN_Y + HEIGHT || aboveId < 0 || (aboveId > 0 && BLOCKS[aboveId]?.solid) || !BLOCKS[this.getBlock(x, y - 1, z)]?.solid) return;
    }
    let bedHead: [number, number, number] | null = null;
    if (placedDef.name === 'bed') {
      // A bed needs a second free cell for its head.
      const hx = x + [1, 0, -1, 0][state & 3], hz = z + [0, 1, 0, -1][state & 3], hid = this.getBlock(hx, y, hz);
      if (hid < 0 || (hid > 0 && BLOCKS[hid]?.solid)) return;
      bedHead = [hx, y, hz];
    }
    for (const box of collisionBoxes(placedDef, state)) {
      if (intersectsBox(x, y, z, p.x - 0.3, p.y, p.z - 0.3, p.x + 0.3, p.y + 1.8, p.z + 0.3, box)) return;
    }

    if (this.setBlock(x, y, z, id, state)) {
      if (bedHead) this.setBlock(bedHead[0], bedHead[1], bedHead[2], id, state | 4);
      if (placedDef.shape === 'door') this.setBlock(x, y + 1, z, id, state | 4);
      this.statistics.blocks_placed = (this.statistics.blocks_placed ?? 0) + 1;
      this.audio?.play(id === ID.water || id === ID.lava ? 'water' : placedDef.tool === 'pickaxe' ? 'stone' : 'place', { x, y, z });
      this.handDip = 0.16;
      if (this.meta.mode !== 'creative') {
        if (isBucketFluid) this.hotbar[this.selected] = { name: 'bucket', count: 1 };
        else this.consumeSelected();
      }
      this.achievement('place');
    }
  }


  /** Opens or closes both halves of the door at x,y,z (state bit 3). `force` sets a definite state (redstone). */
  toggleDoor(x: number, y: number, z: number, force?: boolean) {
    const cell = this.getCell(x, y, z), id = blockId(cell), def = BLOCKS[id];
    if (!def) return;
    if (def.shape === 'trapdoor') {
      const st = blockState(cell), open = force ?? !(st & 8);
      if (((st & 8) !== 0) !== open) { this.setBlock(x, y, z, id, open ? st | 8 : st & 7); this.audio?.play('door', { x, y, z }); }
      return;
    }
    if (def.shape !== 'door') return;
    const st = blockState(cell), open = force ?? (st & 8) === 0;
    if (((st & 8) !== 0) === open) return;
    const below = this.getCell(x, y - 1, z);
    const dy = st & 4 ? -1 : blockId(this.getCell(x, y + 1, z)) === id ? 1 : blockId(below) === id && !(blockState(below) & 4) ? -1 : 0;
    for (const o of dy ? [0, dy] : [0]) {
      const c = this.getCell(x, y + o, z);
      if (blockId(c) === id) this.setBlock(x, y + o, z, id, open ? blockState(c) | 8 : blockState(c) & 7);
    }
    this.audio?.play('door', { x, y, z });
  }

  /** Pressure plates: pressed while the player stands on them, which powers the block below. */
  private updateButtons() {
    const fx = Math.floor(this.position.x), fy = Math.floor(this.position.y + 0.05), fz = Math.floor(this.position.z);
    const id = this.getBlock(fx, fy, fz), def = BLOCKS[id];
    const on = !!def && def.name.endsWith('_pressure_plate') && this.grounded;
    if (this.plate && (!on || this.plate[0] !== fx || this.plate[1] !== fy || this.plate[2] !== fz)) {
      this.redstone.setPlate(this.plate[0], this.plate[1], this.plate[2], false);
      this.plate = null;
    }
    this.redstone.setPlate(fx, fy, fz, on);
    if (on) this.plate = [fx, fy, fz];
  }

  /** After a block is broken: remove the other half of a door and everything that stood on it or was mounted on it. */
  private afterBreak(x: number, y: number, z: number, def: (typeof BLOCKS)[number], state: number) {
    if (def.name === 'bed') {
      const k = state & 4 ? -1 : 1, ox = x + [1, 0, -1, 0][state & 3] * k, oz = z + [0, 1, 0, -1][state & 3] * k;
      if (this.getBlock(ox, y, oz) === def.id) this.setBlock(ox, y, oz, 0);
    }
    if (def.shape === 'door') {
      const dy = state & 4 ? -1 : 1;
      if (this.getBlock(x, y + dy, z) === def.id) this.setBlock(x, y + dy, z, 0);
      else if (!(state & 4) && this.getBlock(x, y - 1, z) === def.id) this.setBlock(x, y - 1, z, 0);
    }
    const pop = (px: number, py: number, pz: number) => {
      const cell = this.getCell(px, py, pz), d = BLOCKS[blockId(cell)], st = blockState(cell);
      if (!d) return;
      if (this.meta.mode !== 'creative' && !(d.shape === 'door' && st & 4)) {
        for (const drop of blockDrops(d, undefined, st)) this.particles.drop(new THREE.Vector3(px + 0.5, py + 0.5, pz + 0.5), drop.name, drop.count, resolve(drop.name)?.color ?? d.color);
      }
      this.setBlock(px, py, pz, 0);
    };
    for (let yy = y + 1; yy < y + 16; yy++) {
      const cell = this.getCell(x, yy, z), id = blockId(cell), d = BLOCKS[id];
      if (id <= 0 || !d) break;
      const standing = d.shape === 'cross' || d.shape === 'lily' || d.shape === 'cactus' || d.shape === 'door' || (d.shape === 'torch' && (!isAttachable(d) || (blockState(cell) & 7) === 0))
        || d.name === 'redstone_wire' || d.name === 'repeater' || d.name === 'comparator' || d.name.endsWith('rail') || d.name.endsWith('_pressure_plate') || d.name.endsWith('_carpet');
      if (!standing) break;
      pop(x, yy, z);
      if (d.shape !== 'cactus' && d.shape !== 'door' && d.name !== 'sugar_cane') break;
    }
    for (const [dx, dy, dz, at, edge] of [[1, 0, 0, 1, 1], [-1, 0, 0, 2, 3], [0, 0, 1, 3, 0], [0, 0, -1, 4, 2], [0, -1, 0, 5, -1]]) {
      const cell = this.getCell(x + dx, y + dy, z + dz), d = BLOCKS[blockId(cell)];
      if (!d || d.id <= 0) continue;
      if ((isAttachable(d) && (blockState(cell) & 7) === at) || (d.name === 'ladder' && (blockState(cell) & 3) === edge)) pop(x + dx, y + dy, z + dz);
    }
  }

  /** The first time a chest that came with the world is opened it is filled from a loot table, like vanilla structure chests. Player-placed chests start empty. */
  private lootFor(x: number, y: number, z: number): (Stack | null)[] {
    const slots: (Stack | null)[] = Array(27).fill(null);
    if (this.edits.has(`${x},${y},${z}`)) return slots;
    const extraKind = extraLootTable(this.terrain, x, y, z);
    if (extraKind) return SV.rollLoot(this, extraKind, x, y, z);
    if (this.dimension === 'end' && x > 525 && y > 35) {
      // End Ship Treasure Chest!
      slots[11] = { name: 'elytra', count: 1 };
      slots[13] = { name: 'diamond', count: 8 };
      slots[15] = { name: 'emerald', count: 12 };
      slots[4] = { name: 'diamond_sword', count: 1 };
      slots[22] = { name: 'firework_rocket', count: 16 };
      return slots;
    }
    if (this.dimension === 'end') {
      slots[2] = { name: 'diamond', count: 6 };
      slots[10] = { name: 'iron_ingot', count: 14 };
      slots[14] = { name: 'ender_pearl', count: 4 };
      slots[18] = { name: 'golden_apple', count: 2 };
      return slots;
    }
    if (this.dimension === 'overworld' && y <= 44) {
      const [shx, shz] = this.terrain.strongholdPos();
      if (Math.hypot(x - shx, z - shz) < 28) {
        slots[4] = { name: 'ender_pearl', count: 4 };
        slots[9] = { name: 'ender_eye', count: 2 };
        slots[12] = { name: 'iron_ingot', count: 10 };
        slots[14] = { name: 'apple', count: 5 };
        slots[21] = { name: 'diamond', count: 3 };
        return slots;
      }
    }
    let table = LOOT.village;
    if (this.dimension === 'nether') table = LOOT.fortress;
    else {
      let spawner = false;
      for (let dy = -1; dy <= 1 && !spawner; dy++) for (let dz = -4; dz <= 4 && !spawner; dz++) for (let dx = -4; dx <= 4; dx++) {
        if (this.getBlock(x + dx, y + dy, z + dz) === ID.spawner) { spawner = true; break; }
      }
      if (spawner) table = LOOT.dungeon;
      else if (ID.blue_terracotta !== undefined && this.getBlock(x, y - 1, z) === ID.blue_terracotta) table = LOOT.temple;
    }
    let h = (Math.imul(x, 73856093) ^ Math.imul(y, 19349663) ^ Math.imul(z, 83492791) ^ this.terrain.seed) >>> 0;
    const rnd = () => { h = (Math.imul(h ^ (h >>> 15), 2246822519) + 0x9e3779b9) >>> 0; return ((h ^ (h >>> 13)) >>> 0) / 4294967296; };
    const total = table.items.reduce((sum, it) => sum + it[3], 0);
    const rolls = table.rolls[0] + Math.floor(rnd() * (table.rolls[1] - table.rolls[0] + 1));
    for (let i = 0; i < rolls; i++) {
      let pick = rnd() * total, item = table.items[0];
      for (const it of table.items) { pick -= it[3]; if (pick <= 0) { item = it; break; } }
      const slot = Math.floor(rnd() * 27);
      if (slots[slot] || !resolve(item[0])) continue;
      slots[slot] = { name: item[0], count: item[1] + Math.floor(rnd() * (item[2] - item[1] + 1)) };
    }
    return slots;
  }

  /** Comparator reading for a container: empty = 0, full = 15. */
  containerSignal(x: number, y: number, z: number): number {
    const slots = this.containers[`${x},${y},${z}`];
    if (!slots || !slots.length) return 0;
    let items = 0;
    for (const s of slots) items += s?.count ?? 0;
    return items === 0 ? 0 : Math.min(15, Math.floor(1 + (items / (slots.length * 64)) * 14));
  }

  private stackFrom(x: number, y: number, z: number): Stack | null {
    const key = `${x},${y},${z}`, slots = this.containers[key] ??= Array(9).fill(null);
    for (let i = 0; i < slots.length; i++) {
      const s = slots[i];
      if (!s) continue;
      s.count--;
      if (s.count <= 0) slots[i] = null;
      return { ...s, count: 1 };
    }
    return null;
  }

  /** Dispensers and droppers: droppers pass the item into a container they face, dispensers eject it into the world. */
  private ejectFrom(x: number, y: number, z: number, dir: number, kind: 'dispenser' | 'dropper'): boolean {
    const stack = this.stackFrom(x, y, z);
    if (!stack) return false;
    const f = [[1, 0, 0], [0, 0, 1], [-1, 0, 0], [0, 0, -1], [0, 1, 0], [0, -1, 0]][dir] ?? [1, 0, 0];
    const tx = x + f[0], ty = y + f[1], tz = z + f[2];
    if (kind === 'dropper') {
      const slots = this.containers[`${tx},${ty},${tz}`];
      if (slots) {
        const hit = slots.find(s => s && s.name === stack.name && s.count < 64) ?? slots.find(s => !s);
        if (hit) { if (hit.name) hit.count += 1; else { hit.name = stack.name; hit.count = 1; } return true; }
      }
    }
    for (let i = 0; i < 4; i++) {
      const target = this.getBlock(tx, ty, tz);
      if (target < 0) break;
      if (target === 0) {
        this.particles.drop(new THREE.Vector3(tx + 0.5 + f[0] * 2, ty + 0.5, tz + 0.5 + f[2] * 2), stack.name, 1, resolve(stack.name)?.color ?? '#ccc');
        break;
      }
    }
    return true;
  }

  /** Hoppers pull one item from the container above and push it into the container they face (or below). */
  private hopperTransfer(x: number, y: number, z: number, dir: number): boolean {
    if (this.getBlock(x, y + 1, z) <= 0) return false;
    const src = this.stackFrom(x, y + 1, z);
    if (!src) return false;
    const f = [[1, 0, 0], [0, 0, 1], [-1, 0, 0], [0, 0, -1], [0, 1, 0], [0, -1, 0]][dir] ?? [0, -1, 0];
    const slots = this.containers[`${x + f[0]},${y + f[1]},${z + f[2]}`] ??= Array(9).fill(null);
    const hit = slots.find(s => s && s.name === src.name && s.count < 64) ?? slots.find(s => !s);
    if (hit) { if (hit.name) hit.count += 1; else { hit.name = src.name; hit.count = 1; } return true; }
    this.particles.drop(new THREE.Vector3(x + 0.5, y - 0.2, z + 0.5), src.name, 1, resolve(src.name)?.color ?? '#ccc');
    return true;
  }

  countItem(name: string) {
    return [...this.hotbar, ...this.inventory].reduce((n, s) => n + (s?.name === name ? s.count : 0), 0);
  }

  removeItem(name: string, count: number) {
    if (this.countItem(name) < count) return false;
    for (const arr of [this.hotbar, this.inventory]) {
      for (let i = 0; i < arr.length; i++) {
        const s = arr[i];
        if (s?.name === name) {
          const n = Math.min(count, s.count);
          s.count -= n; count -= n;
          if (s.count <= 0) arr[i] = null;
          if (!count) return true;
        }
      }
    }
    return true;
  }

  command(text: string) {
    const [cmd, ...args] = text.trim().replace(/^\//, '').split(/\s+/);
    if (!text.startsWith('/')) return 'Steve: ' + text;
    switch (cmd) {
      case 'help':
        return '/effect give <effect> [sec] [amp] · /enchant <id> [lvl] · /xp <n|nL> · /clear · /locate mineshaft|shipwreck|monument|mansion|outpost|ancient_city|bastion · ' + '/give <item> [count] · /tp <x> <y> <z> · /time day|night|<0–1> · /weather clear|rain|storm · /gamemode survival|creative|adventure|spectator · /setblock <x> <y> <z> <block> · /dimension overworld|nether|end · /summon <mob> · /locate <stronghold|endcity|village|dungeon|pyramid|fortress|biome> · /seed';
      case 'locate': {
        const what = (args[0] === 'structure' || args[0] === 'biome' ? args[1] : args[0]) ?? '';
        const hit = what ? this.terrain.locate(what.replace(/^minecraft:/, ''), this.position.x, this.position.z) : null;
        if (!hit) return 'Could not find "' + what + '" nearby. Try: stronghold, endcity, village, dungeon, pyramid, fortress or a biome name';
        return `The nearest ${what} is at ${hit[0]}, ${hit[1]}, ${hit[2]} (${Math.round(Math.hypot(hit[0] - this.position.x, hit[2] - this.position.z))} blocks away)`;
      }
      case 'seed': return this.meta.seed;
      case 'weather':
        if (args[0] === 'clear' || args[0] === 'rain' || args[0] === 'storm') {
          this.weather = args[0]; this.weatherTimer = 90;
          return 'Weather set to ' + args[0];
        }
        return 'Usage: /weather clear|rain|storm';
      case 'summon': {
        const species = args[0] as Species;
        if (this.mobs.spawn(species, this.position.x + 3, this.position.z + 3)) return 'Summoned ' + species;
        return 'Cannot spawn here';
      }
      case 'time': {
        const v = args[0] === 'day' ? 0.2 : args[0] === 'night' ? 0.72 : Number(args[0]);
        if (!Number.isFinite(v)) return 'Usage: /time day|night|0–1';
        this.time = ((v % 1) + 1) % 1;
        return 'Time set to ' + this.time.toFixed(2);
      }
      case 'gamemode':
        if (['creative', 'survival', 'adventure', 'spectator'].includes(args[0])) {
          this.meta.mode = args[0] as any;
          return 'Game mode: ' + args[0];
        }
        return 'Unknown game mode';
      case 'give': {
        const n = Math.min(640, Math.max(1, Number(args[1]) || 1));
        if (!resolve(args[0])) return 'Unknown item: ' + args[0];
        return this.addItem(args[0], n) ? 'Given ' + n + ' ' + args[0] : 'Inventory full';
      }
      case 'tp': {
        const p = args.map(Number);
        if (p.length !== 3 || !p.every(Number.isFinite)) return 'Usage: /tp x y z';
        this.teleport(p[0], p[1], p[2]);
        return 'Teleported to ' + p.join(', ');
      }
      case 'setblock': {
        const p = args.slice(0, 3).map(Number), id = ID[args[3]];
        if (p.length !== 3 || !p.every(Number.isFinite) || id === undefined) return 'Usage: /setblock x y z block_id';
        return this.setBlock(p[0], p[1], p[2], id) ? 'Block placed' : 'Chunk not loaded';
      }
      case 'dimension':
        if (['overworld', 'nether', 'end'].includes(args[0])) {
          this.changeDimension(args[0] as Dimension);
          return 'Traveling to ' + args[0];
        }
        return 'Unknown dimension';
      case 'effect': case 'enchant': case 'xp': case 'clear': case 'kill':
        return SV.command(this, cmd, args);
      default: return 'Unknown command. /help';
    }
  }

  consumeSelected() {
    const s = this.hotbar[this.selected];
    if (s) { s.count--; if (s.count <= 0) this.hotbar[this.selected] = null; }
  }

  addItem(name: string, count: number) {
    const def = resolve(name);
    if (!def || !Number.isInteger(count) || count <= 0) return false;
    const max = def.stack, slots = [...this.hotbar, ...this.inventory];
    const capacity = slots.reduce((sum, slot) => sum + (!slot ? max : slot.name === name ? Math.max(0, max - slot.count) : 0), 0);
    if (capacity < count) return false;
    let remaining = count;
    for (const slot of slots) {
      if (slot?.name === name && slot.count < max) {
        const n = Math.min(max - slot.count, remaining);
        slot.count += n; remaining -= n;
        if (!remaining) return true;
      }
    }
    for (const arr of [this.hotbar, this.inventory]) {
      for (let i = 0; i < arr.length; i++) {
        if (!arr[i]) {
          const n = Math.min(max, remaining);
          arr[i] = { name, count: n }; remaining -= n;
          if (!remaining) return true;
        }
      }
    }
    return true;
  }

  addXp(n: number) {
    if (n <= 0) return;
    n = SV.mend(this, n);
    if (n <= 0) return;
    this.xp += n;
    const lvl = Math.floor(Math.sqrt(this.xp));
    if (lvl > this.lastLevel) {
      this.lastLevel = lvl;
      this.audio?.play('levelup');
      this.onToast(`レベル ${lvl} に到達！`, `Level ${lvl} reached!`);
    }
  }

  private computeArmor(): number {
    return SV.armorPoints(this);
  }

  dropSelected() {
    const s = this.hotbar[this.selected];
    if (!s) return;
    this.camera.getWorldDirection(this._dir);
    this.particles.drop(this.camera.position.clone().addScaledVector(this._dir, 1.5), s.name, 1, resolve(s.name)?.color ?? '#aaa');
    SV.rememberDrop(this, s);
    this.statistics.dropped = (this.statistics.dropped ?? 0) + 1;
    s.count--;
    if (s.count <= 0) this.hotbar[this.selected] = null;
  }

  craftRecipe(id: string, table: boolean, all = false) {
    const r = RECIPES.find(x => x.id === id);
    if (!r) return false;
    let crafted = false;
    const loops = all ? 64 : 1;
    for (let i = 0; i < loops; i++) {
      if (!canCraft(r, recipeCounts([...this.hotbar, ...this.inventory]), this.meta.mode === 'creative', table)) break;
      const backup = this.hotbar.map(s => (s ? { ...s } : null));
      const backupInv = this.inventory.map(s => (s ? { ...s } : null));
      if (this.meta.mode !== 'creative') {
        for (const [n, c] of Object.entries(r.ingredients)) this.removeItem(n, c);
      }
      if (!this.addItem(r.result, r.count)) {
        this.hotbar = backup;
        this.inventory = backupInv;
        break;
      }
      crafted = true;
      if (this.meta.mode === 'creative') break;
    }
    if (crafted) {
      this.achievement('craft');
      this.audio?.play('wood');
    }
    return crafted;
  }

  trade(give: string, cost: number, result: string, count: number) {
    const backup = this.hotbar.map(s => (s ? { ...s } : null));
    const backupInv = this.inventory.map(s => (s ? { ...s } : null));
    if (this.removeItem(give, cost) && this.addItem(result, count)) return true;
    this.hotbar = backup;
    this.inventory = backupInv;
    return false;
  }

  updateStations(dt: number) {
    const keys = Object.keys(this.furnaces), count = Math.min(8, keys.length);
    if (!count) return;
    const elapsed = dt * Math.max(1, keys.length / count);
    for (let i = 0; i < count; i++) {
      const key = keys[(this.stationCursor + i) % keys.length];
      const state = this.furnaces[key], slots = this.containers[key];
      if (state && slots?.length === 5) { SV.brewTick(this, state, slots, elapsed); continue; }
      if (!state || !slots || slots.length !== 3) continue;
      const input = slots[0], fuel = slots[1], output = slots[2];
      const recipe = input ? SMELTING[input.name] : undefined;
      state.burn = Math.max(0, state.burn - elapsed);
      if (recipe && (!output || (output.name === recipe.result && output.count < 64))) {
        if (state.burn <= 0 && fuel && FUEL[fuel.name]) {
          state.burn = FUEL[fuel.name];
          fuel.count--;
          if (fuel.count <= 0) slots[1] = fuel.name === 'lava_bucket' ? { name: 'bucket', count: 1 } : null;
        }
        if (state.burn > 0) {
          state.progress += elapsed / recipe.time;
          if (state.progress >= 1) {
            state.progress = 0;
            input!.count--;
            if (input!.count <= 0) slots[0] = null;
            if (output) output.count++;
            else slots[2] = { name: recipe.result, count: 1 };
            this.audio?.play('stone');
          }
        }
      } else {
        state.progress = 0;
      }
    }
    this.stationCursor = (this.stationCursor + count) % keys.length;
  }

  explode(p: THREE.Vector3, r: number) {
    this.audio?.play('explosion', p);
    this.particles.burst(p, '#e8c28a', 40, 8);
    this.particles.burst(p, '#6b675c', 30, 5);
    const d = p.distanceTo(this.position);
    if (d < r * 2) this.damage(Math.ceil((r * 2 - d) * 2), 'explosion');
    for (let y = -r; y <= r; y++) for (let z = -r; z <= r; z++) for (let x = -r; x <= r; x++) {
      if (x * x + y * y + z * z <= r * r) this.explosionQueue.push([p.x + x, p.y + y, p.z + z]);
    }
  }

  swapSlots(a: number, b: number) {
    return SV.swapSlots(this, a, b);
  }

  toggleElytra() { SV.toggleElytra(this); }

  give(name: string, count = 64) {
    const def = resolve(name);
    if (!def) return false;
    const ok = this.addItem(name, count);
    this.onToast(def.ja + ' × ' + count, def.name + ' × ' + count);
    return ok;
  }

  achievement(id: string) {
    if (!this.achievements.includes(id)) {
      this.achievements.push(id);
      const names: Record<string, string> = {
        mine: 'はじまりの一歩',
        place: '建築の時間',
        craft: 'ものづくりの達人',
        nether: 'さらなる深みへ（ネザー）',
        end: 'おしまい？（ジ・エンド）',
        dragon: 'エンドの解放（エンドラ討伐）',
        enchant: 'エンチャントの使い手',
        brew: '町のお薬屋さん',
      };
      this.onToast('進捗達成: ' + (names[id] ?? id), 'Advancement: ' + id);
    }
  }

  damage(amount: number, source = 'generic') {
    SV.hurt(this, amount, source);
  }

  respawn() {
    SV.clearEffects(this);
    this.health = 20;
    this.hunger = 20;
    this.dead = false;
    this.gliding = false;
    this.levitationTimer = 0;
    if (this.dimension !== 'overworld') this.changeDimension('overworld');
    const p = this.respawnPoint ?? this.terrain.spawnPosition(2);
    this.position.set(p[0], p[1], p[2]);
    this.velocity.set(0, 0, 0);
    this.fallTop = this.position.y;
  }

  teleport(x: number, y: number, z: number) {
    this.position.set(x, y, z);
    this.velocity.set(0, 0, 0);
    this.fallTop = y;
    this.focus = '';
  }

  changeDimension(dimension: Dimension) {
    if (dimension === this.dimension) return;
    this.dimensionStores[this.dimension] = { edits: this.edits, containers: this.containers, furnaces: this.furnaces };
    this.dimension = dimension;
    this.attachDimensionStore(dimension);
    this.terrain = new Terrain(this.meta.seed, dimension);
    this.mobs.host.terrain = this.terrain;
    this.mobs.host.dimension = dimension;
    this.mobs.clear();
    this.particles.clear();
    this.simulation.clear();
    this.clearChunks();
    const spawnY = dimension === 'end' ? Math.max(24, this.terrain.height(0, 8) + 2) : this.terrain.height(0, 8) + 2;
    if (dimension !== 'end') this.position.set(...this.terrain.spawnPosition(2));
    else this.position.set(0, spawnY, 8);
    this.mobs.populate();
    this.velocity.set(0, 0, 0);
    this.gliding = false;
    this.portalCharge = 0;
    this.levitationTimer = 0;
    this.ready = false;
    this.focus = '';
    this.streamAt = -10;
    this.environment.markShadow();
  }

  snapshot(): WorldSave {
    this.dimensionStores[this.dimension] = { edits: this.edits, containers: this.containers, furnaces: this.furnaces };
    const dimensions: NonNullable<WorldSave['dimensions']> = {};
    for (const dimension of ['overworld', 'nether', 'end'] as const) {
      const store = this.dimensionStores[dimension];
      if (store) dimensions[dimension] = { edits: [...store.edits], containers: store.containers, furnaces: store.furnaces };
    }
    return {
      meta: { ...this.meta, updated: Date.now() },
      position: this.position.toArray() as [number, number, number],
      yaw: this.input.yaw,
      pitch: this.input.pitch,
      time: this.time,
      dimension: this.dimension,
      edits: [...this.edits],
      inventory: this.inventory,
      hotbar: this.hotbar,
      health: this.health,
      hunger: this.hunger,
      xp: this.xp,
      selected: this.selected,
      statistics: this.statistics,
      achievements: this.achievements,
      containers: this.containers,
      furnaces: this.furnaces,
      dimensions,
      respawnPoint: this.respawnPoint,
      dragonDefeated: this.dragonDefeated,
      elytraEquipped: this.elytraEquipped,
      ...SV.savePlayer(this),
    };
  }

  save() { if (this.meta.id) this.onSave(this.snapshot()); }

  private frame = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.frame);
    const dt = Math.min(0.04, this.last ? (now - this.last) / 1000 : 0.016);
    this.last = now;
    this.elapsed += dt;
    this.frameCount++;
    if (this.hitFlash > 0) this.hitFlash = Math.max(0, this.hitFlash - dt);

    if (now - this.fpsAt > 1000) {
      this.fps = Math.round((this.frameCount * 1000) / (now - this.fpsAt));
      this.frameCount = 0;
      this.fpsAt = now;
      if (this.active && this.ready && this.settings.adaptiveResolution && this.queue.length === 0 && this.pending.size === 0 && now - this.lastScaleCheck > 4000) {
        this.lastScaleCheck = now;
        const next = this.fps < 43 ? Math.max(0.68, this.renderScale - 0.12) : this.fps > 57 ? Math.min(1, this.renderScale + 0.05) : this.renderScale;
        if (Math.abs(next - this.renderScale) > 0.01) {
          this.renderScale = next;
          this.renderer.setPixelRatio(this.basePixelRatio * this.renderScale);
          this.resize();
        }
      }
    }

    if (this.elapsed - this.streamAt > 0.65) {
      this.streamAt = this.elapsed;
      this.stream();
    }
    this.dispatch();

    // Amortized chunk geometry upload (max 2 chunks/frame during active gameplay so FPS stays locked!)
    let uploaded = 0;
    while (this.uploadQueue.length > 0 && uploaded < 2) {
      const item = this.uploadQueue.shift()!;
      this.mountChunk(item.m);
      uploaded++;
    }

    if (!this.ready) {
      const usePosition = this.pendingPlay || this.active;
      const cx = Math.floor((usePosition ? this.position.x : 0) / 16);
      const cz = Math.floor((usePosition ? this.position.z : 0) / 16);
      let near = 0;
      for (let z = -1; z <= 1; z++) for (let x = -1; x <= 1; x++) if (this.chunks.has((cx + x) + ',' + (cz + z))) near++;
      if (near === 9) {
        this.ready = true;
        if (this.pendingPlay) {
          this.pendingPlay = false;
          this.activate();
        } else if (!this.active && !this.input.active) {
          this.camera.position.set(32, 87, 48);
          this.camera.lookAt(-8, 66, -24);
        }
      }
    }

    if (this.active && this.ready) {
      this.input.update(dt);
      if (this.sleeping) {
        this.sleepTimer -= dt;
        if (this.sleepTimer <= 0) {
          this.sleeping = false;
          this.time = 0.08;
          this.weather = 'clear';
          this.weatherTimer = 90;
          this.health = Math.min(20, this.health + 4);
          this.onToast('朝になりました', 'Good morning!');
        }
      }
      this.time = (this.time + dt / 1200) % 1;
      this.meta.playTime += dt;

      this.weatherTimer -= dt;
      if (this.weatherTimer <= 0 && this.dimension === 'overworld') {
        this.weatherTimer = 45 + Math.random() * 80;
        this.weather = this.weather === 'clear' ? (Math.random() < 0.2 ? 'storm' : 'rain') : 'clear';
        if (this.weather === 'clear') this.onToast('雨が上がりました', 'The rain has stopped');
        else this.onToast(this.weather === 'storm' ? '雷雨が近づいています' : '雨が降り始めました', this.weather === 'storm' ? 'A thunderstorm is rolling in' : 'It has started raining');
      }
      if (this.weather === 'storm' && this.dimension === 'overworld') {
        this.lightningTimer -= dt;
        if (this.lightningTimer <= 0) {
          this.lightningTimer = 7 + Math.random() * 14;
          this.environment.triggerLightning();
          this.audio?.play('thunder');
        }
      }

      this.physics(dt);
      this.camera.rotation.order = 'YXZ';
      this.camera.rotation.set(this.input.pitch, this.input.yaw, 0);
      this.mining(dt);
      this.updateHand(dt);
      this.simulation.update(dt, (x, y, z) => new THREE.Vector3(x, y, z));
      this.updateButtons();
      this.updateStations(dt);
      SV.tick(this, dt);
      this.mobs.update(dt, this.environment.daylight, this.meta.difficulty === 'peaceful');

      if (this.meta.mode === 'survival' || this.meta.mode === 'adventure') {
        this.survivalTick += dt;
        if (this.survivalTick > 4) {
          this.survivalTick = 0;
          this.hunger = Math.max(0, this.hunger - (this.input.run ? 0.14 : 0.04));
          if (this.hunger > 17 && this.health < 20) this.health = Math.min(20, this.health + 1);
          if (this.hunger <= 0) this.damage(1, 'starve');
        }
        const under = this.getBlock(this.camera.position.x, this.camera.position.y, this.camera.position.z) === ID.water;
        this.oxygen = under ? Math.max(0, this.oxygen - dt * SV.oxygenRate(this)) : Math.min(20, this.oxygen + dt * 3);
        if (this.oxygen <= 0 && under) SV.drown(this, dt);
      }

      let burstCount = 0;
      while (this.explosionQueue.length && burstCount++ < 10) {
        const [x, y, z] = this.explosionQueue.shift()!, id = this.getBlock(x, y, z);
        if (id > 0 && id !== ID.bedrock) this.setBlock(x, y, z, 0);
      }
      if (this.elapsed - this.autoSaveAt > 30) {
        this.autoSaveAt = this.elapsed;
        this.save();
      }
    } else if (!this.input.active && !this.active && this.meta.id === 'greenwood' && !this.dead) {
      const a = 0.56 + Math.sin(this.elapsed * 0.017) * 0.13;
      this.camera.position.set(Math.sin(a) * 72 - 7, 87, Math.cos(a) * 72 - 18);
      this.camera.lookAt(-8, 66, -24);
    }

    if (!this.active && this.stationsInMenu) this.updateStations(dt);

    const biomeKey = `${this.meta.seed},${this.dimension},${Math.floor(this.position.x / 4)},${Math.floor(this.position.z / 4)},${Math.floor(this.position.y / 8)}`;
    if (biomeKey !== this.biomeKey) {
      this.biomeKey = biomeKey;
      this.currentBiome = this.terrain.caveBiome(this.position.x, this.position.y, this.position.z) ?? this.terrain.biome(this.position.x, this.position.z);
    }

    this.particles.update(
      dt,
      (x, y, z) => this.getBlock(x, y, z),
      (n, c, p) => {
        if (this.position.distanceTo(p) < 2.2 && SV.pickup(this, n, c)) {
          this.audio?.play('xp');
          return true;
        }
        return false;
      },
      this.position,
    );
    if (!this.active && this.ready && this.meta.id === 'greenwood') this.mobs.update(dt, 0.8, true);

    const heldName = this.hotbar[this.selected]?.name ?? '';
    const heldLight = this.active && (HELD_LIGHT_ITEMS.has(heldName) || HELD_LIGHT_ITEMS.has(this.offhand?.name ?? '')) ? (heldName === 'lava_bucket' ? 0.95 : 0.85) : this.active && SV.has(this, 'night_vision') ? 1.25 : 0;
    const underwater = this.getBlock(this.camera.position.x, this.camera.position.y, this.camera.position.z) === ID.water;
    const moonPhase = Math.floor((this.meta.playTime / 240) % 8);
    if (this.active && this.redstone.active.size) {
      this.redstoneTimer += dt;
      if (this.redstoneTimer >= 0.05) { this.redstoneTimer = 0; this.redstone.tick(); }
    }
    this.environment.update(this.elapsed, this.time, this.camera, this.dimension, this.settings, this.weather, this.currentBiome, moonPhase, heldLight, underwater);

    if (this.environment.failed) {
      for (const c of this.chunks.values()) c.solid.material = this.environment.fallback;
      if (!this.fallbackNotified) {
        this.fallbackNotified = true;
        this.onToast('セーフ描画モードに切り替えました', 'Safe rendering mode enabled');
      }
    }

    if (this.elapsed - this.lastShadow > 3.5 || this.position.distanceTo(this.lastShadowPos) > 4) {
      this.lastShadow = this.elapsed;
      this.lastShadowPos.copy(this.position);
      this.environment.markShadow();
    }

    this.cullChunks();
    this.renderer.render(this.scene, this.camera);
    this.audio?.listener(this.camera.position.x, this.camera.position.y, this.camera.position.z, this.input.yaw);

    if (now - this.snapshotAt > 110) {
      this.snapshotAt = now;
      this.onSnapshot({
        ...EMPTY_SNAPSHOT,
        ready: this.ready,
        progress: Math.min(1, this.chunks.size / ((this.settings.distance * 2 + 1) ** 2 * 0.78)),
        x: this.position.x, y: this.position.y, z: this.position.z,
        yaw: this.input.yaw, pitch: this.input.pitch,
        fps: this.fps, chunks: this.chunks.size,
        biome: this.currentBiome, dimension: this.dimension,
        health: this.health, hunger: this.hunger, oxygen: this.oxygen,
        xp: this.xp, level: Math.floor(Math.sqrt(this.xp)),
        armor: this.computeArmor(),
        time: this.time, selected: this.selected,
        hotbar: this.hotbar.map(s => (s ? { ...s } : null)),
        inventory: this.inventory.map(s => (s ? { ...s } : null)),
        target: this.target ? BLOCKS[this.target.id].name : '',
        breaking: this.breaking, mode: this.meta.mode, flying: this.flying,
        gliding: this.gliding, elytraEquipped: this.elytraEquipped,
        sleeping: this.sleeping, portalCharge: this.portalCharge,
        underwater,
        raining: this.weather !== 'clear', thundering: this.weather === 'storm',
        moonPhase, weather: this.weather, debug: this.debug,
        statistics: { ...this.statistics }, achievements: [...this.achievements],
        dead: this.dead, containers: this.containers,
        boss: this.mobs.getBossInfo(),
        bossName: this.mobs.bossInfo()?.name ?? '',
        bossHp: this.mobs.bossInfo()?.hp ?? 0,
        bossMaxHp: this.mobs.bossInfo()?.maxHp ?? 200,
        crystals: this.mobs.bossInfo()?.crystals ?? 0,
        dragonDefeated: this.dragonDefeated,
        hitFlash: this.hitFlash,
        ...SV.hud(this),
      });
    }
  };

  private getCanvasTex(key: string, canvasEl?: HTMLCanvasElement | OffscreenCanvas) {
    let tex = this.handTextures.get(key);
    if (!tex && canvasEl) {
      tex = new THREE.CanvasTexture(canvasEl as HTMLCanvasElement);
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter;
      tex.colorSpace = THREE.SRGBColorSpace;
      this.handTextures.set(key, tex);
    }
    return tex ?? null;
  }

  updateHand(dt = 0.016) {
    const held = this.hotbar[this.selected], name = held?.name ?? 'hand';
    if (name !== this.lastHand) {
      this.lastHand = name;
      if (held) {
        const faces = blockFaceCanvases(name);
        const isBlock = !!faces && BLOCKS[ID[name]]?.shape !== 'cross' && BLOCKS[ID[name]]?.shape !== 'torch' && BLOCKS[ID[name]]?.shape !== 'door';
        if (isBlock && faces) {
          for (let i = 0; i < 6; i++) {
            const mat = this.handFaceMaterials[i];
            mat.map = this.getCanvasTex(`${name}:f${i}`, faces[i]);
            mat.color.set('#ffffff');
            mat.transparent = false;
            mat.alphaTest = 0;
            mat.needsUpdate = true;
          }
          const isSlab = BLOCKS[ID[name]]?.shape === 'slab' || BLOCKS[ID[name]]?.shape === 'bed';
          this.hand.scale.set(1, isSlab ? 0.55 : 1, 1);
        } else {
          const tex = this.getCanvasTex(`${name}:item`, handTileCanvas(name));
          for (const mat of this.handFaceMaterials) {
            mat.map = tex;
            mat.color.set('#ffffff');
            mat.transparent = true;
            mat.alphaTest = 0.3;
            mat.needsUpdate = true;
          }
          this.hand.scale.set(0.95, 0.95, 0.14);
        }
      } else {
        for (const mat of this.handFaceMaterials) {
          mat.map = null;
          mat.color.set('#c99c7b');
          mat.transparent = false;
          mat.alphaTest = 0;
          mat.needsUpdate = true;
        }
        this.hand.scale.set(0.5, 0.5, 1.3);
      }
    }

    this.handDip = Math.max(0, this.handDip - dt * 1.4);
    const walkBob = this.grounded ? Math.sin(this.elapsed * 10) * Math.min(0.025, Math.hypot(this.input.move.x, this.input.move.z) * 0.025) : 0;
    const swing = this.input.mining ? Math.sin(this.elapsed * 16) * 0.18 : 0;
    this.hand.position.y = -0.34 + swing + walkBob - this.handDip * 0.5;
    this.hand.rotation.x = 0.2 + swing * 1.5 - this.handDip * 1.1;
    this.hand.rotation.z = -swing * 0.65;
    this.hand.visible = !this.thirdPerson;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.resizeObserver.disconnect();
    this.listeners.forEach(f => f());
    this.input.dispose();
    this.workers.forEach(s => s.worker.terminate());
    this.clearChunks();
    this.environment.dispose();
    this.outline.geometry.dispose();
    (this.outline.material as THREE.Material).dispose();
    this.crack.geometry.dispose();
    this.crackMaterials.forEach(m => { m.map?.dispose(); m.dispose(); });
    this.hand.geometry.dispose();
    this.handMaterial.dispose();
    this.handTextures.forEach(t => t.dispose());
    this.handFaceMaterials.forEach(m => m.dispose());
    this.particles.dispose();
    this.mobs.dispose();
    this.renderer.dispose();
  }
}
