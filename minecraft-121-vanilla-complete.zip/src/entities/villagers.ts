import { BLOCKS, resolve } from '../game/data';
import { JOB_SITES as MOB_JOB_SITES, PROFESSION_JA, TRADES, type Profession, type Offer as MobOffer } from './mobdata';

/*
 * Unified Villager Professions, Job Sites, Trade Levels, Stock & Restocking, Demand Pricing, and Hero Discounts.
 * Supports both:
 *  - Seed-based VillagerData (PROFESSIONS, offersForLevel, employ, unemploy, findJobSite, useOffer, tickVillager, price, levelFor)
 *  - Progress-based VillagerProgress (newVillager, getTradeOffers, addTradeXp, updateJob, restockVillager)
 */

export type VillagerProfession = Profession;

export interface Offer {
  id: string;
  give: string;
  n: number;
  cost: number;
  give2?: string;
  n2?: number;
  get: string;
  result: string;
  count: number;
  uses: number;
  max: number;
  maxUses: number;
  xp: number;
  level: number;
  demand: number;
  ench?: Record<string, number>;
}

export type TradeOffer = Offer;

export interface VillagerData {
  profession: VillagerProfession;
  level: number;
  xp: number;
  offers: Offer[];
  uses: Record<string, number>;
  demand?: Record<string, number>;
  job?: { x: number; y: number; z: number } | [number, number, number] | null;
  seed: number;
  restock: number;
  lastRestockDay: number;
}

export type VillagerProgress = VillagerData;

/** [give, n, get, count, maxUses, xp, (second input, n2), (enchantments)] */
type T = [string, number, string, number, number, number, string?, number?, Record<string, number>?];
const E = 'emerald';
interface ProfessionDef { ja: string; en: string; site: string; levels: T[][]; }

export const PROFESSIONS: Record<string, ProfessionDef> = {
  farmer: { ja: '農民', en: 'Farmer', site: 'composter', levels: [
    [['wheat', 20, E, 1, 16, 2], ['potato', 26, E, 1, 16, 2], ['carrot', 22, E, 1, 16, 2], ['beetroot', 15, E, 1, 16, 2], [E, 1, 'bread', 6, 16, 1]],
    [['pumpkin', 6, E, 1, 12, 10], [E, 1, 'pumpkin_pie', 4, 12, 5], [E, 1, 'apple', 4, 16, 5]],
    [[E, 3, 'cookie', 18, 12, 10], ['melon', 4, E, 1, 12, 20]],
    [[E, 1, 'cake', 1, 12, 15], [E, 2, 'hay_block', 2, 12, 15]],
    [[E, 3, 'golden_carrot', 3, 12, 30], [E, 4, 'glistering_melon_slice', 3, 12, 30]],
  ] },
  fisherman: { ja: '釣り人', en: 'Fisherman', site: 'barrel', levels: [
    [['string', 20, E, 1, 16, 2], ['coal', 10, E, 1, 16, 2], [E, 1, 'cooked_cod', 6, 16, 1, 'cod', 6]],
    [['cod', 15, E, 1, 16, 10], [E, 2, 'campfire', 1, 12, 5]],
    [['salmon', 13, E, 1, 16, 20], [E, 7, 'fishing_rod', 1, 3, 10, undefined, undefined, { lure: 2, unbreaking: 2 }]],
    [['tropical_fish', 6, E, 1, 12, 30]],
    [['pufferfish', 4, E, 1, 12, 30], ['boat', 1, E, 1, 12, 30]],
  ] },
  shepherd: { ja: '羊飼い', en: 'Shepherd', site: 'loom', levels: [
    [['white_wool', 18, E, 1, 16, 2], [E, 2, 'shears', 1, 12, 1]],
    [['white_dye', 12, E, 1, 16, 10], [E, 1, 'white_wool', 1, 16, 5], [E, 1, 'white_carpet', 4, 16, 5]],
    [['yellow_dye', 12, E, 1, 16, 20], [E, 3, 'bed', 1, 12, 10]],
    [['red_dye', 12, E, 1, 16, 30], [E, 3, 'white_banner', 1, 12, 15]],
    [[E, 2, 'painting', 3, 12, 30], [E, 2, 'item_frame', 1, 12, 30]],
  ] },
  fletcher: { ja: '矢師', en: 'Fletcher', site: 'fletching_table', levels: [
    [['stick', 32, E, 1, 16, 2], [E, 1, 'arrow', 16, 12, 1], [E, 1, 'flint', 10, 12, 1, 'gravel', 10]],
    [['flint', 26, E, 1, 12, 10], [E, 2, 'bow', 1, 12, 5]],
    [['string', 14, E, 1, 16, 20], [E, 3, 'crossbow', 1, 12, 10]],
    [['feather', 24, E, 1, 16, 30], [E, 12, 'bow', 1, 3, 15, undefined, undefined, { power: 3, unbreaking: 2 }]],
    [[E, 14, 'crossbow', 1, 3, 30, undefined, undefined, { quick_charge: 2, multishot: 1 }], [E, 2, 'spectral_arrow', 5, 12, 30]],
  ] },
  librarian: { ja: '司書', en: 'Librarian', site: 'lectern', levels: [
    [['paper', 24, E, 1, 16, 2], [E, 9, 'bookshelf', 1, 12, 1], [E, 18, 'enchanted_book', 1, 12, 1, 'book', 1, { mending: 1 }]],
    [['book', 4, E, 1, 12, 10], [E, 1, 'lantern', 1, 12, 5], [E, 22, 'enchanted_book', 1, 12, 5, 'book', 1, { efficiency: 4 }]],
    [['ink_sac', 5, E, 1, 12, 20], [E, 1, 'glass', 4, 12, 10], [E, 28, 'enchanted_book', 1, 12, 10, 'book', 1, { unbreaking: 3 }]],
    [['writable_book', 2, E, 1, 12, 30], [E, 5, 'clock', 1, 12, 15], [E, 4, 'compass', 1, 12, 15]],
    [[E, 20, 'name_tag', 1, 12, 30]],
  ] },
  cartographer: { ja: '製図家', en: 'Cartographer', site: 'cartography_table', levels: [
    [['paper', 24, E, 1, 16, 2], [E, 7, 'map', 1, 12, 1]],
    [['glass_pane', 11, E, 1, 16, 10]],
    [['compass', 1, E, 1, 12, 20], [E, 13, 'filled_map', 1, 12, 10, 'compass', 1]],
    [[E, 7, 'item_frame', 1, 12, 15], [E, 3, 'white_banner', 1, 12, 15]],
    [[E, 8, 'globe_banner_pattern', 1, 12, 30], [E, 6, 'map', 2, 12, 30]],
  ] },
  cleric: { ja: '聖職者', en: 'Cleric', site: 'brewing_stand', levels: [
    [['rotten_flesh', 32, E, 1, 16, 2], [E, 1, 'redstone', 2, 12, 1]],
    [['gold_ingot', 3, E, 1, 12, 10], [E, 1, 'lapis_lazuli', 1, 12, 5]],
    [['rabbit_foot', 2, E, 1, 12, 20], [E, 4, 'glowstone', 1, 12, 10]],
    [['scute', 4, E, 1, 12, 30], ['glass_bottle', 9, E, 1, 12, 30], [E, 5, 'ender_pearl', 1, 12, 15]],
    [['nether_wart', 22, E, 1, 12, 30], [E, 3, 'experience_bottle', 1, 12, 30]],
  ] },
  armorer: { ja: '防具鍛冶', en: 'Armorer', site: 'blast_furnace', levels: [
    [['coal', 15, E, 1, 16, 2], [E, 5, 'iron_helmet', 1, 12, 1], [E, 9, 'iron_chestplate', 1, 12, 1], [E, 7, 'iron_leggings', 1, 12, 1], [E, 4, 'iron_boots', 1, 12, 1]],
    [['iron_ingot', 4, E, 1, 12, 10], [E, 1, 'chainmail_boots', 1, 12, 5], [E, 3, 'chainmail_leggings', 1, 12, 5]],
    [['lava_bucket', 1, E, 1, 12, 20], ['diamond', 1, E, 1, 12, 20], [E, 5, 'shield', 1, 12, 10], [E, 4, 'chainmail_chestplate', 1, 12, 10]],
    [[E, 19, 'diamond_leggings', 1, 3, 15, undefined, undefined, { protection: 2 }], [E, 13, 'diamond_boots', 1, 3, 15, undefined, undefined, { protection: 2 }]],
    [[E, 13, 'diamond_helmet', 1, 3, 30, undefined, undefined, { protection: 3 }], [E, 21, 'diamond_chestplate', 1, 3, 30, undefined, undefined, { protection: 3 }]],
  ] },
  weaponsmith: { ja: '武器鍛冶', en: 'Weaponsmith', site: 'grindstone', levels: [
    [['coal', 15, E, 1, 16, 2], [E, 3, 'iron_axe', 1, 12, 1], [E, 7, 'iron_sword', 1, 3, 1, undefined, undefined, { sharpness: 1 }]],
    [['iron_ingot', 4, E, 1, 12, 10], [E, 36, 'bell', 1, 12, 5]],
    [['flint', 24, E, 1, 12, 20]],
    [['diamond', 1, E, 1, 12, 30], [E, 17, 'diamond_axe', 1, 3, 15, undefined, undefined, { efficiency: 2 }]],
    [[E, 13, 'diamond_sword', 1, 3, 30, undefined, undefined, { sharpness: 3 }]],
  ] },
  toolsmith: { ja: '道具鍛冶', en: 'Toolsmith', site: 'smithing_table', levels: [
    [['coal', 15, E, 1, 16, 2], [E, 1, 'stone_axe', 1, 12, 1], [E, 1, 'stone_shovel', 1, 12, 1], [E, 1, 'stone_pickaxe', 1, 12, 1], [E, 1, 'stone_hoe', 1, 12, 1]],
    [['iron_ingot', 4, E, 1, 12, 10], [E, 36, 'bell', 1, 12, 5]],
    [['flint', 30, E, 1, 12, 20], [E, 6, 'iron_pickaxe', 1, 3, 10, undefined, undefined, { efficiency: 1 }], [E, 4, 'diamond_hoe', 1, 3, 10]],
    [['diamond', 1, E, 1, 12, 30], [E, 12, 'diamond_axe', 1, 3, 15, undefined, undefined, { efficiency: 2 }], [E, 10, 'diamond_shovel', 1, 3, 15, undefined, undefined, { efficiency: 2 }]],
    [[E, 18, 'diamond_pickaxe', 1, 3, 30, undefined, undefined, { efficiency: 3, unbreaking: 2 }]],
  ] },
  butcher: { ja: '肉屋', en: 'Butcher', site: 'smoker', levels: [
    [['chicken', 14, E, 1, 16, 2], ['porkchop', 7, E, 1, 16, 2], ['rabbit', 4, E, 1, 16, 2], [E, 1, 'rabbit_stew', 1, 12, 1]],
    [['coal', 15, E, 1, 16, 2], [E, 1, 'cooked_porkchop', 5, 16, 5], [E, 1, 'cooked_chicken', 8, 16, 5]],
    [['mutton', 7, E, 1, 16, 20], ['raw_beef', 10, E, 1, 16, 20]],
    [['dried_kelp_block', 10, E, 1, 12, 30], ['kelp', 20, E, 1, 12, 30]],
    [['sweet_berries', 10, E, 1, 12, 30]],
  ] },
  leatherworker: { ja: '革細工師', en: 'Leatherworker', site: 'cauldron', levels: [
    [['leather', 6, E, 1, 16, 2], [E, 3, 'leather_leggings', 1, 12, 1], [E, 7, 'leather_chestplate', 1, 12, 1]],
    [['flint', 26, E, 1, 12, 10], [E, 5, 'leather_helmet', 1, 12, 5], [E, 4, 'leather_boots', 1, 12, 5]],
    [['rabbit_hide', 9, E, 1, 12, 20], [E, 7, 'leather_chestplate', 1, 12, 10, undefined, undefined, { protection: 1 }]],
    [['scute', 4, E, 1, 12, 30]],
    [[E, 6, 'saddle', 1, 12, 30], [E, 5, 'leather_helmet', 1, 12, 30, undefined, undefined, { protection: 2 }]],
  ] },
  mason: { ja: '石工', en: 'Mason', site: 'stonecutter', levels: [
    [['clay_ball', 10, E, 1, 16, 2], [E, 1, 'brick', 10, 16, 1]],
    [['stone', 20, E, 1, 16, 10], [E, 1, 'chiseled_stone_bricks', 4, 16, 5]],
    [['granite', 16, E, 1, 16, 20], ['andesite', 16, E, 1, 16, 20], ['diorite', 16, E, 1, 16, 20], [E, 1, 'polished_andesite', 4, 16, 10]],
    [['quartz', 12, E, 1, 12, 30], [E, 1, 'terracotta', 1, 12, 15]],
    [[E, 1, 'quartz_block', 1, 12, 30], [E, 1, 'quartz_pillar', 1, 12, 30]],
  ] },
};

export const WANDERING: T[] = [
  [E, 5, 'slime_ball', 1, 5, 1], [E, 1, 'oak_sapling', 1, 8, 1], [E, 2, 'cactus', 1, 8, 1], [E, 1, 'sugar_cane', 1, 8, 1], [E, 1, 'pumpkin_seeds', 1, 12, 1],
  [E, 1, 'melon_seeds', 1, 12, 1], [E, 3, 'nautilus_shell', 1, 5, 1], [E, 6, 'name_tag', 1, 3, 1], [E, 6, 'lead', 2, 6, 1], [E, 3, 'packed_ice', 1, 6, 1], [E, 1, 'lily_pad', 2, 5, 1],
];

export const JOB_SITES: Record<string, Profession> = MOB_JOB_SITES;
export const PROFESSION_BLOCKS = JOB_SITES;
export const PROFESSION_NAMES = PROFESSION_JA;
export const LEVEL_NAMES = ['新米', '見習い', '一人前', '熟練', '達人'];
export const LEVEL_XP = [0, 10, 70, 150, 250];

function rng(seed: number) {
  let s = (seed | 0) || 0x9e3779b9;
  return () => { s = (s + 0x6d2b79f5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

const toOffer = (t: T, level: number): Offer => ({
  id: `${t[0]}_${t[1]}_${t[2]}_${level}`,
  give: t[0],
  n: t[1],
  cost: t[1],
  get: t[2],
  result: t[2],
  count: t[3],
  max: t[4],
  maxUses: t[4],
  xp: t[5],
  give2: t[6],
  n2: t[7],
  ench: t[8],
  uses: 0,
  level,
  demand: 0,
});

const known = (t: T) => !!resolve(t[0]) && !!resolve(t[2]) && (!t[6] || !!resolve(t[6]));

export function newVillager(arg: VillagerProfession | number = 'unemployed'): VillagerData {
  if (typeof arg === 'number') {
    return { profession: 'none', level: 1, xp: 0, offers: [], uses: {}, demand: {}, job: null, seed: arg, restock: 0, lastRestockDay: -1 };
  }
  return { profession: arg, level: 1, xp: 0, offers: [], uses: {}, demand: {}, job: undefined, seed: 42, restock: 0, lastRestockDay: -1 };
}

export function offersForLevel(profession: string, level: number, seed: number): Offer[] {
  const pool = (PROFESSIONS[profession]?.levels[level - 1] ?? []).filter(known);
  const r = rng(seed * 31 + level * 977);
  const picked: T[] = [], rest = [...pool];
  while (picked.length < 2 && rest.length) picked.push(rest.splice(Math.floor(r() * rest.length), 1)[0]);
  return picked.map(t => toOffer(t, level));
}

export function employ(v: VillagerData, profession: string, job: [number, number, number] | { x: number; y: number; z: number } | null) {
  if (!PROFESSIONS[profession]) return false;
  v.profession = profession as VillagerProfession;
  v.job = job;
  v.level = 1;
  v.xp = 0;
  v.restock = 60;
  v.offers = offersForLevel(profession, 1, v.seed || 42);
  return true;
}

export function unemploy(v: VillagerData) {
  if (v.xp > 0 || v.level > 1) { v.job = null; return false; }
  v.profession = 'none';
  v.job = null;
  v.offers = [];
  return true;
}

export function wanderingTrader(seed: number): VillagerData {
  const r = rng(seed), pool = WANDERING.filter(known), offers: Offer[] = [];
  while (offers.length < 6 && pool.length) offers.push(toOffer(pool.splice(Math.floor(r() * pool.length), 1)[0], 1));
  return { profession: 'wandering_trader' as VillagerProfession, level: 1, xp: 0, offers, uses: {}, demand: {}, job: null, seed, restock: Infinity, lastRestockDay: -1 };
}

export function findJobSite(
  getBlock: (x: number, y: number, z: number) => number,
  x: number,
  y: number,
  z: number,
  claimed: Set<string>,
  radius = 8,
  vertical = 3,
): { profession: Profession; pos: [number, number, number] } | null {
  const bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z);
  let best: { profession: Profession; pos: [number, number, number] } | null = null, bestD = Infinity;
  for (let dy = -vertical; dy <= vertical; dy++) for (let dx = -radius; dx <= radius; dx++) for (let dz = -radius; dz <= radius; dz++) {
    const d = dx * dx + dy * dy + dz * dz;
    if (d >= bestD) continue;
    const id = getBlock(bx + dx, by + dy, bz + dz);
    if (id <= 0) continue;
    const profession = JOB_SITES[BLOCKS[id]?.name ?? ''];
    if (!profession || claimed.has((bx + dx) + ',' + (by + dy) + ',' + (bz + dz))) continue;
    best = { profession, pos: [bx + dx, by + dy, bz + dz] }; bestD = d;
  }
  return best;
}

export function price(o: Offer, hero = 0): number {
  let p = o.n + Math.floor(o.n * 0.05 * Math.max(0, o.demand ?? 0));
  if (hero > 0) p -= Math.floor(o.n * (0.3 + 0.0625 * (hero - 1)));
  return Math.max(1, Math.min(64, p));
}

export const levelFor = (xp: number) => {
  let l = 1;
  for (let i = 1; i < LEVEL_XP.length; i++) if (xp >= LEVEL_XP[i]) l = i + 1;
  return l;
};

export function useOffer(v: VillagerData, i: number): { leveled: boolean; playerXp: number } | null {
  const o = v.offers[i];
  if (!o || o.uses >= o.max) return null;
  o.uses++;
  v.uses[o.id] = o.uses;
  v.xp += o.xp;
  let leveled = false;
  if (PROFESSIONS[v.profession]) {
    const target = levelFor(v.xp);
    while (v.level < target && v.level < 5) {
      v.level++;
      v.offers.push(...offersForLevel(v.profession, v.level, v.seed || 42));
      leveled = true;
    }
  }
  return { leveled, playerXp: 3 + Math.floor(o.xp / 5) + (leveled ? 5 : 0) };
}

export function restock(v: VillagerData) {
  for (const o of v.offers) {
    o.demand = Math.max(0, o.demand + (o.uses >= o.max ? 2 : o.uses > o.max / 2 ? 1 : -1));
    o.uses = 0;
  }
  v.uses = {};
}

export function tickVillager(v: VillagerData, dt: number, dayLength = 240): boolean {
  if (!PROFESSIONS[v.profession] || !v.job) return false;
  v.restock -= dt;
  if (v.restock > 0) return false;
  v.restock = dayLength / 2;
  if (!v.offers.some(o => o.uses > 0)) return false;
  restock(v);
  return true;
}

export function getTradeOffers(v?: VillagerData, hero = 0): TradeOffer[] {
  if (!v || v.profession === 'unemployed' || v.profession === 'none' || v.profession === 'nitwit') return [];
  if (v.offers && v.offers.length > 0) {
    return v.offers.map(o => {
      const adjCost = price(o, hero);
      return { ...o, cost: adjCost, n: adjCost };
    });
  }
  const all = TRADES[v.profession] ?? [];
  const filtered = all.filter(o => o.level <= v.level);
  const cap = v.level === 1 ? 2 : v.level === 2 ? 3 : filtered.length;
  return filtered.slice(0, cap).map((o: MobOffer) => {
    const d = v.demand?.[o.id] ?? 0;
    const baseOffer: Offer = {
      id: o.id,
      level: o.level,
      give: o.give,
      cost: o.cost,
      n: o.n,
      result: o.result,
      get: o.get,
      count: o.count,
      uses: v.uses?.[o.id] ?? 0,
      max: o.maxUses,
      maxUses: o.maxUses,
      xp: o.xp,
      demand: d,
      ench: o.ench,
    };
    const adjCost = price(baseOffer, hero);
    return { ...baseOffer, cost: adjCost, n: adjCost };
  });
}

export function addTradeXp(v: VillagerData, offer: TradeOffer) {
  v.uses ??= {};
  v.uses[offer.id] = (v.uses[offer.id] ?? 0) + 1;
  const idx = v.offers?.findIndex(o => o.id === offer.id) ?? -1;
  if (idx >= 0 && v.offers[idx]) v.offers[idx].uses = v.uses[offer.id];
  v.xp += Math.max(3, offer.xp);
  while (v.level < 5 && v.xp >= LEVEL_XP[v.level]) {
    v.level++;
    if (v.offers && v.offers.length > 0 && PROFESSIONS[v.profession]) {
      v.offers.push(...offersForLevel(v.profession, v.level, v.seed || 42));
    }
  }
}

export function restockVillager(v: VillagerData, day: number) {
  if (v.job && v.lastRestockDay !== day) {
    v.demand ??= {};
    for (const [id, used] of Object.entries(v.uses ?? {})) {
      if (used >= 12) v.demand[id] = Math.min(8, (v.demand[id] ?? 0) + 2);
      else if (used === 0 && (v.demand[id] ?? 0) > 0) v.demand[id] = Math.max(0, v.demand[id] - 1);
    }
    if (v.offers?.length) restock(v);
    v.uses = {};
    v.lastRestockDay = day;
  }
}

export function updateJob(
  v: VillagerData,
  world: { getBlock(x: number, y: number, z: number): number },
  position: { x: number; y: number; z: number },
  taken: Set<string>,
) {
  const jobCoords = Array.isArray(v.job) ? { x: v.job[0], y: v.job[1], z: v.job[2] } : v.job;
  if (jobCoords) {
    const key = `${jobCoords.x},${jobCoords.y},${jobCoords.z}`;
    const block = BLOCKS[world.getBlock(jobCoords.x, jobCoords.y, jobCoords.z)]?.name;
    if (block && PROFESSION_BLOCKS[block] === v.profession && !taken.has(key)) {
      taken.add(key);
      return;
    }
    v.job = undefined;
    if (v.xp === 0) {
      v.profession = 'unemployed';
      v.level = 1;
      v.uses = {};
      v.offers = [];
    }
  }
  const px = Math.floor(position.x), py = Math.floor(position.y), pz = Math.floor(position.z);
  for (let dx = -8; dx <= 8; dx++) {
    for (let dz = -8; dz <= 8; dz++) {
      for (let dy = -2; dy <= 2; dy++) {
        const x = px + dx, y = py + dy, z = pz + dz, key = `${x},${y},${z}`;
        if (taken.has(key)) continue;
        const job = PROFESSION_BLOCKS[BLOCKS[world.getBlock(x, y, z)]?.name ?? ''];
        if (job && (v.xp === 0 || job === v.profession)) {
          v.profession = job;
          v.job = { x, y, z };
          if (v.xp === 0 && (!v.offers || v.offers.length === 0) && PROFESSIONS[job]) {
            v.offers = offersForLevel(job, 1, v.seed || 42);
          }
          taken.add(key);
          return;
        }
      }
    }
  }
}
