/*
 * Java Edition entity physics, ported tick-for-tick (all velocities here are in blocks / game tick, 20 ticks = 1 s).
 *
 *  - AABB helpers and Entity.push (soft entity-entity separation)
 *  - LivingEntity.travel while fall-flying (elytra): lift from cos²(pitch), dive acceleration, pitch-up speed-for-height trade,
 *    10 % velocity re-alignment per tick, 0.99 / 0.98 drag, "fly into wall" kinetic damage = 10·Δv − 3
 *  - FireworkRocketEntity attached boost: v += look·0.1 + (look·1.5 − v)·0.5, lifetime 10·flight + rand(6) + rand(7) ticks
 *    (terminal speed 1.7 b/t = 34 m/s before drag, the wiki's 33.5 m/s)
 *  - Leads: elastic beyond 6 blocks (v += sign(d)·d²·0.4 on the normalised offset), snap at 12 blocks, 5 block fence roam radius
 *  - Boat: status machine (in water / under water / under flowing water / on land / in air), buoyancy, per-status friction
 *    (0.9 water, block slipperiness on land -> 8 m/s on water, 40 m/s on ice, 72.7 m/s on blue ice), paddle thrust 0.04 / 0.005,
 *    1°/tick² turning, two seats (0.2 / −0.6, animals +0.2) and automatic mob boarding
 *  - AbstractMinecart.push: velocity averaging between carts, furnace carts shoving trains, entity nudges
 *
 * Sources: Minecraft Wiki (Elytra, Firework Rocket, Lead, Boat, Minecart) and the corresponding Java Edition classes.
 */

export interface Vec3 { x: number; y: number; z: number }
export const TICK = 0.05;
export const TPS = 20;

// ------------------------------------------------------------------------------------------------------------------ AABB
export interface AABB { minX: number; minY: number; minZ: number; maxX: number; maxY: number; maxZ: number }

/** Bounding box of an entity standing at (x, y, z) — y is the feet, the box is centred horizontally. */
export function entityBox(x: number, y: number, z: number, width: number, height: number): AABB {
  const r = width / 2;
  return { minX: x - r, minY: y, minZ: z - r, maxX: x + r, maxY: y + height, maxZ: z + r };
}
export function inflate(b: AABB, dx: number, dy: number, dz: number): AABB {
  return { minX: b.minX - dx, minY: b.minY - dy, minZ: b.minZ - dz, maxX: b.maxX + dx, maxY: b.maxY + dy, maxZ: b.maxZ + dz };
}
export function intersects(a: AABB, b: AABB): boolean {
  return a.minX < b.maxX && a.maxX > b.minX && a.minY < b.maxY && a.maxY > b.minY && a.minZ < b.maxZ && a.maxZ > b.minZ;
}
/** True when any block cell overlapped by the box is solid (the callback gets integer block coordinates). */
export function boxCollides(b: AABB, solid: (x: number, y: number, z: number) => boolean): boolean {
  const e = 1e-7;
  for (let y = Math.floor(b.minY + e); y <= Math.floor(b.maxY - e); y++)
    for (let z = Math.floor(b.minZ + e); z <= Math.floor(b.maxZ - e); z++)
      for (let x = Math.floor(b.minX + e); x <= Math.floor(b.maxX - e); x++)
        if (solid(x, y, z)) return true;
  return false;
}

/**
 * Entity.push: the horizontal impulse two overlapping entities give each other. Returns the impulse for B (A gets the negative),
 * or null when they are closer than 0.01 blocks on both axes.
 */
export function pushApart(ax: number, az: number, bx: number, bz: number): { x: number; z: number } | null {
  let d = bx - ax, e = bz - az, f = Math.max(Math.abs(d), Math.abs(e));
  if (f < 0.01) return null;
  f = Math.sqrt(f);
  d /= f; e /= f;
  const g = Math.min(1, 1 / f);
  return { x: d * g * 0.05, z: e * g * 0.05 };
}

// ---------------------------------------------------------------------------------------------------------------- Elytra
export const ELYTRA_GRAVITY = 0.08, SLOW_FALLING_GRAVITY = 0.01;

/**
 * One tick of fall-flying. `look` is the unit view vector and `pitch` the vanilla xRot in radians (positive = looking DOWN).
 */
export function elytraTick(v: Vec3, look: Vec3, pitch: number, gravity = ELYTRA_GRAVITY): Vec3 {
  const lookH = Math.hypot(look.x, look.z), speedH = Math.hypot(v.x, v.z);
  const lookLen = Math.hypot(look.x, look.y, look.z);
  let lift = Math.cos(pitch);
  lift = lift * lift * Math.min(1, lookLen / 0.4);
  let x = v.x, y = v.y + gravity * (-1 + lift * 0.75), z = v.z;
  if (y < 0 && lookH > 0) {                               // falling: convert sink into forward speed
    const d = y * -0.1 * lift;
    x += (look.x * d) / lookH; y += d; z += (look.z * d) / lookH;
  }
  if (pitch < 0 && lookH > 0) {                           // looking up: trade horizontal speed for height
    const d = speedH * -Math.sin(pitch) * 0.04;
    x += (-look.x * d) / lookH; y += d * 3.2; z += (-look.z * d) / lookH;
  }
  if (lookH > 0) {                                        // steer: 10 % of the velocity turns towards the view direction
    x += ((look.x / lookH) * speedH - x) * 0.1;
    z += ((look.z / lookH) * speedH - z) * 0.1;
  }
  return { x: x * 0.99, y: y * 0.98, z: z * 0.99 };
}

/** One tick of an attached firework rocket. */
export function rocketBoostTick(v: Vec3, look: Vec3): Vec3 {
  return {
    x: v.x + look.x * 0.1 + (look.x * 1.5 - v.x) * 0.5,
    y: v.y + look.y * 0.1 + (look.y * 1.5 - v.y) * 0.5,
    z: v.z + look.z * 0.1 + (look.z * 1.5 - v.z) * 0.5,
  };
}
/** Lifetime in ticks of a rocket with the given flight duration (1-3). */
export function rocketLifetime(flight: number, rnd: () => number = Math.random): number {
  return 10 * Math.max(1, flight) + Math.floor(rnd() * 6) + Math.floor(rnd() * 7);
}
/** Kinetic ("experienced kinetic energy") damage for losing `deltaH` blocks/tick of horizontal speed against a wall. */
export function flyIntoWallDamage(deltaH: number): number { return Math.max(0, deltaH * 10 - 3); }

/** Frame-rate independent driver around elytraTick: feeds on real seconds, runs whole 20 Hz ticks. */
export class ElytraFlight {
  private acc = 0;
  private wearTicks = 0;
  private pendingWear = 0;
  /** Remaining boost ticks of every attached rocket. */
  rockets: number[] = [];
  /** Ticks spent gliding since take-off. */
  ticks = 0;

  reset() { this.acc = 0; this.rockets.length = 0; this.ticks = 0; this.wearTicks = 0; this.pendingWear = 0; }
  get boosting() { return this.rockets.length > 0; }
  boost(flight = 1, rnd: () => number = Math.random) { this.rockets.push(rocketLifetime(flight, rnd)); }
  /** Durability points to take from the elytra since the last call (1 per 20 ticks of gliding). */
  takeWear() { const w = this.pendingWear; this.pendingWear = 0; return w; }

  /** `vel` in blocks / second (mutated and returned). */
  step(dt: number, vel: Vec3, look: Vec3, pitch: number, gravity = ELYTRA_GRAVITY): Vec3 {
    this.acc = Math.min(this.acc + dt, 0.25);
    let v: Vec3 = { x: vel.x / TPS, y: vel.y / TPS, z: vel.z / TPS };
    while (this.acc >= TICK) {
      this.acc -= TICK;
      this.ticks++;
      v = elytraTick(v, look, pitch, gravity);
      for (let i = this.rockets.length - 1; i >= 0; i--) {
        v = rocketBoostTick(v, look);
        if (--this.rockets[i] <= 0) this.rockets.splice(i, 1);
      }
      if (++this.wearTicks >= 20) { this.wearTicks = 0; this.pendingWear++; }
    }
    vel.x = v.x * TPS; vel.y = v.y * TPS; vel.z = v.z * TPS;
    return vel;
  }
}

// ----------------------------------------------------------------------------------------------------------------- Leads
export const LEASH_ELASTIC = 6, LEASH_SNAP = 12, LEASH_FENCE_ROAM = 5;
const sq = (d: number) => Math.sign(d) * d * d * 0.4;

/** One tick of a leashed mob: `snap` when stretched past 12 blocks, otherwise the velocity impulse pulling it to the holder. */
export function leashTick(mob: Vec3, holder: Vec3): { dist: number; snap: boolean; pull: Vec3 | null } {
  const dx = holder.x - mob.x, dy = holder.y - mob.y, dz = holder.z - mob.z;
  const dist = Math.hypot(dx, dy, dz);
  if (dist > LEASH_SNAP) return { dist, snap: true, pull: null };
  if (dist <= LEASH_ELASTIC) return { dist, snap: false, pull: null };
  return { dist, snap: false, pull: { x: sq(dx / dist), y: sq(dy / dist), z: sq(dz / dist) } };
}

// ----------------------------------------------------------------------------------------------------------------- Boats
export type BoatStatus = 'in_water' | 'under_water' | 'under_flowing_water' | 'on_land' | 'in_air';
export const BOAT = { width: 1.375, height: 0.5625, gravity: 0.04, maxPassengers: 2, defaultFriction: 0.6 } as const;
export interface BoatState {
  /** Velocity in blocks / tick. */
  vx: number; vy: number; vz: number;
  /** Turning speed in degrees / tick. */
  deltaRotation: number;
  status: BoatStatus;
}
export interface BoatInput { left: boolean; right: boolean; up: boolean; down: boolean }
export const newBoatState = (): BoatState => ({ vx: 0, vy: 0, vz: 0, deltaRotation: 0, status: 'in_air' });

/** Boat.floatBoat: gravity, buoyancy and friction for the current status. `y` is the boat's bottom, `waterLevel` the surface. */
export function boatFloat(s: BoatState, status: BoatStatus, y: number, waterLevel: number, landFriction: number): void {
  let g = -BOAT.gravity, buoyancy = 0, friction = 0.05;
  if (s.status === 'in_air' && status !== 'in_air' && status !== 'on_land') {
    // Splash-down: the hull is snapped onto the surface by the caller (see boatSplashY) and the fall stops dead.
    s.vy = 0;
    s.status = 'in_water';
    return;
  }
  if (status === 'in_water') { buoyancy = (waterLevel - y) / BOAT.height; friction = 0.9; }
  else if (status === 'under_flowing_water') { g = -7e-4; friction = 0.9; }
  else if (status === 'under_water') { buoyancy = 0.01; friction = 0.45; }
  else if (status === 'in_air') friction = 0.9;
  else friction = landFriction;
  s.vx *= friction; s.vz *= friction; s.vy += g;
  s.deltaRotation *= friction;
  if (buoyancy > 0) s.vy = (s.vy + buoyancy * (BOAT.gravity / 0.65)) * 0.75;
  s.status = status;
}
/** Where the hull bottom sits right after splash-down. */
export const boatSplashY = (waterSurface: number) => waterSurface - BOAT.height + 0.101;

/**
 * Boat.controlBoat. `fx`/`fz` is the unit forward vector of the hull. Returns the thrust applied this tick (blocks/tick²);
 * the caller adds `s.deltaRotation` degrees (clockwise) to the yaw.
 */
export function boatControl(s: BoatState, input: BoatInput, fx: number, fz: number): number {
  let f = 0;
  if (input.left) s.deltaRotation--;
  if (input.right) s.deltaRotation++;
  if (input.right !== input.left && !input.up && !input.down) f += 0.005;
  if (input.up) f += 0.04;
  if (input.down) f -= 0.005;
  s.vx += fx * f; s.vz += fz * f;
  return f;
}
/** Boat.positionRider: forward offset of seat `index` (0 = front) when `count` passengers ride. */
export function boatSeatOffset(index: number, count: number, animal = false): number {
  if (count <= 1) return 0;
  return (index === 0 ? 0.2 : -0.6) + (animal ? 0.2 : 0);
}
/** Boat.tick boarding rule: only living, non-aquatic, non-player entities narrower than the hull, and only while no player steers. */
export function canBoardBoat(o: { passengers: number; playerControlled: boolean; width: number; aquatic: boolean; alreadyRiding: boolean }): boolean {
  return !o.playerControlled && o.passengers < BOAT.maxPassengers && !o.alreadyRiding && o.width < BOAT.width && !o.aquatic;
}

// -------------------------------------------------------------------------------------------------------------- Minecarts
export interface CartBody { x: number; z: number; vx: number; vz: number; furnace?: boolean }

/** AbstractMinecart.push(minecart): both carts end up near their average velocity, pushed apart; furnace carts shove the other. */
export function minecartCollide(a: CartBody, b: CartBody): boolean {
  let dx = b.x - a.x, dz = b.z - a.z;
  const d2 = dx * dx + dz * dz;
  if (d2 < 1e-4) return false;
  const d = Math.sqrt(d2), inv = Math.min(1, 1 / d);
  dx = (dx / d) * inv * 0.1 * 0.5; dz = (dz / d) * inv * 0.1 * 0.5;
  const ax = (a.vx + b.vx) / 2, az = (a.vz + b.vz) / 2;
  if (b.furnace && !a.furnace) {
    // The plain cart takes over the furnace cart's velocity (keeping 20 % of its own); the furnace cart keeps 95 %.
    const bvx = b.vx, bvz = b.vz;
    a.vx = a.vx * 0.2 + bvx - dx; a.vz = a.vz * 0.2 + bvz - dz;
    b.vx *= 0.95; b.vz *= 0.95;
  } else if (a.furnace && !b.furnace) {
    const avx = a.vx, avz = a.vz;
    b.vx = b.vx * 0.2 + avx + dx; b.vz = b.vz * 0.2 + avz + dz;
    a.vx *= 0.95; a.vz *= 0.95;
  } else {
    a.vx = ax * 0.2 + ax - dx; a.vz = az * 0.2 + az - dz;
    b.vx = ax * 0.2 + ax + dx; b.vz = az * 0.2 + az + dz;
  }
  return true;
}
/** AbstractMinecart.push(entity): the cart is nudged away from the entity (which receives a quarter of the impulse back). */
export function minecartEntityPush(cart: CartBody, ex: number, ez: number): { x: number; z: number } | null {
  let dx = ex - cart.x, dz = ez - cart.z;
  const d2 = dx * dx + dz * dz;
  if (d2 < 1e-4) return null;
  const d = Math.sqrt(d2), inv = Math.min(1, 1 / d);
  dx = (dx / d) * inv * 0.1 * 0.5; dz = (dz / d) * inv * 0.1 * 0.5;
  cart.vx -= dx; cart.vz -= dz;
  return { x: dx / 4, z: dz / 4 };
}
