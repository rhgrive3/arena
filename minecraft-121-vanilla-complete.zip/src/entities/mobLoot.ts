// Mob loot tables — Java Edition 1.21 (data/minecraft/loot_table/entities/*.json, summarised on minecraft.wiki "Drops").
// Pure function, no three.js: the mob manager hands in the dying mob's state and gets back the stacks to drop.
//
// Entry rules (the same functions vanilla uses):
//   • `n: [min, max]`  set_count uniform(min, max); a negative min means "clamped at 0" (e.g. [-1, 1] = 1/3 chance of one).
//   • `loot`           looting_enchant: + uniform(0, loot × level) to the count (vanilla 1 per level).
//   • `p` / `pl`       random_chance_with_enchanted_bonus: base chance, + `pl` per Looting level.
//   • `player`         killed_by_player condition (rare drops, blaze rods, breeze rods …).
//   • `cook`           furnace_smelt when the mob dies on fire.

export interface LootEntry {
  item: string;
  n?: [number, number];
  loot?: number;
  p?: number;
  pl?: number;
  player?: boolean;
  cook?: string;
}
/** One "pick exactly one of" pool (weights) — used for witch / guardian / zombie rare drops. */
export interface LootChoice { choice: [string, number][]; p?: number; pl?: number; player?: boolean; rolls?: [number, number]; n?: [number, number]; loot?: number }
type Table = (LootEntry | LootChoice)[];

const ZOMBIE_RARE: LootChoice = { choice: [['iron_ingot', 1], ['carrot', 1], ['potato', 1]], p: 0.025, pl: 0.01, player: true };

export const MOB_LOOT: Record<string, Table> = {
  // ---- passive -------------------------------------------------------------------------------------------------------------
  cow: [{ item: 'raw_beef', n: [1, 3], loot: 1, cook: 'cooked_beef' }, { item: 'leather', n: [0, 2], loot: 1 }],
  mooshroom: [{ item: 'raw_beef', n: [1, 3], loot: 1, cook: 'cooked_beef' }, { item: 'leather', n: [0, 2], loot: 1 }],
  pig: [{ item: 'porkchop', n: [1, 3], loot: 1, cook: 'cooked_porkchop' }],
  sheep: [{ item: 'mutton', n: [1, 2], loot: 1, cook: 'cooked_mutton' }],      // + 1 wool of its colour while unsheared (added by the caller)
  chicken: [{ item: 'chicken', n: [1, 1], loot: 1, cook: 'cooked_chicken' }, { item: 'feather', n: [0, 2], loot: 1 }],
  rabbit: [{ item: 'rabbit_hide', n: [0, 1], loot: 1 }, { item: 'rabbit', n: [0, 1], loot: 1, cook: 'cooked_rabbit' }, { item: 'rabbit_foot', p: 0.1, pl: 0.03, player: true }],
  horse: [{ item: 'leather', n: [0, 2], loot: 1 }], donkey: [{ item: 'leather', n: [0, 2], loot: 1 }], mule: [{ item: 'leather', n: [0, 2], loot: 1 }],
  llama: [{ item: 'leather', n: [0, 2], loot: 1 }],
  skeleton_horse: [{ item: 'bone', n: [0, 2], loot: 1 }], zombie_horse: [{ item: 'rotten_flesh', n: [0, 2], loot: 1 }],
  cat: [{ item: 'string', n: [0, 2], loot: 1 }],
  parrot: [{ item: 'feather', n: [1, 2], loot: 1 }],
  panda: [{ item: 'bamboo', n: [0, 2], loot: 1 }],
  polar_bear: [{ choice: [['cod', 3], ['salmon', 1]], n: [0, 2], loot: 1 }],
  dolphin: [{ item: 'cod', n: [0, 1], loot: 1, cook: 'cooked_cod' }],
  squid: [{ item: 'ink_sac', n: [1, 3], loot: 1 }], glow_squid: [{ item: 'glow_ink_sac', n: [1, 3], loot: 1 }],
  turtle: [{ item: 'seagrass', n: [0, 2], loot: 1 }],
  fish: [{ item: 'cod', n: [1, 1], cook: 'cooked_cod' }, { item: 'bone_meal', p: 0.05 }],
  salmon: [{ item: 'salmon', n: [1, 1], cook: 'cooked_salmon' }, { item: 'bone_meal', p: 0.05 }],
  tropical_fish: [{ item: 'tropical_fish', n: [1, 1] }, { item: 'bone_meal', p: 0.05 }],
  pufferfish: [{ item: 'pufferfish', n: [1, 1] }, { item: 'bone_meal', p: 0.05 }],
  strider: [{ item: 'string', n: [2, 5], loot: 1 }],
  snow_golem: [{ item: 'snowball', n: [0, 15] }],
  iron_golem: [{ item: 'iron_ingot', n: [3, 5] }, { item: 'poppy', n: [0, 2] }],
  // Nothing on death in Java: wolf, fox, ocelot, goat, camel, armadillo, sniffer, bee, frog, tadpole, axolotl, allay, bat,
  // villager, wandering trader (they only drop what they hold).
  // ---- hostile -------------------------------------------------------------------------------------------------------------
  zombie: [{ item: 'rotten_flesh', n: [0, 2], loot: 1 }, ZOMBIE_RARE],
  husk: [{ item: 'rotten_flesh', n: [0, 2], loot: 1 }, ZOMBIE_RARE],
  zombie_villager: [{ item: 'rotten_flesh', n: [0, 2], loot: 1 }, ZOMBIE_RARE],
  drowned: [{ item: 'rotten_flesh', n: [0, 2], loot: 1 }, { item: 'copper_ingot', p: 0.11, pl: 0.02, player: true }],
  skeleton: [{ item: 'bone', n: [0, 2], loot: 1 }, { item: 'arrow', n: [0, 2], loot: 1 }],
  stray: [{ item: 'bone', n: [0, 2], loot: 1 }, { item: 'arrow', n: [0, 2], loot: 1 }],
  bogged: [{ item: 'bone', n: [0, 2], loot: 1 }, { item: 'arrow', n: [0, 2], loot: 1 }],
  wither_skeleton: [{ item: 'coal', n: [-1, 1], loot: 1 }, { item: 'bone', n: [0, 2], loot: 1 }, { item: 'wither_skeleton_skull', p: 0.025, pl: 0.01, player: true }],
  creeper: [{ item: 'gunpowder', n: [0, 2], loot: 1 }],
  spider: [{ item: 'string', n: [0, 2], loot: 1 }, { item: 'spider_eye', n: [-1, 1], loot: 1, player: true }],
  cave_spider: [{ item: 'string', n: [0, 2], loot: 1 }, { item: 'spider_eye', n: [-1, 1], loot: 1, player: true }],
  enderman: [{ item: 'ender_pearl', n: [0, 1], loot: 1 }],
  blaze: [{ item: 'blaze_rod', n: [0, 1], loot: 1, player: true }],
  ghast: [{ item: 'ghast_tear', n: [0, 1], loot: 1 }, { item: 'gunpowder', n: [0, 2], loot: 1 }],
  breeze: [{ item: 'breeze_rod', n: [1, 2], loot: 1, player: true }],
  witch: [{ choice: [['glass_bottle', 1], ['glowstone_dust', 1], ['gunpowder', 1], ['redstone', 1], ['spider_eye', 1], ['sugar', 1], ['stick', 2]], rolls: [1, 3], n: [0, 2], loot: 1 }],
  guardian: [{ item: 'prismarine_shard', n: [0, 2], loot: 1 }, { choice: [['cod', 2], ['prismarine_crystals', 2], ['', 1]], loot: 1 }],
  elder_guardian: [{ item: 'prismarine_shard', n: [0, 2], loot: 1 }, { choice: [['cod', 2], ['prismarine_crystals', 2], ['', 1]], loot: 1 }, { item: 'wet_sponge', n: [1, 1], player: true }],
  shulker: [{ item: 'shulker_shell', p: 0.5, pl: 0.0625 }],
  phantom: [{ item: 'phantom_membrane', n: [0, 1], loot: 1, player: true }],
  pillager: [{ item: 'crossbow', p: 0.085, pl: 0.01, player: true }],
  vindicator: [{ item: 'emerald', n: [0, 1], loot: 1, player: true }, { item: 'iron_axe', p: 0.085, pl: 0.01, player: true }],
  evoker: [{ item: 'totem_of_undying', n: [1, 1] }, { item: 'emerald', n: [0, 1], loot: 1, player: true }],
  ravager: [{ item: 'saddle', n: [1, 1] }],
  hoglin: [{ item: 'porkchop', n: [2, 4], loot: 1, cook: 'cooked_porkchop' }, { item: 'leather', n: [0, 1], loot: 1 }],
  zoglin: [{ item: 'rotten_flesh', n: [1, 3], loot: 1 }],
  piglin_brute: [{ item: 'golden_axe', p: 0.085, pl: 0.01, player: true }],
  zombified_piglin: [{ item: 'rotten_flesh', n: [0, 1], loot: 1 }, { item: 'gold_nugget', n: [0, 1], loot: 1 }, { item: 'gold_ingot', p: 0.025, pl: 0.01, player: true }],
  warden: [{ item: 'sculk_catalyst', n: [1, 1] }],
  wither: [{ item: 'nether_star', n: [1, 1] }],
  // ender dragon: no items (XP + the egg on the portal).
};

export interface LootContext {
  species: string;
  rng: () => number;
  looting?: number;
  onFire?: boolean;
  /** killed_by_player (defaults to true: this is a single-player game where almost every kill is the player's). */
  byPlayer?: boolean;
  /** Slime / magma cube size. */
  size?: number;
  /** Unsheared sheep drop one wool block of their colour. */
  wool?: string | null;
}

const uni = (rng: () => number, a: number, b: number) => a + Math.floor(rng() * (b - a + 1));

/** Rolls the vanilla loot of a dying mob. Returns merged [item, count] pairs (count ≥ 1). */
export function rollMobLoot(ctx: LootContext): [string, number][] {
  const { rng } = ctx, looting = Math.max(0, ctx.looting ?? 0), byPlayer = ctx.byPlayer !== false;
  const out = new Map<string, number>();
  const add = (item: string, n: number) => { if (item && n > 0) out.set(item, (out.get(item) ?? 0) + n); };
  let table: Table | undefined = MOB_LOOT[ctx.species];
  if (ctx.species === 'slime') table = (ctx.size ?? 1) === 1 ? [{ item: 'slime_ball', n: [0, 2], loot: 1 }] : [];
  if (ctx.species === 'magma_cube') table = (ctx.size ?? 1) > 1 ? [{ item: 'magma_cream', n: [-2, 1], loot: 1 }] : [];
  if (ctx.species === 'sheep' && ctx.wool) add(ctx.wool, 1);
  for (const e of table ?? []) {
    if (e.player && !byPlayer) continue;
    if (e.p !== undefined && rng() >= e.p + (e.pl ?? 0) * looting) continue;
    if ('choice' in e) {
      const rolls = e.rolls ? uni(rng, e.rolls[0], e.rolls[1]) : 1;
      const total = e.choice.reduce((s, c) => s + c[1], 0);
      for (let r = 0; r < rolls; r++) {
        let x = rng() * total, pick = e.choice[e.choice.length - 1][0];
        for (const [item, w] of e.choice) { x -= w; if (x < 0) { pick = item; break; } }
        let n = e.n ? Math.max(0, uni(rng, e.n[0], e.n[1])) : 1;
        if (e.loot && looting) n += uni(rng, 0, e.loot * looting);
        add(pick, n);
      }
      continue;
    }
    let n = e.n ? uni(rng, e.n[0], e.n[1]) : 1;
    if (e.loot && looting) n += uni(rng, 0, e.loot * looting);
    add(ctx.onFire && e.cook ? e.cook : e.item, Math.max(0, n));
  }
  return [...out];
}
