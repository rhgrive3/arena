// Sheep wool colours — Java Edition (minecraft.wiki "Sheep", "Dye", "Wool").
//  • Natural colours follow the biome group (Java 1.21.5 "Spring to Life"): temperate → white common; cold → black common;
//    warm → brown common. Common 81.836 %, three uncommon colours 5 % each, rare 3 %, pink 0.164 % everywhere.
//  • Lambs inherit their parents' colour: the 2-dye crafting mix when one exists (blue + white → light blue …), otherwise one
//    parent's colour at random.
//  • The fleece is tinted with the Java sheep colour table (the dye's colour × 0.75, white #E6E6E6).
export const DYE_IDS = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black'] as const;
export type DyeId = (typeof DYE_IDS)[number];

/** Java Edition sheep fleece colours (minecraft.wiki "Dye" › Color values, "Sheep (JE)" column). */
export const SHEEP_COLORS: Record<DyeId, string> = {
  white: '#e6e6e6', orange: '#ba6015', magenta: '#953a8d', light_blue: '#2b86a3', yellow: '#bea22d', lime: '#609517', pink: '#b6687f', gray: '#353b3d',
  light_gray: '#757571', cyan: '#107575', purple: '#66258a', blue: '#2d337f', brown: '#623f25', green: '#465d10', red: '#84221c', black: '#151518',
};

export type SheepBiomeGroup = 'temperate' | 'cold' | 'warm';
/** Biome → sheep colour group (wiki "Sheep" › Spawning lists). */
export function sheepBiomeGroup(biome: string): SheepBiomeGroup {
  const b = biome.toLowerCase();
  if (/savanna|jungle|badlands|desert|warm_ocean|lukewarm|mangrove|nether|crimson|warped|soul_sand|basalt/.test(b)) return 'warm';
  if (/snow|frozen|ice|taiga|grove|jagged_peaks|slope|windswept|cold_ocean|deep_dark|the_end|^end/.test(b)) return 'cold';
  return 'temperate';
}
const TIERS: Record<SheepBiomeGroup, { common: DyeId; uncommon: DyeId[]; rare: DyeId }> = {
  temperate: { common: 'white', uncommon: ['light_gray', 'gray', 'black'], rare: 'brown' },
  cold: { common: 'black', uncommon: ['white', 'light_gray', 'gray'], rare: 'brown' },
  warm: { common: 'brown', uncommon: ['white', 'light_gray', 'gray'], rare: 'black' },
};
/** Natural spawn colour: common 81.836 %, uncommon 3 × 5 %, rare 3 %, pink 0.164 %. */
export function rollSheepColor(group: SheepBiomeGroup, rng: () => number): DyeId {
  const t = TIERS[group], r = rng() * 100;
  if (r < 0.164) return 'pink';
  if (r < 0.164 + 3) return t.rare;
  if (r < 0.164 + 3 + 15) return t.uncommon[Math.min(2, Math.floor((r - 3.164) / 5))];
  return t.common;
}

/** Java's two-dye crafting recipes (wiki "Dye"): the colour a lamb gets when its parents' colours mix. */
const MIX: Record<string, DyeId> = {
  'gray+white': 'light_gray', 'black+white': 'gray', 'red+yellow': 'orange', 'green+white': 'lime', 'blue+green': 'cyan',
  'blue+white': 'light_blue', 'blue+red': 'purple', 'pink+purple': 'magenta', 'red+white': 'pink',
};
export function mixDyes(a: DyeId, b: DyeId): DyeId | null {
  if (a === b) return a;
  return MIX[[a, b].sort().join('+')] ?? null;
}
/** A lamb's colour: the mix when the two dyes craft into another one, otherwise a random parent's colour. */
export function lambColor(a: DyeId, b: DyeId, rng: () => number): DyeId {
  return mixDyes(a, b) ?? (rng() < 0.5 ? a : b);
}
export const isDyeId = (s: string): s is DyeId => (DYE_IDS as readonly string[]).includes(s);
/** jeb_ sheep: the colour shown at `t` seconds (every colour in dye order, 25 ticks each). */
export const jebColor = (t: number, id: number): DyeId => DYE_IDS[Math.floor((t * 20 + id) / 25) % 16];
