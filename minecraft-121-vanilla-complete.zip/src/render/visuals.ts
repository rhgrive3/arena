import type { Dimension } from '../game/types';

export type Precipitation = 'none' | 'rain' | 'snow';
export type BlockReader = (x: number, y: number, z: number) => number;

const TEMPERATURE: Record<string, number> = {
  snowy_plains: 0, ice_spikes: 0, snowy_taiga: -0.5, snowy_beach: 0.05,
  snowy_slopes: -0.3, grove: -0.2, jagged_peaks: -0.7, frozen_peaks: -0.7,
  frozen_river: 0, frozen_ocean: 0, deep_frozen_ocean: 0,
  windswept_hills: 0.2, windswept_forest: 0.2, windswept_gravelly_hills: 0.2,
  taiga: 0.25, old_growth_spruce_taiga: 0.25, old_growth_pine_taiga: 0.3,
  meadow: 0.5, stony_shore: 0.2,
};
const DRY = new Set(['desert', 'badlands', 'eroded_badlands', 'wooded_badlands', 'savanna', 'savanna_plateau', 'windswept_savanna', 'stony_peaks']);

// Rendering-only climate lookup. No terrain, block state or weather is mutated.
export function precipitationAt(biome: string, y = 64, dimension: Dimension = 'overworld'): Precipitation {
  const name = biome.replace(/^minecraft:/, '');
  if (dimension !== 'overworld' || DRY.has(name)) return 'none';
  const temperature = (TEMPERATURE[name] ?? 0.8) - Math.max(0, y - 80) * 0.00125;
  return temperature < 0.15 ? 'snow' : 'rain';
}

export interface FovState {
  sprinting?: boolean;
  speedLevel?: number;
  slownessLevel?: number;
  bowCharge?: number;
  underwater?: boolean;
  flying?: boolean;
  spyglass?: boolean;
  spyglassScale?: number;
}

export function dynamicFov(base: number, state: FovState = {}): number {
  const fov = Number.isFinite(base) ? Math.min(110, Math.max(30, base)) : 70;
  if (state.spyglass) return fov * (state.spyglassScale ?? 0.1);
  const speed = Math.max(0.05, 1 + 0.2 * Math.max(0, state.speedLevel ?? 0) - 0.15 * Math.max(0, state.slownessLevel ?? 0));
  const movement = speed * (state.sprinting ? 1.3 : 1);
  const charge = Math.min(1, Math.max(0, state.bowCharge ?? 0));
  const multiplier = (1 + movement) * 0.5 * (state.flying ? 1.1 : 1) * (1 - charge * charge * 0.15);
  return Math.min(150, Math.max(5, fov * multiplier - (state.underwater ? 7 : 0)));
}

export interface NetherAtmosphere {
  particle: 'white_ash' | 'ash' | 'crimson_spore' | 'warped_spore';
  color: string;
  fall: number;
  drift: number;
  density: number;
  size: number;
  opacity: number;
}

export const NETHER_ATMOSPHERES: Record<string, NetherAtmosphere> = {
  basalt_deltas: { particle: 'white_ash', color: '#dedddd', fall: 0.75, drift: 0.6, density: 480, size: 0.065, opacity: 0.8 },
  // Java uses dark ash against cyan fog, not glowing blue soul flames.
  soul_sand_valley: { particle: 'ash', color: '#778b91', fall: 0.12, drift: 0.3, density: 140, size: 0.045, opacity: 0.58 },
  crimson_forest: { particle: 'crimson_spore', color: '#b52b35', fall: -0.08, drift: 0.22, density: 160, size: 0.065, opacity: 0.72 },
  warped_forest: { particle: 'warped_spore', color: '#35b8b2', fall: 0.18, drift: 0.38, density: 220, size: 0.06, opacity: 0.72 },
};

export const EFFECT_COLORS: Record<string, string> = {
  speed: '#33ebff', slowness: '#8bafe0', haste: '#d9c043', mining_fatigue: '#4a4217',
  strength: '#ffc700', instant_health: '#f82423', instant_damage: '#a9656a',
  jump_boost: '#fdff84', nausea: '#551d4a', regeneration: '#cd5cab', resistance: '#9146f0',
  fire_resistance: '#ff9900', water_breathing: '#98dac0', invisibility: '#f6f6f6',
  blindness: '#1f1f23', night_vision: '#c2ff66', hunger: '#587653', weakness: '#484d48',
  poison: '#87a363', wither: '#736156', health_boost: '#f87d23', absorption: '#2552a5',
  saturation: '#f82423', glowing: '#94a061', levitation: '#ceffff', luck: '#339900',
  slow_falling: '#f7f8e0', conduit_power: '#1dc2d1', dolphins_grace: '#88a3be',
  bad_omen: '#0b6138', hero_of_the_village: '#44ff44', darkness: '#292721',
  wind_charged: '#b8d7da', weaving: '#a29b89', oozing: '#99cc33', infested: '#8c9b8c',
  trial_omen: '#16a5aa', raid_omen: '#de574f',
};

export function potionColor(effects: Record<string, number | { t: number; amp: number }>): string | null {
  let r = 0, g = 0, b = 0, weight = 0;
  for (const [id, effect] of Object.entries(effects)) {
    const time = typeof effect === 'number' ? effect : effect.t;
    if (!(time > 0)) continue;
    const color = parseInt((EFFECT_COLORS[id] ?? '#8b8b8b').slice(1), 16);
    const n = typeof effect === 'number' ? 1 : Math.max(1, effect.amp + 1);
    r += (color >> 16) * n; g += ((color >> 8) & 255) * n; b += (color & 255) * n; weight += n;
  }
  if (!weight) return null;
  return '#' + [r, g, b].map(c => Math.round(c / weight).toString(16).padStart(2, '0')).join('');
}