import { canvas as makeAtlasCanvas } from "../textures/atlas";
import * as THREE from 'three';
import { paintBanner, BANNER_W, BANNER_H, type BannerLayer } from '../systems/banners';
import { getTileTexture } from '../textures/atlas';

/**
 * Placed banners that carry loom patterns: a full 3D banner assembly (wooden pole, horizontal crossbar,
 * gold end finials, and 3D cloth box textured on front & back with the layered loom pattern).
 */
export class BannerMeshes {
  private meshes = new Map<string, THREE.Object3D>();
  private poleGeo = new THREE.BoxGeometry(0.11, 1.75, 0.11);
  private barGeo = new THREE.BoxGeometry(0.84, 0.125, 0.14);
  private finialGeo = new THREE.BoxGeometry(0.06, 0.10, 0.12);
  private clothGeo = new THREE.BoxGeometry(0.75, 1.52, 0.06);
  private woodMat: THREE.MeshLambertMaterial | null = null;
  private goldMat: THREE.MeshLambertMaterial | null = null;

  constructor(private scene: THREE.Scene) {}

  private ensureBaseMats() {
    if (!this.woodMat) {
      try {
        this.woodMat = new THREE.MeshLambertMaterial({ map: getTileTexture('oak_planks') });
        this.goldMat = new THREE.MeshLambertMaterial({ map: getTileTexture('gold_block') });
      } catch {
        this.woodMat = new THREE.MeshLambertMaterial({ color: '#a88754' });
        this.goldMat = new THREE.MeshLambertMaterial({ color: '#f6d03c' });
      }
    }
  }

  set(key: string, x: number, y: number, z: number, base: string, layers: BannerLayer[], yaw: number) {
    this.remove(key);
    this.ensureBaseMats();
    const cv = makeAtlasCanvas(BANNER_W * 3, BANNER_H * 3) as unknown as HTMLCanvasElement;
    paintBanner(cv.getContext('2d')!, base, layers, 3);
    const tex = new THREE.CanvasTexture(cv);
    tex.magFilter = THREE.NearestFilter;
    tex.colorSpace = THREE.SRGBColorSpace;

    const group = new THREE.Group();
    const pole = new THREE.Mesh(this.poleGeo, this.woodMat!);
    pole.position.set(0, 0.875, 0);
    group.add(pole);

    const bar = new THREE.Mesh(this.barGeo, this.woodMat!);
    bar.position.set(0, 1.71, 0);
    group.add(bar);

    for (const sx of [-0.44, 0.44]) {
      const fin = new THREE.Mesh(this.finialGeo, this.goldMat!);
      fin.position.set(sx, 1.71, 0);
      group.add(fin);
    }

    const clothMat = new THREE.MeshLambertMaterial({ map: tex, side: THREE.DoubleSide });
    const cloth = new THREE.Mesh(this.clothGeo, clothMat);
    cloth.position.set(0, 0.90, 0.09);
    group.add(cloth);

    group.position.set(x + 0.5, y, z + 0.5);
    group.rotation.y = yaw;
    this.scene.add(group);
    this.meshes.set(key, group);
  }
  remove(key: string) {
    const m = this.meshes.get(key);
    if (!m) return;
    this.scene.remove(m);
    m.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.material && mesh.material !== this.woodMat && mesh.material !== this.goldMat) {
        const mat = mesh.material as THREE.MeshLambertMaterial;
        mat.map?.dispose();
        mat.dispose();
      }
    });
    this.meshes.delete(key);
  }
  clear() { for (const k of [...this.meshes.keys()]) this.remove(k); }
  get size() { return this.meshes.size; }
}

/**
 * Dynamic 3D Bedrock Lock Bar renderer for repeaters locked by a side repeater/comparator.
 * Uses a single shared geometry and material across all locked repeaters to avoid extra texture/shader allocations.
 */
export class RepeaterLockMeshes {
  private meshes = new Map<string, THREE.Mesh>();
  private geo = new THREE.BoxGeometry(0.14, 0.16, 0.76);
  private mat: THREE.MeshLambertMaterial | null = null;

  constructor(private scene: THREE.Scene) {}

  private getMat(): THREE.MeshLambertMaterial {
    if (!this.mat) {
      try {
        this.mat = new THREE.MeshLambertMaterial({ map: getTileTexture('bedrock') });
      } catch {
        this.mat = new THREE.MeshLambertMaterial({ color: '#3b3b3b' });
      }
    }
    return this.mat;
  }

  sync(lockedKeys: Iterable<string>, getState: (x: number, y: number, z: number) => number) {
    const active = new Set<string>();
    for (const k of lockedKeys) {
      active.add(k);
      const [x, y, z] = k.split(',').map(Number);
      const state = getState(x, y, z);
      const dir = state & 3, delay = (state >> 2) & 3;
      const off = (9 - delay * 2) / 16;
      let m = this.meshes.get(k);
      if (!m) {
        m = new THREE.Mesh(this.geo, this.getMat());
        this.scene.add(m);
        this.meshes.set(k, m);
      }
      if (dir === 0 || dir === 2) {
        const bx = dir === 0 ? off + 1 / 16 : 1 - (off + 1 / 16);
        m.position.set(x + bx, y + 0.21, z + 0.5);
        m.rotation.y = 0;
      } else {
        const bz = dir === 1 ? off + 1 / 16 : 1 - (off + 1 / 16);
        m.position.set(x + 0.5, y + 0.21, z + bz);
        m.rotation.y = Math.PI / 2;
      }
    }
    for (const [k, m] of [...this.meshes.entries()]) {
      if (!active.has(k)) {
        this.scene.remove(m);
        this.meshes.delete(k);
      }
    }
  }

  clear() {
    for (const m of this.meshes.values()) this.scene.remove(m);
    this.meshes.clear();
  }

  get size() { return this.meshes.size; }
}

export type NetherRigKind =
  | 'campfire'
  | 'soul_campfire'
  | 'unlit_campfire'
  | 'spawner'
  | 'trial_spawner'
  | 'respawn_anchor'
  | 'wither_skeleton_skull'
  | 'piglin_head'
  | 'brewing_stand'
  | 'soul_lantern'
  | 'lantern';

interface RigEntry {
  kind: NetherRigKind;
  x: number;
  y: number;
  z: number;
  group: THREE.Group;
  spinner?: THREE.Object3D;
  flame?: THREE.Object3D;
}

/**
 * Multi-part 3D voxel sub-mesh manager for intricate Nether & dungeon blocks whose vanilla 3D geometry
 * requires crossed logs, rotating inner mob effigies, protruding Piglin snouts/tusks/ears, or alembic flasks.
 * Shares geometries and materials across all instances for zero per-block shader overhead.
 */
export class NetherBlockRigMeshes {
  private rigs = new Map<string, RigEntry>();
  private mats = new Map<string, THREE.Material>();
  private geos = new Map<string, THREE.BufferGeometry>();
  private time = 0;

  constructor(private scene: THREE.Scene) {}

  private box(w: number, h: number, d: number): THREE.BufferGeometry {
    const key = `${w.toFixed(4)},${h.toFixed(4)},${d.toFixed(4)}`;
    let g = this.geos.get(key);
    if (!g) {
      g = new THREE.BoxGeometry(w, h, d);
      this.geos.set(key, g);
    }
    return g;
  }

  private mat(tileOrHex: string, basic = false): THREE.Material {
    const key = `${basic ? 'B' : 'L'}:${tileOrHex}`;
    let m = this.mats.get(key);
    if (!m) {
      if (tileOrHex.startsWith('#')) {
        m = basic
          ? new THREE.MeshBasicMaterial({ color: tileOrHex })
          : new THREE.MeshLambertMaterial({ color: tileOrHex });
      } else {
        try {
          const tex = getTileTexture(tileOrHex);
          m = basic
            ? new THREE.MeshBasicMaterial({ map: tex, transparent: true, alphaTest: 0.1 })
            : new THREE.MeshLambertMaterial({ map: tex, transparent: true, alphaTest: 0.1 });
        } catch {
          m = basic
            ? new THREE.MeshBasicMaterial({ color: '#ff9e24' })
            : new THREE.MeshLambertMaterial({ color: '#7a5838' });
        }
      }
      this.mats.set(key, m);
    }
    return m;
  }

  set(key: string, x: number, y: number, z: number, kind: NetherRigKind) {
    const existing = this.rigs.get(key);
    if (existing && existing.kind === kind) return;
    if (existing) this.remove(key);

    const group = new THREE.Group();
    group.position.set(x + 0.5, y, z + 0.5);
    let spinner: THREE.Object3D | undefined;
    let flame: THREE.Object3D | undefined;

    if (kind === 'campfire' || kind === 'soul_campfire' || kind === 'unlit_campfire') {
      const logMat = this.mat('campfire_log_side');
      const soul = kind === 'soul_campfire';
      const lit = kind !== 'unlit_campfire';
      const emberMat = this.mat(lit ? (soul ? 'soul_campfire_ember' : 'campfire_ember') : 'basalt_top', lit);
      // 4 crossed 3D charred timber logs sitting atop the base
      const logZGeo = this.box(4 / 16, 3.5 / 16, 15.6 / 16);
      const logXGeo = this.box(15.6 / 16, 3.5 / 16, 4 / 16);
      const l1 = new THREE.Mesh(logZGeo, logMat); l1.position.set(-5 / 16, 0.5 + 1.2 / 16, 0);
      const l2 = new THREE.Mesh(logZGeo, logMat); l2.position.set(5 / 16, 0.5 + 1.2 / 16, 0);
      const l3 = new THREE.Mesh(logXGeo, logMat); l3.position.set(0, 0.5 + 3.2 / 16, -5 / 16);
      const l4 = new THREE.Mesh(logXGeo, logMat); l4.position.set(0, 0.5 + 3.2 / 16, 5 / 16);
      const bed = new THREE.Mesh(this.box(8 / 16, 1.2 / 16, 8 / 16), emberMat);
      bed.position.set(0, 0.505, 0);
      group.add(l1, l2, l3, l4, bed);

      if (lit) {
        const fg = new THREE.Group();
        fg.position.set(0, 0.56, 0);
        const outerMat = this.mat(soul ? 'soul_fire' : 'fire', true);
        const coreMat = this.mat(soul ? '#7af7ff' : '#ffd84a', true);
        const f1 = new THREE.Mesh(this.box(6 / 16, 7 / 16, 1.5 / 16), outerMat);
        const f2 = new THREE.Mesh(this.box(1.5 / 16, 7 / 16, 6 / 16), outerMat);
        const fc = new THREE.Mesh(this.box(3.2 / 16, 5.5 / 16, 3.2 / 16), coreMat);
        f1.position.y = 3.5 / 16;
        f2.position.y = 3.5 / 16;
        fc.position.y = 2.8 / 16;
        fg.add(f1, f2, fc);
        group.add(fg);
        flame = fg;
      }
    } else if (kind === 'spawner' || kind === 'trial_spawner') {
      const trial = kind === 'trial_spawner';
      const spin = new THREE.Group();
      spin.position.set(0, 0.52, 0);
      const headMat = this.mat(trial ? 'trial_spawner_core' : 'spawner_core', true);
      const rodMat = this.mat(trial ? '#5cd4ba' : '#ffba38', true);
      const head = new THREE.Mesh(this.box(0.28, 0.28, 0.28), headMat);
      spin.add(head);
      for (let i = 0; i < 4; i++) {
        const a = (i * Math.PI) / 2;
        const rod = new THREE.Mesh(this.box(0.07, 0.34, 0.07), rodMat);
        rod.position.set(Math.cos(a) * 0.24, -0.04, Math.sin(a) * 0.24);
        spin.add(rod);
      }
      group.add(spin);
      spinner = spin;
    } else if (kind === 'piglin_head') {
      const snoutMat = this.mat('piglin_snout');
      const earMat = this.mat('piglin_ear');
      const tuskMat = this.mat('#fffdf2');
      const snout = new THREE.Mesh(this.box(5 / 16, 4 / 16, 2.2 / 16), snoutMat);
      snout.position.set(0, 4 / 16, 0.5 + 1 / 16);
      const tL = new THREE.Mesh(this.box(1.5 / 16, 3 / 16, 1.8 / 16), tuskMat);
      tL.position.set(-3.2 / 16, 3.5 / 16, 0.5 + 0.9 / 16);
      const tR = new THREE.Mesh(this.box(1.5 / 16, 3 / 16, 1.8 / 16), tuskMat);
      tR.position.set(3.2 / 16, 3.5 / 16, 0.5 + 0.9 / 16);
      const earL = new THREE.Mesh(this.box(1.6 / 16, 6 / 16, 4.5 / 16), earMat);
      earL.position.set(-0.5 - 0.7 / 16, 7 / 16, 0);
      earL.rotation.z = 0.18;
      const earR = new THREE.Mesh(this.box(1.6 / 16, 6 / 16, 4.5 / 16), earMat);
      earR.position.set(0.5 + 0.7 / 16, 7 / 16, 0);
      earR.rotation.z = -0.18;
      group.add(snout, tL, tR, earL, earR);
    } else if (kind === 'wither_skeleton_skull') {
      const browMat = this.mat('wither_skeleton_skull_top');
      const brow = new THREE.Mesh(this.box(12 / 16, 2 / 16, 1.4 / 16), browMat);
      brow.position.set(0, 10.5 / 16, 0.5 + 0.6 / 16);
      group.add(brow);
    } else if (kind === 'respawn_anchor') {
      const portalMat = this.mat('portal', true);
      const disk = new THREE.Mesh(this.box(10 / 16, 0.6 / 16, 10 / 16), portalMat);
      disk.position.set(0, 1.005, 0);
      group.add(disk);
      flame = disk;
    } else if (kind === 'brewing_stand') {
      const goldMat = this.mat('gold_block');
      const collar = new THREE.Mesh(this.box(4.2 / 16, 2 / 16, 4.2 / 16), goldMat);
      collar.position.set(0, 11 / 16, 0);
      const p1 = new THREE.Mesh(this.box(3.2 / 16, 4.5 / 16, 3.2 / 16), this.mat('#d93848'));
      p1.position.set(-4.5 / 16, 4.2 / 16, 3.5 / 16);
      const p2 = new THREE.Mesh(this.box(3.2 / 16, 4.5 / 16, 3.2 / 16), this.mat('#9b42e8'));
      p2.position.set(4.5 / 16, 4.2 / 16, 3.5 / 16);
      const p3 = new THREE.Mesh(this.box(3.2 / 16, 4.5 / 16, 3.2 / 16), this.mat('#f59e28'));
      p3.position.set(0, 4.2 / 16, -4.5 / 16);
      group.add(collar, p1, p2, p3);
    } else if (kind === 'soul_lantern' || kind === 'lantern') {
      const ironMat = this.mat('lantern_iron');
      const loop = new THREE.Mesh(this.box(2 / 16, 2.5 / 16, 2 / 16), ironMat);
      loop.position.set(0, 10 / 16, 0);
      group.add(loop);
    }

    this.scene.add(group);
    this.rigs.set(key, { kind, x, y, z, group, spinner, flame });
  }

  remove(key: string) {
    const r = this.rigs.get(key);
    if (!r) return;
    this.scene.remove(r.group);
    this.rigs.delete(key);
  }

  unloadChunk(cx: number, cz: number) {
    const x0 = cx * 16, x1 = x0 + 16, z0 = cz * 16, z1 = z0 + 16;
    for (const [k, r] of [...this.rigs.entries()]) {
      if (r.x >= x0 && r.x < x1 && r.z >= z0 && r.z < z1) this.remove(k);
    }
  }

  update(dt: number) {
    this.time += dt;
    for (const r of this.rigs.values()) {
      if (r.spinner) {
        r.spinner.rotation.y = this.time * 2.2 + (r.x * 0.7 + r.z * 1.3);
        r.spinner.position.y = 0.5 + Math.sin(this.time * 3.2 + r.x) * 0.06;
      }
      if (r.flame && (r.kind === 'campfire' || r.kind === 'soul_campfire')) {
        const s = 0.92 + Math.sin(this.time * 9 + r.x * 2.1 + r.z * 1.7) * 0.1;
        r.flame.scale.set(1, s, 1);
      }
    }
  }

  clear() {
    for (const k of [...this.rigs.keys()]) this.remove(k);
  }

  get size() { return this.rigs.size; }
}
