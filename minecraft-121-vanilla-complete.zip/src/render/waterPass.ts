// Shader-pack style water: a small deferred step so the water can see what lies behind it.
//
//   1. Everything except fluids and the "late" see-through effects (rain, particles) is drawn into an MSAA render target
//      with a depth texture.
//   2. That image is copied to the screen by a full-screen triangle which also writes its depth (gl_FragDepth), so the
//      default framebuffer ends up exactly as if the scene had been drawn there.
//   3. The fluid meshes (layer 1) are drawn with normal depth testing; their shader samples the colour + depth of step 1 for
//      refraction, per-pixel water thickness (Beer–Lambert absorption), shoreline foam and Snell's window.
//   4. Late transparent effects (layer 2) are drawn last, on top of water and terrain, depth-tested against both.
//
// Cost: one extra full-screen pass and one HalfFloat MSAA target the size of the canvas. Only enabled on High / Ultra with
// WebGL 2; Low / Medium keep the single-pass alpha-blended water.
import * as THREE from 'three';

export const LAYER_FLUID = 1;
export const LAYER_LATE = 2;

export class WaterPass {
  enabled = false;
  private rt: THREE.WebGLRenderTarget | null = null;
  private quadScene = new THREE.Scene();
  private quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private quadMat: THREE.ShaderMaterial;
  private size = new THREE.Vector2();

  constructor(private renderer: THREE.WebGLRenderer, private waterMat: THREE.ShaderMaterial, private uniforms: Record<string, THREE.IUniform>) {
    this.quadMat = new THREE.ShaderMaterial({
      uniforms: { tColor: { value: null }, tDepth: { value: null } },
      depthTest: true, depthWrite: true, depthFunc: THREE.AlwaysDepth,
      vertexShader: 'varying vec2 vUv; void main(){ vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }',
      fragmentShader: `uniform sampler2D tColor; uniform sampler2D tDepth; varying vec2 vUv;
        void main(){
          gl_FragColor = vec4(texture2D(tColor, vUv).rgb, 1.0);
          gl_FragDepth = texture2D(tDepth, vUv).r;
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
    });
    const tri = new THREE.BufferGeometry();
    tri.setAttribute('position', new THREE.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
    const quad = new THREE.Mesh(tri, this.quadMat);
    quad.frustumCulled = false;
    this.quadScene.add(quad);
  }

  /** Turns the refraction path on / off (quality preset, WebGL 2 required). */
  setEnabled(on: boolean) {
    on = on && this.renderer.capabilities.isWebGL2;
    if (on === this.enabled) return;
    this.enabled = on;
    this.uniforms.uRefract.value = on ? 1 : 0;
    // Refraction composites the background itself, so the water is opaque and writes depth (water seen through water uses the
    // nearest surface, like shader packs); the fallback blends.
    this.waterMat.transparent = !on;
    this.waterMat.depthWrite = on;
    this.waterMat.needsUpdate = true;
    if (!on) { this.rt?.dispose(); this.rt = null; }
  }

  private ensureTarget() {
    this.renderer.getDrawingBufferSize(this.size);
    const w = Math.max(1, Math.floor(this.size.x)), h = Math.max(1, Math.floor(this.size.y));
    if (this.rt && this.rt.width === w && this.rt.height === h) return this.rt;
    this.rt?.dispose();
    const depth = new THREE.DepthTexture(w, h);
    depth.type = THREE.UnsignedIntType;
    this.rt = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, samples: 4, depthTexture: depth, depthBuffer: true });
    this.rt.texture.minFilter = this.rt.texture.magFilter = THREE.LinearFilter;
    return this.rt;
  }

  /** Moves see-through effects (points, sprites, depth-write-free transparent meshes) to the late layer. */
  private classify(scene: THREE.Scene) {
    for (const o of scene.children) {
      if (o.userData.lateChecked) continue;
      if ((o as THREE.Light).isLight) { o.layers.enableAll(); o.userData.lateChecked = true; continue; }
      const mat = (o as THREE.Mesh).material as THREE.Material | undefined;
      const late = (o as THREE.Points).isPoints || (!!mat && !Array.isArray(mat) && mat.transparent && !mat.depthWrite && !o.userData.sky);
      if (late && !o.userData.fluid) o.layers.set(LAYER_LATE);
      o.userData.lateChecked = true;
    }
  }

  render(scene: THREE.Scene, camera: THREE.PerspectiveCamera) {
    const r = this.renderer;
    camera.layers.enableAll();
    if (!this.enabled) { r.render(scene, camera); return; }
    this.classify(scene);
    const rt = this.ensureTarget(), autoClear = r.autoClear;
    // 1. scene without fluids / late effects → target
    camera.layers.set(0);
    r.setRenderTarget(rt);
    r.render(scene, camera);
    r.setRenderTarget(null);
    // 2. copy colour + depth to the screen
    this.quadMat.uniforms.tColor.value = rt.texture;
    this.quadMat.uniforms.tDepth.value = rt.depthTexture;
    r.render(this.quadScene, this.quadCam);
    // 3. fluids sample the target
    const u = this.uniforms;
    u.uScene.value = rt.texture; u.uDepthTex.value = rt.depthTexture;
    (u.uRes.value as THREE.Vector2).set(rt.width, rt.height);
    (u.uCamNF.value as THREE.Vector2).set(camera.near, camera.far);
    r.autoClear = false;
    camera.layers.set(LAYER_FLUID);
    r.render(scene, camera);
    // 4. rain, particles and other see-through effects on top
    camera.layers.set(LAYER_LATE);
    r.render(scene, camera);
    r.autoClear = autoClear;
    camera.layers.enableAll();
  }

  dispose() { this.rt?.dispose(); this.quadMat.dispose(); }
}
