import * as THREE from 'three';
import { BLOCKS, ID } from '../game/data';
import type { Stack } from '../game/types';
import { getTileTexture } from '../textures/atlas';
import { bannerColorOf, bannerShieldCanvas, type BannerLayer } from '../systems/banners';
import { potionColor, type BlockReader } from './visuals';

export type VanillaParticleKind = 'crit' | 'enchanted_hit' | 'mobSpell' | 'portal' | 'lava_pop' | 'drip_water' | 'drip_lava' | 'rain_splash' | 'happy_villager';
export interface ParticleOptions {
  count?: number;
  color?: string;
  life?: number;
  target?: THREE.Vector3;
  radius?: number;
  height?: number;
  phase?: number;
}

const MASKS: Record<string, string[]> = {
  crit: ['#......#', '.#....#.', '..#..#..', '...##...', '...##...', '..#..#..', '.#....#.', '#......#'],
  enchanted_hit: ['........', '.#....#.', '..####..', '.##..##.', '.##..##.', '..####..', '.#....#.', '........'],
  happy_villager: ['...#....', '...#....', '..###...', '########', '..###...', '...#....', '...#....', '........'],
  drip_hang: ['........', '...##...', '...##...', '........', '........', '........', '........', '........'],
  drip_fall: ['........', '........', '...##...', '...##...', '........', '........', '........', '........'],
  drip_land: ['........', '........', '........', '..####..', '........', '........', '........', '........'],
  lava_pop: ['........', '..####..', '..####..', '..####..', '..####..', '...##...', '........', '........'],
};
const COLORS: Record<VanillaParticleKind, string> = {
  crit: '#bca47d', enchanted_hit: '#a5f3e8', mobSpell: '#33ebff', portal: '#ad3ee0',
  lava_pop: '#ffb31a', drip_water: '#426bd6', drip_lava: '#ff7011', rain_splash: '#477bd5', happy_villager: '#24d329',
};

interface Particle {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  gravity: number;
  life: number;
  max: number;
  rotSpeed: number;
  kind?: VanillaParticleKind;
  color?: string;
  age?: number;
  size?: number;
  phase?: number;
  radius?: number;
  height?: number;
  start?: THREE.Vector3;
  target?: THREE.Vector3;
  anchor?: THREE.Vector3;
  hang?: number;
  landed?: boolean;
  frame?: number;
}

interface Drop {
  mesh: THREE.Mesh;
  name: string;
  count: number;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  baseY: number;
}

// =====================================================================================================================
// Java Edition billboard particles ("FX layer")
// ---------------------------------------------------------------------------------------------------------------------
// Vanilla particles are camera-facing 2D sprites that live for a handful of 20 Hz game ticks, are visible within 32
// blocks and (mostly) ignore entities. Everything below reproduces the client-side particle classes of Java Edition:
//   CritParticle (crit / enchanted_hit) + TrackingEmitter, SpellParticle (entity_effect — "mobSpell" before 1.13),
//   PortalParticle, LavaParticle (+ block.lava.pop), DripParticle (dripping_* -> falling_* -> splash / landing_lava),
//   WaterDropParticle (rain), SplashParticle, SuspendedTownParticle (happy_villager) and SmokeParticle.
// All velocities are blocks / tick and all lifetimes are ticks, exactly like the game; rendering interpolates between
// the previous and the current tick. `FxSim` has no three.js dependency so it can be verified headlessly.
// =====================================================================================================================

export const FX_TICK = 1 / 20;
/** "Particles render in a spherical area around the player with a radius of 32 blocks." */
export const FX_RANGE = 32;
export const FX_MAX = 2048;

export type FxKind =
  | 'crit' | 'enchanted_hit' | 'effect' | 'portal' | 'lava' | 'smoke'
  | 'dripping_water' | 'falling_water' | 'dripping_lava' | 'falling_lava' | 'landing_lava'
  | 'rain' | 'splash' | 'happy_villager';

export type RGB = [number, number, number];
/** Feet-centre position + bounding box of an entity (Java: getX(scale) = x + width * scale, getY(scale) = y + height * scale). */
export interface FxBox { x: number; y: number; z: number; w: number; h: number }

export interface FxSpec {
  /** Java Edition particle id. */
  id: string;
  /** Sprite frames in the atlas, in playback order. */
  frames: number[];
  /** Ignores the ambient light (rendered full-bright). */
  emissive: boolean;
  note: string;
}

// Sprite atlas slots (8 x 4 grid of 8 px sprites).
const S = { crit: 0, ench: 1, spell: [2, 3, 4, 5], glint: 6, lava: 7, generic: [8, 9, 10], dripHang: 11, dripFall: 12, dripLand: 13, splash: [14, 15] };

export const FX_SPECS: Record<FxKind, FxSpec> = {
  crit:           { id: 'crit',           frames: [S.crit],     emissive: false, note: 'white star that fades to orange (green *0.96, blue *0.9 per tick)' },
  enchanted_hit:  { id: 'enchanted_hit',  frames: [S.ench],     emissive: true,  note: 'crit particle tinted red *0.3, green *0.8 -> blue-white spark' },
  effect:         { id: 'entity_effect',  frames: S.spell,      emissive: false, note: 'rising swirl in the colour of the status effect' },
  portal:         { id: 'portal',         frames: [S.generic[0]], emissive: true, note: 'purple mote that is pulled into its origin' },
  lava:           { id: 'lava',           frames: [S.lava],     emissive: true,  note: 'ember that hops off a lava surface and trails smoke' },
  smoke:          { id: 'smoke',          frames: S.generic,    emissive: false, note: 'dark rising puff' },
  dripping_water: { id: 'dripping_water', frames: [S.dripHang], emissive: false, note: 'hangs under the block for 40 ticks' },
  falling_water:  { id: 'falling_water',  frames: [S.dripFall], emissive: false, note: 'falls, then splashes' },
  dripping_lava:  { id: 'dripping_lava',  frames: [S.dripHang], emissive: true,  note: 'white-hot, cools to orange while hanging' },
  falling_lava:   { id: 'falling_lava',   frames: [S.dripFall], emissive: true,  note: 'falls, then leaves a landing_lava blob' },
  landing_lava:   { id: 'landing_lava',   frames: [S.dripLand], emissive: true,  note: 'flat blob on the floor' },
  rain:           { id: 'rain',           frames: S.splash,     emissive: false, note: 'droplet that bounces off the block the rain hits' },
  splash:         { id: 'splash',         frames: S.splash,     emissive: false, note: 'water droplet' },
  happy_villager: { id: 'happy_villager', frames: [S.glint],    emissive: true,  note: 'green glint that hangs almost still' },
};

/** The names used in the feature request / older game versions -> the Java Edition particle chain they map to. */
export const FX_ALIASES: Record<string, FxKind[]> = {
  crit: ['crit'],
  enchanted_hit: ['enchanted_hit'], magicCrit: ['enchanted_hit'],
  mobSpell: ['effect'], entity_effect: ['effect'],
  portal: ['portal'],
  lava_pop: ['lava', 'smoke'],
  drip_water: ['dripping_water', 'falling_water', 'splash'], dripWater: ['dripping_water', 'falling_water', 'splash'],
  drip_lava: ['dripping_lava', 'falling_lava', 'landing_lava'], dripLava: ['dripping_lava', 'falling_lava', 'landing_lava'],
  rain_splash: ['rain'],
  happy_villager: ['happy_villager'], happyVillager: ['happy_villager'],
};

export const FX_COLORS = {
  water: [0.2, 0.3, 1.0] as RGB,                       // DripParticle water
  lavaFall: [1.0, 0.2857143, 0.083333336] as RGB,      // falling_lava / landing_lava
  rain: [0.38, 0.52, 0.96] as RGB,                     // tint of the splash sprites
};

export function hexToRgb(hex: string): RGB {
  const n = parseInt(hex.replace('#', ''), 16) || 0;
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

export interface FxParticle {
  kind: FxKind;
  x: number; y: number; z: number;
  px: number; py: number; pz: number;
  vx: number; vy: number; vz: number;
  age: number; life: number;
  /** Java `quadSize`: half the edge of the sprite, in blocks. */
  size: number;
  r: number; g: number; b: number; a: number;
  /** Downward acceleration in blocks / tick². */
  gravity: number;
  friction: number;
  physics: boolean;
  onGround: boolean;
  /** PortalParticle origin. */
  sx: number; sy: number; sz: number;
  /** Helix of the status-effect swirl. */
  orbit?: { cx: number; cz: number; radius: number; angle: number; omega: number };
}

interface FxEmitter { kind: 'crit' | 'enchanted_hit'; age: number; life: number; box: FxBox | (() => FxBox) }

export class FxSim {
  list: FxParticle[] = [];
  emitters: FxEmitter[] = [];
  /** Camera position; particles further than FX_RANGE away are not created. */
  viewer: { x: number; y: number; z: number } | null = null;
  /** How many particles of each kind were ever created (debugging / tests). */
  spawned: Partial<Record<FxKind, number>> = {};
  ticks = 0;
  /** Fraction of the current tick that has elapsed, for render interpolation. */
  alpha = 0;
  private acc = 0;

  constructor(public rand: () => number = Math.random, public solid: (x: number, y: number, z: number) => boolean = () => false) {}

  private gauss() {
    const u = Math.max(1e-9, this.rand()), v = this.rand();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  /** Particle(level, x, y, z, xa, ya, za): the random initial velocity every vanilla particle starts from. */
  private baseVelocity(p: FxParticle, xa: number, ya: number, za: number) {
    const r = this.rand;
    const vx = xa + (r() * 2 - 1) * 0.4, vy = ya + (r() * 2 - 1) * 0.4, vz = za + (r() * 2 - 1) * 0.4;
    const f = (r() + r() + 1) * 0.15, len = Math.hypot(vx, vy, vz) || 1;
    p.vx = (vx / len) * f * 0.4;
    p.vy = (vy / len) * f * 0.4 + 0.1;
    p.vz = (vz / len) * f * 0.4;
  }

  spawn(kind: FxKind, x: number, y: number, z: number, xa = 0, ya = 0, za = 0, color?: RGB, alpha = 1): FxParticle | null {
    if (this.list.length >= FX_MAX) return null;
    const v = this.viewer;
    if (v) {
      const dx = x - v.x, dy = y - v.y, dz = z - v.z;
      if (dx * dx + dy * dy + dz * dz > FX_RANGE * FX_RANGE) return null;
    }
    const r = this.rand;
    const p: FxParticle = {
      kind, x, y, z, px: x, py: y, pz: z, vx: 0, vy: 0, vz: 0, age: 0, life: 1,
      size: 0.1 * (r() * 0.5 + 0.5) * 2, r: 1, g: 1, b: 1, a: alpha,
      gravity: 0, friction: 0.98, physics: false, onGround: false, sx: x, sy: y, sz: z,
    };
    const life = (base: number, lo = 0.2) => Math.max(1, Math.floor(base / (r() * 0.8 + lo)));
    switch (kind) {
      case 'crit':
      case 'enchanted_hit': {
        this.baseVelocity(p, xa, ya, za);
        p.friction = 0.7; p.gravity = 0.04 * 0.5;
        p.vx = p.vx * 0.1 + xa * 0.4; p.vy = p.vy * 0.1 + ya * 0.4; p.vz = p.vz * 0.1 + za * 0.4;
        p.r = p.g = p.b = r() * 0.3 + 0.6;
        p.size *= 0.75;
        p.life = life(6, 0.6);
        if (kind === 'enchanted_hit') { p.r *= 0.3; p.g *= 0.8; }
        break;
      }
      case 'effect': {
        this.baseVelocity(p, 0.5 - r(), ya, 0.5 - r());
        p.friction = 0.96; p.gravity = 0.04 * -0.1;
        p.vy *= 0.2;
        p.size *= 0.75;
        p.life = life(8);
        break;
      }
      case 'portal': {
        p.vx = xa; p.vy = ya; p.vz = za;
        p.x = p.px = x + xa; p.y = p.py = y + ya + 1; p.z = p.pz = z + za;
        p.size = 0.1 * (r() * 0.2 + 0.5);
        const f = r() * 0.6 + 0.4;
        p.r = f * 0.9; p.g = f * 0.3; p.b = f;
        p.life = Math.floor(r() * 10) + 40;
        break;
      }
      case 'lava': {
        this.baseVelocity(p, 0, 0, 0);
        p.gravity = 0.04 * 0.75; p.friction = 0.999;
        p.vx *= 0.8; p.vz *= 0.8;
        p.vy = r() * 0.4 + 0.05;
        p.size *= r() * 2 + 0.2;
        p.life = life(16);
        p.physics = true;
        break;
      }
      case 'smoke': {
        this.baseVelocity(p, 0, 0, 0);
        p.friction = 0.96; p.gravity = 0.04 * -0.1;
        p.vx = p.vx * 0.1 + xa; p.vy = p.vy * 0.1 + ya; p.vz = p.vz * 0.1 + za;
        p.r = p.g = p.b = r() * 0.3;
        p.size *= 0.75;
        p.life = life(8);
        p.physics = true;
        break;
      }
      case 'dripping_water':
      case 'dripping_lava': {
        p.gravity = 0.06 * (kind === 'dripping_lava' ? 0.01 : 0.02);
        p.life = 40;
        if (kind === 'dripping_water') [p.r, p.g, p.b] = FX_COLORS.water;
        break;
      }
      case 'falling_water':
      case 'falling_lava': {
        p.vx = xa; p.vy = ya; p.vz = za;
        p.gravity = 0.06;
        p.life = life(64);
        p.physics = true;
        [p.r, p.g, p.b] = kind === 'falling_water' ? FX_COLORS.water : FX_COLORS.lavaFall;
        break;
      }
      case 'landing_lava': {
        p.life = life(16);
        [p.r, p.g, p.b] = FX_COLORS.lavaFall;
        break;
      }
      case 'rain':
      case 'splash': {
        this.baseVelocity(p, 0, 0, 0);
        p.vx *= 0.3; p.vz *= 0.3;
        p.vy = r() * 0.2 + 0.1;
        p.gravity = kind === 'rain' ? 0.06 : 0.04;
        p.life = life(8);
        p.physics = true;
        [p.r, p.g, p.b] = FX_COLORS.rain;
        break;
      }
      case 'happy_villager': {
        this.baseVelocity(p, xa, ya, za);
        p.vx *= 0.02; p.vy *= 0.02; p.vz *= 0.02;
        p.size *= r() * 0.6 + 0.5;
        p.life = life(20);
        p.friction = 0.99;
        break;
      }
    }
    if (color) { p.r = color[0]; p.g = color[1]; p.b = color[2]; }
    this.list.push(p);
    this.spawned[kind] = (this.spawned[kind] ?? 0) + 1;
    return p;
  }

  private move(p: FxParticle) {
    const nx = p.x + p.vx, ny = p.y + p.vy, nz = p.z + p.vz;
    if (p.physics && p.vy < 0 && this.solid(Math.floor(nx), Math.floor(ny), Math.floor(nz))) {
      p.x = nx; p.z = nz;
      p.y = Math.floor(ny) + 1.001;
      p.vy = 0;
      p.onGround = true;
    } else {
      p.x = nx; p.y = ny; p.z = nz;
      if (p.vy !== 0) p.onGround = false;
    }
  }

  /** One particle, one game tick. Returns false when the particle is gone. */
  private tickParticle(p: FxParticle): boolean {
    p.px = p.x; p.py = p.y; p.pz = p.z;
    if (p.age++ >= p.life) {
      if (p.kind === 'dripping_water') this.spawn('falling_water', p.x, p.y, p.z, p.vx, p.vy, p.vz);
      else if (p.kind === 'dripping_lava') this.spawn('falling_lava', p.x, p.y, p.z, p.vx, p.vy, p.vz);
      return false;
    }
    switch (p.kind) {
      case 'portal': {
        const f1 = p.age / p.life, f = 1 - (-f1 + f1 * f1 * 2);
        p.x = p.sx + p.vx * f;
        p.y = p.sy + p.vy * f + (1 - f1);
        p.z = p.sz + p.vz * f;
        return true;
      }
      case 'dripping_water':
      case 'dripping_lava':
        if (p.kind === 'dripping_lava') { p.r = 1; p.g = 16 / (p.age + 16); p.b = 4 / (p.age + 8); }
        p.vy -= p.gravity;
        this.move(p);
        p.vx *= 0.98; p.vy *= 0.98; p.vz *= 0.98;
        return true;
      case 'falling_water':
      case 'falling_lava':
        p.vy -= p.gravity;
        this.move(p);
        if (p.onGround) {
          this.spawn(p.kind === 'falling_water' ? 'splash' : 'landing_lava', p.x, p.y, p.z);
          return false;
        }
        p.vx *= 0.98; p.vy *= 0.98; p.vz *= 0.98;
        return true;
      case 'landing_lava':
        return true;
      case 'rain':
      case 'splash':
        p.vy -= p.gravity;
        this.move(p);
        p.vx *= 0.98; p.vy *= 0.98; p.vz *= 0.98;
        if (p.onGround) {
          if (this.rand() < 0.5) return false;
          p.vx *= 0.7; p.vz *= 0.7;
        }
        return true;
      case 'happy_villager':
        this.move(p);
        p.vx *= 0.99; p.vy *= 0.99; p.vz *= 0.99;
        return true;
      default: {
        p.vy -= p.gravity;
        this.move(p);
        if ((p.kind === 'effect' || p.kind === 'smoke') && p.y === p.py) { p.vx *= 1.1; p.vz *= 1.1; }
        p.vx *= p.friction; p.vy *= p.friction; p.vz *= p.friction;
        if (p.onGround) { p.vx *= 0.7; p.vz *= 0.7; }
        if (p.kind === 'crit' || p.kind === 'enchanted_hit') { p.g *= 0.96; p.b *= 0.9; }
        else if (p.kind === 'lava') { if (this.rand() > p.age / p.life) this.spawn('smoke', p.x, p.y, p.z, p.vx, p.vy, p.vz); }
        else if (p.kind === 'effect' && p.orbit) {
          const o = p.orbit;
          o.angle += o.omega;
          o.radius += 0.003;
          p.x = o.cx + Math.cos(o.angle) * o.radius;
          p.z = o.cz + Math.sin(o.angle) * o.radius;
        }
        return true;
      }
    }
  }

  tick() {
    this.ticks++;
    const r = this.rand;
    for (let i = this.emitters.length - 1; i >= 0; i--) {
      // TrackingEmitter: 16 tries per tick, kept when they fall inside the unit sphere.
      const e = this.emitters[i], b = typeof e.box === 'function' ? e.box() : e.box;
      for (let k = 0; k < 16; k++) {
        const d0 = r() * 2 - 1, d1 = r() * 2 - 1, d2 = r() * 2 - 1;
        if (d0 * d0 + d1 * d1 + d2 * d2 <= 1) this.spawn(e.kind, b.x + (b.w * d0) / 4, b.y + b.h * (0.5 + d1 / 4), b.z + (b.w * d2) / 4, d0, d1 + 0.2, d2);
      }
      if (++e.age >= e.life) this.emitters.splice(i, 1);
    }
    const list = this.list;
    for (let i = list.length - 1; i >= 0; i--) {
      if (!this.tickParticle(list[i])) {
        list[i] = list[list.length - 1];
        list.pop();
      }
    }
  }

  /** Advances by real time; returns how many game ticks ran. */
  step(dt: number): number {
    this.acc += Math.min(dt, 0.25);
    let n = 0;
    while (this.acc >= FX_TICK) { this.acc -= FX_TICK; this.tick(); n++; }
    this.alpha = this.acc / FX_TICK;
    return n;
  }

  count(kind: FxKind) { let n = 0; for (const p of this.list) if (p.kind === kind) n++; return n; }

  clear() { this.list.length = 0; this.emitters.length = 0; }

  // ---- Emitters ---------------------------------------------------------------------------------------------------

  /** Critical hit: Player.crit() attaches a 3-tick TrackingEmitter of `crit` stars to the victim. */
  crit(box: FxBox | (() => FxBox)) { this.emitters.push({ kind: 'crit', age: 0, life: 3, box }); }

  /** Sharpness / Smite / Bane of Arthropods / Impaling bonus damage: the same emitter with `enchanted_hit`. */
  enchantedHit(box: FxBox | (() => FxBox)) { this.emitters.push({ kind: 'enchanted_hit', age: 0, life: 3, box }); }

  /**
   * LivingEntity.tickEffects — call once per game tick for an entity with active status effects. One swirl is created
   * with a chance of 1 in 4 (ambient / beacon effects: 1 in 20 and 15 % opaque; invisible entities: 1 in 15), in the colour
   * of one of the active effects. `time` (seconds) winds the spawn point around the entity so the swirls climb in a helix.
   */
  mobSpell(box: FxBox, colors: RGB | RGB[], opts: { ambient?: boolean; invisible?: boolean; time?: number; force?: boolean } = {}): FxParticle | null {
    const r = this.rand, odds = (opts.invisible ? 15 : 4) * (opts.ambient ? 5 : 1);
    if (!opts.force && Math.floor(r() * odds) !== 0) return null;
    const list = (typeof colors[0] === 'number' ? [colors] : colors) as RGB[];
    if (!list.length) return null;
    const color = list[Math.floor(r() * list.length) % list.length];
    const radius = box.w * 0.5 + 0.05;
    const angle = (opts.time ?? this.ticks * FX_TICK) * 5 + (r() < 0.5 ? Math.PI : 0);
    const p = this.spawn('effect', box.x + Math.cos(angle) * radius, box.y + r() * box.h, box.z + Math.sin(angle) * radius, 1, 1, 1, color, opts.ambient ? 0.15 : 1);
    if (p) p.orbit = { cx: box.x, cz: box.z, radius, angle, omega: 0.25 };
    return p;
  }

  /** NetherPortalBlock.animateTick: four motes per visit that start beside the portal plane and are drawn into the block. */
  portal(bx: number, by: number, bz: number, planeAlongZ = false) {
    const r = this.rand;
    for (let i = 0; i < 4; i++) {
      let x = bx + r(), z = bz + r();
      const y = by + r();
      let vx = (r() - 0.5) * 0.5, vz = (r() - 0.5) * 0.5;
      const vy = (r() - 0.5) * 0.5, j = r() < 0.5 ? -1 : 1;
      if (planeAlongZ) { x = bx + 0.5 + 0.25 * j; vx = r() * 2 * j; }
      else { z = bz + 0.5 + 0.25 * j; vz = r() * 2 * j; }
      this.spawn('portal', x, y, z, vx, vy, vz);
    }
  }

  /** EnderMan.aiStep: two portal motes per tick anywhere in the bounding box. */
  enderman(box: FxBox, count = 2) {
    const r = this.rand;
    for (let i = 0; i < count; i++) {
      this.spawn('portal', box.x + box.w * (r() * 2 - 1) * 0.5, box.y + r() * box.h - 0.25, box.z + box.w * (r() * 2 - 1) * 0.5, (r() - 0.5) * 2, -r(), (r() - 0.5) * 2);
    }
  }

  /** LavaFluid.animateTick: an ember leaves the top face of a lava block that has air above it. */
  lavaPop(bx: number, by: number, bz: number) { return this.spawn('lava', bx + this.rand(), by + 1, bz + this.rand()); }

  /** A drip forming 0.05 below the underside of block (bx, by, bz), which has water / lava on top of it. */
  drip(bx: number, by: number, bz: number, fluid: 'water' | 'lava') {
    return this.spawn(fluid === 'water' ? 'dripping_water' : 'dripping_lava', bx + this.rand(), by - 0.05, bz + this.rand());
  }

  /** LevelRenderer.tickRain: a `rain` droplet on the top face (y = `top`) of the block the rain lands on; smoke over lava / magma. */
  rainSplash(bx: number, top: number, bz: number, smoke = false) {
    return this.spawn(smoke ? 'smoke' : 'rain', bx + this.rand(), top, bz + this.rand());
  }

  /** ParticleUtils.spawnParticleInBlock — bone meal: `count` (15) glints anywhere inside the block, drifting at gaussian * 0.02. */
  happyVillager(bx: number, by: number, bz: number, count = 15, xzSpread = 0.5, ySpread = 1) {
    const r = this.rand, off = 0.5 - xzSpread;
    for (let i = 0; i < count; i++) {
      const vx = this.gauss() * 0.02, vy = this.gauss() * 0.02, vz = this.gauss() * 0.02;
      this.spawn('happy_villager', bx + off + r() * xzSpread * 2, by + r() * ySpread, bz + off + r() * xzSpread * 2, vx, vy, vz);
    }
  }

  /** Villager.addParticlesAroundSelf — trading / claiming a job site: 5 glints around and above the villager. */
  happyVillagerAround(box: FxBox, count = 5) {
    const r = this.rand;
    for (let i = 0; i < count; i++) {
      const vx = this.gauss() * 0.02, vy = this.gauss() * 0.02, vz = this.gauss() * 0.02;
      this.spawn('happy_villager', box.x + box.w * (r() * 2 - 1), box.y + r() * box.h + 1, box.z + box.w * (r() * 2 - 1), vx, vy, vz);
    }
  }
}

/** Approximate bounding box of a mob rig (feet at the group's origin; height from the head joint). */
export function entityFxBox(group: { position: { x: number; y: number; z: number }; scale?: { y: number } }, head?: { position: { y: number } } | null): FxBox {
  const sc = group.scale?.y || 1;
  const h = Math.min(3.2, Math.max(0.4, ((head?.position.y ?? 1) + 0.35) * sc));
  return { x: group.position.x, y: group.position.y, z: group.position.z, w: Math.min(1.4, Math.max(0.3, h * 0.4)), h };
}

/** Current sprite half-size in blocks (the per-class getQuadSize overrides). */
export function fxRenderSize(p: FxParticle, alpha = 0): number {
  const t = Math.min(1, (p.age + alpha) / Math.max(1, p.life));
  switch (p.kind) {
    case 'crit':
    case 'enchanted_hit': return p.size * Math.min(1, t * 32);
    case 'portal': { const f = 1 - t; return p.size * (1 - f * f); }
    case 'lava': return p.size * (1 - t * t);
    default: return p.size;
  }
}

/** Atlas slot for the particle's age (setSpriteFromAge). */
export function fxFrame(p: FxParticle): number {
  const fr = FX_SPECS[p.kind].frames;
  if (fr.length === 1) return fr[0];
  return fr[Math.min(fr.length - 1, Math.floor((p.age * fr.length) / Math.max(1, p.life)))];
}

// ---- World-driven ambience (Level.animateTick / LevelRenderer.tickRain) ----------------------------------------------

export interface FxWorld { getBlock(x: number, y: number, z: number): number }

export interface AnimateOptions {
  /** Random block visits per tick. Vanilla does 667 within 16 blocks (plus 667 within 32); chances are scaled to compensate. */
  samples?: number;
  radius?: number;
  /** Rain strength 0‥1 (0 = no rain splashes). */
  rain?: number;
  /** "Decreased" particles: half the rain splashes (default true). */
  decreased?: boolean;
  /** Precipitation type at a position; splashes only appear where it rains (not where it snows or stays dry). */
  precipitation?: (x: number, y: number, z: number) => 'none' | 'rain' | 'snow';
  sound?: (kind: 'lava_pop' | 'lava_ambient' | 'portal', x: number, y: number, z: number) => void;
}

export const isFluidBlock = (id: number) => id > 0 && (id === ID.water || id === ID.lava);
export const isFullSolid = (id: number) => { const d = id > 0 ? BLOCKS[id] : undefined; return !!d && !!d.solid && d.shape === 'cube'; };
/** #impermeable: glass never lets drips through. */
export const isImpermeable = (id: number) => id > 0 && /glass/.test(BLOCKS[id]?.name ?? '');
const blocksMotion = (id: number) => id > 0 && (!!BLOCKS[id]?.solid || isFluidBlock(id));

/**
 * Level.trySpawnDripParticles for a fluid block at (x, y, z): the block below must be a full, permeable solid and the
 * space under that must be open. Returns the y of the block the drip hangs from, or null.
 */
export function dripBlockBelow(world: FxWorld, x: number, y: number, z: number): number | null {
  const b = world.getBlock(x, y - 1, z);
  if (!isFullSolid(b) || isImpermeable(b)) return null;
  const c = world.getBlock(x, y - 2, z);
  if (c < 0 || isFullSolid(c) || isFluidBlock(c)) return null;
  return y - 1;
}

/** Highest motion-blocking block of a column between yFrom (must be open, i.e. sky above) and yTo; null when covered / empty. */
export function rainColumnTop(world: FxWorld, x: number, z: number, yFrom: number, yTo: number): number | null {
  if (world.getBlock(x, yFrom, z) !== 0) return null;
  for (let y = yFrom - 1; y >= yTo; y--) if (blocksMotion(world.getBlock(x, y, z))) return y;
  return null;
}

export const RAIN_SPLASH_RADIUS = 10;
const RAIN_SCAN_UP = 28;

/** One game tick of block-driven particles around (cx, cy, cz): lava embers, ceiling drips, portal motes and rain splashes. */
export function animateWorldTick(sim: FxSim, world: FxWorld, cx: number, cy: number, cz: number, o: AnimateOptions = {}): void {
  const r = sim.rand, samples = o.samples ?? 400, range = o.radius ?? 16, k = Math.max(1, 667 / samples);
  const bx = Math.floor(cx), by = Math.floor(cy), bz = Math.floor(cz);
  for (let i = 0; i < samples; i++) {
    const x = bx + Math.floor(r() * range) - Math.floor(r() * range);
    const y = by + Math.floor(r() * range) - Math.floor(r() * range);
    const z = bz + Math.floor(r() * range) - Math.floor(r() * range);
    const id = world.getBlock(x, y, z);
    if (id <= 0) continue;
    if (id === ID.lava) {
      if (world.getBlock(x, y + 1, z) === 0) {
        if (r() < k / 100) { if (sim.lavaPop(x, y, z)) o.sound?.('lava_pop', x + 0.5, y + 1, z + 0.5); }
        if (r() < k / 200) o.sound?.('lava_ambient', x + 0.5, y + 1, z + 0.5);
      }
      if (r() < k / 10) { const d = dripBlockBelow(world, x, y, z); if (d !== null) sim.drip(x, d, z, 'lava'); }
    } else if (id === ID.water) {
      if (r() < k / 10) { const d = dripBlockBelow(world, x, y, z); if (d !== null) sim.drip(x, d, z, 'water'); }
    } else if (id === ID.portal) {
      const alongZ = world.getBlock(x - 1, y, z) !== ID.portal && world.getBlock(x + 1, y, z) !== ID.portal;
      const n = Math.floor(k) + (r() < k - Math.floor(k) ? 1 : 0);
      for (let j = 0; j < n; j++) sim.portal(x, y, z, alongZ);
      if (r() < k / 100) o.sound?.('portal', x + 0.5, y + 0.5, z + 0.5);
    }
  }
  const rain = o.rain ?? 0;
  if (rain > 0) {
    const n = Math.floor((100 * rain * rain) / (o.decreased === false ? 1 : 2));
    const span = RAIN_SPLASH_RADIUS * 2 + 1;
    for (let i = 0; i < n; i++) {
      const x = bx + Math.floor(r() * span) - RAIN_SPLASH_RADIUS, z = bz + Math.floor(r() * span) - RAIN_SPLASH_RADIUS;
      const top = rainColumnTop(world, x, z, by + RAIN_SCAN_UP, by - 10);
      if (top === null || top > by + 10) continue;
      if (o.precipitation && o.precipitation(x, top + 1, z) !== 'rain') continue;
      const id = world.getBlock(x, top, z);
      sim.rainSplash(x, isFluidBlock(id) ? top + 0.89 : top + 1, z, id === ID.lava || id === ID.magma_block);
    }
  }
}

// ---- Sprite atlas + renderer -----------------------------------------------------------------------------------------

type Px = [number, number, number];
const WHITE: Record<string, Px> = { '#': [255, 255, 255], '+': [214, 214, 214], '-': [160, 160, 160] };
const SPRITES: { slot: number; rows: string[]; pal?: Record<string, Px> }[] = [
  { slot: S.crit, rows: ['....#...', '.#..#...', '..#.#.#.', '...###..', '#######.', '...###..', '..#.#.#.', '.#..#...'] },
  { slot: S.ench, rows: ['...#....', '...#....', '..#+#...', '##+++##.', '..#+#...', '...#....', '...#....', '........'] },
  { slot: S.spell[0], rows: ['.#####..', '#.....#.', '#.###..#', '#.#..#.#', '#.#.##.#', '#..#...#', '.#...##.', '..###...'] },
  { slot: S.spell[1], rows: ['........', '..####..', '.#....#.', '.#.##.#.', '.#.#..#.', '.#..##..', '..#.....', '........'] },
  { slot: S.spell[2], rows: ['........', '........', '...##...', '..#..#..', '..#.#...', '...#....', '........', '........'] },
  { slot: S.spell[3], rows: ['........', '........', '........', '...##...', '...##...', '........', '........', '........'] },
  { slot: S.glint, rows: ['...#....', '...#....', '..#+#...', '##+++##.', '..#+#...', '...#....', '...#....', '........'], pal: { '#': [44, 196, 52], '+': [176, 255, 160] } },
  { slot: S.lava, rows: ['..oooo..', '.o####o.', 'o##++##o', 'o#++++#o', 'o#++++#o', 'o##++##o', '.o####o.', '..oooo..'], pal: { o: [214, 72, 12], '#': [255, 142, 24], '+': [255, 226, 96] } },
  { slot: S.generic[0], rows: ['..####..', '.######.', '########', '########', '########', '########', '.######.', '..####..'] },
  { slot: S.generic[1], rows: ['........', '..####..', '.######.', '.######.', '.######.', '.######.', '..####..', '........'] },
  { slot: S.generic[2], rows: ['........', '........', '...##...', '..####..', '..####..', '...##...', '........', '........'] },
  { slot: S.dripHang, rows: ['...##...', '...##...', '..####..', '..####..', '.######.', '.#+####.', '.######.', '..####..'] },
  { slot: S.dripFall, rows: ['........', '...##...', '...##...', '..####..', '..#+##..', '..####..', '...##...', '........'] },
  { slot: S.dripLand, rows: ['........', '........', '........', '........', '........', '........', '.######.', '########'] },
  { slot: S.splash[0], rows: ['........', '........', '...#....', '........', '.#...#..', '...#....', '..#.#...', '........'] },
  { slot: S.splash[1], rows: ['........', '........', '........', '........', '..#.....', '....#...', '.#.#..#.', '..#.#...'] },
];

export const FX_ATLAS = { cols: 8, rows: 4, cell: 8 };

/** RGBA pixels of the sprite sheet (top row first). */
export function buildFxAtlasPixels(): Uint8Array {
  const { cols, rows, cell } = FX_ATLAS, w = cols * cell, data = new Uint8Array(w * rows * cell * 4);
  for (const sp of SPRITES) {
    const ox = (sp.slot % cols) * cell, oy = Math.floor(sp.slot / cols) * cell, pal = sp.pal ?? WHITE;
    for (let y = 0; y < cell; y++) for (let x = 0; x < cell; x++) {
      const c = pal[sp.rows[y][x]];
      if (!c) continue;
      const i = ((oy + y) * w + ox + x) * 4;
      data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2]; data[i + 3] = 255;
    }
  }
  return data;
}

class FxLayer {
  points: THREE.Points;
  geometry = new THREE.BufferGeometry();
  material: THREE.ShaderMaterial;
  texture: THREE.DataTexture;
  private pos = new Float32Array(FX_MAX * 3);
  private col = new Float32Array(FX_MAX * 4);
  private misc = new Float32Array(FX_MAX * 3);

  constructor() {
    const { cols, rows, cell } = FX_ATLAS;
    this.texture = new THREE.DataTexture(buildFxAtlasPixels(), cols * cell, rows * cell, THREE.RGBAFormat);
    this.texture.magFilter = THREE.NearestFilter;
    this.texture.minFilter = THREE.NearestFilter;
    this.texture.needsUpdate = true;
    this.geometry.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.geometry.setAttribute('aColor', new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage));
    this.geometry.setAttribute('aMisc', new THREE.BufferAttribute(this.misc, 3).setUsage(THREE.DynamicDrawUsage));
    this.geometry.setDrawRange(0, 0);
    this.material = new THREE.ShaderMaterial({
      uniforms: { uMap: { value: this.texture }, uScale: { value: 600 }, uAmbient: { value: 1 }, uMaxSize: { value: 256 } },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute vec4 aColor; attribute vec3 aMisc; uniform float uScale; uniform float uAmbient; uniform float uMaxSize; varying vec4 vColor; varying float vFrame;
      void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * mv; gl_PointSize = clamp(aMisc.x * 2.0 * uScale / max(0.05, -mv.z), 1.0, uMaxSize); vColor = vec4(aColor.rgb * mix(uAmbient, 1.0, aMisc.z), aColor.a); vFrame = aMisc.y; }`,
      fragmentShader: `uniform sampler2D uMap; varying vec4 vColor; varying float vFrame;
      void main(){ float f = floor(vFrame + 0.5); vec2 cell = vec2(mod(f, ${cols}.0), floor(f / ${cols}.0)); vec4 t = texture2D(uMap, (cell + gl_PointCoord) / vec2(${cols}.0, ${rows}.0)); if (t.a < 0.5) discard; gl_FragColor = vec4(t.rgb * vColor.rgb, vColor.a); }`,
    });
    this.points = new THREE.Points(this.geometry, this.material);
    this.points.frustumCulled = false;
    this.points.renderOrder = 3;
  }

  sync(sim: FxSim) {
    const list = sim.list, n = Math.min(list.length, FX_MAX), a = sim.alpha, pos = this.pos, col = this.col, misc = this.misc;
    for (let i = 0; i < n; i++) {
      const p = list[i], i3 = i * 3, i4 = i * 4;
      pos[i3] = p.px + (p.x - p.px) * a; pos[i3 + 1] = p.py + (p.y - p.py) * a; pos[i3 + 2] = p.pz + (p.z - p.pz) * a;
      col[i4] = p.r; col[i4 + 1] = p.g; col[i4 + 2] = p.b; col[i4 + 3] = p.a;
      misc[i3] = fxRenderSize(p, a); misc[i3 + 1] = fxFrame(p); misc[i3 + 2] = FX_SPECS[p.kind].emissive ? 1 : 0;
    }
    this.geometry.setDrawRange(0, n);
    if (n > 0) {
      this.geometry.attributes.position.needsUpdate = true;
      this.geometry.attributes.aColor.needsUpdate = true;
      this.geometry.attributes.aMisc.needsUpdate = true;
    }
  }

  dispose() { this.geometry.dispose(); this.material.dispose(); this.texture.dispose(); }
}


export class ParticleSystem {
  particles: Particle[] = [];
  drops: Drop[] = [];
  geometry = new THREE.BoxGeometry(1, 1, 1);
  materials = new Map<string, THREE.MeshLambertMaterial>();
  dropMaterials = new Map<string, THREE.MeshLambertMaterial>();
  private pool: THREE.Mesh[] = [];
  readonly maxParticles = 512;
  readonly spriteGeometry = new THREE.PlaneGeometry(1, 1);
  readonly spriteMaterials = new Map<string, THREE.MeshBasicMaterial>();
  readonly spriteTextures = new Map<string, THREE.DataTexture>();
  private blockTime = 0;
  private entityTime = 0;
  private visualTime = 0;
  private effectOrigin = new THREE.Vector3();
  /** Java-style billboard particles (crit, enchanted_hit, entity_effect, portal, lava, drips, rain, happy_villager …). */
  fx: FxSim;
  private fxLayer = new FxLayer();
  private fxFloor: ((x: number, y: number, z: number) => number) | null = null;

  constructor(public scene: THREE.Scene) {
    this.fx = new FxSim(Math.random, (x, y, z) => {
      const b = this.fxFloor ? this.fxFloor(x, y, z) : 0;
      return b > 0 && !!BLOCKS[b]?.solid;
    });
  }

  /** Per-frame camera data for the billboard layer: sprite scale (px per block at distance 1), light level and the 32-block cull origin. */
  setView(camera: THREE.PerspectiveCamera, viewportHeightPx: number, ambient = 1) {
    const u = this.fxLayer.material.uniforms;
    u.uScale.value = viewportHeightPx / (2 * Math.tan((camera.fov * Math.PI) / 360));
    u.uMaxSize.value = Math.max(64, viewportHeightPx * 0.35);
    u.uAmbient.value = Math.max(0.25, Math.min(1, ambient));
    (this.fx.viewer ??= { x: 0, y: 0, z: 0 });
    this.fx.viewer.x = camera.position.x; this.fx.viewer.y = camera.position.y; this.fx.viewer.z = camera.position.z;
  }

  material(color: string) {
    let m = this.materials.get(color);
    if (!m) {
      m = new THREE.MeshLambertMaterial({ color });
      this.materials.set(color, m);
    }
    return m;
  }

  dropMaterial(name: string, fallbackColor: string, stack?: Stack) {
    if (stack && (stack.patterns?.length || stack.bannerBase) && (name === 'shield' || name.endsWith('_banner'))) {
      const base = stack.bannerBase ?? bannerColorOf(name);
      const key = `bannerdrop:${name}:${base}:${(stack.patterns ?? []).map(l => l.p + ':' + l.c).join(',')}`;
      let m = this.dropMaterials.get(key);
      if (!m) {
        const cv = bannerShieldCanvas(base, stack.patterns as BannerLayer[] | undefined, name === 'shield');
        const tex = new THREE.CanvasTexture(cv);
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        tex.colorSpace = THREE.SRGBColorSpace;
        m = new THREE.MeshLambertMaterial({ map: tex });
        this.dropMaterials.set(key, m);
      }
      return m;
    }
    let m = this.dropMaterials.get(name);
    if (!m) {
      try {
        const tex = getTileTexture(name);
        m = new THREE.MeshLambertMaterial({ map: tex, transparent: true, alphaTest: 0.35 });
      } catch {
        m = this.material(fallbackColor);
      }
      this.dropMaterials.set(name, m);
    }
    return m;
  }

  private acquire(mat: THREE.Material) {
    const m = this.pool.pop();
    if (m) {
      m.material = mat;
      m.geometry = this.geometry;
      m.visible = true;
      return m;
    }
    return new THREE.Mesh(this.geometry, mat);
  }

  private release(m: THREE.Mesh) {
    m.visible = false;
    if (this.pool.length < 220) this.pool.push(m);
    else this.scene.remove(m);
  }

  burst(p: THREE.Vector3, color: string, count = 10, power = 3, gravity = 12) {
    const mat = this.material(color);
    for (let i = 0; i < count && this.particles.length < 180; i++) {
      const mesh = this.acquire(mat);
      mesh.position.set(p.x + (Math.random() - 0.5) * 0.65, p.y + (Math.random() - 0.5) * 0.65, p.z + (Math.random() - 0.5) * 0.65);
      const s = 0.06 + Math.random() * 0.08;
      mesh.scale.setScalar(s);
      mesh.rotation.set(Math.random() * 3, Math.random() * 3, 0);
      if (!mesh.parent) this.scene.add(mesh);
      const life = 0.32 + Math.random() * 0.45;
      this.particles.push({
        mesh,
        vx: (Math.random() - 0.5) * power,
        vy: Math.random() * power * 0.9,
        vz: (Math.random() - 0.5) * power,
        gravity,
        life,
        max: life,
        rotSpeed: 2 + Math.random() * 4,
      });
    }
  }

  spark(p: THREE.Vector3, color: string, count = 8) {
    this.burst(p, color, count, 2.2, -1.8);
  }

  private spriteTexture(kind: VanillaParticleKind, frame: number) {
    const key = `${kind}:${frame}`;
    let texture = this.spriteTextures.get(key);
    if (texture) return texture;
    const maskName = kind === 'drip_water' || kind === 'drip_lava' ? ['drip_hang', 'drip_fall', 'drip_land'][Math.min(2, frame)] : kind;
    const mask = MASKS[maskName];
    const pixels = new Uint8Array(8 * 8 * 4);
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      let visible = mask ? mask[y][x] === '#' : false;
      const dx = x - 3.5, dy = y - 3.5;
      if (kind === 'portal') visible = Math.abs(dx) + Math.abs(dy) <= 1 + frame * 0.42;
      if (kind === 'mobSpell') {
        const angle = Math.atan2(dy, dx) + Math.PI;
        const radius = 0.45 + angle * 0.4;
        visible = Math.abs(Math.hypot(dx, dy) - radius) < 0.7 && y > frame * 0.22;
      }
      if (kind === 'rain_splash') visible = (frame === 0 ? (y === 4 && (x === 2 || x === 4)) || (y === 5 && x === 3) : frame === 1 ? y === 3 && (x === 1 || x === 5) : frame === 2 ? y === 4 && (x === 1 || x === 6) : y === 5 && (x === 2 || x === 5));
      const index = (y * 8 + x) * 4;
      const shade = kind === 'crit' || kind === 'enchanted_hit' ? (x + y) % 3 === 0 ? 185 : 255 : 255;
      pixels[index] = shade; pixels[index + 1] = shade; pixels[index + 2] = shade;
      pixels[index + 3] = visible ? 255 : 0;
      if (kind === 'lava_pop' && visible) {
        pixels[index + 1] = y < 3 ? 155 : 220; pixels[index + 2] = x < 4 ? 110 : 30;
      }
    }
    texture = new THREE.DataTexture(pixels, 8, 8, THREE.RGBAFormat);
    texture.magFilter = THREE.NearestFilter; texture.minFilter = THREE.NearestFilter;
    texture.colorSpace = THREE.SRGBColorSpace; texture.generateMipmaps = false;
    texture.needsUpdate = true;
    this.spriteTextures.set(key, texture);
    return texture;
  }

  private spriteMaterial(kind: VanillaParticleKind, color: string, frame = 0) {
    const tint = new THREE.Color(color);
    const quantized = [tint.r, tint.g, tint.b].map(v => Math.round(v * 7) / 7);
    const key = `${kind}:${quantized.join(',')}:${frame}`;
    let material = this.spriteMaterials.get(key);
    if (!material) {
      if (this.spriteMaterials.size >= 512) {
        const fallback = [...this.spriteMaterials.entries()].find(([k]) => k.startsWith(`${kind}:`) && k.endsWith(`:${frame}`));
        if (fallback) return fallback[1];
      }
      material = new THREE.MeshBasicMaterial({
        map: this.spriteTexture(kind, frame), color: tint.setRGB(quantized[0], quantized[1], quantized[2]),
        transparent: true, alphaTest: 0.05, depthWrite: false, side: THREE.DoubleSide, toneMapped: false,
      });
      this.spriteMaterials.set(key, material);
    }
    return material;
  }

  emit(kind: VanillaParticleKind, origin: THREE.Vector3, options: ParticleOptions = {}) {
    const count = Math.max(0, Math.min(64, Math.floor(options.count ?? 1)));
    for (let i = 0; i < count && this.particles.length < this.maxParticles; i++) {
      const color = options.color ?? COLORS[kind];
      const mesh = this.acquire(this.spriteMaterial(kind, color));
      mesh.geometry = this.spriteGeometry;
      mesh.rotation.set(0, 0, 0);
      mesh.position.copy(origin);
      const life = Math.max(0.05, options.life ?? (kind === 'portal' ? 1.4 + Math.random() * 0.5 : kind === 'mobSpell' ? 1.2 + Math.random() * 0.6 : kind.startsWith('drip_') ? 4 : kind === 'rain_splash' ? 0.22 + Math.random() * 0.12 : 0.35 + Math.random() * 0.4));
      const p: Particle = {
        mesh, kind, color, life, max: life, age: 0, frame: 0,
        vx: (Math.random() - 0.5) * 2.4, vy: 0.3 + Math.random() * 1.5, vz: (Math.random() - 0.5) * 2.4,
        gravity: 2.2, rotSpeed: 0, size: 0.16 + Math.random() * 0.08,
      };
      if (kind === 'crit' || kind === 'enchanted_hit' || kind === 'happy_villager') {
        mesh.position.x += (Math.random() - 0.5) * 0.7;
        mesh.position.y += (Math.random() - 0.5) * 0.7;
        mesh.position.z += (Math.random() - 0.5) * 0.7;
        p.gravity = kind === 'happy_villager' ? -0.15 : 1.2;
        if (kind === 'happy_villager') { p.vx *= 0.25; p.vz *= 0.25; p.vy = 0.15; }
      } else if (kind === 'mobSpell') {
        p.anchor = origin; p.phase = (options.phase ?? 0) + i * Math.PI * 2 / Math.max(1, count);
        p.radius = options.radius ?? 0.45; p.height = options.height ?? 1.8;
        p.size = 0.19; p.gravity = 0;
        mesh.position.set(origin.x + Math.cos(p.phase) * p.radius, origin.y + 0.1, origin.z + Math.sin(p.phase) * p.radius);
      } else if (kind === 'portal') {
        const angle = Math.random() * Math.PI * 2, radius = options.radius ?? 1.25;
        p.target = (options.target ?? origin).clone();
        mesh.position.add(new THREE.Vector3(Math.cos(angle) * radius, (Math.random() - 0.3) * 1.8, Math.sin(angle) * radius));
        p.start = mesh.position.clone(); p.size = 0.1 + Math.random() * 0.1; p.gravity = 0;
      } else if (kind === 'lava_pop') {
        p.vx *= 0.25; p.vz *= 0.25; p.vy = 2 + Math.random() * 2; p.gravity = 9; p.size = 0.24;
      } else if (kind.startsWith('drip_')) {
        p.vx = p.vy = p.vz = 0; p.hang = 0.4 + Math.random() * 0.35; p.gravity = 5; p.size = 0.21;
      } else if (kind === 'rain_splash') {
        p.vx *= 0.35; p.vz *= 0.35; p.vy = 0.5 + Math.random() * 0.5; p.gravity = 8; p.size = 0.2;
      }
      mesh.scale.setScalar(p.size!);
      if (!mesh.parent) this.scene.add(mesh);
      this.particles.push(p);
    }
  }

  crit(pOrBox: THREE.Vector3 | FxBox | (() => FxBox), count = 16) {
    if (pOrBox instanceof THREE.Vector3) {
      this.emit('crit', pOrBox, { count });
    } else {
      this.fx.crit(pOrBox);
      if (typeof pOrBox === 'function') {
        const b = pOrBox();
        this.emit('crit', new THREE.Vector3(b.x, b.y + b.h * 0.5, b.z), { count });
      }
    }
  }

  enchantedHit(pOrBox: THREE.Vector3 | FxBox | (() => FxBox), count = 14) {
    if (pOrBox instanceof THREE.Vector3) {
      this.emit('enchanted_hit', pOrBox, { count });
    } else {
      this.fx.enchantedHit(pOrBox);
      if (typeof pOrBox === 'function') {
        const b = pOrBox();
        this.emit('enchanted_hit', new THREE.Vector3(b.x, b.y + b.h * 0.5, b.z), { count });
      }
    }
  }

  mobSpell(pOrBox: THREE.Vector3 | FxBox, colorOrColors: string | RGB | RGB[], countOrOpts: number | { ambient?: boolean; invisible?: boolean; time?: number; force?: boolean } = 2, phase = 0, height = 1.8) {
    if (pOrBox instanceof THREE.Vector3) {
      this.emit('mobSpell', pOrBox, { color: colorOrColors as string, count: typeof countOrOpts === 'number' ? countOrOpts : 2, phase, height });
      return null;
    }
    return this.fx.mobSpell(pOrBox, colorOrColors as RGB | RGB[], typeof countOrOpts === 'object' ? countOrOpts : undefined);
  }

  portal(bxOrVec: number | THREE.Vector3, byOrCount = 2, bzOrTarget?: number | THREE.Vector3, planeAlongZ = false) {
    if (bxOrVec instanceof THREE.Vector3) {
      this.emit('portal', bxOrVec, { count: byOrCount, target: bzOrTarget instanceof THREE.Vector3 ? bzOrTarget : bxOrVec });
    } else {
      this.fx.portal(bxOrVec, byOrCount, bzOrTarget as number, planeAlongZ);
    }
  }

  endermanPortal(box: FxBox, count = 2) { this.fx.enderman(box, count); }

  lavaPop(bxOrVec: number | THREE.Vector3, byOrCount = 1, bz?: number) {
    if (bxOrVec instanceof THREE.Vector3) {
      this.emit('lava_pop', bxOrVec, { count: byOrCount });
      return null;
    }
    return this.fx.lavaPop(bxOrVec, byOrCount, bz!);
  }

  dripWater(bxOrVec: number | THREE.Vector3, by?: number, bz?: number) {
    if (bxOrVec instanceof THREE.Vector3) {
      this.emit('drip_water', bxOrVec);
      return null;
    }
    return this.fx.drip(bxOrVec, by!, bz!, 'water');
  }

  dripLava(bxOrVec: number | THREE.Vector3, by?: number, bz?: number) {
    if (bxOrVec instanceof THREE.Vector3) {
      this.emit('drip_lava', bxOrVec);
      return null;
    }
    return this.fx.drip(bxOrVec, by!, bz!, 'lava');
  }

  rainSplash(bxOrVec: number | THREE.Vector3, topOrCount = 2, bz?: number) {
    if (bxOrVec instanceof THREE.Vector3) {
      this.emit('rain_splash', bxOrVec, { count: topOrCount });
      return null;
    }
    return this.fx.rainSplash(bxOrVec, topOrCount, bz!);
  }

  happyVillager(bxOrVec: number | THREE.Vector3, byOrCount = 12, bz?: number, count = 15, xzSpread = 0.5, ySpread = 1) {
    if (bxOrVec instanceof THREE.Vector3) {
      this.emit('happy_villager', bxOrVec, { count: byOrCount });
    } else {
      this.fx.happyVillager(bxOrVec, byOrCount, bz!, count, xzSpread, ySpread);
    }
  }

  happyVillagerAround(box: FxBox, count = 5) { this.fx.happyVillagerAround(box, count); }

  entityEffects(dt: number, player: THREE.Vector3, effects: Record<string, { t: number; amp: number }>, mobs: readonly { group: THREE.Object3D; species: string; fx?: Record<string, number> }[]) {
    this.visualTime += dt;
    this.entityTime += dt;
    if (this.entityTime < 0.14) return;
    this.entityTime %= 0.14;
    const color = potionColor(effects);
    if (color) this.mobSpell(player, color, 2, this.visualTime * 3.5);
    for (const mob of mobs) {
      if (mob.group.position.distanceToSquared(player) > 32 * 32) continue;
      if (mob.species === 'enderman') this.portal(this.effectOrigin.copy(mob.group.position).add(new THREE.Vector3(0, 1.3, 0)), 2);
      const tint = mob.fx && potionColor(mob.fx);
      if (tint) this.mobSpell(mob.group.position, tint, 2, this.visualTime * 3.5, mob.species === 'enderman' ? 2.8 : 1.6);
    }
  }

  ambientBlocks(dt: number, origin: THREE.Vector3, getBlock: BlockReader, getCell?: BlockReader) {
    this.blockTime += dt;
    if (this.blockTime < 0.1) return;
    this.blockTime %= 0.1;
    if (this.particles.length > 320) return;
    for (let i = 0; i < 100; i++) {
      const x = Math.floor(origin.x + (Math.random() - 0.5) * 16);
      const y = Math.floor(origin.y + (Math.random() - 0.4) * 16);
      const z = Math.floor(origin.z + (Math.random() - 0.5) * 16);
      const id = getBlock(x, y, z);
      if (id < 0) continue;
      if (id === ID.lava && getBlock(x, y + 1, z) === 0 && (!getCell || (getCell(x, y, z) >>> 12) === 0)) {
        this.lavaPop(this.effectOrigin.set(x + Math.random(), y + 0.93, z + Math.random()));
      } else if (id === ID.portal) {
        this.portal(this.effectOrigin.set(x + 0.5, y + 0.5, z + 0.5), 1);
      } else if (id === 0 && BLOCKS[getBlock(x, y + 1, z)]?.solid) {
        const fluid = getBlock(x, y + 2, z);
        this.effectOrigin.set(x + 0.2 + Math.random() * 0.6, y + 0.98, z + 0.2 + Math.random() * 0.6);
        if (fluid === ID.water) this.dripWater(this.effectOrigin);
        if (fluid === ID.lava) this.dripLava(this.effectOrigin);
      }
    }
  }

  private updateSprite(p: Particle, dt: number, floor: BlockReader, camera?: THREE.Camera) {
    p.age! += dt;
    const t = Math.min(1, p.age! / p.max), kind = p.kind!;
    let frame = 0;
    if (kind === 'portal') {
      p.mesh.position.lerpVectors(p.start!, p.target!, t * t);
      frame = Math.min(7, Math.floor(t * 8));
    } else if (kind === 'mobSpell') {
      const a = p.phase! + p.age! * 3.8, radius = p.radius! * (1 - t * 0.25);
      p.mesh.position.set(p.anchor!.x + Math.cos(a) * radius, p.anchor!.y + 0.1 + t * p.height!, p.anchor!.z + Math.sin(a) * radius);
      frame = Math.min(7, Math.floor(t * 8));
    } else if (kind.startsWith('drip_')) {
      if (p.landed) { frame = 2; }
      else if (p.age! <= p.hang!) { frame = 0; }
      else {
        frame = 1;
        const steps = Math.max(1, Math.ceil(dt / 0.025)), step = dt / steps;
        for (let j = 0; j < steps; j++) {
          p.vy -= p.gravity * step;
          p.mesh.position.y += p.vy * step;
          const hit = floor(p.mesh.position.x, p.mesh.position.y, p.mesh.position.z);
          if (hit !== 0 && (hit < 0 || BLOCKS[hit]?.solid || hit === ID.water || hit === ID.lava)) {
            if (hit < 0) { p.life = 0; break; }
            p.mesh.position.y = Math.floor(p.mesh.position.y) + 1.02;
            p.landed = true; p.vy = 0; p.life = Math.min(p.life, kind === 'drip_lava' ? 0.3 : 0.12); frame = 2;
            break;
          }
        }
      }
    } else {
      const damping = Math.exp(-(kind === 'crit' || kind === 'enchanted_hit' ? 4 : 1.5) * dt);
      p.vx *= damping; p.vz *= damping;
      p.vy -= p.gravity * dt;
      p.mesh.position.x += p.vx * dt; p.mesh.position.y += p.vy * dt; p.mesh.position.z += p.vz * dt;
      if (kind === 'rain_splash') frame = Math.min(3, Math.floor(t * 4));
    }
    if (p.frame !== frame) { p.frame = frame; p.mesh.material = this.spriteMaterial(kind, p.color!, frame); }
    const scale = kind === 'portal' ? Math.sin(Math.PI * t) * 0.8 + 0.2 : kind === 'mobSpell' ? Math.min(1, p.age! * 10) * Math.min(1, (1 - t) * 5) : Math.min(1, (1 - t) * 4);
    p.mesh.scale.setScalar(p.size! * Math.max(0.02, scale));
    if (camera) p.mesh.quaternion.copy(camera.quaternion);
  }

  bubbleColumn(x: number, y: number, z: number, mode: 'up' | 'down', elapsed = 0) {
    const mat = this.material(mode === 'up' ? '#b8f4ff' : '#7ad6f0');
    const count = 2;
    for (let i = 0; i < count && this.particles.length < 180; i++) {
      const mesh = this.acquire(mat);
      const a = elapsed * 6.5 + i * Math.PI + Math.random() * 0.6;
      const r = mode === 'down' ? 0.28 : 0.18 + Math.random() * 0.18;
      mesh.position.set(x + 0.5 + Math.cos(a) * r, y + (mode === 'up' ? 0.15 : 0.85), z + 0.5 + Math.sin(a) * r);
      mesh.scale.setScalar(0.055 + Math.random() * 0.035);
      mesh.rotation.set(0, a, 0);
      if (!mesh.parent) this.scene.add(mesh);
      const life = 0.45 + Math.random() * 0.25;
      this.particles.push({
        mesh,
        vx: mode === 'down' ? -Math.sin(a) * 1.4 : (Math.random() - 0.5) * 0.35,
        vy: mode === 'up' ? 4.2 + Math.random() * 1.4 : -3.4 - Math.random() * 1.1,
        vz: mode === 'down' ? Math.cos(a) * 1.4 : (Math.random() - 0.5) * 0.35,
        gravity: mode === 'up' ? -2.5 : 2.5,
        life,
        max: life,
        rotSpeed: mode === 'down' ? 7 : 3,
      });
    }
  }

  crumbs(origin: THREE.Vector3, dir: THREE.Vector3, color: string, count = 5) {
    const mat = this.material(color);
    for (let i = 0; i < count && this.particles.length < 180; i++) {
      const mesh = this.acquire(mat);
      mesh.position.set(
        origin.x + dir.x * 0.45 + (Math.random() - 0.5) * 0.22,
        origin.y - 0.18 + dir.y * 0.35 + (Math.random() - 0.5) * 0.14,
        origin.z + dir.z * 0.45 + (Math.random() - 0.5) * 0.22,
      );
      mesh.scale.setScalar(0.045 + Math.random() * 0.035);
      mesh.rotation.set(Math.random() * 3, Math.random() * 3, 0);
      if (!mesh.parent) this.scene.add(mesh);
      const life = 0.28 + Math.random() * 0.22;
      this.particles.push({
        mesh,
        vx: dir.x * 0.8 + (Math.random() - 0.5) * 1.4,
        vy: 0.6 + Math.random() * 0.9,
        vz: dir.z * 0.8 + (Math.random() - 0.5) * 1.4,
        gravity: 9.5,
        life,
        max: life,
        rotSpeed: 4 + Math.random() * 4,
      });
    }
  }

  brushDust(x: number, y: number, z: number, color: string, count = 12) {
    this.burst(new THREE.Vector3(x + 0.5, y + 0.55, z + 0.5), color, count, 1.9, 6.5);
  }

  drop(p: THREE.Vector3, name: string, count: number, color: string, stack?: Stack) {
    const hasBannerMeta = !!(stack && (stack.patterns?.length || stack.bannerBase));
    if (!hasBannerMeta) {
      for (let i = 0; i < this.drops.length; i++) {
        const ex = this.drops[i];
        if (ex.name === name && ex.count + count <= 64 && ex.mesh.position.distanceToSquared(p) < 0.75) {
          ex.count += count;
          return;
        }
      }
    }
    if (this.drops.length > 80) {
      this.release(this.drops[0].mesh);
      this.drops.shift();
    }
    const isBannerLike = hasBannerMeta && (name === 'shield' || name.endsWith('_banner'));
    const isBlock = !isBannerLike && ID[name] !== undefined && BLOCKS[ID[name]]?.shape === 'cube';
    const mesh = this.acquire(this.dropMaterial(name, color, stack));
    mesh.position.copy(p);
    mesh.rotation.set(0, 0, 0);
    if (isBannerLike) mesh.scale.set(0.24, 0.42, 0.06);
    else if (isBlock) mesh.scale.set(0.24, 0.24, 0.24);
    else mesh.scale.set(0.26, 0.26, 0.05);
    if (!mesh.parent) this.scene.add(mesh);
    this.drops.push({
      mesh,
      name,
      count,
      vx: (Math.random() - 0.5) * 2.2,
      vy: 3.1,
      vz: (Math.random() - 0.5) * 2.2,
      age: 0,
      baseY: p.y,
    });
  }

  takeNear(p: THREE.Vector3, r: number, accept: (name: string) => boolean): { name: string; count: number } | null {
    let bi = -1, bd = r * r;
    for (let i = 0; i < this.drops.length; i++) {
      const d = this.drops[i];
      if (d.age < 0.7) continue;
      const dd = d.mesh.position.distanceToSquared(p);
      if (dd < bd && accept(d.name)) { bd = dd; bi = i; }
    }
    if (bi < 0) return null;
    const d = this.drops[bi], name = d.name;
    if (d.count > 1) d.count--;
    else { this.release(d.mesh); const last = this.drops.length - 1; if (bi !== last) this.drops[bi] = this.drops[last]; this.drops.pop(); }
    return { name, count: 1 };
  }

  update(
    dt: number,
    floor: (x: number, y: number, z: number) => number,
    pickup: (name: string, count: number, position: THREE.Vector3) => boolean,
    playerPos?: THREE.Vector3,
    camera?: THREE.Camera,
  ) {
    if (!Number.isFinite(dt) || dt <= 0) return;
    this.fxFloor = floor;
    this.fx.step(dt);
    if (this.fx.list.length > 0 || this.fxLayer.points.parent) {
      if (!this.fxLayer.points.parent) this.scene.add(this.fxLayer.points);
      this.fxLayer.sync(this.fx);
    }
    dt = Math.min(dt, 0.25);
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.release(p.mesh);
        const last = this.particles.length - 1;
        if (i !== last) this.particles[i] = this.particles[last];
        this.particles.pop();
        continue;
      }
      if (p.kind) { this.updateSprite(p, dt, floor, camera); continue; }
      p.vy -= p.gravity * dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      p.mesh.rotation.x += dt * p.rotSpeed;
      p.mesh.rotation.y += dt * p.rotSpeed * 0.6;
      const scaleDecay = Math.max(0.1, 1 - dt * 0.85);
      p.mesh.scale.multiplyScalar(scaleDecay);
    }

    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.age += dt;
      d.vy -= 12 * dt;

      if (playerPos && d.age > 0.6) {
        const dx = playerPos.x - d.mesh.position.x;
        const dy = playerPos.y + 0.6 - d.mesh.position.y;
        const dz = playerPos.z - d.mesh.position.z;
        const dist = Math.hypot(dx, dy, dz);
        if (dist < 2.6 && dist > 0.05) {
          const pull = (1 - dist / 2.6) * 9 * dt;
          d.mesh.position.x += (dx / dist) * pull;
          d.mesh.position.y += (dy / dist) * pull;
          d.mesh.position.z += (dz / dist) * pull;
        }
      }

      const nx = d.mesh.position.x + d.vx * dt;
      const ny = d.mesh.position.y + d.vy * dt;
      const nz = d.mesh.position.z + d.vz * dt;
      const below = floor(nx, ny - 0.14, nz);
      if (below > 0 && below !== ID.water) {
        d.vy = 0;
        d.vx *= 0.78;
        d.vz *= 0.78;
        d.baseY = Math.floor(ny - 0.14) + 1.15;
        d.mesh.position.set(nx, d.baseY + Math.sin(d.age * 3.2) * 0.055, nz);
      } else {
        d.mesh.position.set(nx, ny, nz);
      }
      d.mesh.rotation.y += dt * 1.9;

      if ((d.age > 0.7 && pickup(d.name, d.count, d.mesh.position)) || d.age > 300) {
        this.release(d.mesh);
        const last = this.drops.length - 1;
        if (i !== last) this.drops[i] = this.drops[last];
        this.drops.pop();
      }
    }
  }

  clear() {
    for (const p of this.particles) this.release(p.mesh);
    for (const d of this.drops) this.release(d.mesh);
    this.particles = [];
    this.drops = [];
    this.blockTime = this.entityTime = this.visualTime = 0;
    this.fx.clear();
    this.fxLayer.sync(this.fx);
  }

  dispose() {
    this.clear();
    this.fxLayer.points.removeFromParent();
    this.fxLayer.dispose();
    for (const m of this.pool) this.scene.remove(m);
    this.pool = [];
    this.geometry.dispose();
    this.spriteGeometry.dispose();
    this.spriteMaterials.forEach(m => m.dispose());
    this.spriteTextures.forEach(t => t.dispose());
    this.spriteMaterials.clear();
    this.spriteTextures.clear();
    this.materials.forEach(m => m.dispose());
    this.dropMaterials.forEach(m => m.dispose());
  }
}
