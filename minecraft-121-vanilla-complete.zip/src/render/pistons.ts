import * as THREE from 'three';
import { BLOCKS, ID } from '../game/data';
import { blockFaceCanvases } from '../textures/atlas';

export interface PistonMove {
  x: number;
  y: number;
  z: number;
  dx: number;
  dy: number;
  dz: number;
  cell: number;
}

export class PistonAnimator {
  private active: { group: THREE.Group; moves: PistonMove[]; elapsed: number; duration: number }[] = [];
  private box = new THREE.BoxGeometry(1.008, 1.008, 1.008);
  private materials = new Map<number, THREE.Material | THREE.Material[]>();

  constructor(private scene: THREE.Scene) {}

  private materialFor(id: number): THREE.Material | THREE.Material[] {
    let mat = this.materials.get(id);
    if (mat) return mat;
    const def = BLOCKS[id];
    const name = def?.name;
    if (name && typeof document !== 'undefined') {
      const faces = blockFaceCanvases(name);
      if (faces && faces.length >= 6) {
        mat = faces.slice(0, 6).map(c => {
          const t = new THREE.CanvasTexture(c as HTMLCanvasElement);
          t.magFilter = THREE.NearestFilter;
          t.minFilter = THREE.NearestFilter;
          t.colorSpace = THREE.SRGBColorSpace;
          return new THREE.MeshLambertMaterial({ map: t, transparent: !!def?.transparent });
        });
        this.materials.set(id, mat);
        return mat;
      }
    }
    mat = new THREE.MeshLambertMaterial({ color: def?.color ?? '#a79d88', transparent: !!def?.transparent });
    this.materials.set(id, mat);
    return mat;
  }

  start(moves: PistonMove[], duration = 0.1) {
    if (!moves.length || this.active.length > 32) return;
    const group = new THREE.Group();
    for (const move of moves) {
      const id = move.cell & 4095;
      if (id <= 0) continue;
      const mesh = new THREE.Mesh(this.box, this.materialFor(id));
      mesh.position.set(move.x + 0.5, move.y + 0.5, move.z + 0.5);
      if (id === ID.piston_head) {
        const axis = move.dx ? 'x' : move.dy ? 'y' : 'z';
        mesh.scale[axis] = 0.25;
      }
      group.add(mesh);
    }
    this.scene.add(group);
    this.active.push({ group, moves, elapsed: 0, duration });
  }

  update(dt: number) {
    for (const animation of this.active) {
      animation.elapsed += dt;
      const t = Math.min(1, animation.elapsed / animation.duration);
      animation.group.children.forEach((mesh, i) => {
        const m = animation.moves[i];
        if (m) mesh.position.set(m.x + 0.5 + m.dx * t, m.y + 0.5 + m.dy * t, m.z + 0.5 + m.dz * t);
      });
      if (t >= 1) this.scene.remove(animation.group);
    }
    this.active = this.active.filter(a => a.elapsed < a.duration);
  }

  clear() {
    this.active.forEach(a => this.scene.remove(a.group));
    this.active = [];
  }

  dispose() {
    this.clear();
    this.box.dispose();
    this.materials.forEach(m => {
      if (Array.isArray(m)) m.forEach(x => x.dispose());
      else m.dispose();
    });
  }
}
