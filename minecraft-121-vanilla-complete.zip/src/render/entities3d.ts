import * as THREE from 'three';
import { BLOCKS, ID, resolve } from '../game/data';
import { blockState } from '../game/blockState';
import type { Stack } from '../game/types';
import { TRIM_MAT_BY_ID } from '../systems/trims';
import { canvas as makeCanvas } from '../textures/canvas';

// =====================================================================================================================
// Shared Geometry & Material Cache for High-Detail 3D Entities
// =====================================================================================================================

const sharedBox = new THREE.BoxGeometry(1, 1, 1);
const matCache = new Map<string, THREE.MeshLambertMaterial | THREE.MeshBasicMaterial>();

function getEntityMat(color: string, basic = false): THREE.MeshLambertMaterial {
  const key = color + (basic ? ':b' : '');
  let m = matCache.get(key);
  if (!m) {
    m = basic ? new THREE.MeshBasicMaterial({ color }) : new THREE.MeshLambertMaterial({ color });
    matCache.set(key, m);
  }
  return m as THREE.MeshLambertMaterial;
}

export function addBoxPart(
  parent: THREE.Object3D,
  color: string,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  basic = false,
): THREE.Mesh {
  const m = new THREE.Mesh(sharedBox, getEntityMat(color, basic));
  m.userData.baseMat = m.material;
  m.position.set(x, y, z);
  m.scale.set(w, h, d);
  m.castShadow = !basic;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

// =====================================================================================================================
// 1. Horse Armor Tiers & 3D Equine Barding Builder (Leather / Copper / Iron / Golden / Diamond / Netherite)
// =====================================================================================================================

export type HorseArmorTier = 'leather' | 'copper' | 'iron' | 'golden' | 'diamond' | 'netherite';

export interface HorseArmorPalette {
  tier: HorseArmorTier;
  item: string;
  pts: number;
  toughness: number;
  main: string;
  dark: string;
  light: string;
  trim: string;
  gem: string;
}

export const HORSE_ARMOR_PALETTES: Record<HorseArmorTier, HorseArmorPalette> = {
  leather:   { tier: 'leather',   item: 'leather_horse_armor',   pts: 3,  toughness: 0, main: '#a86434', dark: '#78421c', light: '#c47b46', trim: '#d8b464', gem: '#e8d084' },
  copper:    { tier: 'copper',    item: 'copper_horse_armor',    pts: 4,  toughness: 0, main: '#c8764c', dark: '#8c4c2c', light: '#e4986e', trim: '#48a888', gem: '#6ce0b8' },
  iron:      { tier: 'iron',      item: 'iron_horse_armor',      pts: 5,  toughness: 0, main: '#d4dad8', dark: '#8e9694', light: '#f0f4f2', trim: '#d8b448', gem: '#5878a8' },
  golden:    { tier: 'golden',    item: 'golden_horse_armor',    pts: 7,  toughness: 0, main: '#f2ca38', dark: '#b88a1c', light: '#fff088', trim: '#c83428', gem: '#ff5242' },
  diamond:   { tier: 'diamond',   item: 'diamond_horse_armor',   pts: 11, toughness: 2, main: '#3ed6c8', dark: '#22968c', light: '#9efcf2', trim: '#f2d24b', gem: '#ffffff' },
  netherite: { tier: 'netherite', item: 'netherite_horse_armor', pts: 12, toughness: 3, main: '#4c464a', dark: '#2e292c', light: '#6e666b', trim: '#d9b448', gem: '#b042ff' },
};

export function parseHorseArmorTier(itemName: string | undefined | null): HorseArmorTier | null {
  if (!itemName) return null;
  const m = /^(leather|copper|iron|golden|diamond|netherite)_horse_armor$/.exec(itemName);
  return m ? (m[1] as HorseArmorTier) : null;
}

export const isHorseArmor = (itemName: string | undefined | null): boolean => parseHorseArmorTier(itemName) !== null;

export function horseArmorPoints(itemName: string | undefined | null): number {
  const tier = parseHorseArmorTier(itemName);
  return tier ? HORSE_ARMOR_PALETTES[tier].pts : 0;
}

export interface HorseArmorAttachment {
  tier: HorseArmorTier;
  bodyGroup: THREE.Group;
  headGroup: THREE.Group;
  legGroups: THREE.Group[];
}

/**
 * Builds articulated 3D Horse Armor barding attached to the horse's body, head/neck, and 4 legs:
 *  - Body: Chest peytral with central boss + gold trim, side caparison panels, 6 hanging tassets, and rear crupper guard
 *  - Head: Angled neck crinet + dorsal mane guard + open-eye chanfron face plate + nose guard + ear guards + forehead crest
 *  - Legs: 4 articulated knee & shin greaves that swing with the horse's stride
 */
export function attachHorseArmor3D(
  mobGroup: THREE.Group,
  headGroup: THREE.Object3D,
  legs: THREE.Object3D[],
  tier: HorseArmorTier,
  h = 0.86,
): HorseArmorAttachment {
  const p = HORSE_ARMOR_PALETTES[tier];

  // 1. Body Barding (Peytral, Caparison Flanks, Tassets & Crupper)
  const bodyGroup = new THREE.Group();
  bodyGroup.name = 'horse_armor_body';
  addBoxPart(bodyGroup, p.dark, 0, h + 0.30, 0, 0.72, 0.64, 1.38);
  addBoxPart(bodyGroup, p.main, 0, h + 0.34, 0.02, 0.74, 0.50, 1.32);
  addBoxPart(bodyGroup, p.trim, 0, h + 0.08, 0.02, 0.75, 0.06, 1.34);

  for (const sx of [-1, 1]) {
    for (let i = 0; i < 3; i++) {
      const tz = -0.38 + i * 0.38;
      addBoxPart(bodyGroup, p.dark, sx * 0.365, h - 0.01, tz, 0.04, 0.14, 0.28);
      addBoxPart(bodyGroup, p.light, sx * 0.372, h + 0.32, tz, 0.03, 0.26, 0.26);
      addBoxPart(bodyGroup, p.trim, sx * 0.376, h + 0.08, tz, 0.035, 0.05, 0.05);
    }
  }

  // Front chest peytral plate + central heraldic boss
  addBoxPart(bodyGroup, p.main, 0, h + 0.28, -0.68, 0.66, 0.44, 0.08);
  addBoxPart(bodyGroup, p.trim, 0, h + 0.28, -0.71, 0.26, 0.26, 0.06);
  addBoxPart(bodyGroup, p.gem, 0, h + 0.28, -0.73, 0.14, 0.14, 0.06);

  // Rear crupper plate + tail arch
  addBoxPart(bodyGroup, p.main, 0, h + 0.32, 0.68, 0.64, 0.42, 0.08);
  addBoxPart(bodyGroup, p.trim, 0, h + 0.46, 0.69, 0.34, 0.10, 0.08);
  mobGroup.add(bodyGroup);

  // 2. Head & Neck Chanfron / Crinet (attached to headGroup so it nods with the horse's head)
  const hg = new THREE.Group();
  hg.name = 'horse_armor_head';
  const neckArmor = addBoxPart(hg, p.main, 0, 0.20, -0.06, 0.32, 0.56, 0.35);
  neckArmor.rotation.x = 0.38;
  const neckTrim = addBoxPart(hg, p.trim, 0, 0.22, -0.06, 0.33, 0.08, 0.36);
  neckTrim.rotation.x = 0.38;
  const maneGuard = addBoxPart(hg, p.dark, 0, 0.26, 0.12, 0.12, 0.58, 0.14);
  maneGuard.rotation.x = 0.38;

  // Open-eye chanfron helmet: leaves eye windows at y=0.50, z=-0.32 completely unobstructed
  addBoxPart(hg, p.main, 0, 0.55, -0.22, 0.37, 0.12, 0.44);
  addBoxPart(hg, p.dark, 0, 0.46, -0.10, 0.36, 0.24, 0.20);
  addBoxPart(hg, p.light, 0, 0.51, -0.37, 0.16, 0.10, 0.34);
  addBoxPart(hg, p.main, 0, 0.42, -0.50, 0.29, 0.16, 0.28);
  addBoxPart(hg, p.trim, 0, 0.58, -0.26, 0.08, 0.08, 0.42);
  addBoxPart(hg, p.gem, 0, 0.56, -0.44, 0.10, 0.08, 0.08);
  for (const sx of [-1, 1]) {
    addBoxPart(hg, p.dark, sx * 0.175, 0.42, -0.30, 0.04, 0.08, 0.22);
    addBoxPart(hg, p.dark, sx * 0.13, 0.62, -0.10, 0.10, 0.14, 0.09);
  }
  headGroup.add(hg);

  // 3. Articulated Leg Greaves (attached to each leg pivot)
  const legGroups: THREE.Group[] = [];
  for (let i = 0; i < Math.min(4, legs.length); i++) {
    const lg = new THREE.Group();
    lg.name = 'horse_armor_leg';
    addBoxPart(lg, p.dark, 0, -h * 0.35, 0, 0.21, 0.26, 0.21);
    addBoxPart(lg, p.trim, 0, -h * 0.48, -0.01, 0.22, 0.06, 0.22);
    legs[i].add(lg);
    legGroups.push(lg);
  }

  return { tier, bodyGroup, headGroup: hg, legGroups };
}

export function detachHorseArmor3D(att: HorseArmorAttachment | undefined | null) {
  if (!att) return;
  att.bodyGroup.parent?.remove(att.bodyGroup);
  att.headGroup.parent?.remove(att.headGroup);
  for (const lg of att.legGroups) lg.parent?.remove(lg);
}

// =====================================================================================================================
// 2. Perfected 3D Player & Elytra Rig (2-Layer Steve Skin + 3D Worn Armor + Articulated Elytra + Held Gear)
// =====================================================================================================================

export interface PlayerRig {
  root: THREE.Group;
  head: THREE.Group;
  torso: THREE.Group;
  legs: [THREE.Group, THREE.Group];
  arms: [THREE.Group, THREE.Group];
  armorLayer: {
    helmet: THREE.Group;
    chestplate: THREE.Group;
    leftPauldron: THREE.Group;
    rightPauldron: THREE.Group;
    leggingsPelvis: THREE.Group;
    leftLegging: THREE.Group;
    rightLegging: THREE.Group;
    leftBoot: THREE.Group;
    rightBoot: THREE.Group;
  };
  elytraGroup: THREE.Group;
  elytraWings: [THREE.Group, THREE.Group];
  rightHeld: THREE.Group;
  leftHeld: THREE.Group;
  lastArmorKey: string;
  lastHeldKey: string;
}

const ARMOR_TIER_PALETTE: Record<string, { main: string; dark: string; light: string }> = {
  leather:   { main: '#a0652d', dark: '#704218', light: '#bf8046' },
  copper:    { main: '#c77c52', dark: '#8f5230', light: '#e49d75' },
  chainmail: { main: '#9aa0a6', dark: '#686e74', light: '#c4cacf' },
  iron:      { main: '#d4dad8', dark: '#929998', light: '#f2f7f5' },
  golden:    { main: '#f0ca3c', dark: '#b58e1c', light: '#fff08a' },
  diamond:   { main: '#42dcd0', dark: '#249c92', light: '#9ffcf4' },
  netherite: { main: '#4f484c', dark: '#302b2e', light: '#70686d' },
  turtle:    { main: '#4ca850', dark: '#2e7532', light: '#76cf7a' },
};

/**
 * Builds the 2-layer Steve player model with 3D hair crown/bangs/sideburns, sclera+indigo eyes, nose, goatee,
 * V-neck collar, untucked tunic hem, cuffed pants, laced boots, 3D armor overlay mounts, and articulated Elytra wings.
 */
export function buildPlayerRig(): PlayerRig {
  const root = new THREE.Group();
  const skin = '#c99676', skinDark = '#b37e5e', hair = '#47301e', hairLight = '#593d28';
  const shirt = '#00a8a8', shirtDark = '#008484', pants = '#3b388c', pantsDark = '#2a2768', shoes = '#626262';

  // Torso (8x12x4 px -> 0.50 x 0.72 x 0.25) + 2nd-layer untucked shirt hem & V-neck collar
  const torso = new THREE.Group();
  addBoxPart(torso, shirt, 0, 1.08, 0, 0.50, 0.72, 0.25);
  addBoxPart(torso, shirtDark, 0, 0.78, 0, 0.52, 0.14, 0.27);
  addBoxPart(torso, skin, 0, 1.38, -0.11, 0.16, 0.12, 0.06);
  addBoxPart(torso, shirtDark, -0.14, 1.38, -0.12, 0.10, 0.10, 0.05);
  addBoxPart(torso, shirtDark, 0.14, 1.38, -0.12, 0.10, 0.10, 0.05);
  root.add(torso);

  // Head (8x8x8 px -> 0.50 x 0.50 x 0.50) + 2nd-layer 3D hair, bangs, sideburns, sclera/pupils, nose, goatee
  const head = new THREE.Group();
  head.position.set(0, 1.69, 0);
  addBoxPart(head, skin, 0, 0, 0, 0.50, 0.50, 0.50);
  addBoxPart(head, hair, 0, 0.20, 0.01, 0.53, 0.15, 0.53);
  addBoxPart(head, hairLight, 0, 0.265, 0, 0.48, 0.04, 0.48);
  addBoxPart(head, hair, -0.12, 0.11, -0.255, 0.22, 0.07, 0.04);
  addBoxPart(head, hair, 0.14, 0.12, -0.255, 0.16, 0.05, 0.04);
  addBoxPart(head, hair, 0, 0.05, 0.25, 0.52, 0.34, 0.05);
  for (const sx of [-1, 1]) {
    addBoxPart(head, hair, sx * 0.255, 0.06, 0.03, 0.04, 0.28, 0.44);
    addBoxPart(head, hair, sx * 0.245, 0.02, -0.21, 0.05, 0.16, 0.08);
    addBoxPart(head, '#ffffff', sx * 0.125, -0.01, -0.252, 0.12, 0.065, 0.02);
    addBoxPart(head, '#3b3296', sx * 0.105, -0.01, -0.256, 0.065, 0.065, 0.025);
  }
  addBoxPart(head, skinDark, 0, -0.06, -0.258, 0.11, 0.06, 0.04);
  addBoxPart(head, '#70442d', 0, -0.16, -0.254, 0.22, 0.07, 0.02);
  addBoxPart(head, '#54311e', -0.08, -0.13, -0.254, 0.06, 0.06, 0.02);
  addBoxPart(head, '#54311e', 0.08, -0.13, -0.254, 0.06, 0.06, 0.02);
  root.add(head);

  // Legs (4x12x4 px -> 0.24 x 0.72 x 0.24)
  const legs: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  for (let i = 0; i < 2; i++) {
    const sx = i === 0 ? -1 : 1;
    const leg = legs[i];
    leg.position.set(sx * 0.125, 0.72, 0);
    addBoxPart(leg, pants, 0, -0.30, 0, 0.24, 0.56, 0.24);
    addBoxPart(leg, '#23204a', 0, -0.04, 0, 0.25, 0.07, 0.25);
    if (sx === -1) addBoxPart(leg, '#e2be46', 0.08, -0.04, -0.128, 0.07, 0.06, 0.02);
    addBoxPart(leg, pantsDark, 0, -0.54, 0, 0.255, 0.09, 0.255);
    addBoxPart(leg, shoes, 0, -0.64, -0.01, 0.25, 0.16, 0.26);
    addBoxPart(leg, '#3e3e3e', 0, -0.70, -0.01, 0.255, 0.05, 0.27);
    root.add(leg);
  }

  // Arms (4x12x4 px -> 0.24 x 0.72 x 0.24)
  const arms: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  for (let i = 0; i < 2; i++) {
    const sx = i === 0 ? -1 : 1;
    const arm = arms[i];
    arm.position.set(sx * 0.37, 1.38, 0);
    addBoxPart(arm, shirt, 0, -0.08, 0, 0.24, 0.28, 0.24);
    addBoxPart(arm, shirtDark, 0, -0.20, 0, 0.255, 0.06, 0.255);
    addBoxPart(arm, skin, 0, -0.44, 0, 0.22, 0.44, 0.22);
    addBoxPart(arm, skinDark, 0, -0.63, 0, 0.225, 0.07, 0.225);
    root.add(arm);
  }

  // Armor Overlay Mounts
  const helmet = new THREE.Group(); head.add(helmet);
  const chestplate = new THREE.Group(); torso.add(chestplate);
  const leftPauldron = new THREE.Group(); arms[0].add(leftPauldron);
  const rightPauldron = new THREE.Group(); arms[1].add(rightPauldron);
  const leggingsPelvis = new THREE.Group(); torso.add(leggingsPelvis);
  const leftLegging = new THREE.Group(); legs[0].add(leftLegging);
  const rightLegging = new THREE.Group(); legs[1].add(rightLegging);
  const leftBoot = new THREE.Group(); legs[0].add(leftBoot);
  const rightBoot = new THREE.Group(); legs[1].add(rightBoot);

  // Held Item Mounts on Left & Right Hands
  const leftHeld = new THREE.Group();
  leftHeld.position.set(0, -0.60, -0.10);
  arms[0].add(leftHeld);
  const rightHeld = new THREE.Group();
  rightHeld.position.set(0, -0.60, -0.10);
  arms[1].add(rightHeld);

  // Articulated 3D Elytra Harness & Dual Chitin Wings
  const elytraGroup = new THREE.Group();
  elytraGroup.visible = false;
  addBoxPart(elytraGroup, '#5e4228', 0, 1.38, 0.135, 0.38, 0.10, 0.06);
  addBoxPart(elytraGroup, '#ebd046', 0, 1.38, 0.155, 0.14, 0.12, 0.05);
  addBoxPart(elytraGroup, '#5e4228', -0.16, 1.44, 0, 0.07, 0.05, 0.28);
  addBoxPart(elytraGroup, '#5e4228', 0.16, 1.44, 0, 0.07, 0.05, 0.28);

  const elytraWings: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  for (let i = 0; i < 2; i++) {
    const sx = i === 0 ? -1 : 1;
    const pivot = elytraWings[i];
    pivot.position.set(sx * 0.06, 1.38, 0.145);
    addBoxPart(pivot, '#8d8c9e', sx * 0.18, -0.44, 0.02, 0.38, 0.88, 0.05);
    addBoxPart(pivot, '#b4b2c4', sx * 0.10, -0.34, 0.028, 0.20, 0.62, 0.05);
    addBoxPart(pivot, '#5c5b6e', sx * 0.33, -0.42, 0.028, 0.09, 0.84, 0.06);
    addBoxPart(pivot, '#6e6d80', sx * 0.20, -0.46, 0.032, 0.04, 0.72, 0.05);
    addBoxPart(pivot, '#3b3a4a', sx * 0.11, -0.92, 0.02, 0.18, 0.16, 0.04);
    addBoxPart(pivot, '#4c4b5e', sx * 0.25, -0.88, 0.02, 0.14, 0.14, 0.04);
    pivot.rotation.z = -sx * 0.26;
    pivot.rotation.x = -0.16;
    pivot.rotation.y = sx * 0.10;
    elytraGroup.add(pivot);
  }
  root.add(elytraGroup);

  return {
    root,
    head,
    torso,
    legs,
    arms,
    armorLayer: {
      helmet,
      chestplate,
      leftPauldron,
      rightPauldron,
      leggingsPelvis,
      leftLegging,
      rightLegging,
      leftBoot,
      rightBoot,
    },
    elytraGroup,
    elytraWings,
    rightHeld,
    leftHeld,
    lastArmorKey: '',
    lastHeldKey: '',
  };
}

function clearGroup(g: THREE.Group) {
  while (g.children.length > 0) g.remove(g.children[0]);
}

function tierColorsOf(itemName: string): { main: string; dark: string; light: string } | null {
  if (itemName === 'turtle_helmet') return ARMOR_TIER_PALETTE.turtle;
  const m = /^(leather|copper|chainmail|iron|golden|diamond|netherite)_(helmet|chestplate|leggings|boots)$/.exec(itemName);
  return m ? ARMOR_TIER_PALETTE[m[1]] : null;
}

function trimColorOf(stack: Stack | null | undefined, fallback: string): string {
  if (stack?.trim?.material && TRIM_MAT_BY_ID[stack.trim.material]) {
    return TRIM_MAT_BY_ID[stack.trim.material].color;
  }
  return fallback;
}

/** Builds a 3D handheld weapon/tool/shield/item inside `target` group. */
export function buildHeldItem3D(target: THREE.Group, stack: Stack | null | undefined, isLeftHand = false) {
  clearGroup(target);
  if (!stack) return;
  const name = stack.name;
  if (name === 'shield') {
    const sh = new THREE.Group();
    sh.position.set(isLeftHand ? -0.10 : 0.10, -0.04, -0.08);
    addBoxPart(sh, '#8a5d32', 0, 0, 0, 0.34, 0.62, 0.06);
    addBoxPart(sh, '#5c3c1e', 0, 0, 0.005, 0.38, 0.66, 0.04);
    addBoxPart(sh, '#c2c8cc', 0, 0, -0.035, 0.10, 0.10, 0.04);
    target.add(sh);
    return;
  }
  const swordMatch = /^(wooden|stone|copper|iron|golden|diamond|netherite)_(sword|axe|pickaxe|shovel|hoe)$/.exec(name);
  if (swordMatch || name === 'trident' || name === 'mace') {
    const tierCol: Record<string, string> = {
      wooden: '#a67c46', stone: '#8a8e88', copper: '#cf7c52', iron: '#d8dedc',
      golden: '#f5ce42', diamond: '#45e0d2', netherite: '#4e474b',
    };
    const bladeCol = name === 'trident' ? '#58d8c8' : name === 'mace' ? '#686c7c' : (tierCol[swordMatch![1]] ?? '#d8dedc');
    const kind = swordMatch ? swordMatch[2] : name;
    const w = new THREE.Group();
    w.rotation.x = -0.95;
    addBoxPart(w, '#6e4c2a', 0, 0.16, 0, 0.06, 0.44, 0.06);
    addBoxPart(w, '#e2be46', 0, -0.06, 0, 0.09, 0.08, 0.09);
    if (kind === 'sword') {
      addBoxPart(w, bladeCol, 0, 0.08, 0, 0.24, 0.06, 0.08);
      addBoxPart(w, bladeCol, 0, 0.38, 0, 0.10, 0.56, 0.05);
    } else if (kind === 'axe') {
      addBoxPart(w, bladeCol, 0, 0.34, -0.06, 0.07, 0.22, 0.22);
    } else if (kind === 'pickaxe') {
      addBoxPart(w, bladeCol, 0, 0.38, 0, 0.07, 0.08, 0.36);
    } else if (kind === 'trident') {
      addBoxPart(w, '#3b8c82', 0, 0.28, 0, 0.06, 0.68, 0.06);
      addBoxPart(w, '#88fff0', 0, 0.62, 0, 0.22, 0.06, 0.06);
      for (const sx of [-0.08, 0, 0.08]) addBoxPart(w, '#a8fff5', sx, 0.72, 0, 0.04, 0.18, 0.04);
    } else {
      addBoxPart(w, bladeCol, 0, 0.40, 0, 0.18, 0.18, 0.18);
    }
    target.add(w);
    return;
  }
  if (name === 'bow' || name === 'crossbow') {
    const b = new THREE.Group();
    b.rotation.x = -0.4;
    addBoxPart(b, '#7d5630', 0, 0.04, -0.08, 0.06, 0.52, 0.08);
    addBoxPart(b, '#e0dcd0', 0, 0.04, 0.02, 0.02, 0.50, 0.02);
    target.add(b);
    return;
  }
  const def = resolve(name);
  if (def) {
    addBoxPart(target, def.color || '#c8a878', 0, -0.02, -0.04, 0.22, 0.22, 0.22);
  }
}

/** Synchronizes a `PlayerRig`'s armor overlays, held items, and Elytra wing animations on every frame. */
export function syncPlayerRig(
  rig: PlayerRig,
  armor: (Stack | null)[],
  mainHand: Stack | null,
  offHand: Stack | null,
  elytraEquipped: boolean,
  gliding: boolean,
  boosting: boolean,
  crouching: boolean,
  elapsed: number,
) {
  const showElytra = elytraEquipped || armor[1]?.name === 'elytra';
  rig.elytraGroup.visible = showElytra;
  if (showElytra) {
    const flutter = gliding
      ? Math.sin(elapsed * (boosting ? 28 : 12)) * (boosting ? 0.08 : 0.03)
      : Math.sin(elapsed * 2.5) * 0.02;
    for (let i = 0; i < 2; i++) {
      const sx = i === 0 ? -1 : 1;
      const w = rig.elytraWings[i];
      if (gliding) {
        w.rotation.z = -sx * (1.22 + flutter);
        w.rotation.x = -0.28;
        w.rotation.y = sx * 0.08;
      } else if (crouching) {
        w.rotation.z = -sx * (0.68 + flutter);
        w.rotation.x = -0.38;
        w.rotation.y = sx * 0.22;
      } else {
        w.rotation.z = -sx * (0.26 + flutter);
        w.rotation.x = -0.16;
        w.rotation.y = sx * 0.10;
      }
    }
  }

  const armorKey = armor.map(s => (s ? `${s.name}:${s.trim?.pattern ?? ''}:${s.trim?.material ?? ''}` : '')).join('|');
  if (armorKey !== rig.lastArmorKey) {
    rig.lastArmorKey = armorKey;
    const L = rig.armorLayer;
    clearGroup(L.helmet);
    clearGroup(L.chestplate);
    clearGroup(L.leftPauldron);
    clearGroup(L.rightPauldron);
    clearGroup(L.leggingsPelvis);
    clearGroup(L.leftLegging);
    clearGroup(L.rightLegging);
    clearGroup(L.leftBoot);
    clearGroup(L.rightBoot);

    // Slot 0: Helmet / Mob Head / Carved Pumpkin
    const hStack = armor[0];
    if (hStack) {
      const tc = tierColorsOf(hStack.name);
      if (tc) {
        const trimCol = trimColorOf(hStack, tc.light);
        addBoxPart(L.helmet, tc.main, 0, 0.10, 0, 0.56, 0.34, 0.56);
        addBoxPart(L.helmet, tc.dark, 0, -0.04, 0.16, 0.55, 0.22, 0.24);
        addBoxPart(L.helmet, trimCol, 0, 0.05, -0.285, 0.57, 0.06, 0.04);
        addBoxPart(L.helmet, tc.dark, 0, -0.02, -0.285, 0.08, 0.14, 0.04);
      } else if (hStack.name === 'carved_pumpkin') {
        addBoxPart(L.helmet, '#d87a22', 0, 0.02, 0, 0.56, 0.54, 0.56);
      }
    }

    // Slot 1: Chestplate (skipped if wearing Elytra in slot 1)
    const cStack = armor[1];
    if (cStack && cStack.name !== 'elytra') {
      const tc = tierColorsOf(cStack.name);
      if (tc) {
        const trimCol = trimColorOf(cStack, tc.light);
        addBoxPart(L.chestplate, tc.main, 0, 1.10, 0, 0.56, 0.68, 0.31);
        addBoxPart(L.chestplate, trimCol, 0, 1.18, -0.16, 0.38, 0.36, 0.04);
        for (const [s, pg] of [[-1, L.leftPauldron], [1, L.rightPauldron]] as const) {
          addBoxPart(pg, tc.main, s * 0.01, -0.08, 0, 0.28, 0.30, 0.28);
          addBoxPart(pg, trimCol, s * 0.01, -0.21, 0, 0.29, 0.05, 0.29);
        }
      }
    }

    // Slot 2: Leggings
    const lStack = armor[2];
    if (lStack) {
      const tc = tierColorsOf(lStack.name);
      if (tc) {
        const trimCol = trimColorOf(lStack, tc.light);
        addBoxPart(L.leggingsPelvis, tc.dark, 0, 0.74, 0, 0.53, 0.14, 0.28);
        for (const lg of [L.leftLegging, L.rightLegging]) {
          addBoxPart(lg, tc.main, 0, -0.26, 0, 0.265, 0.46, 0.265);
          addBoxPart(lg, trimCol, 0, -0.44, 0, 0.27, 0.05, 0.27);
        }
      }
    }

    // Slot 3: Boots
    const bStack = armor[3];
    if (bStack) {
      const tc = tierColorsOf(bStack.name);
      if (tc) {
        const trimCol = trimColorOf(bStack, tc.light);
        for (const bg of [L.leftBoot, L.rightBoot]) {
          addBoxPart(bg, tc.main, 0, -0.62, -0.01, 0.275, 0.22, 0.28);
          addBoxPart(bg, trimCol, 0, -0.52, -0.01, 0.28, 0.05, 0.285);
        }
      }
    }
  }

  const heldKey = `${mainHand?.name ?? ''}|${offHand?.name ?? ''}`;
  if (heldKey !== rig.lastHeldKey) {
    rig.lastHeldKey = heldKey;
    buildHeldItem3D(rig.rightHeld, mainHand, false);
    buildHeldItem3D(rig.leftHeld, offHand, true);
  }
}

// =====================================================================================================================
// 3. Perfected 3D Armor Stand System (Java ArmorStandModel 12x1x12 Base Plate + Twin Torso Sticks + Poses + Gear)
// =====================================================================================================================

export type ArmorStandPose = 'default' | 'heroic' | 'salute' | 'zombie';
export const ARMOR_STAND_POSES: readonly ArmorStandPose[] = ['default', 'heroic', 'salute', 'zombie'];

export interface ArmorStandData {
  id: number;
  dimension: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pose: ArmorStandPose;
  armor: [Stack | null, Stack | null, Stack | null, Stack | null];
  held: Stack | null;
  offhand: Stack | null;
}

export interface ArmorStandSave {
  id: number;
  dimension: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pose: ArmorStandPose;
  armor: [Stack | null, Stack | null, Stack | null, Stack | null];
  held: Stack | null;
  offhand?: Stack | null;
}

export interface ArmorStandInstance extends ArmorStandData {
  group: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  wobble: number;
  hits: number;
  lastHitAt: number;
}

/**
 * Builds an authentic Java Edition `ArmorStandModel` (12×1×12 smooth-stone base plate, twin leg posts,
 * waist crossbar, twin vertical torso sticks with open center gap, wide shoulder beam, neck peg, head block,
 * articulated arms, and full 3D armor/elytra/held-weapon rendering).
 */
export function buildArmorStandMesh(data: Pick<ArmorStandData, 'pose' | 'armor' | 'held' | 'offhand'>): {
  group: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
} {
  const g = new THREE.Group();
  const s = 1 / 16;
  const stone = '#9e9e9a', stoneDark = '#787874', stoneRim = '#b8b8b2';
  const wood = '#b89458', woodDark = '#8f6e38', woodJoint = '#73562a';

  // 12x1x12 Smooth Stone Base Plate with stepped stone bevel
  addBoxPart(g, stoneDark, 0, 0.5 * s, 0, 12 * s, 1 * s, 12 * s);
  addBoxPart(g, stone, 0, 0.9 * s, 0, 11.4 * s, 0.4 * s, 11.4 * s);
  addBoxPart(g, stoneRim, 0, 1.15 * s, 0, 10.4 * s, 0.15 * s, 10.4 * s);

  // Left & Right Leg Sticks (2x11x2 px)
  const legs: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  for (let i = 0; i < 2; i++) {
    const sx = i === 0 ? -1 : 1;
    const leg = legs[i];
    leg.position.set(sx * 1.9 * s, 12 * s, 0);
    addBoxPart(leg, wood, 0, -5.5 * s, 0, 2 * s, 11 * s, 2 * s);
    addBoxPart(leg, woodJoint, 0, -5.5 * s, 0, 2.2 * s, 1.2 * s, 2.2 * s);
    g.add(leg);
  }

  // Waist Crossbeam (8x2x2 px) + Twin Vertical Torso Sticks (2x7x2 px with open center gap!) + Shoulder Block (12x3x3 px)
  addBoxPart(g, woodDark, 0, 12.5 * s, 0, 8 * s, 2 * s, 2 * s);
  addBoxPart(g, wood, -2 * s, 17 * s, 0, 2 * s, 7 * s, 2 * s);
  addBoxPart(g, wood, 2 * s, 17 * s, 0, 2 * s, 7 * s, 2 * s);
  addBoxPart(g, wood, 0, 22 * s, 0, 12 * s, 3 * s, 3 * s);
  addBoxPart(g, woodDark, 0, 23.6 * s, 0, 11.4 * s, 0.4 * s, 2.6 * s);

  // Head & Neck Peg
  const head = new THREE.Group();
  head.position.set(0, 23.5 * s, 0);
  addBoxPart(head, woodDark, 0, 1.0 * s, 0, 2 * s, 2 * s, 2 * s);
  addBoxPart(head, wood, 0, 4.5 * s, 0, 2.2 * s, 6 * s, 2.2 * s);
  g.add(head);

  // Articulated Arms (2x12x2 px) with shoulder dowel pegs
  const arms: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  for (let i = 0; i < 2; i++) {
    const sx = i === 0 ? -1 : 1;
    const arm = arms[i];
    arm.position.set(sx * 6.5 * s, 22 * s, 0);
    addBoxPart(arm, woodJoint, -sx * 0.4 * s, 0, 0, 1.4 * s, 1.6 * s, 1.6 * s);
    addBoxPart(arm, wood, 0, -5 * s, 0, 2 * s, 12 * s, 2 * s);
    addBoxPart(arm, woodJoint, 0, -5 * s, 0, 2.2 * s, 1.2 * s, 2.2 * s);
    g.add(arm);
  }

  // Apply Pose
  const pose = data.pose;
  if (pose === 'heroic') {
    arms[0].rotation.set(-0.35, 0, -0.25);
    arms[1].rotation.set(-0.85, -0.20, 0.22);
    head.rotation.y = -0.15;
  } else if (pose === 'salute') {
    arms[0].rotation.set(0.10, 0, -0.12);
    arms[1].rotation.set(-2.1, -0.35, 0.45);
    head.rotation.y = 0.12;
  } else if (pose === 'zombie') {
    arms[0].rotation.set(-1.45, 0.1, -0.05);
    arms[1].rotation.set(-1.45, -0.1, 0.05);
  } else {
    arms[0].rotation.set(-0.08, 0, -0.08);
    arms[1].rotation.set(-0.08, 0, 0.08);
  }

  // Render Equipped Armor / Elytra / Held Gear
  const [hStack, cStack, lStack, bStack] = data.armor;
  if (hStack) {
    const tc = tierColorsOf(hStack.name);
    if (tc) {
      const trimCol = trimColorOf(hStack, tc.light);
      addBoxPart(head, tc.main, 0, 5.2 * s, 0, 8.8 * s, 5.4 * s, 8.8 * s);
      addBoxPart(head, tc.dark, 0, 3.2 * s, 2.2 * s, 8.6 * s, 3.6 * s, 4.4 * s);
      addBoxPart(head, trimCol, 0, 4.2 * s, -4.5 * s, 9.0 * s, 1.2 * s, 0.8 * s);
    } else if (hStack.name === 'carved_pumpkin' || hStack.name.endsWith('_head') || hStack.name.endsWith('_skull')) {
      const col = resolve(hStack.name)?.color ?? '#7ab858';
      addBoxPart(head, col, 0, 4.5 * s, 0, 8.4 * s, 8.4 * s, 8.4 * s);
    }
  }
  if (cStack) {
    if (cStack.name === 'elytra') {
      addBoxPart(g, '#5e4228', 0, 21.5 * s, 2.2 * s, 6 * s, 1.6 * s, 1 * s);
      addBoxPart(g, '#ebd046', 0, 21.5 * s, 2.5 * s, 2.2 * s, 1.8 * s, 0.8 * s);
      for (const sx of [-1, 1]) {
        const w = new THREE.Group();
        w.position.set(sx * 1.0 * s, 21.5 * s, 2.3 * s);
        w.rotation.set(-0.16, sx * 0.10, -sx * 0.26);
        addBoxPart(w, '#8d8c9e', sx * 2.8 * s, -7.0 * s, 0.3 * s, 6.0 * s, 14.0 * s, 0.8 * s);
        addBoxPart(w, '#b4b2c4', sx * 1.6 * s, -5.4 * s, 0.45 * s, 3.2 * s, 9.8 * s, 0.8 * s);
        addBoxPart(w, '#5c5b6e', sx * 5.2 * s, -6.6 * s, 0.45 * s, 1.4 * s, 13.4 * s, 0.9 * s);
        g.add(w);
      }
    } else {
      const tc = tierColorsOf(cStack.name);
      if (tc) {
        const trimCol = trimColorOf(cStack, tc.light);
        addBoxPart(g, tc.main, 0, 17.8 * s, 0, 8.8 * s, 10.5 * s, 4.8 * s);
        addBoxPart(g, trimCol, 0, 19.0 * s, -2.5 * s, 6.0 * s, 6.0 * s, 0.8 * s);
        for (let i = 0; i < 2; i++) {
          const sx = i === 0 ? -1 : 1;
          addBoxPart(arms[i], tc.main, sx * 0.3 * s, -1.5 * s, 0, 4.4 * s, 5.2 * s, 4.4 * s);
          addBoxPart(arms[i], trimCol, sx * 0.3 * s, -3.8 * s, 0, 4.6 * s, 0.9 * s, 4.6 * s);
        }
      }
    }
  }
  if (lStack) {
    const tc = tierColorsOf(lStack.name);
    if (tc) {
      const trimCol = trimColorOf(lStack, tc.light);
      addBoxPart(g, tc.dark, 0, 12.2 * s, 0, 8.4 * s, 2.2 * s, 4.4 * s);
      for (const leg of legs) {
        addBoxPart(leg, tc.main, 0, -4.0 * s, 0, 3.8 * s, 7.2 * s, 3.8 * s);
        addBoxPart(leg, trimCol, 0, -7.0 * s, 0, 3.9 * s, 0.8 * s, 3.9 * s);
      }
    }
  }
  if (bStack) {
    const tc = tierColorsOf(bStack.name);
    if (tc) {
      const trimCol = trimColorOf(bStack, tc.light);
      for (const leg of legs) {
        addBoxPart(leg, tc.main, 0, -9.2 * s, -0.2 * s, 4.2 * s, 3.6 * s, 4.4 * s);
        addBoxPart(leg, trimCol, 0, -7.6 * s, -0.2 * s, 4.3 * s, 0.8 * s, 4.5 * s);
      }
    }
  }
  if (data.held) {
    const rHeld = new THREE.Group();
    rHeld.position.set(0, -9.8 * s, -1.2 * s);
    buildHeldItem3D(rHeld, data.held, false);
    arms[1].add(rHeld);
  }
  if (data.offhand) {
    const lHeld = new THREE.Group();
    lHeld.position.set(0, -9.8 * s, -1.2 * s);
    buildHeldItem3D(lHeld, data.offhand, true);
    arms[0].add(lHeld);
  }

  return { group: g, head, leftArm: arms[0], rightArm: arms[1], leftLeg: legs[0], rightLeg: legs[1] };
}

export class ArmorStandManager {
  stands: ArmorStandInstance[] = [];
  private nextId = 1;
  private tmp = new THREE.Vector3();

  constructor(private scene: THREE.Scene) {}

  spawn(
    dimension: string,
    x: number,
    y: number,
    z: number,
    yaw = 0,
    pose: ArmorStandPose = 'default',
    armor: [Stack | null, Stack | null, Stack | null, Stack | null] = [null, null, null, null],
    held: Stack | null = null,
    offhand: Stack | null = null,
  ): ArmorStandInstance {
    const built = buildArmorStandMesh({ pose, armor, held, offhand });
    built.group.position.set(x, y, z);
    built.group.rotation.y = yaw;
    built.group.visible = true;
    this.scene.add(built.group);
    const inst: ArmorStandInstance = {
      id: this.nextId++,
      dimension,
      x,
      y,
      z,
      yaw,
      pose,
      armor: [armor[0] ? { ...armor[0] } : null, armor[1] ? { ...armor[1] } : null, armor[2] ? { ...armor[2] } : null, armor[3] ? { ...armor[3] } : null],
      held: held ? { ...held } : null,
      offhand: offhand ? { ...offhand } : null,
      group: built.group,
      head: built.head,
      leftArm: built.leftArm,
      rightArm: built.rightArm,
      leftLeg: built.leftLeg,
      rightLeg: built.rightLeg,
      wobble: 0,
      hits: 0,
      lastHitAt: -10,
    };
    this.stands.push(inst);
    return inst;
  }

  rebuild(st: ArmorStandInstance) {
    this.scene.remove(st.group);
    const built = buildArmorStandMesh(st);
    built.group.position.set(st.x, st.y, st.z);
    built.group.rotation.y = st.yaw;
    this.scene.add(built.group);
    st.group = built.group;
    st.head = built.head;
    st.leftArm = built.leftArm;
    st.rightArm = built.rightArm;
    st.leftLeg = built.leftLeg;
    st.rightLeg = built.rightLeg;
  }

  pick(dimension: string, origin: THREE.Vector3, dir: THREE.Vector3, reach = 4.6): ArmorStandInstance | null {
    let best: ArmorStandInstance | null = null, bestD = reach;
    for (const s of this.stands) {
      if (s.dimension !== dimension) continue;
      this.tmp.set(s.x, s.y + 0.95, s.z).sub(origin);
      const d = this.tmp.length();
      if (d > bestD) continue;
      if (this.tmp.normalize().dot(dir) < 0.88) continue;
      best = s;
      bestD = d;
    }
    return best;
  }

  /** Cycles pose when sneaking with empty hand, or swaps armor/elytra/held gear with the player's hand! */
  interact(
    st: ArmorStandInstance,
    held: Stack | null,
    crouching: boolean,
    hitYOffset = 1.0,
  ): { action: 'pose' | 'swap'; replacement: Stack | null } | null {
    if (crouching && !held) {
      const idx = (ARMOR_STAND_POSES.indexOf(st.pose) + 1) % ARMOR_STAND_POSES.length;
      st.pose = ARMOR_STAND_POSES[idx];
      this.rebuild(st);
      return { action: 'pose', replacement: null };
    }
    if (held) {
      const slot = armorSlotForStand(held.name);
      if (slot >= 0) {
        const prev = st.armor[slot];
        st.armor[slot] = { ...held, count: 1 };
        this.rebuild(st);
        return { action: 'swap', replacement: prev };
      }
      const prevHeld = st.held;
      st.held = { ...held, count: 1 };
      this.rebuild(st);
      return { action: 'swap', replacement: prevHeld };
    }
    // Empty hand: take from the targeted height or first occupied slot
    const prefSlot = hitYOffset > 1.45 ? 0 : hitYOffset > 0.95 ? 1 : hitYOffset > 0.45 ? 2 : 3;
    if (st.held && hitYOffset > 0.7 && hitYOffset < 1.35) {
      const out = st.held;
      st.held = null;
      this.rebuild(st);
      return { action: 'swap', replacement: out };
    }
    for (const sIdx of [prefSlot, 0, 1, 2, 3]) {
      if (st.armor[sIdx]) {
        const out = st.armor[sIdx];
        st.armor[sIdx] = null;
        this.rebuild(st);
        return { action: 'swap', replacement: out };
      }
    }
    if (st.held) {
      const out = st.held;
      st.held = null;
      this.rebuild(st);
      return { action: 'swap', replacement: out };
    }
    return null;
  }

  /** Hits the armor stand: 1st hit wobbles it, 2nd hit within 1.5s breaks it and returns all dropped stacks. */
  hit(st: ArmorStandInstance, now: number, creative = false): Stack[] | null {
    if (!creative && now - st.lastHitAt > 1.5) st.hits = 0;
    st.lastHitAt = now;
    st.hits++;
    st.wobble = 0.35;
    if (!creative && st.hits < 2) return null;
    const drops: Stack[] = [{ name: 'armor_stand', count: 1 }];
    for (const a of st.armor) if (a) drops.push(a);
    if (st.held) drops.push(st.held);
    if (st.offhand) drops.push(st.offhand);
    this.remove(st);
    return drops;
  }

  remove(st: ArmorStandInstance) {
    this.scene.remove(st.group);
    const idx = this.stands.indexOf(st);
    if (idx >= 0) this.stands.splice(idx, 1);
  }

  update(dt: number, currentDim: string) {
    for (const st of this.stands) {
      st.group.visible = st.dimension === currentDim;
      if (st.wobble > 0) {
        st.wobble = Math.max(0, st.wobble - dt * 1.8);
        st.group.rotation.z = Math.sin(st.wobble * 32) * st.wobble * 0.25;
      } else {
        st.group.rotation.z = 0;
      }
    }
  }

  clear() {
    for (const st of this.stands) this.scene.remove(st.group);
    this.stands = [];
  }

  save(): ArmorStandSave[] {
    return this.stands.map(s => ({
      id: s.id,
      dimension: s.dimension,
      x: s.x,
      y: s.y,
      z: s.z,
      yaw: s.yaw,
      pose: s.pose,
      armor: [s.armor[0], s.armor[1], s.armor[2], s.armor[3]],
      held: s.held,
      offhand: s.offhand,
    }));
  }

  load(list: ArmorStandSave[] | undefined) {
    this.clear();
    for (const s of list ?? []) {
      const inst = this.spawn(s.dimension || 'overworld', s.x, s.y, s.z, s.yaw ?? 0, s.pose ?? 'default', s.armor ?? [null, null, null, null], s.held ?? null, s.offhand ?? null);
      inst.id = s.id ?? inst.id;
      this.nextId = Math.max(this.nextId, inst.id + 1);
    }
  }
}

function armorSlotForStand(name: string): number {
  if (name === 'elytra') return 1;
  if (name === 'carved_pumpkin' || name === 'turtle_helmet' || name.endsWith('_helmet') || name.endsWith('_head') || name.endsWith('_skull')) return 0;
  if (name.endsWith('_chestplate')) return 1;
  if (name.endsWith('_leggings')) return 2;
  if (name.endsWith('_boots')) return 3;
  return -1;
}

// =====================================================================================================================
// 4. Perfected 3D Item Frame & Glow Item Frame Renderer (12x12x1 Birch Border + 8-Step Rotated 3D Items + Full 16x16 Map)
// =====================================================================================================================

export function buildItemFrameMesh(item: Stack | null, rotStep = 0, glow = false): THREE.Group {
  const g = new THREE.Group();
  const s = 1 / 16;
  const birch = '#d9c89a', birchLight = '#eadab0', birchDark = '#b59f6e';
  const leather = glow ? '#228b86' : '#7d4827', leatherDark = glow ? '#16605b' : '#5e341a', stitch = glow ? '#6ef7ec' : '#9c6239';
  const isMap = item?.name === 'map' || item?.name === 'filled_map';

  // Backing plate + recessed leather mat + 4 stitched inner dashes
  addBoxPart(g, leatherDark, 0, 0.5, 0.446, 10.4 * s, 10.4 * s, 0.5 * s, glow);
  addBoxPart(g, leather, 0, 0.5, 0.440, 9.4 * s, 9.4 * s, 0.55 * s, glow);
  if (!isMap) {
    for (const sy of [-1, 1]) addBoxPart(g, stitch, 0, 0.5 + sy * 4.2 * s, 0.436, 7.6 * s, 0.35 * s, 0.58 * s, glow);
    for (const sx of [-1, 1]) addBoxPart(g, stitch, sx * 4.2 * s, 0.5, 0.436, 0.35 * s, 7.6 * s, 0.58 * s, glow);

    if (glow) {
      for (const [gx, gy] of [[-3.1, 3.0], [3.1, -2.2], [-2.3, -3.1], [2.4, 2.5], [0, 3.2]]) {
        addBoxPart(g, '#88fff4', gx * s, 0.5 + gy * s, 0.434, 1.0 * s, 1.0 * s, 0.62 * s, true);
      }
    }

    // 4 Birch frame bars with inner highlight bevel + 4 corner miter blocks + brass corner studs
    for (const sy of [-1, 1]) {
      addBoxPart(g, birch, 0, 0.5 + sy * 5.5 * s, 0.424, 9.8 * s, 1.15 * s, 1.25 * s);
      addBoxPart(g, birchLight, 0, 0.5 + sy * 5.0 * s, 0.418, 9.6 * s, 0.35 * s, 1.3 * s);
    }
    for (const sx of [-1, 1]) {
      addBoxPart(g, birch, sx * 5.5 * s, 0.5, 0.424, 1.15 * s, 9.8 * s, 1.25 * s);
      addBoxPart(g, birchLight, sx * 5.0 * s, 0.5, 0.418, 0.35 * s, 9.6 * s, 1.3 * s);
    }
    for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
      addBoxPart(g, birchDark, sx * 5.5 * s, 0.5 + sy * 5.5 * s, 0.422, 1.25 * s, 1.25 * s, 1.35 * s);
      addBoxPart(g, '#d8b448', sx * 5.5 * s, 0.5 + sy * 5.5 * s, 0.412, 0.45 * s, 0.45 * s, 1.42 * s);
    }
  }

  if (item) {
    const holder = new THREE.Group();
    holder.name = 'item_frame_holder';
    holder.position.set(0, 0.5, 0.388);
    holder.rotation.z = -((rotStep & 7) * Math.PI) / 4;
    const n = item.name;
    if (n === 'elytra') {
      addBoxPart(holder, '#6e4e2e', 0, 2.55 * s, 0.01, 3.6 * s, 1.0 * s, 0.7 * s, glow);
      addBoxPart(holder, '#ebd046', 0, 2.55 * s, 0, 1.7 * s, 1.25 * s, 0.9 * s, glow);
      for (const sx of [-1, 1]) {
        const w = new THREE.Group();
        w.position.set(sx * 0.85 * s, 2.4 * s, 0);
        w.rotation.z = sx * 0.28;
        addBoxPart(w, '#9695a8', sx * 1.6 * s, -2.8 * s, 0, 3.1 * s, 5.8 * s, 0.85 * s, glow);
        addBoxPart(w, '#b8b7c8', sx * 0.9 * s, -2.2 * s, -0.1 * s, 1.4 * s, 4.4 * s, 0.92 * s, glow);
        addBoxPart(w, '#5d5b6e', sx * 2.85 * s, -2.8 * s, 0.1 * s, 0.85 * s, 5.8 * s, 0.92 * s, glow);
        addBoxPart(w, '#48475a', sx * 1.25 * s, -5.85 * s, 0, 1.9 * s, 1.65 * s, 0.75 * s, glow);
        holder.add(w);
      }
    } else if (isMap) {
      // Full 16x16 map board covering the entire block face cleanly in front of the backing
      addBoxPart(holder, '#c4b082', 0, 0, 0, 15.8 * s, 15.8 * s, 0.65 * s, glow);
      addBoxPart(holder, '#dfd2a8', 0, 0, -0.005, 14.8 * s, 14.8 * s, 0.70 * s, glow);
      addBoxPart(holder, '#5cb85c', -2.8 * s, 2.0 * s, -0.010, 7.2 * s, 7.8 * s, 0.76 * s, glow);
      addBoxPart(holder, '#3d85c6', 3.0 * s, -1.6 * s, -0.010, 6.4 * s, 9.2 * s, 0.76 * s, glow);
      addBoxPart(holder, '#d6be7c', -2.5 * s, -3.8 * s, -0.010, 6.6 * s, 4.0 * s, 0.76 * s, glow);
      addBoxPart(holder, '#e03c31', -3.2 * s, 2.4 * s, -0.016, 1.4 * s, 1.4 * s, 0.85 * s, true);
      addBoxPart(holder, '#28d448', 0.4 * s, -0.4 * s, -0.016, 1.5 * s, 1.5 * s, 0.85 * s, true);
    } else if (n.endsWith('_sword') || n === 'trident' || n === 'mace') {
      const col = resolve(n)?.color ?? '#4ce0d2';
      const sw = new THREE.Group();
      sw.rotation.z = Math.PI / 4;
      addBoxPart(sw, '#6b4a28', 0, -2.6 * s, 0, 1.1 * s, 2.6 * s, 0.9 * s, glow);
      addBoxPart(sw, '#ebd046', 0, -4.1 * s, 0, 1.6 * s, 1.2 * s, 1.15 * s, glow);
      addBoxPart(sw, col, 0, -1.1 * s, 0, 4.0 * s, 0.95 * s, 1.15 * s, glow);
      addBoxPart(sw, col, 0, 2.2 * s, 0, 1.85 * s, 5.8 * s, 0.85 * s, glow);
      holder.add(sw);
    } else {
      const col = resolve(n)?.color ?? '#d8b448';
      addBoxPart(holder, col, 0, 0, 0, 5.2 * s, 5.2 * s, 1.8 * s, glow);
    }
    g.add(holder);
  }
  return g;
}

export class ItemFrameMeshes {
  private meshes = new Map<string, { group: THREE.Group; sig: string }>();
  rotations = new Map<string, number>();
  glows = new Set<string>();

  constructor(private scene: THREE.Scene) {}

  set(key: string, x: number, y: number, z: number, state: number, item: Stack | null, rotStep?: number, glow?: boolean) {
    if (rotStep !== undefined) this.rotations.set(key, rotStep & 7);
    if (glow !== undefined) { if (glow) this.glows.add(key); else this.glows.delete(key); }
    const rot = this.rotations.get(key) ?? 0;
    const isGlow = this.glows.has(key);
    const sig = `${x},${y},${z}:${state}:${item?.name ?? ''}:${rot}:${isGlow ? 1 : 0}`;
    const prev = this.meshes.get(key);
    if (prev && prev.sig === sig) return;
    if (prev) this.scene.remove(prev.group);

    const group = buildItemFrameMesh(item, rot, isGlow);
    // Wall attachment orientation from pane state (0..3)
    const dir = state & 3;
    const yaws = [0, -Math.PI / 2, Math.PI, Math.PI / 2];
    group.position.set(x + 0.5, y, z + 0.5);
    group.rotation.y = yaws[dir] ?? 0;
    this.scene.add(group);
    this.meshes.set(key, { group, sig });
  }

  rotate(key: string): number {
    const next = ((this.rotations.get(key) ?? 0) + 1) & 7;
    this.rotations.set(key, next);
    return next;
  }

  comparatorSignal(key: string, hasItem: boolean): number {
    if (!hasItem) return 0;
    return ((this.rotations.get(key) ?? 0) & 7) + 1;
  }

  remove(key: string) {
    const prev = this.meshes.get(key);
    if (prev) {
      this.scene.remove(prev.group);
      this.meshes.delete(key);
    }
  }

  clear() {
    for (const k of [...this.meshes.keys()]) this.remove(k);
  }

  get size() { return this.meshes.size; }
}

// =====================================================================================================================
// 5. Perfected 3D Painting System (Beveled Oak & Gold Gallery Frame + Pixel-Art Canvas Motifs Across 1x1..4x4)
// =====================================================================================================================

export type PaintingMotifId = 'kebab' | 'aztec' | 'creebet' | 'wanderer' | 'skull_and_roses' | 'wither' | 'fighters' | 'burning_skull';

export interface PaintingSpec {
  id: PaintingMotifId;
  ja: string;
  w: number;
  h: number;
}

export const PAINTING_MOTIFS: readonly PaintingSpec[] = [
  { id: 'kebab',           ja: 'ケバブとピーマン (1×1)',       w: 1, h: 1 },
  { id: 'aztec',           ja: 'de_aztec (1×1)',              w: 1, h: 1 },
  { id: 'creebet',         ja: '海辺のクリーパー (2×1)',       w: 2, h: 1 },
  { id: 'wanderer',        ja: '霧の上の放浪者 (1×2)',         w: 1, h: 2 },
  { id: 'skull_and_roses', ja: '月光のドクロとバラ (2×2)',     w: 2, h: 2 },
  { id: 'wither',          ja: 'ウィザーの誕生 (2×2)',         w: 2, h: 2 },
  { id: 'fighters',        ja: 'ファイターズ (4×2)',           w: 4, h: 2 },
  { id: 'burning_skull',   ja: '燃えるドクロ (4×4)',           w: 4, h: 4 },
];

export interface PaintingSave {
  id: number;
  dimension: string;
  x: number;
  y: number;
  z: number;
  dir: number; // 0: +Z wall, 1: +X wall, 2: -Z wall, 3: -X wall
  motif: PaintingMotifId;
}

export interface PaintingInstance extends PaintingSave {
  w: number;
  h: number;
  group: THREE.Group;
}

function paintMotifCanvas(motif: PaintingMotifId, wBlocks: number, hBlocks: number) {
  const pw = wBlocks * 16, ph = hBlocks * 16;
  const cv = makeCanvas(pw, ph);
  const ctx = cv.getContext('2d')!;
  const R = (x: number, y: number, w: number, h: number, col: string) => {
    ctx.fillStyle = col;
    ctx.fillRect(Math.round(x), Math.round(y), Math.max(1, Math.round(w)), Math.max(1, Math.round(h)));
  };
  R(0, 0, pw, ph, '#4a3219');
  R(1, 1, pw - 2, ph - 2, '#7d562c');
  const cx = 2, cy = 2, cw = pw - 4, ch = ph - 4;

  if (motif === 'kebab') {
    R(cx, cy, cw, ch, '#2e5894');
    R(cx + 2, cy + 2, 8, 8, '#d49a4a');
    R(cx + 3, cy + 3, 6, 6, '#a8442a');
    R(cx + 2, cy + 8, 8, 2, '#4ca83b');
  } else if (motif === 'aztec') {
    R(cx, cy, cw, ch, '#d8c89e');
    R(cx, cy + 6, cw, ch - 6, '#b8a274');
    R(cx + 3, cy + 3, 6, 5, '#8c7852');
    R(cx + 5, cy + 2, 2, 2, '#547842');
  } else if (motif === 'creebet') {
    R(cx, cy, cw, ch * 0.35, '#5b9be0');
    R(cx, cy + ch * 0.35, cw, ch * 0.15, '#e89864');
    R(cx, cy + ch * 0.50, cw, ch * 0.50, '#24589c');
    R(cx + 4, cy + ch * 0.65, 10, 1, '#5894d8');
    R(cx + 2, cy + 3, 8, 5, '#6d7682');
    R(cx + 4, cy + 2, 4, 2, '#dce4ec');
    R(cx + 9, cy + 2, 9, 6, '#505864');
    R(cx + 11, cy + 1, 5, 2, '#e8eef4');
    R(cx + 18, cy + 3, 8, 8, '#50b444');
    R(cx + 19, cy + 4, 6, 6, '#64c856');
    R(cx + 19, cy + 5, 2, 2, '#141814');
    R(cx + 23, cy + 5, 2, 2, '#141814');
    R(cx + 21, cy + 7, 2, 2, '#141814');
    R(cx + 20, cy + 8, 4, 2, '#141814');
  } else if (motif === 'wanderer') {
    R(cx, cy, cw, ch * 0.5, '#b8d0e0');
    R(cx, cy + ch * 0.45, cw, ch * 0.35, '#8ca4b8');
    R(cx, cy + ch * 0.72, cw, ch * 0.28, '#384048');
    R(cx + 5, cy + 9, 2, 3, '#d8a888');
    R(cx + 4, cy + 12, 4, 9, '#1c2228');
  } else if (motif === 'skull_and_roses') {
    R(cx, cy, cw, ch * 0.55, '#121b30');
    for (const [sx, sy] of [[4, 3], [8, 6], [14, 2], [25, 9], [6, 11]]) R(cx + sx, cy + sy, 1, 1, '#d8e4ff');
    R(cx + 20, cy + 3, 5, 5, '#f4f0d8');
    R(cx + 22, cy + 5, 2, 2, '#d8d2b4');
    R(cx, cy + ch * 0.55, cw, ch * 0.45, '#193b32');
    R(cx, cy + ch * 0.55, cw, 2, '#28584a');
    R(cx + 9, cy + 8, 10, 8, '#d4d0c4');
    R(cx + 10, cy + 8, 8, 7, '#eceae0');
    R(cx + 11, cy + 11, 2, 2, '#16161c');
    R(cx + 15, cy + 11, 2, 2, '#16161c');
    R(cx + 13, cy + 13, 2, 2, '#323238');
    R(cx + 11, cy + 16, 6, 2, '#dedad0');
    for (const tx of [12, 14, 16]) R(cx + tx, cy + 16, 1, 2, '#8a867c');
    for (const rx of [3, 9, 15, 21]) {
      R(cx + rx, cy + 20, 4, 3, '#c82424');
      R(cx + rx + 1, cy + 20, 2, 2, '#f04848');
      R(cx + rx + 1, cy + 23, 1, 4, '#367c2b');
      R(cx + rx + 2, cy + 24, 2, 1, '#4ca63e');
    }
  } else if (motif === 'wither') {
    R(cx, cy, cw, ch, '#381818');
    R(cx, cy + 18, cw, ch - 18, '#6e482c');
    R(cx + 12, cy + 13, 4, 8, '#4f3824');
    R(cx + 8, cy + 13, 12, 4, '#4f3824');
    for (const sx of [8, 12, 16]) {
      R(cx + sx, cy + 9, 3, 3, '#222226');
      R(cx + sx + 1, cy + 10, 1, 1, '#58e8ff');
    }
  } else if (motif === 'fighters') {
    R(cx, cy, cw, ch, '#34241a');
    R(cx, cy + ch * 0.65, cw, ch * 0.35, '#6e4a2c');
    R(cx + 12, cy + 6, 8, 14, '#2b62a8');
    R(cx + 38, cy + 6, 8, 14, '#b8322c');
    R(cx + 14, cy + 3, 4, 4, '#e0b088');
    R(cx + 40, cy + 3, 4, 4, '#e0b088');
  } else {
    R(cx, cy, cw, ch, '#1c2438');
    R(cx + cw * 0.2, cy + ch * 0.35, cw * 0.6, ch * 0.55, '#d85818');
    R(cx + cw * 0.28, cy + ch * 0.42, cw * 0.44, ch * 0.42, '#f5a828');
    R(cx + cw * 0.32, cy + ch * 0.28, cw * 0.36, ch * 0.34, '#e8e4d4');
    R(cx + cw * 0.36, cy + ch * 0.36, cw * 0.08, ch * 0.08, '#1a1a1a');
    R(cx + cw * 0.54, cy + ch * 0.36, cw * 0.08, ch * 0.08, '#1a1a1a');
  }
  return cv;
}

export function buildPaintingMesh(motif: PaintingMotifId): { group: THREE.Group; w: number; h: number } {
  const spec = PAINTING_MOTIFS.find(m => m.id === motif) ?? PAINTING_MOTIFS[0];
  const w = spec.w, h = spec.h;
  const g = new THREE.Group();
  const s = 1 / 16;
  const oakBack = '#8f6b3c', frameOuter = '#4a3016', frameMid = '#6b4722', frameGold = '#d4a844';

  // 1px wooden canvas backing plate
  addBoxPart(g, oakBack, 0, 0.5, 0.435, w - 0.02, h - 0.02, 1 * s);
  // Multi-stepped 3D gallery frame moulding + corner medallions + museum brass plaque
  addBoxPart(g, frameOuter, 0, 0.5 + (h * 0.5 - 0.03), 0.418, w, 0.06, 1.5 * s);
  addBoxPart(g, frameOuter, 0, 0.5 - (h * 0.5 - 0.03), 0.418, w, 0.06, 1.5 * s);
  addBoxPart(g, frameOuter, -(w * 0.5 - 0.03), 0.5, 0.418, 0.06, h, 1.5 * s);
  addBoxPart(g, frameOuter, w * 0.5 - 0.03, 0.5, 0.418, 0.06, h, 1.5 * s);

  addBoxPart(g, frameMid, 0, 0.5 + (h * 0.5 - 0.055), 0.421, w - 0.06, 0.03, 1.35 * s);
  addBoxPart(g, frameMid, 0, 0.5 - (h * 0.5 - 0.055), 0.421, w - 0.06, 0.03, 1.35 * s);
  addBoxPart(g, frameMid, -(w * 0.5 - 0.055), 0.5, 0.421, 0.03, h - 0.06, 1.35 * s);
  addBoxPart(g, frameMid, w * 0.5 - 0.055, 0.5, 0.421, 0.03, h - 0.06, 1.35 * s);

  addBoxPart(g, frameGold, 0, 0.5 + (h * 0.5 - 0.075), 0.423, w - 0.12, 0.02, 1.25 * s);
  addBoxPart(g, frameGold, 0, 0.5 - (h * 0.5 - 0.075), 0.423, w - 0.12, 0.02, 1.25 * s);
  addBoxPart(g, frameGold, -(w * 0.5 - 0.075), 0.5, 0.423, 0.02, h - 0.12, 1.25 * s);
  addBoxPart(g, frameGold, w * 0.5 - 0.075, 0.5, 0.423, 0.02, h - 0.12, 1.25 * s);

  for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
    addBoxPart(g, frameGold, sx * (w * 0.5 - 0.035), 0.5 + sy * (h * 0.5 - 0.035), 0.410, 0.055, 0.055, 1.65 * s);
  }
  addBoxPart(g, '#e2be54', 0, 0.5 - (h * 0.5 - 0.03), 0.408, Math.min(0.22, w * 0.25), 0.035, 1.7 * s);

  const cv = paintMotifCanvas(motif, w, h);
  const tex = new THREE.CanvasTexture(cv as unknown as HTMLCanvasElement);
  tex.magFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  const artMat = new THREE.MeshLambertMaterial({ map: tex, color: '#ffffff' });
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(w - 0.14, h - 0.14), artMat);
  plane.position.set(0, 0.5, 0.398);
  plane.rotation.y = Math.PI;
  g.add(plane);

  return { group: g, w, h };
}

export class PaintingManager {
  paintings: PaintingInstance[] = [];
  private nextId = 1;
  private motifCursor = 0;
  private tmp = new THREE.Vector3();

  constructor(private scene: THREE.Scene) {}

  place(dimension: string, x: number, y: number, z: number, dir: number, motif?: PaintingMotifId): PaintingInstance {
    const chosen = motif ?? PAINTING_MOTIFS[this.motifCursor++ % PAINTING_MOTIFS.length].id;
    const { group, w, h } = buildPaintingMesh(chosen);
    const yaws = [0, -Math.PI / 2, Math.PI, Math.PI / 2];
    group.position.set(x + 0.5, y + (h - 1) * 0.5, z + 0.5);
    group.rotation.y = yaws[dir & 3] ?? 0;
    this.scene.add(group);
    const inst: PaintingInstance = {
      id: this.nextId++,
      dimension,
      x,
      y,
      z,
      dir: dir & 3,
      motif: chosen,
      w,
      h,
      group,
    };
    this.paintings.push(inst);
    return inst;
  }

  pick(dimension: string, origin: THREE.Vector3, dir: THREE.Vector3, reach = 4.6): PaintingInstance | null {
    let best: PaintingInstance | null = null, bestD = reach;
    for (const p of this.paintings) {
      if (p.dimension !== dimension) continue;
      this.tmp.set(p.x + 0.5, p.y + 0.5 + (p.h - 1) * 0.5, p.z + 0.5).sub(origin);
      const d = this.tmp.length();
      if (d > bestD) continue;
      if (this.tmp.normalize().dot(dir) < 0.85) continue;
      best = p;
      bestD = d;
    }
    return best;
  }

  remove(p: PaintingInstance) {
    this.scene.remove(p.group);
    const idx = this.paintings.indexOf(p);
    if (idx >= 0) this.paintings.splice(idx, 1);
  }

  syncDimension(currentDim: string) {
    for (const p of this.paintings) p.group.visible = p.dimension === currentDim;
  }

  clear() {
    for (const p of this.paintings) this.scene.remove(p.group);
    this.paintings = [];
  }

  save(): PaintingSave[] {
    return this.paintings.map(p => ({
      id: p.id,
      dimension: p.dimension,
      x: p.x,
      y: p.y,
      z: p.z,
      dir: p.dir,
      motif: p.motif,
    }));
  }

  load(list: PaintingSave[] | undefined) {
    this.clear();
    for (const s of list ?? []) {
      const inst = this.place(s.dimension || 'overworld', s.x, s.y, s.z, s.dir ?? 0, s.motif ?? 'creebet');
      inst.id = s.id ?? inst.id;
      this.nextId = Math.max(this.nextId, inst.id + 1);
    }
  }
}
