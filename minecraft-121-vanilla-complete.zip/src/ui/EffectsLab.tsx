import { useEffect, useRef, useState } from 'react';
import { ArrowDownToLine, ArrowLeft, ArrowUpRight, Check, ChevronRight, Move, Pause, Play, RotateCcw, Sparkles, Wind } from 'lucide-react';
import * as THREE from 'three';
import { Environment } from '../render/environment';
import { ParticleSystem, type VanillaParticleKind } from '../render/particles';
import { getTileTexture } from '../textures/atlas';
import { DEFAULT_SETTINGS, type Dimension } from '../game/types';
import { ID } from '../game/data';
import './effects-lab.css';

const EFFECTS: { id: VanillaParticleKind; ja: string; en: string; description: string; category: string }[] = [
  { id: 'crit', ja: 'クリティカルヒット', en: 'Critical hit', description: 'ヒットの瞬間に弾ける、温かい色のピクセルスター。', category: 'COMBAT' },
  { id: 'enchanted_hit', ja: 'エンチャントヒット', en: 'Enchanted hit', description: '魔力を帯びた一撃に、青白いクロス状の火花を。', category: 'COMBAT' },
  { id: 'mobSpell', ja: 'ポーションの渦', en: 'Potion spiral', description: '体を囲み、ゆっくり立ち上る効果色のスパイラル。', category: 'MAGIC' },
  { id: 'portal', ja: 'ポータル', en: 'Portal', description: '空間に漂い、中心へと吸い込まれる紫の粒子。', category: 'MAGIC' },
  { id: 'lava_pop', ja: '溶岩の火の粉', en: 'Lava pop', description: '溶岩の表面から跳ね上がり、重力に引かれる火の粉。', category: 'WORLD' },
  { id: 'drip_water', ja: '水のしずく', en: 'Water drip', description: '天井にたまり、落ちて、地面で弾ける一滴。', category: 'WORLD' },
  { id: 'drip_lava', ja: '溶岩のしずく', en: 'Lava drip', description: '暗い洞窟をほのかに照らす、熱を帯びた滴下。', category: 'WORLD' },
  { id: 'rain_splash', ja: '雨のしぶき', en: 'Rain splash', description: '雨が地面に触れた瞬間の、小さな青い水しぶき。', category: 'WEATHER' },
  { id: 'happy_villager', ja: '成長のきらめき', en: 'Happy villager', description: '骨粉、作物の成長、取引の成功に緑の輝きを。', category: 'WORLD' },
];
const WEATHER = [
  ['clear', '晴れ / Clear'], ['rain', '雨 / Rain'], ['snow', '雪原 / Snow'],
  ['basalt_deltas', '玄武岩の三角州 / Ash'], ['soul_sand_valley', 'ソウルサンドの谷 / Soul'],
  ['crimson_forest', '真紅の森 / Crimson'], ['warped_forest', '歪んだ森 / Warped'],
];

export function EffectsLab({ onClose, ja = true }: { onClose(): void; ja?: boolean }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const dialog = useRef<HTMLElement>(null);
  const reset = useRef<() => void>(() => {});
  const close = useRef(onClose); close.current = onClose;
  const [kind, setKind] = useState<VanillaParticleKind>('crit');
  const [weather, setWeather] = useState('clear');
  const [playing, setPlaying] = useState(true);
  const [sprinting, setSprinting] = useState(false);
  const [speed, setSpeed] = useState(false);
  const [bow, setBow] = useState(false);
  const [fov, setFov] = useState(58);
  const [error, setError] = useState('');
  const live = useRef({ kind, weather, playing, sprinting, speed, bow });
  live.current = { kind, weather, playing, sprinting, speed, bow };
  const effect = EFFECTS.find(e => e.id === kind)!;
  const t = (j: string, e: string) => ja ? j : e;

  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    dialog.current?.querySelector<HTMLButtonElement>('button')?.focus();
    const key = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); close.current(); }
      if (event.key === 'Tab') {
        const focusable = Array.from(dialog.current?.querySelectorAll<HTMLElement>('button, a, select, input') ?? []).filter(el => !el.hasAttribute('disabled'));
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    window.addEventListener('keydown', key, true);
    return () => { window.removeEventListener('keydown', key, true); previous?.focus(); };
  }, []);

  useEffect(() => {
    if (!canvas.current) return;
    const element = canvas.current;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ canvas: element, antialias: true, alpha: false }); }
    catch (e) { setError(String(e)); return; }
    renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(58, 1, 0.1, 600);
    const settings = { ...DEFAULT_SETTINGS, quality: 'medium' as const, distance: 4, bloom: false };
    const env = new Environment(scene, renderer, settings);
    const particles = new ParticleSystem(scene);
    env.attachWorld({ surfaceAt: () => ({ y: 0, solid: true }), biomeAt: () => live.current.weather === 'snow' ? 'snowy_plains' : 'plains' });
    const stage = new THREE.Group(); scene.add(stage);
    const cubeGeo = new THREE.BoxGeometry(1, 1, 1);
    const materials = new Map<string, THREE.MeshLambertMaterial>();
    const mat = (name: string, color = '#ffffff') => {
      const key = name + color;
      if (!materials.has(key)) materials.set(key, new THREE.MeshLambertMaterial({ map: name ? getTileTexture(name) : null, color }));
      return materials.get(key)!;
    };
    const block = (x: number, y: number, z: number, material: THREE.Material, sx = 1, sy = 1, sz = 1, parent = stage) => {
      const mesh = new THREE.Mesh(cubeGeo, material); mesh.position.set(x, y, z); mesh.scale.set(sx, sy, sz); parent.add(mesh); return mesh;
    };
    const grass = mat('grass_block'), dirt = mat('dirt'), stone = mat('stone_bricks');
    const ground = new THREE.InstancedMesh(cubeGeo, grass, 441);
    const placement = new THREE.Object3D();
    let groundIndex = 0;
    stage.add(ground);
    for (let x = -10; x <= 10; x++) for (let z = -10; z <= 10; z++) {
      placement.position.set(x, -0.55, z); placement.updateMatrix(); ground.setMatrixAt(groundIndex++, placement.matrix);
      if (Math.abs(x) < 3 && Math.abs(z) < 3) block(x, -0.04, z, stone, 1, 0.06, 1);
    }
    ground.instanceMatrix.needsUpdate = true;
    const snow = new THREE.Group(); stage.add(snow);
    const snowMat = mat('', '#edf4f3');
    const snowLayer = new THREE.InstancedMesh(cubeGeo, snowMat, 416); snow.add(snowLayer);
    let snowIndex = 0; placement.scale.set(1, 0.08, 1);
    for (let x = -10; x <= 10; x++) for (let z = -10; z <= 10; z++) if (Math.abs(x) > 2 || Math.abs(z) > 2) {
      placement.position.set(x, -0.02, z); placement.updateMatrix(); snowLayer.setMatrixAt(snowIndex++, placement.matrix);
    }
    snowLayer.instanceMatrix.needsUpdate = true;
    for (const [x, z] of [[-6, -6], [5, -7], [-8, 3], [8, 2]]) {
      block(x, 1.4, z, mat('oak_log'), 0.65, 2.9, 0.65);
      block(x, 3.5, z, mat('oak_leaves'), 3.1, 2.4, 3.1);
      block(x, 4.8, z, mat('oak_leaves'), 2.2, 0.8, 2.2);
    }
    const dummy = new THREE.Group(); stage.add(dummy);
    const oak = mat('oak_planks');
    block(0, 0.25, 0, mat('cobblestone'), 0.9, 0.5, 0.9, dummy);
    block(0, 0.9, 0, oak, 0.2, 1.1, 0.2, dummy);
    block(0, 1.55, 0, oak, 0.9, 0.9, 0.45, dummy);
    block(0, 2.22, 0, mat('birch_planks'), 0.6, 0.6, 0.6, dummy);
    block(0, 1.55, 0.24, mat('', '#d5dfb8'), 0.48, 0.48, 0.02, dummy);
    block(0, 1.55, 0.26, mat('', '#748b46'), 0.18, 0.18, 0.02, dummy);
    const ceiling = new THREE.Group(); stage.add(ceiling);
    block(0, 3.8, 0, stone, 2.2, 0.45, 1.8, ceiling);
    const lava = block(0, 0.03, 0, mat('lava'), 2, 0.12, 2);
    const plant = new THREE.Group(); stage.add(plant);
    block(0, 0.08, 0, dirt, 1.3, 0.25, 1.3, plant);
    block(0, 0.6, 0, mat('', '#74b245'), 0.14, 0.9, 0.14, plant);
    block(-0.25, 0.6, 0, mat('', '#a0cb58'), 0.5, 0.16, 0.35, plant);
    block(0.25, 0.8, 0, mat('', '#a0cb58'), 0.5, 0.16, 0.35, plant);
    const portal = new THREE.Group(); stage.add(portal);
    for (let x = -1; x <= 1; x++) for (let y = 0; y <= 3; y++) if (Math.abs(x) === 1 || y === 0 || y === 3) block(x * 0.8, y * 0.8 + 0.4, 0, mat('obsidian'), 0.8, 0.8, 0.65, portal);
    const portalMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 } }, side: THREE.DoubleSide,
      vertexShader: 'varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
      fragmentShader: 'varying vec2 vUv; uniform float uTime; void main(){vec2 p=floor(vUv*24.0)/24.0;float n=sin(p.x*23.0+sin(p.y*28.0+uTime)*2.0+uTime*1.2);gl_FragColor=vec4(mix(vec3(0.17,0.02,0.32),vec3(0.6,0.18,0.85),n*0.5+0.5),1.0);}',
    });
    const portalPlane = new THREE.Mesh(new THREE.PlaneGeometry(0.95, 1.8), portalMat); portalPlane.position.set(0, 1.6, 0); portal.add(portalPlane);
    const source = new THREE.Vector3(0, 1.55, 0);
    const floor = (_x: number, y: number, _z: number) => y < 0.01 ? ID.stone : 0;
    let elapsed = 0, last = performance.now(), emitter = 0, uiTimer = 0, charge = 0, raf = 0, yaw = 0.55, dragX: number | null = null;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const emit = () => {
      const kind = live.current.kind;
      source.set(0, kind.startsWith('drip_') ? 3.55 : kind === 'lava_pop' || kind === 'rain_splash' ? 0.12 : kind === 'happy_villager' ? 0.8 : 1.55, 0);
      const count = kind === 'mobSpell' || kind === 'portal' ? 3 : kind.startsWith('drip_') ? 1 : kind === 'lava_pop' ? 2 : 22;
      particles.emit(kind, kind === 'mobSpell' ? dummy.position : source, { count, phase: elapsed * 3, height: 2.7, radius: kind === 'portal' ? 1.7 : 0.65 });
    };
    reset.current = () => { particles.clear(); emitter = 10; };
    const api = { scene, camera, env, particles, emit, get kind() { return live.current.kind; } };
    (window as any).__effectsLab = api;
    const resize = () => { const r = element.getBoundingClientRect(); renderer.setSize(r.width, r.height, false); camera.aspect = r.width / Math.max(1, r.height); camera.updateProjectionMatrix(); };
    const observer = new ResizeObserver(resize); observer.observe(element); resize();
    const down = (event: PointerEvent) => { dragX = event.clientX; element.setPointerCapture(event.pointerId); };
    const move = (event: PointerEvent) => { if (dragX !== null) { yaw -= (event.clientX - dragX) * 0.008; dragX = event.clientX; } };
    const up = () => { dragX = null; };
    element.addEventListener('pointerdown', down); element.addEventListener('pointermove', move); element.addEventListener('pointerup', up); element.addEventListener('pointercancel', up);
    let previousKind = live.current.kind;
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, Math.max(0, (now - last) / 1000)); last = now;
      const state = live.current;
      if (state.kind !== previousKind) { reset.current(); previousKind = state.kind; }
      if (state.playing) elapsed += dt;
      const angle = yaw + (reduced ? 0 : Math.sin(elapsed * 0.17) * 0.045);
      camera.position.set(Math.sin(angle) * 8, 4.2, Math.cos(angle) * 8); camera.lookAt(0, 1.25, 0);
      charge = state.bow ? Math.min(1, charge + dt) : 0;
      env.updateFov(camera, dt, 58, { sprinting: state.sprinting, speedLevel: state.speed ? 2 : 0, bowCharge: charge });
      const nether = !['clear', 'rain', 'snow'].includes(state.weather);
      const dimension: Dimension = nether ? 'nether' : 'overworld';
      const biome = nether ? state.weather : state.weather === 'snow' ? 'snowy_plains' : 'plains';
      env.update(elapsed, 0.25, camera, dimension, settings, state.weather === 'rain' || state.weather === 'snow' ? 'rain' : 'clear', biome);
      snow.visible = state.weather === 'snow';
      const isDrip = state.kind.startsWith('drip_');
      ceiling.visible = isDrip; lava.visible = state.kind === 'lava_pop'; plant.visible = state.kind === 'happy_villager'; portal.visible = state.kind === 'portal';
      dummy.visible = !isDrip && !lava.visible && !plant.visible && !portal.visible && state.kind !== 'rain_splash';
      portalMat.uniforms.uTime.value = elapsed;
      if (state.playing) {
        emitter += dt;
        const period = state.kind === 'portal' || state.kind === 'mobSpell' ? 0.15 : isDrip ? 0.6 : state.kind === 'lava_pop' ? 0.28 : 1.05;
        if (emitter >= period) { emitter = 0; emit(); }
        particles.update(dt, floor, () => false, undefined, camera);
        env.rainSplashes(dt, camera, particles, dimension);
      }
      uiTimer += dt;
      if (uiTimer > 0.2) { uiTimer = 0; setFov(Math.round(camera.fov)); }
      renderer.render(scene, camera);
    };
    emit(); raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf); observer.disconnect();
      element.removeEventListener('pointerdown', down); element.removeEventListener('pointermove', move); element.removeEventListener('pointerup', up); element.removeEventListener('pointercancel', up);
      particles.dispose(); env.dispose(); cubeGeo.dispose(); portalPlane.geometry.dispose(); portalMat.dispose(); materials.forEach(m => m.dispose()); renderer.dispose();
      delete (window as any).__effectsLab;
    };
  }, []);

  return <div className="effects-backdrop">
    <section className="effects-dialog" ref={dialog} role="dialog" aria-modal="true" aria-labelledby="effects-title">
      <header className="effects-header">
        <button className="effects-back" onClick={onClose} aria-label={t('タイトルに戻る', 'Back to title')}><ArrowLeft size={19}/></button>
        <div><span className="effects-eyebrow">MINECRAFT / JAVA VISUALS</span><h1 id="effects-title">{t('パーティクルラボ', 'The Particle Lab')}<span>VISUAL UPDATE</span></h1></div>
        <a className="effects-download" href="/downloads/minecraft-java-visual-effects.zip" download><ArrowDownToLine size={17}/><span>{t('成果物 ZIP', 'Download ZIP')}</span></a>
      </header>
      <div className="effects-workspace">
        <aside className="effects-sidebar" aria-label={t('演出を選択', 'Choose an effect')}>
          <div className="effects-section-label"><Sparkles size={14}/>{t('小さな粒に、生きた世界を。', 'A little detail. A living world.')}</div>
          <div className="effects-list">{EFFECTS.map(item => <button key={item.id} className={kind === item.id ? 'is-selected' : ''} onClick={() => setKind(item.id)} aria-pressed={kind === item.id} data-effect={item.id}>
            <span className="effect-pixel"/><span><strong>{ja ? item.ja : item.en}</strong><small>{item.id}</small></span><ChevronRight size={14}/>
          </button>)}</div>
          <div className="effects-sidebar-note"><Check size={13}/><span>{t('ワールド生成は変更しません', 'World generation is untouched')}</span></div>
        </aside>
        <div className="effects-main">
          <div className="effects-toolbar"><label><Wind size={15}/><span>{t('大気環境', 'Atmosphere')}</span><select value={weather} onChange={e => setWeather(e.target.value)} aria-label={t('大気環境', 'Atmosphere')}>{WEATHER.map(([id, label]) => <option key={id} value={id}>{label}</option>)}</select></label><span className="effects-live"><i/>{playing ? 'LIVE PREVIEW' : 'PAUSED'}</span></div>
          <div className="effects-viewport">
            <canvas ref={canvas} aria-label={t('パーティクルのリアルタイム3Dプレビュー。ドラッグで回転。', 'Live 3D particle preview. Drag to orbit.')}/>
            {error && <div className="effects-error">WebGL: {error}</div>}
            <div className="effects-scene-caption"><span>{effect.category}</span><h2>{ja ? effect.ja : effect.en}</h2><p>{ja ? effect.description : 'Original pixel sprites and Java-inspired motion, rendered live.'}</p></div>
            <span className="effects-orbit-hint"><Move size={13}/>{t('ドラッグで視点を回転', 'Drag to look around')}</span>
          </div>
          <div className="effects-playback">
            <div className="effects-playback-buttons"><button onClick={() => setPlaying(!playing)} aria-label={playing ? t('一時停止', 'Pause') : t('再生', 'Play')}>{playing ? <Pause size={16}/> : <Play size={16}/>}</button><button onClick={() => reset.current()} aria-label={t('演出をリセット', 'Reset effect')}><RotateCcw size={16}/></button><span>{t('動的 FOV', 'Dynamic FOV')}</span></div>
            <div className="effects-fov-toggles">{[[sprinting, setSprinting, t('ダッシュ', 'Sprint')], [speed, setSpeed, 'Speed II'], [bow, setBow, t('弓を引く', 'Draw bow')]].map(([value, setter, label]) => <button key={String(label)} onClick={() => (setter as (v: boolean) => void)(!value)} aria-pressed={!!value} className={value ? 'active' : ''}>{value ? <Check size={12}/> : <span/>}{String(label)}</button>)}</div>
            <output aria-label="FOV" className="effects-fov-value">{fov}<small> FOV</small></output>
          </div>
        </div>
      </div>
      <footer className="effects-footer"><span><i/>{t('公式 Java Edition のビジュアルを参照した非公式実装', 'An unofficial implementation, informed by Java Edition visuals')}</span><a href="https://www.minecraft.net/en-us/article/nether-update-java" target="_blank" rel="noreferrer">{t('公式リファレンス', 'Official reference')}<ArrowUpRight size={13}/></a></footer>
    </section>
  </div>;
}