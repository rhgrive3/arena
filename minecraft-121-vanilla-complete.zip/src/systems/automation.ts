import type { Stack } from '../game/types';
import { resolve } from '../game/data';
import { matchGrid } from './crafting';

export function isShulkerBoxName(name: string): boolean {
  return name === 'shulker_box' || name.endsWith('_shulker_box');
}

export function insertStack(
  slots: (Stack | null)[],
  stack: Stack,
  disabled = 0,
  allowed?: number[],
  forbidShulker = false,
): boolean {
  if (forbidShulker && isShulkerBoxName(stack.name)) return false;
  const max = resolve(stack.name)?.stack ?? 64;
  const compatible = (s: Stack) =>
    s.name === stack.name &&
    s.label === stack.label &&
    JSON.stringify(s.ench) === JSON.stringify(stack.ench) &&
    s.durability === stack.durability;
  const canUse = (i: number) => !(disabled & (1 << i)) && (!allowed || allowed.includes(i));
  const i = slots.findIndex((s, idx) => canUse(idx) && s && compatible(s) && s.count + stack.count <= max);
  if (i >= 0) {
    slots[i]!.count += stack.count;
    return true;
  }
  const empty = slots.findIndex((s, idx) => !s && canUse(idx));
  if (empty < 0 || stack.count > max) return false;
  slots[empty] = { ...stack };
  return true;
}

export function transferOne(
  source: (Stack | null)[],
  destination: (Stack | null)[],
  disabled = 0,
  balanced = false,
  fromSideOrAllowed?: boolean | number[],
  allowedSrc?: number[],
  forbidShulker = false,
): boolean {
  if (source === destination) return false;
  // Wiki (Hopper): When pulling from a furnace (3 slots) into a hopper (5 slots), pull from output slot 2,
  // or from fuel slot 1 if an empty bucket remains there.
  const defaultFurnaceOut =
    source.length === 3 && destination.length === 5
      ? source[1]?.name === 'bucket'
        ? [2, 1]
        : [2]
      : source.map((_, i) => i);
  const srcIndices = allowedSrc ?? defaultFurnaceOut;
  const allowedDest: number[] | undefined = Array.isArray(fromSideOrAllowed)
    ? fromSideOrAllowed
    : destination.length === 3 && !balanced
    ? [fromSideOrAllowed ? 1 : 0]
    : undefined;

  // Wiki (Hopper): If the hopper is unable to pull/push from the first occupied slot (e.g. filter slots full of other items),
  // it scans subsequent source slots in order and transfers the first item that fits into destination.
  for (const srcIdx of srcIndices) {
    const stack = source[srcIdx];
    if (!stack || stack.count <= 0) continue;
    if (forbidShulker && isShulkerBoxName(stack.name)) continue;
    if (balanced) {
      const max = resolve(stack.name)?.stack ?? 64;
      const candidates = destination
        .map((s, j) => ({ s, j }))
        .filter(
          ({ s, j }) =>
            !(disabled & (1 << j)) &&
            (!allowedDest || allowedDest.includes(j)) &&
            (!s || (s.name === stack.name && s.count < max)),
        )
        .sort((a, b) => (a.s?.count ?? 0) - (b.s?.count ?? 0));
      if (!candidates.length) continue;
      const dest = candidates[0].j;
      if (destination[dest]) destination[dest]!.count++;
      else destination[dest] = { ...stack, count: 1 };
    } else if (!insertStack(destination, { ...stack, count: 1 }, disabled, allowedDest, forbidShulker)) {
      continue;
    }
    stack.count--;
    if (stack.count <= 0) source[srcIdx] = null;
    return true;
  }
  return false;
}

export function findCrafterRecipe(slots: (Stack | null)[], disabled = 0) {
  return matchGrid(slots.slice(0, 9).map(s => s?.name ?? null), disabled) ?? undefined;
}
