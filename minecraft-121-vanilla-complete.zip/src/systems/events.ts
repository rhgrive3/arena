/*
 * Gameplay event bus — the contract between the gameplay systems (this prompt) and the renderer / audio (prompt 1).
 *
 * Nothing in here draws. Systems publish what happened, with world coordinates and vanilla block-state style flags;
 * the renderer subscribes with `engine.gameplay.events.on(type, handler)` (or `'*'` for everything) and decides how to
 * show it (particles, model swaps, overlays, sounds).
 */
export type GameEventType =
  // player state
  | 'pose'                    // { pose, height, eyeHeight, forced }
  | 'use_start'               // { item, kind: 'eat' | 'drink', ticks }
  | 'use_tick'                // { item, kind, tick, total }          (every 4 ticks: bite / sip particles)
  | 'use_finish'              // { item, kind, food, saturation, returned }
  | 'use_cancel'              // { item, kind, tick }
  | 'freeze'                  // { ticksFrozen, progress, fullyFrozen }
  | 'bubble_column'           // { drag: boolean | null }             (null = left the column)
  // blocks
  | 'waterlogged'             // { x, y, z, waterlogged }
  | 'scaffolding'             // { x, y, z, distance, bottom }
  | 'scaffolding_collapse'    // { x, y, z, landedAt: [x, y, z] | null }
  | 'ender_chest_open' | 'ender_chest_close'
  | 'shulker_box_drop'        // { x, y, z, items }
  | 'chiseled_bookshelf'      // { x, y, z, slot, occupied: boolean[6], lastInteractedSlot }
  | 'campfire'                // { x, y, z, lit, signalFire, waterlogged, items }
  | 'campfire_smoke'          // { x, y, z, signalFire, height }
  | 'campfire_cooked'         // { x, y, z, slot, result }
  | 'cauldron'                // { x, y, z, content, level, color }
  | 'dripstone_drip'          // { x, y, z, fluid, tip: [x, y, z] }
  // redstone
  | 'vibration'               // { event, frequency, x, y, z }
  | 'vibration_travel'        // { from: [x, y, z], to: [x, y, z], ticks, frequency }
  | 'sculk_sensor'            // { x, y, z, phase: 'inactive' | 'active' | 'cooldown', power, frequency, calibrated }
  | 'target_hit'              // { x, y, z, power, ticks }
  | 'tripwire'                // { hook: [x, y, z], attached, powered }
  // minecarts
  | 'hopper_minecart_pull' | 'furnace_minecart_smoke' | 'tnt_minecart_primed' | 'tnt_minecart_explode';

export type GameEventDetail = Record<string, unknown>;
export interface GameEvent { type: GameEventType; detail: GameEventDetail; tick: number; }
type Handler = (event: GameEvent) => void;

export class EventBus {
  private handlers = new Map<string, Set<Handler>>();
  /** Last events (newest last) — handy for debugging overlays and for tests. */
  readonly recent: GameEvent[] = [];
  tick = 0;

  /** Subscribe to one event type or to `'*'`. Returns the unsubscribe function. */
  on(type: GameEventType | '*', handler: Handler): () => void {
    let set = this.handlers.get(type);
    if (!set) { set = new Set(); this.handlers.set(type, set); }
    set.add(handler);
    return () => { set!.delete(handler); };
  }

  emit(type: GameEventType, detail: GameEventDetail = {}) {
    const event: GameEvent = { type, detail, tick: this.tick };
    this.recent.push(event);
    if (this.recent.length > 96) this.recent.splice(0, this.recent.length - 96);
    for (const key of [type, '*']) {
      const set = this.handlers.get(key);
      if (set) for (const h of [...set]) { try { h(event); } catch { /* a broken listener must never stop the simulation */ } }
    }
  }

  last(type: GameEventType): GameEvent | undefined {
    for (let i = this.recent.length - 1; i >= 0; i--) if (this.recent[i].type === type) return this.recent[i];
    return undefined;
  }
  count(type: GameEventType) { return this.recent.reduce((n, e) => n + (e.type === type ? 1 : 0), 0); }
  clear() { this.recent.length = 0; }
}

/**
 * Sculk sensor frequencies (Java 1.20.2+ `VibrationSystem.FREQUENCIES`). A comparator behind an active sensor outputs
 * this value; a calibrated sensor only listens to the frequency equal to the signal strength at its input side.
 */
export const VIBRATION_FREQUENCY: Record<string, number> = {
  step: 1, swim: 1, flap: 1,
  projectile_land: 2, hit_ground: 2, splash: 2,
  item_interact_finish: 3, projectile_shoot: 3, instrument_play: 3,
  entity_action: 4, elytra_glide: 4, unequip: 4,
  entity_dismount: 5, equip: 5,
  entity_mount: 6, entity_interact: 6, shear: 6,
  entity_damage: 7,
  drink: 8, eat: 8,
  container_close: 9, block_close: 9, block_deactivate: 9, block_detach: 9,
  container_open: 10, block_open: 10, block_activate: 10, block_attach: 10, prime_fuse: 10, note_block_play: 10,
  block_change: 11,
  block_destroy: 12, fluid_pickup: 12,
  block_place: 13, fluid_place: 13,
  entity_place: 14, lightning_strike: 14, teleport: 14,
  entity_die: 15, explode: 15,
};
/** `#minecraft:ignore_vibrations_sneaking`: these are silent when the source is sneaking. */
export const SNEAK_SILENT = new Set(['step', 'swim', 'flap', 'hit_ground', 'projectile_shoot', 'item_interact_finish']);
export const SENSOR_RANGE = 8;
export const CALIBRATED_SENSOR_RANGE = 16;
/** Vanilla: max(1, 15 - floor(distance / range * 15)). */
export const sensorPower = (distance: number, range: number) => Math.max(1, 15 - Math.floor((distance / range) * 15));
