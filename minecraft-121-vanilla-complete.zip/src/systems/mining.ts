import type { BlockDef } from '../game/data';
import { isSlabBlock } from '../game/blockState';
import { CROPS, cropDrops } from './farming';

const MATERIALS:Record<string,{speed:number;level:number}>={
  wooden:{speed:2,level:1},golden:{speed:12,level:1},stone:{speed:4,level:2},copper:{speed:5,level:2},
  iron:{speed:6,level:3},diamond:{speed:8,level:4},netherite:{speed:9,level:5},
};
const toolCatCache = new Map<string, string>();
const toolLvlCache = new Map<string, number>();
const toolSpdCache = new Map<string, number>();

export function toolCategory(tool?:BlockDef):string{
  if(!tool)return '';
  const n=tool.name;
  let c=toolCatCache.get(n);
  if(c===undefined){
    c=n==='shears'?'shears':(/_(pickaxe|axe|shovel|hoe|sword)$/.exec(n)?.[1]??'');
    toolCatCache.set(n,c);
  }
  return c;
}

export function toolLevel(tool?:BlockDef):number{
  if(!tool)return 0;
  const n=tool.name;
  let l=toolLvlCache.get(n);
  if(l===undefined){
    const prefix=n.split('_')[0];
    l=MATERIALS[prefix]?.level??0;
    toolLvlCache.set(n,l);
  }
  return l;
}

export function canHarvest(block:BlockDef,tool?:BlockDef):boolean{
  if(!block.tier)return true;
  if(toolCategory(tool)!==block.tool)return false;
  return toolLevel(tool)>=block.tier;
}

/*
 * Breaking speed — Java Edition 1.21 (minecraft.wiki "Breaking"): the tool speed for the block (+ Efficiency level² + 1 when that
 * speed is above 1), × (1 + 0.2 × Haste), × Mining Fatigue (0.3, 0.09, 0.0027, 0.00081 — hard-coded per level, MC-279819),
 * × 0.2 with the head under water (Aqua Affinity removes it), ÷ 5 when not on the ground. Damage per tick = speed / hardness / 30
 * (/ 100 when the block cannot be harvested); ≥ 1 breaks instantly, otherwise the time is ceil(1 / damage) ticks.
 */
export const FATIGUE_MULTIPLIER = [1, 0.3, 0.09, 0.0027, 0.00081];
export interface BreakOptions {
  /** Efficiency level of the held tool. */
  efficiency?: number;
  onGround?: boolean;
  /** Haste / fatigue / under-water factor (survival.miningFactor gives the reciprocal). */
  speedMultiplier?: number;
  aquaAffinity?: boolean;
}
const SWORD_EFFICIENT_SET = new Set(['pumpkin','carved_pumpkin','jack_o_lantern','melon','melon_block','cocoa','vine','glow_lichen','moss_carpet','big_dripleaf','small_dripleaf','sweet_berry_bush','hanging_roots']);
/** Tool component speed for the block (1.21 Tool rules, incl. shears 15 / 5 / 2 and swords 15 on cobweb, 1.5 on plants). */
export function toolSpeed(block:BlockDef,tool?:BlockDef):number{
  const category=toolCategory(tool);
  if(!category)return 1;
  if(category==='shears'){
    if(block.name==='cobweb'||block.pattern==='leaves')return 15;
    if(block.pattern==='wool'||block.name.endsWith('_wool'))return 5;
    if(block.name==='vine'||block.name==='glow_lichen')return 2;
    return 1;
  }
  if(category==='sword'){
    if(block.name==='cobweb')return 15;
    if(block.pattern==='leaves'||block.pattern==='plant'||SWORD_EFFICIENT_SET.has(block.name))return 1.5;
    return 1;
  }
  if(category===block.tool&&tool){
    let s=toolSpdCache.get(tool.name);
    if(s===undefined){s=MATERIALS[tool.name.split('_')[0]]?.speed??1;toolSpdCache.set(tool.name,s);}
    return s;
  }
  return 1;
}
/** Block damage per game tick (≥ 1 = instant). 0 for unbreakable blocks. */
export function breakProgressPerTick(block:BlockDef,tool?:BlockDef,opts:BreakOptions={}):number{
  if(block.hardness<0||!Number.isFinite(block.hardness))return 0;
  if(block.hardness===0)return Infinity;
  if(block.name==='bamboo'&&toolCategory(tool)==='sword')return Infinity;   // BambooStalkBlock: swords always break it at once
  let speed=toolSpeed(block,tool);
  const eff=opts.efficiency??0;
  if(speed>1&&eff>0)speed+=eff*eff+1;
  speed*=opts.speedMultiplier??1;
  if(opts.onGround===false)speed/=5;
  return speed/block.hardness/(canHarvest(block,tool)?30:100);
}
/** Whole ticks to break the block (0 = instant, Infinity = unbreakable). */
export function breakTicks(block:BlockDef,tool?:BlockDef,opts:BreakOptions={}):number{
  const p=breakProgressPerTick(block,tool,opts);
  if(!(p>0))return Infinity;
  return p>=1?0:Math.ceil(1/p-1e-9);
}
/** Seconds to break the block: on the ground / in the air (×5) and with the head under water (×5 unless Aqua Affinity). */
export function miningTime(block:BlockDef,tool?:BlockDef,onGround=true,underwater=false,opts:BreakOptions={}):number{
  const water=underwater&&!opts.aquaAffinity?0.2:1;
  return breakTicks(block,tool,{...opts,onGround,speedMultiplier:(opts.speedMultiplier??1)*water})/20;
}

/** Mining state kept per player outside the Engine class: a 20 Hz stepper, the 5-tick delay after a break, start-tick handling. */
export interface MiningTicks { acc:number; delay:number; destroying:boolean; fresh:boolean; wasHeld:boolean }
const miningStates=new WeakMap<object,MiningTicks>();
export function miningStateOf(owner:object):MiningTicks{
  let m=miningStates.get(owner);
  if(!m)miningStates.set(owner,m={acc:0,delay:0,destroying:false,fresh:false,wasHeld:false});
  return m;
}

export function blockDrops(block:BlockDef,tool:BlockDef|undefined,state=0,rng=Math.random,fortune=0):{name:string;count:number}[]{
  if(block.name==='piston_head'||block.name==='moving_piston')return [];
  if(CROPS.has(block.name))return cropDrops(block.name,state,rng,fortune);
  if(!canHarvest(block,tool))return [];
  if(block.name==='spawner')return [];
  if(block.name==='melon_block'||block.name==='melon')return [{name:'melon_slice',count:Math.min(9,3+Math.floor(rng()*(5+fortune)))}];
  if(block.name==='copper_bulb_lit'||block.name==='lit_copper_bulb')return [{name:'copper_bulb',count:1}];
  if(block.name==='inverted_daylight_detector'||block.name==='daylight_detector_inverted')return [{name:'daylight_detector',count:1}];
  if(block.name==='farmland'||block.name==='farmland_moist')return [{name:'dirt',count:1}];
  if(block.name==='sweet_berry_bush')return state>=2?[{name:'sweet_berries',count:2+Math.floor(rng()*2)}]:state>=1?[{name:'sweet_berries',count:1}]:[];
  if(block.name==='glass'||block.name==='glass_pane'||block.name.endsWith('_stained_glass')||block.name.endsWith('_stained_glass_pane'))return [];
  if(block.name==='snow_block')return [{name:'snowball',count:4}];
  if(block.name==='gravel')return [{name:rng()<Math.min(1,0.1+fortune*0.14)?'flint':'gravel',count:1}];
  if(block.name==='glowstone')return [{name:'glowstone_dust',count:Math.min(4,2+Math.floor(rng()*(3+fortune)))}];
  if(block.name==='bookshelf')return [{name:'book',count:3}];
  if(block.name==='clay')return [{name:'clay_ball',count:4}];
  if(block.pattern==='leaves'){
    if(toolCategory(tool)==='shears')return [{name:block.name,count:1}];
    const out:{name:string;count:number}[]=[];
    const sapling=block.name.replace(/_leaves$/,'_sapling');
    if(rng()<0.07+fortune*0.02)out.push({name:sapling,count:1});
    if(rng()<0.04+fortune*0.01)out.push({name:'stick',count:1+Math.floor(rng()*2)});
    if((block.name==='oak_leaves'||block.name==='dark_oak_leaves')&&rng()<0.02+fortune*0.005)out.push({name:'apple',count:1});
    return out;
  }
  if(block.name==='short_grass'||block.name==='fern'||block.name==='tall_grass'||block.name==='large_fern'){
    if(toolCategory(tool)==='shears')return [{name:block.name,count:1}];
    return rng()<0.15?[{name:'wheat_seeds',count:1+Math.floor(rng()*(1+fortune*2))}]:[];
  }
  if(isSlabBlock(block)&&state===2)return [{name:block.drop||block.name,count:2}];
  const name=block.drop||block.name;
  let count=1;
  if(block.name==='lapis_ore'||block.name==='deepslate_lapis_ore')count=4+Math.floor(rng()*6);
  else if(block.name==='redstone_ore'||block.name==='deepslate_redstone_ore')count=4+Math.floor(rng()*2);
  else if(block.name==='copper_ore'||block.name==='deepslate_copper_ore')count=2+Math.floor(rng()*4);
  else if(block.name==='nether_gold_ore')count=2+Math.floor(rng()*5);
  return [{name,count}];
}

export function blockExperience(block:BlockDef):number{
  if(block.name==='coal_ore'||block.name==='deepslate_coal_ore'||block.name==='nether_gold_ore')return 1;
  if(block.name==='redstone_ore'||block.name==='deepslate_redstone_ore'||block.name==='lapis_ore'||block.name==='deepslate_lapis_ore'||block.name==='nether_quartz_ore')return 3;
  if(block.name==='diamond_ore'||block.name==='deepslate_diamond_ore'||block.name==='emerald_ore'||block.name==='deepslate_emerald_ore')return 5;
  if(block.name==='spawner')return 18;
  return 0;
}
