// Archaeology: brushing suspicious sand / gravel, the loot tables behind it, and decorated pots (one stack of one item type).
import { sherdItem, templateItem } from '../game/content121';
import type { Stack } from '../game/types';

export type ArchTable = 'desert_pyramid' | 'desert_well' | 'ocean_warm' | 'ocean_cold' | 'trail_common' | 'trail_rare';
const sherds = (...names: string[]): [string, number][] => names.map(n => [sherdItem(n), 1]);
/** [item, weight] — vanilla tables, with the three 1.21 sherds (flow / guster / scrape) folded into the rare trail-ruins table. */
export const ARCH_LOOT: Record<ArchTable, [string, number][]> = {
  desert_pyramid: [...sherds('archer', 'miner', 'prize', 'skull'), ['diamond', 1], ['tnt', 1], ['gunpowder', 1], ['emerald', 1]],
  desert_well: [[sherdItem('arms_up'), 2], [sherdItem('brewer'), 2], ['brick', 1], ['emerald', 1], ['stick', 1], ['mushroom_stew', 1]],
  ocean_warm: [...sherds('angler', 'shelter', 'snort'), ['iron_axe', 1], ['emerald', 2], ['wheat', 2], ['wooden_hoe', 2], ['coal', 2], ['gold_nugget', 2]],
  ocean_cold: [...sherds('blade', 'explorer', 'mourner', 'plenty'), ['iron_axe', 1], ['emerald', 2], ['wheat', 2], ['wooden_hoe', 2], ['coal', 2], ['gold_nugget', 2]],
  trail_common: [['emerald', 2], ['wheat', 2], ['wooden_hoe', 2], ['clay_ball', 2], ['brick', 2], ['yellow_dye', 2], ['blue_dye', 2], ['light_blue_dye', 2], ['white_dye', 2], ['orange_dye', 2], ['string', 1], ['coal', 2], ['wheat_seeds', 1], ['gold_nugget', 1], ['beetroot_seeds', 1], ['lead', 1]],
  trail_rare: [...sherds('burn', 'danger', 'friend', 'heart', 'heartbreak', 'howl', 'sheaf', 'flow', 'guster', 'scrape'), [templateItem('wayfinder'), 1], [templateItem('raiser'), 1], [templateItem('shaper'), 1], [templateItem('host'), 1], ['disc_fragment', 1]],
};

/** Which table a suspicious block rolls on, from the structure that owns it (null = a stray block, e.g. placed in creative). */
export function pickTable(block: string, structure: string | null, deep: boolean, coin: number): ArchTable {
  if (structure === 'ocean_ruin') return block === 'suspicious_sand' ? 'ocean_warm' : 'ocean_cold';
  if (structure === 'trail_ruins') return deep && coin < 0.45 ? 'trail_rare' : 'trail_common';
  if (block === 'suspicious_sand') return coin < 0.5 ? 'desert_pyramid' : 'desert_well';
  return coin < 0.2 ? 'trail_rare' : 'trail_common';
}
const mix = (seed: number) => { let h = Math.imul(seed ^ (seed >>> 15), 0x2c1b3c6d); h = Math.imul(h ^ (h >>> 12), 0x297a2d39); return ((h ^ (h >>> 15)) >>> 0) / 4294967296; };
export const positionSeed = (x: number, y: number, z: number, seed: number) => (Math.imul(x | 0, 73856093) ^ Math.imul(y | 0, 19349663) ^ Math.imul(z | 0, 83492791) ^ Math.imul(seed | 0, 1274126177)) | 0;
/** Deterministic weighted pick: the same block in the same world always hides the same item. */
export function archaeologyRoll(table: ArchTable, seed: number): string {
  const list = ARCH_LOOT[table];
  let total = 0;
  for (const [, w] of list) total += w;
  let r = mix(seed) * total;
  for (const [name, w] of list) { r -= w; if (r < 0) return name; }
  return list[list.length - 1][0];
}

/** Brushing takes four strokes; the block's cell state shows the dusted stage (1‥3) in between. */
export const BRUSH_STROKES = 4;
export const BRUSH_COOLDOWN = 0.4;
export class BrushSession {
  key = '';
  strokes = 0;
  private last = -Infinity;
  /** Registers one stroke on the block `key` at time `now`; returns the stroke count (BRUSH_STROKES = uncovered) or 0 if too soon. */
  stroke(key: string, now: number): number {
    if (key !== this.key) { this.key = key; this.strokes = 0; }
    else if (now - this.last < BRUSH_COOLDOWN) return 0;
    this.last = now;
    return ++this.strokes;
  }
  reset() { this.key = ''; this.strokes = 0; }
}

/**
 * Decorated pot: holds a single stack. Moves up to `amount` items of `held` into `slot` and returns the new pot content plus how many
 * were accepted, or null when the pot holds a different item or is already a full stack.
 */
export function potInsert(slot: Stack | null | undefined, held: Stack, maxStack: number, amount = 1): { slot: Stack; moved: number } | null {
  if (held.count <= 0) return null;
  if (slot && (slot.name !== held.name || slot.count >= maxStack)) return null;
  if (held.ench || held.durability !== undefined || held.label) { if (slot) return null; return { slot: { ...held, count: 1 }, moved: 1 }; }
  const moved = Math.min(amount, held.count, maxStack - (slot?.count ?? 0));
  return moved > 0 ? { slot: { name: held.name, count: (slot?.count ?? 0) + moved }, moved } : null;
}
