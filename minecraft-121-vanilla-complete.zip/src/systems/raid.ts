/*
 * Village raids — a port of Java Edition's Raid / Raids classes (1.21).
 *
 * Flow (Minecraft Wiki "Raid" + net.minecraft.world.entity.raid.Raid):
 *   Bad Omen -> (enter village) Raid Omen 30 s -> raid created at the village centre
 *   -> 300 tick "pre-raid" while the red boss bar charges (15 s) -> wave 1 … wave N
 *   -> every cleared wave: 300 tick cooldown, bar refills, a spawn point is searched 8 times every 5 ticks
 *      (64 blocks out, 32 blocks once < 100 ticks remain, right at the centre as a last resort)
 *   -> last wave dead: 40 ticks later "Raid - Victory", Hero of the Village (48 000 ticks, amplifier = omen level − 1)
 *   -> village wiped out: "Raid - Defeat" and the raiders celebrate; either way the raid object lives 600 more ticks
 *   -> 48 000 active ticks: the raid expires.
 *
 * Waves: Easy 3, Normal 5, Hard 7, plus one bonus wave (a copy of the last table column) when the omen level is ≥ II.
 * The boss bar shows the summed HEALTH of the living raiders over the wave's total health, and appends
 * "N raiders remaining" when two or fewer are left.
 */

export type RaidDifficulty = 'easy' | 'normal' | 'hard';
export type RaiderType = 'vindicator' | 'evoker' | 'pillager' | 'witch' | 'ravager';
export type RaidStatus = 'ongoing' | 'victory' | 'loss' | 'stopped';

/** Raid.RaiderType.spawnsPerWaveBeforeBonus — index = wave number (1-7), index 0 unused. Order = vanilla enum order. */
export const RAIDER_WAVES: Record<RaiderType, readonly number[]> = {
  vindicator: [0, 0, 2, 0, 1, 4, 2, 5],
  evoker: [0, 0, 0, 0, 0, 1, 1, 2],
  pillager: [0, 4, 3, 3, 4, 4, 4, 2],
  witch: [0, 0, 0, 0, 3, 0, 0, 1],
  ravager: [0, 0, 0, 1, 0, 1, 0, 2],
};
export const RAIDER_ORDER: readonly RaiderType[] = ['vindicator', 'evoker', 'pillager', 'witch', 'ravager'];

export const RAID = {
  preRaidTicks: 300, cooldownTicks: 300, postRaidTicks: 40, celebrateTicks: 600, timeoutTicks: 48000,
  heroTicks: 48000, raidOmenTicks: 600, joinRadius: 96, leaveRadius: 112, barRadius: 96, idleLeaveTicks: 2400,
  villageRadius: 32,
} as const;

export function numGroups(d: RaidDifficulty): number { return d === 'easy' ? 3 : d === 'normal' ? 5 : 7; }
export function asDifficulty(d: string | undefined): RaidDifficulty { return d === 'hard' || d === 'hardcore' ? 'hard' : d === 'normal' ? 'normal' : 'easy'; }

/** Raid.getDefaultNumSpawns */
export function defaultSpawns(type: RaiderType, wave: number, groups: number, bonusWave: boolean): number {
  return RAIDER_WAVES[type][bonusWave ? groups : wave] ?? 0;
}
/** Raid.getPotentialBonusSpawns */
export function bonusSpawns(type: RaiderType, wave: number, d: RaidDifficulty, bonusWave: boolean, rnd: () => number): number {
  const easy = d === 'easy', normal = d === 'normal';
  let l: number;
  switch (type) {
    case 'witch': if (easy || wave <= 2 || wave === 4) return 0; l = 1; break;
    case 'pillager': case 'vindicator': l = easy ? Math.floor(rnd() * 2) : normal ? 1 : 2; break;
    case 'ravager': l = !easy && bonusWave ? 1 : 0; break;
    default: return 0;
  }
  return l > 0 ? Math.floor(rnd() * (l + 1)) : 0;
}

export interface WaveEntry { type: RaiderType; rider?: RaiderType; leader?: boolean }

/** Raid.spawnGroup: the full roster of a wave, with ravager riders and the wave captain marked. */
export function composeWave(wave: number, d: RaidDifficulty, bonusWave: boolean, rnd: () => number = Math.random): WaveEntry[] {
  const out: WaveEntry[] = [];
  const groups = numGroups(d);
  let leaderSet = false;
  for (const type of RAIDER_ORDER) {
    const n = defaultSpawns(type, wave, groups, bonusWave) + bonusSpawns(type, wave, d, bonusWave, rnd);
    let k = 0;
    for (let i = 0; i < n; i++) {
      const e: WaveEntry = { type };
      if (!leaderSet && type !== 'witch' && type !== 'ravager') { e.leader = true; leaderSet = true; }   // only illagers carry the banner
      if (type === 'ravager') {
        if (wave === numGroups('normal')) e.rider = 'pillager';
        else if (wave >= numGroups('hard')) e.rider = k === 0 ? 'evoker' : 'vindicator';
        k++;
      }
      out.push(e);
    }
  }
  return out;
}
/** Number of mobs in a roster (riders count). */
export const waveSize = (w: WaveEntry[]) => w.reduce((n, e) => n + 1 + (e.rider ? 1 : 0), 0);

export interface RaiderRef { id: number; health: number; x: number; y: number; z: number; idleTicks?: number }

export interface RaidWorld {
  rnd(): number;
  difficulty(): string | undefined;
  /** Spawns one raider at the position and returns its id (and health) — null when it could not be placed. */
  spawnRaider(type: RaiderType, x: number, y: number, z: number, wave: number, leader: boolean, ridingId: number | null): { id: number; health: number } | null;
  /** Live data of a raider, or null once it is dead / gone. */
  raider(id: number): RaiderRef | null;
  /** Raid-capable mobs (illagers, witches, ravagers) that are not part of any raid yet, within the radius of the centre. */
  strays?(cx: number, cy: number, cz: number, radius: number): { id: number; health: number }[];
  /** Number of villagers (claimed POIs stand-in) within the radius of the point. */
  villagers(cx: number, cy: number, cz: number, radius: number): number;
  /** Centre of the nearest other village section within `radius`, used when the current section is wiped out. */
  nearestVillage?(cx: number, cy: number, cz: number, radius: number): [number, number, number] | null;
  /** Surface spawn height for a column, or null when raiders cannot stand there (glass, leaves, water, unloaded…). */
  spawnY(x: number, z: number): number | null;
  /** Is the position part of a village (raiders never spawn inside one unless there is no alternative)? */
  inVillage(x: number, y: number, z: number): boolean;
  onEvent?(e: RaidEvent, raid: Raid): void;
}
export type RaidEvent =
  | { type: 'start' } | { type: 'horn'; x: number; y: number; z: number; wave: number } | { type: 'wave'; wave: number; total: number; count: number }
  | { type: 'victory' } | { type: 'loss' } | { type: 'expired' } | { type: 'stopped' } | { type: 'celebrate'; raiders: number[] } | { type: 'moved' };

export interface RaidSave {
  center: [number, number, number]; omen: number; status: RaidStatus; started: boolean; active: boolean;
  groupsSpawned: number; numGroups: number; ticksActive: number; cooldown: number; postRaidTicks: number;
  totalHealth: number; celebrationTicks: number; members: number[]; heroes: boolean; difficulty: RaidDifficulty;
  /** Legacy fields kept so older UI / saves keep working. */
  wave: number; total: number; alive: number; timer: number; delay: number;
}

export class Raid implements RaidSave {
  center: [number, number, number];
  /** Raid Omen level that started the raid (1-5). */
  omen: number;
  status: RaidStatus = 'ongoing';
  started = false;
  active = true;
  groupsSpawned = 0;
  numGroups: number;
  difficulty: RaidDifficulty;
  ticksActive = 0;
  /** Raid.raidCooldownTicks */
  cooldown: number = RAID.preRaidTicks;
  postRaidTicks = 0;
  totalHealth = 0;
  celebrationTicks = 0;
  /** Raiders of the current wave. */
  members: number[] = [];
  /** The player dealt the killing blow to at least one raider (needed for Hero of the Village). */
  heroes = false;
  /** Boss bar fill, 0-1. */
  progress = 0;
  waveSpawnPos: [number, number, number] | null = null;
  private healthCache = 0;

  constructor(center: [number, number, number], omen: number, difficulty: RaidDifficulty) {
    this.center = [center[0], center[1], center[2]];
    this.omen = Math.max(1, Math.min(5, Math.floor(omen)));
    this.difficulty = difficulty;
    this.numGroups = numGroups(difficulty);
  }

  // ---- legacy aliases (HUD / saves written before the port)
  get wave() { return this.groupsSpawned; }
  get total() { return this.numGroups + (this.hasBonusWave ? 1 : 0); }
  get alive() { return this.members.length; }
  get timer() { return this.cooldown / 20; }
  get delay() { return this.cooldown / 20; }

  get hasBonusWave() { return this.omen > 1; }
  get isOver() { return this.status === 'victory' || this.status === 'loss'; }
  get stopped() { return this.status === 'stopped'; }
  private get finalWave() { return this.groupsSpawned === this.numGroups; }
  private get hasMoreWaves() { return this.hasBonusWave ? this.groupsSpawned < this.numGroups + 1 : !this.finalWave; }
  private get shouldSpawnBonusGroup() { return this.finalWave && this.hasBonusWave; }
  private get firstWaveSpawned() { return this.groupsSpawned > 0; }
  /** Chance for raiders to carry enchanted weapons: 10 % at Raid Omen II up to 75 % at V. */
  get enchantChance() { return [0, 0, 0.1, 0.25, 0.5, 0.75][this.omen] ?? 0; }

  /** Boss bar label, exactly like the in-game event names. */
  barName(): { en: string; ja: string } {
    if (this.status === 'victory') return { en: 'Raid - Victory', ja: '襲撃 - 勝利' };
    if (this.status === 'loss') return { en: 'Raid - Defeat', ja: '襲撃 - 敗北' };
    const n = this.members.length;
    if (this.started && this.firstWaveSpawned && n > 0 && n <= 2) return { en: `Raid - ${n} raiders remaining`, ja: `襲撃 - 残りの襲撃者: ${n}` };
    return { en: 'Raid', ja: '襲撃' };
  }

  /** A raider of this raid died; `byPlayer` when the player landed the kill. */
  onRaiderKilled(id: number, byPlayer: boolean) {
    const i = this.members.indexOf(id);
    if (i < 0) return;
    this.members.splice(i, 1);
    if (byPlayer) this.heroes = true;
  }

  stop(world?: RaidWorld) {
    if (this.status === 'stopped') return;
    this.active = false; this.status = 'stopped';
    world?.onEvent?.({ type: 'stopped' }, this);
  }

  private livingHealth(world: RaidWorld): number {
    let h = 0;
    for (const id of this.members) h += world.raider(id)?.health ?? 0;
    return h;
  }

  /** Raid.findRandomSpawnPos — proximity 0 = 64 blocks out, 1 = 32 blocks, 2 = at the centre (villages allowed). */
  findSpawnPos(world: RaidWorld, proximity: number, tries: number): [number, number, number] | null {
    const k = proximity === 0 ? 2 : 2 - proximity;
    for (let i = 0; i < tries; i++) {
      const f = world.rnd() * Math.PI * 2;
      const x = Math.floor(this.center[0]) + Math.floor(Math.cos(f) * 32 * k) + Math.floor(world.rnd() * 5);
      const z = Math.floor(this.center[2]) + Math.floor(Math.sin(f) * 32 * k) + Math.floor(world.rnd() * 5);
      const y = world.spawnY(x, z);
      if (y === null || Math.abs(y - this.center[1]) >= 96) continue;
      if (world.inVillage(x, y, z) && proximity < 2) continue;
      return [x + 0.5, y, z + 0.5];
    }
    return null;
  }
  /** The 8 attempts made every 5 ticks of the cooldown. */
  private validSpawnPos(world: RaidWorld, proximity: number): [number, number, number] | null {
    for (let j = 0; j < 8; j++) { const p = this.findSpawnPos(world, proximity, 1); if (p) return p; }
    return null;
  }

  private spawnGroup(world: RaidWorld, pos: [number, number, number]) {
    const wave = this.groupsSpawned + 1, bonus = this.shouldSpawnBonusGroup;
    this.totalHealth = 0;
    this.members = [];
    const roster = composeWave(wave, this.difficulty, bonus, () => world.rnd());
    for (const e of roster) {
      const ox = (world.rnd() - 0.5) * 3, oz = (world.rnd() - 0.5) * 3;
      const m = world.spawnRaider(e.type, pos[0] + ox, pos[1], pos[2] + oz, wave, !!e.leader, null);
      if (!m) continue;
      this.members.push(m.id); this.totalHealth += m.health;
      if (e.rider) {
        const r = world.spawnRaider(e.rider, pos[0] + ox, pos[1], pos[2] + oz, wave, false, m.id);
        if (r) { this.members.push(r.id); this.totalHealth += r.health; }
      }
    }
    // Illagers, witches and ravagers already around (patrols, eggs…) join when the wave spawns.
    for (const s of world.strays?.(this.center[0], this.center[1], this.center[2], RAID.joinRadius) ?? []) {
      if (!this.members.includes(s.id)) { this.members.push(s.id); this.totalHealth += s.health; }
    }
    this.waveSpawnPos = null;
    this.groupsSpawned++;
    this.healthCache = this.totalHealth;
    this.progress = 1;
    world.onEvent?.({ type: 'horn', x: pos[0], y: pos[1], z: pos[2], wave }, this);
    world.onEvent?.({ type: 'wave', wave, total: this.total, count: this.members.length }, this);
  }

  /** Raid.tick — call once per game tick. */
  tick(world: RaidWorld) {
    if (this.status === 'stopped') return;
    if (this.status === 'ongoing') {
      this.active = true;
      if (asDifficulty(world.difficulty()) !== this.difficulty && world.difficulty() === 'peaceful') { this.stop(world); return; }
      if (world.difficulty() === 'peaceful') { this.stop(world); return; }
      // The village is gone: move to a neighbouring section or lose.
      if (world.villagers(this.center[0], this.center[1], this.center[2], RAID.villageRadius) === 0) {
        const next = world.nearestVillage?.(this.center[0], this.center[1], this.center[2], RAID.villageRadius * 2) ?? null;
        if (next) { this.center = [next[0], next[1], next[2]]; world.onEvent?.({ type: 'moved' }, this); }
        else if (this.groupsSpawned > 0) { this.status = 'loss'; world.onEvent?.({ type: 'loss' }, this); world.onEvent?.({ type: 'celebrate', raiders: [...this.members] }, this); return; }
        else { this.stop(world); return; }
      }
      if (++this.ticksActive >= RAID.timeoutTicks) { world.onEvent?.({ type: 'expired' }, this); this.stop(world); return; }

      // Drop dead / unloaded raiders, and every 20 ticks the ones that strayed too far or idled for 2 minutes.
      const far = this.ticksActive % 20 === 0;
      for (let i = this.members.length - 1; i >= 0; i--) {
        const r = world.raider(this.members[i]);
        if (!r) { this.members.splice(i, 1); continue; }
        if (far) {
          const d2 = (r.x - this.center[0]) ** 2 + (r.y - this.center[1]) ** 2 + (r.z - this.center[2]) ** 2;
          if (d2 >= RAID.leaveRadius ** 2 || (r.idleTicks ?? 0) > RAID.idleLeaveTicks) this.members.splice(i, 1);
        }
      }
      const living = this.members.length;
      const moreWaves = this.hasMoreWaves;

      if (living === 0 && moreWaves) {
        if (this.cooldown > 0) {
          const has = this.waveSpawnPos !== null;
          if (!has && this.cooldown % 5 === 0) {
            const proximity = this.cooldown < 40 ? 2 : this.cooldown < 100 ? 1 : 0;
            this.waveSpawnPos = this.validSpawnPos(world, proximity);
          }
          this.cooldown--;
          this.progress = Math.max(0, Math.min(1, (300 - this.cooldown) / 300));
        } else if (this.cooldown === 0 && this.groupsSpawned > 0) {
          this.cooldown = RAID.cooldownTicks;
          this.progress = 0;
          return;
        }
      }
      if (living > 0) {
        const h = this.livingHealth(world);
        // The bar only ever goes down within a wave (it updates on damage, never on healing).
        this.healthCache = Math.min(this.healthCache, h);
        this.progress = this.totalHealth > 0 ? Math.max(0, Math.min(1, this.healthCache / this.totalHealth)) : 0;
      }

      // Time to spawn the next group?
      const shouldSpawn = this.cooldown === 0 && (this.groupsSpawned < this.numGroups || this.shouldSpawnBonusGroup) && living === 0;
      if (shouldSpawn) {
        let pos = this.waveSpawnPos;
        // 6 last-resort groups of 20 locations, right next to the centre.
        for (let g = 0; g < 6 && !pos; g++) pos = this.findSpawnPos(world, 2, 20);
        if (pos) {
          if (!this.started) { this.started = true; world.onEvent?.({ type: 'start' }, this); }
          this.spawnGroup(world, pos);
        } else { this.stop(world); return; }      // no place to spawn at all: the raid ends without counting as a victory
      }

      if (this.started && !moreWaves && this.members.length === 0) {
        if (this.postRaidTicks < RAID.postRaidTicks) this.postRaidTicks++;
        else { this.status = 'victory'; this.progress = 0; world.onEvent?.({ type: 'victory' }, this); }
      }
    }
    if (this.isOver) {
      this.celebrationTicks++;
      if (this.celebrationTicks >= RAID.celebrateTicks) { this.stop(world); return; }
      if (this.status === 'loss' && this.celebrationTicks % 20 === 0) world.onEvent?.({ type: 'celebrate', raiders: [...this.members] }, this);
    }
  }

  save(): RaidSave {
    return {
      center: [...this.center] as [number, number, number], omen: this.omen, status: this.status, started: this.started, active: this.active,
      groupsSpawned: this.groupsSpawned, numGroups: this.numGroups, ticksActive: this.ticksActive, cooldown: this.cooldown,
      postRaidTicks: this.postRaidTicks, totalHealth: this.totalHealth, celebrationTicks: this.celebrationTicks, members: [...this.members],
      heroes: this.heroes, difficulty: this.difficulty, wave: this.wave, total: this.total, alive: this.alive, timer: this.timer, delay: this.delay,
    };
  }
  static load(s: Partial<RaidSave> & { center: [number, number, number] }, fallback: RaidDifficulty = 'easy'): Raid {
    const r = new Raid(s.center, s.omen ?? 1, s.difficulty ?? fallback);
    r.status = s.status ?? 'ongoing';
    r.groupsSpawned = s.groupsSpawned ?? s.wave ?? 0;
    r.started = s.started ?? r.groupsSpawned > 0;
    r.numGroups = s.numGroups ?? r.numGroups;
    r.ticksActive = s.ticksActive ?? 0;
    r.cooldown = s.cooldown ?? (r.groupsSpawned > 0 ? 0 : RAID.preRaidTicks);
    r.postRaidTicks = s.postRaidTicks ?? 0;
    r.totalHealth = s.totalHealth ?? 0;
    r.celebrationTicks = s.celebrationTicks ?? 0;
    r.members = [...(s.members ?? [])];
    r.heroes = !!s.heroes;
    r.healthCache = r.totalHealth;
    return r;
  }
}

/** Can a raid start here? (Java: never in the Nether, never on Peaceful, not with the raids game rule off.) */
export function canStartRaid(dimension: string, difficulty: string | undefined, gameruleRaids = true): boolean {
  return dimension !== 'nether' && difficulty !== 'peaceful' && gameruleRaids;
}
