// 1.21 combat maths: the mace and its three enchantments (Density, Breach, Wind Burst), mob armor, and the constants of the four
// new status effects (Wind Charged, Infested, Oozing, Weaving). Pure functions only, shared by survival.ts, the mob manager and tests.

// ---- Mace --------------------------------------------------------------------------------------------------------------
/** Extra smash damage for a fall of `fall` blocks: +4 for each of the first 3, +2 for the next 5, +1 for every block after. */
export const maceSmashBonus = (fall: number) => Math.min(fall, 3) * 4 + Math.min(Math.max(fall - 3, 0), 5) * 2 + Math.max(0, fall - 8);
/** Density: +0.5 damage per level for every block fallen. */
export const densityBonus = (level: number, fall: number) => 0.5 * Math.max(0, level) * Math.max(0, fall);
export const SMASH_MIN_FALL = 1.5;
export const smashDamage = (fall: number, density = 0) => (fall > SMASH_MIN_FALL ? maceSmashBonus(fall) + densityBonus(density, fall) : 0);

/**
 * Breach (Java 1.21 enchantment `armor_effectiveness: add −0.15 per level`): it lowers the *fraction of damage the armour
 * absorbs* by 0.15 per level (CombatRules.getDamageAfterAbsorb clamps the result to 0‥1) — it does not scale armour points.
 */
export const BREACH_PER_LEVEL = 0.15;
/** Kept for callers / tests: the armour-effectiveness offset of a Breach level (0, −0.15, −0.30 …). */
export const breachFactor = (level: number) => -BREACH_PER_LEVEL * Math.max(0, level);
/** Vanilla armor formula → fraction of the damage the armour absorbs (0‥0.8). */
export function armorAbsorbed(damage: number, armor: number, toughness = 0) {
  return Math.min(20, Math.max(armor / 5, armor - (4 * damage) / (toughness + 8))) / 25;
}
/** Vanilla armor formula → fraction of the damage that gets through. */
export function armorMultiplier(damage: number, armor: number, toughness = 0) {
  return 1 - armorAbsorbed(damage, armor, toughness);
}
export function damageAfterArmor(damage: number, armor: number, breachLevel = 0, toughness = 0) {
  if (armor <= 0) return damage;
  const absorbed = Math.min(1, Math.max(0, armorAbsorbed(damage, armor, toughness) + breachFactor(breachLevel)));
  return damage * (1 - absorbed);
}
/** Natural armor points of mobs (Java 1.21 attribute defaults). Magma cubes get 3 × size via `mobArmor`. */
export const MOB_ARMOR: Record<string, number> = {
  zombie: 2, husk: 2, drowned: 2, zombie_villager: 2, zombified_piglin: 2, wither: 4, shulker: 20, killer_bunny: 8,
};
/**
 * Ominous trial spawner equipment (minecraft.wiki "Ominous Trial Spawner"): a helmet + chestplate set — chainmail 4/7, iron 2/7,
 * diamond 1/7 — each piece missing half of the time; melee mobs hold an iron sword (4/7), iron sword Sharpness I (1/7), iron
 * sword Knockback I (1/7) or a diamond sword (1/7); ranged mobs a bow (plain 2/4, Power I 1/4, Punch I 1/4).
 * Returned as armour points / toughness / extra melee damage, since mobs here have no visible equipment slots.
 */
export interface OminousGear { armor: number; toughness: number; weapon: number; weaponName: string }
export function ominousEquipment(rng: () => number, ranged: boolean): OminousGear {
  const r = rng() * 7, set = r < 4 ? 'chainmail' : r < 6 ? 'iron' : 'diamond';
  const pts = set === 'chainmail' ? [2, 5] : set === 'iron' ? [2, 6] : [3, 8];
  let armor = 0, toughness = 0;
  for (const p of pts) if (rng() >= 0.5) { armor += p; if (set === 'diamond') toughness += 2; }
  if (ranged) { const b = rng() * 4; return { armor, toughness, weapon: 0, weaponName: b < 2 ? 'bow' : b < 3 ? 'bow_power_1' : 'bow_punch_1' }; }
  const w = rng() * 7;
  // Mob attack damage = base + weapon modifier: iron sword +5, Sharpness I +1, diamond sword +6.
  return w < 4 ? { armor, toughness, weapon: 5, weaponName: 'iron_sword' } : w < 5 ? { armor, toughness, weapon: 6, weaponName: 'iron_sword_sharpness_1' }
    : w < 6 ? { armor, toughness, weapon: 5, weaponName: 'iron_sword_knockback_1' } : { armor, toughness, weapon: 6, weaponName: 'diamond_sword' };
}
/** @deprecated use ominousEquipment */
export const ominousArmorSet = (rng: () => number) => ominousEquipment(rng, false).armor;
export const mobArmor = (species: string, bonus = 0, size = 0) => (species === 'magma_cube' ? 3 * size : MOB_ARMOR[species] ?? 0) + bonus;

/** Wind Burst (minecraft.wiki "Wind Burst"): a landed smash launches the attacker ≈ 8 blocks per level (I 8, II 16, III 24);
 *  the blast's knockback multiplier is 1.2 / 1.75 / 2.2, then 1.15 + 0.35 × level. */
export const PLAYER_GRAVITY = 24;
export const WIND_BURST_HEIGHT = 8;
export const WIND_BURST_RADIUS = 3.5;
export const windBurstMultiplier = (level: number) => (level <= 0 ? 0 : level === 1 ? 1.2 : level === 2 ? 1.75 : level === 3 ? 2.2 : 1.15 + 0.35 * level);
/** Peak height of a jump starting at `v` blocks/tick under the player's vanilla motion (y += vy; vy = (vy − 0.08) × 0.98). */
function apex(v: number) { let y = 0, top = 0; for (let i = 0; i < 400 && v > -0.5; i++) { y += v; if (y > top) top = y; v = (v - 0.08) * 0.98; } return top; }
/** Launch speed in blocks/second that reaches 8 × level blocks with the real player physics (`gravity` kept for old callers). */
export const windBurstVelocity = (level: number, _gravity = PLAYER_GRAVITY) => {
  if (level <= 0) return 0;
  const h = WIND_BURST_HEIGHT * level;
  let lo = 0, hi = 10;
  for (let i = 0; i < 40; i++) { const mid = (lo + hi) / 2; if (apex(mid) < h) lo = mid; else hi = mid; }
  return hi * 20;
};
/** Displacement applied to something at (tx,ty,tz) by a wind burst at (cx,cy,cz); null when out of range. */
export function windKnockback(cx: number, cy: number, cz: number, tx: number, ty: number, tz: number, radius = WIND_BURST_RADIUS, power = 1): [number, number, number] | null {
  const dx = tx - cx, dy = ty - cy, dz = tz - cz, d = Math.hypot(dx, dy, dz);
  if (d > radius) return null;
  const f = (1 - d / radius) * 2.2 * power + 0.6 * power, h = Math.hypot(dx, dz) || 1;
  return [(dx / h) * f, 0.5 * f, (dz / h) * f];
}

// ---- Status effects ----------------------------------------------------------------------------------------------------
export const EFFECTS_121 = ['wind_charged', 'infested', 'oozing', 'weaving'] as const;
export type Effect121 = (typeof EFFECTS_121)[number];
/** Infested: 10 % chance per hit to release 1–2 silverfish. */
export const INFESTED_CHANCE = 0.1;
export const infestedCount = (rng: () => number) => 1 + (rng() < 0.5 ? 1 : 0);
/** Oozing: two slimes on death. */
export const OOZING_SLIMES = 2;
/** Weaving: 2–3 cobwebs on death, and the holder is slowed only to 50 % in cobwebs instead of 25 %. */
export const weavingCount = (rng: () => number) => 2 + Math.floor(rng() * 2);
export const COBWEB_SLOW = 0.25;
export const COBWEB_SLOW_WEAVING = 0.5;
export const cobwebSpeedFactor = (inWeb: boolean, weaving: boolean) => (!inWeb ? 1 : weaving ? COBWEB_SLOW_WEAVING : COBWEB_SLOW);
export const WIND_CHARGED_RADIUS = 3;

/** Picks up to `count` free cells around (x,y,z) (the cell itself first, then a shuffled 3×3×2 neighbourhood) for cobwebs. */
export function cobwebSpots(isFree: (x: number, y: number, z: number) => boolean, x: number, y: number, z: number, count: number, rng: () => number): [number, number, number][] {
  const bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z), cells: [number, number, number][] = [];
  for (let dy = 0; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (dx || dy || dz) cells.push([bx + dx, by + dy, bz + dz]);
  for (let i = cells.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [cells[i], cells[j]] = [cells[j], cells[i]]; }
  cells.unshift([bx, by, bz]);
  const out: [number, number, number][] = [];
  for (const c of cells) { if (out.length >= count) break; if (isFree(c[0], c[1], c[2])) out.push(c); }
  return out;
}

// ---- Charged creepers ---------------------------------------------------------------------------------------------------
export const CREEPER_RADIUS = 3;
export const CHARGED_POWER = 2;
export const creeperRadius = (charged: boolean) => CREEPER_RADIUS * (charged ? CHARGED_POWER : 1);
/** Explosion damage at distance `d` from a blast of power `r` in open air — the same Java formula the engine uses for the player
 *  (systems/explosion.ts): impact = 1 − d / 2r, damage = (impact² + impact) / 2 × 7 × 2r + 1; 0 beyond 2r. */
export const explosionDamage = (r: number, d: number) => {
  if (d >= r * 2) return 0;
  const i = 1 - d / (r * 2);
  return Math.floor((i * i + i) / 2 * 7 * (r * 2) + 1);
};
export const MOB_HEADS: Record<string, string> = { zombie: 'zombie_head', skeleton: 'skeleton_skull', creeper: 'creeper_head', wither_skeleton: 'wither_skeleton_skull', piglin: 'piglin_head' };
export const LIGHTNING_CHARGE_RADIUS = 4;
