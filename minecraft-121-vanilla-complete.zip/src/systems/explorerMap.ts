// Explorer maps: a time-sliced nearest-structure search and the cartographer's map trades.
//
// Finding the nearest ocean monument / woodland mansion can mean evaluating hundreds of placement regions (each a handful of terrain
// height samples), far too much for one frame. `searchStructure` therefore walks the regions ring by ring inside a generator and
// only runs it for a few milliseconds at a time, yielding back to the browser (requestIdleCallback / setTimeout) between slices.
import type { Terrain } from '../world/terrain';
import { regionSize, siteAt } from '../world/structures';
import type { Stack } from '../game/types';

export type MapKind = 'monument' | 'mansion' | 'buried_treasure' | 'trial_chambers';
export interface MapSpec { kind: MapKind; item: string; ja: string; en: string; /** target icon drawn on the map */ icon: string; /** villager level that unlocks the trade */ level: number; cost: number; xp: number }
export const EXPLORER_MAPS: MapSpec[] = [
  { kind: 'monument', item: 'ocean_explorer_map', ja: '海洋探検家の地図', en: 'Ocean Explorer Map', icon: 'monument', level: 2, cost: 13, xp: 5 },
  { kind: 'mansion', item: 'woodland_explorer_map', ja: '森林探検家の地図', en: 'Woodland Explorer Map', icon: 'mansion', level: 3, cost: 14, xp: 10 },
  { kind: 'trial_chambers', item: 'trial_explorer_map', ja: '試練の探検家の地図', en: 'Trial Explorer Map', icon: 'trial_chambers', level: 3, cost: 12, xp: 10 },
  { kind: 'buried_treasure', item: 'buried_treasure_map', ja: '埋もれた宝の地図', en: 'Buried Treasure Map', icon: 'red_x', level: 4, cost: 12, xp: 15 },
];
export const mapSpecOf = (item: string) => EXPLORER_MAPS.find(m => m.item === item);
export interface MapData { kind: string; x: number; z: number; icon: string }
export const mapStack = (spec: MapSpec, x: number, z: number): Stack => ({ name: spec.item, count: 1, label: spec.ja, map: { kind: spec.kind, x, z, icon: spec.icon } });

export type Found = [number, number, number] | null;
/**
 * Walks the placement regions around (px, pz) in growing square rings, yielding after every region so the caller can pause.
 * Once a site has been found the search stops as soon as no farther ring could contain a closer one.
 */
export function* ringSearch(t: Terrain, kind: string, px: number, pz: number, maxRings = 14): Generator<void, Found, void> {
  const region = regionSize(kind, t.dimension);
  if (!region) return null;
  const crx = Math.floor(px / region), crz = Math.floor(pz / region);
  let best: Found = null, bestD = Infinity;
  for (let r = 0; r <= maxRings; r++) {
    for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
      const p = siteAt(t, kind, crx + dx, crz + dz);
      if (p) { const d = Math.hypot(p.x - px, p.z - pz); if (d < bestD) { bestD = d; best = [p.x, p.y, p.z]; } }
      yield;
    }
    if (best && bestD <= r * region) break;                       // every site in ring r+1 and beyond is at least r·region away
  }
  return best;
}

export interface SearchOptions {
  maxRings?: number;
  /** Time budget of one slice in milliseconds. */
  budgetMs?: number;
  /** How the next slice is scheduled. Default: one slice per ~16 ms timer tick, so slices never run back to back. */
  schedule?: (fn: () => void) => void;
  now?: () => number;
}
export interface SearchJob { promise: Promise<Found>; cancel(): void; regionsScanned: number; slices: number; /** longest single slice so far, in ms */ maxSliceMs: number; done: boolean }
const paced = (fn: () => void) => { setTimeout(fn, 16); };
/** Searches are serialized: several map trades unlocking at once still cost at most one slice per tick. */
let chain: Promise<unknown> = Promise.resolve();

/**
 * Starts a background search for the nearest `kind`. The work is cut into slices of `budgetMs` (4 ms by default; one placement
 * region costs 0.1–2 ms) with a timer tick between slices, so the main thread is never blocked for longer than a fraction of a frame.
 */
export function searchStructure(t: Terrain, kind: string, px: number, pz: number, opts: SearchOptions = {}): SearchJob {
  const budget = opts.budgetMs ?? 4, schedule = opts.schedule ?? paced;
  const now = opts.now ?? (() => (typeof performance !== 'undefined' ? performance.now() : Date.now()));
  const gen = ringSearch(t, kind, px, pz, opts.maxRings ?? 14);
  let cancelled = false;
  const job: SearchJob = { promise: Promise.resolve(null), cancel() { cancelled = true; }, regionsScanned: 0, slices: 0, maxSliceMs: 0, done: false };
  const run = () => new Promise<Found>(resolve => {
    const step = () => {
      if (cancelled) { job.done = true; resolve(null); return; }
      job.slices++;
      const start = now();
      for (;;) {
        const r = gen.next();
        if (r.done) { job.maxSliceMs = Math.max(job.maxSliceMs, now() - start); job.done = true; resolve(r.value); return; }
        job.regionsScanned++;
        if (now() - start >= budget) break;
      }
      job.maxSliceMs = Math.max(job.maxSliceMs, now() - start);
      schedule(step);
    };
    schedule(step);
  });
  const queued = chain.then(run, run);
  chain = queued.catch(() => null);
  job.promise = queued;
  return job;
}

const COMPASS_JA = ['北', '北東', '東', '南東', '南', '南西', '西', '北西'], COMPASS_EN = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
/** Distance and 8-way compass heading from the player to the map target (−z is north, +x is east). */
export function describeTarget(px: number, pz: number, x: number, z: number) {
  const dx = x - px, dz = z - pz, distance = Math.round(Math.hypot(dx, dz));
  const i = ((Math.round(Math.atan2(dx, -dz) / (Math.PI / 4)) % 8) + 8) % 8;
  return { distance, ja: COMPASS_JA[i], en: COMPASS_EN[i] };
}
