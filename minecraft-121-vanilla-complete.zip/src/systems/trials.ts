// Trial spawners & vaults (1.21). Pure game logic: no three.js, no DOM — the engine supplies a small host (see game/world121.ts)
// and the headless tests supply a stub. Nothing here scans the world: only blocks that were registered (chunk scan / placement)
// are ticked, at 4 Hz, so the cost is O(registered spawners) and independent of render distance.
import type { SpawnerKind } from '../world/dungeons';
import type { GameEvents, SpawnerPhase, VaultPhase } from '../game/events';
import { ENCHANT_BY_ID, rollEnchants } from './magic';

export const TRIAL_COOLDOWN_SEC = 30 * 60;
export const PLAYER_RANGE = 14;
export const SPAWN_RANGE = 4;
export const SPAWN_INTERVAL = 1;          // trial chamber spawners: 20 ticks between spawns (wiki)
export const EJECT_INTERVAL = 1.5;        // one reward every 30 ticks
export const VAULT_RANGE = 4.5;
export const TICK = 0.25;
/** Ominous trials periodically drop an "ominous item spawner" above a participating player (Java 1.21 TrialSpawnerConfig
 *  ticks_between_item_spawners). The item (lingering potion / wind charge) falls and bursts where it lands. */
export const OMINOUS_ITEM_INTERVAL = 8;
/** Each ominous spawner owns two projectiles, fixed per position and seed: a lingering potion and one of five shots. */
export const OMINOUS_POTIONS = ['wind_charged', 'oozing', 'weaving', 'infested', 'strength', 'speed', 'slow_falling'] as const;
export const OMINOUS_SHOTS = ['arrow', 'arrow_poison', 'arrow_slowness', 'small_fireball', 'wind_charge'] as const;
export function ominousProjectiles(x: number, y: number, z: number, seed: number): [string, string] {
  const h = mixPos(x, y, z, seed ^ 0x5bd1e995);
  return ['potion:' + OMINOUS_POTIONS[h % OMINOUS_POTIONS.length], OMINOUS_SHOTS[(h >>> 8) % OMINOUS_SHOTS.length]];
}

export interface SpawnerConfig { species: string[]; total: number; totalPer: number; simultaneous: number; simultaneousPer: number }
/** Vanilla numbers: base amount + an increment for every additional player that has been detected. */
export const SPAWNER_CONFIG: Record<SpawnerKind, SpawnerConfig> = {
  melee: { species: ['zombie', 'husk', 'spider'], total: 6, totalPer: 2, simultaneous: 3, simultaneousPer: 0.5 },
  small_melee: { species: ['slime', 'cave_spider', 'silverfish'], total: 6, totalPer: 2, simultaneous: 3, simultaneousPer: 0.5 },
  ranged: { species: ['skeleton', 'stray', 'bogged'], total: 6, totalPer: 2, simultaneous: 3, simultaneousPer: 0.5 },
  breeze: { species: ['breeze'], total: 2, totalPer: 1, simultaneous: 1, simultaneousPer: 0.5 },
};
/** Mobs that cannot wear the ominous equipment get twice the total in an ominous trial (wiki "Ominous Trial Spawner"). */
export const NO_EQUIPMENT = new Set(['spider', 'cave_spider', 'silverfish', 'slime', 'breeze']);
const KINDS: SpawnerKind[] = ['melee', 'ranged', 'small_melee', 'breeze'];

/** Difficulty scaling: how many mobs the trial needs in total and how many may be alive at once for `players` participants. */
export function scaling(kind: SpawnerKind, players: number, ominous = false, species?: string) {
  const c = SPAWNER_CONFIG[kind], extra = Math.max(0, players - 1);
  const noGear = kind === 'breeze' || (species ? NO_EQUIPMENT.has(species) : false);
  const total = Math.floor(c.total + c.totalPer * extra) * (ominous && noGear ? 2 : 1);
  // Ominous trials allow one more mob out at once.
  const simultaneous = Math.max(1, Math.floor(c.simultaneous + c.simultaneousPer * extra)) + (ominous ? 1 : 0);
  return { total, simultaneous };
}
const mix = (x: number, y: number, z: number, seed: number) => mixPos(x, y, z, seed);
function mixPos(x: number, y: number, z: number, seed: number) {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 1103515245) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return (h ^ (h >>> 16)) >>> 0;
}
/** What a spawner at this position summons (stable for a given world seed, so it never has to be stored at generation time). */
export function spawnerProfile(x: number, y: number, z: number, seed: number, kind?: SpawnerKind) {
  const h = mix(x, y, z, seed), k = kind ?? KINDS[h % KINDS.length], list = SPAWNER_CONFIG[k].species;
  return { kind: k, species: list[(h >>> 8) % list.length] };
}

export interface Reward { item: string; count: number; ench?: Record<string, number>; /** remaining durability fraction (damaged shields) */ durability?: number }
/**
 * Loot entry: [item, min, max, weight, extra]. extra: 'lvl:a-b' = enchant_with_levels(a‥b), 'book:a,b,c' = enchant_randomly
 * from that list, 'dmg:0.5-1' = set_damage, 'bottle:a-b' = Ominous Bottle amplifier range. '' = empty roll.
 */
type LootEntry = [string, number, number, number, string?];
// Spawner rewards — minecraft.wiki "Trial Spawner" / "Ominous Trial Spawner" (Java 1.21).
const SPAWNER_CONSUMABLES: LootEntry[] = [['bread', 1, 3, 3], ['cooked_chicken', 1, 1, 3], ['baked_potato', 1, 3, 2], ['potion_regeneration', 1, 1, 1], ['potion_swiftness', 1, 1, 1]];
const OMINOUS_CONSUMABLES: LootEntry[] = [['baked_potato', 2, 4, 21], ['cooked_beef', 1, 2, 21], ['golden_carrot', 1, 2, 14], ['potion_regeneration', 1, 1, 7], ['potion_strength', 1, 1, 7]];
// Vault rewards — minecraft.wiki "Vault" / "Ominous Vault": the reward table flattened into its three pools.
const VAULT_POOL1: LootEntry[] = [
  ['shield', 1, 1, 300, 'dmg:0.5-1'], ['arrow', 2, 8, 92], ['tipped_arrow_poison', 2, 8, 92], ['iron_axe', 1, 1, 200, 'lvl:5-15'], ['wind_charge', 1, 3, 69],
  ['iron_ingot', 1, 4, 69], ['crossbow', 1, 1, 200, 'lvl:5-20'], ['diamond', 1, 2, 23], ['golden_carrot', 1, 2, 200], ['diamond_axe', 1, 1, 100, 'lvl:5-15'],
  ['bow', 1, 1, 300, 'lvl:5-15'], ['ominous_bottle', 1, 1, 46, 'bottle:0-1'], ['diamond_chestplate', 1, 1, 100, 'lvl:5-15'],
  ['enchanted_book', 1, 1, 200, 'book:mending,riptide,loyalty,channeling,impaling'], ['iron_chestplate', 1, 1, 200, 'lvl:0-10'],
  ['enchanted_book', 1, 1, 200, 'book:sharpness,bane_of_arthropods,efficiency,fortune,silk_touch,feather_falling'],
  ['emerald', 2, 4, 392], ['wind_charge', 4, 12, 23], ['honey_bottle', 1, 2, 69],
];
const VAULT_POOL2: LootEntry[] = [['diamond', 1, 2, 1], ['arrow', 2, 8, 4], ['tipped_arrow_poison', 2, 8, 4], ['ominous_bottle', 1, 1, 2, 'bottle:0-0'], ['wind_charge', 4, 12, 1],
  ['wind_charge', 1, 3, 3], ['emerald', 2, 4, 4], ['honey_bottle', 1, 2, 3], ['iron_ingot', 1, 4, 3]];
const VAULT_POOL3: LootEntry[] = [['music_disc_precipice', 1, 1, 2], ['bolt_armor_trim_smithing_template', 1, 1, 3], ['trident', 1, 1, 1], ['', 0, 0, 36], ['golden_apple', 1, 1, 4], ['guster_banner_pattern', 1, 1, 2]];
const OMINOUS_POOL1: LootEntry[] = [
  ['emerald', 4, 10, 145], ['wind_charge', 8, 12, 116], ['tipped_arrow_slowness_strong', 4, 12, 87], ['diamond', 2, 3, 58],
  ['enchanted_book', 1, 1, 120, 'book:wind_burst=1'], ['enchanted_book', 1, 1, 120, 'book:breach,density'],
  ['enchanted_book', 1, 1, 120, 'book:knockback,punch,smite,looting,multishot'], ['golden_apple', 1, 1, 180],
  ['diamond_chestplate', 1, 1, 180, 'lvl:5-20'], ['diamond_axe', 1, 1, 180, 'lvl:5-20'], ['ominous_bottle', 1, 1, 29, 'bottle:2-4'],
  ['emerald_block', 1, 1, 300], ['diamond_block', 1, 1, 60], ['iron_block', 1, 1, 240], ['crossbow', 1, 1, 240, 'lvl:5-20'],
];
const OMINOUS_POOL2: LootEntry[] = [['emerald', 4, 10, 5], ['wind_charge', 8, 12, 4], ['tipped_arrow_slowness_strong', 4, 12, 3], ['diamond', 2, 3, 2], ['ominous_bottle', 1, 1, 1, 'bottle:2-4']];
const OMINOUS_POOL3: LootEntry[] = [['', 0, 0, 10], ['music_disc_creator', 1, 1, 3], ['heavy_core', 1, 1, 3], ['enchanted_golden_apple', 1, 1, 9], ['flow_armor_trim_smithing_template', 1, 1, 9], ['flow_banner_pattern', 1, 1, 6]];
/** Kept for compatibility: the first (main) pool of each vault table. */
export const VAULT_LOOT = VAULT_POOL1, OMINOUS_VAULT_LOOT = OMINOUS_POOL1;

function roll(table: LootEntry[], rng: () => number): Reward | null {
  let total = 0;
  for (const e of table) total += e[3];
  let r = rng() * total, pick = table[table.length - 1];
  for (const e of table) { r -= e[3]; if (r < 0) { pick = e; break; } }
  if (!pick[0]) return null;
  const reward: Reward = { item: pick[0], count: pick[1] + Math.floor(rng() * (pick[2] - pick[1] + 1)) };
  const extra = pick[4] ?? '';
  if (extra.startsWith('book:')) {
    const opts = extra.slice(5).split(','), [id, fixed] = opts[Math.floor(rng() * opts.length)].split('=');
    reward.ench = { [id]: fixed ? Number(fixed) : 1 + Math.floor(rng() * (ENCHANT_BY_ID[id]?.max ?? 1)) };
  } else if (extra.startsWith('lvl:')) {
    const [a, b] = extra.slice(4).split('-').map(Number), level = a + Math.floor(rng() * (b - a + 1));
    const list = level > 0 ? rollEnchants(pick[0], level, rng) : [];
    if (list.length) reward.ench = Object.fromEntries(list);
  } else if (extra.startsWith('dmg:')) {
    const [a, b] = extra.slice(4).split('-').map(Number);
    reward.durability = a + rng() * (b - a);
  } else if (extra.startsWith('bottle:')) {
    const [a, b] = extra.slice(7).split('-').map(Number);
    reward.ench = { ominous_bottle_amplifier: a + Math.floor(rng() * (b - a + 1)) };
  }
  return reward;
}
/** Rolls the spawner reward table once: a key (50 %, ominous 30 %) goes to every player, otherwise each player gets one supply item. */
export function rollSpawnerRewards(ominous: boolean, players: number, rng: () => number): Reward[] {
  const n = Math.max(1, players);
  if (rng() < (ominous ? 0.3 : 0.5)) return Array.from({ length: n }, () => ({ item: ominous ? 'ominous_trial_key' : 'trial_key', count: 1 }));
  return Array.from({ length: n }, () => roll(ominous ? OMINOUS_CONSUMABLES : SPAWNER_CONSUMABLES, rng)!);
}
/** Single-player helper kept for older callers. */
export function rollSpawnerReward(ominous: boolean, rng: () => number): Reward { return rollSpawnerRewards(ominous, 1, rng)[0]; }
/** Vault reward: pool 1 once, pool 2 one to three times, pool 3 once (often empty). */
export function rollVault(ominous: boolean, rng: () => number): Reward[] {
  const [p1, p2, p3] = ominous ? [OMINOUS_POOL1, OMINOUS_POOL2, OMINOUS_POOL3] : [VAULT_POOL1, VAULT_POOL2, VAULT_POOL3];
  const out: Reward[] = [];
  const push = (r: Reward | null) => { if (r) out.push(r); };
  push(roll(p1, rng));
  for (let i = 1 + Math.floor(rng() * 3); i > 0; i--) push(roll(p2, rng));
  push(roll(p3, rng));
  return out;
}

export interface TrialSpawner {
  x: number; y: number; z: number;
  kind: SpawnerKind; species: string;
  phase: SpawnerPhase; ominous: boolean;
  /** UUIDs of every player detected during the current trial — drives the scaling and gets one reward each. */
  players: string[];
  spawned: number; killed: number; alive: number[];
  nextSpawn: number; cooldownUntil: number;
  queue: Reward[]; nextEject: number;
  /** Next ominous item drop (seconds on the world clock). */
  nextItem?: number;
}
export interface Vault {
  x: number; y: number; z: number; ominous: boolean; phase: VaultPhase;
  /** UUIDs that have already looted this vault — each player can unlock a vault exactly once. */
  rewarded: string[];
  queue: Reward[]; nextEject: number;
}
export interface TrialPlayer { id: string; /** level of Bad Omen / Trial Omen, 0 when the player has neither */ omen: number }
export interface TrialHost {
  /** Persistent world clock in seconds (survives save / load, so cooldowns do too). */
  now(): number;
  rng(): number;
  /** null = the chunk is not loaded (state is left untouched). */
  blockAt(x: number, y: number, z: number): 'spawner' | 'vault' | 'ominous_vault' | 'other' | null;
  setPhase(x: number, y: number, z: number, state: number): void;
  playersNear(x: number, y: number, z: number, r: number): TrialPlayer[];
  spawn(species: string, x: number, y: number, z: number, ominous: boolean, key: string): number | null;
  alive(id: number): boolean;
  remove(id: number): void;
  eject(x: number, y: number, z: number, reward: Reward, from: 'spawner' | 'vault', ominous: boolean): void;
  /** Bad Omen was consumed to turn a spawner ominous (the engine converts it into Trial Omen). */
  omenUsed?(player: string): void;
  /** Ominous trial: an item spawner above a player / trial mob near the spawner shoots `item` ('potion:<effect>' or a shot). */
  ominousItem?(x: number, y: number, z: number, item: string): void;
  /** World seed (numeric) — fixes each spawner's projectile pair. */
  seed?(): number;
  emit?<K extends keyof GameEvents>(type: K, payload: GameEvents[K]): void;
}
export interface TrialSave { spawners: TrialSpawner[]; vaults: Vault[] }
export type UnlockResult = { ok: true; consume: string } | { ok: false; reason: 'already' | 'wrong_key' | 'no_key' | 'busy' | 'missing' };

const PHASE_STATE: Record<SpawnerPhase, number> = { inactive: 0, waiting: 1, active: 2, ejecting: 3, cooldown: 4 };
const VAULT_STATE: Record<VaultPhase, number> = { inactive: 0, active: 1, unlocking: 2, ejecting: 3 };
export const spawnerCellState = (phase: SpawnerPhase, ominous: boolean) => PHASE_STATE[phase] + (ominous ? 8 : 0);
const keyOf = (x: number, y: number, z: number) => `${x},${y},${z}`;

export class TrialSystem {
  spawners = new Map<string, TrialSpawner>();
  vaults = new Map<string, Vault>();
  private owners = new Map<number, string>();
  private acc = 0;

  constructor(public host: TrialHost) {}

  registerSpawner(x: number, y: number, z: number, kind: SpawnerKind, species: string): TrialSpawner {
    const key = keyOf(x, y, z), cur = this.spawners.get(key);
    if (cur) return cur;
    const s: TrialSpawner = { x, y, z, kind, species, phase: 'inactive', ominous: false, players: [], spawned: 0, killed: 0, alive: [], nextSpawn: 0, cooldownUntil: 0, queue: [], nextEject: 0 };
    this.spawners.set(key, s);
    return s;
  }
  registerVault(x: number, y: number, z: number, ominous: boolean): Vault {
    const key = keyOf(x, y, z), cur = this.vaults.get(key);
    if (cur) return cur;
    const v: Vault = { x, y, z, ominous, phase: 'inactive', rewarded: [], queue: [], nextEject: 0 };
    this.vaults.set(key, v);
    return v;
  }
  /** The block was broken / replaced. */
  remove(x: number, y: number, z: number) {
    const key = keyOf(x, y, z), s = this.spawners.get(key);
    if (s) for (const id of s.alive) this.owners.delete(id);
    this.spawners.delete(key);
    this.vaults.delete(key);
  }
  spawnerAt(x: number, y: number, z: number) { return this.spawners.get(keyOf(x, y, z)); }
  vaultAt(x: number, y: number, z: number) { return this.vaults.get(keyOf(x, y, z)); }

  /** Called by the mob manager whenever a mob dies; only mobs summoned by a spawner count towards its trial. */
  onMobDeath(id: number) {
    const key = this.owners.get(id);
    if (key === undefined) return;
    this.owners.delete(id);
    const s = this.spawners.get(key);
    if (!s) return;
    const i = s.alive.indexOf(id);
    if (i >= 0) { s.alive.splice(i, 1); s.killed++; }
  }

  update(dt: number) {
    this.acc += dt;
    if (this.acc < TICK) return;
    this.acc = 0;
    for (const s of this.spawners.values()) this.tickSpawner(s);
    for (const v of this.vaults.values()) this.tickVault(v);
  }

  private setPhase(s: TrialSpawner, phase: SpawnerPhase) {
    s.phase = phase;
    this.host.setPhase(s.x, s.y, s.z, spawnerCellState(phase, s.ominous));
    this.host.emit?.('trial_spawner_state', { x: s.x, y: s.y, z: s.z, phase, ominous: s.ominous, players: s.players.length });
  }
  private resetTrial(s: TrialSpawner, now: number) {
    for (const id of s.alive) { this.owners.delete(id); this.host.remove(id); }
    s.alive = []; s.spawned = 0; s.killed = 0; s.nextSpawn = now + SPAWN_INTERVAL;
  }

  private tickSpawner(s: TrialSpawner) {
    const here = this.host.blockAt(s.x, s.y, s.z), now = this.host.now();
    if (here === null) return;
    if (here !== 'spawner') { this.remove(s.x, s.y, s.z); return; }
    if (s.phase === 'cooldown') {
      if (now >= s.cooldownUntil) { s.ominous = false; s.players = []; this.setPhase(s, 'inactive'); }
      return;
    }
    if (s.phase === 'ejecting') {
      if (now < s.nextEject) return;
      const reward = s.queue.shift();
      if (reward) {
        this.host.eject(s.x, s.y, s.z, reward, 'spawner', s.ominous);
        this.host.emit?.('trial_spawner_eject', { x: s.x, y: s.y, z: s.z, item: reward.item, count: reward.count, ominous: s.ominous });
        s.nextEject = now + EJECT_INTERVAL;
      }
      if (!s.queue.length) { s.cooldownUntil = now + TRIAL_COOLDOWN_SEC; this.setPhase(s, 'cooldown'); }
      return;
    }
    const near = this.host.playersNear(s.x + 0.5, s.y + 0.5, s.z + 0.5, PLAYER_RANGE);
    if (s.phase !== 'active') {
      if (!near.length) { if (s.phase !== 'waiting') this.setPhase(s, 'waiting'); return; }
      s.players = []; s.alive = []; s.spawned = 0; s.killed = 0; s.nextSpawn = now + SPAWN_INTERVAL;
      for (const p of near) s.players.push(p.id);
      this.setPhase(s, 'active');
    }
    let grew = false;
    for (const p of near) if (!s.players.includes(p.id)) { s.players.push(p.id); grew = true; }
    const omen = near.find(p => p.omen > 0);
    if (omen && !s.ominous) {                                           // Bad Omen → the running trial restarts as an ominous one
      s.ominous = true;
      this.resetTrial(s, now);
      this.host.omenUsed?.(omen.id);
      this.setPhase(s, 'active');
    } else if (grew) this.host.emit?.('trial_spawner_state', { x: s.x, y: s.y, z: s.z, phase: s.phase, ominous: s.ominous, players: s.players.length });
    // Mobs that vanished without dying (despawn, unload) are summoned again.
    s.alive = s.alive.filter(id => {
      if (this.host.alive(id)) return true;
      this.owners.delete(id);
      s.spawned = Math.max(0, s.spawned - 1);
      return false;
    });
    const { total, simultaneous } = scaling(s.kind, s.players.length, s.ominous, s.species);
    if (s.killed >= total) {
      s.queue = rollSpawnerRewards(s.ominous, s.players.length, () => this.host.rng());
      s.nextEject = now + EJECT_INTERVAL;
      this.setPhase(s, 'ejecting');
      return;
    }
    if (s.ominous && near.length && this.host.ominousItem) {
      if (s.nextItem === undefined || s.nextItem > now + OMINOUS_ITEM_INTERVAL * 2) s.nextItem = now + OMINOUS_ITEM_INTERVAL;
      if (now >= s.nextItem) {
        s.nextItem = now + OMINOUS_ITEM_INTERVAL * (0.75 + this.host.rng() * 0.5);
        const pair = ominousProjectiles(s.x, s.y, s.z, this.host.seed?.() ?? 0);
        this.host.ominousItem(s.x, s.y, s.z, pair[this.host.rng() < 0.5 ? 0 : 1]);
      }
    }
    if (s.spawned < total && s.alive.length < simultaneous && now >= s.nextSpawn) {
      const key = keyOf(s.x, s.y, s.z);
      for (let attempt = 0; attempt < 6; attempt++) {
        const a = this.host.rng() * Math.PI * 2, d = 1.5 + this.host.rng() * (SPAWN_RANGE - 1.5);
        const id = this.host.spawn(s.species, s.x + 0.5 + Math.cos(a) * d, s.y, s.z + 0.5 + Math.sin(a) * d, s.ominous, key);
        if (id === null) continue;
        s.alive.push(id); s.spawned++; s.nextSpawn = now + SPAWN_INTERVAL;
        this.owners.set(id, key);
        this.host.emit?.('trial_spawner_spawn', { x: s.x, y: s.y, z: s.z, species: s.species, mobId: id, ominous: s.ominous });
        break;
      }
    }
  }

  private setVault(v: Vault, phase: VaultPhase) {
    if (v.phase === phase) return;
    v.phase = phase;
    this.host.setPhase(v.x, v.y, v.z, VAULT_STATE[phase]);
    this.host.emit?.('vault_state', { x: v.x, y: v.y, z: v.z, phase, ominous: v.ominous });
  }
  private tickVault(v: Vault) {
    const here = this.host.blockAt(v.x, v.y, v.z), now = this.host.now();
    if (here === null) return;
    if (here !== (v.ominous ? 'ominous_vault' : 'vault')) { this.remove(v.x, v.y, v.z); return; }
    if (v.phase === 'unlocking' || v.phase === 'ejecting') {
      if (now < v.nextEject) return;
      const reward = v.queue.shift();
      if (reward) {
        this.setVault(v, 'ejecting');
        this.host.eject(v.x, v.y, v.z, reward, 'vault', v.ominous);
        this.host.emit?.('vault_eject', { x: v.x, y: v.y, z: v.z, item: reward.item, count: reward.count, ominous: v.ominous });
        v.nextEject = now + 1;
        return;
      }
    }
    const fresh = this.host.playersNear(v.x + 0.5, v.y + 0.5, v.z + 0.5, VAULT_RANGE).some(p => !v.rewarded.includes(p.id));
    this.setVault(v, fresh ? 'active' : 'inactive');
  }

  /** A player uses `held` on the vault. On success the caller must consume one `consume` item from the player's hand. */
  tryUnlock(x: number, y: number, z: number, player: string, held: string | undefined): UnlockResult {
    const v = this.vaults.get(keyOf(x, y, z));
    if (!v) return { ok: false, reason: 'missing' };
    const deny = (reason: 'already' | 'wrong_key' | 'no_key' | 'busy'): UnlockResult => {
      this.host.emit?.('vault_denied', { x, y, z, reason, player });
      return { ok: false, reason };
    };
    if (v.rewarded.includes(player)) return deny('already');
    if (v.phase === 'unlocking' || v.phase === 'ejecting') return deny('busy');
    const need = v.ominous ? 'ominous_trial_key' : 'trial_key';
    if (held !== need) return deny(held === 'trial_key' || held === 'ominous_trial_key' ? 'wrong_key' : 'no_key');
    v.rewarded.push(player);
    v.queue = rollVault(v.ominous, () => this.host.rng());
    v.nextEject = this.host.now() + 1;
    this.setVault(v, 'unlocking');
    return { ok: true, consume: need };
  }

  save(): TrialSave {
    return { spawners: [...this.spawners.values()].map(s => ({ ...s, players: [...s.players], alive: [...s.alive], queue: [...s.queue] })), vaults: [...this.vaults.values()].map(v => ({ ...v, rewarded: [...v.rewarded], queue: [...v.queue] })) };
  }
  load(data?: TrialSave | null) {
    this.spawners.clear(); this.vaults.clear(); this.owners.clear();
    for (const s of data?.spawners ?? []) {
      const key = keyOf(s.x, s.y, s.z);
      this.spawners.set(key, { ...s, players: [...(s.players ?? [])], alive: [...(s.alive ?? [])], queue: [...(s.queue ?? [])] });
      for (const id of s.alive ?? []) this.owners.set(id, key);
    }
    for (const v of data?.vaults ?? []) this.vaults.set(keyOf(v.x, v.y, v.z), { ...v, rewarded: [...(v.rewarded ?? [])], queue: [...(v.queue ?? [])] });
  }
}
