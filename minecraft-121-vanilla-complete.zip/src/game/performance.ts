export function workerLimit(cores = 4, memoryGB = 8): number {
  // Leave a logical core for input, audio and the renderer on small devices.
  return Math.max(1, Math.min(4, Math.floor(cores) - 1, memoryGB <= 4 ? 2 : 4));
}

export function uploadBudget(active: boolean, targetFps = 60): number {
  return active ? Math.min(3, 1000 / targetFps * 0.15) : 8;
}

export function dataOnlyChunk(cx: number, cz: number, px: number, pz: number, distance: number): boolean {
  return (cx - px) ** 2 + (cz - pz) ** 2 > (distance + 0.5) ** 2;
}

/** Hysteresis avoids resolution pumping; CPU-heavy frames do not sacrifice pixels. */
export class AdaptiveResolution {
  scale = 1;
  frameMs = 1000 / 60;
  cpuMs = 0;
  private slowFor = 0;
  private fastFor = 0;
  private samples = 0;
  private cooldown = 2000;

  reset(scale = 1) {
    this.scale = scale;
    this.frameMs = 1000 / 60;
    this.cpuMs = this.slowFor = this.fastFor = this.samples = 0;
    this.cooldown = 2000;
  }

  sample(frameMs: number, cpuMs: number, targetFps = 60, uploading = false): number {
    if (!Number.isFinite(frameMs) || frameMs <= 0 || frameMs > 200 || !Number.isFinite(cpuMs)) return this.scale;
    this.cooldown = Math.max(0, this.cooldown - frameMs);
    // Ignore upload samples without erasing sustained load between streamed chunks.
    if (uploading) return this.scale;
    this.frameMs += (frameMs - this.frameMs) * 0.06;
    this.cpuMs += (Math.max(0, cpuMs) - this.cpuMs) * 0.06;
    this.samples++;
    if (this.samples < 60) {
      this.slowFor = this.fastFor = 0;
      return this.scale;
    }
    const budget = 1000 / targetFps;
    const slow = this.frameMs > budget * 1.14 && this.cpuMs < budget * 0.85;
    this.slowFor = slow ? this.slowFor + frameMs : 0;
    this.fastFor = this.frameMs < budget * 1.04 ? this.fastFor + frameMs : 0;
    if (!this.cooldown && this.slowFor > 1400 && this.scale > 0.8) {
      this.scale = Math.max(0.8, Math.round((this.scale - 0.05) * 100) / 100);
      this.cooldown = 3000;
      this.slowFor = this.fastFor = 0;
    } else if (!this.cooldown && this.fastFor > 8000 && this.scale < 1) {
      this.scale = Math.min(1, Math.round((this.scale + 0.025) * 1000) / 1000);
      this.cooldown = 4000;
      this.slowFor = this.fastFor = 0;
    }
    return this.scale;
  }
}