// Minecraft Java Edition rule helpers: experience curve, hunger / saturation / exhaustion, shield geometry, comparator readings,
// piston push rules and book limits. Pure functions with no engine / three.js dependency so they can be unit-tested directly.

// ---------------------------------------------------------------------------------------------------------------------
// Experience (Java: total points to reach a level is piecewise quadratic, the points needed per level are linear per tier)
// ---------------------------------------------------------------------------------------------------------------------
/** Total experience points needed to *reach* `level` from level 0. */
export function xpForLevel(level: number): number {
  const l = Math.max(0, Math.floor(level));
  if (l <= 16) return l * l + 6 * l;
  if (l <= 31) return Math.floor(2.5 * l * l - 40.5 * l + 360);
  return Math.floor(4.5 * l * l - 162.5 * l + 2220);
}
/** Points needed to go from `level` to `level + 1`. */
export const xpToNext = (level: number): number => (level <= 15 ? 2 * level + 7 : level <= 30 ? 5 * level - 38 : 9 * level - 158);
/** Level for a total amount of experience points. */
export function levelFromXp(xp: number): number {
  const total = Math.max(0, xp);
  let l = Math.floor(Math.sqrt(total));
  while (l > 0 && xpForLevel(l) > total) l--;
  while (xpForLevel(l + 1) <= total) l++;
  return l;
}
/** 0..1 fill of the experience bar. */
export function xpProgress(xp: number): number {
  const l = levelFromXp(xp);
  return Math.max(0, Math.min(0.9999, (xp - xpForLevel(l)) / xpToNext(l)));
}
/** Like `/xp add <n> levels` (negative to spend): the bar fraction is kept, exactly as Java's giveExperienceLevels does. */
export function xpAfterLevels(xp: number, delta: number): number {
  const l = levelFromXp(xp), frac = xpProgress(xp), nl = Math.max(0, l + delta);
  return xpForLevel(nl) + Math.floor(frac * xpToNext(nl));
}
/** Experience dropped on death: 7 per level, capped at 100. */
export const deathXp = (xp: number): number => Math.min(100, levelFromXp(xp) * 7);
/** Old saves stored xp = level² (+ fraction). Convert while keeping level and bar progress. */
export function migrateOldXp(oldXp: number): number {
  const l = Math.floor(Math.sqrt(Math.max(0, oldXp))), frac = (oldXp - l * l) / Math.max(1, (l + 1) ** 2 - l * l);
  return xpForLevel(l) + Math.floor(frac * xpToNext(l));
}

// ---------------------------------------------------------------------------------------------------------------------
// Hunger, saturation and exhaustion
// ---------------------------------------------------------------------------------------------------------------------
/** [nutrition, saturation restored] per item (Java 1.20: saturation = nutrition × modifier × 2). */
export const FOOD: Record<string, [number, number]> = {
  apple: [4, 2.4], baked_potato: [5, 6], beef: [3, 1.8], raw_beef: [3, 1.8], beetroot: [1, 1.2], beetroot_soup: [6, 7.2], bread: [5, 6], carrot: [3, 3.6],
  chicken: [2, 1.2], raw_chicken: [2, 1.2], cod: [2, 0.4], raw_cod: [2, 0.4], cooked_beef: [8, 12.8], steak: [8, 12.8], cooked_chicken: [6, 7.2],
  cooked_cod: [5, 6], cooked_mutton: [6, 9.6], cooked_porkchop: [8, 12.8], cooked_rabbit: [5, 6], cooked_salmon: [6, 9.6], cookie: [2, 0.4],
  dried_kelp: [1, 0.6], enchanted_golden_apple: [4, 9.6], golden_apple: [4, 9.6], golden_carrot: [6, 14.4], honey_bottle: [6, 1.2], melon_slice: [2, 1.2],
  mushroom_stew: [6, 7.2], mutton: [2, 1.2], raw_mutton: [2, 1.2], poisonous_potato: [2, 1.2], porkchop: [3, 1.8], raw_porkchop: [3, 1.8], potato: [1, 0.6],
  pufferfish: [1, 0.2], pumpkin_pie: [8, 4.8], rabbit: [3, 1.8], raw_rabbit: [3, 1.8], rabbit_stew: [10, 12], rotten_flesh: [4, 0.8], salmon: [2, 0.4],
  raw_salmon: [2, 0.4], spider_eye: [2, 3.2], suspicious_stew: [6, 7.2], sweet_berries: [2, 0.4], glow_berries: [2, 0.4], tropical_fish: [1, 0.2],
  chorus_fruit: [4, 2.4], cake: [2, 0.4],
};
/** Nutrition + saturation for an item; unknown foods fall back to the definition's nutrition with the common 0.3 modifier. */
export const foodValue = (name: string, fallbackNutrition = 0): [number, number] => FOOD[name] ?? [fallbackNutrition, fallbackNutrition * 0.6];

export interface FoodState { food: number; sat: number; exh: number; timer: number; acc: number; ptick: number }
export const newFood = (): FoodState => ({ food: 20, sat: 5, exh: 0, timer: 0, acc: 0, ptick: 0 });
export const addExhaustion = (f: FoodState, n: number) => { if (n > 0) f.exh = Math.min(40, f.exh + n); };
/** Eating: food += nutrition (max 20); saturation = min(saturation + restored, food). */
export function eatFood(f: FoodState, nutrition: number, saturation: number) {
  f.food = Math.min(20, f.food + nutrition);
  f.sat = Math.min(f.food, f.sat + saturation);
}
export interface HungerEnv { health(): number; difficulty: string; naturalRegen?: boolean; heal(n: number): void; hurt(n: number): void }
/** One game tick (1/20 s) of Java's FoodData.tick. */
export function stepFood(f: FoodState, env: HungerEnv) {
  const peaceful = env.difficulty === 'peaceful', regen = env.naturalRegen !== false;
  if (f.exh > 4) {
    f.exh -= 4;
    if (!peaceful) { if (f.sat > 0) f.sat = Math.max(0, f.sat - 1); else f.food = Math.max(0, f.food - 1); }
  }
  const hurt = env.health() < 20;
  if (peaceful && regen) {                                      // peaceful: +1 HP per second and food refills on its own
    f.ptick++;
    if (f.ptick % 20 === 0 && hurt) env.heal(1);
    if (f.ptick % 10 === 0 && f.food < 20) f.food++;
    return;
  }
  if (regen && f.sat > 0 && hurt && f.food >= 20) {             // fast regeneration: saturation is burnt, every 10 ticks
    if (++f.timer >= 10) { const s = Math.min(f.sat, 6); env.heal(s / 6); addExhaustion(f, s); f.timer = 0; }
  } else if (regen && f.food >= 18 && hurt) {                   // normal regeneration: 1 HP every 80 ticks for 6 exhaustion
    if (++f.timer >= 80) { env.heal(1); addExhaustion(f, 6); f.timer = 0; }
  } else if (f.food <= 0) {                                     // starvation
    if (++f.timer >= 80) {
      const h = env.health();
      if (h > 10 || env.difficulty === 'hard' || (h > 1 && env.difficulty === 'normal')) env.hurt(1);
      f.timer = 0;
    }
  } else f.timer = 0;
}
/** Frame-rate independent wrapper: runs whole 20 Hz ticks. */
export function tickFood(f: FoodState, dt: number, env: HungerEnv) {
  f.acc += dt;
  let n = 0;
  while (f.acc >= 0.05 && n++ < 8) { f.acc -= 0.05; stepFood(f, env); }
  if (f.acc > 0.4) f.acc = 0;
}
export const canSprintWith = (food: number) => food > 6;

// ---------------------------------------------------------------------------------------------------------------------
// Shield
// ---------------------------------------------------------------------------------------------------------------------
export const SHIELD_DELAY = 0.25;     // seconds the shield must be raised before it blocks (5 ticks)
export const SHIELD_DISABLE = 5;      // seconds a shield stays unusable after being hit by an axe
/** Sources a raised shield can never stop (fall, drowning, starvation, magic / potions, lightning, the void …). */
export const SHIELD_BYPASS = new Set(['fall', 'drown', 'starve', 'void', 'magic', 'fire', 'contact', 'generic', 'lightning', 'sonic']);
/** Mobs whose melee hits knock a shield out for 5 s (axe wielders and the warden). */
export const AXE_ATTACKERS = new Set(['vindicator', 'piglin_brute', 'warden']);
/**
 * Java's isDamageSourceBlocked geometry: the attacker → player vector, flattened to the horizontal plane, must point against
 * the facing direction. That is a full 180° semicircle in front of the player; pitch is ignored.
 */
export function attackerInFront(yaw: number, px: number, pz: number, ax: number, az: number): boolean {
  const vx = px - ax, vz = pz - az, len = Math.hypot(vx, vz);
  if (len < 1e-6) return false;                                   // normalised zero vector → dot product 0 → not blocked (as in Java)
  const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
  return (vx * fx + vz * fz) / len < 0;
}
/** Angle (degrees, 0 = dead ahead, ±180 = behind, positive = to the right) the hit came from. */
export function hitAngle(yaw: number, px: number, pz: number, ax: number, az: number): number {
  const toX = ax - px, toZ = az - pz, facing = Math.atan2(-Math.sin(yaw), -Math.cos(yaw)), at = Math.atan2(toX, toZ);
  let d = at - facing;
  while (d > Math.PI) d -= 2 * Math.PI;
  while (d < -Math.PI) d += 2 * Math.PI;
  return -(d * 180) / Math.PI;
}
/** Durability lost by a shield that blocked `damage`: only hits of 3 or more hurt it, for 1 + floor(damage). */
export const shieldWear = (damage: number): number => (damage >= 3 ? 1 + Math.floor(damage) : 0);

// ---------------------------------------------------------------------------------------------------------------------
// Comparator readings for blocks that are not inventories
// ---------------------------------------------------------------------------------------------------------------------
export const DISC_SIGNAL: Record<string, number> = {
  music_disc_13: 1, music_disc_cat: 2, music_disc_blocks: 3, music_disc_chirp: 4, music_disc_far: 5, music_disc_mall: 6, music_disc_mellohi: 7,
  music_disc_stal: 8, music_disc_strad: 9, music_disc_ward: 10, music_disc_11: 11, music_disc_wait: 12, music_disc_pigstep: 13, music_disc_otherside: 14,
  music_disc_5: 15, music_disc_relic: 14, music_disc_creator: 12, music_disc_creator_music_box: 11, music_disc_precipice: 13,
};
export const MUSIC_DISCS = Object.keys(DISC_SIGNAL);
/** Cauldron block state: 0‥3 = water layers, 4 = lava (always reads 3). */
export const cauldronSignal = (state: number): number => (state >= 4 ? 3 : Math.max(0, Math.min(3, state)));
/** Lectern: page 0 → 1 … last page → 15; a single-page book reads 15. */
export const lecternSignal = (page: number, pages: number): number => (pages <= 0 ? 0 : pages === 1 ? 15 : 1 + Math.floor((Math.max(0, Math.min(pages - 1, page)) / (pages - 1)) * 14));
/** Composter fill: 0‥8 straight from the block state. */
export const composterSignal = (state: number): number => Math.max(0, Math.min(8, state));
/** Respawn anchor with 0‥4 charges reads 0, 3, 7, 11, 15. */
export const anchorSignal = (charges: number): number => Math.floor((Math.max(0, Math.min(4, charges)) / 4) * 15);
/** Inventory fullness: floor(1 + Σ(count / stack size) / slots × 14), 0 when empty. */
export function fullnessSignal(slots: ({ count: number; max: number } | null)[]): number {
  let sum = 0, any = false;
  for (const s of slots) if (s && s.count > 0) { sum += s.count / Math.max(1, s.max); any = true; }
  return !any || !slots.length ? 0 : Math.min(15, Math.floor(1 + (sum / slots.length) * 14));
}

// ---------------------------------------------------------------------------------------------------------------------
// Pistons (Java Edition): blocks that can never be pushed, plus block-entity blocks, plus blocks that break when pushed
// ---------------------------------------------------------------------------------------------------------------------
export const PISTON_IMMOVABLE = new Set([
  'bedrock', 'barrier', 'obsidian', 'crying_obsidian', 'reinforced_deepslate', 'budding_amethyst', 'sculk_shrieker', 'trial_spawner', 'vault', 'ominous_vault', 'respawn_anchor', 'command_block', 'chain_command_block', 'repeating_command_block',
  'structure_block', 'jigsaw', 'light', 'end_portal', 'end_portal_frame', 'end_gateway', 'portal', 'nether_portal', 'spawner', 'trial_spawner', 'vault',
  'enchanting_table', 'ender_chest', 'beacon', 'jukebox', 'lodestone', 'grindstone', 'anvil', 'chipped_anvil', 'damaged_anvil', 'creaking_heart',
  'sculk_sensor', 'calibrated_sculk_sensor', 'sculk_shrieker', 'sculk_catalyst', 'moving_piston', 'piston_head',
  // blocks that own a block entity cannot be moved in Java
  'chest', 'trapped_chest', 'barrel', 'furnace', 'blast_furnace', 'smoker', 'hopper', 'dropper', 'dispenser', 'crafter', 'brewing_stand', 'lectern',
  'daylight_detector', 'inverted_daylight_detector', 'conduit', 'beehive', 'bee_nest', 'chiseled_bookshelf', 'decorated_pot_block',
]);
/** Blocks a piston crushes (drops them as items) instead of pushing. */
export const PISTON_BREAKS = new Set(['small_amethyst_bud', 'medium_amethyst_bud', 'large_amethyst_bud', 'amethyst_cluster', 'chorus_flower', 'chorus_plant', 'shulker_box', 'campfire', 'soul_campfire', 'bell', 'lantern', 'soul_lantern', 'cobweb', 'dragon_egg', 'pumpkin', 'pumpkin_block', 'melon', 'melon_block', 'bed', 'cactus']);
export const isPistonImmovable = (name: string): boolean => PISTON_IMMOVABLE.has(name) || name.endsWith('_banner') || name.endsWith('_sign');

// ---------------------------------------------------------------------------------------------------------------------
// Books
// ---------------------------------------------------------------------------------------------------------------------
export const BOOK_MAX_PAGES = 100;
export const BOOK_MAX_PAGE_CHARS = 1024;
export const BOOK_MAX_TITLE = 15;
export const GENERATION_NAMES: [string, string][] = [['原本', 'Original'], ['コピー', 'Copy of original'], ['コピーのコピー', 'Copy of a copy'], ['ボロボロ', 'Tattered']];
/** Anything signed can be copied while it is an original or a first copy. */
export const canCopyBook = (generation = 0) => generation < 2;
export const clampPages = (pages: string[]): string[] => pages.slice(0, BOOK_MAX_PAGES).map(p => p.slice(0, BOOK_MAX_PAGE_CHARS));

// ---------------------------------------------------------------------------------------------------------------------
// Mob detection: how far away a mob notices the player (Java: LivingEntity.getVisibilityPercent)
// ---------------------------------------------------------------------------------------------------------------------
/** Fraction of the normal follow range: sneaking 0.8; invisible 0.7 × armour coverage (min 10 %), i.e. 7 % when naked. */
export function visibilityPercent(opts: { invisible: boolean; sneaking: boolean; armorPieces: number }): number {
  let v = opts.sneaking ? 0.8 : 1;
  if (opts.invisible) v *= 0.7 * Math.max(0.1, opts.armorPieces / 4);
  return v;
}

// ---------------------------------------------------------------------------------------------------------------------
// Night Vision (Java: GameRenderer.getNightVisionScale)
// ---------------------------------------------------------------------------------------------------------------------
/** 1.0 while more than 10 s remain, then a 2 Hz flicker between 0.4 and 1.0 until it ends. */
export const nightVisionScale = (secondsLeft: number): number => (secondsLeft <= 0 ? 0 : secondsLeft > 10 ? 1 : 0.7 + Math.sin(secondsLeft * 4 * Math.PI) * 0.3);
/** Underwater fog distance: Night Vision pushes the fog far back (28 → 72 blocks) so the sea floor stays visible. */
export const underwaterFog = (nv: number): { near: number; far: number } => ({ near: 2 + 5 * nv, far: 28 + 44 * nv });
/** Player.getWaterVision: ramps to 0.6 over the first 100 ticks under water, then to 1 at 600 ticks (30 s). */
export function waterVision(ticks: number): number {
  if (ticks >= 600) return 1;
  const f = Math.min(1, Math.max(0, ticks / 100)), g = ticks < 100 ? 0 : (ticks - 100) / 500;
  return f * 0.6 + g * 0.39999998;
}
/** FogRenderer (water): fog from the camera to 96 × max(0.25, water vision) blocks, ×0.85 in swamps; Night Vision pushes it out. */
export const vanillaWaterFog = (vision: number, swamp: boolean, nightVision = 0): { near: number; far: number } => {
  const far = 96 * Math.max(0.25, vision) * (swamp ? 0.85 : 1);
  return { near: 0, far: far + (Math.max(far, 96) - far) * nightVision };
};
/** FogRenderer water fog colour: the biome fog colour pushed towards full brightness by the water vision (rgb · (1 − w) + rgb / max · w). */
export function waterFogBrightened(rgb: number, vision: number): [number, number, number] {
  const r = ((rgb >> 16) & 255) / 255, g = ((rgb >> 8) & 255) / 255, b = (rgb & 255) / 255, m = Math.max(r, g, b, 1e-4);
  const k = (1 - vision) + vision / m;
  return [Math.min(1, r * k), Math.min(1, g * k), Math.min(1, b * k)];
}
