/*
 * Player movement on a fixed 20 Hz tick — a port of Java Edition 1.21 LivingEntity.aiStep / travel, Entity.move
 * (collide, step-up, maybeBackOffFromEdge), Player.travel (creative flight, swimming) and LocalPlayer.aiStep (flight thrust).
 *
 * Inside the simulation velocities are blocks / tick. The engine keeps `engine.velocity` in blocks / second as the player's
 * persistent velocity (agreed with the combat work: knockback is *added* to it and decays through the friction below).
 *
 * Values checked on minecraft.wiki (Player, Breaking, Damage, Weather, Bed, Ladder pages):
 *   walking 4.317 m/s, sprinting 5.612, sneaking / crawling 1.295, flying 10.889, sprint flying 21.778, terminal velocity 78.4,
 *   jump height 1.2522, ground friction 0.6 × 0.91 = 0.546 with +0.098 / tick acceleration, ladder 2.35 m/s up / 3 m/s down,
 *   fall damage ceil(distance − 3 − Jump Boost), hay bale & honey block 20 %, bed half the distance, slime 0 unless sneaking,
 *   void below (world floor − 64): 4 damage per half second, nether portal 80 ticks (creative 1).
 * Not confirmed on the wiki (taken from the decompiled code paths named above, marked 未確認 in the report):
 *   ice 0.98 / blue ice 0.989 / slime 0.8 slipperiness, soul sand & honey speed factor 0.4, honey jump factor 0.5,
 *   air acceleration 0.02 (0.026 sprinting), water drag 0.8 (0.9 sprint-swimming → 3.92 m/s, the wiki says 5.612),
 *   lava 0.5 drag, flight thrust 0.15 / tick with ×0.6 vertical damping (→ 7.5 m/s), bed bounce 0.66.
 */

export const TICK = 0.05;
export const TPS = 20;
export const GRAVITY = 0.08;
export const SLOW_FALL_GRAVITY = 0.01;
export const DRAG_Y = 0.9800000190734863;
export const AIR_FRICTION = 0.91;
export const DEFAULT_SLIP = 0.6;
export const BASE_SPEED = 0.1;
export const SPRINT_MULT = 1.3;
export const SNEAK_INPUT = 0.3;
export const USE_ITEM_INPUT = 0.2;
export const INPUT_DAMP = 0.98;
export const GROUND_ACCEL_K = 0.21600002;
export const AIR_ACCEL = 0.02;
export const AIR_ACCEL_SPRINT = 0.025999999;
export const JUMP_POWER = 0.42;
export const SPRINT_JUMP_BOOST = 0.2;
export const JUMP_DELAY_TICKS = 10;
export const STEP_HEIGHT = 0.6;
export const FLY_SPEED = 0.05;
export const CLIMB_SPEED = 0.2;
export const CLIMB_MAX_FALL = 0.15000000596046448;
export const CLIMB_MAX_H = 0.15000000596046448;
export const WATER_ACCEL = 0.02;
export const WATER_DRAG = 0.8;
export const WATER_DRAG_SPRINT = 0.9;
export const WATER_DRAG_Y = 0.800000011920929;
export const FLUID_JUMP = 0.03999999910593033;
export const MIN_VELOCITY = 0.003;

// ---- Hazards ---------------------------------------------------------------------------------------------------------------------
export const PORTAL_WAIT_SURVIVAL = 80;
export const PORTAL_WAIT_CREATIVE = 1;
export const PORTAL_DECAY = 4;
export const VOID_DEPTH = 64;
export const VOID_DAMAGE = 4;
export const HURT_COOLDOWN_TICKS = 10;
export const LAVA_DAMAGE = 4;
export const LAVA_FIRE_TICKS = 300;
export const FIRE_DAMAGE = 1;
export const SOUL_FIRE_DAMAGE = 2;
export const FIRE_IGNITE_TICKS = 160;
export const PLAYER_FIRE_IMMUNE_TICKS = 20;
export const BURN_DAMAGE = 1;
export const CACTUS_DAMAGE = 1;

const clamp = (v: number, lo: number, hi: number) => (v < lo ? lo : v > hi ? hi : v);

// ---- Block properties ------------------------------------------------------------------------------------------------------------
/** Block.getFriction ("slipperiness"). */
export function slipperinessOf(name: string): number {
  switch (name) {
    case 'ice': case 'packed_ice': case 'frosted_ice': return 0.98;
    case 'blue_ice': return 0.989;
    case 'slime_block': return 0.8;
    default: return DEFAULT_SLIP;
  }
}
/** Block.getSpeedFactor — multiplies the horizontal velocity after every move. */
export const blockSpeedFactorOf = (name: string) => (name === 'soul_sand' || name === 'honey_block' ? 0.4 : 1);
/** Block.getJumpFactor. */
export const blockJumpFactorOf = (name: string) => (name === 'honey_block' ? 0.5 : 1);
/** updateEntityAfterFallOn: slime reverses the vertical speed, beds return 66 %. 0 = the speed is zeroed. */
export const bounceOf = (name: string) => (name === 'slime_block' ? 1 : name === 'bed' ? 0.66 : 0);
/** Block.fallOn damage multiplier: hay bale / honey block 0.2, slime block 0 (sneaking players get the full damage). */
export const fallDamageMultiplierOf = (name: string) => (name === 'hay_block' || name === 'honey_block' ? 0.2 : name === 'slime_block' ? 0 : 1);
/** BedBlock.fallOn passes half the fall distance on. */
export const fallDistanceScaleOf = (name: string) => (name === 'bed' ? 0.5 : 1);
const CLIMBABLE = new Set(['ladder', 'vine', 'weeping_vines', 'weeping_vines_plant', 'twisting_vines', 'twisting_vines_plant', 'cave_vines', 'cave_vines_plant']);
/** #minecraft:climbable (scaffolding has its own handling in systems/gameplay.ts). */
export const isClimbable = (name: string) => CLIMBABLE.has(name);

/** LivingEntity.calculateFallDamage: ceil((distance − safe_fall_distance) × multiplier), safe distance = 3 + Jump Boost level. */
export function fallDamageAmount(distance: number, jumpBoostLevel = 0, multiplier = 1): number {
  const d = Math.ceil((distance - 3 - jumpBoostLevel) * multiplier);
  return d > 0 ? d : 0;
}
export const portalWait = (creative: boolean) => (creative ? PORTAL_WAIT_CREATIVE : PORTAL_WAIT_SURVIVAL);

// ---- Simulation types ------------------------------------------------------------------------------------------------------------
export interface MotionBody {
  x: number; y: number; z: number;
  /** blocks / tick */
  vx: number; vy: number; vz: number;
  onGround: boolean;
  /** Accumulated descent since the last reset (Entity.fallDistance). */
  fallDistance: number;
  horizontalCollision: boolean;
  jumpDelay: number;
}
export const newBody = (x = 0, y = 0, z = 0): MotionBody => ({ x, y, z, vx: 0, vy: 0, vz: 0, onGround: false, fallDistance: 0, horizontalCollision: false, jumpDelay: 0 });

export interface MotionWorld {
  /** True when a player box (0.6 wide) of `height` with its feet at (x, y, z) overlaps something solid. */
  collides(x: number, y: number, z: number, height: number): boolean;
}
export type MotionMode = 'walk' | 'fly' | 'noclip';
export interface TickInput {
  /** World-space movement intent, |m| ≤ 1. */
  mx: number; mz: number;
  jump: boolean; descend: boolean; sneak: boolean; sprint: boolean;
  /** Engine convention: forward = (−sin yaw, −cos yaw); pitch > 0 looks up. */
  yaw: number; pitch: number;
}
export interface TickEnv {
  mode: MotionMode;
  height: number;
  water: boolean; lava: boolean; lavaDeep: boolean; climbable: boolean; swimming: boolean;
  /** Water at the head (swimming keeps steering vertically while submerged). */
  waterAbove: boolean;
  /** movement_speed attribute in blocks / tick: 0.1 × sprint 1.3 × effects × freezing … */
  speed: number;
  /** Input multiplier: sneaking / crawling 0.3 (+ Swift Sneak), using an item 0.2. */
  inputScale: number;
  slip: number;
  blockSpeed: number;
  jumpPower: number;
  slowFalling: boolean;
  /** Levitation amplifier + 1, 0 = none. */
  levitation: number;
  flySpeed: number;
  depthStrider: number;
  dolphinsGrace: boolean;
  /** Entity.makeStuckInBlock horizontal factor (cobweb 0.25); 1 = not stuck. */
  stuck: number;
  stuckY?: number;
  /** Scaffolding / powder snow / bubble columns — receives and returns blocks / tick. */
  adjustVertical?: (vy: number) => number;
  /** Bounce factor of the block the body landed on (slime 1, bed 0.66). */
  bounce?: (b: MotionBody) => number;
  stepHeight?: number;
}
export interface MoveResult {
  dx: number; dy: number; dz: number;
  colX: boolean; colY: boolean; colZ: boolean;
  /** Vertical collision while moving down (Entity.verticalCollisionBelow) or a successful step. */
  below: boolean;
  stepped: boolean;
}
export interface TickResult {
  landed: boolean;
  /** Vertical speed of the landing move (blocks / tick). */
  impactVy: number;
  /** Fall distance handed to Block.fallOn — accumulated *before* the landing move, like Entity.checkFallDamage. */
  fallDistance: number;
  jumped: boolean;
  climbing: boolean;
  dx: number; dy: number; dz: number;
  /** Horizontal speed lost against walls (blocks / tick). */
  speedLostH: number;
}

// ---- Collision -------------------------------------------------------------------------------------------------------------------
const SUB_STEP = 0.45;
const BISECT = 22;

/** Largest displacement ≤ |d| along one axis before the box hits something (sub-stepped so fast falls cannot tunnel). */
function sweepAxis(w: MotionWorld, h: number, x: number, y: number, z: number, axis: 0 | 1 | 2, d: number): number {
  if (d === 0) return 0;
  // Java ignores shapes the box already overlaps: an entity stuck inside a block can always move out of it.
  if (w.collides(x, y, z, h)) return d;
  const n = Math.max(1, Math.ceil(Math.abs(d) / SUB_STEP)), step = d / n;
  let moved = 0;
  for (let i = 0; i < n; i++) {
    const at = (t: number) => {
      const o = moved + step * t;
      return axis === 0 ? w.collides(x + o, y, z, h) : axis === 1 ? w.collides(x, y + o, z, h) : w.collides(x, y, z + o, h);
    };
    if (!at(1)) { moved += step; continue; }
    let lo = 0, hi = 1;
    for (let k = 0; k < BISECT; k++) { const mid = (lo + hi) / 2; if (at(mid)) hi = mid; else lo = mid; }
    return moved + step * lo;
  }
  return moved;
}

/** Y first, then the larger horizontal axis, then the smaller one (Entity.collideWithShapes). */
function collideBox(w: MotionWorld, h: number, x: number, y: number, z: number, dx: number, dy: number, dz: number) {
  const ry = sweepAxis(w, h, x, y, z, 1, dy);
  let rx = 0, rz = 0;
  if (Math.abs(dx) < Math.abs(dz)) {
    rz = sweepAxis(w, h, x, y + ry, z, 2, dz);
    rx = sweepAxis(w, h, x, y + ry, z + rz, 0, dx);
  } else {
    rx = sweepAxis(w, h, x, y + ry, z, 0, dx);
    rz = sweepAxis(w, h, x + rx, y + ry, z, 2, dz);
  }
  return { rx, ry, rz };
}

const near = (a: number, b: number) => Math.abs(a - b) < 1e-9;

/**
 * Entity.move: sneaking players back off edges (maybeBackOffFromEdge, 0.05 steps against a 0.6 drop), the box collides axis by axis,
 * and a blocked horizontal move retries candidate step-up heights (1/16 carpet, 2/16 diode, 3/16 trapdoor, up to 0.6 slab/stairs)
 * so thin floor blocks never snag under 2-block doorways or while airborne.
 */
export function moveBody(b: MotionBody, dx: number, dy: number, dz: number, env: TickEnv, w: MotionWorld, sneak: boolean): MoveResult {
  if (env.mode === 'noclip') {
    b.x += dx; b.y += dy; b.z += dz;
    b.onGround = false; b.horizontalCollision = false;
    return { dx, dy, dz, colX: false, colY: false, colZ: false, below: false, stepped: false };
  }
  const h = env.height, step = env.stepHeight ?? STEP_HEIGHT;
  if (env.stuck < 1) {
    const sy = env.stuckY ?? 0.05;
    dx *= env.stuck; dy *= sy; dz *= env.stuck;
    b.vx = 0; b.vy = 0; b.vz = 0;
  }
  if (sneak && env.mode === 'walk' && dy <= 0) {
    const canFall = (ox: number, oz: number, dist: number) => !w.collides(b.x + ox, b.y - dist, b.z + oz, dist);
    if (b.onGround || (b.fallDistance < step && !canFall(0, 0, step - b.fallDistance))) {
      const sx = Math.sign(dx) * 0.05, sz = Math.sign(dz) * 0.05;
      while (dx !== 0 && canFall(dx, 0, step)) { if (Math.abs(dx) <= 0.05) { dx = 0; break; } dx -= sx; }
      while (dz !== 0 && canFall(0, dz, step)) { if (Math.abs(dz) <= 0.05) { dz = 0; break; } dz -= sz; }
      while (dx !== 0 && dz !== 0 && canFall(dx, dz, step)) {
        dx = Math.abs(dx) <= 0.05 ? 0 : dx - sx;
        dz = Math.abs(dz) <= 0.05 ? 0 : dz - sz;
      }
    }
  }
  let { rx, ry, rz } = collideBox(w, h, b.x, b.y, b.z, dx, dy, dz);
  let colX = !near(rx, dx), colZ = !near(rz, dz);
  const colY = !near(ry, dy), landing = colY && dy < 0;
  let stepped = false;
  if (step > 0 && env.mode !== 'fly' && (colX || colZ)) {
    const baseY = landing ? b.y + ry : b.y;
    const surfaceStep = (env.water || env.lava) && !env.waterAbove;
    const maxStep = (b.onGround || landing || surfaceStep) ? step : Math.min(step, 0.2);
    const candidates = maxStep <= 0.2 ? [0.065, 0.13, maxStep] : [0.065, 0.13, 0.2, maxStep];
    for (let ci = 0; ci < candidates.length; ci++) {
      const targetUp = candidates[ci];
      if (targetUp > maxStep + 1e-6) continue;
      const up = sweepAxis(w, h, b.x, baseY, b.z, 1, targetUp);
      if (up <= 1e-6) continue;
      const s = collideBox(w, h, b.x, baseY + up, b.z, dx, 0, dz);
      const down = sweepAxis(w, h, b.x + s.rx, baseY + up, b.z + s.rz, 1, -up);
      if (s.rx * s.rx + s.rz * s.rz > rx * rx + rz * rz + 1e-12) {
        rx = s.rx; rz = s.rz; ry = baseY + up + down - b.y;
        colX = !near(rx, dx); colZ = !near(rz, dz);
        stepped = true;
        if (!colX && !colZ) break;
      }
    }
  }
  b.x += rx; b.y += ry; b.z += rz;
  b.horizontalCollision = colX || colZ;
  const below = landing || (env.mode !== 'fly' && stepped && dy <= 0);
  b.onGround = below;
  if (colX) b.vx = 0;
  if (colZ) b.vz = 0;
  if (colY && !stepped) {
    const bounce = dy < 0 && !sneak && env.bounce ? env.bounce(b) : 0;
    b.vy = bounce > 0 && b.vy < 0 ? -b.vy * bounce : 0;
  } else if (stepped && b.vy < 0) b.vy = 0;
  return { dx: rx, dy: ry, dz: rz, colX, colY, colZ, below, stepped };
}

/** Moves, then does the Entity.checkFallDamage bookkeeping. */
export function integrate(b: MotionBody, dx: number, dy: number, dz: number, env: TickEnv, w: MotionWorld, sneak: boolean, res: TickResult): MoveResult {
  const wasGround = b.onGround, hBefore = Math.hypot(b.vx, b.vz);
  const mv = moveBody(b, dx, dy, dz, env, w, sneak);
  res.dx = mv.dx; res.dy = mv.dy; res.dz = mv.dz;
  res.speedLostH = Math.max(0, hBefore - Math.hypot(b.vx, b.vz));
  if (b.onGround) {
    res.fallDistance = b.fallDistance;
    res.landed = !wasGround || b.fallDistance > 0;
    res.impactVy = dy;
    b.fallDistance = 0;
  } else if (mv.dy < 0) b.fallDistance -= mv.dy;
  return mv;
}

export const newResult = (): TickResult => ({ landed: false, impactVy: 0, fallDistance: 0, jumped: false, climbing: false, dx: 0, dy: 0, dz: 0, speedLostH: 0 });

/** One player tick: LivingEntity.aiStep (velocity cut-off, jumping, flight thrust) followed by travel() and Entity.move(). */
export function playerTick(b: MotionBody, inp: TickInput, env: TickEnv, w: MotionWorld): TickResult {
  const res = newResult();
  if (Math.abs(b.vx) < MIN_VELOCITY) b.vx = 0;
  if (Math.abs(b.vy) < MIN_VELOCITY) b.vy = 0;
  if (Math.abs(b.vz) < MIN_VELOCITY) b.vz = 0;
  if (b.jumpDelay > 0) b.jumpDelay--;
  const fly = env.mode !== 'walk';
  if (inp.jump && !fly) {
    if (env.water || env.lava) b.vy += FLUID_JUMP;                                   // jumpInLiquid
    else if (b.onGround && b.jumpDelay === 0) {                                      // jumpFromGround
      b.vy = env.jumpPower;
      if (inp.sprint) { b.vx += -Math.sin(inp.yaw) * SPRINT_JUMP_BOOST; b.vz += -Math.cos(inp.yaw) * SPRINT_JUMP_BOOST; }
      b.jumpDelay = JUMP_DELAY_TICKS;
      res.jumped = true;
    }
  } else if (!inp.jump) b.jumpDelay = 0;
  if (fly) { const j = (inp.jump ? 1 : 0) - (inp.descend ? 1 : 0); if (j) b.vy += j * FLY_SPEED * 3; }

  let ix = inp.mx * INPUT_DAMP * env.inputScale, iz = inp.mz * INPUT_DAMP * env.inputScale;
  const il = Math.hypot(ix, iz);
  if (il > 1) { ix /= il; iz /= il; }
  if (env.adjustVertical && !fly) b.vy = env.adjustVertical(b.vy);
  const falling = b.vy <= 0;
  const gravity = env.slowFalling && falling ? SLOW_FALL_GRAVITY : GRAVITY;
  const yStart = b.y;
  const groundAccel = env.speed * GROUND_ACCEL_K / (env.slip * env.slip * env.slip);

  if (fly) {
    const d = b.vy;
    const accel = b.onGround ? groundAccel : env.flySpeed, f = b.onGround ? env.slip * AIR_FRICTION : AIR_FRICTION;
    b.vx += ix * accel; b.vz += iz * accel;
    integrate(b, b.vx, b.vy, b.vz, env, w, false, res);
    b.vx *= f; b.vz *= f; b.vy = d * 0.6;
    b.fallDistance = 0;
  } else if (env.water) {
    if (env.swimming) {
      const look = Math.sin(inp.pitch), e = look < -0.2 ? 0.085 : 0.06;
      if (look <= 0 || inp.jump || env.waterAbove) b.vy += (look - b.vy) * e;
    }
    let f = inp.sprint ? WATER_DRAG_SPRINT : WATER_DRAG, g = WATER_ACCEL;
    let eff = clamp(env.depthStrider, 0, 3) / 3;
    if (!b.onGround) eff *= 0.5;
    if (eff > 0) { f += (0.54600006 - f) * eff; g += (env.speed - g) * eff; }
    if (env.dolphinsGrace) f = 0.96;
    b.vx += ix * g; b.vz += iz * g;
    const vx0 = b.vx, vz0 = b.vz;
    const mv = integrate(b, b.vx, b.vy, b.vz, env, w, inp.sneak, res);
    if ((mv.colX || mv.colZ) && env.climbable) b.vy = CLIMB_SPEED;
    b.vx *= f; b.vy *= WATER_DRAG_Y; b.vz *= f;
    if (!inp.sprint) {
      const gs = gravity / 16;
      b.vy = falling && Math.abs(b.vy - 0.005) >= 0.003 && Math.abs(b.vy - gs) < 0.003 ? -0.003 : b.vy - gs;
    }
    if ((mv.colX || mv.colZ) && (!w.collides(b.x + vx0, yStart + b.vy + 0.6, b.z + vz0, env.height) || !w.collides(b.x + vx0, b.y + 0.65, b.z + vz0, env.height))) b.vy = 0.30000001192092896;
    b.fallDistance = 0;
  } else if (env.lava) {
    b.vx += ix * WATER_ACCEL; b.vz += iz * WATER_ACCEL;
    const vx0 = b.vx, vz0 = b.vz;
    const mv = integrate(b, b.vx, b.vy, b.vz, env, w, inp.sneak, res);
    if (!env.lavaDeep) {
      b.vx *= 0.5; b.vy *= WATER_DRAG_Y; b.vz *= 0.5;
      const gs = gravity / 16;
      b.vy = falling && Math.abs(b.vy - 0.005) >= 0.003 && Math.abs(b.vy - gs) < 0.003 ? -0.003 : b.vy - gs;
    } else { b.vx *= 0.5; b.vy *= 0.5; b.vz *= 0.5; }
    b.vy -= gravity / 4;
    if ((mv.colX || mv.colZ) && (!w.collides(b.x + vx0, yStart + b.vy + 0.6, b.z + vz0, env.height) || !w.collides(b.x + vx0, b.y + 0.65, b.z + vz0, env.height))) b.vy = 0.30000001192092896;
  } else {
    const accel = b.onGround ? groundAccel : inp.sprint ? AIR_ACCEL_SPRINT : AIR_ACCEL;
    const f = b.onGround ? env.slip * AIR_FRICTION : AIR_FRICTION;
    b.vx += ix * accel; b.vz += iz * accel;
    if (env.climbable) {                                                             // handleOnClimbable
      b.fallDistance = 0;
      b.vx = clamp(b.vx, -CLIMB_MAX_H, CLIMB_MAX_H);
      b.vz = clamp(b.vz, -CLIMB_MAX_H, CLIMB_MAX_H);
      b.vy = Math.max(b.vy, -CLIMB_MAX_FALL);
      if (b.vy < 0 && inp.sneak) b.vy = 0;
    }
    const mv = integrate(b, b.vx, b.vy, b.vz, env, w, inp.sneak, res);
    if (env.climbable && (mv.colX || mv.colZ || inp.jump)) { b.vy = CLIMB_SPEED; res.climbing = true; }
    if (env.levitation > 0) b.vy += (0.05 * env.levitation - b.vy) * 0.2;
    else b.vy -= gravity;
    b.vx *= f; b.vy *= DRAG_Y; b.vz *= f;
  }
  if (env.blockSpeed !== 1 && !fly) { b.vx *= env.blockSpeed; b.vz *= env.blockSpeed; }
  return res;
}

// ---- Fixed step --------------------------------------------------------------------------------------------------------------------
/** Accumulates frame time into whole 50 ms ticks (at most `maxBacklog` seconds are kept, like ElytraFlight). */
export class FixedStepper {
  acc = 0;
  constructor(public maxBacklog = 0.25) {}
  advance(dt: number): number {
    this.acc = Math.min(this.acc + Math.max(0, dt), this.maxBacklog);
    let n = 0;
    while (this.acc >= TICK - 1e-9) { this.acc -= TICK; n++; }
    if (this.acc < 0) this.acc = 0;
    return n;
  }
  /** Interpolation factor between the previous and the current tick. */
  get alpha() { return clamp(this.acc / TICK, 0, 1); }
}

// ---- Hazards: burning, environmental damage cadence, portal charge ----------------------------------------------------------------
export interface HazardState {
  tick: number;
  /** Entity.remainingFireTicks: > 0 burning, ≤ 0 the fire-immune window after the fire went out (players: −20). */
  fireTicks: number;
  lastHurtTick: number;
  lastHurtAmount: number;
  portalTicks: number;
  deaths: number;
}
export const newHazardState = (): HazardState => ({ tick: 0, fireTicks: -PLAYER_FIRE_IMMUNE_TICKS, lastHurtTick: -1000, lastHurtAmount: 0, portalTicks: 0, deaths: -1 });

/** LivingEntity.hurt cooldown: within 10 ticks of the last hit only a bigger hit gets through (its difference). */
export function envHurtAmount(s: HazardState, amount: number): number {
  if (s.tick - s.lastHurtTick >= HURT_COOLDOWN_TICKS) { s.lastHurtTick = s.tick; s.lastHurtAmount = amount; return amount; }
  if (amount > s.lastHurtAmount) { const d = amount - s.lastHurtAmount; s.lastHurtAmount = amount; return d; }
  return 0;
}

export interface FireContext { inFire: boolean; fireDamage: number; inLava: boolean; extinguish: boolean }
/**
 * One tick of burning: Entity.baseTick (1 damage when remainingFireTicks % 20 == 0, not in lava), lavaHurt (ignite 15 s, 4 damage),
 * BaseFireBlock.entityInside (+1 fire tick, ignite 8 s when the counter reaches 0, 1 / 2 damage) and Entity.move (no fire around →
 * fire-immune window; water, rain, bubble columns and powder snow put the fire out). Returns the fire damage to deal this tick.
 */
export function fireTick(s: HazardState, c: FireContext): number {
  let dmg = 0;
  if (s.fireTicks > 0) { if (s.fireTicks % 20 === 0 && !c.inLava) dmg = BURN_DAMAGE; s.fireTicks--; }
  if (c.inLava) { s.fireTicks = Math.max(s.fireTicks, LAVA_FIRE_TICKS); dmg = Math.max(dmg, LAVA_DAMAGE); }
  if (c.inFire) { s.fireTicks++; if (s.fireTicks === 0) s.fireTicks = FIRE_IGNITE_TICKS; dmg = Math.max(dmg, c.fireDamage); }
  if (!c.inFire && !c.inLava && s.fireTicks <= 0) s.fireTicks = -PLAYER_FIRE_IMMUNE_TICKS;
  if (s.fireTicks > 0 && c.extinguish) s.fireTicks = -PLAYER_FIRE_IMMUNE_TICKS;
  return dmg;
}
export const resetFire = (s: HazardState) => { s.fireTicks = -PLAYER_FIRE_IMMUNE_TICKS; };

// ---- Per-engine state (kept outside the Engine class so engine.ts needs no new fields) --------------------------------------------
export interface EngineMotion {
  stepper: FixedStepper;
  body: MotionBody;
  prev: { x: number; y: number; z: number };
  cur: { x: number; y: number; z: number };
  phys: { x: number; y: number; z: number };
  init: boolean;
}
const motions = new WeakMap<object, EngineMotion>();
const hazards = new WeakMap<object, HazardState>();
export function motionOf(owner: object): EngineMotion {
  let m = motions.get(owner);
  if (!m) motions.set(owner, m = { stepper: new FixedStepper(), body: newBody(), prev: { x: 0, y: 0, z: 0 }, cur: { x: 0, y: 0, z: 0 }, phys: { x: 0, y: 0, z: 0 }, init: false });
  return m;
}
export function hazardsOf(owner: object): HazardState {
  let h = hazards.get(owner);
  if (!h) hazards.set(owner, h = newHazardState());
  return h;
}
/** Sets the player on fire for at least `seconds` (Entity.igniteForSeconds) — for blazes, Fire Aspect, fire charges … */
export function ignite(owner: object, seconds: number) { const s = hazardsOf(owner); s.fireTicks = Math.max(s.fireTicks, Math.floor(seconds * TPS)); }
export const isBurning = (owner: object) => hazardsOf(owner).fireTicks > 0;
export const extinguish = (owner: object) => resetFire(hazardsOf(owner));
