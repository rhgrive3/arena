import { BLOCKS, ID, type BlockDef } from './data';

// A cell keeps its block ID in the low 12 bits and its state in the high 4.
// Old saves contain plain IDs and therefore naturally decode to state zero.
export const BLOCK_ID_MASK = 0x0fff;
export const STATE_SHIFT = 12;
export const WATERLOGGED_BIT = 8;
export type Facing = 0 | 1 | 2 | 3;
export type Face = 0 | 1 | 2 | 3 | 4 | 5;
export const FACING_FACES: readonly Face[] = [4, 1, 5, 0];

// World-coordinate waterlogging table (supports 100% of waterloggable blocks including 4-bit-full stairs/trapdoors/doors).
const waterloggedCoords = new Set<string>();

export function blockId(cell: number): number {
  return cell < 0 ? cell : cell & BLOCK_ID_MASK;
}

export function blockState(cell: number): number {
  return cell < 0 ? 0 : (cell >>> STATE_SHIFT) & 15;
}

export function makeCell(id: number, state = 0): number {
  if (!Number.isInteger(id) || id < 0 || id > BLOCK_ID_MASK || !Number.isInteger(state) || state < 0 || state > 15) {
    throw new RangeError('Invalid block ID or block state');
  }
  return id === 0 ? 0 : id | (state << STATE_SHIFT);
}

/** True if a block definition can be waterlogged in Java Edition 1.21. */
export function canWaterlog(def: BlockDef | undefined): boolean {
  if (!def || def.id <= 0) return false;
  const n = def.name;
  if (
    def.shape === 'slab' ||
    def.shape === 'stairs' ||
    def.shape === 'fence' ||
    def.shape === 'pane' ||
    def.shape === 'chest' ||
    def.shape === 'trapdoor' ||
    def.shape === 'lantern'
  ) {
    return true;
  }
  return (
    n.endsWith('_wall') ||
    n.endsWith('_sign') ||
    n.endsWith('_banner') ||
    n.endsWith('_coral') ||
    n.endsWith('_coral_fan') ||
    n.endsWith('copper_grate') ||
    n.endsWith('_candle') ||
    n === 'candle' ||
    n === 'chain' ||
    n === 'ladder' ||
    n === 'scaffolding' ||
    n === 'conduit' ||
    n === 'sea_pickle' ||
    n === 'decorated_pot' ||
    n === 'Lightning_rod'.toLowerCase() ||
    n === 'ender_chest' ||
    n === 'trapped_chest' ||
    n === 'campfire' ||
    n === 'soul_campfire' ||
    n === 'unlit_campfire' ||
    n === 'sculk_sensor' ||
    n === 'calibrated_sculk_sensor' ||
    n === 'sculk_shrieker' ||
    n === 'amethyst_cluster' ||
    n.endsWith('_amethyst_bud') ||
    n === 'pointed_dripstone' ||
    n === 'heavy_core' ||
    n === 'light' ||
    n === 'barrier'
  );
}

/** Sets or clears the cell-level waterlogged bit (bit 3 = 8) on waterloggable blocks whose state uses <= 3 bits. */
export function withWaterlogged(cell: number, waterlogged = true): number {
  const id = blockId(cell);
  if (id <= 0) return waterlogged ? (ID.water ?? 0) : 0;
  const st = blockState(cell);
  return makeCell(id, waterlogged ? (st | WATERLOGGED_BIT) : (st & ~WATERLOGGED_BIT));
}

export function isCellWaterlogged(cell: number): boolean {
  const id = blockId(cell);
  if (id <= 0) return false;
  const def = BLOCKS[id];
  if (!canWaterlog(def)) return false;
  if (def.shape === 'trapdoor' || def.shape === 'door') return false; // bit 3 is open/shut on doors & trapdoors
  return (blockState(cell) & WATERLOGGED_BIT) !== 0;
}

export function setWaterloggedAt(x: number, y: number, z: number, waterlogged: boolean): void {
  const k = `${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`;
  if (waterlogged) waterloggedCoords.add(k);
  else waterloggedCoords.delete(k);
}

export function isWaterloggedAt(x: number, y: number, z: number, cell?: number): boolean {
  if (cell !== undefined && isCellWaterlogged(cell)) return true;
  return waterloggedCoords.has(`${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`);
}

/**
 * Finds the adjacent partner of a Double Chest (Large Chest) at (x, y, z), or null if single chest.
 * In Java Edition, two chests of the same type (`chest` or `trapped_chest`) with the same facing direction
 * placed side-by-side perpendicular to their facing direction combine into a 54-slot Large Chest.
 */
export function doubleChestPartner(
  getCell: (x: number, y: number, z: number) => number,
  x: number,
  y: number,
  z: number,
): [number, number, number] | null {
  const selfCell = getCell(x, y, z);
  const selfId = blockId(selfCell);
  const selfName = BLOCKS[selfId]?.name;
  if (selfName !== 'chest' && selfName !== 'trapped_chest') return null;
  const facing = blockState(selfCell) & 3;
  // Facing 0 (+Z) or 2 (-Z) -> partners lie along X (±1, 0). Facing 1 (-X) or 3 (+X) -> partners lie along Z (0, ±1).
  const dirs: readonly [number, number][] = (facing & 1) === 0 ? [[-1, 0], [1, 0]] : [[0, -1], [0, 1]];
  for (const [dx, dz] of dirs) {
    const nx = x + dx, nz = z + dz;
    const nCell = getCell(nx, y, nz);
    if (blockId(nCell) === selfId && (blockState(nCell) & 3) === facing) {
      return [nx, y, nz];
    }
  }
  return null;
}

/** Returns a unified 54-slot array for a Double Chest (or 27-slot array for a single chest). */
export function getDoubleChestSlots<T = unknown>(
  containers: Record<string, (T | null)[]>,
  getCell: (x: number, y: number, z: number) => number,
  x: number,
  y: number,
  z: number,
): (T | null)[] {
  const k1 = `${x},${y},${z}`;
  if (!containers[k1]) containers[k1] = new Array(27).fill(null);
  const partner = doubleChestPartner(getCell, x, y, z);
  if (!partner) return containers[k1];
  const [px, py, pz] = partner;
  const k2 = `${px},${py},${pz}`;
  if (!containers[k2]) containers[k2] = new Array(27).fill(null);
  // Canonical ordering: lower X or lower Z half comes first
  const firstFirst = x < px || (x === px && z < pz);
  const left = firstFirst ? containers[k1] : containers[k2];
  const right = firstFirst ? containers[k2] : containers[k1];
  return [...left.slice(0, 27), ...right.slice(0, 27)];
}

// The camera looks along -Z at yaw 0; the opening faces the player.
export function facingForYaw(yaw: number): Facing {
  return ((Math.round(-yaw / (Math.PI / 2)) % 4 + 4) % 4) as Facing;
}

export function isHorizontalFacing(name: string): boolean {
  const block = name.replace(/^open_/, '');
  return block === 'chest' || block === 'trapped_chest' || block === 'ender_chest' || block === 'barrel' ||
    block === 'furnace' || block === 'blast_furnace' || block === 'smoker' ||
    block === 'piston' || block === 'sticky_piston' || block === 'observer' || block === 'dropper' || block === 'dispenser' ||
    block === 'end_portal_frame' || block === 'dragon_head' || block === 'chiseled_bookshelf' || block === 'carved_pumpkin' ||
    block.endsWith('_glazed_terracotta');
}

/**
 * Redstone components whose state is a direction in the redstone engine's order: 0 +X, 1 +Z, 2 -X, 3 -Z, 4 up, 5 down.
 */
export function isDirectional(name: string): boolean {
  return name === 'piston' || name === 'sticky_piston' || name === 'observer' || name === 'dropper' || name === 'dispenser' || name === 'crafter' || name === 'hopper';
}

export function isAxisBlock(name: string): boolean {
  return name.endsWith('_log') || name === 'purpur_pillar' || name === 'quartz_pillar' || name === 'bone_block' || name === 'basalt' || name === 'hay_block';
}

export function isSlabBlock(def: BlockDef): boolean {
  return def.shape === 'slab' && def.name.endsWith('_slab');
}

export function isAttachable(def: BlockDef): boolean {
  return def.shape === 'torch' && def.name !== 'lantern' && def.name !== 'brewing_stand' && def.name !== 'end_rod';
}

export function isUpperPlacement(normal: { y:number }, hitY: number): boolean {
  return normal.y < 0 || (normal.y === 0 && hitY > .5);
}

export function stateForPlacement(def: BlockDef, yaw: number, normal: { x: number; y: number; z: number }, hitY = 0, pitch = 0): number {
  if (isDirectional(def.name)) {
    if (def.name === 'hopper') return normal.y !== 0 ? 5 : normal.x > 0 ? 2 : normal.x < 0 ? 0 : normal.z > 0 ? 3 : 1;
    const f = facingForYaw(yaw);
    if (def.name === 'observer') return pitch < -0.87 ? 5 : pitch > 0.87 ? 4 : (f + 3) % 4;
    return pitch < -0.87 ? 4 : pitch > 0.87 ? 5 : (f + 1) % 4;
  }
  if (def.shape === 'end_rod') {
    if (normal.y > 0) return 0;
    if (normal.y < 0) return 5;
    return normal.x > 0 ? 1 : normal.x < 0 ? 2 : normal.z > 0 ? 3 : 4;
  }
  if (isHorizontalFacing(def.name)) return facingForYaw(yaw);
  if (isAxisBlock(def.name)) return normal.x !== 0 ? 1 : normal.z !== 0 ? 2 : 0;
  if (isSlabBlock(def)) return isUpperPlacement(normal,hitY) ? 1 : 0;
  if (def.shape === 'stairs') return facingForYaw(yaw) | (isUpperPlacement(normal,hitY) ? 4 : 0);
  if (def.shape === 'door') return [2, 1, 0, 3][facingForYaw(yaw)];
  if (def.shape === 'trapdoor') return [0, 3, 2, 1][facingForYaw(yaw)] | (isUpperPlacement(normal, hitY) ? 4 : 0);
  if (def.name === 'bed' || def.name.endsWith('_bed')) return [3, 0, 1, 2][facingForYaw(yaw)];
  if (def.name === 'ladder') return normal.y !== 0 ? -1 : normal.x > 0 ? 1 : normal.x < 0 ? 3 : normal.z > 0 ? 0 : 2;
  if (def.name === 'tripwire_hook' && normal.y !== 0) return -1;
  if (isAttachable(def)) {
    if (normal.y > 0) return 0;
    if (normal.y < 0) return def.name === 'lever' || def.name.endsWith('_button') ? 5 : -1;
    return normal.x > 0 ? 1 : normal.x < 0 ? 2 : normal.z > 0 ? 3 : 4;
  }
  if (def.name === 'end_rod') {
    if (normal.y > 0) return 0;
    if (normal.y < 0) return 5;
    return normal.x > 0 ? 1 : normal.x < 0 ? 2 : normal.z > 0 ? 3 : 4;
  }
  if (def.name.endsWith('_banner')) {
    if (normal.y > 0) return facingForYaw(yaw);
    if (normal.y < 0) return -1;
    return 4 + (normal.z > 0 ? 0 : normal.x < 0 ? 1 : normal.z < 0 ? 2 : 3);
  }
  if (def.name.endsWith('_sign')) {
    if (def.name.includes('hanging')) return facingForYaw(yaw);
    if (normal.y > 0) return facingForYaw(yaw);
    if (normal.y < 0) return -1;
    return 4 + (normal.z > 0 ? 0 : normal.x < 0 ? 1 : normal.z < 0 ? 2 : 3);
  }
  if (def.shape === 'pane' && (def.name.endsWith('glass_pane') || def.name === 'iron_bars')) return (facingForYaw(yaw) & 1) ^ 1;
  return 0;
}

export function localFaceForState(def: BlockDef, state: number, worldFace: Face): Face {
  if (isAxisBlock(def.name)) {
    const axis = state & 3;
    if (axis === 1) return worldFace < 2 ? 2 : 0;
    if (axis === 2) return worldFace >= 4 ? 2 : 0;
    return worldFace;
  }
  if (isDirectional(def.name)) {
    const d = state & 7;
    if (d === 4) return worldFace === 2 ? 4 : worldFace === 3 ? 5 : 0;
    if (d === 5) return worldFace === 3 ? 4 : worldFace === 2 ? 5 : 0;
    const front = [0, 4, 1, 5][d];
    const back = [1, 5, 0, 4][d];
    if (worldFace === front) return 4;
    if (worldFace === back) return 5;
    if (worldFace < 2 || worldFace >= 4) return 0;
    return worldFace;
  }
  if (isHorizontalFacing(def.name)) {
    if (worldFace === 2 || worldFace === 3) return worldFace;
    const front = FACING_FACES[state & 3];
    if (worldFace === front) return 4;
    return 0;
  }
  return worldFace;
}
