import type { Context2D } from './canvas';

const rgb = (hex: string): [number, number, number] => [
  Number.parseInt(hex.slice(1, 3), 16) || 0,
  Number.parseInt(hex.slice(3, 5), 16) || 0,
  Number.parseInt(hex.slice(5, 7), 16) || 0,
];

const clampByte = (v: number): number => Math.max(0, Math.min(255, Math.round(v)));

function hexToRgb(hex: string): [number, number, number] {
  return rgb(hex.startsWith('#') ? hex : '#888888');
}

function lerpRgb(a: [number, number, number], b: [number, number, number], t: number): [number, number, number] {
  const u = Math.max(0, Math.min(1, t));
  return [
    a[0] + (b[0] - a[0]) * u,
    a[1] + (b[1] - a[1]) * u,
    a[2] + (b[2] - a[2]) * u,
  ];
}

function sampleRamp(ramp: string[], t: number): [number, number, number] {
  const u = Math.max(0, Math.min(0.9999, t)) * (ramp.length - 1);
  const idx = Math.floor(u);
  const frac = u - idx;
  return lerpRgb(hexToRgb(ramp[idx]), hexToRgb(ramp[Math.min(ramp.length - 1, idx + 1)]), frac);
}

/** Deterministic integer hash on a 16x16 torus (strictly periodic mod 16). */
function hash16(x: number, y: number, seed: number): number {
  const wx = ((x % 16) + 16) % 16;
  const wy = ((y % 16) + 16) % 16;
  let h = (wx * 374761393 + wy * 668265263 + seed * 1442695041) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

/**
 * Smooth periodic value noise on a 16x16 torus with wavelength `periodX` x `periodY` pixels.
 * Because `cellsX = 16 / periodX`, `x = 0` and `x = 16` wrap seamlessly around the torus.
 */
function periodicNoise16(x: number, y: number, periodX: number, periodY: number, seed: number): number {
  const cellsX = Math.max(1, Math.round(16 / periodX));
  const cellsY = Math.max(1, Math.round(16 / periodY));
  const gx = (x / 16) * cellsX;
  const gy = (y / 16) * cellsY;
  const x0 = Math.floor(gx);
  const y0 = Math.floor(gy);
  const fx = gx - x0;
  const fy = gy - y0;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const ix0 = ((x0 % cellsX) + cellsX) % cellsX;
  const iy0 = ((y0 % cellsY) + cellsY) % cellsY;
  const ix1 = (ix0 + 1) % cellsX;
  const iy1 = (iy0 + 1) % cellsY;
  const n00 = hash16(ix0, iy0, seed);
  const n10 = hash16(ix1, iy0, seed);
  const n01 = hash16(ix0, iy1, seed);
  const n11 = hash16(ix1, iy1, seed);
  return (n00 * (1 - ux) + n10 * ux) * (1 - uy) + (n01 * (1 - ux) + n11 * ux) * uy;
}

/** Multi-octave periodic FBM on 16x16 torus. */
function fbm16(x: number, y: number, seed: number, periodX = 4, periodY = 4): number {
  const v1 = periodicNoise16(x, y, periodX, periodY, seed);
  const v2 = periodicNoise16(x, y, Math.max(2, periodX >> 1), Math.max(2, periodY >> 1), seed + 101);
  const v3 = hash16(Math.floor(x), Math.floor(y), seed + 202);
  return v1 * 0.56 + v2 * 0.30 + v3 * 0.14;
}

interface VoronoiSample {
  cellId: number;
  dist1: number;
  dist2: number;
  edgeDist: number;
  relX: number;
  relY: number;
  cellRand: number;
}

/**
 * Seamless 16x16 toroidal Voronoi / Worley cellular tessellation for polygonal cobblestones,
 * crystalline minerals, and porous stones.
 */
function voronoi16(
  x: number,
  y: number,
  pts: readonly [number, number, number][],
  metric: 'euclid' | 'octagonal' | 'manhattan' = 'octagonal',
): VoronoiSample {
  let d1 = 1e9;
  let d2 = 1e9;
  let bestId = 0;
  let bestDx = 0;
  let bestDy = 0;
  let bestRand = 0.5;

  for (let i = 0; i < pts.length; i++) {
    const [px, py, pr] = pts[i];
    let dx = x - px;
    let dy = y - py;
    if (dx > 8) dx -= 16;
    else if (dx < -8) dx += 16;
    if (dy > 8) dy -= 16;
    else if (dy < -8) dy += 16;

    let dist: number;
    if (metric === 'manhattan') {
      dist = Math.abs(dx) + Math.abs(dy);
    } else if (metric === 'octagonal') {
      const ax = Math.abs(dx), ay = Math.abs(dy);
      dist = Math.max(ax, ay) * 0.78 + (ax + ay) * 0.32;
    } else {
      dist = Math.hypot(dx, dy);
    }

    if (dist < d1) {
      d2 = d1;
      d1 = dist;
      bestId = i;
      bestDx = dx;
      bestDy = dy;
      bestRand = pr;
    } else if (dist < d2) {
      d2 = dist;
    }
  }

  return {
    cellId: bestId,
    dist1: d1,
    dist2: d2,
    edgeDist: d2 - d1,
    relX: bestDx,
    relY: bestDy,
    cellRand: bestRand,
  };
}

/**
 * 3-Pass Height-Field & Material Buffer for 16x16 Stone Tiles:
 * - Pass 1: Base geological/architectural RGB palette & topology.
 * - Pass 2: 3D Normal-bump directional bevel lighting + 3x3 crevice Ambient Occlusion + warm/cool temperature shift.
 * - Pass 3: Micro-facet crystalline specular glints, sub-texel mortar contrast, & wraparound harmonization.
 */
class StoneSurface16 {
  r = new Float32Array(256);
  g = new Float32Array(256);
  b = new Float32Array(256);
  h = new Float32Array(256);
  spec = new Float32Array(256);

  set(x: number, y: number, col: [number, number, number] | string, height = 0.5, specular = 0) {
    const wx = ((x % 16) + 16) % 16;
    const wy = ((y % 16) + 16) % 16;
    const i = wy * 16 + wx;
    const c = typeof col === 'string' ? hexToRgb(col) : col;
    this.r[i] = c[0];
    this.g[i] = c[1];
    this.b[i] = c[2];
    this.h[i] = height;
    this.spec[i] = specular;
  }

  commit(
    ctx: Context2D,
    pass: 1 | 2 | 3 = 3,
    opts: {
      bevelStrength?: number;
      aoStrength?: number;
      specStrength?: number;
      warmCoolShift?: number;
      wrapEdges?: boolean;
      lightMortar?: boolean;
    } = {},
  ) {
    const bevelStrength = opts.bevelStrength ?? 26;
    const aoStrength = opts.aoStrength ?? 28;
    const specStrength = opts.specStrength ?? 22;
    const warmCoolShift = opts.warmCoolShift ?? 3.5;
    const wrapEdges = opts.wrapEdges ?? true;
    const lightMortar = opts.lightMortar ?? false;

    const img = ctx.createImageData(16, 16);
    const d = img.data;

    const getH = (x: number, y: number): number => {
      const cx = wrapEdges ? ((x % 16) + 16) % 16 : Math.max(0, Math.min(15, x));
      const cy = wrapEdges ? ((y % 16) + 16) % 16 : Math.max(0, Math.min(15, y));
      return this.h[cy * 16 + cx];
    };

    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const i = y * 16 + x;
        let rr = this.r[i];
        let gg = this.g[i];
        let bb = this.b[i];
        const hc = this.h[i];

        if (pass >= 2) {
          const hx0 = getH(x - 1, y);
          const hx1 = getH(x + 1, y);
          const hy0 = getH(x, y - 1);
          const hy1 = getH(x, y + 1);
          const slopeX = hx0 - hx1;
          const slopeY = hy0 - hy1;
          const bevel = (slopeX * 0.52 + slopeY * 0.68) * bevelStrength;

          let sumN = 0;
          for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              if (dx === 0 && dy === 0) continue;
              sumN += getH(x + dx, y + dy);
            }
          }
          const avgN = sumN / 8;
          const crevice = Math.max(0, avgN - hc);
          const crown = Math.max(0, hc - avgN);
          const aoDelta = lightMortar && hc < 0.25
            ? crevice * 6
            : -crevice * aoStrength + crown * (aoStrength * 0.42);

          const totalLight = (lightMortar && hc < 0.25 ? bevel * 0.25 : bevel) + aoDelta;
          const temp = (totalLight / 24) * warmCoolShift;
          rr += totalLight + temp;
          gg += totalLight + temp * 0.35;
          bb += totalLight - temp * 0.65;
        }

        if (pass >= 3) {
          const sp = this.spec[i];
          if (sp > 0) {
            const glint = sp * specStrength;
            rr += glint;
            gg += glint * 1.02;
            bb += glint * 1.06;
          }
          const micro = lightMortar && hc < 0.25 ? 4 : (hc - 0.5) * 7.5;
          rr += micro;
          gg += micro;
          bb += micro;
        }

        const p = i * 4;
        d[p] = clampByte(rr);
        d[p + 1] = clampByte(gg);
        d[p + 2] = clampByte(bb);
        d[p + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  }
}

// Pre-placed toroidal Voronoi cell centers for cobblestone families (13 irregular cobbles)
const COBBLE_PTS: readonly [number, number, number][] = [
  [2.1, 1.8, 0.15], [7.4, 1.5, 0.72], [12.8, 2.2, 0.38],
  [1.4, 6.4, 0.84], [5.8, 5.7, 0.25], [10.5, 6.2, 0.61], [14.7, 6.9, 0.47],
  [3.3, 10.6, 0.53], [8.2, 10.2, 0.19], [13.1, 11.1, 0.89],
  [1.9, 14.5, 0.67], [6.9, 14.3, 0.31], [11.6, 14.8, 0.76],
];

const PRISMARINE_PTS: readonly [number, number, number][] = [
  [2.5, 2.0, 0.20], [8.0, 1.8, 0.75], [13.2, 2.6, 0.45],
  [1.8, 7.2, 0.65], [6.4, 6.5, 0.12], [11.4, 7.0, 0.88],
  [3.6, 11.8, 0.35], [8.8, 11.4, 0.92], [13.8, 12.2, 0.52],
  [1.2, 14.8, 0.78], [6.8, 14.9, 0.28], [11.8, 15.1, 0.60],
];

const PEBBLE_PTS: readonly [number, number, number][] = [
  [1.5, 1.2, 0.12], [5.2, 1.6, 0.85], [9.1, 1.1, 0.34], [13.4, 1.8, 0.68],
  [3.2, 4.5, 0.74], [7.3, 4.1, 0.21], [11.2, 4.8, 0.91], [15.1, 4.3, 0.43],
  [1.2, 8.1, 0.56], [4.9, 7.8, 0.09], [8.8, 8.4, 0.79], [12.7, 7.9, 0.29],
  [2.8, 11.6, 0.88], [6.7, 11.3, 0.41], [10.6, 11.9, 0.16], [14.4, 11.5, 0.63],
  [1.6, 14.7, 0.32], [5.5, 14.4, 0.71], [9.7, 14.9, 0.52], [13.6, 14.6, 0.18],
];

/**
 * Helper to build running-bond masonry bricks with per-brick stone grain, weathered chips,
 * recessed mortar grooves, and 3D bevel height maps.
 */
function buildBrickCourseSurface(
  surf: StoneSurface16,
  ramp: string[],
  mortarCol: string,
  courses: { y0: number; y1: number; xSplits: number[] }[],
  seed: number,
  opts: {
    mortarDepth?: number;
    cracked?: boolean;
    mossy?: boolean;
    mossRamp?: string[];
  } = {},
) {
  const mortarRgb = hexToRgb(mortarCol);
  const mDepth = opts.mortarDepth ?? 0.12;

  for (let ci = 0; ci < courses.length; ci++) {
    const { y0, y1, xSplits } = courses[ci];
    const courseH = y1 - y0;
    for (let y = y0; y < y1; y++) {
      const dy = y - y0;
      const isBottomMortar = dy === courseH - 1;
      const isTopEdge = dy === 0;
      const isPreBottom = dy === courseH - 2;

      for (let x = 0; x < 16; x++) {
        let brickIdx = 0;
        let isVertMortar = false;
        let isLeftEdge = false;
        let isRightEdge = false;
        for (let si = 0; si < xSplits.length; si++) {
          const sx = xSplits[si];
          if (x === sx) isVertMortar = true;
          if (x === ((sx + 1) & 15)) isLeftEdge = true;
          if (x === ((sx + 15) & 15)) isRightEdge = true;
          if (x > sx) brickIdx = si + 1;
        }
        if (brickIdx >= xSplits.length) brickIdx = 0;

        if (isBottomMortar || isVertMortar) {
          const mn = (hash16(x, y, seed + 17) - 0.5) * 16;
          surf.set(
            x,
            y,
            [mortarRgb[0] + mn, mortarRgb[1] + mn, mortarRgb[2] + mn],
            mDepth,
            0,
          );
          continue;
        }

        const brickBias = (hash16(brickIdx * 3 + ci * 7, ci * 11, seed + 31) - 0.5) * 0.24;
        const grain = fbm16(x + ci * 3, y + brickIdx * 5, seed + 53, 8, 4) - 0.5;
        let edgeBias = 0;
        let h = 0.58 + brickBias * 0.35 + grain * 0.18;
        let spec = 0;

        if (isTopEdge) { edgeBias += 0.18; h += 0.16; }
        if (isLeftEdge) { edgeBias += 0.15; h += 0.13; }
        if (isPreBottom) { edgeBias -= 0.16; h -= 0.14; }
        if (isRightEdge) { edgeBias -= 0.15; h -= 0.13; }
        if (isTopEdge && isLeftEdge) { edgeBias += 0.08; spec = 0.38; }

        const t = Math.max(0.08, Math.min(0.96, 0.52 + brickBias + grain * 0.42 + edgeBias));
        surf.set(x, y, sampleRamp(ramp, t), Math.max(0.18, Math.min(0.95, h)), spec);
      }
    }
  }

  if (opts.cracked) {
    const cracks: [number, number, boolean][] = [
      [4, 1, false], [5, 2, true], [5, 3, false], [6, 4, true], [7, 5, false], [6, 6, false], [4, 3, false],
      [11, 9, false], [12, 10, true], [11, 11, false], [10, 12, true], [10, 13, false], [9, 14, false], [12, 12, false],
      [2, 10, false], [3, 11, true], [3, 12, false],
    ];
    const darkCrack = lerpRgb(mortarRgb, [12, 12, 14], 0.55);
    const spallCol = sampleRamp(ramp, 0.88);
    for (const [cx, cy, spall] of cracks) {
      surf.set(cx, cy, darkCrack, 0.05, 0);
      if (spall) {
        surf.set((cx + 1) & 15, cy, spallCol, 0.78, 0.25);
      }
    }
  }

  if (opts.mossy) {
    const mossPalette = opts.mossRamp ?? ['#2d4c1b', '#3f6927', '#558736', '#6da148', '#86ba5c'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const i = y * 16 + x;
        const isGroove = surf.h[i] < 0.25;
        const mNoise = fbm16(x, y, seed + 333, 8, 8);
        if ((isGroove && mNoise > 0.28) || mNoise > 0.50) {
          const mt = Math.max(0, Math.min(1, (mNoise - 0.34) * 1.8 + (hash16(x, y, seed + 444) - 0.5) * 0.25));
          surf.set(x, y, sampleRamp(mossPalette, mt), isGroove ? 0.36 : 0.68, 0.08);
        }
      }
    }
  }
}

/**
 * Renders polished stone blocks (polished_granite, polished_diorite, polished_andesite,
 * polished_deepslate, polished_blackstone, polished_tuff, smooth_stone) with a precision
 * 3D beveled frame, diagonal specular sheen, and honed mineral interior.
 */
function buildPolishedStoneSurface(
  surf: StoneSurface16,
  ramp: string[],
  seed: number,
  opts: {
    borderDark: string;
    borderLight: string;
    borderShadow: string;
    grainScaleX?: number;
    grainScaleY?: number;
    doubleSlabSide?: boolean;
    crystalDots?: [string, string, number];
  },
) {
  const gx = opts.grainScaleX ?? 8;
  const gy = opts.grainScaleY ?? 8;

  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const n = fbm16(x, y, seed, gx, gy);
      const diag = Math.sin(((x + y) / 16) * Math.PI * 2 + 0.6) * 0.08;
      const t = Math.max(0.15, Math.min(0.88, n * 0.72 + 0.14 + diag));
      let col = sampleRamp(ramp, t);
      let h = 0.55 + (t - 0.5) * 0.16;
      let spec = diag > 0.04 ? 0.22 : 0.05;

      if (opts.crystalDots) {
        const [darkDot, lightDot, freq] = opts.crystalDots;
        const hDot = hash16(x, y, seed + 91);
        if (hDot < freq * 0.5) {
          col = lerpRgb(col, hexToRgb(darkDot), 0.65);
          h -= 0.06;
        } else if (hDot > 1 - freq * 0.5) {
          col = lerpRgb(col, hexToRgb(lightDot), 0.65);
          h += 0.06;
          spec = 0.38;
        }
      }

      surf.set(x, y, col, h, spec);
    }
  }

  const applyFrame = (y0: number, y1: number) => {
    for (let x = 0; x < 16; x++) {
      surf.set(x, y0, opts.borderDark, 0.16, 0);
      surf.set(x, y1, opts.borderDark, 0.14, 0);
    }
    for (let y = y0; y <= y1; y++) {
      surf.set(0, y, opts.borderDark, 0.16, 0);
      surf.set(15, y, opts.borderDark, 0.14, 0);
    }
    for (let x = 1; x < 15; x++) {
      surf.set(x, y0 + 1, opts.borderLight, 0.78, 0.35);
      surf.set(x, y1 - 1, opts.borderShadow, 0.36, 0);
    }
    for (let y = y0 + 1; y < y1; y++) {
      surf.set(1, y, opts.borderLight, 0.76, 0.30);
      surf.set(14, y, opts.borderShadow, 0.36, 0);
    }
    surf.set(1, y0 + 1, opts.borderLight, 0.86, 0.55);
  };

  if (opts.doubleSlabSide) {
    applyFrame(0, 7);
    applyFrame(8, 15);
  } else {
    applyFrame(0, 15);
  }
}

/**
 * Mineral Ore Cluster Definitions (Java 1.17-1.21 unique silhouettes per mineral type).
 */
const ORE_PATTERNS: Record<string, { map: string[]; pal: Record<string, [string, number, number]> }> = {
  coal: {
    map: [
      '................',
      '..0122210.......',
      '.012343210.0121.',
      '..0111110.012320',
      '..........01110.',
      '....01222210....',
      '...0123443210...',
      '....01122110....',
      '.012210.........',
      '01234210..012210',
      '.011110..0123420',
      '.........0122210',
      '..0122210.01110.',
      '.012343210......',
      '..0111110.......',
      '................',
    ],
    pal: {
      '1': ['#101214', 0.32, 0.05],
      '2': ['#1e2124', 0.48, 0.15],
      '3': ['#31363b', 0.66, 0.45],
      '4': ['#4d545c', 0.78, 0.75],
    },
  },
  iron: {
    map: [
      '................',
      '....012310......',
      '...0123420..010.',
      '..0123210..01230',
      '..01110...012320',
      '.........012210.',
      '..01210..0110...',
      '.0123420........',
      '.013210...01230.',
      '..010....0124320',
      '........0123210.',
      '...0120..0110...',
      '..012430........',
      '.0123210..01210.',
      '..0110...012320.',
      '..........0110..',
    ],
    pal: {
      '1': ['#75513d', 0.38, 0.10],
      '2': ['#a6795e', 0.56, 0.25],
      '3': ['#d4a98c', 0.72, 0.50],
      '4': ['#f5d6be', 0.84, 0.80],
    },
  },
  copper: {
    map: [
      '................',
      '..012310........',
      '.01244320..0140.',
      '..013210..014320',
      '...010...012310.',
      '.........0110...',
      '....014310......',
      '...01443210.....',
      '...0123210..010.',
      '....0110...01430',
      '.0120.....014320',
      '012430....01210.',
      '013210...0110...',
      '.0110..012430...',
      '.......013210...',
      '........010.....',
    ],
    pal: {
      '1': ['#823820', 0.38, 0.12],
      '2': ['#c45c38', 0.58, 0.30],
      '3': ['#eb8257', 0.74, 0.58],
      '4': ['#3ca680', 0.70, 0.50],
    },
  },
  gold: {
    map: [
      '................',
      '...01210........',
      '..0123420..0120.',
      '..0133210.013420',
      '...01210..012310',
      '....010....0120.',
      '......0120..00..',
      '.010.013420.....',
      '01320012310.....',
      '01430.0120..0120',
      '.0120..00..01340',
      '..00.......01230',
      '....01210...010.',
      '...0134320......',
      '...0123210......',
      '....0110........',
    ],
    pal: {
      '1': ['#8f590a', 0.38, 0.20],
      '2': ['#cc8d18', 0.58, 0.45],
      '3': ['#f5c82e', 0.76, 0.75],
      '4': ['#fff59e', 0.88, 1.00],
    },
  },
  diamond: {
    map: [
      '................',
      '....0120........',
      '...013430..0120.',
      '...012320.013430',
      '....0120..012320',
      '...........0110.',
      '.....01210......',
      '....0134430.....',
      '....0123320.....',
      '.0120.0110......',
      '013430.....0120.',
      '012320....013430',
      '.0110.....012320',
      '....0120...0110.',
      '...013430.......',
      '....0120........',
    ],
    pal: {
      '1': ['#12737d', 0.40, 0.30],
      '2': ['#22b5c2', 0.62, 0.60],
      '3': ['#5cf0f5', 0.80, 0.88],
      '4': ['#e8ffff', 0.92, 1.00],
    },
  },
  emerald: {
    map: [
      '................',
      '...0120.........',
      '..013420...010..',
      '..012320..01340.',
      '...0110...01230.',
      '...........010..',
      '......0120......',
      '.010.013420.....',
      '01340012320.....',
      '01230.0110..010.',
      '.010.......01340',
      '...........01230',
      '...0120.....010.',
      '..013420........',
      '..012320........',
      '...0110.........',
    ],
    pal: {
      '1': ['#0a5c24', 0.40, 0.25],
      '2': ['#189e43', 0.62, 0.55],
      '3': ['#38e06c', 0.80, 0.85],
      '4': ['#c4ffd6', 0.92, 1.00],
    },
  },
  lapis: {
    map: [
      '................',
      '..012210........',
      '.01234320..0120.',
      '.01322310.012320',
      '..012210..013210',
      '...0110....0110.',
      '.....012210.....',
      '....01234320....',
      '....01322320....',
      '.0120.01210.....',
      '012320.....01210',
      '013420....012320',
      '.0110.....013210',
      '....012210.0110.',
      '...0123320......',
      '....01110.......',
    ],
    pal: {
      '1': ['#10225e', 0.38, 0.15],
      '2': ['#1f42ab', 0.58, 0.35],
      '3': ['#3c6be6', 0.74, 0.60],
      '4': ['#e0be46', 0.82, 0.85],
    },
  },
  redstone: {
    map: [
      '................',
      '...0120....010..',
      '..013420..01320.',
      '..012310..01430.',
      '...010.....0120.',
      '.....01210..00..',
      '....0134320.....',
      '.010.012310.....',
      '01320.010..0120.',
      '01430.....013420',
      '.0120.....012310',
      '..00..010..010..',
      '.....01320......',
      '..01001430.0120.',
      '.013200120013420',
      '..010......0110.',
    ],
    pal: {
      '1': ['#590808', 0.36, 0.20],
      '2': ['#991212', 0.56, 0.45],
      '3': ['#db2525', 0.76, 0.78],
      '4': ['#ff786e', 0.88, 1.00],
    },
  },
  quartz: {
    map: [
      '................',
      '..01230.........',
      '.0134430...0120.',
      '..012320..013430',
      '...0120..012320.',
      '.........0110...',
      '....01230.......',
      '...0134430......',
      '..0123320...010.',
      '..01110....01340',
      '.0120.....012430',
      '013430....01220.',
      '012320...0110...',
      '.0110..012340...',
      '.......013210...',
      '........010.....',
    ],
    pal: {
      '1': ['#8c7d74', 0.42, 0.20],
      '2': ['#c4bab0', 0.64, 0.50],
      '3': ['#ebe6df', 0.82, 0.80],
      '4': ['#ffffff', 0.94, 1.00],
    },
  },
};

/**
 * Populates a StoneSurface16 with one of the three base host rocks:
 * - 'stone': Jappa stratified Overworld gray stone
 * - 'deepslate': Metamorphic foliated dark slate
 * - 'netherrack': Craggy crimson-maroon Nether bloodstone
 */
function buildHostRockSurface(surf: StoneSurface16, host: 'stone' | 'deepslate' | 'netherrack', seed = 101) {
  if (host === 'stone') {
    // Authentic Jappa 1.14+ horizontally stratified stone plates with crisp 1px cleavage ledges
    const ramp = ['#565755', '#666865', '#757774', '#828480', '#8f918d', '#9d9f9b', '#abada8'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        // Compress X by 0.5 and stretch Y by 1.0 on toroidal Voronoi to form 3-5px wide horizontal stone shelves
        const sx = ((x * 0.5 + (y & 1) * 0.35) % 8) * 2;
        const v = voronoi16(sx, y, PEBBLE_PTS, 'manhattan');
        const h1 = hash16(x, y, seed + 73);
        const isCleavage = v.edgeDist < 0.36 && v.relY > -0.2;
        const isLedgeTop = v.relY < -0.35 && v.edgeDist >= 0.36;
        let t = 0.44 + v.cellRand * 0.28 + (h1 - 0.5) * 0.18 - v.relY * 0.14;
        let h = 0.52 + (t - 0.5) * 0.38;
        if (isCleavage) {
          t = 0.08 + h1 * 0.14;
          h = 0.18;
        } else if (isLedgeTop) {
          t = Math.min(0.96, t + 0.18);
          h = 0.78;
        }
        surf.set(x, y, sampleRamp(ramp, Math.max(0.05, Math.min(0.96, t))), h, t > 0.82 ? 0.20 : 0.04);
      }
    }
    return;
  }

  if (host === 'deepslate') {
    const ramp = ['#222429', '#31343b', '#41444d', '#50545e', '#616672', '#727885'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const wave = Math.sin(((x + (y >> 1)) / 16) * Math.PI * 2) * 0.85;
        const band = ((y + wave + 16) % 4) / 4;
        const n = fbm16(x, y, seed + 211, 8, 4);
        const isCleavage = band < 0.22;
        const isRidge = band >= 0.22 && band < 0.46;
        const t = isCleavage ? 0.08 + n * 0.15 : isRidge ? 0.62 + n * 0.32 : 0.32 + n * 0.36;
        const h = isCleavage ? 0.18 : isRidge ? 0.76 : 0.50 + (n - 0.5) * 0.22;
        surf.set(x, y, sampleRamp(ramp, t), h, isRidge ? 0.25 : 0.05);
      }
    }
    return;
  }

  // 'netherrack'
  const ramp = ['#3d1816', '#52221f', '#692d29', '#7f3a34', '#964942', '#ad5b53'];
  const vPts = COBBLE_PTS;
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const v = voronoi16(x, y, vPts, 'octagonal');
      const n = fbm16(x, y, seed + 307, 8, 8);
      const isFissure = v.edgeDist < 0.48;
      const t = isFissure ? 0.08 + n * 0.15 : Math.max(0.20, Math.min(0.95, 0.35 + v.cellRand * 0.35 + (n - 0.5) * 0.35 - v.dist1 * 0.06));
      const h = isFissure ? 0.16 : Math.max(0.28, Math.min(0.90, 0.72 - v.dist1 * 0.14 + (n - 0.5) * 0.18));
      surf.set(x, y, sampleRamp(ramp, t), h, 0.04);
    }
  }
}

/**
 * Draws any stone-family tile onto `ctx` using our 3-pass relief & review pipeline.
 * Returns `true` if `name` is a stone-family tile handled by this module.
 */
export function drawStoneTile(name: string, ctx: Context2D, pass: 1 | 2 | 3 = 3): boolean {
  const surf = new StoneSurface16();

  // =========================================================================
  // FAMILY 1: NATURAL OVERWORLD STONES & POLISHED VARIANTS
  // =========================================================================
  if (name === 'stone') {
    buildHostRockSurface(surf, 'stone', 101);
    surf.commit(ctx, pass, { bevelStrength: 24, aoStrength: 26, specStrength: 16 });
    return true;
  }

  if (name === 'smooth_stone' || name === 'smooth_stone_side') {
    buildPolishedStoneSurface(
      surf,
      ['#8a8c88', '#9a9c98', '#abada8', '#b8bab5', '#c7c9c4'],
      113,
      {
        borderDark: '#575955',
        borderLight: '#d8dad4',
        borderShadow: '#7c7e7a',
        grainScaleX: 8,
        grainScaleY: 4,
        doubleSlabSide: name === 'smooth_stone_side',
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 22, aoStrength: 24, specStrength: 20, wrapEdges: false });
    return true;
  }

  if (name === 'granite') {
    const ramp = ['#5e3c30', '#7a5041', '#946452', '#a87663', '#bd8975', '#d19e8b'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, PEBBLE_PTS, 'octagonal');
        const n = fbm16(x, y, 131, 8, 8);
        const h1 = hash16(x, y, 137);
        let t = 0.38 + v.cellRand * 0.36 + (n - 0.5) * 0.32;
        let spec = 0.08;
        if (h1 < 0.14 || v.edgeDist < 0.28) { t = 0.08; }
        else if (h1 > 0.85) { t = 0.94; spec = 0.45; }
        const h = 0.35 + t * 0.52;
        surf.set(x, y, sampleRamp(ramp, t), h, spec);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 25, aoStrength: 26, specStrength: 22 });
    return true;
  }

  if (name === 'polished_granite') {
    buildPolishedStoneSurface(
      surf,
      ['#784e3f', '#8f604e', '#a3715e', '#b5826e', '#c79480'],
      139,
      {
        borderDark: '#543429',
        borderLight: '#deb09d',
        borderShadow: '#6e4638',
        crystalDots: ['#543429', '#e3b8a6', 0.18],
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 24, aoStrength: 24, specStrength: 26, wrapEdges: false });
    return true;
  }

  if (name === 'diorite') {
    const ramp = ['#4f504d', '#6e706c', '#969893', '#bcbdb8', '#d6d7d2', '#ebece6', '#fafaf7'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, PEBBLE_PTS, 'octagonal');
        const n = fbm16(x, y, 149, 8, 8);
        const h1 = hash16(x, y, 151);
        const isHornblende = (v.edgeDist < 0.38 && n < 0.52) || h1 < 0.14;
        const t = isHornblende ? 0.06 + h1 * 0.22 : Math.min(0.98, 0.52 + v.cellRand * 0.32 + (n - 0.5) * 0.28);
        const h = isHornblende ? 0.24 : 0.48 + t * 0.42;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.82 ? 0.42 : 0.05);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 24 });
    return true;
  }

  if (name === 'polished_diorite') {
    buildPolishedStoneSurface(
      surf,
      ['#989994', '#b4b5b0', '#cbccc7', '#dedfd9', '#f0f1ec'],
      157,
      {
        borderDark: '#696a66',
        borderLight: '#ffffff',
        borderShadow: '#8c8d88',
        crystalDots: ['#5e5f5b', '#ffffff', 0.20],
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 24, aoStrength: 24, specStrength: 28, wrapEdges: false });
    return true;
  }

  if (name === 'andesite') {
    const ramp = ['#545852', '#676c65', '#797f77', '#8a9088', '#9ca39a', '#b0b7ae'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, PEBBLE_PTS, 'octagonal');
        const pheno = hash16(x, y, 173);
        const isPocket = v.edgeDist < 0.36 && pheno < 0.55;
        const dirBias = (-v.relX * 0.12 - v.relY * 0.14);
        let t = 0.42 + v.cellRand * 0.34 + dirBias + (pheno - 0.5) * 0.20;
        if (isPocket) t = 0.08 + pheno * 0.14;
        else if (pheno > 0.86) t = Math.min(0.96, t + 0.22);
        const h = isPocket ? 0.20 : 0.36 + t * 0.52;
        surf.set(x, y, sampleRamp(ramp, Math.max(0.05, Math.min(0.96, t))), h, t > 0.80 ? 0.24 : 0.04);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 20 });
    return true;
  }

  if (name === 'polished_andesite') {
    buildPolishedStoneSurface(
      surf,
      ['#696e67', '#7b8079', '#8c9189', '#9ba198', '#abb0a7'],
      179,
      {
        borderDark: '#4a4e48',
        borderLight: '#c2c7be',
        borderShadow: '#5e635c',
        crystalDots: ['#525750', '#c4c9c0', 0.14],
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 24, aoStrength: 24, specStrength: 24, wrapEdges: false });
    return true;
  }

  if (name === 'calcite') {
    const ramp = ['#9a978c', '#b5b1a5', '#cfccc0', '#e0ddd3', '#eeece4', '#faf9f5'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        // Organic crystalline rhombohedral calcite plates with diagonal cleavage veins
        const v = voronoi16(x + y * 0.35, y - x * 0.25, PRISMARINE_PTS, 'manhattan');
        const n = fbm16(x, y, 181, 8, 8);
        const isVein = v.edgeDist < 0.44;
        const t = isVein ? 0.10 + n * 0.22 : Math.min(0.98, 0.46 + v.cellRand * 0.30 + n * 0.24 - (v.relX + v.relY) * 0.06);
        const h = isVein ? 0.24 : 0.50 + t * 0.40;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.78 ? 0.48 : 0.10);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 26, specStrength: 28 });
    return true;
  }

  if (name === 'dripstone_block') {
    const ramp = ['#4a3529', '#614738', '#785947', '#8c6b57', '#a17e69', '#b8947e'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        // Vertically stretched stalactitic travertine flutes + dissolution pores
        const sy = ((y * 0.5 + (x & 1) * 0.25) % 8) * 2;
        const v = voronoi16(x, sy, PEBBLE_PTS, 'manhattan');
        const vug = hash16(x, y, 197);
        const isFissure = v.edgeDist < 0.36;
        const isRib = v.relX < -0.25 && !isFissure;
        let t = 0.44 + v.cellRand * 0.30 + (vug - 0.5) * 0.18 - v.relX * 0.14;
        let h = 0.48 + (t - 0.5) * 0.38;
        if (isFissure || vug < 0.08) {
          t = 0.08 + vug * 0.12;
          h = 0.16;
        } else if (isRib) {
          t = Math.min(0.96, t + 0.18);
          h = 0.78;
        }
        surf.set(x, y, sampleRamp(ramp, Math.max(0.05, Math.min(0.96, t))), h, t > 0.82 ? 0.22 : 0.04);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 18 });
    return true;
  }

  // =========================================================================
  // FAMILY 2: COBBLESTONES, GRAVEL & BEDROCK
  // =========================================================================
  if (name === 'cobblestone' || name === 'mossy_cobblestone') {
    const ramp = ['#303130', '#4a4c49', '#636662', '#7a7d78', '#8f928d', '#a4a7a1', '#babdb7'];
    const mossRamp = ['#284718', '#3b6324', '#507d32', '#689943', '#82b356'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, COBBLE_PTS, 'octagonal');
        const grain = (hash16(x, y, 211) - 0.5) * 0.14;
        if (v.edgeDist < 0.52) {
          if (name === 'mossy_cobblestone' && fbm16(x, y, 223, 8, 8) > 0.34) {
            const mt = fbm16(x + 2, y + 3, 227, 8, 8);
            surf.set(x, y, sampleRamp(mossRamp, mt), 0.34, 0.08);
          } else {
            surf.set(x, y, sampleRamp(ramp, 0.05 + Math.max(0, grain)), 0.10, 0);
          }
        } else {
          const dome = Math.max(0, 1 - v.dist1 * 0.32);
          const dirBias = (-v.relX * 0.11 - v.relY * 0.13);
          const t = Math.max(0.18, Math.min(0.98, 0.38 + v.cellRand * 0.26 + dome * 0.24 + dirBias + grain));
          const h = Math.max(0.24, Math.min(0.95, 0.32 + dome * 0.52 + dirBias * 0.45));
          if (name === 'mossy_cobblestone' && fbm16(x, y, 229, 8, 8) > 0.60) {
            const mt = Math.max(0.2, Math.min(0.95, 0.45 + dirBias * 1.4 + grain));
            surf.set(x, y, sampleRamp(mossRamp, mt), h * 0.92, 0.10);
          } else {
            surf.set(x, y, sampleRamp(ramp, t), h, t > 0.85 ? 0.28 : 0.04);
          }
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 32, specStrength: 20 });
    return true;
  }

  if (name === 'cobbled_deepslate') {
    const ramp = ['#18191d', '#282a30', '#383b43', '#494d57', '#5b606b', '#6e7480', '#838996'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, COBBLE_PTS, 'manhattan');
        const grain = (hash16(x, y, 233) - 0.5) * 0.16;
        if (v.edgeDist < 0.50) {
          surf.set(x, y, sampleRamp(ramp, 0.04), 0.08, 0);
        } else {
          const facet = Math.max(0, 1 - v.dist1 * 0.30);
          const dirBias = (-v.relX * 0.12 - v.relY * 0.14);
          const t = Math.max(0.16, Math.min(0.98, 0.36 + v.cellRand * 0.28 + facet * 0.24 + dirBias + grain));
          const h = Math.max(0.22, Math.min(0.95, 0.30 + facet * 0.54 + dirBias * 0.48));
          surf.set(x, y, sampleRamp(ramp, t), h, t > 0.80 ? 0.36 : 0.08);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 30, aoStrength: 34, specStrength: 24 });
    return true;
  }

  if (name === 'bedrock') {
    const ramp = ['#0e0f10', '#202224', '#373a3d', '#525659', '#707579', '#8f9499', '#aeb4b8'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x + Math.sin((y / 16) * Math.PI * 2) * 1.5, y, COBBLE_PTS, 'manhattan');
        const n1 = periodicNoise16(x, y, 8, 4, 241);
        const h1 = hash16(x, y, 257);
        const isDarkVein = v.edgeDist < 0.55 || (n1 < 0.35 && h1 < 0.45);
        const isBrightRidge = v.dist1 < 1.35 && v.cellRand > 0.45;
        const t = isDarkVein ? 0.04 + h1 * 0.16 : isBrightRidge ? 0.78 + h1 * 0.20 : 0.35 + v.cellRand * 0.35 + (n1 - 0.5) * 0.25;
        const h = isDarkVein ? 0.14 : isBrightRidge ? 0.86 : 0.48 + (t - 0.5) * 0.4;
        surf.set(x, y, sampleRamp(ramp, t), h, isBrightRidge ? 0.35 : 0.05);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 32, aoStrength: 34, specStrength: 24 });
    return true;
  }

  if (name === 'gravel') {
    const ramp = ['#45403d', '#5c5652', '#736c67', '#89817b', '#9e958e', '#b5aca4'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        // Multi-colored packed river/cave pebbles without linear striping
        const v = voronoi16(x, y, PEBBLE_PTS, 'octagonal');
        const h1 = hash16(x, y, 263);
        const isGap = v.edgeDist < 0.38;
        const dirBias = (-v.relX * 0.14 - v.relY * 0.16);
        const t = isGap ? 0.08 + h1 * 0.12 : Math.max(0.18, Math.min(0.96, 0.28 + v.cellRand * 0.52 + dirBias + (h1 - 0.5) * 0.14));
        const h = isGap ? 0.16 : 0.34 + t * 0.52;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.82 ? 0.25 : 0.04);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 18 });
    return true;
  }

  // =========================================================================
  // FAMILY 3: STONE BRICKS, CLAY BRICKS & MUD BRICKS
  // =========================================================================
  if (name === 'stone_bricks' || name === 'mossy_stone_bricks' || name === 'cracked_stone_bricks') {
    buildBrickCourseSurface(
      surf,
      ['#565854', '#6b6d68', '#7d807a', '#8e918b', '#9fa29c', '#b2b5ae'],
      '#3c3e3b',
      [
        { y0: 0, y1: 8, xSplits: [15] },
        { y0: 8, y1: 16, xSplits: [7] },
      ],
      307,
      {
        cracked: name === 'cracked_stone_bricks',
        mossy: name === 'mossy_stone_bricks',
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 20 });
    return true;
  }

  if (name === 'chiseled_stone_bricks') {
    const ramp = ['#383a37', '#545752', '#6e716c', '#82857f', '#969993', '#abad9f', '#bfc2ba'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const ring = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5));
        const grain = (hash16(x, y, 311) - 0.5) * 0.08;
        let h = 0.5;
        let t = 0.55;
        if (ring >= 7.0) {
          const topL = x === 0 || y === 0;
          h = topL ? 0.72 : 0.22;
          t = topL ? 0.78 : 0.18;
        } else if (ring >= 5.8) {
          const topL = x <= 2 || y <= 2;
          h = 0.78;
          t = (topL ? 0.78 : 0.56) + grain;
        } else if (ring >= 4.8) {
          h = 0.14;
          t = 0.08 + grain;
        } else if (ring >= 2.8) {
          const topL = x <= 5 || y <= 5;
          h = 0.80;
          t = (topL ? 0.82 : 0.58) + grain;
        } else if (ring >= 1.8) {
          h = 0.16;
          t = 0.10 + grain;
        } else {
          const topL = x === 7 && y === 7;
          h = 0.84;
          t = (topL ? 0.90 : 0.68) + grain;
        }
        surf.set(x, y, sampleRamp(ramp, Math.max(0.04, Math.min(0.96, t))), h, h > 0.78 ? 0.24 : 0);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 32, specStrength: 22, wrapEdges: false });
    return true;
  }

  if (name === 'bricks') {
    buildBrickCourseSurface(
      surf,
      ['#63291e', '#7d3729', '#964535', '#ad5543', '#c26754', '#d67c69'],
      '#b8b0a2',
      [
        { y0: 0, y1: 4, xSplits: [7, 15] },
        { y0: 4, y1: 8, xSplits: [3, 11] },
        { y0: 8, y1: 12, xSplits: [7, 15] },
        { y0: 12, y1: 16, xSplits: [3, 11] },
      ],
      317,
      { mortarDepth: 0.16 },
    );
    // In Pass 2 & Pass 3, crisp lime-mortar highlight & under-brick shadow accentuate 3D course depth
    if (pass >= 2) {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const i = y * 16 + x;
          if (surf.h[i] < 0.25) {
            surf.r[i] += pass === 3 ? 16 : 10;
            surf.g[i] += pass === 3 ? 15 : 9;
            surf.b[i] += pass === 3 ? 13 : 8;
          }
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 24, aoStrength: 24, specStrength: 20, lightMortar: true });
    return true;
  }

  if (name === 'mud_bricks') {
    buildBrickCourseSurface(
      surf,
      ['#5c4331', '#70533d', '#85654b', '#997659', '#ad896a', '#bf9c7c'],
      '#423022',
      [
        { y0: 0, y1: 8, xSplits: [8, 15] },
        { y0: 8, y1: 16, xSplits: [4, 11] },
      ],
      331,
      { mortarDepth: 0.14 },
    );
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 14 });
    return true;
  }

  if (name === 'packed_mud') {
    const ramp = ['#5e4633', '#735640', '#87674d', '#99775b', '#ad896b', '#c29e7d'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const n = fbm16(x, y, 337, 8, 8);
        const h1 = hash16(x, y, 347);
        const isStraw = h1 > 0.86 || (h1 > 0.78 && ((x + y) & 1) === 0);
        const t = isStraw ? 0.92 : Math.max(0.10, Math.min(0.82, n * 0.65 + (h1 - 0.5) * 0.25));
        const h = isStraw ? 0.72 : 0.35 + t * 0.45;
        surf.set(x, y, sampleRamp(ramp, t), h, isStraw ? 0.22 : 0.02);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 24, aoStrength: 26, specStrength: 14 });
    return true;
  }

  // =========================================================================
  // FAMILY 4: DEEPSLATE FAMILY & REINFORCED DEEPSLATE
  // =========================================================================
  if (name === 'deepslate') {
    buildHostRockSurface(surf, 'deepslate', 353);
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 22 });
    return true;
  }

  if (name === 'deepslate_top') {
    const ramp = ['#1e2025', '#2e3138', '#3e424b', '#4f545f', '#606673', '#727987'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, PRISMARINE_PTS, 'octagonal');
        const n = fbm16(x, y, 359, 8, 8);
        const isSeam = v.edgeDist < 0.44;
        const t = isSeam ? 0.08 : Math.min(0.95, 0.34 + v.cellRand * 0.30 + (n - 0.5) * 0.28 - (v.relX + v.relY) * 0.08);
        const h = isSeam ? 0.16 : 0.42 + t * 0.45;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.78 ? 0.30 : 0.06);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 22 });
    return true;
  }

  if (name === 'polished_deepslate') {
    buildPolishedStoneSurface(
      surf,
      ['#2d2f36', '#3b3e47', '#4a4e59', '#5a5f6b', '#6b717f'],
      367,
      {
        borderDark: '#1b1d21',
        borderLight: '#7f8594',
        borderShadow: '#26282e',
        crystalDots: ['#1e2025', '#858b99', 0.14],
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 26, wrapEdges: false });
    return true;
  }

  if (name === 'deepslate_bricks') {
    buildBrickCourseSurface(
      surf,
      ['#26282e', '#34373f', '#434752', '#525763', '#636977', '#757c8c'],
      '#16181c',
      [
        { y0: 0, y1: 8, xSplits: [15] },
        { y0: 8, y1: 16, xSplits: [7] },
      ],
      373,
      { mortarDepth: 0.10 },
    );
    surf.commit(ctx, pass, { bevelStrength: 30, aoStrength: 32, specStrength: 24 });
    return true;
  }

  if (name === 'deepslate_tiles') {
    buildBrickCourseSurface(
      surf,
      ['#1e2025', '#2b2d34', '#383b44', '#464a55', '#565b68', '#686e7d'],
      '#111216',
      [
        { y0: 0, y1: 4, xSplits: [5, 11, 15] },
        { y0: 4, y1: 8, xSplits: [2, 8, 13] },
        { y0: 8, y1: 12, xSplits: [6, 12, 15] },
        { y0: 12, y1: 16, xSplits: [3, 9, 14] },
      ],
      379,
      { mortarDepth: 0.08 },
    );
    surf.commit(ctx, pass, { bevelStrength: 30, aoStrength: 34, specStrength: 26 });
    return true;
  }

  if (name === 'chiseled_deepslate') {
    const ramp = ['#17191d', '#282b32', '#393d46', '#4b505c', '#5d6370', '#717887'];
    const map = [
      '1111111111111111',
      '1444444444444431',
      '1400000000000021',
      '1404444314444021',
      '1404220214022021',
      '1404040214040021',
      '1404000214000021',
      '1403222213222021',
      '1300000000000021',
      '1404444314444021',
      '1404000214002021',
      '1404040214042021',
      '1404220214222021',
      '1403222213222021',
      '1322222222222221',
      '0000000000000000',
    ];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const ch = map[y][x];
        const lv = Number(ch) / 4;
        const n = (hash16(x, y, 383) - 0.5) * 0.08;
        const t = Math.max(0.04, Math.min(0.96, lv * 0.85 + 0.08 + n));
        const h = 0.14 + lv * 0.72;
        surf.set(x, y, sampleRamp(ramp, t), h, lv > 0.7 ? 0.32 : 0.04);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 30, aoStrength: 32, specStrength: 24, wrapEdges: false });
    return true;
  }

  if (name === 'reinforced_deepslate' || name === 'reinforced_deepslate_side' || name === 'reinforced_deepslate_top' || name === 'reinforced_deepslate_bottom') {
    buildHostRockSurface(surf, 'deepslate', 389);
    const boneDark = '#787562', boneMid = '#aba78e', boneLight = '#dedac0';
    const sculkDark = '#0f3038', sculkMid = '#1f6470', sculkGlow = '#48cfd9';
    if (name === 'reinforced_deepslate_top') {
      for (let i = 0; i < 16; i++) {
        for (const r of [0, 1, 14, 15]) {
          surf.set(i, r, r === 0 || r === 14 ? boneLight : boneMid, 0.82, 0.35);
          surf.set(r, i, r === 0 || r === 14 ? boneLight : boneMid, 0.82, 0.35);
        }
        surf.set(i, 2, sculkDark, 0.20, 0.10);
        surf.set(i, 13, sculkDark, 0.20, 0.10);
        surf.set(2, i, sculkDark, 0.20, 0.10);
        surf.set(13, i, sculkDark, 0.20, 0.10);
      }
      for (const [cx, cy] of [[1, 1], [14, 1], [1, 14], [14, 14], [7, 1], [8, 1], [7, 14], [8, 14], [1, 7], [1, 8], [14, 7], [14, 8]]) {
        surf.set(cx, cy, sculkGlow, 0.90, 0.85);
      }
    } else if (name === 'reinforced_deepslate_bottom') {
      for (let i = 0; i < 16; i++) {
        surf.set(i, 0, boneDark, 0.72, 0.20);
        surf.set(i, 15, boneDark, 0.72, 0.20);
        surf.set(0, i, boneDark, 0.72, 0.20);
        surf.set(15, i, boneDark, 0.72, 0.20);
      }
    } else {
      for (let x = 0; x < 16; x++) {
        surf.set(x, 0, boneLight, 0.86, 0.40);
        surf.set(x, 1, boneMid, 0.80, 0.25);
        surf.set(x, 2, boneDark, 0.65, 0.10);
        surf.set(x, 3, sculkMid, 0.35, 0.40);
        surf.set(x, 13, sculkDark, 0.32, 0.20);
        surf.set(x, 14, boneMid, 0.76, 0.20);
        surf.set(x, 15, boneDark, 0.68, 0.10);
      }
      for (let y = 2; y < 14; y++) {
        surf.set(0, y, boneMid, 0.78, 0.25);
        surf.set(1, y, boneDark, 0.68, 0.15);
        surf.set(14, y, boneMid, 0.78, 0.25);
        surf.set(15, y, boneDark, 0.68, 0.15);
      }
      for (const x of [3, 7, 8, 12]) {
        surf.set(x, 3, sculkGlow, 0.88, 0.90);
        surf.set(x, 12, sculkGlow, 0.88, 0.90);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 26, wrapEdges: false });
    return true;
  }

  // =========================================================================
  // FAMILY 5: 1.21 TUFF FAMILY (TRIAL CHAMBERS)
  // =========================================================================
  if (name === 'tuff') {
    const ramp = ['#3d4038', '#4f5349', '#62665b', '#73786b', '#858a7c', '#979d8e'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, PRISMARINE_PTS, 'octagonal');
        const n = fbm16(x, y, 401, 8, 8);
        const h1 = hash16(x, y, 409);
        const isAshPocket = v.edgeDist < 0.42 || h1 < 0.10;
        const t = isAshPocket ? 0.08 + h1 * 0.18 : Math.min(0.95, 0.36 + v.cellRand * 0.28 + (n - 0.5) * 0.32);
        const h = isAshPocket ? 0.20 : 0.38 + t * 0.48;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.82 ? 0.18 : 0.03);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 18 });
    return true;
  }

  if (name === 'polished_tuff') {
    buildPolishedStoneSurface(
      surf,
      ['#52564c', '#63685c', '#74796c', '#848a7b', '#969c8c'],
      419,
      {
        borderDark: '#393c35',
        borderLight: '#adb3a2',
        borderShadow: '#494d44',
        crystalDots: ['#3e4139', '#b0b6a5', 0.14],
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 24, aoStrength: 26, specStrength: 22, wrapEdges: false });
    return true;
  }

  if (name === 'tuff_bricks') {
    buildBrickCourseSurface(
      surf,
      ['#464940', '#585c51', '#6a6e62', '#7a7f72', '#8b9082', '#9da394'],
      '#32352e',
      [
        { y0: 0, y1: 8, xSplits: [15] },
        { y0: 8, y1: 16, xSplits: [7] },
      ],
      421,
      { mortarDepth: 0.10 },
    );
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 20 });
    return true;
  }

  if (name === 'chiseled_tuff' || name === 'chiseled_tuff_top') {
    const ramp = ['#33362e', '#484c42', '#5c6155', '#707568', '#83897a', '#989e8e'];
    const map = [
      '1111111111111111',
      '1444444444444431',
      '1400000000000021',
      '1404444444443021',
      '1404000000002021',
      '1404044444302021',
      '1404040000202021',
      '1404040430202021',
      '1404030220202021',
      '1404000000202021',
      '1403222222202021',
      '1400000000002021',
      '1322222222222021',
      '1200000000000021',
      '1322222222222221',
      '0000000000000000',
    ];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const lv = Number(map[y][x]) / 4;
        const n = (hash16(x, y, 431) - 0.5) * 0.08;
        const t = Math.max(0.05, Math.min(0.96, lv * 0.84 + 0.08 + n));
        surf.set(x, y, sampleRamp(ramp, t), 0.16 + lv * 0.70, lv > 0.7 ? 0.26 : 0.04);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 22, wrapEdges: false });
    return true;
  }

  if (name === 'chiseled_tuff_bricks' || name === 'chiseled_tuff_bricks_top') {
    const ramp = ['#30332b', '#464a40', '#5a5f53', '#6e7466', '#828879', '#979e8e'];
    const map = [
      '1444444314444443',
      '1400000214000002',
      '1404430214044302',
      '1404020214040202',
      '1403220214032202',
      '1400000214000002',
      '1322222213222222',
      '0000000000000000',
      '4431444444314444',
      '0021400000214000',
      '3021404430214044',
      '2021404020214040',
      '2021403220214032',
      '0021400000214000',
      '2221322222213222',
      '0000000000000000',
    ];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const lv = Number(map[y][x]) / 4;
        const n = (hash16(x, y, 433) - 0.5) * 0.08;
        const t = Math.max(0.04, Math.min(0.96, lv * 0.85 + 0.08 + n));
        surf.set(x, y, sampleRamp(ramp, t), 0.14 + lv * 0.72, lv > 0.7 ? 0.26 : 0.04);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 22 });
    return true;
  }

  // =========================================================================
  // FAMILY 6: BLACKSTONE & BASALT FAMILY
  // =========================================================================
  if (name === 'blackstone' || name === 'blackstone_top' || name === 'gilded_blackstone') {
    const ramp = ['#120f17', '#1e1a26', '#2b2536', '#393246', '#483f57', '#584e69'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, COBBLE_PTS, 'octagonal');
        const n = fbm16(x, y, 443, 8, 4);
        const isGroove = v.edgeDist < 0.46;
        const t = isGroove ? 0.05 : Math.min(0.95, 0.30 + v.cellRand * 0.30 + (n - 0.5) * 0.30 - (v.relX + v.relY) * 0.08);
        const h = isGroove ? 0.14 : 0.38 + t * 0.48;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.78 ? 0.25 : 0.04);
      }
    }
    if (name === 'gilded_blackstone') {
      const goldPat = ORE_PATTERNS.gold;
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const ch = goldPat.map[y][x];
          if (ch === '.') continue;
          if (ch === '0') {
            surf.set(x, y, '#140f1a', 0.16, 0);
          } else {
            const [gCol, gH, gSpec] = goldPat.pal[ch];
            surf.set(x, y, gCol, gH, gSpec);
          }
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 32, specStrength: 24 });
    return true;
  }

  if (name === 'polished_blackstone') {
    buildPolishedStoneSurface(
      surf,
      ['#1b1722', '#262130', '#332c3f', '#41394f', '#514761'],
      449,
      {
        borderDark: '#0e0c12',
        borderLight: '#665b78',
        borderShadow: '#16131c',
        crystalDots: ['#120f17', '#6b607d', 0.12],
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 26, wrapEdges: false });
    return true;
  }

  if (name === 'polished_blackstone_bricks') {
    buildBrickCourseSurface(
      surf,
      ['#18141f', '#231e2c', '#30293b', '#3e364c', '#4d435e', '#5e5370'],
      '#0d0a11',
      [
        { y0: 0, y1: 8, xSplits: [15] },
        { y0: 8, y1: 16, xSplits: [7] },
      ],
      457,
      { mortarDepth: 0.08 },
    );
    surf.commit(ctx, pass, { bevelStrength: 30, aoStrength: 34, specStrength: 24 });
    return true;
  }

  if (name === 'chiseled_polished_blackstone') {
    const ramp = ['#0f0c14', '#1d1826', '#2b2437', '#3a3149', '#4b405c', '#5e5170'];
    const map = [
      '1111111111111111',
      '1444444444444431',
      '1400000000000021',
      '1403333333333021',
      '1403444444442021',
      '1403400330022021',
      '1403400330022021',
      '1403400330022021',
      '1403400330022021',
      '1403400330022021',
      '1403222222222021',
      '1402222222222021',
      '1400000000000021',
      '1322222222222221',
      '1222222222222211',
      '0000000000000000',
    ];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const lv = Number(map[y][x]) / 4;
        const n = (hash16(x, y, 461) - 0.5) * 0.07;
        const t = Math.max(0.03, Math.min(0.96, lv * 0.86 + 0.06 + n));
        surf.set(x, y, sampleRamp(ramp, t), 0.12 + lv * 0.74, lv > 0.7 ? 0.30 : 0.05);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 30, aoStrength: 32, specStrength: 24, wrapEdges: false });
    return true;
  }

  if (name === 'basalt_top') {
    const ramp = ['#222327', '#33353b', '#454850', '#575b64', '#6a6f7a', '#7e838f'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const dx = Math.abs(x - 7.5), dy = Math.abs(y - 7.5);
        const oct = Math.max(dx, dy) * 0.75 + (dx + dy) * 0.32;
        const n = (hash16(x, y, 463) - 0.5) * 0.12;
        const ring = Math.sin(oct * 1.65) * 0.5 + 0.5;
        const isCrack = (x === y || x + y === 15) && oct > 2.5 && oct < 6.5;
        const t = isCrack ? 0.08 : Math.max(0.10, Math.min(0.95, ring * 0.72 + 0.14 + n));
        const h = isCrack ? 0.18 : 0.32 + t * 0.52;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.78 ? 0.28 : 0.05);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 22 });
    return true;
  }

  if (name === 'basalt_side' || name === 'basalt') {
    const ramp = ['#202125', '#313339', '#42454d', '#545862', '#666b77', '#797f8c'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const colPhase = (x % 4) / 4;
        const jointY = (y + Math.floor(x / 4) * 5) % 8 === 0;
        const n = periodicNoise16(x, y, 4, 8, 467) - 0.5;
        const isFurrow = x % 4 === 0 || jointY;
        const isRidge = x % 4 === 1 && !jointY;
        const t = isFurrow ? 0.08 + Math.max(0, n * 0.2) : isRidge ? 0.78 + n * 0.18 : 0.44 + (0.5 - colPhase) * 0.3 + n * 0.22;
        const h = isFurrow ? 0.16 : isRidge ? 0.80 : 0.52 + n * 0.20;
        surf.set(x, y, sampleRamp(ramp, t), h, isRidge ? 0.28 : 0.05);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 22 });
    return true;
  }

  if (name === 'smooth_basalt') {
    const ramp = ['#202126', '#2f3138', '#3e414a', '#4f525d', '#606470', '#727785'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, PRISMARINE_PTS, 'euclid');
        const n = fbm16(x, y, 479, 8, 8);
        const t = v.edgeDist < 0.35 ? 0.14 + n * 0.16 : Math.min(0.92, 0.32 + n * 0.48 + (0.5 - v.dist1 * 0.12));
        const h = 0.34 + t * 0.46;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.76 ? 0.22 : 0.05);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 22, aoStrength: 24, specStrength: 20 });
    return true;
  }

  // =========================================================================
  // FAMILY 7: SANDSTONES, QUARTZ, PRISMARINE, PURPUR, NETHER & END STONES
  // =========================================================================
  if (name.includes('sandstone')) {
    const red = name.includes('red_');
    const ramp = red
      ? ['#783814', '#94491f', '#ad5a2b', '#c26b38', '#d47e48', '#e6945c']
      : ['#a69560', '#bda971', '#d1be84', '#dfd098', '#ebe0ae', '#f7efc4'];
    const mortar = red ? '#692f10' : '#968552';

    if (name.endsWith('_top') || name === 'smooth_sandstone') {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const v = voronoi16(x, y, PRISMARINE_PTS, 'octagonal');
          const n = fbm16(x, y, red ? 487 : 491, 8, 4);
          const ripple = Math.sin(((x + y * 2) / 16) * Math.PI * 2) * 0.14;
          const isRim = x === 0 || y === 0;
          const isShadowRim = x === 15 || y === 15;
          let t = Math.max(0.12, Math.min(0.96, 0.48 + (n - 0.5) * 0.48 + v.cellRand * 0.18 + ripple));
          let h = 0.34 + t * 0.52;
          if (isRim) { t = Math.min(0.98, t + 0.22); h = 0.82; }
          else if (isShadowRim) { t = Math.max(0.08, t - 0.24); h = 0.22; }
          surf.set(x, y, sampleRamp(ramp, t), h, t > 0.80 ? 0.26 : 0.05);
        }
      }
      surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 26, specStrength: 20 });
      return true;
    }

    if (name.endsWith('_bottom')) {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const v = voronoi16(x, y, COBBLE_PTS, 'octagonal');
          const n = fbm16(x, y, red ? 499 : 503, 8, 8);
          const t = v.edgeDist < 0.48 ? 0.10 : Math.min(0.92, 0.35 + v.cellRand * 0.32 + (n - 0.5) * 0.25);
          surf.set(x, y, sampleRamp(ramp, t), v.edgeDist < 0.48 ? 0.18 : 0.40 + t * 0.45, 0.05);
        }
      }
      surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 14 });
      return true;
    }

    if (name === 'cut_sandstone') {
      buildBrickCourseSurface(
        surf,
        ramp,
        mortar,
        [
          { y0: 0, y1: 8, xSplits: [15] },
          { y0: 8, y1: 16, xSplits: [7] },
        ],
        509,
        { mortarDepth: 0.14 },
      );
      surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 18 });
      return true;
    }

    if (name === 'chiseled_sandstone') {
      const map = [
        '4444444444444444',
        '3333333333333333',
        '0000000000000000',
        '3444444444444432',
        '3400033333000422',
        '3400033333000422',
        '3400033003000422',
        '3433330000333422',
        '3433000000003422',
        '3433003333003422',
        '3433003333003422',
        '3433333333333422',
        '3222222222222222',
        '0000000000000000',
        '4444444444444444',
        '2222222222222222',
      ];
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const lv = Number(map[y][x]) / 4;
          const n = (hash16(x, y, 521) - 0.5) * 0.07;
          const t = Math.max(0.06, Math.min(0.96, lv * 0.82 + 0.10 + n));
          surf.set(x, y, sampleRamp(ramp, t), 0.16 + lv * 0.70, lv > 0.75 ? 0.22 : 0.04);
        }
      }
      surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 18, wrapEdges: false });
      return true;
    }

    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const n = fbm16(x, y, red ? 523 : 541, 8, 4);
        let t = 0.55 + (n - 0.5) * 0.28;
        let h = 0.58;
        if (y === 0) { t = 0.88; h = 0.82; }
        else if (y === 1 || y === 2) { t = 0.72 + (n - 0.5) * 0.18; h = 0.74; }
        else if (y === 3) { t = 0.14; h = 0.16; }
        else if (y === 7 || y === 11 || y === 15) {
          const wave = Math.round(Math.sin((x / 16) * Math.PI * 2) * 0.6);
          if (y + wave === 7 || y + wave === 11 || y === 15) { t = 0.16 + n * 0.14; h = 0.22; }
        } else if (y === 4 || y === 8 || y === 12) {
          t = Math.min(0.94, t + 0.18);
          h = 0.72;
        }
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.82 ? 0.20 : 0.03);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 16 });
    return true;
  }

  if (name.startsWith('quartz') || name === 'smooth_quartz') {
    const ramp = ['#bdb5a8', '#cfc8bc', '#dfd9ce', '#ece7de', '#f6f3ed', '#ffffff'];
    if (name === 'quartz_pillar' || name === 'quartz_pillar_side') {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const rib = x % 4;
          const isGroove = rib === 0;
          const isHighlight = rib === 1;
          const isCap = y === 0 || y === 15;
          const t = isCap ? (y === 0 ? 0.88 : 0.28) : isGroove ? 0.18 : isHighlight ? 0.94 : 0.68;
          const h = isCap ? (y === 0 ? 0.84 : 0.32) : isGroove ? 0.22 : isHighlight ? 0.82 : 0.60;
          surf.set(x, y, sampleRamp(ramp, t), h, isHighlight ? 0.45 : 0.10);
        }
      }
      surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 26 });
      return true;
    }

    if (name === 'quartz_pillar_top') {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const r = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5));
          const isGroove = Math.abs(r - 6.5) < 0.6 || Math.abs(r - 3.5) < 0.6;
          const t = isGroove ? 0.18 : r < 2.0 ? 0.92 : 0.74 - (x + y - 15) * 0.015;
          const h = isGroove ? 0.20 : 0.76;
          surf.set(x, y, sampleRamp(ramp, t), h, !isGroove ? 0.38 : 0.05);
        }
      }
      surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 26, wrapEdges: false });
      return true;
    }

    if (name === 'quartz_bricks') {
      buildBrickCourseSurface(
        surf,
        ramp,
        '#b0a89b',
        [
          { y0: 0, y1: 8, xSplits: [15] },
          { y0: 8, y1: 16, xSplits: [7] },
        ],
        547,
        { mortarDepth: 0.16 },
      );
      surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 26, specStrength: 26 });
      return true;
    }

    if (name === 'smooth_quartz') {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const v = voronoi16(x, y, PRISMARINE_PTS, 'octagonal');
          const n = fbm16(x, y, 557, 8, 8);
          const vein = v.edgeDist < 0.42 ? -0.18 : Math.sin(((x * 2 - y) / 16) * Math.PI * 2) * 0.12;
          const t = Math.max(0.18, Math.min(0.98, 0.66 + (n - 0.5) * 0.36 + vein));
          surf.set(x, y, sampleRamp(ramp, t), 0.32 + t * 0.52, t > 0.84 ? 0.45 : 0.12);
        }
      }
      surf.commit(ctx, pass, { bevelStrength: 24, aoStrength: 24, specStrength: 26 });
      return true;
    }

    buildPolishedStoneSurface(
      surf,
      ramp,
      563,
      {
        borderDark: '#b8b0a2',
        borderLight: '#ffffff',
        borderShadow: '#cfc8bc',
        grainScaleX: 8,
        grainScaleY: 4,
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 22, aoStrength: 22, specStrength: 28, wrapEdges: false });
    return true;
  }

  if (name === 'prismarine' || name === 'prismarine_top' || name === 'prismarine_side') {
    const ramp = ['#244d47', '#356b63', '#49877d', '#5fa397', '#7bbfb2', '#9cd9cc'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, PRISMARINE_PTS, 'octagonal');
        const n = fbm16(x, y, 569, 8, 8);
        if (v.edgeDist < 0.50) {
          const glow = ((x + y) % 5 === 0) ? '#62c4b8' : '#224a44';
          surf.set(x, y, glow, 0.14, 0.25);
        } else {
          const dome = Math.max(0, 1 - v.dist1 * 0.28);
          const dirBias = (-v.relX * 0.10 - v.relY * 0.12);
          const t = Math.max(0.20, Math.min(0.98, 0.40 + v.cellRand * 0.28 + dome * 0.24 + dirBias + (n - 0.5) * 0.18));
          surf.set(x, y, sampleRamp(ramp, t), 0.34 + dome * 0.52, t > 0.80 ? 0.35 : 0.08);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 24 });
    return true;
  }

  if (name === 'prismarine_bricks') {
    buildBrickCourseSurface(
      surf,
      ['#26524b', '#366e65', '#498a7f', '#5ca69a', '#74bfb2', '#91d9cc'],
      '#1c3d38',
      [
        { y0: 0, y1: 8, xSplits: [7, 15] },
        { y0: 8, y1: 16, xSplits: [3, 11] },
      ],
      571,
      { mortarDepth: 0.12 },
    );
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 24 });
    return true;
  }

  if (name === 'dark_prismarine') {
    buildBrickCourseSurface(
      surf,
      ['#162b24', '#223f35', '#2f5448', '#3e6b5c', '#4f8271', '#659987'],
      '#0e1c17',
      [
        { y0: 0, y1: 4, xSplits: [3, 7, 11, 15] },
        { y0: 4, y1: 8, xSplits: [1, 5, 9, 13] },
        { y0: 8, y1: 12, xSplits: [3, 7, 11, 15] },
        { y0: 12, y1: 16, xSplits: [1, 5, 9, 13] },
      ],
      577,
      { mortarDepth: 0.10 },
    );
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 32, specStrength: 24 });
    return true;
  }

  if (name === 'netherrack' || name === 'crimson_nylium' || name === 'warped_nylium' || name === 'crimson_nylium_side' || name === 'warped_nylium_side') {
    buildHostRockSurface(surf, 'netherrack', 587);
    if (name === 'crimson_nylium' || name === 'warped_nylium') {
      const warp = name.startsWith('warped');
      const ramp = warp
        ? ['#103d3a', '#1a5954', '#267871', '#35968d', '#48b5aa', '#68d4c8']
        : ['#4a1115', '#69191f', '#87232a', '#a62e36', '#c44149', '#e05c64'];
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const v = voronoi16(x, y, PRISMARINE_PTS, 'octagonal');
          const n = fbm16(x, y, warp ? 593 : 599, 8, 8);
          const t = v.edgeDist < 0.42 ? 0.12 : Math.min(0.96, 0.36 + v.cellRand * 0.32 + (n - 0.5) * 0.32);
          surf.set(x, y, sampleRamp(ramp, t), v.edgeDist < 0.42 ? 0.24 : 0.45 + t * 0.44, t > 0.82 ? 0.28 : 0.05);
        }
      }
    } else if (name.endsWith('_nylium_side')) {
      const warp = name.startsWith('warped');
      const ramp = warp
        ? ['#103d3a', '#1a5954', '#267871', '#35968d', '#48b5aa']
        : ['#4a1115', '#69191f', '#87232a', '#a62e36', '#c44149'];
      const overhang = [4, 5, 4, 3, 5, 6, 4, 3, 5, 4, 6, 5, 3, 4, 5, 4];
      for (let x = 0; x < 16; x++) {
        const oh = overhang[x];
        for (let y = 0; y <= oh; y++) {
          const isLip = y === oh;
          const isTop = y === 0;
          const t = isTop ? 0.88 : isLip ? 0.16 : 0.52 + (hash16(x, y, 601) - 0.5) * 0.28;
          surf.set(x, y, sampleRamp(ramp, t), isLip ? 0.25 : 0.76, isTop ? 0.30 : 0.06);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 20 });
    return true;
  }

  if (name === 'nether_bricks' || name === 'cracked_nether_bricks' || name === 'red_nether_bricks') {
    const red = name === 'red_nether_bricks';
    const ramp = red
      ? ['#260407', '#3b070c', '#520c13', '#6b121b', '#851b26', '#9e2632']
      : ['#1a0c0f', '#261217', '#33191f', '#422229', '#522b34', '#633640'];
    buildBrickCourseSurface(
      surf,
      ramp,
      red ? '#1a0204' : '#110709',
      [
        { y0: 0, y1: 4, xSplits: [7, 15] },
        { y0: 4, y1: 8, xSplits: [3, 11] },
        { y0: 8, y1: 12, xSplits: [7, 15] },
        { y0: 12, y1: 16, xSplits: [3, 11] },
      ],
      red ? 607 : 613,
      { mortarDepth: 0.08, cracked: name === 'cracked_nether_bricks' },
    );
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 32, specStrength: 22 });
    return true;
  }

  if (name === 'end_stone') {
    const ramp = ['#8f8a54', '#aba56a', '#c4be80', '#d9d496', '#ebe6ad', '#f7f4c6'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, COBBLE_PTS, 'octagonal');
        const n = fbm16(x, y, 617, 8, 8);
        const rim = Math.max(0, 1 - v.edgeDist * 0.65);
        const t = Math.max(0.10, Math.min(0.96, 0.25 + rim * 0.58 + (n - 0.5) * 0.22));
        const h = 0.24 + rim * 0.60 + (n - 0.5) * 0.14;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.82 ? 0.24 : 0.04);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 20 });
    return true;
  }

  if (name === 'end_stone_bricks') {
    buildBrickCourseSurface(
      surf,
      ['#9c9760', '#b5b076', '#ccc78c', '#dfdca0', '#eeeab4', '#faf7cc'],
      '#807b49',
      [
        { y0: 0, y1: 8, xSplits: [15] },
        { y0: 8, y1: 16, xSplits: [7] },
      ],
      619,
      { mortarDepth: 0.14 },
    );
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 28, specStrength: 22 });
    return true;
  }

  if (name === 'purpur_block') {
    buildBrickCourseSurface(
      surf,
      ['#6b456b', '#825882', '#996b99', '#ad7fad', '#c293c2', '#d6aad6'],
      '#523252',
      [
        { y0: 0, y1: 8, xSplits: [7, 15] },
        { y0: 8, y1: 16, xSplits: [7, 15] },
      ],
      631,
      { mortarDepth: 0.14 },
    );
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 22 });
    return true;
  }

  if (name === 'purpur_pillar' || name === 'purpur_pillar_top') {
    const ramp = ['#5e3b5e', '#784e78', '#916291', '#a876a8', '#bf8CBF', '#d4a3d4'];
    if (name === 'purpur_pillar_top') {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const r = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5));
          const isGroove = Math.abs(r - 6.5) < 0.6 || Math.abs(r - 3.5) < 0.6;
          const t = isGroove ? 0.16 : 0.72 - (x + y - 15) * 0.015;
          surf.set(x, y, sampleRamp(ramp, t), isGroove ? 0.18 : 0.76, !isGroove ? 0.28 : 0.04);
        }
      }
    } else {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const rib = x % 4;
          const isCap = y === 0 || y === 15;
          const t = isCap ? (y === 0 ? 0.86 : 0.24) : rib === 0 ? 0.16 : rib === 1 ? 0.88 : 0.60;
          const h = isCap ? 0.78 : rib === 0 ? 0.20 : rib === 1 ? 0.82 : 0.56;
          surf.set(x, y, sampleRamp(ramp, t), h, rib === 1 ? 0.30 : 0.05);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 22 });
    return true;
  }

  // =========================================================================
  // FAMILY 8: ALL 18 STONE / DEEPSLATE / NETHER ORES + RAW ORE BLOCKS + DEBRIS
  // =========================================================================
  if (name.endsWith('_ore')) {
    const isDeepslate = name.startsWith('deepslate_');
    const isNether = name.startsWith('nether_');
    const host = isDeepslate ? 'deepslate' : isNether ? 'netherrack' : 'stone';
    buildHostRockSurface(surf, host, isDeepslate ? 353 : isNether ? 587 : 101);

    const mineralKey = name
      .replace(/^deepslate_/, '')
      .replace(/^nether_/, '')
      .replace(/_ore$/, '');
    const oreSpec = ORE_PATTERNS[mineralKey] ?? ORE_PATTERNS.diamond;
    const socketCol: [number, number, number] = isDeepslate
      ? [24, 26, 31]
      : isNether
      ? [54, 20, 18]
      : [72, 73, 70];

    for (let y = 0; y < 16; y++) {
      const row = oreSpec.map[y];
      for (let x = 0; x < 16; x++) {
        const ch = row[x];
        if (ch === '.') continue;
        if (ch === '0') {
          const i = y * 16 + x;
          const blended = lerpRgb([surf.r[i], surf.g[i], surf.b[i]], socketCol, 0.65);
          surf.set(x, y, blended, 0.20, 0);
        } else {
          const [colHex, hVal, specVal] = oreSpec.pal[ch];
          surf.set(x, y, colHex, hVal, specVal);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 28 });
    return true;
  }

  if (name === 'raw_iron_block' || name === 'raw_copper_block') {
    const isIron = name === 'raw_iron_block';
    const ramp = isIron
      ? ['#4f3728', '#73523c', '#996f54', '#bf8f70', '#deb292', '#f5d2b5']
      : ['#2b6650', '#42876c', '#7a3b24', '#ad5737', '#d47650', '#f29a72'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, COBBLE_PTS, 'octagonal');
        const n = fbm16(x, y, isIron ? 641 : 643, 8, 8);
        if (v.edgeDist < 0.48) {
          surf.set(x, y, sampleRamp(ramp, isIron ? 0.05 : 0.08), 0.12, 0.10);
        } else {
          const dome = Math.max(0, 1 - v.dist1 * 0.28);
          const dirBias = (-v.relX * 0.11 - v.relY * 0.13);
          const t = Math.max(0.22, Math.min(0.98, 0.42 + v.cellRand * 0.28 + dome * 0.24 + dirBias + (n - 0.5) * 0.16));
          surf.set(x, y, sampleRamp(ramp, t), 0.34 + dome * 0.54, t > 0.78 ? 0.45 : 0.12);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 30, aoStrength: 32, specStrength: 28 });
    return true;
  }

  if (name === 'ancient_debris' || name === 'ancient_debris_top' || name === 'ancient_debris_side') {
    const ramp = ['#241713', '#3b2620', '#543830', '#6e4b41', '#8a6256', '#a87d6f', '#c49b8d'];
    if (name.endsWith('_top')) {
      const map = [
        '1233333333333321',
        '2455555555555421',
        '3511111111111421',
        '3514555555541421',
        '3514111111441421',
        '3514135541441421',
        '3514131141441421',
        '3514131241441421',
        '3514133341441421',
        '3514111111441421',
        '3514444444441421',
        '3511111111111421',
        '3444444444444421',
        '2111111111111121',
        '2344444444444321',
        '1111111111111111',
      ];
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const lv = (Number(map[y][x]) - 1) / 4;
          const n = (hash16(x, y, 647) - 0.5) * 0.08;
          surf.set(x, y, sampleRamp(ramp, Math.max(0.05, Math.min(0.96, lv * 0.85 + 0.08 + n))), 0.16 + lv * 0.72, lv > 0.7 ? 0.38 : 0.08);
        }
      }
    } else {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const plateY = y % 4;
          const off = (Math.floor(y / 4) % 2) * 4;
          const plateX = (x + off) % 8;
          const isGap = plateY === 3 || plateX === 7;
          const isRim = plateY === 0 || plateX === 0;
          const n = (hash16(x, y, 653) - 0.5) * 0.14;
          const t = isGap ? 0.08 : isRim ? 0.84 + n : 0.52 + n;
          const h = isGap ? 0.16 : isRim ? 0.80 : 0.56;
          surf.set(x, y, sampleRamp(ramp, t), h, isRim ? 0.35 : 0.08);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 30, aoStrength: 32, specStrength: 26 });
    return true;
  }

  // =========================================================================
  // FAMILY 9: STONE WORKSTATIONS, FURNACES, REDSTONE & AMETHYST
  // =========================================================================
  if (name === 'lodestone' || name === 'lodestone_top' || name === 'lodestone_side') {
    const ramp = ['#36383d', '#4d5057', '#666a73', '#7f848f', '#989ea8', '#b3b9c4', '#cfd5e0'];
    if (name === 'lodestone_top') {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const dx = Math.abs(x - 7.5), dy = Math.abs(y - 7.5);
          const isAxis = dx < 1.0 || dy < 1.0;
          const isDiag = Math.abs(dx - dy) < 1.0 && dx < 5.5;
          const oct = Math.max(dx, dy) + Math.min(dx, dy) * 0.45;
          let lv = 0.52;
          if (x === 0 || y === 0 || x === 15 || y === 15) lv = 0.18;
          else if (x === 1 || y === 1 || x === 14 || y === 14) lv = 0.80;
          else if (oct > 5.8 && oct < 7.0) lv = 0.22;
          else if (dx < 1.6 && dy < 1.6) lv = 0.94;
          else if (isAxis && oct < 6.0) lv = 0.86;
          else if (isDiag) lv = 0.72;
          surf.set(x, y, sampleRamp(ramp, lv), 0.16 + lv * 0.72, lv > 0.75 ? 0.40 : 0.08);
        }
      }
    } else {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          let lv = 0.54 + (hash16(x, y, 659) - 0.5) * 0.10;
          if (y === 0 || y === 15 || y === 4 || y === 11) lv = 0.18;
          else if (y === 1 || y === 5 || y === 12) lv = 0.84;
          else if (y > 4 && y < 11) {
            if (x === 0 || x === 15 || x === 4 || x === 11 || x === 7 || x === 8) lv = 0.20;
            else if (x === 1 || x === 5 || x === 12) lv = 0.82;
            else lv = 0.62;
          }
          surf.set(x, y, sampleRamp(ramp, lv), 0.16 + lv * 0.72, lv > 0.75 ? 0.35 : 0.08);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 26, wrapEdges: false });
    return true;
  }

  if (
    /^(furnace|blast_furnace|smoker|dispenser|dropper|observer)_(top|bottom|side|front|back)$/.test(name) ||
    name === 'furnace' || name === 'blast_furnace' || name === 'smoker' || name === 'dispenser' || name === 'dropper' || name === 'observer'
  ) {
    const isBlast = name.startsWith('blast_furnace');
    const isSmoker = name.startsWith('smoker');
    const isObs = name.startsWith('observer');
    const isDisp = name.startsWith('dispenser');
    const isDrop = name.startsWith('dropper');
    const face = name.endsWith('_top') ? 'top' : name.endsWith('_bottom') ? 'bottom' : name.endsWith('_front') ? 'front' : name.endsWith('_back') ? 'back' : 'side';

    const stoneRamp = isBlast
      ? ['#3b3e40', '#505457', '#676c70', '#7e8488', '#969ca1', '#b0b6bc']
      : ['#383a38', '#4f524e', '#666965', '#7b7f7a', '#919690', '#a8ada6'];

    if (face === 'top' || face === 'bottom') {
      // Concentric framed stone top (no horizontal brick split!)
      buildPolishedStoneSurface(
        surf,
        stoneRamp,
        661,
        {
          borderDark: '#262826',
          borderLight: '#b5bab3',
          borderShadow: '#454845',
        },
      );
      for (let i = 3; i < 13; i++) {
        surf.set(i, 3, '#383a38', 0.24, 0);
        surf.set(i, 12, '#383a38', 0.24, 0);
        surf.set(3, i, '#383a38', 0.24, 0);
        surf.set(12, i, '#383a38', 0.24, 0);
      }
      if (isSmoker && face === 'top') {
        for (let y = 5; y <= 10; y++) {
          for (let x = 5; x <= 10; x++) {
            const isHole = (x === 6 || x === 9) && (y === 6 || y === 9);
            surf.set(x, y, isHole ? '#141615' : '#4a4e4d', isHole ? 0.08 : 0.65, isHole ? 0 : 0.25);
          }
        }
      }
      if (isObs && face === 'top') {
        for (let y = 2; y < 14; y++) {
          surf.set(7, y, '#222422', 0.18, 0);
          surf.set(8, y, '#222422', 0.18, 0);
        }
        surf.set(6, 5, '#c92a22', 0.65, 0.40);
        surf.set(9, 5, '#c92a22', 0.65, 0.40);
        surf.set(7, 4, '#eb3b30', 0.72, 0.55);
        surf.set(8, 4, '#eb3b30', 0.72, 0.55);
      }
      surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 22, wrapEdges: false });
      return true;
    }

    buildBrickCourseSurface(
      surf,
      stoneRamp,
      '#282a28',
      [
        { y0: 0, y1: 8, xSplits: [7, 15] },
        { y0: 8, y1: 16, xSplits: [3, 11] },
      ],
      661,
      { mortarDepth: 0.14 },
    );

    if (isSmoker && (face === 'side' || face === 'front')) {
      for (let y = 0; y < 16; y++) {
        for (const x of [0, 1, 14, 15]) {
          const isOuter = x === 0 || x === 15;
          surf.set(x, y, isOuter ? '#4a361e' : '#6e5230', isOuter ? 0.65 : 0.78, 0.10);
        }
      }
    }

    if (face === 'front') {
      if (isObs) {
        for (let x = 2; x < 14; x++) {
          surf.set(x, 4, '#262826', 0.22, 0);
          surf.set(x, 5, '#9ea39d', 0.82, 0.25);
        }
        for (const ex of [4, 10]) {
          for (let dy = 6; dy <= 8; dy++) {
            for (let dx = 0; dx < 2; dx++) {
              surf.set(ex + dx, dy, dy === 7 && dx === 0 ? '#d9dada' : '#141615', 0.14, 0.30);
            }
          }
        }
        for (let x = 6; x <= 9; x++) {
          surf.set(x, 11, '#1a1c1b', 0.14, 0);
          surf.set(x, 12, '#323634', 0.24, 0);
        }
      } else if (isDisp || isDrop) {
        for (let y = 2; y < 14; y++) {
          for (let x = 2; x < 14; x++) {
            surf.set(x, y, sampleRamp(stoneRamp, 0.64), 0.66, 0.10);
          }
        }
        if (isDisp) {
          for (let y = 5; y <= 10; y++) {
            for (let x = 5; x <= 10; x++) {
              const d = Math.hypot(x - 7.5, y - 7.5);
              if (d < 2.2) surf.set(x, y, '#101211', 0.06, 0);
              else if (d < 3.2) surf.set(x, y, '#383b38', 0.28, 0);
            }
          }
        } else {
          for (let y = 6; y <= 10; y++) {
            const halfW = y - 5;
            for (let x = 8 - halfW; x <= 7 + halfW; x++) {
              surf.set(x, y, y === 10 ? '#383b38' : '#101211', 0.08, 0);
            }
          }
        }
      } else {
        for (let y = 2; y <= 6; y++) {
          for (let x = 3; x <= 12; x++) {
            if (y === 2 && (x === 3 || x === 12)) continue;
            const isGrate = isBlast && y >= 4 && x >= 4 && x <= 11 && x % 2 === 0;
            surf.set(x, y, isGrate ? '#8a9499' : '#141615', isGrate ? 0.68 : 0.10, isGrate ? 0.40 : 0);
          }
        }
        for (let y = 9; y <= 13; y++) {
          for (let x = 3; x <= 12; x++) {
            const isEmber = (isBlast || isSmoker) && y === 12 && x >= 5 && x <= 10;
            surf.set(x, y, isEmber ? '#e86a24' : y === 13 ? '#595c58' : '#101211', isEmber ? 0.45 : 0.08, isEmber ? 0.65 : 0);
          }
        }
      }
    } else if (face === 'back' && isObs) {
      for (let y = 5; y <= 10; y++) {
        for (let x = 5; x <= 10; x++) {
          const d = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5));
          surf.set(x, y, d < 1.5 ? '#e03024' : d < 2.5 ? '#7a1610' : '#2a2d2b', d < 1.5 ? 0.72 : 0.25, d < 1.5 ? 0.65 : 0);
        }
      }
    }

    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 22 });
    return true;
  }

  if (name === 'stonecutter' || name === 'stonecutter_top' || name === 'stonecutter_side' || name === 'stonecutter_bottom') {
    if (name === 'stonecutter_top') {
      buildPolishedStoneSurface(
        surf,
        ['#8a8c88', '#9a9c98', '#abada8', '#b8bab5', '#c7c9c4'],
        673,
        { borderDark: '#575955', borderLight: '#d8dad4', borderShadow: '#7c7e7a' },
      );
      for (let x = 2; x < 14; x++) {
        surf.set(x, 7, '#1c1d1c', 0.08, 0);
        surf.set(x, 8, '#1c1d1c', 0.08, 0);
        surf.set(x, 6, '#666864', 0.36, 0);
        surf.set(x, 9, '#d8dad4', 0.78, 0.30);
      }
    } else if (name === 'stonecutter_bottom') {
      buildHostRockSurface(surf, 'deepslate', 677);
    } else {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const n = (hash16(x, y, 679) - 0.5) * 0.14;
          if (y < 7) {
            const isTop = y === 0;
            const isBot = y === 6;
            const t = isTop ? 0.90 : isBot ? 0.22 : 0.62 + n;
            surf.set(x, y, sampleRamp(['#575955', '#7c7e7a', '#9a9c98', '#b8bab5', '#d8dad4'], t), isTop ? 0.82 : isBot ? 0.28 : 0.65, isTop ? 0.30 : 0.08);
          } else {
            const isLeg = x < 4 || x > 11 || y > 11;
            const t = isLeg ? 0.42 + n : 0.12 + n * 0.5;
            surf.set(x, y, sampleRamp(['#1e2024', '#31343a', '#454952', '#5c616b'], t), isLeg ? 0.56 : 0.20, 0.06);
          }
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 22, wrapEdges: false });
    return true;
  }

  if (name === 'grindstone') {
    const ramp = ['#60635e', '#757872', '#8a8e87', '#9ea39b', '#b4b8b0', '#cacfc6'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const d = Math.hypot(x - 7.5, y - 7.5);
        const n = (hash16(x, y, 683) - 0.5) * 0.12;
        if (d < 2.2) {
          surf.set(x, y, d < 1.2 ? '#2b2015' : '#59432c', 0.22, 0.10);
        } else if (d < 3.4) {
          surf.set(x, y, sampleRamp(ramp, 0.88), 0.78, 0.30);
        } else {
          const ring = Math.cos((d / 7.5) * Math.PI) * 0.2 + 0.55 + n;
          surf.set(x, y, sampleRamp(ramp, Math.max(0.15, Math.min(0.95, ring))), 0.45 + ring * 0.35, 0.12);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 22, wrapEdges: false });
    return true;
  }

  if (name === 'amethyst_block' || name === 'amethyst_block_top' || name === 'amethyst_block_side' || name === 'budding_amethyst') {
    const ramp = ['#341d54', '#4e2f7a', '#6b44a1', '#895ec4', '#ab7fe3', '#cfa8ff', '#f3e6ff'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, PRISMARINE_PTS, 'manhattan');
        const cleave = ((x * 3 - y * 2 + 32) % 7) / 7;
        const isEdge = v.edgeDist < 0.45;
        const t = isEdge ? 0.12 : Math.max(0.20, Math.min(0.98, 0.32 + v.cellRand * 0.36 + cleave * 0.30));
        const h = isEdge ? 0.22 : 0.42 + t * 0.48;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.76 ? 0.65 : 0.18);
      }
    }
    if (name === 'budding_amethyst') {
      for (let i = 2; i < 14; i++) {
        for (const [cx, cy] of [[i, i], [15 - i, i]]) {
          surf.set(cx, cy, '#221138', 0.12, 0.20);
          if (i % 2 === 0) surf.set(Math.min(15, cx + 1), cy, '#f3e6ff', 0.88, 0.90);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 28, specStrength: 32 });
    return true;
  }

  // =========================================================================
  // FAMILY 10: MINERAL BLOCKS, 1.21 COPPER / TRIAL BLOCKS, MAGMA, PORTAL FRAME
  // =========================================================================
  if (name === 'coal_block') {
    const ramp = ['#0b0c0e', '#141619', '#1e2126', '#2a2e35', '#383d46', '#484e59'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, COBBLE_PTS, 'manhattan');
        const n = fbm16(x, y, 701, 8, 8);
        const isSeam = v.edgeDist < 0.42;
        const t = isSeam ? 0.04 : Math.min(0.96, 0.28 + v.cellRand * 0.34 + (n - 0.5) * 0.30);
        const h = isSeam ? 0.14 : 0.38 + t * 0.48;
        surf.set(x, y, sampleRamp(ramp, t), h, t > 0.78 ? 0.50 : 0.10);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 28 });
    return true;
  }

  if (name === 'lapis_block') {
    const ramp = ['#102054', '#193382', '#2347ab', '#315cd1', '#4875eb', '#6b96ff'];
    buildPolishedStoneSurface(
      surf,
      ramp,
      709,
      {
        borderDark: '#0d1b47',
        borderLight: '#78a1ff',
        borderShadow: '#162c70',
        crystalDots: ['#122561', '#d9b848', 0.16],
      },
    );
    surf.commit(ctx, pass, { bevelStrength: 24, aoStrength: 26, specStrength: 26, wrapEdges: false });
    return true;
  }

  if (name === 'netherite_block') {
    const ramp = ['#1d191e', '#2b262d', '#3a333d', '#4a424e', '#5b5260', '#706575'];
    buildPolishedStoneSurface(
      surf,
      ramp,
      719,
      {
        borderDark: '#141115',
        borderLight: '#827687',
        borderShadow: '#221d24',
        grainScaleX: 8,
        grainScaleY: 4,
      },
    );
    for (const y of [4, 8, 12]) {
      for (let x = 2; x < 14; x++) {
        surf.set(x, y, '#181419', 0.24, 0.05);
        surf.set(x, y + 1, '#665c6b', 0.74, 0.40);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 30, wrapEdges: false });
    return true;
  }

  if (
    name === 'cut_copper' ||
    name === 'exposed_cut_copper' ||
    name === 'weathered_cut_copper' ||
    name === 'oxidized_cut_copper'
  ) {
    const ramp = name.startsWith('oxidized_')
      ? ['#29594b', '#387563', '#49917b', '#5bad94', '#72c4ab', '#8ed9c2']
      : name.startsWith('weathered_')
      ? ['#3b5941', '#4e7556', '#628f6b', '#78a67e', '#91bd94', '#abd4ad']
      : name.startsWith('exposed_')
      ? ['#5c4338', '#78584a', '#916d5c', '#a8826e', '#bf9882', '#d4ae98']
      : ['#783822', '#96492e', '#b55b3c', '#cf6f4e', '#e68663', '#fa9f7d'];
    const mortar = name.startsWith('oxidized_')
      ? '#1d4237'
      : name.startsWith('weathered_')
      ? '#2b4230'
      : name.startsWith('exposed_')
      ? '#453128'
      : '#592716';
    buildBrickCourseSurface(
      surf,
      ramp,
      mortar,
      [
        { y0: 0, y1: 8, xSplits: [7, 15] },
        { y0: 8, y1: 16, xSplits: [7, 15] },
      ],
      727,
      { mortarDepth: 0.14 },
    );
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 28, specStrength: 28 });
    return true;
  }

  if (
    name === 'chiseled_copper' ||
    name === 'exposed_chiseled_copper' ||
    name === 'weathered_chiseled_copper' ||
    name === 'oxidized_chiseled_copper'
  ) {
    const ramp = name.startsWith('oxidized_')
      ? ['#244f42', '#356e5d', '#478c77', '#5aa890', '#72c2a9', '#8fd9c1']
      : name.startsWith('weathered_')
      ? ['#35523b', '#496e50', '#5e8a66', '#74a37b', '#8ebd92', '#a8d4ac']
      : name.startsWith('exposed_')
      ? ['#543d33', '#705245', '#8a6757', '#a37c6a', '#ba927e', '#d1a994']
      : ['#6e321e', '#8f432b', '#ad5539', '#c96a4b', '#e38160', '#fa9b7a'];
    const map = [
      '1444444444444431',
      '1400000000000021',
      '1404444004444021',
      '1404223004223021',
      '1404202004202021',
      '1404322004322021',
      '1403222003222021',
      '1400000440000021',
      '1400000440000021',
      '1404444004444021',
      '1404223004223021',
      '1404202004202021',
      '1404322004322021',
      '1403222003222021',
      '1322222222222221',
      '0000000000000000',
    ];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const lv = Number(map[y][x]) / 4;
        const n = (hash16(x, y, 733) - 0.5) * 0.07;
        surf.set(x, y, sampleRamp(ramp, Math.max(0.05, Math.min(0.96, lv * 0.85 + 0.08 + n))), 0.14 + lv * 0.72, lv > 0.7 ? 0.38 : 0.08);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 28, wrapEdges: false });
    return true;
  }

  if (name === 'trial_spawner' || name === 'vault' || name === 'ominous_vault') {
    const isOminous = name === 'ominous_vault';
    const isVault = name === 'vault' || isOminous;
    const frameCol = isOminous ? '#2d4059' : '#364f59';
    const highlightCol = isOminous ? '#5878a3' : '#5e8896';
    const copperTrim = isOminous ? '#49917b' : '#c96a4b';
    const glowCol = isOminous ? '#4fd8eb' : '#ff9b38';
    buildHostRockSurface(surf, 'deepslate', 739);
    for (let i = 0; i < 16; i++) {
      for (const r of [0, 1, 14, 15]) {
        surf.set(i, r, r === 0 || r === 14 ? highlightCol : frameCol, 0.82, 0.35);
        surf.set(r, i, r === 0 || r === 14 ? highlightCol : frameCol, 0.82, 0.35);
      }
      surf.set(i, 2, copperTrim, 0.74, 0.40);
      surf.set(i, 13, copperTrim, 0.74, 0.40);
    }
    for (let y = 4; y < 12; y++) {
      for (let x = 4; x < 12; x++) {
        const isBar = !isVault && (x === 6 || x === 9 || y === 6 || y === 9);
        surf.set(x, y, isBar ? frameCol : '#0d1217', isBar ? 0.68 : 0.10, isBar ? 0.25 : 0);
      }
    }
    for (let y = 6; y <= 9; y++) {
      for (let x = 7; x <= 8; x++) {
        surf.set(x, y, glowCol, 0.78, 0.90);
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 28, wrapEdges: false });
    return true;
  }

  if (name === 'magma_block') {
    const rockRamp = ['#210e0b', '#331612', '#47201a', '#5c2a22', '#70352b'];
    const lavaRamp = ['#b83814', '#e05a1e', '#fa8c28', '#ffbd38', '#fff078'];
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        const v = voronoi16(x, y, COBBLE_PTS, 'octagonal');
        const n = fbm16(x, y, 743, 8, 8);
        if (v.edgeDist < 0.58) {
          const lt = Math.max(0, Math.min(1, (0.58 - v.edgeDist) * 1.9 + (n - 0.5) * 0.25));
          surf.set(x, y, sampleRamp(lavaRamp, lt), 0.24, 0.85);
        } else {
          const rt = Math.max(0.1, Math.min(0.95, 0.30 + v.cellRand * 0.35 + (n - 0.5) * 0.30));
          surf.set(x, y, sampleRamp(rockRamp, rt), 0.68, 0.06);
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 26, aoStrength: 28, specStrength: 24 });
    return true;
  }

  if (name === 'end_portal_frame_top' || name === 'end_portal_frame_side') {
    const stoneRamp = ['#9e9960', '#b8b376', '#d1cc8e', '#e3dfa2', '#f2efb8'];
    const tealRamp = ['#1c3d35', '#2d5e52', '#3f7d6e', '#569c8b', '#75bfb0', '#9ee0d1'];
    if (name === 'end_portal_frame_top') {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const r = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5));
          if (r < 3.6) {
            surf.set(x, y, r < 2.6 ? '#0e1c18' : '#224038', r < 2.6 ? 0.08 : 0.28, 0.10);
          } else if (r < 5.6) {
            const t = 0.45 + (hash16(x, y, 751) - 0.5) * 0.25;
            surf.set(x, y, sampleRamp(stoneRamp, t), 0.58, 0.12);
          } else {
            const isCorner = (x <= 2 || x >= 13) && (y <= 2 || y >= 13);
            surf.set(x, y, sampleRamp(tealRamp, isCorner ? 0.85 : 0.52), isCorner ? 0.86 : 0.74, isCorner ? 0.45 : 0.20);
          }
        }
      }
    } else {
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const n = (hash16(x, y, 757) - 0.5) * 0.22;
          if (y < 5 || (y < 8 && ((x >= 2 && x <= 4) || (x >= 11 && x <= 13)))) {
            const isRim = y === 0 || y === 4;
            surf.set(x, y, sampleRamp(tealRamp, isRim ? 0.78 : 0.48 + n), isRim ? 0.82 : 0.68, 0.28);
          } else if (y === 15) {
            surf.set(x, y, sampleRamp(stoneRamp, 0.15), 0.24, 0);
          } else {
            surf.set(x, y, sampleRamp(stoneRamp, 0.58 + n), 0.54 + n * 0.2, 0.10);
          }
        }
      }
    }
    surf.commit(ctx, pass, { bevelStrength: 28, aoStrength: 30, specStrength: 24, wrapEdges: false });
    return true;
  }

  return false;
}
