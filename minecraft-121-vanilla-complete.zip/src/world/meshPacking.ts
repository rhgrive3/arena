/** 0xffff is reserved for primitive restart in WebGL 2. Keep large meshes at 32 bits. */
export function compactIndices(indices: Uint32Array, vertexCount: number): Uint16Array | Uint32Array {
  return vertexCount <= 65535 ? new Uint16Array(indices) : indices;
}