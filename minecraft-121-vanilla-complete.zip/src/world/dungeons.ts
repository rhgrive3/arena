// Structure builders added with the dungeon pass: trial chambers (1.21), ruined portals, ocean ruins, buried treasure and trail ruins,
// plus the small "bee tree" feature. Every builder is a pure function of the world seed and writes through `put`, which clips to the
// chunk being generated — so the same code runs on the main thread (loot / spawner lookup) and in chunk workers.
import { ID } from '../game/data';
import { makeCell } from '../game/blockState';
import type { Terrain } from './terrain';
import type { Put, Placed } from './structures';
import { growJigsaw, toWorld, worldDir, type Box, type Connector, type PieceDef, type Placed as JigsawPlaced, type Pool } from './struct/jigsaw';
import { chest, barrel, pottedPlant } from './struct/decor';
import { tag, bed, door, stairsUp, ladderOn, attachOn, rsFacing, PANE_X, PANE_Z } from './struct/common';

const SEA = 62;
const B = ID as Record<string, number | undefined>;
const id = (name: string, fallback = 'stone'): number => B[name] ?? B[fallback] ?? 1;
const cell = (name: string, state = 0, fallback = 'stone'): number => {
  const b = id(name, fallback);
  return state && b > 0 ? makeCell(b, state & 15) : b;
};
const hash = (x: number, z: number, seed: number) => {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
const hash3 = (x: number, y: number, z: number, seed: number) => hash(x + y * 131, z - y * 71, seed);
function mulberry(seed: number) {
  let a = seed | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// =========================================================================================================================
// 1. Trial Chambers (1.21) — Jigsaw multi-template network:
//    Corridors (straight_1..8, turn, intersection, end_1/2, entrance with respawn beds), Atrium (2-storey grand gallery with
//    copper grates, upper catwalks, breeze spawners, dispensers & vault), and 9 distinct combat/treasure chamber templates
//    (assembly, eruption, fanned,pedestal, slanted, stepped, addons, supply, ominous vault arena) with Tuff/Copper processor.
// =========================================================================================================================
export const CHAMBER_CELL = 16;
export const CHAMBER_GRID = 2;
export type SpawnerKind = 'melee' | 'small_melee' | 'ranged' | 'breeze';
export type RoomType = 'atrium' | 'spawner' | 'vault' | 'supply' | 'ominous';
export type ChamberTemplate =
  | 'atrium_grand'
  | 'chamber_assembly'
  | 'chamber_eruption'
  | 'chamber_fanned'
  | 'chamber_pedestal'
  | 'chamber_slanted'
  | 'chamber_stepped'
  | 'chamber_gallery'
  | 'vault_sanctum'
  | 'vault_treasury'
  | 'supply_cache'
  | 'supply_barracks'
  | 'ominous_arena';
export type CorridorStyle = 'columns' | 'alcoves' | 'grated' | 'bridged';

export interface ChamberRoom {
  gx: number; gz: number; x: number; z: number;
  type: RoomType;
  template: ChamberTemplate;
  rot: number;
  corridorStyle: CorridorStyle;
  /** bit 0 N(-z) · 1 E(+x) · 2 S(+z) · 3 W(-x) */
  links: number;
}
export interface ChamberLayout {
  x: number; y: number; z: number;
  rooms: ChamberRoom[];
  spawners: { x: number; y: number; z: number; kind: SpawnerKind }[];
  vaults: { x: number; y: number; z: number; ominous: boolean }[];
  chests: [number, number, number][];
  pots: [number, number, number][];
  dispensers: [number, number, number][];
  barrels: [number, number, number][];
}

const DIRS: [number, number][] = [[0, -1], [1, 0], [0, 1], [-1, 0]];
const layouts = new Map<string, ChamberLayout>();
const SPAWNER_TEMPLATES: ChamberTemplate[] = ['chamber_assembly', 'chamber_eruption', 'chamber_fanned', 'chamber_pedestal', 'chamber_slanted', 'chamber_stepped', 'chamber_gallery'];
const VAULT_TEMPLATES: ChamberTemplate[] = ['vault_sanctum', 'vault_treasury'];
const SUPPLY_TEMPLATES: ChamberTemplate[] = ['supply_cache', 'supply_barracks'];
const CORR_STYLES: CorridorStyle[] = ['columns', 'alcoves', 'grated', 'bridged'];

export function chamberLayout(seed: number, px: number, py: number, pz: number): ChamberLayout {
  const key = `${seed}:${px},${py},${pz}`, cached = layouts.get(key);
  if (cached) return cached;
  const rnd = mulberry(Math.imul(seed | 0, 31) ^ Math.imul(px | 0, 73856093) ^ Math.imul(pz | 0, 19349663));
  const rooms: ChamberRoom[] = [{ gx: 0, gz: 0, x: px, z: pz, type: 'atrium', template: 'atrium_grand', rot: Math.floor(rnd() * 4), corridorStyle: 'columns', links: 0 }];
  const at = (gx: number, gz: number) => rooms.find(r => r.gx === gx && r.gz === gz);
  const want = 9 + Math.floor(rnd() * 5);
  for (let guard = 0; rooms.length < want && guard < 600; guard++) {
    const from = rooms[Math.floor(rnd() * rooms.length)], d = Math.floor(rnd() * 4), gx = from.gx + DIRS[d][0], gz = from.gz + DIRS[d][1];
    if (Math.abs(gx) > CHAMBER_GRID || Math.abs(gz) > CHAMBER_GRID) continue;
    const existing = at(gx, gz);
    if (existing) {
      if (rnd() < 0.25) { from.links |= 1 << d; existing.links |= 1 << ((d + 2) % 4); }
      continue;
    }
    from.links |= 1 << d;
    rooms.push({
      gx, gz, x: px + gx * CHAMBER_CELL, z: pz + gz * CHAMBER_CELL,
      type: 'spawner', template: 'chamber_assembly', rot: Math.floor(rnd() * 4),
      corridorStyle: CORR_STYLES[Math.floor(rnd() * CORR_STYLES.length)],
      links: 1 << ((d + 2) % 4),
    });
  }
  let far = rooms[rooms.length - 1], farD = -1;
  for (const r of rooms.slice(1)) { const d = Math.abs(r.gx) + Math.abs(r.gz); if (d > farD) { farD = d; far = r; } }
  const cycle: RoomType[] = ['spawner', 'vault', 'spawner', 'supply', 'spawner', 'vault', 'spawner', 'supply'];
  let n = 0, spIdx = Math.floor(rnd() * SPAWNER_TEMPLATES.length), vIdx = Math.floor(rnd() * 2), sIdx = Math.floor(rnd() * 2);
  for (const r of rooms.slice(1)) {
    r.type = r === far ? 'ominous' : cycle[n++ % cycle.length];
    if (r.type === 'ominous') r.template = 'ominous_arena';
    else if (r.type === 'spawner') r.template = SPAWNER_TEMPLATES[spIdx++ % SPAWNER_TEMPLATES.length];
    else if (r.type === 'vault') r.template = VAULT_TEMPLATES[vIdx++ % VAULT_TEMPLATES.length];
    else r.template = SUPPLY_TEMPLATES[sIdx++ % SUPPLY_TEMPLATES.length];
  }

  const L: ChamberLayout = { x: px, y: py, z: pz, rooms, spawners: [], vaults: [], chests: [], pots: [], dispensers: [], barrels: [] };
  const kinds: SpawnerKind[] = ['melee', 'ranged', 'small_melee', 'melee', 'ranged', 'breeze'];
  for (const r of rooms) {
    if (r.type === 'atrium') {
      L.spawners.push({ x: r.x - 3, y: py, z: r.z, kind: 'breeze' }, { x: r.x + 3, y: py, z: r.z, kind: 'breeze' });
      L.vaults.push({ x: r.x, y: py, z: r.z, ominous: false });
      L.chests.push([r.x + 3, py, r.z + 3]);
      L.pots.push([r.x - 4, py, r.z - 4], [r.x + 4, py, r.z - 4], [r.x - 4, py, r.z + 4]);
      L.dispensers.push([r.x - 4, py + 2, r.z], [r.x + 4, py + 2, r.z]);
    } else if (r.type === 'spawner') {
      const k1 = kinds[Math.floor(rnd() * kinds.length)];
      L.spawners.push({ x: r.x, y: py, z: r.z, kind: k1 });
      if (r.template === 'chamber_eruption' || r.template === 'chamber_gallery') {
        L.spawners.push({ x: r.x, y: py + 4, z: r.z - 3, kind: 'ranged' });
      }
      L.pots.push([r.x - 3, py, r.z + 3], [r.x + 3, py, r.z - 3]);
      L.dispensers.push([r.x, py + 2, r.z - 4]);
    } else if (r.type === 'vault') {
      L.vaults.push({ x: r.x, y: py, z: r.z, ominous: false });
      L.pots.push([r.x - 3, py, r.z - 3], [r.x + 3, py, r.z + 3], [r.x - 3, py, r.z + 3], [r.x + 3, py, r.z - 3]);
      L.chests.push([r.x, py, r.z - 4]);
    } else if (r.type === 'supply') {
      L.chests.push([r.x - 3, py, r.z - 3], [r.x + 3, py, r.z + 3]);
      L.barrels.push([r.x - 3, py, r.z - 2], [r.x - 2, py, r.z - 3]);
      L.pots.push([r.x + 3, py, r.z - 3], [r.x - 3, py, r.z + 3]);
    } else {
      L.vaults.push({ x: r.x, y: py + 1, z: r.z, ominous: true });
      L.spawners.push({ x: r.x - 3, y: py, z: r.z - 3, kind: 'melee' }, { x: r.x + 3, y: py, z: r.z + 3, kind: 'ranged' }, { x: r.x, y: py + 4, z: r.z - 3, kind: 'breeze' });
      L.pots.push([r.x - 4, py, r.z + 4], [r.x + 4, py, r.z - 4]);
      L.dispensers.push([r.x - 4, py + 2, r.z], [r.x + 4, py + 2, r.z]);
    }
  }
  if (layouts.size > 64) layouts.clear();
  layouts.set(key, L);
  return L;
}

export function trialChambers(t: Terrain, put: Put, p: Placed) {
  const L = chamberLayout(t.seed, p.x, p.y, p.z), s = t.seed + 7800, y = p.y;
  const bricks = id('tuff_bricks', 'tuff'), polished = id('polished_tuff', 'tuff'), chisT = id('chiseled_tuff', 'tuff'), chisTB = id('chiseled_tuff_bricks', 'tuff'), tuff = id('tuff');
  const copper = id('copper_block'), expCop = id('exposed_copper', 'copper_block'), weaCop = id('weathered_copper', 'copper_block'), ox = id('oxidized_copper', 'copper_block');
  const cut = id('cut_copper', 'copper_block'), expCut = id('exposed_cut_copper', 'cut_copper'), weaCut = id('weathered_cut_copper', 'cut_copper'), oxCut = id('oxidized_cut_copper', 'copper_block');
  const chisC = id('chiseled_copper', 'copper_block'), expChisC = id('exposed_chiseled_copper', 'chiseled_copper'), weaChisC = id('weathered_chiseled_copper', 'chiseled_copper'), oxChisC = id('oxidized_chiseled_copper', 'chiseled_copper');
  const grate = id('copper_grate', 'copper_block'), bulb = id('copper_bulb_lit', 'glowstone'), chain = id('chain', 'iron_bars'), water = id('water'), magma = id('magma_block', 'tuff');
  const waxedCop = id('waxed_copper_block', 'copper_block'), waxedCut = id('waxed_cut_copper', 'cut_copper');
  const copDoor = id('copper_door', 'oak_door'), copTrap = id('copper_trapdoor', 'oak_trapdoor'), oxBulb = id('oxidized_copper_bulb', 'copper_bulb_lit');

  // Vanilla processor: oxidized/weathered/exposed/waxed copper mix + tuff brick/polished tuff weathering.
  const copperWall = (x: number, yy: number, z: number) => {
    const r = hash3(x, yy, z, s + 11);
    return r < 0.28 ? ox : r < 0.52 ? weaCop : r < 0.74 ? expCop : copper;
  };
  const cutFloor = (x: number, yy: number, z: number) => {
    const r = hash3(x, yy, z, s + 12);
    return r < 0.25 ? oxCut : r < 0.50 ? weaCut : r < 0.75 ? expCut : cut;
  };
  const chisCopper = (x: number, yy: number, z: number) => {
    const r = hash3(x, yy, z, s + 13);
    return r < 0.25 ? oxChisC : r < 0.50 ? weaChisC : r < 0.75 ? expChisC : chisC;
  };
  const tuffWall = (x: number, yy: number, z: number) => {
    const r = hash3(x, yy, z, s + 14);
    return r < 0.08 ? tuff : r < 0.22 ? polished : bricks;
  };

  for (const r of L.rooms) {
    const tall = r.type === 'atrium' || r.type === 'ominous' || r.template === 'chamber_eruption' || r.template === 'chamber_gallery';
    const H = tall ? 12 : 7;
    // 1. Base shell, floor trim, copper bands, chiseled friezes, copper grate skylights & bulbs.
    for (let dz = -5; dz <= 5; dz++) for (let dx = -5; dx <= 5; dx++) {
      const x = r.x + dx, z = r.z + dz, ax = Math.abs(dx), az = Math.abs(dz), wall = ax === 5 || az === 5;
      put(x, y - 2, z, tuff, true);
      put(x, y - 1, z, wall ? bricks : ax === 4 || az === 4 ? polished : ax <= 1 && az <= 1 ? (ax + az === 0 ? chisCopper(x, y - 1, z) : cutFloor(x, y - 1, z)) : (ax + az) % 3 === 0 ? cutFloor(x, y - 1, z) : bricks, true);
      for (let dy = 0; dy < H; dy++) {
        let b = 0;
        if (wall) {
          if (dy === 2 || (tall && dy === 5)) b = ((dx + dz) & 3) === 0 ? chisTB : copperWall(x, y + dy, z);
          else if (dy === H - 1) b = chisT;
          else if (dy === 0) b = polished;
          else b = tuffWall(x, y + dy, z);
        } else if (ax === 4 && az === 4) {
          b = dy % 3 === 2 ? chisT : polished;
        }
        put(x, y + dy, z, b, true);
      }
      // Ceiling with copper bulbs, grates and cut copper beams
      put(x, y + H, z, (ax === 2 && az === 2) || (ax === 0 && az === 3) || (ax === 3 && az === 0) ? bulb : wall ? bricks : (ax === 3 && az <= 2) || (az === 3 && ax <= 2) ? grate : (ax + az) % 2 === 0 ? cutFloor(x, y + H, z) : polished, true);
    }

    // 2. Template-specific interior geometry (keeps doorway aisles dx=0 / dz=0 clear at y..y+2)
    const R = (lx: number, ly: number, lz: number, b: number) => {
      const [wx, wz] = r.rot === 0 ? [r.x + lx, r.z + lz] : r.rot === 1 ? [r.x - lz, r.z + lx] : r.rot === 2 ? [r.x - lx, r.z - lz] : [r.x + lz, r.z - lx];
      put(wx, y + ly, wz, b, true);
    };
    switch (r.template) {
      case 'atrium_grand':
        // Grand two-storey atrium (corridor/atrium_1): grand staircase down to central fountain, copper grate mezzanine, wall reliefs
        for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
          R(sx * 3, 0, sz * 3, chisT); R(sx * 3, 1, sz * 3, grate); R(sx * 3, 2, sz * 3, bulb);
          for (let lx = 2; lx <= 4; lx++) for (let lz = 2; lz <= 4; lz++) R(sx * lx, 3, sz * lz, lx === 2 || lz === 2 ? cut : grate);
          // Central fountain rim around the vault
          R(sx * 1, 0, sz * 1, chisTB); R(sx * 1, -1, 0, water); R(0, -1, sz * 1, water);
        }
        // Grand stepped descent along the west balcony
        for (let step = 0; step < 3; step++) {
          for (let lz = -1; lz <= 1; lz++) R(-4 + step, 2 - step, lz, step === 0 ? cut : bricks);
        }
        // Wall mob/spiral reliefs on opposing upper walls (dy=4..6)
        for (const sz of [-5, 5]) {
          R(-1, 5, sz, chisTB); R(0, 5, sz, oxChisC); R(1, 5, sz, chisTB);
          R(0, 4, sz, grate); R(0, 6, sz, grate);
        }
        R(-4, 5, 0, chain); R(-4, 4, 0, bulb); R(4, 5, 0, chain); R(4, 4, 0, bulb);
        R(-3, 4, -3, waxedCop); R(3, 4, 3, waxedCut); R(-2, 4, -3, oxBulb);
        R(-4, 0, -2, copDoor); R(-4, 1, -2, cell('copper_door', 4, 'oak_door'));
        R(2, 3, 2, copTrap);
        break;
      case 'chamber_assembly':
        // Elevated side catwalks with ladders and copper grate platforms
        for (const sx of [-1, 1]) {
          for (let lz = -3; lz <= 3; lz++) if (Math.abs(lz) >= 2) { R(sx * 3, 2, lz, grate); R(sx * 4, 2, lz, cut); }
          R(sx * 3, 0, -3, polished); R(sx * 3, 1, -3, polished);
        }
        break;
      case 'chamber_eruption':
        // Central water geyser basin + magma ring + upper ranged gallery at dy=3
        for (const [lx, lz] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) { R(lx, -1, lz, magma); R(lx, 0, lz, water); R(lx, 1, lz, grate); }
        for (let lx = -3; lx <= 3; lx++) for (let lz = -4; lz <= -2; lz++) R(lx, 3, lz, lz === -2 ? grate : polished);
        break;
      case 'chamber_fanned':
        // Diagonal copper-grate blast shields around the central spawner
        for (const [lx, lz] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) {
          R(lx, 0, lz, cut); R(lx, 1, lz, grate); R(lx, 2, lz, chisC);
        }
        break;
      case 'chamber_pedestal':
        // Stepped tuff-brick pedestal in the center with corner copper columns
        for (let lx = -1; lx <= 1; lx++) for (let lz = -1; lz <= 1; lz++) if (lx || lz) R(lx, -1, lz, chisTB);
        for (const [lx, lz] of [[-3, -2], [3, -2], [-3, 2], [3, 2]]) { R(lx, 0, lz, ox); R(lx, 1, lz, weaCop); R(lx, 2, lz, bulb); }
        break;
      case 'chamber_slanted':
        // Stepped cover platforms on opposing corners
        for (const sgn of [-1, 1]) {
          R(sgn * 3, 0, sgn * 2, bricks); R(sgn * 3, 0, sgn * 3, bricks); R(sgn * 3, 1, sgn * 3, cut);
          R(-sgn * 2, 0, sgn * 3, grate); R(-sgn * 2, 1, sgn * 3, grate);
        }
        break;
      case 'chamber_stepped':
        // Terraced combat tiers along the diagonal corners
        for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
          R(sx * 4, 0, sz * 3, polished); R(sx * 3, 0, sz * 4, polished);
          R(sx * 4, 1, sz * 3, cut); R(sx * 3, 1, sz * 4, cut);
        }
        break;
      case 'chamber_gallery':
        // Two-level gallery with perimetercopper-grate catwalk at dy=3
        for (let k = -4; k <= 4; k++) for (const side of [-4, 4]) {
          if (Math.abs(k) >= 2) { R(k, 3, side, grate); R(side, 3, k, grate); }
        }
        for (let lz = -4; lz <= -2; lz++) for (let lx = -2; lx <= 2; lx++) R(lx, 3, lz, grate);
        break;
      case 'vault_sanctum':
      case 'vault_treasury':
        // Ceremonial chiseled tuff & copper shrine around the vault
        for (const [lx, lz] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) {
          R(lx, 0, lz, chisTB); R(lx, 1, lz, grate); R(lx, 2, lz, chisC); R(lx, 3, lz, bulb);
        }
        if (r.template === 'vault_treasury') {
          for (const sx of [-3, 3]) { R(sx, 0, -4, chisT); R(sx, 1, -4, bulb); }
        }
        break;
      case 'supply_cache':
      case 'supply_barracks':
        // Rest/supply room: respawn beds (like vanilla entrance/intersect bedrooms), crafting table, barrels
        bed(put, r.x + 2, y, r.z - 4, 0);
        if (r.template === 'supply_barracks') bed(put, r.x + 3, y, r.z - 4, 0);
        put(r.x - 4, y, r.z, id('crafting_table'), true);
        put(r.x - 4, y, r.z + 1, id('cauldron', 'tuff_bricks'), true);
        break;
      case 'ominous_arena':
        // Multi-tiered ominous boss arena: raised central dais, upper breeze platform at dy=3, soul/copper lanterns
        for (let lx = -1; lx <= 1; lx++) for (let lz = -1; lz <= 1; lz++) R(lx, 0, lz, lx === 0 && lz === 0 ? chisC : oxCut);
        for (let lx = -2; lx <= 2; lx++) for (let lz = -4; lz <= -2; lz++) R(lx, 3, lz, grate);
        for (const [lx, lz] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) { R(lx, 0, lz, ox); R(lx, 1, lz, grate); R(lx, 2, lz, bulb); }
        break;
    }
  }

  // 3. Corridors & Intersections (multi-template styles: columns, alcoves, grated, bridged)
  for (const r of L.rooms) for (let d = 0; d < 4; d++) {
    if (!(r.links & (1 << d))) continue;
    const [ux, uz] = DIRS[d];
    // 3x3 doorway arch with chiseled tuff header
    for (let w = -1; w <= 1; w++) {
      for (let dy = 0; dy <= 2; dy++) put(r.x + ux * 5 + (uz ? w : 0), y + dy, r.z + uz * 5 + (ux ? w : 0), 0, true);
      put(r.x + ux * 5 + (uz ? w : 0), y + 3, r.z + uz * 5 + (ux ? w : 0), chisTB, true);
    }
    if (d !== 1 && d !== 2) continue;
    const style = r.corridorStyle;
    for (let i = 6; i <= 10; i++) for (let w = -2; w <= 2; w++) for (let dy = -2; dy <= 4; dy++) {
      const x = r.x + ux * i + (uz ? w : 0), z = r.z + uz * i + (ux ? w : 0), side = Math.abs(w) === 2;
      let b = 0;
      if (dy === -2) b = tuff;
      else if (dy === -1) {
        b = side ? bricks : style === 'grated' && Math.abs(w) <= 1 && i === 8 ? grate : w === 0 ? cutFloor(x, y - 1, z) : polished;
      } else if (dy === 4) {
        b = (w === 0 && (i === 7 || i === 9)) ? bulb : side ? bricks : w === 0 ? grate : polished;
      } else if (side) {
        if (style === 'alcoves' && i === 8 && dy <= 1) b = dy === 0 ? id('decorated_pot', 'tuff_bricks') : 0;
        else if (style === 'columns' && (i === 7 || i === 9)) b = dy === 1 ? chisCopper(x, y + dy, z) : polished;
        else b = dy === 1 ? copperWall(x, y + dy, z) : dy === 3 ? chisT : tuffWall(x, y + dy, z);
      } else if (style === 'bridged' && dy === 3 && Math.abs(w) === 1) {
        b = grate;
      }
      put(x, y + dy, z, b, true);
    }
  }

  // 4. Functional block entities: Trial Spawners, Vaults, Ominous Vaults, Dispensers, Barrels, Chests & Pots
  const spawner = id('trial_spawner', 'spawner'), vault = id('vault', 'chest'), oVault = id('ominous_vault', 'chest'), chestId = id('chest'), pot = id('decorated_pot', 'air'), disp = id('dispenser', 'tuff_bricks'), barrelId = id('barrel', 'chest');
  const biomeStr = typeof t.biomeAt === 'function' ? t.biomeAt(p.x, p.z, y) : 'plains';
  const coldBiome = /snow|frozen|ice|taiga|peaks/.test(biomeStr), wetBiome = /swamp|mangrove|jungle/.test(biomeStr), dryBiome = /desert|badlands|savanna/.test(biomeStr);
  for (const sp of L.spawners) {
    put(sp.x, sp.y - 1, sp.z, chisC, true);
    put(sp.x, sp.y, sp.z, spawner, true);
    // Vanilla spawner mob-indicator blocks around the spawner base
    const ind =
      sp.kind === 'breeze' ? oxChisC :
      sp.kind === 'ranged' ? (coldBiome ? id('packed_ice', 'tuff') : wetBiome ? id('moss_block', 'tuff') : id('bone_block', 'polished_tuff')) :
      sp.kind === 'small_melee' ? (hash(sp.x, sp.z, s + 99) < 0.5 ? chisT : id('moss_block', 'tuff')) :
      (dryBiome ? id('sandstone', 'tuff') : id('mossy_cobblestone', 'tuff'));
    for (const [ox, oz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) put(sp.x + ox, sp.y - 1, sp.z + oz, ind, true);
    if (sp.kind === 'small_melee') put(sp.x + 1, sp.y, sp.z + 1, id('cobweb', 'air'), false);
  }
  for (const v of L.vaults) { if (v.ominous) put(v.x, v.y - 1, v.z, chisC, true); put(v.x, v.y, v.z, v.ominous ? oVault : vault, true); put(v.x, v.y + 1, v.z, 0, true); }
  for (const [x, cy, z] of L.chests) { put(x, cy, z, chestId, true); tag(t, x, cy, z, 'trial_chambers_supply'); }
  for (const [x, cy, z] of L.barrels) { put(x, cy, z, barrelId, true); tag(t, x, cy, z, 'trial_chambers_corridor'); }
  for (const [x, cy, z] of L.dispensers) { put(x, cy, z, cell('dispenser', rsFacing(2), 'tuff_bricks'), true); tag(t, x, cy, z, 'trial_chambers_dispenser'); }
  for (const [x, cy, z] of L.pots) put(x, cy, z, pot, true);
}

// =========================================================================================================================
// 2. Ruined Portal — 10 Standard Templates (portal_1..10) + 3 Giant Templates (giant_portal_1..3),
//    4 Placement Categories (on_land_surface, partly_buried, under_water, in_nether),
//    and Authentic Vanilla Processor Rules (obsidian -> crying_obsidian, stone_bricks -> mossy/cracked, gold blocks, chains,
//    iron bars, lava & magma netherrack spread).
// =========================================================================================================================
export type RuinedPortalVariant =
  | 'portal_1' | 'portal_2' | 'portal_3' | 'portal_4' | 'portal_5'
  | 'portal_6' | 'portal_7' | 'portal_8' | 'portal_9' | 'portal_10'
  | 'giant_portal_1' | 'giant_portal_2' | 'giant_portal_3';

export const RUINED_PORTAL_VARIANTS: readonly RuinedPortalVariant[] = [
  'portal_1', 'portal_2', 'portal_3', 'portal_4', 'portal_5',
  'portal_6', 'portal_7', 'portal_8', 'portal_9', 'portal_10',
  'giant_portal_1', 'giant_portal_2', 'giant_portal_3',
];

export interface RuinedPortalPlan {
  variant: RuinedPortalVariant;
  giant: boolean;
  rot: number;
  placement: 'surface' | 'partly_buried' | 'underwater' | 'nether';
  chest: [number, number, number];
  goldBlocks: [number, number, number][];
}

export function ruinedPortalPlan(seed: number, x: number, y: number, z: number, dim = 'overworld'): RuinedPortalPlan {
  const s = seed + 7900;
  const h1 = hash(x, z, s), h2 = hash(x, z, s + 7), h3 = hash(x, z, s + 13);
  // Vanilla: 5% chance for giant_portal_1..3, 95% chance for portal_1..10
  const giant = h1 < 0.05;
  const variant: RuinedPortalVariant = giant
    ? (['giant_portal_1', 'giant_portal_2', 'giant_portal_3'] as const)[Math.floor(h2 * 3) % 3]
    : (['portal_1', 'portal_2', 'portal_3', 'portal_4', 'portal_5', 'portal_6', 'portal_7', 'portal_8', 'portal_9', 'portal_10'] as const)[Math.floor(h2 * 10) % 10];
  const rot = Math.floor(h3 * 4) & 3;
  const alongX = (rot & 1) === 0;
  const at = (u: number, w: number): [number, number] => (alongX ? [x + u, z + w] : [x + w, z + u]);
  const placement = dim === 'nether' ? 'nether' : y < SEA - 1 ? 'underwater' : h1 > 0.52 ? 'partly_buried' : 'surface';
  const base = placement === 'partly_buried' ? y - 1 : y;
  const [cx, cz] = at(-3, 1);
  const [gx1, gz1] = at(2, 1), [gx2, gz2] = at(-2, -1);
  const goldBlocks: [number, number, number][] = variant === 'portal_3' ? [] : [[gx1, base, gz1]];
  if (giant || variant === 'portal_2' || variant === 'portal_6' || variant === 'portal_9') goldBlocks.push([gx2, base + (giant ? 5 : 3), gz2]);
  if (variant === 'giant_portal_3') {
    const [gx3, gz3] = at(1, 1), [gx4, gz4] = at(-1, -1), [gx5, gz5] = at(2, -1), [gx6, gz6] = at(-2, 1);
    goldBlocks.push([gx3, base + 5, gz3], [gx4, base + 5, gz4], [gx5, base + 1, gz5], [gx6, base + 1, gz6]);
  }
  return { variant, giant, rot, placement, chest: [cx, base, cz], goldBlocks };
}

export const RUINED_PORTAL_TEMPLATES = [
  'portal_1', 'portal_2', 'portal_3', 'portal_4', 'portal_5',
  'portal_6', 'portal_7', 'portal_8', 'portal_9', 'portal_10',
  'giant_portal_1', 'giant_portal_2', 'giant_portal_3',
] as const;
export type RuinedPortalTemplate = typeof RUINED_PORTAL_TEMPLATES[number];

export interface RuinedPortalInfo {
  template: RuinedPortalTemplate;
  giant: boolean;
  rot: number;
  mirror: boolean;
  yOffset: number;
  baseGoldBlocks: number;
  hasLavaPool: boolean;
  chestPos: [number, number, number];
}

const TEMPLATE_GOLD_COUNT: Record<RuinedPortalTemplate, number> = {
  portal_1: 2,
  portal_2: 2,
  portal_3: 0,
  portal_4: 1,
  portal_5: 3,
  portal_6: 1,
  portal_7: 2,
  portal_8: 3,
  portal_9: 2,
  portal_10: 2,
  giant_portal_1: 2,
  giant_portal_2: 2,
  giant_portal_3: 6,
};

export function ruinedPortalInfo(
  seed: number,
  px: number,
  py: number,
  pz: number,
  isNether = false,
  forceTemplate?: RuinedPortalTemplate,
): RuinedPortalInfo {
  const s = seed + 7900;
  let template: RuinedPortalTemplate;
  if (forceTemplate) {
    template = forceTemplate;
  } else {
    // Vanilla: 95% normal (portal_1..10), 5% giant (giant_portal_1..3)
    const r0 = hash(px, pz, s);
    const isGiant = r0 >= 0.95;
    const idx = isGiant
      ? 10 + (Math.floor(hash(px, pz, s + 4) * 3) % 3)
      : Math.floor(hash(px, pz, s + 5) * 10) % 10;
    template = RUINED_PORTAL_TEMPLATES[idx];
  }
  const giant = template.startsWith('giant_');
  const rot = Math.floor(hash(px, pz, s + 6) * 4) & 3;
  const mirror = hash(px, pz, s + 7) < 0.5;
  const yOffset = template === 'portal_7' && !isNether ? -1 : 0;
  const y = py + yOffset;
  const mapUW = (u: number, w: number): [number, number] => {
    const mu = mirror ? -u : u;
    switch (rot) {
      case 0: return [px + mu, pz + w];
      case 1: return [px - w, pz + mu];
      case 2: return [px - mu, pz - w];
      default: return [px + w, pz - mu];
    }
  };
  const [cx, cz] = giant ? mapUW(-3, 2) : mapUW(-3, 1);
  const hasLavaPool = template !== 'portal_1' && template !== 'portal_6';
  return {
    template,
    giant,
    rot,
    mirror,
    yOffset,
    baseGoldBlocks: TEMPLATE_GOLD_COUNT[template],
    hasLavaPool,
    chestPos: [cx, y, cz],
  };
}

function ruinedPortalByTemplate(t: Terrain, put: Put, p: Placed, forceTemplate?: RuinedPortalTemplate) {
  const s = t.seed + 7900, nether = t.dimension === 'nether';
  const info = ruinedPortalInfo(t.seed, p.x, p.y, p.z, nether, forceTemplate);
  const y = p.y + info.yOffset;
  const obs = id('obsidian'), cry = id('crying_obsidian', 'obsidian'), rack = id('netherrack'), magma = id('magma_block', 'netherrack');
  const lava = id('lava'), gold = id('gold_block'), chest = id('chest');
  const base = nether ? id('polished_blackstone_bricks', 'blackstone') : id('stone_bricks');
  const mossy = nether ? id('blackstone') : id('mossy_stone_bricks', 'stone_bricks');
  const cracked = nether ? id('cracked_polished_blackstone_bricks', 'blackstone') : id('cracked_stone_bricks', 'stone_bricks');
  const chiseled = nether ? id('chiseled_polished_blackstone', 'blackstone') : id('chiseled_stone_bricks', 'stone_bricks');
  const G = nether ? id('gilded_blackstone', 'gold_block') : chiseled;
  const chain = id('chain', 'iron_bars'), bars = nether ? chain : id('iron_bars');
  const slab = nether ? id('blackstone_slab', 'polished_blackstone_bricks') : id('stone_brick_slab', 'stone_bricks');
  const stair = nether ? id('polished_blackstone_brick_stairs', 'polished_blackstone_bricks') : id('stone_brick_stairs', 'stone_bricks');

  const at = (u: number, w: number): [number, number] => {
    const mu = info.mirror ? -u : u;
    switch (info.rot) {
      case 0: return [p.x + mu, p.z + w];
      case 1: return [p.x - w, p.z + mu];
      case 2: return [p.x - mu, p.z - w];
      default: return [p.x + w, p.z - mu];
    }
  };
  const P = (u: number, dy: number, w: number, blk: number) => {
    const [wx, wz] = at(u, w);
    put(wx, y + dy, wz, blk, true);
  };
  const mason = (u: number, dy: number, w: number) => {
    const [wx, wz] = at(u, w), n = hash3(wx, y + dy, wz, s + 3);
    return n < 0.25 ? mossy : n < 0.48 ? cracked : n < 0.56 ? G : base;
  };
  // Vanilla Java processor: each obsidian block has a 15% chance of becoming crying_obsidian
  const obsOrCry = (u: number, dy: number, w: number) => hash3(u, dy, p.x ^ p.z ^ w, s + 2) >= 0.85 ? cry : obs;

  // 1. Downward-tapering netherrack cone/stalactite underneath the portal (with ~7% magma_block)
  for (let depth = 1; depth <= 3; depth++) {
    const maxR = 5.6 - (depth - 1) * 1.4;
    for (let dz = -5; dz <= 5; dz++) for (let dx = -5; dx <= 5; dx++) {
      const d = Math.hypot(dx, dz), x = p.x + dx, z = p.z + dz, n = hash3(x, depth, z, s + 1);
      if (d > maxR || n > 0.88 - d * 0.11) continue;
      if (depth === 1 && info.hasLavaPool && n < 0.14 && d < 3.2 && d > 1.5 && (!nether || info.template === 'portal_7')) {
        put(x, y - 1, z, lava, true);
      } else {
        put(x, y - depth, z, n < 0.07 ? magma : rack, true);
      }
    }
  }

  // 2. Stepped masonry platform
  const uMin = info.giant ? -4 : -3, uMax = info.giant ? 3 : 2, wSpan = info.giant ? 2 : 1;
  for (let u = uMin; u <= uMax; u++) for (let w = -wSpan; w <= wSpan; w++) {
    P(u, -1, w, mason(u, -1, w));
    if (Math.abs(w) === wSpan && Math.abs(u) <= uMax - 1 && hash(u, w, s + 9) < 0.45) {
      P(u, 0, w, slab);
    }
  }

  // 3. Portal frame (standard 4×5, 5×5 for `portal_6`, or giant 6×7)
  const is5x5 = info.template === 'portal_6';
  const fU0 = info.giant ? -3 : -2, fU1 = info.giant ? 2 : is5x5 ? 2 : 1, fH = info.giant ? 6 : 4;
  for (let u = fU0; u <= fU1; u++) for (let v = 0; v <= fH; v++) {
    const edge = u === fU0 || u === fU1 || v === 0 || v === fH;
    const n = hash3(u, v, p.x ^ p.z, s + 2);
    if (!edge) { P(u, v, 0, 0); continue; }
    // `portal_6`: top center block (u === 0, v === fH) is misplaced (shifted to w = 1)
    if (is5x5 && u === 0 && v === fH) {
      P(0, fH, 0, 0);
      P(0, fH, 1, obsOrCry(0, fH, 1));
      continue;
    }
    const missing = v > 0 && (n < 0.12 || (v >= fH - 1 && n < 0.38));
    P(u, v, 0, missing ? 0 : obsOrCry(u, v, 0));
  }
  // Ensure at least 1 crying_obsidian on the frame so every ruined portal exhibits the crying obsidian processor
  P(fU0, 1, 0, cry);

  // 4. Template-specific architectural surrounds & gold/lava placements (`portal_1..10` & `giant_portal_1..3`)
  const goldCoords: [number, number, number][] = [];
  switch (info.template) {
    case 'portal_1':
      // Small incomplete portal with 4 slabs, 2 stairs, 2 chiseled blocks, 2 gold blocks, and NO lava
      P(-2, 0, 1, stair); P(1, 0, 1, stair);
      P(-3, 0, 0, chiseled); P(2, 0, 0, chiseled);
      P(-2, 0, -1, slab); P(1, 0, -1, slab);
      goldCoords.push([-3, 1, 0], [2, 1, 0]);
      break;
    case 'portal_2':
      // Hanging incomplete portal suspended with 2 iron bars / chains over a lava pool, with slabs & 2 gold blocks
      for (let u = -2; u <= 1; u++) for (let w = -2; w <= -1; w++) P(u, -1, w, lava);
      for (const u of [fU0, fU1]) {
        P(u, fH + 1, 0, bars);
        P(u, fH + 2, 0, mason(u, fH + 2, 0));
      }
      goldCoords.push([fU0, fH + 1, -1], [fU1, fH + 1, -1]);
      break;
    case 'portal_3':
      // Small incomplete portal on a masonry platform with 2 lava blocks, 8 stairs, 6 slabs, and NO gold block (0 gold blocks)
      P(-2, -1, -2, lava); P(-1, -1, -2, lava);
      for (const u of [-3, 2]) { P(u, 0, -1, stair); P(u, 0, 0, chiseled); P(u, 0, 1, stair); }
      break;
    case 'portal_4':
      // Small incomplete portal with 3 lava blocks, 8 stairs, 4 slabs, 2 chiseled blocks, and 1 gold block
      P(-2, -1, -2, lava); P(-1, -1, -2, lava); P(0, -1, -2, lava);
      P(-3, 0, 0, chiseled); P(2, 0, 0, chiseled);
      goldCoords.push([2, 1, 0]);
      break;
    case 'portal_5':
      // Small portal where the top of the portal has fallen over onto the ground, with 3 gold blocks and 1 lava block
      for (let w = -3; w <= -1; w++) {
        P(-1, 0, w, obsOrCry(-1, 0, w));
        if (w === -3) P(0, 0, w, obsOrCry(0, 0, w));
        if (w >= -2) P(1, 0, w, obsOrCry(1, 0, w));
      }
      P(0, -1, -2, lava);
      goldCoords.push([-2, 0, -2], [1, 0, -3], [2, 0, 1]);
      break;
    case 'portal_6':
      // 5×5 portal where the top center block is misplaced (shifted to w = 1), 4 slabs, 2 stairs, 1 gold block, no lava
      P(-2, 0, 1, stair); P(2, 0, 1, stair);
      goldCoords.push([2, 0, -1]);
      break;
    case 'portal_7':
      // Incomplete portal submerged/sunken in a lava pool, 3 slabs, 1 stairs, 2 gold blocks
      for (let u = -2; u <= 1; u++) { P(u, -1, -2, lava); P(u, -1, 2, lava); }
      P(2, 0, 1, stair);
      goldCoords.push([-3, 0, 0], [2, 0, 0]);
      break;
    case 'portal_8':
      // Incomplete portal at the top of a 6-stair staircase, where the top has fallen into a lava pool, 3 gold blocks
      for (let u = -1; u <= 0; u++) for (let sStep = 1; sStep <= 3; sStep++) P(u, -sStep + 1, 1 + sStep, stair);
      for (let u = -2; u <= 1; u++) P(u, -1, -2, lava);
      P(-1, 0, -2, obsOrCry(-1, 0, -2)); P(0, 0, -2, obsOrCry(0, 0, -2));
      P(-3, 0, 0, chiseled); P(2, 0, 0, chiseled);
      goldCoords.push([-3, 1, 0], [2, 1, 0], [0, 0, -3]);
      break;
    case 'portal_9':
      // Small incomplete portal surrounded by 11 stairs, 1 magma block, 1 slab, 2 gold blocks
      for (let u = -3; u <= 2; u++) { P(u, 0, 1, stair); if (u < 2) P(u, 0, -1, stair); }
      P(2, 0, -1, magma);
      goldCoords.push([-3, 1, 0], [2, 1, 0]);
      break;
    case 'portal_10':
      // Incomplete portal that has fallen backward into a lava pool, with 3 chains, 3 chiseled blocks, 3 stairs, 2 gold blocks
      for (let u = -2; u <= 1; u++) for (let w = -3; w <= -1; w++) {
        P(u, -1, w, lava);
        if (u === -2 || u === 1 || w === -3) P(u, 0, w, obsOrCry(u, 0, w));
      }
      P(-3, 0, 0, chiseled); P(2, 0, 0, chiseled); P(0, 0, 1, chiseled);
      P(-2, 1, 0, chain); P(-1, 1, 0, chain); P(1, 1, 0, chain);
      goldCoords.push([-3, 1, 0], [2, 1, 0]);
      break;
    case 'giant_portal_1':
    case 'giant_portal_2':
      // Large incomplete portal with 2 gold blocks, iron bars/chains, stairs, slabs, and chiseled blocks
      for (const u of [fU0 - 1, fU1 + 1]) {
        for (let v = 0; v <= fH; v++) P(u, v, 0, v === fH ? chiseled : mason(u, v, 0));
        for (let v = 1; v <= fH - 1; v++) P(u, v, 1, bars);
      }
      for (let u = fU0; u <= fU1; u++) P(u, fH + 1, 0, mason(u, fH + 1, 0));
      goldCoords.push([-1, fH + 1, 0], [0, fH + 1, 0]);
      break;
    case 'giant_portal_3':
      // Large incomplete portal with 6 gold blocks (the most gold blocks of any template) and separate fallen obsidian
      for (const u of [fU0 - 1, fU1 + 1]) {
        for (let v = 0; v <= fH; v++) P(u, v, 0, v === fH ? chiseled : mason(u, v, 0));
      }
      P(-2, 0, -2, obsOrCry(-2, 0, -2)); P(-1, 0, -2, obsOrCry(-1, 0, -2)); P(1, 0, -2, obsOrCry(1, 0, -2));
      goldCoords.push(
        [-2, fH + 1, 0], [-1, fH + 1, 0], [0, fH + 1, 0], [1, fH + 1, 0],
        [fU0 - 1, fH + 1, 0], [fU1 + 1, fH + 1, 0],
      );
      break;
  }

  // Place template gold blocks (`portal_3` has 0 gold blocks; all other templates place their canonical gold blocks)
  goldCoords.forEach(([gu, gv, gw], idx) => {
    // Vanilla 30% air processor on secondary gold blocks (keep index 0 so templates with >=1 gold block always retain gold)
    if (idx === 0 || hash3(gu, gv, gw, s + 19) >= 0.30 || forceTemplate !== undefined) {
      P(gu, gv, gw, gold);
    }
  });

  // Tagged loot chest
  const [cx, cy, cz] = info.chestPos;
  put(cx, cy, cz, chest, true);
  tag(t, cx, cy, cz, 'ruined_portal');
}


export function ruinedPortal(t: Terrain, put: Put, p: Placed, forceTemplate?: RuinedPortalTemplate) {
  if (forceTemplate !== undefined) { ruinedPortalByTemplate(t, put, p, forceTemplate); return; }

  const plan = ruinedPortalPlan(t.seed, p.x, p.y, p.z, t.dimension);
  const s = t.seed + 7900, nether = t.dimension === 'nether', underwater = plan.placement === 'underwater';
  const y = plan.placement === 'partly_buried' ? p.y - 1 : p.y;
  const obs = id('obsidian'), cry = id('crying_obsidian', 'obsidian'), rack = id('netherrack'), magma = id('magma_block', 'netherrack'), lava = id('lava'), water = id('water'), gold = id('gold_block');
  const chain = id('chain', 'iron_bars'), bars = id('iron_bars');
  const base = nether ? id('polished_blackstone_bricks', 'blackstone') : id('stone_bricks');
  const mossy = nether ? id('blackstone') : id('mossy_stone_bricks', 'stone_bricks');
  const cracked = nether ? id('gilded_blackstone', 'blackstone') : id('cracked_stone_bricks', 'stone_bricks');
  const chis = nether ? id('chiseled_polished_blackstone', 'polished_blackstone_bricks') : id('chiseled_stone_bricks', 'stone_bricks');
  const stairName = nether ? 'blackstone_stairs' : 'stone_brick_stairs';
  const slabName = nether ? 'blackstone_slab' : 'stone_brick_slab';
  const wallName = nether ? 'blackstone_wall' : 'stone_brick_wall';

  const alongX = (plan.rot & 1) === 0;
  const at = (u: number, w: number): [number, number] => (alongX ? [p.x + u, p.z + w] : [p.x + w, p.z + u]);
  const biomeStr = typeof t.biomeAt === 'function' ? t.biomeAt(p.x, p.z, p.y - 1) : 'plains';
  const cold = /snow|frozen|ice|taiga|peaks/.test(biomeStr);
  const desert = /desert|badlands/.test(biomeStr);
  const jungle = /jungle/.test(biomeStr);
  const swamp = /swamp|mangrove/.test(biomeStr);
  const mossiness = nether || desert ? 0 : (jungle || underwater) ? 0.8 : swamp ? 0.5 : cold ? 0.1 : 0.2;
  const fallbackStone = nether ? 'blackstone' : 'stone_bricks';
  const stoneBrickProc = (x: number, yy: number, z: number) => {
    const r = hash3(x, yy, z, s + 3);
    if (r < 0.5 * mossiness) return mossy;
    if (r < 0.5 * mossiness + 0.5 * (1 - mossiness)) return cracked;
    return r < 0.92 ? base : chis;
  };
  // Vanilla Java Edition: 15% obsidian -> crying_obsidian
  const obsProc = (u: number, v: number) => (hash3(u + p.x, v + y, p.z, s + 2) < 0.15 ? cry : obs);

  // 1. Netherrack & magma spread processor (portal_1 has NO lava; cold biomes convert lava->netherrack & 0% magma)
  const spreadR = plan.giant ? 6 : 5;
  const noLava = plan.variant === 'portal_1';
  for (let dz = -spreadR; dz <= spreadR; dz++) for (let dx = -spreadR; dx <= spreadR; dx++) {
    const d = Math.hypot(dx, dz), x = p.x + dx, z = p.z + dz, n = hash(x, z, s + 1);
    if (d > spreadR + 0.3 || n > 0.88 - d * 0.10) continue;
    const surfY = Math.min(y - 1, t.height(x, z));
    for (let yy = surfY; yy <= y - 1; yy++) {
      let blk = rack;
      if (!noLava && !cold) {
        const isLava = (plan.variant === 'portal_7' || plan.variant === 'portal_10' ? n < 0.32 : n < 0.22) && d < 3.2 && d > 1.4;
        if (isLava) blk = (underwater || hash3(x, yy, z, s + 17) < 0.2) ? magma : lava;
        else if (hash3(x, yy, z, s + 18) < 0.07) blk = magma;
      }
      put(x, yy, z, blk, true);
    }
  }

  // 2. Stepped masonry platform, stairs, slabs and decorative walls
  const uMin = plan.giant ? -4 : -3, uMax = plan.giant ? 3 : 2, wSpan = plan.giant ? 2 : 1;
  for (let u = uMin; u <= uMax; u++) for (let w = -wSpan; w <= wSpan; w++) {
    const [x, z] = at(u, w), edge = u === uMin || u === uMax || Math.abs(w) === wSpan;
    for (let yy = Math.min(t.height(x, z), y - 2); yy < y - 1; yy++) put(x, yy, z, stoneBrickProc(x, yy, z), true);
    put(x, y - 1, z, edge && hash(x, z, s + 4) < 0.35 ? cell(slabName, 0, fallbackStone) : stoneBrickProc(x, y - 1, z), true);
  }
  // Approach steps (portal_8 & portal_9 feature prominent staircases)
  const stepSpan = plan.variant === 'portal_8' || plan.variant === 'portal_9' ? 2 : 1;
  for (const wSide of [-wSpan - 1, wSpan + 1]) for (let u = -stepSpan; u <= 0; u++) {
    const [x, z] = at(u, wSide);
    put(x, y - 1, z, cell(stairName, stairsUp(alongX ? (wSide < 0 ? 2 : 0) : (wSide < 0 ? 1 : 3)), fallbackStone), true);
  }

  // 3. Portal frame + 13 template-specific shapes
  const fMinU = plan.giant ? -3 : -2, fMaxU = plan.giant ? 2 : 1, fMaxV = plan.giant ? 6 : 4;
  for (let u = fMinU; u <= fMaxU; u++) for (let v = 0; v <= fMaxV; v++) {
    const [x, z] = at(u, 0), edge = u === fMinU || u === fMaxU || v === 0 || v === fMaxV;
    if (!edge) { put(x, y + v, z, underwater ? water : 0, true); continue; }
    const n = hash3(u, v, p.x ^ p.z, s + 2);
    const missing = v > 0 && (
      (plan.variant === 'portal_3' && u === fMaxU && v >= 2) ||
      (plan.variant === 'portal_4' && v === fMaxV && u >= 0) ||
      (plan.variant === 'portal_5' && v === fMaxV) ||
      (plan.variant === 'portal_6' && v === fMaxV && u === 0) ||
      (plan.variant === 'portal_7' && u === fMinU && v >= 3) ||
      (plan.variant === 'portal_8' && v >= fMaxV - 1 && u >= 0) ||
      (plan.variant === 'portal_10' && v >= fMaxV - 2) ||
      (n < 0.10 || (v >= fMaxV - 1 && n < 0.30))
    );
    put(x, y + v, z, missing ? (underwater ? water : 0) : obsProc(u, v), true);
  }

  // Variant architectural details
  if (plan.giant || plan.variant === 'portal_1' || plan.variant === 'portal_2' || plan.variant === 'portal_5' || plan.variant === 'portal_8') {
    for (const u of [fMinU - 1, fMaxU + 1]) {
      const [x, z] = at(u, 0);
      for (let v = 0; v <= fMaxV - 1; v++) put(x, y + v, z, v === fMaxV - 1 ? chis : v % 2 === 1 ? cell(wallName, 0, fallbackStone) : stoneBrickProc(x, y + v, z), true);
    }
    for (let u = fMinU; u <= fMaxU; u++) {
      const [x, z] = at(u, 0);
      if (hash(x, z, s + 8) < 0.75) put(x, y + fMaxV + 1, z, u === fMinU || u === fMaxU ? chis : cell(slabName, 0, fallbackStone), true);
    }
  }
  if (plan.giant || plan.variant === 'portal_2' || plan.variant === 'portal_6' || plan.variant === 'portal_9' || plan.variant === 'portal_10') {
    const [cx1, cz1] = at(fMinU + 1, 0), [cx2, cz2] = at(fMaxU - 1, 0);
    put(cx1, y + fMaxV - 1, cz1, chain, true);
    // Nether portals use chains instead of iron bars
    put(cx2, y + fMaxV - 1, cz2, nether ? chain : bars, true);
    if (plan.variant === 'portal_10') { const [cx3, cz3] = at(0, 0); put(cx3, y + fMaxV - 1, cz3, chain, true); }
  }
  if (plan.variant === 'portal_5' || plan.variant === 'portal_10' || plan.variant === 'portal_4' || plan.variant === 'portal_7' || plan.giant) {
    // Fallen top / backward-fallen obsidian rubble
    for (const [ru, rw] of [[0, 2], [1, 2], [-1, -2], ...(plan.variant === 'portal_5' || plan.variant === 'portal_10' ? [[-1, 2] as [number, number], [0, 3] as [number, number]] : [])]) {
      const [rx, rz] = at(ru, rw);
      put(rx, y, rz, obsProc(ru, 0), true);
    }
  }
  if (jungle || swamp) {
    for (let u = uMin; u <= uMax; u++) if (hash(u, p.x, s + 23) < 0.4) {
      const [vx, vz] = at(u, wSpan + 1);
      put(vx, y, vz, id('vine', 'air'), false);
    }
  }

  // 4. Gold blocks (30% chance to be removed per block except ensuring giant/non-portal_3 keep at least 1 if present) & Loot Chest
  plan.goldBlocks.forEach(([gx, gy, gz], idx) => {
    if (idx === 0 || hash3(gx, gy, gz, s + 31) >= 0.30) put(gx, gy, gz, gold, true);
  });
  const [cx, cy, cz] = plan.chest;
  put(cx, cy - 1, cz, stoneBrickProc(cx, cy - 1, cz), true);
  chest(put, t, cx, cy, cz, plan.rot, 'ruined_portal');
  if (!underwater) put(cx, cy + 1, cz, 0, true);
}

// =========================================================================================================================
// 3. Ocean Ruins — Warm (Sandstone / Cut / Chiseled / Smooth + Suspicious Sand) and Cold (Stone Bricks / Mossy / Cracked /
//    Chiseled / Obsidian + Suspicious Gravel), Large Ruin Templates (big_warm_ruin / big_cold_ruin) + 1..8 Surrounding
//    Small Ruins (ruin1..8, brick/mossy/cracked) with Drowned/Archaeology integration.
// =========================================================================================================================
export type OceanRuinTemplate = 'big_ruin_1' | 'big_ruin_2' | 'big_ruin_3' | 'big_ruin_4' | 'ruin_1' | 'ruin_2' | 'ruin_3' | 'ruin_4' | 'ruin_5' | 'ruin_6' | 'ruin_7' | 'ruin_8';
export interface OceanRuinPiece {
  template: OceanRuinTemplate;
  large: boolean;
  warm: boolean;
  x: number; y: number; z: number;
  halfX: number; halfZ: number; height: number;
  rot: number;
  chest: [number, number, number] | null;
  suspicious: [number, number, number][];
}
export interface OceanRuinCluster {
  warm: boolean;
  pieces: OceanRuinPiece[];
}

export function oceanRuinCluster(t: Terrain, p: { x: number; y: number; z: number }): OceanRuinCluster {
  const s = t.seed + 8000;
  const biome = typeof t.biomeAt === 'function' ? t.biomeAt(p.x, p.z, p.y - 1) : 'ocean';
  const warm = /warm|lukewarm|desert|beach/.test(biome) || hash(p.x, p.z, s + 9) < 0.35;
  const rnd = mulberry(Math.imul(t.seed | 0, 17) ^ Math.imul(p.x, 73856093) ^ Math.imul(p.z, 19349663));
  const pieces: OceanRuinPiece[] = [];

  // Vanilla: 30% large ruin (with 90% chance of 4..8 small ruins in a cluster), 70% small ruin (with 0..3 companions)
  const bigTemplates: OceanRuinTemplate[] = ['big_ruin_1', 'big_ruin_2', 'big_ruin_3', 'big_ruin_4'];
  const smallTemplates: OceanRuinTemplate[] = ['ruin_1', 'ruin_2', 'ruin_3', 'ruin_4', 'ruin_5', 'ruin_6', 'ruin_7', 'ruin_8'];
  const mainH = Math.min(SEA - 4, p.y);
  const mainLarge = rnd() < 0.30;
  const mainTpl = (mainLarge ? bigTemplates : smallTemplates)[Math.floor(rnd() * (mainLarge ? bigTemplates.length : smallTemplates.length))];
  const mainSus: [number, number, number][] = [
    [p.x - 1, mainH - 1, p.z + 1], [p.x + 1, mainH - 1, p.z - 1], [p.x + 2, mainH - 1, p.z + 1], [p.x + 5, mainH - 1, p.z + 1],
  ];
  pieces.push({
    template: mainTpl, large: mainLarge, warm,
    x: p.x, y: mainH, z: p.z, halfX: mainLarge ? 4 : 2, halfZ: mainLarge ? 4 : 2, height: mainLarge ? 6 : 4,
    rot: Math.floor(rnd() * 4),
    chest: [p.x - 1, mainH, p.z - 1],
    suspicious: mainSus,
  });

  // Cluster satellites: 90% chance of 4..8 small ruins when main is large; 0..3 when main is small
  const offsets: [number, number][] = [[-7, -6], [7, -6], [-7, 7], [7, 7], [0, -8], [0, 8], [-8, 0], [8, 0]];
  const startOff = Math.floor(rnd() * offsets.length);
  const wantSat = mainLarge ? (rnd() < 0.90 ? 4 + Math.floor(rnd() * 5) : 0) : Math.floor(rnd() * 4);
  for (let i = 0; i < offsets.length && pieces.length < 1 + wantSat; i++) {
    const [ox, oz] = offsets[(startOff + i) % offsets.length];
    if (pieces.slice(1).some(q => Math.hypot(q.x - (p.x + ox), q.z - (p.z + oz)) < 5.5)) continue;
    const cx = p.x + ox, cz = p.z + oz, h = Math.min(SEA - 6, t.height(cx, cz));
    const hy = h + 1;
    const hasChest = rnd() < 0.65;
    pieces.push({
      template: smallTemplates[(i + Math.floor(rnd() * 8)) % smallTemplates.length],
      large: false, warm,
      x: cx, y: hy, z: cz, halfX: 2, halfZ: 2, height: 4 + (i & 1),
      rot: Math.floor(rnd() * 4),
      chest: hasChest ? [cx, hy, cz] : null,
      suspicious: [[cx + 1, hy - 1, cz], [cx - 1, hy - 1, cz + 1]],
    });
  }
  return { warm, pieces };
}

export function oceanRuin(t: Terrain, put: Put, p: Placed) {
  const cluster = oceanRuinCluster(t, p), s = t.seed + 8000, warm = cluster.warm;
  const walls = warm
    ? [id('sandstone'), id('cut_sandstone', 'sandstone'), id('chiseled_sandstone', 'sandstone'), id('smooth_sandstone', 'sandstone')]
    : [id('stone_bricks'), id('mossy_stone_bricks', 'stone_bricks'), id('cracked_stone_bricks', 'stone_bricks'), id('chiseled_stone_bricks', 'stone_bricks')];
  const stairName = warm ? 'sandstone_stairs' : 'stone_brick_stairs';
  const slabName = warm ? 'sandstone_slab' : 'stone_brick_slab';
  const wallBlockName = warm ? 'sandstone_wall' : 'stone_brick_wall';
  const floor = warm ? id('sand') : id('gravel');
  const sus = warm ? id('suspicious_sand', 'sand') : id('suspicious_gravel', 'gravel');
  const lantern = id('sea_lantern', 'glowstone'), magma = id('magma_block', 'stone_bricks'), obs = id('obsidian'), prism = id('prismarine_bricks', 'prismarine'), water = id('water');
  const accent = warm ? id('polished_diorite', 'sandstone') : id('polished_granite', 'stone_bricks');
  const warmTerra = id('light_blue_terracotta', 'sandstone'), coldPlank = id('dark_oak_planks', 'spruce_planks');
  const lootTable = warm ? 'ocean_ruin_warm' : 'ocean_ruin_cold';

  for (let idx = 0; idx < cluster.pieces.length; idx++) {
    const pc = cluster.pieces[idx], { x: cx, y: hy, z: cz, halfX, halfZ, height: H } = pc;
    // 1. Foundation, sediment floor & suspicious sand/gravel pockets
    for (let dz = -halfZ; dz <= halfZ; dz++) for (let dx = -halfX; dx <= halfX; dx++) {
      const x = cx + dx, z = cz + dz, edge = Math.abs(dx) === halfX || Math.abs(dz) === halfZ, r = hash(x, z, s + idx);
      for (let yy = Math.min(t.height(x, z), hy - 3); yy < hy - 1; yy++) put(x, yy, z, walls[0], true);
      put(x, hy - 1, z, !edge && r < 0.22 ? sus : r < 0.52 ? floor : r < 0.56 ? magma : walls[Math.floor(r * 97) % walls.length], true);
      // Interior water clearing & internal arches for big ruins
      if (!edge) {
        for (let dy = 0; dy < H - 1; dy++) put(x, hy + dy, z, water, true);
        if (pc.large && (Math.abs(dx) === 2 && Math.abs(dz) === 2)) {
          for (let dy = 0; dy < H - 2; dy++) put(x, hy + dy, z, dy === H - 3 ? walls[2] : prism, true);
        }
      }
    }

    // 2. Ruined walls with window slits, chiseled friezes, stepped cornices & partial roof slabs
    for (let dz = -halfZ; dz <= halfZ; dz++) for (let dx = -halfX; dx <= halfX; dx++) {
      const x = cx + dx, z = cz + dz, ax = Math.abs(dx), az = Math.abs(dz);
      const edge = ax === halfX || az === halfZ, corner = ax === halfX && az === halfZ;
      if (!edge) continue;
      // Arched doorways on 1 or 2 faces
      const isDoor = (dx === 0 && dz === halfZ) || (pc.large && dz === 0 && dx === -halfX);
      if (isDoor) {
        put(x, hy + H - 2, z, cell(stairName, stairsUp(0, true), 'stone_bricks'), true);
        continue;
      }
      const wallTop = corner ? H : Math.max(1, Math.floor(hash(x, z, s + 5 + idx) * (H + 1)));
      const integrity = warm ? (pc.large ? 0.9 : 0.8) : (idx % 3 === 0 ? (pc.large ? 0.9 : 0.8) : idx % 3 === 1 ? 0.7 : 0.5);
      for (let dy = 0; dy < wallTop; dy++) {
        if (!corner && dy > 0 && hash3(x, hy + dy, z, s + 41) > integrity) continue;
        const isWindow = !corner && dy === 2 && ((ax === 2 && az === halfZ) || (az === 2 && ax === halfX));
        if (isWindow) { put(x, hy + dy, z, cell(wallBlockName, 0, 'stone_bricks'), true); continue; }
        const hr = hash3(x, hy + dy, z, s + 19);
        const mat = dy === H - 2 ? (warm && hr < 0.35 ? warmTerra : walls[2]) : !warm && corner && dy === 0 && hr < 0.25 ? obs : !warm && hr < 0.12 ? coldPlank : hr < 0.20 ? accent : walls[Math.floor(hash3(x, hy + dy, z, s) * walls.length)];
        put(x, hy + dy, z, mat, true);
      }
      if (corner && wallTop >= H - 1) put(x, hy + wallTop, z, hash(x, z, s + 14) < 0.45 ? lantern : cell(slabName, 0, 'stone_bricks'), true);
    }

    // Partial ruined roof cap on large ruins
    if (pc.large) {
      for (let dz = -halfZ + 1; dz <= halfZ - 1; dz++) for (let dx = -halfX + 1; dx <= halfX - 1; dx++) {
        const x = cx + dx, z = cz + dz;
        if (hash(x, z, s + 31) < 0.55) put(x, hy + H - 1, z, dx === 0 && dz === 0 ? lantern : cell(slabName, 0, 'stone_bricks'), true);
      }
    }

    // 3. Chests & guaranteed suspicious archaeology blocks
    if (pc.chest) {
      const [chx, chy, chz] = pc.chest;
      chest(put, t, chx, chy, chz, pc.rot, lootTable);
    }
    for (const [sx, sy, sz] of pc.suspicious) put(sx, sy, sz, sus, true);
  }
}

// =========================================================================================================================
// 4. Buried Treasure
// =========================================================================================================================
export function buriedTreasure(t: Terrain, put: Put, p: Placed) {
  put(p.x, p.y - 1, p.z, id('sandstone'), true);
  put(p.x, p.y, p.z, id('chest'), true);
  tag(t, p.x, p.y, p.z, 'buried_treasure');
  put(p.x, p.y + 1, p.z, id('sand'), true);
}

// =========================================================================================================================
// 5. Trail Ruins (1.20) — True Jigsaw Multi-Piece Underground Excavation Site:
//    Central sunken tower (tower_1..5 + tower_top poking out of the ground), segmented buried cobblestone/mud-brick road
//    (road_section_1..4), job-site buildings (hall_1..4, Cartographer, Loom/Weaver, Smithy, Stonecutter, Pottery workshop),
//    one_room_1..4, and Decor edificios, completely packed with gravel, dirt, coarse_dirt & suspicious_gravel (trail_common / trail_rare).
// =========================================================================================================================
export type TrailPieceKind = 'tower' | 'road' | 'hall' | 'cartographer' | 'weaver' | 'smithy' | 'mason' | 'one_room' | 'decor';
export interface TrailLayout {
  x: number; y: number; z: number; baseY: number;
  pieces: JigsawPlaced[];
  suspicious: [number, number, number][];
}

const trailCon = (x: number, y: number, z: number, dir: number, name: string, target: string, pool: string): Connector => ({ x, y, z, dir, name, target, pool });
const TRAIL_ROAD_1: PieceDef = {
  id: 'road_section_1', kind: 'road', size: [3, 4, 11],
  connectors: [
    trailCon(1, 0, 0, 0, 'road', 'road', ''),
    trailCon(1, 0, 10, 2, 'road', 'road', 'roads'),
    trailCon(0, 0, 2, 3, 'side', 'entry', 'buildings'),
    trailCon(2, 0, 2, 1, 'side', 'entry', 'buildings'),
    trailCon(0, 0, 5, 3, 'side', 'entry', 'buildings'),
    trailCon(2, 0, 5, 1, 'side', 'entry', 'buildings'),
  ],
};
const TRAIL_ROAD_2: PieceDef = {
  id: 'road_section_2', kind: 'road', size: [3, 4, 5],
  connectors: [
    trailCon(1, 0, 0, 0, 'road', 'road', ''),
    trailCon(1, 0, 4, 2, 'road', 'road', 'roads'),
    trailCon(0, 0, 2, 3, 'side', 'entry', 'buildings'),
    trailCon(2, 0, 2, 1, 'side', 'entry', 'buildings'),
  ],
};
const trailRoomDef = (id: string, kind: TrailPieceKind, w: number, h: number, l: number, max = 2): PieceDef => ({
  id, kind, size: [w, h, l], max,
  connectors: [trailCon(w >> 1, 0, 0, 0, 'entry', 'side', '')],
});
const TRAIL_BUILDINGS: PieceDef[] = [
  trailRoomDef('hall_1', 'hall', 5, 5, 5, 4),
  trailRoomDef('guild_cartographer', 'cartographer', 5, 4, 5, 4),
  trailRoomDef('guild_weaver', 'weaver', 5, 4, 5, 4),
  trailRoomDef('guild_smithy', 'smithy', 5, 4, 5, 4),
  trailRoomDef('guild_mason', 'mason', 5, 4, 5, 4),
  trailRoomDef('one_room_1', 'one_room', 4, 4, 4, 6),
  trailRoomDef('decor_1', 'decor', 3, 3, 3, 6),
];
const TRAIL_POOLS: Record<string, Pool> = {
  roads: { entries: [{ def: TRAIL_ROAD_1, weight: 6 }, { def: TRAIL_ROAD_2, weight: 4 }] },
  buildings: {
    entries: [
      { def: TRAIL_BUILDINGS[0], weight: 5 },
      { def: TRAIL_BUILDINGS[1], weight: 4 },
      { def: TRAIL_BUILDINGS[2], weight: 4 },
      { def: TRAIL_BUILDINGS[3], weight: 4 },
      { def: TRAIL_BUILDINGS[4], weight: 4 },
      { def: TRAIL_BUILDINGS[5], weight: 5 },
      { def: TRAIL_BUILDINGS[6], weight: 3 },
    ],
  },
};

const TRAIL_CACHE = new Map<string, TrailLayout>();
export function trailRuinsLayout(seed: number, px: number, py: number, pz: number): TrailLayout {
  const key = `${seed}:${px},${py},${pz}`, hit = TRAIL_CACHE.get(key);
  if (hit) return hit;
  const baseY = py - 7;
  const towerBox: Box = [px - 2, baseY, pz - 2, px + 2, py + 2, pz + 2];
  const pieces = growJigsaw({
    seed: (Math.imul(seed | 0, 2654435761) ^ Math.imul(px, 73856093) ^ Math.imul(pz, 19349663)) >>> 0,
    pools: TRAIL_POOLS,
    occupied: [towerBox],
    roots: [
      { x: px + 2, y: baseY, z: pz, dir: 1, target: 'road', pool: 'roads' },
      { x: px - 2, y: baseY, z: pz, dir: 3, target: 'road', pool: 'roads' },
      { x: px, y: baseY, z: pz + 2, dir: 2, target: 'road', pool: 'roads' },
      { x: px, y: baseY, z: pz - 2, dir: 0, target: 'road', pool: 'roads' },
    ],
    maxDepth: 8,
    maxPieces: 26,
    bounds: { cx: px, cz: pz, r: 22, y0: baseY - 2, y1: py + 3 },
  });
  const L: TrailLayout = { x: px, y: py, z: pz, baseY, pieces, suspicious: [[px, baseY, pz], [px + 1, baseY, pz - 1], [px - 1, baseY + 1, pz + 1]] };
  if (TRAIL_CACHE.size > 32) TRAIL_CACHE.clear();
  TRAIL_CACHE.set(key, L);
  return L;
}

export function trailRuins(t: Terrain, put: Put, p: Placed) {
  const L = trailRuinsLayout(t.seed, p.x, p.y, p.z);
  const s = t.seed + 8100, top = p.y, base = L.baseY;
  const terr = ['white_terracotta', 'light_blue_terracotta', 'yellow_terracotta', 'orange_terracotta', 'red_terracotta', 'brown_terracotta', 'cyan_terracotta', 'magenta_terracotta', 'purple_terracotta', 'blue_terracotta', 'cyan_concrete', 'red_concrete'].map(n => id(n, 'terracotta'));
  const mud = id('mud_bricks', 'bricks'), packed = id('packed_mud', 'dirt'), bricks = id('bricks', 'mud_bricks');
  const cobble = id('cobblestone'), mossy = id('mossy_cobblestone', 'cobblestone'), gravel = id('gravel'), coarse = id('coarse_dirt', 'dirt'), dirt = id('dirt'), sus = id('suspicious_gravel', 'gravel'), planks = id('spruce_planks', 'oak_planks');

  // Archaeological fill processor (gravel, dirt, coarse dirt, and suspicious_gravel)
  const fillAt = (x: number, yy: number, z: number) => {
    const r = hash3(x, yy, z, s + 4), deep = yy <= base + 2;
    return r < (deep ? 0.14 : 0.07) ? sus : r < 0.52 ? gravel : r < 0.78 ? dirt : coarse;
  };
  const masonry = (x: number, yy: number, z: number, color: number) => {
    const r = hash3(x, yy, z, s + 2);
    return dyLvl(yy) === 0 ? (r < 0.45 ? mossy : cobble) : r < 0.35 ? mud : r < 0.50 ? packed : r < 0.62 ? bricks : color;
  };
  const dyLvl = (yy: number) => yy - base;

  // 1. Central Tower (tower_1..5 + tower_top poking 1-2 blocks above surface with terracotta mosaic & workstations)
  const towerCol = terr[Math.floor(hash(p.x, p.z, s) * terr.length)];
  const towerCol2 = terr[(Math.floor(hash(p.x, p.z, s) * terr.length) + 3) % terr.length];
  for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
    const x = p.x + dx, z = p.z + dz, edge = Math.abs(dx) === 2 || Math.abs(dz) === 2, corner = Math.abs(dx) === 2 && Math.abs(dz) === 2;
    put(x, base - 1, z, (dx + dz) % 2 === 0 ? towerCol : mud, true);
    for (let dy = 0; dy < 9; dy++) {
      const yy = base + dy, r = hash3(x, yy, z, s + 2);
      if (yy > top + 1) break;
      if (edge) {
        // Doorways on all 4 cardinal sides at dy=0..1
        if ((dx === 0 || dz === 0) && dy <= 1) put(x, yy, z, fillAt(x, yy, z), true);
        else put(x, yy, z, dy >= 7 ? (corner ? cobble : r < 0.4 ? mud : towerCol2) : masonry(x, yy, z, (dy & 1) ? towerCol : towerCol2), true);
      } else if (yy <= top) {
        put(x, yy, z, dy === 4 && r < 0.5 ? planks : fillAt(x, yy, z), true);
      }
    }
  }
  // Guaranteed suspicious gravel in tower base
  for (const [sx, sy, sz] of L.suspicious) put(sx, sy, sz, sus, true);

  // 2. Jigsaw Pieces: Buried Roads, Guild Buildings (Cartographer, Weaver, Smithy, Mason), Halls & Decor
  L.pieces.forEach((pc, idx) => {
    const [w, h, l] = pc.def.size, kind = pc.def.kind as TrailPieceKind;
    const colA = terr[(idx * 3 + Math.floor(hash(p.x, p.z, s + 8) * 7)) % terr.length];
    const colB = terr[(idx * 5 + 2) % terr.length];
    for (let lz = 0; lz < l; lz++) for (let lx = 0; lx < w; lx++) {
      const [x, by, z] = toWorld(pc, lx, 0, lz);
      if (kind === 'road') {
        const side = lx === 0 || lx === w - 1;
        put(x, by - 1, z, side ? (lz % 2 === 0 ? mud : cobble) : hash(x, z, s + 3) < 0.55 ? gravel : packed, true);
        put(x, by, z, fillAt(x, by, z), true);
        put(x, by + 1, z, fillAt(x, by + 1, z), true);
        continue;
      }
      const edge = lx === 0 || lx === w - 1 || lz === 0 || lz === l - 1;
      const isDoor = lz === 0 && lx === (w >> 1);
      // Terracotta geometric floor mosaic
      put(x, by - 1, z, ((lx + lz) & 1) === 0 ? colA : mud, true);
      for (let ly = 0; ly < h; ly++) {
        const yy = by + ly;
        if (yy > top) break;
        if (edge && !(isDoor && ly <= 1)) {
          put(x, yy, z, ly === h - 1 ? mud : masonry(x, yy, z, ((lx + ly + lz) & 1) ? colA : colB), true);
        } else {
          put(x, yy, z, ly === h - 1 && hash(x, z, s + 19) < 0.45 ? planks : fillAt(x, yy, z), true);
        }
      }
    }
    // Guild workstation & archaeological relics inside each room
    if (kind !== 'road') {
      const [wx, wy, wz] = toWorld(pc, w >> 1, 0, l - 2);
      const station =
        kind === 'cartographer' ? id('cartography_table', 'crafting_table') :
        kind === 'weaver' ? id('loom', 'crafting_table') :
        kind === 'smithy' ? id('smithing_table', 'blast_furnace') :
        kind === 'mason' ? id('stonecutter', 'bricks') :
        kind === 'hall' ? id('decorated_pot', 'mud_bricks') :
        kind === 'one_room' ? id('grindstone', 'cobblestone') : id('campfire', 'packed_mud');
      put(wx, wy, wz, station, true);
      if (kind === 'smithy') { const [fx, fy, fz] = toWorld(pc, 1, 0, l - 2); put(fx, fy, fz, id('blast_furnace', 'furnace'), true); }
      if (kind === 'decor') { const [kx, ky, kz] = toWorld(pc, 1, 0, l - 2); put(kx, ky, kz, id('coal_block', 'bricks'), true); }
      if (kind === 'hall') { const [cx, cy, cz] = toWorld(pc, 1, 0, l - 2); put(cx, cy, cz, id('cauldron', 'cobblestone'), true); }
      const [sx, sy, sz] = toWorld(pc, 1, 0, 1);
      put(sx, sy, sz, sus, true);
    }
  });
}

// =========================================================================================================================
// 6. Bee trees
// =========================================================================================================================
/** A lone oak with a bee nest on its trunk and a few flowers at its foot, in roughly one out of 30 flowery chunks. */
export function placeBeeNests(t: Terrain, put: Put, ox: number, oz: number) {
  if (t.dimension !== 'overworld' || B.bee_nest === undefined) return;
  const cx = Math.floor(ox / 16), cz = Math.floor(oz / 16);
  if (hash(cx, cz, t.seed + 8200) > 0.035) return;
  const x = cx * 16 + 4 + Math.floor(hash(cx, cz, t.seed + 8201) * 8), z = cz * 16 + 4 + Math.floor(hash(cx, cz, t.seed + 8202) * 8), h = t.height(x, z);
  if (h < SEA + 1 || h > 125) return;
  const biome = t.biomeAt(x, z, h);
  if (!/plains|meadow|flower|forest|cherry/.test(biome) || /dark|taiga|snowy|pale|wooded_badlands/.test(biome)) return;
  const log = id('oak_log'), leaves = id('oak_leaves'), flowers = [id('poppy'), id('dandelion'), id('cornflower', 'poppy'), id('oxeye_daisy', 'dandelion')];
  for (let dy = 3; dy <= 6; dy++) {
    const r = dy >= 6 ? 1 : 2;
    for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) if (Math.abs(dx) + Math.abs(dz) < r * 2 || dy === 4) put(x + dx, h + dy, z + dz, leaves, false);
  }
  for (let dy = 1; dy <= 5; dy++) put(x, h + dy, z, log, true);
  put(x + 1, h + 3, z, id('bee_nest'), true);
  [[2, 1], [-1, 2], [1, -2], [-2, -1], [2, -2]].forEach(([dx, dz], i) => {
    if (t.height(x + dx, z + dz) === h) put(x + dx, h + 1, z + dz, flowers[i % flowers.length], false);
  });
}
