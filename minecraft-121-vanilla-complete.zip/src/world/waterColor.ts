// Biome water colours — minecraft.wiki "Water" › Color (Java Edition): [surface colour, underwater fog colour].
const C = (w: string, f: string) => [parseInt(w.slice(1), 16), parseInt(f.slice(1), 16)] as const;
const DEFAULT = C('#3f76e4', '#050533');
const TABLE: [RegExp, readonly [number, number]][] = [
  [/^mangrove_swamp$/, C('#3a7a6a', '#4d7a60')],
  [/^swamp$/, C('#617b64', '#232317')],
  [/lukewarm_ocean/, C('#45adf2', '#041633')],
  [/warm_ocean/, C('#43d5ee', '#041f33')],
  [/frozen_river|frozen_ocean/, C('#3938c9', '#050533')],
  [/cold_ocean|snowy_taiga|snowy_beach/, C('#3d57d6', '#050533')],
  [/^meadow$/, C('#0e4ecf', '#050533')],
  [/^cherry_grove$/, C('#5db7ef', '#5db7ef')],
];
const cache = new Map<string, readonly [number, number]>();
function entry(biome: string) {
  let e = cache.get(biome);
  if (!e) { e = TABLE.find(([re]) => re.test(biome))?.[1] ?? DEFAULT; cache.set(biome, e); }
  return e;
}
/** 0xRRGGBB surface colour of water in this biome. */
export const waterColorOf = (biome: string) => entry(biome)[0];
/** 0xRRGGBB underwater fog colour in this biome. */
export const waterFogColorOf = (biome: string) => entry(biome)[1];
export const DEFAULT_WATER_COLOR = DEFAULT[0];
