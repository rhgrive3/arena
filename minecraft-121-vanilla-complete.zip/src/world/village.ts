// Villages (terrain-fitted plains village with church, weaponsmith, terraced farm and meeting-point bell), the stronghold
// (portal room + corridors, prison cells, spiral staircase, two-storey library, store room) and the end ship.
// Every builder is a pure function of the world seed and writes through a chunk-clipping `put`.
import { ID } from '../game/data';
import { makeCell } from '../game/blockState';
import type { Terrain } from './terrain';
import { markLoot, markPreset } from './loot';

type Put = (x: number, y: number, z: number, id: number, replace?: boolean) => void;
const SEA = 62;
const B = ID as Record<string, number | undefined>;
const id = (name: string, fallback = 'stone'): number => B[name] ?? B[fallback] ?? 1;
const cell = (name: string, state: number, fallback = 'stone') => makeCell(id(name, fallback), state);
const hash = (x: number, z: number, seed: number) => {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
const hash3 = (x: number, y: number, z: number, seed: number) => hash(x + y * 131, z - y * 71, seed);
/** Direction index: 0 north (-z), 1 east (+x), 2 south (+z), 3 west (-x). A stair with state d rises towards direction d. */
const DIRS: [number, number][] = [[0, -1], [1, 0], [0, 1], [-1, 0]];
const fill = (put: Put, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, block: number) => {
  for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) put(x, y, z, block, true);
};
const bed = (put: Put, x: number, y: number, z: number, facing: number) => {
  const dx = facing === 3 ? 1 : facing === 1 ? -1 : 0, dz = facing === 0 ? 1 : facing === 2 ? -1 : 0;
  put(x, y, z, cell('bed', facing), true);
  put(x + dx, y, z + dz, cell('bed', facing | 4), true);
};

// =========================================================================================================================
// Village
// =========================================================================================================================
export type VillageBuildingKind = 'house' | 'church' | 'weaponsmith' | 'farm' | 'well';
export interface VillageBuilding { kind: VillageBuildingKind; x0: number; z0: number; x1: number; z1: number; /** First air level above the floor (floor block is at g - 1). */ g: number }
export interface FarmTerrace { x0: number; z0: number; x1: number; z1: number; /** y of the farmland / water / border layer. */ level: number }
export interface VillagePlan {
  cx: number; cz: number;
  buildings: VillageBuilding[];
  terraces: FarmTerrace[];
  bell: [number, number, number];
  composter: [number, number, number];
  /** Axis-aligned path segments [x0, z0, x1, z1]. */
  paths: [number, number, number, number][];
  /** Every paved cell with the level (y of the surface block) it is laid at; 4-neighbours never differ by more than one. */
  pathCells: { x: number; z: number; y: number }[];
}

/** Surface block level; open water counts as its surface so that paths become boardwalks. */
const ground = (t: Terrain, x: number, z: number) => Math.max(t.height(x, z), SEA);
const levelAt = (t: Terrain, x: number, z: number) => ground(t, x, z) + 1;

/**
 * Layout of a plains village centred on (cx, cz): where each building stands and on which level it adapts to the terrain.
 * Path levels are the lowest surface that is never below the ground and never changes by more than one block between
 * neighbouring cells, so every level change can be taken on a single wooden stair.
 */
export function villagePlan(t: Terrain, cx: number, cz: number): VillagePlan {
  const seg = (x0: number, z0: number, x1: number, z1: number): [number, number, number, number] => [cx + x0, cz + z0, cx + x1, cz + z1];
  // Buildings with the cell in front of their door and the branch that links it to the roads.
  const defs: [VillageBuildingKind, number, number, number, number, [number, number, number, number] | null][] = [
    ['well', -1, -1, 3, 3, null],
    ['house', -12, -10, 5, 5, seg(-10, -5, -10, -1)], ['house', 6, -9, 6, 5, seg(9, -4, 9, -1)], ['house', -12, 5, 5, 6, seg(-10, 4, -10, 1)],
    ['church', -4, -24, 7, 11, seg(-1, -13, -1, -13)],
    ['weaponsmith', 13, 4, 9, 7, seg(16, 3, 16, 1)],
  ];
  const paths = [
    seg(0, -13, 0, -2), seg(0, 2, 0, 13), seg(-13, 0, -2, 0), seg(2, 0, 22, 0),                       // four roads
    seg(-2, -2, 2, -2), seg(-2, 2, 2, 2), seg(-2, -2, -2, 2), seg(2, -2, 2, 2),                       // plaza ring around the well
    seg(13, -1, 13, -21),                                                                             // lane along the farm
    ...defs.flatMap(d => (d[5] ? [d[5]] : [])),
  ];
  const cells = new Map<string, { x: number; z: number; y: number }>();
  for (const [x0, z0, x1, z1] of paths) {
    const n = Math.max(Math.abs(x1 - x0), Math.abs(z1 - z0)), sx = Math.sign(x1 - x0), sz = Math.sign(z1 - z0);
    for (let i = 0; i <= n; i++) { const x = x0 + sx * i, z = z0 + sz * i; cells.set(x + ',' + z, { x, z, y: ground(t, x, z) }); }
  }
  const relax = () => {
    for (let changed = true; changed;) {
      changed = false;
      for (const c of cells.values()) for (const [dx, dz] of DIRS) { const n = cells.get((c.x + dx) + ',' + (c.z + dz)); if (n && n.y - 1 > c.y) { c.y = n.y - 1; changed = true; } }
    }
  };
  relax();
  const buildings: VillageBuilding[] = defs.map(([kind, x0, z0, w, d, branch]) => {
    let g = levelAt(t, cx + x0 + (w >> 1), cz + z0 + (d >> 1));
    if (branch) { const front = cells.get(branch[0] + ',' + branch[1])!; g = Math.max(g, front.y + 1); front.y = g - 1; }       // the doorstep is level with the floor
    return { kind, x0: cx + x0, z0: cz + z0, x1: cx + x0 + w - 1, z1: cz + z0 + d - 1, g };
  });
  relax();
  defs.forEach((d, i) => { if (d[5]) buildings[i].g = Math.max(buildings[i].g, cells.get(d[5][0] + ',' + d[5][1])!.y + 1); });
  // Terraced farm: three 9×5 plots that climb the slope one block (or more) at a time.
  const tz = [-23, -18, -13].map(z => cz + z), th = tz.map(z => ground(t, cx + 18, z + 2));
  const order = th[0] <= th[2] ? [0, 1, 2] : [2, 1, 0];
  const levels: number[] = [];
  let prev = -Infinity;
  for (const k of order) { levels[k] = Math.max(th[k], prev + 1); prev = levels[k]; }
  const terraces = tz.map((z0, k) => ({ x0: cx + 14, z0, x1: cx + 22, z1: z0 + 4, level: levels[k] }));
  buildings.push({ kind: 'farm', x0: cx + 14, z0: cz - 23, x1: cx + 22, z1: cz - 9, g: levels[0] + 1 });
  const bx = cx + 3, bz = cz + 3;
  return {
    cx, cz, buildings, terraces, paths, pathCells: [...cells.values()],
    bell: [bx, ground(t, bx, bz) + 1, bz],
    composter: [terraces[0].x0, terraces[0].level + 1, terraces[0].z0],
  };
}

/** Stone footing (retaining wall): fills from `top` down to the natural surface so nothing floats on a slope. */
function footing(t: Terrain, put: Put, x: number, z: number, top: number, block: number) {
  const h = t.height(x, z);
  for (let y = top; y > h && y > top - 20; y--) put(x, y, z, block, true);
}

/**
 * Terrain-following paths: dirt path on the ground, a plank boardwalk on stone footings wherever the path runs above the
 * ground (dips, ponds, the approach to a raised doorway) and an oak stair on every one-block level change.
 */
function drawPaths(t: Terrain, put: Put, plan: VillagePlan) {
  const path = id('dirt_path', 'gravel'), plank = id('oak_planks'), cob = id('cobblestone');
  const at = new Map(plan.pathCells.map(c => [c.x + ',' + c.z, c]));
  for (const c of plan.pathCells) {
    for (let dy = 1; dy <= 3; dy++) put(c.x, c.y + dy, c.z, 0, true);
    if (c.y > t.height(c.x, c.z)) { footing(t, put, c.x, c.z, c.y - 1, cob); put(c.x, c.y, c.z, plank, true); }
    else put(c.x, c.y, c.z, path, true);
    for (let d = 0; d < 4; d++) {                                   // stair rising from a lower neighbour towards this cell
      const n = at.get((c.x - DIRS[d][0]) + ',' + (c.z - DIRS[d][1]));
      if (n && n.y === c.y - 1) { put(c.x, c.y, c.z, cell('oak_stairs', d), true); break; }
    }
  }
}

function house(t: Terrain, put: Put, b: VillageBuilding, doorDir: 0 | 2, seed: number) {
  const { x0, z0, g } = b, w = b.x1 - b.x0 + 1, d = b.z1 - b.z0 + 1;
  const cob = id('cobblestone'), plank = id('oak_planks'), log = id('oak_log'), glass = id('glass_pane', 'glass');
  const doorX = x0 + (w >> 1), doorZ = doorDir === 2 ? z0 + d - 1 : z0;
  for (let dz = 0; dz < d; dz++) for (let dx = 0; dx < w; dx++) {
    const x = x0 + dx, z = z0 + dz, wall = dx === 0 || dx === w - 1 || dz === 0 || dz === d - 1, corner = (dx === 0 || dx === w - 1) && (dz === 0 || dz === d - 1);
    footing(t, put, x, z, g - 2, cob);
    put(x, g - 1, z, cob, true);
    for (let dy = 0; dy < 3; dy++) {
      let blk = wall ? plank : 0;
      if (corner) blk = log;
      else if (wall && dy === 0) blk = cob;
      else if (wall && dy === 1 && (dx === 2 || dz === 2) && !(x === doorX && z === doorZ)) blk = glass;
      put(x, g + dy, z, blk, true);
    }
  }
  put(doorX, g, doorZ, id('oak_door'), true); put(doorX, g + 1, doorZ, 0, true);
  // Gabled oak-stair roof with one block of overhang.
  for (let k = 0; k <= ((w + 1) >> 1); k++) for (let dz = -1; dz <= d; dz++) {
    const xl = x0 - 1 + k, xr = x0 + w - k, y = g + 3 + k;
    if (xl < xr) {
      put(xl, y, z0 + dz, cell('oak_stairs', 1), true); put(xr, y, z0 + dz, cell('oak_stairs', 3), true);
      if (dz === 0 || dz === d - 1) for (let x = xl + 1; x < xr; x++) put(x, y, z0 + dz, plank, true);
    } else if (xl === xr) put(xl, y, z0 + dz, id('oak_slab', 'oak_planks'), true);
  }
  const back = doorDir === 2 ? z0 + 1 : z0 + d - 2;
  bed(put, x0 + 1, g, doorDir === 2 ? z0 + 1 : z0 + d - 3, 0);
  put(x0 + w - 2, g, back, id('crafting_table'), true);
  const chestZ = doorDir === 2 ? z0 + d - 2 : z0 + 1;
  put(x0 + w - 2, g, chestZ, id('chest'), true); markLoot(x0 + w - 2, g, chestZ, 'village_plains_house');
  put(x0 + (w >> 1), g + 2 + ((w + 1) >> 1), z0 + (d >> 1), id('lantern', 'torch'), true);              // hangs under the ridge
  void seed;
}

function church(t: Terrain, put: Put, b: VillageBuilding) {
  const { x0, z0, g } = b, cob = id('cobblestone'), mossy = id('mossy_cobblestone', 'cobblestone'), log = id('oak_log'), glass = id('yellow_stained_glass', 'glass'), plank = id('oak_planks');
  for (let lz = 0; lz <= 10; lz++) for (let lx = 0; lx <= 6; lx++) {
    const x = x0 + lx, z = z0 + lz, wall = lx === 0 || lx === 6 || lz === 0 || lz === 10, corner = (lx === 0 || lx === 6) && (lz === 0 || lz === 10);
    footing(t, put, x, z, g - 2, cob);
    put(x, g - 1, z, cob, true);
    for (let dy = 0; dy <= 4; dy++) {
      let blk = 0;
      if (corner) blk = log;
      else if (wall) blk = (dy === 1 || dy === 2) && ((lz % 2 === 0 && lz >= 2 && lz <= 8) || (lz === 0 && lx === 3)) ? glass : hash3(x, dy, z, 91) < 0.15 ? mossy : cob;
      put(x, g + dy, z, blk, true);
    }
  }
  // Nave roof: cobblestone-stair gable.
  for (let k = 0; k <= 3; k++) for (let lz = -1; lz <= 11; lz++) {
    const y = g + 5 + k, z = z0 + lz;
    if (k < 3) {
      put(x0 + k, y, z, cell('cobblestone_stairs', 1), true); put(x0 + 6 - k, y, z, cell('cobblestone_stairs', 3), true);
      if (lz === 0 || lz === 10) for (let lx = k + 1; lx <= 5 - k; lx++) put(x0 + lx, y, z, cob, true);
    } else put(x0 + 3, y, z, id('cobblestone_slab', 'cobblestone'), true);
  }
  // Bell tower over the north end with a ladder.
  for (let dy = 5; dy <= 10; dy++) for (let lz = 0; lz <= 4; lz++) for (let lx = 1; lx <= 5; lx++) {
    const edge = lx === 1 || lx === 5 || lz === 0 || lz === 4;
    let blk = 0;
    if (dy === 10) blk = cob;
    else if (edge) blk = dy === 8 && (lx === 3 || lz === 2) ? id('glass_pane', 'glass') : cob;
    put(x0 + lx, g + dy, z0 + lz, blk, true);
  }
  for (let lz = 1; lz <= 3; lz++) for (let lx = 2; lx <= 4; lx++) put(x0 + lx, g + 11, z0 + lz, id('cobblestone_slab', 'cobblestone'), true);
  put(x0 + 3, g + 12, z0 + 2, id('torch'), true);
  for (let dy = 0; dy <= 9; dy++) put(x0 + 3, g + dy, z0 + 1, cell('ladder', 0), true);
  // Altar: brewing stand (cleric workstation) on a stone table, aisle carpet, loot chest.
  put(x0 + 3, g, z0 + 3, cob, true); put(x0 + 3, g + 1, z0 + 3, id('brewing_stand'), true);
  put(x0 + 2, g, z0 + 3, cell('cobblestone_stairs', 1), true); put(x0 + 4, g, z0 + 3, cell('cobblestone_stairs', 3), true);
  for (let lz = 4; lz <= 9; lz++) put(x0 + 3, g, z0 + lz, id('yellow_carpet', 'white_carpet'), true);
  put(x0 + 1, g, z0 + 1, id('chest'), true); markLoot(x0 + 1, g, z0 + 1, 'village_temple');
  put(x0 + 1, g + 2, z0 + 9, id('lantern', 'torch'), true); put(x0 + 5, g + 2, z0 + 9, id('lantern', 'torch'), true);
  put(x0 + 1, g, z0 + 9, plank, true); put(x0 + 5, g, z0 + 9, plank, true); put(x0 + 1, g + 1, z0 + 9, id('oak_fence'), true); put(x0 + 5, g + 1, z0 + 9, id('oak_fence'), true);
  put(x0 + 3, g, z0 + 10, id('oak_door'), true); put(x0 + 3, g + 1, z0 + 10, 0, true);
}

function weaponsmith(t: Terrain, put: Put, b: VillageBuilding) {
  const { x0, z0, g } = b, cob = id('cobblestone'), plank = id('oak_planks'), log = id('oak_log'), slab = id('cobblestone_slab', 'cobblestone'), fence = id('oak_fence');
  for (let lz = 0; lz <= 6; lz++) for (let lx = 0; lx <= 8; lx++) {
    const x = x0 + lx, z = z0 + lz;
    footing(t, put, x, z, g - 2, cob);
    put(x, g - 1, z, cob, true);
    for (let dy = 0; dy <= 2; dy++) {
      let blk = 0;
      if (lz >= 1 && lx <= 5) {                                   // enclosed house part
        const wall = lx === 0 || lx === 5 || lz === 1 || lz === 6, corner = (lx === 0 || lx === 5) && (lz === 1 || lz === 6);
        if (corner) blk = log;
        else if (wall) blk = dy === 0 || lx === 5 ? cob : dy === 1 && (lz === 3 || lz === 4 || lx === 1 || lx === 4) ? id('glass_pane', 'glass') : plank;
      } else if (lz >= 1 && (lx === 8 || lz === 6)) blk = cob;      // forge back and side walls
      put(x, g + dy, z, blk, true);
    }
    put(x, g + 3, z, lz === 0 || lx === 0 || lx === 8 || lz === 6 ? slab : cob, true);
  }
  for (const lx of [0, 4, 8]) for (let dy = 0; dy <= 2; dy++) put(x0 + lx, g + dy, z0, fence, true);          // porch posts
  put(x0 + 3, g, z0 + 1, id('oak_door'), true); put(x0 + 3, g + 1, z0 + 1, 0, true);
  // Forge: lava basin behind iron bars, blast furnace, furnace, grindstone and smithing table.
  for (let lz = 3; lz <= 5; lz++) for (let lx = 6; lx <= 7; lx++) put(x0 + lx, g, z0 + lz, cob, true);
  put(x0 + 7, g, z0 + 4, id('lava'), true); put(x0 + 7, g, z0 + 5, id('lava'), true);
  put(x0 + 6, g + 1, z0 + 3, id('iron_bars'), true); put(x0 + 7, g + 1, z0 + 3, id('iron_bars'), true);
  put(x0 + 6, g + 1, z0 + 4, id('iron_bars'), true); put(x0 + 6, g + 1, z0 + 5, id('iron_bars'), true);
  put(x0 + 7, g, z0 + 2, id('blast_furnace', 'furnace'), true);
  put(x0 + 6, g, z0 + 2, id('furnace'), true);
  put(x0 + 7, g, z0 + 1, id('grindstone', 'anvil'), true);
  put(x0 + 1, g, z0 + 5, id('chest'), true); markLoot(x0 + 1, g, z0 + 5, 'village_weaponsmith');
  put(x0 + 4, g, z0 + 5, id('smithing_table', 'crafting_table'), true);
  put(x0 + 2, g + 2, z0 + 3, id('lantern', 'torch'), true);
}

function farm(t: Terrain, put: Put, plan: VillagePlan, seed: number) {
  const log = id('oak_log'), cob = id('cobblestone'), mossy = id('mossy_cobblestone', 'cobblestone'), soil = id('farmland_moist', 'farmland'), water = id('water');
  const crops = ['wheat_crop', 'carrots', 'potatoes', 'beetroots'];
  plan.terraces.forEach(tr => {
    const crop = crops[Math.floor(hash(tr.x0, tr.z0, seed + 5) * crops.length)];
    for (let z = tr.z0; z <= tr.z1; z++) for (let x = tr.x0; x <= tr.x1; x++) {
      const border = x === tr.x0 || x === tr.x1 || z === tr.z0 || z === tr.z1, channel = z === tr.z0 + 2;
      const h = t.height(x, z);
      for (let y = tr.level - 1; y > h && y > tr.level - 20; y--) put(x, y, z, hash3(x, y, z, seed) < 0.3 ? mossy : cob, true);       // retaining wall
      for (let dy = 1; dy <= 4; dy++) put(x, tr.level + dy, z, 0, true);
      put(x, tr.level - 1, z, h >= tr.level - 1 ? id('dirt') : cob, true);
      if (border) put(x, tr.level, z, log, true);
      else if (channel) put(x, tr.level, z, water, true);
      else {
        put(x, tr.level, z, soil, true);
        const stage = crop === 'beetroots' ? Math.floor(hash(x, z, seed + 6) * 4) : Math.floor(hash(x, z, seed + 6) * 8);
        put(x, tr.level + 1, z, cell(crop, stage, 'wheat_crop'), true);
      }
    }
  });
  plan.terraces.forEach((tr, k) => {                                              // wooden step between neighbouring terraces
    const next = plan.terraces[k + 1];
    if (next && next.level !== tr.level) {
      const up = next.level > tr.level;
      put(tr.x1, (up ? tr.level : next.level) + 1, up ? tr.z1 : next.z0, cell('oak_stairs', up ? 2 : 0), true);
    }
  });
  const [cxp, cyp, czp] = plan.composter;
  put(cxp, cyp, czp, id('composter', 'barrel'), true);
}

/** Plains village: meeting point (well + bell), three houses, church, weaponsmith and a terraced farm, all fitted to the terrain. */
export function buildVillage(t: Terrain, put: Put, cx: number, cz: number) {
  const plan = villagePlan(t, cx, cz), seed = t.seed + 4242, cob = id('cobblestone'), mossy = id('mossy_cobblestone', 'cobblestone');
  drawPaths(t, put, plan);
  for (const b of plan.buildings) {
    if (b.kind === 'house') house(t, put, b, b.z0 > cz ? 0 : 2, seed);
    else if (b.kind === 'church') church(t, put, b);
    else if (b.kind === 'weaponsmith') weaponsmith(t, put, b);
    else if (b.kind === 'farm') farm(t, put, plan, seed);
    else {                                                                    // well
      const wy = b.g;
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        footing(t, put, cx + dx, cz + dz, wy - 1, mossy);
        put(cx + dx, wy, cz + dz, dx === 0 && dz === 0 ? id('water') : mossy, true);
        if (Math.abs(dx) === 1 && Math.abs(dz) === 1) { put(cx + dx, wy + 1, cz + dz, id('oak_fence'), true); put(cx + dx, wy + 2, cz + dz, id('oak_fence'), true); }
        else { put(cx + dx, wy + 1, cz + dz, 0, true); put(cx + dx, wy + 2, cz + dz, 0, true); }
        put(cx + dx, wy + 3, cz + dz, id('oak_planks'), true);
      }
    }
  }
  // Meeting-point bell on a stone base, lamp posts along the roads.
  const [bx, by, bz] = plan.bell;
  footing(t, put, bx, bz, by - 1, cob);
  put(bx, by - 1, bz, cob, true); put(bx, by, bz, id('bell', 'gold_block'), true); put(bx, by + 1, bz, 0, true);
  for (const [dx, dz] of [[5, 1], [-5, -1], [1, -8], [-1, 8], [11, 1]]) {
    const ly = ground(t, cx + dx, cz + dz) + 1;
    put(cx + dx, ly, cz + dz, id('oak_fence'), true); put(cx + dx, ly + 1, cz + dz, id('oak_fence'), true); put(cx + dx, ly + 2, cz + dz, id('lantern', 'torch'), true);
  }
}

// =========================================================================================================================
// Stronghold
// =========================================================================================================================
export const STRONGHOLD_FLOOR = 30;
export interface Box { x0: number; y0: number; z0: number; x1: number; y1: number; z1: number }
export interface StrongholdPlan {
  portal: Box; corridor: Box; hub: Box; prison: Box; library: Box; store: Box; stair: Box;
  cells: { door: [number, number, number]; inside: [number, number, number] }[];
  chests: { pos: [number, number, number]; table: string }[];
  /** Centre column of the spiral staircase and the level it climbs to. */
  spiral: { x: number; z: number; top: number };
}
/** Rooms of the stronghold around its portal room at (cx, cz). All boxes include their walls. */
export function strongholdPlan(t: Terrain, cx: number, cz: number): StrongholdPlan {
  const F = STRONGHOLD_FLOOR, bx = (x0: number, y0: number, z0: number, x1: number, y1: number, z1: number): Box => ({ x0: cx + x0, y0: F + y0, z0: cz + z0, x1: cx + x1, y1: F + y1, z1: cz + z1 });
  const top = Math.max(t.height(cx, cz - 36), SEA + 1);
  return {
    portal: bx(-5, 0, -5, 5, 6, 5),
    corridor: bx(-2, 0, -17, 2, 4, -6),
    hub: bx(-5, 0, -28, 5, 7, -18),
    prison: bx(-22, 0, -29, -6, 4, -21),
    library: bx(10, 0, -30, 24, 11, -16),
    store: bx(-9, 0, -15, -3, 5, -9),
    stair: { x0: cx - 2, y0: F, z0: cz - 38, x1: cx + 2, y1: top, z1: cz - 34 },
    cells: [-18, -14, -10].map(x => ({ door: [cx + x, F + 1, cz - 25] as [number, number, number], inside: [cx + x, F + 1, cz - 27] as [number, number, number] })),
    chests: [
      { pos: [cx + 2, F + 1, cz - 12], table: 'stronghold_corridor' },
      { pos: [cx - 8, F + 1, cz - 12], table: 'stronghold_crossing' },
      { pos: [cx + 12, F + 1, cz - 18], table: 'stronghold_library' },
      { pos: [cx + 12, F + 6, cz - 28], table: 'stronghold_library' },
    ],
    spiral: { x: cx, z: cz - 36, top },
  };
}

/**
 * Stronghold: the end-portal room is reached through a maze of stone-brick corridors — a five-way crossing, a prison with
 * iron-barred cells, a store room, a two-storey library and a spiral staircase that climbs to the surface.
 */
export function buildStronghold(t: Terrain, put: Put, cx: number, cz: number) {
  const P = strongholdPlan(t, cx, cz), F = STRONGHOLD_FLOOR, s = t.seed + 3300;
  const sb = id('stone_bricks'), mossy = id('mossy_stone_bricks', 'stone_bricks'), cracked = id('cracked_stone_bricks', 'stone_bricks');
  const bars = id('iron_bars'), shelf = id('bookshelf'), plank = id('oak_planks'), fence = id('oak_fence'), web = id('cobweb', 'air'), torch = id('torch'), chest = id('chest'), slab = id('stone_brick_slab', 'stone_bricks');
  const brick = (x: number, y: number, z: number) => { const r = hash3(x, y, z, s); return r < 0.2 ? mossy : r < 0.35 ? cracked : sb; };
  const room = (b: Box) => {
    for (let y = b.y0; y <= b.y1; y++) for (let z = b.z0; z <= b.z1; z++) for (let x = b.x0; x <= b.x1; x++) {
      const shell = x === b.x0 || x === b.x1 || y === b.y0 || y === b.y1 || z === b.z0 || z === b.z1;
      put(x, y, z, shell ? brick(x, y, z) : 0, true);
    }
  };
  const carve = (x0: number, y0: number, z0: number, x1: number, y1: number, z1: number) => fill(put, cx + x0, F + y0, cz + z0, cx + x1, F + y1, cz + z1, 0);
  const at = (x: number, y: number, z: number, blk: number) => put(cx + x, F + y, cz + z, blk, true);

  // ---- Shells ----------------------------------------------------------------------------------------------------------
  room(P.store); room(P.corridor); room(P.hub); room(P.prison);
  room({ x0: cx + 6, y0: F, z0: cz - 25, x1: cx + 9, y1: F + 4, z1: cz - 21 });           // passage hub → library
  room(P.library);
  room({ x0: cx - 2, y0: F, z0: cz - 33, x1: cx + 2, y1: F + 4, z1: cz - 29 });           // passage hub → staircase
  for (let y = F; y <= F + 3; y++) for (let z = -14; z <= -10; z++) at(3, y - F, z, brick(cx + 3, y, cz + z));    // altar niche backing

  // ---- End-portal room (unchanged layout: lava pool, 12 frames, one-in-four eyes) -----------------------------------------
  for (let dy = 0; dy < 7; dy++) for (let dz = -5; dz <= 5; dz++) for (let dx = -5; dx <= 5; dx++) {
    const shell = Math.abs(dx) === 5 || Math.abs(dz) === 5 || dy === 0 || dy === 6;
    put(cx + dx, F + dy, cz + dz, shell ? (hash(dx + dy, dz, 71) < 0.25 ? mossy : sb) : 0, true);
  }
  for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) at(dx, 1, dz, Math.abs(dx) <= 1 && Math.abs(dz) <= 1 ? id('lava') : sb);
  at(0, 1, 3, cell('stone_brick_stairs', 0));
  const ring: [number, number, number, boolean][] = [
    [-1, -2, 0, true], [0, -2, 0, false], [1, -2, 0, false], [2, -1, 1, false], [2, 0, 1, true], [2, 1, 1, false],
    [1, 2, 2, false], [0, 2, 2, false], [-1, 2, 2, true], [-2, 1, 3, false], [-2, 0, 3, false], [-2, -1, 3, false],
  ];
  for (const [dx, dz, facing, eye] of ring) at(dx, 2, dz, cell('end_portal_frame', facing | (eye ? 4 : 0)));
  for (const [dx, dz] of [[4, 4], [-4, 4], [4, -4], [-4, -4]]) at(dx, 1, dz, torch);
  for (const dz of [-2, 0, 2]) for (const dx of [-5, 5]) { at(dx, 3, dz, bars); at(dx, 4, dz, bars); }

  // ---- Doorways ----------------------------------------------------------------------------------------------------------
  carve(-1, 1, -18, 1, 3, -5);                 // portal room ↔ corridor ↔ crossing
  carve(-6, 1, -24, -5, 3, -22);               // crossing ↔ prison
  carve(5, 1, -24, 9, 3, -22);                 // crossing ↔ library passage
  carve(10, 1, -23, 10, 2, -23); at(10, 1, -23, id('oak_door'));
  carve(-1, 1, -34, 1, 3, -28);                // crossing ↔ spiral staircase
  carve(-3, 1, -12, -2, 2, -12);               // corridor ↔ store room

  // ---- Corridor with a chest altar ---------------------------------------------------------------------------------------
  carve(2, 1, -13, 2, 2, -11);
  at(2, 1, -13, slab); at(2, 1, -11, slab);
  at(1, 1, -8, torch); at(-1, 1, -16, torch);

  // ---- Five-way crossing with a central pillar -----------------------------------------------------------------------------
  for (let dy = 1; dy <= 6; dy++) at(0, dy, -23, brick(cx, F + dy, cz - 23));
  for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { at(dx, 1, -23 + dz, slab); }
  for (const [dx, dz] of [[4, -19], [-4, -19], [4, -27], [-4, -27]]) at(dx, 1, dz, torch);

  // ---- Prison: three cells behind iron bars and iron doors ----------------------------------------------------------------
  for (let y = 1; y <= 3; y++) for (let z = -28; z <= -25; z++) for (const x of [-21, -20, -16, -12, -8, -7]) at(x, y, z, brick(cx + x, F + y, cz + z));
  for (const c of P.cells) {
    const dx = c.door[0] - cx;
    for (let y = 1; y <= 3; y++) for (let x = dx - 1; x <= dx + 1; x++) at(x, y, -25, bars);
    at(dx, 1, -25, id('iron_door', 'oak_door')); at(dx, 2, -25, 0);
  }
  at(-7, 1, -22, torch); at(-21, 1, -22, torch); at(-14, 1, -22, torch);

  // ---- Store room -----------------------------------------------------------------------------------------------------------
  for (const z of [-14, -10]) for (let x = -8; x <= -5; x++) { at(x, 1, z, plank); if ((x & 1) === 0) at(x, 2, z, id('barrel', 'oak_planks')); }
  at(-4, 1, -14, torch);

  // ---- Library: two storeys of bookshelves, balcony, ladder, chandelier, cobwebs -------------------------------------------
  const L = P.library, ix0 = L.x0 + 1, ix1 = L.x1 - 1, iz0 = L.z0 + 1, iz1 = L.z1 - 1;
  for (let z = iz0; z <= iz1; z++) for (let x = ix0; x <= ix1; x++) {
    const d = Math.min(x - ix0, ix1 - x, z - iz0, iz1 - z), nearDoor = x <= ix0 + 1 && Math.abs(z - (cz - 23)) <= 1;
    if (d === 0 && !nearDoor) {
      const pillar = ((x + z) & 3) === 0;
      for (let y = F + 1; y <= F + 4; y++) put(x, y, z, pillar ? plank : shelf, true);
      for (let y = F + 6; y <= F + 9; y++) put(x, y, z, pillar ? plank : shelf, true);
    }
    if (d <= 2) put(x, F + 5, z, plank, true);                                    // balcony floor
    if (d === 2) put(x, F + 6, z, fence, true);                                    // balcony rail
    if (d >= 3 && (x - ix0) % 3 === 0 && Math.abs(z - (cz - 23)) >= 2 && Math.abs(z - (cz - 23)) <= 3) for (let y = F + 1; y <= F + 3; y++) put(x, y, z, shelf, true);
    for (let y = F + 1; y <= F + 10; y++) {
      const corner = d <= 1 && (y === F + 4 || y >= F + 9), r = hash3(x, y, z, s + 9);
      if (((corner && r < 0.3) || (d >= 3 && y === F + 10 && r < 0.12)) && !(d === 0 && !nearDoor)) put(x, y, z, web, false);
    }
  }
  for (let y = F + 1; y <= F + 5; y++) put(L.x1 - 2, y, L.z1 - 2, cell('ladder', 3), true);                 // ladder against the east shelves
  const mx = (L.x0 + L.x1) >> 1, mz = cz - 23;
  for (let y = F + 8; y <= F + 10; y++) put(mx, y, mz, fence, true);
  for (const [dx, dz] of DIRS) { put(mx + dx, F + 8, mz + dz, fence, true); put(mx + dx, F + 9, mz + dz, torch, true); }
  put(ix0 + 1, F + 1, mz + 2, torch, true); put(ix1 - 1, F + 1, mz, torch, true);

  // ---- Spiral staircase to the surface --------------------------------------------------------------------------------------
  const S = P.stair, sx = P.spiral.x, sz = P.spiral.z, top = P.spiral.top;
  for (let y = F; y <= top + 3; y++) for (let z = S.z0; z <= S.z1; z++) for (let x = S.x0; x <= S.x1; x++) {
    const wall = x === S.x0 || x === S.x1 || z === S.z0 || z === S.z1;
    if (wall) { if (y <= top) put(x, y, z, brick(x, y, z), true); }
    else put(x, y, z, y === F || (x === sx && z === sz && y <= top) ? brick(x, y, z) : 0, true);
  }
  carve(-1, 1, -34, 1, 3, -34);
  const RING: [number, number, number][] = [[-1, 1, -1], [-1, 0, 0], [-1, -1, -1], [0, -1, 1], [1, -1, -1], [1, 0, 2], [1, 1, -1], [0, 1, 3]];
  for (let i = 1; ; i++) {
    const [dx, dz, stair] = RING[i % 8], y = F + ((i + 1) >> 1);
    if (y > top) break;
    put(sx + dx, y, sz + dz, stair < 0 ? sb : cell('stone_brick_stairs', stair), true);
  }
  put(sx, top + 1, sz, torch, true);

  // ---- Loot ------------------------------------------------------------------------------------------------------------------
  for (const c of P.chests) { put(c.pos[0], c.pos[1], c.pos[2], chest, true); markLoot(c.pos[0], c.pos[1], c.pos[2], c.table); }
}

// =========================================================================================================================
// End ship
// =========================================================================================================================
export interface EndShipPlan {
  x: number; y: number; z: number; length: number;
  dragonHead: [number, number, number]; elytraFrame: [number, number, number]; brewingStand: [number, number, number];
  chests: [number, number, number][]; mastTop: [number, number, number];
}
/** The end ship floats bow-first towards -z; (x, z) is the bow on the centre line and y the keel. */
export function endShipPlan(x: number, y: number, z: number): EndShipPlan {
  return {
    x, y, z, length: 25,
    dragonHead: [x, y + 5, z - 2], elytraFrame: [x, y + 2, z + 23], brewingStand: [x, y + 5, z + 22],
    chests: [[x - 2, y + 1, z + 22], [x + 2, y + 1, z + 22]], mastTop: [x, y + 18, z + 11],
  };
}
/**
 * End ship: purpur hull with a hold, deck, stern castle and masts. A dragon head rides the bow, the treasure room in the stern
 * holds two loot chests guarding an item frame with the elytra, and the brewing stand carries two Instant Health II potions.
 */
export function buildEndShip(put: Put, x: number, y: number, z: number) {
  const P = endShipPlan(x, y, z), purpur = id('purpur_block'), pillar = id('purpur_pillar', 'purpur_block'), esb = id('end_stone_bricks'), glass = id('magenta_stained_glass', 'glass');
  const pslab = id('purpur_slab', 'purpur_block'), rod = id('end_rod', 'torch');
  const hw = (dz: number) => (dz < 2 ? 1 : dz < 5 ? 2 : 3);
  for (let dz = 0; dz <= 24; dz++) {
    const w = hw(dz);
    for (let dx = -w; dx <= w; dx++) {
      const side = Math.abs(dx) === w || dz === 0 || dz === 24, px = x + dx, pz = z + dz;
      put(px, y, pz, dz >= 18 && Math.abs(dx) <= 1 ? id('obsidian') : purpur, true);
      for (let dy = 1; dy <= 3; dy++) put(px, y + dy, pz, side ? (dy === 1 ? esb : purpur) : dz === 17 && !(dx === 0 && dy <= 2) ? purpur : 0, true);
      put(px, y + 4, pz, purpur, true);
      put(px, y + 5, pz, side ? ((dx + dz) & 1 ? pslab : purpur) : 0, true);
      for (let dy = 6; dy <= 9; dy++) put(px, y + dy, pz, 0, true);
      if (dz >= 18) {                                                           // stern castle
        const wall = side || dz === 18;
        for (let dy = 5; dy <= 7; dy++) put(px, y + dy, pz, wall ? (dy === 6 && (dx === 0 || dz === 21) ? glass : pillar) : 0, true);
        put(px, y + 8, pz, purpur, true);
        put(px, y + 9, pz, side || dz === 18 ? pslab : 0, true);
      }
    }
  }
  put(x, y + 5, z + 18, 0, true); put(x, y + 6, z + 18, 0, true);                // cabin door
  // Masts with yards and end rods; the main mast carries the ladder into the hold.
  for (let dy = 1; dy <= 18; dy++) put(x, y + dy, z + 11, pillar, true);
  for (let dy = 5; dy <= 12; dy++) put(x, y + dy, z + 5, pillar, true);
  for (const [my, mz, half] of [[10, 11, 3], [15, 11, 2], [10, 5, 2]] as const) for (let dx = -half; dx <= half; dx++) if (dx !== 0) put(x + dx, y + my, z + mz, esb, true);
  for (const [dx, dy, dz] of [[-3, 9, 11], [3, 9, 11], [-2, 14, 11], [2, 14, 11], [0, 19, 11], [0, 13, 5], [-2, 5, 6], [2, 5, 6], [-2, 9, 20], [2, 9, 20]]) put(x + dx, y + dy, z + dz, rod, true);
  for (let dy = 1; dy <= 4; dy++) put(x, y + dy, z + 12, cell('ladder', 0), true);
  // Bowsprit with the dragon head.
  put(x, y + 4, z - 1, purpur, true); put(x, y + 4, z - 2, esb, true);
  put(P.dragonHead[0], P.dragonHead[1], P.dragonHead[2], cell('dragon_head', 0), true);
  // Treasure room: two chests and the elytra in an item frame on the stern wall.
  for (const c of P.chests) { put(c[0], c[1], c[2], id('chest'), true); markLoot(c[0], c[1], c[2], 'end_city_treasure'); }
  const [fx, fy, fz] = P.elytraFrame;
  put(fx, fy, fz, cell('item_frame', 10, 'oak_trapdoor'), true); markPreset(fx, fy, fz, [['elytra', 1]]);
  put(x - 2, y + 2, z + 18, rod, true); put(x + 2, y + 2, z + 18, rod, true);
  // Brewing stand with two Instant Health II potions in the captain's cabin.
  const [bx, by, bz] = P.brewingStand;
  put(bx, by, bz, id('brewing_stand'), true); markPreset(bx, by, bz, [['potion_healing_strong', 1], ['potion_healing_strong', 1], null, null, null]);
  put(x - 2, y + 5, z + 22, id('ender_chest', 'obsidian'), true);
}
