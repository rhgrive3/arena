// 作業B: Java Edition のブロック光（block light）と空の光（sky light）の3D BFS伝播。
// 光源・空の明るさから 1 ブロック（マンハッタン距離）ごとに 1 減り、光を通さない（opaque）ブロックで止まる。
import { BLOCKS, type BlockDef } from '../game/data';

const CUSTOM_SUB = new Set(['hopper', 'composter', 'cauldron', 'repeater', 'comparator', 'decorated_pot', 'frosted_ice', 'suspicious_sand', 'suspicious_gravel']);
/** Same rule as the mesher's LUT_OPAQUE: a non-transparent full block stops light. */
export function lightOpaque(def: BlockDef | undefined): boolean {
  return !!def && def.id > 0 && !def.transparent && !CUSTOM_SUB.has(def.name);
}
export const lightEmission = (def: BlockDef | undefined) => (def?.light ? Math.min(15, def.light) : 0);

let opaqueLut = new Uint8Array(0), emitLut = new Uint8Array(0), filterLut = new Uint8Array(0), maxEmit = 0;
function ensure() {
  if (opaqueLut.length === BLOCKS.length) return;
  opaqueLut = new Uint8Array(BLOCKS.length);
  emitLut = new Uint8Array(BLOCKS.length);
  filterLut = new Uint8Array(BLOCKS.length);
  maxEmit = 0;
  for (let i = 0; i < BLOCKS.length; i++) {
    const def = BLOCKS[i];
    opaqueLut[i] = lightOpaque(def) ? 1 : 0;
    emitLut[i] = lightEmission(def);
    maxEmit = Math.max(maxEmit, emitLut[i]);
    const n = def?.name ?? '';
    filterLut[i] = (n === 'water' || n === 'cobweb' || n.endsWith('_leaves')) ? 1 : 0;
  }
}

const R = 15, SIDE = 2 * R + 1, VOL = SIDE * SIDE * SIDE;
const stamp = new Uint32Array(VOL), queue = new Int32Array(VOL), dist = new Uint8Array(VOL);
let gen = 0;
const D6 = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];

/**
 * Block light (0‥15) at (x, y, z): breadth-first search from the target through non-opaque cells; a light source at path
 * distance d contributes (emission − d). Opaque emitters (glowstone, lamps) light their neighbours.
 */
export function blockLightAt(getBlock: (x: number, y: number, z: number) => number, x: number, y: number, z: number): number {
  ensure();
  x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
  const self = getBlock(x, y, z) & 0xfff;
  const own = emitLut[self] ?? 0;
  if (opaqueLut[self]) return own;
  if (++gen === 0xffffffff) { stamp.fill(0); gen = 1; }
  let best = own, head = 0, tail = 0;
  const idx = (dx: number, dy: number, dz: number) => ((dy + R) * SIDE + (dz + R)) * SIDE + (dx + R);
  const i0 = idx(0, 0, 0);
  stamp[i0] = gen; dist[i0] = 0; queue[tail++] = i0;
  while (head < tail) {
    const i = queue[head++], d = dist[i];
    if (maxEmit - (d + 1) <= best) break;
    const dx = (i % SIDE) - R, dz = (Math.floor(i / SIDE) % SIDE) - R, dy = Math.floor(i / (SIDE * SIDE)) - R;
    for (const [ox, oy, oz] of D6) {
      const nx = dx + ox, ny = dy + oy, nz = dz + oz;
      if (nx < -R || nx > R || ny < -R || ny > R || nz < -R || nz > R) continue;
      const ni = idx(nx, ny, nz);
      if (stamp[ni] === gen) continue;
      stamp[ni] = gen;
      const id = getBlock(x + nx, y + ny, z + nz) & 0xfff, em = emitLut[id] ?? 0;
      if (em - (d + 1) > best) best = em - (d + 1);
      if (!opaqueLut[id]) { dist[ni] = d + 1; queue[tail++] = ni; }
    }
  }
  return best;
}

/**
 * 3D Sky Light (0‥15) at (x, y, z) via Vanilla Java Edition 1.21 rules:
 *  - An unobstructed vertical column to the sky (`y .. y + scanHeight`) receives Sky Light 15 (minus 1 per light-filtering block such as leaves/water/cobweb).
 *  - Columns under overhangs/cave roofs receive Sky Light via 3D BFS from nearby sky-exposed columns, decaying by 1 per Manhattan step.
 */
export function skyLightAt(
  getBlock: (x: number, y: number, z: number) => number,
  x: number,
  y: number,
  z: number,
  scanHeight = 32,
): number {
  ensure();
  x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
  const self = getBlock(x, y, z) & 0xfff;
  if (opaqueLut[self]) return 0;

  const columnSkyLight = (cx: number, cy: number, cz: number): number => {
    let light = 15;
    for (let yy = cy + scanHeight; yy >= cy; yy--) {
      const id = getBlock(cx, yy, cz) & 0xfff;
      if (opaqueLut[id]) return 0;
      if (filterLut[id]) {
        light--;
        if (light <= 0) return 0;
      }
    }
    return light;
  };

  const direct = columnSkyLight(x, y, z);
  if (direct === 15) return 15;

  if (++gen === 0xffffffff) { stamp.fill(0); gen = 1; }
  let best = direct, head = 0, tail = 0;
  const idx = (dx: number, dy: number, dz: number) => ((dy + R) * SIDE + (dz + R)) * SIDE + (dx + R);
  const i0 = idx(0, 0, 0);
  stamp[i0] = gen; dist[i0] = 0; queue[tail++] = i0;

  while (head < tail) {
    const i = queue[head++], d = dist[i];
    if (15 - (d + 1) <= best) break;
    const dx = (i % SIDE) - R, dz = (Math.floor(i / SIDE) % SIDE) - R, dy = Math.floor(i / (SIDE * SIDE)) - R;
    for (const [ox, oy, oz] of D6) {
      const nx = dx + ox, ny = dy + oy, nz = dz + oz;
      if (nx < -R || nx > R || ny < -R || ny > R || nz < -R || nz > R) continue;
      const ni = idx(nx, ny, nz);
      if (stamp[ni] === gen) continue;
      stamp[ni] = gen;
      const id = getBlock(x + nx, y + ny, z + nz) & 0xfff;
      if (opaqueLut[id]) continue;
      const col = columnSkyLight(x + nx, y + ny, z + nz);
      if (col - (d + 1) > best) best = col - (d + 1);
      dist[ni] = d + 1;
      queue[tail++] = ni;
    }
  }
  return best;
}
