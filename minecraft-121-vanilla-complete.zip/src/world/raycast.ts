import { BLOCKS } from '../game/data';
import { blockId, blockState } from '../game/blockState';
import { selectionBoxes, type Bounds } from './shapes';

export interface VoxelHit {
  x: number; y: number; z: number; id: number;
  distance: number; normal: { x: number; y: number; z: number };
}

function intersectRayBox(
  origin: readonly number[], direction: readonly number[],
  x: number, y: number, z: number, box: Bounds, reach: number,
): { distance: number; axis: number; sign: number } | null {
  const block=[x,y,z];
  let near=-Infinity, far=Infinity, axis=-1, sign=0;
  for(let i=0;i<3;i++){
    const lo=block[i]+box[i], hi=block[i]+box[i+3], o=origin[i], d=direction[i];
    if(Math.abs(d)<1e-10){if(o<lo||o>hi)return null;continue;}
    const a=(lo-o)/d,b=(hi-o)/d,entry=Math.min(a,b),exit=Math.max(a,b);
    if(entry>near){near=entry;axis=i;sign=d>0?-1:1;}
    far=Math.min(far,exit);
    if(near>far)return null;
  }
  if(far<0||near>reach)return null;
  return {distance:Math.max(0,near),axis,sign};
}

// Amanatides-Woo voxel traversal visits each crossed cell once instead of
// allocating hundreds of temporary vectors per frame.
export function traceVoxelRay(
  origin: readonly [number,number,number], direction: readonly [number,number,number], reach: number,
  getCell: (x:number,y:number,z:number)=>number,
): VoxelHit | null {
  if(!Number.isFinite(reach)||reach<=0)return null;
  const dx=direction[0],dy=direction[1],dz=direction[2];
  if(Math.abs(dx)<1e-10&&Math.abs(dy)<1e-10&&Math.abs(dz)<1e-10)return null;

  let cx=Math.floor(origin[0]), cy=Math.floor(origin[1]), cz=Math.floor(origin[2]);
  const sx=dx>0?1:dx<0?-1:0, sy=dy>0?1:dy<0?-1:0, sz=dz>0?1:dz<0?-1:0;
  const dtx=dx===0?Infinity:Math.abs(1/dx);
  const dty=dy===0?Infinity:Math.abs(1/dy);
  const dtz=dz===0?Infinity:Math.abs(1/dz);
  let bx=dx===0?Infinity:((sx>0?cx+1:cx)-origin[0])/dx;
  let by=dy===0?Infinity:((sy>0?cy+1:cy)-origin[1])/dy;
  let bz=dz===0?Infinity:((sz>0?cz+1:cz)-origin[2])/dz;
  let entered=0;
  for(let visited=0;visited<128 && entered<=reach;visited++){
    const block=getCell(cx,cy,cz),id=blockId(block),def=BLOCKS[id];
    if(id>0&&def){
      let best: ReturnType<typeof intersectRayBox>=null;
      for(const box of selectionBoxes(def,blockState(block))){
        const hit=intersectRayBox(origin,direction,cx,cy,cz,box,reach);
        if(hit&&hit.distance+1e-8>=entered&&(!best||hit.distance<best.distance))best=hit;
      }
      if(best){
        const normal={x:0,y:0,z:0};
        if(best.axis===0)normal.x=best.sign;else if(best.axis===1)normal.y=best.sign;else if(best.axis===2)normal.z=best.sign;
        return {x:cx,y:cy,z:cz,id,distance:best.distance,normal};
      }
    }
    if(bx<=by&&bx<=bz){
      entered=bx;
      if(!Number.isFinite(entered))break;
      cx+=sx; bx+=dtx;
    }else if(by<=bz){
      entered=by;
      if(!Number.isFinite(entered))break;
      cy+=sy; by+=dty;
    }else{
      entered=bz;
      if(!Number.isFinite(entered))break;
      cz+=sz; bz+=dtz;
    }
  }
  return null;
}