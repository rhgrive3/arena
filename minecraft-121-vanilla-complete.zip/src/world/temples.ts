// Jungle pyramid (arrow-dispenser tripwire traps + three-lever puzzle that hides a chest) and igloo (hidden trapdoor under the
// carpet, ladder shaft and the basement laboratory with the two holding cells).  Layouts follow the Minecraft Wiki descriptions.
import { ID } from '../game/data';
import { makeCell } from '../game/blockState';
import type { Terrain } from './terrain';
import type { Put, Placed } from './structures';
import { markLoot, markPreset } from './loot';

const B = ID as Record<string, number | undefined>;
const id = (name: string, fallback = 'stone'): number => B[name] ?? B[fallback] ?? 1;
const cell = (name: string, state: number, fallback = 'stone') => makeCell(id(name, fallback), state);
const hash = (x: number, z: number, seed: number) => {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
const hash3 = (x: number, y: number, z: number, seed: number) => hash(x + y * 131, z - y * 71, seed);
type P3 = [number, number, number];

// =========================================================================================================================
// Jungle pyramid
// =========================================================================================================================
export interface JungleTempleParts {
  /** Puzzle levers ordered [furthest from the staircase, middle, closest to the staircase]. */
  levers: [P3, P3, P3];
  /** Main-floor block that the sticky piston pulls away, the piston, its head and the hidden power source. */
  door: P3; piston: P3; head: P3; power: P3;
  hiddenChest: P3; trapChest: P3;
  traps: { hooks: [P3, P3]; string: P3; dispenser: P3; facing: number; wire: P3[]; powered: P3 }[];
  stairTop: P3; entrance: P3;
}
/** World positions of every functional block of the jungle pyramid placed at `p` (12×15 footprint, three levels). */
export function jungleTempleParts(p: { x: number; y: number; z: number }): JungleTempleParts {
  const Y = p.y, w = (lx: number, y: number, lz: number): P3 => [p.x - 6 + lx, y, p.z - 7 + lz];
  return {
    levers: [w(4, Y - 3, 4), w(3, Y - 3, 4), w(2, Y - 3, 4)],
    door: w(8, Y - 1, 1), head: w(9, Y - 1, 1), piston: w(10, Y - 1, 1), power: w(10, Y - 2, 1),
    hiddenChest: w(8, Y - 2, 1), trapChest: w(3, Y - 4, 12),
    traps: [
      { hooks: [w(6, Y - 4, 9), w(8, Y - 4, 9)], string: w(7, Y - 4, 9), dispenser: w(7, Y - 4, 13), facing: 3, powered: w(9, Y - 4, 9),
        wire: [w(10, Y - 4, 9), w(10, Y - 4, 10), w(10, Y - 4, 11), w(10, Y - 4, 12), w(10, Y - 4, 13), w(9, Y - 4, 13), w(8, Y - 4, 13)] },
      { hooks: [w(4, Y - 4, 10), w(4, Y - 4, 12)], string: w(4, Y - 4, 11), dispenser: w(1, Y - 4, 11), facing: 0, powered: w(4, Y - 4, 9),
        wire: [w(4, Y - 4, 8), w(3, Y - 4, 8), w(2, Y - 4, 8), w(1, Y - 4, 8), w(1, Y - 4, 9), w(1, Y - 4, 10)] },
    ],
    stairTop: w(5, Y - 1, 2), entrance: w(7, Y, 14),
  };
}

/** Lever indices of the solution, per the Wiki: far on, near on, near off, far off (0 = far, 1 = middle, 2 = near). */
export const JUNGLE_PUZZLE_SEQUENCE = [0, 2, 2, 0] as const;
/**
 * Feeds one lever flick into the puzzle. `history` holds the most recent flicks; the hidden door is open exactly while the last
 * four flicks are the solution sequence, so any further flick closes it again (as the vanilla circuit does).
 */
export function junglePuzzleStep(history: readonly number[], lever: number): { history: number[]; open: boolean } {
  const next = [...history, lever].slice(-JUNGLE_PUZZLE_SEQUENCE.length);
  return { history: next, open: next.length === JUNGLE_PUZZLE_SEQUENCE.length && next.every((v, i) => v === JUNGLE_PUZZLE_SEQUENCE[i]) };
}
/** Block edits that move the hidden door: the sticky piston retracts and pulls the floor block off the chest (or pushes it back). */
export function junglePuzzleEdits(parts: JungleTempleParts, open: boolean): { pos: P3; id: number; state: number }[] {
  const cob = id('mossy_cobblestone', 'cobblestone'), sticky = id('sticky_piston', 'piston');
  return open
    ? [{ pos: parts.power, id: id('cobblestone'), state: 0 }, { pos: parts.piston, id: sticky, state: 2 }, { pos: parts.head, id: cob, state: 0 }, { pos: parts.door, id: 0, state: 0 }]
    : [{ pos: parts.door, id: cob, state: 0 }, { pos: parts.head, id: id('piston_head', 'cobblestone'), state: 10 }, { pos: parts.piston, id: sticky, state: 10 }, { pos: parts.power, id: id('redstone_block'), state: 0 }];
}

export function jungleTemple(t: Terrain, put: Put, p: Placed) {
  const L = jungleTempleParts(p), Y = p.y, s = t.seed + 7800;
  const cob = id('cobblestone'), mossy = id('mossy_cobblestone', 'cobblestone'), chiseled = id('chiseled_stone_bricks', 'stone_bricks'), vine = id('vine', 'air'), wire = id('redstone_wire');
  const W = (lx: number, y: number, lz: number, blk: number) => put(p.x - 6 + lx, y, p.z - 7 + lz, blk, true);
  const at = (q: P3, blk: number) => put(q[0], q[1], q[2], blk, true);
  const stone = (lx: number, y: number, lz: number) => (hash3(p.x + lx, y, p.z + lz, s) < 0.4 ? mossy : cob);

  for (let lz = 0; lz <= 14; lz++) for (let lx = 0; lx <= 11; lx++) {
    const edge = lx === 0 || lx === 11 || lz === 0 || lz === 14;
    for (let y = Y - 9; y <= Y - 6; y++) W(lx, y, lz, cob);
    for (let y = Y - 5; y <= Y + 4; y++) W(lx, y, lz, y === Y - 5 || y === Y - 1 || y === Y + 4 || edge || y < Y - 1 ? stone(lx, y, lz) : 0);
    const in1 = lx >= 1 && lx <= 10 && lz >= 1 && lz <= 13, edge1 = lx === 1 || lx === 10 || lz === 1 || lz === 13;
    for (let y = Y + 5; y <= Y + 7; y++) W(lx, y, lz, in1 && edge1 ? stone(lx, y, lz) : 0);
    W(lx, Y + 8, lz, in1 ? stone(lx, Y + 8, lz) : 0);
    W(lx, Y + 9, lz, lx >= 2 && lx <= 9 && lz >= 2 && lz <= 12 ? stone(lx, Y + 9, lz) : 0);
    W(lx, Y + 10, lz, lx >= 3 && lx <= 8 && lz >= 3 && lz <= 11 ? stone(lx, Y + 10, lz) : 0);
    if (edge && hash(p.x + lx, p.z + lz, s + 1) < 0.35) {                           // vines hanging on the outer walls
      const ox = lx === 0 ? -1 : lx === 11 ? 1 : 0, oz = ox ? 0 : lz === 0 ? -1 : 1;
      for (let y = Y + 3; y >= Y + 3 - Math.floor(hash(lx, lz, s + 2) * 4); y--) put(p.x - 6 + lx + ox, y, p.z - 7 + lz + oz, vine, false);
    }
  }
  // Openings: entrance, upper-tier windows.
  for (let y = Y; y <= Y + 2; y++) { W(7, y, 14, 0); W(8, y, 14, 0); }
  for (const lz of [1, 13]) for (const lx of [5, 6]) W(lx, Y + 6, lz, 0);
  for (const lx of [1, 10]) for (const lz of [4, 7, 10]) W(lx, Y + 6, lz, 0);

  // ---- Basement --------------------------------------------------------------------------------------------------------
  const carve = (x0: number, z0: number, x1: number, z1: number) => { for (let y = Y - 4; y <= Y - 2; y++) for (let lz = z0; lz <= z1; lz++) for (let lx = x0; lx <= x1; lx++) W(lx, y, lz, 0); };
  carve(1, 1, 5, 4);            // stair + lever room
  carve(6, 3, 8, 5);            // passage
  carve(6, 6, 8, 11);           // trap corridor
  carve(7, 12, 7, 12);          // alcove in front of the first dispenser
  carve(3, 10, 5, 12);          // chest corridor
  carve(2, 11, 2, 11);          // alcove in front of the second dispenser
  // Staircase main floor → basement (descends towards -x along lz = 2).
  for (let i = 0; i < 4; i++) {
    const lx = 5 - i, y = Y - 1 - i;
    for (let yy = Y - 4; yy < y; yy++) W(lx, yy, 2, cob);
    W(lx, y, 2, cell('cobblestone_stairs', 1));
    for (let yy = y + 1; yy <= Y - 1; yy++) W(lx, yy, 2, 0);
  }
  W(1, Y - 1, 2, 0);
  // Lever puzzle: three levers on chiseled stone bricks.
  for (const lv of L.levers) { put(lv[0], lv[1], lv[2] + 1, chiseled, true); at(lv, cell('lever', 4)); }
  // Hidden chest under the main floor, closed by a sticky piston that a concealed redstone block keeps extended.
  for (const e of junglePuzzleEdits(L, false)) at(e.pos, e.id ? makeCell(e.id, e.state) : 0);
  at(L.hiddenChest, id('chest')); markLoot(...L.hiddenChest, 'jungle_temple');
  for (let lz = 1; lz <= 2; lz++) for (let lx = 9; lx <= 10; lx++) W(lx, Y, lz, mossy);                    // ledge hiding the piston
  W(9, Y - 4, 2, 0); W(10, Y - 4, 2, 0); W(9, Y - 4, 3, 0); W(10, Y - 4, 3, 0);                            // sealed mechanism room
  W(9, Y - 4, 3, wire); W(10, Y - 4, 3, cell('repeater', 3)); W(10, Y - 4, 2, wire); W(9, Y - 4, 2, cell('repeater', 0));
  // Arrow traps: tripwire → hook → hidden redstone dust → dispenser with 2–14 arrows.
  L.traps.forEach((tr, n) => {
    at(tr.hooks[0], cell('tripwire_hook', n === 0 ? 1 : 3)); at(tr.hooks[1], cell('tripwire_hook', n === 0 ? 2 : 4));
    at(tr.string, id('tripwire', 'air'));
    for (const q of tr.wire) at(q, wire);
    at(tr.dispenser, cell('dispenser', tr.facing));
    markPreset(...tr.dispenser, [['arrow', 2 + Math.floor(hash(tr.dispenser[0], tr.dispenser[2], s + 3) * 13)], null, null, null, null, null, null, null, null]);
  });
  at(L.trapChest, id('chest')); markLoot(...L.trapChest, 'jungle_temple');

  // ---- Staircase main floor → upper floor (along lz = 12) ---------------------------------------------------------------
  for (let i = 0; i < 5; i++) {
    const lx = 2 + i, y = Y + i;
    for (let yy = Y; yy < y; yy++) W(lx, yy, 12, cob);
    W(lx, y, 12, cell('cobblestone_stairs', 1));
    for (let yy = y + 1; yy <= Y + 6; yy++) W(lx, yy, 12, 0);
  }
}

// =========================================================================================================================
// Igloo
// =========================================================================================================================
export interface IglooParts {
  basement: boolean;
  trapdoor: P3; carpet: P3; bed: P3; furnace: P3; craftingTable: P3;
  /** Basement pieces (present only when `basement`). */
  floorY: number; ladderTop: P3; brewingStand: P3; chest: P3; cauldron: P3;
  cells: { species: 'villager' | 'zombie_villager'; inside: P3; bars: P3[] }[];
}
export const iglooHasBasement = (seed: number, p: { x: number; z: number }) => hash(p.x, p.z, seed + 7900) < 0.5;
export function iglooParts(seed: number, p: { x: number; y: number; z: number }): IglooParts {
  const sx = p.x + 1, sz = p.z + 1, by = p.y - 12;
  return {
    basement: iglooHasBasement(seed, p),
    trapdoor: [sx, p.y - 1, sz], carpet: [sx, p.y, sz], bed: [p.x - 2, p.y, p.z - 1], furnace: [p.x + 1, p.y, p.z - 2], craftingTable: [p.x - 1, p.y, p.z - 2],
    floorY: by, ladderTop: [sx, p.y - 2, sz], brewingStand: [sx, by + 1, sz + 6], chest: [sx - 1, by + 1, sz + 6], cauldron: [sx + 1, by + 1, sz + 6],
    cells: [
      { species: 'villager', inside: [sx - 2, by + 1, sz + 3], bars: [[sx - 1, by + 1, sz + 3], [sx - 1, by + 2, sz + 3], [sx - 1, by + 1, sz + 4], [sx - 1, by + 2, sz + 4]] },
      { species: 'zombie_villager', inside: [sx + 2, by + 1, sz + 3], bars: [[sx + 1, by + 1, sz + 3], [sx + 1, by + 2, sz + 3], [sx + 1, by + 1, sz + 4], [sx + 1, by + 2, sz + 4]] },
    ],
  };
}

export function igloo(t: Terrain, put: Put, p: Placed) {
  const I = iglooParts(t.seed, p), y = p.y, s = t.seed + 7900;
  const snow = id('snow_block'), ice = id('ice'), white = id('white_carpet'), gray = id('light_gray_carpet', 'white_carpet');
  const at = (q: P3, blk: number) => put(q[0], q[1], q[2], blk, true);
  // Dome of snow blocks on a snow floor.
  for (let dz = -4; dz <= 4; dz++) for (let dx = -4; dx <= 4; dx++) {
    const flat = dx * dx + dz * dz;
    if (flat > 14) continue;
    for (let dy = 1; dy <= 6; dy++) put(p.x + dx, y - 1 - dy, p.z + dz, snow, false);
    put(p.x + dx, y - 1, p.z + dz, snow, true);
    for (let dy = 0; dy <= 4; dy++) {
      const d = flat + dy * dy * 1.5;
      put(p.x + dx, y + dy, p.z + dz, d <= 14 && d > 6.5 ? snow : 0, true);
    }
    if (flat <= 6.5) put(p.x + dx, y, p.z + dz, ((dx + dz) & 1) === 0 ? white : gray, true);
  }
  // Entrance tunnel (south) and ice windows.
  for (let dz = 3; dz <= 5; dz++) {
    put(p.x, y - 1, p.z + dz, snow, true);
    put(p.x, y, p.z + dz, 0, true); put(p.x, y + 1, p.z + dz, 0, true);
    put(p.x - 1, y, p.z + dz, snow, true); put(p.x + 1, y, p.z + dz, snow, true); put(p.x - 1, y + 1, p.z + dz, snow, true); put(p.x + 1, y + 1, p.z + dz, snow, true);
    put(p.x, y + 2, p.z + dz, snow, true);
  }
  put(p.x - 3, y + 1, p.z, ice, true); put(p.x + 3, y + 1, p.z, ice, true);
  // Furniture: bed, furnace, crafting table, redstone torch.
  put(I.bed[0], y, I.bed[2], cell('bed', 0), true); put(I.bed[0], y, I.bed[2] + 1, cell('bed', 4), true);
  at(I.furnace, id('furnace')); at(I.craftingTable, id('crafting_table'));
  put(p.x, y + 1, p.z - 2, cell('redstone_torch', 0, 'torch'), true); put(p.x, y, p.z - 2, snow, true);
  if (!I.basement) return;

  // Hidden trapdoor under the carpet, ladder shaft cased in stone bricks.
  const sb = id('stone_bricks'), mossy = id('mossy_stone_bricks', 'stone_bricks'), cracked = id('cracked_stone_bricks', 'stone_bricks');
  const brick = (x: number, yy: number, z: number) => { const r = hash3(x, yy, z, s); return r < 0.2 ? mossy : r < 0.35 ? cracked : sb; };
  const [sx, , sz] = I.trapdoor, by = I.floorY;
  at(I.trapdoor, cell('oak_trapdoor', 4)); at(I.carpet, white);
  for (let yy = by + 4; yy <= y - 2; yy++) for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
    if (dx === 0 && dz === 0) put(sx, yy, sz, cell('ladder', 0), true);
    else put(sx + dx, yy, sz + dz, brick(sx + dx, yy, sz + dz), true);
  }
  // Basement: 5 wide, 7 long, 3 high.
  for (let yy = by; yy <= by + 4; yy++) for (let dz = -1; dz <= 7; dz++) for (let dx = -3; dx <= 3; dx++) {
    const shell = Math.abs(dx) === 3 || dz === -1 || dz === 7 || yy === by || yy === by + 4;
    if (yy === by + 4 && dx === 0 && dz === 0) continue;                              // ladder passes through the ceiling
    put(sx + dx, yy, sz + dz, shell ? brick(sx + dx, yy, sz + dz) : 0, true);
  }
  for (let yy = by + 1; yy <= by + 3; yy++) put(sx, yy, sz, cell('ladder', 0), true);
  // Two holding cells behind iron bars: a villager and a zombie villager (cure it with the weakness potion + golden apple).
  for (const c of I.cells) {
    const cx = c.inside[0];
    for (let yy = by + 1; yy <= by + 3; yy++) { put(cx, yy, sz + 2, brick(cx, yy, sz + 2), true); put(cx, yy, sz + 5, brick(cx, yy, sz + 5), true); }
    for (const b of c.bars) at(b, id('iron_bars'));
    put(c.bars[0][0], by + 3, sz + 3, brick(c.bars[0][0], by + 3, sz + 3), true); put(c.bars[0][0], by + 3, sz + 4, brick(c.bars[0][0], by + 3, sz + 4), true);
  }
  for (let dz = 1; dz <= 5; dz++) put(sx, by + 1, sz + dz, id('red_carpet', 'white_carpet'), true);
  // Laboratory bench: brewing stand with a splash potion of weakness, cauldron, and the chest with the golden apple.
  at(I.brewingStand, id('brewing_stand')); markPreset(...I.brewingStand, [['splash_weakness', 1], null, null, null, null]);
  at(I.cauldron, id('cauldron', 'stone_bricks'));
  at(I.chest, id('chest')); markLoot(...I.chest, 'igloo_chest');
  put(sx - 2, by + 3, sz + 6, id('cobweb', 'air'), true);
  put(sx + 2, by + 1, sz + 6, cell('redstone_torch', 0, 'torch'), true);
  put(sx - 2, by + 1, sz + 1, id('torch'), true);
}
