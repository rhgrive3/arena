// Ocean structures (Minecraft Wiki "Ocean Monument/Structure" & "Shipwreck/Structure", Java Edition 1.21 parity).
//  * Ocean monument – 58×58×23 prismarine complex on 23 giant 4×4 seabed pillars:
//    - Exact 49-unit room graph (`OceanMonumentPieces`): 2 layers of 5×4 (40 units) + top layer of 3×2 (6 units) + 3 dummy units
//      (left wing, right wing, penthouse).
//    - 2×2×2 Core placed at the back (8 gold blocks wrapped in dark prismarine); randomized wall-closing pass (up to 5 tries per
//      unit for 2 closures) verified via BFS reachability to the front-center Entry unit.
//    - Priority room packer: DXY (2×1×2) → DYZ (1×2×2) → DZ (1×2×1) → DX (2×1×1) → DY (1×1×2) → Sponge room (all walls except
//      bottom closed; 6×6 ceiling grid with 1/3 empty, 1/2 1 wet_sponge, 1/6 2 wet_sponges) → 3 Small Room blueprints (1/3 each:
//      Plus-shaped, Four-pillar, Dark prismarine, with 50% central 2×2 pillar when top & bottom are closed and >=2 sides are open).
//    - Asymmetric wings: one wing is `wing_with_room` (enclosed chamber with central pillar), the other is `wing_with_open_area`
//      (open hall); each wing and the Penthouse hold one Elder Guardian (3 total).
//  * Shipwreck – all 20 official Java Edition structure templates (`with_mast`, `with_mast_degraded`, `rightsideup_full`,
//    `rightsideup_full_degraded`, `rightsideup_fronthalf`, `rightsideup_fronthalf_degraded`, `rightsideup_backhalf`,
//    `rightsideup_backhalf_degraded`, `sideways_full`, `sideways_full_degraded`, `sideways_fronthalf`,
//    `sideways_fronthalf_degraded`, `sideways_backhalf`, `sideways_backhalf_degraded`, `upsidedown_full`,
//    `upsidedown_full_degraded`, `upsidedown_fronthalf`, `upsidedown_fronthalf_degraded`, `upsidedown_backhalf`,
//    `upsidedown_backhalf_degraded`) built from 2 distinct Overworld wood types per ship.
import { type Put, type StructHost, SEA, bid, cell, hash2, hash3, mulberry, stairsUp, ladderOn, attachOn } from './common';
import { chest, barrel, itemFrame, lantern } from './decor';

interface Site { x: number; y: number; z: number }
export const MONUMENT_HALF = 28;

export type MonumentRoomKind =
  | 'entry' | 'core' | 'sponge'
  | 'dxy' | 'dyz' | 'dz' | 'dx' | 'dy'
  | 'small_plus' | 'small_pillars' | 'small_dark';

export interface MonumentRoom {
  gx: number; gy: number; gz: number;
  spanX: number; spanY: number; spanZ: number;
  kind: MonumentRoomKind;
  centralPillar: boolean;
  /** Open connections bitmask: 0 = front(-z), 1 = right(+x), 2 = back(+z), 3 = left(-x), 4 = up(+y), 5 = down(-y). */
  open: number;
}
export interface MonumentPlan {
  /** 49 basic units (46 grid units across 5×4×2 + 3×2×1, plus 3 dummy units for wings and penthouse). */
  unitCount: 49;
  coreGx: number;
  rooms: MonumentRoom[];
  spongeCentres: [number, number, number][];
  /** Asymmetric wings per Wiki: true = left wing has room & right wing has open area; false = reversed. */
  leftWingHasRoom: boolean;
  /** The 23 giant 4×4 foundation pillar centres [dx, dz] relative to monument centre. */
  pillars: [number, number][];
}

const MON_PLANS = new Map<string, MonumentPlan>();

/** The 23 giant 4×4 seabed pillar offsets (relative to monument centre) supporting the body, wings, and entrance. */
export const MONUMENT_PILLARS: readonly [number, number][] = [
  [-25, -25], [-13, -25], [13, -25], [25, -25],
  [-25, -13], [-15, -13], [-5, -13], [5, -13], [15, -13], [25, -13],
  [-25, -1],  [-15, -1],  [-5, -1],  [5, -1],  [15, -1],  [25, -1],
  [-25, 11],  [-15, 11],  [-5, 11],  [5, 11],  [15, 11],  [25, 11],
  [0, 23],
];

/**
 * Exact 49-unit procedural room-graph generator per Minecraft Wiki `Ocean Monument/Structure`:
 *  - 46 non-dummy basic units: Layer 0 (5×4 = 20), Layer 1 (5×4 = 20), Layer 2 (3×2 = 6, gx 1..3, gz 1..2)
 *  - 3 dummy units (46 = left wing, 47 = right wing, 48 = penthouse), total = 49 basic units.
 *  - 2×2×2 Core (8 units) placed at the back; randomized wall-closing pass (up to 5 attempts per unit for 2 closures)
 *    with BFS reachability check to Entry unit (gx=2, gz=0, gy=0).
 *  - Priority room packing: DXY → DYZ → DZ → DX → DY → Sponge → Small (Plus / Four-pillar / Dark prismarine).
 */
export function monumentRoomGraph(seed: number, p: Site): MonumentPlan {
  const key = `${seed}:${p.x},${p.y},${p.z}`;
  const cached = MON_PLANS.get(key);
  if (cached) return cached;
  const rnd = mulberry((Math.imul(seed | 0, 2654435761) ^ Math.imul(p.x, 73856093) ^ Math.imul(p.z, 19349663) ^ 0x5deece66d) >>> 0);

  // Map (gx, gy, gz) to unit index 0..45, or -1 if outside the 46-unit grid (5×4 on gy=0,1; 3×2 on gy=2 at gx=1..3, gz=1..2).
  const coords: [number, number, number][] = [];
  const lookup = new Map<string, number>();
  for (let gy = 0; gy < 3; gy++) {
    for (let gz = 0; gz < 4; gz++) for (let gx = 0; gx < 5; gx++) {
      if (gy === 2 && (gx < 1 || gx > 3 || gz < 1 || gz > 2)) continue;
      const id = coords.length;
      coords.push([gx, gy, gz]);
      lookup.set(`${gx},${gy},${gz}`, id);
    }
  }
  // 46 grid units + 3 dummy units (46 = left wing, 47 = right wing, 48 = penthouse) = 49 units.
  const TOTAL_UNITS = 49, WING_L = 46, WING_R = 47, PENTHOUSE = 48;
  const adj: [number, number][][] = Array.from({ length: TOTAL_UNITS }, () => []);
  const openEdge = new Set<string>();
  const edgeKey = (a: number, b: number) => (a < b ? `${a}:${b}` : `${b}:${a}`);
  const connect = (a: number, b: number, dirFromA: number) => {
    const k = edgeKey(a, b);
    if (openEdge.has(k)) return;
    openEdge.add(k);
    adj[a].push([b, dirFromA]);
    adj[b].push([a, dirFromA ^ (dirFromA < 4 ? 2 : 1)]);
  };
  const DIRS: [number, number, number, number][] = [
    [0, 0, -1, 0], [1, 0, 0, 1], [0, 0, 1, 2], [-1, 0, 0, 3], [0, 1, 0, 4], [0, -1, 0, 5],
  ];
  for (let u = 0; u < 46; u++) {
    const [gx, gy, gz] = coords[u];
    for (const [dx, dy, dz, dir] of DIRS) {
      const v = lookup.get(`${gx + dx},${gy + dy},${gz + dz}`);
      if (v !== undefined) connect(u, v, dir);
    }
    if (gy === 0 && gx === 0) connect(u, WING_L, 3);
    if (gy === 0 && gx === 4) connect(u, WING_R, 1);
    if (gy === 2) connect(u, PENTHOUSE, 4);
  }

  const used = new Uint8Array(TOTAL_UNITS);
  used[WING_L] = 1; used[WING_R] = 1; used[PENTHOUSE] = 1;
  const entryUnit = lookup.get('2,0,0')!;

  // Place 2×2×2 Core (8 basic units) at the back (gz = 2..3, gy = 0..1, gx = coreGx..coreGx+1)
  const coreGx = 1 + Math.floor(rnd() * 3); // 1, 2, or 3
  for (let dy = 0; dy <= 1; dy++) for (let dz = 2; dz <= 3; dz++) for (let dx = 0; dx <= 1; dx++) {
    const u = lookup.get(`${coreGx + dx},${dy},${dz}`);
    if (u !== undefined) used[u] = 1;
  }

  // BFS helper: verifies `start` can still reach `entryUnit` through open walls
  const canReachEntry = (start: number): boolean => {
    if (start === entryUnit) return true;
    const seen = new Uint8Array(TOTAL_UNITS);
    const q = [start];
    seen[start] = 1;
    while (q.length) {
      const cur = q.pop()!;
      for (const [nxt] of adj[cur]) {
        if (!openEdge.has(edgeKey(cur, nxt)) || seen[nxt]) continue;
        if (nxt === entryUnit) return true;
        seen[nxt] = 1;
        q.push(nxt);
      }
    }
    return false;
  };

  // Randomize unit order; for each unit make up to 5 attempts to close walls until 2 closures succeed
  const order = Array.from({ length: 46 }, (_, i) => i);
  for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
  for (const u of order) {
    let closed = 0;
    for (let attempt = 0; attempt < 5 && closed < 2; attempt++) {
      const neighbours = adj[u];
      if (!neighbours.length) break;
      const [v] = neighbours[Math.floor(rnd() * neighbours.length)];
      const k = edgeKey(u, v);
      if (!openEdge.has(k)) continue;
      openEdge.delete(k);
      if (canReachEntry(u) && canReachEntry(v)) closed++;
      else openEdge.add(k);
    }
  }

  const isOpen = (gx: number, gy: number, gz: number, dir: number): boolean => {
    const u = lookup.get(`${gx},${gy},${gz}`);
    if (u === undefined) return false;
    const [dx, dy, dz] = DIRS[dir];
    const v = lookup.get(`${gx + dx},${gy + dy},${gz + dz}`);
    return v !== undefined && openEdge.has(edgeKey(u, v));
  };
  const openMask = (gx: number, gy: number, gz: number): number => {
    let m = 0;
    for (let d = 0; d < 6; d++) if (isOpen(gx, gy, gz, d)) m |= 1 << d;
    return m;
  };
  const isUnused = (gx: number, gy: number, gz: number): boolean => {
    const u = lookup.get(`${gx},${gy},${gz}`);
    return u !== undefined && !used[u];
  };
  const markUsed = (gx: number, gy: number, gz: number) => {
    const u = lookup.get(`${gx},${gy},${gz}`);
    if (u !== undefined) used[u] = 1;
  };

  const rooms: MonumentRoom[] = [];
  // Mark Entry room and Core room
  used[entryUnit] = 1;
  rooms.push({ gx: 2, gy: 0, gz: 0, spanX: 1, spanY: 1, spanZ: 1, kind: 'entry', centralPillar: false, open: openMask(2, 0, 0) | 1 });
  rooms.push({ gx: coreGx, gy: 0, gz: 2, spanX: 2, spanY: 2, spanZ: 2, kind: 'core', centralPillar: false, open: openMask(coreGx, 0, 2) });

  // Second randomized pass: assign DXY → DYZ → DZ → DX → DY → Sponge → 3 Small Room variants
  const order2 = Array.from({ length: 46 }, (_, i) => i);
  for (let i = order2.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [order2[i], order2[j]] = [order2[j], order2[i]]; }
  for (const u of order2) {
    if (used[u]) continue;
    const [gx, gy, gz] = coords[u];
    const op = openMask(gx, gy, gz);
    // 1. DXY room (2×1×2: current, above, right, above-right)
    if (isUnused(gx + 1, gy, gz) && isUnused(gx, gy + 1, gz) && isUnused(gx + 1, gy + 1, gz) &&
        isOpen(gx, gy, gz, 1) && isOpen(gx, gy, gz, 4) && isOpen(gx + 1, gy, gz, 4) && isOpen(gx, gy + 1, gz, 1)) {
      markUsed(gx, gy, gz); markUsed(gx + 1, gy, gz); markUsed(gx, gy + 1, gz); markUsed(gx + 1, gy + 1, gz);
      rooms.push({ gx, gy, gz, spanX: 2, spanY: 2, spanZ: 1, kind: 'dxy', centralPillar: false, open: op });
      continue;
    }
    // 2. DYZ room (1×2×2: current, above, back, above-back)
    if (isUnused(gx, gy, gz + 1) && isUnused(gx, gy + 1, gz) && isUnused(gx, gy + 1, gz + 1) &&
        isOpen(gx, gy, gz, 2) && isOpen(gx, gy, gz, 4) && isOpen(gx, gy, gz + 1, 4) && isOpen(gx, gy + 1, gz, 2)) {
      markUsed(gx, gy, gz); markUsed(gx, gy, gz + 1); markUsed(gx, gy + 1, gz); markUsed(gx, gy + 1, gz + 1);
      rooms.push({ gx, gy, gz, spanX: 1, spanY: 2, spanZ: 2, kind: 'dyz', centralPillar: true, open: op });
      continue;
    }
    // 3. DZ room (1×2×1: current and behind)
    if (isUnused(gx, gy, gz + 1) && isOpen(gx, gy, gz, 2)) {
      markUsed(gx, gy, gz); markUsed(gx, gy, gz + 1);
      rooms.push({ gx, gy, gz, spanX: 1, spanY: 1, spanZ: 2, kind: 'dz', centralPillar: false, open: op | openMask(gx, gy, gz + 1) });
      continue;
    }
    // 4. DX room (2×1×1: current and right)
    if (isUnused(gx + 1, gy, gz) && isOpen(gx, gy, gz, 1)) {
      markUsed(gx, gy, gz); markUsed(gx + 1, gy, gz);
      rooms.push({ gx, gy, gz, spanX: 2, spanY: 1, spanZ: 1, kind: 'dx', centralPillar: false, open: op | openMask(gx + 1, gy, gz) });
      continue;
    }
    // 5. DY room (1×1×2: current and above)
    if (isUnused(gx, gy + 1, gz) && isOpen(gx, gy, gz, 4)) {
      markUsed(gx, gy, gz); markUsed(gx, gy + 1, gz);
      rooms.push({ gx, gy, gz, spanX: 1, spanY: 2, spanZ: 1, kind: 'dy', centralPillar: false, open: op | openMask(gx, gy + 1, gz) });
      continue;
    }
    // 6. Sponge room (all walls except bottom are closed, or top-layer cell)
    markUsed(gx, gy, gz);
    if ((op & 0b011111) === 0 || (gy === 2 && rnd() < 0.5)) {
      rooms.push({ gx, gy, gz, spanX: 1, spanY: 1, spanZ: 1, kind: 'sponge', centralPillar: false, open: 1 << 5 });
      continue;
    }
    // 7. Three Small Room variants (1/3 chance each: Plus-shaped, Four-pillar, Dark prismarine)
    const rPick = rnd();
    const kind: MonumentRoomKind = rPick < 1 / 3 ? 'small_plus' : rPick < 2 / 3 ? 'small_pillars' : 'small_dark';
    const sideCount = (op & 1) + ((op >> 1) & 1) + ((op >> 2) & 1) + ((op >> 3) & 1);
    const topBottomClosed = (op & (1 << 4)) === 0 && (op & (1 << 5)) === 0;
    const centralPillar = kind !== 'small_plus' && topBottomClosed && sideCount >= 2 && rnd() < 0.5;
    rooms.push({ gx, gy, gz, spanX: 1, spanY: 1, spanZ: 1, kind, centralPillar, open: op });
  }

  // Ensure at least one sponge room is registered in the room list as well as the upper wing sponge chambers
  if (!rooms.some(r => r.kind === 'sponge')) {
    const topRoom = rooms.find(r => r.gy === 2) ?? rooms[rooms.length - 1];
    topRoom.kind = 'sponge';
  }
  const spongeCentres: [number, number, number][] = [[-13, 1, 13], [13, 1, 13]];
  if (rnd() < 0.7) spongeCentres.push([0, 7, 13]);
  const plan: MonumentPlan = {
    unitCount: 49,
    coreGx,
    rooms,
    spongeCentres,
    leftWingHasRoom: rnd() < 0.5,
    pillars: MONUMENT_PILLARS.map(c => [c[0], c[1]]),
  };
  if (MON_PLANS.size > 24) MON_PLANS.clear();
  MON_PLANS.set(key, plan);
  return plan;
}

export function oceanMonument(t: StructHost, put: Put, p: Site, ox?: number, oz?: number) {
  const pb = bid('prismarine_bricks', 'prismarine'), pr = bid('prismarine'), dp = bid('dark_prismarine', 'prismarine');
  const lan = bid('sea_lantern', 'glowstone'), water = bid('water'), gold = bid('gold_block'), sponge = bid('wet_sponge', 'sponge');
  const s = t.seed + 7300, H = MONUMENT_HALF;
  const T = SEA - 3 - p.y;
  const tierB = T >= 12, tierC = T >= 17, top = tierC ? 17 : tierB ? 12 : 6;
  const elderTopDy = (Math.max(3, Math.min(5, Math.floor((SEA - 2 - p.y) / 3))) - 1) * 3 + 1;
  const plan = monumentRoomGraph(t.seed, p);
  const wall = (x: number, y: number, z: number) => (hash3(x, y, z, s) < 0.28 ? pr : pb);
  const door = (a: number, b: number) => Math.abs(a) <= 2 || Math.abs(b) <= 2;
  const x0 = ox === undefined ? p.x - H : Math.max(p.x - H, ox - 1), x1 = ox === undefined ? p.x + H + 1 : Math.min(p.x + H + 1, ox + 17);
  const z0 = oz === undefined ? p.z - H : Math.max(p.z - H, oz - 1), z1 = oz === undefined ? p.z + H + 1 : Math.min(p.z + H + 1, oz + 17);

  // Helper: check if (dx, dz) lies inside one of the 23 giant 4×4 foundation pillars
  const inGiantPillar = (dx: number, dz: number): boolean => {
    for (const [px, pz] of MONUMENT_PILLARS) {
      if (dx >= px - 2 && dx <= px + 1 && dz >= pz - 2 && dz <= pz + 1) return true;
    }
    return false;
  };

  // 1. Base platform, 23 giant 4×4 seabed pillars, stepped pyramid shell, asymmetric wings, front entrance arch & corner towers.
  for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
    const dx = x - p.x, dz = z - p.z, ax = Math.abs(dx), az = Math.abs(dz), m = Math.max(ax, az);
    const shaft = ax <= 3 && az <= 3;
    if (inGiantPillar(dx, dz) || m >= 27 || m <= 3) {
      for (let y = Math.max(t.height(x, z) + 1, p.y - 16); y < p.y; y++) put(x, y, z, pb, true);
    }
    for (let dy = 0; dy <= top; dy++) {
      let b = water;
      const y = p.y + dy;
      if (dy === 0) {
        b = (ax % 8 === 0 || az % 8 === 0) ? dp : ((ax + az) === 16 || (ax === 10 && az === 10)) ? lan : hash2(x, z, s + 1) < 0.25 ? pr : pb;
      } else if (dy <= 5) {
        if (m >= 27) {
          const frontArch = dz <= -27 && ax <= 3 && dy <= 4;
          b = (door(dx, dz) && dy <= 4) || frontArch ? water : dy === 3 && ((dx + dz) & 3) === 0 ? lan : dy === 5 ? dp : wall(x, y, z);
        } else if (m === 20) {
          b = door(dx, dz) && dy <= 4 ? water : dy === 4 && ((dx + dz) & 3) === 0 ? lan : wall(x, y, z);
        } else if (m > 20 && m < 27) {
          if (dy === 1 && ((ax + az) & 7) === 0) b = lan;
          else if (ax === 24 && az % 6 === 0) b = (dy === 3 ? lan : pb);
          else if (dz <= -21 && ax >= 4 && ax <= 6 && (dy === 1 || dy === 5 || ax === 6)) b = ax === 5 && dy === 3 ? lan : dp;
          // Asymmetric wing interiors: one wing is `wing_with_room` (enclosed colonnade pillar at dz=±6), the other is `wing_with_open_area`
          const isRoomWing = dx < 0 ? plan.leftWingHasRoom : !plan.leftWingHasRoom;
          if (isRoomWing && ax === 23 && Math.abs(dz) === 6) b = dy === 3 ? lan : dp;
        }
      } else if (dy === 6) {
        b = shaft ? water : (m <= 29 ? (m >= 28 || m === 20 ? dp : wall(x, y, z)) : water);
      } else if (tierB && dy <= 11) {
        if (m >= 20 && m <= 21) b = door(dx, dz) && dy >= 8 && dy <= 10 ? water : dy === 9 && ((dx + dz) & 3) === 0 ? lan : wall(x, y, z);
        else if (ax >= 22 && ax <= 26 && az <= 18 && dy <= 8) {
          const wingEdge = ax === 22 || ax === 26 || az === 18;
          b = dy === 8 ? (wingEdge ? dp : pb) : wingEdge && dy === 7 && (az % 4 === 0) ? lan : wingEdge ? pb : water;
        }
      } else if (tierB && dy === 12) {
        b = m <= 21 && !shaft ? (m === 21 ? dp : wall(x, y, z)) : water;
      } else if (tierC && dy <= 16) {
        if (m >= 12 && m <= 13) b = door(dx, dz) && dy >= 14 && dy <= 15 ? water : dy === 15 && ((dx + dz) & 3) === 0 ? lan : wall(x, y, z);
        else if (m === 6 && dy >= 13 && dy <= 15) {
          if (ax === 6 && az === 6) b = dy === 14 ? lan : dp;
          else if ((ax === 6 && az === 3) || (az === 6 && ax === 3)) b = pb;
        }
      } else if (tierC && dy === 17) {
        b = m <= 13 && !shaft ? (m === 13 || m <= 5 ? dp : wall(x, y, z)) : water;
      }
      put(x, y, z, b, true);
    }
    if (tierC && m <= 5 && T >= 19) {
      const capH = 22;
      for (let dy = 18; dy <= capH; dy++) {
        if (m <= Math.max(1, 5 - (dy - 18))) put(x, p.y + dy, z, (ax === az && dy === capH) ? lan : dp, true);
      }
    }
    if (ax >= 27 && az >= 27) {
      const h = Math.min(14, T - 1);
      for (let dy = 6; dy <= h; dy++) put(x, p.y + dy, z, dy === h ? lan : (dy & 1 ? dp : pb), true);
    }
  }

  const A = (dx: number, dy: number, dz: number, b: number) => {
    const x = p.x + dx, z = p.z + dz;
    if ((ox === undefined || (x >= ox - 1 && x <= ox + 17)) && (oz === undefined || (z >= oz - 1 && z <= oz + 17))) put(x, p.y + dy, z, b, true);
  };

  // 2. Build the 49-unit procedural room blueprints (DXY, DYZ, DZ, DX, DY, Sponge, Plus-shaped, Four-pillar, Dark prismarine).
  for (const r of plan.rooms) {
    if (r.kind === 'core' || r.kind === 'entry') continue;
    const cx = (r.gx - 2) * 7, cz = (r.gz - 1.5) * 7 | 0;
    const baseDy = r.gy === 0 ? 1 : r.gy === 1 ? 7 : 13;
    if (baseDy + 3 > top) continue;
    if (r.kind === 'dxy' && tierB) {
      // DXY room (2×1×2): two hollow pillars coming up with openings facing top-center and 4 sea lanterns at corners
      for (const sx of [-2, 2]) for (const sz of [-1, 1]) {
        for (let dy = 0; dy <= 7; dy++) if ( baseDy + dy <= top) A(cx + sx, baseDy + dy, cz + sz, dy === 3 || dy === 4 ? lan : pb);
      }
      A(cx, 6, cz, water);
    } else if (r.kind === 'dyz' && tierB) {
      // DYZ room (1×2×2): 2×2 pillar of dark prismarine and sea lanterns in the middle, framed upper ledges
      for (const sx of [0, 1]) for (const sz of [0, 1]) {
        for (let dy = 0; dy <= 7; dy++) if (baseDy + dy <= top) A(cx + sx, baseDy + dy, cz + sz, dy === 2 || dy === 5 ? lan : dp);
      }
    } else if (r.kind === 'dz') {
      // DZ room (1×2×1): open-centered prismarine bricks structure in the middle with sea lanterns on the 4 corners
      for (const sx of [-2, 2]) for (const sz of [-2, 2]) {
        for (let dy = 0; dy <= 3; dy++) A(cx + sx, baseDy + dy, cz + sz, dy === 2 ? lan : pb);
      }
    } else if (r.kind === 'dx') {
      // DX room (2×1×1): U-shaped prismarine brick outcropping on floor & ceiling with prismarine & 4 corner sea lanterns in middle
      for (const sx of [-2, 2]) for (const sz of [-2, 2]) {
        A(cx + sx, baseDy, cz + sz, pb);
        A(cx + sx, baseDy + 1, cz + sz, pr);
        A(cx + sx, baseDy + 2, cz + sz, lan);
        A(cx + sx, baseDy + 3, cz + sz, pb);
      }
    } else if (r.kind === 'dy' && tierB) {
      // DY room (1×1×2): tall room with 2×2 prismarine brick corners midway up (inner corner missing)
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) A(cx + dx, 6, cz + dz, water);
      for (const [sx, sz] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) {
        A(cx + sx, baseDy + 3, cz + sz, pb);
        A(cx + sx, baseDy + 4, cz + sz, lan);
      }
    } else if (r.kind === 'small_plus') {
      // Plus-shaped small room: 2×2 prismarine bricks at floor/ceiling in each corner, sea lanterns at middle level
      for (const sx of [-2, 2]) for (const sz of [-2, 2]) {
        A(cx + sx, baseDy, cz + sz, pb);
        A(cx + sx, baseDy + 2, cz + sz, lan);
        A(cx + sx, baseDy + 3, cz + sz, pb);
      }
    } else if (r.kind === 'small_pillars') {
      // Four-pillar small room: four 1×1 pillars of prismarine bricks and a sea lantern (+ optional 2×2 central pillar)
      for (const sx of [-2, 2]) for (const sz of [-2, 2]) {
        A(cx + sx, baseDy, cz + sz, pb); A(cx + sx, baseDy + 1, cz + sz, lan); A(cx + sx, baseDy + 2, cz + sz, pb);
      }
      if (r.centralPillar) for (let dy = 0; dy <= 3; dy++) A(cx, baseDy + dy, cz, dy & 1 ? pr : pb);
    } else if (r.kind === 'small_dark') {
      // Dark prismarine small room: dark prismarine wall lining (+ optional 2×2 central pillar)
      for (const sx of [-2, 2]) for (const sz of [-2, 2]) A(cx + sx, baseDy + 1, cz + sz, dp);
      if (r.centralPillar) for (let dy = 0; dy <= 3; dy++) A(cx, baseDy + dy, cz, dy & 1 ? pr : pb);
    }
  }

  // 3. Core room (2×2×2 units): dark prismarine shell encasing the 8 gold blocks, sea lanterns, treasure chest, framed crystal.
  for (let dz = -16; dz <= -10; dz++) for (let dx = -3; dx <= 3; dx++) for (let dy = 1; dy <= 5; dy++) {
    const edge = Math.abs(dx) === 3 || dz === -16 || dz === -10;
    A(dx, dy, dz, edge && !(dz === -10 && Math.abs(dx) <= 1 && dy <= 3) ? dp : water);
  }
  for (let dz = -14; dz <= -13; dz++) for (let dx = -1; dx <= 0; dx++) for (let dy = 1; dy <= 2; dy++) A(dx, dy, dz, gold);
  for (const [dx, dz] of [[-2, -15], [2, -15], [-2, -11], [2, -11]]) A(dx, 3, dz, lan);
  if (ox === undefined || (p.x + 2 >= ox - 1 && p.x + 2 <= ox + 17 && p.z - 15 >= oz! - 1 && p.z - 15 <= oz! + 17)) chest(put, t, p.x + 2, p.y + 1, p.z - 15, 2, 'monument_treasure');
  if (ox === undefined || (p.x >= ox - 1 && p.x <= ox + 17 && p.z - 15 >= oz! - 1 && p.z - 15 <= oz! + 17)) itemFrame(put, t, p.x, p.y + 3, p.z - 15, 0, 'monument_frame');

  // 4. Wet sponge rooms: dark prismarine / prismarine brick walls, bottom entrance, 6×6 ceiling grid with 1/3 empty, 1/2 1 sponge, 1/6 2 sponges.
  for (const [cx, baseDy, cz] of plan.spongeCentres) {
    if (baseDy + 4 > top) continue;
    for (let dz = -4; dz <= 4; dz++) for (let dx = -4; dx <= 4; dx++) for (let dy = 0; dy <= 4; dy++) {
      const x = cx + dx, z = cz + dz, yy = baseDy + dy, edge = Math.abs(dx) === 4 || Math.abs(dz) === 4;
      let b = water;
      if (edge) b = dz === -4 && Math.abs(dx) <= 1 && dy <= 2 ? water : (dy === 2 ? dp : pb);
      else {
        // Wiki sponge distribution across the 6×6 interior columns: 1/3 empty, 1/2 one sponge (dy=4), 1/6 two sponges (dy=3,4) plus floor/wall sponges
        const colRoll = hash2(x + p.x, z + p.z, s + 5 + baseDy);
        if (dy === 4 && colRoll >= 1 / 3) b = sponge;
        else if (dy === 3 && colRoll >= 5 / 6) b = sponge;
        else if ((dy === 0 || Math.abs(dx) === 3 || Math.abs(dz) === 3) && hash3(x + p.x, yy, z + p.z, s + 5) < 0.58) b = sponge;
      }
      if (!edge && dx === 0 && dz === 0 && dy === 2) b = lan;
      A(x, yy, z, b);
    }
  }

  // 5. Guarantee open water swim space for all 3 Elder Guardians (left wing [-12,1,0], right wing [12,1,0], penthouse [0,elderTopDy,0]).
  for (const [ex, ey, ez] of [[-12, 1, 0], [12, 1, 0], [0, elderTopDy, 0]] as const) {
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) for (let dy = 0; dy <= 1; dy++) {
      if (ey + dy <= top) A(ex + dx, ey + dy, ez + dz, water);
    }
  }

  // 6. Framed prismarine crystals on the inner ring wall.
  for (const [dx, dz, d] of [[-8, -19, 0], [8, 19, 2], [-19, 8, 3], [19, -8, 1]] as const) {
    const x = p.x + dx, z = p.z + dz;
    if ((ox === undefined || (x >= ox - 1 && x <= ox + 17)) && (oz === undefined || (z >= oz - 1 && z <= oz + 17))) itemFrame(put, t, x, p.y + 3, z, d, 'monument_frame');
  }
}

// ---- Shipwreck (All 20 official Java Edition NBT template variants + 8 two-wood pairings) ----------------------------
export const SHIPWRECK_WOOD_PAIRS: readonly [string, string][] = [
  ['oak', 'spruce'],
  ['dark_oak', 'spruce'],
  ['jungle', 'spruce'],
  ['birch', 'spruce'],
  ['oak', 'dark_oak'],
  ['spruce', 'dark_oak'],
  ['birch', 'jungle'],
  ['spruce', 'oak'],
];

/** All 20 official Java Edition shipwreck structure template IDs (`data/minecraft/structure/shipwreck/*.nbt`). */
export const SHIPWRECK_TEMPLATES = [
  'with_mast',
  'with_mast_degraded',
  'rightsideup_full',
  'rightsideup_full_degraded',
  'rightsideup_fronthalf',
  'rightsideup_fronthalf_degraded',
  'rightsideup_backhalf',
  'rightsideup_backhalf_degraded',
  'sideways_full',
  'sideways_full_degraded',
  'sideways_fronthalf',
  'sideways_fronthalf_degraded',
  'sideways_backhalf',
  'sideways_backhalf_degraded',
  'upsidedown_full',
  'upsidedown_full_degraded',
  'upsidedown_fronthalf',
  'upsidedown_fronthalf_degraded',
  'upsidedown_backhalf',
  'upsidedown_backhalf_degraded',
] as const;

export type ShipwreckTemplate = typeof SHIPWRECK_TEMPLATES[number];
export type ShipwreckPosture = 'upright' | 'sideways' | 'upsidedown';
export type ShipwreckCondition = 'with_mast' | 'degraded' | 'split_hull';
export type ShipwreckSection = 'full' | 'fronthalf' | 'backhalf';

export interface ShipwreckSpec {
  template: ShipwreckTemplate;
  hullWood: string;
  frameWood: string;
  rot: number;
  posture: ShipwreckPosture;
  condition: ShipwreckCondition;
  section: ShipwreckSection;
  degraded: boolean;
  degradeRate: number;
}

export function shipwreckVariant(seed: number, x: number, z: number): ShipwreckSpec {
  const s = seed + 7200;
  const pairIdx = Math.floor(hash2(x, z, s + 11) * SHIPWRECK_WOOD_PAIRS.length) % SHIPWRECK_WOOD_PAIRS.length;
  const [hullWood, frameWood] = SHIPWRECK_WOOD_PAIRS[pairIdx];
  const rot = Math.floor(hash2(x, z, s + 12) * 4) & 3;
  const tplIdx = Math.floor(hash2(x, z, s + 14) * SHIPWRECK_TEMPLATES.length) % SHIPWRECK_TEMPLATES.length;
  const template = SHIPWRECK_TEMPLATES[tplIdx];
  const posture: ShipwreckPosture = template.startsWith('sideways') ? 'sideways' : template.startsWith('upsidedown') ? 'upsidedown' : 'upright';
  const section: ShipwreckSection = template.includes('fronthalf') ? 'fronthalf' : template.includes('backhalf') ? 'backhalf' : 'full';
  const degraded = template.endsWith('_degraded');
  const condition: ShipwreckCondition = template.startsWith('with_mast') ? 'with_mast' : section !== 'full' ? 'split_hull' : 'degraded';
  const degradeRate = template === 'with_mast' ? 0.03 : !degraded ? 0.08 : 0.17;
  return { template, hullWood, frameWood, rot, posture, condition, section, degraded, degradeRate };
}

export function shipwreckBuild(t: StructHost, put: Put, p: Site) {
  const seed = t.seed + 7200;
  const spec = shipwreckVariant(t.seed, p.x, p.z);
  const { hullWood, frameWood, rot, posture, condition, section, degradeRate } = spec;
  const planks = bid(hullWood + '_planks', 'oak_planks');
  const deckId = bid(frameWood + '_planks', 'spruce_planks');
  const log = bid(frameWood + '_log', 'spruce_log');
  const fence = bid(frameWood + '_fence', 'oak_fence');
  const hullSlab = bid(hullWood + '_slab', 'oak_slab');
  const trapdoor = bid(hullWood + '_trapdoor', 'oak_trapdoor');
  const water = bid('water');
  const stairsName = hullWood + '_stairs';
  const frameStairsName = frameWood + '_stairs';

  // Fronthalf / backhalf / split_hull templates offset the broken half laterally by 1 block across a midships hull fracture
  const splitShift = (i: number) => (section === 'fronthalf' && i < -2 ? -1 : section === 'backhalf' && i > 2 ? 1 : 0);
  const XZ = (i: number, w: number): [number, number] => {
    const ww = w + splitShift(i);
    return rot === 0 ? [p.x + i, p.z + ww] : rot === 1 ? [p.x - ww, p.z + i] : rot === 2 ? [p.x - i, p.z - ww] : [p.x + ww, p.z - i];
  };
  const D = (d: number) => (d + rot) & 3;
  const P = (i: number, dy: number, w: number, b: number) => { const [x, z] = XZ(i, w); put(x, p.y + dy, z, b, true); };
  const hw = (i: number) => (Math.abs(i) >= 9 ? 1 : Math.abs(i) >= 6 ? 2 : 3);
  const decay = (i: number, dy: number, w: number, k: number) => hash3(i + p.x, dy + k, w + p.z, seed) < degradeRate;
  const maxDy = Math.max(8, SEA - 2 - p.y);
  const insideFill = p.y + 3 < SEA ? water : 0;

  // 1. Hull, keel, transverse ribs, cargo hold, main deck & gunwale rails.
  for (let i = -10; i <= 10; i++) {
    const h = hw(i);
    const isBreach = (section === 'fronthalf' && i === -2) || (section === 'backhalf' && i === 2);
    const isRib = i === -6 || i === -2 || i === 2 || i === 6;
    for (let w = -3; w <= 3; w++) for (let dy = 0; dy <= 5; dy++) {
      if (Math.abs(w) > h) {
        if (Math.abs(w) <= 3 && dy <= 4 && Math.abs(i) <= 10) P(i, dy, w, 0);
        continue;
      }
      if (isBreach && dy >= 2 && Math.abs(w) < h) {
        P(i, dy, w, insideFill);
        continue;
      }
      const edge = Math.abs(w) === h, tip = Math.abs(i) === 10;
      let b = 0;
      if (dy === 0) {
        b = w === 0 ? log : edge && Math.abs(i) <= 7 ? cell(stairsName, stairsUp(D(w > 0 ? 2 : 0), true), 'oak_stairs') : deckId;
      } else if (dy <= 2) {
        if (edge || tip) {
          b = decay(i, dy, w, 1) && dy === 2 ? insideFill : (isRib && dy === 1 ? log : planks);
        } else if (isRib && Math.abs(w) === h - 1 && dy === 1) {
          b = cell(frameStairsName, stairsUp(D(w > 0 ? 0 : 2)), 'oak_stairs');
        } else {
          b = insideFill;
        }
      } else if (dy === 3) {
        const hatch = (i === 2 || i === 3) && w === 0;
        if (hatch) b = trapdoor;
        else if (edge) b = planks;
        else b = decay(i, dy, w, 2) ? insideFill : deckId;
      } else if (dy === 4) {
        if (edge && !decay(i, dy, w, 3)) {
          b = Math.abs(i) <= 4 && (i & 1) === 0 ? fence : cell(stairsName, stairsUp(D(w > 0 ? 0 : 2)), 'oak_stairs');
        } else b = 0;
      } else b = 0;
      P(i, dy, w, b);
    }
  }

  // 2. Posture-specific structural features (upside-down turtled keel arch / sideways capsized canted strakes).
  if (posture === 'upsidedown') {
    for (let i = -8; i <= 8; i++) {
      P(i, 6, 0, log);
      for (const w of [-1, 1]) if (!decay(i, 5, w, 7)) P(i, 5, w, cell(stairsName, stairsUp(D(w > 0 ? 2 : 0)), 'oak_stairs'));
    }
  } else if (posture === 'sideways') {
    for (let i = -6; i <= 6; i += 2) {
      P(i, 5, 3, planks);
      P(i, 6, 2, cell(stairsName, stairsUp(D(2)), 'oak_stairs'));
    }
  }

  // 3. Forecastle bow deck (i = 7..10, dy = 4..5), stempost & bowsprit.
  for (let i = 7; i <= 10; i++) {
    const h = hw(i);
    for (let w = -h; w <= h; w++) {
      const edge = Math.abs(w) === h;
      P(i, 4, w, edge ? planks : deckId);
      if (edge && i < 10 && !decay(i, 5, w, 6)) P(i, 5, w, i === 7 ? cell(stairsName, stairsUp(D(1)), 'oak_stairs') : fence);
    }
  }
  P(6, 4, -1, cell(stairsName, stairsUp(D(1)), 'oak_stairs'));
  P(6, 4, 1, cell(stairsName, stairsUp(D(1)), 'oak_stairs'));
  for (let k = 0; k < 4; k++) P(11 + k, 4 + (k >= 2 ? 1 : 0), 0, log);
  P(10, 5, 0, cell(stairsName, stairsUp(D(1)), 'oak_stairs'));

  // 4. Three masts (foremast i=6, mainmast i=1, mizzenmast i=-5), cross-yards & crow's nest.
  const mast = (i: number, fullH: number) => {
    const h = condition === 'with_mast' ? fullH : Math.min(fullH, 6 + Math.floor(hash2(p.x + i, p.z, seed + 13) * 3));
    const topY = Math.min(h, maxDy);
    for (let dy = 3; dy <= topY; dy++) {
      const wOff = posture === 'sideways' && dy >= 6 ? 1 : 0;
      P(i, dy, wOff, log);
    }
    if (condition === 'with_mast' && topY >= 8) {
      const wOff = posture === 'sideways' ? 1 : 0;
      for (let w = -2; w <= 2; w++) P(i, topY - 2, w + wOff, w === 0 ? log : fence);
      if (i === 1 && topY >= 10) {
        for (let di = -1; di <= 1; di++) for (let dw = -1; dw <= 1; dw++) if (di || dw) P(i + di, topY - 1, dw + wOff, hullSlab);
      }
    }
  };
  mast(1, 12);
  mast(-5, 9 + Math.floor(hash2(p.x, p.z, seed + 13) * 2));
  if (condition === 'with_mast') mast(6, 9);

  // 5. Two-tier Stern Castle: Captain's Map Cabin (dy = 4..7) & Poop Deck (dy = 7..8).
  for (let i = -9; i <= -5; i++) for (let w = -2; w <= 2; w++) for (let dy = 4; dy <= 7; dy++) {
    const edge = i === -9 || i === -5 || Math.abs(w) === 2, corner = (i === -9 || i === -5) && Math.abs(w) === 2, roof = dy === 7;
    if (roof) {
      P(i, dy, w, decay(i, dy, w, 4) ? 0 : (edge ? cell(stairsName, stairsUp(D(i === -9 ? 1 : i === -5 ? 3 : w > 0 ? 0 : 2)), 'oak_stairs') : deckId));
    } else if (edge) {
      const doorway = i === -5 && w === 0 && dy <= 5;
      const window = dy === 5 && ((i === -9 && Math.abs(w) <= 1) || (i === -7 && Math.abs(w) === 2));
      P(i, dy, w, doorway ? 0 : window ? fence : corner ? log : planks);
    } else {
      P(i, dy, w, 0);
    }
  }
  for (let w = -2; w <= 2; w++) P(-9, 8, w, fence);
  P(-6, 8, 0, fence);
  const [cx, cz] = XZ(-8, 1);
  chest(put, t, cx, p.y + 4, cz, D(1), 'shipwreck_map');
  { const [fx, fz] = XZ(-8, -1); itemFrame(put, t, fx, p.y + 5, fz, D(3), 'shipwreck_frame'); }
  { const [lx, lz] = XZ(-7, -1); lantern(put, lx, p.y + 4, lz); }
  P(-7, 4, 0, fence);
  P(-7, 5, 0, bid(hullWood + '_pressure_plate', 'oak_pressure_plate'));

  // 6. Cargo Hold & Stern Treasure Hold: bulkhead partition with doorway, ladder below hatch, 3 supply chests, 3 barrels, 1 treasure chest.
  for (let w = -2; w <= 2; w++) for (let dy = 1; dy <= 2; dy++) P(-3, dy, w, w === 0 && dy <= 2 ? insideFill : planks);
  for (let dy = 1; dy <= 2; dy++) P(1, dy, 0, cell('ladder', ladderOn(D(3))));
  for (const [i, w] of [[2, 2], [4, -2], [0, -2]] as const) {
    const [x, z] = XZ(i, w);
    chest(put, t, x, p.y + 1, z, D(w > 0 ? 0 : 2), 'shipwreck_supply');
  }
  for (const [i, w] of [[5, 2], [6, 1], [-1, 2]] as const) {
    const [x, z] = XZ(i, w);
    barrel(put, t, x, p.y + 1, z, D(w > 0 ? 0 : 2));
  }
  { const [x, z] = XZ(-7, 0); chest(put, t, x, p.y + 1, z, D(1), 'shipwreck_treasure'); }
  { const [x, z] = XZ(-6, 1); put(x, p.y + 1, z, cell(stairsName, stairsUp(D(1)), 'oak_stairs'), true); }
  { const [tx, tz] = XZ(-7, -1); put(tx, p.y + 1, tz, cell('torch', attachOn(D(0)), 'torch'), true); }
}
