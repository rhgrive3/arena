// Structures: end ship, jungle temple, igloo, and the 1.21 desert pyramid (Minecraft Wiki: "End City#Ship", "Jungle Pyramid", "Igloo", "Desert pyramid").
import { type Put, type StructHost, DX, DZ, bid, cell, hash2, hash3, tag, bed, stairsUp, ladderOn, attachOn, rsFacing, stoneBrick, mossyCobble, PANE_X, PANE_Z } from './common';
import { chest } from './decor';

interface Site { x: number; y: number; z: number }

// ======================================================================================================================
// End ship – floats beside an end city. Dragon head on the bow, a brewing stand with two Instant Health II potions and,
// in the stern of the hold, two treasure chests flanking the item frame that holds the elytra.
// ======================================================================================================================
/** Offsets from the ship origin (x = centre line, y = keel, z = bow). */
export const END_SHIP = {
  length: 25,
  dragonHead: [0, 5, -2], brewingStand: [0, 1, 12], elytraFrame: [0, 2, 21], chests: [[-1, 1, 21], [1, 1, 21]], mastTop: [0, 17, 11],
} as const;
const shipHalfWidth = (dz: number) => (dz < 0 || dz > 24 ? -1 : dz === 0 ? 0 : dz === 1 || dz === 24 ? 1 : dz <= 3 || dz >= 22 ? 2 : 3);

export function endShip(t: StructHost, put: Put, x: number, y: number, z: number) {
  const P = (dx: number, dy: number, dz: number, b: number) => put(x + dx, y + dy, z + dz, b, true);
  const purpur = bid('purpur_block', 'end_stone'), pillar = bid('purpur_pillar', 'purpur_block'), bricks = bid('end_stone_bricks', 'end_stone'), slab = bid('purpur_slab', 'purpur_block');
  const glass = bid('magenta_stained_glass', 'glass'), rod = bid('end_rod', 'torch'), obsidian = bid('obsidian');
  for (let dz = 0; dz <= 24; dz++) {
    const hw = shipHalfWidth(dz), hold = dz >= 4 && dz <= 21;
    for (let dx = -hw; dx <= hw; dx++) {
      const side = Math.abs(dx) === hw;
      if (!side || hw === 0) P(dx, 0, dz, dx === 0 ? obsidian : purpur);                               // keel
      for (let dy = 1; dy <= 3; dy++) P(dx, dy, dz, side || !hold ? (side && dz % 4 === 0 ? pillar : purpur) : 0);   // hull + hold
      P(dx, 4, dz, purpur);                                                                             // deck
      for (let dy = 5; dy <= 12; dy++) P(dx, dy, dz, 0);
      if (side && dz >= 4 && dz <= 17) P(dx, 5, dz, slab);                                              // bulwark
      if (dz >= 18) {                                                                                   // stern cabin
        const wall = side || dz === 18 || dz === 24;
        for (let dy = 5; dy <= 7; dy++) P(dx, dy, dz, wall ? (dy === 6 && side && (dz === 20 || dz === 21) ? glass : dz === 18 && dx === 0 && dy <= 6 ? 0 : purpur) : 0);
        P(dx, 8, dz, purpur);
        if (side || dz === 24) P(dx, 9, dz, slab);
      }
    }
  }
  // Bowsprit with the dragon head looking ahead.
  P(0, 5, 0, bricks); P(0, 5, -1, bricks);
  P(0, 5, -2, cell('dragon_head', 2, 'obsidian'));
  // Mast, yard and crow's nest.
  for (let dy = 5; dy <= 16; dy++) P(0, dy, 11, pillar);
  for (let dx = -3; dx <= 3; dx++) if (dx) { P(dx, 12, 11, bricks); if (Math.abs(dx) === 3) P(dx, 11, 11, rod); }
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (dx || dz) P(dx, 16, 11 + dz, slab);
  P(0, 17, 11, rod);
  // Hold: hatch ladder, brewing stand, treasure chests and the elytra frame on the stern bulkhead.
  for (let dy = 1; dy <= 4; dy++) P(2, dy, 4, cell('ladder', ladderOn(0)));
  const [bx, by, bz] = END_SHIP.brewingStand;
  P(bx, by - 1, bz, obsidian); P(bx, by, bz, bid('brewing_stand', 'obsidian')); tag(t, x + bx, y + by, z + bz, 'end_ship_brewing');
  for (const [cx, cy, cz] of END_SHIP.chests) { P(cx, cy, cz, bid('chest')); tag(t, x + cx, y + cy, z + cz, 'end_city_treasure'); }
  const [fx, fy, fz] = END_SHIP.elytraFrame;
  P(fx, fy, fz, cell('item_frame', ladderOn(2), 'ladder')); tag(t, x + fx, y + fy, z + fz, 'end_ship_elytra');
  for (const dz of [8, 16]) for (const dx of [-2, 2]) P(dx, 3, dz, rod);
  P(0, 7, 21, rod);
}

// ======================================================================================================================
// Jungle temple – 12×15 mossy cobblestone stepped pyramid (Minecraft Wiki "Jungle pyramid").
// Exterior: 40% mossy / 60% cobblestone processor, front entrance staircase, stepped cornice of cobblestone stairs,
// chiseled stone brick relief motifs, arrow-slit windows, and hanging exterior & interior vines.
// Interior: Main hall with central floor opening overlooking the basement, staircase to the upper observation room,
// staircase down to the basement, two tripwire-dispenser arrow traps (corridor trap + chest-alcove trap), and the
// three-lever combination lock (ON-OFF-ON) operating two sticky pistons that open the secret vault.
// ======================================================================================================================
/** Lever states that open the vault (index 0 = the lever next to the stairs). */
export const JUNGLE_CODE: readonly boolean[] = [true, false, true];
export interface JungleTempleParts {
  levers: [number, number, number][]; supports: [number, number, number][]; torches: [number, number, number][]; dust: [number, number, number][];
  pistons: [number, number, number][]; heads: [number, number, number][]; door: [number, number, number][]; vault: [number, number, number];
  hooks: [number, number, number][]; strings: [number, number, number][]; trapDust: [number, number, number][]; dispenser: [number, number, number];
  secondaryTrap: { hooks: [number, number, number][]; string: [number, number, number]; dust: [number, number, number][]; dispenser: [number, number, number] };
  chests: [number, number, number][]; corridor: [number, number, number];
}
/** World coordinates of the temple's mechanisms. Plan axes: a = along (world z, 0..14), b = across (world x, 0..11). */
export function jungleTempleParts(p: Site): JungleTempleParts {
  const f = p.y - 4, W = (a: number, yy: number, b: number): [number, number, number] => [p.x - 6 + b, yy, p.z - 7 + a];
  return {
    levers: [W(1, f + 1, 5), W(2, f + 1, 5), W(3, f + 1, 5)], supports: [W(1, f + 1, 4), W(2, f + 1, 4), W(3, f + 1, 4)],
    torches: [W(1, f + 1, 3), W(3, f + 1, 3)],
    dust: [W(2, f + 1, 3), W(2, f + 1, 2), W(3, f + 1, 2), W(4, f + 1, 2), W(5, f + 1, 2), W(5, f + 1, 3)],
    pistons: [W(5, f, 4), W(5, f + 1, 4)], heads: [W(6, f, 4), W(6, f + 1, 4)], door: [W(7, f, 4), W(7, f + 1, 4)], vault: W(8, f, 1),
    hooks: [W(10, f, 4), W(10, f, 7)], strings: [W(10, f, 5), W(10, f, 6)], trapDust: [W(11, f, 8), W(12, f, 8), W(12, f, 7)], dispenser: W(12, f, 6),
    secondaryTrap: {
      hooks: [W(9, f, 4), W(9, f, 7)], string: W(9, f, 5),
      dust: [W(9, f, 8), W(8, f, 8)], dispenser: W(8, f, 7),
    },
    chests: [W(11, f, 5), W(8, f, 1)], corridor: W(6, f, 5),
  };
}

export function jungleTemple(t: StructHost, put: Put, p: Site) {
  const Y = p.y, f = Y - 4, x0 = p.x - 6, z0 = p.z - 7, stone = mossyCobble(t.seed + 8100), s = t.seed + 8100;
  const Q = (a: number, yy: number, b: number, block: number) => put(x0 + b, yy, z0 + a, block, true);
  const M = (a: number, yy: number, b: number) => put(x0 + b, yy, z0 + a, stone(x0 + b, yy, z0 + a), true);
  const at = (c: [number, number, number], block: number) => put(c[0], c[1], c[2], block, true);
  const chis = bid('chiseled_stone_bricks', 'stone_bricks');

  // 1. Beardifier foundation down to terrain ground + solid basement core + three stepped pyramid tiers above ground.
  for (let a = 0; a <= 14; a++) for (let b = 0; b <= 11; b++) {
    const wx = x0 + b, wz = z0 + a, g = t.height(wx, wz);
    for (let yy = Math.min(g, Y - 10); yy <= Y - 1; yy++) M(a, yy, b);
    const edge = a === 0 || a === 14 || b === 0 || b === 11;
    for (let yy = Y; yy <= Y + 4; yy++) if (edge) M(a, yy, b); else Q(a, yy, b, 0);
    M(a, Y + 5, b);
    const in2 = a >= 1 && a <= 13 && b >= 1 && b <= 10, edge2 = a === 1 || a === 13 || b === 1 || b === 10;
    for (let yy = Y + 6; yy <= Y + 8; yy++) if (in2 && edge2) M(a, yy, b); else Q(a, yy, b, 0);
    if (in2) M(a, Y + 9, b);
    if (a >= 4 && a <= 10 && b >= 4 && b <= 7) M(a, Y + 10, b);
  }

  // 2. Stepped pyramid exterior cornices, chiseled stone brick relief motifs, entrance stairway & arrow-slit windows.
  for (const b of [5, 6]) {
    for (let yy = Y; yy <= Y + 2; yy++) Q(14, yy, b, 0);
    Q(15, Y - 1, b, cell('cobblestone_stairs', stairsUp(0), 'cobblestone'));
  }
  for (const b of [4, 7]) for (let yy = Y; yy <= Y + 3; yy++) Q(14, yy, b, yy === Y + 2 ? chis : stone(x0 + b, yy, z0 + 14));
  // Chiseled stone brick glyphs on exterior & interior walls (vanilla Jungle Pyramid signature)
  for (const b of [5, 6]) { Q(0, Y + 2, b, chis); Q(0, Y + 1, b, chis); Q(13, Y + 7, b, chis); Q(1, Y + 7, b, chis); }
  for (const b of [0, 11]) { Q(7, Y + 1, b, 0); Q(7, Y + 2, b, 0); Q(4, Y + 2, b, chis); Q(10, Y + 2, b, chis); }
  for (const b of [1, 10]) { Q(7, Y + 7, b, 0); Q(4, Y + 7, b, chis); Q(10, Y + 7, b, chis); }
  // Upper-tier decorative stairs around the crown
  for (let b = 3; b <= 8; b++) {
    Q(3, Y + 10, b, cell('cobblestone_stairs', stairsUp(2), 'cobblestone'));
    Q(11, Y + 10, b, cell('cobblestone_stairs', stairsUp(0), 'cobblestone'));
  }
  // Main floor central lightwell opening (vanilla feature overlooking the basement corridor) + interior pillars
  Q(6, Y - 1, 5, 0); Q(6, Y - 1, 6, 0);
  for (const [pa, pb] of [[4, 3], [10, 3]]) for (let yy = Y; yy <= Y + 4; yy++) M(pa, yy, pb);
  // Stairs to the upper floor
  for (let i = 0; i <= 5; i++) {
    Q(10 - i, Y + i, 9, cell('cobblestone_stairs', stairsUp(0), 'cobblestone'));
    for (let yy = Y; yy < Y + i; yy++) M(10 - i, yy, 9);
    for (let yy = Y + i + 1; yy <= Y + i + 3; yy++) Q(10 - i, yy, 9, 0);
  }
  // Vines on the outer walls and upper interior walls (only where nothing else was written).
  for (let a = -1; a <= 15; a++) for (let b = -1; b <= 12; b++) {
    if (a >= 0 && a <= 14 && b >= 0 && b <= 11) continue;
    if ((a < 0 || a > 14) && (b < 0 || b > 11)) continue;
    for (let yy = Y + 1; yy <= Y + 4; yy++) if (hash3(a, yy, b, s + 1) < 0.25 && !(a === 15 && (b === 5 || b === 6))) put(x0 + b, yy, z0 + a, bid('vine', 'air'), false);
  }

  // ---- Basement -----------------------------------------------------------------------------------------------------
  const J = jungleTempleParts(p);
  for (let a = 1; a <= 11; a++) for (const b of [5, 6]) for (let yy = f; yy <= f + 2; yy++) Q(a, yy, b, 0);   // trap corridor
  for (let i = 0; i <= 3; i++) {                                                                             // stairs down from the ground floor
    Q(1, Y - 1 - i, 10 - i, cell('cobblestone_stairs', stairsUp(1), 'cobblestone'));
    for (let yy = Y - i; yy <= Y + 2 - i; yy++) Q(1, yy, 10 - i, 0);
  }
  // Chiseled stone bricks backing the 3 levers
  for (const a of [1, 2, 3]) Q(a, f + 2, 4, chis);
  // Three levers → NOT / pass / NOT → one dust line → two sticky pistons holding the vault wall shut.
  J.levers.forEach(c => at(c, cell('lever', attachOn(3))));
  J.torches.forEach(c => at(c, cell('redstone_torch', attachOn(1), 'torch')));
  [15, 14, 15, 14, 13, 12].forEach((power, i) => at(J.dust[i], cell('redstone_wire', power, 'air')));
  J.pistons.forEach(c => at(c, cell('sticky_piston', rsFacing(2) | 8, 'piston')));
  J.heads.forEach(c => at(c, cell('piston_head', rsFacing(2) | 8, 'oak_planks')));
  J.door.forEach(c => at(c, bid('mossy_cobblestone', 'cobblestone')));
  for (let a = 7; a <= 8; a++) for (let b = 1; b <= 3; b++) for (let yy = f; yy <= f + 1; yy++) Q(a, yy, b, 0);   // hidden vault
  at(J.chests[1], bid('chest')); tag(t, ...J.chests[1], 'jungle_temple');
  // Arrow trap: tripwire across the corridor → hook → dust → dispenser at the end of the corridor, camouflaged behind vines.
  at(J.hooks[0], cell('tripwire_hook', attachOn(3), 'air')); at(J.hooks[1], cell('tripwire_hook', attachOn(1), 'air'));
  J.strings.forEach(c => at(c, cell('tripwire', 1, 'air')));
  J.trapDust.forEach(c => at(c, bid('redstone_wire', 'air')));
  at(J.dispenser, cell('dispenser', rsFacing(0), 'cobblestone')); tag(t, ...J.dispenser, 'jungle_temple_dispenser');
  Q(11, f + 1, 6, bid('vine', 'air'));
  // Secondary tripwire trap around the corner in front of the corridor chest (camouflaged behind vines).
  at(J.secondaryTrap.hooks[0], cell('tripwire_hook', attachOn(3), 'air'));
  at(J.secondaryTrap.hooks[1], cell('tripwire_hook', attachOn(1), 'air'));
  at(J.secondaryTrap.string, cell('tripwire', 1, 'air'));
  Q(9, f, 6, cell('tripwire', 1, 'air'));
  J.secondaryTrap.dust.forEach(c => at(c, bid('redstone_wire', 'air')));
  at(J.secondaryTrap.dispenser, cell('dispenser', rsFacing(3), 'cobblestone')); tag(t, ...J.secondaryTrap.dispenser, 'jungle_temple_dispenser');
  Q(8, f + 1, 6, bid('vine', 'air'));
  at(J.chests[0], bid('chest')); tag(t, ...J.chests[0], 'jungle_temple');
}

// ======================================================================================================================
// Igloo – 3-piece NBT assembly (`igloo/top`, `igloo/middle` × 2..9 sections, `igloo/bottom`, Minecraft Wiki "Igloo").
//   • `igloo/top`: snow dome (7×5×8) with 2 ice windows, white & light-gray carpets, red bed, furnace, crafting table,
//     redstone torch, and (when a basement generates, 50% chance) an oak trapdoor hidden under the third white carpet.
//   • `igloo/middle`: 3×3×3 stone-brick vertical shaft repeated 2..9 times (variable depth 14..35 blocks) + 1-block connector
//     ring with ladders running down to the basement ceiling.
//   • `igloo/bottom`: 7×6×9 basement laboratory built from stone bricks, mossy/cracked/chiseled stone bricks and stone,
//     furnished with a brewing stand (Splash Potion of Weakness), 2/3-filled water cauldron, spruce-stairs/slab worktable with
//     potted cactus, cobweb, red carpets hiding a polished andesite block, an oak wall sign (`<---- ---->`), a loot chest
//     (always containing a golden apple), and two iron-bar cells holding an unemployed villager and a cleric zombie villager.
// ======================================================================================================================
export const IGLOO_DEPTH = 14;
export const iglooHasBasement = (seed: number, x: number, z: number) => hash2(x, z, seed + 8200) < 0.5;
/** Variable number of 3-block `igloo/middle` shaft sections (2..9, matching vanilla `random.nextInt(8) + 2`). */
export const iglooShaftSections = (seed: number, x: number, z: number) => 2 + Math.floor(hash2(x, z, seed + 8207) * 8);
/** Orientation of the igloo (0 S, 1 W, 2 N, 3 E). */
export const iglooRotation = (seed: number, x: number, z: number) => Math.floor(hash2(x, z, seed + 8085) * 4) & 3;

export interface IglooParts {
  basement: boolean;
  rot: number;
  shaftSections: number;
  depth: number;
  carpet: [number, number, number];
  trapdoor: [number, number, number];
  ladderTop: [number, number, number];
  floorY: number;
  brewingStand: [number, number, number];
  chest: [number, number, number];
  cauldron: [number, number, number];
  polishedAndesite: [number, number, number];
  sign: [number, number, number];
  pottedCactus: [number, number, number];
  villager: [number, number, number];
  zombieVillager: [number, number, number];
}

function rotXZ(p: Site, rot: number, dx: number, dz: number): [number, number] {
  const r = rot & 3;
  const right = (r + 1) & 3, south = (r + 2) & 3;
  return [p.x + DX[right] * dx + DX[south] * dz, p.z + DZ[right] * dx + DZ[south] * dz];
}

export function iglooParts(seed: number, p: Site): IglooParts {
  const rot = iglooRotation(seed, p.x, p.z);
  const shaftSections = iglooShaftSections(seed, p.x, p.z);
  const depth = shaftSections * 3 + 8;
  const by = p.y - depth;
  const W = (dx: number, yy: number, dz: number): [number, number, number] => {
    const [wx, wz] = rotXZ(p, rot, dx, dz);
    return [wx, yy, wz];
  };
  return {
    basement: iglooHasBasement(seed, p.x, p.z),
    rot, shaftSections, depth,
    carpet: W(0, p.y, -2),
    trapdoor: W(0, p.y - 1, -2),
    ladderTop: W(0, p.y - 2, -2),
    floorY: by,
    brewingStand: W(2, by, -1),
    chest: W(-2, by, -1),
    cauldron: W(2, by, 0),
    polishedAndesite: W(0, by - 1, 1),
    sign: W(0, by + 1, 1),
    pottedCactus: W(-2, by + 1, 0),
    villager: W(-2, by, 3),
    zombieVillager: W(2, by, 3),
  };
}
const domeInside = (dx: number, dy: number, dz: number) => dy >= 0 && dx * dx + dz * dz + dy * dy * 1.44 <= 6.8;

export function igloo(t: StructHost, put: Put, p: Site) {
  const y = p.y, snow = bid('snow_block');
  const G = iglooParts(t.seed, p), rot = G.rot;
  const P = (dx: number, yy: number, dz: number, b: number) => {
    const [wx, wz] = rotXZ(p, rot, dx, dz);
    put(wx, yy, wz, b, true);
  };
  const white = bid('white_carpet', 'air'), gray = bid('light_gray_carpet', 'white_carpet');

  // ---- Piece 1: `igloo/top` (7×5×8 snow dome + 3-block entrance tunnel) ----
  for (let dz = -4; dz <= 4; dz++) for (let dx = -4; dx <= 4; dx++) {
    if (dx * dx + dz * dz <= 17) { P(dx, y - 1, dz, snow); P(dx, y - 2, dz, snow); }
    for (let dy = 0; dy <= 4; dy++) {
      if (domeInside(dx, dy, dz)) {
        const isGray = (Math.abs(dx) === 1 && (dz === 0 || dz === 1)) || (dx === 0 && dz === 2);
        P(dx, y + dy, dz, dy === 0 ? (isGray ? gray : white) : 0);
        continue;
      }
      const shellCell = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, -1, 0]].some(([ax, ay, az]) => domeInside(dx + ax, dy + ay, dz + az));
      if (shellCell) P(dx, y + dy, dz, snow);
    }
  }
  // Entrance tunnel on the front (+dz) side.
  for (let dz = 3; dz <= 5; dz++) {
    P(0, y, dz, 0); P(0, y + 1, dz, 0); P(0, y - 1, dz, snow);
    if (dz > 3) for (const dx of [-1, 1]) { P(dx, y - 1, dz, snow); P(dx, y, dz, snow); P(dx, y + 1, dz, snow); }
    for (let dx = -1; dx <= 1; dx++) P(dx, y + 2, dz, snow);
  }
  P(-3, y + 1, 0, bid('ice', 'glass')); P(3, y + 1, 0, bid('ice', 'glass'));
  const [bedX, bedZ] = rotXZ(p, rot, -2, 0);
  bed(put, bedX, y, bedZ, (2 + rot) & 3);
  P(2, y, -1, bid('furnace')); P(2, y, 0, bid('crafting_table')); P(1, y, 2, bid('redstone_torch', 'torch'));
  if (!G.basement) return;

  // ---- Piece 2: `igloo/middle` (3×3×3 stone-brick vertical shaft × G.shaftSections) ----
  P(0, y - 1, -2, cell('oak_trapdoor', 4, 'oak_planks'));
  P(0, y, -2, white);
  const by = G.floorY, s = t.seed + 8201;
  const sb = bid('stone_bricks'), mossy = bid('mossy_stone_bricks', 'stone_bricks'), cracked = bid('cracked_stone_bricks', 'stone_bricks');
  const chiseled = bid('chiseled_stone_bricks', 'stone_bricks');
  const basementBrick = (wx: number, wy: number, wz: number) => {
    const r = hash3(wx, wy, wz, s);
    return r < 0.14 ? mossy : r < 0.22 ? cracked : r < 0.28 ? chiseled : sb;
  };
  const SB = (dx: number, yy: number, dz: number) => {
    const [wx, wz] = rotXZ(p, rot, dx, dz);
    put(wx, yy, wz, basementBrick(wx, yy, wz), true);
  };

  // ---- Piece 3: `igloo/bottom` (7×6×9 basement laboratory) ----
  for (let yy = by - 1; yy <= by + 3; yy++) for (let dz = -3; dz <= 5; dz++) for (let dx = -3; dx <= 3; dx++) {
    const edge = Math.abs(dx) === 3 || dz === -3 || dz === 5 || yy === by - 1 || yy === by + 3;
    if (edge) SB(dx, yy, dz); else P(dx, yy, dz, 0);
  }
  // Polished andesite & infested stone bricks hidden under the red carpets in the basement (Wiki spec)
  P(0, by - 1, 1, bid('polished_andesite', 'stone_bricks'));
  P(0, by - 1, 0, bid('infested_stone_bricks', 'stone_bricks'));

  // Shaft walls & ladder rungs from trapdoor (y - 2) down to basement floor (by)
  for (let yy = by + 4; yy <= y - 2; yy++) for (let dz = -3; dz <= -1; dz++) for (let dx = -1; dx <= 1; dx++) {
    if (dx || dz !== -2) SB(dx, yy, dz);
  }
  for (let yy = by; yy <= y - 2; yy++) P(0, yy, -2, cell('ladder', ladderOn(rot)));

  // Two holding cells behind iron bars (villager on left dx=-2..-1, zombie villager on right dx=1..2) with central stone-brick divider
  const barsPane = rot % 2 === 0 ? PANE_X : PANE_Z;
  for (let yy = by; yy <= by + 2; yy++) {
    for (const dx of [-2, -1, 1, 2]) P(dx, yy, 2, cell('iron_bars', barsPane, 'stone_bricks'));
    for (let dz = 2; dz <= 4; dz++) SB(0, yy, dz);
  }
  // Oak wall sign `<---- ---->` mounted on the cell divider facing the laboratory
  P(0, by + 1, 1, cell('oak_sign', ladderOn((rot + 2) & 3), 'air'));
  tag(t, ...G.sign, 'igloo_sign');

  // Laboratory furnishings: brewing stand (Splash Potion of Weakness), 2/3 water cauldron, spruce-stairs/slab table, potted cactus, golden-apple chest
  put(...G.brewingStand, bid('brewing_stand', 'cauldron'), true); tag(t, ...G.brewingStand, 'igloo_brewing');
  put(...G.cauldron, cell('cauldron', 2, 'stone_bricks'), true);
  put(...G.chest, bid('chest'), true); tag(t, ...G.chest, 'igloo_chest');

  // Spruce stairs & slab worktable + potted cactus on the left wall
  P(-2, by, 0, cell('spruce_stairs', stairsUp((rot + 3) & 3, true), 'spruce_planks'));
  P(-2, by, 1, cell('spruce_stairs', stairsUp((rot + 2) & 3, true), 'spruce_planks'));
  P(-1, by, 0, cell('spruce_slab', 1, 'spruce_planks'));
  P(-2, by + 1, 0, bid('cactus', 'decorated_pot'));

  // Torches, red carpets, cobwebs
  P(-2, by + 2, 1, cell('torch', attachOn((rot + 3) & 3)));
  P(2, by + 2, 1, cell('torch', attachOn((rot + 1) & 3)));
  P(0, by + 2, -1, cell('torch', attachOn(rot)));
  P(0, by, 0, bid('red_carpet', 'white_carpet'));
  P(0, by, 1, bid('red_carpet', 'white_carpet'));
  P(-2, by + 2, -2, bid('cobweb', 'air'));
  P(2, by + 2, -2, bid('cobweb', 'air'));
}

// ======================================================================================================================
// Desert Pyramid (Java Edition 1.21 `DesertPyramidPiece`, Minecraft Wiki "Desert pyramid"):
//  * 21×21 stepped sandstone pyramid (`-10..+10`) with two 3×4 front towers, orange-terracotta ankh hieroglyphs, crenelated
//    parapets, 5 upper/front entrances (front portico between the two towers, two upper back entrances on the left and right
//    sides near the top of the pyramid at dy = 4..5, and one entrance at the top of each tower connecting via internal stairs
//    to the ground floor), 2nd-floor interior balcony walkway, and open 1×1 skylight window at the apex.
//  * Ground floor: sandstone & orange/blue terracotta wind-rose mosaic with 10 chiseled/cut sandstone colonnade pillars.
//  * Central secret fosse: 4 chests tagged `desert_pyramid` facing inward around a stone pressure plate over a 3×3 TNT grid.
//  * 1.20+ Trails & Tales buried archaeology chamber (`23w14a`+): randomly placed in the back-left or back-right quadrant,
//    with 1 visible `suspicious_sand` block exposed on the top ground-floor layer (`y - 1`, same height as the main floor
//    `blue_terracotta`) at the top of the collapsed sandstone stair shaft leading down into a 5×5 buried room with a second
//    orange/blue terracotta wind-rose floor mosaic, buried `suspicious_sand`, and an intact `decorated_pot`.
// ======================================================================================================================
export interface DesertPyramidSpec {
  rot: number;
  archSide: -1 | 1;
  collapseDepth: number;
  suspiciousCoords: [number, number, number][];
}

export function desertPyramidVariant(seed: number, cx: number, cz: number): DesertPyramidSpec {
  const s = seed + 7600;
  const rot = Math.floor(hash2(cx, cz, s + 1) * 4) & 3;
  const archSide: -1 | 1 = hash2(cx, cz, s + 2) < 0.5 ? -1 : 1;
  const collapseDepth = 1 + (Math.floor(hash2(cx, cz, s + 3) * 3) % 3);
  const XZ = (lx: number, lz: number): [number, number] =>
    rot === 0 ? [cx + lx, cz + lz] : rot === 1 ? [cx - lz, cz + lx] : rot === 2 ? [cx - lx, cz - lz] : [cx + lz, cz - lx];
  const ax0 = archSide < 0 ? -8 : 4;
  // 23w14a+: 1 block of suspicious_sand is always visible on the top layer (dy = -1, ground floor level) above the collapsed stairs
  const [topWx, topWz] = XZ(ax0 + 2, -3);
  const suspiciousCoords: [number, number, number][] = [[topWx, -1, topWz]];
  for (let lz = -8; lz <= -6; lz++) for (let lx = ax0 + 1; lx <= ax0 + 3; lx++) {
    if (hash3(lx + cx, -4, lz + cz, s + 5) < 0.65 || suspiciousCoords.length < 6) {
      const [wx, wz] = XZ(lx, lz);
      suspiciousCoords.push([wx, -4, wz]);
    }
  }
  return { rot, archSide, collapseDepth, suspiciousCoords };
}

export function desertPyramidBuild(
  t: StructHost,
  put: Put,
  foundation: (x: number, y: number, z: number, id: number) => void,
  cx: number,
  cz: number,
) {
  const y = t.height(cx, cz) + 1;
  const spec = desertPyramidVariant(t.seed, cx, cz);
  const { rot, archSide } = spec;
  const ss = bid('sandstone'), cut = bid('cut_sandstone', 'sandstone'), chis = bid('chiseled_sandstone', 'sandstone');
  const smooth = bid('smooth_sandstone', 'sandstone'), slab = bid('sandstone_slab', 'sandstone');
  const orange = bid('orange_terracotta', 'terracotta'), blue = bid('blue_terracotta', 'terracotta');
  const sand = bid('sand'), susSand = bid('suspicious_sand', 'sand'), tnt = bid('tnt');
  const plate = bid('stone_pressure_plate', 'oak_pressure_plate'), pot = bid('decorated_pot', 'terracotta');

  const XZ = (lx: number, lz: number): [number, number] =>
    rot === 0 ? [cx + lx, cz + lz] : rot === 1 ? [cx - lz, cz + lx] : rot === 2 ? [cx - lx, cz - lz] : [cx + lz, cz - lx];
  const D = (d: number) => (d + rot) & 3;
  const P = (lx: number, dy: number, lz: number, b: number) => {
    const [wx, wz] = XZ(lx, lz);
    put(wx, y + dy, wz, b, true);
  };
  const stairs = (d: number, upsideDown = false) => cell('sandstone_stairs', stairsUp(D(d), upsideDown), 'sandstone');

  // 1. 21×21 foundation & main ground floor (-10..+10).
  const half = 10;
  for (let lz = -half; lz <= half; lz++) for (let lx = -half; lx <= half; lx++) {
    const [wx, wz] = XZ(lx, lz);
    foundation(wx, y - 1, wz, ss);
    put(wx, y - 1, wz, ss, true);
  }

  // 2. Stepped 21×21 pyramid shell (dy = 0..9, r = 10 - dy) + 2nd-floor interior balcony (dy = 4) + skylight apex.
  for (let step = 0; step <= 9; step++) {
    const r = half - step;
    for (let lz = -r; lz <= r; lz++) for (let lx = -r; lx <= r; lx++) {
      const m = Math.max(Math.abs(lx), Math.abs(lz));
      const edge = m === r;
      const wall = m >= r - 1;
      let b = 0;
      if (step === 9) {
        // Skylight crown at the apex (dy = 9): open 1×1 window at (0, 9, 0) framed by sandstone stairs & slabs
        b = lx === 0 && lz === 0 ? 0 : Math.abs(lx) + Math.abs(lz) === 1 ? stairs(lz < 0 ? 2 : lz > 0 ? 0 : lx < 0 ? 1 : 3) : slab;
      } else if (step === 8) {
        b = m === 2 ? (Math.abs(lx) === 2 && Math.abs(lz) === 2 ? cut : ss) : m === 1 ? smooth : 0;
      } else if (edge) {
        b = step === 0 || step === 4 ? cut : ss;
        // Upper front & side facade hieroglyphs (step 5..7)
        if ((lz === r || Math.abs(lx) === r) && step >= 5 && step <= 7 && (lz === r ? Math.abs(lx) <= 1 : Math.abs(lz) <= 1)) {
          const mid = lz === r ? lx === 0 : lz === 0;
          b = mid && step === 6 ? chis : orange;
        }
      } else if (wall) {
        b = step === 1 || step === 5 ? cut : ss;
      } else if (step === 4 && m >= 3 && m <= 5) {
        // 2nd-floor interior gallery walkway overlooking the central wind-rose atrium
        b = m === 3 ? slab : ss;
      }
      P(lx, step, lz, b);
    }
  }
  // Two upper back entrances on the left (lx = -4) and right (lx = +4) sides near the top of the pyramid (dy = 4..5, lz = -6..-5)
  for (const bx of [-4, 4]) for (const bz of [-6, -5]) for (const by of [4, 5]) P(bx, by, bz, 0);
  // 2nd-floor gallery parapet & corner chiseled pillars at dy = 5..6
  for (const s1 of [-3, 3]) for (const s2 of [-3, 3]) { P(s1, 5, s2, chis); P(s1, 6, s2, cut); }

  // 3. Ground floor Vanilla wind-rose mosaic (y - 1) & 10 interior colonnade pillars (dy = 0..3).
  for (let lz = -4; lz <= 4; lz++) for (let lx = -4; lx <= 4; lx++) {
    const ax = Math.abs(lx), az = Math.abs(lz);
    let f = ss;
    if (ax === 0 && az === 0) f = blue;
    else if ((ax === 1 && az === 0) || (ax === 0 && az === 1) || (ax === 2 && az === 1) || (ax === 1 && az === 2) || (ax === 2 && az === 2) || (ax === 3 && az === 0) || (ax === 0 && az === 3)) f = orange;
    else if ((ax === 2 && az === 0) || (ax === 0 && az === 2)) f = cut;
    P(lx, -1, lz, f);
  }
  for (const [px, pz] of [[-3, -3], [3, -3], [-3, 3], [3, 3], [-6, -5], [6, -5], [-6, -1], [6, -1], [-6, 3], [6, 3]] as const) {
    for (let dy = 0; dy <= 3; dy++) P(px, dy, pz, dy === 1 || dy === 2 ? chis : cut);
  }
  // Side entrances on the East (+10) & West (-10) faces
  for (const sx of [-10, 10]) {
    P(sx, 0, 0, 0); P(sx, 1, 0, 0); P(sx - Math.sign(sx), 0, 0, 0); P(sx - Math.sign(sx), 1, 0, 0);
    P(sx, 2, 0, chis); P(sx, 2, -1, cut); P(sx, 2, 1, cut);
  }

  // 4. Two 3×4 Front Towers (lx = -10..-8 and lx = 8..10, lz = 7..10, dy = 0..10) with terracotta Ankh hieroglyphs & internal stairs.
  for (const sx of [-10, 8] as const) {
    const outerX = sx < 0 ? sx : sx + 2;
    for (let lz = 7; lz <= 10; lz++) for (let lx = sx; lx <= sx + 2; lx++) {
      const [wx, wz] = XZ(lx, lz);
      foundation(wx, y - 1, wz, ss);
      put(wx, y - 1, wz, ss, true);
      const midX = sx + 1, edge = lx === sx || lx === sx + 2 || lz === 7 || lz === 10;
      const corner = (lx === sx || lx === sx + 2) && (lz === 7 || lz === 10);
      for (let dy = 0; dy <= 9; dy++) {
        let id = edge ? (corner ? cut : ss) : 0;
        // Front & outer-side Ankh / Cross hieroglyphs on lz = 10 and lx = outerX
        if (lz === 10) {
          if (lx === midX && (dy === 3 || dy === 4 || dy === 6 || dy === 8)) id = orange;
          else if (lx === midX && (dy === 5 || dy === 7)) id = chis;
          else if (lx !== midX && (dy === 5 || dy === 7)) id = orange;
        } else if (lx === outerX && (lz === 8 || lz === 9)) {
          if (dy === 4 || dy === 6) id = orange;
          else if (dy === 5) id = chis;
        }
        // Ground-floor doorway into the tower staircase (lz = 7, lx = midX, dy = 0..1)
        if (lz === 7 && lx === midX && dy <= 1) id = 0;
        // 2nd-floor doorway from tower onto the upper pyramid gallery (lz = 7, lx = midX, dy = 4..5)
        if (lz === 7 && lx === midX && (dy === 4 || dy === 5)) id = 0;
        P(lx, dy, lz, id);
      }
      // Crenelated tower battlements & top tower entrance at dy = 9..10
      if (edge) P(lx, 10, lz, corner ? cut : slab);
    }
    const midX = sx + 1;
    P(midX, 9, 8, 0); // top of tower entrance opening
    // Internal staircase climbing dy = 0..3 inside the tower + stepped roof crown stairs
    P(midX, 0, 8, stairs(2));
    P(midX, 1, 9, stairs(2));
    P(midX, 2, 9, smooth);
    P(midX, 3, 8, stairs(0));
    P(sx, 9, 8, stairs(sx < 0 ? 1 : 3));
    P(sx + 2, 9, 8, stairs(sx < 0 ? 3 : 1));
    P(midX, 9, 10, stairs(0));
  }

  // 5. Front Entrance Portico between the two towers (lx = -2..2, lz = 6..10, dy = 0..5).
  for (let lz = 7; lz <= 10; lz++) for (let lx = -2; lx <= 2; lx++) {
    const [wx, wz] = XZ(lx, lz);
    foundation(wx, y - 1, wz, ss);
    put(wx, y - 1, wz, ss, true);
    const edge = Math.abs(lx) === 2 || lz === 10;
    for (let dy = 0; dy <= 4; dy++) {
      let id = 0;
      if (dy === 4) id = ss;
      else if (edge) {
        if (lz === 10 && Math.abs(lx) <= 1 && dy <= 1) id = 0; // front entrance doorway
        else if (lz === 10 && dy === 2 && lx === 0) id = chis;
        else if (lz === 10 && dy === 3) id = orange;
        else if (Math.abs(lx) === 1 && lz === 10 && dy <= 2) id = cut;
        else id = ss;
      }
      P(lx, dy, lz, id);
    }
    if (edge) P(lx, 5, lz, slab);
  }
  for (let dy = 0; dy < 3; dy++) for (let lx = -1; lx <= 1; lx++) for (let lz = 6; lz <= 10; lz++) P(lx, dy, lz, 0);
  P(-2, 2, 8, bid('torch'));
  P(2, 2, 8, bid('torch'));

  // 6. Central Hidden TNT Trap Chamber (y - 2 down to y - 9, symmetric around (cx, cz)).
  for (let dy = 2; dy <= 7; dy++) {
    for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
      const wall = Math.abs(dx) === 2 || Math.abs(dz) === 2 || dy === 7;
      const mat = !wall ? 0 : dy === 3 ? orange : dy === 4 ? chis : cut;
      put(cx + dx, y - dy, cz + dz, mat, true);
    }
  }
  // Four inward-facing chests tagged `desert_pyramid` around the central stone pressure plate
  for (const [dx, dz, dir] of [[1, 0, 3], [-1, 0, 1], [0, 1, 0], [0, -1, 2]] as const) {
    chest(put, t, cx + dx, y - 6, cz + dz, dir, 'desert_pyramid');
  }
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
    put(cx + dx, y - 8, cz + dz, tnt, true);
    put(cx + dx, y - 9, cz + dz, ss, true);
  }
  put(cx, y - 6, cz, plate, true);

  // 7. 1.20+ Trails & Tales Buried Archaeology Room (back-left or back-right quadrant, buried in sand & suspicious_sand).
  const ax0 = archSide < 0 ? -8 : 4;
  for (let lz = -9; lz <= -5; lz++) for (let lx = ax0; lx <= ax0 + 4; lx++) {
    const edge = lx === ax0 || lx === ax0 + 4 || lz === -9 || lz === -5;
    const rdx = lx - (ax0 + 2), rdz = lz - (-7);
    // Floor at y - 5 with second wind-rose terracotta motif
    const floorMat = rdx === 0 && rdz === 0 ? blue : (rdx === 0 || rdz === 0) && Math.abs(rdx) + Math.abs(rdz) <= 2 ? orange : cut;
    P(lx, -5, lz, floorMat);
    for (let dy = -4; dy <= -2; dy++) {
      if (edge) {
        const doorway = lz === -5 && rdx === 0 && dy >= -3;
        const relief = !doorway && dy === -3 && (rdx === 0 || rdz === 0);
        P(lx, dy, lz, doorway ? sand : relief ? chis : cut);
      } else {
        P(lx, dy, lz, dy === -4 ? sand : 0);
      }
    }
  }
  // Collapsed sandstone stairs connecting the ground floor (-4..-2) down into the archaeology room entrance
  for (let sStep = 0; sStep < 3; sStep++) {
    const slz = -3 - sStep;
    P(ax0 + 2, -1 - sStep, slz, stairs(0));
    P(ax0 + 2, -sStep, slz, sStep < spec.collapseDepth ? sand : 0);
  }
  // Place deterministic suspicious_sand blocks: 1 visible at ground-floor level (y - 1) + buried archaeology floor (y - 4)
  for (const [wx, dy, wz] of spec.suspiciousCoords) put(wx, y + dy, wz, susSand, true);
  // Intact decorated pot in the back corner of the archaeology room
  P(ax0 + (archSide < 0 ? 1 : 3), -3, -8, pot);
}
