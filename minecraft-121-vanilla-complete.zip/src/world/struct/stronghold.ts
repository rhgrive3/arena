// Stronghold (Minecraft Wiki "Stronghold" – structure pieces, Java Edition StrongholdPieces). Like vanilla it grows from a spiral
// staircase: every exit of a placed piece asks for a new piece chosen by weight (corridor 40, turns, prison hall, room crossing,
// five-way crossing, straight/spiral stairs, chest corridor, library [single-storey & duplex], portal room), which is kept only if
// its bounding box does not collide with what is already there. The portal room (one per stronghold) and the libraries (at most two)
// only appear several pieces away from the start.
import { makeCell } from '../../game/blockState';
import { chest, barrel, lectern, brewing, itemFrame, lantern } from './decor';
import { type Put, type StructHost, DX, DZ, bid, cell, hash2, hash3, mulberry, tag, stoneBrick, stairsUp, ladderOn, attachOn, doorOn, PANE_X, PANE_Z } from './common';

export type PieceType = 'start' | 'corridor' | 'turn' | 'prison' | 'crossing' | 'five_way_crossing' | 'stairs' | 'spiral' | 'chest_corridor' | 'library' | 'portal_room'
  | 'long_hall' | 'four_way' | 'storeroom' | 'cell_block' | 'altar';
interface Exit { lx: number; ly: number; lz: number; turn: number }
interface Def { w: number; h: number; l: number; ex: number; ey: number; exits: Exit[]; weight: number; max: number; minDepth: number }
/** Local frame: lx across (0..w-1), ly up (0 = floor block), lz along the travel direction; the entry is centred on (ex, ey, 0). */
const DEFS: Record<PieceType, Def> = {
  start: { w: 5, h: 11, l: 5, ex: 2, ey: 6, exits: [{ lx: 2, ly: 0, lz: 5, turn: 0 }], weight: 0, max: 1, minDepth: 0 },
  corridor: { w: 5, h: 5, l: 7, ex: 2, ey: 0, exits: [{ lx: 2, ly: 0, lz: 7, turn: 0 }, { lx: -1, ly: 0, lz: 3, turn: 3 }, { lx: 5, ly: 0, lz: 3, turn: 1 }], weight: 40, max: 99, minDepth: 0 },
  turn: { w: 5, h: 5, l: 5, ex: 2, ey: 0, exits: [{ lx: -1, ly: 0, lz: 2, turn: 3 }, { lx: 5, ly: 0, lz: 2, turn: 1 }], weight: 30, max: 99, minDepth: 0 },
  prison: { w: 9, h: 5, l: 11, ex: 2, ey: 0, exits: [{ lx: 2, ly: 0, lz: 11, turn: 0 }], weight: 8, max: 5, minDepth: 1 },
  crossing: { w: 11, h: 7, l: 11, ex: 5, ey: 0, exits: [{ lx: 5, ly: 0, lz: 11, turn: 0 }, { lx: -1, ly: 0, lz: 5, turn: 3 }, { lx: 11, ly: 0, lz: 5, turn: 1 }], weight: 12, max: 6, minDepth: 0 },
  five_way_crossing: {
    w: 11, h: 9, l: 11, ex: 4, ey: 2,
    exits: [
      { lx: 4, ly: 0, lz: 11, turn: 0 },
      { lx: -1, ly: 2, lz: 4, turn: 3 },
      { lx: 11, ly: 2, lz: 4, turn: 1 },
      { lx: -1, ly: 5, lz: 8, turn: 3 },
      { lx: 11, ly: 5, lz: 8, turn: 1 },
    ],
    weight: 10, max: 5, minDepth: 2,
  },
  stairs: { w: 5, h: 11, l: 8, ex: 2, ey: 6, exits: [{ lx: 2, ly: 0, lz: 8, turn: 0 }], weight: 5, max: 5, minDepth: 1 },
  spiral: { w: 5, h: 11, l: 5, ex: 2, ey: 6, exits: [{ lx: 2, ly: 0, lz: 5, turn: 0 }], weight: 5, max: 6, minDepth: 1 },
  chest_corridor: { w: 5, h: 5, l: 7, ex: 2, ey: 0, exits: [{ lx: 2, ly: 0, lz: 7, turn: 0 }], weight: 6, max: 4, minDepth: 1 },
  library: { w: 14, h: 11, l: 15, ex: 4, ey: 0, exits: [], weight: 10, max: 2, minDepth: 4 },
  portal_room: { w: 11, h: 8, l: 16, ex: 5, ey: 0, exits: [], weight: 20, max: 1, minDepth: 8 },
  // Pieces added for the large maze: long pillared halls, four-way halls, store rooms, cell blocks and altar chapels.
  long_hall: { w: 5, h: 5, l: 15, ex: 2, ey: 0, exits: [{ lx: 2, ly: 0, lz: 15, turn: 0 }, { lx: -1, ly: 0, lz: 7, turn: 3 }, { lx: 5, ly: 0, lz: 7, turn: 1 }], weight: 16, max: 10, minDepth: 1 },
  four_way: { w: 9, h: 5, l: 9, ex: 4, ey: 0, exits: [{ lx: 4, ly: 0, lz: 9, turn: 0 }, { lx: -1, ly: 0, lz: 4, turn: 3 }, { lx: 9, ly: 0, lz: 4, turn: 1 }], weight: 14, max: 8, minDepth: 2 },
  storeroom: { w: 9, h: 6, l: 9, ex: 4, ey: 0, exits: [], weight: 8, max: 5, minDepth: 2 },
  cell_block: { w: 11, h: 5, l: 13, ex: 5, ey: 0, exits: [{ lx: 5, ly: 0, lz: 13, turn: 0 }], weight: 8, max: 4, minDepth: 2 },
  altar: { w: 9, h: 7, l: 9, ex: 4, ey: 0, exits: [], weight: 6, max: 3, minDepth: 3 },
};

export interface Piece {
  type: PieceType; d: number; ax: number; ay: number; az: number; depth: number; variant: number;
  /** Entry: 0 open arch (OPENING), 1 oak wooden door (WOOD_DOOR), 2 iron-bar grate (GRATES), 3 iron door with stone buttons (IRON_DOOR). */
  door: number;
  /** [x0, y0, z0, x1, y1, z1] inclusive. */
  box: [number, number, number, number, number, number];
  /** Which exits lead to another piece (the others stay walled up). */
  open: boolean[];
  /** Library: true = 2-storey duplex (height 11, 233 bookshelves, 2 chests); false = single-storey (height 6, 1 chest). */
  tall?: boolean;
}
export interface StrongholdLayout { cx: number; cz: number; pieces: Piece[]; portal: [number, number, number] | null }

/** Half-size of the maze (blocks from the starting staircase): a 168×168 labyrinth over up to six levels. */
export const STRONGHOLD_RADIUS = 84;
/** Walking level of the corridors that leave the starting staircase. */
export const STRONGHOLD_Y = 31;
const MAX_PIECES = 120, MIN_Y = 6;

const world = (p: { type: PieceType; d: number; ax: number; ay: number; az: number }, lx: number, ly: number, lz: number): [number, number, number] => {
  const def = DEFS[p.type], r = (p.d + 1) & 3;
  return [p.ax + DX[r] * (lx - def.ex) + DX[p.d] * lz, p.ay + ly - def.ey, p.az + DZ[r] * (lx - def.ex) + DZ[p.d] * lz];
};
function boxOf(p: { type: PieceType; d: number; ax: number; ay: number; az: number; tall?: boolean }): Piece['box'] {
  const def = DEFS[p.type];
  const h = p.type === 'library' && p.tall === false ? 6 : def.h;
  const a = world(p, 0, 0, 0), b = world(p, def.w - 1, h - 1, def.l - 1);
  return [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.min(a[2], b[2]), Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.max(a[2], b[2])];
}
const overlaps = (a: Piece['box'], b: Piece['box']) => a[0] <= b[3] && a[3] >= b[0] && a[1] <= b[4] && a[4] >= b[1] && a[2] <= b[5] && a[5] >= b[2];

function generate(seed: number, cx: number, cz: number): StrongholdLayout {
  const rnd = mulberry(seed), pieces: Piece[] = [], counts: Partial<Record<PieceType, number>> = {};
  const d0 = Math.floor(rnd() * 4);
  const start: Piece = { type: 'start', d: d0, ax: cx - DX[d0] * 2, ay: STRONGHOLD_Y + 5, az: cz - DZ[d0] * 2, depth: 0, variant: 0, door: 0, box: [0, 0, 0, 0, 0, 0], open: [false] };
  start.box = boxOf(start);
  pieces.push(start);
  interface Pending { parent: Piece; exit: number; depth: number }
  const queue: Pending[] = [{ parent: start, exit: 0, depth: 1 }];
  let portal: StrongholdLayout['portal'] = null;
  while (queue.length && pieces.length < MAX_PIECES) {
    const q = queue.splice(Math.floor(rnd() * queue.length), 1)[0], e = DEFS[q.parent.type].exits[q.exit];
    const [ax, ay, az] = world(q.parent, e.lx, e.ly, e.lz), d = (q.parent.d + e.turn) & 3;
    const pool = (Object.keys(DEFS) as PieceType[]).filter(k => DEFS[k].weight > 0 && (counts[k] ?? 0) < DEFS[k].max && q.depth >= DEFS[k].minDepth && !(k === q.parent.type && k !== 'corridor'));
    // The portal room and the first library are tried first once they are allowed, so every stronghold has them.
    const forced: PieceType[] = [];
    // The end portal room is the deepest dead end: it is only offered once the maze has grown to more than half of its size.
    if (pool.includes('portal_room') && pieces.length >= MAX_PIECES * 0.55) forced.push('portal_room');
    if (pool.includes('library') && !counts.library) forced.push('library');
    for (let tries = 0; tries < 8 && (forced.length || pool.length); tries++) {
      let type: PieceType;
      if (forced.length) { type = forced.shift()!; pool.splice(pool.indexOf(type), 1); }
      else {
        let w = rnd() * pool.reduce((s, k) => s + DEFS[k].weight, 0), i = 0;
        while (i < pool.length - 1 && (w -= DEFS[pool[i]].weight) > 0) i++;
        type = pool.splice(i, 1)[0];
      }
      const def = DEFS[type];
      const door = type === 'portal_room' ? 2 : type === 'library' ? 3 : type === 'prison' ? Math.floor(rnd() * 3) : Math.floor(rnd() * 4);
      const firstLib = type === 'library' && !counts.library;
      const piece: Piece = {
        type, d, ax, ay, az, depth: q.depth, variant: Math.floor(rnd() * 8), door,
        box: [0, 0, 0, 0, 0, 0], open: def.exits.map(() => false),
        tall: type === 'library' ? true : undefined,
      };
      piece.box = boxOf(piece);
      let b = piece.box;
      let fits = b[1] >= MIN_Y && Math.max(Math.abs(b[0] - cx), Math.abs(b[3] - cx), Math.abs(b[2] - cz), Math.abs(b[5] - cz)) <= STRONGHOLD_RADIUS && !pieces.some(o => overlaps(b, o.box));
      // Vanilla StrongholdPieces$Library: if a 2-storey duplex library is obstructed overhead (or is a second library), fall back to single-storey (height 6)
      if (type === 'library' && !firstLib && (!fits || rnd() < 0.45)) {
        piece.tall = false;
        piece.box = boxOf(piece);
        b = piece.box;
        fits = b[1] >= MIN_Y && Math.max(Math.abs(b[0] - cx), Math.abs(b[3] - cx), Math.abs(b[2] - cz), Math.abs(b[5] - cz)) <= STRONGHOLD_RADIUS && !pieces.some(o => overlaps(b, o.box));
      }
      if (!fits) continue;
      pieces.push(piece);
      counts[type] = (counts[type] ?? 0) + 1;
      q.parent.open[q.exit] = true;
      if (type === 'portal_room') portal = world(piece, 5, 2, 10);
      def.exits.forEach((_, i) => {
        if (type === 'turn' && i !== (piece.variant & 1)) return;
        if (type === 'corridor' && i > 0 && rnd() > 0.35) return;
        queue.push({ parent: piece, exit: i, depth: q.depth + 1 });
      });
      break;
    }
  }
  return { cx, cz, pieces, portal };
}

const LAYOUTS = new Map<string, StrongholdLayout>();
/** Layout of the stronghold whose starting staircase is at (cx, cz). Deterministic for a seed. */
export function strongholdLayout(seed: number, cx: number, cz: number): StrongholdLayout {
  const key = seed + ':' + cx + ',' + cz, hit = LAYOUTS.get(key);
  if (hit) return hit;
  let best: StrongholdLayout | null = null, bestScore = -1;
  for (let attempt = 0; attempt < 40; attempt++) {
    const L = generate((Math.imul(seed | 0, 31) ^ Math.imul(cx, 7919) ^ Math.imul(cz, 104729)) + attempt * 977, cx, cz);
    const has = (k: PieceType) => L.pieces.some(p => p.type === k), maxDepth = Math.max(...L.pieces.map(p => p.depth));
    const portalDepth = L.pieces.find(p => p.type === 'portal_room')?.depth ?? 0;
    const levels = new Set(L.pieces.map(p => p.box[1])).size;
    const score = (L.portal ? 100 : 0) + (has('library') ? 20 : 0) + (has('prison') ? 20 : 0) + (has('chest_corridor') ? 5 : 0) + (has('crossing') ? 5 : 0)
      + (has('five_way_crossing') ? 5 : 0) + (has('cell_block') ? 5 : 0) + (has('storeroom') ? 5 : 0) + (has('altar') ? 5 : 0)
      + Math.min(60, L.pieces.length / 2) + (L.portal ? 30 * (portalDepth / Math.max(1, maxDepth)) : 0) + Math.min(10, levels * 2);
    if (score > bestScore) { best = L; bestScore = score; }
    if (score >= 290) break;
  }
  if (LAYOUTS.size > 16) LAYOUTS.clear();
  LAYOUTS.set(key, best!);
  return best!;
}

const FRAME_RING: [number, number, number][] = [[-1, -2, 0], [0, -2, 0], [1, -2, 0], [2, -1, 1], [2, 0, 1], [2, 1, 1], [1, 2, 2], [0, 2, 2], [-1, 2, 2], [-2, 1, 3], [-2, 0, 3], [-2, -1, 3]];
const SPIRAL_RING: [number, number][] = [[2, 1], [3, 1], [3, 2], [3, 3], [2, 3], [1, 3], [1, 2], [1, 1]];

function buildPiece(t: StructHost, put: Put, p: Piece) {
  const def = DEFS[p.type], d = p.d, right = (d + 1) & 3, back = (d + 2) & 3, left = (d + 3) & 3, brick = stoneBrick(t.seed + 3301);
  const H = p.type === 'library' && p.tall === false ? 6 : def.h;
  const S = (lx: number, ly: number, lz: number, block: number) => { const [x, y, z] = world(p, lx, ly, lz); put(x, y, z, block, true); };
  const SB = (lx: number, ly: number, lz: number) => { const [x, y, z] = world(p, lx, ly, lz); put(x, y, z, brick(x, y, z), true); };
  const T = (lx: number, ly: number, lz: number, table: string) => { const [x, y, z] = world(p, lx, ly, lz); put(x, y, z, bid('chest'), true); tag(t, x, y, z, table); };
  const rnd = (lx: number, ly: number, lz: number, salt = 0) => { const [x, y, z] = world(p, lx, ly, lz); return hash3(x, y, z, t.seed + 3307 + salt); };
  /** Iron bars running along the local X axis (across) or the local Z axis (along). */
  const barsAcross = cell('iron_bars', d % 2 === 0 ? PANE_X : PANE_Z), barsAlong = cell('iron_bars', d % 2 === 0 ? PANE_Z : PANE_X);
  const torchOn = (w: number) => cell('torch', attachOn(w));
  const lanternAt = (lx: number, ly: number, lz: number, soul = false) => { const [x, y, z] = world(p, lx, ly, lz); lantern(put, x, y, z, soul); };
  const solid = p.type === 'stairs' || p.type === 'spiral' || p.type === 'start';
  for (let ly = 0; ly < H; ly++) for (let lz = 0; lz < def.l; lz++) for (let lx = 0; lx < def.w; lx++) {
    const edge = lx === 0 || lx === def.w - 1 || ly === 0 || ly === H - 1 || lz === 0 || lz === def.l - 1;
    if (edge || solid) SB(lx, ly, lz); else S(lx, ly, lz, 0);
  }

  switch (p.type) {
    case 'corridor':
      S(1, 2, 1, torchOn(left)); S(3, 2, 5, torchOn(right));
      break;
    case 'turn':
      S(2, 2, 3, torchOn(d));
      break;
    case 'chest_corridor':
      // Vanilla Stronghold/Structure/Loot Altar (5×5×7): 7 stone brick slabs surrounding a stone brick altar base with 1 chest (`stronghold_corridor`).
      SB(2, 1, 3); SB(3, 1, 3);
      T(2, 2, 3, 'stronghold_corridor');
      for (const [lx, lz] of [[1, 2], [1, 3], [1, 4], [2, 2], [2, 4], [3, 2], [3, 4]]) S(lx, 1, lz, bid('stone_brick_slab', 'stone_bricks'));
      S(1, 2, 1, torchOn(left)); S(3, 2, 5, torchOn(right));
      break;
    case 'prison':
      // Vanilla StrongholdPieces$PrisonHall: 9×5×11 walkway on the entry side, two cells behind an iron-bar wall with two open iron doors.
      for (let lz = 1; lz <= 9; lz++) for (let ly = 1; ly <= 3; ly++) S(4, ly, lz, barsAlong);
      for (let lx = 5; lx <= 7; lx++) for (let ly = 1; ly <= 3; ly++) S(lx, ly, 5, barsAcross);
      for (const lz of [3, 7]) { S(4, 1, lz, cell('iron_door', doorOn(right), 'iron_bars')); S(4, 2, lz, cell('iron_door', doorOn(right) | 4, 'iron_bars')); }
      S(1, 2, 5, torchOn(left)); S(3, 2, 1, torchOn(back)); S(3, 2, 9, torchOn(d));
      S(7, 3, 1, bid('cobweb', 'air')); S(7, 3, 9, bid('cobweb', 'air'));
      break;
    case 'crossing': {
      // Vanilla StrongholdPieces$RoomCrossing (11×7×11): 4 variants (0 Pillar with torches, 1 Fountain, 2 Two-level Storeroom with ladder & chest, 3 Empty room)
      const v = p.variant % 4;
      if (v === 0) {                                                   // Stone Pillar room
        for (let ly = 1; ly <= 5; ly++) SB(5, ly, 5);
        for (const [lx, lz] of [[4, 4], [6, 4], [4, 6], [6, 6], [4, 5], [6, 5], [5, 4], [5, 6]]) S(lx, 1, lz, bid('stone_brick_slab', 'stone_bricks'));
        S(4, 3, 5, torchOn(right)); S(6, 3, 5, torchOn(left)); S(5, 3, 4, torchOn(d)); S(5, 3, 6, torchOn(back));
      } else if (v === 1) {                                            // Fountain room: stone brick ring & central pillar with water source on top
        for (let lz = 3; lz <= 7; lz++) for (let lx = 3; lx <= 7; lx++) {
          const rim = lx === 3 || lx === 7 || lz === 3 || lz === 7;
          if (rim) SB(lx, 1, lz);
          else S(lx, 1, lz, bid('water'));
        }
        SB(5, 1, 5); SB(5, 2, 5); SB(5, 3, 5); S(5, 4, 5, bid('water'));
        S(1, 3, 1, torchOn(left)); S(9, 3, 9, torchOn(right));
      } else if (v === 2) {                                            // Dual-level Storeroom: cobblestone central column housing a torch, ladder to oak plank upper chamber with chest
        const cob = bid('cobblestone'), planks = bid('oak_planks');
        for (let lz = 2; lz <= 8; lz++) for (let lx = 2; lx <= 8; lx++) S(lx, 3, lz, planks);
        for (let ly = 1; ly <= 5; ly++) { S(4, ly, 4, cob); S(6, ly, 4, cob); S(4, ly, 6, cob); S(6, ly, 6, cob); }
        S(5, 1, 5, cob); S(5, 2, 5, bid('torch')); S(5, 3, 5, cob);
        for (let ly = 1; ly <= 3; ly++) S(1, ly, 5, cell('ladder', ladderOn(left)));
        // Second-floor loot chest standing on the oak_planks upper floor (`ly = 3`), plus ground-floor storage table
        T(3, 4, 7, 'stronghold_crossing');
        S(2, 4, 7, bid('oak_fence', 'oak_planks')); S(2, 5, 7, bid('torch'));
        if (rnd(3, 4, 8, 9) < 0.5) S(3, 5, 8, bid('cobweb', 'air'));
        S(9, 3, 1, torchOn(right));
      } else {                                                         // Empty room
        for (const [lx, lz] of [[1, 1], [9, 1], [1, 9], [9, 9]]) if (rnd(lx, 5, lz) < 0.7) S(lx, 5, lz, bid('cobweb', 'air'));
        S(5, 3, 1, torchOn(back));
      }
      break;
    }
    case 'five_way_crossing': {
      // Vanilla StrongholdPieces$FiveWayCrossing (11×9×11):
      // Sloped slab stairways down to forward exit (ly=0) and up to upper-left exit (ly=5), plus bridge across to upper-right exit (ly=5).
      const slab = bid('stone_brick_slab', 'stone_bricks'), smooth = bid('smooth_stone', 'stone_bricks');
      for (let lz = 2; lz <= 8; lz++) {
        // Central downward ramp from entry (ly=2) to forward exit (ly=0)
        const stepY = lz <= 4 ? 2 : lz <= 6 ? 1 : 0;
        for (let lx = 3; lx <= 5; lx++) {
          for (let y = 1; y <= stepY; y++) S(lx, y, lz, smooth);
          if (lz === 4 || lz === 6) S(lx, stepY + 1, lz, slab);
        }
        // Left upward ramp to upper level (ly=5)
        const upY = Math.min(5, 2 + Math.floor((lz - 1) / 2));
        for (let lx = 1; lx <= 2; lx++) {
          for (let y = 1; y < upY; y++) SB(lx, y, lz);
          S(lx, upY, lz, (lz & 1) ? slab : smooth);
        }
      }
      // Upper bridge across lx=2..9 at ly=5, lz=7..9 connecting the two upper exits
      for (let lz = 7; lz <= 9; lz++) for (let lx = 2; lx <= 9; lx++) S(lx, 5, lz, smooth);
      S(1, 4, 2, torchOn(left)); S(9, 4, 2, torchOn(right)); S(5, 6, 8, torchOn(d));
      break;
    }
    case 'long_hall':
      for (const lz of [3, 11]) for (let ly = 1; ly <= 3; ly++) { SB(1, ly, lz); SB(3, ly, lz); }
      for (const lz of [3, 11]) { S(2, 3, lz, bid('stone_brick_slab', 'stone_bricks')); S(2, 2, lz - 1, torchOn(back)); }
      S(1, 2, 5, torchOn(left)); S(3, 2, 9, torchOn(right));
      if (rnd(2, 3, 7) < 0.5) S(2, 3, 7, bid('cobweb', 'air'));
      break;
    case 'four_way':
      for (const [lx, lz] of [[2, 2], [6, 2], [2, 6], [6, 6]]) for (let ly = 1; ly <= 3; ly++) SB(lx, ly, lz);
      S(3, 2, 2, torchOn(left)); S(5, 2, 6, torchOn(right)); S(3, 2, 6, torchOn(left)); S(5, 2, 2, torchOn(right));
      for (let ly = 1; ly <= 3; ly++) SB(4, ly, 4);
      S(4, 4, 4, bid('stone_brick_slab', 'stone_bricks')); lanternAt(4, 3, 3);
      break;
    case 'storeroom':
      for (let lz = 2; lz <= 6; lz++) for (let ly = 1; ly <= 2; ly++) { const [x, y, z] = world(p, 1, ly, lz); barrel(put, t, x, y, z, right); }
      for (const lz of [3, 5, 7]) { S(7, 1, lz, bid('oak_planks')); const [x, y, z] = world(p, 7, 2, lz); chest(put, t, x, y, z, left, 'stronghold_crossing'); }
      S(7, 1, 1, bid('oak_planks')); S(7, 2, 1, bid('oak_fence', 'oak_planks')); S(7, 3, 1, bid('torch'));
      S(4, 4, 4, bid('oak_fence', 'oak_planks')); lanternAt(4, 3, 4);
      for (const [lx, lz] of [[1, 1], [7, 7], [1, 7]]) if (rnd(lx, 4, lz) < 0.7) S(lx, 4, lz, bid('cobweb', 'air'));
      break;
    case 'cell_block':
      for (let lz = 1; lz <= 11; lz++) for (let ly = 1; ly <= 3; ly++) { S(4, ly, lz, barsAlong); S(6, ly, lz, barsAlong); }
      for (const lz of [4, 8]) for (let ly = 1; ly <= 3; ly++) for (const lx of [1, 2, 3, 7, 8, 9]) SB(lx, ly, lz);
      for (const lz of [2, 6, 10]) {
        S(4, 1, lz, cell('iron_door', doorOn(right), 'iron_bars')); S(4, 2, lz, cell('iron_door', doorOn(right) | 4, 'iron_bars'));
        S(6, 1, lz, cell('iron_door', doorOn(left), 'iron_bars')); S(6, 2, lz, cell('iron_door', doorOn(left) | 4, 'iron_bars'));
        S(1, 1, lz, bid('oak_planks')); S(9, 1, lz, bid('oak_planks'));                       // plank bunks
        if (rnd(1, 3, lz) < 0.5) S(2, 1, lz, bid('cobweb', 'air'));
      }
      S(5, 3, 3, torchOn(back)); S(5, 3, 9, torchOn(back)); S(3, 3, 1, torchOn(left)); S(7, 3, 11, torchOn(right));
      break;
    case 'altar': {
      for (let lz = 4; lz <= 6; lz++) for (let lx = 3; lx <= 5; lx++) S(lx, 1, lz, bid('chiseled_stone_bricks', 'stone_bricks'));
      for (let lx = 3; lx <= 5; lx++) S(lx, 1, 3, cell('stone_brick_stairs', stairsUp(back), 'stone_bricks'));
      { const [x, y, z] = world(p, 4, 2, 6); chest(put, t, x, y, z, d, 'stronghold_corridor'); }
      { const [x, y, z] = world(p, 3, 2, 6); brewing(put, t, x, y, z); }
      { const [x, y, z] = world(p, 5, 2, 6); lectern(put, x, y, z, d); }
      { const [x, y, z] = world(p, 4, 3, 7); itemFrame(put, t, x, y, z, back); }
      for (const [lx, lz] of [[1, 1], [7, 1], [1, 7], [7, 7]]) { for (let ly = 1; ly <= 5; ly++) SB(lx, ly, lz); }
      S(2, 3, 1, torchOn(left)); S(6, 3, 1, torchOn(right)); S(2, 3, 7, torchOn(left)); S(6, 3, 7, torchOn(right));
      for (const [lx, lz] of [[2, 4], [6, 4]]) { S(lx, 1, lz, bid('oak_fence', 'oak_planks')); lanternAt(lx, 2, lz, true); }
      break;
    }
    case 'stairs':
      // Vanilla StrongholdPieces$StraightStairsDown: 3-block wide staircase with an empty alcove under the stairs
      for (let k = 1; k <= 6; k++) for (let lx = 1; lx <= 3; lx++) {
        S(lx, 7 - k, k, cell('cobblestone_stairs', stairsUp(back), 'stone_bricks'));
        for (let ly = 8 - k; ly <= 10 - k; ly++) S(lx, ly, k, 0);
        // Empty alcove carved underneath the upper steps
        if (k <= 3) for (let ly = 1; ly <= 5 - k; ly++) S(lx, ly, k, 0);
      }
      break;
    case 'start':
    case 'spiral':
      for (let ly = 1; ly <= 9; ly++) for (let lz = 1; lz <= 3; lz++) for (let lx = 1; lx <= 3; lx++) if (lx !== 2 || lz !== 2) S(lx, ly, lz, 0);
      SB(2, 6, 1);                                                     // landing behind the upper door
      for (let j = 1; j <= 11; j++) {                                  // half-block steps winding down around the newel
        const [lx, lz] = SPIRAL_RING[j % 8];
        S(lx, j % 2 ? (13 - j) / 2 : 6 - j / 2, lz, cell('stone_brick_slab', j % 2 ? 0 : 1, 'stone_bricks'));
      }
      S(1, 8, 1, torchOn(left));
      break;
    case 'library': {
      // Vanilla Stronghold/Structure/Library blueprint (14×11×15 duplex with exactly 233 bookshelves, or 14×6×15 single-storey):
      // Wall bookshelves alternating with oak plank pilasters, 5 rows of double-sided freestanding bookshelves (lz = 3,5,7,9,11),
      // cobwebs dispersed on the ground floor, and (when duplex) an oak plank balcony with oak fence railings, ladder on the far wall,
      // oak fence + 4-torch chandelier in the centre, and a second chest on the balcony.
      const shelf = bid('bookshelf', 'oak_planks'), planks = bid('oak_planks'), fence = bid('oak_fence', 'oak_planks'), web = bid('cobweb', 'air');
      const duplex = p.tall !== false;
      for (let lz = 1; lz <= 13; lz++) for (let lx = 1; lx <= 12; lx++) {
        if ((lx <= 2 || lx >= 11 || lz <= 2 || lz >= 12) && rnd(lx, 4, lz, 5) < 0.14) S(lx, 4, lz, web);
        if (duplex && (lx <= 2 || lx >= 11 || lz <= 2 || lz >= 12) && rnd(lx, 9, lz, 5) < 0.1) S(lx, 9, lz, web);
      }
      for (const [lx, ly, lz] of [[2, 4, 2], [11, 4, 2], [2, 4, 12], [11, 4, 12], [5, 4, 12], [8, 4, 1]]) S(lx, ly, lz, web);
      // Ground floor: side wall bookshelves (3 high, capped by oak planks at ly=4) with plank pilasters every 3 blocks (54 shelves), plus 5 rows of freestanding shelves (84 shelves)
      for (let lz = 1; lz <= 13; lz++) {
        const pilaster = lz % 3 === 1;
        for (let ly = 1; ly <= 4; ly++) {
          S(1, ly, lz, pilaster || ly === 4 ? planks : shelf);
          S(12, ly, lz, pilaster || ly === 4 ? planks : shelf);
        }
      }
      for (const lz of [3, 5, 7, 9, 11]) for (let ly = 1; ly <= 3; ly++) for (const lx of [3, 4, 6, 7, 9, 10]) {
        S(lx, ly, lz, shelf);
      }
      for (const lx of [2, 11]) for (let ly = 1; ly <= 2; ly++) S(lx, ly, 13, shelf);
      // Wall torches on ground floor pilasters
      for (const lz of [4, 7, 10]) { S(2, 3, lz, torchOn(left)); S(11, 3, lz, torchOn(right)); }
      T(3, 1, 12, 'stronghold_library');
      S(3, 2, 12, 0);

      if (duplex) {
        // Gallery (second floor at ly=5): oak plank ring with oak fence railing (ly=6), upper wall bookshelves (ly=6..8, capped at ly=9)
        for (let lz = 1; lz <= 13; lz++) for (let lx = 1; lx <= 12; lx++) {
          const ring = lx <= 3 || lx >= 10 || lz <= 2 || lz >= 11;
          if (!ring) continue;
          S(lx, 5, lz, planks);
          const inner = ((lx === 3 || lx === 10) && lz >= 2 && lz <= 11) || ((lz === 2 || lz === 11) && lx >= 3 && lx <= 10);
          if (inner) S(lx, 6, lz, fence);
        }
        for (let lz = 1; lz <= 13; lz++) {
          const pilaster = lz % 3 === 1;
          for (let ly = 6; ly <= 9; ly++) {
            S(1, ly, lz, pilaster || ly === 9 ? planks : shelf);
            S(12, ly, lz, pilaster || ly === 9 ? planks : shelf);
          }
        }
        for (let lx = 2; lx <= 11; lx++) {
          const backPilaster = lx % 3 === 0;
          const frontPilaster = lx === 3 || lx === 9;
          for (let ly = 6; ly <= 9; ly++) {
            S(lx, ly, 13, backPilaster || ly === 9 ? planks : shelf);
            S(lx, ly, 1, frontPilaster || ly === 9 ? planks : shelf);
          }
        }
        S(3, 6, 1, shelf);
        // Ladder on the wall furthest from the entrance (lz = 13, lx = 10, ly = 1..5)
        for (let ly = 1; ly <= 5; ly++) S(10, ly, 13, cell('ladder', ladderOn(d)));
        S(10, 6, 13, 0);
        // Chandelier: oak fence cross suspended from ceiling with 4 torches
        S(6, 9, 7, fence); S(6, 8, 7, fence); S(6, 7, 7, fence);
        for (const [lx, lz] of [[5, 7], [7, 7], [6, 6], [6, 8]]) { S(lx, 7, lz, fence); S(lx, 8, lz, bid('torch')); }
        T(1, 6, 6, 'stronghold_library');
        S(1, 7, 6, 0);
      }
      break;
    }
    case 'portal_room': {
      // Vanilla Stronghold/Structure/Portal Room blueprint (11×8×16):
      // Two side lava basins (lx=1, lz=2..4 & lx=9, lz=2..4) + wall lavafalls, iron-bar windows on side walls,
      // 3-step stone brick stairs climbing to the 5×5 portal dais over a 3×3 lava pool, silverfish spawner on the steps,
      // and 12 inward-facing end_portal_frame blocks (each with 10% chance of an Eye of Ender).
      for (let lz = 1; lz <= 14; lz++) {
        for (const lx of [1, 9]) if (lz >= 2 && lz <= 13) S(lx, 1, lz, bid('lava')); else SB(lx, 1, lz);
        SB(2, 1, lz); SB(8, 1, lz);
      }
      // Side wall lava niches pouring into the side basins
      for (const lx of [1, 9]) { SB(lx, 2, 2); SB(lx, 2, 4); SB(lx, 3, 3); S(lx, 2, 3, bid('lava')); }
      // Iron bar windows along side walls
      for (const lz of [3, 4, 7, 8, 11, 12]) for (const ly of [2, 3, 4]) { S(0, ly, lz, barsAlong); S(10, ly, lz, barsAlong); }
      // Steps up to the portal platform
      for (let lx = 3; lx <= 7; lx++) S(lx, 1, 7, cell('stone_brick_stairs', stairsUp(d), 'stone_bricks'));
      for (let lz = 8; lz <= 12; lz++) for (let lx = 3; lx <= 7; lx++) {
        if (lx >= 4 && lx <= 6 && lz >= 9 && lz <= 11) S(lx, 1, lz, bid('lava')); else SB(lx, 1, lz);
      }
      S(5, 2, 7, bid('spawner', 'iron_bars'));                           // silverfish spawner on the steps
      const [px, py, pz] = world(p, 5, 2, 10), frame = bid('end_portal_frame', 'stone_bricks');
      FRAME_RING.forEach(([dx, dz, facing], i) => {
        const eye = hash2(px + i * 17, pz - i * 29, t.seed + 3311) < 0.1 && i !== 0;      // 10 % per frame, never a finished portal
        put(px + dx, py, pz + dz, makeCell(frame, facing | (eye ? 4 : 0)), true);
      });
      S(3, 4, 1, torchOn(back)); S(7, 4, 1, torchOn(back));
      break;
    }
  }

  // Entry: 3×3 opening, closed by: 0 open arch, 1 oak door, 2 iron-bar grate, 3 iron door with stone buttons.
  if (p.type !== 'start') {
    for (let ly = def.ey + 1; ly <= def.ey + 3; ly++) for (let lx = def.ex - 1; lx <= def.ex + 1; lx++) {
      const centre = lx === def.ex && ly <= def.ey + 2;
      if (p.door === 0 || (centre && p.door === 2)) S(lx, ly, 0, 0);
      else if (p.door === 2) S(lx, ly, 0, barsAcross);
      else if (centre && p.door === 3) S(lx, ly, 0, cell('iron_door', doorOn(back) | (ly === def.ey + 2 ? 4 : 0), 'oak_door'));
      else if (centre) S(lx, ly, 0, cell('oak_door', doorOn(back) | (ly === def.ey + 2 ? 4 : 0)));
    }
    if (p.door === 3) {
      S(def.ex - 1, def.ey + 2, 1, cell('oak_button', attachOn(back), 'torch'));
    }
  }
  def.exits.forEach((e, i) => {
    if (!p.open[i]) return;
    for (let ly = e.ly + 1; ly <= e.ly + 3; ly++) for (let k = -1; k <= 1; k++) {
      if (e.turn === 0) S(e.lx + k, ly, e.lz - 1, 0);
      else S(e.turn === 3 ? e.lx + 1 : e.lx - 1, ly, e.lz + k, 0);
    }
  });
}

/** Writes the stronghold around (cx, cz); with (ox, oz) only the pieces touching that chunk are built. */
export function buildStronghold(t: StructHost, put: Put, cx: number, cz: number, ox?: number, oz?: number) {
  const L = strongholdLayout(t.seed, cx, cz);
  for (const p of L.pieces) {
    if (ox !== undefined && oz !== undefined && (p.box[3] < ox - 1 || p.box[0] > ox + 17 || p.box[5] < oz - 1 || p.box[2] > oz + 17)) continue;
    buildPiece(t, put, p);
  }
  return L;
}
