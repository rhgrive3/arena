//Shared toolkit for the Java-Edition structure pieces (villages, strongholds, mansions, ancient cities, bastions,
// end ships, jungle temples and igloos). Every builder is a pure function of the world seed and writes through `put`,
// which the chunk generator clips to the chunk being built.
import { ID } from '../../game/data';
import { makeCell } from '../../game/blockState';

export type Put = (x: number, y: number, z: number, id: number, replace?: boolean) => void;
/** The slice of `Terrain` the builders need – small enough to be mocked by the verification suite. */
export interface StructHost {
  seed: number;
  height(x: number, z: number): number;
  /** "x,y,z" → loot/contents table of a generated block entity (chest, dispenser, brewing stand, item frame). */
  structTags?: Map<string, string>;
}

/** Topmost water block (vanilla sea level 63 → Y 62); kept in sync with terrain.ts. */
export const SEA = 62;
const B = ID as Record<string, number | undefined>;
/** Block ID by name with a fallback (old saves / reduced registries never crash a builder). */
export const bid = (name: string, fallback = 'stone'): number => B[name] ?? B[fallback] ?? 1;
export const hasBlock = (name: string): boolean => B[name] !== undefined;
/** Block cell = ID + 4-bit state. */
export const cell = (name: string, state = 0, fallback = 'stone'): number => {
  const i = bid(name, fallback);
  return state && i > 0 ? makeCell(i, state & 15) : i;
};

export const hash2 = (x: number, z: number, seed: number) => {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
export const hash3 = (x: number, y: number, z: number, seed: number) => hash2(x + y * 131, z - y * 71, seed);
export function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export type BlockFn = number | ((x: number, y: number, z: number) => number);
const pick = (b: BlockFn, x: number, y: number, z: number) => (typeof b === 'number' ? b : b(x, y, z));
/** Solid box (bounds may be given in any order). */
export function fill(put: Put, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, block: BlockFn) {
  if (x0 > x1) [x0, x1] = [x1, x0];
  if (y0 > y1) [y0, y1] = [y1, y0];
  if (z0 > z1) [z0, z1] = [z1, z0];
  for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) put(x, y, z, pick(block, x, y, z), true);
}
/** Hollow box: `wall` on the six faces, `inside` (air by default) everywhere else. */
export function shell(put: Put, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, wall: BlockFn, inside: BlockFn = 0) {
  for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
    const edge = x === x0 || x === x1 || y === y0 || y === y1 || z === z0 || z === z1;
    put(x, y, z, pick(edge ? wall : inside, x, y, z), true);
  }
}

/** Remembers which loot table / fixed contents a generated block entity uses. */
export function tag(t: StructHost, x: number, y: number, z: number, table: string) {
  (t.structTags ??= new Map()).set(x + ',' + y + ',' + z, table);
}

// ---- Directions -------------------------------------------------------------------------------------------------------
// Horizontal world direction w: 0 = north (-z), 1 = east (+x), 2 = south (+z), 3 = west (-x).
export const DX = [0, 1, 0, -1] as const, DZ = [-1, 0, 1, 0] as const;
/** Stairs whose high side points towards w (so walking towards w climbs them). +4 = upside down. */
export const stairsUp = (w: number, upsideDown = false) => (w & 3) | (upsideDown ? 4 : 0);
/** Ladder / item frame hanging on the block that lies in direction w. */
export const ladderOn = (w: number) => [0, 3, 2, 1][w & 3];
/** Torch, lever, button or tripwire hook attached to the block that lies in direction w (0 = standing on the floor). */
export const attachOn = (w: number) => [3, 2, 4, 1][w & 3];
/** Piston / dispenser / dropper facing w. */
export const rsFacing = (w: number) => [3, 0, 1, 2][w & 3];
/** Door leaf standing on the w edge of its cell (add 4 for the upper half). */
export const doorOn = (w: number) => [0, 3, 2, 1][w & 3];
/** Glass pane / iron bars running along world X (1) or along world Z (0). */
export const PANE_X = 1, PANE_Z = 0;

/** Places a two-block door (lower + upper half). */
export function door(put: Put, x: number, y: number, z: number, name: string, w: number) {
  put(x, y, z, cell(name, doorOn(w), 'oak_door'), true);
  put(x, y + 1, z, cell(name, doorOn(w) | 4, 'oak_door'), true);
}
/** Bed: foot at (x, y, z); `facing` follows Terrain.placeBed (0 → head towards +z, 1 → -x, 2 → -z, 3 → +x). */
export function bed(put: Put, x: number, y: number, z: number, facing: number) {
  const dx = facing === 3 ? 1 : facing === 1 ? -1 : 0, dz = facing === 0 ? 1 : facing === 2 ? -1 : 0;
  put(x, y, z, cell('bed', facing, 'white_wool'), true);
  put(x + dx, y, z + dz, cell('bed', facing | 4, 'white_wool'), true);
}

// ---- Ground height memo (structures query the same columns for every chunk they touch) ----------------------------------
const HEIGHTS = new WeakMap<object, Map<number, number>>();
export function groundY(t: StructHost, x: number, z: number): number {
  let m = HEIGHTS.get(t);
  if (!m) { m = new Map(); HEIGHTS.set(t, m); }
  const k = (x + 2097152) * 4194304 + (z + 2097152);
  let h = m.get(k);
  if (h === undefined) { h = t.height(x, z); m.set(k, h); }
  return h;
}

/** Weathered stone bricks like vanilla strongholds: 50% plain stone bricks, 30% mossy stone bricks, 20% cracked stone bricks. */
export const stoneBrick = (seed: number) => (x: number, y: number, z: number) => {
  const r = hash3(x, y, z, seed);
  return r < 0.3 ? bid('mossy_stone_bricks', 'stone_bricks') : r < 0.5 ? bid('cracked_stone_bricks', 'stone_bricks') : bid('stone_bricks');
};
/** Jungle-temple masonry: cobblestone with mossy cobblestone mixed in. */
export const mossyCobble = (seed: number, ratio = 0.4) => (x: number, y: number, z: number) =>
  hash3(x, y, z, seed) < ratio ? bid('mossy_cobblestone', 'cobblestone') : bid('cobblestone');
