// Strict TDD Verification Suite for 100% Minecraft Java Edition 1.21 Parity
// Covers all 5 domains from the audit report:
//   1. Structures & Architecture (Woodland Mansion, End City/Ship, Trial Chambers, Ancient City, Bastion, 128 Strongholds,
//      Fortress/End City /locate, 58x23x58 Ocean Monument, Village Blueprints, Outpost rotation & cage spawn,
//      Swamp Hut mushroom & Witch+Black Cat spawn, Buried Treasure (9,~,9), Igloo infested stone bricks, Trail Ruins)
//   2. Blocks, BlockState, Waterlogging, Stair Corner Shapes, Double Chests & 3D Custom Block Shapes
//   3. World Generation, All 64 Biomes (including End sub-biomes & the_void), End Pillar Cages & 3D Sky Light BFS
//   4. Items (Spawn Eggs, Firework Star, Lingering Potions), All 39 Status Effects & All 42 Enchantments (binding_curse/vanishing_curse)
//   5. Mobs (cod, ender_dragon, trader_llama, illusioner, giant), A* Maze/Door/Lava Pathfinding & Redstone 0-Tick Piston / Moving Piston AABB

import * as THREE from 'three';
import '../src/game/content';
import { BLOCKS, ITEMS, ID, resolve } from '../src/game/data';
import * as BS from '../src/game/blockState';
import * as Shapes from '../src/world/shapes';
import * as LF from '../src/world/lightField';
import * as TMod from '../src/world/terrain';
import * as StructMod from '../src/world/structures';
import * as MansionMod from '../src/world/struct/mansionGrand';
import * as EndCityMod from '../src/world/struct/endCity';
import * as DungeonsMod from '../src/world/dungeons';
import * as VariantsMod from '../src/world/struct/variants';
import * as SeaMod from '../src/world/struct/sea';
import * as VillageGrandMod from '../src/world/struct/villageGrand';
import * as ExtraMod from '../src/world/struct/extra';
import * as MagicMod from '../src/systems/magic';
import * as MobDataMod from '../src/entities/mobdata';
import * as BehaviorsMod from '../src/entities/behaviors';
import * as PathMod from '../src/entities/pathfinding';
import * as RedstoneMod from '../src/systems/redstone';

let pass = 0;
let fail = 0;
const failures: string[] = [];

function ok(name: string, cond: boolean, detail: unknown = '') {
  if (cond) {
    pass++;
    console.log('PASS  ' + name);
  } else {
    fail++;
    const msg = name + (detail !== '' ? '  → ' + JSON.stringify(detail) : '');
    failures.push(msg);
    console.log('FAIL  ' + msg);
  }
}

class Cap {
  cells = new Map<string, number>();
  put = (x: number, y: number, z: number, cell: number, replace = true) => {
    const k = `${x},${y},${z}`;
    if (!replace && (this.cells.get(k) ?? 0) !== 0) return;
    if (cell === 0) this.cells.delete(k);
    else this.cells.set(k, cell);
  };
  cell(x: number, y: number, z: number): number {
    return this.cells.get(`${x},${y},${z}`) ?? 0;
  }
  id(x: number, y: number, z: number): number {
    return BS.blockId(this.cell(x, y, z));
  }
  state(x: number, y: number, z: number): number {
    return BS.blockState(this.cell(x, y, z));
  }
  name(x: number, y: number, z: number): string {
    const id = this.id(x, y, z);
    return id > 0 ? (BLOCKS[id]?.name ?? 'air') : 'air';
  }
  count(blockName: string): number {
    const target = (ID as Record<string, number>)[blockName];
    if (target === undefined) return 0;
    let n = 0;
    for (const c of this.cells.values()) if (BS.blockId(c) === target) n++;
    return n;
  }
  bounds(minFilterY = -Infinity): { minX: number; maxX: number; minY: number; maxY: number; minZ: number; maxZ: number; dx: number; dy: number; dz: number } {
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity, minZ = Infinity, maxZ = -Infinity;
    for (const [k, c] of this.cells) {
      if ((c & 0xfff) === 0) continue;
      const [x, y, z] = k.split(',').map(Number);
      if (y < minFilterY) continue;
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
    }
    return { minX, maxX, minY, maxY, minZ, maxZ, dx: maxX - minX + 1, dy: maxY - minY + 1, dz: maxZ - minZ + 1 };
  }
}

function makeHost(seed = 77, groundY = 69) {
  return {
    seed,
    dimension: 'overworld' as const,
    structTags: new Map<string, string>(),
    height: () => groundY,
    biome: () => 'dark_forest',
    biomeAt: () => 'dark_forest',
    spawnPoint: () => [0, groundY + 1, 0] as [number, number, number],
  };
}

console.log('=== 1. STRUCTURES & ARCHITECTURE PARITY ===');

// 1.1 Woodland Mansion: asymmetric MansionGrid exterior footprint varies by seed
{
  const w1 = new Cap(), w2 = new Cap();
  MansionMod.grandMansion(makeHost(77) as any, w1.put, { x: 0, y: 70, z: 0 });
  MansionMod.grandMansion(makeHost(849281) as any, w2.put, { x: 0, y: 70, z: 0 });
  const outerCols = (w: Cap) => {
    const s = new Set<string>();
    for (const [k, c] of w.cells) {
      const [x, y, z] = k.split(',').map(Number);
      if (y === 71 && (c & 0xfff) !== 0 && (Math.abs(x) > 32 || Math.abs(z) > 26)) s.add(`${x},${z}`);
    }
    return [...s].sort().join(';');
  };
  const o1 = outerCols(w1), o2 = outerCols(w2);
  ok('1.1a Woodland Mansion: MansionGrid drives asymmetric exterior extensions that vary per seed',
    o1.length > 0 && o2.length > 0 && o1 !== o2, [o1.length, o2.length]);
}

// 1.2 Woodland Mansion: room templates 2x2_b3 (180+ bookshelves), 1x2_a9 (42+ chests), 2x2_a1 (4 jail cells with 4 iron doors)
{
  const wLib = new Cap(), hLib = makeHost(77);
  MansionMod.buildMansionRoom(hLib as any, wLib.put, '2x2_b3', 0, 70, 0, 15, 15, 8, 'S');
  ok('1.2a Woodland Mansion 2x2_b3 (Large Library): contains >= 180 bookshelves',
    wLib.count('bookshelf') >= 180, wLib.count('bookshelf'));

  const wChest = new Cap(), hChest = makeHost(77);
  MansionMod.buildMansionRoom(hChest as any, wChest.put, '1x2_a9', 0, 70, 0, 7, 15, 8, 'S');
  ok('1.2b Woodland Mansion 1x2_a9 (Large Chest Room): contains >= 42 chests',
    wChest.count('chest') >= 42, wChest.count('chest'));

  const wJail = new Cap(), hJail = makeHost(77);
  MansionMod.buildMansionRoom(hJail as any, wJail.put, '2x2_a1', 0, 70, 0, 15, 15, 8, 'S');
  ok('1.2c Woodland Mansion 2x2_a1 (Large Jail): 4 cells with >= 8 iron_door blocks (4 doors) and >= 24 iron_bars',
    wJail.count('iron_door') >= 8 && wJail.count('iron_bars') >= 24, [wJail.count('iron_door'), wJail.count('iron_bars')]);
}

// 1.3 Woodland Mansion: Secret rooms are completely walled off from corridors (no open doorway) & 1x2_a6 entrance is boarded with birch_planks
{
  const w = new Cap(), h = makeHost(77);
  const rooms = MansionMod.grandMansion(h as any, w.put, { x: 0, y: 70, z: 0 });
  const secretRooms = rooms.filter(r => r.secret);
  const allSealed = secretRooms.length >= 4 && secretRooms.every(r => {
    const wallX = r.wing > 0 ? (r.column === 0 ? 15 + 7 : 15 + 11) : (r.column === 0 ? -15 - 7 : -15 - 11);
    const n0 = w.name(wallX, r.y, r.doorZ), n1 = w.name(wallX, r.y + 1, r.doorZ);
    return n0 !== 'air' && n1 !== 'air';
  });
  ok('1.3a Woodland Mansion: all secret rooms (secret=true) have their corridor wall completely sealed (no doorway opening)',
    allSealed, secretRooms.length);

  const wTree = new Cap(), hTree = makeHost(77);
  MansionMod.buildMansionRoom(hTree as any, wTree.put, '1x2_a6', 0, 70, 0, 7, 15, 8, 'S');
  ok('1.3b Woodland Mansion 1x2_a6 (Tree-chopping room): entrance is boarded up with birch_planks',
    wTree.count('birch_planks') >= 6 && wTree.count('dark_oak_log') >= 2, [wTree.count('birch_planks'), wTree.count('dark_oak_log')]);

  // 1.3c Biome restriction: validate('mansion') only permits dark_forest
  const mockForest = {
    seed: 123, dimension: 'overworld', height: () => 70, spawnPoint: () => [0, 70, 0],
    biomeAt: () => 'forest', biome: () => 'forest',
  };
  const mockBirch = {
    seed: 123, dimension: 'overworld', height: () => 70, spawnPoint: () => [0, 70, 0],
    biomeAt: () => 'old_growth_birch_forest', biome: () => 'old_growth_birch_forest',
  };
  ok('1.3c Woodland Mansion: never generates in regular forest or old_growth_birch_forest (dark_forest only)',
    StructMod.siteAt(mockForest as any, 'mansion', 2, 2) === null &&
    StructMod.siteAt(mockBirch as any, 'mansion', 2, 2) === null);
}

// 1.4 End City & End Ship: overhanging upside-down purpur_stairs roof rims & spiral staircases
{
  const w = new Cap(), h = makeHost(849281);
  EndCityMod.buildEndCity(h as any, w.put, 510, 28, 0, undefined, undefined, true);
  let invertedStairs = 0, normalStairs = 0;
  const stairId = ID.purpur_stairs;
  for (const c of w.cells.values()) {
    if (BS.blockId(c) === stairId) {
      if (BS.blockState(c) & 4) invertedStairs++;
      else normalStairs++;
    }
  }
  const slabs = w.count('purpur_slab');
  ok('1.4 End City: builds overhanging upside-down purpur_stairs roof eaves (>= 120 inverted stairs) & internal spiral staircases (>= 50 slabs)',
    invertedStairs >= 120 && normalStairs >= 40 && slabs >= 50, [invertedStairs, normalStairs, slabs]);
}

// 1.5 Trial Chambers: multi-layer atrium (height >= 14), water traps & waxed copper / copper doors / oxidized bulbs
{
  const t = new TMod.Terrain('849281'), w = new Cap();
  DungeonsMod.trialChambers(t, w.put, { kind: 'trial_chambers', x: 0, y: -30, z: 0 });
  const b = w.bounds();
  ok('1.5 Trial Chambers: multi-storey atrium/gallery (height >= 14) with waxed_copper_block, copper_door, copper_trapdoor & oxidized_copper_bulb',
    b.dy >= 14 && w.count('waxed_copper_block') > 0 && w.count('copper_door') > 0 && w.count('copper_trapdoor') > 0 && w.count('oxidized_copper_bulb') > 0,
    [b.dy, w.count('waxed_copper_block'), w.count('copper_door'), w.count('copper_trapdoor'), w.count('oxidized_copper_bulb')]);
}

// 1.6 Ancient City: expansive 100+ block footprint with 10+ peripheral Jigsaw modules
{
  const h = makeHost(849281), w = new Cap();
  const plan = VariantsMod.ancientCityPlan(849281, { x: 0, y: -51, z: 0 });
  VariantsMod.ancientCity(h as any, w.put, { x: 0, y: -51, z: 0 });
  const b = w.bounds();
  ok('1.6 Ancient City: spans >= 100x90 blocks with >= 10 peripheral Jigsaw modules while keeping 5 city chests',
    b.dx >= 100 && b.dz >= 90 && plan.modules.length >= 10 && w.count('chest') === 5,
    [b.dx, b.dz, plan.modules.length, w.count('chest')]);
}

// 1.7 Bastion Remnant: large multi-tier fortress (>= 39x26x39) with deep lava basin in treasure variant
{
  const h = makeHost(21), w = new Cap();
  VariantsMod.bastion(h as any, w.put, { x: 0, y: 32, z: 0 }, 'treasure');
  const b = w.bounds();
  ok('1.7 Bastion Remnant: multi-tier footprint >= 39x26x39 with deep lava basin (minY <= 24)',
    b.dx >= 39 && b.dy >= 26 && b.dz >= 39 && b.minY <= 24, [b.dx, b.dy, b.dz, b.minY]);
}

// 1.8 Strongholds: 128 strongholds across 8 concentric rings [3, 6, 10, 15, 21, 28, 36, 9]
{
  const t = new TMod.Terrain('849281');
  const rings = typeof (t as any).strongholdRings === 'function' ? (t as any).strongholdRings() : [];
  const locOrigin = t.locate('stronghold', 0, 0);
  const locFar = t.locate('stronghold', 5000, 0);
  ok('1.8 Strongholds: 128 strongholds across 8 concentric rings (radii 1,280..24,320) and dynamic /locate in outer rings',
    rings.length === 128 &&
    Math.hypot(rings[0][0], rings[0][1]) >= 1200 &&
    Math.hypot(rings[127][0], rings[127][1]) <= 24500 &&
    locOrigin !== null && locFar !== null &&
    (locOrigin[0] !== locFar[0] || locOrigin[2] !== locFar[2]),
    [rings.length, locOrigin, locFar]);
}

// 1.9 Nether Fortress & End City dynamic /locate
{
  const tn = new TMod.Terrain('849281', 'nether');
  const f0 = tn.locate('fortress', 0, 0);
  const fFar = tn.locate('fortress', 2400, 2400);
  ok('1.9a Nether Fortress /locate: finds nearest regional fortress instead of always returning [32, 48, 32]',
    f0 !== null && fFar !== null && (f0[0] !== fFar[0] || f0[2] !== fFar[2]) && Math.hypot(fFar[0] - 2400, fFar[2] - 2400) < 600,
    [f0, fFar]);

  const te = new TMod.Terrain('849281', 'end');
  const c0 = te.locate('end_city', 0, 0);
  const cFar = te.locate('end_city', 3200, 3200);
  ok('1.9b End City /locate: finds nearest outer-island End City instead of always returning END_FIRST_CITY',
    c0 !== null && cFar !== null && (c0[0] !== cFar[0] || c0[2] !== cFar[2]) && Math.hypot(cFar[0] - 3200, cFar[2] - 3200) < 900,
    [c0, cFar]);
}

// 1.10 Ocean Monument: exact 58x23x58 dimensions above floor (y >= p.y)
{
  const h = { ...makeHost(9, 30), height: () => 30 }, w = new Cap();
  SeaMod.oceanMonument(h as any, w.put, { x: 0, y: 39, z: 0 });
  const b = w.bounds(39);
  ok('1.10 Ocean Monument: exact 58×23×58 exterior dimensions above floor (y >= 39)',
    b.dx === 58 && b.dy === 23 && b.dz === 58, [b.dx, b.dy, b.dz]);
}

// 1.11 Village Blueprints: official Wiki blueprint registry & per-piece blueprint ID assignment
{
  const blueprints = (VillageGrandMod as any).VILLAGE_BLUEPRINTS as string[] | undefined;
  const h = makeHost(42, 70);
  const L = VillageGrandMod.grandVillageLayout(h as any, 0, 0, 'plains');
  const assigned = L.buildings.filter(p => typeof p.meta.blueprint === 'string' && (p.meta.blueprint as string).startsWith('plains_'));
  ok('1.11 Village Blueprints: >= 40 canonical Wiki blueprint IDs registered and assigned to every village building',
    Array.isArray(blueprints) && blueprints.length >= 40 && assigned.length === L.buildings.length && L.buildings.length >= 6,
    [blueprints?.length ?? 0, assigned.length, L.buildings.length]);
}

// 1.12 Pillager Outpost: 4-way rotation & cage Iron Golem / Allay spawning in populateStructures
{
  const rotFn = (StructMod as any).outpostRotation as ((seed: number, x: number, z: number) => number) | undefined;
  const rots = new Set<number>();
  if (typeof rotFn === 'function') {
    for (let i = 0; i < 40; i++) rots.add(rotFn(849281, i * 160, -i * 96));
  }
  ok('1.12a Pillager Outpost: outpostRotation produces all 4 cardinal rotations (0..3)',
    rots.size === 4, [...rots]);
}

// 1.13 Swamp Hut: potted mushroom on window sill & Witch + Black Cat spawn in populateStructures
{
  const t = new TMod.Terrain('849281'), w = new Cap();
  t.witchHut(w.put, () => {}, 0, 0);
  const hasMushroom = w.count('red_mushroom') + w.count('brown_mushroom') + w.count('potted_red_mushroom') >= 1;
  ok('1.13a Swamp Hut (Witch Hut): contains a potted mushroom in the window',
    hasMushroom, [w.count('red_mushroom'), w.count('brown_mushroom')]);

  // Verify populateStructures spawns witch + black cat at witch_hut AND iron_golem/allay at outpost
  const spawned: { species: string; x: number; y: number; z: number; variant?: string }[] = [];
  const mockTerrain = {
    seed: 849281,
    dimension: 'overworld',
    height: () => 64,
    biome: () => 'swamp',
    biomeAt: () => 'swamp',
    spawnPoint: () => [0, 65, 0],
    locate: (what: string) => {
      if (what === 'witch_hut') return [10, 66, 10] as [number, number, number];
      if (what === 'outpost') return [12, 65, 12] as [number, number, number];
      return null;
    },
  };
  const mockCtx = {
    scene: new THREE.Scene(),
    mobs: [],
    timeline: 0,
    rnd: () => 0.3,
    host: {
      terrain: mockTerrain,
      position: new THREE.Vector3(10, 66, 10),
      dimension: 'overworld',
      getBlock: () => ID.spruce_planks,
      sound: () => {},
    },
    spawn: (species: string, x: number, z: number, _baby?: boolean, y?: number) => {
      const m: any = { species, x, y: y ?? 66, z, group: { position: new THREE.Vector3(x, y ?? 66, z) } };
      spawned.push(m);
      return m;
    },
  };
  const mb = new BehaviorsMod.MobBehaviors(mockCtx as any);
  (mb as any).populateStructures();
  const hasWitch = spawned.some(s => s.species === 'witch');
  const hasBlackCat = spawned.some(s => s.species === 'cat' && s.variant === 'black');
  const hasCageAlly = spawned.some(s => s.species === 'iron_golem' || s.species === 'allay');
  ok('1.13b Swamp Hut & Outpost Spawning: populateStructures spawns Witch + Black Cat in Swamp Hut and Iron Golem/Allay in Outpost cage',
    hasWitch && hasBlackCat && hasCageAlly, spawned.map(s => [s.species, s.variant]));
}

// 1.14 Buried Treasure chunk offset (9, ~, 9), Igloo infested_stone_bricks & Trail Ruins street length
{
  const t = new TMod.Terrain('849281');
  const treasures: [number, number, number][] = [];
  for (let i = -5; i <= 5; i++) {
    const loc = StructMod.locateExtra(t, 'buried_treasure', i * 400, i * 300);
    if (loc) treasures.push(loc);
  }
  ok('1.14a Buried Treasure: always placed at chunk-local coordinates (9, ~, 9)',
    treasures.length > 0 && treasures.every(([x, , z]) => ((x % 16) + 16) % 16 === 9 && ((z % 16) + 16) % 16 === 9),
    treasures.slice(0, 3));

  const tig = makeHost(55, 79), wig = new Cap();
  ExtraMod.igloo(tig as any, wig.put, { x: -789, y: 80, z: 170 });
  ok('1.14b Igloo basement: contains infested_stone_bricks hidden under the carpet',
    wig.count('infested_stone_bricks') >= 1, wig.count('infested_stone_bricks'));

  const trL = DungeonsMod.trailRuinsLayout(849281, 200, 72, 200);
  const trW = new Cap();
  DungeonsMod.trailRuins(t, trW.put, { kind: 'trail_ruins', x: 200, y: 72, z: 200 });
  const trB = trW.bounds();
  ok('1.14c Trail Ruins: extended buried street network (>= 14 pieces, span >= 24 blocks)',
    trL.pieces.length >= 14 && Math.max(trB.dx, trB.dz) >= 24, [trL.pieces.length, trB.dx, trB.dz]);
}

console.log('\n=== 2. BLOCKS, BLOCKSTATES, SHAPES, WATERLOGGING & DOUBLE CHESTS ===');

// 2.1 Missing Block Families
{
  const COLORS = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black'];
  const allBeds = COLORS.every(c => (ID as any)[`${c}_bed`] !== undefined);
  const allShulkers = COLORS.every(c => (ID as any)[`${c}_shulker_box`] !== undefined);
  const allGlassPanes = COLORS.every(c => (ID as any)[`${c}_stained_glass_pane`] !== undefined);
  const allGlazed = COLORS.every(c => (ID as any)[`${c}_glazed_terracotta`] !== undefined);
  const allCandles = (ID as any).candle !== undefined && COLORS.every(c => (ID as any)[`${c}_candle`] !== undefined);
  const CORALS = ['tube', 'brain', 'bubble', 'fire', 'horn'];
  const allCorals = CORALS.every(c => (ID as any)[`dead_${c}_coral_block`] !== undefined && (ID as any)[`${c}_coral_fan`] !== undefined && (ID as any)[`dead_${c}_coral_fan`] !== undefined);
  const allCopper = ['copper_door', 'copper_trapdoor', 'waxed_copper_block', 'waxed_cut_copper', 'waxed_chiseled_copper', 'waxed_copper_grate', 'waxed_copper_bulb', 'exposed_copper_bulb', 'weathered_copper_bulb', 'oxidized_copper_bulb'].every(k => (ID as any)[k] !== undefined);
  const WOODS = ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak', 'mangrove', 'cherry', 'bamboo', 'crimson', 'warped'];
  const allSigns = WOODS.every(w => (ID as any)[`${w}_sign`] !== undefined && (ID as any)[`${w}_hanging_sign`] !== undefined);
  const techAndBamboo = ['bamboo_mosaic', 'bamboo_mosaic_stairs', 'bamboo_mosaic_slab', 'command_block', 'structure_block', 'jigsaw', 'barrier', 'light', 'infested_stone_bricks'].every(k => (ID as any)[k] !== undefined);

  ok('2.1a All 16 colored beds & 16 colored shulker boxes are registered', allBeds && allShulkers, [allBeds, allShulkers]);
  ok('2.1b All 16 stained glass panes, 16 glazed terracotta & 17 candles are registered', allGlassPanes && allGlazed && allCandles, [allGlassPanes, allGlazed, allCandles]);
  ok('2.1c All 5 dead coral blocks & 10 coral fans (live + dead) are registered', allCorals);
  ok('2.1d Copper doors/trapdoors, waxed copper family & oxidized copper bulbs are registered', allCopper);
  ok('2.1e All 11 wood signs & hanging signs, bamboo mosaic & technical blocks are registered', allSigns && techAndBamboo, [allSigns, techAndBamboo]);
}

// 2.2 Waterlogging support
{
  const canWl = (BS as any).canWaterlog as ((def: any) => boolean) | undefined;
  const setWl = (BS as any).setWaterloggedAt as ((x: number, y: number, z: number, v: boolean) => void) | undefined;
  const isWl = (BS as any).isWaterloggedAt as ((x: number, y: number, z: number, cell?: number) => boolean) | undefined;
  const withWl = (BS as any).withWaterlogged as ((cell: number, v?: boolean) => number) | undefined;
  const cellWl = (BS as any).isCellWaterlogged as ((cell: number) => boolean) | undefined;

  let wlOk = false;
  if (typeof canWl === 'function' && typeof setWl === 'function' && typeof isWl === 'function' && typeof withWl === 'function' && typeof cellWl === 'function') {
    const slabCell = withWl(BS.makeCell(ID.oak_slab, 1), true);
    setWl(10, 64, 10, true);
    wlOk =
      canWl(BLOCKS[ID.oak_stairs]) &&
      canWl(BLOCKS[ID.oak_slab]) &&
      canWl(BLOCKS[ID.chest]) &&
      canWl(BLOCKS[ID.oak_fence]) &&
      canWl(BLOCKS[ID.iron_bars]) &&
      canWl(BLOCKS[ID.lantern]) &&
      canWl(BLOCKS[ID.oak_trapdoor]) &&
      !canWl(BLOCKS[ID.stone]) &&
      cellWl(slabCell) &&
      isWl(10, 64, 10);
    setWl(10, 64, 10, false);
  }
  ok('2.2 Waterlogging: supports cell bit & world-coordinate waterlogging on stairs, slabs, chests, fences, iron_bars, lanterns & trapdoors', wlOk);
}

// 2.3 Stair corner shapes (inner_left, inner_right, outer_left, outer_right)
{
  const shapeAt = (Shapes as any).stairShapeAt as ((getCell: (x: number, y: number, z: number) => number, x: number, y: number, z: number) => string) | undefined;
  const boxesAt = (Shapes as any).stairBoxesAt as ((getCell: (x: number, y: number, z: number) => number, x: number, y: number, z: number) => readonly any[]) | undefined;
  let stairOk = false;
  if (typeof shapeAt === 'function' && typeof boxesAt === 'function') {
    const w = new Cap();
    // Place stair at (0,0,0) facing 0 (-Z step). Behind it at (0,0,-1) place perpendicular stair facing 1 (+X step) -> outer_right
    w.put(0, 0, 0, BS.makeCell(ID.oak_stairs, 0));
    const sStraight = shapeAt((x, y, z) => w.cell(x, y, z), 0, 0, 0);
    w.put(0, 0, -1, BS.makeCell(ID.oak_stairs, 1));
    const sOuterR = shapeAt((x, y, z) => w.cell(x, y, z), 0, 0, 0);
    w.put(0, 0, -1, BS.makeCell(ID.oak_stairs, 3));
    const sOuterL = shapeAt((x, y, z) => w.cell(x, y, z), 0, 0, 0);
    w.put(0, 0, -1, 0);
    w.put(0, 0, 1, BS.makeCell(ID.oak_stairs, 1));
    const sInnerR = shapeAt((x, y, z) => w.cell(x, y, z), 0, 0, 0);
    w.put(0, 0, 1, BS.makeCell(ID.oak_stairs, 3));
    const sInnerL = shapeAt((x, y, z) => w.cell(x, y, z), 0, 0, 0);
    const bStraight = JSON.stringify(boxesAt((x, y, z) => 0, 0, 0, 0));
    const bInnerL = JSON.stringify(boxesAt((x, y, z) => w.cell(x, y, z), 0, 0, 0));
    stairOk =
      sStraight === 'straight' &&
      sOuterR === 'outer_right' &&
      sOuterL === 'outer_left' &&
      sInnerR === 'inner_right' &&
      sInnerL === 'inner_left' &&
      bStraight !== bInnerL;
  }
  ok('2.3 Stair Corner Shapes: stairShapeAt & stairBoxesAt compute straight, outer_left, outer_right, inner_left, inner_right with 3D corner step boxes', stairOk);
}

// 2.4 Double Chest (Large Chest) 54-slot pairing
{
  const partnerFn = (BS as any).doubleChestPartner as ((getCell: (x: number, y: number, z: number) => number, x: number, y: number, z: number) => [number, number, number] | null) | undefined;
  const slotsFn = (BS as any).getDoubleChestSlots as ((containers: Record<string, any[]>, getCell: (x: number, y: number, z: number) => number, x: number, y: number, z: number) => any[]) | undefined;
  let chestOk = false;
  if (typeof partnerFn === 'function' && typeof slotsFn === 'function') {
    const w = new Cap();
    w.put(5, 64, 5, BS.makeCell(ID.chest, 0)); // facing 0 (along Z), so adjacent partner is along X at (6, 64, 5)
    w.put(6, 64, 5, BS.makeCell(ID.chest, 0));
    const p = partnerFn((x, y, z) => w.cell(x, y, z), 5, 64, 5);
    const containers: Record<string, any[]> = {};
    const combined = slotsFn(containers, (x, y, z) => w.cell(x, y, z), 5, 64, 5);
    chestOk = p !== null && p[0] === 6 && p[1] === 64 && p[2] === 5 && combined.length === 54;
  }
  ok('2.4 Double Chest: adjacent matching chests pair into a 54-slot Large Chest inventory', chestOk);
}

// 2.5 Custom 3D Shapes for Hopper, Cauldron, Composter, Lectern, Stonecutter, Bell & Chain
{
  const names = ['hopper', 'cauldron', 'composter', 'lectern', 'stonecutter', 'bell', 'chain'];
  const fullCube = JSON.stringify([[0, 0, 0, 1, 1, 1]]);
  const allCustom = names.every(n => {
    const def = BLOCKS[(ID as any)[n]];
    if (!def) return false;
    const boxes = Shapes.modelBoxes(def, 0);
    return boxes.length > 0 && JSON.stringify(boxes) !== fullCube;
  });
  ok('2.5 Custom 3D Block Models: hopper, cauldron, composter, lectern, stonecutter, bell & chain all have non-cube 3D modelBoxes',
    allCustom, names.map(n => [n, Shapes.modelBoxes(BLOCKS[(ID as any)[n]], 0).length]));
}

console.log('\n=== 3. WORLD GENERATION, 64 BIOMES, END PILLARS & 3D SKY LIGHT ===');

// 3.1 All 64 Java Edition 1.21 Biomes (including End sub-biomes & the_void)
{
  const allLabels = (TMod as any).ALL_BIOME_LABELS as Record<string, any> | undefined;
  const te = new TMod.Terrain('849281', 'end');
  const seenEnd = new Set<string>();
  seenEnd.add(te.biome(0, 0));
  for (let r = 150; r <= 2400; r += 50) {
    for (const [x, z] of [[r, 0], [r, r], [-r, r], [0, -r]]) {
      seenEnd.add(te.biome(x, z));
    }
  }
  ok('3.1 All 64 Java Edition 1.21 Biomes: ALL_BIOME_LABELS has 64 biomes and End generator produces the_end, end_highlands, end_midlands, small_end_islands, end_barrens',
    !!allLabels && Object.keys(allLabels).length === 64 &&
    ['the_end', 'end_highlands', 'end_midlands', 'small_end_islands', 'end_barrens'].every(b => seenEnd.has(b) && !!allLabels[b]) &&
    !!allLabels.the_void,
    [allLabels ? Object.keys(allLabels).length : 0, [...seenEnd]]);
}

// 3.2 End Pillars: 2 caged pillars with full iron_bars walls, roof & hollow interior
{
  const pillars = TMod.endPillars();
  const caged = pillars.filter(p => p.caged);
  const te = new TMod.Terrain('849281', 'end');
  const chunkMap = new Map<string, Uint16Array>();
  const getEndBlock = (wx: number, wy: number, wz: number) => {
    const cx = wx >> 4, cz = wz >> 4, k = `${cx},${cz}`;
    let data = chunkMap.get(k);
    if (!data) { data = te.generate(cx, cz, [], true).data; chunkMap.set(k, data); }
    const lx = ((wx % 16) + 16) % 16, lz = ((wz % 16) + 16) % 16;
    return BLOCKS[BS.blockId(data[TMod.blockIndex(lx, wy, lz)])]?.name ?? 'air';
  };
  const cagesOk = caged.length === 2 && caged.every(p =>
    getEndBlock(p.x + 2, p.h + 2, p.z) === 'iron_bars' &&
    getEndBlock(p.x - 2, p.h + 2, p.z) === 'iron_bars' &&
    getEndBlock(p.x, p.h + 4, p.z) === 'iron_bars' &&
    getEndBlock(p.x, p.h + 1, p.z) === 'bedrock'
  );
  ok('3.2 End Pillars: 2 pillars generate complete iron_bars cages (walls + roof at h+4 + bedrock base)', cagesOk);
}

// 3.3 3D Sky Light BFS propagation (skyLightAt in lightField.ts)
{
  const skyFn = (LF as any).skyLightAt as ((getBlock: (x: number, y: number, z: number) => number, x: number, y: number, z: number) => number) | undefined;
  let skyOk = false;
  if (typeof skyFn === 'function') {
    // Build a roof at y=70 covering x >= 0 (x < 0 is open sky)
    const getB = (x: number, y: number, z: number) => {
      if (y === 60) return ID.stone;
      if (y === 70 && x >= 0 && Math.abs(z) <= 10) return ID.stone;
      return 0;
    };
    const lOpen = skyFn(getB, -1, 65, 0);
    const lUnder0 = skyFn(getB, 0, 65, 0);
    const lUnder1 = skyFn(getB, 1, 65, 0);
    const lUnder2 = skyFn(getB, 2, 65, 0);
    skyOk = lOpen === 15 && lUnder0 === 14 && lUnder1 === 13 && lUnder2 === 12;
  }
  ok('3.3 3D Sky Light BFS: skyLightAt propagates 15 in open sky and decays 14 -> 13 -> 12 laterally under cave overhangs', skyOk);
}

console.log('\n=== 4. ITEMS, 39 STATUS EFFECTS & 42 ENCHANTMENTS ===');

// 4.1 All 39 Status Effects
{
  const effKeys = Object.keys(MagicMod.EFFECTS);
  ok('4.1 Status Effects: all 39 Java Edition 1.21 effects registered (including luck, unluck, health_boost, dolphins_grace)',
    effKeys.length === 39 && ['luck', 'unluck', 'health_boost', 'dolphins_grace'].every(k => !!MagicMod.EFFECTS[k]),
    effKeys.length);
}

// 4.2 Enchantments: binding_curse and vanishing_curse registry IDs resolve & work with lvl()
{
  const hasBinding = !!MagicMod.ENCHANT_BY_ID.binding_curse && !!MagicMod.ENCHANT_BY_ID.curse_of_binding;
  const hasVanishing = !!MagicMod.ENCHANT_BY_ID.vanishing_curse && !!MagicMod.ENCHANT_BY_ID.curse_of_vanishing;
  const st = { name: 'diamond_chestplate', count: 1, ench: { binding_curse: 1, vanishing_curse: 1 } };
  const lvlOk = MagicMod.lvl(st as any, 'curse_of_binding') === 1 && MagicMod.lvl(st as any, 'binding_curse') === 1 &&
                MagicMod.lvl(st as any, 'curse_of_vanishing') === 1 && MagicMod.lvl(st as any, 'vanishing_curse') === 1;
  ok('4.2 Enchantments: official Java 1.21 IDs binding_curse & vanishing_curse resolve in ENCHANT_BY_ID and lvl()',
    hasBinding && hasVanishing && lvlOk);
}

// 4.3 Missing Items: Spawn Eggs, Firework Star & Lingering Potions
{
  const reqItems = [
    'firework_star', 'lingering_potion', 'lingering_swiftness', 'lingering_healing', 'lingering_harming', 'lingering_poison', 'lingering_regeneration',
    'zombie_spawn_egg', 'skeleton_spawn_egg', 'creeper_spawn_egg', 'spider_spawn_egg', 'enderman_spawn_egg',
    'villager_spawn_egg', 'iron_golem_spawn_egg', 'witch_spawn_egg', 'pillager_spawn_egg', 'warden_spawn_egg', 'breeze_spawn_egg',
  ];
  const allExist = reqItems.every(n => !!resolve(n));
  ok('4.3 Items: firework_star, lingering potions & mob spawn eggs are registered in item registry',
    allExist && ITEMS.length >= 500, [allExist, ITEMS.length]);
}

console.log('\n=== 5. MOBS, A* PATHFINDING & REDSTONE 0-TICK / MOVING PISTONS ===');

// 5.1 Canonical Mob IDs (cod, ender_dragon, trader_llama, illusioner, giant)
{
  const reqMobs = ['cod', 'ender_dragon', 'trader_llama', 'illusioner', 'giant'];
  const allInNew = reqMobs.every(m => !!(MobDataMod.NEW_SPECIES as any)[m]);
  ok('5.1 Mob Registry: canonical Java 1.21 mob IDs (cod, ender_dragon, trader_llama, illusioner, giant) are registered',
    allInNew, reqMobs.filter(m => !(MobDataMod.NEW_SPECIES as any)[m]));
}

// 5.2 A* Pathfinding: maze detour, wooden door traversal (openDoors: true) & lava avoidance
{
  const w = new Cap();
  for (let x = -10; x <= 10; x++) for (let z = -10; z <= 10; z++) w.put(x, 63, z, ID.stone);
  // Wall across x = 2 from z = -5 to z = 5 with a wooden oak_door at (2, 64, 0)
  for (let z = -5; z <= 5; z++) {
    for (let y = 64; y <= 65; y++) {
      w.put(2, y, z, z === 0 ? BS.makeCell(ID.oak_door, y === 65 ? 4 : 0) : ID.stone);
    }
  }
  const pathWithDoor = PathMod.findPath((x, y, z) => w.id(x, y, z), 0, 64, 0, 4, 64, 0, { maxNodes: 400, openDoors: true } as any);
  const throughDoor = Array.isArray(pathWithDoor) && pathWithDoor.some(p => p.x === 2 && p.z === 0);
  ok('5.2 A* Pathfinding: navigates through closed wooden doors when openDoors=true and detours around walls',
    throughDoor && Array.isArray(pathWithDoor) && pathWithDoor[pathWithDoor.length - 1].x === 4);
}

// 5.3 Redstone 0-tick piston block spit & moving_piston interpolated collision box
{
  const cells = new Map<string, number>();
  const k = (x: number, y: number, z: number) => `${x},${y},${z}`;
  const host: RedstoneMod.RedstoneHost = {
    getCell: (x, y, z) => cells.get(k(x, y, z)) ?? 0,
    setBlock: (x, y, z, id, state = 0) => {
      if (id === 0) cells.delete(k(x, y, z));
      else cells.set(k(x, y, z), BS.makeCell(id, state));
      return true;
    },
  };
  const rs = new RedstoneMod.Redstone(host);
  // Sticky piston at (0, 64, 0) facing +X (state 0), stone block in front at (1, 64, 0)
  rs.set(0, 64, 0, ID.sticky_piston, 0);
  rs.set(1, 64, 0, ID.stone, 0);
  const ztFn = (rs as any).zeroTickPiston as ((x: number, y: number, z: number) => boolean) | undefined;
  const moveBoxFn = (RedstoneMod as any).movingPistonBox as ((move: any, progress: number) => readonly number[]) | undefined;
  let ztOk = false;
  if (typeof ztFn === 'function' && typeof moveBoxFn === 'function') {
    const didSpit = ztFn.call(rs, 0, 64, 0);
    // After 0-tick pulse: sticky piston at (0,64,0) is retracted (state 0), (1,64,0) is air (0), and stone is spat out to (2,64,0)!
    const boxHalf = moveBoxFn({ x: 1, y: 64, z: 0, dx: 1, dy: 0, dz: 0, cell: ID.stone }, 0.5);
    ztOk =
      didSpit &&
      BS.blockId(host.getCell(0, 64, 0)) === ID.sticky_piston &&
      (BS.blockState(host.getCell(0, 64, 0)) & 8) === 0 &&
      BS.blockId(host.getCell(1, 64, 0)) === 0 &&
      BS.blockId(host.getCell(2, 64, 0)) === ID.stone &&
      boxHalf.length === 6 && Math.abs(boxHalf[0] - 1.5) < 1e-6 && Math.abs(boxHalf[3] - 2.5) < 1e-6;
  }
  ok('5.3 Redstone 0-Tick & Moving Piston: zeroTickPiston spits block to (x+2) in 0 ticks and movingPistonBox interpolates collision AABB', ztOk);
}

console.log(`\n=== SUMMARY: ${pass} passed, ${fail} failed ===`);
if (fail > 0) {
  process.exit(1);
}
