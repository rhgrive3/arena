/*
 * Work A — player physics against Java Edition 1.21 reference values (logic only, no browser).
 * Run: npx tsx scripts/test-player-physics.ts
 */
import '../src/game/content';
import { BLOCKS, ID, resolve } from '../src/game/data';
import * as PP from '../src/game/playerPhysics';
import { breakTicks, miningTime, FATIGUE_MULTIPLIER } from '../src/systems/mining';
import { random } from '../src/input/math';

const results: { name: string; ok: boolean; info: string }[] = [];
function check(name: string, ok: boolean, info = '') {
  results.push({ name, ok, info });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${info ? '  — ' + info : ''}`);
}
const near = (a: number, b: number, tol: number) => Math.abs(a - b) <= tol;
const f3 = (n: number) => n.toFixed(3);

class World implements PP.MotionWorld {
  solid = new Set<string>();
  constructor(public floor = 0) {}
  set(x: number, y: number, z: number) { this.solid.add(`${x},${y},${z}`); }
  isSolid(x: number, y: number, z: number) { return y < this.floor || this.solid.has(`${x},${y},${z}`); }
  collides(x: number, y: number, z: number, h: number) {
    const x0 = Math.floor(x - 0.3), x1 = Math.floor(x + 0.3), y0 = Math.floor(y + 0.001), y1 = Math.floor(y + h - 0.001), z0 = Math.floor(z - 0.3), z1 = Math.floor(z + 0.3);
    for (let by = y0; by <= y1; by++) for (let bz = z0; bz <= z1; bz++) for (let bx = x0; bx <= x1; bx++) if (this.isSolid(bx, by, bz)) return true;
    return false;
  }
}
const env = (o: Partial<PP.TickEnv> = {}): PP.TickEnv => ({
  mode: 'walk', height: 1.8, water: false, lava: false, lavaDeep: false, climbable: false, swimming: false, waterAbove: false,
  speed: PP.BASE_SPEED, inputScale: 1, slip: PP.DEFAULT_SLIP, blockSpeed: 1, jumpPower: PP.JUMP_POWER, slowFalling: false,
  levitation: 0, flySpeed: PP.FLY_SPEED, depthStrider: 0, dolphinsGrace: false, stuck: 1, ...o,
});
// yaw 0: forward = (−sin 0, −cos 0) = (0, −1)
const inp = (o: Partial<PP.TickInput> = {}): PP.TickInput => ({ mx: 0, mz: -1, jump: false, descend: false, sneak: false, sprint: false, yaw: 0, pitch: 0, ...o });
// Standing still in Java: gravity is applied every tick, so a grounded body carries vy = −0.08 × 0.98 into the next move.
const grounded = (y = 0) => { const b = PP.newBody(0.5, y, 0.5); b.onGround = true; b.vy = -PP.GRAVITY * PP.DRAG_Y; return b; };
/** Distance still covered after releasing the keys: u + u·r + … while the speed is ≥ 0.003 (aiStep zeroes smaller components). */
const coast = (u: number, r: number) => { let d = 0; for (let v = u; v >= PP.MIN_VELOCITY; v *= r) d += v; return d; };
/** Steady horizontal speed (m/s) after `n` ticks and the tick at which 90 % of it was first reached. */
function steady(e: PP.TickEnv, i: PP.TickInput, n = 120, b = grounded(), w: PP.MotionWorld = new World()) {
  const speeds: number[] = [];
  for (let t = 0; t < n; t++) { const r = PP.playerTick(b, i, e, w); speeds.push(Math.hypot(r.dx, r.dz) * PP.TPS); }
  const top = speeds[speeds.length - 1];
  return { top, t90: speeds.findIndex(s => s >= 0.9 * top) + 1, body: b };
}
function stopDistance(e: PP.TickEnv) {
  const w = new World(), b = steady(e, inp(), 200, grounded(), w).body;
  let d = 0;
  for (let t = 0; t < 400; t++) { const r = PP.playerTick(b, inp({ mz: 0 }), e, w); d += Math.hypot(r.dx, r.dz); }
  return d;
}

// ---- 1. Walking / sprinting / sneaking ----------------------------------------------------------------------------------------
const walk = steady(env(), inp());
check('walking top speed 4.317 m/s (wiki: Player)', near(walk.top, 4.317, 0.005), `${f3(walk.top)} m/s, 90 % after ${walk.t90} ticks`);
const sprint = steady(env({ speed: PP.BASE_SPEED * PP.SPRINT_MULT }), inp({ sprint: true }));
check('sprinting top speed 5.612 m/s', near(sprint.top, 5.612, 0.005), `${f3(sprint.top)} m/s, 90 % after ${sprint.t90} ticks`);
const sneak = steady(env({ inputScale: PP.SNEAK_INPUT }), inp({ sneak: true }));
check('sneaking top speed 1.295 m/s', near(sneak.top, 1.295, 0.003), `${f3(sneak.top)} m/s, 90 % after ${sneak.t90} ticks`);
// analytic: v_n = v∞ (1 − 0.546^n) → 90 % at n = ceil(ln 0.1 / ln 0.546) = 4
check('ground acceleration reaches 90 % of top speed in 4 ticks (0.546 friction)', walk.t90 === 4 && sprint.t90 === 4, `walk ${walk.t90}, sprint ${sprint.t90}`);
const stopGround = stopDistance(env()), stopIce = stopDistance(env({ slip: 0.98 }));
const uG = 0.098 * 0.546 / (1 - 0.546), uI = (0.1 * 0.98 * PP.GROUND_ACCEL_K / 0.98 ** 3) * (0.98 * 0.91) / (1 - 0.98 * 0.91);
check('stopping distance on normal ground (0.546 friction, 0.003 cut-off)', near(stopGround, coast(uG, 0.546), 0.002), `${f3(stopGround)} blocks (formula ${f3(coast(uG, 0.546))})`);
check('stopping distance on ice ≈ 1.69 blocks (slipperiness 0.98 × 0.91, 未確認値)', near(stopIce, coast(uI, 0.98 * 0.91), 0.005) && stopIce > 6 * stopGround, `${f3(stopIce)} blocks (formula ${f3(coast(uI, 0.98 * 0.91))})`);
const ice = steady(env({ slip: 0.98 }), inp(), 400);
check('walking top speed on ice (same formula)', near(ice.top, 20 * (0.1 * 0.98 * PP.GROUND_ACCEL_K / 0.98 ** 3) / (1 - 0.98 * 0.91), 0.01), `${f3(ice.top)} m/s, 90 % after ${ice.t90} ticks`);
const soul = steady(env({ blockSpeed: 0.4 }), inp());
check('soul sand speed factor 0.4 slows walking (≈ 2.51 m/s with this model, 未確認)', soul.top < 0.6 * walk.top && soul.top > 0.5 * walk.top, `${f3(soul.top)} m/s`);

// ---- 2. Jumping, sprint-jumping, terminal velocity -------------------------------------------------------------------------------
{
  const w = new World(), b = grounded();
  let top = 0, airTicks = 0;
  for (let t = 0; t < 40; t++) { PP.playerTick(b, inp({ mz: 0, jump: t === 0 }), env(), w); top = Math.max(top, b.y); if (!b.onGround) airTicks++; }
  check('jump height 1.2522 blocks (wiki: Player)', near(top, 1.2522, 0.0005), `${top.toFixed(4)} blocks, ${airTicks} ticks in the air`);
}
{
  const w = new World(), e = env({ speed: PP.BASE_SPEED * PP.SPRINT_MULT }), b = steady(e, inp({ sprint: true }), 100, grounded(), w).body;
  const z0 = b.z;
  let t = 0;
  PP.playerTick(b, inp({ sprint: true, jump: true }), e, w);
  while (!b.onGround && t++ < 60) PP.playerTick(b, inp({ sprint: true }), e, w);
  const d = Math.abs(b.z - z0);
  check('sprint-jump covers ≈ 4.225 − 0.6 blocks (wiki gap 4.225 incl. the 0.6 wide hitbox)', near(d + 0.6, 4.225, 0.06), `${f3(d)} blocks in the air (+0.6 = ${f3(d + 0.6)})`);
}
{
  const w = new World(-1e9), b = PP.newBody(0, 0, 0);
  for (let t = 0; t < 2000; t++) PP.playerTick(b, inp({ mz: 0 }), env(), w);
  check('terminal velocity 78.4 m/s (wiki: Player)', near(-b.vy * PP.TPS, 78.4, 0.01), `${f3(-b.vy * PP.TPS)} m/s`);
}
{
  const w = new World(), b = grounded();
  let top = 0;
  for (let t = 0; t < 40; t++) { PP.playerTick(b, inp({ mz: 0, jump: t === 0 }), env({ jumpPower: PP.JUMP_POWER + 0.2 }), w); top = Math.max(top, b.y); }
  check('Jump Boost II (+0.1 / level) jumps higher', top > 2.0, `${f3(top)} blocks`);
}

// ---- 3. Falling: measured fall distance and damage --------------------------------------------------------------------------------
function dropFrom(h: number) {
  const w = new World(), b = PP.newBody(0.5, h, 0.5);
  b.vy = -(PP.GRAVITY * PP.DRAG_Y);              // walking off an edge: gravity was already applied on the last ground tick
  for (let t = 0; t < 400; t++) { const r = PP.playerTick(b, inp({ mz: 0 }), env(), w); if (r.landed) return r.fallDistance; }
  return NaN;
}
check('fallDamageAmount: ceil(d − 3): 3 → 0, 3.5 → 1, 4 → 1, 13 → 10', PP.fallDamageAmount(3) === 0 && PP.fallDamageAmount(3.5) === 1 && PP.fallDamageAmount(4) === 1 && PP.fallDamageAmount(13) === 10);
check('Jump Boost II raises the safe distance by 2', PP.fallDamageAmount(5, 2) === 0 && PP.fallDamageAmount(6, 2) === 1);
check('hay bale / honey: ceil((d − 3) × 0.2) → 20 blocks = 4', PP.fallDamageAmount(20, 0, PP.fallDamageMultiplierOf('hay_block')) === 4 && PP.fallDamageMultiplierOf('honey_block') === 0.2);
check('bed halves the distance (10 → 5 → 2 damage), slime block 0', PP.fallDamageAmount(10 * PP.fallDistanceScaleOf('bed')) === 2 && PP.fallDamageMultiplierOf('slime_block') === 0);
{
  const rows = [3, 4, 5, 10, 22, 23, 24].map(h => { const d = dropFrom(h); return { h, d, dmg: PP.fallDamageAmount(d) }; });
  console.log('      drop → fall distance (excl. landing tick) → damage: ' + rows.map(r => `${r.h}→${r.d.toFixed(2)}→${r.dmg}`).join(', '));
  const by = (h: number) => rows.find(r => r.h === h)!;
  check('a 3-block drop does not hurt, 4 blocks = 1, 5 blocks = 2 (wiki: Damage)', by(3).dmg === 0 && by(4).dmg === 1 && by(5).dmg === 2);
  check('24 blocks is lethal for 20 HP (wiki: guaranteed lethal = health + 3.5)', by(24).dmg >= 20, `23 → ${by(23).dmg}, 24 → ${by(24).dmg}`);
}

// ---- 4. Ladders, flight, water --------------------------------------------------------------------------------------------------
{
  const w = new World(); for (let y = 0; y < 40; y++) w.set(0, y, -1);
  const b = PP.newBody(0.5, 0, 0.5); b.onGround = true;
  let vy = 0;
  for (let t = 0; t < 60; t++) { const r = PP.playerTick(b, inp(), env({ climbable: true }), w); vy = r.dy * PP.TPS; }
  check('ladder: climbing by walking into the wall 2.35 m/s (wiki: Ladder)', near(vy, 2.352, 0.002), `${f3(vy)} m/s`);
  const d = PP.newBody(0.5, 30, 0.5);
  for (let t = 0; t < 40; t++) { const r = PP.playerTick(d, inp({ mz: 0 }), env({ climbable: true }), w); vy = r.dy * PP.TPS; }
  check('ladder: sliding down is capped at 3 m/s', near(vy, -3, 0.001), `${f3(vy)} m/s`);
  const s = PP.newBody(0.5, 20, 0.5);
  for (let t = 0; t < 40; t++) PP.playerTick(s, inp({ mz: 0, sneak: true }), env({ climbable: true }), w);
  check('ladder: sneaking holds position', near(s.y, 20, 1e-9), `y = ${s.y}`);
}
{
  const fly = steady(env({ mode: 'fly' }), inp(), 200, PP.newBody(0.5, 50, 0.5), new World(-1e9));
  const fast = steady(env({ mode: 'fly', flySpeed: PP.FLY_SPEED * 2 }), inp(), 200, PP.newBody(0.5, 50, 0.5), new World(-1e9));
  check('creative flight 10.889 m/s, sprint-flying 21.778 m/s (wiki: Player)', near(fly.top, 10.889, 0.005) && near(fast.top, 21.778, 0.005), `${f3(fly.top)} / ${f3(fast.top)} m/s`);
  const b = PP.newBody(0.5, 50, 0.5);
  let vy = 0;
  for (let t = 0; t < 60; t++) vy = PP.playerTick(b, inp({ mz: 0, jump: true }), env({ mode: 'fly' }), new World(-1e9)).dy * PP.TPS;
  check('creative flight vertical speed 7.5 m/s (0.15 thrust, ×0.6 damping, 未確認)', near(vy, 7.5, 0.01), `${f3(vy)} m/s`);
}
{
  const swim = steady(env({ water: true }), inp(), 200);
  check('walking through water 1.96 m/s (wiki: 1.97 partially submerged)', near(swim.top, 1.96, 0.03), `${f3(swim.top)} m/s`);
  const sprintSwim = steady(env({ water: true, swimming: true, waterAbove: true }), inp({ sprint: true }), 300, PP.newBody(0.5, 5, 0.5), new World(-1e9));
  console.log(`      sprint-swimming (drag 0.9): ${f3(sprintSwim.top)} m/s — wiki states 5.612 m/s → 未確認 / mismatch reported`);
  const b = PP.newBody(0.5, 10, 0.5);
  let vy = 0;
  for (let t = 0; t < 100; t++) vy = PP.playerTick(b, inp({ mz: 0 }), env({ water: true }), new World(-1e9)).dy * PP.TPS;
  check('sinking in water ≈ 0.5 m/s (×0.8 drag, −0.005 per tick)', near(vy, -0.5, 0.01), `${f3(vy)} m/s`);
  const up = PP.newBody(0.5, 10, 0.5);
  for (let t = 0; t < 100; t++) vy = PP.playerTick(up, inp({ mz: 0, jump: true }), env({ water: true }), new World(-1e9)).dy * PP.TPS;
  console.log(`      swimming up while holding jump (+0.04 per tick): ${f3(vy)} m/s (未確認)`);
}

// ---- 5. Frame-rate independence -----------------------------------------------------------------------------------------------------
{
  const seqs: Record<string, number[]> = { '1/30': [], '1/60': [], '1/144': [], irregular: [] };
  const total = 3.0;
  const rnd = random(99);
  for (const [name, list] of Object.entries(seqs)) {
    let t = 0;
    while (t < total - 1e-12) {
      let dt = name === '1/30' ? 1 / 30 : name === '1/60' ? 1 / 60 : name === '1/144' ? 1 / 144 : 1 / 200 + rnd() * (1 / 20 - 1 / 200);
      if (t + dt > total) dt = total - t;
      list.push(dt); t += dt;
    }
  }
  const finals: Record<string, { x: number; y: number; z: number; ticks: number; rx: number; rz: number }> = {};
  for (const [name, list] of Object.entries(seqs)) {
    const w = new World(), b = grounded(), st = new PP.FixedStepper(), e = env({ speed: PP.BASE_SPEED * PP.SPRINT_MULT });
    let ticks = 0, prev = { x: b.x, z: b.z };
    for (const dt of list) {
      const n = st.advance(dt);
      for (let k = 0; k < n; k++) { prev = { x: b.x, z: b.z }; PP.playerTick(b, inp({ sprint: true, jump: true, mx: 0.6, mz: -0.8 }), e, w); ticks++; }
    }
    const a = st.alpha;
    finals[name] = { x: b.x, y: b.y, z: b.z, ticks, rx: prev.x + (b.x - prev.x) * a, rz: prev.z + (b.z - prev.z) * a };
  }
  const ref = finals['1/60'];
  const worst = Math.max(...Object.values(finals).map(f => Math.hypot(f.x - ref.x, f.y - ref.y, f.z - ref.z)));
  const worstRender = Math.max(...Object.values(finals).map(f => Math.hypot(f.rx - ref.rx, f.rz - ref.rz)));
  console.log('      ' + Object.entries(finals).map(([k, f]) => `${k}: ${f.ticks} ticks (${f3(f.x)}, ${f3(f.y)}, ${f3(f.z)})`).join(' · '));
  check('same input at dt = 1/30, 1/60, 1/144 and irregular dt → same positions after 3 s', worst < 1e-9 && Object.values(finals).every(f => f.ticks === 60), `max difference ${worst.toExponential(2)} blocks`);
  check('interpolated (rendered) positions agree within one tick of motion', worstRender < 0.3, `max ${f3(worstRender)} blocks`);
}

// ---- 6. Portals, void, fire ---------------------------------------------------------------------------------------------------------
check('nether portal: 80 ticks (4 s) in survival, 1 tick in creative (wiki: Nether portal)', PP.portalWait(false) === 80 && PP.portalWait(true) === 1 && PP.PORTAL_DECAY === 4);
{
  const s = PP.newHazardState();
  let dealt = 0;
  for (let t = 0; t < 40; t++) { s.tick++; dealt += PP.envHurtAmount(s, PP.VOID_DAMAGE); }
  check('void: 4 damage every half second (16 in 2 s, below the floor − 64)', dealt === 16 && PP.VOID_DEPTH === 64, `${dealt} damage in 40 ticks`);
}
{
  const s = PP.newHazardState();
  let inFire = 0, after = 0;
  for (let t = 0; t < 40; t++) { s.tick++; const d = PP.fireTick(s, { inFire: true, fireDamage: 1, inLava: false, extinguish: false }); inFire += d > 0 ? PP.envHurtAmount(s, d) : 0; }
  const burning = s.fireTicks;
  for (let t = 0; t < 200; t++) { s.tick++; const d = PP.fireTick(s, { inFire: false, fireDamage: 0, inLava: false, extinguish: false }); after += d > 0 ? PP.envHurtAmount(s, d) : 0; }
  check('fire block: 1 damage per hit (every 10 ticks), sets the player on fire for 8 s after 20 ticks inside', inFire === 4 && burning === 160, `${inFire} damage in 2 s, fire ticks ${burning}`);
  check('burning: 1 damage per second until it runs out (8 s → 8 damage)', after === 8 && s.fireTicks <= 0, `${after} damage`);
  const l = PP.newHazardState();
  let lava = 0;
  for (let t = 0; t < 20; t++) { l.tick++; const d = PP.fireTick(l, { inFire: false, fireDamage: 0, inLava: true, extinguish: false }); lava += d > 0 ? PP.envHurtAmount(l, d) : 0; }
  check('lava: 4 damage every half second and burning for 15 s', lava === 8 && l.fireTicks === 300, `${lava} damage in 1 s, fire ticks ${l.fireTicks}`);
  for (let t = 0; t < 3; t++) { l.tick++; PP.fireTick(l, { inFire: false, fireDamage: 0, inLava: false, extinguish: true }); }
  check('water / rain put the fire out', l.fireTicks <= 0);
}

// ---- 7. Breaking times (minecraft.wiki "Breaking") -------------------------------------------------------------------------------
{
  const B = (n: string) => BLOCKS[ID[n]], T = (n: string) => resolve(n)!;
  const cases: [string, number, number][] = [
    ['stone + wooden pickaxe (1.15 s)', breakTicks(B('stone'), T('wooden_pickaxe')), 23],
    ['stone + diamond pickaxe (0.3 s)', breakTicks(B('stone'), T('diamond_pickaxe')), 6],
    ['dirt by hand (0.75 s)', breakTicks(B('dirt'), undefined), 15],
    ['obsidian + diamond pickaxe (9.4 s)', breakTicks(B('obsidian'), T('diamond_pickaxe')), 188],
    ['obsidian by hand (250 s)', breakTicks(B('obsidian'), undefined), 5000],
    ['stone + diamond pickaxe in the air ×5', breakTicks(B('stone'), T('diamond_pickaxe'), { onGround: false }), 29],
    ['wool + shears (speed 5)', breakTicks(B('white_wool'), T('shears')), 5],
  ];
  for (const [label, got, want] of cases) check(`breaking: ${label} → ${want} ticks`, got === want, `${got} ticks`);
  check('Efficiency V + Haste II diamond pickaxe breaks stone instantly ((8 + 26) × 1.4 = 47.6 > 45)', breakTicks(B('stone'), T('diamond_pickaxe'), { efficiency: 5, speedMultiplier: 1.4 }) === 0);
  check('Efficiency only helps the right tool (pickaxe on dirt stays at 15 ticks)', breakTicks(B('dirt'), T('diamond_pickaxe'), { efficiency: 5 }) === 15);
  check('under water ×5 (Aqua Affinity removes it), in the air another ×5', near(miningTime(B('dirt'), undefined, true, true), 3.75, 1e-9) && near(miningTime(B('dirt'), undefined, true, true, { aquaAffinity: true }), 0.75, 1e-9) && near(miningTime(B('dirt'), undefined, false, true), 18.75, 1e-9));
  check('Mining Fatigue I–IV: 0.3, 0.09, 0.0027, 0.00081 (hard-coded, wiki)', FATIGUE_MULTIPLIER.join() === '1,0.3,0.09,0.0027,0.00081');
}


// ---- 8. Water-to-shore climb, flight stability & cross-plant UVs ------------------------------------------------------------
{
  const shoreWorld: PP.MotionWorld = {
    collides(x, y, z, h) {
      if (y < 61) return true;
      if (z - 0.3 < 0 && y < 63) return true;
      return false;
    },
  };
  const b = PP.newBody(0.5, 62.2, 0.35);
  let reachedShore = false;
  for (let t = 0; t < 40; t++) {
    const inWater = b.y + 0.08 < 63 && b.z >= 0;
    const waterAbove = b.y + 0.9 < 63 && b.z >= 0;
    PP.playerTick(b, inp({ jump: inWater }), env({ water: inWater, waterAbove }), shoreWorld);
    if (b.y >= 63 - 1e-4 && b.z < 0 && b.onGround) reachedShore = true;
  }
  check("water surface to adjacent shore block climb reaches y = 63 on land", reachedShore && b.y >= 63 - 1e-4 && b.z < 0, `y=${f3(b.y)}, z=${f3(b.z)}`);

  const flyBody = PP.newBody(0.5, 62.85, 0.35);
  PP.playerTick(flyBody, inp({ jump: false }), env({ mode: "fly" }), shoreWorld);
  check("flying horizontally against a block edge never sets onGround = true", !flyBody.onGround, `onGround=${flyBody.onGround}`);
}

const passed = results.filter(r => r.ok).length;
console.log(`\n${passed}/${results.length} player physics checks passed`);
if (passed !== results.length) process.exit(1);
