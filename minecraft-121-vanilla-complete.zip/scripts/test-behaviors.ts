import assert from 'node:assert/strict';
import * as THREE from 'three';
import '../src/game/content';
import { ID, resolve } from '../src/game/data';
import { MobManager } from '../src/entities/mobs';
import { SPECIES } from '../src/entities/mobs';
import { armorInfo, weaponInfo, armorFactor } from '../src/entities/behaviors';
import { Terrain, MIN_Y } from '../src/world/terrain';
import { locateExtra } from '../src/world/structures';
import { ProceduralAudio } from '../src/audio/sound';
import { MUSIC_DISCS } from '../src/game/extras';

/* Behaviour checks: ladder/vine/wall climbing, villager sleep + panic + golem summon, equipment pickup, structure mobs, dragon breath, sound, items. */
let passed = 0, failed = 0;
const tests: [string, () => void | Promise<void>][] = [];
const test = (name: string, fn: () => void | Promise<void>) => tests.push([name, fn]);

type Put = (x: number, y: number, z: number, id: number, state?: number) => void;
function world(ground = 64) {
  const cells = new Map<string, number>(), k = (x: number, y: number, z: number) => `${x},${y},${z}`;
  const put: Put = (x, y, z, id, state = 0) => cells.set(k(x, y, z), id | (state << 12));
  const getCell = (x: number, y: number, z: number) => { x = Math.floor(x); y = Math.floor(y); z = Math.floor(z); return cells.get(k(x, y, z)) ?? (y <= ground ? ID.stone : 0); };
  return { cells, put, getCell, getBlock: (x: number, y: number, z: number) => getCell(x, y, z) & 4095 };
}
function makeHost(w: { getBlock: any; getCell: any }, opts: { dimension?: string; terrain?: any; getBlock?: any } = {}) {
  const sounds: string[] = [], dmg: number[] = [], drops: { name: string; pos: THREE.Vector3; age: number }[] = [], toasts: string[] = [];
  const host: any = {
    terrain: opts.terrain ?? { height: () => 64, biome: () => 'plains', seed: 5, dimension: 'overworld' },
    position: new THREE.Vector3(0.5, 65, 8.5), camera: new THREE.PerspectiveCamera(), time: 0, dimension: opts.dimension ?? 'overworld', dragonDefeated: false,
    getBlock: opts.getBlock ?? w.getBlock, getCell: w.getCell,
    damage: (n: number) => dmg.push(n), addItem: () => true, toast: (j: string) => toasts.push(j), sound: (s: string) => sounds.push(s),
    explode: () => {}, teleport: () => {}, openTrade: () => {}, onDragonDefeated: () => {}, onEnterGateway: () => {}, levitate: () => {},
    particles: {
      burst: () => {}, spark: () => {},
      drop: (p: THREE.Vector3, name: string) => drops.push({ name, pos: p.clone(), age: 1 }),
      takeNear: (p: THREE.Vector3, r: number, accept: (n: string) => boolean) => {
        let bi = -1, bd = r * r; drops.forEach((d, i) => { const dd = d.pos.distanceToSquared(p); if (dd < bd && accept(d.name)) { bd = dd; bi = i; } });
        if (bi < 0) return null; const n = drops[bi].name; drops.splice(bi, 1); return { name: n, count: 1 };
      },
    },
  };
  const m = new MobManager(new THREE.Scene(), host);
  m.clear(); (m as any).rnd = () => 0.1;
  return { m, host, sounds, dmg, drops, toasts };
}
const run = (m: MobManager, seconds: number, daylight = 0.1, dt = 0.05) => { for (let t = 0; t < seconds; t += dt) m.update(dt, daylight, false); };

test('items: glass bottle, dragon breath, jukebox and 13 music discs exist; old block IDs unchanged', () => {
  assert.ok(resolve('glass_bottle') && resolve('dragon_breath') && ID.jukebox !== undefined);
  assert.equal(MUSIC_DISCS.length, 13);
  for (const d of MUSIC_DISCS) assert.ok(resolve(d.name), d.name);
  assert.equal(ID.water, 8); assert.equal(ID.iron_ore, 15); assert.equal(ID.note_block, 343); assert.equal(ID.bed, 384); assert.equal(ID.raw_copper_block, 590);
  assert.ok(ID.jukebox > 590, 'jukebox appended after all existing blocks (saves stay compatible)');
});

test('mobs climb ladders towards a target above them and step off at the top', () => {
  const w = world();
  for (let y = 65; y <= 72; y++) { w.put(5, y, 0, ID.stone); w.put(4, y, 0, ID.ladder, 1); }
  for (let x = 5; x <= 8; x++) for (let z = -1; z <= 1; z++) w.put(x, 72, z, ID.stone);
  const { m, host } = makeHost(w);
  host.position.set(7.5, 73.1, 0.5);
  const z = m.spawn('zombie', 3.5, 0.5, false, 65)!;
  run(m, 25);
  assert.ok(z.group.position.y > 72.5, 'zombie reached the platform, y=' + z.group.position.y.toFixed(2));
  assert.ok(z.group.position.x >= 4.9, 'zombie stepped off the ladder onto the platform, x=' + z.group.position.x.toFixed(2));
});

test('mobs climb vines', () => {
  const w = world();
  for (let y = 65; y <= 70; y++) { w.put(5, y, 0, ID.stone); w.put(4, y, 0, ID.vine, 0); }
  for (let x = 5; x <= 8; x++) for (let z = -1; z <= 1; z++) w.put(x, 70, z, ID.stone);
  const { m, host } = makeHost(w);
  host.position.set(7.5, 71.1, 0.5);
  const z = m.spawn('zombie', 3.5, 0.5, false, 65)!;
  run(m, 25);
  assert.ok(z.group.position.y > 70.5, 'zombie climbed the vine, y=' + z.group.position.y.toFixed(2));
});

test('spiders scale solid walls while chasing', () => {
  const w = world();
  for (let y = 65; y <= 75; y++) for (let z = -16; z <= 16; z++) w.put(5, y, z, ID.stone); // long wall: no way around it
  for (let x = 6; x <= 10; x++) for (let z = -3; z <= 3; z++) w.put(x, 75, z, ID.stone); // plateau behind the wall top
  const { m, host } = makeHost(w);
  host.position.set(7.5, 77, 0.5);
  const s = m.spawn('spider', 3.0, 0.5, false, 65)!;
  run(m, 20);
  assert.ok(s.group.position.y > 74, 'spider climbed the wall, y=' + s.group.position.y.toFixed(2));
});

test('villagers walk to a free bed at night, lie down, and wake at sunrise', () => {
  const w = world();
  w.put(3, 65, 2, ID.bed, 0); w.put(4, 65, 2, ID.bed, 4);
  const { m, host } = makeHost(w);
  host.position.set(0.5, 65, 30);
  const v = m.spawn('villager', 0.5, 0.5, false, 65)!;
  run(m, 20, 0.05);
  const x = v as any;
  assert.equal(x.sleeping, true, 'villager is asleep');
  assert.ok(Math.abs(v.group.rotation.x - Math.PI / 2) < 0.01, 'lying down');
  assert.ok(Math.hypot(v.group.position.x - 3.5, v.group.position.z - 2.5) < 1.2, 'on the bed');
  const second = m.spawn('villager', 0.5, 0.5, false, 65)!;
  run(m, 5, 0.05);
  assert.notEqual((second as any).bed && (second as any).bed.x === 3 && (second as any).sleeping, true, 'a second villager does not take the occupied bed');
  run(m, 2, 0.8);
  assert.equal(x.sleeping, false, 'woke at daylight');
  assert.equal(v.group.rotation.x, 0);
});

test('panicking villagers flee zombies and summon an iron golem when 3+ villagers are near', () => {
  const w = world();
  const { m, host, toasts } = makeHost(w);
  host.position.set(0.5, 65, 40);
  const vs = [0, 1, 2].map(i => m.spawn('villager', 0.5 + i * 1.5, 0.5, false, 65)!);
  const z = m.spawn('zombie', 4.5, 4.5, false, 65)!;
  void z;
  let fled = false;
  for (let t = 0; t < 12; t += 0.05) { m.update(0.05, 0.9, false); if (vs.some(v => v.state === 'flee')) fled = true; }
  assert.ok(fled, 'villagers entered the flee state');
  assert.ok(m.mobs.some(x => x.species === 'iron_golem'), 'iron golem appeared');
  assert.ok(toasts.length > 0, 'player was notified');
});

test('golems are never summoned for fewer than 3 villagers', () => {
  const w = world();
  const { m, host } = makeHost(w);
  host.position.set(0.5, 65, 40);
  for (let i = 0; i < 2; i++) m.spawn('villager', 0.5 + i, 0.5, false, 65);
  m.spawn('zombie', 4.5, 4.5, false, 65);
  run(m, 15, 0.9);
  assert.ok(!m.mobs.some(x => x.species === 'iron_golem'));
});

test('zombies pick up armour and weapons from the ground; armour reduces damage, weapons add damage', () => {
  assert.equal(armorInfo('iron_helmet')?.pts, 2); assert.equal(armorInfo('diamond_chestplate')?.pts, 8); assert.ok((weaponInfo('iron_sword')?.bonus ?? 0) > (weaponInfo('wooden_sword')?.bonus ?? 99));
  assert.ok(armorFactor(20) < 0.25);
  const w = world();
  const { m, host, drops, dmg } = makeHost(w);
  host.position.set(0.5, 65, 30);
  const z = m.spawn('zombie', 0.5, 0.5, false, 65)!;
  for (const n of ['iron_helmet', 'diamond_chestplate', 'iron_sword', 'bucket']) drops.push({ name: n, pos: new THREE.Vector3(1.5, 65.2, 0.5), age: 1 });
  run(m, 6, 0.1);
  const g = (z as any).gear;
  assert.ok(g, 'zombie has gear'); assert.equal(g.armor[0], 'iron_helmet'); assert.equal(g.armor[1], 'diamond_chestplate'); assert.ok(g.weaponBonus > 0);
  assert.equal(drops.length, 1, 'only the useless bucket stays on the ground');
  const plain = m.spawn('zombie', 6, 6, false, 65)!;
  const hp0 = z.hp, hp1 = plain.hp;
  (m as any).damageMob(z, 10); (m as any).damageMob(plain, 10);
  assert.ok(hp0 - z.hp < hp1 - plain.hp, `armoured zombie took ${hp0 - z.hp}, plain took ${hp1 - plain.hp}`);
  // Better gear replaces worse gear and the old piece drops
  drops.push({ name: 'netherite_helmet', pos: z.group.position.clone(), age: 1 });
  run(m, 2, 0.1);
  assert.equal(g.armor[0], 'netherite_helmet'); assert.ok(drops.some(d => d.name === 'iron_helmet'), 'old helmet dropped');
  // melee bonus: standing next to the player
  host.position.copy(z.group.position).add(new THREE.Vector3(0, 0, 1)); dmg.length = 0;
  run(m, 2, 0.1);
  assert.ok(dmg.some(d => d > 3), 'armed zombie hits harder than the vanilla 3: ' + dmg.join(','));
});

test('ocean monuments get exactly 3 elder guardians; woodland mansions get evokers and vindicators', () => {
  const t = new Terrain('849281');
  const chunks = new Map<string, Uint16Array>();
  const getBlock = (x: number, y: number, z: number) => {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    const cx = x >> 4, cz = z >> 4, key = cx + ',' + cz;
    let d = chunks.get(key); if (!d) { d = t.generate(cx, cz).data; chunks.set(key, d); }
    return y < MIN_Y ? 1 : d[(y - MIN_Y) * 256 + (z & 15) * 16 + (x & 15)] & 4095;
  };
  const w = { getBlock, getCell: getBlock };
  const mon = locateExtra(t, 'monument', 0, 0)!;
  assert.ok(mon, 'monument located');
  const A = makeHost(w, { terrain: t });
  A.host.position.set(mon[0] + 0.5, mon[1] + 8, mon[2] + 0.5);
  run(A.m, 5, 0.8);
  const elders = A.m.mobs.filter(x => x.species === 'elder_guardian');
  assert.equal(elders.length, 3, 'elder guardians: ' + elders.length);
  assert.ok(A.m.mobs.filter(x => x.species === 'guardian').length >= 3, 'guardians present');
  run(A.m, 10, 0.8);
  assert.equal(A.m.mobs.filter(x => x.species === 'elder_guardian').length, 3, 'still exactly 3 (no re-population)');
  const man = locateExtra(t, 'mansion', 0, 0)!;
  assert.ok(man, 'mansion located');
  const B = makeHost(w, { terrain: t });
  B.host.position.set(man[0] + 0.5, man[1] + 3, man[2] + 0.5);
  run(B.m, 5, 0.8);
  assert.ok(B.m.mobs.filter(x => x.species === 'evoker').length >= 1, 'evoker present');
  assert.ok(B.m.mobs.filter(x => x.species === 'vindicator').length >= 2, 'vindicators present');
});

test('Ender Dragon spits breath clouds that hurt, shrink, and can be collected with glass bottles', () => {
  const w = world(30);
  const { m, host, dmg } = makeHost(w, { dimension: 'end', terrain: { height: () => 30, biome: () => 'the_end', seed: 1 } });
  host.position.set(3, 31, 3);
  const dragon = m.spawn('dragon', 0, 0, false, 44)!;
  dragon.state = 'perch'; dragon.phaseTimer = 99;
  (m.beh as any).breathT = 0;
  for (let t = 0; t < 3; t += 0.05) { dragon.state = 'perch'; dragon.phaseTimer = 99; m.update(0.05, 0.5, false); }
  assert.ok(m.beh.clouds.length >= 1, 'breath cloud created');
  const c = m.beh.clouds[0], r0 = c.radius;
  assert.ok(r0 >= 2.5 && c.life > 25, 'cloud radius ' + r0 + ' life ' + c.life);
  host.position.set(c.pos.x, c.pos.y + 0.1, c.pos.z); dmg.length = 0;
  for (let t = 0; t < 2; t += 0.05) { dragon.state = 'perch'; dragon.phaseTimer = 99; m.update(0.05, 0.5, false); }
  assert.ok(dmg.length >= 2, 'standing in the cloud hurts');
  const ok = m.beh.collectBreath(new THREE.Vector3(c.pos.x, c.pos.y + 1.6, c.pos.z), new THREE.Vector3(0, -1, 0));
  assert.ok(ok && c.radius < r0 - 0.4, 'a bottle took 0.5 radius');
  assert.equal(m.beh.collectBreath(new THREE.Vector3(90, 40, 90), new THREE.Vector3(0, -1, 0)), false, 'nothing to collect far away');
  c.life = 0.01; m.update(0.1, 0.5, false);
  assert.ok(!m.beh.clouds.includes(c), 'expired cloud removed');
});

// ------------------------------------------------------------------ audio with a mocked Web Audio graph
function mockAudio() {
  const stats = { osc: 0, noise: 0, time: 0 };
  const param = () => ({ value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {}, setTargetAtTime() {} });
  const node = (extra: object = {}) => ({ connect() {}, disconnect() {}, start() {}, stop() {}, onended: null as any, frequency: param(), gain: param(), detune: param(), Q: param(), delayTime: param(), positionX: param(), positionY: param(), positionZ: param(), type: '', buffer: null, playbackRate: param(), ...extra });
  class Ctx {
    state = 'running'; sampleRate = 8000; destination = node(); listener = { positionX: param(), positionY: param(), positionZ: param(), forwardX: param(), forwardY: param(), forwardZ: param(), upX: param(), upY: param(), upZ: param() };
    get currentTime() { return stats.time; }
    createGain() { return node(); } createDelay() { return node(); } createBiquadFilter() { return node(); } createPanner() { return node(); }
    createOscillator() { stats.osc++; return node(); } createBufferSource() { stats.noise++; return node(); }
    createBuffer(_c: number, len: number) { return { getChannelData: () => new Float32Array(len) }; } resume() { return Promise.resolve(); } close() { return Promise.resolve(); }
  }
  (globalThis as any).AudioContext = Ctx;
  const a = new ProceduralAudio({ muted: false, volume: 0.5, music: true } as any);
  a.resume(); clearInterval(a.musicTimer!);
  return { a, stats };
}

test('every one of the 79 mobs has its own say / hurt / death voice, villagers snore', () => {
  const { a, stats } = mockAudio();
  const counts = new Map<string, number>();
  for (const sp of SPECIES) for (const kind of ['say', 'hurt', 'death'] as const) {
    stats.time += 1; const before = stats.osc + stats.noise; a.play(`${kind}:${sp}`, { x: 1, y: 2, z: 3 });
    const made = stats.osc + stats.noise - before; assert.ok(made > 0, `${kind}:${sp} produced sound`); counts.set(sp + kind, made);
  }
  stats.time += 1; const b0 = stats.osc; a.play('snore:villager'); assert.ok(stats.osc > b0, 'snore');
  assert.ok((counts.get('pigsay') ?? 0) > (counts.get('cowsay') ?? 99) || (counts.get('chickensay') ?? 0) >= 3, 'multi-pulse voices (pig / chicken) differ from single moos');
  for (const k of ['fizz', 'equip', 'golem_summon', 'bottle_fill', 'dragon_breath', 'jukebox_insert']) { stats.time += 1; const n = stats.osc + stats.noise; a.play(k); assert.ok(stats.osc + stats.noise > n, k); }
});

test('ambient layers: caves, cave biomes, nether, end, forest birds, ocean', () => {
  const { a, stats } = mockAudio();
  const envs = [
    { dim: 'overworld', biome: 'plains', y: 70, surface: 64, cave: null, night: false, underwater: false, raining: false },
    { dim: 'overworld', biome: 'forest', y: 20, surface: 80, cave: 'dripstone_caves', night: false, underwater: false, raining: false },
    { dim: 'overworld', biome: 'forest', y: 20, surface: 80, cave: 'lush_caves', night: false, underwater: false, raining: false },
    { dim: 'overworld', biome: 'forest', y: -40, surface: 80, cave: 'deep_dark', night: false, underwater: false, raining: false },
    { dim: 'overworld', biome: 'swamp', y: 64, surface: 64, cave: null, night: true, underwater: false, raining: false },
    { dim: 'overworld', biome: 'ocean', y: 50, surface: 40, cave: null, night: false, underwater: true, raining: false },
    { dim: 'nether', biome: 'soul_sand_valley', y: 40, surface: 0, cave: null, night: false, underwater: false, raining: false },
    { dim: 'end', biome: 'the_end', y: 40, surface: 0, cave: null, night: false, underwater: false, raining: false },
  ];
  for (const e of envs) { const before = stats.osc + stats.noise; for (let i = 0; i < 400; i++) { stats.time += 0.5; a.ambient(e); } assert.ok(stats.osc + stats.noise > before, `${e.dim}/${e.biome}/${e.cave} ambient sound`); }
});

test('jukebox discs play looping tunes, loudness depends on distance, and they stop', async () => {
  const { a, stats } = mockAudio();
  a.listener(0, 64, 0, 0);
  a.playDisc('j1', 'music_disc_pigstep', { x: 3, y: 64, z: 0 });
  assert.ok(a.isDiscPlaying('j1'));
  const o0 = stats.osc + stats.noise;
  await new Promise(r => setTimeout(r, 1700));
  const near = stats.osc + stats.noise - o0; assert.ok(near > 4, 'tune produced notes: ' + near);
  a.stopDisc('j1'); assert.ok(!a.isDiscPlaying('j1'));
  a.playDisc('j2', 'music_disc_cat', { x: 400, y: 64, z: 0 });
  const o1 = stats.osc + stats.noise; await new Promise(r => setTimeout(r, 1200));
  assert.equal(stats.osc + stats.noise - o1, 0, 'a far-away jukebox is inaudible (and costs nothing)');
  a.stopAllDiscs();
  for (const d of MUSIC_DISCS) { a.playDisc('x', d.name, { x: 0, y: 64, z: 0 }); assert.ok(a.isDiscPlaying('x'), d.name); }
  a.stopAllDiscs();
});

(async () => {
  for (const [name, fn] of tests) {
    try { await fn(); passed++; console.log('PASS  ' + name); } catch (e) { failed++; console.log('FAIL  ' + name + '\n      ' + ((e as Error).message ?? e).toString().split('\n')[0]); }
  }
  console.log(`\n${passed}/${passed + failed} behaviour checks passed`);
  process.exit(failed ? 1 : 0);
})();
