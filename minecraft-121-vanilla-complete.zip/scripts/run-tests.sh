#!/usr/bin/env bash
set -euo pipefail

TESTS=(
  scripts/test-behaviors.ts
  scripts/test-farming.ts
  scripts/test-fidelity.ts
  scripts/test-gameplay.ts
  scripts/test-graphics-ui.ts
  scripts/test-living-world.ts
  scripts/test-mobs.ts
  scripts/test-performance.ts
  scripts/test-realism.ts
  scripts/test-redstone.ts
  scripts/test-redstone2.ts
  scripts/test-redstone-100-wiki.ts
  scripts/test-survival.ts
  scripts/test-tricky-trials.ts
  scripts/test-vanilla-plus.ts
  scripts/verify-biomes.ts
  scripts/test-structures.ts
  scripts/test-particles-env.ts
  scripts/test-visual-effects.ts
)

for t in "${TESTS[@]}"; do
  echo "=== Running $t ==="
  npx tsx "$t"
done
echo "All 19 test suites passed!"
npx tsx scripts/test-jigsaw-structures.ts
npx tsx scripts/test-vanilla-physics.ts
