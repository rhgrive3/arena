import assert from 'node:assert/strict';
import { AdaptiveResolution, dataOnlyChunk, uploadBudget, workerLimit } from '../src/game/performance';
import { compactIndices } from '../src/world/meshPacking';
import { BLOCKS, ID } from '../src/game/data';
import '../src/game/content';
import { tilesFor } from '../src/textures/atlas';
import { HEIGHT, MIN_Y } from '../src/world/terrain';
import { meshChunk } from '../src/world/mesher';

let passed = 0;
function test(name: string, run: () => void) { run(); passed++; console.log('PASS ' + name); }

test('worker count reserves a main-thread core and bounds memory', () => {
  assert.equal(workerLimit(1), 1);
  assert.equal(workerLimit(2), 1);
  assert.equal(workerLimit(4, 4), 2);
  assert.equal(workerLimit(16, 8), 4);
});
test('uploads have a smaller time budget during gameplay', () => {
  assert.ok(uploadBudget(true) < 3);
  assert.ok(uploadBudget(false) > uploadBudget(true));
  assert.ok(uploadBudget(true, 120) < uploadBudget(true, 60));
});
test('data-only classification preserves the exact circular render boundary', () => {
  for (let radius = 2; radius <= 9; radius++) for (let z = -12; z <= 12; z++) for (let x = -12; x <= 12; x++) {
    assert.equal(dataOnlyChunk(x - 7, z + 4, -7, 4, radius), Math.hypot(x, z) > radius + 0.5);
  }
});
test('16-bit indices preserve values and halve index memory', () => {
  const source = Uint32Array.from([0, 2, 1, 3, 4096, 65534]);
  const packed = compactIndices(source, 65535);
  assert.ok(packed instanceof Uint16Array);
  assert.deepEqual([...packed], [...source]);
  assert.equal(packed.byteLength, source.byteLength / 2);
});
test('large meshes retain 32-bit indices without primitive-restart collisions', () => {
  const source = Uint32Array.from([0, 65535, 65536, 100000]);
  const packed = compactIndices(source, 100001);
  assert.ok(packed instanceof Uint32Array);
  assert.deepEqual([...packed], [...source]);
  assert.equal(packed.buffer, source.buffer, 'Large buffers are not copied');
});
test('real meshes use compact buffers without changing face count or normals', () => {
  const padded = new Uint16Array(18 * 18 * HEIGHT);
  padded[(64 - MIN_Y) * 324 + 9 * 18 + 9] = ID.stone;
  const mesh = meshChunk(padded, 66, BLOCKS.map((_, id) => tilesFor(id)));
  assert.equal(mesh.solid.index.length, 36);
  assert.ok(compactIndices(mesh.solid.index, mesh.solid.position.length / 3) instanceof Uint16Array);
  assert.equal(mesh.solid.position.length, 72);
  assert.ok([...mesh.solid.normal].every(n => n === -1 || n === 0 || n === 1));
});
test('stable 60 FPS remains at native preset resolution', () => {
  const c = new AdaptiveResolution();
  for (let i = 0; i < 1200; i++) c.sample(1000 / 60, 5);
  assert.equal(c.scale, 1);
});
test('one long frame and tab-resume spikes do not lower quality', () => {
  const c = new AdaptiveResolution();
  for (let i = 0; i < 300; i++) c.sample(1000 / 60, 5);
  c.sample(170, 4);
  c.sample(60000, 4);
  c.sample(NaN, 4);
  for (let i = 0; i < 150; i++) c.sample(1000 / 60, 5);
  assert.equal(c.scale, 1);
});
test('sustained GPU-like load reduces resolution gradually with an 80% floor', () => {
  const c = new AdaptiveResolution();
  let previous = 1;
  for (let i = 0; i < 1800; i++) {
    c.sample(30, 4);
    assert.ok(previous - c.scale <= 0.051);
    previous = c.scale;
  }
  assert.equal(c.scale, 0.8);
});
test('CPU-bound frames do not waste image quality', () => {
  const c = new AdaptiveResolution();
  for (let i = 0; i < 1200; i++) c.sample(32, 25);
  assert.equal(c.scale, 1);
});
test('chunk upload bursts do not trigger resolution degradation', () => {
  const c = new AdaptiveResolution();
  for (let i = 0; i < 1200; i++) c.sample(30, 5, 60, true);
  assert.equal(c.scale, 1);
});
test('quality recovers after sustained headroom', () => {
  const c = new AdaptiveResolution();
  c.reset(0.8);
  for (let i = 0; i < 5400; i++) c.sample(1000 / 60, 4);
  assert.equal(c.scale, 1);
});
test('continuous movement does not disable adaptation between chunk uploads', () => {
  const c = new AdaptiveResolution();
  for (let i = 0; i < 1800; i++) c.sample(30, 4, 60, i % 5 === 0);
  assert.equal(c.scale, 0.8);
});
console.log(`\n${passed}/${passed} optimization checks passed.`);