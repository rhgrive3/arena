// Needs playwright-core and a headless Chromium outside this project (see PROGRESS.md 記録 012). Usage: node browser-shots.mjs <dist/index.html> <outDir> <seed> <targets>
// Real in-browser screenshots: starts a creative world in headless Chromium (SwiftShader WebGL) and photographs biomes.
import { chromium } from 'playwright-core';
import fs from 'node:fs';
import path from 'node:path';
const dist = process.argv[2], outDir = process.argv[3], seed = process.argv[4] ?? '849281', targets = (process.argv[5] ?? 'spawn').split(',');
const exe = fs.readdirSync(path.join(process.env.HOME, '.cache/ms-playwright')).filter(d => d.startsWith('chromium_headless_shell')).map(d => path.join(process.env.HOME, '.cache/ms-playwright', d, 'chrome-linux/headless_shell'))[0];
const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 480, height: 270 } });
const errors = [];
page.on('pageerror', e => errors.push('pageerror: ' + String(e).slice(0, 300)));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 300)); });
await page.goto('file://' + dist + '#d=' + (process.env.DIST ?? '6'));
await page.waitForFunction(() => window.__game, null, { timeout: 60000 });
await page.evaluate(seed => {
  const g = window.__game;
  g.setSettings({ ...g.settings, distance: Number(new URLSearchParams(location.hash.slice(1)).get('d') ?? 6), quality: 'low', adaptiveResolution: false, touch: false });
  g.start({ id: 'shot-' + seed, name: 'shot', seed, mode: 'creative', difficulty: 'peaceful', hardcore: false, structures: true, bonus: false, cheats: true, created: 0, updated: 0, playTime: 0 });
}, seed);
await page.waitForFunction(() => window.__game.ready && window.__game.active, null, { timeout: 240000 });
const shots = [];
for (const target of targets) {
  const info = await page.evaluate(target => {
    const g = window.__game, t = g.terrain;
    g.time = 0.27; g.weather = 'clear'; g.weatherTimer = 99999; g.flying = true;
    let px, pz, label = target;
    if (target === 'spawn') { px = 12; pz = 14; }
    else if (/^-?\d+:-?\d+$/.test(target)) { [px, pz] = target.split(':').map(Number); }
    else { const p = t.locate(target, -11, 27); if (!p) return null; px = p[0]; pz = p[2]; }
    // stand ~62 blocks away on the lower side and look at the target
    let best = null;
    for (let a = 0; a < 8; a++) { const cx = px + Math.cos(a * Math.PI / 4) * 30, cz = pz + Math.sin(a * Math.PI / 4) * 30, h = t.height(cx, cz); if (!best || h < best.h) best = { cx, cz, h }; }
    const ground = Math.max(63, best.h), th = Math.max(63, t.height(px, pz)), cy = Math.max(ground + 16, th + 10);
    g.teleport(best.cx, cy, best.cz);
    g.input.yaw = Math.atan2(-(px - best.cx), -(pz - best.cz));
    g.input.pitch = Math.atan2(th - cy, 30) - 0.02;
    return { label, px: Math.round(px), pz: Math.round(pz), th, cam: [Math.round(best.cx), Math.round(cy), Math.round(best.cz)], biome: t.biome(px, pz) };
  }, target);
  if (!info) { console.log('not found:', target); continue; }
  await page.waitForTimeout(1500);
  await page.waitForFunction(() => { const g = window.__game; return g.queue.length === 0 && g.pending.size === 0 && g.uploadQueue.length === 0; }, null, { timeout: 240000 }).catch(() => console.log('timeout waiting for chunks at', target));
  await page.waitForTimeout(2500);
  const fps = await page.evaluate(() => window.__game.fps);
  console.log(JSON.stringify({ ...info, fps }));
  const data = await page.evaluate(() => { const g = window.__game; g.hand.visible = false; g.outline.visible = false; g.renderer.render(g.scene, g.camera); return g.canvas.toDataURL('image/jpeg', 0.82).split(',')[1]; });
  shots.push({ label: `${info.label} → ${info.biome} @ ${info.px},${info.pz} (ground y=${info.th})`, data });
}
// 2×2 contact sheets
for (let i = 0; i < shots.length; i += 4) {
  const sheet = await browser.newPage({ viewport: { width: 1760, height: 1000 } });
  await sheet.setContent(`<body style="margin:0;display:grid;grid-template-columns:880px 880px;background:#111">${shots.slice(i, i + 4).map(s => `<div style="position:relative;height:500px"><img src="data:image/jpeg;base64,${s.data}" style="width:880px;height:500px"><span style="position:absolute;left:300px;top:6px;font:bold 15px sans-serif;color:#fff;background:#000c;padding:3px 8px">${s.label}</span></div>`).join('')}</body>`);
  await sheet.screenshot({ path: path.join(outDir, `${process.env.NAME ?? 'sheet'}${i / 4 + 1}.jpg`), type: 'jpeg', quality: 72, timeout: 120000 });
  await sheet.close();
}
if (errors.length) console.log('ERRORS:\n' + [...new Set(errors)].slice(0, 8).join('\n'));
await browser.close();
