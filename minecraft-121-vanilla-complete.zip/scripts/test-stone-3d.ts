import assert from 'node:assert/strict';
import '../src/game/content';
import { BLOCKS, ID, faceTile } from '../src/game/data';
import { canvas, type Context2D } from '../src/textures/canvas';
import { drawStoneTile } from '../src/textures/stoneArt';
import { auditBlockFaceTextures, renderBlockIcon3D, uiTileCanvas } from '../src/textures/atlas';

let passed = 0;
function check(name: string, cond: unknown) {
  assert.ok(cond, `Failed: ${name}`);
  passed++;
}

// 1. Complete Atlas Face Audit: zero missing tiles across all 667 blocks
{
  const audit = auditBlockFaceTextures();
  check('All 667 registered blocks resolve all 6 faces with 0 missing atlas tiles', audit.missing.length === 0 && audit.blocks >= 660);
}

// 2. Stairs, Slabs, Walls, and Fences inherit their parent stone block directional face tiles
{
  check('stone_brick_stairs inherits stone_bricks face tiles', faceTile(BLOCKS[ID.stone_brick_stairs], 2) === 'stone_bricks');
  check('sandstone_stairs inherits sandstone_top, sandstone_bottom, and sandstone_side',
    faceTile(BLOCKS[ID.sandstone_stairs], 2) === 'sandstone_top' &&
    faceTile(BLOCKS[ID.sandstone_stairs], 3) === 'sandstone_bottom' &&
    faceTile(BLOCKS[ID.sandstone_stairs], 4) === 'sandstone_side'
  );
  check('quartz_stairs inherits quartz_block_top and quartz_block_side',
    faceTile(BLOCKS[ID.quartz_stairs], 2) === 'quartz_block_top' &&
    faceTile(BLOCKS[ID.quartz_stairs], 4) === 'quartz_block_side'
  );
  check('deepslate_stairs inherits deepslate_top and deepslate',
    faceTile(BLOCKS[ID.deepslate_stairs], 2) === 'deepslate_top' &&
    faceTile(BLOCKS[ID.deepslate_stairs], 4) === 'deepslate'
  );
}

// 3. Directional stone blocks have distinct top vs side face tiles
{
  const dirBlocks = [
    ['deepslate', 'deepslate_top', 'deepslate'],
    ['blackstone', 'blackstone_top', 'blackstone'],
    ['basalt', 'basalt_top', 'basalt_side'],
    ['quartz_pillar', 'quartz_pillar_top', 'quartz_pillar'],
    ['purpur_pillar', 'purpur_pillar_top', 'purpur_pillar'],
    ['reinforced_deepslate', 'reinforced_deepslate_top', 'reinforced_deepslate_side'],
    ['lodestone', 'lodestone_top', 'lodestone_side'],
    ['chiseled_tuff', 'chiseled_tuff_top', 'chiseled_tuff'],
    ['chiseled_tuff_bricks', 'chiseled_tuff_bricks_top', 'chiseled_tuff_bricks'],
    ['stonecutter', 'stonecutter_top', 'stonecutter_side'],
    ['ancient_debris', 'ancient_debris_top', 'ancient_debris_side'],
  ] as const;

  for (const [bName, expTop, expSide] of dirBlocks) {
    const b = BLOCKS[ID[bName]];
    check(`${bName} maps top face to ${expTop} and side face to ${expSide}`,
      faceTile(b, 2) === expTop && faceTile(b, 4) === expSide
    );
  }
}

// 4. Every stone-family tile passes 3-Pass Iterative Quality Review (color richness, luminance range, 3D relief gradient)
{
  const stoneTiles = [
    'stone', 'smooth_stone', 'smooth_stone_side', 'granite', 'polished_granite',
    'diorite', 'polished_diorite', 'andesite', 'polished_andesite', 'calcite', 'dripstone_block',
    'cobblestone', 'mossy_cobblestone', 'cobbled_deepslate', 'bedrock', 'gravel',
    'stone_bricks', 'mossy_stone_bricks', 'cracked_stone_bricks', 'chiseled_stone_bricks',
    'bricks', 'mud_bricks', 'packed_mud',
    'deepslate', 'deepslate_top', 'polished_deepslate', 'deepslate_bricks', 'deepslate_tiles', 'chiseled_deepslate',
    'reinforced_deepslate_top', 'reinforced_deepslate_side', 'reinforced_deepslate_bottom',
    'tuff', 'polished_tuff', 'tuff_bricks', 'chiseled_tuff', 'chiseled_tuff_top', 'chiseled_tuff_bricks', 'chiseled_tuff_bricks_top',
    'blackstone', 'blackstone_top', 'gilded_blackstone', 'polished_blackstone', 'polished_blackstone_bricks', 'chiseled_polished_blackstone',
    'basalt_top', 'basalt_side', 'smooth_basalt',
    'sandstone_top', 'sandstone_bottom', 'sandstone_side', 'cut_sandstone', 'chiseled_sandstone', 'smooth_sandstone',
    'red_sandstone_top', 'red_sandstone_bottom', 'red_sandstone_side',
    'quartz_block_top', 'quartz_block_side', 'quartz_pillar_top', 'quartz_pillar', 'quartz_bricks', 'smooth_quartz',
    'prismarine_top', 'prismarine_side', 'prismarine_bricks', 'dark_prismarine',
    'netherrack', 'crimson_nylium', 'crimson_nylium_side', 'warped_nylium', 'warped_nylium_side',
    'nether_bricks', 'red_nether_bricks', 'cracked_nether_bricks',
    'end_stone', 'end_stone_bricks', 'purpur_block', 'purpur_pillar', 'purpur_pillar_top',
    'coal_ore', 'iron_ore', 'copper_ore', 'gold_ore', 'diamond_ore', 'emerald_ore', 'lapis_ore', 'redstone_ore',
    'deepslate_coal_ore', 'deepslate_iron_ore', 'deepslate_copper_ore', 'deepslate_gold_ore',
    'deepslate_diamond_ore', 'deepslate_emerald_ore', 'deepslate_lapis_ore', 'deepslate_redstone_ore',
    'nether_quartz_ore', 'nether_gold_ore', 'raw_iron_block', 'raw_copper_block',
    'ancient_debris_top', 'ancient_debris_side',
    'lodestone_top', 'lodestone_side',
    'furnace_top', 'furnace_side', 'furnace_front',
    'blast_furnace_top', 'blast_furnace_side', 'blast_furnace_front',
    'smoker_top', 'smoker_side', 'smoker_front',
    'dispenser_front', 'dropper_front', 'observer_front', 'observer_top', 'observer_back',
    'stonecutter_top', 'stonecutter_side', 'stonecutter_bottom', 'grindstone',
    'amethyst_block_top', 'amethyst_block_side', 'budding_amethyst',
    'coal_block', 'lapis_block', 'netherite_block',
    'cut_copper', 'exposed_cut_copper', 'weathered_cut_copper', 'oxidized_cut_copper',
    'chiseled_copper', 'exposed_chiseled_copper', 'weathered_chiseled_copper', 'oxidized_chiseled_copper',
    'trial_spawner', 'vault', 'ominous_vault', 'magma_block',
    'end_portal_frame_top', 'end_portal_frame_side',
  ];

  for (const tName of stoneTiles) {
    const c1 = canvas(16), c2 = canvas(16), c3 = canvas(16);
    const ok1 = drawStoneTile(tName, c1.getContext('2d') as Context2D, 1);
    const ok2 = drawStoneTile(tName, c2.getContext('2d') as Context2D, 2);
    const ok3 = drawStoneTile(tName, c3.getContext('2d') as Context2D, 3);
    check(`${tName} is handled by drawStoneTile across all 3 passes`, ok1 && ok2 && ok3);

    const d1 = (c1.getContext('2d') as Context2D).getImageData(0, 0, 16, 16).data;
    const d3 = (c3.getContext('2d') as Context2D).getImageData(0, 0, 16, 16).data;
    const cols1 = new Set<number>(), cols3 = new Set<number>();
    let minL = 255, maxL = 0;
    for (let i = 0; i < 256; i++) {
      cols1.add((d1[i * 4] << 16) | (d1[i * 4 + 1] << 8) | d1[i * 4 + 2]);
      const r = d3[i * 4], g = d3[i * 4 + 1], b = d3[i * 4 + 2];
      cols3.add((r << 16) | (g << 8) | b);
      const l = 0.299 * r + 0.587 * g + 0.114 * b;
      if (l < minL) minL = l;
      if (l > maxL) maxL = l;
    }
    check(`${tName} Pass 3 has rich 3D shading (>=16 unique shades & >=28 luminance contrast)`,
      cols3.size >= 16 && cols3.size >= cols1.size && (maxL - minL) >= 28
    );
  }
}

// 5. 3D Isometric Block Icons render cleanly for walls, stairs, slabs, stonecutter, and grindstone
{
  for (const bName of ['cobblestone_wall', 'stone_brick_stairs', 'stone_brick_slab', 'stonecutter', 'grindstone']) {
    const icon = renderBlockIcon3D(BLOCKS[ID[bName]]);
    check(`${bName} renders a 48x48 3D isometric icon`, !!icon && icon.width === 48 && icon.height === 48);
    const d = (icon!.getContext('2d') as Context2D).getImageData(0, 0, 48, 48).data;
    let nonTransparent = 0;
    for (let i = 3; i < d.length; i += 4) if (d[i] > 0) nonTransparent++;
    check(`${bName} 3D icon has substantial non-empty silhouette (${nonTransparent} px)`, nonTransparent >= 350);
  }
}

console.log(`All ${passed} stone 3D appearance & 3-pass review checks passed!`);
