// Record 018 verification suite: tests all 11 Wiki-verified single-player Java Edition mechanics in vanillaPlus.ts,
// redstone.ts, farming.ts, mobs.ts, survival.ts, and engine.ts.
import * as THREE from 'three';
import '../src/game/content';
import { BLOCKS, ID, resolve } from '../src/game/data';
import { blockId, blockState, makeCell } from '../src/game/blockState';
import {
  COPPER_OXIDATION_PRECHECK, tickCopperOxidation, waxCopper, scrapeCopper, deoxidizeCopperAround, isWaxedCopper,
  LIGHTNING_ROD_RADIUS, findNearestLightningRod,
  bindLodestoneCompass, lodestoneTargetOf,
  AMETHYST_STAGES, tickBuddingAmethyst, amethystDrops, generateAmethystGeode,
  trySummonMultiblock,
  PIGLIN_BARTER_TICKS, PIGLIN_ZOMBIFY_TICKS, isWearingGoldArmor, rollPiglinBarter,
  wardenSonicDamage, ominousBottleStack, ominousBottleAmplifier,
  computeRailState,
  SUSPICIOUS_STEW_FLOWERS, craftSuspiciousStew,
  bundleInsert, bundleWeight, bundleDropAll,
  tickChorusFlower,
  parseCoords, parseSelector,
} from '../src/systems/vanillaPlus';
import { Redstone } from '../src/systems/redstone';
import * as SV from '../src/game/survival';
import { isPistonImmovable, PISTON_BREAKS } from '../src/game/vanilla';

let pass = 0, fail = 0;
function ok(name: string, cond: boolean, detail: unknown = '') {
  if (cond) {
    pass++;
    console.log('PASS  ' + name);
  } else {
    fail++;
    console.error('FAIL  ' + name, detail);
  }
}

const k = (x: number, y: number, z: number) => `${x},${y},${z}`;
function makeWorld() {
  const cells = new Map<string, number>();
  const getCell = (x: number, y: number, z: number) => cells.get(k(x, y, z)) ?? 0;
  const getBlock = (x: number, y: number, z: number) => blockId(getCell(x, y, z));
  const setBlock = (x: number, y: number, z: number, id: number, st = 0) => {
    if (id === 0) cells.delete(k(x, y, z));
    else cells.set(k(x, y, z), makeCell(id, st));
    return true;
  };
  return { cells, getCell, getBlock, setBlock };
}

// 1. Copper Oxidation, Waxing, Scraping & Lightning Deoxidation (Wiki: Block of Copper)
{
  const w = makeWorld();
  w.setBlock(0, 64, 0, ID.copper_block, 0);
  ok('copper oxidation pre-check constant is 64/1125', Math.abs(COPPER_OXIDATION_PRECHECK - 64 / 1125) < 1e-12);
  ok('copper oxidizes through all 4 stages (copper -> exposed -> weathered -> oxidized)',
    tickCopperOxidation(w.getCell, w.setBlock, 0, 64, 0, () => 0.1, true) && w.getBlock(0, 64, 0) === ID.exposed_copper &&
    tickCopperOxidation(w.getCell, w.setBlock, 0, 64, 0, () => 0.1, true) && w.getBlock(0, 64, 0) === ID.weathered_copper &&
    tickCopperOxidation(w.getCell, w.setBlock, 0, 64, 0, () => 0.1, true) && w.getBlock(0, 64, 0) === ID.oxidized_copper);

  // Lower-stage neighbor within Manhattan distance 4 prevents oxidation
  w.setBlock(10, 64, 10, ID.exposed_copper, 0);
  w.setBlock(12, 64, 10, ID.copper_block, 0); // Manhattan distance 2, lower stage (0 < 1)
  ok('lower-stage copper neighbor within 4 blocks aborts oxidation (Wiki rule)',
    !tickCopperOxidation(w.getCell, w.setBlock, 10, 64, 10, () => 0.001, true) && w.getBlock(10, 64, 10) === ID.exposed_copper);

  // Honeycomb waxing & Axe scraping
  ok('honeycomb waxes copper and prevents oxidation',
    waxCopper(w.getCell, w.setBlock, 10, 64, 10) && isWaxedCopper(w.getCell(10, 64, 10)) &&
    !tickCopperOxidation(w.getCell, w.setBlock, 10, 64, 10, () => 0.001, true));
  ok('axe scrapes wax off first, then steps oxidation back one stage',
    scrapeCopper(w.getCell, w.setBlock, 10, 64, 10) === 'unwaxed' && !isWaxedCopper(w.getCell(10, 64, 10)) &&
    scrapeCopper(w.getCell, w.setBlock, 10, 64, 10) === 'scraped' && w.getBlock(10, 64, 10) === ID.copper_block);

  // Lightning strike deoxidizes hit block to stage 0 and steps back nearby unwaxed copper
  w.setBlock(20, 64, 20, ID.oxidized_copper, 0);
  w.setBlock(21, 64, 20, ID.weathered_copper, 0);
  const cleaned = deoxidizeCopperAround(w.getCell, w.setBlock, 20, 64, 20);
  ok('lightning deoxidizes hit copper to stage 0 and steps back neighbor',
    cleaned === 2 && w.getBlock(20, 64, 20) === ID.copper_block && w.getBlock(21, 64, 20) === ID.exposed_copper);
}

// 2. Lightning Rod (128-block diversion, 8-tick redstone pulse 15, strong power below)
{
  ok('lightning rod radius is 128 blocks in Java Edition', LIGHTNING_ROD_RADIUS === 128);
  const rods: [number, number, number][] = [[200, 70, 200], [50, 70, 50], [90, 70, 90]];
  ok('closest lightning rod within 128 blocks is selected',
    JSON.stringify(findNearestLightningRod(rods, 40, 40)) === JSON.stringify([50, 70, 50]) &&
    findNearestLightningRod([[300, 70, 300]], 0, 0) === null);

  const w = makeWorld();
  const rs = new Redstone({ getCell: w.getCell, setBlock: w.setBlock });
  w.setBlock(0, 64, 0, ID.stone, 0);
  w.setBlock(0, 65, 0, ID.lightning_rod, 0); rs.register(0, 65, 0);
  w.setBlock(1, 64, 0, ID.redstone_wire, 0); rs.register(1, 64, 0);
  rs.triggerLightningRod(0, 65, 0, 8);
  rs.tick();
  ok('struck lightning rod emits signal 15 and strongly powers the block below for 8 ticks',
    blockState(w.getCell(0, 65, 0)) === 15 && blockState(w.getCell(1, 64, 0)) === 15);
  for (let i = 0; i < 8; i++) rs.tick();
  rs.tick();
  ok('lightning rod turns off after 8 ticks',
    blockState(w.getCell(0, 65, 0)) === 0 && blockState(w.getCell(1, 64, 0)) === 0);
}

// 3. Budding Amethyst & 4-Stage Amethyst Cluster Growth + Drops + Geode Generation
{
  const w = makeWorld();
  w.setBlock(0, 40, 0, ID.budding_amethyst, 0);
  ok('budding amethyst is piston immovable and amethyst clusters break when pushed',
    isPistonImmovable('budding_amethyst') && PISTON_BREAKS.has('amethyst_cluster') && PISTON_BREAKS.has('small_amethyst_bud'));

  // Deterministic rng (< 0.2 triggers face 0 = +X)
  for (let s = 0; s < 4; s++) {
    tickBuddingAmethyst(w.getCell, w.setBlock, 0, 40, 0, () => 0.01);
    ok(`amethyst grows to stage ${s + 1}: ${AMETHYST_STAGES[s]}`, w.getBlock(1, 40, 0) === ID[AMETHYST_STAGES[s]]);
  }
  ok('budding amethyst drops nothing even with Silk Touch',
    amethystDrops('budding_amethyst', true, true, 3).length === 0);
  ok('immature amethyst bud drops nothing without Silk Touch and drops itself with Silk Touch',
    amethystDrops('medium_amethyst_bud', true, false, 0).length === 0 &&
    amethystDrops('medium_amethyst_bud', true, true, 0)[0]?.name === 'medium_amethyst_bud');
  ok('amethyst cluster drops 4 shards with pickaxe, 2 without, and up to 16 with Fortune III',
    amethystDrops('amethyst_cluster', true, false, 0)[0]?.count === 4 &&
    amethystDrops('amethyst_cluster', false, false, 0)[0]?.count === 2 &&
    amethystDrops('amethyst_cluster', true, false, 3, () => 0.99)[0]?.count === 16);

  const gw = makeWorld();
  const g = generateAmethystGeode(gw.setBlock, 0, 20, 0, 5, () => 0.05);
  ok('3-layer amethyst geode generates basalt outer, calcite middle, and budding amethyst inner shell',
    g.buddingCount > 0 && gw.getBlock(5, 20, 0) === ID.basalt && gw.getBlock(4, 20, 0) === ID.calcite);
}

// 4. Multiblock Summoning Rituals (Snow Golem, Iron Golem, Wither Boss)
{
  const w = makeWorld();
  w.setBlock(0, 64, 0, ID.snow_block);
  w.setBlock(0, 65, 0, ID.snow_block);
  w.setBlock(0, 66, 0, ID.carved_pumpkin);
  const sg = trySummonMultiblock(w.getBlock, w.setBlock, 0, 66, 0);
  ok('2 snow blocks + carved pumpkin summons snow_golem and clears blocks',
    sg?.species === 'snow_golem' && w.getBlock(0, 64, 0) === 0 && w.getBlock(0, 66, 0) === 0);

  w.setBlock(5, 64, 5, ID.iron_block);
  w.setBlock(5, 65, 5, ID.iron_block);
  w.setBlock(4, 65, 5, ID.iron_block);
  w.setBlock(6, 65, 5, ID.iron_block);
  w.setBlock(5, 66, 5, ID.carved_pumpkin);
  const ig = trySummonMultiblock(w.getBlock, w.setBlock, 5, 66, 5);
  ok('T-shaped 4 iron blocks + carved pumpkin summons player-created iron_golem and clears all 5 blocks',
    ig?.species === 'iron_golem' && ig.playerCreated && w.getBlock(4, 65, 5) === 0 && w.getBlock(5, 64, 5) === 0);

  w.setBlock(10, 64, 10, ID.soul_sand);
  w.setBlock(10, 65, 10, ID.soul_sand);
  w.setBlock(9, 65, 10, ID.soul_sand);
  w.setBlock(11, 65, 10, ID.soul_sand);
  w.setBlock(9, 66, 10, ID.wither_skeleton_skull);
  w.setBlock(10, 66, 10, ID.wither_skeleton_skull);
  w.setBlock(11, 66, 10, ID.wither_skeleton_skull);
  const wi = trySummonMultiblock(w.getBlock, w.setBlock, 11, 66, 10);
  ok('4 soul sand + 3 wither skeleton skulls summons wither with 220-tick warmup and clears all 7 blocks',
    wi?.species === 'wither' && wi.warmupTicks === 220 && w.getBlock(10, 64, 10) === 0 && w.getBlock(9, 66, 10) === 0);
}

// 5. Piglin Bartering, Gold Armor Neutrality & Zombification + Warden Sonic Boom
{
  ok('piglin barter timer is 120 ticks and zombification is 300 ticks',
    PIGLIN_BARTER_TICKS === 120 && PIGLIN_ZOMBIFY_TICKS === 300);
  ok('wearing any golden armor piece makes piglins neutral',
    !isWearingGoldArmor([null, { name: 'iron_chestplate', count: 1 }, null, null]) &&
    isWearingGoldArmor([{ name: 'golden_helmet', count: 1 }, null, null, null]));
  const r0 = rollPiglinBarter(() => 0.001), r1 = rollPiglinBarter(() => 0.5);
  ok('piglin bartering table rolls Soul Speed enchanted book and Nether materials',
    r0.name === 'enchanted_book' && r0.ench?.soul_speed === 2 && !!resolve(r1.name));
  ok('warden Sonic Boom deals 10 armor-piercing damage reduced only by Resistance (20% per level)',
    wardenSonicDamage(0) === 10 && wardenSonicDamage(2) === 6);
}

// 6. Respawn Anchor, Lodestone Compass, Ominous Bottle -> Raid Omen / Trial Omen, Suspicious Stew, Bundle, Chorus Flower
{
  const comp = bindLodestoneCompass({ name: 'compass', count: 1 }, 'nether', 120, 64, -80);
  const tgt = lodestoneTargetOf(comp);
  ok('lodestone binds compass to dimension and coordinates',
    tgt?.dim === 'nether' && tgt.x === 120 && tgt.y === 64 && tgt.z === -80);

  const ob = ominousBottleStack(4);
  ok('ominous bottle stores amplifier 0..4 (I..V)', ob.name === 'ominous_bottle' && ominousBottleAmplifier(ob) === 3);

  const stew = craftSuspiciousStew('oxeye_daisy')!;
  const witherStew = craftSuspiciousStew('wither_rose')!;
  ok('suspicious stew encodes exact Java flower effects (oxeye_daisy = 8s regeneration, wither_rose = 8s wither)',
    SUSPICIOUS_STEW_FLOWERS.oxeye_daisy[0] === 'regeneration' && SUSPICIOUS_STEW_FLOWERS.oxeye_daisy[1] === 8 &&
    stew.name === 'suspicious_stew' && witherStew.name === 'suspicious_stew');

  const bundle: any = { name: 'bundle', count: 1 };
  const pearls: any = { name: 'ender_pearl', count: 10 }; // weight 4 each -> 40 weight
  const cobble: any = { name: 'cobblestone', count: 30 }; // weight 1 each -> only 24 fit
  const sword: any = { name: 'diamond_sword', count: 1 }; // weight 64 -> 0 fit when not empty
  ok('bundle packs mixed items up to 64 weight units (ender pearls weight 4, cobblestone weight 1)',
    bundleInsert(bundle, pearls) === 10 && bundleWeight(bundle) === 40 &&
    bundleInsert(bundle, cobble) === 24 && bundleWeight(bundle) === 64 && cobble.count === 6 &&
    bundleInsert(bundle, sword) === 0);
  const emptied = bundleDropAll(bundle);
  ok('emptying a bundle returns all stored stacks and resets weight to 0',
    emptied.length === 2 && bundleWeight(bundle) === 0);

  const cw = makeWorld();
  cw.setBlock(0, 63, 0, ID.end_stone, 0);
  cw.setBlock(0, 64, 0, ID.chorus_flower, 0);
  ok('chorus flower grows upward into chorus_plant stem and places chorus_flower above',
    tickChorusFlower(cw.getCell, cw.setBlock, 0, 64, 0, () => 0.1) &&
    cw.getBlock(0, 64, 0) === ID.chorus_plant && cw.getBlock(0, 65, 0) === ID.chorus_flower);
}

// 7. Rail Curve Auto-Connect & T-Junction Redstone Switching + Trapped Chest
{
  const w = makeWorld();
  const rs = new Redstone({ getCell: w.getCell, setBlock: w.setBlock });
  w.setBlock(0, 63, 0, ID.stone, 0);
  w.setBlock(0, 64, 0, ID.rail, 6); rs.register(0, 64, 0);
  w.setBlock(0, 64, 1, ID.rail, 0); // South
  w.setBlock(1, 64, 0, ID.rail, 1); // East
  w.setBlock(-1, 64, 0, ID.rail, 1); // West
  rs.tick();
  const unpoweredCurve = blockState(w.getCell(0, 64, 0));
  w.setBlock(0, 64, -1, ID.redstone_block, 0); rs.register(0, 64, -1);
  rs.tick();
  const poweredCurve = blockState(w.getCell(0, 64, 0));
  ok('T-junction rail flips its 90-degree curve when powered by redstone',
    unpoweredCurve === 6 && poweredCurve === 7);

  w.setBlock(10, 64, 10, ID.stone, 0);
  w.setBlock(10, 65, 10, ID.trapped_chest, 1); rs.register(10, 65, 10);
  w.setBlock(11, 64, 10, ID.redstone_wire, 0); rs.register(11, 64, 10);
  rs.tick();
  ok('open trapped_chest powers adjacent wire and strongly powers the block below it',
    blockState(w.getCell(11, 64, 10)) > 0);
}

// 8. Gamerules & Extended Commands (/gamerule, /setblock, /fill, /clone, /summon, ~ and ^ coords, @e selector)
{
  const w = makeWorld();
  const spawned: string[] = [];
  const stub: any = {
    meta: { mode: 'survival', id: 'cmdtest' },
    position: new THREE.Vector3(10, 64, 20),
    input: { yaw: 0, pitch: 0 },
    hotbar: [{ name: 'diamond_sword', count: 1 }, ...Array(8).fill(null)],
    inventory: Array(27).fill(null),
    armor: [null, null, null, null],
    offhand: null,
    selected: 0,
    xp: 100, lastLevel: 7, statistics: {},
    particles: { drop() {}, burst() {} },
    getCell: w.getCell,
    getBlock: w.getBlock,
    setBlock: w.setBlock,
    mobs: {
      mobs: [{ species: 'zombie', group: { position: new THREE.Vector3(12, 64, 20) } }],
      spawn(sp: string) { spawned.push(sp); return { species: sp }; },
      kill(m: any) { this.mobs = this.mobs.filter((x: any) => x !== m); },
    },
  };
  SV.command(stub, 'gamerule', ['keepInventory', 'true']);
  const d = SV.deathDrops(stub);
  ok('/gamerule keepInventory true preserves inventory and XP on death',
    stub.gamerules.keepInventory === true && d.dropped === 0 && stub.hotbar[0]?.name === 'diamond_sword' && stub.xp === 100);

  SV.command(stub, 'setblock', ['~2', '~1', '~-3', 'gold_block']);
  ok('/setblock supports relative ~ coordinates', w.getBlock(12, 65, 17) === ID.gold_block);

  SV.command(stub, 'fill', ['0', '64', '0', '2', '66', '2', 'stone', 'hollow']);
  ok('/fill hollow builds a 3x3x3 shell with air inside',
    w.getBlock(0, 64, 0) === ID.stone && w.getBlock(1, 65, 1) === 0);

  SV.command(stub, 'clone', ['0', '64', '0', '2', '66', '2', '20', '64', '20']);
  ok('/clone copies the region preserving hollow interior',
    w.getBlock(20, 64, 20) === ID.stone && w.getBlock(21, 65, 21) === 0);

  SV.command(stub, 'summon', ['iron_golem', '~', '~', '~']);
  const killMsg = SV.command(stub, 'kill', ['@e[type=zombie,distance=..10]']);
  ok('/summon and /kill @e[type=zombie,distance=..10] work with entity selectors',
    spawned.includes('iron_golem') && killMsg === 'Killed 1 entity(s)' && stub.mobs.mobs.length === 0);

  const local = parseCoords(['^0', '^0', '^5'], { x: 0, y: 64, z: 0, yaw: 0, pitch: 0 });
  ok('local ^ ^ ^ coordinates advance along the look vector',
    local !== null && local[0] === 0 && local[1] === 64 && local[2] === -5);
  const sel = parseSelector('@e[type=minecraft:creeper,distance=..15]');
  ok('selector parser extracts target, type and maxDistance',
    sel?.target === 'e' && sel.type === 'creeper' && sel.maxDistance === 15);
}

console.log(`\n${pass}/${pass + fail} Wiki-verified Vanilla+ checks passed`);
if (fail > 0) process.exit(1);
