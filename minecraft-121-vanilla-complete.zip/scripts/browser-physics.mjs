// Work A — browser measurement of the player physics in the built game (dist/index.html).
// Setup (once): mkdir /tmp/pw && cd /tmp/pw && npm init -y && npm i playwright-core && npx playwright-core install chromium-headless-shell
// Run: NODE_PATH=/tmp/pw/node_modules node scripts/browser-physics.mjs "$PWD/dist/index.html"
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
const require = createRequire(path.join(process.env.NODE_PATH ?? '/tmp/pw/node_modules', 'x.js'));
const { chromium } = require('playwright-core');

const dist = process.argv[2];
const cache = path.join(process.env.HOME, '.cache/ms-playwright');
const findExe = dir => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) { const r = findExe(p); if (r) return r; } else if (e.name === 'headless_shell' || e.name === 'chrome-headless-shell') return p; } return null; };
const browser = await chromium.launch({ executablePath: findExe(cache), args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 320, height: 180 } });
const errors = [];
page.on('pageerror', e => errors.push(String(e.stack ?? e).slice(0, 400)));
await page.goto('file://' + dist);
await page.waitForFunction(() => window.__game, null, { timeout: 60000 });
await page.evaluate(() => {
  const g = window.__game;
  g.setSettings({ ...g.settings, distance: 2, quality: 'low', adaptiveResolution: false, touch: false });
  g.start({ id: 'phys-1', name: 'phys', seed: '849281', mode: 'survival', difficulty: 'peaceful', hardcore: false, structures: false, bonus: false, cheats: true, created: 0, updated: 0, playTime: 0 });
});
await page.waitForFunction(() => window.__game.ready && window.__game.active, null, { timeout: 240000 });

// A 3-wide stone runway 40 blocks above the spawn, 90 blocks long towards −z (yaw 0 walks to −z).
const setup = await page.evaluate(() => {
  const g = window.__game, X = Math.floor(g.position.x), Z = Math.floor(g.position.z), Y = Math.floor(g.position.y) + 40;
  g.command(`/setblock ${X} ${Y} ${Z} stone`);
  const stone = g.getBlock(X, Y, Z);
  for (let z = Z - 90; z <= Z + 2; z++) for (let x = X - 1; x <= X + 1; x++) { g.setBlock(x, Y, z, stone); for (let y = 1; y <= 4; y++) g.setBlock(x, Y + y, z, 0); }
  g.weather = 'clear';
  return { X, Y, Z, stone };
});
const place = () => page.evaluate(s => {
  const g = window.__game;
  g.input.keys.clear(); g.input.yaw = 0; g.input.pitch = 0;
  g.position.set(s.X + 0.5, s.Y + 1, s.Z + 0.5); g.velocity.set(0, 0, 0); g.fallTop = g.position.y; g.flying = false;
}, setup);
/** Samples (playTime, x, y, z) every animation frame for `ms` while `keys` are held. */
const run = (keys, ms, release = ms) => page.evaluate(([keys, ms, release]) => new Promise(res => {
  const g = window.__game, out = [], t0 = performance.now();
  keys.forEach(k => g.input.keys.add(k));
  const f = () => {
    const now = performance.now() - t0;
    if (now >= release) keys.forEach(k => g.input.keys.delete(k));
    out.push([g.meta.playTime, g.position.x, g.position.y, g.position.z, g.grounded ? 1 : 0]);
    if (now < ms) requestAnimationFrame(f); else res(out);
  };
  requestAnimationFrame(f);
}), [keys, ms, release]);
const speedOf = s => { const a = s.find(r => r[0] - s[0][0] >= 1.5), b = s[s.length - 1]; return Math.abs(b[3] - a[3]) / (b[0] - a[0]); };
const fps = s => (s.length - 1) / (s[s.length - 1][0] - s[0][0]);
const out = {};
await place(); await page.waitForTimeout(800);
let s = await run(['KeyW'], 4000); out.walk = { mps: speedOf(s), fps: fps(s) };
await place(); await page.waitForTimeout(800);
s = await run(['KeyW', 'ControlLeft'], 4000); out.sprint = { mps: speedOf(s), fps: fps(s) };
await place(); await page.waitForTimeout(800);
s = await run(['KeyW', 'ShiftLeft'], 4000); out.sneak = { mps: speedOf(s), fps: fps(s) };
await place(); await page.waitForTimeout(800);
s = await run(['Space'], 1600, 120);
const y0 = s[0][2]; out.jump = { height: Math.max(...s.map(r => r[2])) - y0, fps: fps(s) };
await place(); await page.waitForTimeout(800);
s = await run(['KeyW'], 2200, 1500);
const rel = s.find(r => r[0] - s[0][0] >= 1.5) ?? s[s.length - 1];
out.stop = { coast: Math.abs(s[s.length - 1][3] - rel[3]) };
out.errors = errors.slice(0, 5);
console.log(JSON.stringify(out, null, 1));
await browser.close();
