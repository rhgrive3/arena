// Isometric render of generated structures (really generated chunks), for eyeballing builders.
// Usage: node render-structure.cjs <out.png> <seed:dim:x0:y0:z0:x1:y1:z1> [more views…]   (views are stacked vertically)
import fs from 'node:fs';
import zlib from 'node:zlib';
import '../src/game/content';
import { BLOCKS } from '../src/game/data';
import { Terrain, blockIndex } from '../src/world/terrain';

const [out = '/tmp/structure.png', ...views] = process.argv.slice(2);
const S = 5, hex = (h: string) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const base = BLOCKS.map(b => hex(b.color.length === 7 ? b.color : '#888888'));
const tiles: { w: number; h: number; px: Uint8Array }[] = [];
for (const view of views) {
  const [seed, dim, ...n] = view.split(':'), [x0, y0, z0, x1, y1, z1] = n.map(Number), t = new Terrain(seed, dim as 'overworld');
  const chunks = new Map<string, Uint16Array>();
  const cell = (x: number, y: number, z: number) => { const cx = Math.floor(x / 16), cz = Math.floor(z / 16), k = cx + ',' + cz; let d = chunks.get(k); if (!d) { d = t.generate(cx, cz).data as Uint16Array; chunks.set(k, d); } return d[blockIndex(x - cx * 16, y, z - cz * 16)] & 0x0fff; };
  const nx = x1 - x0 + 1, ny = y1 - y0 + 1, nz = z1 - z0 + 1, w = (nx + nz) * S + 4, h = (nx + nz) * (S >> 1) + ny * S + S + 4, px = new Uint8Array(w * h * 3).fill(24);
  const rect = (u: number, v: number, rw: number, rh: number, c: number[], k: number) => { for (let yy = Math.max(0, v); yy < Math.min(h, v + rh); yy++) for (let xx = Math.max(0, u); xx < Math.min(w, u + rw); xx++) { const i = (yy * w + xx) * 3; px[i] = c[0] * k; px[i + 1] = c[1] * k; px[i + 2] = c[2] * k; } };
  for (let s = 0; s <= nx + nz - 2; s++) for (let x = Math.max(0, s - nz + 1); x <= Math.min(nx - 1, s); x++) for (let y = 0; y < ny; y++) {
    const z = s - x, id = cell(x0 + x, y0 + y, z0 + z);
    if (!id) continue;
    const u = (x - z + nz - 1) * S + 2, v = (x + z) * (S >> 1) + (ny - 1 - y) * S + 2, c = base[id], thin = !BLOCKS[id].solid;
    if (thin) { rect(u + 3, v + 2, S - 1, S, c, 1); continue; }
    rect(u, v, 2 * S, S >> 1, c, 1); rect(u, v + (S >> 1), S, S, c, 0.72); rect(u + S, v + (S >> 1), S, S, c, 0.52);
  }
  tiles.push({ w, h, px });
}
const W = Math.max(...tiles.map(t => t.w)), H = tiles.reduce((a, t) => a + t.h, 0), img = new Uint8Array(W * H * 3).fill(24);
let oy = 0;
for (const t of tiles) { for (let y = 0; y < t.h; y++) img.set(t.px.subarray(y * t.w * 3, (y + 1) * t.w * 3), ((oy + y) * W) * 3); oy += t.h; }
const raw = Buffer.alloc((W * 3 + 1) * H);
for (let y = 0; y < H; y++) Buffer.from(img.buffer, y * W * 3, W * 3).copy(raw, y * (W * 3 + 1) + 1);
const table = new Int32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; table[n] = c; }
const crc = (b: Buffer) => { let c = -1; for (const v of b) c = table[(c ^ v) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
const chunk = (type: string, data: Buffer) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]), c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([len, td, c]); };
const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
fs.writeFileSync(out, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
console.log('wrote', out, W + 'x' + H);
