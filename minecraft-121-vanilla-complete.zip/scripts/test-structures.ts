// Structure verification suite (record 019): villages, strongholds, woodland mansions, ancient cities, bastion remnants,
// end ships, jungle temples, igloos and the room-level loot tables, checked against the Minecraft Wiki (Java Edition) descriptions.
// Every builder is run into an in-memory block map (and, for the integration checks, through the real chunk generator);
// redstone contraptions are executed with the game's own redstone engine.
import '../src/game/content';
import { BLOCKS, ID, resolve } from '../src/game/data';
import { blockId, blockState } from '../src/game/blockState';
import { Terrain, MIN_Y, END_FIRST_SHIP, END_OUTER_ARRIVAL, END_GATEWAY_MAIN, END_PILLAR_RADIUS, endPillars, FOOTPRINT_BUFFER, NETHER_HEIGHT, NETHER_LAVA, SEA as SEA_LEVEL_BLOCK } from '../src/world/terrain';
import { grandVillageLayout, villageVariantFor } from '../src/world/struct/villageGrand';
import { rotSize } from '../src/world/struct/jigsaw';
import { locateExtra, EXTRA_LOOT } from '../src/world/structures';
import { SEA, DX, DZ, mulberry, type StructHost } from '../src/world/struct/common';
import { plainsVillage, villageLayout } from '../src/world/struct/village';
import { strongholdLayout, buildStronghold, STRONGHOLD_RADIUS, type StrongholdLayout } from '../src/world/struct/stronghold';
import { mansion, mansionLayout, MANSION_SIGNATURE, ancientCity, ancientCityPlan, ANCIENT_CITY, bastion, bastionType, BASTION_TYPES } from '../src/world/struct/variants';
import { chamberLayout, trialChambers, ruinedPortalPlan, ruinedPortal, RUINED_PORTAL_VARIANTS, oceanRuinCluster, oceanRuin, trailRuinsLayout, trailRuins } from '../src/world/dungeons';
import { boxesOverlap } from '../src/world/struct/jigsaw';
import { endShip, END_SHIP, jungleTemple, jungleTempleParts, JUNGLE_CODE, igloo, iglooParts, iglooHasBasement, iglooShaftSections } from '../src/world/struct/extra';
import { mineshaftLayout, buildMineshaft, mineshaftVariantFor } from '../src/world/struct/mineshaft';
import { grandVillage, isZombieVillage } from '../src/world/struct/villageGrand';
import { ROOM_LOOT, FIXED_CONTENTS, rollRoomLoot, lootTagAt } from '../src/world/struct/loot';
import { Redstone, type RedstoneHost } from '../src/systems/redstone';
import * as SV from '../src/game/survival';

let pass = 0, fail = 0;
function ok(name: string, cond: boolean, detail: unknown = '') {
  if (cond) { pass++; console.log('PASS  ' + name); }
  else { fail++; console.log('FAIL  ' + name + (detail !== '' ? '  → ' + (typeof detail === 'string' ? detail : JSON.stringify(detail)) : '')); }
}
const section = (s: string) => console.log('\n── ' + s + ' ' + '─'.repeat(Math.max(0, 70 - s.length)));

type V3 = [number, number, number];
const K = (x: number, y: number, z: number) => x + ',' + y + ',' + z;
/** In-memory world with the chunk generator's `put` semantics (replace = false only fills empty cells). */
class Cap {
  cells = new Map<string, number>();
  private byName: Map<string, V3[]> | null = null;
  put = (x: number, y: number, z: number, id: number, replace = false) => { const k = K(x, y, z); if (replace || !this.cells.get(k)) { this.cells.set(k, id); this.byName = null; } };
  cell(x: number, y: number, z: number) { return this.cells.get(K(x, y, z)) ?? 0; }
  name(x: number, y: number, z: number) { return BLOCKS[blockId(this.cell(x, y, z))]?.name ?? 'air'; }
  state(x: number, y: number, z: number) { return blockState(this.cell(x, y, z)); }
  find(name: string): V3[] {
    if (!this.byName) {
      this.byName = new Map();
      for (const [k, c] of this.cells) { if (!c) continue; const n = BLOCKS[blockId(c)]?.name ?? 'air'; let a = this.byName.get(n); if (!a) this.byName.set(n, a = []); a.push(k.split(',').map(Number) as V3); }
    }
    return this.byName.get(name) ?? [];
  }
  count(name: string, box?: number[]) { const a = this.find(name); return box ? a.filter(([x, y, z]) => x >= box[0] && y >= box[1] && z >= box[2] && x <= box[3] && y <= box[4] && z <= box[5]).length : a.length; }
}
const mk = (seed: number, height: (x: number, z: number) => number = () => 70): StructHost & { structTags: Map<string, string> } => ({ seed, height, structTags: new Map() });
const tagsOf = (t: { structTags: Map<string, string> }, table: string): V3[] => [...t.structTags].filter(([, v]) => v === table).map(([k]) => k.split(',').map(Number) as V3);

const FLOWERS = new Set(['poppy', 'dandelion', 'allium', 'azure_bluet', 'red_tulip', 'oxeye_daisy', 'blue_orchid']);
const OPEN = (n: string) => n === 'air' || n === 'torch' || n === 'redstone_torch' || n === 'cobweb' || n === 'ladder' || n.endsWith('_door') || n.endsWith('_carpet') || n === 'redstone_wire'
  || n === 'lever' || n === 'tripwire' || n === 'tripwire_hook' || n === 'vine' || FLOWERS.has(n) || n === 'nether_wart' || n === 'sculk_sensor';
/** Flood fill through walkable cells that the builder wrote (anything it never touched counts as solid rock). */
function flood(w: Cap, start: V3, open: (n: string) => boolean = OPEN, limit = 600000): Set<string> {
  const seen = new Set<string>([K(...start)]), q: V3[] = [start];
  while (q.length && seen.size < limit) {
    const [x, y, z] = q.pop()!;
    for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
      const k = K(x + dx, y + dy, z + dz);
      if (seen.has(k) || !w.cells.has(k) || !open(w.name(x + dx, y + dy, z + dz))) continue;
      seen.add(k); q.push([x + dx, y + dy, z + dz]);
    }
  }
  return seen;
}
const near = (set: Set<string>, [x, y, z]: V3) => [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1], [0, 0, 0]].some(([a, b, c]) => set.has(K(x + a, y + b, z + c)));
/** Reads blocks from the real chunk generator. */
function reader(t: Terrain) {
  const chunks = new Map<string, Uint16Array>();
  const cell = (x: number, y: number, z: number) => {
    const cx = x >> 4, cz = z >> 4, k = cx + ',' + cz;
    let d = chunks.get(k);
    if (!d) { d = t.generate(cx, cz).data as Uint16Array; chunks.set(k, d); }
    return d[(y - MIN_Y) * 256 + (z & 15) * 16 + (x & 15)];
  };
  return { cell, name: (x: number, y: number, z: number) => BLOCKS[blockId(cell(x, y, z))]?.name ?? 'air' };
}

// ======================================================================================================================
section('1. Village — meeting point, church, weaponsmith, terraced farm (flat ground)');
{
  const t = mk(11), w = new Cap(), cx = 100, cz = 200;
  plainsVillage(t, w.put, cx, cz);
  const L = villageLayout(t, cx, cz), kinds = L.buildings.map(b => b.kind).sort().join(',');
  ok('layout: three houses, a church and a weaponsmith', kinds === 'church,house,house,house,smithy', kinds);
  ok('flat ground needs no foundation at all', L.buildings.every(b => b.foundation === 'flat'), L.buildings.map(b => b.foundation));
  const [bx, by, bz] = L.bell;
  ok('meeting point: a bell hangs under a wooden lintel between two fence posts', w.name(bx, by, bz) === 'bell' && w.name(bx, by + 1, bz) === 'oak_planks' && w.name(bx - 1, by, bz) === 'oak_fence' && w.name(bx + 1, by, bz) === 'oak_fence');
  ok('meeting point: the well holds water inside a mossy cobblestone ring', w.name(cx, L.wellY, cz) === 'water' && w.name(cx + 1, L.wellY, cz) === 'mossy_cobblestone' && w.name(cx, L.wellY + 3, cz) === 'oak_planks');
  const church = L.buildings.find(b => b.kind === 'church')!, cb = [church.x0, church.floorY - 1, church.z0, church.x1, church.floorY + 13, church.z1];
  ok('church: bell tower rises 11 blocks, twice the height of the nave', BLOCKS[blockId(w.cell(church.x0, church.floorY + 10, church.z0))]?.name.includes('cobblestone') === true && w.name(church.x0, church.floorY + 7, church.z1) === 'air');
  ok('church: ladder climbs the whole tower (12 rungs)', w.count('ladder', cb) === 12, w.count('ladder', cb));
  ok('church: cleric brewing stand, pews and glass pane windows', w.count('brewing_stand', cb) === 1 && w.count('oak_stairs', cb) === 8 && w.count('glass_pane', cb) >= 8, [w.count('brewing_stand', cb), w.count('oak_stairs', cb), w.count('glass_pane', cb)]);
  ok('church: its chest uses the village_temple table', tagsOf(t, 'village_temple').length === 1 && w.name(...tagsOf(t, 'village_temple')[0]) === 'chest');
  const smithy = L.buildings.find(b => b.kind === 'smithy')!, sb = [smithy.x0, smithy.floorY - 1, smithy.z0, smithy.x1, smithy.floorY + 5, smithy.z1];
  ok('weaponsmith: lava forge, blast furnace, grindstone, furnace and anvil', w.count('lava', sb) === 2 && w.count('blast_furnace', sb) === 1 && w.count('grindstone', sb) === 1 && w.count('furnace', sb) === 1 && w.count('anvil', sb) === 1,
    ['lava', 'blast_furnace', 'grindstone', 'furnace', 'anvil'].map(n => w.count(n, sb)));
  const safe = new Set(['cobblestone', 'mossy_cobblestone', 'iron_bars', 'lava']);
  ok('weaponsmith: the lava is walled in by stone and iron bars (nothing flammable touches it)', w.find('lava').every(([x, y, z]) => [[1, 0], [-1, 0], [0, 1], [0, -1]].every(([a, c]) => safe.has(w.name(x + a, y, z + c))) && w.name(x, y - 1, z) === 'cobblestone'));
  ok('weaponsmith: its chest uses the village_weaponsmith table', tagsOf(t, 'village_weaponsmith').length === 1 && w.name(...tagsOf(t, 'village_weaponsmith')[0]) === 'chest');
  const houses = L.buildings.filter(b => b.kind === 'house');
  ok('houses: each has a two-block door, a bed, a crafting table and a chest', houses.every(b => { const bb = [b.x0, b.floorY, b.z0, b.x1, b.floorY + 3, b.z1]; return w.count('oak_door', bb) === 2 && w.count('bed', bb) === 2 && w.count('crafting_table', bb) === 1 && w.count('chest', bb) === 1; }));
  ok('houses: the three chests use the village_plains_house table', tagsOf(t, 'village_plains_house').length === 3);
  const F = L.farm;
  ok('farm: three terraces, each one block higher than the last (段々畑)', F.terraces.length === 3 && F.terraces[1] - F.terraces[0] === 1 && F.terraces[2] - F.terraces[1] === 1, F.terraces);
  let channels = true, crops = 0, soil = 0, contained = true;
  for (let k = 0; k < 3; k++) {
    const Y = F.terraces[k], z0 = F.z0 + k * 5;
    for (let x = F.x0 + 1; x <= F.x1 - 1; x++) {
      if (w.name(x, Y, z0 + 2) !== 'water') channels = false;
      for (const z of [z0 + 1, z0 + 3]) { if (w.name(x, Y, z) === 'farmland_moist') soil++; if (['wheat_crop', 'carrots', 'potatoes'].includes(w.name(x, Y + 1, z))) crops++; }
    }
  }
  for (const [x, y, z] of w.find('water')) {
    if (x === cx && z === cz) continue;
    if (![[1, 0], [-1, 0], [0, 1], [0, -1]].every(([a, c]) => ['water', 'farmland_moist', 'oak_log'].includes(w.name(x + a, y, z + c))) || w.name(x, y - 1, z) !== 'dirt') contained = false;
  }
  ok('farm: every terrace has a nine-block irrigation channel', channels);
  ok('farm: hydrated farmland on both sides of the channels, planted with wheat, carrots and potatoes', soil === 54 && crops === 54 && w.count('wheat_crop') === 18 && w.count('carrots') === 18 && w.count('potatoes') === 18, [soil, crops]);
  ok('farm: the water is held by log borders and soil (cannot leak down the terraces)', contained);
  ok('farm: a composter stands beside the plots', w.name(...L.composter) === 'composter');
  ok('roads: dirt paths link the meeting point with every door', w.count('dirt_path') >= 60 && L.buildings.every(b => ['dirt_path', 'cobblestone', 'oak_planks'].includes(w.name(b.doorX + DX[b.doorDir], b.floorY - 1, b.doorZ + DZ[b.doorDir]))), w.count('dirt_path'));
  ok('lamp posts light the village', w.count('lantern') >= 5);
}

section('2. Village — foundations follow the terrain (stone walls / boardwalks)');
{
  // Gentle slope: one block every eight blocks → 1–2 blocks of difference under a building → stone retaining wall.
  const h1 = (x: number) => 70 + Math.floor((x - 60) / 8), t = mk(12, h1), w = new Cap(), cx = 100, cz = 200;
  plainsVillage(t, w.put, cx, cz);
  const L = villageLayout(t, cx, cz), walls = L.buildings.filter(b => b.foundation === 'stone_wall');
  ok('gentle slope: buildings with a 1–2 block height difference get a stone wall foundation', walls.length >= 2 && L.buildings.every(b => b.foundation !== 'boardwalk'), L.buildings.map(b => [b.kind, b.maxGround - b.minGround, b.foundation]));
  let gaps = 0, filled = 0;
  for (const b of walls) for (let z = b.z0; z <= b.z1; z++) for (let x = b.x0; x <= b.x1; x++) for (let y = h1(x) + 1; y <= b.floorY - 1; y++) { filled++; if (!w.name(x, y, z).includes('cobblestone')) gaps++; }
  ok('gentle slope: the wall closes every gap between floor and ground with (mossy) cobblestone', gaps === 0 && filled > 20, [gaps, filled]);
  ok('gentle slope: the floor sits on the highest ground of the footprint', L.buildings.every(b => b.floorY === b.maxGround + 1));

  // Steep slope: one block every two blocks → 3+ blocks of difference → log stilts and a plank boardwalk.
  const h2 = (x: number) => 70 + Math.floor((x - 60) / 2), t2 = mk(13, h2), w2 = new Cap();
  plainsVillage(t2, w2.put, cx, cz);
  const L2 = villageLayout(t2, cx, cz), decks = L2.buildings.filter(b => b.foundation === 'boardwalk');
  ok('steep slope: buildings with 3+ blocks of difference stand on a boardwalk foundation', decks.length >= 2 && decks.some(b => b.kind === 'church') && decks.some(b => b.kind === 'smithy'), L2.buildings.map(b => [b.kind, b.maxGround - b.minGround, b.foundation]));
  let stilts = true, stiltBlocks = 0;
  for (const b of decks) for (const [x, z] of [[b.x0, b.z0], [b.x0, b.z1]]) for (let y = h2(x) + 1; y <= b.floorY - 2; y++) { stiltBlocks++; if (w2.name(x, y, z) !== 'oak_log') stilts = false; }
  ok('steep slope: oak log stilts reach from the ground to the floor at the low corners', stilts && stiltBlocks >= 4, stiltBlocks);
  ok('steep slope: a plank deck runs along the door side of every stilted building', decks.every(b => { const z = b.doorZ + DZ[b.doorDir]; let n = 0; for (let x = b.x0; x <= b.x1; x++) if (w2.name(x, b.floorY - 1, z) === 'oak_planks') n++; return n >= b.x1 - b.x0; }));
  const churchB = decks.find(b => b.kind === 'church')!;
  ok('steep slope: wooden stairs lead from the deck down to the ground', w2.find('oak_stairs').some(([x, , z]) => x === churchB.doorX && z > churchB.z1 + 1));
  const ys: number[] = [];
  let causeway = true;
  for (let x = cx + 2; x <= cx + 22; x++) {
    let y = -1;
    for (let yy = 60; yy <= 130; yy++) if (w2.name(x, yy, cz) === 'dirt_path') y = yy;
    ys.push(y);
    for (let yy = h2(x) + 1; yy < y; yy++) if (!w2.name(x, yy, cz).includes('cobblestone')) causeway = false;
  }
  ok('steep slope: the road never steps more than one block at a time', ys.every((y, i) => y > 0 && (i === 0 || Math.abs(y - ys[i - 1]) <= 1)), ys);
  ok('steep slope: raised road sections rest on a stone causeway', causeway);
  // Water crossing.
  const h3 = (x: number) => (x >= cx - 21 && x <= cx - 16 ? 58 : 70), t3 = mk(14, h3), w3 = new Cap();
  plainsVillage(t3, w3.put, cx, cz);
  ok('water: the road crosses on a plank bridge at sea level', [16, 17, 18, 19, 20, 21].every(d => w3.name(cx - d, SEA, cz) === 'oak_planks' && w3.name(cx - d, SEA + 1, cz) === 'air') && w3.name(cx - 15, 70, cz) === 'dirt_path');
  const F3 = villageLayout(t3, cx, cz).farm;
  ok('water: farm terraces over the shore are filled up from the lake bed and still hold their channels', [0, 1, 2].every(k => { for (let x = F3.x0 + 1; x < F3.x1; x++) if (w3.name(x, F3.terraces[k], F3.z0 + k * 5 + 2) !== 'water' || w3.name(x, F3.terraces[k] - 1, F3.z0 + k * 5 + 2) !== 'dirt') return false; return true; }) && F3.terraces[0] >= SEA);
}

// ======================================================================================================================
section('3. Stronghold — piece generator (spiral start, corridors, prison, library, portal room)');
const SH_SEEDS = [1, 42, 849281, 20240601, -7, 123456];
{
  const layouts = SH_SEEDS.map(s => strongholdLayout(s, 1000, -600));
  const has = (L: StrongholdLayout, k: string) => L.pieces.some(p => p.type === k);
  ok('every stronghold starts with the spiral staircase', layouts.every(L => L.pieces[0].type === 'start'));
  ok('every stronghold has exactly one portal room', layouts.every(L => L.pieces.filter(p => p.type === 'portal_room').length === 1 && L.portal !== null));
  ok('every stronghold has 1–2 libraries and at least one prison hall', layouts.every(L => { const n = L.pieces.filter(p => p.type === 'library').length; return n >= 1 && n <= 2 && has(L, 'prison'); }), layouts.map(L => L.pieces.map(p => p.type).join(' ')).slice(0, 1));
  ok('corridors, turns and crossings connect the rooms (12+ pieces each)', layouts.every(L => L.pieces.length >= 12 && L.pieces.filter(p => p.type === 'corridor' || p.type === 'turn').length >= 3), layouts.map(L => L.pieces.length));
  ok('the portal room is never attached to the start: at least four pieces away', layouts.every(L => L.pieces.find(p => p.type === 'portal_room')!.depth >= 4), layouts.map(L => L.pieces.find(p => p.type === 'portal_room')!.depth));
  ok('pieces never overlap', layouts.every(L => L.pieces.every((a, i) => L.pieces.every((b, j) => i >= j || !(a.box[0] <= b.box[3] && a.box[3] >= b.box[0] && a.box[1] <= b.box[4] && a.box[4] >= b.box[1] && a.box[2] <= b.box[5] && a.box[5] >= b.box[2])))));
  ok('pieces stay inside the generation radius and above the bedrock layers', layouts.every(L => L.pieces.every(p => p.box[1] >= 6 && Math.max(Math.abs(p.box[0] - 1000), Math.abs(p.box[3] - 1000), Math.abs(p.box[2] + 600), Math.abs(p.box[5] + 600)) <= STRONGHOLD_RADIUS)));
  ok('layouts are deterministic per seed and differ between seeds', JSON.stringify(strongholdLayout(42, 1000, -600)) === JSON.stringify(layouts[1]) && JSON.stringify(layouts[0].pieces.map(p => p.type)) !== JSON.stringify(layouts[1].pieces.map(p => p.type)));
  ok('stairs lead to deeper levels in at least one stronghold', layouts.some(L => new Set(L.pieces.map(p => p.box[1])).size >= 3));
}
{
  const t = mk(42), w = new Cap(), L = buildStronghold(t, w.put, 1000, -600), [px, py, pz] = L.portal!;
  const frames = w.find('end_portal_frame');
  const facing = (x: number, z: number) => (z - pz === -2 ? 0 : x - px === 2 ? 1 : z - pz === 2 ? 2 : 3);
  ok('portal room: 12 end portal frames form the 5×5 ring', frames.length === 12 && frames.every(([x, y, z]) => y === py && Math.max(Math.abs(x - px), Math.abs(z - pz)) === 2 && Math.min(Math.abs(x - px), Math.abs(z - pz)) <= 1));
  ok('portal room: every frame faces the centre', frames.every(([x, y, z]) => (w.state(x, y, z) & 3) === facing(x, z)));
  ok('portal room: eyes are pre-filled at random but the portal is never complete', frames.filter(([x, y, z]) => w.state(x, y, z) & 4).length < 12);
  let lava = 0; for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (w.name(px + dx, py - 1, pz + dz) === 'lava') lava++;
  const room = L.pieces.find(p => p.type === 'portal_room')!;
  ok('portal room: lava pool under the ring, lava channels along the walls, spawner on the steps', lava === 9 && w.count('lava', room.box) >= 9 + 24 && w.count('spawner', room.box) === 1 && w.count('stone_brick_stairs', room.box) === 5, [lava, w.count('lava', room.box)]);
  ok('portal room: entered through an iron-bar grate, and it holds no chest', w.count('iron_bars', room.box) >= 7 + 16 && w.count('chest', room.box) === 0, w.count('iron_bars', room.box));
  const lib = L.pieces.find(p => p.type === 'library')!, libChests = tagsOf(t, 'stronghold_library').filter(([x, y, z]) => x >= lib.box[0] && x <= lib.box[3] && z >= lib.box[2] && z <= lib.box[5] && y >= lib.box[1] && y <= lib.box[4]);
  ok('library: two storeys of bookshelves (100+)', w.count('bookshelf', lib.box) >= 100, w.count('bookshelf', lib.box));
  ok('library: cobwebs hang between the shelves', w.count('cobweb', lib.box) >= 6, w.count('cobweb', lib.box));
  ok('library: plank gallery with a fence railing and a ladder up to it', w.count('oak_planks', lib.box) >= 60 && w.count('oak_fence', lib.box) >= 30 && w.count('ladder', lib.box) === 5, [w.count('oak_planks', lib.box), w.count('oak_fence', lib.box), w.count('ladder', lib.box)]);
  ok('library: one chest on each floor, both on the stronghold_library table', libChests.length === 2 && Math.abs(libChests[0][1] - libChests[1][1]) === 5 && libChests.every(c => w.name(...c) === 'chest'), libChests);
  const prison = L.pieces.find(p => p.type === 'prison')!;
  ok('prison hall: cells behind iron bars with two iron doors', w.count('iron_bars', prison.box) >= 30 && w.count('iron_door', prison.box) === 4, [w.count('iron_bars', prison.box), w.count('iron_door', prison.box)]);
  const start = L.pieces[0], slabs = w.find('stone_brick_slab').filter(([x, y, z]) => x >= start.box[0] && x <= start.box[3] && y >= start.box[1] && y <= start.box[4] && z >= start.box[2] && z <= start.box[5]);
  ok('spiral staircase: eleven half-block steps wind six blocks down around the newel', slabs.length === 11 && new Set(slabs.map(s => s[1])).size === 6 && w.name(1000, start.box[1] + 3, -600).includes('stone_bricks'), slabs.length);
  // Walk the maze: start at the top landing of the staircase.
  let sx: V3 | null = null;
  for (let y = start.box[4]; y >= start.box[1] && !sx; y--) for (let z = start.box[2]; z <= start.box[5] && !sx; z++) for (let x = start.box[0]; x <= start.box[3]; x++) if (w.cells.has(K(x, y, z)) && w.name(x, y, z) === 'air') { sx = [x, y, z]; break; }
  const walk = flood(w, sx!);
  ok('maze: the portal can be reached on foot from the starting staircase', walk.has(K(px, py, pz)));
  ok('maze: both library chests and the prison doors are reachable too', libChests.every(c => near(walk, c)) && w.find('iron_door').some(c => near(walk, c)));
  ok('maze: every placed piece is connected to the start', L.pieces.every(p => { for (let y = p.box[1] + 1; y < p.box[4]; y++) for (let z = p.box[2] + 1; z < p.box[5]; z++) for (let x = p.box[0] + 1; x < p.box[3]; x++) if (walk.has(K(x, y, z))) return true; return false; }));
  ok('masonry: stone bricks are mixed with mossy and cracked variants', w.count('stone_bricks') > 2000 && w.count('mossy_stone_bricks') > 300 && w.count('cracked_stone_bricks') > 300, [w.count('stone_bricks'), w.count('mossy_stone_bricks'), w.count('cracked_stone_bricks')]);
  // Chunk-by-chunk generation must produce exactly the same blocks.
  const clipped = new Cap();
  for (let oz = -688; oz <= -520; oz += 16) for (let ox = 912; ox <= 1088; ox += 16) buildStronghold(t, (x, y, z, id, rep) => { if (x >= ox && x < ox + 16 && z >= oz && z < oz + 16) clipped.put(x, y, z, id, rep); }, 1000, -600, ox, oz);
  let same = clipped.cells.size === w.cells.size;
  if (same) for (const [k, c] of w.cells) if (clipped.cells.get(k) !== c) { same = false; break; }
  ok('chunk clipping: building chunk by chunk yields the identical stronghold', same, [clipped.cells.size, w.cells.size]);
  // Tables across all seeds.
  const all = SH_SEEDS.map(s => { const th = mk(s), wh = new Cap(); buildStronghold(th, wh.put, 1000, -600); return { th, wh }; });
  ok('altar chests (chest corridor) use stronghold_corridor', all.some(a => tagsOf(a.th, 'stronghold_corridor').length > 0) && all.every(a => tagsOf(a.th, 'stronghold_corridor').every(c => a.wh.name(...c) === 'chest' && a.wh.name(c[0], c[1] - 1, c[2]).includes('stone_bricks'))));
  ok('store-room chests (room crossing) use stronghold_crossing', all.some(a => tagsOf(a.th, 'stronghold_crossing').length > 0) && all.every(a => tagsOf(a.th, 'stronghold_crossing').every(c => a.wh.name(c[0], c[1] - 1, c[2]) === 'oak_planks')));
  ok('every stronghold chest is tagged with one of the three stronghold tables', all.every(a => a.wh.find('chest').every(c => (a.th.structTags.get(K(...c)) ?? '').startsWith('stronghold_'))));
}

// ======================================================================================================================
section('4. Woodland mansion — irregular rooms, random links, room types');
{
  const P = { x: 0, y: 70, z: 0 }, seeds = [5, 77, 849281, 31337], layouts = seeds.map(s => mansionLayout(s, P));
  ok('rooms are irregular: single cells and merged double cells on every mansion', layouts.every(r => r.some(x => x.cells === 1) && r.some(x => x.cells === 2) && new Set(r.map(x => x.x1 - x.x0)).size >= 3), layouts.map(r => r.length));
  ok('the room count changes with the seed (16–24 rooms on three floors)', new Set(layouts.map(r => r.length)).size >= 2 && layouts.every(r => r.length >= 14 && r.length <= 24 && new Set(r.map(x => x.floor)).size === 3), layouts.map(r => r.length));
  ok('every mansion has a chest storage, a jail, a cat statue and a flower garden', layouts.every(r => ['storage', 'jail', 'cat_statue', 'flower_garden'].every(k => r.some(x => x.type === k))));
  ok('room plans differ between seeds and repeat for the same seed', JSON.stringify(layouts[0]) !== JSON.stringify(layouts[1]) && JSON.stringify(mansionLayout(77, P)) === JSON.stringify(layouts[1]));
  ok('at least eight different room types occur', new Set(layouts.flat().map(r => r.type)).size >= 8, [...new Set(layouts.flat().map(r => r.type))]);
  ok('rooms are linked at random by side doors', layouts.every(r => r.some(x => x.link !== null) && r.some(x => x.link === null)));
  const t = mk(77), w = new Cap(), rooms = layouts[1];
  mansion(t, w.put, P);
  const missing = rooms.filter(r => w.count(MANSION_SIGNATURE[r.type], [r.x0, r.y - 1, r.z0, r.x1, r.y + 3, r.z1]) === 0).map(r => r.type);
  ok('every room contains the furniture of its type', missing.length === 0, missing);
  ok('every room opens onto the corridor through a two-block doorway', rooms.every(r => w.name(r.doorX, r.y, P.z + r.side * 2) === 'air' && w.name(r.doorX, r.y + 1, P.z + r.side * 2) === 'air'));
  ok('side doors between neighbouring rooms are open', rooms.filter(r => r.link !== null).every(r => w.name(r.link!, r.y, P.z + r.side * 6) === 'air' && w.name(r.link!, r.y + 1, P.z + r.side * 6) === 'air'));
  const walk = flood(w, [P.x - 15, P.y, P.z]);
  ok('all three floors and every room can be reached from the entrance (stairs in the corridor)', rooms.every(r => walk.has(K(r.doorX, r.y, P.z + r.side * 3)) || walk.has(K(r.doorX, r.y + 1, P.z + r.side * 3))), rooms.filter(r => !walk.has(K(r.doorX, r.y, P.z + r.side * 3)) && !walk.has(K(r.doorX, r.y + 1, P.z + r.side * 3))).map(r => [r.floor, r.type]));
  const storage = rooms.filter(r => r.type === 'storage'), chests = w.find('chest');
  ok('storage rooms hold rows of chests on the mansion_storage table', chests.length >= 2 && chests.every(c => t.structTags.get(K(...c)) === 'mansion_storage') && storage.every(r => w.count('chest', [r.x0, r.y, r.z0, r.x1, r.y, r.z1]) >= 2), chests.length);
  const jail = rooms.find(r => r.type === 'jail')!, cat = rooms.find(r => r.type === 'cat_statue')!, garden = rooms.find(r => r.type === 'flower_garden')!;
  ok('jail: cells behind iron bars with iron doors', w.count('iron_bars', [jail.x0, jail.y, jail.z0, jail.x1, jail.y + 2, jail.z1]) >= 9 && w.count('iron_door', [jail.x0, jail.y, jail.z0, jail.x1, jail.y + 2, jail.z1]) >= 4);
  ok('cat statue: black wool body, head with ears and a raised tail', w.count('black_wool', [cat.x0, cat.y, cat.z0, cat.x1, cat.y + 3, cat.z1]) >= 18, w.count('black_wool', [cat.x0, cat.y, cat.z0, cat.x1, cat.y + 3, cat.z1]));
  const gb = [garden.x0, garden.y - 1, garden.z0, garden.x1, garden.y + 1, garden.z1];
  ok('flower garden: grass floor planted with several kinds of flowers', w.count('grass_block', gb) >= 9 && [...FLOWERS].filter(f => w.count(f, gb) > 0).length >= 3, [...FLOWERS].map(f => w.count(f, gb)));
  ok('shell: three floors of dark oak with a cobblestone foundation and a pitched roof', w.name(P.x, P.y - 1, P.z) === 'cobblestone' && w.name(P.x, P.y + 4, P.z).includes('planks') && w.name(P.x, P.y + 9, P.z).includes('planks') && w.name(P.x, P.y + 26, P.z).includes('log'));
}

// ======================================================================================================================
section('5. Ancient city — long corridors, barracks, redstone laboratory under the frame');
{
  const P = { x: 0, y: -51, z: 0 }, t = mk(9), w = new Cap(), y = P.y;
  ancientCity(t, w.put, P);
  const F = ANCIENT_CITY.frame, Lb = ANCIENT_CITY.lab, ly = y + Lb.floor + 1;
  ok('city centre: reinforced deepslate frame, 22 wide and 8 tall, open inside', w.count('reinforced_deepslate') === 2 * 22 + 2 * 6 && w.name(0, y + 3, 0) === 'air' && w.name(F.x0, y + 4, 0) === 'reinforced_deepslate' && w.name(F.x1, y + 4, 0) === 'reinforced_deepslate', w.count('reinforced_deepslate'));
  ok('laboratory: lies directly below the frame, sealed from the cavern floor', Lb.x0 <= F.x0 + 3 && Lb.x1 >= F.x1 - 2 && w.name(0, y + Lb.ceiling, 0) === 'deepslate_tiles' && w.name(0, ly, 2) === 'air' && y + Lb.ceiling < y - 1);
  const lb = [Lb.x0, y + Lb.floor, Lb.z0, Lb.x1, y + Lb.ceiling, Lb.z1];
  const parts = ['redstone_wire', 'repeater', 'comparator', 'sticky_piston', 'lever', 'note_block', 'target', 'lectern', 'redstone_block', 'sculk_sensor', 'redstone_torch'];
  ok('laboratory: redstone experiments (dust, repeater, comparator, piston, lamp, note block, target, lectern …)', parts.every(n => w.count(n, lb) >= 1) && w.count('unlit_redstone_lamp', lb) + w.count('redstone_lamp', lb) >= 2, parts.filter(n => w.count(n, lb) < 1));
  const open = flood(w, [0, y, 13]), sealed = flood(w, [0, y, 13], n => OPEN(n) && n !== 'iron_door');
  ok('laboratory: a stairwell behind the frame leads down to its iron door', open.has(K(0, ly, 2)) && w.name(0, ly, 5) === 'iron_door' && w.name(0, ly + 1, 5) === 'iron_door');
  ok('laboratory: with the door shut it cannot be entered; the lever above the door opens it', !sealed.has(K(0, ly, 2)) && w.name(0, ly + 2, 6) === 'lever');
  let floorOk = true, pillars = 0;
  for (const c of ANCIENT_CITY.corridors) for (let x = c.x0; x <= c.x1; x++) {
    for (let d = -2; d <= 2; d++) if (!['deepslate_tiles', 'gray_wool'].includes(w.name(x, y - 1, c.z + d))) floorOk = false;
    if (x % 4 === 0) for (const d of [-2, 2]) if (['deepslate_bricks', 'cobbled_deepslate'].includes(w.name(x, y + 2, c.z + d))) pillars++;
  }
  ok('long corridors: two 65-block colonnades paved with deepslate tiles and a wool runner', floorOk && ANCIENT_CITY.corridors.every(c => c.x1 - c.x0 + 1 === 65));
  ok('long corridors: deepslate brick pillars every four blocks and soul lanterns under a ruined roof', pillars === 2 * 2 * 17 && w.count('soul_lantern') >= 20 && w.count('deepslate_bricks') > 400, [pillars, w.count('soul_lantern')]);
  ok('barracks: two halls with bunk beds (six beds below, six wool bunks above, each)', ANCIENT_CITY.barracks.every(b => w.count('bed', [b.x0, y, b.z0, b.x1, y, b.z1]) === 12 && w.count('gray_wool', [b.x0, y + 3, b.z0, b.x1, y + 3, b.z1]) === 12), ANCIENT_CITY.barracks.map(b => w.count('bed', [b.x0, y, b.z0, b.x1, y, b.z1])));
  ok('barracks: reachable from the city and stocked with an ancient_city chest', ANCIENT_CITY.barracks.every(b => { const c = tagsOf(t, 'ancient_city').find(([x, , z]) => x >= b.x0 && x <= b.x1 && z >= b.z0 && z <= b.z1); return !!c && near(open, c); }));
  const I = ANCIENT_CITY.iceBox, ice = tagsOf(t, 'ancient_city_ice_box');
  ok('ice box: packed ice room whose chest uses its own table', ice.length === 1 && w.name(...ice[0]) === 'chest' && w.count('packed_ice', [I.x0, y - 1, I.z0, I.x1, y + 3, I.z1]) >= 25 && near(open, ice[0]), w.count('packed_ice'));
  ok('sculk: veins on the cavern floor with sensors, shriekers and catalysts', w.count('sculk_block') > 400 && w.count('sculk_sensor') >= 3 && w.count('sculk_shrieker') >= 2 && w.count('sculk_catalyst') >= 2, [w.count('sculk_block'), w.count('sculk_sensor'), w.count('sculk_shrieker'), w.count('sculk_catalyst')]);
  ok('city chests: corridor and barracks chests use ancient_city (4 chests)', tagsOf(t, 'ancient_city').length === 4 && w.count('chest') === 5);
}

// ======================================================================================================================
section('6. Bastion remnant — treasure room, hoglin stables, bridge, housing units');
{
  const seen = new Set<string>();
  for (let i = 0; i < 60; i++) seen.add(bastionType(7, i * 176 + 31, i * 97 - 400));
  ok('the variant is chosen per site and all four occur', seen.size === 4 && bastionType(7, 31, -400) === bastionType(7, 31, -400), [...seen]);
  const P = { x: 0, y: 32, z: 0 }, y = P.y, built = Object.fromEntries(BASTION_TYPES.map(k => { const t = mk(21), w = new Cap(); bastion(t, w.put, P, k); return [k, { t, w }]; }));
  const T = built.treasure, S = built.hoglin_stable, B = built.bridge, H = built.housing;
  ok('treasure room: lava pit with a central platform, gold blocks and a spawner', T.w.count('lava') >= 300 && T.w.count('gold_block') >= 10 && T.w.name(0, y, 0) === 'spawner' && T.w.name(0, y - 1, 0) === 'polished_blackstone_bricks', [T.w.count('lava'), T.w.count('gold_block')]);
  ok('treasure room: four bridges cross the lava to the platform', [[5, 0], [-5, 0], [0, 5], [0, -5]].every(([a, c]) => T.w.name(a, y - 1, c) === 'polished_blackstone_bricks' && T.w.name(a, y - 3, c) === 'lava') && T.w.name(5, y - 1, 5) === 'air');
  ok('treasure room: two chests on the bastion_treasure table', tagsOf(T.t, 'bastion_treasure').length === 2 && T.w.count('chest') === 2);
  ok('hoglin stables: ten pens on soul soil and nylium with hay, under a roof', S.w.count('hay_block') === 10 && S.w.count('soul_soil') + S.w.count('crimson_nylium') >= 300 && S.w.count('chain') === 20 && S.w.name(0, y + 7, 0).includes('blackstone'), [S.w.count('hay_block'), S.w.count('chain')]);
  ok('hoglin stables: two chests on the bastion_hoglin_stable table', tagsOf(S.t, 'bastion_hoglin_stable').length === 2 && S.w.count('chest') === 2);
  let deck = true; for (let dz = -8; dz <= 8; dz++) if (B.w.name(0, y + 5, dz) !== 'polished_blackstone_bricks' || B.w.name(0, y + 6, dz) !== 'air') deck = false;
  ok('bridge: a high deck spans the lava moat between two gate towers', deck && B.w.name(0, y - 1, 0) === 'lava' && B.w.name(5, y + 8, 12).includes('blackstone') && B.w.name(5, y + 8, -12).includes('blackstone') && B.w.count('ladder') === 12, B.w.count('ladder'));
  ok('bridge: two chests on the bastion_bridge table', tagsOf(B.t, 'bastion_bridge').length === 2 && B.w.count('chest') === 2);
  ok('housing units: four two-storey houses around a nether wart courtyard', H.w.count('nether_wart') === 25 && H.w.count('soul_sand') === 25 && H.w.count('ladder') === 20 && H.w.name(8, y + 4, 8) === 'blackstone' && H.w.name(8, y + 6, 8) === 'air', [H.w.count('nether_wart'), H.w.count('ladder')]);
  ok('housing units: chests on the bastion_other table', tagsOf(H.t, 'bastion_other').length === 4 && H.w.count('chest') === 4);
  const sig = (w: Cap) => ['lava', 'hay_block', 'nether_wart', 'ladder', 'spawner', 'chain'].map(n => (w.count(n) > 0 ? 1 : 0)).join('');
  ok('the four variants are built differently', new Set([T, S, B, H].map(b => sig(b.w))).size === 4, [T, S, B, H].map(b => sig(b.w)));
  ok('all variants use blackstone masonry with gilded blackstone and basalt', [T, S, B, H].every(b => b.w.count('polished_blackstone_bricks') > 300 && b.w.count('gilded_blackstone') > 10 && b.w.count('basalt') > 10));
}

// ======================================================================================================================
section('7. End ship — dragon head, elytra item frame, Instant Health II brewing stand');
{
  const t = mk(33), w = new Cap(), O: V3 = [0, 40, 0], at = (o: readonly number[]): V3 => [O[0] + o[0], O[1] + o[1], O[2] + o[2]];
  endShip(t, w.put, ...O);
  const frame = at(END_SHIP.elytraFrame), stand = at(END_SHIP.brewingStand), chests = END_SHIP.chests.map(at);
  ok('a dragon head is mounted on the bow', w.name(...at(END_SHIP.dragonHead)) === 'dragon_head' && w.name(0, 45, -1) === 'end_stone_bricks');
  ok('the elytra hangs in an item frame on the stern bulkhead', w.name(...frame) === 'item_frame' && w.name(frame[0], frame[1], frame[2] + 1) === 'purpur_block' && t.structTags.get(K(...frame)) === 'end_ship_elytra');
  ok('the item frame holds exactly one elytra', FIXED_CONTENTS.end_ship_elytra.slots.length === 1 && FIXED_CONTENTS.end_ship_elytra.slots[0][1] === 'elytra' && !!resolve('elytra'));
  ok('two treasure chests flank the frame (end_city_treasure)', chests.every(c => w.name(...c) === 'chest' && t.structTags.get(K(...c)) === 'end_city_treasure' && w.name(c[0], c[1] + 1, c[2]) === 'air') && chests[0][0] === frame[0] - 1 && chests[1][0] === frame[0] + 1);
  ok('the brewing stand holds two Instant Health II potions', w.name(...stand) === 'brewing_stand' && t.structTags.get(K(...stand)) === 'end_ship_brewing' && FIXED_CONTENTS.end_ship_brewing.slots.length === 2 && FIXED_CONTENTS.end_ship_brewing.slots.every(s => s[1] === 'potion_healing_strong' && s[0] < 3) && !!resolve('potion_healing_strong'));
  let minY = Infinity, minZ = Infinity, maxZ = -Infinity; for (const k of w.cells.keys()) { const [, yy, zz] = k.split(',').map(Number); if (w.cells.get(k)) { minY = Math.min(minY, yy); minZ = Math.min(minZ, zz); maxZ = Math.max(maxZ, zz); } }
  ok('the ship floats: a 25-block purpur hull with nothing beneath the keel', minY === 40 && maxZ - minZ + 1 >= 25 && w.count('purpur_block') > 400 && w.name(0, 40, 12) === 'obsidian', [minY, maxZ - minZ + 1, w.count('purpur_block')]);
  ok('mast with a crow\'s nest and end rods', w.name(...at(END_SHIP.mastTop)) === 'end_rod' && w.count('purpur_pillar', [0, 45, 11, 0, 56, 11]) === 12 && w.count('end_rod') >= 6);
  const walk = flood(w, [0, 45, 10]);
  ok('the hold is reached by a ladder from the deck; chests, frame and stand are accessible', w.count('ladder') === 4 && near(walk, frame) && chests.every(c => near(walk, c)) && near(walk, stand));
  ok('stern cabin with stained glass windows', w.count('magenta_stained_glass') === 4 && w.name(0, 45, 18) === 'air');
}

// ======================================================================================================================
section('8. Jungle temple — dispenser arrow trap and three-lever combination vault');
{
  const P = { x: 0, y: 70, z: 0 }, t = mk(3), w = new Cap(), J = jungleTempleParts(P);
  jungleTemple(t, w.put, P);
  ok('12×15 mossy cobblestone pyramid with two tiers above ground', w.name(-6, 72, -7).includes('cobblestone') && w.name(5, 72, 7).includes('cobblestone') && w.name(-5, 77, -6).includes('cobblestone') && w.count('mossy_cobblestone') > 250 && w.count('cobblestone') > 400);
  ok('vines grow on the outer walls', w.count('vine') >= 20, w.count('vine'));
  ok('three levers sit side by side on the basement wall', J.levers.every((c, i) => w.name(...c) === 'lever' && (w.state(...c) & 8) === 0 && w.name(...J.supports[i]).includes('cobblestone')) && w.count('lever') === 3);
  ok('two sticky pistons hold the vault wall shut', J.pistons.every(c => w.name(...c) === 'sticky_piston' && (w.state(...c) & 8) === 8) && J.heads.every(c => w.name(...c) === 'piston_head') && J.door.every(c => w.name(...c) === 'mossy_cobblestone'));
  ok('tripwire: two hooks face each other across the corridor with string between them', J.hooks.every(c => w.name(...c) === 'tripwire_hook') && J.strings.every(c => w.name(...c) === 'tripwire') && w.state(...J.hooks[0]) === 1 && w.state(...J.hooks[1]) === 2);
  ok('dispenser: hidden at the end of the corridor, facing down it, wired to the hook', w.name(...J.dispenser) === 'dispenser' && (w.state(...J.dispenser) & 7) === 3 && J.trapDust.every(c => w.name(...c) === 'redstone_wire') && t.structTags.get(K(...J.dispenser)) === 'jungle_temple_dispenser');
  ok('two chests: one behind the trap, one inside the vault (jungle_temple table)', tagsOf(t, 'jungle_temple').length === 2 && J.chests.every(c => w.name(...c) === 'chest') && w.count('chest') === 2);
  const closed = flood(w, [-1, 70, 5]);
  ok('the corridor chest is reachable from the entrance, the vault is sealed', near(closed, J.chests[0]) && !near(closed, J.chests[1]) && closed.has(K(...J.corridor)), [near(closed, J.chests[0]), near(closed, J.chests[1])]);
  ok('the wiring is hidden inside the walls', [...J.dust, ...J.torches, ...J.trapDust].every(c => !closed.has(K(...c))));

  // Run the contraptions with the game's redstone engine.
  class RW implements RedstoneHost {
    cells = new Map<string, number>(); ejected: string[] = [];
    getCell(x: number, y: number, z: number) { return this.cells.get(K(x, y, z)) ?? 0; }
    setBlock(x: number, y: number, z: number, id: number, state = 0) { const k = K(x, y, z), c = id === 0 ? 0 : id | (state << 12); if ((this.cells.get(k) ?? 0) === c) return false; if (c) this.cells.set(k, c); else this.cells.delete(k); return true; }
    eject(x: number, y: number, z: number, dir: number, kind: string) { this.ejected.push(kind + ':' + K(x, y, z) + ':' + dir); return true; }
    containerSignal() { return 0; }
    door() { /* no doors in the temple */ }
    sound() { /* silent */ }
  }
  const boot = () => {
    const rw = new RW(), r = new Redstone(rw);
    for (const [k, c] of w.cells) if (c) rw.cells.set(k, c);
    for (const k of rw.cells.keys()) { const [x, y, z] = k.split(',').map(Number); r.register(x, y, z); }
    const tick = (n: number) => { for (let i = 0; i < n; i++) r.tick(); };
    const nm = (c: V3) => BLOCKS[blockId(rw.getCell(...c))]?.name ?? 'air';
    return { rw, r, tick, nm };
  };
  const idle = boot(); idle.tick(20);
  ok('redstone: with all levers off the lock rests closed (pistons stay extended)', J.pistons.every(c => (blockState(idle.rw.getCell(...c)) & 8) === 8) && J.door.every(c => idle.nm(c) === 'mossy_cobblestone'), J.door.map(c => idle.nm(c)));
  const results: string[] = [];
  let correct = true;
  for (let m = 0; m < 8; m++) {
    const sim = boot(), combo = [0, 1, 2].map(i => !!(m & (1 << i)));
    sim.tick(4);
    combo.forEach((on, i) => { if (on) sim.r.set(...J.levers[i], ID.lever, blockState(w.cell(...J.levers[i])) | 8); });
    sim.tick(30);
    const opened = J.door.every(c => sim.nm(c) === 'air'), want = combo.every((v, i) => v === JUNGLE_CODE[i]);
    results.push(combo.map(v => (v ? 1 : 0)).join('') + (opened ? ':open' : ':shut'));
    if (opened !== want) correct = false;
  }
  ok('redstone: only the combination ON-OFF-ON retracts the pistons and opens the vault (all 8 combinations tried)', correct, results);
  {
    const sim = boot(); sim.tick(4);
    JUNGLE_CODE.forEach((on, i) => { if (on) sim.r.set(...J.levers[i], ID.lever, blockState(w.cell(...J.levers[i])) | 8); });
    sim.tick(30);
    const after = new Cap(); for (const [k, c] of w.cells) after.cells.set(k, sim.rw.cells.get(k) ?? 0);
    ok('redstone: with the vault open the hidden chest can be reached from the corridor', near(flood(after, [-1, 70, 5]), J.chests[1]));
    JUNGLE_CODE.forEach((on, i) => { if (on) sim.r.set(...J.levers[i], ID.lever, blockState(w.cell(...J.levers[i]))); });
    sim.tick(30);
    ok('redstone: switching the levers back closes the vault again', J.door.every(c => sim.nm(c) === 'mossy_cobblestone'), J.door.map(c => sim.nm(c)));
  }
  {
    const sim = boot(); sim.tick(4);
    const before = sim.rw.ejected.length;
    sim.r.set(...J.hooks[1], ID.tripwire_hook, blockState(w.cell(...J.hooks[1])) | 8);       // an entity walks through the string
    sim.tick(12);
    ok('redstone: tripping the wire fires the dispenser down the corridor', before === 0 && sim.rw.ejected.some(e => e.startsWith('dispenser:' + K(...J.dispenser))), sim.rw.ejected);
  }
  const arrows = Array.from({ length: 40 }, (_, i) => rollRoomLoot(ROOM_LOOT.jungle_temple_dispenser, mulberry(i + 1), n => !!resolve(n), () => 64, 9).filter(Boolean));
  ok('the dispenser is loaded with 2–14 arrows and nothing else', arrows.every(a => a.length >= 1 && a.length <= 2 && a.every(s => s!.name === 'arrow' && s!.count >= 2 && s!.count <= 7)));
}

// ======================================================================================================================
section('9. Igloo — snow dome, carpet over the trapdoor, basement laboratory');
{
  let withB: { x: number; y: number; z: number } | null = null, without: { x: number; y: number; z: number } | null = null, n = 0;
  for (let i = 0; i < 400; i++) { const p = { x: i * 37 - 900, y: 80, z: i * 53 + 11 }; if (iglooHasBasement(55, p.x, p.z)) { n++; withB ??= p; } else without ??= p; }
  ok('about half of the igloos have a basement', n > 140 && n < 260, n);
  const t = mk(55, () => 79), w = new Cap(), P = withB!, G = iglooParts(55, P);
  igloo(t, w.put, P);
  ok('snow block dome, 7 blocks across, with ice windows', w.count('snow_block') > 120 && w.name(P.x - 3, P.y + 1, P.z) === 'ice' && w.name(P.x + 3, P.y + 1, P.z) === 'ice' && w.name(P.x, P.y + 3, P.z) === 'snow_block' && w.name(P.x, P.y + 2, P.z) === 'air', w.count('snow_block'));
  ok('furnished with a bed, a furnace, a crafting table and a redstone torch', w.count('bed', [P.x - 3, P.y, P.z - 3, P.x + 3, P.y, P.z + 3]) === 2 && w.count('furnace') === 1 && w.count('crafting_table') === 1 && w.count('redstone_torch') === 1);
  ok('white and light gray carpet covers the floor', w.count('white_carpet') + w.count('light_gray_carpet') >= 12 && w.count('light_gray_carpet') >= 4, [w.count('white_carpet'), w.count('light_gray_carpet')]);
  const inside = flood(w, [P.x, P.y, P.z + 5]);
  ok('the entrance tunnel leads into the dome', inside.has(K(P.x, P.y + 1, P.z)));
  ok('a trapdoor is set into the floor and hidden under a carpet', w.name(...G.trapdoor) === 'oak_trapdoor' && (w.state(...G.trapdoor) & 12) === 4 && w.name(...G.carpet) === 'white_carpet' && G.carpet[1] === G.trapdoor[1] + 1);
  let rungs = 0; for (let yy = G.floorY; yy <= P.y - 2; yy++) if (w.name(P.x, yy, P.z - 2) === 'ladder') rungs++;
  ok('a ladder shaft runs from the trapdoor down to the basement', rungs === P.y - 1 - G.floorY && rungs === 13 && w.name(P.x, P.y - 5, P.z - 3).includes('stone_bricks'), rungs);
  const room = flood(w, [P.x, G.floorY, P.z]);
  ok('basement: brewing stand, cauldron and chest', w.name(...G.brewingStand) === 'brewing_stand' && w.name(...G.cauldron) === 'cauldron' && w.name(...G.chest) === 'chest' && near(room, G.chest) && near(room, G.brewingStand));
  ok('basement: the brewing stand holds a Splash Potion of Weakness', t.structTags.get(K(...G.brewingStand)) === 'igloo_brewing' && FIXED_CONTENTS.igloo_brewing.slots[0][1] === 'splash_weakness' && !!resolve('splash_weakness'));
  ok('basement: the chest uses igloo_chest, which always contains a golden apple', t.structTags.get(K(...G.chest)) === 'igloo_chest' && ROOM_LOOT.igloo_chest.always!.some(a => a[0] === 'golden_apple' && a[3] === 1));
  const standable = (c: V3) => w.cells.has(K(...c)) && w.name(...c) === 'air' && w.name(c[0], c[1] + 1, c[2]) === 'air' && w.name(c[0], c[1] - 1, c[2]).includes('stone_bricks');
  ok('basement: two cells behind iron bars hold the villager and the zombie villager', standable(G.villager) && standable(G.zombieVillager) && !room.has(K(...G.villager)) && !room.has(K(...G.zombieVillager)) && w.count('iron_bars') === 12 && !flood(w, G.villager).has(K(...G.zombieVillager)));
  ok('basement is only reachable through the hatch (the carpet hides it)', room.has(K(P.x, P.y - 2, P.z - 2)) && !inside.has(K(P.x, P.y - 2, P.z - 2)));
  const t2 = mk(55, () => 79), w2 = new Cap();
  igloo(t2, w2.put, without!);
  ok('igloos without a basement have no trapdoor, ladder or laboratory', w2.count('oak_trapdoor') === 0 && w2.count('ladder') === 0 && w2.count('brewing_stand') === 0 && w2.count('snow_block') > 120 && t2.structTags.size === 0);
}

// ======================================================================================================================
section('10. Room-level loot tables');
{
  const exists = (n: string) => !!resolve(n), names = Object.keys(ROOM_LOOT);
  const rolls = (table: string, n = 300) => Array.from({ length: n }, (_, i) => rollRoomLoot(ROOM_LOOT[table], mulberry(i * 7919 + 13), exists, k => resolve(k)?.stack ?? 64).filter(Boolean).map(s => s!));
  const seenIn = (table: string) => new Set(rolls(table).flat().map(s => s.name));
  ok('18 room tables are defined (stronghold ×3, village ×3, bastion ×4, ancient city ×2, jungle temple ×2 …)', names.length === 18 && ['stronghold_library', 'stronghold_corridor', 'stronghold_crossing', 'desert_pyramid', 'mansion_storage', 'village_weaponsmith', 'village_temple', 'village_plains_house', 'igloo_chest', 'jungle_temple', 'jungle_temple_dispenser', 'end_city_treasure', 'bastion_treasure', 'bastion_hoglin_stable', 'bastion_bridge', 'bastion_other', 'ancient_city', 'ancient_city_ice_box'].every(k => names.includes(k)), names.length);
  ok('every table rolls at least one real item every time', names.every(k => rolls(k, 60).every(r => r.length > 0 && r.every(s => exists(s.name) && s.count >= 1 && s.count <= (resolve(s.name)?.stack ?? 64)))), names.filter(k => !rolls(k, 60).every(r => r.length > 0)));
  ok('at least 85 % of the Wiki entries exist in this game\'s item registry', (() => { const all = names.flatMap(k => ROOM_LOOT[k].items.map(i => i[0])); return all.filter(exists).length / all.length; })() >= 0.85, [...new Set(names.flatMap(k => ROOM_LOOT[k].items.map(i => i[0])).filter(n => !exists(n)))]);
  ok('rolls are deterministic for a chest position', JSON.stringify(rolls('bastion_other', 5)) === JSON.stringify(rolls('bastion_other', 5)));
  const lib = seenIn('stronghold_library'), cor = seenIn('stronghold_corridor'), cro = seenIn('stronghold_crossing');
  ok('stronghold library: only books, paper, maps, compasses and enchanted books', [...lib].every(n => ['book', 'paper', 'map', 'compass', 'enchanted_book', 'eye_armor_trim_smithing_template'].includes(n)) && lib.has('book') && lib.has('paper') && lib.has('enchanted_book'), [...lib]);
  ok('stronghold altar chest: ender pearls, iron gear and diamonds — never paper', cor.has('ender_pearl') && cor.has('iron_sword') && cor.has('diamond') && !cor.has('paper') && !cor.has('coal'), [...cor]);
  ok('stronghold store room: coal, bread, ingots — no ender pearls', cro.has('coal') && cro.has('bread') && !cro.has('ender_pearl') && !cro.has('book'), [...cro]);
  const pyr = seenIn('desert_pyramid');
  ok('desert pyramid TNT chamber: bones, spider eyes, rotten flesh, golden apples, sand', ['bone', 'spider_eye', 'rotten_flesh', 'golden_apple', 'sand', 'gunpowder', 'emerald'].every(n => pyr.has(n)) && !pyr.has('book') && !pyr.has('ender_pearl'), [...pyr]);
  const man = seenIn('mansion_storage');
  ok('mansion storage: leads, name tags, music discs, seeds and the chance of a diamond chestplate', ['lead', 'name_tag', 'music_disc_13', 'music_disc_cat', 'melon_seeds', 'diamond_chestplate', 'diamond_hoe'].every(n => man.has(n)) && !man.has('ender_pearl'), [...man]);
  const smith = seenIn('village_weaponsmith'), temple = seenIn('village_temple'), house = seenIn('village_plains_house');
  ok('village: weaponsmith (iron gear, obsidian), temple (redstone, lapis) and house (potatoes, saplings) differ', smith.has('iron_sword') && smith.has('obsidian') && !smith.has('potato') && temple.has('redstone') && temple.has('lapis_lazuli') && !temple.has('iron_sword') && house.has('potato') && house.has('oak_sapling') && !house.has('obsidian'));
  ok('igloo chest: a golden apple in every roll', rolls('igloo_chest').every(r => r.some(s => s.name === 'golden_apple')));
  ok('bastion treasure: always a netherite upgrade template; netherite ingots and ancient debris', rolls('bastion_treasure').every(r => r.some(s => s.name === 'netherite_upgrade')) && seenIn('bastion_treasure').has('netherite_ingot') && seenIn('bastion_treasure').has('ancient_debris'));
  ok('bastion bridge: always a lodestone', rolls('bastion_bridge').every(r => r.some(s => s.name === 'lodestone')));
  ok('bastion stables and housing: saddles/golden carrots vs. pigstep/banner pattern', seenIn('bastion_hoglin_stable').has('saddle') && seenIn('bastion_hoglin_stable').has('golden_carrot') && !seenIn('bastion_hoglin_stable').has('music_disc_pigstep') && seenIn('bastion_other').has('music_disc_pigstep') && seenIn('bastion_other').has('piglin_banner_pattern'));
  ok('ancient city ice box: only stew, golden carrots, baked potatoes, packed ice and snowballs', [...seenIn('ancient_city_ice_box')].every(n => ['suspicious_stew', 'golden_carrot', 'baked_potato', 'packed_ice', 'snowball'].includes(n)) && seenIn('ancient_city').has('echo_shard'), [...seenIn('ancient_city_ice_box')]);
  ok('end city treasure: diamond and iron gear, gold, beetroot seeds', ['diamond', 'gold_ingot', 'iron_ingot', 'beetroot_seeds', 'diamond_sword', 'iron_pickaxe'].every(n => seenIn('end_city_treasure').has(n)));
  ok('fixed contents reference real items', Object.values(FIXED_CONTENTS).every(f => f.slots.every(s => exists(s[1]) && s[0] < f.size)));
  ok('the new structure kinds also have a fallback table in EXTRA_LOOT', !!EXTRA_LOOT.jungle_temple && !!EXTRA_LOOT.igloo && Object.values(EXTRA_LOOT).every(tb => tb.items.every(i => exists(i[0]))));
}

// ======================================================================================================================
section('11. Integration with the chunk generator (seed 849281)');
{
  const T = new Terrain('849281'), R = reader(T);
  // Nearest seed-determined village (there is no hand-placed spawn village any more — vanilla has none either).
  const nearest = T.locate('village', 0, 0)!;
  ok('no fixed spawn village / starter cabin: the nearest village is found purely from the seed', !!nearest && !(nearest[0] === 15 && nearest[2] === 16) && R.name(-21, T.height(-21, -16) + 1, -16) !== 'oak_planks', nearest);
  const L = villageLayout(T, nearest[0], nearest[2]), smithy = L.buildings.find(b => b.kind === 'smithy')!, church = L.buildings.find(b => b.kind === 'church')!;
  const scan = (name: string, b: { x0: number; z0: number; x1: number; z1: number; floorY: number }, up = 4) => { let n = 0; for (let y = b.floorY - 1; y <= b.floorY + up; y++) for (let z = b.z0; z <= b.z1; z++) for (let x = b.x0; x <= b.x1; x++) if (R.name(x, y, z) === name) n++; return n; };
  ok('village: bell, composter and well are generated', R.name(...L.bell) === 'bell' && R.name(...L.composter) === 'composter' && R.name(nearest[0], L.wellY, nearest[2]) === 'water');
  ok('village: weaponsmith with blast furnace and lava, church with brewing stand', scan('blast_furnace', smithy) === 1 && scan('lava', smithy) === 2 && scan('grindstone', smithy) === 1 && scan('brewing_stand', church) === 1);
  ok('village: terraced farmland with water channels', [0, 1, 2].every(k => R.name(L.farm.x0 + 5, L.farm.terraces[k], L.farm.z0 + k * 5 + 2) === 'water' && R.name(L.farm.x0 + 5, L.farm.terraces[k], L.farm.z0 + k * 5 + 1) === 'farmland_moist'));
  const fresh = new Terrain('849281');
  ok('loot tag lookup works on a terrain that never generated the chunk (worker-built chunks)', lootTagAt(fresh, smithy.x0 + 1, smithy.floorY, smithy.z0 + 5) === 'village_weaponsmith' && lootTagAt(fresh, 0, 200, 0) === null);
  const far = T.locate('village', 400, 400);
  if (far) { const LV = villageLayout(T, far[0], far[2]); ok('procedural village: bell and composter are generated too', R.name(...LV.bell) === 'bell' && R.name(...LV.composter) === 'composter', far); }
  else ok('procedural village located', false);
  // Stronghold.
  const [sx, sz] = T.strongholdPos(), SL = strongholdLayout(T.seed, sx, sz), [px, py, pz] = SL.portal!;
  let frames = 0; for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) if (R.name(px + dx, py, pz + dz) === 'end_portal_frame') frames++;
  ok('stronghold: the portal room is generated away from the start, with all 12 frames', frames === 12 && Math.hypot(px - sx, pz - sz) >= 12 && R.name(sx, SL.pieces[0].box[1] + 3, sz).includes('stone_bricks'), [frames, Math.round(Math.hypot(px - sx, pz - sz))]);
  const lib = SL.pieces.find(p => p.type === 'library')!; let shelves = 0;
  for (let y = lib.box[1]; y <= lib.box[4]; y++) for (let z = lib.box[2]; z <= lib.box[5]; z++) for (let x = lib.box[0]; x <= lib.box[3]; x++) if (R.name(x, y, z) === 'bookshelf') shelves++;
  ok('stronghold: the library is generated with its bookshelves and tagged chests', shelves >= 100 && [...T.structTags.values()].filter(v => v === 'stronghold_library').length >= 2, shelves);
  ok('stronghold: /locate points at the starting staircase', (() => { const p = T.locate('stronghold', 0, 0)!; return p[0] === sx && p[2] === sz; })());
  // Desert pyramid.
  {
    const wp = new Cap(), px0 = 4000, pz0 = 4000, base = T.height(px0, pz0) + 1;
    T.desertPyramid(wp.put, () => { /* foundation not needed */ }, px0, pz0);
    const chests = [...T.structTags].filter(([, v]) => v === 'desert_pyramid').map(([k]) => k.split(',').map(Number) as V3).filter(c => Math.abs(c[0] - px0) <= 1 && Math.abs(c[2] - pz0) <= 1);
    ok('desert pyramid: the four chests of the hidden chamber are tagged desert_pyramid', chests.length === 4 && chests.every(c => wp.name(...c) === 'chest' && c[1] === base - 6), chests);
    ok('desert pyramid: a pressure plate in the middle sits above a 3×3 layer of TNT', wp.name(px0, base - 6, pz0).endsWith('pressure_plate') && wp.count('tnt') === 9 && wp.find('tnt').every(c => c[1] === base - 8 && Math.abs(c[0] - px0) <= 1 && Math.abs(c[2] - pz0) <= 1), [wp.name(px0, base - 6, pz0), wp.count('tnt')]);
    ok('desert pyramid: blue terracotta marks the chamber in the floor above', wp.name(px0, base - 1, pz0) === 'blue_terracotta');
  }
  // New structures in the world.
  const findIn = (seeds: string[], kind: string) => { for (const s of seeds) { const tt = s === '849281' ? T : new Terrain(s), p = locateExtra(tt, kind, 0, 0); if (p) return { tt, p }; } return null; };
  const jt = findIn(['849281', '1', '42', '2024'], 'jungle_temple');
  if (jt) {
    const rr = reader(jt.tt), J = jungleTempleParts({ x: jt.p[0], y: jt.p[1], z: jt.p[2] });
    ok('jungle temple: generated in a jungle biome with levers, pistons, tripwire and dispenser', /jungle/.test(jt.tt.biome(jt.p[0], jt.p[2])) && J.levers.every(c => rr.name(...c) === 'lever') && J.pistons.every(c => rr.name(...c) === 'sticky_piston') && J.hooks.every(c => rr.name(...c) === 'tripwire_hook') && rr.name(...J.dispenser) === 'dispenser', [jt.tt.biome(jt.p[0], jt.p[2]), jt.p]);
    ok('jungle temple: chests and dispenser are tagged for loot', lootTagAt(jt.tt, ...J.chests[0]) === 'jungle_temple' && lootTagAt(jt.tt, ...J.chests[1]) === 'jungle_temple' && lootTagAt(jt.tt, ...J.dispenser) === 'jungle_temple_dispenser');
  } else ok('jungle temple located in one of the test seeds', false);
  const ig = findIn(['849281', '1', '42', '2024'], 'igloo');
  if (ig) {
    const rr = reader(ig.tt), biome = ig.tt.biome(ig.p[0], ig.p[2]);
    ok('igloo: generated in a snowy biome as a snow dome with a bed', ['snowy_plains', 'snowy_taiga', 'snowy_slopes'].includes(biome) && rr.name(ig.p[0], ig.p[1] + 3, ig.p[2]) === 'snow_block' && rr.name(ig.p[0] - 2, ig.p[1], ig.p[2]) === 'bed', [biome, ig.p]);
  } else ok('igloo located in one of the test seeds', false);
  // End ship beside the first end city.
  const E = new Terrain('849281', 'end'), RE = reader(E), at = (o: readonly number[]): V3 => [END_FIRST_SHIP[0] + o[0], END_FIRST_SHIP[1] + o[1], END_FIRST_SHIP[2] + o[2]];
  ok('end ship: generated beside the end city with dragon head, elytra frame and brewing stand', RE.name(...at(END_SHIP.dragonHead)) === 'dragon_head' && RE.name(...at(END_SHIP.elytraFrame)) === 'item_frame' && RE.name(...at(END_SHIP.brewingStand)) === 'brewing_stand' && END_SHIP.chests.every(c => RE.name(...at(c)) === 'chest'));
  ok('end ship: tags resolve to the elytra frame, the potion stand and the treasure table', lootTagAt(E, ...at(END_SHIP.elytraFrame)) === 'end_ship_elytra' && lootTagAt(E, ...at(END_SHIP.brewingStand)) === 'end_ship_brewing' && lootTagAt(E, ...at(END_SHIP.chests[0])) === 'end_city_treasure');
  ok('end ship: /locate endship points at the ship (1,000+ blocks out on the outer islands)', (() => { const p = E.locate('endship', 0, 0)!; return p[0] === END_FIRST_SHIP[0] && Math.abs(p[2] - END_FIRST_SHIP[2]) <= 14 && Math.hypot(p[0], p[2]) >= 1000 && Math.hypot(END_OUTER_ARRIVAL[0], END_OUTER_ARRIVAL[2]) >= 1000; })());
  ok('item frame is a registered wall-mounted block', ID.item_frame !== undefined && BLOCKS[ID.item_frame].shape === 'pane' && !BLOCKS[ID.item_frame].solid);
  // Mansion / ancient city / bastion through the generator.
  const man = locateExtra(T, 'mansion', 0, 0);
  if (man) {
    const rooms = mansionLayout(T.seed, { x: man[0], y: man[1], z: man[2] }), st = rooms.find(r => r.type === 'storage')!;
    let chests = 0; for (let z = st.z0; z <= st.z1; z++) for (let x = st.x0; x <= st.x1; x++) if (R.name(x, st.y, z) === 'chest') chests++;
    ok('woodland mansion: the storage room and the corridor carpet are generated', chests >= 2 && R.name(man[0], man[1], man[2]).endsWith('carpet'), [chests, R.name(man[0], man[1], man[2])]);
  } else ok('mansion located', false);
  const city = locateExtra(T, 'ancient_city', 0, 0);
  if (city) ok('ancient city: frame and laboratory are generated deep underground', R.name(city[0] + ANCIENT_CITY.frame.x0, city[1] + 3, city[2]) === 'reinforced_deepslate' && R.name(city[0] - 5, city[1] + ANCIENT_CITY.lab.floor + 1, city[2] - 3) === 'redstone_wire' && city[1] < 0, city);
  else ok('ancient city located', false);
  const N = new Terrain('849281', 'nether'), bp = locateExtra(N, 'bastion', 0, 0);
  if (bp) {
    const RN = reader(N), kind = bastionType(N.seed, bp[0], bp[2]); RN.name(bp[0], bp[1], bp[2]);
    const table = { treasure: 'bastion_treasure', hoglin_stable: 'bastion_hoglin_stable', bridge: 'bastion_bridge', housing: 'bastion_other' }[kind];
    for (const [dx, dz] of [[-12, -12], [12, -12], [-12, 12], [12, 12]]) RN.name(bp[0] + dx, bp[1], bp[2] + dz);
    ok('bastion remnant: generated in the nether with chests on its variant table (' + kind + ')', [...N.structTags.values()].filter(v => v === table).length >= 2 && [...N.structTags.values()].every(v => !v.startsWith('bastion_') || v === table), kind);
  } else ok('bastion located', false);
}

// ======================================================================================================================
section('12. Engine glue — chests, brewing stands, dispensers and item frames receive their contents');
{
  const E = new Terrain('849281', 'end'), at = (o: readonly number[]): V3 => [END_FIRST_SHIP[0] + o[0], END_FIRST_SHIP[1] + o[1], END_FIRST_SHIP[2] + o[2]];
  const mock = (terrain: Terrain, dimension: string): any => ({
    terrain, dimension, containers: {} as Record<string, any[]>, edits: new Map<string, number>(), hotbar: Array(9).fill(null), selected: 0, meta: { mode: 'survival', structures: true }, audio: null, handDip: 0,
    got: [] as [string, number][], addItem(n: string, c: number) { this.got.push([n, c]); return true; }, consumeSelected() { this.hotbar[this.selected] = null; },
    getBlock: () => 0,
    seedNatural(x: number, y: number, z: number) { SV.seedNatural(this, x, y, z); }, useItemFrame(x: number, y: number, z: number) { return SV.useItemFrame(this, x, y, z); },
    lootFor(x: number, y: number, z: number) { return this.edits.has(K(x, y, z)) ? Array(27).fill(null) : SV.roomLootFor(this, x, y, z) ?? Array(27).fill(null); },
  });
  const e = mock(E, 'end'), frame = at(END_SHIP.elytraFrame), stand = at(END_SHIP.brewingStand), chest = at(END_SHIP.chests[0]);
  e.seedNatural(...frame);
  ok('item frame on the end ship is seeded with the elytra', JSON.stringify(e.containers[K(...frame)]) === JSON.stringify([{ name: 'elytra', count: 1 }]), e.containers[K(...frame)]);
  ok('right-clicking the frame hands over the elytra exactly once', e.useItemFrame(...frame) === true && JSON.stringify(e.got) === '[["elytra",1]]' && e.containers[K(...frame)][0] === null && (e.seedNatural(...frame), e.containers[K(...frame)][0] === null));
  e.hotbar[0] = { name: 'diamond', count: 3 };
  ok('an empty frame accepts the held item', e.useItemFrame(...frame) && e.containers[K(...frame)][0]?.name === 'diamond' && e.containers[K(...frame)][0]?.count === 1);
  e.seedNatural(...stand);
  ok('brewing stand on the end ship is seeded with two Instant Health II potions', e.containers[K(...stand)]?.length === 5 && e.containers[K(...stand)].filter((x: any) => x?.name === 'potion_healing_strong').length === 2 && e.containers[K(...stand)].filter(Boolean).length === 2, e.containers[K(...stand)]);
  const loot = e.lootFor(...chest).filter(Boolean), allowed = new Set([...ROOM_LOOT.end_city_treasure.items.map(i => i[0]), ...ROOM_LOOT.end_city_treasure.always!.map(i => i[0])]);
  ok('ship chest rolls end_city_treasure (no elytra in the chest any more)', loot.length >= 2 && loot.every((x: any) => allowed.has(x.name)) && !loot.some((x: any) => x.name === 'elytra'), loot);
  ok('the same chest always rolls the same loot', JSON.stringify(e.lootFor(...chest)) === JSON.stringify(e.lootFor(...chest)));
  const e2 = mock(E, 'end'); e2.edits.set(K(...frame), 0); e2.seedNatural(...frame);
  ok('player-edited positions are never re-seeded (no duplication)', e2.containers[K(...frame)] === undefined && e2.lootFor(...frame).every((x: any) => x === null));
  // Overworld: stronghold library chest and jungle temple dispenser.
  const T = new Terrain('849281'), [sx, sz] = T.strongholdPos(), SL = strongholdLayout(T.seed, sx, sz), lib = SL.pieces.find(p => p.type === 'library')!, o = mock(T, 'overworld');
  T.generate(Math.floor((lib.box[0] + lib.box[3]) / 32), Math.floor((lib.box[2] + lib.box[5]) / 32));
  for (let cx = lib.box[0] >> 4; cx <= lib.box[3] >> 4; cx++) for (let cz = lib.box[2] >> 4; cz <= lib.box[5] >> 4; cz++) T.generate(cx, cz);
  const libChest = [...T.structTags].find(([, v]) => v === 'stronghold_library')![0].split(',').map(Number) as V3, books = o.lootFor(...libChest).filter(Boolean);
  ok('stronghold library chest rolls only library loot (books, paper, maps, compasses)', books.length >= 2 && books.every((x: any) => ['book', 'paper', 'map', 'compass', 'enchanted_book', 'eye_armor_trim_smithing_template'].includes(x.name)), books);
  ok('enchanted books come out enchanted', Array.from({ length: 40 }, (_, i) => SV.rollRoom(o, 'stronghold_library', i, 20, 7)).flat().filter((x: any) => x?.name === 'enchanted_book').every((x: any) => x.ench && Object.keys(x.ench).length === 1));
  const d = SV.rollRoom(o, 'jungle_temple_dispenser', 5, 60, 5, 9);
  ok('jungle temple dispenser inventory: nine slots holding arrows', d.length === 9 && d.filter(Boolean).length >= 1 && d.filter(Boolean).every((x: any) => x.name === 'arrow'));
}

// ======================================================================================================================
section('13. Vanilla 1.21 parity — generation order, footprint masking, bedrock, rivers, Nether and End dimensions');
{
  const T = new Terrain('849281'), R = reader(T);
  // 13a. Spawn is seed-determined, there is no starter cabin and no artificial levelling around the origin.
  const sp = T.spawnPoint();
  ok('world spawn is a dry, non-ocean column found by spiral search (no hard-coded spawn)', sp[1] > SEA_LEVEL_BLOCK && !T.biome(sp[0], sp[2]).endsWith('ocean'), sp);
  let planks = 0; for (let y = 60; y < 110; y++) for (let z = -22; z <= -12; z++) for (let x = -27; x <= -17; x++) if (R.name(x, y, z).endsWith('_planks')) planks++;
  ok('no starter cabin at (-24, -19)', planks === 0, planks);
  const relief = (() => { let lo = Infinity, hi = -Infinity; for (let z = -56; z <= 56; z += 8) for (let x = -56; x <= 56; x += 8) { const h = T.height(x, z); lo = Math.min(lo, h); hi = Math.max(hi, h); } return hi - lo; })();
  ok('terrain around the origin is natural multi-noise relief (the 58-block spawn flattening is gone)', relief >= 6, relief);

  // 13b. Structure footprint masking: no leaves / huge mushroom / bamboo inside any village footprint + 2-block buffer.
  const v = T.locate('village', 0, 0)!;
  const variant = villageVariantFor(T.biome(v[0], v[2])), L = grandVillageLayout(T, v[0], v[2], variant);
  const boxes: [number, number, number, number, string][] = L.core.buildings.map(b => [b.x0, b.z0, b.x1, b.z1, b.kind] as [number, number, number, number, string]);
  for (const p of L.pieces) { const [W, Ln] = rotSize(p.def, p.rot); boxes.push([p.bx, p.bz, p.bx + W - 1, p.bz + Ln - 1, p.def.kind]); }
  let leafHits = 0, checkedFootprints = 0;
  for (const [x0, z0, x1, z1] of boxes) {
    checkedFootprints++;
    for (let z = z0 - FOOTPRINT_BUFFER; z <= z1 + FOOTPRINT_BUFFER; z++) for (let x = x0 - FOOTPRINT_BUFFER; x <= x1 + FOOTPRINT_BUFFER; x++) {
      const g = T.height(x, z);
      for (let y = Math.max(SEA_LEVEL_BLOCK, g - 2); y <= g + 24; y++) { const n = R.name(x, y, z); if (n.endsWith('_leaves') || n === 'red_mushroom_block' || n === 'brown_mushroom_block' || n === 'mushroom_stem' || n === 'bamboo') leafHits++; }
    }
  }
  ok(`footprint masking: zero tree / mushroom / bamboo blocks inside ${checkedFootprints} village footprints (+${FOOTPRINT_BUFFER} buffer)`, checkedFootprints >= 8 && leafHits === 0, [checkedFootprints, leafHits]);
  const fp = T.structureFootprints(v[0] & ~15, v[2] & ~15);
  ok('structureFootprints() exposes the village pieces (houses, streets, farms, well) for the vegetation pass', fp.length >= 10 && fp.some(f => f.kind === 'village_well') && fp.some(f => f.kind.startsWith('village_')), fp.length);
  // 13c. AABB non-overlap of every village piece (houses, job sites, farms, pens, streets never intersect each other).
  const bld = boxes.filter(b => b[4] !== 'street' && b[4] !== 'lamp');
  let overlaps = 0;
  for (let i = 0; i < bld.length; i++) for (let j = i + 1; j < bld.length; j++) {
    const a = bld[i], b = bld[j];
    if (a[0] <= b[2] && b[0] <= a[2] && a[1] <= b[3] && b[1] <= a[3]) overlaps++;
  }
  ok(`village AABB collision: ${bld.length} buildings/farms/pens, zero overlaps`, bld.length >= 8 && overlaps === 0, overlaps);
  // Streets never cut through a building either.
  let streetHits = 0;
  for (const st of boxes.filter(b => b[4] === 'street')) for (const b of bld) if (st[0] <= b[2] && b[0] <= st[2] && st[1] <= b[3] && b[1] <= st[3]) streetHits++;
  ok('village streets never overlap a building footprint', streetHits === 0, streetHits);

  // 13d. Bedrock: five-layer random gradient Y -64‥-60, solid at -64, nothing at -59.
  const layer = (y: number) => { let n = 0; for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) if (R.name(x, y, z) === 'bedrock') n++; return n; };
  const b64 = layer(-64), b63 = layer(-63), b62 = layer(-62), b61 = layer(-61), b60 = layer(-60), b59 = layer(-59);
  ok('overworld bedrock: Y -64 solid, -63 > -62 > -61 > -60 thinning gradient, none at -59', b64 === 256 && b63 > b62 && b62 > b61 && b61 > b60 && b60 > 0 && b59 === 0, [b64, b63, b62, b61, b60, b59]);

  // 13e. Rivers: continuous water at the sea level block (Y 62), air above, bed carved to Y 55‥59.
  const riv = T.locate('river', 0, 0);
  if (riv) {
    let cols = 0, good = 0, bedOk = 0, floating = 0;
    for (let dz = -24; dz <= 24; dz += 2) for (let dx = -24; dx <= 24; dx += 2) {
      const x = riv[0] + dx, z = riv[2] + dz;
      if (T.biome(x, z) !== 'river') continue;
      const h = T.height(x, z); cols++;
      if (R.name(x, SEA_LEVEL_BLOCK, z) === 'water' && R.name(x, SEA_LEVEL_BLOCK + 1, z) === 'air') good++;
      if (h >= 54 && h <= 60) bedOk++;
      for (let y = SEA_LEVEL_BLOCK + 1; y < SEA_LEVEL_BLOCK + 40; y++) if (R.name(x, y, z) === 'water') floating++;
    }
    ok(`river: water surface at Y ${SEA_LEVEL_BLOCK} with air above in ≥ 80 % of ${cols} river columns, no water above sea level`, cols >= 20 && good >= cols * 0.8 && floating === 0, [cols, good, floating]);
    ok('river bed is carved down to roughly Y 55‥59 (sand / gravel / clay bottom)', bedOk >= cols * 0.6 && (() => { for (let dz = -24; dz <= 24; dz++) for (let dx = -24; dx <= 24; dx++) { const x = riv[0] + dx, z = riv[2] + dz; if (T.biome(x, z) === 'river') { const n = R.name(x, T.height(x, z), z); if (['sand', 'gravel', 'clay'].includes(n)) return true; } } return false; })(), [cols, bedOk]);
  } else ok('river located for the water-level test', false);

  // 13f. Nether: 0‥128 build height, lava sea surface at Y 31, five-layer bedrock gradients on floor and roof.
  const N = new Terrain('849281', 'nether'), RN = reader(N);
  const nl = (y: number, cx = 0, cz = 0) => { let n = 0; for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) if (RN.name(cx * 16 + x, y, cz * 16 + z) === 'bedrock') n++; return n; };
  ok('nether bedrock floor: Y 0 solid, 1‥4 thinning, none at 5', nl(0) === 256 && nl(1) > nl(2) && nl(2) > nl(3) && nl(3) > nl(4) && nl(4) > 0 && nl(5) === 0, [nl(0), nl(1), nl(2), nl(3), nl(4), nl(5)]);
  ok(`nether bedrock roof: Y ${NETHER_HEIGHT - 1} solid, 126‥123 thinning, nothing above the roof`, nl(127) === 256 && nl(126) > nl(125) && nl(125) > nl(124) && nl(124) > nl(123) && nl(123) > 0 && nl(122) === 0 && (() => { for (let y = 128; y < 140; y++) for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) if (RN.name(x, y, z) !== 'air') return false; return true; })(), [nl(127), nl(126), nl(125), nl(124), nl(123)]);
  let lavaAtSea = 0, lavaSeaCols = 0, perchedPools = 0, shore = 0;
  for (let cz = 0; cz < 6; cz++) for (let cx = 0; cx < 6; cx++) for (let z = 0; z < 16; z += 4) for (let x = 0; x < 16; x += 4) {
    const wx = cx * 16 + x + 200, wz = cz * 16 + z + 200;
    if (N.height(wx, wz) === NETHER_LAVA) {
      const top = RN.name(wx, NETHER_LAVA, wz);
      if (top === 'lava') { lavaSeaCols++; if (RN.name(wx, NETHER_LAVA + 1, wz) === 'air') lavaAtSea++; } else shore++;   // netherrack shoreline exactly at Y 31
    }
    // A lava *sea* above Y 31 would show as a ≥ 3-deep lava column; lavafalls and structure cauldrons are single blocks.
    let run = 0; for (let y = NETHER_LAVA + 1; y < 100; y++) { if (RN.name(wx, y, wz) === 'lava') { if (++run === 3) perchedPools++; } else run = 0; }
  }
  ok(`nether lava sea surface is exactly Y ${NETHER_LAVA} (${lavaSeaCols} sea + ${shore} shore columns sampled), no perched lava seas`, lavaSeaCols > 0 && lavaAtSea === lavaSeaCols && perchedPools === 0, [lavaSeaCols, lavaAtSea, perchedPools]);
  const prof: number[] = []; for (let y0 = 0; y0 < 128; y0 += 16) { let sld = 0; for (let y = y0; y < y0 + 16; y++) for (let z = 0; z < 16; z += 2) for (let x = 0; x < 16; x += 2) { const n = RN.name(80 + x, y, 80 + z); if (n !== 'air' && n !== 'lava') sld++; } prof.push(sld / 1024); }
  ok('nether is a 3-D multi-layer cavern (open space exists both below and above a mid-height shelf)', prof.some((f, i) => i > 0 && i < 7 && f < 0.7 && prof.slice(i + 1).some(g => g > f + 0.15)), prof.map(f => f.toFixed(2)));
  const ns = N.spawnPoint();
  ok('nether spawn stands on solid ground above the lava sea with head room', ns[1] > NETHER_LAVA && RN.name(ns[0], ns[1] - 1, ns[2]) !== 'air' && RN.name(ns[0], ns[1], ns[2]) === 'air' && RN.name(ns[0], ns[1] + 1, ns[2]) === 'air', ns);

  // 13g. The End: 10 obsidian pillars on the radius-42 ring, heights 76‥103, two caged; gateway at radius 96; outer islands ≥ 1,000 blocks.
  const P = endPillars();
  ok('end pillars: exactly 10, radius 42, heights 76‥103 in steps of 3, radius 2‥5, two caged', P.length === 10 && P.every(p => Math.abs(Math.hypot(p.x, p.z) - END_PILLAR_RADIUS) <= 1.5) && P.map(p => p.h).join() === '76,79,82,85,88,91,94,97,100,103' && P.every(p => p.r >= 2 && p.r <= 5) && P.filter(p => p.caged).length === 2);
  const E = new Terrain('849281', 'end'), RE = reader(E);
  const tall = P[9], short = P[0];
  ok('tallest pillar is obsidian up to Y 103 with a bedrock cap; caged pillar wears iron bars', RE.name(tall.x, tall.h, tall.z) === 'obsidian' && RE.name(tall.x, tall.h + 1, tall.z) === 'bedrock' && RE.name(tall.x, tall.h + 2, tall.z) === 'air' && RE.name(short.x + 2, short.h + 2, short.z) === 'iron_bars');
  ok('end gateway frame sits on the radius-96 ring at Y 75', Math.hypot(END_GATEWAY_MAIN[0], END_GATEWAY_MAIN[2]) === 96 && END_GATEWAY_MAIN[1] === 75 && RE.name(END_GATEWAY_MAIN[0], END_GATEWAY_MAIN[1] + 1, END_GATEWAY_MAIN[2]) === 'bedrock');
  ok('outer-island arrival is ≥ 1,000 blocks out and lands on end stone', Math.hypot(END_OUTER_ARRIVAL[0], END_OUTER_ARRIVAL[2]) >= 1000 && RE.name(END_OUTER_ARRIVAL[0], END_OUTER_ARRIVAL[1] - 1, END_OUTER_ARRIVAL[2]) === 'end_stone');
  ok('void gap: no terrain between radius 120 and 1,000', [150, 300, 500, 700, 900].every(r => E.height(r, 0) < 0 && E.height(0, r) < 0 && E.height(-r, r) < 0));

  // 13h. Pillager outpost: wiki watchtower (dark-oak posts, birch floors, stair eaves, 4 levels, ~22 tall) with camp pieces.
  const op = (() => { for (const seed of ['849281', '11', '4242', '777']) { const tt = seed === '849281' ? T : new Terrain(seed), q = locateExtra(tt, 'outpost', 0, 0); if (q) return { tt, q }; } return null; })();
  if (op) {
    const { tt, q } = op, RO = tt === T ? R : reader(tt), [ox0, oy0, oz0] = q, base = tt.height(ox0, oz0) + 1;
    const col = (x: number, z: number, name: string, y0: number, y1: number) => { let n = 0; for (let yy = y0; yy <= y1; yy++) if (RO.name(x, yy, z) === name) n++; return n; };
    ok('outpost: dark-oak log corner posts run the full ~22-block height', col(ox0 + 3, oz0 + 3, 'dark_oak_log', base, base + 17) >= 17 && col(ox0 + 4, oz0 + 4, 'dark_oak_log', base + 19, base + 21) === 3, [oy0, base]);
    ok('outpost: four birch floors (ground, two landings, top room) and cobblestone-stair eaves under the overhang', RO.name(ox0 + 1, base, oz0 + 1) === 'birch_planks' && RO.name(ox0 + 1, base + 9, oz0 + 1) === 'birch_planks' && RO.name(ox0 + 1, base + 14, oz0 + 1) === 'birch_planks' && RO.name(ox0 + 1, base + 18, oz0 + 1) === 'birch_planks' && RO.name(ox0 + 4, base + 17, oz0) === 'cobblestone_stairs');
    ok('outpost: ladder shaft, top-floor chest, ominous banner and the iron-bar cage', col(ox0, oz0 + 2, 'ladder', base, base + 18) >= 15 && RO.name(ox0 - 3, base + 19, oz0 - 3) === 'chest' && RO.name(ox0, base + 20, oz0 - 5) === 'white_banner' && (() => { const g = tt.height(ox0 + 7, oz0 - 2) + 1; return RO.name(ox0 + 8, g, oz0 - 2) === 'iron_bars' && RO.name(ox0 + 8, g + 1, oz0 - 1) === 'dark_oak_log'; })());
    ok('outpost: beardifier foundation — no air directly under the tower base', (() => { for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) if (RO.name(ox0 + dx, base - 1, oz0 + dz) === 'air') return false; return true; })());
  } else ok('pillager outpost located', false);
}

// ======================================================================================================================
section('14. Vanilla 1.21 exact parity — Mineshaft, Monster Room (Spawner), Zombie Village, Stronghold & Igloo');
{
  // 14a. Mineshaft: 10×10 Dirt Room + recursive corridors (5-block arch spacing), 5×5 crossings (1–2 storeys), diagonal stairs, cave spider spawner, normal vs mesa variants
  const mSeeds = [1, 42, 849281, 2024];
  const mLayouts = mSeeds.map(s => mineshaftLayout(s, 200, 28, -300, 'normal'));
  ok('mineshaft: starts with a 10×10 dirt room (parlor) and grows a multi-piece branching network', mLayouts.every(L => L.pieces[0].type === 'room' && L.pieces[0].box[3] - L.pieces[0].box[0] + 1 === 10 && L.pieces[0].box[5] - L.pieces[0].box[2] + 1 === 10 && L.pieces.length >= 12), mLayouts.map(L => L.pieces.length));
  ok('mineshaft: layouts differ between seeds and include corridors, 5×5 crossings and diagonal staircases', JSON.stringify(mLayouts[0].pieces.map(p => p.type)) !== JSON.stringify(mLayouts[1].pieces.map(p => p.type)) && ['corridor', 'crossing', 'stairs'].every(k => mLayouts.some(L => L.pieces.some(p => p.type === k))));
  ok('mineshaft: pieces never overlap (strict AABB collision check)', mLayouts.every(L => L.pieces.every((a, i) => L.pieces.every((b, j) => i >= j || !(a.box[0] <= b.box[3] && a.box[3] >= b.box[0] && a.box[1] <= b.box[4] && a.box[4] >= b.box[1] && a.box[2] <= b.box[5] && a.box[5] >= b.box[2])))));
  const tm = mk(849281), wm = new Cap(), ML = buildMineshaft(tm, wm.put, 200, 28, -300, 'normal');
  ok('mineshaft (normal): oak planks/fences, rails, 39+ cobwebs, cave spider spawner and abandoned_mineshaft chests', wm.count('oak_planks') > 150 && wm.count('oak_fence') >= 16 && wm.count('rail') >= 10 && wm.count('cobweb') >= 39 && ML.spawners.every(s => wm.name(...s) === 'spawner') && tagsOf(tm, 'abandoned_mineshaft').length >= 2, [wm.count('cobweb'), ML.spawners.length]);
  const tmMesa = mk(849281), wmMesa = new Cap();
  buildMineshaft(tmMesa, wmMesa.put, 200, 62, -300, 'mesa');
  ok('mineshaft (badlands / mesa): dark oak planks, fences and logs with higher rail density', wmMesa.count('dark_oak_planks') > 150 && wmMesa.count('dark_oak_fence') >= 16 && wmMesa.count('oak_planks') === 0 && mineshaftVariantFor('badlands') === 'mesa');

  // 14b. Monster Room (Dungeon / Spawner room): 5×5, 5×7, 7×5, 7×7 interior sizes, 75% mossy cobblestone floor, spawner species & simple_dungeon loot
  const T = new Terrain('849281');
  const dRooms: [number, number, number, number, number][] = [];
  for (let cz = -20; cz <= 20; cz++) for (let cx = -20; cx <= 20; cx++) { const r = T.dungeonAt(cx, cz); if (r) dRooms.push(r); }
  const sizes = new Set(dRooms.map(r => `${r[3] * 2 + 1}x${r[4] * 2 + 1}`));
  ok('monster room (spawner): all four vanilla interior footprints (5×5, 5×7, 7×5, 7×7) generate across chunks', ['5x5', '5x7', '7x5', '7x7'].every(s => sizes.has(s)), [...sizes]);
  const wd = new Cap();
  T.dungeon(wd.put, [100, 20, 100, 3, 3]); // 7×7 interior (9×6×9 outer)
  const mossyFloor = wd.count('mossy_cobblestone', [96, 20, 96, 104, 20, 104]), cobFloor = wd.count('cobblestone', [96, 20, 96, 104, 20, 104]);
  ok('monster room (spawner): 75 % mossy cobblestone / 25 % cobblestone floor, cobblestone walls, central spawner and 1–2 simple_dungeon chests', mossyFloor > cobFloor && mossyFloor + cobFloor === 81 && wd.name(100, 21, 100) === 'spawner' && wd.count('chest') >= 1 && wd.count('chest') <= 2 && T.structTags.get('97,21,100') === 'simple_dungeon', [mossyFloor, cobFloor]);
  const spSpecies = new Set(dRooms.map(r => T.dungeonSpawnerSpecies(r[0], r[1] + 1, r[2])));
  ok('monster room (spawner): spawner mob species roll zombie (50%), skeleton (25%) and spider (25%)', ['zombie', 'skeleton', 'spider'].every(s => spSpecies.has(s as any)), [...spSpecies]);

  // 14c. Zombie (Abandoned) Village: 2% natural chance, all doors & torches/lanterns missing, mossy cobblestone, cobwebs, brown stained glass across all 5 biome variants
  let zvCount = 0;
  for (let i = 0; i < 2000; i++) if (isZombieVillage(849281, i * 112, i * 73)) zvCount++;
  ok('zombie village: ~2% of villages naturally generate as abandoned zombie villages', zvCount >= 15 && zvCount <= 75, zvCount);
  const tz = mk(321, () => 70), wz = new Cap();
  const ZVL = grandVillage(tz, wz.put, 400, 400, 'plains', undefined, undefined, true);
  ok('zombie village: zero doors, zero torches and zero lanterns in the entire village', ZVL.abandoned && wz.count('oak_door') === 0 && wz.count('torch') === 0 && wz.count('lantern') === 0, [wz.count('oak_door'), wz.count('torch'), wz.count('lantern')]);
  ok('zombie village: cobblestone is weathered to mossy cobblestone, wood/stairs/slabs decay into cobwebs, and windows use brown stained glass', wz.count('mossy_cobblestone') > wz.count('cobblestone') && wz.count('cobweb') >= 20 && wz.count('brown_stained_glass') >= 10 && wz.count('yellow_stained_glass') >= 4, [wz.count('mossy_cobblestone'), wz.count('cobblestone'), wz.count('cobweb'), wz.count('brown_stained_glass')]);
  const zvBiomesOk = (['plains', 'desert', 'savanna', 'snowy', 'taiga'] as const).every((v, idx) => {
    const tzb = mk(500 + idx, () => 70), wzb = new Cap();
    const lb = grandVillage(tzb, wzb.put, 400, 400, v, undefined, undefined, true);
    return lb.abandoned && wzb.count('torch') === 0 && wzb.count('lantern') === 0 && wzb.count('cobweb') >= 10;
  });
  ok('zombie village: all 5 biome variants (plains, desert, savanna, snowy, taiga) generate abandoned decay with cobwebs and zero torches/lanterns', zvBiomesOk);

  // 14d. Stronghold: five-way crossing, single/duplex library (233 bookshelves in duplex), 7 stone brick slabs on loot altar, 4 entry types (including iron door + button) and fountain/storeroom crossings
  const shAll = SH_SEEDS.map(s => strongholdLayout(s, 1000, -600));
  ok('stronghold: includes five_way_crossing and 4 entry types (open, oak door, iron grate, iron door with button)', shAll.some(L => L.pieces.some(p => p.type === 'five_way_crossing')) && shAll.some(L => L.pieces.some(p => p.door === 3)));
  const shBuilt = SH_SEEDS.map(s => { const t = mk(s), w = new Cap(); return { s, t, w, L: buildStronghold(t, w.put, 1000, -600) }; });
  const tallLibPick = shBuilt.map(x => ({ x, p: x.L.pieces.find(p => p.type === 'library' && p.tall !== false) })).find(e => e.p)!;
  const altarPick = shBuilt.map(x => ({ x, p: x.L.pieces.find(p => p.type === 'chest_corridor') })).find(e => e.p)!;
  ok('stronghold duplex library: contains exactly 233 bookshelves, oak fence railings + chandelier, 5 ladder rungs and 2 chests', tallLibPick.x.w.count('bookshelf', tallLibPick.p!.box) === 233 && tallLibPick.x.w.count('ladder', tallLibPick.p!.box) === 5 && tallLibPick.x.w.count('chest', tallLibPick.p!.box) === 2, tallLibPick.x.w.count('bookshelf', tallLibPick.p!.box));
  ok('stronghold loot altar (chest_corridor): contains 1 chest on a stone brick altar surrounded by 7 stone_brick_slab blocks', altarPick.x.w.count('chest', altarPick.p!.box) === 1 && altarPick.x.w.count('stone_brick_slab', altarPick.p!.box) === 7, altarPick.x.w.count('stone_brick_slab', altarPick.p!.box));

  // 14e. Igloo: variable shaft depth (2..9 middle pieces → depth 14..35), spruce stairs/slab worktable, potted cactus, polished andesite under red carpet, oak sign tagged igloo_sign
  const shaftLens = new Set<number>();
  for (let i = 0; i < 120; i++) shaftLens.add(iglooShaftSections(55, i * 31, i * 47));
  ok('igloo: middle shaft varies across all 8 vanilla section counts (2..9 sections, depth 14..35 blocks)', shaftLens.size >= 7 && Math.min(...shaftLens) === 2 && Math.max(...shaftLens) === 9, [...shaftLens].sort((a, b) => a - b));
  const tig = mk(55, () => 79), wig = new Cap(), Pig = { x: -789, y: 80, z: 170 }, Gig = iglooParts(55, Pig);
  igloo(tig, wig.put, Pig);
  ok('igloo basement: polished andesite under red carpet, oak sign at Gig.sign tagged igloo_sign, spruce stairs/slab table and potted cactus', wig.name(...Gig.polishedAndesite) === 'polished_andesite' && wig.name(Gig.polishedAndesite[0], Gig.polishedAndesite[1] + 1, Gig.polishedAndesite[2]) === 'red_carpet' && wig.name(...Gig.sign) === 'oak_sign' && tig.structTags.get(K(...Gig.sign)) === 'igloo_sign' && wig.count('spruce_stairs') === 2 && wig.count('spruce_slab') === 1 && wig.name(...Gig.pottedCactus) === 'cactus');
}

// ======================================================================================================================
section('15. Multi-template & Jigsaw verification for Trial Chambers, Ruined Portals, Trail Ruins, Ancient City, Jungle Temple & Ocean Ruins');
{

  // 14a. Trial Chambers: multi-template rooms, multi-style corridors, oxidized/weathered/exposed/waxed copper processor, dispensers, barrels, beds
  const tcTemplates = new Set<string>(), tcCorrStyles = new Set<string>();
  for (let s = 1; s <= 12; s++) {
    const L = chamberLayout(s * 977, s * 160, -30, 0);
    for (const r of L.rooms) { tcTemplates.add(r.template); tcCorrStyles.add(r.corridorStyle); }
  }
  ok('trial chambers: at least 10 distinct room templates and all 4 corridor styles occur across sites', tcTemplates.size >= 10 && tcCorrStyles.size === 4, [[...tcTemplates], [...tcCorrStyles]]);
  {
    const T = new Terrain('849281'), w = new Cap(), P = { kind: 'trial_chambers' as const, x: 0, y: -30, z: 0 };
    trialChambers(T, w.put, P);
    const coppers = ['copper_block', 'exposed_copper', 'weathered_copper', 'oxidized_copper', 'cut_copper', 'exposed_cut_copper', 'weathered_cut_copper', 'oxidized_cut_copper', 'chiseled_copper', 'copper_grate', 'copper_bulb_lit'];
    ok('trial chambers: full oxidation spectrum of copper blocks, cut copper, chiseled copper, grates and lit bulbs', coppers.every(n => w.count(n) > 0), coppers.map(n => [n, w.count(n)]));
    ok('trial chambers: trial spawners, normal & ominous vaults, dispensers, barrels, supply chests, decorated pots and respawn beds',
      w.count('trial_spawner') >= 6 && w.count('vault') >= 2 && w.count('ominous_vault') === 1 && w.count('dispenser') >= 3 && w.count('barrel') >= 2 && w.count('chest') >= 2 && w.count('decorated_pot') >= 4 && w.count('bed') >= 2);
    ok('trial chambers: chests, barrels and dispensers are tagged with their room loot tables',
      tagsOf(T, 'trial_chambers_supply').length >= 2 && tagsOf(T, 'trial_chambers_corridor').length >= 2 && tagsOf(T, 'trial_chambers_dispenser').length >= 3);
  }

  // 14b. Ruined Portal: 10 standard + 3 giant templates, 4 placement categories, Overworld stone-brick vs Nether blackstone processor
  {
    const seenVariants = new Set<string>(), seenPlacements = new Set<string>();
    for (let i = 0; i < 400; i++) {
      const y = i % 5 === 0 ? 52 : 70, dim = i % 7 === 0 ? 'nether' : 'overworld';
      const pl = ruinedPortalPlan(849281, i * 137, y, i * 251, dim);
      seenVariants.add(pl.variant); seenPlacements.add(pl.placement);
    }
    ok(`ruined portal: all ${RUINED_PORTAL_VARIANTS.length} templates (portal_1..10 + giant_portal_1..3) and all 4 placements occur`,
      seenVariants.size === 13 && seenPlacements.size === 4, [[...seenVariants].length, [...seenPlacements]]);
    const TO = new Terrain('849281', 'overworld'), wO = new Cap();
    ruinedPortal(TO, wO.put, { kind: 'ruined_portal', x: 100, y: 70, z: 100 });
    const TN = new Terrain('849281', 'nether'), wN = new Cap();
    ruinedPortal(TN, wN.put, { kind: 'ruined_portal', x: 100, y: 45, z: 100 });
    ok('ruined portal: Overworld uses stone bricks (plain/mossy/cracked/chiseled) while Nether uses blackstone + gilded blackstone',
      wO.count('stone_bricks') + wO.count('mossy_stone_bricks') + wO.count('cracked_stone_bricks') >= 8 &&
      wN.count('polished_blackstone_bricks') + wN.count('blackstone') + wN.count('gilded_blackstone') >= 8);
    ok('ruined portal: chest is tagged ruined_portal and gold block + crying obsidian + netherrack/magma spread are placed',
      tagsOf(TO, 'ruined_portal').length === 1 && wO.count('gold_block') >= 1 && wO.count('obsidian') + wO.count('crying_obsidian') >= 6 && wO.count('netherrack') + wO.count('magma_block') >= 8);
  }

  // 14c. Trail Ruins: Jigsaw road + guild buildings (cartographer, weaver, smithy, mason, hall) + sunken tower + terracotta mosaics
  {
    const kindsSeen = new Set<string>();
    for (let s = 1; s <= 8; s++) {
      const L = trailRuinsLayout(s * 131, s * 100, 72, 0);
      ok(`trail ruins (seed ${s}): Jigsaw pieces never overlap and stay inside bounds`,
        L.pieces.length >= 6 && L.pieces.every((a: any, i: number) => L.pieces.every((b: any, j: number) => i >= j || !boxesOverlap(a.box, b.box))), L.pieces.length);
      for (const p of L.pieces) kindsSeen.add(p.def.kind);
    }
    ok('trail ruins: Jigsaw generates roads, halls, cartographer, weaver, smithy, mason and one-room pieces',
      ['road', 'hall', 'cartographer', 'weaver', 'smithy', 'mason'].every(k => kindsSeen.has(k)), [...kindsSeen]);
    const T = new Terrain('849281'), w = new Cap();
    trailRuins(T, w.put, { kind: 'trail_ruins', x: 200, y: 72, z: 200 });
    ok('trail ruins: mud bricks, packed mud, coloured terracotta, cobblestones, gravel/dirt fill and suspicious gravel',
      w.count('mud_bricks') >= 40 && w.count('packed_mud') >= 10 && w.count('suspicious_gravel') >= 8 && w.count('gravel') >= 40);
  }

  // 14d. Ancient City: city_center_1..3 variants, soul fire braziers, cross-walkways, and Jigsaw peripheral modules (sauna, camps, tall ruins, sculk garden, shrine)
  {
    const centers = new Set<string>(), mods = new Set<string>();
    for (let s = 1; s <= 15; s++) {
      const pl = ancientCityPlan(s * 97, { x: s * 240, y: -51, z: 0 });
      centers.add(pl.centerVariant);
      for (const m of pl.modules) mods.add(m.kind);
    }
    ok('ancient city: all 3 city_center variants and all 7 peripheral module types occur across sites',
      centers.size === 3 && mods.size === 7, [[...centers], [...mods]]);
    const t = mk(9), w = new Cap();
    ancientCity(t, w.put, { x: 0, y: -51, z: 0 });
    ok('ancient city: chiseled deepslate Warden crest, soul fire braziers, wool sound-insulated cross-walkways and peripheral structures',
      w.count('chiseled_deepslate') >= 12 && w.count('soul_fire') >= 4 && w.count('gray_wool') >= 140);
  }

  // 14e. Jungle Temple: chiseled stone brick glyphs, entrance stairway, main-floor lightwell and beardifier foundation
  {
    const P = { x: 0, y: 70, z: 0 }, t = mk(3, () => 66), w = new Cap();
    jungleTemple(t, w.put, P);
    ok('jungle temple: chiseled stone brick relief motifs on exterior/interior walls and entrance stairs',
      w.count('chiseled_stone_bricks') >= 14 && w.count('cobblestone_stairs') >= 20);
    ok('jungle temple: beardifier foundation fills down to uneven terrain below the basement',
      w.name(0, 60, 0).includes('cobblestone'));
  }

  // 14f. Ocean Ruins: warm sandstone cluster vs cold stone-brick/obsidian cluster, large ruin + 3..5 satellite ruins, tagged chests & suspicious blocks
  {
    const T = new Terrain('849281');
    const warmSite = { kind: 'ocean_ruin' as const, x: 50, y: 46, z: 50 };
    const coldSite = { kind: 'ocean_ruin' as const, x: -400, y: 44, z: -400 };
    // Force warm vs cold check across sites
    let foundWarm = false, foundCold = false;
    for (let i = 0; i < 40 && (!foundWarm || !foundCold); i++) {
      const p = { kind: 'ocean_ruin' as const, x: i * 97, y: 45, z: i * 131 };
      const cl = oceanRuinCluster(T, p);
      if (cl.warm && cl.pieces.length >= 4 && !foundWarm) {
        const w = new Cap(); oceanRuin(T, w.put, p);
        ok('ocean ruins (warm): multi-hut cluster (1 large + 3..5 small) of sandstone/cut/chiseled/smooth with suspicious_sand & ocean_ruin_warm chests',
          cl.pieces.length >= 4 && w.count('sandstone') + w.count('cut_sandstone') + w.count('chiseled_sandstone') > 60 && w.count('suspicious_sand') >= 6 && tagsOf(T, 'ocean_ruin_warm').length >= 1);
        foundWarm = true;
      } else if (!cl.warm && cl.pieces.length >= 4 && !foundCold) {
        const w = new Cap(); oceanRuin(T, w.put, p);
        ok('ocean ruins (cold): multi-hut cluster (1 large + 3..5 small) of stone bricks (plain/mossy/cracked/chiseled) with suspicious_gravel & ocean_ruin_cold chests',
          cl.pieces.length >= 4 && w.count('stone_bricks') + w.count('mossy_stone_bricks') + w.count('cracked_stone_bricks') > 60 && w.count('suspicious_gravel') >= 6 && tagsOf(T, 'ocean_ruin_cold').length >= 1);
        foundCold = true;
      }
    }
    void warmSite; void coldSite;
  }
}


console.log(`\n${pass}/${pass + fail} structure checks passed`);
if (fail) process.exit(1);
