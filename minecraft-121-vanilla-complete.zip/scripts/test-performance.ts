import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import '../src/game/content';
import { BLOCKS, ID } from '../src/game/data';
import { makeCell } from '../src/game/blockState';
import { makeAtlasDataArray, tilesFor } from '../src/textures/atlas';
import { Terrain, MIN_Y, HEIGHT } from '../src/world/terrain';
import { meshChunk } from '../src/world/mesher';
import { findPath, passable, floorLike, isClimbable } from '../src/entities/pathfinding';
import { Redstone } from '../src/systems/redstone';
import { newMap, updateMap, mapRGBA } from '../src/systems/maps';

let passed = 0;
function check(name: string, cond: unknown) {
  assert.ok(cond, `Failed: ${name}`);
  console.log(`PASS  ${name}`);
  passed++;
}

// 1. Greedy Mesher index-stride synchronization & transparent block face completeness
{
  const tiles = BLOCKS.map((_, i) => tilesFor(i));
  const padded = new Uint16Array(18 * 18 * HEIGHT);
  const setPadded = (x: number, y: number, z: number, id: number, st = 0) => {
    padded[(y - MIN_Y) * 324 + (z + 1) * 18 + (x + 1)] = makeCell(id, st);
  };

  // 4x1x4 flat stone platform: all 16 top faces (+Y) share sky light 15 and AO 0, so they must merge into 1 single +Y quad (4 vertices with ny === 1)
  for (let z = 2; z < 6; z++) {
    for (let x = 2; x < 6; x++) {
      setPadded(x, 64, z, ID.stone, 0);
    }
  }
  const m = meshChunk(padded, 70, tiles);
  let topVerts = 0;
  for (let i = 1; i < m.solid.normal.length; i += 3) {
    if (m.solid.normal[i] === 1) topVerts++;
  }
  // Smooth lighting: the evenly lit top and sides still merge into 1 quad each; the shaded underside keeps its light gradient
  // (sky light 13‥14 under the slab, Java AmbientOcclusionFace), so only those 16 cells stay separate: 21 quads in total.
  check('4x1x4 stone platform greedy-merges all 16 top faces into 1 quad (4 vertices) with zero duplicate faces', topVerts === 4 && m.solid.position.length <= 21 * 12);

  // Fluids (Java LiquidBlockRenderer): a 3×3 pool of sources on stone is a flat 8/9-high surface (shore cells stay separate for foam); a lone
  // flowing cell slopes; a source under another water block has no top face; nothing is emitted under an opaque ceiling.
  {
    padded.fill(0);
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) setPadded(x, 63, z, ID.stone);
    for (let z = 4; z < 7; z++) for (let x = 4; x < 7; x++) setPadded(x, 64, z, ID.water, 0);
    for (let z = 3; z < 8; z++) for (let x = 3; x < 8; x++) if (x === 3 || x === 7 || z === 3 || z === 7) setPadded(x, 64, z, ID.stone);
    const wm = meshChunk(padded, 70, tiles).water;
    const tops: number[][] = [];
    for (let i = 0; i < wm.normal.length; i += 12) if (wm.normal[i + 1] === 1) tops.push([wm.position[i + 1], wm.position[i + 4], wm.position[i + 7], wm.position[i + 10]]);
    check('fluid: enclosed 3×3 source pool → flat surface at y + 8/9', tops.length >= 1 && tops.length <= 9 && tops.every(t => t.every(y => Math.abs(y - (64 + 8 / 9 - 0.001)) < 1e-4)));
    setPadded(5, 65, 5, ID.water, 0);
    const wm2 = meshChunk(padded, 70, tiles).water;
    let full = 0;
    for (let i = 0; i < wm2.normal.length; i += 12) if (wm2.normal[i + 1] === 1) for (let k = 0; k < 4; k++) if (Math.abs(wm2.position[i + 1 + k * 3] - (64 + 1 - 0.001)) < 1e-4) full++;
    check('fluid: corners next to a column with water above rise to the full block (calculateAverageHeight)', full >= 4);
    padded.fill(0);
    setPadded(2, 64, 2, ID.water, 0); setPadded(2, 65, 2, ID.stone);
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) setPadded(2 + dx, 64, 2 + dz, ID.stone);
    setPadded(2, 63, 2, ID.stone);
    check('fluid: a fully enclosed cell emits nothing', meshChunk(padded, 70, tiles).water.position.length === 0);
    padded.fill(0);
  }

  // Single glass block surrounded by air must emit all 6 faces (+X, -X, +Y, -Y, +Z, -Z = 6 quads = 72 position floats)
  padded.fill(0);
  setPadded(8, 64, 8, ID.glass, 0);
  const mGlass = meshChunk(padded, 70, tiles);
  check('Isolated transparent cube (glass) emits all 6 faces including -X/-Y/-Z', mGlass.solid.position.length === 72 && mGlass.solid.index.length === 36);
}

// 2. Deterministic Terrain Generation & Meshing Performance
{
  const t0 = performance.now();
  const tex1 = makeAtlasDataArray();
  const tex2 = makeAtlasDataArray();
  const tiles = BLOCKS.map((_, i) => tilesFor(i));
  const atlasElapsed = performance.now() - t0;
  check('makeAtlasDataArray caches dilated RGBA layers across invocations', tex1.image?.data === tex2.image?.data || atlasElapsed < 500);
  check('tilesFor returns cached face tile arrays per block ID', tilesFor(ID.stone) === tilesFor(ID.stone));

  const terrainA = new Terrain('202505', 'overworld');
  const terrainB = new Terrain('202505', 'overworld');
  const genStart = performance.now();
  const cA = terrainA.generate(0, 0);
  const genMs = performance.now() - genStart;
  const cB = terrainB.generate(0, 0);

  check('Terrain.generate is 100% deterministic across instances', cA.maxY === cB.maxY && Buffer.compare(Buffer.from(cA.data.buffer), Buffer.from(cB.data.buffer)) === 0);
  check(`Single Overworld chunk generation completes quickly (${genMs.toFixed(1)} ms)`, genMs < 250);

  const meshStart = performance.now();
  const meshA = meshChunk(cA.padded, cA.maxY, tiles, cA.tint);
  const meshMs = performance.now() - meshStart;
  check(`Single Overworld chunk meshing + lighting completes quickly (${meshMs.toFixed(1)} ms) with compact vertex buffer`, meshMs < 80 && meshA.solid.position.length > 0 && meshA.solid.position.length < 150000);
}

// 3. A* Pathfinding LUT & 32-bit Integer Key Correctness & Speed
{
  check('Pathfinding LUTs classify air, ladder, water, stone, and hazards accurately', passable(0) && isClimbable(ID.ladder) && floorLike(ID.stone) && !passable(ID.lava, false) && passable(ID.lava, true));
  const getFlat = (_x: number, y: number, _z: number) => (y === 63 ? ID.stone : 0);
  const p0 = performance.now();
  let path: any = null;
  for (let i = 0; i < 100; i++) {
    path = findPath(getFlat, 0, 64, 0, 12, 64, 12, { maxNodes: 256 });
  }
  const pathMs = performance.now() - p0;
  check(`100 A* pathfinding queries complete in ${pathMs.toFixed(2)} ms (< 50 ms)`, path && path.length > 0 && pathMs < 50);
}

// 4. Redstone Single-Pass Convergence & Coordinate Parse Cache
{
  const world = new Map<string, number>();
  const rs = new Redstone({
    getCell: (x, y, z) => world.get(`${x},${y},${z}`) ?? 0,
    setBlock: (x, y, z, id, st = 0) => {
      if (id === 0) world.delete(`${x},${y},${z}`);
      else world.set(`${x},${y},${z}`, makeCell(id, st));
      return true;
    },
  });
  for (let x = 0; x < 16; x++) {
    rs.set(x, 63, 0, ID.stone, 0);
    rs.set(x, 64, 0, x === 0 ? ID.redstone_block : ID.redstone_wire, 0);
  }
  const r0 = performance.now();
  for (let i = 0; i < 100; i++) {
    rs.blockChanged(0, 64, 0);
    rs.tick();
  }
  const rsMs = performance.now() - r0;
  check(`100 Redstone solver ticks complete in ${rsMs.toFixed(2)} ms with signal decaying 15 -> 1`, (world.get('1,64,0')! >>> 12) === 15 && (world.get('15,64,0')! >>> 12) === 1 && rsMs < 100);
}

// 5. Explorer Map Scale-0 Fast Path & Precomputed Palette RGBA LUT
{
  const m = newMap(1, 'overworld', 0, 0, 0);
  const sample = (x: number, z: number) => ({
    y: 64 + ((x + z) & 7),
    color: ((x ^ z) & 1) ? '#7fb238' : '#4040ff',
    water: ((x ^ z) & 1) === 0,
    depth: 3,
  });
  const m0 = performance.now();
  for (let i = 0; i < 16; i++) updateMap(m, 0, 0, sample, 128);
  const rgba = mapRGBA(m);
  const mapMs = performance.now() - m0;
  check(`Full 16-step map sweep + RGBA conversion completes in ${mapMs.toFixed(2)} ms`, rgba.length === 128 * 128 * 4 && rgba[3] === 255 && mapMs < 50);
}

console.log(`\n${passed}/${passed} performance & equivalence checks passed`);
