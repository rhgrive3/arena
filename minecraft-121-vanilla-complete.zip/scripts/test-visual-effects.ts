import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import * as THREE from 'three';
import '../src/game/content';
import { ID } from '../src/game/data';
import { DEFAULT_SETTINGS } from '../src/game/types';
import { ParticleSystem, type VanillaParticleKind } from '../src/render/particles';
import { Environment } from '../src/render/environment';
import { precipitationAt, dynamicFov, potionColor, NETHER_ATMOSPHERES } from '../src/render/visuals';
import { MobManager } from '../src/entities/mobs';
import { Farming, SEED_TO_CROP } from '../src/systems/farming';
import { makeCell, blockState } from '../src/game/blockState';
import * as SV from '../src/game/survival';

const results: { name: string; passed: boolean; error?: string }[] = [];
function check(name: string, test: () => void) {
  try { test(); results.push({ name, passed: true }); }
  catch (error) { results.push({ name, passed: false, error: String(error) }); console.error(`FAIL ${name}: ${error}`); }
}
const ok = (name: string, condition: unknown) => check(name, () => assert.ok(condition));
const near = (actual: number, expected: number, epsilon = 1e-6) => assert.ok(Math.abs(actual - expected) < epsilon, `${actual} != ${expected}`);
const originalRandom = Math.random;
let seed = 73921;
Math.random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
const scene = new THREE.Scene();
const system = new ParticleSystem(scene);
const origin = new THREE.Vector3(0, 2, 0);
const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 100);
camera.rotation.set(0.2, 0.6, 0.1);
const air = () => 0;
const noPickup = () => false;
const kinds: VanillaParticleKind[] = ['crit', 'enchanted_hit', 'mobSpell', 'portal', 'lava_pop', 'drip_water', 'drip_lava', 'rain_splash', 'happy_villager'];

for (const kind of kinds) {
  system.clear();
  system.emit(kind, origin, { count: 3 });
  const p = system.particles[0];
  const material = p.mesh.material as THREE.MeshBasicMaterial;
  ok(`${kind}: exact count`, system.particles.length === 3);
  ok(`${kind}: typed particle`, p.kind === kind);
  ok(`${kind}: camera-facing plane, not cube`, p.mesh.geometry === system.spriteGeometry);
  ok(`${kind}: valid lifetime`, p.life > 0 && p.life === p.max);
  ok(`${kind}: finite position`, p.mesh.position.toArray().every(Number.isFinite));
  ok(`${kind}: transparent cutout`, material.transparent && material.alphaTest > 0);
  ok(`${kind}: no depth-write artifacts`, material.depthWrite === false);
  ok(`${kind}: pixel filtering`, material.map?.magFilter === THREE.NearestFilter && material.map?.minFilter === THREE.NearestFilter);
  const data = (material.map as THREE.DataTexture).image.data;
  const alpha = Array.from(data).filter((_, i) => i % 4 === 3);
  ok(`${kind}: visible pixels`, alpha.some(a => a > 0));
  ok(`${kind}: transparent silhouette`, alpha.some(a => a === 0));
  system.update(0.05, air, noPickup, undefined, camera);
  check(`${kind}: billboard follows camera quaternion`, () => near(Math.abs(p.mesh.quaternion.dot(camera.quaternion)), 1));
}

system.clear(); system.crit(origin, 8);
ok('crit helper emits warm cross stars', system.particles.length === 8 && system.particles.every(p => p.kind === 'crit' && p.color === '#bca47d'));
system.clear(); system.enchantedHit(origin, 7);
ok('enchanted-hit helper emits pale cyan', system.particles.length === 7 && system.particles.every(p => p.kind === 'enchanted_hit' && p.color === '#a5f3e8'));
system.clear(); system.happyVillager(origin, 9);
ok('happy-villager helper emits green glints', system.particles.length === 9 && system.particles.every(p => p.kind === 'happy_villager'));

system.clear(); system.portal(origin, 1);
const portal = system.particles[0], portalStart = portal.mesh.position.clone(), distance = portalStart.distanceTo(origin);
system.update(0.2, air, noPickup);
ok('portal moves inward, never ballistic outward', portal.mesh.position.distanceTo(origin) < distance);
const afterFirst = portal.mesh.position.distanceTo(origin);
system.update(0.2, air, noPickup);
ok('portal attraction accelerates', afterFirst - portal.mesh.position.distanceTo(origin) > distance - afterFirst);
ok('portal keeps immutable spawn position', portal.start!.equals(portalStart));
ok('portal animates generic pixel frames', system.spriteTextures.has(`portal:${portal.frame}`));

system.clear(); const anchor = new THREE.Vector3(0, 1, 0);
system.mobSpell(anchor, '#33ebff', 2, 0);
const swirl = system.particles[0], swirlStart = swirl.mesh.position.clone();
system.update(0.2, air, noPickup);
ok('potion spiral rises', swirl.mesh.position.y > swirlStart.y);
ok('potion spiral rotates around entity', Math.abs(swirl.mesh.position.z - swirlStart.z) > 0.05);
anchor.x += 4; system.update(0.1, air, noPickup);
ok('potion spiral follows moving entity', swirl.mesh.position.x > 3.5);
ok('potion sprite animates spiral frames', swirl.frame! > 0);

system.clear(); system.lavaPop(origin, 2);
const lava = system.particles[0], lavaY = lava.mesh.position.y;
system.update(0.05, air, noPickup);
ok('lava pops upward', lava.mesh.position.y > lavaY && lava.gravity > 0);
ok('lava sprite remains bright in caves', (lava.mesh.material as THREE.MeshBasicMaterial).isMeshBasicMaterial);

for (const kind of ['drip_water', 'drip_lava'] as const) {
  system.clear(); system.emit(kind, new THREE.Vector3(0, 3, 0));
  const p = system.particles[0], initial = p.mesh.position.y;
  system.update(0.2, air, noPickup);
  check(`${kind}: hanging phase is stationary`, () => near(p.mesh.position.y, initial));
  for (let i = 0; i < 12; i++) system.update(0.05, air, noPickup);
  ok(`${kind}: falls after ceiling hang`, p.mesh.position.y < initial && p.frame === 1);
  for (let i = 0; i < 40 && !p.landed; i++) system.update(0.05, (_x, y) => y < 1 ? ID.stone : 0, noPickup);
  ok(`${kind}: collides with floor`, p.landed === true);
  ok(`${kind}: landing texture stage`, p.frame === 2);
  ok(`${kind}: lands above solid surface`, p.mesh.position.y >= 1);
}

system.clear(); system.rainSplash(origin, 2);
const splash = system.particles[0];
system.update(0.1, air, noPickup);
ok('rain splash animates through splash frames', splash.frame! > 0);
for (let i = 0; i < 15; i++) system.update(0.1, air, noPickup);
ok('short-lived rain splash expires', system.particles.length === 0);

system.clear(); system.emit('crit', origin, { count: -10 });
ok('negative count emits nothing', system.particles.length === 0);
system.emit('crit', origin, { count: 999999 });
ok('per-call spawn cap', system.particles.length === 64);
for (let i = 0; i < 30; i++) system.emit('portal', origin, { count: 64 });
ok('global particle budget is enforced', system.particles.length === system.maxParticles);
system.clear(); system.crit(origin, 1);
const beforeInvalid = system.particles[0].mesh.position.clone();
system.update(Number.NaN, air, noPickup); system.update(-1, air, noPickup);
ok('invalid delta cannot corrupt positions', system.particles[0].mesh.position.equals(beforeInvalid));
for (let i = 0; i < 30; i++) system.update(0.1, air, noPickup);
ok('expired particles are removed from simulation', system.particles.length === 0);
ok('expired meshes are hidden or detached', scene.children.every(child => !child.visible));
system.crit(origin, 1); const recycled = system.particles[0].mesh;
system.clear(); system.burst(origin, '#fff', 1);
ok('sprite-to-debris pooling resets geometry', system.particles[0].mesh === recycled && system.particles[0].mesh.geometry === system.geometry);
system.clear();

// Exercise the actual action handlers, not just the public particle helpers.
{
  const mob: any = { species: 'zombie', group: new THREE.Group(), hp: 100, state: 'wander', timer: 0, hurtTimer: 0 };
  mob.group.position.set(0, 1, 0);
  const manager: any = {
    crystals: [], projectiles: [], mobs: [mob],
    behaviors: { modifyDamage: (_m: unknown, damage: number) => damage },
    beh: { armorOf: () => 0 }, host: { particles: system, sound() {} },
    setHurtTint() {}, provoke() {}, kill() {},
  };
  system.clear();
  const hit = MobManager.prototype.hit.call(manager, new THREE.Vector3(0, 2, 3), new THREE.Vector3(0, 0, -1), 4, true);
  ok('action integration: critical melee hit lands', hit === true);
  ok('action integration: critical melee invokes crit emitter', system.particles.some(p => p.kind === 'crit'));
  system.clear();
  MobManager.prototype.hit.call(manager, new THREE.Vector3(0, 2, 3), new THREE.Vector3(0, 0, -1), 4, false);
  ok('action integration: normal melee does not emit critical stars', !system.particles.some(p => p.kind === 'crit'));
  system.clear();
  MobManager.prototype.damageMob.call(manager, mob, 2, undefined, true);
  ok('action integration: ranged critical damage invokes crit emitter', system.particles.some(p => p.kind === 'crit'));

  const attack = (enchanted: boolean, smash = false) => {
    system.clear();
    const held = { name: smash ? 'mace' : 'diamond_sword', count: 1, ench: enchanted ? { sharpness: 1 } : {} };
    const target = { species: 'zombie', group: new THREE.Group() };
    const e: any = {
      meta: { mode: 'creative' }, blocking: false, swingHeld: false, effects: {}, elapsed: 100, attackAt: 0,
      hotbar: [held], selected: 0, position: new THREE.Vector3(0, 64, 0), velocity: new THREE.Vector3(0, smash ? -9 : 0, 0),
      fallTop: smash ? 72 : 64, grounded: !smash, input: { run: false }, camera: new THREE.PerspectiveCamera(),
      particles: system, getBlock: () => 0, mobs: { hit() { this.lastHit = target; return true; }, extraDamage() {}, hurtNear: () => 0 },
    };
    SV.tryAttack(e, held, { damage: 4 } as any);
    return system.particles.some(p => p.kind === 'enchanted_hit');
  };
  ok('action integration: Sharpness emits enchanted hit sprites', attack(true));
  ok('action integration: ordinary weapon emits no enchanted sprites', !attack(false));
  ok('action integration: unenchanted mace smash is not an enchanted hit', !attack(false, true));

  system.clear();
  const crop = ID[SEED_TO_CROP.wheat_seeds], cells = new Map<string, number>([['0,0,0', makeCell(ID.farmland, 1)], ['0,1,0', makeCell(crop, 0)]]);
  const farm = new Farming({
    getCell: (x, y, z) => cells.get(`${x},${y},${z}`) ?? 0,
    setBlock(x, y, z, id, state = 0) { cells.set(`${x},${y},${z}`, makeCell(id, state)); return true; },
    growth: (x, y, z) => system.happyVillager(new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5), 5),
    particles: (x, y, z, _color, count) => system.happyVillager(new THREE.Vector3(x, y, z), count),
  }, () => 0);
  farm.randomTick(0, 1, 0, 1);
  ok('action integration: natural crop random tick advances growth', blockState(cells.get('0,1,0')!) === 1);
  ok('action integration: natural growth emits green glints', system.particles.length > 0 && system.particles.every(p => p.kind === 'happy_villager'));
  system.clear();
  ok('action integration: bone meal emits green glints on successful growth', farm.bonemeal(0, 1, 0) && system.particles.some(p => p.kind === 'happy_villager'));
  cells.set('0,1,0', makeCell(crop, 7)); system.clear();
  ok('action integration: bone meal on a mature crop does not fake success', !farm.bonemeal(0, 1, 0) && system.particles.length === 0);
}
system.clear();

ok('potion color ignores expired effects', potionColor({ speed: { t: 0, amp: 0 } }) === null);
ok('potion color supports mob timers', potionColor({ poison: 5 }) === '#87a363');
ok('potion color supports player effect level', potionColor({ speed: { t: 5, amp: 2 } }) === '#33ebff');
ok('multiple potion effects blend colors', potionColor({ speed: 5, poison: 5 }) !== '#33ebff' && potionColor({ speed: 5, poison: 5 }) !== '#87a363');
const nearMob = { species: 'enderman', group: new THREE.Group(), fx: { poison: 5 } };
const farMob = { species: 'enderman', group: new THREE.Group() }; farMob.group.position.x = 100;
system.entityEffects(0.15, origin, { speed: { t: 3, amp: 0 } }, [nearMob, farMob]);
ok('active player potion emits spirals', system.particles.filter(p => p.kind === 'mobSpell').length === 4);
ok('nearby enderman emits portal motes', system.particles.filter(p => p.kind === 'portal').length === 2);
ok('distant entities are culled', system.particles.length === 6);
system.clear();

Math.random = () => 0.5;
let reads = 0;
system.ambientBlocks(0.11, new THREE.Vector3(), (_x, y) => { reads++; return y === 1 ? ID.lava : 0; }, () => ID.lava);
ok('exposed lava sources emit lava pops', system.particles.some(p => p.kind === 'lava_pop'));
ok('ambient query budget is bounded', reads <= 300);
system.clear(); system.ambientBlocks(0.11, new THREE.Vector3(), (_x, y) => y === 1 ? ID.lava : 0, () => ID.lava | (1 << 12));
ok('flowing lava does not emit source pops', system.particles.length === 0);
system.clear(); system.ambientBlocks(0.11, new THREE.Vector3(), () => ID.portal);
ok('nether portal blocks emit inward particles', system.particles.some(p => p.kind === 'portal'));
system.clear(); system.ambientBlocks(0.11, new THREE.Vector3(), (_x, y) => y === 2 ? ID.stone : y === 3 ? ID.water : 0);
ok('water above solid ceiling creates hanging drips', system.particles.some(p => p.kind === 'drip_water'));
system.clear(); system.ambientBlocks(0.11, new THREE.Vector3(), (_x, y) => y === 2 ? ID.stone : y === 3 ? ID.lava : 0);
ok('lava above solid ceiling creates hanging drips', system.particles.some(p => p.kind === 'drip_lava'));
system.clear(); system.ambientBlocks(0.11, new THREE.Vector3(), () => -1);
ok('unloaded cells never emit particles', system.particles.length === 0);
Math.random = originalRandom;

for (const biome of ['snowy_plains', 'snowy_taiga', 'snowy_beach', 'ice_spikes', 'snowy_slopes', 'grove', 'jagged_peaks', 'frozen_peaks', 'frozen_river', 'frozen_ocean', 'deep_frozen_ocean']) {
  ok(`${biome}: snowfall automatically selected`, precipitationAt(biome, 64) === 'snow');
}
for (const biome of ['plains', 'forest', 'jungle', 'swamp', 'cherry_grove', 'taiga']) ok(`${biome}: temperate precipitation is rain`, precipitationAt(biome, 64) === 'rain');
for (const biome of ['desert', 'badlands', 'savanna', 'stony_peaks']) ok(`${biome}: arid biomes suppress precipitation`, precipitationAt(biome, 200) === 'none');
ok('high-altitude hills switch to snow', precipitationAt('windswept_hills', 180) === 'snow');
ok('low-altitude hills keep rain', precipitationAt('windswept_hills', 64) === 'rain');
ok('namespaced biome IDs supported', precipitationAt('minecraft:frozen_peaks', 120) === 'snow');
ok('Nether never receives rain or snow', precipitationAt('snowy_plains', 90, 'nether') === 'none');
ok('End never receives rain or snow', precipitationAt('plains', 90, 'end') === 'none');

check('base FOV preserved', () => near(dynamicFov(70), 70));
check('sprinting widens Java movement FOV', () => near(dynamicFov(70, { sprinting: true }), 80.5));
check('Speed I widens FOV', () => near(dynamicFov(70, { speedLevel: 1 }), 77));
ok('Speed II is wider than Speed I', dynamicFov(70, { speedLevel: 2 }) > dynamicFov(70, { speedLevel: 1 }));
ok('sprint and Speed stack multiplicatively', dynamicFov(70, { sprinting: true, speedLevel: 1 }) > dynamicFov(70, { sprinting: true }));
check('full bow draw narrows FOV by 15 percent', () => near(dynamicFov(70, { bowCharge: 1 }), 59.5));
check('half bow draw uses squared charge', () => near(dynamicFov(70, { bowCharge: 0.5 }), 67.375));
ok('bow draw and sprint compose', dynamicFov(70, { sprinting: true, bowCharge: 1 }) < dynamicFov(70, { sprinting: true }));
check('bow charge clamped to one', () => near(dynamicFov(70, { bowCharge: 5 }), 59.5));
check('negative bow charge ignored', () => near(dynamicFov(70, { bowCharge: -1 }), 70));
check('spyglass takes precedence over sprint, bow and speed', () => near(dynamicFov(70, { spyglass: true, sprinting: true, speedLevel: 2, bowCharge: 1 }), 7));
check('underwater narrowing retained', () => near(dynamicFov(70, { underwater: true }), 63));
ok('slowness narrows FOV', dynamicFov(70, { slownessLevel: 1 }) < 70);
ok('extreme speed FOV bounded', dynamicFov(110, { speedLevel: 100 }) <= 150);
ok('extreme slowness stays finite', Number.isFinite(dynamicFov(70, { slownessLevel: 100 })));
check('invalid base falls back safely', () => near(dynamicFov(Number.NaN), 70));
const smooth = (fps: number) => {
  const c = new THREE.PerspectiveCamera(70);
  for (let i = 0; i < fps; i++) Environment.prototype.updateFov.call({} as Environment, c, 1 / fps, 70, { sprinting: true });
  return c.fov;
};
check('FOV easing is frame-rate independent at 30 and 60 FPS', () => near(smooth(30), smooth(60), 1e-5));
const recovery = new THREE.PerspectiveCamera(59.5);
for (let i = 0; i < 100; i++) Environment.prototype.updateFov.call({} as Environment, recovery, 1 / 60, 70, {});
check('bow release smoothly restores base FOV', () => near(recovery.fov, 70, 0.01));

const renderer = { capabilities: { getMaxAnisotropy: () => 1, isWebGL2: true }, debug: {}, shadowMap: {} } as unknown as THREE.WebGLRenderer;
const envScene = new THREE.Scene();
const env = new Environment(envScene, renderer, DEFAULT_SETTINGS);
const weatherCamera = new THREE.PerspectiveCamera(); weatherCamera.position.set(0, 72, 0);
env.update(1, 0.25, weatherCamera, 'overworld', DEFAULT_SETTINGS, 'rain', 'snowy_plains');
ok('environment switches rain to snow', env.precipitation === 'snow' && env.rainMat.uniforms.uSnow.value === 1);
ok('snow is visible during precipitation', env.rain.visible);
env.update(2, 0.25, weatherCamera, 'overworld', DEFAULT_SETTINGS, 'rain', 'plains');
ok('environment switches back to rain', env.precipitation === 'rain' && env.rainMat.uniforms.uSnow.value === 0);
env.update(3, 0.25, weatherCamera, 'overworld', DEFAULT_SETTINGS, 'clear', 'snowy_plains');
ok('clear weather disables snowfall', !env.rain.visible && env.precipitation === 'none');
for (const [biome, profile] of Object.entries(NETHER_ATMOSPHERES)) {
  env.update(4, 0.25, weatherCamera, 'nether', DEFAULT_SETTINGS, 'storm', biome);
  ok(`${biome}: atmosphere enabled`, env.ambientParticles.visible);
  ok(`${biome}: precipitation disabled`, !env.rain.visible);
  check(`${biome}: correct vertical motion`, () => near(env.ambientMat.uniforms.uFall.value, profile.fall));
  ok(`${biome}: distinct particle density`, env.ambientParticles.geometry.drawRange.count === profile.density);
}
ok('basalt white ash falls rather than rises', NETHER_ATMOSPHERES.basalt_deltas.fall > 0);
ok('crimson spores drift upward', NETHER_ATMOSPHERES.crimson_forest.fall < 0);
ok('soul valley uses ash, not invented soul-fire sparks', NETHER_ATMOSPHERES.soul_sand_valley.particle === 'ash');
env.update(5, 0.25, weatherCamera, 'nether', DEFAULT_SETTINGS, 'rain', 'nether_wastes');
ok('Nether wastes do not get invented biome spores', !env.ambientParticles.visible);
env.update(6, 0.25, weatherCamera, 'nether', { ...DEFAULT_SETTINGS, quality: 'low' }, 'clear', 'basalt_deltas');
ok('low quality reduces ambient GPU density', env.ambientParticles.geometry.drawRange.count < NETHER_ATMOSPHERES.basalt_deltas.density);

let surface = { y: 64, solid: true }, biome = 'plains', surfaceReads = 0;
env.attachWorld({ surfaceAt() { surfaceReads++; return surface; }, biomeAt: () => biome });
env.update(7, 0.25, weatherCamera, 'overworld', DEFAULT_SETTINGS, 'rain', 'plains');
ok('weather occlusion uses fixed query budget', surfaceReads === 48);
ok('weather surface heights are uploaded for roof clipping', env.rain.geometry.getAttribute('aSurface').getX(0) === 64);
ok('weather samples actual column climate', env.rain.geometry.getAttribute('aClimate').getX(0) === 1);
system.clear(); env.rainSplashes(0.1, weatherCamera, system, 'overworld');
ok('rain splashes spawn on solid exposed ground', system.particles.length > 0 && system.particles.every(p => p.kind === 'rain_splash'));
system.clear(); surface = { y: 64, solid: false }; env.rainSplashes(0.1, weatherCamera, system, 'overworld');
ok('rain splashes skip water, lava and air', system.particles.length === 0);
surface = { y: 64, solid: true }; biome = 'snowy_plains'; env.rainSplashes(0.1, weatherCamera, system, 'overworld');
ok('snow never spawns rain splashes', system.particles.length === 0);
biome = 'desert'; env.rainSplashes(0.1, weatherCamera, system, 'overworld');
ok('dry biome never spawns rain splashes', system.particles.length === 0);
biome = 'plains'; env.rainSplashes(0.1, weatherCamera, system, 'nether');
ok('Nether never spawns rain splashes', system.particles.length === 0);

const engineSource = readFileSync(new URL('../src/game/engine.ts', import.meta.url), 'utf8');
ok('one dynamic-FOV writer in active frame', (engineSource.match(/this\.environment\.updateFov\(/g) ?? []).length === 1);
ok('old per-frame FOV reset removed', !engineSource.includes('this.camera.fov = wantFov'));
ok('visual block queries have no generation side effect', !engineSource.slice(engineSource.indexOf('  visualCell('), engineSource.indexOf('  visualSurfaceAt(')).includes('invalidate'));

for (const line of readFileSync(new URL('../docs/world-generation.sha256', import.meta.url), 'utf8').trim().split('\n')) {
  const [expected, file] = line.split(/\s+/);
  const actual = createHash('sha256').update(readFileSync(new URL('../' + file, import.meta.url))).digest('hex');
  ok(`world-generation unchanged: ${file}`, actual === expected);
}

let disposedTextures = 0, disposedMaterials = 0;
system.spriteTextures.forEach(t => t.addEventListener('dispose', () => disposedTextures++));
system.spriteMaterials.forEach(m => m.addEventListener('dispose', () => disposedMaterials++));
const textureCount = system.spriteTextures.size, materialCount = system.spriteMaterials.size;
system.dispose(); env.dispose();
ok('all sprite textures disposed', disposedTextures === textureCount);
ok('all shared sprite materials disposed', disposedMaterials === materialCount);
ok('sprite caches cleared on dispose', system.spriteTextures.size === 0 && system.spriteMaterials.size === 0);
ok('pooled meshes detached on dispose', scene.children.length === 0);
Math.random = originalRandom;

const passed = results.filter(r => r.passed).length;
mkdirSync('reports', { recursive: true });
writeFileSync('reports/visual-effects.json', JSON.stringify({ suite: 'visual-effects', passed, failed: results.length - passed, total: results.length, results }, null, 2) + '\n');
console.log(`\n${passed}/${results.length} visual-effects checks passed`);
if (passed !== results.length) process.exit(1);