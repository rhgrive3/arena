import { rollMobLoot } from '../src/entities/mobLoot';
import { rollSheepColor, sheepBiomeGroup, mixDyes, lambColor, SHEEP_COLORS, jebColor } from '../src/entities/sheep';
import { fluidOwnHeight, fluidHeightAt, fluidFlow } from '../src/systems/fluids';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import '../src/game/content';
import { BLOCKS, ID, resolve } from '../src/game/data';
import { Terrain, blockIndex } from '../src/world/terrain';
import { locateExtra, extraLootTable, EXTRA_LOOT, regionSize } from '../src/world/structures';
import { chamberLayout } from '../src/world/dungeons';
import { EventBus } from '../src/game/events';
import { TrialSystem, scaling, spawnerProfile, TRIAL_COOLDOWN_SEC, rollVault, rollSpawnerRewards, ominousProjectiles, OMINOUS_SHOTS, type TrialPlayer, type Reward } from '../src/systems/trials';
import { ominousEquipment } from '../src/systems/combat121';
import {
  maceSmashBonus, densityBonus, smashDamage, breachFactor, damageAfterArmor, windBurstVelocity, PLAYER_GRAVITY, windKnockback,
  cobwebSpeedFactor, COBWEB_SLOW, creeperRadius, explosionDamage, mobArmor,
} from '../src/systems/combat121';
import { MobManager, type Mob, type MobHost } from '../src/entities/mobs';
import { tickTurtleEgg, campfireBelow, WOLF_ARMOR_HP, HIVE_MAX_HONEY } from '../src/entities/behaviors';
import {
  beaconLevel, beaconRange, beaconEffects, beaconPowers, conduitStatus, CONDUIT_FRAME_POSITIONS, BeaconSystem, CONDUIT_ATTACK_DAMAGE,
} from '../src/systems/beacon';
import { ARCH_LOOT, archaeologyRoll, pickTable, BrushSession, BRUSH_STROKES, potInsert, type ArchTable } from '../src/systems/archaeology';
import { TRIM_RECIPES, TRIM_PATTERNS, TRIM_MATERIALS, trimPreview, TEMPLATE_COPY_BLOCK } from '../src/systems/smithing';
import { RECIPES } from '../src/systems/crafting';
import { searchStructure, ringSearch, describeTarget, EXPLORER_MAPS, mapStack } from '../src/systems/explorerMap';
import { potionEffects, EFFECTS, ENCHANT_BY_ID, brewResult } from '../src/systems/magic';

const results: { name: string; ok: boolean; error?: string }[] = [];
async function test(name: string, fn: () => void | Promise<void>) {
  try { await fn(); results.push({ name, ok: true }); }
  catch (e) { results.push({ name, ok: false, error: e instanceof Error ? e.stack ?? e.message : String(e) }); }
}
const I = ID as Record<string, number>;
function seeded(seed = 12345) { let a = seed; return () => { a = (a * 1664525 + 1013904223) >>> 0; return a / 4294967296; }; }

// ---------- a tiny block world + mob manager (no WebGL) ---------------------------------------------------------------------
function world(ground = 64) {
  const cells = new Map<string, number>(), key = (x: number, y: number, z: number) => `${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`;
  const getCell = (x: number, y: number, z: number) => cells.get(key(x, y, z)) ?? (Math.floor(y) < ground ? I.grass_block : 0);
  const set = (x: number, y: number, z: number, name: string, state = 0) => cells.set(key(x, y, z), I[name] | (state << 12));
  const drops: { name: string; count: number; pos: THREE.Vector3 }[] = [], explosions: number[] = [], events = new EventBus();
  const flags = { rain: false, grown: 0, knocked: 0 };
  const position = new THREE.Vector3(0, ground, 0), camera = new THREE.PerspectiveCamera(70, 1, 0.1, 100);
  const host: MobHost = {
    terrain: { height: () => ground - 1, biome: () => 'plains', seed: 7 } as never,
    position, camera, time: 0, dimension: 'overworld', dragonDefeated: false,
    getBlock: (x, y, z) => getCell(x, y, z) & 0x0fff,
    damage() {}, addItem: () => true, toast() {}, sound() {}, explode: (_p, r) => { explosions.push(r); }, teleport() {}, openTrade() {},
    onDragonDefeated() {}, onEnterGateway() {}, levitate() {},
    particles: { burst() {}, spark() {}, drop: (p: THREE.Vector3, name: string, count: number) => { drops.push({ name, count, pos: p.clone() }); } },
    setBlock: (x, y, z, id, state = 0) => { cells.set(key(x, y, z), id | (state << 12)); return true; },
    getState: (x, y, z) => getCell(x, y, z) >> 12,
    raining: () => flags.rain,
    emit: (type, payload) => events.emit(type, payload),
    growCrop: () => { flags.grown++; return true; },
    nearestDrop: (name, x, y, z, r, avoid) => {
      let best: THREE.Vector3 | null = null, bd = r * r;
      for (const d of drops) {
        if (d.name !== name) continue;
        if (avoid && (d.pos.x - avoid[0] - 0.5) ** 2 + (d.pos.z - avoid[2] - 0.5) ** 2 < 6.25) continue;
        const dd = d.pos.distanceToSquared(new THREE.Vector3(x, y, z));
        if (dd < bd) { bd = dd; best = d.pos; }
      }
      return best ? { x: best.x, y: best.y, z: best.z } : null;
    },
    takeDrop: (name, x, y, z, r) => {
      const i = drops.findIndex(d => d.name === name && d.pos.distanceTo(new THREE.Vector3(x, y, z)) <= r);
      return i < 0 ? 0 : drops.splice(i, 1)[0].count;
    },
    knockPlayer: () => { flags.knocked++; },
  };
  const mobs = new MobManager(new THREE.Scene(), host);
  mobs.clear();
  mobs.spawnTimer = -1e9;
  const spawn = (species: Parameters<MobManager['spawn']>[0], x: number, z: number, baby = false, y = ground) => {
    const m = mobs.spawn(species, x, z, baby, y);
    assert.ok(m, species + ' spawns');
    return m as Mob;
  };
  const blockAt = (x: number, y: number, z: number) => BLOCKS[getCell(x, y, z) & 0x0fff]?.name ?? 'air';
  const count = (name: string) => [...cells.values()].filter(c => (c & 0x0fff) === I[name]).length;
  return { mobs, host, set, getCell, blockAt, count, drops, explosions, events, flags, position, spawn, cells };
}

// ---------- a trial-system host -------------------------------------------------------------------------------------------
function trials() {
  const blocks = new Map<string, 'spawner' | 'vault' | 'ominous_vault' | 'other' | null>(), states = new Map<string, number>();
  const alive = new Set<number>(), removed: number[] = [], ejected: { reward: Reward; from: string }[] = [], omens: string[] = [], events = new EventBus();
  const ctx = { now: 0, players: [] as TrialPlayer[], nextId: 1, maxAlive: 0, spawned: 0 };
  const k = (x: number, y: number, z: number) => `${x},${y},${z}`;
  const sys = new TrialSystem({
    now: () => ctx.now, rng: seeded(99),
    blockAt: (x, y, z) => (blocks.has(k(x, y, z)) ? blocks.get(k(x, y, z))! : 'other'),
    setPhase: (x, y, z, s) => { states.set(k(x, y, z), s); },
    playersNear: () => ctx.players,
    spawn: () => { const id = ctx.nextId++; alive.add(id); ctx.spawned++; ctx.maxAlive = Math.max(ctx.maxAlive, alive.size); return id; },
    alive: id => alive.has(id),
    remove: id => { alive.delete(id); removed.push(id); },
    eject: (_x, _y, _z, reward, from) => { ejected.push({ reward, from }); },
    omenUsed: p => { omens.push(p); },
    emit: (type, payload) => events.emit(type, payload),
  });
  const advance = (sec: number) => { for (let t = 0; t < sec - 1e-9; t += 0.25) { ctx.now += 0.25; sys.update(0.25); } };
  const killAll = () => { for (const id of [...alive]) { alive.delete(id); sys.onMobDeath(id); } };
  const spawner = (x = 0, kind: 'melee' | 'breeze' = 'melee') => { blocks.set(k(x, 0, 0), 'spawner'); return sys.registerSpawner(x, 0, 0, kind, kind === 'breeze' ? 'breeze' : 'zombie'); };
  return { sys, ctx, blocks, states, alive, removed, ejected, omens, events, advance, killAll, spawner, k };
}

async function main() {
  // ===== content ============================================================================================================
  await test('content: new blocks/items are registered and legacy ids are untouched', () => {
    assert.equal(ID.grass_block, 1); assert.equal(ID.dirt, 2); assert.equal(ID.stone, 3);
    for (const n of ['tuff_bricks', 'chiseled_copper', 'trial_spawner', 'vault', 'ominous_vault', 'beacon', 'conduit', 'suspicious_sand', 'suspicious_gravel', 'decorated_pot', 'bee_nest', 'beehive', 'turtle_egg', 'zombie_head', 'skeleton_skull', 'creeper_head', 'wither_skeleton_skull'])
      assert.ok(I[n] > I.campfire, n + ' is a block appended after the legacy set');
    for (const n of ['trial_key', 'ominous_trial_key', 'ominous_bottle', 'brush', 'armadillo_scute', 'wolf_armor', 'torchflower_seeds', 'pitcher_pod', 'ocean_explorer_map', 'woodland_explorer_map', 'buried_treasure_map', 'heart_pottery_sherd', 'sentry_armor_trim_smithing_template', 'potion_wind_charged', 'splash_weaving', 'potion_oozing', 'potion_infested'])
      assert.ok(resolve(n), n + ' resolves');
    for (const e of ['wind_charged', 'infested', 'oozing', 'weaving', 'bad_omen', 'trial_omen', 'conduit_power']) assert.ok(EFFECTS[e], e + ' effect');
    for (const e of ['density', 'breach', 'wind_burst']) assert.deepEqual(ENCHANT_BY_ID[e].on, ['mace']);
    assert.deepEqual(potionEffects('potion_wind_charged')?.effects[0].slice(0, 2), ['wind_charged', 180]);
    assert.equal(brewResult('awkward_potion', 'breeze_rod'), 'potion_wind_charged');
    assert.equal(brewResult('awkward_potion', 'cobweb'), 'potion_weaving');
    assert.equal(brewResult('awkward_potion', 'slime_block'), 'potion_oozing');
    assert.equal(brewResult('awkward_potion', 'stone'), 'potion_infested');
  });

  // ===== structures =========================================================================================================
  const terrain = new Terrain('tricky-trials', 'overworld');
  const countIn = (t: Terrain, x: number, z: number, names: string[]) => {
    const cx = Math.floor(x / 16), cz = Math.floor(z / 16), g = t.generate(cx, cz, [], true), ids = names.map(n => I[n]), out = names.map(() => 0);
    for (let i = 0; i < g.data.length; i++) { const j = ids.indexOf(g.data[i] & 0x0fff); if (j >= 0) out[j]++; }
    return { out, data: g.data, cx, cz };
  };
  await test('trial chambers: procedural layout is deterministic, connected and stocked', () => {
    const a = chamberLayout(4242, 100, -30, 200), b = chamberLayout(4242, 100, -30, 200), c = chamberLayout(4243, 100, -30, 200);
    assert.equal(a, b, 'cached');
    assert.notDeepEqual(a.rooms.map(r => [r.gx, r.gz]), c.rooms.map(r => [r.gx, r.gz]), 'different seed → different maze');
    for (const seed of [1, 2, 3, 4, 5, 6, 7, 8]) {
      const L = chamberLayout(seed * 977, 0, -30, 0);
      assert.ok(L.rooms.length >= 9 && L.rooms.length <= 13, 'room count ' + L.rooms.length);
      assert.equal(L.rooms[0].type, 'atrium');
      assert.equal(L.rooms.filter(r => r.type === 'ominous').length, 1);
      assert.ok(L.spawners.length >= 6, 'spawners ' + L.spawners.length);
      assert.ok(L.vaults.filter(v => !v.ominous).length >= 2 && L.vaults.filter(v => v.ominous).length === 1);
      assert.ok(L.chests.length >= 2);
      const seen = new Set(['0,0']), queue = [L.rooms[0]];                 // every room is reachable through the corridors
      while (queue.length) {
        const r = queue.pop()!;
        [[0, -1], [1, 0], [0, 1], [-1, 0]].forEach(([dx, dz], d) => {
          if (!(r.links & (1 << d))) return;
          const n = L.rooms.find(o => o.gx === r.gx + dx && o.gz === r.gz + dz);
          assert.ok(n, 'a link leads to a room');
          assert.ok(n!.links & (1 << ((d + 2) % 4)), 'links are symmetric');
          if (!seen.has(n!.gx + ',' + n!.gz)) { seen.add(n!.gx + ',' + n!.gz); queue.push(n!); }
        });
      }
      assert.equal(seen.size, L.rooms.length, 'connected');
    }
  });
  await test('trial chambers: generated underground from tuff and copper with spawners and a vault', () => {
    const p = locateExtra(terrain, 'trial_chambers', 0, 0);
    assert.ok(p, 'a trial chamber exists near the origin');
    assert.ok(p![1] <= -22 && p![1] >= -38, 'buried deep: y=' + p![1]);
    const { out, data, cx, cz } = countIn(terrain, p![0], p![2], ['tuff_bricks', 'polished_tuff', 'copper_block', 'cut_copper', 'chiseled_copper', 'trial_spawner', 'vault', 'copper_bulb_lit']);
    assert.ok(out[0] > 60, 'tuff bricks ' + out[0]);
    assert.ok(out[1] > 20 && out[2] + out[3] + out[4] > 8, 'polished tuff + copper');
    assert.ok(out[5] >= 1, 'trial spawner in the atrium chunk');
    assert.ok(out[7] >= 1, 'copper bulbs light the rooms');
    assert.equal(data[blockIndex(p![0] - cx * 16, p![1], p![2] - cz * 16)] & 0x0fff, I.vault, 'vault at the atrium centre');
    assert.equal(data[blockIndex(p![0] - cx * 16, p![1] + 1, p![2] - cz * 16)] & 0x0fff, 0, 'air above the vault');
    assert.equal(extraLootTable(terrain, p![0] + 3, p![1], p![2] + 3), 'trial_chambers');
  });
  await test('structures: ruined portal, ocean ruins, buried treasure, trail ruins, ancient city, shipwreck and bastion are placed', () => {
    const found: Record<string, [number, number, number] | null> = {};
    for (const kind of ['ruined_portal', 'ocean_ruin', 'buried_treasure', 'trail_ruins', 'ancient_city', 'shipwreck']) found[kind] = locateExtra(terrain, kind, 0, 0);
    for (const [kind, p] of Object.entries(found)) assert.ok(p, kind + ' can be located');
    const portal = countIn(terrain, found.ruined_portal![0], found.ruined_portal![2], ['obsidian', 'crying_obsidian', 'netherrack']).out;
    assert.ok(portal[0] + portal[1] >= 3 && portal[2] >= 3, 'ruined portal blocks ' + portal);
    const bt = found.buried_treasure!, chunk = countIn(terrain, bt[0], bt[2], ['chest']);
    assert.equal(chunk.data[blockIndex(bt[0] - chunk.cx * 16, bt[1], bt[2] - chunk.cz * 16)] & 0x0fff, I.chest, 'treasure chest');
    assert.notEqual(chunk.data[blockIndex(bt[0] - chunk.cx * 16, bt[1] + 1, bt[2] - chunk.cz * 16)] & 0x0fff, 0, 'the chest is buried');
    assert.equal(extraLootTable(terrain, bt[0], bt[1], bt[2]), 'buried_treasure');
    const ruin = countIn(terrain, found.ocean_ruin![0], found.ocean_ruin![2], ['suspicious_sand', 'suspicious_gravel', 'chest', 'stone_bricks', 'sandstone', 'cut_sandstone', 'mossy_stone_bricks']).out;
    assert.ok(ruin[0] + ruin[1] >= 1, 'ocean ruins hide suspicious blocks ' + ruin);
    assert.ok(ruin[3] + ruin[4] + ruin[5] + ruin[6] >= 4, 'ruined walls');
    const trail = countIn(terrain, found.trail_ruins![0], found.trail_ruins![2], ['suspicious_gravel', 'mud_bricks', 'gravel']).out;
    assert.ok(trail[0] >= 1 && trail[1] >= 5, 'trail ruins: suspicious gravel + mud bricks ' + trail);
    const nether = new Terrain('tricky-trials', 'nether');
    assert.ok(locateExtra(nether, 'bastion', 0, 0), 'bastion remnant in the nether');
    assert.ok(locateExtra(nether, 'ruined_portal', 0, 0), 'ruined portal in the nether');
    for (const table of Object.values(EXTRA_LOOT)) for (const [name] of table.items) assert.ok(resolve(name), 'loot item exists: ' + name);
  });

  // ===== explorer map: asynchronous structure search =======================================================================
  await test('explorer map: the search is time-sliced and finds the same site as the blocking locate', async () => {
    for (const kind of ['trial_chambers', 'buried_treasure', 'monument']) {
      let yields = 0;
      const job = searchStructure(terrain, kind, 40, -25, { budgetMs: 0, schedule: fn => { yields++; setTimeout(fn, 0); } });
      assert.equal(job.done, false, 'nothing runs synchronously');
      const found = await job.promise, direct = locateExtra(terrain, kind, 40, -25);
      assert.ok(job.done);
      assert.deepEqual(found, direct, kind + ' matches locateExtra');
      assert.ok(yields >= 2 && yields === job.slices, `${kind}: yielded to the event loop ${yields} times`);
      assert.ok(job.regionsScanned >= 1 && job.regionsScanned < 23 * 23, 'stops early once the nearest site is certain');
      assert.ok(job.maxSliceMs < 50, `${kind}: no slice blocks for long (${job.maxSliceMs.toFixed(1)} ms)`);
    }
    const gen = ringSearch(terrain, 'mansion', 0, 0, 1);
    let steps = 0; while (!gen.next().done) steps++;
    assert.equal(steps, 9, 'rings 0 and 1 = 9 regions, one yield each');
    const cancelled = searchStructure(terrain, 'mansion', 0, 0, { budgetMs: 0 });
    cancelled.cancel();
    assert.equal(await cancelled.promise, null);
    assert.equal(regionSize('monument'), 224);
    assert.equal(await searchStructure(new Terrain('tricky-trials', 'end'), 'monument', 0, 0).promise, null, 'no monuments in the End');
  });
  await test('explorer map: cartographer map specs and the target description', () => {
    assert.deepEqual(EXPLORER_MAPS.map(m => m.kind).sort(), ['buried_treasure', 'mansion', 'monument', 'trial_chambers']);
    for (const m of EXPLORER_MAPS) assert.ok(resolve(m.item) && m.level >= 2 && m.level <= 5);
    const stack = mapStack(EXPLORER_MAPS[0], 320, -640);
    assert.deepEqual(stack.map, { kind: 'monument', x: 320, z: -640, icon: 'monument' });
    assert.deepEqual(describeTarget(0, 0, 0, -100), { distance: 100, ja: '北', en: 'N' });
    assert.equal(describeTarget(0, 0, 100, 100).en, 'SE');
    assert.equal(describeTarget(10, 10, -90, 10).en, 'W');
  });

  // ===== trial spawner ======================================================================================================
  await test('trial spawner: difficulty scales with the number of players', () => {
    assert.deepEqual(scaling('melee', 1), { total: 6, simultaneous: 3 });
    assert.deepEqual(scaling('melee', 2), { total: 8, simultaneous: 3 });
    assert.deepEqual(scaling('melee', 3), { total: 10, simultaneous: 4 });
    assert.deepEqual(scaling('breeze', 1), { total: 2, simultaneous: 1 });
    assert.deepEqual(scaling('breeze', 4), { total: 5, simultaneous: 2 });
    assert.deepEqual(scaling('breeze', 1, true), { total: 4, simultaneous: 2 });
    assert.deepEqual(spawnerProfile(5, -30, 9, 77), spawnerProfile(5, -30, 9, 77));
    assert.equal(spawnerProfile(5, -30, 9, 77, 'breeze').species, 'breeze');
  });
  await test('trial spawner: waves, reward ejection and the 30 minute cooldown', () => {
    const t = trials(), s = t.spawner();
    t.advance(1);
    assert.equal(s.phase, 'waiting'); assert.equal(t.alive.size, 0);
    t.ctx.players = [{ id: 'A', omen: 0 }];
    t.advance(0.5);
    assert.equal(s.phase, 'active');
    assert.equal(t.states.get('0,0,0'), 2);
    t.advance(20);
    assert.equal(t.alive.size, 3, 'at most 3 alive at once for one player');
    let guard = 0;
    while (s.phase === 'active' && guard++ < 40) { t.killAll(); t.advance(2.5); }
    assert.equal(t.ctx.spawned, 6, 'exactly 6 mobs for one player');
    assert.equal(t.ctx.maxAlive, 3);
    assert.equal(t.ejected.length + s.queue.length, 1, 'one reward per player');
    t.advance(4);
    assert.equal(s.phase, 'cooldown');
    assert.equal(t.states.get('0,0,0'), 4);
    assert.equal(t.ejected.length, 1); assert.equal(t.ejected[0].from, 'spawner');
    assert.ok(Math.abs(s.cooldownUntil - t.ctx.now - TRIAL_COOLDOWN_SEC) < 6);
    t.advance(TRIAL_COOLDOWN_SEC - 30);
    assert.equal(s.phase, 'cooldown', 'still inactive after 29½ minutes even with the player standing next to it');
    assert.equal(t.ctx.spawned, 6);
    t.advance(40);
    assert.equal(s.phase, 'active', 'a new trial starts after the cooldown');
    assert.ok(t.events.count('trial_spawner_state') >= 4);
  });
  await test('trial spawner: more players → more mobs and one reward each; despawned mobs are replaced', () => {
    const t = trials(), s = t.spawner();
    t.ctx.players = [{ id: 'A', omen: 0 }, { id: 'B', omen: 0 }, { id: 'C', omen: 0 }];
    t.advance(30);
    assert.equal(t.alive.size, 4, '4 at once for three players');
    const lost = [...t.alive][0];
    t.alive.delete(lost);                                               // vanished without dying
    t.advance(3);
    assert.equal(t.alive.size, 4, 'the lost mob was summoned again');
    assert.equal(s.killed, 0);
    let guard = 0;
    while (s.phase === 'active' && guard++ < 60) { t.killAll(); t.advance(2.5); }
    assert.equal(s.killed, 10, '10 kills needed for three players');
    t.advance(8);
    assert.equal(t.ejected.length, 3, 'one reward per participant');
    assert.equal(s.phase, 'cooldown');
    const copy = trials();
    copy.blocks.set('0,0,0', 'spawner'); copy.ctx.now = t.ctx.now;
    copy.sys.load(JSON.parse(JSON.stringify(t.sys.save())));
    assert.equal(copy.sys.spawnerAt(0, 0, 0)?.phase, 'cooldown', 'cooldown survives save / load');
    assert.equal(copy.sys.spawnerAt(0, 0, 0)?.cooldownUntil, s.cooldownUntil);
    t.blocks.set('0,0,0', null); t.advance(1);
    assert.ok(t.sys.spawnerAt(0, 0, 0), 'unloaded chunk: state is kept');
    t.blocks.set('0,0,0', 'other'); t.advance(1);
    assert.equal(t.sys.spawnerAt(0, 0, 0), undefined, 'broken spawner is forgotten');
  });
  await test('trial spawner: Bad Omen switches a running trial to an ominous one', () => {
    const t = trials(), s = t.spawner(0, 'breeze');
    t.ctx.players = [{ id: 'A', omen: 0 }];
    t.advance(6);
    assert.equal(t.alive.size, 1); assert.equal(s.ominous, false);
    t.ctx.players = [{ id: 'A', omen: 1 }];
    t.advance(0.5);
    assert.equal(s.ominous, true);
    assert.deepEqual(t.omens, ['A']);
    assert.equal(t.removed.length, 1, 'the normal wave is removed');
    assert.equal(t.states.get('0,0,0'), 2 + 8, 'ominous flag in the cell state');
    t.advance(20);
    assert.equal(t.alive.size, 2, 'ominous breeze spawner: two at once');
    let guard = 0;
    while (s.phase === 'active' && guard++ < 40) { t.killAll(); t.advance(2.5); }
    assert.equal(s.killed, 4);
    t.advance(5);
    assert.equal(t.omens.length, 1, 'omen is consumed once');
    t.advance(TRIAL_COOLDOWN_SEC + 5);
    assert.equal(s.ominous, true, 'the player still has the omen, so the next trial is ominous again');
    t.ctx.players = [];
    const u = trials(), s2 = u.spawner();
    u.ctx.players = [{ id: 'Z', omen: 0 }];
    u.advance(3); u.killAll(); u.advance(60);
    assert.equal(s2.ominous, false);
  });

  // ===== vault ==============================================================================================================
  await test('vault: trial key unlocks it exactly once per player UUID', () => {
    const t = trials();
    t.blocks.set('0,0,5', 'vault'); t.blocks.set('0,0,9', 'ominous_vault');
    const v = t.sys.registerVault(0, 0, 5, false);
    t.sys.registerVault(0, 0, 9, true);
    t.ctx.players = [{ id: 'A', omen: 0 }];
    t.advance(0.5);
    assert.equal(v.phase, 'active'); assert.equal(t.states.get('0,0,5'), 1);
    assert.deepEqual(t.sys.tryUnlock(0, 0, 5, 'A', undefined), { ok: false, reason: 'no_key' });
    assert.deepEqual(t.sys.tryUnlock(0, 0, 5, 'A', 'stick'), { ok: false, reason: 'no_key' });
    assert.deepEqual(t.sys.tryUnlock(0, 0, 5, 'A', 'ominous_trial_key'), { ok: false, reason: 'wrong_key' });
    assert.deepEqual(t.sys.tryUnlock(0, 0, 5, 'A', 'trial_key'), { ok: true, consume: 'trial_key' });
    assert.deepEqual(t.sys.tryUnlock(0, 0, 5, 'B', 'trial_key'), { ok: false, reason: 'busy' });
    t.advance(8);
    const loot = t.ejected.filter(e => e.from === 'vault');
    assert.ok(loot.length >= 2 && loot.length <= 3, 'vault ejected ' + loot.length + ' stacks');
    for (const e of loot) assert.ok(resolve(e.reward.item), e.reward.item);
    assert.deepEqual(t.sys.tryUnlock(0, 0, 5, 'A', 'trial_key'), { ok: false, reason: 'already' });
    assert.equal(v.phase, 'inactive', 'nothing left for player A');
    assert.deepEqual(v.rewarded, ['A']);
    assert.deepEqual(t.sys.tryUnlock(0, 0, 5, 'B', 'trial_key'), { ok: true, consume: 'trial_key' });
    t.advance(8);
    assert.deepEqual(v.rewarded, ['A', 'B']);
    assert.deepEqual(t.sys.tryUnlock(0, 0, 9, 'A', 'trial_key'), { ok: false, reason: 'wrong_key' });
    assert.deepEqual(t.sys.tryUnlock(0, 0, 9, 'A', 'ominous_trial_key'), { ok: true, consume: 'ominous_trial_key' });
    const copy = trials();
    copy.sys.load(JSON.parse(JSON.stringify(t.sys.save())));
    assert.deepEqual(copy.sys.tryUnlock(0, 0, 5, 'A', 'trial_key'), { ok: false, reason: 'already' }, 'the ledger is saved');
    assert.equal(t.events.count('vault_denied') >= 5, true);
    const rng = seeded(5);
    for (let i = 0; i < 200; i++) assert.ok(rollVault(true, rng).filter(r => r.item === 'heavy_core').length <= 1);
  });

  // ===== mace ===============================================================================================================
  await test('mace: Density, Breach and Wind Burst maths', () => {
    assert.equal(maceSmashBonus(3), 12); assert.equal(maceSmashBonus(8), 22); assert.equal(maceSmashBonus(10), 24);
    assert.equal(densityBonus(5, 10), 25); assert.equal(densityBonus(1, 4), 2);
    assert.equal(smashDamage(1, 5), 0, 'no smash below 1.5 blocks');
    assert.equal(smashDamage(10, 5), 49);
    assert.ok(Math.abs(breachFactor(1) + 0.15) < 1e-9 && Math.abs(breachFactor(4) + 0.6) < 1e-9);
    assert.equal(damageAfterArmor(20, 0), 20);
    assert.equal(damageAfterArmor(20, 20), 12);
    const b1 = damageAfterArmor(20, 20, 1), b4 = damageAfterArmor(20, 20, 4);
    assert.ok(Math.abs(b1 - 15) < 1e-9 && b4 === 20, `breach: absorbed 0.40 − 0.15·level → ${b1} ${b4}`);
    const apex = (v: number) => { let y = 0, top = 0; for (let i = 0; i < 400 && v > -0.5; i++) { y += v; top = Math.max(top, y); v = (v - 0.08) * 0.98; } return top; };
    for (const l of [1, 2, 3]) assert.ok(Math.abs(apex(windBurstVelocity(l) / 20) - 8 * l) < 0.05, 'launch height ≈ 8 blocks per level (wiki): ' + apex(windBurstVelocity(l) / 20));
    void PLAYER_GRAVITY;
    assert.equal(windBurstVelocity(0), 0);
    const k = windKnockback(0, 0, 0, 2, 0, 0);
    assert.ok(k && k[0] > 0 && k[1] > 0 && k[2] === 0, 'pushed away and up');
    assert.equal(windKnockback(0, 0, 0, 9, 0, 0), null);
  });
  await test('mace: Breach ignores 15% of a mob\'s armor per level on a real hit', () => {
    const w = world(), shulker = w.spawn('shulker', 2, 0);
    assert.equal(mobArmor('shulker'), 20);
    w.mobs.behaviors.breach = 0;
    const plain = w.mobs.behaviors.modifyDamage(shulker, 20, true);
    w.mobs.behaviors.breach = 4;
    const breached = w.mobs.behaviors.modifyDamage(shulker, 20, true);
    assert.equal(plain, 12); assert.equal(breached, 20);
    assert.equal(w.mobs.behaviors.modifyDamage(shulker, 20, false), 12, 'breach only applies to the melee hit');
    const cow = w.spawn('cow', 4, 0);
    assert.equal(w.mobs.behaviors.modifyDamage(cow, 7, true), 7, 'unarmored mobs take full damage');
    const ominous = w.spawn('skeleton', 6, 0); ominous.bonusArmor = 8;
    assert.ok(w.mobs.behaviors.modifyDamage(ominous, 10, false) < 10, 'ominous trial mobs wear armor');
  });

  // ===== 1.21 status effects ================================================================================================
  await test('effects: Oozing, Weaving and Wind Charged trigger on death, Infested on damage', () => {
    const w = world(), b = w.mobs.behaviors;
    const z = w.spawn('zombie', 3, 3), bystander = w.spawn('cow', 4.5, 3), before = bystander.group.position.clone();
    assert.ok(b.applyEffect(z, 'oozing', 60) && b.applyEffect(z, 'weaving', 60) && b.applyEffect(z, 'wind_charged', 60));
    assert.equal(b.applyEffect(z, 'speed', 60), false);
    w.mobs.extraDamage(z, 100);
    assert.ok(!w.mobs.mobs.includes(z), 'zombie died');
    assert.equal(w.mobs.mobs.filter(m => m.species === 'slime').length, 2, 'Oozing: two slimes');
    const webs = w.count('cobweb');
    assert.ok(webs >= 2 && webs <= 3, 'Weaving: 2–3 cobwebs, got ' + webs);
    assert.ok(bystander.group.position.distanceTo(before) > 0.5, 'Wind Charged: the burst pushed the cow');
    assert.equal(w.flags.knocked, 0, 'player is out of range');
    assert.equal(w.events.count('wind_burst'), 1);
    assert.deepEqual(w.events.recent.filter(e => e.type === 'effect_trigger').map(e => (e.payload as { effect: string }).effect).sort(), ['oozing', 'weaving', 'wind_charged']);
    const s = w.spawn('skeleton', -4, -4);
    b.applyEffect(s, 'infested', 60);
    w.mobs.rnd = () => 0.05;                                            // below the 10 % chance
    b.modifyDamage(s, 2, false);
    const fish = w.mobs.mobs.filter(m => m.species === 'silverfish').length;
    assert.ok(fish >= 1 && fish <= 2, 'Infested: 1–2 silverfish, got ' + fish);
    w.mobs.rnd = () => 0.9;
    b.modifyDamage(s, 2, false);
    assert.equal(w.mobs.mobs.filter(m => m.species === 'silverfish').length, fish, 'no spawn above the chance');
    assert.equal(b.splash(new THREE.Vector3(-4, 64, -4), 'weaving', 30) >= 1, true);
    assert.ok(s.fx?.weaving);
    b.pre(s, 31, 1);
    assert.equal(s.fx?.weaving, undefined, 'effects time out');
    assert.equal(cobwebSpeedFactor(true, false), COBWEB_SLOW);
    assert.equal(cobwebSpeedFactor(true, true), 0.5, 'Weaving: cobwebs slow to 50 % instead of 25 % (Java 1.21)');
    assert.equal(cobwebSpeedFactor(false, false), 1);
  });

  // ===== enderman ===========================================================================================================
  await test('enderman: picks up and places blocks, flees water and rain, dodges projectiles', () => {
    const w = world(), e = w.spawn('enderman', 0, 0), b = w.mobs.behaviors;
    w.set(1, 64, 0, 'poppy');
    for (let x = -3; x <= 3; x++) for (let z = -3; z <= 3; z++) w.set(x, 63, z, 'stone');   // only the flower is holdable nearby
    assert.equal(b.endermanBlock(e, true), true);
    assert.equal(e.carried, I.poppy); assert.equal(w.blockAt(1, 64, 0), 'air');
    assert.equal(b.endermanBlock(e, true), true);
    assert.equal(e.carried, undefined); assert.equal(w.count('poppy'), 1, 'the flower was set down again');
    assert.equal(w.events.count('enderman_block'), 2);
    w.set(0, 64, 0, 'water');
    const hp = e.hp, from = e.group.position.clone();
    assert.equal(b.pre(e, 0.6, 1), false);
    assert.equal(e.hp, hp - 1, 'water hurts');
    assert.ok(e.group.position.distanceTo(from) >= 3, 'teleported out of the water');
    assert.notEqual(w.blockAt(e.group.position.x, e.group.position.y, e.group.position.z), 'water');
    w.flags.rain = true;
    const hp2 = e.hp;
    b.pre(e, 0.6, 1);
    assert.equal(e.hp, hp2 - 1, 'rain hurts under the open sky');
    w.flags.rain = false;
    const p2 = e.group.position.clone();
    assert.equal(b.dodgeProjectile(e), true);
    assert.ok(e.group.position.distanceTo(p2) >= 3, 'emergency teleport when an arrow arrives');
    assert.equal(e.state, 'chase');
    assert.equal(b.dodgeProjectile(w.spawn('zombie', 9, 9)), false);
    w.mobs.shootPlayerArrow(e.group.position.clone().add(new THREE.Vector3(0, 0.9, -3)), new THREE.Vector3(0, 0, 1), 26, 7);
    const hp3 = e.hp;
    for (let i = 0; i < 30; i++) w.mobs.update(1 / 60, 1, true);
    assert.equal(e.hp, hp3, 'a direct arrow hit never damages an enderman');
    e.carried = I.sand;
    w.mobs.kill(e);
    assert.ok(w.drops.some(d => d.name === 'sand'), 'the carried block is dropped on death');
    assert.deepEqual(w.events.recent.filter(x => x.type === 'enderman_teleport').map(x => (x.payload as { cause: string }).cause).slice(0, 3), ['water', 'rain', 'projectile']);
  });

  // ===== charged creeper ====================================================================================================
  await test('charged creeper: lightning charges it, the blast doubles and victims drop heads', () => {
    assert.equal(creeperRadius(false), 3); assert.equal(creeperRadius(true), 6);
    assert.ok(explosionDamage(6, 2) > explosionDamage(3, 2) && explosionDamage(3, 0) === 43 && explosionDamage(6, 0) === 85, 'Java explosion damage: creeper 43, charged creeper 85 at the centre');
    const w = world(), b = w.mobs.behaviors;
    const far = w.spawn('creeper', 30, 30), c = w.spawn('creeper', 0, 0), pig = w.spawn('pig', 1, 1);
    assert.equal(b.lightning(new THREE.Vector3(0.5, 64, 0.5)), 1);
    assert.equal(c.charged, true); assert.equal(far.charged, undefined);
    assert.ok(!w.mobs.mobs.includes(pig) || pig.species !== 'pig', 'lightning zombifies pigs');
    assert.ok(w.mobs.mobs.some(m => m.species === 'zombified_piglin'));
    assert.equal(w.events.count('creeper_charged'), 1);
    assert.equal(b.lightning(c.group.position.clone(), true), 0, 'already charged');
    assert.equal(w.mobs.save().find(s => s.id === c.id)?.extra?.charged, true, 'the charge is saved');
    for (const m of w.mobs.mobs.filter(x => x.species === 'zombified_piglin')) w.mobs.kill(m);
    w.drops.length = 0;
    const zombie = w.spawn('zombie', 2, 0), skeleton = w.spawn('skeleton', 0, 2);
    b.creeperExplode(c);
    assert.deepEqual(w.explosions, [6], 'charged blast radius');
    assert.ok(!w.mobs.mobs.includes(zombie) && !w.mobs.mobs.includes(skeleton), 'both victims died');
    const heads = w.drops.filter(d => /_head$|_skull$/.test(d.name));
    assert.equal(heads.length, 1, 'exactly one head per explosion');
    assert.ok(['zombie_head', 'skeleton_skull'].includes(heads[0].name));
    assert.equal(w.events.count('mob_head_drop'), 1);
    const w2 = world(), plain = w2.spawn('creeper', 0, 0), z2 = w2.spawn('zombie', 4, 0), ws = w2.spawn('wither_skeleton', 0, 1.5);
    ws.hp = 1;
    w2.mobs.behaviors.creeperExplode(plain);
    assert.deepEqual(w2.explosions, [3]);
    assert.ok(w2.mobs.mobs.includes(z2), 'a normal blast at 4 blocks (≈10 damage) does not kill a zombie');
    assert.equal(w2.drops.filter(d => /_head$|_skull$/.test(d.name)).length, 0, 'no heads without a charge');
    const w3 = world(), cc = w3.spawn('creeper', 0, 0), v3 = w3.spawn('wither_skeleton', 1, 0), c3 = w3.spawn('creeper', 30, 0);
    cc.charged = true; v3.hp = 1; c3.hp = 1;
    assert.equal(w3.mobs.behaviors.blast(new THREE.Vector3(0, 64, 0), 6, true, cc), 'wither_skeleton_skull');
    assert.equal(w3.mobs.behaviors.blast(new THREE.Vector3(30, 64, 0), 6, true, null), 'creeper_head');
  });

  // ===== turtle =============================================================================================================
  await test('turtle: homes to its beach, lays eggs that hatch, babies shed scutes', () => {
    const w = world(), b = w.mobs.behaviors;
    for (let x = 7; x <= 13; x++) for (let z = -3; z <= 3; z++) w.set(x, 63, z, 'sand');
    const t = w.spawn('turtle', 0.5, 0.5);
    t.home = [10, 64, 0];
    t.pregnant = true;
    let frames = 0;
    while (w.count('turtle_egg') === 0 && frames++ < 4000) assert.equal(b.pre(t, 0.05, 1), true, 'a pregnant turtle is fully driven by the behaviour');
    assert.equal(w.count('turtle_egg'), 1, 'eggs laid after ' + frames + ' frames');
    assert.equal(t.pregnant, false);
    const [ex, ey, ez] = t.home!;
    assert.equal(w.blockAt(ex, ey, ez), 'turtle_egg'); assert.equal(w.blockAt(ex, ey - 1, ez), 'sand', 'laid on sand');
    assert.ok(Math.hypot(ex - 10, ez) <= 3, 'near the home beach');
    const eggs = (w.getCell(ex, ey, ez) >> 12 & 3) + 1;
    assert.ok(eggs >= 1 && eggs <= 4);
    assert.equal(w.events.last('turtle_lay')?.eggs, eggs);
    let state = eggs - 1, hatch = 0, ticks = 0;
    while (!hatch && ticks++ < 10) { const r = tickTurtleEgg(state, true, () => 0); state = r.state; hatch = r.hatch; }
    assert.equal(ticks, 3, 'two cracks, then the eggs hatch');
    assert.equal(hatch, eggs);
    assert.deepEqual(tickTurtleEgg(2, false, () => 0.5), { state: 2, hatch: 0 }, 'by day eggs almost never progress');
    assert.deepEqual(tickTurtleEgg(2, true, () => 0.04), { state: 2 | 4, hatch: 0 }, 'at night they crack quickly');
    const stray = w.spawn('turtle', 60, 0);
    stray.home = [10, 64, 0];
    const d0 = Math.hypot(60 - 10.5, 0.5);
    for (let i = 0; i < 100; i++) assert.equal(b.pre(stray, 0.05, 1), true);
    assert.ok(Math.hypot(stray.group.position.x - 10.5, stray.group.position.z - 0.5) < d0 - 1, 'homing instinct walks it back');
    const baby = w.spawn('turtle', 20, 20, true);
    b.pre(baby, 0.05, 1);
    baby.baby = false;
    w.drops.length = 0;
    b.pre(baby, 0.05, 1);
    assert.deepEqual(w.drops.map(d => d.name), ['scute'], 'a scute drops when the baby grows up');
    b.pre(baby, 0.05, 1);
    assert.equal(w.drops.length, 1, 'only once');
  });

  // ===== bee ================================================================================================================
  await test('bee: leaves the nest, pollinates, fertilises crops on the way home and fills the hive', () => {
    const w = world(), b = w.mobs.behaviors;
    w.set(0, 66, 0, 'bee_nest'); w.set(6, 64, 0, 'poppy'); w.set(3, 64, 0, 'wheat_crop');
    const bee = w.spawn('bee', 1.5, 1.5, false, 65);
    let frames = 0;
    const run = (until: () => boolean, max = 3000) => { while (!until() && frames++ < max) b.pre(bee, 0.05, 1); assert.ok(until(), 'reached within ' + max + ' frames'); };
    run(() => !!bee.pollinating);
    assert.deepEqual(bee.hive, [0, 66, 0], 'found its nest');
    assert.ok(bee.group.position.distanceTo(new THREE.Vector3(6.5, 64.75, 0.5)) < 0.5, 'hovering on the flower');
    run(() => !!bee.nectar);
    assert.equal(w.events.count('bee_pollinate'), 1);
    run(() => (bee.inHive ?? 0) > 0);
    assert.equal(w.flags.grown, 1, 'the wheat under its path got a bone-meal tick');
    assert.equal(bee.group.visible, false, 'inside the hive');
    assert.equal(w.getCell(0, 66, 0) >> 12, 0);
    run(() => !bee.inHive);
    assert.equal(bee.group.visible, true);
    assert.equal(w.getCell(0, 66, 0) >> 12, 1, 'honey level went up');
    assert.equal(w.events.last('hive_honey')?.level, 1);
    for (let trip = 0; trip < 6; trip++) { frames = 0; run(() => (bee.inHive ?? 0) > 0); run(() => !bee.inHive); }
    assert.equal(w.getCell(0, 66, 0) >> 12, HIVE_MAX_HONEY, 'honey is capped at 5');
    frames = 0;
    for (let i = 0; i < 600; i++) b.pre(bee, 0.05, 0.1);                 // night: go home and stay
    assert.ok((bee.inHive ?? 0) > 0, 'bees sleep in the hive at night');
    assert.equal(campfireBelow(w.host.getBlock, 0, 66, 0), false);
    assert.equal(b.angerHive(0, 66, 0), 1);
    assert.ok(bee.anger > 0 && bee.group.visible, 'harvesting without smoke angers the bees');
    w.set(0, 62, 0, 'campfire'); w.set(0, 65, 0, 'air'); w.set(0, 64, 0, 'air'); w.set(0, 63, 0, 'air');
    assert.equal(campfireBelow(w.host.getBlock, 0, 66, 0), true, 'a campfire up to 5 blocks below calms them');
    w.set(0, 64, 0, 'stone');
    assert.equal(campfireBelow(w.host.getBlock, 0, 66, 0), false, 'unless something solid blocks the smoke');
  });

  // ===== allay / sniffer / armadillo / wolf armor ===========================================================================
  await test('allay: collects the item it was given and delivers to the player or a note block', () => {
    const w = world(), b = w.mobs.behaviors, a = w.spawn('allay', 2, 2, false, 65);
    assert.equal(b.interact(a, 'diamond'), 'consume');
    assert.equal(a.wanted, 'diamond');
    w.drops.push({ name: 'diamond', count: 3, pos: new THREE.Vector3(8, 64.2, 2) }, { name: 'dirt', count: 9, pos: new THREE.Vector3(4, 64.2, 2) });
    let frames = 0;
    while (w.events.count('allay_deliver') === 0 && frames++ < 2000) assert.equal(b.pre(a, 0.05, 1), true);
    const d = w.events.last('allay_deliver')!;
    assert.deepEqual([d.item, d.count, d.to], ['diamond', 3, 'player']);
    assert.ok(a.group.position.distanceTo(w.position) < 3.5, 'came back to the player');
    assert.ok(w.drops.some(x => x.name === 'dirt' && x.count === 9), 'other items are ignored');
    w.drops.length = 0;
    w.set(12, 64, 2, 'note_block');
    b.noteBlockPlayed(12, 64, 2);
    assert.deepEqual(a.noteBlock, [12, 64, 2]);
    w.drops.push({ name: 'diamond', count: 2, pos: new THREE.Vector3(-6, 64.2, 2) });
    frames = 0;
    while (w.events.count('allay_deliver') < 2 && frames++ < 3000) b.pre(a, 0.05, 1);
    const d2 = w.events.last('allay_deliver')!;
    assert.deepEqual([d2.count, d2.to], [2, 'note_block']);
    assert.ok(Math.hypot(d2.x - 12.5, d2.z - 2.5) < 0.1, 'dropped onto the note block');
    for (let i = 0; i < 200; i++) b.pre(a, 0.05, 1);
    assert.equal(w.events.count('allay_deliver'), 2, 'it does not pick its own delivery back up');
    assert.equal(b.interact(a, ''), true);
    assert.equal(a.wanted, undefined);
  });
  await test('sniffer digs up ancient seeds; armadillo is brushed for scutes; wolf armor absorbs damage', () => {
    const w = world(), b = w.mobs.behaviors, s = w.spawn('sniffer', 0.5, 0.5);
    s.digCooldown = 0;
    assert.equal(b.pre(s, 0.05, 1), true);
    assert.equal(s.digging, true);
    let frames = 0;
    while (s.digging && frames++ < 200) b.pre(s, 0.05, 1);
    assert.ok(frames >= 85 && frames <= 95, 'digging takes ~4.5 s, took ' + frames + ' frames');
    assert.ok(['torchflower_seeds', 'pitcher_pod'].includes(w.drops[0].name), 'dug up ' + w.drops[0].name);
    assert.equal(w.events.count('sniffer_dig'), 1);
    s.digCooldown = 0;
    assert.equal(b.pre(s, 0.05, 1), false, 'never digs the same block twice');
    const stone = world(); for (let x = -2; x <= 2; x++) for (let z = -2; z <= 2; z++) stone.set(x, 63, z, 'stone');
    const s2 = stone.spawn('sniffer', 0.5, 0.5); s2.digCooldown = 0;
    assert.equal(stone.mobs.behaviors.pre(s2, 0.05, 1), false, 'stone is not diggable');
    const both = new Set<string>();
    for (let i = 0; i < 40; i++) { const wi = world(), si = wi.spawn('sniffer', 0.5, 0.5); wi.mobs.rnd = seeded((i + 1) * 97531); si.digCooldown = 0; for (let f = 0; f < 100; f++) wi.mobs.behaviors.pre(si, 0.05, 1); both.add(wi.drops[0]?.name); }
    assert.deepEqual([...both].sort(), ['pitcher_pod', 'torchflower_seeds']);

    w.drops.length = 0;
    const arm = w.spawn('armadillo', 5, 5);
    assert.equal(b.interact(arm, 'brush'), true);
    assert.deepEqual(w.drops.map(d => d.name), ['armadillo_scute']);
    assert.equal(b.interact(arm, 'stick'), null, 'only the brush works');
    arm.scuteTimer = 0.01;
    b.pre(arm, 0.05, 1);
    assert.equal(w.drops.length, 2, 'scutes are also shed over time');
    assert.ok(RECIPES.some(r => r.result === 'wolf_armor' && r.ingredients.armadillo_scute === 6), 'wolf armor = 6 armadillo scutes');
    assert.ok(RECIPES.some(r => r.result === 'brush'));

    const wolf = w.spawn('wolf', -5, 5);
    assert.equal(b.interact(wolf, 'wolf_armor'), null, 'wild wolves cannot wear armor');
    wolf.tamed = true;
    assert.equal(b.interact(wolf, 'wolf_armor'), 'consume');
    assert.equal(wolf.wolfArmor, WOLF_ARMOR_HP);
    const hp = wolf.hp;
    w.mobs.extraDamage(wolf, 10);
    assert.equal(wolf.hp, hp, 'the armor took the hit');
    assert.equal(wolf.wolfArmor, WOLF_ARMOR_HP - 10);
    assert.equal(b.interact(wolf, 'armadillo_scute'), 'consume');
    assert.equal(wolf.wolfArmor, WOLF_ARMOR_HP - 2, 'repaired with a scute');
    w.mobs.timeline += 1;   // 作業B: past the 10-tick invulnerability timer
    w.mobs.extraDamage(wolf, 200);
    assert.equal(wolf.wolfArmor, 0); assert.equal(wolf.hp, hp, 'the breaking hit is still absorbed');
    w.mobs.timeline += 1;   // 作業B: past the 10-tick invulnerability timer
    w.mobs.extraDamage(wolf, 3);
    assert.equal(wolf.hp, hp - 3, 'no armor left');
    wolf.wolfArmor = 20;
    assert.equal(b.interact(wolf, 'shears'), true);
    assert.ok(w.drops.some(d => d.name === 'wolf_armor'));
  });

  // ===== beacon & conduit ===================================================================================================
  await test('beacon: pyramid tiers 1–4 from mixed mineral blocks, powers and range', () => {
    const cells = new Map<string, number>(), get = (x: number, y: number, z: number) => cells.get(`${x},${y},${z}`) ?? 0;
    const layer = (l: number, name: string) => { for (let dz = -l; dz <= l; dz++) for (let dx = -l; dx <= l; dx++) cells.set(`${dx},${10 - l},${dz}`, I[name]); };
    assert.equal(beaconLevel(get, 0, 10, 0), 0);
    const mats = ['iron_block', 'gold_block', 'diamond_block', 'netherite_block'];
    for (let l = 1; l <= 4; l++) { layer(l, mats[l - 1]); assert.equal(beaconLevel(get, 0, 10, 0), l, 'tier ' + l); }
    cells.set('0,9,0', I.emerald_block);
    assert.equal(beaconLevel(get, 0, 10, 0), 4, 'emerald blocks count too');
    cells.set('3,7,3', I.stone);
    assert.equal(beaconLevel(get, 0, 10, 0), 2, 'a hole in layer 3 drops it to tier 2');
    cells.set('1,9,1', I.dirt);
    assert.equal(beaconLevel(get, 0, 10, 0), 0);
    assert.deepEqual([1, 2, 3, 4].map(beaconRange), [20, 30, 40, 50]);
    assert.deepEqual(beaconPowers(1), ['speed', 'haste']);
    assert.ok(beaconPowers(2).includes('resistance') && !beaconPowers(2).includes('strength') && beaconPowers(3).includes('strength'));
    assert.deepEqual(beaconEffects(1, 'haste', ''), [['haste', 11, 0]]);
    assert.deepEqual(beaconEffects(1, 'strength', ''), [], 'strength needs tier 3');
    assert.deepEqual(beaconEffects(4, 'strength', 'strength'), [['strength', 17, 1]], 'tier 4: level II');
    assert.deepEqual(beaconEffects(4, 'speed', 'regeneration'), [['speed', 17, 0], ['regeneration', 17, 0]]);

    cells.set('1,9,1', I.iron_block); cells.set('3,7,3', I.iron_block); cells.set('0,10,0', I.beacon);
    const applied: string[] = [], states: number[] = [], events = new EventBus(), player = { id: 'A', x: 30, y: 12, z: 0, wet: false };
    const sys = new BeaconSystem({ getBlock: get, setState: (_x, _y, _z, s) => { states.push(s); }, players: () => [player], addEffect: (_p, id, sec, amp) => { applied.push(`${id}:${sec}:${amp}`); }, hostilesInWater: () => [], damageMob() {}, emit: (t, p) => events.emit(t, p) });
    const beacon = sys.addBeacon(0, 10, 0);
    sys.update(0.1);
    assert.equal(beacon.level, 4); assert.deepEqual(states, [4]);
    assert.deepEqual(applied, ['speed:17:0'], 'player 30 blocks away is inside the tier-4 range');
    assert.ok(sys.cyclePower(beacon)); assert.equal(beacon.primary, 'haste');
    assert.ok(sys.cyclePower(beacon, true)); assert.equal(beacon.secondary, 'regeneration');
    applied.length = 0; sys.update(4);
    assert.deepEqual(applied, ['haste:17:0', 'regeneration:17:0']);
    player.x = 60; applied.length = 0; sys.update(4);
    assert.deepEqual(applied, [], 'out of range');
    cells.set('2,8,2', I.stone); player.x = 5; sys.update(4);
    assert.equal(beacon.level, 1); assert.equal(beacon.secondary, '', 'secondary power is lost below tier 4');
    assert.equal(events.last('beacon_state')?.range, 20);
    const copy = new BeaconSystem(sys.host); copy.load(JSON.parse(JSON.stringify(sys.save())));
    assert.equal(copy.beacons.get('0,10,0')?.primary, 'haste');
  });
  await test('conduit: 16–42 prismarine frame blocks in water, range and hostile hunting', () => {
    assert.equal(CONDUIT_FRAME_POSITIONS.length, 42);
    assert.equal(new Set(CONDUIT_FRAME_POSITIONS.map(p => p.join(','))).size, 42);
    const cells = new Map<string, number>(), get = (x: number, y: number, z: number) => cells.get(`${x},${y},${z}`) ?? I.water;
    const frame = (n: number, names = ['prismarine', 'prismarine_bricks', 'dark_prismarine', 'sea_lantern']) => { for (const k of [...cells.keys()]) if (k !== '0,0,0' && !k.startsWith('dry')) cells.delete(k); CONDUIT_FRAME_POSITIONS.slice(0, n).forEach(([x, y, z], i) => cells.set(`${x},${y},${z}`, I[names[i % names.length]])); };
    cells.set('0,0,0', I.conduit);
    frame(15); assert.deepEqual(conduitStatus(get, 0, 0, 0), { frame: 15, active: false, range: 0, hunting: false });
    frame(16); assert.deepEqual(conduitStatus(get, 0, 0, 0), { frame: 16, active: true, range: 32, hunting: false });
    frame(30); assert.equal(conduitStatus(get, 0, 0, 0).range, 64);
    frame(42); assert.deepEqual(conduitStatus(get, 0, 0, 0), { frame: 42, active: true, range: 96, hunting: true });
    cells.set('1,0,0', 0);
    assert.equal(conduitStatus(get, 0, 0, 0).active, false, 'needs a full 3×3×3 of water');
    cells.delete('1,0,0');
    const applied: string[] = [], hits: [number, number][] = [], player = { id: 'A', x: 40, y: 0, z: 0, wet: true };
    const sys = new BeaconSystem({ getBlock: get, setState() {}, players: () => [player], addEffect: (_p, id) => { applied.push(id); }, hostilesInWater: (_x, _y, _z, r) => (r === 8 ? [7, 9] : []), damageMob: (id, d) => { hits.push([id, d]); } });
    sys.addConduit(0, 0, 0);
    sys.update(0.1);
    assert.deepEqual(applied, ['conduit_power', 'water_breathing', 'night_vision', 'haste']);
    assert.deepEqual(hits, [[7, CONDUIT_ATTACK_DAMAGE], [9, CONDUIT_ATTACK_DAMAGE]], 'a full frame attacks hostile mobs in the water');
    player.wet = false; applied.length = 0; sys.update(2);
    assert.deepEqual(applied, [], 'only players in water or rain are buffed');
    frame(16); player.wet = true; hits.length = 0; applied.length = 0; sys.update(2);
    assert.deepEqual(hits, [], 'a small frame does not hunt');
    assert.deepEqual(applied, [], '40 blocks is outside the 32 block range');
  });

  // ===== archaeology ========================================================================================================
  await test('archaeology: brushing takes four strokes and loot is deterministic per block', () => {
    for (const [table, list] of Object.entries(ARCH_LOOT)) for (const [name, w] of list) assert.ok(resolve(name) && w > 0, `${table}: ${name}`);
    const sherds = new Set(Object.values(ARCH_LOOT).flat().map(([n]) => n).filter(n => n.endsWith('_pottery_sherd')));
    assert.equal(sherds.size, 23, 'every pottery sherd can be found');
    assert.equal(archaeologyRoll('trail_rare', 1234), archaeologyRoll('trail_rare', 1234));
    const seen = new Set<string>();
    for (let i = 0; i < 400; i++) seen.add(archaeologyRoll('ocean_cold', i * 7919));
    assert.equal(seen.size, ARCH_LOOT.ocean_cold.length, 'all entries are reachable');
    assert.equal(pickTable('suspicious_sand', 'ocean_ruin', false, 0.5), 'ocean_warm');
    assert.equal(pickTable('suspicious_gravel', 'ocean_ruin', false, 0.5), 'ocean_cold');
    assert.equal(pickTable('suspicious_gravel', 'trail_ruins', true, 0.1), 'trail_rare');
    assert.equal(pickTable('suspicious_gravel', 'trail_ruins', true, 0.9), 'trail_common');
    assert.ok((['desert_pyramid', 'desert_well'] as ArchTable[]).includes(pickTable('suspicious_sand', null, false, 0.7)));
    const brush = new BrushSession();
    assert.equal(brush.stroke('a', 0), 1);
    assert.equal(brush.stroke('a', 0.05), 0, 'strokes have a short cooldown');
    assert.equal(brush.stroke('a', 0.5), 2); assert.equal(brush.stroke('a', 1.0), 3);
    assert.equal(brush.stroke('b', 1.1), 1, 'moving to another block starts over');
    assert.equal(brush.stroke('a', 1.6), 1);
    for (let i = 1; i < BRUSH_STROKES; i++) brush.stroke('a', 1.6 + i);
    assert.equal(brush.strokes, BRUSH_STROKES);
  });
  await test('decorated pot stores exactly one stack of one item type', () => {
    let slot = potInsert(null, { name: 'emerald', count: 10 }, 64)!.slot;
    assert.deepEqual(slot, { name: 'emerald', count: 1 });
    assert.equal(potInsert(slot, { name: 'diamond', count: 1 }, 64), null, 'a second item type is refused');
    const bulk = potInsert(slot, { name: 'emerald', count: 100 }, 64, 100)!;
    assert.equal(bulk.moved, 63); assert.equal(bulk.slot.count, 64);
    slot = bulk.slot;
    assert.equal(potInsert(slot, { name: 'emerald', count: 5 }, 64), null, 'full at one stack');
    assert.equal(potInsert(null, { name: 'ender_pearl', count: 16 }, 16, 99)!.slot.count, 16, 'respects smaller stack sizes');
    assert.deepEqual(potInsert(null, { name: 'iron_sword', count: 1, durability: 50 }, 1)!.slot, { name: 'iron_sword', count: 1, durability: 50 });
  });

  // ===== smithing ===========================================================================================================
  await test('smithing: 18 templates (incl. 1.21 flow / bolt) × 10 materials and the duplication recipes', () => {
    assert.equal(TRIM_PATTERNS.length, 18); assert.equal(TRIM_MATERIALS.length, 10);
    assert.equal(TRIM_RECIPES.length, 180);
    assert.equal(new Set(TRIM_RECIPES.map(r => r.template + '+' + r.addition)).size, 180);
    for (const r of TRIM_RECIPES) assert.ok(resolve(r.template) && resolve(r.addition), r.template + ' + ' + r.addition);
    const armor = { name: 'diamond_chestplate', count: 1, durability: 300, ench: { protection: 4 } };
    const out = trimPreview({ name: 'sentry_armor_trim_smithing_template', count: 1 }, armor, { name: 'amethyst_shard', count: 3 });
    assert.deepEqual(out, { ...armor, trim: { pattern: 'sentry', material: 'amethyst' } }, 'the armor keeps its enchantments and durability');
    assert.equal(trimPreview({ name: 'sentry_armor_trim_smithing_template', count: 1 }, out, { name: 'amethyst_shard', count: 1 }), null, 'same trim twice is rejected');
    assert.deepEqual(trimPreview({ name: 'tide_armor_trim_smithing_template', count: 1 }, out, { name: 'gold_ingot', count: 1 })?.trim, { pattern: 'tide', material: 'gold' }, 'trims can be replaced');
    assert.equal(trimPreview({ name: 'sentry_armor_trim_smithing_template', count: 1 }, { name: 'diamond_sword', count: 1 }, { name: 'gold_ingot', count: 1 }), null, 'only armor');
    assert.equal(trimPreview({ name: 'sentry_armor_trim_smithing_template', count: 1 }, armor, { name: 'stick', count: 1 }), null);
    assert.equal(Object.keys(TEMPLATE_COPY_BLOCK).length, 19, '18 trims + netherite upgrade');
    for (const [template, blockName] of Object.entries(TEMPLATE_COPY_BLOCK)) {
      const r = RECIPES.find(x => x.id === 'copy_' + template);
      assert.ok(r, 'duplication recipe for ' + template);
      assert.equal(r!.result, template); assert.equal(r!.count, 2);
      assert.deepEqual(r!.ingredients, blockName === template ? r!.ingredients : { diamond: 7, [template]: 1, [blockName]: 1 });
      assert.ok(resolve(blockName), blockName);
    }
    for (const id of ['beacon', 'conduit', 'decorated_pot', 'beehive', 'mace', 'wind_charge', 'tuff_bricks']) assert.ok(RECIPES.some(r => r.id === id || r.result === id), id + ' recipe');
  });

  await test('slimes: sizes 1 / 2 / 4, health size², a big slime splits into 2–4 medium ones, small slimes drop slime balls', () => {
    const w = world();
    const big = w.spawn('slime', 0, 0);
    w.mobs.setSlimeSize(big, 4);
    assert.equal(big.maxHp, 16); assert.equal(big.size, 4);
    w.drops.length = 0;
    w.mobs.kill(big);
    const kids = w.mobs.mobs.filter(m => m.species === 'slime');
    assert.ok(kids.length >= 2 && kids.length <= 4, 'split into 2–4, got ' + kids.length);
    assert.ok(kids.every(k => k.size === 2 && k.maxHp === 4));
    assert.equal(w.drops.filter(d => d.name === 'slime_ball').length, 0, 'only size-1 slimes drop slime balls');
    const tiny = w.spawn('slime', 3, 3); w.mobs.setSlimeSize(tiny, 1);
    w.mobs.kill(tiny);
    assert.equal(w.mobs.mobs.filter(m => m.species === 'slime').length, kids.length, 'size 1 does not split');
    assert.equal(mobArmor('magma_cube', 0, 4), 12); assert.equal(mobArmor('iron_golem'), 0); assert.equal(mobArmor('zombie'), 2);
  });

  await test('loot tables: Java 1.21 drops (ranges, cooked meat, nothing for goats / camels, breeze rods)', () => {
    let s = 1; const rng = () => (s = (s * 16807) % 2147483647) / 2147483647;
    const sum = (species: string, n = 400, extra: Partial<Parameters<typeof rollMobLoot>[0]> = {}) => {
      const tot: Record<string, number> = {}, max: Record<string, number> = {};
      for (let i = 0; i < n; i++) for (const [item, c] of rollMobLoot({ species, rng, ...extra })) { tot[item] = (tot[item] ?? 0) + c; max[item] = Math.max(max[item] ?? 0, c); }
      return { tot, max };
    };
    const cow = sum('cow');
    assert.ok(cow.max.raw_beef === 3 && cow.max.leather === 2 && cow.tot.raw_beef / 400 > 1.7 && cow.tot.raw_beef / 400 < 2.3, JSON.stringify(cow));
    assert.ok(sum('cow', 50, { onFire: true }).tot.cooked_beef > 0 && !sum('cow', 50, { onFire: true }).tot.raw_beef);
    for (const none of ['goat', 'camel', 'armadillo', 'sniffer', 'bee', 'fox', 'wolf', 'villager', 'wandering_trader', 'dragon', 'piglin']) assert.deepEqual(rollMobLoot({ species: none, rng }), [], none);
    assert.ok(sum('breeze').tot.breeze_rod > 0 && !sum('breeze').tot.wind_charge);
    assert.deepEqual(rollMobLoot({ species: 'warden', rng }), [['sculk_catalyst', 1]]);
    const looted = sum('skeleton', 400, { looting: 3 });
    assert.ok(looted.max.bone === 5 && looted.tot.arrow > 0, 'Looting III: up to 2 + 3 bones');
    assert.ok(!sum('magma_cube', 200, { size: 1 }).tot.magma_cream && sum('magma_cube', 200, { size: 4 }).tot.magma_cream > 0);
    assert.deepEqual(rollMobLoot({ species: 'sheep', rng, wool: 'white_wool' }).find(e => e[0] === 'white_wool'), ['white_wool', 1]);
  });

  await test('fluids: Java heights (source 8/9, level n → (8 − n)/9, full under the same fluid) and FlowingFluid.getFlow', () => {
    assert.ok(Math.abs(fluidOwnHeight(0) - 8 / 9) < 1e-9 && Math.abs(fluidOwnHeight(7) - 1 / 9) < 1e-9 && fluidOwnHeight(8) === 8 / 9);
    const cells = new Map<string, number>(), k = (x: number, y: number, z: number) => `${x},${y},${z}`;
    const get = (x: number, y: number, z: number) => cells.get(k(x, y, z)) ?? (y < 0 ? I.stone : 0);
    cells.set(k(0, 0, 0), I.water); cells.set(k(1, 0, 0), I.water | (1 << 12)); cells.set(k(2, 0, 0), I.water | (2 << 12));
    assert.equal(fluidHeightAt(get, I.water, 0, 0, 0), 8 / 9);
    cells.set(k(0, 1, 0), I.water);
    assert.equal(fluidHeightAt(get, I.water, 0, 0, 0), 1, 'water above → full block');
    const f = fluidFlow(get, 1, 0, 0, id => id === I.stone);
    assert.ok(f[0] > 0.99 && Math.abs(f[2]) < 1e-9, 'level-1 water flows away from the source towards level 2: ' + f);
    const still = fluidFlow(get, 5, 0, 5, id => id === I.stone);
    assert.deepEqual([...still], [0, 0, 0]);
  });

  await test('trial rewards & vaults follow the wiki loot tables; ominous gear and item spawners', () => {
    let s = 7; const rng = () => (s = (s * 16807) % 2147483647) / 2147483647;
    let keys = 0;
    for (let i = 0; i < 2000; i++) { const r = rollSpawnerRewards(false, 2, rng); assert.equal(r.length, 2); if (r[0].item === 'trial_key') { keys++; assert.equal(r[1].item, 'trial_key', 'a key goes to every player'); } }
    assert.ok(keys > 900 && keys < 1100, 'normal spawner: 50 % keys, got ' + keys);
    for (let i = 0; i < 300; i++) for (const r of rollSpawnerRewards(false, 1, rng)) assert.ok(['trial_key', 'bread', 'cooked_chicken', 'baked_potato', 'potion_regeneration', 'potion_swiftness'].includes(r.item), r.item);
    for (let i = 0; i < 300; i++) for (const r of rollSpawnerRewards(true, 1, rng)) assert.ok(['ominous_trial_key', 'baked_potato', 'cooked_beef', 'golden_carrot', 'potion_regeneration', 'potion_strength'].includes(r.item), r.item);
    const seen = new Set<string>();
    for (let i = 0; i < 3000; i++) for (const r of rollVault(false, rng)) { seen.add(r.item); assert.ok(resolve(r.item), 'item exists: ' + r.item); if (r.item === 'shield') assert.ok(r.durability! >= 0.5 && r.durability! <= 1); }
    for (const it of ['emerald', 'bolt_armor_trim_smithing_template', 'music_disc_precipice', 'guster_banner_pattern', 'tipped_arrow_poison', 'trident']) assert.ok(seen.has(it), 'vault can give ' + it);
    assert.ok(!seen.has('heavy_core'), 'heavy cores only come from ominous vaults');
    const oseen = new Set<string>();
    for (let i = 0; i < 3000; i++) for (const r of rollVault(true, rng)) { oseen.add(r.item); assert.ok(resolve(r.item), 'item exists: ' + r.item); }
    for (const it of ['heavy_core', 'flow_armor_trim_smithing_template', 'flow_banner_pattern', 'music_disc_creator', 'enchanted_golden_apple', 'tipped_arrow_slowness_strong']) assert.ok(oseen.has(it), 'ominous vault can give ' + it);
    assert.deepEqual(scaling('melee', 1, true, 'zombie'), { total: 6, simultaneous: 4 }, 'ominous: one more mob at once');
    assert.deepEqual(scaling('small_melee', 1, true, 'cave_spider'), { total: 12, simultaneous: 4 }, 'gear-less mobs: twice the total');
    let chain = 0;
    for (let i = 0; i < 700; i++) { const g = ominousEquipment(rng, false); assert.ok(g.weapon === 5 || g.weapon === 6); assert.ok(g.armor <= 11); if (g.armor > 0 && g.armor <= 7 && g.toughness === 0) chain++; }
    const [potion, shot] = ominousProjectiles(10, -20, 30, 1234);
    assert.ok(potion.startsWith('potion:') && OMINOUS_SHOTS.includes(shot as never));
    assert.deepEqual(ominousProjectiles(10, -20, 30, 1234), [potion, shot], 'fixed per position and seed');
  });

  await test('sheep: biome colours, dyeing, shearing drops of that colour, lamb colour mixing, grazing regrows wool, jeb_', () => {
    let s = 3; const rng = () => (s = (s * 16807) % 2147483647) / 2147483647;
    const count = (g: Parameters<typeof rollSheepColor>[0]) => { const c: Record<string, number> = {}; for (let i = 0; i < 100000; i++) { const k = rollSheepColor(g, rng); c[k] = (c[k] ?? 0) + 1; } return c; };
    const t = count('temperate'), cold = count('cold'), warm = count('warm');
    assert.ok(t.white > 81000 && t.white < 82700 && t.black > 4500 && t.black < 5500 && t.brown > 2600 && t.brown < 3400 && (t.pink ?? 0) < 300, JSON.stringify(t));
    assert.ok(cold.black > 81000 && warm.brown > 81000 && warm.black > 2600 && warm.black < 3400, 'cold → black, warm → brown common');
    assert.equal(sheepBiomeGroup('snowy_plains'), 'cold'); assert.equal(sheepBiomeGroup('windswept_savanna'), 'warm'); assert.equal(sheepBiomeGroup('plains'), 'temperate'); assert.equal(sheepBiomeGroup('stony_peaks'), 'temperate');
    assert.equal(mixDyes('blue', 'white'), 'light_blue'); assert.equal(mixDyes('red', 'yellow'), 'orange'); assert.equal(mixDyes('purple', 'pink'), 'magenta'); assert.equal(mixDyes('red', 'blue'), 'purple');
    assert.equal(mixDyes('green', 'red'), null);
    for (let i = 0; i < 50; i++) assert.ok(['green', 'red'].includes(lambColor('green', 'red', rng)));
    assert.equal(SHEEP_COLORS.white, '#e6e6e6'); assert.equal(SHEEP_COLORS.red, '#84221c');
    const w = world();
    const sh = w.spawn('sheep', 0, 0);
    w.mobs.setSheepColor(sh, 'white');
    assert.ok(w.mobs.interact(new THREE.Vector3(0, 65.5, 2), new THREE.Vector3(0, -0.3, -1).normalize(), 'blue_dye'));
    assert.equal(sh.woolColor, 'blue');
    w.drops.length = 0;
    assert.ok(w.mobs.interact(new THREE.Vector3(0, 65.5, 2), new THREE.Vector3(0, -0.3, -1).normalize(), 'shears'));
    assert.ok(!sh.wool && w.drops.some(d => d.name === 'blue_wool' && d.count >= 1 && d.count <= 3), JSON.stringify(w.drops));
    w.mobs.interact(new THREE.Vector3(0, 65.5, 2), new THREE.Vector3(0, -0.3, -1).normalize(), 'red_dye');
    assert.equal(sh.woolColor, 'blue', 'sheared sheep cannot be dyed');
    for (let i = 0; i < 4000 && !sh.wool; i++) w.mobs.update(0.05, 1, true);
    assert.ok(sh.wool, 'grazing regrows the wool');
    assert.equal(w.mobs.save().find(x => x.id === sh.id)?.woolColor, 'blue', 'colour is saved');
    const lootW = rollMobLoot({ species: 'sheep', rng, wool: 'blue_wool' });
    assert.ok(lootW.some(([n]) => n === 'blue_wool'));
    assert.equal(jebColor(0, 0), 'white'); assert.equal(jebColor(25 / 20, 0), 'orange');
  });

  const failed = results.filter(r => !r.ok);
  for (const r of results) console.log(`${r.ok ? '✓' : '✗'} ${r.name}${r.ok ? '' : '\n   ' + r.error}`);
  console.log(`\n${results.length - failed.length} / ${results.length} passed`);
  if (failed.length) process.exit(1);
}
void main();
