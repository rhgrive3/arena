import assert from 'node:assert/strict';
import * as THREE from 'three';
import '../src/game/content';
import { BLOCKS, ID } from '../src/game/data';
import { random } from '../src/input/math';
import { Fluids, WL_OPEN_ALL, WL_OPEN_SIDES } from '../src/systems/fluids';
import {
  ElytraFlight, elytraTick, rocketBoostTick, rocketLifetime, flyIntoWallDamage, leashTick, LEASH_SNAP, boatFloat, boatControl, newBoatState,
  boatSeatOffset, canBoardBoat, minecartCollide, pushApart, entityBox, intersects, BOAT,
} from '../src/entities/physics';
import { Fishing, catchVelocity } from '../src/systems/fishing';
import { VehicleManager } from '../src/entities/vehicles';
import {
  NaturalSpawner, CELL, MOB_CAP, mobCap, categoryOf, despawnTick, isDarkEnoughToSpawn, isSlimeChunk, skyDarkenOf, spawnList,
  PhantomSpawner, type MobCategory, type SpawnWorld,
} from '../src/entities/spawning';
import { Raid, RAID, composeWave, waveSize, numGroups, canStartRaid, type RaidWorld, type RaiderType } from '../src/systems/raid';
import { MobManager } from '../src/entities/mobs';

/*
 * Java Edition parity checks for the four systems ported from the Minecraft Wiki / Java sources:
 *   1. fluids (slope search, infinite water, lava viscosity per dimension, waterlogging)
 *   2. entity physics (elytra aerodynamics + rockets, leads, boats with two riders, minecart collisions, fishing bobber + bite AI)
 *   3. natural spawning (mob caps, 24-128 block sphere, light level 0, despawn rules)
 *   4. raids (wave tables, boss bar, cooldowns, victory / defeat / expiry)
 */
const results: { name: string; ok: boolean; note?: string }[] = [];
function test(name: string, fn: () => void) {
  try { fn(); results.push({ name, ok: true }); }
  catch (e) { results.push({ name, ok: false, note: e instanceof Error ? e.message : String(e) }); }
}

// ================================================================================================================ fluids
class FluidWorld {
  cells = new Map<string, number>();
  logged = new Set<string>();
  loggable = new Set<number>();
  open = new Map<string, number>();
  dim = 'overworld';
  k = (x: number, y: number, z: number) => x + ',' + y + ',' + z;
  get(x: number, y: number, z: number) { return this.cells.get(this.k(x, y, z)) ?? 0; }
  id(x: number, y: number, z: number) { return this.get(x, y, z) & 4095; }
  st(x: number, y: number, z: number) { return (this.get(x, y, z) >>> 12) & 15; }
  put(x: number, y: number, z: number, id: number, state = 0) { if (id) this.cells.set(this.k(x, y, z), id | (state << 12)); else this.cells.delete(this.k(x, y, z)); }
  fluids = new Fluids({
    getCell: (x, y, z) => this.get(x, y, z),
    setBlock: (x, y, z, id, s = 0) => { this.put(x, y, z, id, s); this.fluids.onBlockChanged(x, y, z); return true; },
    dimension: () => this.dim,
    isWaterlogged: (x, y, z) => this.logged.has(this.k(x, y, z)),
    waterloggable: (x, y, z) => this.loggable.has(this.id(x, y, z)),
    setWaterlogged: (x, y, z, on) => { if (on) this.logged.add(this.k(x, y, z)); else this.logged.delete(this.k(x, y, z)); this.fluids.onBlockChanged(x, y, z); return true; },
    waterlogOpen: (x, y, z) => this.open.get(this.k(x, y, z)) ?? WL_OPEN_ALL,
  }, random(5));
  floor(r: number, y = 0) { for (let x = -r; x <= r; x++) for (let z = -r; z <= r; z++) this.put(x, y, z, ID.stone); return this; }
  source(x: number, y: number, z: number, id = ID.water) { this.put(x, y, z, id, 0); this.fluids.onBlockChanged(x, y, z); return this; }
  run(seconds: number) { for (let t = 0; t < seconds; t += 0.05) this.fluids.update(0.05, 1e6, 1e6); return this; }
}
const SLAB = Object.keys(ID).find(n => n.endsWith('_slab'))!, FENCE = Object.keys(ID).find(n => n.endsWith('_fence'))!;

test('fluid: water spreads 1 block per 5 ticks and reaches exactly 7 blocks', () => {
  const w = new FluidWorld().floor(10).source(0, 1, 0);
  w.run(0.3);
  assert.equal(w.id(1, 1, 0), ID.water); assert.equal(w.st(1, 1, 0), 1);
  assert.equal(w.id(2, 1, 0), 0, 'second block not yet reached after 6 ticks');
  w.run(4);
  assert.equal(w.st(7, 1, 0), 7); assert.equal(w.id(8, 1, 0), 0);
  assert.equal(w.id(4, 1, 3), ID.water, 'diamond shape'); assert.equal(w.id(4, 1, 4), 0);
});
test('fluid: flows only towards the nearest drop within the slope find distance (4)', () => {
  const w = new FluidWorld().floor(8); w.put(3, 0, 0, 0); w.source(0, 1, 0).run(4);
  assert.equal(w.id(1, 1, 0), ID.water); assert.equal(w.id(2, 1, 0), ID.water);
  assert.equal(w.id(-1, 1, 0), 0, 'no flow away from the drop'); assert.equal(w.id(0, 1, 1), 0); assert.equal(w.id(0, 1, -1), 0);
  assert.equal(w.id(3, 0, 0), ID.water, 'falls into the hole'); assert.equal(w.st(3, 0, 0) & 8, 8);
  const far = new FluidWorld().floor(8); far.put(6, 0, 0, 0); far.source(0, 1, 0).run(4);
  assert.equal(far.id(-1, 1, 0), ID.water, 'a drop 6 blocks away is out of range: spreads everywhere');
});
test('fluid: two sources over a solid floor make an infinite source; game rule can disable it; lava never does', () => {
  const w = new FluidWorld().floor(3); for (const [x, z] of [[-1, 0], [3, 0], [0, 1], [1, 1], [2, 1], [0, -1], [1, -1], [2, -1]]) w.put(x, 1, z, ID.stone);
  w.source(0, 1, 0).source(2, 1, 0).run(1);
  assert.equal(w.id(1, 1, 0), ID.water); assert.equal(w.st(1, 1, 0), 0, 'middle became a source');
  const l = new FluidWorld().floor(3); for (const [x, z] of [[-1, 0], [3, 0], [0, 1], [1, 1], [2, 1], [0, -1], [1, -1], [2, -1]]) l.put(x, 1, z, ID.stone);
  l.source(0, 1, 0, ID.lava).source(2, 1, 0, ID.lava).run(8);
  assert.equal(l.id(1, 1, 0), ID.lava); assert.notEqual(l.st(1, 1, 0), 0, 'lava stays flowing');
});
test('fluid: a source in mid-air flows down first and out to its four sides one flow tick later (wiki: Fluid#Spreading)', () => {
  const w = new FluidWorld().floor(4); w.source(0, 3, 0).run(0.3);
  assert.equal(w.id(0, 2, 0), ID.water, 'falls first'); assert.equal(w.st(0, 2, 0) & 8, 8); assert.equal(w.id(1, 3, 0), 0, 'sides still dry after the first tick');
  w.run(0.3); assert.equal(w.id(1, 3, 0), ID.water, 'then spreads sideways'); assert.equal(w.st(1, 3, 0), 1);
  w.run(3); assert.equal(w.id(1, 1, 0), ID.water, 'and pools on the floor');
  // A FLOWING cell above a drop never spreads sideways: the stream stays one block wide.
  const c = new FluidWorld().floor(8); c.put(3, 0, 0, 0); c.put(3, -1, 0, 0); c.source(0, 1, 0).run(4);
  assert.equal(c.id(3, 1, 0), ID.water); assert.equal(c.id(4, 1, 0), 0, 'does not cross the hole'); assert.equal(c.id(3, 1, 1), 0);
});
test('fluid: lava viscosity — 30 ticks/block and 3 blocks in the Overworld, 10 ticks/block and 7 blocks in the Nether', () => {
  const o = new FluidWorld().floor(10).source(0, 1, 0, ID.lava);
  o.run(1.4); assert.equal(o.id(1, 1, 0), 0, 'nothing before 30 ticks');
  o.run(0.3); assert.equal(o.id(1, 1, 0), ID.lava); assert.equal(o.st(1, 1, 0), 2, 'drop-off 2 per block');
  o.run(20); assert.equal(o.st(3, 1, 0), 6); assert.equal(o.id(4, 1, 0), 0);
  const n = new FluidWorld(); n.dim = 'nether'; n.floor(10).source(0, 1, 0, ID.lava);
  n.run(0.6); assert.equal(n.id(1, 1, 0), ID.lava, 'Nether lava moves after 10 ticks'); assert.equal(n.st(1, 1, 0), 1);
  n.run(20); assert.equal(n.st(7, 1, 0), 7); assert.equal(n.id(8, 1, 0), 0);
  assert.equal(o.fluids.delay(ID.lava) / n.fluids.delay(ID.lava), 3); assert.equal(o.fluids.slope(ID.lava), 2); assert.equal(n.fluids.slope(ID.lava), 4);
});
test('fluid: lava + water reactions (obsidian, cobblestone, stone) also against waterlogged blocks', () => {
  const w = new FluidWorld().floor(6); w.source(0, 1, 0, ID.lava).run(4); w.source(3, 1, 0).run(3);
  assert.equal(w.id(2, 1, 0), ID.cobblestone, 'flowing lava touched by water');
  const o = new FluidWorld().floor(4); o.source(0, 1, 0, ID.lava); o.source(1, 1, 0); o.run(1);
  assert.equal(o.id(0, 1, 0), ID.obsidian);
  const s = new FluidWorld().floor(6); s.put(2, 1, 0, ID[SLAB]); s.logged.add(s.k(2, 1, 0)); s.source(0, 1, 0, ID.lava).run(6);
  assert.equal(s.id(1, 1, 0), ID.cobblestone, 'lava next to a waterlogged slab');
});
test('waterlogging: a waterlogged block is a water source for its neighbours and for the two-source rule', () => {
  const w = new FluidWorld().floor(8); w.put(0, 1, 0, ID[SLAB]); w.logged.add(w.k(0, 1, 0)); w.fluids.onBlockChanged(0, 1, 0); w.run(4);
  assert.equal(w.id(1, 1, 0), ID.water); assert.equal(w.st(1, 1, 0), 1, 'level 1 right next to the waterlogged block');
  assert.equal(w.st(7, 1, 0), 7);
  const t = new FluidWorld().floor(3); for (const [x, z] of [[-1, 0], [3, 0], [0, 1], [1, 1], [2, 1], [0, -1], [1, -1], [2, -1]]) t.put(x, 1, z, ID.stone);
  t.put(0, 1, 0, ID[SLAB]); t.logged.add(t.k(0, 1, 0)); t.source(2, 1, 0).run(1);
  assert.equal(t.st(1, 1, 0), 0, 'slab + source = infinite water'); assert.equal(t.id(1, 1, 0), ID.water);
});
test('waterlogging: water only leaves through non-full faces (bottom slab keeps its floor, stairs keep their back)', () => {
  const w = new FluidWorld().floor(8); w.put(0, 0, 0, 0); w.put(0, 1, 0, ID[SLAB]); w.logged.add(w.k(0, 1, 0)); w.open.set(w.k(0, 1, 0), WL_OPEN_SIDES);
  w.fluids.onBlockChanged(0, 1, 0); w.run(2);
  assert.equal(w.id(0, 0, 0), 0, 'bottom slab does not drain downwards'); assert.equal(w.id(1, 1, 0), ID.water);
  const d = new FluidWorld().floor(8); d.put(0, 0, 0, 0); d.put(0, 1, 0, ID[SLAB]); d.logged.add(d.k(0, 1, 0)); d.fluids.onBlockChanged(0, 1, 0); d.run(2);
  assert.equal(d.id(0, 0, 0), ID.water, 'top slab drains downwards');
  const s = new FluidWorld().floor(8); s.put(0, 1, 0, ID[SLAB]); s.logged.add(s.k(0, 1, 0)); s.open.set(s.k(0, 1, 0), WL_OPEN_SIDES & ~1);   // +x face is the full back
  s.fluids.onBlockChanged(0, 1, 0); s.run(0.3);
  assert.equal(s.id(1, 1, 0), 0, 'closed face'); assert.equal(s.id(-1, 1, 0), ID.water);
});
test('waterlogging: a dry waterloggable block between two sources fills up; flowing water never enters it', () => {
  const w = new FluidWorld().floor(12); w.loggable.add(ID[FENCE]); w.put(1, 1, 0, ID[FENCE]); w.source(0, 1, 0).source(2, 1, 0).run(1);
  assert.ok(w.logged.has(w.k(1, 1, 0)), 'fence became waterlogged');
  const f = new FluidWorld().floor(12); f.loggable.add(ID[FENCE]); f.put(2, 1, 0, ID[FENCE]); f.source(0, 1, 0).run(3);
  assert.ok(!f.logged.has(f.k(2, 1, 0)), 'flowing water does not waterlog');
});

// ================================================================================================================ elytra
const lookOf = (pitchDown: number) => ({ x: 0, y: -Math.sin(pitchDown), z: -Math.cos(pitchDown) });
function glide(pitchDeg: number, ticks = 2000) {
  const p = (pitchDeg * Math.PI) / 180, look = lookOf(p);
  let v = { x: 0, y: 0, z: 0 };
  for (let i = 0; i < ticks; i++) v = elytraTick(v, look, p);
  return { h: Math.hypot(v.x, v.z) * 20, sink: -v.y * 20 };
}
test('elytra: glide ratio ≈ 10 : 1 looking at the horizon (wiki: 10.06)', () => {
  const g = glide(0), ratio = g.h / g.sink;
  assert.ok(ratio > 9.6 && ratio < 10.5, 'ratio=' + ratio.toFixed(2));
});
test('elytra: minimum airspeed ≈ 7.2 m/s at 30° up, slowest sink ≈ 1.5 m/s at 12-15° up, dives are fastest', () => {
  const up30 = glide(-30), up13 = glide(-13), level = glide(0), dive = glide(40);
  assert.ok(Math.abs(Math.hypot(up30.h, up30.sink) - 7.2) < 0.6, 'speed@30°=' + Math.hypot(up30.h, up30.sink).toFixed(2));
  assert.ok(up13.sink > 1.2 && up13.sink < 1.8, 'sink@13°=' + up13.sink.toFixed(2));
  assert.ok(up13.sink < level.sink && up13.sink < up30.sink, 'best sink near 12-15°');
  assert.ok(dive.h > level.h * 1.5, 'diving builds speed');
});
test('elytra: pulling up trades speed for height; sharp turns bleed speed', () => {
  const p0 = (35 * Math.PI) / 180; let v = { x: 0, y: 0, z: 0 };
  for (let i = 0; i < 200; i++) v = elytraTick(v, lookOf(p0), p0);
  const fast = Math.hypot(v.x, v.z); const up = (-40 * Math.PI) / 180; let climbed = 0;
  for (let i = 0; i < 30; i++) { v = elytraTick(v, lookOf(up), up); climbed += v.y; }
  assert.ok(climbed > 5, 'climbed ' + climbed.toFixed(1)); assert.ok(Math.hypot(v.x, v.z) < fast * 0.75, 'lost speed while climbing');
  let t = { x: 0, y: 0, z: -1.5 }; for (let i = 0; i < 10; i++) t = elytraTick(t, { x: 1, y: 0, z: 0 }, 0);
  assert.ok(Math.hypot(t.x, t.z) < 1.3, 'turn drag');
});
test('firework rocket: ≈ 33.5 m/s boost, lifetime 10·flight + rand(6) + rand(7), kinetic wall damage 10·Δv − 3', () => {
  const look = lookOf(0); let v = { x: 0, y: 0, z: 0 };
  for (let i = 0; i < 60; i++) v = rocketBoostTick(elytraTick(v, look, 0), look);
  assert.ok(Math.abs(Math.hypot(v.x, v.y, v.z) * 20 - 33.5) < 1.2, 'speed=' + (Math.hypot(v.x, v.y, v.z) * 20).toFixed(1));
  assert.equal(rocketLifetime(1, () => 0), 10); assert.equal(rocketLifetime(3, () => 0.999), 41);
  assert.equal(flyIntoWallDamage(0.3), 0); assert.ok(Math.abs(flyIntoWallDamage(1.5) - 12) < 1e-9);
  const a = new ElytraFlight(), b = new ElytraFlight(), va = { x: 0, y: 0, z: -10 }, vb = { x: 0, y: 0, z: -10 };
  for (let i = 0; i < 60; i++) a.step(1 / 60, va, look, 0);
  for (let i = 0; i < 20; i++) b.step(1 / 20, vb, look, 0);
  assert.ok(Math.abs(va.z - vb.z) < 0.6 && Math.abs(va.y - vb.y) < 0.6, 'frame-rate independent');
  const w = new ElytraFlight(); for (let i = 0; i < 100; i++) w.step(0.05, { x: 0, y: 0, z: 0 }, look, 0);
  assert.equal(w.takeWear(), 5, '1 durability per second of gliding');
});

// ================================================================================================================= leads
test('lead: slack within 6 blocks, d²·0.4 pull beyond, snaps past 12', () => {
  assert.equal(leashTick({ x: 0, y: 0, z: 0 }, { x: 5.9, y: 0, z: 0 }).pull, null);
  const p = leashTick({ x: 0, y: 0, z: 0 }, { x: 8, y: 0, z: 0 });
  assert.ok(p.pull && Math.abs(p.pull.x - 0.4) < 1e-9 && p.pull.z === 0);
  const up = leashTick({ x: 0, y: 0, z: 0 }, { x: 0, y: 9, z: 0 }); assert.ok(up.pull && up.pull.y > 0, 'lifts a mob hanging below');
  assert.equal(leashTick({ x: 0, y: 0, z: 0 }, { x: LEASH_SNAP + 0.1, y: 0, z: 0 }).snap, true);
  assert.equal(leashTick({ x: 0, y: 0, z: 0 }, { x: LEASH_SNAP - 0.1, y: 0, z: 0 }).snap, false);
});

// ================================================================================================================= boats
function boatTopSpeed(status: 'in_water' | 'on_land', friction: number) {
  const s = newBoatState(); s.status = status;
  for (let i = 0; i < 3000; i++) { boatFloat(s, status, 0, status === 'in_water' ? 0.3656 : 0, friction); s.vy = 0; boatControl(s, { left: false, right: false, up: true, down: false }, 0, -1); }
  return Math.hypot(s.vx, s.vz) * 20;
}
test('boat: 8 m/s on water, 40 m/s on ice, 72.7 m/s on blue ice, 2 m/s on land', () => {
  assert.ok(Math.abs(boatTopSpeed('in_water', 0.9) - 8) < 0.05);
  assert.ok(Math.abs(boatTopSpeed('on_land', 0.98) - 40) < 0.1);
  assert.ok(Math.abs(boatTopSpeed('on_land', 0.989) - 72.73) < 0.3);
  assert.ok(Math.abs(boatTopSpeed('on_land', 0.6) - 2) < 0.05);
});
test('boat: buoyancy settles the hull 0.366 blocks below the surface; turning accelerates 1°/tick²; seats and boarding rules', () => {
  const s = newBoatState(); s.status = 'in_water'; let y = 0.2;
  for (let i = 0; i < 400; i++) { boatFloat(s, 'in_water', y, 1, 0.9); y += s.vy; }
  assert.ok(Math.abs(1 - y - 0.3656) < 0.01, 'draught=' + (1 - y).toFixed(3));
  const t = newBoatState(); boatControl(t, { left: false, right: true, up: false, down: false }, 0, -1); boatControl(t, { left: false, right: true, up: false, down: false }, 0, -1);
  assert.equal(t.deltaRotation, 2); assert.ok(Math.abs(Math.hypot(t.vx, t.vz) - 0.01) < 1e-9, 'turning alone paddles at 0.005');
  assert.equal(boatSeatOffset(0, 1), 0); assert.equal(boatSeatOffset(0, 2), 0.2); assert.equal(boatSeatOffset(1, 2), -0.6); assert.ok(Math.abs(boatSeatOffset(1, 2, true) + 0.4) < 1e-9);
  const base = { passengers: 0, playerControlled: false, width: 0.9, aquatic: false, alreadyRiding: false };
  assert.equal(canBoardBoat(base), true); assert.equal(canBoardBoat({ ...base, passengers: 2 }), false);
  assert.equal(canBoardBoat({ ...base, playerControlled: true }), false); assert.equal(canBoardBoat({ ...base, aquatic: true }), false);
  assert.equal(canBoardBoat({ ...base, width: BOAT.width }), false, 'too wide (ravager, horse…)');
  assert.ok(intersects(entityBox(0, 0, 0, 1, 1), entityBox(0.9, 0, 0, 1, 1))); assert.ok(!intersects(entityBox(0, 0, 0, 1, 1), entityBox(1.1, 0, 0, 1, 1)));
  const push = pushApart(0, 0, 0.25, 0)!; assert.ok(push.x > 0 && push.x <= 0.05);
});
test('boat (integration): floats on water, picks up exactly two mobs, a full boat refuses the player, the front seat steers', () => {
  const block = (_x: number, y: number) => (Math.floor(y) <= 55 ? ID.stone : Math.floor(y) <= 62 ? ID.water : 0);
  const riders = new Map<number, number | null>(), placed = new Map<number, THREE.Vector3>();
  const mobs = [1, 2, 3].map(id => ({ id, x: 0.5 + id * 0.3, y: 62.6, z: 0.5, width: 0.9, aquatic: false, riding: false }));
  const vm = new VehicleManager(new THREE.Scene(), {
    getCell: (x, y, z) => block(x, y, z as never), getBlock: (x, y, z) => block(x, y, z as never),
    mobs: () => mobs, setRider: (id, v) => { riders.set(id, v); const m = mobs.find(q => q.id === id)!; m.riding = v != null; return true; },
    placeRider: (id, x, y, z) => { placed.set(id, new THREE.Vector3(x, y, z)); return true; },
  } as never);
  const boat = vm.spawn('boat', 0.5, 63.2, 0.5);
  for (let i = 0; i < 200; i++) vm.update(0.05, null);
  assert.ok(Math.abs(boat.pos.y - (62 + 8 / 9 - 0.3656)) < 0.05, 'floating at y=' + boat.pos.y.toFixed(3));
  assert.equal(boat.passengers!.length, 2, 'two seats'); assert.equal(riders.size, 2); assert.equal(mobs[2].riding, false);
  const a = placed.get(boat.passengers![0])!, b = placed.get(boat.passengers![1])!;
  assert.ok(Math.abs(a.distanceTo(b) - 0.8) < 0.05, 'seats 0.8 apart: ' + a.distanceTo(b).toFixed(2));
  assert.equal(vm.mount(boat), false, 'no free seat for the player'); assert.equal(vm.riding, null);
  const solo = vm.spawn('boat', 20.5, 63.2, 0.5);
  for (let i = 0; i < 100; i++) vm.update(0.05, null);
  assert.equal(vm.mount(solo), true);
  const z0 = solo.pos.z; for (let i = 0; i < 100; i++) vm.update(0.05, { forward: 1, strafe: 0, yaw: 0 });
  assert.ok(z0 - solo.pos.z > 15 && solo.speed < 8.2, 'rows at up to 8 m/s: moved ' + (z0 - solo.pos.z).toFixed(1) + ' at ' + solo.speed.toFixed(2));
});
test('minecart collisions: velocities average and separate; a furnace cart shoves the train', () => {
  const a = { x: 0, z: 0, vx: 0.4, vz: 0 }, b = { x: 0.9, z: 0, vx: 0, vz: 0 };
  assert.ok(minecartCollide(a, b));
  assert.ok(Math.abs(a.vx - (0.24 - 0.05)) < 1e-9 && Math.abs(b.vx - (0.24 + 0.05)) < 1e-9, `a=${a.vx} b=${b.vx}`);
  const h1 = { x: 0, z: 0, vx: 0.3, vz: 0 }, h2 = { x: 0.9, z: 0, vx: -0.3, vz: 0 }; minecartCollide(h1, h2);
  assert.ok(h1.vx < 0 && h2.vx > 0, 'head-on carts bounce apart');
  const f = { x: 0, z: 0, vx: 0.2, vz: 0, furnace: true }, c = { x: 0.9, z: 0, vx: 0, vz: 0 }; minecartCollide(f, c);
  assert.ok(Math.abs(f.vx - 0.19) < 1e-9, 'furnace keeps 95 %'); assert.ok(Math.abs(c.vx - 0.25) < 1e-9, 'pushed cart takes the furnace speed + separation');
});

// =============================================================================================================== fishing
function pond(seed: number, lure = 0, raining = false) {
  const getBlock = (_x: number, y: number) => (Math.floor(y) < 55 ? ID.stone : Math.floor(y) <= 62 ? ID.water : 0);
  const f = new Fishing(new THREE.Scene(), { getBlock, particles: { burst() {} }, sound() {}, raining: () => raining }, random(seed));
  const tip = new THREE.Vector3(0, 64, 0);
  f.cast(tip, new THREE.Vector3(0.6, -0.2, 0.6).normalize(), lure);
  return { f, tip };
}
test('fishing: the bobber flies in an arc, splashes down and floats at the water surface', () => {
  const { f, tip } = pond(3);
  let maxDist = 0; for (let i = 0; i < 80; i++) { f.update(0.05, tip); maxDist = Math.max(maxDist, f.bobber!.position.distanceTo(tip)); }
  assert.equal(f.phase, 'waiting'); assert.ok(maxDist > 3 && maxDist < 32, 'cast distance ' + maxDist.toFixed(1));
  for (let i = 0; i < 40; i++) { f.update(0.05, tip); assert.ok(Math.abs(f.bobber!.position.y - (62 + 8 / 9)) < 0.35, 'y=' + f.bobber!.position.y.toFixed(2)); }
  assert.equal(f.openWater(f.bobber!.position), true);
});
test('fishing: bite AI — lured in 100-600 ticks, fish approaches 20-80 ticks, nibbles 20-40 ticks, then escapes', () => {
  for (const seed of [1, 2, 3, 4, 5, 6]) {
    const { f, tip } = pond(seed);
    let t = 0, biteAt = -1, biteLen = 0, sawApproach = 0;
    for (; t < 900; t++) {
      f.update(0.05, tip);
      if (f.timeUntilHooked > 0) sawApproach++;
      if (f.biting) { if (biteAt < 0) biteAt = t; biteLen++; } else if (biteAt >= 0) break;
    }
    assert.ok(biteAt >= 120 && biteAt <= 720, `seed ${seed}: bite at tick ${biteAt}`);
    assert.ok(sawApproach >= 19 && sawApproach <= 80, `seed ${seed}: approach ${sawApproach}`);
    assert.ok(biteLen >= 19 && biteLen <= 46, `seed ${seed}: nibble ${biteLen}`);   // 20-40 ticks in water; ticks spent bobbing above the surface do not count
    assert.equal(f.phase, 'waiting', 'the fish got away and the cycle restarts');
  }
});
test('fishing: reeling during the nibble catches (1 durability); Lure shortens the wait; the hook is lost beyond 32 blocks', () => {
  const { f, tip } = pond(9);
  for (let t = 0; t < 900 && !f.biting; t++) f.update(0.05, tip);
  const r = f.reel(0, tip)!; assert.ok(r.caught, 'caught something'); assert.equal(r.wear, 1); assert.ok(r.xp >= 1 && r.xp <= 6);
  const wait = (lure: number) => { let sum = 0; for (let s = 20; s < 40; s++) { const p = pond(s, lure); let t = 0; for (; t < 900 && !p.f.biting; t++) p.f.update(0.05, p.tip); sum += t; } return sum / 20; };
  const w0 = wait(0), w3 = wait(3);
  assert.ok(w0 - w3 > 150, `Lure III saves ~300 ticks: ${w0.toFixed(0)} vs ${w3.toFixed(0)}`);
  const far = pond(4); far.f.update(0.05, far.tip); far.f.update(0.05, new THREE.Vector3(200, 64, 0)); assert.equal(far.f.active, false);
  const v = catchVelocity({ x: 0, y: 0, z: 0 }, { x: 16, y: 0, z: 0 }); assert.ok(Math.abs(v.x - 1.6) < 1e-9 && Math.abs(v.y - 0.32) < 1e-9, 'Δ·0.1 and √16·0.08 upwards');
});
test('fishing: treasure needs open water (uniform still-water layers below, air above)', () => {
  const mk = (fn: (x: number, y: number, z: number) => number) => new Fishing(new THREE.Scene(), { getBlock: (x, y, z) => fn(Math.floor(x), Math.floor(y), Math.floor(z)), particles: { burst() {} }, sound() {} });
  const p = new THREE.Vector3(0.5, 62.9, 0.5);
  assert.equal(mk((_x, y) => (y <= 62 ? ID.water : 0)).openWater(p), true);
  assert.equal(mk((x, y) => (y <= 62 ? (x === 2 ? ID.stone : ID.water) : 0)).openWater(p), false, 'pool too small');
  assert.equal(mk((_x, y) => (y === 62 ? ID.water : y < 62 ? ID.stone : 0)).openWater(p), false, 'one block deep');
  assert.equal(mk((_x, y) => (y <= 62 ? ID.water : y === 64 ? ID.stone : 0)).openWater(p), false, 'roof 2 blocks up');
});

// ============================================================================================================== spawning
function platformWorld(o: Partial<{ sky: number; block: number; darken: number; minY: number; floor: string; dim: string }> = {}) {
  const spawned: { species: string; x: number; y: number; z: number; category: MobCategory }[] = [];
  const rnd = random(11);
  const w: SpawnWorld = {
    dimension: o.dim ?? 'overworld', seaLevel: 62, minY: o.minY ?? 60, seed: 1234, rnd,
    cell: (_x, y) => (y <= 64 ? CELL.SOLID | CELL.FULL : 0),
    name: (_x, y) => (y <= 64 ? o.floor ?? 'stone' : 'air'),
    topY: () => 64, biome: () => 'plains',
    skyLight: () => o.sky ?? 0, blockLight: () => o.block ?? 0, skyDarken: () => o.darken ?? 0,
    spawn: (species, x, y, z, category) => { spawned.push({ species, x, y, z, category }); return true; },
  };
  const counts = (): Record<MobCategory, number> => {
    const c: Record<MobCategory, number> = { monster: 0, creature: 0, ambient: 0, axolotls: 0, underground_water_creature: 0, water_creature: 0, water_ambient: 0, misc: 0 };
    for (const s of spawned) c[s.category]++;
    return c;
  };
  return { w, spawned, counts };
}
const ctx = (tick: number, counts: Record<MobCategory, number>, extra: object = {}) => ({ px: 0.5, py: 65, pz: 0.5, tick, counts, chunkRadius: 8, peaceful: false, ...extra });
test('spawning: mob caps 70/10/15/5/5/5/20 scale with loaded chunks ÷ 289', () => {
  assert.deepEqual([MOB_CAP.monster, MOB_CAP.creature, MOB_CAP.ambient, MOB_CAP.axolotls, MOB_CAP.underground_water_creature, MOB_CAP.water_creature, MOB_CAP.water_ambient], [70, 10, 15, 5, 5, 5, 20]);
  assert.equal(mobCap('monster', 289), 70); assert.equal(mobCap('monster', NaturalSpawner.capChunks(4)), 19); assert.equal(NaturalSpawner.capChunks(12), 289);
  assert.equal(categoryOf('zombie'), 'monster'); assert.equal(categoryOf('cow'), 'creature'); assert.equal(categoryOf('bat'), 'ambient');
  assert.equal(categoryOf('glow_squid'), 'underground_water_creature'); assert.equal(categoryOf('salmon'), 'water_ambient'); assert.equal(categoryOf('villager'), 'misc');
});
test('spawning: monsters fill up to the cap, never within 24 blocks of the player and never beyond 128', () => {
  const p = platformWorld(), sp = new NaturalSpawner();
  for (let t = 1; t <= 400; t++) sp.tick(p.w, ctx(t, p.counts()));
  const monsters = p.spawned.filter(s => s.category === 'monster');
  assert.ok(monsters.length >= 70 && monsters.length <= 73, 'monsters=' + monsters.length + ' (cap 70 + at most one pack overshoot)');
  for (const m of p.spawned) { const d = Math.hypot(m.x - 0.5, m.y - 65, m.z - 0.5); assert.ok(d > 24 && d <= 128.01, 'distance ' + d.toFixed(1)); assert.equal(m.y, 65); }
  assert.ok(new Set(monsters.map(m => m.species)).size >= 4, 'weighted mix of species');
});
test('spawning: block light must be 0 (1.18+), daylight blocks surface spawns, the Nether allows light, Peaceful spawns none', () => {
  const run = (o: object, extra: object = {}) => { const p = platformWorld(o), sp = new NaturalSpawner(); for (let t = 1; t <= 60; t++) sp.tick(p.w, ctx(t, p.counts(), extra)); return p.spawned.filter(s => s.category === 'monster').length; };
  assert.equal(run({ block: 1 }), 0, 'a single light level stops monsters');
  assert.equal(run({ sky: 15, darken: 0 }), 0, 'open sky at noon');
  assert.ok(run({ sky: 15, darken: 11 }) > 0, 'open sky at midnight');
  assert.equal(run({}, { peaceful: true }), 0); assert.equal(run({}, { spawnMonsters: false }), 0);
  const r = random(3);
  assert.equal(isDarkEnoughToSpawn(0, 1, 0, false, 'overworld', r), false); assert.equal(isDarkEnoughToSpawn(0, 11, 0, false, 'nether', () => 0.99), false);
  assert.equal(isDarkEnoughToSpawn(0, 7, 0, false, 'nether', r), true);
  assert.equal(skyDarkenOf(1), 0); assert.equal(skyDarkenOf(0), 11);
});
test('spawning: animals only get a spawn cycle every 400 ticks, need grass and light > 8', () => {
  const p = platformWorld({ sky: 15, darken: 0, floor: 'grass_block' }), sp = new NaturalSpawner();
  for (let t = 1; t < 400; t++) sp.tick(p.w, ctx(t, p.counts()));
  assert.equal(p.spawned.filter(s => s.category === 'creature').length, 0);
  sp.tick(p.w, ctx(400, p.counts()));
  const animals = p.spawned.filter(s => s.category === 'creature');
  assert.ok(animals.length > 0 && animals.length <= 13, 'animals=' + animals.length);
  assert.ok(animals.every(a => ['sheep', 'pig', 'chicken', 'cow', 'horse', 'donkey'].includes(a.species)));
  const stone = platformWorld({ sky: 15, darken: 0 }), s2 = new NaturalSpawner(); s2.tick(stone.w, ctx(400, stone.counts()));
  assert.equal(stone.spawned.filter(s => s.category === 'creature').length, 0, 'no animals on stone');
});
test('spawning: a lower heightmap raises the rate (why perimeters and sky farms work)', () => {
  const rate = (minY: number) => { const p = platformWorld({ minY }), sp = new NaturalSpawner(); let n = 0; const zero = p.counts(); for (let t = 1; t <= 300; t++) n += sp.tick(p.w, ctx(t, { ...zero })); return n; };
  const shallow = rate(60), deep = rate(-64);
  assert.ok(shallow > deep * 5, `shallow ${shallow} vs deep ${deep}`);
});
test('despawning: instantly beyond 128 blocks, never within 32, 1/800 per tick after 600 idle ticks; animals and persistent mobs stay', () => {
  const r = random(21);
  assert.equal(despawnTick({ noActionTime: 0 }, 'monster', 129 * 129, r), true);
  assert.equal(despawnTick({ noActionTime: 0 }, 'water_ambient', 65 * 65, r), true, 'fish: 64 blocks');
  const near = { noActionTime: 5000 }; assert.equal(despawnTick(near, 'monster', 31 * 31, r), false); assert.equal(near.noActionTime, 0);
  let total = 0; const N = 3000;
  for (let i = 0; i < N; i++) { const s = { noActionTime: 0 }; let t = 0; while (!despawnTick(s, 'monster', 50 * 50, r)) t++; assert.ok(t >= 600); total += t; }
  assert.ok(Math.abs(total / N - 1400) < 60, 'mean lifetime ' + (total / N).toFixed(0) + ' ticks (600 + 800)');
  const cow = { noActionTime: 0 }; for (let i = 0; i < 5000; i++) assert.equal(despawnTick(cow, 'creature', 100 * 100, r), false);
  const named = { noActionTime: 0 }; for (let i = 0; i < 5000; i++) assert.equal(despawnTick(named, 'monster', 100 * 100, r, true), false);
  let illager = 0; const N2 = 2000; for (let i = 0; i < N2; i++) { const s = { noActionTime: 0 }; let t = 0; while (!despawnTick(s, 'monster', 50 * 50, r, false, 2)) t++; illager += t; }
  assert.ok(Math.abs(illager / N2 - 1000) < 60, 'illagers idle 3x as fast: ' + (illager / N2).toFixed(0));
});
test('spawning: biome tables, slime chunks (1 in 10, deterministic) and phantoms after 3 sleepless days', () => {
  assert.ok(spawnList('monster', 'desert', 'overworld').some(e => e.species === 'husk' && e.weight === 80));
  assert.equal(spawnList('monster', 'mushroom_fields', 'overworld').length, 0);
  assert.ok(spawnList('monster', 'soul_sand_valley', 'nether').some(e => e.species === 'ghast' && e.weight === 50));
  assert.deepEqual(spawnList('creature', 'plains', 'overworld').filter(e => e.species === 'sheep')[0], { species: 'sheep', weight: 12, min: 4, max: 4 });
  let n = 0; for (let x = -50; x < 50; x++) for (let z = -50; z < 50; z++) if (isSlimeChunk(42, x, z)) n++;
  assert.ok(n > 850 && n < 1150, 'slime chunks ' + n + '/10000'); assert.equal(isSlimeChunk(42, 3, 7), isSlimeChunk(42, 3, 7));
  const ph = new PhantomSpawner(), base = { rnd: random(8), seesSky: true, y: 70, seaLevel: 62, night: true, difficulty: 'normal', dimension: 'overworld' };
  let rested = 0, tired = 0;
  for (let i = 0; i < 40000; i++) rested += ph.tick({ ...base, ticksSinceRest: 60000 });
  for (let i = 0; i < 40000; i++) tired += ph.tick({ ...base, ticksSinceRest: 300000 });
  assert.equal(rested, 0); assert.ok(tired > 5, 'phantoms=' + tired);
});

// ================================================================================================================= raids
const countOf = (w: ReturnType<typeof composeWave>, t: RaiderType) => w.filter(e => e.type === t).length + w.filter(e => e.rider === t).length;
test('raid: wave tables match Java (pillager/vindicator/ravager/witch/evoker per wave and difficulty, jockeys, bonus wave)', () => {
  const r = random(31);
  assert.deepEqual([numGroups('easy'), numGroups('normal'), numGroups('hard')], [3, 5, 7]);
  for (let i = 0; i < 300; i++) {
    const e1 = composeWave(1, 'easy', false, r), e3 = composeWave(3, 'easy', false, r);
    const e1p = e1.filter(x => x.type === 'pillager').length, e1v = e1.filter(x => x.type === 'vindicator').length;
    assert.ok(e1p >= 4 && e1p <= 5 && e1v <= 1 && e1p + e1v === e1.length, `easy wave 1: ${e1p} pillagers, ${e1v} vindicators`);
    assert.equal(e3.filter(x => x.type === 'ravager').length, 1); assert.ok(e3.every(x => !x.rider));
    const n4 = composeWave(4, 'normal', false, r), n5 = composeWave(5, 'normal', false, r);
    assert.equal(n4.filter(x => x.type === 'witch').length, 3);
    assert.equal(n5.filter(x => x.type === 'evoker').length, 1);
    assert.deepEqual(n5.filter(x => x.type === 'ravager').map(x => x.rider), ['pillager'], 'wave 5: pillager riding a ravager');
    const v5 = n5.filter(x => x.type === 'vindicator').length; assert.ok(v5 >= 4 && v5 <= 5);
    const h7 = composeWave(7, 'hard', false, r);
    assert.deepEqual(h7.filter(x => x.type === 'ravager').map(x => x.rider), ['evoker', 'vindicator']);
    assert.equal(h7.filter(x => x.type === 'evoker').length, 2);
    const p7 = h7.filter(x => x.type === 'pillager').length, v7 = h7.filter(x => x.type === 'vindicator').length, w7 = h7.filter(x => x.type === 'witch').length;
    assert.ok(p7 >= 2 && p7 <= 4 && v7 >= 5 && v7 <= 7 && w7 >= 1 && w7 <= 2, `hard wave 7: ${p7}/${v7}/${w7}`);
    assert.equal(h7.filter(x => x.leader).length, 1, 'one captain per wave'); assert.ok(h7.find(x => x.leader)!.type !== 'witch');
    const bonus = composeWave(6, 'normal', true, r);
    assert.ok(countOf(bonus, 'ravager') <= 2 && bonus.filter(x => x.type === 'evoker').length === 1, 'bonus wave copies the last column');
    assert.ok(waveSize(h7) >= 14 && waveSize(h7) <= 19);
  }
  assert.equal(canStartRaid('nether', 'hard'), false); assert.equal(canStartRaid('overworld', 'peaceful'), false); assert.equal(canStartRaid('overworld', 'easy', false), false);
});
function raidSim(difficulty: string, omen = 1) {
  const raiders = new Map<number, { health: number; x: number; y: number; z: number }>();
  const events: string[] = []; let nextId = 1; const state = { villagers: 5, difficulty };
  const world: RaidWorld = {
    rnd: random(41), difficulty: () => state.difficulty,
    spawnRaider: (_t, x, y, z) => { const id = nextId++; raiders.set(id, { health: 24, x, y, z }); return { id, health: 24 }; },
    raider: id => { const r = raiders.get(id); return r ? { id, ...r } : null; },
    villagers: () => state.villagers, spawnY: () => 64, inVillage: (x, _y, z) => Math.hypot(x, z) < 20,
    onEvent: e => events.push(e.type),
  };
  const raid = new Raid([0, 64, 0], omen, difficulty === 'hard' ? 'hard' : difficulty === 'normal' ? 'normal' : 'easy');
  const tick = (n = 1) => { for (let i = 0; i < n; i++) raid.tick(world); };
  const killAll = () => { for (const id of [...raid.members]) { raiders.delete(id); raid.onRaiderKilled(id, true); } };
  return { raid, world, raiders, events, tick, killAll, state };
}
test('raid: the bar charges for 300 ticks, then wave 1 spawns 64 blocks out with the horn; the bar tracks raider health', () => {
  const s = raidSim('easy');
  s.tick(150); assert.equal(s.raid.groupsSpawned, 0); assert.ok(Math.abs(s.raid.progress - 0.5) < 0.01, 'half charged'); assert.equal(s.raid.barName().en, 'Raid');
  s.tick(151); assert.equal(s.raid.groupsSpawned, 1); assert.ok(s.events.includes('horn') && s.events.includes('start'));
  const first = s.raiders.get(s.raid.members[0])!; const d = Math.hypot(first.x, first.z);
  assert.ok(d > 55 && d < 75, 'spawn distance ' + d.toFixed(0));
  assert.equal(s.raid.progress, 1);
  for (const id of s.raid.members) s.raiders.get(id)!.health = 12; s.tick();
  assert.ok(Math.abs(s.raid.progress - 0.5) < 1e-9, 'half health = half bar');
  for (const id of s.raid.members) s.raiders.get(id)!.health = 24; s.tick();
  assert.ok(Math.abs(s.raid.progress - 0.5) < 1e-9, 'healing does not refill the bar');
  while (s.raid.members.length > 2) { const id = s.raid.members[0]; s.raiders.delete(id); s.raid.onRaiderKilled(id, true); }
  assert.equal(s.raid.barName().en, 'Raid - 2 raiders remaining');
});
test('raid: 300 tick cooldown between waves, victory 40 ticks after the last wave, Hero of the Village, 600 ticks of celebration', () => {
  const s = raidSim('normal');
  s.tick(301);
  for (let wave = 1; wave <= 5; wave++) {
    assert.equal(s.raid.groupsSpawned, wave); assert.ok(s.raid.members.length >= 4, 'wave ' + wave + ' has raiders');
    s.killAll();
    if (wave < 5) { s.tick(200); assert.equal(s.raid.groupsSpawned, wave, 'still cooling down'); s.tick(102); }
  }
  s.tick(30); assert.equal(s.raid.status, 'ongoing'); s.tick(12);
  assert.equal(s.raid.status, 'victory'); assert.equal(s.raid.heroes, true); assert.equal(s.raid.barName().en, 'Raid - Victory');
  s.tick(590); assert.equal(s.raid.stopped, false, 'celebrating'); s.tick(12); assert.equal(s.raid.stopped, true, 'raid object removed after 600 ticks');
  assert.equal(RAID.heroTicks, 48000);
});
test('raid: Raid Omen II+ adds a bonus wave; Easy 3 / Hard 7 waves; difficulty is fixed when the raid starts', () => {
  const run = (d: string, omen: number) => { const s = raidSim(d, omen); s.tick(301); let waves = 0; while (s.raid.status === 'ongoing' && waves < 12) { waves = s.raid.groupsSpawned; s.killAll(); s.tick(345); } return s.raid.groupsSpawned; };
  assert.equal(run('easy', 1), 3); assert.equal(run('easy', 2), 4); assert.equal(run('normal', 5), 6); assert.equal(run('hard', 1), 7); assert.equal(run('hard', 3), 8);
  assert.equal(new Raid([0, 0, 0], 5, 'hard').enchantChance, 0.75); assert.equal(new Raid([0, 0, 0], 1, 'hard').enchantChance, 0);
});
test('raid: defeat when the village dies, raiders beyond 112 blocks leave, Peaceful stops it, 48 000 ticks expire it', () => {
  const s = raidSim('easy'); s.tick(301); s.state.villagers = 0; s.tick();
  assert.equal(s.raid.status, 'loss'); assert.equal(s.raid.barName().en, 'Raid - Defeat'); assert.ok(s.events.includes('celebrate'));
  const before = raidSim('easy'); before.state.villagers = 0; before.tick(); assert.equal(before.raid.stopped, true, 'no village before the first wave: the raid just ends');
  const far = raidSim('easy'); far.tick(301); const id = far.raid.members[0]; far.raiders.get(id)!.x = 500; far.tick(20);
  assert.ok(!far.raid.members.includes(id), 'strayed raider dropped from the raid');
  const peace = raidSim('easy'); peace.tick(10); peace.state.difficulty = 'peaceful'; peace.tick(); assert.equal(peace.raid.stopped, true);
  const long = raidSim('easy'); long.tick(301); long.tick(48000); assert.equal(long.raid.stopped, true); assert.ok(long.events.includes('expired'));
  const saved = Raid.load(JSON.parse(JSON.stringify(raidSim('hard', 2).raid.save()))); assert.equal(saved.total, 8); assert.equal(saved.omen, 2);
});

// ============================================================================================= MobManager integration
function manager(extra: object = {}) {
  const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 100);
  const toasts: string[] = [], effects: string[] = [];
  const getBlock = (_x: number, y: number) => (Math.floor(y) <= 64 ? ID.stone : 0);
  const mobs = new MobManager(new THREE.Scene(), {
    terrain: { height: () => 64, biome: () => 'plains' } as never, position: new THREE.Vector3(0.5, 65, 0.5), camera, dimension: 'overworld', dragonDefeated: false, time: 0,
    getBlock, damage() {}, addItem: () => true, toast: (_j: string, e: string) => { toasts.push(e); }, sound() {}, explode() {}, teleport() {}, openTrade() {},
    onDragonDefeated() {}, onEnterGateway() {}, levitate() {}, difficulty: () => 'normal', effect: (id: string) => { effects.push(id); },
    particles: { burst() {}, drop() {}, spark() {} } as never, ...extra,
  } as never);
  mobs.mobs = [];
  return { mobs, toasts, effects };
}
test('raid (integration): needs a village, 15 s of bar charge, wave 1 = 4-6 raiders with a captain, red boss bar, cooldown refills', () => {
  const { mobs, toasts } = manager();
  assert.equal(mobs.startRaid(), false, 'no villagers, no raid');
  for (let i = 0; i < 4; i++) mobs.spawn('villager', i, 2, false, 65);
  assert.equal(mobs.startRaid(undefined, 1), true); assert.equal(mobs.startRaid(), false, 'one raid at a time');
  assert.equal(mobs.raid!.total, 5, 'Normal = 5 waves');
  for (let i = 0; i < 150; i++) mobs.update(0.05, 1, false);
  const bar = mobs.getBossInfo()!; assert.equal(bar.name, 'Raid'); assert.ok(bar.hp > 40 && bar.hp < 60, 'bar half charged: ' + bar.hp);
  assert.equal(mobs.mobs.filter(m => m.raidMember).length, 0);
  for (let i = 0; i < 160; i++) mobs.update(0.05, 1, false);
  const raiders = mobs.mobs.filter(m => m.raidMember);
  assert.equal(mobs.raid!.wave, 1); assert.ok(raiders.length >= 4 && raiders.length <= 6, 'raiders=' + raiders.length);
  assert.equal(raiders.filter(m => m.captain).length, 1); assert.ok(raiders.every(m => ['pillager', 'vindicator'].includes(m.species)));
  assert.ok(toasts.some(t => t.startsWith('Raid wave 1/5')));
  assert.ok(mobs.isPersistent(raiders[0]), 'raiders do not despawn or count towards the mob cap');
  for (const m of [...raiders]) mobs.kill(m);
  for (const m of [...mobs.mobs]) if (m.raidMember) { m.hp = 0; mobs.mobs.splice(mobs.mobs.indexOf(m), 1); }
  mobs.update(0.05, 1, false); mobs.update(0.05, 1, false);
  assert.equal(mobs.raid!.members.length, 0); assert.ok(mobs.raid!.cooldown > 250, 'cooldown restarted');
  mobs.dispose();
});
test('spawning (integration): with the game environment the manager runs the Java spawner — night monsters outside 24 blocks, caps respected', () => {
  const env = { raining: false, thundering: false, chunkRadius: 6, seed: 7, spawnMonsters: true, spawnAnimals: true, raids: true, capScale: 1 };
  const { mobs } = manager({ spawnEnv: () => env, blockLight: () => 0 });
  for (let i = 0; i < 400; i++) mobs.update(0.05, 0, false);
  const cap = mobCap('monster', NaturalSpawner.capChunks(6));
  const monsters = mobs.mobs.filter(m => categoryOf(m.species) === 'monster');
  assert.ok(monsters.length > 5 && monsters.length <= cap + 3, `monsters=${monsters.length} cap=${cap}`);
  assert.equal(mobs.categoryCounts().monster, monsters.length);
  const lit = manager({ spawnEnv: () => env, blockLight: () => 4 });
  for (let i = 0; i < 200; i++) lit.mobs.update(0.05, 0, false);
  assert.equal(lit.mobs.mobs.filter(m => categoryOf(m.species) === 'monster').length, 0, 'torch-lit ground spawns nothing');
  const day = manager({ spawnEnv: () => env, blockLight: () => 0 });
  for (let i = 0; i < 200; i++) day.mobs.update(0.05, 1, false);
  assert.equal(day.mobs.mobs.filter(m => categoryOf(m.species) === 'monster').length, 0, 'no surface monsters at noon');
  mobs.dispose(); lit.mobs.dispose(); day.mobs.dispose();
});

const failed = results.filter(r => !r.ok);
for (const r of results) console.log((r.ok ? 'ok   ' : 'FAIL ') + r.name + (r.note ? '\n       ' + r.note : ''));
console.log(`\n${results.length - failed.length} / ${results.length} checks passed`);
void BLOCKS;
if (failed.length) process.exit(1);
