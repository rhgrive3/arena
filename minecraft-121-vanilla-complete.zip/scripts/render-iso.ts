// Oblique voxel render of really generated chunks (same data the game meshes), for checking terrain shape and decoration.
// Usage: node render-iso.mjs <seed> <out.png> <target,target,...>   target = biome name | "spawn" | "x:z"
import fs from 'node:fs';
import zlib from 'node:zlib';
import '../src/game/content';
import { BLOCKS, ID } from '../src/game/data';
import { blockId } from '../src/game/blockState';
import { Terrain, MIN_Y, HEIGHT } from '../src/world/terrain';

const [seed = '849281', out = '/tmp/iso.png', list = 'spawn'] = process.argv.slice(2);
const targets = list.split(','), t = new Terrain(seed);
const CH = 9, N = CH * 16, A = 2, B = 1, C = 2, Y0 = 34, Y1 = 196, TW = N * 2 * A, TH = N * 2 * B + (Y1 - Y0) * C + 8;
const cols = Math.min(2, targets.length), rows = Math.ceil(targets.length / cols), W = TW * cols, Hh = TH * rows, img = new Uint8Array(W * Hh * 3).fill(18);
const hex = (h: string) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const base = BLOCKS.map(b => hex(b.color.length === 7 ? b.color : '#888888'));
function png(w: number, h: number, rgb: Uint8Array) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) Buffer.from(rgb.buffer, y * w * 3, w * 3).copy(raw, y * (w * 3 + 1) + 1);
  const table = new Int32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; table[n] = c; }
  const crc = (b: Buffer) => { let c = -1; for (const v of b) c = table[(c ^ v) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
  const chunk = (type: string, data: Buffer) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]), c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([len, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

targets.forEach((target, ti) => {
  let px = 6, pz = 12;
  if (/^-?\d+:-?\d+$/.test(target)) [px, pz] = target.split(':').map(Number);
  else if (target === 'peak') { let best = -1; for (let z = -2600; z <= 2600; z += 20) for (let x = -2600; x <= 2600; x += 20) { const h = t.height(x, z); if (h > best) { best = h; px = x; pz = z; } } }
  else if (target !== 'spawn') { const p = t.locate(target, target === 'village' ? 400 : -11, target === 'village' ? 400 : 27); if (!p) { console.log('not found:', target); return; } px = p[0]; pz = p[2]; }
  const cx0 = Math.floor(px / 16) - (CH >> 1), cz0 = Math.floor(pz / 16) - (CH >> 1), ox = (ti % cols) * TW, oy = Math.floor(ti / cols) * TH;
  const vox = new Uint16Array(N * N * HEIGHT), tint = new Float32Array(N * N * 3), top = new Int16Array(N * N);
  for (let cz = 0; cz < CH; cz++) for (let cx = 0; cx < CH; cx++) {
    const g = t.generate(cx0 + cx, cz0 + cz);
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
      const gi = (cz * 16 + z) * N + cx * 16 + x;
      for (let k = 0; k < 3; k++) tint[gi * 3 + k] = g.tint[(z * 16 + x) * 3 + k];
      let hi = 0;
      for (let y = 0; y < HEIGHT; y++) { const id = blockId(g.data[y * 256 + z * 16 + x]); vox[gi * HEIGHT + y] = id; if (id) hi = y; }
      top[gi] = hi + MIN_Y;
    }
  }
  const seen: Record<string, number> = {}; let minH = 999, maxH = -999, maxStep = 0;
  for (let z = 0; z < N; z++) for (let x = 0; x < N; x++) {
    const wx = cx0 * 16 + x, wz = cz0 * 16 + z, h = t.height(wx, wz), b = t.biomeAt(wx, wz, h);
    seen[b] = (seen[b] ?? 0) + 1; minH = Math.min(minH, h); maxH = Math.max(maxH, h);
    if (x + 1 < N) maxStep = Math.max(maxStep, Math.abs(t.height(wx + 1, wz) - h));
  }
  const px3 = (sx: number, sy: number, c: number[], f: number) => { if (sx < 0 || sx >= TW || sy < 0 || sy >= TH) return; const o = ((oy + sy) * W + ox + sx) * 3; img[o] = Math.min(255, c[0] * f); img[o + 1] = Math.min(255, c[1] * f); img[o + 2] = Math.min(255, c[2] * f); };
  for (let d = 0; d <= 2 * N - 2; d++) for (let x = Math.max(0, d - N + 1); x <= Math.min(N - 1, d); x++) {
    const z = d - x, gi = z * N + x, tp = top[gi];
    const front = Math.min(x + 1 < N ? top[gi + 1] : Y0, z + 1 < N ? top[gi + N] : Y0, tp);
    const sx = (x - z) * A + TW / 2 - A;
    for (let y = Math.max(Y0, front - 1); y <= Math.min(Y1, tp); y++) {
      const id = vox[gi * HEIGHT + (y - MIN_Y)];
      if (!id) continue;
      const def = BLOCKS[id]; let c = base[id];
      if (def.pattern === 'grass' && def.name === 'grass_block') c = [tint[gi * 3] * 150, tint[gi * 3 + 1] * 150, tint[gi * 3 + 2] * 150];
      else if (def.pattern === 'leaves' && !/cherry|azalea/.test(def.name)) c = [tint[gi * 3] * 112, tint[gi * 3 + 1] * 118, tint[gi * 3 + 2] * 105];
      else if (id === ID.water) c = [58, 112, 205];
      const sy = (x + z) * B - (y - Y0) * C + (Y1 - Y0) * C + 4, small = def.shape === 'cross' || def.shape === 'lily' || def.shape === 'torch';
      if (small) { px3(sx + 1, sy + 1, c, 1.05); px3(sx + 2, sy + 1, c, 0.95); continue; }
      const isWater = id === ID.water, above = y - MIN_Y + 1 < HEIGHT ? vox[gi * HEIGHT + (y - MIN_Y + 1)] : 0;
      if (!(isWater && above === ID.water)) for (let i = 0; i < 2 * A; i++) for (let j = 0; j < 2 * B; j++) px3(sx + i, sy + j, c, isWater ? 1 : 1.08);
      if (!isWater) for (let i = 0; i < 2 * A; i++) for (let j = 0; j < C; j++) px3(sx + i, sy + 2 * B + j, c, i < A ? 0.8 : 0.62);
    }
  }
  console.log(`[${ti + 1}] ${target} @ ${px},${pz} · ground ${minH}…${maxH} · max step ${maxStep} · ` + Object.entries(seen).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, v]) => `${k} ${Math.round(v / (N * N) * 100)}%`).join(', '));
});
fs.writeFileSync(out, png(W, Hh, img));
console.log('wrote', out, W + 'x' + Hh);
