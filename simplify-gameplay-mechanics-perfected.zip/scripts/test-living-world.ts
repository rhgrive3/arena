import assert from 'node:assert/strict';
import * as THREE from 'three';
import { BLOCKS, ID, resolve } from '../src/game/data';
import '../src/game/content';
import { stateForPlacement } from '../src/game/blockState';
import { collisionBoxes } from '../src/world/shapes';
import { Farming, cropDrops } from '../src/systems/farming';
import { blockDrops } from '../src/systems/mining';
import { canStand, findPath } from '../src/entities/pathfinding';
import { MobManager, SPECIES, type MobHost } from '../src/entities/mobs';
import * as V from '../src/entities/villagers';
import { Redstone, type RedstoneHost, type PistonMove } from '../src/systems/redstone';
import { findCrafterRecipe, insertStack, transferOne } from '../src/systems/automation';
import { matchGrid } from '../src/systems/crafting';
import { Fishing, fishingLoot, lootChances, rollLoot } from '../src/systems/fishing';
import { VehicleManager, MAX_CART_SPEED } from '../src/entities/vehicles';
import { random } from '../src/input/math';
import type { Stack } from '../src/game/types';

let passed = 0, failed = 0;
function test(name: string, run: () => void) {
  try {
    run();
    console.log('PASS  ' + name);
    passed++;
  } catch (e) {
    console.error('FAIL  ' + name, e);
    failed++;
  }
}

class World implements RedstoneHost {
  cells = new Map<string, number>();
  daylight?: () => number;
  raining?: () => boolean;
  transfers = 0;
  crafts = 0;
  moveBlocks?: (moves: PistonMove[], duration: number) => void;
  getCell(x: number, y: number, z: number) { return this.cells.get(`${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`) ?? 0; }
  getBlock(x: number, y: number, z: number) { const c = this.getCell(x, y, z); return c < 0 ? -1 : c & 4095; }
  setBlock(x: number, y: number, z: number, id: number, state = 0) {
    const k = `${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`, c = id ? id | (state << 12) : 0;
    if (this.getCell(x, y, z) === c) return false;
    if (c === 0) this.cells.delete(k); else this.cells.set(k, c);
    return true;
  }
  put(x: number, y: number, z: number, n: string, state = 0) { this.setBlock(x, y, z, n === 'air' ? 0 : ID[n], state); }
  transfer() { this.transfers++; return true; }
  craft() { this.crafts++; return true; }
}

const farm = (rng: () => number = () => 0) => { const w = new World(), f = new Farming(w, rng); return { w, f }; };

// ---- 1. Farming, Light Check, Vanilla 3x3 Growth Formula, Trampling, Mega Trees, Giant Mushrooms, Composter
test('hoe turns unobstructed grass into farmland and refuses obstructed surface', () => {
  const { w, f } = farm();
  w.put(0, 0, 0, 'grass_block');
  assert.equal(f.interact('iron_hoe', { x: 0, y: 0, z: 0 }), 'till');
  assert.equal(w.getBlock(0, 0, 0), ID.farmland);
  w.put(1, 0, 0, 'dirt'); w.put(1, 1, 0, 'stone');
  assert.equal(f.interact('iron_hoe', { x: 1, y: 0, z: 0 }), 'blocked');
});
test('coarse dirt and rooted dirt take two passes with a hoe', () => {
  const { w, f } = farm();
  w.put(0, 0, 0, 'coarse_dirt');
  f.interact('wooden_hoe', { x: 0, y: 0, z: 0 });
  assert.equal(w.getBlock(0, 0, 0), ID.dirt);
  f.interact('wooden_hoe', { x: 0, y: 0, z: 0 });
  assert.equal(w.getBlock(0, 0, 0), ID.farmland);
});
test('crops stop growing in darkness (light < 9) and grow underground next to a torch', () => {
  const { w, f } = farm();
  w.put(0, 0, 0, 'farmland', 7);
  w.put(0, 1, 0, 'wheat_crop', 0);
  f.randomTick(0, 1, 0, 0);
  assert.equal(w.getCell(0, 1, 0) >>> 12, 0, 'darkness halts growth');
  w.put(1, 1, 0, 'torch');
  f.randomTick(0, 1, 0, 0);
  assert.equal(w.getCell(0, 1, 0) >>> 12, 1, 'torch light >= 9 enables underground growth');
});
test('growthChance follows the vanilla 3x3 farmland hydration & crowding formula', () => {
  const { w, f } = farm();
  w.put(0, 0, 0, 'farmland', 0); w.put(0, 1, 0, 'wheat_crop', 0);
  assert.equal(f.growthChance(0, 1, 0, ID.wheat_crop), 1 / 13);
  w.put(0, 0, 0, 'farmland_moist');
  assert.equal(f.growthChance(0, 1, 0, ID.wheat_crop), 1 / 7);
  for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) w.put(dx, 0, dz, 'farmland_moist');
  assert.equal(f.growthChance(0, 1, 0, ID.wheat_crop), 1 / 3);
  for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) if (dx || dz) w.put(dx, 1, dz, 'wheat_crop', 2);
  assert.equal(f.growthChance(0, 1, 0, ID.wheat_crop), 1 / 6, 'crowded halves growth points');
});
test('farmland trampling reverts farmland to dirt and pops the crop above', () => {
  const { w, f } = farm();
  const dropped: string[] = [];
  (w as any).drop = (_x: number, _y: number, _z: number, name: string) => dropped.push(name);
  w.put(0, 0, 0, 'farmland', 7);
  w.put(0, 1, 0, 'wheat_crop', 7);
  assert.equal(f.trample(0, 0, 0), true);
  assert.equal(w.getBlock(0, 0, 0), ID.dirt);
  assert.equal(w.getBlock(0, 1, 0), 0);
  assert.ok(dropped.includes('wheat'));
});
test('blocked tree growth is atomic and 2x2 spruce saplings grow a mega tree', () => {
  const { w, f } = farm();
  w.put(0, 0, 0, 'dirt'); w.put(0, 1, 0, 'oak_sapling'); w.put(0, 3, 0, 'stone');
  const before = [...w.cells];
  assert.equal(f.growTree(0, 1, 0), false);
  assert.deepEqual([...w.cells], before);

  const { w: w2, f: f2 } = farm();
  for (let dx = -5; dx <= 6; dx++) for (let dz = -5; dz <= 6; dz++) w2.put(dx, 0, dz, 'grass_block');
  for (const [dx, dz] of [[0, 0], [1, 0], [0, 1], [1, 1]]) w2.put(dx, 1, dz, 'spruce_sapling');
  assert.equal(f2.growTree(0, 1, 0), true);
  for (const [dx, dz] of [[0, 0], [1, 0], [0, 1], [1, 1]]) assert.equal(w2.getBlock(dx, 1, dz), ID.spruce_log);
});
test('bone meal on a mushroom grows a huge mushroom', () => {
  const { w, f } = farm();
  w.put(0, 0, 0, 'mycelium'); w.put(0, 1, 0, 'red_mushroom');
  assert.equal(f.bonemeal(0, 1, 0), true);
  assert.ok([...w.cells.values()].some(c => (c & 4095) === ID.red_mushroom_block));
});
test('composter fills in 7 layers to state 8 and yields bone meal', () => {
  const { w, f } = farm(() => 0);
  w.put(0, 0, 0, 'composter');
  for (let i = 0; i < 6; i++) assert.equal(f.compost(0, 0, 0, 'wheat_seeds'), 'added');
  assert.equal(f.compost(0, 0, 0, 'wheat_seeds'), 'full');
  assert.equal(w.getCell(0, 0, 0) >>> 12, 8);
  assert.equal(f.compost(0, 0, 0, null), 'collected');
  assert.equal(w.getCell(0, 0, 0) >>> 12, 0);
});
test('Fortune increases mature crop yields', () => {
  const r = random(11);
  let base = 0, fort = 0;
  for (let i = 0; i < 200; i++) {
    base += cropDrops('carrots', 7, r, 0)[0].count;
    fort += cropDrops('carrots', 7, r, 3)[0].count;
  }
  assert.ok(fort > base, `fortune (${fort}) > base (${base})`);
  assert.ok(blockDrops(BLOCKS[ID.carrot_crop], undefined, 7, () => 0)[0].count >= 2);
});

// ---- 2. All 79 Mob Species, 3D Aquatic Swimming, Special AI, Interactions, Save/Load Persistence
function mobWorld() {
  const w = new World(), position = new THREE.Vector3(0, 65, 8), camera = new THREE.PerspectiveCamera();
  camera.position.set(0, 66, 8);
  let consumed = 0, moving = false, sneaking = false, playerDmg = 0;
  const effects: Record<string, number> = {};
  const host: MobHost = {
    terrain: { height: () => 64, biome: () => 'plains' } as any,
    position, camera, time: 0.2, dimension: 'overworld', dragonDefeated: false,
    getBlock: (x, y, z) => y < 65 ? ID.stone : w.getBlock(x, y, z),
    damage: n => { playerDmg += n; },
    addItem: () => true,
    toast: () => {},
    sound: () => {},
    explode: () => {},
    teleport: () => {},
    openTrade: () => {},
    onDragonDefeated: () => {},
    onEnterGateway: () => {},
    levitate: () => {},
    consume: () => { consumed++; return true; },
    playerMoving: () => moving,
    sneaking: () => sneaking,
    effect: (id, sec) => { effects[id] = sec; },
    particles: { burst: () => {}, spark: () => {}, drop: () => {} },
  };
  const m = new MobManager(new THREE.Scene(), host);
  m.clear();
  m.rnd = () => 0.1;
  return { w, m, host, consumed: () => consumed, effects, dmg: () => playerDmg, move: (v: boolean) => moving = v, sneak: (v: boolean) => sneaking = v };
}
const interact = (m: MobManager, item: string) => m.interact(new THREE.Vector3(0, 65.8, 2), new THREE.Vector3(0, 0, -1), item);

test('all 79 mob species have valid spawnable 3D models and stats', () => {
  const { m } = mobWorld();
  assert.equal(SPECIES.length, 79);
  for (const s of SPECIES) {
    const mdl = m.model(s);
    assert.ok(mdl.g.children.length > 0, s + ' model');
  }
  assert.equal(m.spawn('unknown' as any, 0, 0), undefined);
  m.dispose();
});
test('3D aquatic swimming keeps fish in water columns instead of y=19.4 underground', () => {
  const { m, w } = mobWorld();
  for (let x = -4; x <= 4; x++) for (let z = -4; z <= 4; z++) for (let y = 65; y <= 70; y++) w.put(x, y, z, 'water');
  const salmon = m.spawn('salmon', 0, 0, false, 68)!;
  for (let i = 0; i < 40; i++) m.update(0.05, 0.8, false);
  assert.ok(salmon.group.position.y >= 65 && salmon.group.position.y <= 70.5, 'salmon swam at y=' + salmon.group.position.y);
  m.dispose();
});
test('pufferfish inflates and inflicts poison when the player is close; tadpole grows into frog', () => {
  const { m, w, host, effects } = mobWorld();
  for (let x = -4; x <= 4; x++) for (let z = -4; z <= 4; z++) for (let y = 65; y <= 70; y++) w.put(x, y, z, 'water');
  host.position.set(0, 67, 1);
  const pf = m.spawn('pufferfish', 0, 0, false, 67)!;
  m.update(0.1, 0.8, false);
  assert.ok(pf.group.scale.x > 0.7, 'inflated');
  assert.ok(effects.poison > 0, 'poisoned player');

  const tad = m.spawn('tadpole', 0, 0, false, 67)!;
  tad.grow = 0.05;
  m.update(0.1, 0.8, false);
  assert.equal(tad.species, 'frog');
  m.dispose();
});
test('zombie villager is cured into a villager with a golden apple', () => {
  const { m, consumed } = mobWorld();
  const zv = m.spawn('zombie_villager', 0, 0, false, 65)!;
  assert.equal(interact(m, 'golden_apple'), true);
  assert.equal(zv.species, 'villager');
  assert.equal(consumed(), 1);
  m.dispose();
});
test('breeding, taming, saddle equipment, leash to fence, wall sight check, and JSON save/load round-trip', () => {
  const { m, w, consumed } = mobWorld();
  const a = m.spawn('cow', 0, 0, false, 65)!, b = m.spawn('cow', 1, 0, false, 65)!;
  assert.equal(interact(m, 'wheat'), true);
  b.love = 30;
  m.update(0.1, 0.4, false);
  assert.equal(m.mobs.filter(x => x.baby).length, 1);
  assert.ok(a.breedCooldown > 290);

  m.clear();
  const horse = m.spawn('horse', 0, 0, false, 65)!;
  interact(m, 'saddle');
  assert.equal(horse.saddled, undefined);
  interact(m, '');
  assert.equal(horse.tamed, true);
  interact(m, 'saddle');
  assert.equal(horse.saddled, true);
  interact(m, '');
  assert.equal(m.riding, horse);
  m.dismount();

  interact(m, 'lead');
  assert.equal(horse.leashed, true);
  assert.equal(m.tieLeashes(2, 65, 2), 1);
  assert.deepEqual(horse.leashPos, [2, 65, 2]);

  const saved = JSON.parse(JSON.stringify(m.save()));
  m.load(saved);
  assert.equal(m.mobs[0].tamed, true);
  assert.equal(m.mobs[0].saddled, true);
  assert.deepEqual(m.mobs[0].leashPos, [2, 65, 2]);

  m.clear();
  m.spawn('cow', 0, 0, false, 65);
  w.put(0, 65, 1, 'stone'); w.put(0, 66, 1, 'stone');
  const prevConsumed = consumed();
  assert.equal(interact(m, 'wheat'), false, 'wall blocks interaction');
  assert.equal(consumed(), prevConsumed);
  m.dispose();
});
test('villagers claim job sites, level up, restock with demand pricing, and raids run waves', () => {
  const w = new World(), v = V.newVillager(7);
  w.put(1, 1, 0, 'composter');
  V.updateJob(v, w, { x: 0, y: 1, z: 0 }, new Set());
  assert.equal(v.profession, 'farmer');
  assert.equal(V.getTradeOffers(v).length, 2);
  for (let i = 0; i < 10 && v.level < 2; i++) V.useOffer(v, 0);
  assert.equal(v.level, 2);
  assert.ok(V.getTradeOffers(v).length >= 3);

  const { m } = mobWorld();
  assert.equal(m.startRaid(), false);
  m.spawn('villager', 0, 0, false, 65);
  assert.equal(m.startRaid(), true);
  assert.equal(m.raid?.total, 3);
  m.update(4.1, 0.4, false);
  assert.equal(m.raid?.wave, 1);
  assert.equal(m.raid?.members.length, 3);
  m.dispose();
});

// ---- 3. Fishing (Open-Water Check, Loot Table, Mob Hooking)
test('fishing loot chances, open-water treasure check, and mob hooking', () => {
  const c0 = lootChances(0), c3 = lootChances(3);
  assert.ok(Math.abs(c0.fish - 0.85) < 1e-9 && Math.abs(c3.treasure - 0.113) < 1e-9);
  const r = random(77);
  for (let i = 0; i < 500; i++) assert.notEqual(rollLoot(3, false, r).kind, 'treasure');
  let fi = 0; assert.equal(fishingLoot(() => (fi++ === 0 ? 0.8 : 0)), 'cod');

  const scene = new THREE.Scene();
  const f = new Fishing(scene, { getBlock: (_x, y) => (y < 60 ? ID.stone : 0), particles: { burst() {} }, sound() {} }, () => 0.5);
  const { m } = mobWorld();
  const cow = m.spawn('cow', 0, 2, false, 60)!;
  f.cast(new THREE.Vector3(0, 61.2, 4), new THREE.Vector3(0, -0.1, -1));
  for (let i = 0; i < 20; i++) f.update(0.02, new THREE.Vector3(0, 61.2, 4), () => m.mobs);
  assert.equal(f.bobber?.state, 'hooked');
  assert.equal(f.bobber?.hookedMob, cow);
  const reel = f.reel(0)!;
  assert.equal(reel.hookedMob, cow);
  assert.equal(reel.wear, 3);
  m.dispose();
});

// ---- 4. Vehicles (Minecart Detector/Activator Rails, Boat on Ice, Save/Load)
test('minecart detector rail, activator rail dismount, and boat high speed on blue ice', () => {
  const w = new World();
  for (let x = 0; x <= 20; x++) w.put(x, 63, 0, 'stone');
  for (let x = 0; x <= 20; x++) w.put(x, 64, 0, x === 5 ? 'detector_rail' : x === 10 ? 'activator_rail' : 'powered_rail', x === 5 ? 0 : 8);
  const v = new VehicleManager(new THREE.Scene(), {
    getCell: (x, y, z) => w.getCell(x, y, z),
    getBlock: (x, y, z) => w.getBlock(x, y, z),
    setBlock: (x, y, z, id, st = 0) => w.setBlock(x, y, z, id, st),
    drop: () => {},
    sound: () => {},
  });
  const cart = v.spawn('minecart', 0.5, 64.0625, 0.5);
  cart.dx = 1; cart.speed = 6;
  v.mount(cart);
  let detectorLit = false;
  for (let i = 0; i < 150; i++) {
    v.update(0.02, { move: { x: 0, z: 0 }, yaw: 0, run: false, ascend: false });
    if ((w.getCell(5, 64, 0) >>> 12) & 8) detectorLit = true;
  }
  assert.ok(detectorLit, 'detector rail powered under cart');
  assert.equal(v.riding, null, 'powered activator rail dismounted rider');
  assert.ok(cart.speed <= MAX_CART_SPEED + 1e-6);

  // Boat on blue ice vs land
  const iceWorld = new World();
  for (let z = -40; z <= 5; z++) for (let x = -2; x <= 2; x++) iceWorld.put(x, 63, z, 'blue_ice');
  const vIce = new VehicleManager(new THREE.Scene(), {
    getCell: (x, y, z) => iceWorld.getCell(x, y, z),
    getBlock: (x, y, z) => iceWorld.getBlock(x, y, z),
  });
  const boat = vIce.spawn('boat', 0.5, 64, 0.5);
  vIce.mount(boat);
  for (let i = 0; i < 100; i++) vIce.update(0.02, { forward: 1, strafe: 0, yaw: 0 });
  assert.ok(boat.pos.z < -15, 'boat glides fast on blue ice: z=' + boat.pos.z.toFixed(1));
});

// ---- 5. Crafter, Hopper Automation, Directional Placement, and Piston Head Shape
test('crafter grid matching, disabled slot bitmask, balanced hopper insertion, and directional placement', () => {
  const g = (rows: string[], key: Record<string, string>) => rows.join('').split('').map(c => key[c] ?? null);
  assert.deepEqual(matchGrid(g(['   ', 'WWW', '   '], { W: 'wheat' })), { result: 'bread', count: 1 });
  assert.equal(matchGrid(g(['  S', ' ST', 'S T'], { S: 'stick', T: 'string' }))?.result, 'fishing_rod');
  assert.equal(matchGrid(g(['S  ', 'TS ', 'T S'], { S: 'stick', T: 'string' }))?.result, 'fishing_rod', 'mirrored');

  const src: (Stack | null)[] = [{ name: 'wheat', count: 4 }];
  const dst: (Stack | null)[] = Array(9).fill(null);
  transferOne(src, dst, 1, true);
  assert.equal(dst[0], null, 'slot 0 disabled');
  assert.equal(dst[1]?.name, 'wheat');

  const src2: (Stack | null)[] = [{ name: 'wheat', count: 4 }];
  const dst2: (Stack | null)[] = Array(3).fill(null);
  transferOne(src2, dst2, 0, true);
  transferOne(src2, dst2, 0, true);
  transferOne(src2, dst2, 0, true);
  assert.deepEqual(dst2.map(s => s?.count), [1, 1, 1], 'balanced distribution');

  // Furnace side hopper inserts fuel into slot 1, top hopper inserts into slot 0
  const fSlots: (Stack | null)[] = [null, null, null];
  transferOne([{ name: 'coal', count: 2 }], fSlots, 0, false, true);
  assert.equal(fSlots[1]?.name, 'coal', 'side hopper inserts fuel into slot 1');
  transferOne([{ name: 'raw_iron', count: 2 }], fSlots, 0, false, false);
  assert.equal(fSlots[0]?.name, 'raw_iron', 'top hopper inserts ore into slot 0');

  // Directional placement & PISTON_HEAD shape
  assert.equal(stateForPlacement(BLOCKS[ID.piston], 0, { x: 0, y: 1, z: 0 }, 0.5, 1.3), 5, 'looking steeply up places piston facing down');
  assert.equal(stateForPlacement(BLOCKS[ID.hopper], 0, { x: 1, y: 0, z: 0 }, 0.5, 0), 2, 'hopper outputs into clicked +X face (-X=2)');
  assert.equal(collisionBoxes(BLOCKS[ID.piston_head], 0).length, 2, 'piston_head has 2 boxes (plate + rod)');
});

console.log(`\n${passed}/${passed + failed} unified living-world checks passed`);
if (failed) process.exitCode = 1;
