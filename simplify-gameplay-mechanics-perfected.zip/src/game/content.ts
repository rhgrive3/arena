import { block, item, ID, BLOCKS, ITEM_ID, type Pattern } from "./data";
const woods:Record<string,[string,string,string]>={spruce:['トウヒ','#66503a','#426b45'],jungle:['ジャングル','#9a7853','#4f8a3b'],acacia:['アカシア','#a06b4c','#8b9b49'],dark_oak:['ダークオーク','#4f3d29','#456d30'],cherry:['サクラ','#d6a398','#e5a9ba'],mangrove:['マングローブ','#865044','#5d853e'],pale_oak:['ペールオーク','#c9c5b4','#b8c4a2'],crimson:['真紅','#814653','#943f50'],warped:['歪んだ','#4c7774','#3c9b8d'],poplar:['ポプラ','#b8ad82','#b7b957']};
for(const [name,[ja,bark,leaf]] of Object.entries(woods)){
  block(name+'_log',ja+'の原木',bark,'bark',2,{tool:'axe',category:'nature'});
  block(name+'_leaves',ja+'の葉',leaf,'leaves',.2,{transparent:true,category:'nature'});
  block(name+'_planks',ja+'の板材',bark,'planks',2,{tool:'axe'});
  block(name+'_sapling',ja+'の苗木',leaf,'plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
}
block('birch_planks','シラカバの板材','#cbb783','planks',2,{tool:'axe'});
const stones:Record<string,[string,string,any,number]>={granite:['花崗岩','#a17d6c','stone',1.5],diorite:['閃緑岩','#c7c6bb','stone',1.5],andesite:['安山岩','#93988d','stone',1.5],deepslate:['深層岩','#55595b','deepslate',3],tuff:['凝灰岩','#7d8273','stone',1.5],calcite:['方解石','#dedbd0','stone',.75],basalt:['玄武岩','#4a4c4f','deepslate',1.25],blackstone:['ブラックストーン','#322d33','stone',1.5],sandstone:['砂岩','#dfd3a2','stone',.8],chiseled_sandstone:['模様入りの砂岩','#dfd3a2','stone',.8],cut_sandstone:['研がれた砂岩','#e4d9aa','stone',.8],smooth_sandstone:['滑らかな砂岩','#e3d7a7','sand',.8],red_sandstone:['赤い砂岩','#b96a38','stone',.8],red_sand:['赤い砂','#c97c40','sand',.5],terracotta:['テラコッタ','#aa664a','terracotta',1.25],quartz_block:['クォーツブロック','#e7e2d6','quartz',.8],prismarine:['プリズマリン','#6caa9d','prismarine',1.5],purpur_block:['プルパーブロック','#a87ba8','purpur',1.5],purpur_pillar:['プルパーの柱','#b184b1','purpur',1.5],nether_bricks:['ネザーレンガ','#3f2127','bricks',2],end_stone_bricks:['エンドストーンレンガ','#dcd9a1','bricks',3],moss_block:['苔ブロック','#728d3d','grass',.1],mycelium:['菌糸','#8e8290','grass',.6],podzol:['ポドゾル','#8b693c','grass',.5],mud:['泥','#655a50','dirt',.5],clay:['粘土','#a4abb0','dirt',.6],ice:['氷','#a4d4e4','glass',.5],packed_ice:['氷塊','#8ebdd4','ice',.5],cactus:['サボテン','#558434','cactus',.4],pumpkin:['カボチャ','#c98a32','bark',1],melon:['スイカ','#8aa342','bark',1],hay_block:['干し草の俵','#c5a447','bark',.5],bookshelf:['本棚','#b18b55','planks',1.5],sponge:['スポンジ','#c9c35c','sponge',.6],glowstone:['グロウストーン','#e3bc68','ore',.3],shroomlight:['シュルームライト','#f09b42','ore',1],sea_lantern:['シーランタン','#b9d9ce','prismarine',.3],magma_block:['マグマブロック','#b65326','lava',.5],soul_sand:['ソウルサンド','#5b4639','dirt',.5],soul_soil:['ソウルソイル','#4f3c31','dirt',.5],crying_obsidian:['泣く黒曜石','#35264c','obsidian',50],crimson_nylium:['真紅のナイリウム','#882b2e','nylium',.4],warped_nylium:['歪んだナイリウム','#2d7873','nylium',.4],ancient_debris:['古代の残骸','#654b42','debris',30],emerald_ore:['エメラルド鉱石','#8c938b','ore',3],lapis_ore:['ラピスラズリ鉱石','#8c938b','ore',3],redstone_ore:['レッドストーン鉱石','#8c938b','ore',3],copper_ore:['銅鉱石','#92918a','ore',3],nether_quartz_ore:['ネザークォーツ鉱石','#85433d','ore',3],nether_gold_ore:['ネザー金鉱石','#85433d','ore',3],obsidian_bricks:['黒曜石レンガ','#3b354b','bricks',50],honey_block:['ハチミツブロック','#dca842','glass',.3],slime_block:['スライムブロック','#8fbd67','glass',.3],bone_block:['骨ブロック','#d6d1b9','rings',2],amethyst_block:['アメジストブロック','#9b7bb5','amethyst',1.5]};
for(const [name,[ja,color,pattern,hardness]] of Object.entries(stones))block(name,ja,color,pattern,hardness,{tool:name==='cactus'||name==='soul_sand'||name==='soul_soil'||name==='clay'||name==='red_sand'?'shovel':pattern==='ore'||pattern==='bricks'||pattern==='stone'||pattern==='purpur'||pattern==='debris'||pattern==='nylium'||pattern==='obsidian'?'pickaxe':'',tier:name==='ancient_debris'||name==='crying_obsidian'||name==='obsidian_bricks'?4:hardness>=3?2:1,shape:name==='cactus'?'cactus':'cube',transparent:name==='cactus'||name==='ice'||name==='honey_block'||name==='slime_block',category:name.includes('ore')||name==='ancient_debris'?'ores':name==='red_sand'||name==='cactus'||name.includes('nylium')||name.includes('soul')?'nature':'building',light:['glowstone','shroomlight','sea_lantern','magma_block','crying_obsidian'].includes(name)?15:0});
for(const ore of ['iron','gold','diamond','emerald','lapis','redstone','copper'])if(!ID[ore+'_ore'])block(ore+'_ore','鉱石','#8c938b','ore',3,{tool:'pickaxe',tier:2,category:'ores'});
for(const ore of ['coal','iron','gold','diamond','emerald','lapis','redstone','copper'])block('deepslate_'+ore+'_ore','深層'+ore+'鉱石','#55595b','ore',4.5,{tool:'pickaxe',tier:2,category:'ores'});
export const DYES:Record<string,string>={white:'#e4e2d8',orange:'#d98943',magenta:'#b65c9e',light_blue:'#79aeda',yellow:'#e1c34d',lime:'#8eb84c',pink:'#dfa0b1',gray:'#666d6b',light_gray:'#a7aaa0',cyan:'#4d9c9f',purple:'#8b65a8',blue:'#536fae',brown:'#87654b',green:'#6c8745',red:'#b95348',black:'#34383a'};
for(const [color,hex] of Object.entries(DYES)){
  const base=color+'_wool';if(!ID[base])block(base,color+' wool',hex,'wool',.8,{category:'decorations'});
  block(color+'_carpet',color+' carpet',hex,'wool',.1,{shape:'slab',category:'decorations'});
   block(color+'_concrete',color+' concrete',hex,'concrete',1.8,{tool:'pickaxe',tier:1,category:'building'});
  block(color+'_stained_glass',color+' stained glass',hex,'glass',.3,{transparent:true,category:'building'});
   block(color+'_terracotta',color+' terracotta',hex,'terracotta',1.25,{tool:'pickaxe',tier:1,category:'building'});
  item(color+'_dye',color+' dye',hex,'gem',{category:'materials'});
}
const shapeBases=['stone_bricks','cobblestone','sandstone','red_sandstone','oak_planks','spruce_planks','birch_planks','jungle_planks','acacia_planks','dark_oak_planks','cherry_planks','quartz_block','nether_bricks','purpur_block','end_stone_bricks','deepslate','granite','diorite','andesite'];
for(const base of shapeBases){const b=BLOCKS[ID[base]];if(!b)continue;for(const [suffix,shape,ja] of [['stairs','stairs','階段'],['slab','slab','ハーフブロック'],['wall','fence','壁'],['fence','fence','フェンス']])block(base+'_'+suffix,b.ja+ja,b.color,b.pattern,b.hardness,{tool:b.tool,tier:b.tier,shape:shape as any,category:'building'});}
for(const base of ['oak','birch','spruce','jungle','acacia','dark_oak','cherry']){const b=BLOCKS[ID[base+'_planks']];block(base+'_door',b.ja+'ドア',b.color,'planks',3,{tool:'axe',shape:'door',category:'building'});block('open_'+base+'_door',b.ja+'ドア（開）',b.color,'planks',3,{tool:'axe',shape:'pane',solid:false,transparent:true,category:'building'});block(base+'_trapdoor',b.ja+'トラップドア',b.color,'planks',3,{tool:'axe',shape:'trapdoor',category:'building'});block(base+'_pressure_plate',b.ja+'感圧板',b.color,'planks',.5,{shape:'slab',category:'redstone'});block(base+'_button',b.ja+'ボタン',b.color,'planks',.5,{shape:'torch',category:'redstone'});}
block('glass_pane','ガラス板','#b4dce1','glass',.3,{transparent:true,shape:'pane'});
block('iron_door','鉄のドア','#c4cbc7','metal',5,{tool:'pickaxe',tier:2,shape:'door'});block('open_iron_door','鉄のドア（開）','#c4cbc7','metal',5,{shape:'pane',solid:false,transparent:true});
block('redstone_lamp','レッドストーンランプ','#b98b4c','ore',.3,{light:15,category:'redstone'});
block('unlit_redstone_lamp','消灯ランプ','#715b3f','ore',.3,{category:'redstone'});
block('redstone_wire','レッドストーンダスト','#b74635','bricks',0,{solid:false,transparent:true,shape:'slab',category:'redstone'});
block('lever','レバー','#9b8c68','torch',.5,{shape:'torch',category:'redstone'});
block('piston','ピストン','#a99b73','craft',1.5,{category:'redstone'});
block('sticky_piston','粘着ピストン','#8ba35d','craft',1.5,{category:'redstone'});
block('observer','オブザーバー','#777c76','furnace',3,{tool:'pickaxe',tier:1,category:'redstone'});
block('hopper','ホッパー','#555d59','metal',3,{tool:'pickaxe',tier:1,category:'redstone'});
block('dropper','ドロッパー','#777c76','furnace',3.5,{tool:'pickaxe',tier:1,category:'redstone'});
block('dispenser','ディスペンサー','#777c76','furnace',3.5,{tool:'pickaxe',tier:1,category:'redstone'});
block('repeater','リピーター','#b7b3a5','bricks',.1,{shape:'slab',category:'redstone'});
block('comparator','コンパレーター','#b7b3a5','bricks',.1,{shape:'slab',category:'redstone'});
block('tnt','TNT','#bd5540','bricks',0,{category:'redstone'});
block('note_block','音符ブロック','#8b6547','planks',.8,{tool:'axe',category:'redstone'});
block('rail','レール','#a39a7e','bricks',.7,{solid:false,transparent:true,shape:'slab',category:'redstone'});
block('powered_rail','パワードレール','#c3a45b','bricks',.7,{solid:false,transparent:true,shape:'slab',category:'redstone'});
block('daylight_detector','日照センサー','#c6b797','bricks',.2,{shape:'slab',category:'redstone'});
block('target','的','#c9b8a0','rings',.5,{category:'redstone'});
block('farmland','耕地','#765436','dirt',.6,{tool:'shovel',shape:'slab',category:'nature'});
block('wheat_crop','小麦','#bda34d','plant',0,{solid:false,transparent:true,shape:'cross',drop:'wheat',category:'nature'});
block('oak_sapling','オークの苗木','#6e963f','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('birch_sapling','シラカバの苗木','#86a94e','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('sugar_cane','サトウキビ','#7fb069','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('beach_sand','砂浜','#e6d9a8','sand',.5,{tool:'shovel',category:'nature'});
block('red_mushroom','赤いキノコ','#c45443','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('brown_mushroom','茶色いキノコ','#a18461','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('cornflower','ヤグルマギク','#4e74d4','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('lily_of_the_valley','スズラン','#f3f5f0','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('orange_tulip','オレンジのチューリップ','#e57c35','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('pink_tulip','ピンクのチューリップ','#e89cb8','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('white_tulip','白いチューリップ','#f0eee6','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('oxeye_daisy','フランスギク','#f3f1e4','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('fern','シダ','#5d8e3e','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature',drop:'wheat_seeds'});
block('dead_bush','枯れ木','#8b693c','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature',drop:'stick'});
block('pink_petals','サクラの花びら','#f4b6c9','plant',0,{solid:false,transparent:true,shape:'lily',category:'nature'});
block('lily_pad','スイレンの葉','#4f8435','plant',0,{solid:false,transparent:true,shape:'lily',category:'nature'});
block('mossy_cobblestone','苔むした丸石','#798474','bricks',2,{tool:'pickaxe',tier:1,category:'building'});
block('mossy_stone_bricks','苔むした石レンガ','#838c7c','bricks',1.5,{tool:'pickaxe',tier:1,category:'building'});
block('coarse_dirt','粗い土','#7b563b','dirt',.5,{tool:'shovel',category:'nature'});
block('dirt_path','草の道','#a38953','grass',.65,{tool:'shovel',drop:'dirt',category:'nature'});
block('red_mushroom_block','赤いキノコブロック','#bd5548','mushroom',.2,{category:'nature'});
block('brown_mushroom_block','茶色いキノコブロック','#967b5d','mushroom',.2,{category:'nature'});
block('torchflower','トーチフラワー','#e4a34c','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('lantern','ランタン','#e1b65e','torch',3.5,{shape:'lantern',light:15,category:'utility'});
block('ladder','はしご','#b28b54','planks',.4,{solid:false,transparent:true,shape:'pane',category:'utility'});
block('barrel','樽','#a17b49','planks',2.5,{tool:'axe',category:'utility'});
block('brewing_stand','醸造台','#b39a5b','tool',.5,{shape:'brewing_stand',category:'utility'});
block('enchanting_table','エンチャントテーブル','#4c4557','obsidian',5,{tool:'pickaxe',tier:1,shape:'enchanting_table',category:'utility'});
block('anvil','金床','#5c625f','metal',5,{tool:'pickaxe',tier:1,shape:'anvil',category:'utility'});
block('grindstone','砥石','#8a8d82','stone',2,{tool:'pickaxe',tier:1,shape:'slab',category:'utility'});
block('loom','織機','#b39465','planks',2.5,{tool:'axe',category:'utility'});
block('stonecutter','石切台','#9a9d92','bricks',3.5,{tool:'pickaxe',tier:1,shape:'slab',category:'utility'});
block('blast_furnace','溶鉱炉','#686e6c','furnace',3.5,{tool:'pickaxe',tier:1,category:'utility'});
block('smoker','燻製器','#8b6b47','furnace',3.5,{tool:'axe',category:'utility'});
block('bed','ベッド','#c43d32','bed',.2,{shape:'bed',transparent:true,stack:1,category:'utility'});
block('portal','ネザーポータル','#8c48d8','water',100,{solid:false,transparent:true,shape:'pane',light:11,category:'utility'});
block('end_portal','エンドポータル','#121d26','water',Infinity,{solid:false,transparent:true,shape:'end_portal',light:15,category:'utility'});
block('end_portal_frame','エンドポータルフレーム','#4f7f6c','end_portal_frame',Infinity,{shape:'end_portal_frame',transparent:true,light:1,category:'utility'});
block('end_gateway','エンドゲートウェイ','#1d1c2e','water',Infinity,{solid:false,transparent:true,shape:'end_gateway',light:15,category:'utility'});
block('end_rod','エンドロッド','#f6f0dc','torch',0,{transparent:true,shape:'end_rod',light:15,category:'decorations'});
block('chorus_plant','コーラスプラント','#7a4b7d','purpur',.4,{tool:'axe',transparent:true,shape:'cactus',drop:'chorus_fruit',category:'nature'});
block('chorus_flower','コーラスフラワー','#b78bc4','purpur',.4,{tool:'axe',transparent:true,shape:'cactus',category:'nature'});
block('shulker_box','シュルカーボックス','#8f5d91','shulker',2,{tool:'pickaxe',tier:1,shape:'shulker_box',transparent:true,stack:1,category:'utility'});
block('dragon_egg','ドラゴンの卵','#1d1424','obsidian',3,{shape:'dragon_egg',transparent:true,light:4,category:'decorations'});
block('dragon_head','ドラゴンの頭','#28222e','obsidian',1,{shape:'dragon_head',transparent:true,category:'decorations'});
block('fire','炎','#ff9b26','plant',0,{solid:false,transparent:true,shape:'cross',light:15,category:'nature'});
block('iron_bars','鉄格子','#9da5a2','metal',5,{tool:'pickaxe',tier:1,transparent:true,shape:'pane',category:'building'});
// Blocks added for vanilla structures (spawner, nether wart, mushroom stem).
block('spawner','スポナー','#1f2a3a','metal',5,{tool:'pickaxe',tier:1,transparent:true,category:'utility'});
block('nether_wart','ネザーウォート','#a3202c','plant',0,{solid:false,transparent:true,shape:'cross',category:'nature'});
block('mushroom_stem','キノコの柄','#d6d0c0','wool',.2,{tool:'axe',category:'nature'});

const toolTiers:Record<string,[string,string,number,number,number]>={wooden:['木','#a88754',2,59,2],stone:['石','#92978d',4,131,3],copper:['銅','#c7835e',5,190,3],iron:['鉄','#d0d7d2',6,250,4],diamond:['ダイヤモンド','#58cfc4',8,1561,5],golden:['金','#e4c35b',12,32,2],netherite:['ネザライト','#655b60',9,2031,6]};
for(const [tier,[ja,color,speed,durability,damage]] of Object.entries(toolTiers))for(const type of ['pickaxe','axe','shovel','sword','hoe'])item(tier+'_'+type,ja+'の'+type,color,'tool',{tool:type,tier:type==='sword'?0:speed,durability,damage:type==='sword'?damage+2:type==='axe'?damage+3:1,stack:1,category:'tools'});
for(const [tier,[ja,color,,durability]] of Object.entries(toolTiers))for(const type of ['helmet','chestplate','leggings','boots'])item(tier+'_'+type,ja+'の'+type,color,'metal',{durability,stack:1,category:'tools'});
const foods:Record<string,[string,string,number]>={cooked_chicken:['焼き鳥','#bd8b58',6],mutton:['生の羊肉','#c46c60',2],cooked_mutton:['焼き羊肉','#9d6a45',6],rabbit:['生の兎肉','#cf9b86',3],cooked_rabbit:['焼き兎肉','#ad7d53',5],cod:['生鱈','#b8b393',2],cooked_cod:['焼き鱈','#c2a578',5],salmon:['生鮭','#ce8066',2],cooked_salmon:['焼き鮭','#c48a62',6],potato:['ジャガイモ','#c7a66b',1],baked_potato:['ベイクドポテト','#b99759',5],carrot:['ニンジン','#db9143',3],golden_carrot:['金のニンジン','#e4c257',6],golden_apple:['金のリンゴ','#e6cb62',4],cookie:['クッキー','#b98c55',2],melon_slice:['スイカの薄切り','#cf6b57',2],sweet_berries:['スイートベリー','#b7544c',2],glow_berries:['グロウベリー','#e0b35a',2],egg:['卵','#e5ddc7',1],mushroom_stew:['キノコシチュー','#b58b61',6],rabbit_stew:['ウサギシチュー','#b68b5c',10],beetroot:['ビートルート','#a7474b',1],beetroot_soup:['ビートルートスープ','#b65c50',6],pumpkin_pie:['パンプキンパイ','#c79552',8],dried_kelp:['乾燥昆布','#667348',1],chorus_fruit:['コーラスフルーツ','#b18aa9',4]};
for(const [name,[ja,color,food]] of Object.entries(foods))item(name,ja,color,'food',{food,category:'food'});
for(const [name,ja,color] of [['slime_ball','スライムボール','#7ac74f'],['magma_cream','マグマクリーム','#c85a20'],['honeycomb','ハニカム','#e8c832'],['ink_sac','イカスミ','#2a2a3a'],['scute','カメの甲羅','#6a9a5a'],['sculk','スカルク','#2a4a4a'],['rabbit_hide','ウサギの皮','#d8d8d8'],['milk_bucket','牛乳入りバケツ','#e5e5d7'],['lava_bucket','溶岩入りバケツ','#e58b36'],['shears','ハサミ','#c4cbc5'],['flint_and_steel','火打石と打ち金','#9b9b8b'],['bow','弓','#b18b54'],['arrow','矢','#d3cdb6'],['fishing_rod','釣竿','#a98855'],['saddle','鞍','#8b6547'],['compass','コンパス','#b9c4bd'],['clock','時計','#d9bd62'],['bucket','バケツ','#aab6b6'],['ender_pearl','エンダーパール','#2b8e7e'],['ender_eye','エンダーアイ','#64d86b'],['blaze_rod','ブレイズロッド','#f0b429'],['blaze_powder','ブレイズパウダー','#f59b23'],['ghast_tear','ガストの涙','#d9f0ee'],['nether_wart','ネザーウォート','#9d282e'],['netherite_scrap','ネザライトの欠片','#6b4c45'],['netherite_ingot','ネザライトインゴット','#53484c'],['shulker_shell','シュルカーの殻','#a16fa3'],['elytra','エリトラ','#8d8a9e'],['dragon_breath','ドラゴンブレス','#d966c8'],['firework_rocket','ロケット花火','#d6483e'],['popped_chorus_fruit','焼いたコーラスフルーツ','#b88db8'],['end_crystal','エンドクリスタル','#eb73e6'],['nether_star','ネザースター','#e5e4c9'],['emerald','エメラルド','#69bd7c'],['lapis_lazuli','ラピスラズリ','#5b78b6'],['redstone','レッドストーン','#b74635'],['charcoal','木炭','#4b443b'],['flint','火打石','#666b69'],['paper','紙','#e4e2d5'],['book','本','#a77c52'],['glass_bottle','ガラス瓶','#c2d8d5'],['potion','ポーション','#b66ca8'],['splash_potion','スプラッシュポーション','#a77cc0'],['experience_bottle','エンチャントの瓶','#b5cf68'],['boat','オークのボート','#ad8954'],['minecart','トロッコ','#aab2ad'],['painting','絵画','#b59b64'],['item_frame','額縁','#b39465'],['sign','看板','#b99a63']])if(ID[name]===undefined)item(name,ja,color,name.includes('bucket')?'misc':name.includes('potion')||name==='glass_bottle'?'gem':'tool',{stack:['shears','flint_and_steel','bow','fishing_rod','saddle','boat','minecart','compass','clock','elytra'].includes(name)?1:['ender_pearl','snowball','egg'].includes(name)?16:64,category:name.includes('potion')||name==='experience_bottle'?'food':['elytra','shears','flint_and_steel','bow','arrow','ender_eye','ender_pearl','firework_rocket','end_crystal'].includes(name)?'tools':'materials'});

// Keep legacy aliases so existing inventories and numeric world IDs remain usable.
for(const wood of ['oak','spruce','birch','jungle','acacia','dark_oak','cherry'])for(const suffix of ['slab','stairs','fence']){
  const oldName=wood+'_planks_'+suffix,canonical=wood+'_'+suffix,id=ID[oldName];
  if(id!==undefined&&ID[canonical]===undefined){ID[canonical]=id;BLOCKS[id].name=canonical;}
}
for(const [oldBase,newBase] of [['stone_bricks','stone_brick'],['quartz_block','quartz'],['nether_bricks','nether_brick'],['purpur_block','purpur'],['end_stone_bricks','end_stone_brick']])for(const suffix of ['slab','stairs','wall']){
  const id=ID[oldBase+'_'+suffix],canonical=newBase+'_'+suffix;
  if(id!==undefined&&ID[canonical]===undefined){ID[canonical]=id;BLOCKS[id].name=canonical;}
}
for(const [color,hex] of Object.entries(DYES))for(const material of ['wool','concrete']){
  const base=color+'_'+material,source=BLOCKS[ID[base]];
  block(base+'_slab',source.ja+'のハーフブロック',hex,source.pattern,source.hardness,{tool:source.tool,tier:source.tier,shape:'slab',category:'building'});
  block(base+'_stairs',source.ja+'の階段',hex,source.pattern,source.hardness,{tool:source.tool,tier:source.tier,shape:'stairs',category:'building'});
}
item('raw_iron','鉄の原石','#cfa789','gem',{category:'materials'});
item('raw_copper','銅の原石','#cb845e','gem',{category:'materials'});
item('raw_gold','金の原石','#dec36e','gem',{category:'materials'});
item('quartz','ネザークォーツ','#e9e3d7','gem',{category:'materials'});
item('snowball','雪玉','#e8eef0','gem',{stack:16,category:'items'});

// Levers and buttons have no collision, and a legacy "open door" block drops the normal door.
for(const b of BLOCKS){if(b.name==='lever'||b.name.endsWith('_button')){b.solid=false;b.transparent=true;}if(b.name.startsWith('open_')&&b.name.endsWith('_door'))b.drop=b.name.slice(5);}

// Redstone parts that were missing: a redstone block (constant 15), and lit/unlit redstone torches.
block('redstone_block','レッドストーンブロック','#b8261a','ore',5,{tool:'pickaxe',tier:1,category:'redstone'});
block('redstone_torch','レッドストーントーチ','#e0463a','torch',0,{solid:false,transparent:true,shape:'torch',light:7,category:'redstone'});
block('unlit_redstone_torch','消えたレッドストーントーチ','#7a2a22','torch',0,{solid:false,transparent:true,shape:'torch',category:'redstone'});

// --- Biome flora & materials (Minecraft Wiki: Biome, Nether, Ocean, Meadow, ...) -------------------------------------
const plantBlock = (name: string, ja: string, color: string, extra: Record<string, unknown> = {}) =>
  ID[name] === undefined && block(name, ja, color, 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature', ...(extra as object) });
// Cold biomes: snow layers on grass and ice on still water.
block('snow_layer', '雪', '#f4fbff', 'snow', 0.1, { tool: 'shovel', shape: 'slab', stack: 64, category: 'nature' });
// Temperate/warm flowers mentioned in the Wiki's biome tables.
plantBlock('allium', 'アリウム', '#b07bd0');
plantBlock('azure_bluet', 'アジサイ', '#e9eef0');
plantBlock('blue_orchid', '青いラン', '#3aa6c9');
plantBlock('lily_of_the_valley', 'スズラン', '#f4f6f0');
plantBlock('pitcher_plant', 'ウツボカズラ', '#7c4a8c');
plantBlock('torchflower', 'トーチフラワー', '#e39a44');
plantBlock('sweet_berry_bush', 'スイートベリーの茂み', '#3f5f2a');
// Jungle & swamp vegetation.
plantBlock('bamboo', '竹', '#79a64a');
plantBlock('vine', 'ツタ', '#3f7a2c');
plantBlock('jungle_fern', 'ジャングルのシダ', '#4f8b3a');
plantBlock('cocoa', 'カカオ', '#9a5a2a');
plantBlock('melon_stem', 'スイカの茎', '#5a8a32');
// Ocean vegetation and warm-water coral (kelp grows in columns, so it gets a tall custom shape).
plantBlock('seagrass', '海草', '#4f9a48');
block('kelp', 'コンブ', '#6aa03a', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature' });
block('sea_pickle', 'シーピクルス', '#8fae52', 'plant', 0.1, { solid: false, transparent: true, shape: 'slab', light: 6, category: 'nature' });
for (const c of ['tube', 'brain', 'bubble', 'fire', 'horn'] as const) {
  const hue = c === 'tube' ? '#6b5bd0' : c === 'brain' ? '#d06a9a' : c === 'bubble' ? '#b06ad0' : c === 'fire' ? '#c8452f' : '#d0b14a';
  block(c + '_coral_block', c + ' coral', hue, 'bricks', 1.5, { tool: 'pickaxe', category: 'nature' });
  plantBlock(c + '_coral', c + ' coral fan', hue);
}
// Azalea/moss vegetation (lush caves, also used in some biomes).
plantBlock('azalea', 'ツツジ', '#4f7d35');
plantBlock('flowering_azalea', '花咲くツツジ', '#b06a9a');
block('azalea_leaves', 'ツツジの葉', '#5f7d3a', 'leaves', 0.2, { transparent: true, category: 'nature' });
block('flowering_azalea_leaves', '花咲くツツジの葉', '#6f8a48', 'leaves', 0.2, { transparent: true, category: 'nature' });
// Nether biome blocks.
block('crimson_nylium', '真紅のナイリウム', '#6a1a24', 'nylium', 0.4, { tool: 'pickaxe', tier: 1, category: 'nature' });
block('warped_nylium', '歪んだナイリウム', '#1a5a55', 'nylium', 0.4, { tool: 'pickaxe', tier: 1, category: 'nature' });
plantBlock('crimson_fungus', '真紅のキノコ', '#a03a2a');
plantBlock('warped_fungus', '歪んだキノコ', '#3aa89a');
plantBlock('crimson_roots', '真紅の根', '#8a2430');
plantBlock('warped_roots', '歪んだ根', '#2a8a7a');
plantBlock('nether_sprouts', 'ネザーの芽', '#3a9a8a');
plantBlock('weeping_vines', '垂れ下がるツタ', '#9a2a30');
plantBlock('twisting_vines', 'ねじれるツタ', '#2a9a8a');
block('soul_fire', 'ソウルファイア', '#4fd8e8', 'plant', 0, { solid: false, transparent: true, shape: 'cross', light: 10, category: 'nature' });
block('soul_torch', 'ソウルファイアの松明', '#4fd8e8', 'torch', 0, { solid: false, transparent: true, shape: 'torch', light: 10, category: 'utility' });
block('soul_lantern', 'ソウルランタン', '#4fd8e8', 'torch', 3.5, { solid: false, transparent: true, shape: 'torch', light: 10, category: 'utility' });
block('gilded_blackstone', '金箔のブラックストーン', '#4a3a22', 'stone', 1.5, { tool: 'pickaxe', tier: 1, category: 'building' });
block('chain', '鎖', '#8a9296', 'metal', 5, { tool: 'pickaxe', tier: 1, transparent: true, shape: 'pane', category: 'decorations' });
block('cauldron', '大釜', '#4a4f52', 'metal', 2, { tool: 'pickaxe', transparent: true, category: 'utility' });

// ===== v11 — tall world, cave biomes, new structures, combat gear, enchanting & brewing ================================
const nb = (name: string, ja: string, color: string, pattern: any, hardness: number, extra: Record<string, unknown> = {}) => { if (ID[name] === undefined) block(name, ja, color, pattern, hardness, extra as any); };
for (const [n, ja, c, tier] of [['coal_block', '石炭ブロック', '#1c1c1e', 1], ['iron_block', '鉄ブロック', '#dcdcdc', 2], ['gold_block', '金ブロック', '#f6d33c', 3], ['diamond_block', 'ダイヤモンドブロック', '#62e0d8', 3], ['emerald_block', 'エメラルドブロック', '#2fc45a', 3], ['lapis_block', 'ラピスラズリブロック', '#1f4aa8', 2], ['copper_block', '銅ブロック', '#c06a4a', 2], ['netherite_block', 'ネザライトブロック', '#3d3a3d', 4]] as const)
  nb(n, ja, c, 'metal', 5, { tool: 'pickaxe', tier, category: 'building' });
const stoneLike: [string, string, string, string, number][] = [
  ['cobbled_deepslate', '深層岩の丸石', '#4d4f52', 'bricks', 3.5], ['polished_deepslate', '磨かれた深層岩', '#4a4c4f', 'deepslate', 3.5], ['deepslate_bricks', '深層岩レンガ', '#46484b', 'bricks', 3.5], ['deepslate_tiles', '深層岩タイル', '#37393c', 'bricks', 3.5], ['chiseled_deepslate', '模様入りの深層岩', '#3a3c3f', 'deepslate', 3.5],
  ['polished_blackstone', '磨かれたブラックストーン', '#35313a', 'stone', 2], ['polished_blackstone_bricks', '磨かれたブラックストーンレンガ', '#2f2b33', 'bricks', 1.5], ['chiseled_polished_blackstone', '模様入りの磨かれたブラックストーン', '#38343d', 'stone', 1.5],
  ['polished_granite', '磨かれた花崗岩', '#a8826f', 'stone', 1.5], ['polished_diorite', '磨かれた閃緑岩', '#cfcec6', 'stone', 1.5], ['polished_andesite', '磨かれた安山岩', '#9a9f94', 'stone', 1.5],
  ['smooth_stone', '滑らかな石', '#a2a39c', 'stone', 2], ['bricks', 'レンガ', '#9a5a48', 'bricks', 2], ['mud_bricks', '泥レンガ', '#8a6a4f', 'bricks', 1.5], ['cracked_stone_bricks', 'ひび割れた石レンガ', '#7f8278', 'bricks', 1.5], ['chiseled_stone_bricks', '模様入りの石レンガ', '#878a80', 'bricks', 1.5],
  ['prismarine_bricks', 'プリズマリンレンガ', '#63ab9e', 'bricks', 1.5], ['dark_prismarine', 'ダークプリズマリン', '#335b4f', 'bricks', 1.5], ['dripstone_block', '鍾乳石ブロック', '#866b5c', 'stone', 1.5], ['smooth_basalt', '滑らかな玄武岩', '#48484e', 'stone', 1.25],
  ['red_nether_bricks', '赤いネザーレンガ', '#46070a', 'bricks', 2], ['cracked_nether_bricks', 'ひび割れたネザーレンガ', '#2a1418', 'bricks', 2], ['quartz_bricks', 'クォーツレンガ', '#e8e2d6', 'bricks', 0.8], ['smooth_quartz', '滑らかなクォーツ', '#ece6da', 'stone', 2], ['cut_copper', '切り込み入りの銅', '#bf6b4d', 'bricks', 3],
];
for (const [n, ja, c, p, h] of stoneLike) nb(n, ja, c, p, h, { tool: 'pickaxe', tier: 1, category: 'building' });
nb('reinforced_deepslate', '強化された深層岩', '#50605a', 'deepslate', 55, { tool: 'pickaxe', tier: 99, category: 'building' });
nb('packed_mud', '固めた泥', '#8f6b52', 'dirt', 1, { category: 'building' });
nb('rooted_dirt', '根付いた土', '#8a6548', 'dirt', 0.5, { tool: 'shovel', category: 'nature' });
nb('nether_wart_block', 'ネザーウォートブロック', '#72080a', 'wool', 1, { category: 'building' });
nb('warped_wart_block', '歪んだウォートブロック', '#167a78', 'wool', 1, { category: 'building' });
nb('wet_sponge', '濡れたスポンジ', '#a9a23a', 'sponge', 0.6, { category: 'building' });
nb('tinted_glass', '遮光ガラス', '#2d2734', 'glass', 0.3, { transparent: true, category: 'building' });
// Deep dark
nb('sculk_block', 'スカルク', '#0c2a32', 'obsidian', 0.6, { tool: 'hoe', category: 'nature' });
nb('sculk_catalyst', 'スカルクカタリスト', '#123a44', 'obsidian', 3, { tool: 'hoe', light: 6, category: 'nature' });
nb('sculk_sensor', 'スカルクセンサー', '#0f4a58', 'obsidian', 1.5, { tool: 'hoe', shape: 'slab', light: 1, category: 'redstone' });
nb('sculk_shrieker', 'スカルクシュリーカー', '#c9c6a8', 'obsidian', 3, { tool: 'hoe', shape: 'slab', category: 'nature' });
// Lush & dripstone caves
nb('moss_carpet', '苔のカーペット', '#5a7a2c', 'wool', 0.1, { shape: 'slab', category: 'nature' });
plantBlock('cave_vines', '洞窟のツタ', '#6f9a2c', { light: 14, drop: 'glow_berries' });
plantBlock('spore_blossom', '胞子の花', '#d86ab0');
plantBlock('big_dripleaf', '大きなドリップリーフ', '#5d9a36');
plantBlock('small_dripleaf', '小さなドリップリーフ', '#6aa63e');
plantBlock('hanging_roots', '垂れ根', '#a5795a');
plantBlock('pointed_dripstone', '鍾乳石', '#8a6f5f');
plantBlock('glow_lichen', 'ヒカリゴケ', '#7aa58f', { light: 7 });
plantBlock('cobweb', 'クモの巣', '#e8ecee', { drop: 'string' });
// Workstations with real GUIs
nb('smithing_table', '鍛冶台', '#3c3f4a', 'craft', 2.5, { tool: 'axe', category: 'utility' });
nb('cartography_table', '製図台', '#7a6a4a', 'craft', 2.5, { tool: 'axe', category: 'utility' });
nb('fletching_table', '矢細工台', '#c9b98a', 'craft', 2.5, { tool: 'axe', category: 'utility' });
nb('lectern', '書見台', '#b08a52', 'planks', 2.5, { tool: 'axe', category: 'utility' });
for (const [color, hex] of Object.entries(DYES)) nb(color + '_banner', color + ' banner', hex, 'wool', 1, { solid: false, transparent: true, shape: 'pane', stack: 16, category: 'decorations' });

// Combat gear
item('shield', '盾', '#8a6a3f', 'tool', { durability: 336, stack: 1, category: 'tools' });
item('crossbow', 'クロスボウ', '#6b4a2c', 'tool', { durability: 465, stack: 1, category: 'tools' });
item('trident', 'トライデント', '#4fa69a', 'tool', { tool: 'trident', damage: 9, durability: 250, stack: 1, category: 'tools' });
item('mace', 'メイス', '#7d7f8c', 'tool', { tool: 'mace', damage: 6, durability: 500, stack: 1, category: 'tools' });
item('totem_of_undying', '不死のトーテム', '#e8c95a', 'gem', { stack: 1, category: 'tools' });
item('heavy_core', 'ヘビーコア', '#5a5d6b', 'metal', { category: 'materials' });
item('breeze_rod', 'ブリーズロッド', '#9ab8e8', 'tool', { category: 'materials' });
item('spectral_arrow', '光の矢', '#f1e27a', 'tool', { category: 'tools' });
for (const [tier, ja, color, dur] of [['leather', '革', '#8a5a3a', 80], ['chainmail', 'チェーン', '#9aa0a6', 200]] as const)
  for (const type of ['helmet', 'chestplate', 'leggings', 'boots']) item(tier + '_' + type, ja + 'の' + type, color, 'metal', { durability: dur, stack: 1, category: 'tools' });
item('turtle_helmet', 'カメの甲羅（ヘルメット）', '#4f9a4a', 'metal', { durability: 275, stack: 1, category: 'tools' });
// Brewing ingredients, enchanting & smithing materials
const mats: [string, string, string, string, Record<string, unknown>?][] = [
  ['glowstone_dust', 'グロウストーンダスト', '#f1c84a', 'gem'], ['sugar', '砂糖', '#f4f4f4', 'gem'], ['spider_eye', 'クモの目', '#8a1c2c', 'food', { food: 2, category: 'food' }], ['fermented_spider_eye', '発酵したクモの目', '#7a2a4a', 'food'],
  ['glistering_melon_slice', 'きらめくスイカの薄切り', '#e8b83a', 'food'], ['rabbit_foot', 'ウサギの足', '#c9a36b', 'misc'], ['phantom_membrane', 'ファントムの皮膜', '#c9c2b0', 'misc'], ['pufferfish', 'フグ', '#e8c232', 'food', { food: 1, category: 'food' }],
  ['tropical_fish', '熱帯魚', '#e87a32', 'food', { food: 1, category: 'food' }], ['poisonous_potato', '青くなったジャガイモ', '#8fae4a', 'food', { food: 2, category: 'food' }], ['enchanted_golden_apple', 'エンチャントされた金のリンゴ', '#f6d33c', 'food', { food: 4, category: 'food' }],
  ['honey_bottle', 'ハチミツ入りの瓶', '#e8a832', 'food', { food: 6, stack: 16, category: 'food' }], ['copper_ingot', '銅インゴット', '#c7835e', 'metal'], ['gold_nugget', '金塊', '#f1cf4a', 'gem'], ['iron_nugget', '鉄塊', '#c9cfcc', 'gem'],
  ['amethyst_shard', 'アメジストの欠片', '#a678f1', 'gem'], ['echo_shard', '残響の欠片', '#0f4a58', 'gem'], ['disc_fragment', 'レコードの破片', '#2a3a4a', 'misc'], ['prismarine_shard', 'プリズマリンの欠片', '#63ab9e', 'gem'], ['prismarine_crystals', 'プリズマリンクリスタル', '#c9e8dc', 'gem'],
  ['nautilus_shell', 'オウムガイの殻', '#d8c8b0', 'misc'], ['heart_of_the_sea', '海洋の心', '#2a8ac9', 'gem'], ['clay_ball', '粘土玉', '#a4a8b8', 'gem'], ['brick', 'レンガ（アイテム）', '#b0604a', 'metal'], ['nether_brick', 'ネザーレンガ（アイテム）', '#44252a', 'metal'],
  ['bowl', 'ボウル', '#7a5a32', 'misc'], ['bone_meal', '骨粉', '#e8e8e0', 'gem'], ['cocoa_beans', 'カカオ豆', '#7a4a22', 'gem'], ['name_tag', '名札', '#c9b98a', 'misc', { category: 'tools' }], ['lead', 'リード', '#a8875a', 'misc', { category: 'tools' }],
  ['spyglass', '望遠鏡', '#c98a4a', 'tool', { stack: 1, category: 'tools' }], ['filled_map', '地図', '#d8c89a', 'misc', { stack: 1, category: 'tools' }], ['writable_book', '本と羽根ペン', '#7a4a2a', 'misc', { stack: 1, category: 'tools' }], ['written_book', '記入済みの本', '#8a2a4a', 'misc', { stack: 1, category: 'tools' }],
  ['enchanted_book', 'エンチャントの本', '#b06ad8', 'misc', { stack: 1, category: 'tools' }], ['netherite_upgrade', 'ネザライト強化の鍛冶型', '#5a4a52', 'metal', { category: 'materials' }], ['map', '白紙の地図', '#e0d6b0', 'misc', { category: 'tools' }],
];
for (const [n, ja, c, p, extra] of mats) item(n, ja, c, p as any, { category: 'materials', ...(extra ?? {}) });
/** Potion families: [ja, colour, has extended variant, has level II variant]. Items: potion_<id>[_long|_strong], splash_<id>[...]. */
export const POTION_BASES: Record<string, [string, string, boolean, boolean]> = {
  swiftness: ['俊敏', '#7cafc6', true, true], slowness: ['鈍化', '#5a6c81', true, true], strength: ['力', '#932423', true, true], healing: ['治癒', '#f82423', false, true], harming: ['負傷', '#430a09', false, true],
  poison: ['毒', '#4e9331', true, true], regeneration: ['再生', '#cd5cab', true, true], fire_resistance: ['耐火', '#e49a3a', true, false], water_breathing: ['水中呼吸', '#2e5299', true, false], night_vision: ['暗視', '#1f1fa1', true, false],
  invisibility: ['透明化', '#7f8392', true, false], leaping: ['跳躍', '#22c94c', true, true], slow_falling: ['低速落下', '#d8d9c0', true, false], weakness: ['弱化', '#484d48', true, false], turtle_master: ['タートルマスター', '#6a5a8a', true, true],
};
for (const [n, ja] of [['water_bottle', '水入り瓶'], ['awkward_potion', '奇妙なポーション'], ['mundane_potion', 'ありふれたポーション'], ['thick_potion', '濃厚なポーション']]) item(n, ja, '#3f76e4', 'gem', { stack: 1, category: 'food' });
for (const [id, [ja, color, long, strong]] of Object.entries(POTION_BASES)) for (const [prefix, pja] of [['potion_', ''], ['splash_', 'スプラッシュ']]) {
  item(prefix + id, pja + ja + 'のポーション', color, 'gem', { stack: 1, category: 'food' });
  if (long) item(prefix + id + '_long', pja + ja + 'のポーション（延長）', color, 'gem', { stack: 1, category: 'food' });
  if (strong) item(prefix + id + '_strong', pja + ja + 'のポーション II', color, 'gem', { stack: 1, category: 'food' });
}

if (ID.deepslate !== undefined && ID.cobbled_deepslate !== undefined) BLOCKS[ID.deepslate].drop = 'cobbled_deepslate';

// Vanilla terrain & biome-feature blocks appended safely at end to preserve existing IDs
plantBlock('sunflower', 'ヒマワリ', '#f6c828');
plantBlock('red_tulip', '赤いチューリップ', '#d8382c');
plantBlock('tall_grass', '背の高い草', '#70a246', { drop: 'wheat_seeds' });
plantBlock('large_fern', '大きなシダ', '#5d8e3e', { drop: 'wheat_seeds' });
nb('blue_ice', '青氷', '#74a8f2', 'ice', 2.8, { tool: 'pickaxe', category: 'nature' });
nb('powder_snow', '粉雪', '#f4fafe', 'snow', 0.25, { solid: false, category: 'nature' });
nb('mangrove_roots', 'マングローブの根', '#523b26', 'bark', 0.7, { tool: 'axe', transparent: true, category: 'nature' });
nb('muddy_mangrove_roots', '泥だらけのマングローブの根', '#4a3d34', 'dirt', 0.7, { tool: 'shovel', category: 'nature' });
nb('raw_iron_block', '鉄の原石ブロック', '#a68b6b', 'ore', 5, { tool: 'pickaxe', tier: 2, category: 'building' });
nb('raw_copper_block', '銅の原石ブロック', '#9a684a', 'ore', 5, { tool: 'pickaxe', tier: 2, category: 'building' });
nb('leaf_litter', '落ち葉', '#7a5a32', 'plant', 0, { solid: false, transparent: true, shape: 'lily', category: 'nature' });

// --- 記録 014: 農業・乗り物・レッドストーン追加分 -----------------------------------------------------------------
// Crops with growth stages (state 0-7). Carrots/potatoes drop their food item, beetroots drop beetroot + seeds (see systems/farming.ts).
nb('carrots', 'ニンジン', '#d98b3a', 'plant', 0, { solid: false, transparent: true, shape: 'cross', drop: 'carrot', category: 'nature' });
nb('potatoes', 'ジャガイモ', '#c9b56b', 'plant', 0, { solid: false, transparent: true, shape: 'cross', drop: 'potato', category: 'nature' });
nb('beetroots', 'ビートルート', '#a94a4e', 'plant', 0, { solid: false, transparent: true, shape: 'cross', drop: 'beetroot', category: 'nature' });
nb('melon_block', 'スイカ', '#8fbd3f', 'leaves', 1, { tool: 'axe', drop: 'melon_slice', category: 'nature' });
nb('pumpkin_block', 'カボチャ', '#d8842c', 'wool', 1, { tool: 'axe', category: 'nature' });
nb('composter', 'コンポスター', '#8a6a3c', 'planks', 0.6, { tool: 'axe', category: 'utility' });
// Piston head occupies the cell in front of an extended piston. It is transparent so it does not conduct power (vanilla).
nb('piston_head', 'ピストンヘッド', '#b08d5a', 'planks', 1.5, { transparent: true, shape: 'piston_head', category: 'redstone' });
nb('inverted_daylight_detector', '日照センサー（反転）', '#7b8fa8', 'bricks', 0.2, { shape: 'slab', drop: 'daylight_detector', category: 'redstone' });
nb('copper_bulb', '銅の電球', '#9a5c3c', 'metal', 3, { tool: 'pickaxe', tier: 1, category: 'redstone' });
nb('copper_bulb_lit', '銅の電球（点灯）', '#f0a862', 'metal', 3, { tool: 'pickaxe', tier: 1, light: 15, drop: 'copper_bulb', category: 'redstone' });
nb('crafter', '自動作業台', '#7d6a4e', 'craft', 1.5, { tool: 'pickaxe', tier: 1, category: 'redstone' });
nb('bell', '鐘', '#e3b43a', 'metal', 5, { tool: 'pickaxe', tier: 1, transparent: true, shape: 'lantern', category: 'utility' });
nb('pumpkin_stem', 'カボチャの茎', '#5a8a32', 'plant', 0, { solid: false, transparent: true, shape: 'cross', category: 'nature' });
nb('farmland_moist', '湿った耕地', '#4f3622', 'dirt', 0.6, { tool: 'shovel', shape: 'slab', drop: 'dirt', category: 'nature' });
nb('detector_rail', 'ディテクターレール', '#b06a4a', 'bricks', 0.7, { solid: false, transparent: true, shape: 'slab', category: 'redstone' });
nb('activator_rail', 'アクティベーターレール', '#a84a3a', 'bricks', 0.7, { solid: false, transparent: true, shape: 'slab', category: 'redstone' });
nb('moving_piston', '移動中のブロック', '#98958a', 'stone', Infinity, { shape: 'moving_piston', transparent: true, category: 'redstone' });
nb('campfire', '焚き火', '#a8642a', 'planks', 2, { tool: 'axe', light: 15, shape: 'slab', transparent: true, category: 'utility' });
nb('dried_kelp_block', '乾燥した昆布ブロック', '#3a4a2a', 'wool', 0.5, { tool: 'hoe', category: 'building' });
nb('quartz_pillar', 'クォーツの柱', '#ebe6dc', 'quartz', 0.8, { tool: 'pickaxe', tier: 1, category: 'building' });

// Backward-compatible aliases across all test suites and modules
ID.carrot_crop = ID.carrots;
ID.potato_crop = ID.potatoes;
ID.beetroot_crop = ID.beetroots;
ID.lit_copper_bulb = ID.copper_bulb_lit;
ID.daylight_detector_inverted = ID.inverted_daylight_detector;
if (ID.farmland !== undefined) BLOCKS[ID.farmland].drop = 'dirt';

for (const [name, ja, color, pattern, extra] of [
  ['beetroot_seeds', 'ビートルートの種', '#8d5a3a', 'misc', { category: 'materials' }],
  ['pumpkin_seeds', 'カボチャの種', '#d9cf9a', 'misc', { category: 'materials' }],
  ['melon_seeds', 'スイカの種', '#2f2f2f', 'misc', { category: 'materials' }],
  ['pufferfish', 'フグ', '#e8c84a', 'food', { food: 1, category: 'food' }],
  ['nautilus_shell', 'オウムガイの殻', '#d8cdb8', 'misc', { category: 'materials' }],
  ['prismarine_shard', 'プリズマリンの欠片', '#7fb8a8', 'gem', { category: 'materials' }],
  ['totem_of_undying', '不死のトーテム', '#e2c24a', 'tool', { stack: 1, category: 'tools' }],
  ['carrot_on_a_stick', 'ニンジン付きの棒', '#d98b3a', 'tool', { stack: 1, durability: 25, category: 'tools' }],
  ['warped_fungus_on_a_stick', '歪んだキノコ付きの棒', '#2ab8a0', 'tool', { stack: 1, durability: 100, category: 'tools' }],
  ['ominous_banner', '不吉な旗', '#5a5a6a', 'misc', { stack: 16, category: 'decorations' }],
  ['piglin_banner', 'ピグリンの旗', '#c08a5a', 'misc', { stack: 1, category: 'items' }],
  ['hoglin_hide', 'ホグリンの皮', '#b07a5a', 'misc', { category: 'materials' }],
  ['chicken', '生の鶏肉', '#e8b8a8', 'food', { food: 2, category: 'food' }],
  ['cake', 'ケーキ', '#f2e6d8', 'food', { food: 7, stack: 1, category: 'food' }],
  ['globe_banner_pattern', '旗の模様（地球）', '#d8d2c4', 'misc', { stack: 1, category: 'materials' }],
  ['wind_charge', 'ウィンドチャージ', '#c9d8f2', 'misc', { category: 'materials' }],
] as [string, string, string, Pattern, Record<string, unknown>][]) if (ID[name] === undefined && ITEM_ID[name] === undefined) item(name, ja, color, pattern, extra as object);
