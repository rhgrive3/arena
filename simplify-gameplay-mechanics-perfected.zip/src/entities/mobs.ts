import { SEA as SEA_LEVEL, endPillars, type Terrain } from '../world/terrain';
import * as THREE from 'three';
import { BLOCKS, ID, resolve } from '../game/data';
import { random } from '../input/math';
import type { BossInfo } from '../game/types';
import {
  NEW_SPECIES, BREED_FOOD, TAME_FOOD, RIDE_TAME, SADDLEABLE, LEASHABLE, RIDE,
  JOB_SITES, TRADES, TRADER_OFFERS, LEVEL_XP, LEVEL_JA, LEVEL_NAMES, PROFESSION_JA,
  BARTER, RAID_WAVES, type Profession, type Offer,
} from './mobdata';
import { findPath, groundAt, type PathPoint } from './pathfinding';
import {
  newVillager, getTradeOffers, addTradeXp, updateJob, restockVillager, tickVillager, wanderingTrader,
  type VillagerData,
} from './villagers';

export type Species =
  | 'cow' | 'pig' | 'sheep' | 'chicken' | 'zombie' | 'skeleton' | 'creeper' | 'spider'
  | 'enderman' | 'villager' | 'wolf' | 'cat' | 'horse' | 'iron_golem' | 'fish' | 'dolphin'
  | 'blaze' | 'ghast' | 'wither' | 'dragon' | 'warden' | 'slime' | 'magma_cube' | 'pillager'
  | 'witch' | 'bee' | 'fox' | 'rabbit' | 'squid' | 'turtle' | 'shulker'
  // Record 014 (48 new species -> 79 total)
  | 'piglin' | 'piglin_brute' | 'zombified_piglin' | 'hoglin' | 'zoglin' | 'strider' | 'wither_skeleton'
  | 'vindicator' | 'evoker' | 'vex' | 'ravager'
  | 'drowned' | 'husk' | 'zombie_villager' | 'stray' | 'bogged' | 'phantom'
  | 'cave_spider' | 'silverfish' | 'endermite' | 'breeze'
  | 'guardian' | 'elder_guardian' | 'salmon' | 'tropical_fish' | 'pufferfish' | 'glow_squid' | 'axolotl' | 'tadpole'
  | 'panda' | 'polar_bear' | 'llama' | 'parrot' | 'goat' | 'frog' | 'camel' | 'donkey' | 'mule'
  | 'skeleton_horse' | 'zombie_horse' | 'mooshroom' | 'armadillo' | 'sniffer' | 'ocelot' | 'snow_golem'
  | 'wandering_trader' | 'allay' | 'bat';

export const SPECIES: Species[] = [
  'cow', 'pig', 'sheep', 'chicken', 'zombie', 'skeleton', 'creeper', 'spider',
  'enderman', 'villager', 'wolf', 'cat', 'horse', 'iron_golem', 'fish', 'dolphin',
  'blaze', 'ghast', 'wither', 'dragon', 'warden', 'slime', 'magma_cube', 'pillager',
  'witch', 'bee', 'fox', 'rabbit', 'squid', 'turtle', 'shulker',
  ...(Object.keys(NEW_SPECIES) as Species[]),
];

export interface DriveInput { move: { x: number; z: number }; yaw: number; run: boolean; ascend: boolean }

export interface MobSave {
  id?: number;
  raidMember?: boolean;
  species: Species;
  position: [number, number, number];
  hp: number;
  baby: boolean;
  age?: number;
  grow?: number;
  tamed: boolean;
  saddled: boolean;
  sitting: boolean;
  leashed: boolean;
  leashPos?: [number, number, number] | null;
  wool: boolean;
  breedCooldown: number;
  love: number;
  profession?: Profession;
  level?: number;
  xp?: number;
  villager?: VillagerData;
}

export interface RaidState {
  wave: number;
  total: number;
  alive: number;
  timer: number;
  delay: number;
  center: [number, number, number];
  members: number[];
}

export interface MobHost {
  terrain: Terrain;
  position: THREE.Vector3;
  camera: THREE.PerspectiveCamera;
  time: number;
  dimension: string;
  dragonDefeated: boolean;
  getBlock(x: number, y: number, z: number): number;
  damage(n: number): void;
  addItem(n: string, c: number): boolean;
  addXp?(n: number): void;
  toast(j: string, e: string): void;
  sound(k: string, p?: { x: number; y: number; z: number }): void;
  explode(p: THREE.Vector3, r: number): void;
  teleport(x: number, y: number, z: number): void;
  openTrade(m?: Mob): void;
  onDragonDefeated(): void;
  onEnterGateway(): void;
  levitate(sec: number): void;
  /** Record 014 hooks */
  wearingGold?(): boolean;
  goldArmor?(): boolean;
  effect?(id: string, sec: number, amp?: number): void;
  insomnia?(): number;
  difficulty?(): string;
  consume?(item?: string, count?: number): boolean;
  playerMoving?(): boolean;
  sneaking?(): boolean;
  heldItem?(): string;
  onVibration?(x: number, y: number, z: number, strength: number): void;
  particles: {
    burst(p: THREE.Vector3, c: string, n?: number, power?: number): void;
    spark?(p: THREE.Vector3, c: string, n?: number): void;
    drop(p: THREE.Vector3, n: string, c: number, col: string): void;
  };
}

export interface Mob {
  id: number;
  species: Species;
  group: THREE.Group;
  legs: THREE.Object3D[];
  limbs?: Limb[];
  walk?: number;
  swing?: number;
  lastX?: number;
  lastZ?: number;
  head: THREE.Object3D;
  woolCoat?: THREE.Object3D;
  collar?: THREE.Object3D;
  hp: number;
  maxHp: number;
  state: 'wander' | 'graze' | 'flee' | 'chase' | 'aim' | 'fuse' | 'teleport' | 'follow' | 'trade' | 'circle' | 'charge' | 'perch';
  phaseTimer: number;
  timer: number;
  attack: number;
  hurtTimer: number;
  dir: number;
  speed: number;
  target: THREE.Vector3;
  fuse: number;
  wool: boolean;
  tamed: boolean;
  love: number;
  egg: number;
  baby: boolean;
  // Record 014
  grow: number;
  age?: number;
  breedCooldown: number;
  saddled?: boolean;
  saddle?: THREE.Object3D;
  leashed: boolean;
  leashPos?: [number, number, number] | null;
  sitting: boolean;
  anger: number;
  path: PathPoint[] | null;
  pathAt: number;
  profession: Profession;
  level: number;
  xp: number;
  villager?: VillagerData;
  captain: boolean;
  raid: boolean;
  raidMember?: boolean;
  vy: number;
  lastNoise: THREE.Vector3 | null;
  tameTries: number;
  barter: number;
  zombify: number;
  special: number;
  rolledUp?: number;
  curing?: number;
  shearedHead?: boolean;
}

type LimbKind = 'leg' | 'arm' | 'wing' | 'spider' | 'tentacle';
interface Limb { node: THREE.Object3D; kind: LimbKind; phase: number; amp: number; baseX: number; baseY: number; baseZ: number; }
interface EndCrystal {
  group: THREE.Group;
  core: THREE.Mesh;
  shell: THREE.Mesh;
  pos: THREE.Vector3;
}
interface Projectile {
  kind: 'mob_arrow' | 'player_arrow' | 'ghast_fireball' | 'blaze_fireball' | 'dragon_fireball' | 'shulker_bullet' | 'ender_pearl' | 'ender_eye' | 'snowball' | 'trident' | 'potion' | 'wind_charge';
  mesh: THREE.Mesh;
  v: THREE.Vector3;
  life: number;
  damage: number;
  target?: THREE.Vector3;
  gravity?: number;
  onEnd?: (pos: THREE.Vector3) => void;
  flame?: boolean;
  punch?: number;
  effect?: [string, number];
}
interface Arrow {
  mesh: THREE.Mesh;
  v: THREE.Vector3;
  life: number;
  fromPlayer: boolean;
  damage: number;
}

const passive = new Set<string>([
  'cow', 'pig', 'sheep', 'chicken', 'villager', 'wolf', 'cat', 'horse',
  'fish', 'dolphin', 'bee', 'fox', 'rabbit', 'squid', 'turtle',
  ...Object.keys(NEW_SPECIES).filter(k => NEW_SPECIES[k].passive),
]);
const neutral = new Set<string>(['zombified_piglin', 'polar_bear', 'llama', 'panda', 'goat', 'wolf', 'bee', 'dolphin', 'iron_golem']);
const flyers = new Set<string>(['bee', 'blaze', 'ghast', 'wither', 'vex', 'phantom', 'allay', 'parrot', 'bat', 'breeze']);
const swimmers = new Set<string>(['fish', 'salmon', 'tropical_fish', 'pufferfish', 'tadpole', 'dolphin', 'squid', 'glow_squid', 'guardian', 'elder_guardian', 'axolotl']);

const drops: Record<string, [string, number]> = {
  cow: ['raw_beef', 2], pig: ['porkchop', 2], sheep: ['white_wool', 1], chicken: ['chicken', 1],
  zombie: ['rotten_flesh', 2], skeleton: ['bone', 2], creeper: ['gunpowder', 2], spider: ['string', 2],
  enderman: ['ender_pearl', 1], villager: ['bread', 1], wolf: ['bone', 1], cat: ['string', 1],
  horse: ['leather', 2], iron_golem: ['iron_ingot', 3], fish: ['cod', 1], dolphin: ['cod', 1],
  blaze: ['blaze_rod', 1], ghast: ['ghast_tear', 1], wither: ['nether_star', 1], dragon: ['dragon_breath', 4],
  warden: ['sculk', 2], slime: ['slime_ball', 2], magma_cube: ['magma_cream', 2],
  pillager: ['arrow', 3], witch: ['redstone', 2], bee: ['honeycomb', 1],
  fox: ['leather', 1], rabbit: ['rabbit_hide', 1], squid: ['ink_sac', 2], turtle: ['scute', 1], shulker: ['shulker_shell', 1],
};
for (const [k, v] of Object.entries(NEW_SPECIES)) drops[k] = v.drop;

export class MobManager {
  mobs: Mob[] = [];
  nextId = 1;
  rnd = random(78123);
  materials = new Map<string, THREE.MeshLambertMaterial>();
  hurtMat = new THREE.MeshLambertMaterial({ color: '#e84a3c', emissive: '#6a120a' });
  box = new THREE.BoxGeometry(1, 1, 1);
  spawnTimer = 0;
  jobTimer = 0;
  arrows: Arrow[] = [];
  crystals: EndCrystal[] = [];
  projectiles: Projectile[] = [];
  emissiveMaterials = new Map<string, THREE.MeshBasicMaterial>();

  private _tmpA = new THREE.Vector3();
  private _tmpB = new THREE.Vector3();
  private _look = new THREE.Vector3();

  constructor(public scene: THREE.Scene, public host: MobHost) {
    this.populate();
  }

  mat(color: string) {
    let m = this.materials.get(color);
    if (!m) {
      m = new THREE.MeshLambertMaterial({ color });
      this.materials.set(color, m);
    }
    return m;
  }

  glowMat(color: string, opacity = 1) {
    const key = color + ':' + opacity;
    let m = this.emissiveMaterials.get(key);
    if (!m) {
      m = new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity });
      this.emissiveMaterials.set(key, m);
    }
    return m;
  }

  part(g: THREE.Object3D, color: string, x: number, y: number, z: number, w: number, h: number, d: number) {
    const m = new THREE.Mesh(this.box, this.mat(color));
    m.userData.baseMat = m.material;
    m.position.set(x, y, z);
    m.scale.set(w, h, d);
    m.castShadow = false;
    m.receiveShadow = true;
    g.add(m);
    return m;
  }

  model(species: Species) {
    const g = new THREE.Group();
    const legs: THREE.Object3D[] = [];
    const wings: THREE.Object3D[] = [];
    const head = new THREE.Group();
    g.add(head);
    let woolCoat: THREE.Object3D | undefined;
    let collar: THREE.Object3D | undefined;

    const eyes = (y: number, z: number, sep: number, color = '#171b17') => {
      this.part(head, color, -sep, y, z, 0.07, 0.07, 0.025);
      this.part(head, color, sep, y, z, 0.07, 0.07, 0.025);
    };
    const quadLegs = (color: string, w: number, h: number, d: number, x: number, z: number) => {
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
        const pivot = new THREE.Group();
        pivot.position.set(sx * x, h, sz * z);
        this.part(pivot, color, 0, -h / 2, 0, w, h, d);
        g.add(pivot);
        legs.push(pivot);
      }
    };

    if (species === 'dragon') {
      this.part(g, '#18141f', 0, 1.4, 0, 1.6, 1.3, 3.2);
      for (let i = 0; i < 4; i++) this.part(g, '#3d334d', 0, 2.2, -1.0 + i * 0.75, 0.25, 0.35, 0.3);
      head.position.set(0, 1.85, -2.3);
      this.part(g, '#1c1826', 0, 1.65, -1.8, 0.7, 0.7, 1.0);
      this.part(head, '#1e1928', 0, 0, 0, 1.0, 0.9, 1.2);
      this.part(head, '#241e30', 0, -0.1, -0.8, 0.75, 0.45, 0.9);
      this.part(head, '#3f3452', -0.35, 0.55, 0.25, 0.16, 0.4, 0.35);
      this.part(head, '#3f3452', 0.35, 0.55, 0.25, 0.16, 0.4, 0.35);
      eyes(0.15, -0.62, 0.3, '#e05cff');
      for (let i = 0; i < 6; i++) {
        this.part(g, i % 2 ? '#18141f' : '#262033', 0, 1.35 - i * 0.04, 1.8 + i * 0.7, 0.55 - i * 0.06, 0.5 - i * 0.05, 0.72);
      }
      for (const side of [-1, 1]) {
        const wingPivot = new THREE.Group();
        wingPivot.position.set(side * 0.85, 1.8, -0.5);
        this.part(wingPivot, '#2e273d', side * 1.9, 0.1, 0, 3.8, 0.18, 0.22);
        this.part(wingPivot, '#120e1a', side * 2.1, -0.02, 0.85, 4.0, 0.06, 1.8);
        g.add(wingPivot);
        wings.push(wingPivot);
      }
      g.scale.setScalar(1.35);
    } else if (species === 'shulker') {
      this.part(g, '#7c4c80', 0, 0.22, 0, 0.95, 0.44, 0.95);
      head.position.set(0, 0.58, 0);
      this.part(head, '#e8dcb8', 0, 0, 0, 0.52, 0.5, 0.52);
      eyes(0.05, -0.27, 0.14, '#241c29');
      const lid = new THREE.Group();
      lid.position.set(0, 0.72, 0);
      this.part(lid, '#9b679f', 0, 0.2, 0, 0.95, 0.48, 0.95);
      g.add(lid);
      wings.push(lid);
    } else if (species === 'cow' || species === 'pig' || species === 'sheep' || species === 'wolf' || species === 'cat' || species === 'horse') {
      const horse = species === 'horse', small = species === 'cat' || species === 'wolf';
      const body = species === 'cow' ? '#665344' : species === 'pig' ? '#d99b91' : species === 'sheep' ? '#e4e2d4' : species === 'wolf' ? '#c5c7bd' : species === 'cat' ? '#bd8c54' : '#8b6747';
      const h = horse ? 1.15 : small ? 0.48 : 0.78;
      this.part(g, body, 0, h, 0, small ? 0.42 : 0.72, small ? 0.4 : 0.65, horse ? 1.35 : 1.05);
      head.position.set(0, h + (horse ? 0.55 : 0.2), -0.6);
      this.part(head, body, 0, 0, 0, 0.43, horse ? 0.65 : 0.43, 0.48);
      this.part(head, species === 'pig' ? '#c4837c' : species === 'cow' ? '#b7a38b' : '#b9a58b', 0, -0.1, -0.28, 0.3, 0.18, 0.13);
      if (species === 'pig') {
        this.part(head, '#8c4e47', -0.07, -0.1, -0.35, 0.05, 0.08, 0.02);
        this.part(head, '#8c4e47', 0.07, -0.1, -0.35, 0.05, 0.08, 0.02);
      }
      eyes(0.07, -0.25, 0.14);
      if (species === 'cow') {
        this.part(g, '#dedbd0', 0.365, h + 0.05, 0.1, 0.02, 0.35, 0.4);
        this.part(g, '#dedbd0', -0.365, h - 0.1, -0.25, 0.02, 0.28, 0.3);
        this.part(head, '#d9d1b8', -0.22, 0.27, 0, 0.1, 0.18, 0.1);
        this.part(head, '#d9d1b8', 0.22, 0.27, 0, 0.1, 0.18, 0.1);
      }
      if (species === 'sheep') {
        woolCoat = this.part(g, '#f2f0e6', 0, h + 0.02, 0, 0.84, 0.78, 1.12);
      }
      if (species === 'cat' || species === 'wolf') {
        this.part(head, body, -0.15, 0.27, 0, 0.12, 0.2, 0.1);
        this.part(head, body, 0.15, 0.27, 0, 0.12, 0.2, 0.1);
        this.part(g, body, 0, h + 0.1, 0.65, 0.12, 0.12, 0.5);
        if (species === 'wolf') {
          collar = this.part(g, '#d64538', 0, h + 0.06, -0.36, 0.46, 0.44, 0.12);
          collar.visible = false;
        }
      }
      if (species === 'horse') {
        this.part(g, '#463b30', 0, h + 0.45, -0.45, 0.16, 0.6, 0.3);
        this.part(g, '#463b30', 0, h, 0.8, 0.14, 0.6, 0.14);
      }
      quadLegs(species === 'cow' ? '#514638' : body, small ? 0.13 : 0.18, h, small ? 0.13 : 0.18, small ? 0.15 : 0.26, horse ? 0.48 : 0.34);
    } else if (species === 'chicken') {
      this.part(g, '#eee9d9', 0, 0.48, 0, 0.4, 0.42, 0.55);
      head.position.set(0, 0.82, -0.22);
      this.part(head, '#f3efdf', 0, 0, 0, 0.3, 0.32, 0.3);
      this.part(head, '#e6b344', 0, -0.05, -0.22, 0.22, 0.1, 0.16);
      this.part(head, '#c94b3c', 0, -0.2, -0.18, 0.12, 0.16, 0.1);
      eyes(0.05, -0.16, 0.1);
      for (const sx of [-1, 1]) {
        const leg = new THREE.Group();
        leg.position.set(sx * 0.09, 0.28, 0);
        this.part(leg, '#cf9c43', 0, -0.14, 0, 0.055, 0.28, 0.055);
        g.add(leg);
        legs.push(leg);
      }
      for (const sx of [-1, 1]) {
        const wing = new THREE.Group();
        wing.position.set(sx * 0.2, 0.52, 0);
        this.part(wing, '#ded8c7', sx * 0.13, 0, 0, 0.26, 0.06, 0.34);
        g.add(wing);
        legs.push(wing);
      }
    } else if (species === 'creeper') {
      this.part(g, '#6b9b4d', 0, 0.85, 0, 0.5, 0.9, 0.35);
      head.position.set(0, 1.55, 0);
      this.part(head, '#76a957', 0, 0, 0, 0.62, 0.62, 0.62);
      this.part(head, '#233323', 0, -0.08, -0.32, 0.16, 0.18, 0.02);
      this.part(head, '#233323', -0.12, -0.02, -0.32, 0.15, 0.13, 0.02);
      this.part(head, '#233323', 0.12, -0.02, -0.32, 0.15, 0.13, 0.02);
      this.part(head, '#233323', 0, -0.2, -0.32, 0.34, 0.12, 0.02);
      quadLegs('#5d8743', 0.2, 0.4, 0.24, 0.17, 0.18);
    } else if (species === 'spider') {
      this.part(g, '#3b302b', 0, 0.45, 0.2, 0.8, 0.42, 0.9);
      head.position.set(0, 0.45, -0.5);
      this.part(head, '#302724', 0, 0, 0, 0.55, 0.38, 0.5);
      eyes(0.05, -0.26, 0.15, '#d44732');
      for (const s of [-1, 1]) for (let i = 0; i < 4; i++) {
        const pivot = new THREE.Group();
        pivot.position.set(s * 0.4, 0.45, -0.35 + i * 0.25);
        this.part(pivot, '#342b26', s * 0.45, 0, 0, 0.9, 0.1, 0.1);
        pivot.rotation.z = s * 0.25;
        g.add(pivot);
        legs.push(pivot);
      }
    } else if (species === 'blaze') {
      this.part(g, '#e8a832', 0, 0.9, 0, 0.5, 0.8, 0.5);
      head.position.set(0, 1.6, 0);
      this.part(head, '#f0b840', 0, 0, 0, 0.5, 0.5, 0.5);
      eyes(0.05, -0.26, 0.13, '#7a4a12');
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * 6.28;
        this.part(g, '#d89a28', Math.cos(a) * 0.4, 0.6 + Math.sin(i) * 0.3, Math.sin(a) * 0.4, 0.15, 0.5, 0.15);
      }
    } else if (species === 'ghast') {
      this.part(g, '#e8e8e8', 0, 1.2, 0, 1.2, 1.2, 1.2);
      head.position.set(0, 1.2, -0.6);
      this.part(head, '#f0f0f0', 0, 0, 0, 0.8, 0.8, 0.8);
      eyes(0.1, -0.4, 0.2, '#5a5a5a');
      this.part(head, '#5a5a5a', 0, -0.2, -0.41, 0.3, 0.15, 0.02);
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * 6.28;
        this.part(g, '#d8d8d8', Math.cos(a) * 0.7, 0.3, Math.sin(a) * 0.7, 0.12, 0.6, 0.12);
      }
    } else if (species === 'wither') {
      this.part(g, '#2a2a2a', 0, 1.1, 0, 0.6, 0.9, 0.6);
      head.position.set(0, 1.8, 0);
      this.part(head, '#3a3a3a', 0, 0, 0, 0.6, 0.6, 0.6);
      eyes(0.05, -0.3, 0.15, '#c8c8c8');
      this.part(g, '#1a1a1a', -0.5, 1.3, 0, 0.2, 0.7, 0.2);
      this.part(g, '#1a1a1a', 0.5, 1.3, 0, 0.2, 0.7, 0.2);
      quadLegs('#2a2a2a', 0.18, 0.6, 0.18, 0.18, 0.18);
    } else if (species === 'warden') {
      this.part(g, '#2a3a4a', 0, 1.2, 0, 0.9, 1.0, 0.7);
      head.position.set(0, 2.0, -0.3);
      this.part(head, '#3a4a5a', 0, 0, 0, 0.7, 0.7, 0.7);
      eyes(0.1, -0.35, 0.2, '#4ac8c8');
      this.part(g, '#1a2a3a', 0, 1.8, -0.5, 0.2, 0.8, 0.2);
      quadLegs('#2a3a4a', 0.25, 0.9, 0.25, 0.3, 0.3);
    } else if (species === 'slime' || species === 'magma_cube') {
      const col = species === 'slime' ? '#7ac74f' : '#c85a20';
      this.part(g, col, 0, 0.4, 0, 0.8, 0.8, 0.8);
      head.position.set(0, 0.4, -0.4);
      this.part(head, col, 0, 0, 0, 0.6, 0.6, 0.6);
      eyes(0.05, -0.3, 0.15, '#2a2a2a');
    } else if (species === 'pillager' || species === 'witch') {
      const skin = '#ba9472', shirt = species === 'pillager' ? '#5a4a3a' : '#4a3a6a';
      this.part(g, shirt, 0, 1.05, 0, 0.52, 0.7, 0.3);
      head.position.set(0, 1.65, 0);
      this.part(head, skin, 0, 0, 0, 0.5, 0.5, 0.5);
      eyes(0.05, -0.26, 0.13, '#202820');
      if (species === 'witch') {
        this.part(head, '#3a2a4a', 0, 0.35, 0, 0.6, 0.15, 0.6);
        this.part(g, '#3a2a4a', 0, 1.05, -0.28, 0.65, 0.22, 0.2);
      }
      for (const s of [-1, 1]) {
        const leg = new THREE.Group(); leg.position.set(s * 0.14, 0.7, 0);
        this.part(leg, '#4a3a2a', 0, -0.35, 0, 0.22, 0.7, 0.23); g.add(leg); legs.push(leg);
        const arm = new THREE.Group(); arm.position.set(s * 0.37, 1.35, 0);
        this.part(arm, skin, 0, -0.32, 0, 0.17, 0.65, 0.18); g.add(arm); legs.push(arm);
      }
    } else if (species === 'bee') {
      this.part(g, '#e8c832', 0, 0.3, 0, 0.4, 0.3, 0.5);
      head.position.set(0, 0.3, -0.3);
      this.part(head, '#e8c832', 0, 0, 0, 0.3, 0.3, 0.3);
      eyes(0.05, -0.15, 0.1, '#2a2a2a');
      this.part(g, '#2a2a2a', 0, 0.3, 0, 0.42, 0.1, 0.3);
      for (const sx of [-1, 1]) {
        const wing = new THREE.Group();
        wing.position.set(sx * 0.15, 0.48, 0);
        this.part(wing, '#ffffff', sx * 0.1, 0, 0, 0.2, 0.03, 0.3);
        g.add(wing);
        legs.push(wing);
      }
    } else if (species === 'fox' || species === 'rabbit') {
      const col = species === 'fox' ? '#c87a3a' : '#d8d8d8';
      this.part(g, col, 0, 0.35, 0, 0.4, 0.35, 0.6);
      head.position.set(0, 0.55, -0.35);
      this.part(head, col, 0, 0, 0, 0.35, 0.35, 0.35);
      eyes(0.05, -0.18, 0.12, '#2a2a2a');
      if (species === 'fox') {
        this.part(head, col, -0.12, 0.22, 0, 0.1, 0.2, 0.08);
        this.part(head, col, 0.12, 0.22, 0, 0.1, 0.2, 0.08);
      } else {
        this.part(head, col, -0.1, 0.3, 0, 0.08, 0.3, 0.05);
        this.part(head, col, 0.1, 0.3, 0, 0.08, 0.3, 0.05);
      }
      quadLegs(col, 0.08, 0.25, 0.08, 0.12, 0.18);
    } else if (species === 'squid' || species === 'turtle') {
      const col = species === 'squid' ? '#4a4a8a' : '#6a9a5a';
      this.part(g, col, 0, 0.4, 0, 0.5, 0.6, 0.7);
      head.position.set(0, 0.4, -0.35);
      this.part(head, col, 0, 0, 0, 0.4, 0.4, 0.4);
      eyes(0.05, -0.2, 0.12, '#ffffff');
      if (species === 'squid') for (let i = 0; i < 6; i++) { const a = (i / 6) * 6.28; const t = new THREE.Group(); t.position.set(Math.cos(a) * 0.25, 0.2, Math.sin(a) * 0.25); this.part(t, col, 0, -0.15, 0, 0.08, 0.3, 0.08); g.add(t); legs.push(t); }
      else quadLegs(col, 0.1, 0.2, 0.1, 0.15, 0.2);
    } else if (species === 'fish' || species === 'dolphin') {
      const col = species === 'fish' ? '#6fa6a3' : '#829fae';
      this.part(g, col, 0, 0.35, 0, 0.32, 0.32, 0.8);
      head.position.set(0, 0.35, -0.4);
      this.part(head, col, 0, 0, 0, 0.28, 0.28, 0.3);
      eyes(0.05, -0.16, 0.1);
      this.part(g, col, 0, 0.35, 0.55, 0.08, 0.4, 0.3);
      this.part(g, col, 0, 0.58, 0.05, 0.08, 0.25, 0.3);
    } else if (NEW_SPECIES[species] && NEW_SPECIES[species].plan !== 'biped') {
      this.buildPlan(species, g, head, legs, eyes, quadLegs);
    } else {
      const info = NEW_SPECIES[species];
      const sk = species === 'skeleton' || species === 'stray' || species === 'bogged' || species === 'wither_skeleton';
      const en = species === 'enderman', v = species === 'villager' || species === 'wandering_trader', golem = species === 'iron_golem';
      const z = species === 'zombie' || species === 'husk' || species === 'drowned' || species === 'zombified_piglin' || species === 'zombie_villager';
      const skin = info ? info.skin : sk ? '#d5d4c5' : en ? '#292630' : v ? '#ba9472' : golem ? '#c3c2ad' : '#668b4d';
      const shirt = info ? info.shirt : sk ? '#c9c9bb' : en ? '#24222b' : v ? '#8b6547' : golem ? '#b4b6a2' : '#3f8d91';
      const pants = info ? info.pants : sk ? '#d0d0c2' : en ? '#211f29' : v ? '#6f513c' : golem ? '#969d88' : '#555b83';
      const scale = info ? info.scale : en ? 1.45 : golem ? 1.3 : 1;
      if (species === 'piglin' || species === 'piglin_brute' || species === 'zombified_piglin') {
        this.part(head, '#f0b8a8', 0, -0.12, -0.3, 0.26, 0.14, 0.1);
        this.part(head, '#f6f0d8', -0.1, -0.1, -0.33, 0.04, 0.1, 0.04);
        this.part(head, '#f6f0d8', 0.1, -0.1, -0.33, 0.04, 0.1, 0.04);
        this.part(head, '#f0b8a8', -0.3, 0.1, 0, 0.08, 0.2, 0.2);
        this.part(head, '#f0b8a8', 0.3, 0.1, 0, 0.08, 0.2, 0.2);
      }
      if (species === 'vindicator' || species === 'evoker' || species === 'wandering_trader' || species === 'zombie_villager') {
        this.part(head, '#9b7757', 0, -0.08, -0.34, 0.14, 0.28, 0.2);
        if (species !== 'wandering_trader' && species !== 'zombie_villager') this.part(g, '#1e1e1e', 0, 1.05, -0.28, 0.65, 0.22, 0.2);
      }
      if (species === 'evoker') this.part(g, '#d9b44a', 0, 1.2, -0.18, 0.3, 0.1, 0.05);
      if (species === 'wandering_trader') this.part(g, '#2b3a7a', 0, 1.4, 0, 0.7, 0.2, 0.5);
      if (species === 'vindicator') { const axe = this.part(g, '#8a8f94', 0.55, 1.0, -0.3, 0.3, 0.3, 0.06); axe.position.y = 0.9; }
      if (species === 'wither_skeleton') { const sw = this.part(g, '#5a5a5a', 0.45, 1.0, -0.35, 0.06, 0.85, 0.12); sw.rotation.x = -0.3; }
      if (species === 'bogged') { this.part(head, '#c43a2e', -0.15, 0.3, 0, 0.14, 0.1, 0.14); this.part(head, '#7a5a3a', 0.15, 0.28, 0.1, 0.12, 0.08, 0.12); }
      if (species === 'snow_golem') { this.part(head, '#d87a22', 0, 0.02, 0, 0.54, 0.54, 0.54); }
      g.scale.setScalar(scale);
      this.part(g, shirt, 0, 1.05, 0, golem ? 0.85 : 0.52, 0.7, 0.3);
      head.position.set(0, 1.65, 0);
      this.part(head, skin, 0, 0, 0, 0.5, 0.5, 0.5);
      eyes(0.05, -0.26, 0.13, en ? '#b78ce0' : '#202820');
      if (v) { this.part(head, '#9b7757', 0, -0.08, -0.34, 0.14, 0.28, 0.2); this.part(head, '#6d5138', 0, 0.25, -0.26, 0.52, 0.12, 0.12); this.part(g, '#a47b53', 0, 1.05, -0.28, 0.65, 0.22, 0.2); }
      if (golem) { this.part(head, '#7c8b54', 0, -0.16, -0.27, 0.2, 0.14, 0.04); this.part(g, '#6e8a46', -0.44, 1.15, 0, 0.12, 0.45, 0.32); }
      for (const s of [-1, 1]) {
        const leg = new THREE.Group(); leg.position.set(s * 0.14, 0.7, 0); this.part(leg, pants, 0, -0.35, 0, en ? 0.13 : 0.22, 0.7, en ? 0.13 : 0.23); g.add(leg); legs.push(leg);
        const arm = new THREE.Group(); arm.position.set(s * (golem ? 0.57 : 0.37), 1.35, 0); this.part(arm, skin, 0, -0.32, 0, golem ? 0.24 : 0.17, golem ? 0.9 : 0.65, 0.18);
        if (z || en) arm.rotation.x = -1.2;
        g.add(arm); legs.push(arm);
      }
      if (sk && species !== 'wither_skeleton') { this.part(g, '#7d6949', 0.45, 1.05, -0.3, 0.06, 0.8, 0.08); this.part(g, '#c9c4ad', 0.45, 1.05, -0.35, 0.04, 0.9, 0.02); }
    }
    const biped = species === 'zombie' || species === 'skeleton' || species === 'villager' || species === 'enderman' || species === 'iron_golem' || species === 'pillager' || species === 'witch' || NEW_SPECIES[species]?.plan === 'biped';
    const plan = NEW_SPECIES[species]?.plan;
    let saddle: THREE.Object3D | undefined;
    if (SADDLEABLE.has(species)) {
      const r = RIDE[species];
      saddle = this.part(g, '#6b4a2c', 0, (r?.seat ?? 1) - 0.25, 0, species === 'pig' ? 0.5 : 0.55, 0.14, species === 'pig' ? 0.5 : 0.6);
      saddle.visible = false;
    }
    const limbs: Limb[] = legs.map((node, i) => {
      const baseX = node.rotation.x, baseY = node.rotation.y, baseZ = node.rotation.z;
      const make = (kind: LimbKind, phase: number, amp: number): Limb => ({ node, kind, phase, amp, baseX, baseY, baseZ });
      if (species === 'spider') return make('spider', (i < 4 ? [0, Math.PI, 0, Math.PI] : [Math.PI, 0, Math.PI, 0])[i % 4], 0.26);
      if (species === 'dragon') return make('wing', Math.PI * (i % 2), 0.45);
      if (species === 'chicken') return i < 2 ? make('leg', Math.PI * i, 0.55) : make('wing', Math.PI * (i - 2), 0.4);
      if (species === 'bee') return make('wing', Math.PI * i, 0.5);
      if (species === 'squid' || species === 'glow_squid') return make('tentacle', (i / Math.max(1, legs.length)) * Math.PI * 2, 0.25);
      if (plan === 'flyer' || species === 'parrot') return make('wing', Math.PI * i, 0.6);
      if (plan === 'spider') return make('spider', (i < 4 ? [0, Math.PI, 0, Math.PI] : [Math.PI, 0, Math.PI, 0])[i % 4], 0.26);
      if (plan === 'strider' || plan === 'bird') return make('leg', Math.PI * i, 0.6);
      if (biped) return i % 2 === 0 ? make('leg', i === 0 ? 0 : Math.PI, 0.55) : make('arm', i === 1 ? Math.PI : 0, baseX < -0.5 ? 0.12 : 0.42);
      const quad = [0, Math.PI, Math.PI, 0];
      return make('leg', quad[i % 4], 0.52);
    });
    return { g, legs, head, woolCoat, collar, limbs, saddle };
  }

  private buildPlan(species: Species, g: THREE.Group, head: THREE.Group, legs: THREE.Object3D[], eyes: (y: number, z: number, sep: number, color?: string) => void, quadLegs: (color: string, w: number, h: number, d: number, x: number, z: number) => void) {
    const info = NEW_SPECIES[species];
    const { skin, shirt, pants, plan } = info;
    if (plan === 'quad') {
      const big = species === 'ravager' || species === 'camel' || species === 'sniffer';
      const steed = species === 'donkey' || species === 'mule' || species === 'skeleton_horse' || species === 'zombie_horse';
      const h = species === 'camel' ? 1.3 : steed ? 1.1 : species === 'llama' ? 1.0 : species === 'armadillo' ? 0.35 : 0.78;
      this.part(g, skin, 0, h, 0, big ? 0.9 : 0.72, big ? 0.8 : 0.65, big ? 1.4 : steed ? 1.3 : 1.05);
      if (species === 'panda' || species === 'mooshroom' || species === 'hoglin' || species === 'zoglin' || species === 'llama' || species === 'armadillo') this.part(g, shirt, 0, h + 0.02, 0.1, 0.74, 0.3, 0.6);
      head.position.set(0, h + (species === 'camel' ? 0.7 : steed ? 0.5 : 0.2), -0.6);
      this.part(head, skin, 0, 0, 0, 0.46, species === 'llama' || species === 'camel' || steed ? 0.6 : 0.43, 0.5);
      this.part(head, shirt, 0, -0.1, -0.3, 0.3, 0.18, 0.13);
      if (species === 'panda') { this.part(head, shirt, -0.14, 0.02, -0.26, 0.12, 0.12, 0.02); this.part(head, shirt, 0.14, 0.02, -0.26, 0.12, 0.12, 0.02); this.part(head, shirt, -0.2, 0.26, 0, 0.12, 0.12, 0.12); this.part(head, shirt, 0.2, 0.26, 0, 0.12, 0.12, 0.12); }
      if (species === 'hoglin' || species === 'zoglin') { this.part(head, '#f0e8d0', -0.2, -0.15, -0.3, 0.06, 0.2, 0.06); this.part(head, '#f0e8d0', 0.2, -0.15, -0.3, 0.06, 0.2, 0.06); }
      if (species === 'goat') { this.part(head, '#4a4036', -0.14, 0.28, 0.05, 0.08, 0.3, 0.08); this.part(head, '#4a4036', 0.14, 0.28, 0.05, 0.08, 0.3, 0.08); }
      if (species === 'ravager') { this.part(head, '#2b3137', -0.3, 0.25, 0, 0.12, 0.35, 0.3); this.part(head, '#2b3137', 0.3, 0.25, 0, 0.12, 0.35, 0.3); }
      if (species === 'camel') { this.part(g, shirt, 0, h + 0.5, 0.1, 0.6, 0.35, 0.6); }
      if (species === 'donkey' || species === 'mule') { this.part(head, pants, -0.16, 0.42, 0, 0.08, 0.32, 0.08); this.part(head, pants, 0.16, 0.42, 0, 0.08, 0.32, 0.08); }
      if (species === 'mooshroom') for (const [mx, mz] of [[-0.2, 0.2], [0.2, -0.1], [0, 0.35]]) { this.part(g, '#c9c0ae', mx, h + 0.45, mz, 0.08, 0.2, 0.08); this.part(g, '#c43a2e', mx, h + 0.58, mz, 0.22, 0.1, 0.22); }
      if (species === 'sniffer') { this.part(g, '#7fb85a', 0, h + 0.45, 0.1, 0.9, 0.1, 1.3); this.part(head, '#7fb85a', 0, 0.2, -0.1, 0.5, 0.1, 0.5); }
      eyes(0.07, -0.26, 0.14, species === 'panda' ? '#ffffff' : '#171b17');
      quadLegs(pants, 0.18, h, 0.18, 0.26, big || steed ? 0.48 : 0.34);
    } else if (plan === 'spider') {
      this.part(g, skin, 0, 0.45, 0.2, 0.8, 0.42, 0.9);
      head.position.set(0, 0.45, -0.5);
      this.part(head, shirt, 0, 0, 0, 0.55, 0.38, 0.5);
      eyes(0.05, -0.26, 0.15, '#d44732');
      for (const sd of [-1, 1]) for (let i = 0; i < 4; i++) {
        const pivot = new THREE.Group(); pivot.position.set(sd * 0.4, 0.45, -0.35 + i * 0.25);
        this.part(pivot, pants, sd * 0.45, 0, 0, 0.9, 0.1, 0.1); pivot.rotation.z = sd * 0.25; g.add(pivot); legs.push(pivot);
      }
    } else if (plan === 'fish') {
      const guardian = species === 'guardian' || species === 'elder_guardian';
      const puffer = species === 'pufferfish';
      this.part(g, skin, 0, 0.35, 0, guardian ? 0.7 : puffer ? 0.45 : 0.32, guardian ? 0.7 : puffer ? 0.45 : 0.32, guardian ? 0.7 : puffer ? 0.45 : 0.8);
      head.position.set(0, 0.35, guardian || puffer ? -0.2 : -0.4);
      this.part(head, skin, 0, 0, 0, 0.28, 0.28, 0.3);
      eyes(0.05, guardian ? -0.3 : -0.16, guardian ? 0 : 0.1, guardian ? shirt : '#171b17');
      if (guardian || puffer) for (let i = 0; i < 12; i++) { const a = (i / 12) * 6.28; this.part(g, pants, Math.cos(a) * (guardian ? 0.4 : 0.25), 0.35 + Math.sin(a * 2) * (guardian ? 0.25 : 0.15), Math.sin(a) * (guardian ? 0.4 : 0.25), 0.08, 0.08, guardian ? 0.4 : 0.2); }
      else { this.part(g, skin, 0, 0.35, 0.55, 0.08, 0.4, 0.3); if (species === 'axolotl') { for (const sd of [-1, 1]) this.part(head, shirt, sd * 0.18, 0.1, 0, 0.2, 0.06, 0.06); quadLegs(pants, 0.06, 0.15, 0.06, 0.14, 0.2); } }
      if (species === 'glow_squid') for (let i = 0; i < 6; i++) { const a = (i / 6) * 6.28; const t = new THREE.Group(); t.position.set(Math.cos(a) * 0.25, 0.2, Math.sin(a) * 0.25); this.part(t, skin, 0, -0.15, 0, 0.08, 0.3, 0.08); g.add(t); legs.push(t); }
    } else if (plan === 'bird') {
      this.part(g, skin, 0, 0.42, 0, 0.3, 0.36, 0.45);
      head.position.set(0, 0.72, -0.18);
      this.part(head, skin, 0, 0, 0, 0.26, 0.28, 0.26);
      this.part(head, '#4a4a4a', 0, -0.05, -0.2, 0.12, 0.1, 0.12);
      eyes(0.05, -0.14, 0.09);
      this.part(g, pants, 0, 0.42, 0.35, 0.1, 0.1, 0.4);
      for (const sx of [-1, 1]) { const w = new THREE.Group(); w.position.set(sx * 0.15, 0.5, 0); this.part(w, shirt, sx * 0.1, 0, 0, 0.2, 0.04, 0.3); g.add(w); legs.push(w); }
    } else if (plan === 'blob') {
      this.part(g, skin, 0, 0.25, 0, 0.6, 0.45, 0.8);
      head.position.set(0, 0.35, -0.4);
      this.part(head, shirt, 0, 0, 0, 0.5, 0.35, 0.4);
      eyes(0.1, -0.2, 0.15, species === 'frog' ? '#ffffff' : '#2a2a2a');
      if (species === 'frog') quadLegs(pants, 0.1, 0.2, 0.1, 0.3, 0.3);
      else for (let i = 0; i < 3; i++) this.part(g, pants, 0, 0.25, -0.3 + i * 0.3, 0.64, 0.1, 0.1);
    } else if (plan === 'flyer') {
      const phantom = species === 'phantom', breeze = species === 'breeze';
      this.part(g, skin, 0, 0.5, 0, phantom ? 0.5 : breeze ? 0.55 : 0.4, phantom ? 0.3 : breeze ? 0.9 : 0.6, phantom ? 1.4 : breeze ? 0.55 : 0.35);
      head.position.set(0, phantom ? 0.5 : 0.95, phantom ? -0.8 : 0);
      this.part(head, shirt, 0, 0, 0, 0.45, phantom ? 0.3 : 0.45, 0.45);
      eyes(0.05, -0.23, 0.12, phantom ? '#8ee36f' : breeze ? '#ffffff' : '#f0f0f0');
      for (const sx of [-1, 1]) {
        const w = new THREE.Group(); w.position.set(sx * 0.25, 0.6, 0);
        this.part(w, pants, sx * (phantom ? 1.2 : 0.4), 0, 0, phantom ? 2.4 : 0.8, 0.06, phantom ? 0.9 : 0.4);
        g.add(w); legs.push(w);
      }
      if (species === 'vex') { const sword = this.part(g, '#c9ccd0', 0.35, 0.4, -0.2, 0.06, 0.6, 0.06); sword.rotation.x = -1.2; }
    } else if (plan === 'strider') {
      this.part(g, skin, 0, 1.25, 0, 0.9, 0.9, 0.9);
      head.position.set(0, 1.7, -0.3);
      eyes(0.0, -0.46, 0.2, '#f0c040');
      for (let i = 0; i < 5; i++) this.part(g, shirt, 0, 1.0 + i * 0.12, -0.46 + i * 0.01, 0.9 - i * 0.05, 0.05, 0.02);
      for (const sx of [-1, 1]) { const leg = new THREE.Group(); leg.position.set(sx * 0.22, 0.85, 0); this.part(leg, pants, 0, -0.42, 0, 0.12, 0.85, 0.12); g.add(leg); legs.push(leg); }
    }
    g.scale.setScalar(info.scale);
  }

  private setHurtTint(m: Mob, hurt: boolean) {
    m.group.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        if (!mesh.userData.baseMat) mesh.userData.baseMat = mesh.material;
        mesh.material = hurt ? this.hurtMat : mesh.userData.baseMat;
      }
    });
  }

  spawn(species: Species, x: number, z: number, baby = false, exactY?: number) {
    if (!SPECIES.includes(species)) return undefined;
    const h = this.host.terrain.height(x, z);
    const y = exactY ?? (species === 'dragon' ? 40 : h + 1);
    if (swimmers.has(species)) {
      if (exactY === undefined && h >= SEA_LEVEL) return undefined;
    } else if (species !== 'dragon' && exactY === undefined && this.host.dimension === 'overworld' && y < SEA_LEVEL + 1) return undefined;

    const { g, legs, head, woolCoat, collar, limbs, saddle } = this.model(species);
    g.position.set(x, y, z);
    if (baby) g.scale.multiplyScalar(0.5);
    const info = NEW_SPECIES[species];
    this.scene.add(g);
    const maxHp =
      species === 'dragon' ? 200 :
      species === 'wither' ? 150 :
      species === 'warden' ? 500 :
      species === 'iron_golem' ? 100 :
      species === 'enderman' ? 40 :
      species === 'horse' ? 30 :
      species === 'shulker' ? 30 :
      species === 'pillager' ? 24 :
      species === 'witch' ? 26 :
      species === 'slime' || species === 'magma_cube' ? 16 :
      species === 'zombie' || species === 'skeleton' || species === 'creeper' ? 20 : info ? info.hp : 10;

    const m: Mob = {
      id: this.nextId++,
      species,
      group: g,
      legs,
      limbs,
      walk: Math.random() * Math.PI * 2,
      swing: 0,
      lastX: x,
      lastZ: z,
      head,
      woolCoat,
      collar,
      hp: maxHp,
      maxHp,
      state: species === 'dragon' ? 'circle' : 'wander',
      phaseTimer: 8 + this.rnd() * 6,
      timer: 1 + this.rnd() * 4,
      attack: 0,
      hurtTimer: 0,
      dir: this.rnd() * Math.PI * 2,
      speed: species === 'dragon' ? 9 : species === 'horse' ? 2.4 : species === 'shulker' ? 0 : species === 'chicken' ? 1.0 : info ? info.speed : 1.25,
      target: g.position.clone(),
      fuse: 0,
      wool: true,
      tamed: false,
      love: 0,
      egg: 20 + this.rnd() * 40,
      baby,
      grow: baby ? 120 : species === 'tadpole' ? 120 : 0,
      age: baby ? -120 : 0,
      breedCooldown: 0,
      saddled: undefined,
      saddle,
      leashed: false,
      leashPos: null,
      sitting: false,
      anger: 0,
      path: null,
      pathAt: 0,
      profession: 'none',
      level: 1,
      xp: 0,
      villager: species === 'villager' ? newVillager('unemployed') : species === 'wandering_trader' ? wanderingTrader(this.nextId * 977) : undefined,
      captain: false,
      raid: false,
      raidMember: false,
      vy: 0,
      lastNoise: null,
      tameTries: 0,
      barter: 0,
      zombify: (species === 'piglin' || species === 'piglin_brute' || species === 'hoglin') && this.host.dimension !== 'nether' ? 15 : 0,
      special: 0,
    };
    if (species === 'villager') {
      const prof = (['farmer', 'librarian', 'none', 'armorer', 'cleric', 'butcher', 'fletcher', 'none'] as Profession[])[Math.floor(this.rnd() * 8)];
      m.profession = prof;
      if (m.villager) m.villager.profession = prof === 'none' ? 'unemployed' : prof;
    }
    this.mobs.push(m);
    return m;
  }

  equipSaddle(m: Mob) {
    if (m.saddled) return;
    m.saddled = true;
    if (m.saddle) m.saddle.visible = true;
    else m.saddle = this.part(m.group, '#8c4f32', 0, m.species === 'horse' ? 1.25 : m.species === 'strider' ? 1.53 : 0.91, 0.08, 0.58, 0.12, 0.7);
  }

  clearSight(a: THREE.Vector3, b: THREE.Vector3) {
    const d = b.clone().sub(a), length = d.length();
    if (length <= 0.6) return true;
    d.normalize();
    for (let t = 0.3; t < length - 0.3; t += 0.3) {
      const p = a.clone().addScaledVector(d, t), id = this.host.getBlock(p.x, p.y, p.z);
      if (id > 0 && BLOCKS[id]?.solid) return false;
    }
    return true;
  }

  tieLeashes(x: number, y: number, z: number): number {
    let n = 0;
    for (const m of this.mobs) {
      if (m.leashed && !m.leashPos) {
        m.leashPos = [Math.floor(x), Math.floor(y), Math.floor(z)];
        n++;
      }
    }
    return n;
  }

  save(): MobSave[] {
    return this.mobs.map(m => ({
      id: m.id,
      raidMember: m.raidMember || m.raid,
      species: m.species,
      position: m.group.position.toArray() as [number, number, number],
      hp: m.hp,
      baby: m.baby,
      age: m.age ?? 0,
      grow: m.grow,
      tamed: m.tamed,
      saddled: !!m.saddled,
      sitting: !!m.sitting,
      leashed: !!m.leashed,
      leashPos: m.leashPos ?? null,
      wool: m.wool,
      breedCooldown: m.breedCooldown ?? 0,
      love: m.love,
      profession: m.profession,
      level: m.level,
      xp: m.xp,
      villager: m.villager ? structuredClone(m.villager) : undefined,
    }));
  }

  load(data: MobSave[]) {
    this.clear();
    for (const s of data) {
      if (!SPECIES.includes(s.species) || !s.position.every(Number.isFinite)) continue;
      const m = this.spawn(s.species, s.position[0], s.position[2], s.baby, s.position[1]);
      if (!m) continue;
      m.id = s.id ?? m.id;
      this.nextId = Math.max(this.nextId, m.id + 1);
      m.raidMember = s.raidMember;
      m.raid = !!s.raidMember;
      Object.assign(m, {
        hp: Math.max(1, Math.min(m.maxHp, s.hp)),
        age: s.age,
        grow: s.grow ?? (s.baby ? 120 : 0),
        tamed: s.tamed,
        sitting: s.sitting,
        leashed: s.leashed,
        leashPos: s.leashPos ?? null,
        wool: s.wool,
        breedCooldown: s.breedCooldown,
        love: s.love,
        profession: s.profession ?? m.profession,
        level: s.level ?? m.level,
        xp: s.xp ?? m.xp,
        villager: s.villager ?? m.villager,
      });
      if (s.saddled) this.equipSaddle(m);
      if (m.collar) m.collar.visible = s.tamed;
      if (m.woolCoat) m.woolCoat.visible = s.wool;
    }
    if (this.host.dimension === 'end' && !this.host.dragonDefeated) {
      for (const p of endPillars()) this.spawnCrystal(p.x, p.h + 2, p.z);
    }
  }

  spawnCrystal(x: number, y: number, z: number) {
    const group = new THREE.Group();
    group.position.set(x + 0.5, y, z + 0.5);
    const base = new THREE.Mesh(this.box, this.mat('#352d42'));
    base.scale.set(0.85, 0.25, 0.85);
    base.position.y = 0.125;
    const core = new THREE.Mesh(this.box, this.glowMat('#eb52eb', 1));
    core.scale.set(0.6, 0.6, 0.6);
    core.position.y = 1.05;
    const shell = new THREE.Mesh(this.box, this.glowMat('#ffc9ff', 0.45));
    shell.scale.set(0.85, 0.85, 0.85);
    shell.position.y = 1.05;
    group.add(base, core, shell);
    this.scene.add(group);
    this.crystals.push({ group, core, shell, pos: group.position });
  }

  populate() {
    this.clear();
    if (this.host.dimension === 'overworld') {
      const p = this.host.position;
      const list: Species[] = ['cow', 'pig', 'sheep', 'chicken', 'cow', 'sheep', 'villager', 'villager', 'wolf', 'cat', 'horse', 'bee', 'rabbit', 'fox'];
      for (let i = 0; i < list.length; i++) {
        const a = i * 2.15, r = 6 + i * 1.55;
        this.spawn(list[i], p.x + Math.cos(a) * r, p.z + Math.sin(a) * r);
      }
      for (const [x, z] of [[15, 5], [19, -8], [5, 20]]) this.spawn('fish', x, z);
      const biome = this.host.terrain.biome(p.x, p.z);
      const extra: Species[] = biome.includes('jungle') ? ['panda', 'parrot', 'ocelot'] : biome.includes('snow') || biome.includes('frozen') ? ['polar_bear', 'snow_golem'] : biome.includes('savanna') ? ['llama', 'donkey', 'armadillo'] : biome.includes('desert') ? ['camel'] : biome.includes('swamp') ? ['frog', 'tadpole'] : biome === 'mushroom_fields' ? ['mooshroom', 'mooshroom'] : biome.includes('peaks') || biome.includes('slopes') || biome.includes('meadow') ? ['goat', 'goat'] : ['donkey'];
      extra.forEach((sp, i) => this.spawn(sp, p.x + Math.cos(i * 1.9 + 1) * 14, p.z + Math.sin(i * 1.9 + 1) * 14));
    } else if (this.host.dimension === 'nether') {
      for (const [sp, x, y, z] of [
        ['ghast', 18, 36, -15], ['ghast', -22, 39, 14],
        ['blaze', 35, 27, 35], ['blaze', 39, 27, 39], ['blaze', 34, 27, 41],
        ['wither_skeleton', 32, 27, 34], ['wither_skeleton', 38, 27, 36],
        ['magma_cube', 14, 26, 8], ['enderman', -14, 26, -12],
        ['piglin', 8, 26, 14], ['piglin', 11, 26, 16], ['hoglin', -8, 26, 18], ['zombified_piglin', 20, 26, 4], ['strider', 0, 32, 30],
      ] as [Species, number, number, number][]) {
        this.spawn(sp, x, z, false, y);
      }
    } else if (this.host.dimension === 'end') {
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        this.spawn('enderman', Math.cos(a) * 18, Math.sin(a) * 18, false, 28);
      }
      for (const [sx, sy, sz] of [[515, 28, 10], [523, 35, 16], [519, 49, 13], [534, 42, -10]]) {
        this.spawn('shulker', sx, sz, false, sy);
      }
      if (!this.host.dragonDefeated) {
        for (const pil of endPillars()) {
          this.spawnCrystal(pil.x, pil.h + 2, pil.z);
        }
        this.spawn('dragon', 0, 0, false, 44);
      }
    }
  }

  clear() {
    for (const m of this.mobs) this.scene.remove(m.group);
    for (const c of this.crystals) this.scene.remove(c.group);
    for (const p of this.projectiles) this.scene.remove(p.mesh);
    this.mobs = [];
    this.crystals = [];
    this.projectiles = [];
    this.riding = null;
    this.activeVillager = null;
    this.tradingMob = null;
  }

  getBossInfo(): BossInfo | null {
    if (this.raid) return { name: `Raid – wave ${this.raid.wave}/${this.raid.total}`, ja: `襲撃 – 第${this.raid.wave}波 / ${this.raid.total}`, hp: this.raid.alive, maxHp: Math.max(1, this.raid.alive, 8), color: '#c03a2b' };
    const warden = this.mobs.find(m => m.species === 'warden' && m.anger >= 80);
    if (warden) return { name: 'Warden', ja: 'ウォーデン', hp: warden.hp, maxHp: warden.maxHp, color: '#1b6a7a' };
    const boss = this.mobs.find(m => m.species === 'dragon' || m.species === 'wither' || m.species === 'warden');
    if (!boss) return null;
    const jaMap: Record<string, string> = { dragon: 'エンダードラゴン', wither: 'ウィザー', warden: 'ウォーデン' };
    return {
      name: boss.species === 'dragon' ? 'Ender Dragon' : boss.species.replace(/_/g, ' '),
      ja: jaMap[boss.species] ?? boss.species,
      hp: Math.max(0, Math.ceil(boss.hp)),
      maxHp: boss.maxHp,
      color: boss.species === 'dragon' ? '#c864e8' : '#7b8098',
      crystals: boss.species === 'dragon' ? this.crystals.length : 0,
    };
  }

  bossInfo(): BossInfo | null {
    if (this.raid) return this.getBossInfo();
    const boss = this.mobs.find(m => (m.species === 'dragon' || m.species === 'wither' || m.species === 'warden') && m.group.position.distanceTo(this.host.position) < 120);
    if (!boss) return null;
    const jaMap: Record<string, string> = { dragon: 'エンダードラゴン', wither: 'ウィザー', warden: 'ウォーデン' };
    return {
      name: boss.species === 'dragon' ? 'Ender Dragon' : boss.species.replace(/_/g, ' '),
      ja: jaMap[boss.species] ?? boss.species,
      hp: Math.max(0, Math.ceil(boss.hp)),
      maxHp: boss.maxHp,
      color: boss.species === 'dragon' ? '#c864e8' : '#7b8098',
      crystals: boss.species === 'dragon' ? this.crystals.length : 0,
    };
  }

  destroyCrystal(idx: number) {
    const c = this.crystals[idx];
    if (!c) return;
    const pos = c.pos.clone().add(new THREE.Vector3(0, 1, 0));
    this.scene.remove(c.group);
    this.crystals.splice(idx, 1);
    this.host.explode(pos, 3);
    this.host.particles.burst(pos, '#eb52eb', 28, 7);
    this.host.toast('エンドクリスタルを破壊しました！', 'End Crystal destroyed!');
  }

  hit(origin: THREE.Vector3, dir: THREE.Vector3, damage: number, critical = false) {
    for (let i = 0; i < this.crystals.length; i++) {
      const cpos = this.crystals[i].pos.clone().add(new THREE.Vector3(0, 1, 0));
      const v = cpos.sub(origin);
      const d = v.length();
      if (d < 6 && v.normalize().dot(dir) > 0.9) {
        this.destroyCrystal(i);
        return true;
      }
    }
    for (const p of this.projectiles) {
      if (p.kind === 'ghast_fireball') {
        const v = p.mesh.position.clone().sub(origin);
        if (v.length() < 5 && v.normalize().dot(dir) > 0.88) {
          p.v.copy(dir).multiplyScalar(18);
          this.host.sound('stone', p.mesh.position);
          return true;
        }
      }
    }

    let best: Mob | null = null, bestD = 6;
    for (const m of this.mobs) {
      const centerH = m.species === 'dragon' ? 1.5 : 0.9;
      const v = m.group.position.clone().add(new THREE.Vector3(0, centerH, 0)).sub(origin);
      const d = v.length();
      const dot = v.normalize().dot(dir);
      const reach = m.species === 'dragon' ? 7 : 5;
      const cone = m.species === 'dragon' ? 0.86 : 0.93;
      if (d < Math.min(bestD, reach) && dot > cone) {
        best = m;
        bestD = d;
      }
    }
    if (!best) return false;
    this.lastHit = best;
    let finalDamage = critical ? Math.ceil(damage * 1.5) : damage;
    if (best.species === 'armadillo') {
      if ((best.rolledUp ?? 0) > 0) finalDamage = Math.max(1, Math.floor(finalDamage * 0.35));
      best.rolledUp = 6;
    }
    best.hp -= finalDamage;
    best.hurtTimer = 0.24;
    this.setHurtTint(best, true);
    if (best.species !== 'dragon' && best.species !== 'shulker') {
      best.state = passive.has(best.species) && !neutral.has(best.species) ? 'flee' : 'chase';
      best.timer = 4;
      best.group.position.addScaledVector(dir, 0.5);
      this.provoke(best);
    }
    const center = best.group.position.clone().add(new THREE.Vector3(0, 1, 0));
    this.host.particles.burst(center, best.species === 'dragon' ? '#d966ff' : '#b65343', critical ? 16 : 10);
    if (critical) {
      this.host.particles.spark?.(center, '#ffd866', 10);
      this.host.sound('critical', best.group.position);
    } else {
      this.host.sound('hurt', best.group.position);
    }
    if (best.hp <= 0) this.kill(best);
    return true;
  }

  kill(m: Mob) {
    if (m === this.riding) this.riding = null;
    if (m === this.activeVillager) this.activeVillager = null;
    if (m === this.tradingMob) this.tradingMob = null;
    if (m.captain) {
      this.badOmen = true;
      this.host.effect?.('bad_omen', 600, 0);
      this.host.toast('不吉な予感…（村に近づくと襲撃が起きる）', 'Bad Omen… (a raid starts near a village)');
      this.host.particles.drop(m.group.position.clone().add(new THREE.Vector3(0, 0.5, 0)), 'ominous_banner', 1, '#5a5a6a');
    }
    if (m.leashed) this.host.particles.drop(m.group.position.clone(), 'lead', 1, '#a8875a');
    if (m.saddled) this.host.particles.drop(m.group.position.clone(), 'saddle', 1, '#8b6547');
    if (m.species === 'evoker' && (m.raid || m.raidMember)) this.host.particles.drop(m.group.position.clone(), 'emerald', 2, '#69bd7c');
    // Slime and magma cube split into two smaller slimes when defeated
    if ((m.species === 'slime' || m.species === 'magma_cube') && !m.baby && m.group.scale.x > 0.65 && this.mobs.length < 36) {
      for (const s of [-0.6, 0.6]) {
        const child = this.spawn(m.species, m.group.position.x + s, m.group.position.z + s, true, m.group.position.y);
        if (child) { child.hp = child.maxHp = 4; }
      }
    }
    const [name, count0] = drops[m.species] ?? ['string', 0];
    const count = count0 + (this.looting > 0 && count0 > 0 ? Math.floor(Math.random() * (this.looting + 1)) : 0);
    if (count > 0 && resolve(name)) {
      this.host.particles.drop(m.group.position.clone().add(new THREE.Vector3(0, 0.5, 0)), name, count, resolve(name)?.color || '#b88b65');
    }
    this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 0.8, 0)), m.species === 'dragon' ? '#e599ff' : '#d7d0b8', m.species === 'dragon' ? 60 : 18, m.species === 'dragon' ? 9 : 4);
    this.scene.remove(m.group);
    this.mobs = this.mobs.filter(x => x !== m);
    this.host.addXp?.(m.species === 'dragon' ? 100 : m.species === 'wither' ? 50 : passive.has(m.species) ? 3 : 6);
    if (m.species === 'dragon') {
      this.host.onDragonDefeated();
    }
  }

  private provoke(m: Mob) {
    if (m === this.riding) return;
    if (m.species === 'warden') { m.anger = 150; m.lastNoise = this.host.position.clone(); return; }
    const group = m.species === 'zombified_piglin' || m.species === 'piglin' || m.species === 'wolf' || m.species === 'bee' || m.species === 'polar_bear' || m.species === 'panda' || m.species === 'iron_golem' || m.species === 'llama' || m.species === 'goat';
    if (neutral.has(m.species) || m.species === 'piglin' || m.species === 'piglin_brute') {
      if (m.tamed) return;
      m.anger = 25;
      if (group) for (const o of this.mobs) if (o !== m && o.species === m.species && !o.tamed && o.group.position.distanceTo(m.group.position) < 16) { o.anger = 25; o.state = 'chase'; }
    }
    if (m.species === 'llama' && m.anger > 0) {
      this.launchProjectile('snowball', m.group.position.clone().add(new THREE.Vector3(0, 1.4, 0)), this.host.camera.position.clone().sub(m.group.position).normalize(), 12, undefined, { color: '#9fbf5a' });
    }
  }

  private damageMob(m: Mob, damage: number, dir?: THREE.Vector3, critical = false) {
    const finalDamage = critical ? Math.ceil(damage * 1.5) : damage;
    m.hp -= finalDamage;
    m.hurtTimer = 0.24;
    this.setHurtTint(m, true);
    if (m.species !== 'dragon' && m.species !== 'shulker') {
      m.state = passive.has(m.species) ? 'flee' : 'chase';
      m.timer = 4;
      if (dir) m.group.position.addScaledVector(dir, 0.5);
    }
    const center = m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0));
    this.host.particles.burst(center, m.species === 'dragon' ? '#d966ff' : '#c74c3c', critical ? 16 : 8);
    this.host.sound(critical ? 'critical' : 'hurt', m.group.position);
    if (m.hp <= 0) this.kill(m);
  }

  activeVillager: Mob | null = null;
  tradingMob: Mob | null = null;
  riding: Mob | null = null;
  heroTimer = 0;
  badOmen = false;
  raid: RaidState | null = null;
  private leashLine: THREE.LineSegments | null = null;
  private playerSpeed = 0;
  private lastPlayerPos = new THREE.Vector3();
  private leashGeo = new THREE.BufferGeometry();

  pick(origin: THREE.Vector3, dir: THREE.Vector3, reach = 4.6): Mob | null {
    let best: Mob | null = null, bestD = reach;
    for (const m of this.mobs) {
      if (m === this.riding) continue;
      const center = m.group.position.clone().add(new THREE.Vector3(0, 0.8 * m.group.scale.y, 0));
      const v = center.clone().sub(origin);
      const d = v.length();
      if (d > bestD || v.normalize().dot(dir) < 0.88 || !this.clearSight(origin, center)) continue;
      best = m; bestD = d;
    }
    return best;
  }

  interact(origin: THREE.Vector3, dir: THREE.Vector3, item: string, crouching = false): boolean | 'consume' {
    const m = this.pick(origin, dir);
    if (!m) return false;
    const sp = m.species, pos = m.group.position;
    const consume = (): true => {
      this.host.consume?.(item, 1);
      return true;
    };
    const hearts = () => this.host.particles.burst(pos.clone().add(new THREE.Vector3(0, 1.3 * m.group.scale.y, 0)), '#d85b65', 8, 1);
    const smoke = () => this.host.particles.burst(pos.clone().add(new THREE.Vector3(0, 1.0, 0)), '#777777', 8, 1);

    // Villager / Wandering Trader trading
    if (sp === 'villager' || sp === 'wandering_trader') {
      if (m.baby) return true;
      this.activeVillager = m;
      this.tradingMob = m;
      m.state = 'trade'; m.timer = 6;
      this.host.openTrade(m);
      return true;
    }
    // Zombie Villager curing with Golden Apple
    if (sp === 'zombie_villager' && (item === 'golden_apple' || item === 'enchanted_golden_apple')) {
      this.replaceSpecies(m, 'villager');
      m.profession = 'farmer';
      m.villager = newVillager('farmer');
      this.host.toast('村人ゾンビを治療しました！', 'Cured Zombie Villager!');
      this.host.sound('levelup', pos);
      return consume();
    }
    // Leads: attach / detach
    if (item === 'lead' && LEASHABLE.has(sp)) {
      if (m.leashed) {
        m.leashed = false; m.leashPos = null;
        this.host.addItem('lead', 1);
        this.host.sound('wood', pos);
        return true;
      }
      m.leashed = true; m.leashPos = null; m.sitting = false;
      this.host.sound('wood', pos);
      return consume();
    }
    if (m.leashed && item !== 'lead') {
      m.leashed = false; m.leashPos = null;
      this.host.addItem('lead', 1);
      this.host.sound('wood', pos);
      return true;
    }
    // Piglins barter for gold ingots
    if (sp === 'piglin' && item === 'gold_ingot') {
      m.barter = 3; m.state = 'graze'; m.timer = 3.5; m.anger = 0;
      this.host.sound('xp', pos);
      return consume();
    }
    // Taming with food (wolves, cats, ocelots, parrots) before breeding
    const tame = TAME_FOOD[sp];
    if (tame && !m.tamed && tame.items.includes(item)) {
      if (this.rnd() < 0.45) this.tame(m); else smoke();
      return consume();
    }
    // Breeding food & pet healing
    const food = BREED_FOOD[sp];
    if (food && food.includes(item)) {
      if (m.baby) {
        m.grow = Math.max(0, m.grow - 12);
        if (m.age !== undefined) m.age = Math.min(0, m.age * 0.9);
        hearts();
        return consume();
      }
      if (m.tamed && m.hp < m.maxHp && (sp === 'wolf' || sp === 'cat')) {
        m.hp = Math.min(m.maxHp, m.hp + 4);
        hearts();
        return consume();
      }
      if (RIDE_TAME.has(sp) && !m.tamed) {
        m.tameTries++; hearts();
        if (this.rnd() < 0.35 * m.tameTries) this.tame(m);
        return consume();
      }
      if (m.breedCooldown > 0 || m.love > 0) return false;
      if ((sp === 'wolf' || sp === 'cat') && !m.tamed) return false;
      m.love = 30; m.state = 'follow'; m.sitting = false; hearts();
      this.host.sound('eat', pos);
      return consume();
    }
    // Tadpole fed slime_ball grows faster into a frog
    if (sp === 'tadpole' && item === 'slime_ball') {
      m.grow = Math.max(0, m.grow - 30);
      if (m.grow <= 0) this.replaceSpecies(m, 'frog');
      else hearts();
      return consume();
    }
    // Saddles
    if (item === 'saddle' && SADDLEABLE.has(sp) && !m.baby) {
      if (RIDE_TAME.has(sp) && !m.tamed) {
        this.host.toast('空の手で、先に馬を手懐けましょう', 'Tame the horse with an empty hand first');
        return true;
      }
      if (!m.saddled) {
        this.equipSaddle(m);
        this.host.sound('wood', pos);
        return consume();
      }
      this.mount(m);
      return true;
    }
    // Milking / stew / shearing / scute brushing
    if ((sp === 'cow' || sp === 'mooshroom' || sp === 'goat') && item === 'bucket') {
      this.host.addItem('milk_bucket', 1);
      this.host.sound('water', pos);
      return consume();
    }
    if (sp === 'mooshroom' && item === 'bowl') {
      this.host.addItem('mushroom_stew', 1);
      return consume();
    }
    if (sp === 'mooshroom' && item === 'shears') {
      this.replaceSpecies(m, 'cow');
      this.host.particles.drop(pos.clone(), 'red_mushroom', 5, '#c43a2e');
      return true;
    }
    if (sp === 'sheep' && item === 'shears' && m.wool) {
      m.wool = false; if (m.woolCoat) m.woolCoat.visible = false;
      this.host.addItem('white_wool', 1 + Math.floor(this.rnd() * 3));
      this.host.sound('grass', pos);
      return true;
    }
    if (sp === 'bogged' && item === 'shears' && !m.shearedHead) {
      m.shearedHead = true;
      this.host.particles.drop(pos.clone(), 'red_mushroom', 2, '#c43a2e');
      this.host.sound('grass', pos);
      return true;
    }
    if (sp === 'armadillo' && (item === 'shears' || item === 'stick')) {
      this.host.particles.drop(pos.clone().add(new THREE.Vector3(0, 0.4, 0)), 'scute', 1, '#b07a6a');
      this.host.sound('wood', pos);
      return true;
    }
    if (sp === 'snow_golem' && item === 'shears' && !m.shearedHead) {
      m.shearedHead = true;
      this.host.particles.drop(pos.clone().add(new THREE.Vector3(0, 1.5, 0)), 'carved_pumpkin', 1, '#d87a22');
      return true;
    }
    // Tamed pets sit / stand
    if (m.tamed && (sp === 'wolf' || sp === 'cat' || sp === 'parrot' || sp === 'ocelot')) {
      m.sitting = !m.sitting;
      m.state = m.sitting ? 'graze' : 'follow';
      this.host.toast(m.sitting ? 'おすわり' : 'ついてくる', m.sitting ? 'Sitting' : 'Following');
      return true;
    }
    // Untamed horse/steed taming with empty hand, or mounting saddled mounts
    if (!crouching && (SADDLEABLE.has(sp) || RIDE_TAME.has(sp)) && !m.baby) {
      if (RIDE_TAME.has(sp) && !m.tamed) {
        m.tameTries++;
        if (this.rnd() < 0.35 + m.tameTries * 0.15) {
          this.tame(m);
        } else {
          smoke();
          this.host.toast('振り落とされた！もう一度乗ってみよう', 'Bucked off! Try again');
        }
        return true;
      }
      if ((sp === 'pig' || sp === 'strider') && !m.saddled) return false;
      this.mount(m);
      return true;
    }
    if (sp === 'allay' && item) { m.tamed = true; hearts(); return true; }
    return false;
  }

  private tame(m: Mob) {
    m.tamed = true; m.state = 'follow'; m.sitting = false; m.anger = 0;
    if (m.collar) m.collar.visible = true;
    this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0)), '#e84a5f', 14, 1.5);
    const ja = NEW_SPECIES[m.species]?.ja ?? ({ wolf: 'オオカミ', cat: 'ネコ', horse: 'ウマ' } as Record<string, string>)[m.species] ?? m.species;
    this.host.toast(`${ja}が懐きました！`, `${m.species.replace(/_/g, ' ')} tamed!`);
  }

  private replaceSpecies(m: Mob, to: Species) {
    const { g, legs, head, woolCoat, collar, limbs, saddle } = this.model(to);
    g.position.copy(m.group.position); g.rotation.y = m.group.rotation.y; g.scale.copy(m.group.scale);
    this.scene.remove(m.group); this.scene.add(g);
    m.group = g; m.legs = legs; m.head = head; m.woolCoat = woolCoat; m.collar = collar; m.limbs = limbs; m.saddle = saddle; m.species = to; m.zombify = 0;
    m.maxHp = NEW_SPECIES[to]?.hp ?? m.maxHp; m.hp = Math.min(m.hp, m.maxHp);
    this.host.particles.burst(g.position.clone().add(new THREE.Vector3(0, 1, 0)), '#9bd36a', 12, 1);
  }

  // ------------------------------------------------------------------ riding

  mount(m: Mob) {
    this.riding = m; m.state = 'wander'; m.sitting = false; m.leashed = false; m.leashPos = null;
    if (RIDE_TAME.has(m.species) && !m.tamed) m.special = 2 + this.rnd() * 3;
    this.host.sound('wood', m.group.position);
  }

  dismount(): THREE.Vector3 | null {
    const m = this.riding; if (!m) return null;
    this.riding = null;
    const out = m.group.position.clone(); out.x += Math.cos(m.dir) * 1.0; out.z -= Math.sin(m.dir) * 1.0; out.y += 0.2;
    return out;
  }

  drive(dt: number, input: DriveInput, holdingCarrot: boolean): THREE.Vector3 | null {
    const m = this.riding; if (!m) return null;
    const r = RIDE[m.species] ?? { seat: 1.2, speed: 0, jump: 0 };
    const controllable = m.species === 'pig' || m.species === 'strider' ? holdingCarrot : m.tamed;
    const fwd = -(input.move.x * Math.sin(input.yaw) + input.move.z * Math.cos(input.yaw));
    const strafe = input.move.x * Math.cos(input.yaw) - input.move.z * Math.sin(input.yaw);
    let move = 0;
    if (controllable && (Math.abs(fwd) > 0.1 || Math.abs(strafe) > 0.1)) {
      m.dir = Math.atan2(-input.move.x, -input.move.z);
      move = r.speed * (input.run ? 1 : 0.7) * Math.min(1, Math.hypot(fwd, strafe));
    } else if (!controllable && m.species !== 'pig' && m.species !== 'strider') {
      if (m.timer <= 0) { m.timer = 1 + this.rnd() * 2; m.dir = this.rnd() * 6.28; }
      move = m.speed;
      m.special -= dt;
      if (m.special <= 0) {
        m.tameTries++;
        if (this.rnd() < 0.2 + m.tameTries * 0.15) { this.tame(m); }
        else {
          this.riding = null;
          this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 1.2, 0)), '#777777', 8, 1);
          this.host.toast('振り落とされた！', 'Bucked off!');
          return null;
        }
      }
    }
    if (input.ascend && r.jump > 0 && m.vy === 0 && controllable) { m.vy = 7 * r.jump * 0.7; }
    this.walk(m, move, dt, true);
    m.group.rotation.y = m.dir;
    const seatY = r.seat * m.group.scale.y;
    return new THREE.Vector3(m.group.position.x, m.group.position.y + seatY + 0.5 - 1.62 + 0.25, m.group.position.z);
  }

  // ------------------------------------------------------------------ villagers & raids

  tradeOffers(): Offer[] {
    const m = this.activeVillager ?? this.tradingMob;
    if (!m) return [];
    if (m.species === 'wandering_trader') return TRADER_OFFERS;
    const discount = this.heroTimer > 0 ? 0.7 : 1;
    if (m.villager) {
      m.villager.profession = m.profession === 'none' ? 'unemployed' : m.profession;
      m.villager.level = m.level;
      m.villager.xp = m.xp;
    }
    const list = TRADES[m.profession] ?? [];
    return list.filter(o => o.level <= m.level).map(o => {
      const demandAdd = m.villager?.demand?.[o.id] ?? 0;
      const baseCost = Math.max(1, o.n + demandAdd);
      const finalN = o.give === 'emerald' ? Math.max(1, Math.round(baseCost * discount)) : baseCost;
      return { ...o, n: finalN, cost: finalN };
    });
  }

  tradeTitle(): { ja: string; en: string } {
    const m = this.activeVillager ?? this.tradingMob;
    if (!m) return { ja: '取引', en: 'Trade' };
    if (m.species === 'wandering_trader') return { ja: '行商人', en: 'WANDERING TRADER' };
    return { ja: `${PROFESSION_JA[m.profession]} · ${LEVEL_JA[m.level]}`, en: `${m.profession.toUpperCase()} · ${LEVEL_NAMES[m.level].toUpperCase()}` };
  }

  recordTrade(offer: Offer) {
    const m = this.activeVillager ?? this.tradingMob;
    if (!m || m.species !== 'villager') return;
    m.xp += offer.xp;
    if (m.villager) {
      addTradeXp(m.villager, { ...offer, uses: m.villager.uses[offer.id] ?? 0, max: offer.maxUses, demand: 0 });
    }
    if (m.level < 5 && m.xp >= LEVEL_XP[m.level + 1]) {
      m.level++;
      if (m.villager) m.villager.level = m.level;
      this.host.particles.burst(m.group.position.clone().add(new THREE.Vector3(0, 1.8, 0)), '#8ad4ff', 14, 1.5);
      this.host.toast(`村人が${LEVEL_JA[m.level]}にレベルアップしました`, `Villager is now ${LEVEL_NAMES[m.level]}`);
    }
  }

  private tickJobs(m: Mob) {
    if (m.baby) return;
    if (m.profession !== 'none' && m.profession !== 'unemployed') return;
    const p = m.group.position, bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z);
    for (let i = 0; i < 40; i++) {
      const x = bx + Math.floor((this.rnd() - 0.5) * 16), y = by + Math.floor((this.rnd() - 0.5) * 6), z = bz + Math.floor((this.rnd() - 0.5) * 16);
      const name = BLOCKS[this.host.getBlock(x, y, z)]?.name;
      const job: Profession | undefined = name ? JOB_SITES[name] : undefined;
      if (!job) continue;
      if (this.mobs.some(o => o !== m && o.species === 'villager' && o.profession === job && o.group.position.distanceTo(new THREE.Vector3(x, y, z)) < 8)) continue;
      m.profession = job; m.level = 1; m.xp = 0;
      if (m.villager) { m.villager.profession = job; m.villager.job = { x, y, z }; m.villager.level = 1; m.villager.xp = 0; }
      this.host.particles.burst(p.clone().add(new THREE.Vector3(0, 1.8, 0)), '#8ad4ff', 10, 1);
      this.host.toast(`村人が${PROFESSION_JA[job]}になりました`, `A villager became a ${job}`);
      return;
    }
  }

  startRaid(center?: THREE.Vector3): boolean {
    if (this.raid) return false;
    let cVec = center;
    if (!cVec) {
      const village = this.mobs.find(m => m.species === 'villager' && m.group.position.distanceTo(this.host.position) < 40);
      if (!village) return false;
      cVec = village.group.position;
    }
    const d = this.host.difficulty?.();
    const total = !d ? 3 : d === 'easy' ? 3 : d === 'hard' ? 7 : 5;
    this.raid = {
      wave: 0,
      total,
      alive: 0,
      timer: 4,
      delay: 4,
      center: [cVec.x, cVec.y, cVec.z],
      members: [],
    };
    this.badOmen = false;
    this.host.toast('襲撃が始まった！', 'Raid incoming!');
    this.host.sound('thunder');
    return true;
  }

  private tickRaid(dt: number, peaceful: boolean) {
    const r = this.raid; if (!r) return;
    if (peaceful) { this.raid = null; return; }
    const activeRaiders = this.mobs.filter(m => m.raid || m.raidMember || r.members.includes(m.id));
    r.alive = activeRaiders.length;
    r.members = activeRaiders.map(m => m.id);
    if (r.alive > 0) { r.timer = 4; r.delay = 4; return; }
    r.timer -= dt;
    r.delay = r.timer;
    if (r.timer > 0) return;
    if (r.wave >= r.total) {
      this.raid = null;
      this.heroTimer = 600;
      this.host.effect?.('hero_of_the_village', 600, 0);
      this.host.addItem('emerald', 5);
      this.host.toast('襲撃を撃退した！ 村の英雄（取引割引）', 'Raid defeated! Hero of the Village');
      this.host.addXp?.(30);
      return;
    }
    r.wave++;
    r.timer = 4;
    r.delay = 4;
    r.members = [];
    const [cx, , cz] = r.center;
    if (!this.host.difficulty && r.total === 3) {
      const table: Species[] = r.wave === 1 ? ['pillager', 'pillager', 'vindicator'] : r.wave === 2 ? ['pillager', 'vindicator', 'vindicator', 'ravager'] : ['evoker', 'pillager', 'vindicator', 'ravager', 'witch'];
      table.forEach((sp, i) => {
        const a = i * 1.2 + r.wave, x = cx + Math.cos(a) * 18, z = cz + Math.sin(a) * 18;
        const m = this.spawn(sp, x, z, false, this.host.terrain.height(x, z) + 1);
        if (m) { m.raid = true; m.raidMember = true; m.state = 'chase'; if (i === 0 && sp === 'pillager') m.captain = true; r.members.push(m.id); }
      });
    } else {
      const wave = RAID_WAVES[Math.min(RAID_WAVES.length - 1, r.wave - 1)];
      const a0 = this.rnd() * 6.28;
      let i = 0;
      for (const [sp, n] of Object.entries(wave)) for (let k = 0; k < n; k++) {
        const a = a0 + (i++) * 0.35, dist = 22 + this.rnd() * 6;
        const rx = cx + Math.cos(a) * dist, rz = cz + Math.sin(a) * dist;
        const m = this.spawn(sp as Species, rx, rz, false, this.host.terrain.height(rx, rz) + 1);
        if (m) { m.raid = true; m.raidMember = true; m.state = 'chase'; if (i === 1 && sp === 'pillager') m.captain = true; r.members.push(m.id); }
      }
    }
    r.alive = r.members.length;
    this.host.toast(`襲撃 第${r.wave}/${r.total}波`, `Raid wave ${r.wave}/${r.total}`);
    this.host.sound('thunder');
  }

  noise(x: number, y: number, z: number, strength = 1) {
    this.host.onVibration?.(x, y, z, strength);
    for (const m of this.mobs) {
      if (m.species !== 'warden') continue;
      const d = m.group.position.distanceTo(new THREE.Vector3(x, y, z));
      if (d > 16) continue;
      m.anger = Math.min(150, m.anger + 35 * strength);
      m.lastNoise = new THREE.Vector3(x, y, z);
      m.timer = Math.min(m.timer, 0.3);
    }
  }

  vibrate(p: THREE.Vector3) {
    this.noise(p.x, p.y, p.z, 1);
  }

  summonWarden(x: number, y: number, z: number) {
    if (this.mobs.some(m => m.species === 'warden' && m.group.position.distanceTo(new THREE.Vector3(x, y, z)) < 48)) return;
    const a = this.rnd() * 6.28, m = this.spawn('warden', x + Math.cos(a) * 5, z + Math.sin(a) * 5, false, y);
    if (m) {
      m.anger = 60; m.special = 3;
      this.host.particles.burst(m.group.position.clone(), '#0f4a58', 40, 4);
      this.host.sound('thunder');
      this.host.toast('ウォーデンが現れた…', 'The Warden emerges…');
    }
  }

  lastHit: Mob | null = null;
  looting = 0;

  hurtNear(pos: THREE.Vector3, r: number, damage: number, exclude?: Mob | null) {
    let n = 0;
    for (const m of [...this.mobs]) { if (m === exclude || m.group.position.distanceTo(pos) > r) continue; this.damageMob(m, damage); n++; }
    return n;
  }

  extraDamage(m: Mob, damage: number) { if (damage > 0 && this.mobs.includes(m)) this.damageMob(m, damage); }

  nearestHostile(pos: THREE.Vector3, r: number): Mob | null {
    let best: Mob | null = null, bestD = r;
    for (const m of this.mobs) { if (passive.has(m.species)) continue; const d = m.group.position.distanceTo(pos); if (d < bestD) { bestD = d; best = m; } }
    return best;
  }

  shoot(m: Mob) {
    const from = m.group.position.clone().add(new THREE.Vector3(0, m.species === 'dragon' ? 1.8 : 1.4, 0));
    if (!this.clearSight(from, this.host.camera.position)) return;
    const kind = m.species === 'ghast' || m.species === 'wither' ? 'ghast_fireball'
      : m.species === 'blaze' ? 'blaze_fireball'
      : m.species === 'dragon' ? 'dragon_fireball'
      : m.species === 'shulker' ? 'shulker_bullet'
      : m.species === 'breeze' ? 'wind_charge'
      : 'mob_arrow';
    const effect: [string, number] | undefined = m.species === 'stray' ? ['slowness', 15] : m.species === 'bogged' ? ['poison', 5] : undefined;
    this.launchProjectile(
      kind,
      from,
      this.host.camera.position.clone().sub(from).normalize(),
      kind === 'mob_arrow' || kind === 'wind_charge' ? 14 : kind === 'dragon_fireball' ? 12 : 9,
      undefined,
      { effect },
    );
    this.host.sound('bow', m.group.position);
  }

  shootPlayerArrow(origin: THREE.Vector3, dir: THREE.Vector3, speed = 26, damage = 7, extra: { flame?: boolean; punch?: number } = {}) {
    this.launchProjectile('player_arrow', origin.clone().addScaledVector(dir, 0.7), dir, speed, undefined, { damage, gravity: 6, ...extra });
    this.host.sound('bow');
  }

  update(dt: number, daylight: number, peaceful: boolean) {
    const now = performance.now();
    this.timeline += dt;
    this.updateCrystals(dt);
    this.updateProjectiles(dt);
    this.jobTimer += dt;
    if (this.jobTimer > 4) {
      this.jobTimer = 0;
      const occupied = new Set<string>();
      for (const m of this.mobs) {
        if (m.villager) {
          updateJob(m.villager, this.host, m.group.position, occupied);
          if (m.villager.profession !== 'unemployed' && m.villager.profession !== 'none') m.profession = m.villager.profession;
        }
      }
    }

    this.spawnTimer += dt;
    if (this.spawnTimer > 8 && this.mobs.length < 24) {
      this.spawnTimer = 0;
      const a = this.rnd() * 6.28, r = 18 + this.rnd() * 15;
      const x = this.host.position.x + Math.cos(a) * r, z = this.host.position.z + Math.sin(a) * r;
      const biome = this.host.terrain.biome(x, z);
      if (this.host.dimension === 'overworld') {
        if (biome !== 'mushroom_fields' && !peaceful && daylight < 0.25) {
          const h = this.host.terrain.height(x, z);
          let list: Species[] = ['zombie', 'skeleton', 'creeper', 'spider', 'enderman', 'zombie_villager', 'breeze'];
          if (biome.includes('desert')) list = ['husk', 'husk', 'skeleton', 'creeper', 'spider'];
          else if (biome.includes('snow') || biome.includes('frozen') || biome.includes('ice')) list = ['stray', 'stray', 'zombie', 'creeper', 'spider'];
          else if (biome.includes('swamp')) list = ['bogged', 'slime', 'witch', 'zombie', 'creeper'];
          if (h < SEA_LEVEL - 1) list = ['drowned', 'drowned', 'squid', 'glow_squid', 'salmon', 'tropical_fish', 'pufferfish'];
          if (biome.includes('ocean') && h < SEA_LEVEL - 12 && this.rnd() < 0.2) list = ['guardian'];
          if ((this.host.insomnia?.() ?? 0) > 180 && this.rnd() < 0.3) this.spawn('phantom', x, z, false, this.host.position.y + 18 + this.rnd() * 6);
          else {
            const sp = list[Math.floor(this.rnd() * list.length)];
            if (swimmers.has(sp) || sp === 'drowned') this.spawn(sp, x, z, false, h + 1 < SEA_LEVEL ? h + 1 : undefined);
            else this.spawn(sp, x, z);
          }
        } else if (biome !== 'mushroom_fields' && !peaceful && daylight >= 0.25 && this.rnd() < 0.05 && !this.raid) {
          for (let i = 0; i < 4; i++) { const m = this.spawn(i === 3 ? 'vindicator' : 'pillager', x + i, z + (i % 2)); if (m && i === 0) m.captain = true; }
        } else if (daylight >= 0.4 && this.mobs.filter(m => passive.has(m.species)).length < 14) {
          const table: Record<string, Species[]> = {
            jungle: ['parrot', 'panda', 'ocelot', 'chicken'],
            snowy: ['polar_bear', 'rabbit', 'fox', 'snow_golem'],
            frozen: ['polar_bear', 'snow_golem'],
            savanna: ['llama', 'donkey', 'armadillo', 'horse', 'cow'],
            desert: ['camel', 'rabbit'],
            swamp: ['frog', 'tadpole', 'slime'],
            mushroom_fields: ['mooshroom'],
            peaks: ['goat'],
            slopes: ['goat'],
            meadow: ['sheep', 'donkey', 'mule', 'rabbit'],
            plains: ['horse', 'donkey', 'mule', 'cow', 'sheep', 'pig'],
            taiga: ['fox', 'wolf', 'rabbit'],
            forest: ['cow', 'pig', 'sheep', 'chicken', 'wolf'],
          };
          const k = Object.keys(table).find(k => biome.includes(k)) ?? 'forest';
          const list = table[k];
          if (this.rnd() < 0.02) this.spawn('wandering_trader', x, z);
          else this.spawn(list[Math.floor(this.rnd() * list.length)], x, z);
        }
      } else if (this.host.dimension === 'nether' && !peaceful) {
        const table: Record<string, Species[]> = {
          nether_wastes: ['ghast', 'magma_cube', 'enderman', 'zombified_piglin', 'zombified_piglin', 'piglin', 'strider'],
          soul_sand_valley: ['skeleton', 'wither_skeleton', 'ghast', 'enderman', 'strider'],
          crimson_forest: ['piglin', 'piglin', 'hoglin', 'hoglin', 'zombified_piglin', 'piglin_brute'],
          warped_forest: ['enderman', 'strider'],
          basalt_deltas: ['ghast', 'magma_cube', 'strider'],
        };
        const list = table[biome] ?? ['magma_cube'];
        this.spawn(list[Math.floor(this.rnd() * list.length)], x, z);
      }
    }

    const currentDay = Math.floor((this.timeline + (this.host.time ?? 0) * 1200) / 240);
    for (let idx = this.mobs.length - 1; idx >= 0; idx--) {
      const m = this.mobs[idx];
      const hostile = !passive.has(m.species) && m.species !== 'iron_golem';
      if (hostile && this.host.dimension === 'overworld' && this.host.terrain.biome(m.group.position.x, m.group.position.z) === 'mushroom_fields') {
        this.scene.remove(m.group);
        this.mobs.splice(idx, 1);
        continue;
      }
      if (peaceful && hostile) {
        this.scene.remove(m.group);
        this.mobs.splice(idx, 1);
        continue;
      }

      if (m.hurtTimer > 0) {
        m.hurtTimer -= dt;
        if (m.hurtTimer <= 0) this.setHurtTint(m, false);
      }

      m.timer -= dt;
      m.attack -= dt;
      m.love = Math.max(0, m.love - dt);
      m.breedCooldown = Math.max(0, m.breedCooldown - dt);
      if (m.rolledUp && m.rolledUp > 0) m.rolledUp = Math.max(0, m.rolledUp - dt);

      const baseScale = NEW_SPECIES[m.species]?.scale ?? (m.species === 'enderman' ? 1.45 : m.species === 'iron_golem' ? 1.3 : 1);
      if (m.baby) {
        if (m.age !== undefined && m.age < 0) {
          m.age = Math.min(0, m.age + dt);
          m.grow = Math.max(0, -m.age);
          if (m.age >= 0) {
            m.baby = false;
            m.grow = 0;
            m.group.scale.setScalar(baseScale);
          }
        } else {
          m.grow -= dt;
          const sc = 0.5 + 0.5 * (1 - Math.max(0, m.grow) / 120);
          m.group.scale.setScalar(sc * baseScale);
          if (m.grow <= 0) {
            m.baby = false;
            m.group.scale.setScalar(baseScale);
          }
        }
      } else if (m.species === 'tadpole' && m.grow > 0) {
        m.grow -= dt;
        if (m.grow <= 0) this.replaceSpecies(m, 'frog');
      }

      if (m.zombify > 0 && this.host.dimension !== 'nether') {
        m.zombify -= dt;
        if (m.zombify <= 0) this.replaceSpecies(m, m.species === 'hoglin' ? 'zoglin' : 'zombified_piglin');
      }
      if (m.species === 'villager') {
        m.special -= dt;
        if (m.special <= 0) { m.special = 6 + this.rnd() * 4; this.tickJobs(m); }
        if (m.villager && daylight > 0.3) {
          restockVillager(m.villager, currentDay);
          tickVillager(m.villager, dt);
        }
      }
      if (m === this.riding) continue;

      const tx = this.host.position.x - m.group.position.x;
      const ty = this.host.position.y - m.group.position.y;
      const tz = this.host.position.z - m.group.position.z;
      const dist = Math.hypot(tx, ty, tz);

      // Undead burn in sunlight (unless in water)
      const burns = m.species === 'zombie' || m.species === 'skeleton' || NEW_SPECIES[m.species]?.burnsInSun;
      if (this.host.dimension === 'overworld' && daylight > 0.58 && burns && this.host.getBlock(m.group.position.x, m.group.position.y, m.group.position.z) !== ID.water) {
        if (m.attack <= 0 && m.hurtTimer <= 0) {
          this._tmpB.copy(m.group.position); this._tmpB.y += 1.4;
          this.host.particles.spark?.(this._tmpB, '#ff9436', 4);
          m.hp -= 2;
          m.hurtTimer = 0.2;
          this.setHurtTint(m, true);
          m.attack = 1.6;
          if (m.hp <= 0) { this.kill(m); continue; }
        }
      }

      let move = 0;

      if (m.species === 'dragon') {
        m.phaseTimer -= dt;
        if (m.phaseTimer <= 0) {
          if (m.state === 'circle') { m.state = 'charge'; m.phaseTimer = 3.5; }
          else if (m.state === 'charge') { m.state = 'perch'; m.phaseTimer = 6; }
          else { m.state = 'circle'; m.phaseTimer = 9 + this.rnd() * 5; }
        }
        const center = m.state === 'perch';
        const targetX = center ? 0 : Math.cos(now * 0.0004 + m.id) * 18;
        const targetZ = center ? 0 : Math.sin(now * 0.0004 + m.id) * 18;
        const targetY = center ? 31 : m.state === 'charge' ? this.host.position.y + 4 : 36 + Math.sin(now * 0.001) * 3;
        const tx2 = m.state === 'charge' ? this.host.position.x : targetX;
        const tz2 = m.state === 'charge' ? this.host.position.z : targetZ;
        const vx = tx2 - m.group.position.x, vz = tz2 - m.group.position.z;
        m.dir = Math.atan2(-vx, -vz);
        const speed = m.state === 'charge' ? 1.9 : m.state === 'perch' ? 1.4 : 0.75;
        m.group.position.x += vx * dt * speed;
        m.group.position.z += vz * dt * speed;
        m.group.position.y += (targetY - m.group.position.y) * Math.min(1, dt * (m.state === 'charge' ? 2.5 : 1.2));
        m.group.rotation.y = m.dir;
        if (!peaceful && m.attack <= 0 && dist < 26 && m.state !== 'perch') { this.shoot(m); m.attack = m.state === 'charge' ? 2.2 : 4; }
        if (!peaceful && m.state === 'perch' && dist < 4.5 && m.attack <= 0) { this.host.damage(6); m.attack = 1.5; }
        if (this.crystals.length && m.hp < m.maxHp) m.hp = Math.min(m.maxHp, m.hp + dt * 1.5);
        continue;
      }

      if (m.species === 'shulker') {
        m.group.position.y += Math.sin(this.timeline * 1.6 + m.id) * dt * 0.15;
        m.dir = Math.atan2(-tx, -tz);
        m.group.rotation.y = m.dir;
        const open = Math.sin(this.timeline * 1.1 + m.id) > 0.2;
        m.group.scale.y = open ? 1 : 0.75;
        if (!peaceful && open && dist < 18 && m.attack <= 0) { this.shoot(m); m.attack = 2.6; }
        continue;
      }

      if (swimmers.has(m.species) || m.species === 'turtle') {
        m.dir += Math.sin(m.timer) * dt * 0.4;
        move = m.speed * 0.85;
        if (m.species === 'pufferfish') {
          const nearPlayer = !peaceful && dist < 3.5;
          m.group.scale.setScalar(baseScale * (nearPlayer ? 1.65 : 1));
          if (nearPlayer && m.attack <= 0) {
            this.host.damage(1);
            this.host.effect?.('poison', 7, 0);
            m.attack = 1.5;
          }
        }
      } else if (m.species === 'bee' || m.species === 'blaze' || m.species === 'ghast' || m.species === 'wither' || m.species === 'bat') {
        m.dir += Math.sin(m.timer * 1.4) * dt * 0.6;
        move = 1.1;
        const baseY = this.host.terrain.height(m.group.position.x, m.group.position.z) + (m.species === 'wither' ? 3.5 : 2.3);
        m.group.position.y += (baseY + Math.sin(now * 0.004 + m.id) * 0.35 - m.group.position.y) * Math.min(1, dt * 4);
        if (!peaceful && (m.species === 'blaze' || m.species === 'ghast' || m.species === 'wither') && dist < (m.species === 'ghast' || m.species === 'wither' ? 26 : 18)) {
          m.dir = Math.atan2(-tx, -tz);
          if (m.attack <= 0) { this.shoot(m); m.attack = m.species === 'ghast' ? 3.2 : 2.2; }
        }
      } else if (m.species === 'creeper' && dist < 12 && !peaceful) {
        m.state = dist < 2.8 ? 'fuse' : 'chase';
        if (m.state === 'fuse') {
          if (m.fuse === 0) this.host.sound('fuse', m.group.position);
          m.fuse += dt;
          const s = 1 + m.fuse * 0.2 + Math.sin(m.fuse * 26) * 0.05;
          m.group.scale.set(s, s, s);
          if (m.fuse > 1.5) {
            this.host.explode(m.group.position.clone(), 3);
            this.scene.remove(m.group);
            this.mobs.splice(idx, 1);
            continue;
          }
        } else {
          m.fuse = Math.max(0, m.fuse - dt);
          m.group.scale.set(1, 1, 1);
          m.dir = Math.atan2(-tx, -tz);
          move = 1.6;
        }
      } else if (m.species === 'skeleton' && dist < 16 && !peaceful) {
        m.state = 'aim';
        m.dir = Math.atan2(-tx, -tz);
        move = dist < 6 ? -1 : dist > 10 ? 1 : 0;
        if (m.attack <= 0) { this.shoot(m); m.attack = 2.2; }
      } else if ((m.species === 'zombie' || m.species === 'zombie_villager' || m.species === 'spider') && dist < 16 && !peaceful) {
        m.state = 'chase';
        m.dir = Math.atan2(-tx, -tz);
        move = m.species === 'spider' ? 2.4 : 1.65;
        if (dist < 1.6 && m.attack <= 0) { this.host.damage(3); m.attack = 1.0; }
      } else if (m.species === 'enderman') {
        this.host.camera.getWorldDirection(this._look);
        if (dist > 0 && (tx * this._look.x + ty * this._look.y + tz * this._look.z) / dist > 0.985 && dist < 22) m.state = 'teleport';
        if (m.state === 'teleport' && m.timer <= 0) {
          const a = this.rnd() * 6.28;
          m.group.position.x = this.host.position.x + Math.cos(a) * 6;
          m.group.position.z = this.host.position.z + Math.sin(a) * 6;
          m.timer = 3;
          this.host.particles.burst(m.group.position, '#a780cf', 18);
          m.state = 'chase';
        }
        if (m.state === 'chase') {
          m.dir = Math.atan2(-tx, -tz); move = 2.5;
          if (dist < 1.6 && m.attack <= 0) { this.host.damage(5); m.attack = 1; }
        }
      } else if (m.species === 'iron_golem') {
        const enemy = this.mobs.find(x => x !== m && !passive.has(x.species) && x.species !== 'iron_golem' && x.group.position.distanceTo(m.group.position) < 10);
        if (enemy) {
          const vx = enemy.group.position.x - m.group.position.x, vz = enemy.group.position.z - m.group.position.z;
          m.dir = Math.atan2(-vx, -vz); move = 1.5; m.state = 'chase';
          if (Math.hypot(vx, vz) < 2 && m.attack <= 0) { enemy.hp -= 15; m.attack = 1; if (enemy.hp <= 0) this.kill(enemy); }
        }
      }

      const special = this.specialAI(m, dt, dist, tx, ty, tz, peaceful, daylight);
      if (special !== null) move = special;

      // Tamed wolves defend their owner by attacking lastHit or nearby hostiles
      if (m.species === 'wolf' && m.tamed && !m.sitting) {
        const foe = (this.lastHit && this.lastHit !== m && this.mobs.includes(this.lastHit) && !this.lastHit.tamed && this.lastHit.group.position.distanceTo(m.group.position) < 16)
          ? this.lastHit
          : null;
        if (foe) {
          const fp = foe.group.position, d = fp.distanceTo(m.group.position);
          m.state = 'chase';
          m.dir = Math.atan2(-(fp.x - m.group.position.x), -(fp.z - m.group.position.z));
          move = m.speed * 2.1;
          if (d < 1.7 && m.attack <= 0) { m.attack = 1.0; this.damageMob(foe, 4); }
        }
      }

      // Snow Golem throws snowballs at hostile mobs
      if (m.species === 'snow_golem') {
        const foe = this.mobs.find(x => x !== m && !passive.has(x.species) && x.group.position.distanceTo(m.group.position) < 12);
        if (foe) {
          const fp = foe.group.position;
          m.dir = Math.atan2(-(fp.x - m.group.position.x), -(fp.z - m.group.position.z));
          if (m.attack <= 0) {
            m.attack = 1.5;
            const from = m.group.position.clone().add(new THREE.Vector3(0, 1.4, 0));
            this.launchProjectile('snowball', from, fp.clone().add(new THREE.Vector3(0, 0.9, 0)).sub(from).normalize(), 14);
            this.host.sound('bow', m.group.position);
          }
        }
      }

      if (m.state === 'wander' || m.state === 'graze' || m.state === 'follow') {
        const pet = m.species === 'wolf' || m.species === 'cat' || m.species === 'parrot' || m.species === 'ocelot' || m.species === 'allay';
        const anchor = m.leashPos ? new THREE.Vector3(m.leashPos[0] + 0.5, m.leashPos[1], m.leashPos[2] + 0.5) : this.host.position;
        const anchorDist = m.group.position.distanceTo(anchor);
        if (m.sitting) {
          m.state = 'graze';
          move = 0;
        } else if (m.tamed && pet && !m.leashed) {
          m.state = 'follow';
          if (dist > 14) {
            m.group.position.set(this.host.position.x + 1.5, this.host.position.y, this.host.position.z + 1.5);
            m.path = null;
          }
        } else if (m.leashed && anchorDist > 5) {
          m.state = 'follow';
        } else if (m.timer <= 0 || (m.state === 'follow' && m.love <= 0 && !m.tamed && !m.leashed)) {
          m.timer = 2 + this.rnd() * 5;
          m.dir = this.rnd() * 6.28;
          m.state = this.rnd() < 0.35 ? 'graze' : 'wander';
        }
        if (!m.sitting) {
          move = m.state === 'graze' ? 0 : m.speed;
          if (m.state === 'follow') {
            const dx = anchor.x - m.group.position.x, dz = anchor.z - m.group.position.z;
            if (anchorDist > 3) {
              m.dir = Math.atan2(-dx, -dz);
              move = m.speed * (m.leashed ? 1.8 : 1.4);
            } else {
              move = 0;
            }
          }
        }
        if (m.leashed && anchorDist > 12) {
          if (m.leashPos) {
            m.leashed = false; m.leashPos = null;
            this.host.particles.drop(m.group.position.clone(), 'lead', 1, '#a8875a');
          } else {
            m.group.position.x = this.host.position.x + tx * -0.4;
            m.group.position.z = this.host.position.z + tz * -0.4;
            m.path = null;
          }
        }
      }
      if (m.state === 'flee') { move = m.speed * 2.4; if (m.timer <= 0) m.state = 'wander'; }
      if (m.rolledUp && m.rolledUp > 0) move = 0;

      // Animals in love walk towards a nearby mate and breed when close
      if (m.love > 0 && !m.baby) {
        const mate = this.mobs.find(x => x !== m && x.species === m.species && x.love > 0 && !x.baby && x.group.position.distanceTo(m.group.position) < 12);
        if (mate) {
          const md = mate.group.position.distanceTo(m.group.position);
          if (md < 3) {
            m.love = 0; mate.love = 0; m.breedCooldown = 300; mate.breedCooldown = 300; m.state = 'wander'; mate.state = 'wander';
            const child = this.spawn(m.species, m.group.position.x + 1, m.group.position.z, true, m.group.position.y);
            if (child && m.species === 'villager') child.profession = 'none';
            this.host.addXp?.(1 + Math.floor(this.rnd() * 7));
            this._tmpB.copy(m.group.position); this._tmpB.y += 1;
            this.host.particles.burst(this._tmpB, '#e47b83', 12, 1);
          } else {
            m.state = 'follow';
            m.dir = Math.atan2(-(mate.group.position.x - m.group.position.x), -(mate.group.position.z - m.group.position.z));
            move = m.speed * 1.25;
          }
        }
      }

      if (move > 0 && (m.state === 'chase' || m.state === 'follow') && !flyers.has(m.species) && !swimmers.has(m.species)) {
        const goal = m.species === 'warden' && m.anger < 80 && m.lastNoise ? m.lastNoise : this.host.position;
        this.steer(m, goal);
      }
      this.walk(m, move, dt, false);

      m.group.rotation.y = m.dir;

      if (m.species === 'chicken') {
        m.egg -= dt;
        if (m.egg <= 0) { m.egg = 30; this.host.particles.drop(m.group.position.clone(), 'egg', 1, '#e6dfcb'); }
      }
      if (m.species === 'sheep' && !m.wool && m.timer > 10) {
        m.wool = true;
        if (m.woolCoat) m.woolCoat.visible = true;
      }
      if (dist > 95 && !m.tamed && !m.leashed && !m.raid && !m.raidMember) {
        this.scene.remove(m.group);
        this.mobs.splice(idx, 1);
      }
    }

    this.animateMobs(dt, now);
    this.heroTimer = Math.max(0, this.heroTimer - dt);
    this.tickRaid(dt, peaceful);
    if (this.badOmen && !this.raid && this.mobs.some(m => m.species === 'villager' && m.group.position.distanceTo(this.host.position) < 24)) {
      this.startRaid(this.host.position);
    }
    this.playerSpeed = dt > 0 ? this.host.position.distanceTo(this.lastPlayerPos) / dt : 0;
    this.lastPlayerPos.copy(this.host.position);

    const pts: THREE.Vector3[] = [];
    for (const m of this.mobs) {
      if (m.leashed) {
        const start = m.leashPos
          ? new THREE.Vector3(m.leashPos[0] + 0.5, m.leashPos[1] + 0.5, m.leashPos[2] + 0.5)
          : this.host.camera.position.clone().add(new THREE.Vector3(0, -0.4, 0));
        pts.push(start, m.group.position.clone().add(new THREE.Vector3(0, 0.8 * m.group.scale.y, 0)));
      }
    }
    if (pts.length) {
      if (!this.leashLine) {
        this.leashLine = new THREE.LineSegments(this.leashGeo, new THREE.LineBasicMaterial({ color: '#8a6b3f' }));
        this.scene.add(this.leashLine);
      }
      this.leashGeo.setFromPoints(pts);
      this.leashGeo.computeBoundingSphere();
    } else if (this.leashLine) {
      this.scene.remove(this.leashLine);
      this.leashLine = null;
    }

    for (let i = this.arrows.length - 1; i >= 0; i--) {
      const a = this.arrows[i];
      a.life -= dt;
      a.v.y -= 8.5 * dt;
      a.mesh.position.addScaledVector(a.v, dt);
      this._tmpA.copy(a.mesh.position).add(a.v);
      a.mesh.lookAt(this._tmpA);

      if (!a.fromPlayer) {
        if (a.mesh.position.distanceTo(this.host.camera.position) < 0.85) {
          this.host.damage(a.damage);
          a.life = 0;
        }
      } else {
        for (const m of this.mobs) {
          this._tmpB.copy(m.group.position);
          this._tmpB.y += m.species === 'dragon' ? 1.5 : 0.9;
          if (a.mesh.position.distanceTo(this._tmpB) < (m.species === 'dragon' ? 2.2 : 1.05)) {
            this.damageMob(m, a.damage, this._tmpA.copy(a.v).normalize(), true);
            a.life = 0;
            break;
          }
        }
      }

      if (a.life <= 0 || this.host.getBlock(a.mesh.position.x, a.mesh.position.y, a.mesh.position.z) > 0) {
        this.scene.remove(a.mesh);
        this.arrows.splice(i, 1);
      }
    }
  }

  private getBlockFor(m: Mob) {
    const strider = m.species === 'strider';
    return (x: number, y: number, z: number) => {
      const id = this.host.getBlock(x, y, z);
      return strider && id === ID.lava ? ID.stone : id;
    };
  }

  private steer(m: Mob, goal: THREE.Vector3) {
    const p = m.group.position, get = this.getBlockFor(m);
    if (!m.path || this.timeline - m.pathAt > 0.8) {
      m.pathAt = this.timeline;
      const ax = p.x - Math.sin(m.dir) * 1.1, az = p.z - Math.cos(m.dir) * 1.1;
      const gy = groundAt(get, Math.floor(ax), Math.floor(p.y + 0.01), Math.floor(az), 3);
      const blocked = Number.isNaN(gy) || gy - p.y > 1.2 || Math.abs(goal.y - p.y) > 1.5;
      m.path = blocked && p.distanceTo(goal) < 40 ? findPath(get, p.x, p.y, p.z, goal.x, goal.y, goal.z, 550) : null;
    }
    if (m.path && m.path.length) {
      const wp = m.path[0], dx = wp.x - p.x, dz = wp.z - p.z, hd = Math.hypot(dx, dz);
      if (hd < 0.35 && Math.abs(wp.y - p.y) < 1.2) m.path.shift();
      else {
        m.dir = Math.atan2(-dx, -dz);
        if (wp.y > p.y + 0.6 && m.vy === 0 && hd < 0.9) m.vy = 7;
      }
    }
  }

  /** 3D aquatic swimming in real water columns, preventing fish from clipping underground. */
  private swim(m: Mob, move: number, dt: number) {
    const p = m.group.position, isWater = (x: number, y: number, z: number) => this.host.getBlock(x, y, z) === ID.water;
    const nx = p.x - Math.sin(m.dir) * move * dt, nz = p.z - Math.cos(m.dir) * move * dt;
    if (!isWater(p.x, p.y, p.z) && !isWater(p.x, p.y - 0.6, p.z)) {
      if (this.host.getBlock(nx, p.y, nz) <= 0) { p.x = nx; p.z = nz; }
      if (this.host.dimension === 'overworld' && p.y > SEA_LEVEL - 1 && this.host.terrain.height(p.x, p.z) < SEA_LEVEL - 1) {
        p.y = Math.max(SEA_LEVEL - 1.5, p.y - 3 * dt);
      }
      return;
    }
    let ny = p.y + Math.sin(m.timer * 0.9 + m.id * 1.7) * 0.5 * dt;
    if (!isWater(p.x, ny + 0.5, p.z)) ny = p.y - 0.8 * dt;
    if (!isWater(p.x, ny - 0.3, p.z) && isWater(p.x, ny + 0.3, p.z)) ny = p.y + 0.6 * dt;
    if (isWater(nx, ny, nz)) {
      p.x = nx; p.z = nz; p.y = ny;
    } else {
      m.dir += Math.PI * (0.5 + this.rnd() * 0.5);
    }
  }

  private walk(m: Mob, move: number, dt: number, ridden: boolean) {
    const p = m.group.position, sp = m.species;
    if (flyers.has(sp)) {
      if (move) {
        const nx = p.x - Math.sin(m.dir) * move * dt, nz = p.z - Math.cos(m.dir) * move * dt;
        if (this.host.getBlock(nx, p.y + 0.3, nz) <= 0) { p.x = nx; p.z = nz; } else m.dir += Math.PI * 0.5;
      }
      return;
    }
    if (swimmers.has(sp)) {
      if (move) this.swim(m, move, dt);
      return;
    }
    const get = this.getBlockFor(m);
    if (m.vy !== 0) { p.y += m.vy * dt; m.vy -= 24 * dt; }
    const nx = move ? p.x - Math.sin(m.dir) * move * dt : p.x, nz = move ? p.z - Math.cos(m.dir) * move * dt : p.z;
    const gy = groundAt(get, Math.floor(nx), Math.floor(p.y + 0.01), Math.floor(nz), 4);
    if (Number.isNaN(gy)) {
      if (move) { m.dir += Math.PI * 0.5 + (this.rnd() - 0.5); m.path = null; }
      if (m.vy === 0 && groundAt(get, Math.floor(p.x), Math.floor(p.y + 0.01), Math.floor(p.z), 4) !== p.y) m.vy = -0.01;
      return;
    }
    const climb = gy - p.y;
    if (climb > 1.15 && m.vy <= 0) {
      if (climb <= 2.2 && (ridden || m.state === 'chase' || m.state === 'follow') && m.vy === 0) m.vy = 7.2;
      else if (move) { m.dir += Math.PI * 0.5 + (this.rnd() - 0.5); m.path = null; }
      return;
    }
    if (climb < -3.2 && !ridden) {
      if (move) { m.dir += Math.PI * 0.5 + (this.rnd() - 0.5); m.path = null; }
      return;
    }
    const water = get(Math.floor(nx), Math.floor(gy), Math.floor(nz)) === ID.water || get(Math.floor(nx), Math.floor(gy) - 1, Math.floor(nz)) === ID.water;
    if (water && !ridden && sp !== 'drowned' && sp !== 'frog' && sp !== 'polar_bear' && sp !== 'turtle' && m.state !== 'follow' && m.state !== 'chase') {
      m.dir += Math.PI * 0.5; m.path = null;
      return;
    }
    p.x = nx; p.z = nz;
    if (m.vy > 0) return;
    if (m.vy < 0) { if (p.y <= gy) { p.y = gy; m.vy = 0; } return; }
    if (p.y > gy + 0.6) { m.vy = -0.01; return; }
    p.y += (gy - p.y) * Math.min(1, dt * 10);
  }

  private specialAI(m: Mob, dt: number, dist: number, tx: number, ty: number, tz: number, peaceful: boolean, daylight: number): number | null {
    const sp = m.species, p = m.group.position, host = this.host;
    void ty;
    const face = () => { m.dir = Math.atan2(-tx, -tz); };
    const melee = (range: number, dmg: number, speed: number, cd = 1.1, onHit?: () => void) => {
      if (peaceful || dist > range) { if (m.state === 'chase') m.state = 'wander'; return null; }
      m.state = 'chase'; face();
      if (dist < 1.9 * Math.max(1, m.group.scale.x) && m.attack <= 0) { host.damage(dmg); m.attack = cd; onHit?.(); }
      return speed;
    };
    const ranged = (range: number, cd: number) => {
      if (peaceful || dist > range) { if (m.state === 'aim') m.state = 'wander'; return null; }
      m.state = 'aim'; face();
      if (m.attack <= 0) { this.shoot(m); m.attack = cd; }
      return dist < 6 ? -1 : dist > 10 ? 1 : 0;
    };
    m.anger = Math.max(0, m.anger - dt);
    switch (sp) {
      case 'husk': return melee(16, 3, 1.5, 1.1, () => host.effect?.('hunger', 7));
      case 'drowned': return melee(16, 3, host.getBlock(p.x, p.y, p.z) === ID.water ? 2.4 : 1.4);
      case 'wither_skeleton': return melee(18, 8, 1.7, 1.0, () => host.effect?.('wither', 8));
      case 'vindicator': return melee(18, 7, 1.9);
      case 'piglin_brute': return melee(18, 10, 1.5, 1.3);
      case 'piglin': {
        if (m.barter > 0) {
          m.barter -= dt; face();
          if (m.barter <= 0) {
            const total = BARTER.reduce((a, b) => a + b[1], 0);
            let r = this.rnd() * total;
            let pick = BARTER[0][0];
            for (const [n, w] of BARTER) { r -= w; if (r <= 0) { pick = n; break; } }
            host.particles.drop(p.clone().add(new THREE.Vector3(0, 1, 0)), pick, 1, resolve(pick)?.color ?? '#c9b98a');
          }
          return 0;
        }
        if ((host.wearingGold?.() || host.goldArmor?.()) && m.anger <= 0) return null;
        return melee(16, 5, 1.6);
      }
      case 'zombified_piglin': return m.anger > 0 ? melee(24, 8, 1.7) : null;
      case 'hoglin': case 'zoglin': return melee(14, 6, 1.8, 1.2, () => { host.levitate(0.15); });
      case 'ravager': return melee(22, 12, 2.0, 1.6);
      case 'silverfish': return melee(10, 1, 2.4, 0.7);
      case 'endermite': return melee(10, 2, 2.0, 0.8);
      case 'cave_spider': return melee(14, 2, 2.6, 1.0, () => host.effect?.('poison', 7));
      case 'slime': case 'magma_cube': {
        if (peaceful || dist > 14) return null;
        m.special -= dt;
        if (m.special < -0.5) m.special = 0.9 + this.rnd() * 0.5;
        const hop = m.special < 0;
        const base = NEW_SPECIES[sp]?.scale ?? (m.baby ? 0.5 : 1);
        m.group.scale.y = base * (hop ? 1.15 : 0.85);
        const s = melee(14, sp === 'slime' ? 2 : 3, 2.1, 1.2);
        return hop ? s : 0;
      }
      case 'breeze': {
        if (peaceful || dist > 18) return null;
        m.state = 'aim'; face();
        const baseY = host.terrain.height(p.x, p.z) + 2.0 + Math.abs(Math.sin(this.timeline * 2.5 + m.id)) * 1.8;
        p.y += (baseY - p.y) * Math.min(1, dt * 4);
        if (m.attack <= 0) { this.shoot(m); m.attack = 2.0; }
        return dist < 5 ? -2.0 : dist > 10 ? 2.2 : 0.8;
      }
      case 'polar_bear': case 'panda': return m.anger > 0 ? melee(20, 6, 1.6) : null;
      case 'goat': {
        if (m.anger > 0) return melee(16, 2, 3.0, 2.5, () => { m.anger = 0; });
        if (dist < 9 && m.attack <= 0 && this.rnd() < dt * 0.03) { m.anger = 4; }
        return null;
      }
      case 'llama': {
        if (m.anger > 0 && dist < 12 && m.attack <= 0) {
          face();
          this.launchProjectile('snowball', p.clone().add(new THREE.Vector3(0, 1.4, 0)), host.camera.position.clone().sub(p).normalize(), 12, undefined, { color: '#9fbf5a' });
          m.attack = 2;
        }
        return null;
      }
      case 'stray': case 'bogged': case 'pillager': return ranged(18, sp === 'pillager' ? 3 : 2.2);
      case 'witch': {
        if (peaceful || dist > 12) return null;
        m.state = 'aim'; face();
        if (m.attack <= 0) {
          m.attack = 3.2;
          const from = p.clone().add(new THREE.Vector3(0, 1.5, 0));
          this.launchProjectile('potion', from, host.camera.position.clone().sub(from).normalize(), 11, undefined, {
            color: '#8a4a9a',
            gravity: 6,
            onEnd: (at) => {
              if (at.distanceTo(host.position) < 3) {
                host.damage(2);
                host.effect?.(this.rnd() < 0.5 ? 'poison' : 'slowness', 6);
              }
            },
          });
        }
        return dist < 5 ? -1 : 0.6;
      }
      case 'evoker': {
        if (peaceful || dist > 16) return null;
        m.state = 'aim'; face();
        m.special -= dt;
        if (m.special <= 0) {
          m.special = 11;
          for (let i = 0; i < 3; i++) {
            const v = this.spawn('vex', p.x + (this.rnd() - 0.5) * 2, p.z + (this.rnd() - 0.5) * 2, false, p.y + 1.5);
            if (v) { v.raid = m.raid; v.raidMember = m.raidMember; v.fuse = 0; }
          }
          host.particles.burst(p.clone().add(new THREE.Vector3(0, 1.5, 0)), '#cfd4ff', 16, 2);
        } else if (dist < 6 && m.attack <= 0) {
          m.attack = 4; host.damage(6);
          host.particles.burst(host.position.clone(), '#5a4a3a', 12, 1.5);
        }
        return dist < 6 ? -1.2 : dist > 10 ? 1 : 0;
      }
      case 'vex': {
        m.fuse += dt; if (m.fuse > 45) { m.hp = 0; this.kill(m); return 0; }
        if (peaceful) return null;
        p.y += ((host.position.y + 1.2) - p.y) * Math.min(1, dt * 3);
        return melee(30, 5, 3.2, 1.0) ?? 1;
      }
      case 'phantom': {
        if (daylight > 0.6 && this.rnd() < dt * 0.5) { this.setHurtTint(m, true); m.hurtTimer = 0.2; }
        m.special -= dt;
        if (m.special <= -2.5) m.special = 6;
        if (m.special > 0) {
          const a = this.timeline * 0.9 + m.id;
          const gx = host.position.x + Math.cos(a) * 10, gz = host.position.z + Math.sin(a) * 10, gy = host.position.y + 14;
          m.dir = Math.atan2(-(gx - p.x), -(gz - p.z));
          p.y += (gy - p.y) * Math.min(1, dt * 1.5);
          m.state = 'circle';
          return 5;
        }
        m.state = 'charge'; face();
        p.y += ((host.position.y + 1) - p.y) * Math.min(1, dt * 2.5);
        if (dist < 1.6 && m.attack <= 0 && !peaceful) { host.damage(2); m.attack = 1.5; m.special = 6; }
        return 9;
      }
      case 'guardian': case 'elder_guardian': {
        if (peaceful || dist > 14) { m.special = 0; return null; }
        m.state = 'aim'; face();
        m.special += dt;
        host.particles.spark?.(p.clone().lerp(host.camera.position, Math.min(1, m.special / 2.5)), '#9fe8ff', 1);
        if (m.special >= 2.5) {
          m.special = 0;
          host.damage(sp === 'guardian' ? 6 : 8);
          if (sp === 'elder_guardian') host.effect?.('mining_fatigue', 60, 2);
        }
        return 0.4;
      }
      case 'warden': {
        const sneaky = host.sneaking?.() ?? false;
        const moving = host.playerMoving ? host.playerMoving() : this.playerSpeed > 1.6;
        if (dist < 16 && moving && !sneaky) {
          const loud = this.playerSpeed > 5 ? 35 : 28;
          m.anger = Math.min(150, m.anger + loud * dt);
          m.lastNoise = host.position.clone();
        }
        if (dist < 2.5 && !sneaky) { m.anger = 150; m.lastNoise = host.position.clone(); }
        m.fuse = m.anger > 0 ? 0 : m.fuse + dt;
        if (m.fuse > 60) {
          host.particles.burst(p.clone(), '#0f4a58', 30, 3);
          this.scene.remove(m.group);
          this.mobs.splice(this.mobs.indexOf(m), 1);
          return 0;
        }
        if (peaceful) return null;
        if (m.anger >= 80) {
          m.state = 'chase'; face();
          if (dist < 2.8 && m.attack <= 0) { host.damage(30); m.attack = 1.2; host.sound('explosion', p); }
          m.special -= dt;
          if (dist >= 4 && dist <= 15 && m.special <= 0 && m.attack <= 0) {
            m.special = 5; host.damage(10); host.sound('explosion', p);
            for (let i = 0; i < 10; i++) host.particles.spark?.(p.clone().add(new THREE.Vector3(0, 1.8, 0)).lerp(host.camera.position, i / 10), '#2fd0e0', 2);
          }
          return 1.9;
        }
        if (m.lastNoise && m.anger > 10) {
          const dx = m.lastNoise.x - p.x, dz = m.lastNoise.z - p.z;
          if (Math.hypot(dx, dz) < 1.5) { m.lastNoise = null; return 0; }
          m.state = 'chase'; m.dir = Math.atan2(-dx, -dz);
          return 1.2;
        }
        if (m.state === 'chase') m.state = 'wander';
        return null;
      }
      case 'strider': {
        if (host.getBlock(p.x, p.y - 0.5, p.z) !== ID.lava && host.getBlock(p.x, p.y - 1, p.z) !== ID.lava) m.group.scale.x = 0.95 + Math.sin(this.timeline * 30) * 0.04;
        else m.group.scale.x = 1;
        return null;
      }
      case 'frog': { if (m.vy === 0 && m.state === 'wander' && this.rnd() < dt * 0.4) m.vy = 5; return null; }
      case 'parrot': case 'allay': {
        p.y += ((groundAt(this.getBlockFor(m), Math.floor(p.x), Math.floor(p.y + 0.5), Math.floor(p.z), 3) || p.y) + (sp === 'allay' ? 1.3 : 0.1) - p.y) * Math.min(1, dt * 4);
        return null;
      }
      case 'wolf': { if (!m.tamed && m.anger > 0) return melee(16, 4, 2.0); return null; }
      case 'bee': { if (m.anger > 0) return melee(12, 2, 1.4, 1.5, () => { host.effect?.('poison', 5); m.anger = 0; }); return null; }
    }
    return null;
  }

  private animateMobs(dt: number, now: number) {
    const px = this.host.position.x, py = this.host.position.y + 1.5, pz = this.host.position.z;
    const norm = (a: number) => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; };
    for (const m of this.mobs) {
      const gx = m.group.position.x, gz = m.group.position.z;
      const speed = dt > 0 ? Math.hypot(gx - (m.lastX ?? gx), gz - (m.lastZ ?? gz)) / dt : 0;
      m.lastX = gx; m.lastZ = gz;
      const wants = Math.max(0, Math.min(1, speed / 1.1));
      m.swing = (m.swing ?? 0) + (wants - (m.swing ?? 0)) * Math.min(1, dt * 9);
      const swing = m.swing ?? 0;
      if (speed > 0.05) m.walk = (m.walk ?? 0) + dt * (3.4 + Math.min(5, speed) * 2.4);
      const walk = m.walk ?? 0;
      for (const limb of m.limbs ?? []) {
        const n = limb.node;
        if (limb.kind === 'spider') {
          n.rotation.y = limb.baseY + Math.sin(walk + limb.phase) * limb.amp * swing;
          n.rotation.z = limb.baseZ + Math.cos(walk + limb.phase) * limb.amp * 0.8 * swing;
        } else if (limb.kind === 'wing') {
          const flying = m.species === 'dragon' || m.species === 'bee' || m.species === 'ghast';
          n.rotation.z = limb.baseZ + Math.sin(now * 0.02 + limb.phase) * limb.amp * (flying ? 1 : 0.25 + swing * 0.75);
        } else if (limb.kind === 'tentacle') {
          n.rotation.x = Math.sin(now * 0.0016 + limb.phase) * 0.22;
          n.rotation.z = Math.cos(now * 0.0013 + limb.phase) * 0.18;
        } else {
          n.rotation.x = limb.baseX + Math.sin(walk + limb.phase) * limb.amp * swing;
        }
      }
      const h = m.head;
      const wantYaw = Math.atan2(-(px - gx), -(pz - gz)) - m.dir;
      const near = Math.hypot(px - gx, pz - gz) < 9;
      const targetYaw = near ? Math.max(-0.9, Math.min(0.9, norm(wantYaw))) : Math.sin(now * 0.0012 + m.id) * 0.12;
      const targetPitch = m.state === 'graze' ? 0.55 + Math.sin(now * 0.0025 + m.id) * 0.08 : near ? Math.max(-0.35, Math.min(0.35, -(py - (m.group.position.y + 1.4)) * 0.2)) : Math.sin(now * 0.0017 + m.id) * 0.04;
      h.rotation.y += (targetYaw - h.rotation.y) * Math.min(1, dt * 5);
      h.rotation.x += (targetPitch - h.rotation.x) * Math.min(1, dt * 5);
    }
  }

  launchProjectile(
    kind: Projectile['kind'],
    origin: THREE.Vector3,
    dir: THREE.Vector3,
    speed: number,
    target?: THREE.Vector3,
    extra?: { damage?: number; gravity?: number; color?: string; onEnd?: (pos: THREE.Vector3) => void; flame?: boolean; punch?: number; effect?: [string, number] },
  ) {
    const color = kind === 'ender_eye' ? '#59d98a' : kind === 'ender_pearl' ? '#2f8f83' : kind === 'snowball' ? '#f2f8ff'
      : kind === 'wind_charge' ? '#b8d8ff'
      : kind === 'shulker_bullet' ? '#c9b6e8' : kind.includes('fireball') ? '#ff8a2a' : '#d8d0b5';
    const glow = kind === 'ender_eye' || kind === 'shulker_bullet' || kind === 'wind_charge' || kind.includes('fireball');
    const mesh = new THREE.Mesh(this.box, glow ? this.glowMat(color, 1) : this.mat(extra?.color ?? color));
    const size = kind.includes('fireball') ? 0.32 : kind === 'wind_charge' ? 0.26 : kind === 'shulker_bullet' ? 0.16 : 0.14;
    mesh.scale.setScalar(size);
    mesh.position.copy(origin);
    this.scene.add(mesh);
    this.projectiles.push({
      kind,
      mesh,
      v: dir.clone().normalize().multiplyScalar(speed),
      life: 8,
      damage: extra?.damage ?? (kind === 'snowball' ? 0 : kind === 'wind_charge' ? 2 : kind.includes('fireball') ? 6 : kind === 'shulker_bullet' ? 4 : 3),
      target: target?.clone(),
      gravity: extra?.gravity,
      onEnd: extra?.onEnd,
      flame: extra?.flame,
      punch: extra?.punch,
      effect: extra?.effect,
    });
  }

  private _playerHead = new THREE.Vector3();

  private updateProjectiles(dt: number) {
    if (this.projectiles.length === 0) return;
    const playerHead = this._playerHead.set(this.host.position.x, this.host.position.y + 1.4, this.host.position.z);
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      if (p.kind === 'ender_eye' && p.target) {
        this._tmpA.copy(p.target).sub(p.mesh.position).normalize().multiplyScalar(7);
        p.v.lerp(this._tmpA, Math.min(1, dt * 2));
        if (p.mesh.position.distanceTo(p.target) < 6) p.life = Math.min(p.life, 0.2);
      }
      if (p.kind.includes('fireball') || p.kind === 'shulker_bullet') p.v.y -= 1.2 * dt;
      if (p.gravity) p.v.y -= p.gravity * dt;
      p.mesh.position.addScaledVector(p.v, dt);
      p.mesh.rotation.x += dt * 3; p.mesh.rotation.y += dt * 2;
      if (p.kind === 'ender_eye' || p.kind === 'shulker_bullet' || p.kind === 'wind_charge') {
        this.host.particles.spark?.(p.mesh.position.clone(), p.kind === 'ender_eye' ? '#7af0a6' : p.kind === 'wind_charge' ? '#d8eaff' : '#d9c8f5', 1);
      }
      const blocked = this.host.getBlock(p.mesh.position.x, p.mesh.position.y, p.mesh.position.z) > 0;
      const hitPlayer = p.mesh.position.distanceTo(playerHead) < 0.7;
      let done = p.life <= 0;
      if (p.kind === 'shulker_bullet' || p.kind.includes('fireball') || p.kind === 'mob_arrow' || p.kind === 'wind_charge') {
        if (hitPlayer) {
          if (p.kind === 'shulker_bullet') this.host.levitate(9);
          else if (p.kind === 'wind_charge') {
            this.host.damage(p.damage);
            this.host.levitate(0.35);
            this.host.particles.burst(p.mesh.position.clone(), '#d8eaff', 20, 4);
          } else if (p.kind.includes('fireball')) {
            this.host.damage(p.damage);
            this.host.explode(p.mesh.position.clone(), p.kind === 'ghast_fireball' ? 2 : 1);
          } else {
            this.host.damage(p.damage);
            if (p.effect) this.host.effect?.(p.effect[0], p.effect[1], 0);
          }
          done = true;
        }
        if (!done) for (const m of this.mobs) {
          if (passive.has(m.species)) continue;
          const c = m.group.position.clone().add(new THREE.Vector3(0, 0.9, 0));
          if (p.mesh.position.distanceTo(c) > 1.1) continue;
          this.damageMob(m, p.damage, p.v.clone().normalize(), true);
          done = true; break;
        }
      } else if (p.kind === 'snowball' || p.kind === 'ender_pearl' || p.kind === 'player_arrow' || p.kind === 'trident' || p.kind === 'potion') {
        for (const m of this.mobs) {
          const c = m.group.position.clone().add(new THREE.Vector3(0, m.species === 'dragon' ? 1.5 : 0.9, 0));
          if (p.mesh.position.distanceTo(c) > (m.species === 'dragon' ? 2 : 1.05)) continue;
          if (p.kind === 'ender_pearl') {
            this.host.teleport(p.mesh.position.x, p.mesh.position.y + 1, p.mesh.position.z);
            this.host.sound('portal', p.mesh.position);
          } else {
            const snowDmg = p.kind === 'snowball' && m.species === 'blaze' ? 3 : 1;
            this.damageMob(m, p.kind === 'player_arrow' || p.kind === 'trident' ? (p.damage || 7) : p.kind === 'potion' ? 0 : snowDmg, p.v.clone().normalize(), p.kind === 'player_arrow');
            if (p.flame && this.mobs.includes(m)) this.damageMob(m, 3);
            if (p.punch && this.mobs.includes(m)) m.group.position.addScaledVector(p.v.clone().setY(0).normalize(), p.punch * 0.8);
          }
          done = true; break;
        }
      }
      if (blocked || (hitPlayer && p.kind === 'ender_pearl')) {
        if (p.kind === 'ender_pearl') {
          this.host.teleport(p.mesh.position.x, p.mesh.position.y + 1, p.mesh.position.z);
          this.host.sound('portal', p.mesh.position);
        } else if (p.kind.includes('fireball')) {
          this.host.explode(p.mesh.position.clone(), 2);
        } else if (p.kind === 'wind_charge') {
          this.host.particles.burst(p.mesh.position.clone(), '#d8eaff', 20, 4);
        }
        done = true;
      }
      if (done) {
        p.onEnd?.(p.mesh.position.clone());
        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
      }
    }
  }

  private updateCrystals(dt: number) {
    if (this.crystals.length === 0) return;
    const dragon = this.mobs.find(m => m.species === 'dragon');
    for (const c of this.crystals) {
      c.shell.rotation.y += dt * 1.6;
      c.core.rotation.y -= dt * 2.4;
      c.group.position.y = c.pos.y + Math.sin(this.timeline * 2 + c.pos.x) * 0.12;
      if (dragon && this.crystals.length && dragon.group.position.distanceTo(c.group.position) < 24) {
        dragon.hp = Math.min(dragon.maxHp, dragon.hp + dt * 4);
        if (Math.random() < dt * 8) {
          this.host.particles.spark?.(c.group.position.clone().add(new THREE.Vector3(0, 1.1, 0)), '#f28bff', 1);
        }
      }
    }
  }

  private timeline = 0;

  dispose() {
    this.clear();
    this.box.dispose();
    this.hurtMat.dispose();
    this.materials.forEach(m => m.dispose());
    this.emissiveMaterials.forEach(m => m.dispose());
  }
}
